const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2d1401,_0x43f67d){if(!_0x2d1401)throw ot(_0x43f67d);},ot=function(_0x3f0ba5){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3f0ba5);},Wr=function(_0x48065b){const _0x3cace2=[];let _0xd2e04d=0x0;for(let _0x4eaedb=0x0;_0x4eaedb<_0x48065b['length'];_0x4eaedb++){let _0x2742ab=_0x48065b['charCodeAt'](_0x4eaedb);_0x2742ab<0x80?_0x3cace2[_0xd2e04d++]=_0x2742ab:_0x2742ab<0x800?(_0x3cace2[_0xd2e04d++]=_0x2742ab>>0x6|0xc0,_0x3cace2[_0xd2e04d++]=_0x2742ab&0x3f|0x80):(_0x2742ab&0xfc00)===0xd800&&_0x4eaedb+0x1<_0x48065b['length']&&(_0x48065b['charCodeAt'](_0x4eaedb+0x1)&0xfc00)===0xdc00?(_0x2742ab=0x10000+((_0x2742ab&0x3ff)<<0xa)+(_0x48065b['charCodeAt'](++_0x4eaedb)&0x3ff),_0x3cace2[_0xd2e04d++]=_0x2742ab>>0x12|0xf0,_0x3cace2[_0xd2e04d++]=_0x2742ab>>0xc&0x3f|0x80,_0x3cace2[_0xd2e04d++]=_0x2742ab>>0x6&0x3f|0x80,_0x3cace2[_0xd2e04d++]=_0x2742ab&0x3f|0x80):(_0x3cace2[_0xd2e04d++]=_0x2742ab>>0xc|0xe0,_0x3cace2[_0xd2e04d++]=_0x2742ab>>0x6&0x3f|0x80,_0x3cace2[_0xd2e04d++]=_0x2742ab&0x3f|0x80);}return _0x3cace2;},Za=function(_0x4c0e05){const _0x1ba350=[];let _0x1f42b2=0x0,_0x2cdc05=0x0;for(;_0x1f42b2<_0x4c0e05['length'];){const _0x50bb98=_0x4c0e05[_0x1f42b2++];if(_0x50bb98<0x80)_0x1ba350[_0x2cdc05++]=String['fromCharCode'](_0x50bb98);else{if(_0x50bb98>0xbf&&_0x50bb98<0xe0){const _0x316fbf=_0x4c0e05[_0x1f42b2++];_0x1ba350[_0x2cdc05++]=String['fromCharCode']((_0x50bb98&0x1f)<<0x6|_0x316fbf&0x3f);}else{if(_0x50bb98>0xef&&_0x50bb98<0x16d){const _0x19895e=_0x4c0e05[_0x1f42b2++],_0x39c9cc=_0x4c0e05[_0x1f42b2++],_0x41c9f3=_0x4c0e05[_0x1f42b2++],_0x27c920=((_0x50bb98&0x7)<<0x12|(_0x19895e&0x3f)<<0xc|(_0x39c9cc&0x3f)<<0x6|_0x41c9f3&0x3f)-0x10000;_0x1ba350[_0x2cdc05++]=String['fromCharCode'](0xd800+(_0x27c920>>0xa)),_0x1ba350[_0x2cdc05++]=String['fromCharCode'](0xdc00+(_0x27c920&0x3ff));}else{const _0x7e6332=_0x4c0e05[_0x1f42b2++],_0x547ca5=_0x4c0e05[_0x1f42b2++];_0x1ba350[_0x2cdc05++]=String['fromCharCode']((_0x50bb98&0xf)<<0xc|(_0x7e6332&0x3f)<<0x6|_0x547ca5&0x3f);}}}}return _0x1ba350['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xf6ffb6,_0x4aec8d){if(!Array['isArray'](_0xf6ffb6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2c283f=_0x4aec8d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2656d1=[];for(let _0x517efa=0x0;_0x517efa<_0xf6ffb6['length'];_0x517efa+=0x3){const _0xd0446b=_0xf6ffb6[_0x517efa],_0x59b690=_0x517efa+0x1<_0xf6ffb6['length'],_0x28bb5a=_0x59b690?_0xf6ffb6[_0x517efa+0x1]:0x0,_0x271f25=_0x517efa+0x2<_0xf6ffb6['length'],_0x170498=_0x271f25?_0xf6ffb6[_0x517efa+0x2]:0x0,_0x1b9c14=_0xd0446b>>0x2,_0x2a41ad=(_0xd0446b&0x3)<<0x4|_0x28bb5a>>0x4;let _0x4ab386=(_0x28bb5a&0xf)<<0x2|_0x170498>>0x6,_0x53b08f=_0x170498&0x3f;_0x271f25||(_0x53b08f=0x40,_0x59b690||(_0x4ab386=0x40)),_0x2656d1['push'](_0x2c283f[_0x1b9c14],_0x2c283f[_0x2a41ad],_0x2c283f[_0x4ab386],_0x2c283f[_0x53b08f]);}return _0x2656d1['join']('');},'encodeString'(_0x458755,_0x47d8d3){return this['HAS_NATIVE_SUPPORT']&&!_0x47d8d3?btoa(_0x458755):this['encodeByteArray'](Wr(_0x458755),_0x47d8d3);},'decodeString'(_0x2f04f1,_0x41945a){return this['HAS_NATIVE_SUPPORT']&&!_0x41945a?atob(_0x2f04f1):Za(this['decodeStringToByteArray'](_0x2f04f1,_0x41945a));},'decodeStringToByteArray'(_0x3ddb8d,_0x49fd94){this['init_']();const _0x3c67f8=_0x49fd94?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5e2db3=[];for(let _0x8645ad=0x0;_0x8645ad<_0x3ddb8d['length'];){const _0x45eb04=_0x3c67f8[_0x3ddb8d['charAt'](_0x8645ad++)],_0x5e73fa=_0x8645ad<_0x3ddb8d['length']?_0x3c67f8[_0x3ddb8d['charAt'](_0x8645ad)]:0x0;++_0x8645ad;const _0x41fc56=_0x8645ad<_0x3ddb8d['length']?_0x3c67f8[_0x3ddb8d['charAt'](_0x8645ad)]:0x40;++_0x8645ad;const _0x483c96=_0x8645ad<_0x3ddb8d['length']?_0x3c67f8[_0x3ddb8d['charAt'](_0x8645ad)]:0x40;if(++_0x8645ad,_0x45eb04==null||_0x5e73fa==null||_0x41fc56==null||_0x483c96==null)throw new ec();const _0x2e9cb1=_0x45eb04<<0x2|_0x5e73fa>>0x4;if(_0x5e2db3['push'](_0x2e9cb1),_0x41fc56!==0x40){const _0x1bdc78=_0x5e73fa<<0x4&0xf0|_0x41fc56>>0x2;if(_0x5e2db3['push'](_0x1bdc78),_0x483c96!==0x40){const _0x433305=_0x41fc56<<0x6&0xc0|_0x483c96;_0x5e2db3['push'](_0x433305);}}}return _0x5e2db3;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5d0a09=0x0;_0x5d0a09<this['ENCODED_VALS']['length'];_0x5d0a09++)this['byteToCharMap_'][_0x5d0a09]=this['ENCODED_VALS']['charAt'](_0x5d0a09),this['charToByteMap_'][this['byteToCharMap_'][_0x5d0a09]]=_0x5d0a09,this['byteToCharMapWebSafe_'][_0x5d0a09]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5d0a09),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5d0a09]]=_0x5d0a09,_0x5d0a09>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5d0a09)]=_0x5d0a09,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5d0a09)]=_0x5d0a09);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x413da0){const _0x3b1b5a=Wr(_0x413da0);return Di['encodeByteArray'](_0x3b1b5a,!0x0);},an=function(_0x355cff){return Br(_0x355cff)['replace'](/\./g,'');},cn=function(_0x29264f){try{return Di['decodeString'](_0x29264f,!0x0);}catch(_0x1661f0){console['error']('base64Decode\x20failed:\x20',_0x1661f0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3ca1fc){return Vr(void 0x0,_0x3ca1fc);}function Vr(_0x1bbd2c,_0xbe628c){if(!(_0xbe628c instanceof Object))return _0xbe628c;switch(_0xbe628c['constructor']){case Date:const _0x52a393=_0xbe628c;return new Date(_0x52a393['getTime']());case Object:_0x1bbd2c===void 0x0&&(_0x1bbd2c={});break;case Array:_0x1bbd2c=[];break;default:return _0xbe628c;}for(const _0x2fa4f4 in _0xbe628c)!_0xbe628c['hasOwnProperty'](_0x2fa4f4)||!nc(_0x2fa4f4)||(_0x1bbd2c[_0x2fa4f4]=Vr(_0x1bbd2c[_0x2fa4f4],_0xbe628c[_0x2fa4f4]));return _0x1bbd2c;}function nc(_0x5f5102){return _0x5f5102!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x55933b=As['__FIREBASE_DEFAULTS__'];if(_0x55933b)return JSON['parse'](_0x55933b);},oc=()=>{if(typeof document>'u')return;let _0x1f4748;try{_0x1f4748=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1856aa=_0x1f4748&&cn(_0x1f4748[0x1]);return _0x1856aa&&JSON['parse'](_0x1856aa);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x3e70a0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3e70a0);return;}},Hr=_0x8643fb=>{var _0x252e81,_0x3e2919;return(_0x3e2919=(_0x252e81=Mi())==null?void 0x0:_0x252e81['emulatorHosts'])==null?void 0x0:_0x3e2919[_0x8643fb];},ac=_0x1d735b=>{const _0x458d7c=Hr(_0x1d735b);if(!_0x458d7c)return;const _0x4bac9f=_0x458d7c['lastIndexOf'](':');if(_0x4bac9f<=0x0||_0x4bac9f+0x1===_0x458d7c['length'])throw new Error('Invalid\x20host\x20'+_0x458d7c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5ef97b=parseInt(_0x458d7c['substring'](_0x4bac9f+0x1),0xa);return _0x458d7c[0x0]==='['?[_0x458d7c['substring'](0x1,_0x4bac9f-0x1),_0x5ef97b]:[_0x458d7c['substring'](0x0,_0x4bac9f),_0x5ef97b];},$r=()=>{var _0x6a3704;return(_0x6a3704=Mi())==null?void 0x0:_0x6a3704['config'];},Gr=_0x370a91=>{var _0x42d062;return(_0x42d062=Mi())==null?void 0x0:_0x42d062['_'+_0x370a91];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x241f2b,_0x3f106a)=>{this['resolve']=_0x241f2b,this['reject']=_0x3f106a;});}['wrapCallback'](_0x1fbedc){return(_0x150d34,_0x2638a2)=>{_0x150d34?this['reject'](_0x150d34):this['resolve'](_0x2638a2),typeof _0x1fbedc=='function'&&(this['promise']['catch'](()=>{}),_0x1fbedc['length']===0x1?_0x1fbedc(_0x150d34):_0x1fbedc(_0x150d34,_0x2638a2));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x1260e6,_0x2cbb1c){if(_0x1260e6['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3b2b5b={'alg':'none','type':'JWT'},_0x177ce8=_0x2cbb1c||'demo-project',_0xcac142=_0x1260e6['iat']||0x0,_0x4e9149=_0x1260e6['sub']||_0x1260e6['user_id'];if(!_0x4e9149)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1077d6={'iss':'https://securetoken.google.com/'+_0x177ce8,'aud':_0x177ce8,'iat':_0xcac142,'exp':_0xcac142+0xe10,'auth_time':_0xcac142,'sub':_0x4e9149,'user_id':_0x4e9149,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x1260e6};return[an(JSON['stringify'](_0x3b2b5b)),an(JSON['stringify'](_0x1077d6)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x21276b=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x21276b=='object'&&_0x21276b['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x41b7b0=W();return _0x41b7b0['indexOf']('MSIE\x20')>=0x0||_0x41b7b0['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x5ef9e1,_0x502031)=>{try{let _0x1e3f53=!0x0;const _0x152be9='validate-browser-context-for-indexeddb-analytics-module',_0x1189ef=self['indexedDB']['open'](_0x152be9);_0x1189ef['onsuccess']=()=>{_0x1189ef['result']['close'](),_0x1e3f53||self['indexedDB']['deleteDatabase'](_0x152be9),_0x5ef9e1(!0x0);},_0x1189ef['onupgradeneeded']=()=>{_0x1e3f53=!0x1;},_0x1189ef['onerror']=()=>{var _0x139100;_0x502031(((_0x139100=_0x1189ef['error'])==null?void 0x0:_0x139100['message'])||'');};}catch(_0x4d91b5){_0x502031(_0x4d91b5);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x109753,_0x48452f,_0x54e570){super(_0x48452f),this['code']=_0x109753,this['customData']=_0x54e570,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x5ab8fc,_0x2ae97c,_0x17297f){this['service']=_0x5ab8fc,this['serviceName']=_0x2ae97c,this['errors']=_0x17297f;}['create'](_0x3fb300,..._0x1dedc8){const _0xb5339a=_0x1dedc8[0x0]||{},_0x808f33=this['service']+'/'+_0x3fb300,_0x131733=this['errors'][_0x3fb300],_0x3877f9=_0x131733?gc(_0x131733,_0xb5339a):'Error',_0x57cc22=this['serviceName']+':\x20'+_0x3877f9+'\x20('+_0x808f33+').';return new Se(_0x808f33,_0x57cc22,_0xb5339a);}}function gc(_0x10714c,_0x474832){return _0x10714c['replace'](mc,(_0x2b1d81,_0x186ba7)=>{const _0x701ec5=_0x474832[_0x186ba7];return _0x701ec5!=null?String(_0x701ec5):'<'+_0x186ba7+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x516535){return JSON['parse'](_0x516535);}function O(_0x5818cd){return JSON['stringify'](_0x5818cd);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x424df3){let _0x532c8e={},_0x5af3c5={},_0x54924={},_0x1e0eea='';try{const _0x5e3c77=_0x424df3['split']('.');_0x532c8e=bt(cn(_0x5e3c77[0x0])||''),_0x5af3c5=bt(cn(_0x5e3c77[0x1])||''),_0x1e0eea=_0x5e3c77[0x2],_0x54924=_0x5af3c5['d']||{},delete _0x5af3c5['d'];}catch{}return{'header':_0x532c8e,'claims':_0x5af3c5,'data':_0x54924,'signature':_0x1e0eea};},yc=function(_0x477085){const _0x412949=zr(_0x477085),_0x3c21cb=_0x412949['claims'];return!!_0x3c21cb&&typeof _0x3c21cb=='object'&&_0x3c21cb['hasOwnProperty']('iat');},vc=function(_0x29a64d){const _0x25625f=zr(_0x29a64d)['claims'];return typeof _0x25625f=='object'&&_0x25625f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x233154,_0x51f9bd){return Object['prototype']['hasOwnProperty']['call'](_0x233154,_0x51f9bd);}function Oe(_0x42bad8,_0x41fd71){if(Object['prototype']['hasOwnProperty']['call'](_0x42bad8,_0x41fd71))return _0x42bad8[_0x41fd71];}function hi(_0x494bff){for(const _0x1c055e in _0x494bff)if(Object['prototype']['hasOwnProperty']['call'](_0x494bff,_0x1c055e))return!0x1;return!0x0;}function ln(_0x43d810,_0xed3c57,_0x1cb767){const _0x3b98de={};for(const _0x2ce304 in _0x43d810)Object['prototype']['hasOwnProperty']['call'](_0x43d810,_0x2ce304)&&(_0x3b98de[_0x2ce304]=_0xed3c57['call'](_0x1cb767,_0x43d810[_0x2ce304],_0x2ce304,_0x43d810));return _0x3b98de;}function De(_0x403054,_0x1b64f1){if(_0x403054===_0x1b64f1)return!0x0;const _0x4c045b=Object['keys'](_0x403054),_0x3e9a06=Object['keys'](_0x1b64f1);for(const _0xc521a6 of _0x4c045b){if(!_0x3e9a06['includes'](_0xc521a6))return!0x1;const _0xb4a63a=_0x403054[_0xc521a6],_0x1b7508=_0x1b64f1[_0xc521a6];if(ks(_0xb4a63a)&&ks(_0x1b7508)){if(!De(_0xb4a63a,_0x1b7508))return!0x1;}else{if(_0xb4a63a!==_0x1b7508)return!0x1;}}for(const _0x2e54d5 of _0x3e9a06)if(!_0x4c045b['includes'](_0x2e54d5))return!0x1;return!0x0;}function ks(_0x1a3908){return _0x1a3908!==null&&typeof _0x1a3908=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x1229b2){const _0x2a2e53=[];for(const [_0x2e2fcb,_0x3e457b]of Object['entries'](_0x1229b2))Array['isArray'](_0x3e457b)?_0x3e457b['forEach'](_0xafbcba=>{_0x2a2e53['push'](encodeURIComponent(_0x2e2fcb)+'='+encodeURIComponent(_0xafbcba));}):_0x2a2e53['push'](encodeURIComponent(_0x2e2fcb)+'='+encodeURIComponent(_0x3e457b));return _0x2a2e53['length']?'&'+_0x2a2e53['join']('&'):'';}function yt(_0x1b0a70){const _0x143235={};return _0x1b0a70['replace'](/^\?/,'')['split']('&')['forEach'](_0x572a8a=>{if(_0x572a8a){const [_0x22ac9e,_0x39f58e]=_0x572a8a['split']('=');_0x143235[decodeURIComponent(_0x22ac9e)]=decodeURIComponent(_0x39f58e);}}),_0x143235;}function vt(_0x1333a3){const _0x39f37e=_0x1333a3['indexOf']('?');if(!_0x39f37e)return'';const _0xec3daf=_0x1333a3['indexOf']('#',_0x39f37e);return _0x1333a3['substring'](_0x39f37e,_0xec3daf>0x0?_0xec3daf:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4c3c60=0x1;_0x4c3c60<this['blockSize'];++_0x4c3c60)this['pad_'][_0x4c3c60]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2e45f4,_0x1940c6){_0x1940c6||(_0x1940c6=0x0);const _0x4ba917=this['W_'];if(typeof _0x2e45f4=='string'){for(let _0x4ccdf8=0x0;_0x4ccdf8<0x10;_0x4ccdf8++)_0x4ba917[_0x4ccdf8]=_0x2e45f4['charCodeAt'](_0x1940c6)<<0x18|_0x2e45f4['charCodeAt'](_0x1940c6+0x1)<<0x10|_0x2e45f4['charCodeAt'](_0x1940c6+0x2)<<0x8|_0x2e45f4['charCodeAt'](_0x1940c6+0x3),_0x1940c6+=0x4;}else{for(let _0x88ed3f=0x0;_0x88ed3f<0x10;_0x88ed3f++)_0x4ba917[_0x88ed3f]=_0x2e45f4[_0x1940c6]<<0x18|_0x2e45f4[_0x1940c6+0x1]<<0x10|_0x2e45f4[_0x1940c6+0x2]<<0x8|_0x2e45f4[_0x1940c6+0x3],_0x1940c6+=0x4;}for(let _0x5ca8e1=0x10;_0x5ca8e1<0x50;_0x5ca8e1++){const _0x1bac6c=_0x4ba917[_0x5ca8e1-0x3]^_0x4ba917[_0x5ca8e1-0x8]^_0x4ba917[_0x5ca8e1-0xe]^_0x4ba917[_0x5ca8e1-0x10];_0x4ba917[_0x5ca8e1]=(_0x1bac6c<<0x1|_0x1bac6c>>>0x1f)&0xffffffff;}let _0x469fd4=this['chain_'][0x0],_0x25f202=this['chain_'][0x1],_0x4a8cfc=this['chain_'][0x2],_0x1c87be=this['chain_'][0x3],_0x2f559c=this['chain_'][0x4],_0xcfd7d4,_0x5d38bb;for(let _0x27b413=0x0;_0x27b413<0x50;_0x27b413++){_0x27b413<0x28?_0x27b413<0x14?(_0xcfd7d4=_0x1c87be^_0x25f202&(_0x4a8cfc^_0x1c87be),_0x5d38bb=0x5a827999):(_0xcfd7d4=_0x25f202^_0x4a8cfc^_0x1c87be,_0x5d38bb=0x6ed9eba1):_0x27b413<0x3c?(_0xcfd7d4=_0x25f202&_0x4a8cfc|_0x1c87be&(_0x25f202|_0x4a8cfc),_0x5d38bb=0x8f1bbcdc):(_0xcfd7d4=_0x25f202^_0x4a8cfc^_0x1c87be,_0x5d38bb=0xca62c1d6);const _0x5c1cae=(_0x469fd4<<0x5|_0x469fd4>>>0x1b)+_0xcfd7d4+_0x2f559c+_0x5d38bb+_0x4ba917[_0x27b413]&0xffffffff;_0x2f559c=_0x1c87be,_0x1c87be=_0x4a8cfc,_0x4a8cfc=(_0x25f202<<0x1e|_0x25f202>>>0x2)&0xffffffff,_0x25f202=_0x469fd4,_0x469fd4=_0x5c1cae;}this['chain_'][0x0]=this['chain_'][0x0]+_0x469fd4&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x25f202&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4a8cfc&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1c87be&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2f559c&0xffffffff;}['update'](_0x36c814,_0x3cf1a3){if(_0x36c814==null)return;_0x3cf1a3===void 0x0&&(_0x3cf1a3=_0x36c814['length']);const _0x2c61d1=_0x3cf1a3-this['blockSize'];let _0x298b79=0x0;const _0x1e3f39=this['buf_'];let _0x2b0718=this['inbuf_'];for(;_0x298b79<_0x3cf1a3;){if(_0x2b0718===0x0){for(;_0x298b79<=_0x2c61d1;)this['compress_'](_0x36c814,_0x298b79),_0x298b79+=this['blockSize'];}if(typeof _0x36c814=='string'){for(;_0x298b79<_0x3cf1a3;)if(_0x1e3f39[_0x2b0718]=_0x36c814['charCodeAt'](_0x298b79),++_0x2b0718,++_0x298b79,_0x2b0718===this['blockSize']){this['compress_'](_0x1e3f39),_0x2b0718=0x0;break;}}else{for(;_0x298b79<_0x3cf1a3;)if(_0x1e3f39[_0x2b0718]=_0x36c814[_0x298b79],++_0x2b0718,++_0x298b79,_0x2b0718===this['blockSize']){this['compress_'](_0x1e3f39),_0x2b0718=0x0;break;}}}this['inbuf_']=_0x2b0718,this['total_']+=_0x3cf1a3;}['digest'](){const _0x4738dd=[];let _0x2d7c4c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2f795c=this['blockSize']-0x1;_0x2f795c>=0x38;_0x2f795c--)this['buf_'][_0x2f795c]=_0x2d7c4c&0xff,_0x2d7c4c/=0x100;this['compress_'](this['buf_']);let _0x36e08e=0x0;for(let _0x1bfa97=0x0;_0x1bfa97<0x5;_0x1bfa97++)for(let _0x52c939=0x18;_0x52c939>=0x0;_0x52c939-=0x8)_0x4738dd[_0x36e08e]=this['chain_'][_0x1bfa97]>>_0x52c939&0xff,++_0x36e08e;return _0x4738dd;}}function Ic(_0x506936,_0x1bfdcb){const _0x476f22=new wc(_0x506936,_0x1bfdcb);return _0x476f22['subscribe']['bind'](_0x476f22);}class wc{constructor(_0xec613c,_0x59c0ce){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x59c0ce,this['task']['then'](()=>{_0xec613c(this);})['catch'](_0x2fac2b=>{this['error'](_0x2fac2b);});}['next'](_0x1a4b30){this['forEachObserver'](_0x2a6ff1=>{_0x2a6ff1['next'](_0x1a4b30);});}['error'](_0x591696){this['forEachObserver'](_0xd11749=>{_0xd11749['error'](_0x591696);}),this['close'](_0x591696);}['complete'](){this['forEachObserver'](_0x50e2a7=>{_0x50e2a7['complete']();}),this['close']();}['subscribe'](_0x4e0b17,_0x3c9783,_0x3cb861){let _0x4e2845;if(_0x4e0b17===void 0x0&&_0x3c9783===void 0x0&&_0x3cb861===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x4e0b17,['next','error','complete'])?_0x4e2845=_0x4e0b17:_0x4e2845={'next':_0x4e0b17,'error':_0x3c9783,'complete':_0x3cb861},_0x4e2845['next']===void 0x0&&(_0x4e2845['next']=Qn),_0x4e2845['error']===void 0x0&&(_0x4e2845['error']=Qn),_0x4e2845['complete']===void 0x0&&(_0x4e2845['complete']=Qn);const _0x4c8d77=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4e2845['error'](this['finalError']):_0x4e2845['complete']();}catch{}}),this['observers']['push'](_0x4e2845),_0x4c8d77;}['unsubscribeOne'](_0x5706ae){this['observers']===void 0x0||this['observers'][_0x5706ae]===void 0x0||(delete this['observers'][_0x5706ae],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2851d3){if(!this['finalized']){for(let _0x1320ec=0x0;_0x1320ec<this['observers']['length'];_0x1320ec++)this['sendOne'](_0x1320ec,_0x2851d3);}}['sendOne'](_0x381b01,_0x30aac7){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x381b01]!==void 0x0)try{_0x30aac7(this['observers'][_0x381b01]);}catch(_0x2d9fcf){typeof console<'u'&&console['error']&&console['error'](_0x2d9fcf);}});}['close'](_0x2e0eed){this['finalized']||(this['finalized']=!0x0,_0x2e0eed!==void 0x0&&(this['finalError']=_0x2e0eed),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3e9c27,_0x4f27ae){if(typeof _0x3e9c27!='object'||_0x3e9c27===null)return!0x1;for(const _0x431825 of _0x4f27ae)if(_0x431825 in _0x3e9c27&&typeof _0x3e9c27[_0x431825]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0xd983fb,_0x12c2b0){return _0xd983fb+'\x20failed:\x20'+_0x12c2b0+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x4f813){const _0x5e61d4=[];let _0x1dc192=0x0;for(let _0x49627b=0x0;_0x49627b<_0x4f813['length'];_0x49627b++){let _0x37f6b8=_0x4f813['charCodeAt'](_0x49627b);if(_0x37f6b8>=0xd800&&_0x37f6b8<=0xdbff){const _0xd25da5=_0x37f6b8-0xd800;_0x49627b++,f(_0x49627b<_0x4f813['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0xe3a1aa=_0x4f813['charCodeAt'](_0x49627b)-0xdc00;_0x37f6b8=0x10000+(_0xd25da5<<0xa)+_0xe3a1aa;}_0x37f6b8<0x80?_0x5e61d4[_0x1dc192++]=_0x37f6b8:_0x37f6b8<0x800?(_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0x6|0xc0,_0x5e61d4[_0x1dc192++]=_0x37f6b8&0x3f|0x80):_0x37f6b8<0x10000?(_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0xc|0xe0,_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0x6&0x3f|0x80,_0x5e61d4[_0x1dc192++]=_0x37f6b8&0x3f|0x80):(_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0x12|0xf0,_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0xc&0x3f|0x80,_0x5e61d4[_0x1dc192++]=_0x37f6b8>>0x6&0x3f|0x80,_0x5e61d4[_0x1dc192++]=_0x37f6b8&0x3f|0x80);}return _0x5e61d4;},Pn=function(_0x54b26c){let _0x3a4ef9=0x0;for(let _0x1d9cb5=0x0;_0x1d9cb5<_0x54b26c['length'];_0x1d9cb5++){const _0x7f240b=_0x54b26c['charCodeAt'](_0x1d9cb5);_0x7f240b<0x80?_0x3a4ef9++:_0x7f240b<0x800?_0x3a4ef9+=0x2:_0x7f240b>=0xd800&&_0x7f240b<=0xdbff?(_0x3a4ef9+=0x4,_0x1d9cb5++):_0x3a4ef9+=0x3;}return _0x3a4ef9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x403306){return _0x403306&&_0x403306['_delegate']?_0x403306['_delegate']:_0x403306;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x3c9411){try{return(_0x3c9411['startsWith']('http://')||_0x3c9411['startsWith']('https://')?new URL(_0x3c9411)['hostname']:_0x3c9411)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1e6f6c){return(await fetch(_0x1e6f6c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x45c6f2,_0x565347,_0x5860ad){this['name']=_0x45c6f2,this['instanceFactory']=_0x565347,this['type']=_0x5860ad,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x131808){return this['instantiationMode']=_0x131808,this;}['setMultipleInstances'](_0x1521c3){return this['multipleInstances']=_0x1521c3,this;}['setServiceProps'](_0x3c05f9){return this['serviceProps']=_0x3c05f9,this;}['setInstanceCreatedCallback'](_0x56db81){return this['onInstanceCreated']=_0x56db81,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0xadf6c6,_0x1fd97e){this['name']=_0xadf6c6,this['container']=_0x1fd97e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x20bc95){const _0x2d2d7a=this['normalizeInstanceIdentifier'](_0x20bc95);if(!this['instancesDeferred']['has'](_0x2d2d7a)){const _0x28de3f=new Ve();if(this['instancesDeferred']['set'](_0x2d2d7a,_0x28de3f),this['isInitialized'](_0x2d2d7a)||this['shouldAutoInitialize']())try{const _0x477d68=this['getOrInitializeService']({'instanceIdentifier':_0x2d2d7a});_0x477d68&&_0x28de3f['resolve'](_0x477d68);}catch{}}return this['instancesDeferred']['get'](_0x2d2d7a)['promise'];}['getImmediate'](_0x157ef4){const _0x15fc05=this['normalizeInstanceIdentifier'](_0x157ef4==null?void 0x0:_0x157ef4['identifier']),_0xf7e60d=(_0x157ef4==null?void 0x0:_0x157ef4['optional'])??!0x1;if(this['isInitialized'](_0x15fc05)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x15fc05});}catch(_0x3b60f9){if(_0xf7e60d)return null;throw _0x3b60f9;}else{if(_0xf7e60d)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x28bc40){if(_0x28bc40['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x28bc40['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x28bc40,!!this['shouldAutoInitialize']()){if(Rc(_0x28bc40))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x113ab1,_0x172d3a]of this['instancesDeferred']['entries']()){const _0x4c475f=this['normalizeInstanceIdentifier'](_0x113ab1);try{const _0xe9bd6f=this['getOrInitializeService']({'instanceIdentifier':_0x4c475f});_0x172d3a['resolve'](_0xe9bd6f);}catch{}}}}['clearInstance'](_0x287632=ke){this['instancesDeferred']['delete'](_0x287632),this['instancesOptions']['delete'](_0x287632),this['instances']['delete'](_0x287632);}async['delete'](){const _0x38be05=Array['from'](this['instances']['values']());await Promise['all']([..._0x38be05['filter'](_0x4c4b24=>'INTERNAL'in _0x4c4b24)['map'](_0x1c2c46=>_0x1c2c46['INTERNAL']['delete']()),..._0x38be05['filter'](_0x1ba5bd=>'_delete'in _0x1ba5bd)['map'](_0x2d30b3=>_0x2d30b3['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x280cfe=ke){return this['instances']['has'](_0x280cfe);}['getOptions'](_0x1ee345=ke){return this['instancesOptions']['get'](_0x1ee345)||{};}['initialize'](_0x2b2f42={}){const {options:_0x3d215a={}}=_0x2b2f42,_0x4bec44=this['normalizeInstanceIdentifier'](_0x2b2f42['instanceIdentifier']);if(this['isInitialized'](_0x4bec44))throw Error(this['name']+'('+_0x4bec44+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x6d66e3=this['getOrInitializeService']({'instanceIdentifier':_0x4bec44,'options':_0x3d215a});for(const [_0x5e043a,_0x5d82f4]of this['instancesDeferred']['entries']()){const _0x504cc3=this['normalizeInstanceIdentifier'](_0x5e043a);_0x4bec44===_0x504cc3&&_0x5d82f4['resolve'](_0x6d66e3);}return _0x6d66e3;}['onInit'](_0x14eabe,_0x2bb12f){const _0xcc6fe6=this['normalizeInstanceIdentifier'](_0x2bb12f),_0x2a3567=this['onInitCallbacks']['get'](_0xcc6fe6)??new Set();_0x2a3567['add'](_0x14eabe),this['onInitCallbacks']['set'](_0xcc6fe6,_0x2a3567);const _0xcd41f0=this['instances']['get'](_0xcc6fe6);return _0xcd41f0&&_0x14eabe(_0xcd41f0,_0xcc6fe6),()=>{_0x2a3567['delete'](_0x14eabe);};}['invokeOnInitCallbacks'](_0x440987,_0x3b0ea9){const _0x1c8dd2=this['onInitCallbacks']['get'](_0x3b0ea9);if(_0x1c8dd2){for(const _0x39e12b of _0x1c8dd2)try{_0x39e12b(_0x440987,_0x3b0ea9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x59815f,options:_0x3ddd92={}}){let _0xe4a6ad=this['instances']['get'](_0x59815f);if(!_0xe4a6ad&&this['component']&&(_0xe4a6ad=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x59815f),'options':_0x3ddd92}),this['instances']['set'](_0x59815f,_0xe4a6ad),this['instancesOptions']['set'](_0x59815f,_0x3ddd92),this['invokeOnInitCallbacks'](_0xe4a6ad,_0x59815f),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x59815f,_0xe4a6ad);}catch{}return _0xe4a6ad||null;}['normalizeInstanceIdentifier'](_0x4e0e13=ke){return this['component']?this['component']['multipleInstances']?_0x4e0e13:ke:_0x4e0e13;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x18f1be){return _0x18f1be===ke?void 0x0:_0x18f1be;}function Rc(_0x2273ea){return _0x2273ea['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x567724){this['name']=_0x567724,this['providers']=new Map();}['addComponent'](_0x25bf3b){const _0xca0c6c=this['getProvider'](_0x25bf3b['name']);if(_0xca0c6c['isComponentSet']())throw new Error('Component\x20'+_0x25bf3b['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xca0c6c['setComponent'](_0x25bf3b);}['addOrOverwriteComponent'](_0x5b2f78){this['getProvider'](_0x5b2f78['name'])['isComponentSet']()&&this['providers']['delete'](_0x5b2f78['name']),this['addComponent'](_0x5b2f78);}['getProvider'](_0x5d2061){if(this['providers']['has'](_0x5d2061))return this['providers']['get'](_0x5d2061);const _0x3a0e58=new Sc(_0x5d2061,this);return this['providers']['set'](_0x5d2061,_0x3a0e58),_0x3a0e58;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1660cd){_0x1660cd[_0x1660cd['DEBUG']=0x0]='DEBUG',_0x1660cd[_0x1660cd['VERBOSE']=0x1]='VERBOSE',_0x1660cd[_0x1660cd['INFO']=0x2]='INFO',_0x1660cd[_0x1660cd['WARN']=0x3]='WARN',_0x1660cd[_0x1660cd['ERROR']=0x4]='ERROR',_0x1660cd[_0x1660cd['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x37b49f,_0x66f4c,..._0x227dd7)=>{if(_0x66f4c<_0x37b49f['logLevel'])return;const _0x1da7a7=new Date()['toISOString'](),_0x5233b0=Pc[_0x66f4c];if(_0x5233b0)console[_0x5233b0]('['+_0x1da7a7+']\x20\x20'+_0x37b49f['name']+':',..._0x227dd7);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x66f4c+')');};class xi{constructor(_0x11dc5a){this['name']=_0x11dc5a,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1678ec){if(!(_0x1678ec in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1678ec+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1678ec;}['setLogLevel'](_0x19d605){this['_logLevel']=typeof _0x19d605=='string'?kc[_0x19d605]:_0x19d605;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x56d2e3){if(typeof _0x56d2e3!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x56d2e3;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x38ed8d){this['_userLogHandler']=_0x38ed8d;}['debug'](..._0x2c0920){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2c0920),this['_logHandler'](this,T['DEBUG'],..._0x2c0920);}['log'](..._0x33b2fc){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x33b2fc),this['_logHandler'](this,T['VERBOSE'],..._0x33b2fc);}['info'](..._0x533eaf){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x533eaf),this['_logHandler'](this,T['INFO'],..._0x533eaf);}['warn'](..._0x19ad81){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x19ad81),this['_logHandler'](this,T['WARN'],..._0x19ad81);}['error'](..._0x3746c3){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3746c3),this['_logHandler'](this,T['ERROR'],..._0x3746c3);}}const Dc=(_0x3af39b,_0x43c338)=>_0x43c338['some'](_0x282f6e=>_0x3af39b instanceof _0x282f6e);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x1cfb0b){const _0x577cbb=new Promise((_0x32a636,_0x571412)=>{const _0x2e6ea6=()=>{_0x1cfb0b['removeEventListener']('success',_0x362674),_0x1cfb0b['removeEventListener']('error',_0x436d51);},_0x362674=()=>{_0x32a636(_e(_0x1cfb0b['result'])),_0x2e6ea6();},_0x436d51=()=>{_0x571412(_0x1cfb0b['error']),_0x2e6ea6();};_0x1cfb0b['addEventListener']('success',_0x362674),_0x1cfb0b['addEventListener']('error',_0x436d51);});return _0x577cbb['then'](_0x35ecf0=>{_0x35ecf0 instanceof IDBCursor&&Kr['set'](_0x35ecf0,_0x1cfb0b);})['catch'](()=>{}),Fi['set'](_0x577cbb,_0x1cfb0b),_0x577cbb;}function Fc(_0x1f6971){if(ui['has'](_0x1f6971))return;const _0x5adbd1=new Promise((_0x28491b,_0x3dec7a)=>{const _0x31018b=()=>{_0x1f6971['removeEventListener']('complete',_0x26aa41),_0x1f6971['removeEventListener']('error',_0xa7d468),_0x1f6971['removeEventListener']('abort',_0xa7d468);},_0x26aa41=()=>{_0x28491b(),_0x31018b();},_0xa7d468=()=>{_0x3dec7a(_0x1f6971['error']||new DOMException('AbortError','AbortError')),_0x31018b();};_0x1f6971['addEventListener']('complete',_0x26aa41),_0x1f6971['addEventListener']('error',_0xa7d468),_0x1f6971['addEventListener']('abort',_0xa7d468);});ui['set'](_0x1f6971,_0x5adbd1);}let di={'get'(_0x4bdd1c,_0x59e03b,_0x104691){if(_0x4bdd1c instanceof IDBTransaction){if(_0x59e03b==='done')return ui['get'](_0x4bdd1c);if(_0x59e03b==='objectStoreNames')return _0x4bdd1c['objectStoreNames']||Yr['get'](_0x4bdd1c);if(_0x59e03b==='store')return _0x104691['objectStoreNames'][0x1]?void 0x0:_0x104691['objectStore'](_0x104691['objectStoreNames'][0x0]);}return _e(_0x4bdd1c[_0x59e03b]);},'set'(_0x49acc3,_0x2ef133,_0x817ae){return _0x49acc3[_0x2ef133]=_0x817ae,!0x0;},'has'(_0x146fe6,_0x4b367c){return _0x146fe6 instanceof IDBTransaction&&(_0x4b367c==='done'||_0x4b367c==='store')?!0x0:_0x4b367c in _0x146fe6;}};function Uc(_0x329504){di=_0x329504(di);}function Wc(_0x2e251b){return _0x2e251b===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x352ee9,..._0x55f987){const _0x361304=_0x2e251b['call'](Xn(this),_0x352ee9,..._0x55f987);return Yr['set'](_0x361304,_0x352ee9['sort']?_0x352ee9['sort']():[_0x352ee9]),_e(_0x361304);}:Lc()['includes'](_0x2e251b)?function(..._0x50870f){return _0x2e251b['apply'](Xn(this),_0x50870f),_e(Kr['get'](this));}:function(..._0xe77107){return _e(_0x2e251b['apply'](Xn(this),_0xe77107));};}function Bc(_0x3845d1){return typeof _0x3845d1=='function'?Wc(_0x3845d1):(_0x3845d1 instanceof IDBTransaction&&Fc(_0x3845d1),Dc(_0x3845d1,Mc())?new Proxy(_0x3845d1,di):_0x3845d1);}function _e(_0x5d96a5){if(_0x5d96a5 instanceof IDBRequest)return xc(_0x5d96a5);if(Jn['has'](_0x5d96a5))return Jn['get'](_0x5d96a5);const _0x40f833=Bc(_0x5d96a5);return _0x40f833!==_0x5d96a5&&(Jn['set'](_0x5d96a5,_0x40f833),Fi['set'](_0x40f833,_0x5d96a5)),_0x40f833;}const Xn=_0x37f848=>Fi['get'](_0x37f848);function Vc(_0x34c64b,_0x162550,{blocked:_0x5c4cb3,upgrade:_0x16fba1,blocking:_0x593901,terminated:_0x773b90}={}){const _0x547617=indexedDB['open'](_0x34c64b,_0x162550),_0x545d31=_e(_0x547617);return _0x16fba1&&_0x547617['addEventListener']('upgradeneeded',_0x1e1b49=>{_0x16fba1(_e(_0x547617['result']),_0x1e1b49['oldVersion'],_0x1e1b49['newVersion'],_e(_0x547617['transaction']),_0x1e1b49);}),_0x5c4cb3&&_0x547617['addEventListener']('blocked',_0x10afd0=>_0x5c4cb3(_0x10afd0['oldVersion'],_0x10afd0['newVersion'],_0x10afd0)),_0x545d31['then'](_0x4c9a3a=>{_0x773b90&&_0x4c9a3a['addEventListener']('close',()=>_0x773b90()),_0x593901&&_0x4c9a3a['addEventListener']('versionchange',_0x237961=>_0x593901(_0x237961['oldVersion'],_0x237961['newVersion'],_0x237961));})['catch'](()=>{}),_0x545d31;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x7166a1,_0x57cdec){if(!(_0x7166a1 instanceof IDBDatabase&&!(_0x57cdec in _0x7166a1)&&typeof _0x57cdec=='string'))return;if(Zn['get'](_0x57cdec))return Zn['get'](_0x57cdec);const _0x1d342a=_0x57cdec['replace'](/FromIndex$/,''),_0x2f19af=_0x57cdec!==_0x1d342a,_0x5de075=$c['includes'](_0x1d342a);if(!(_0x1d342a in(_0x2f19af?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5de075||Hc['includes'](_0x1d342a)))return;const _0x154d63=async function(_0x36d85f,..._0x14f81b){const _0x4d4105=this['transaction'](_0x36d85f,_0x5de075?'readwrite':'readonly');let _0x2d0462=_0x4d4105['store'];return _0x2f19af&&(_0x2d0462=_0x2d0462['index'](_0x14f81b['shift']())),(await Promise['all']([_0x2d0462[_0x1d342a](..._0x14f81b),_0x5de075&&_0x4d4105['done']]))[0x0];};return Zn['set'](_0x57cdec,_0x154d63),_0x154d63;}Uc(_0x78324b=>({..._0x78324b,'get':(_0x4b88d1,_0x568e85,_0x26741f)=>Os(_0x4b88d1,_0x568e85)||_0x78324b['get'](_0x4b88d1,_0x568e85,_0x26741f),'has':(_0x13ebf6,_0x2d10d7)=>!!Os(_0x13ebf6,_0x2d10d7)||_0x78324b['has'](_0x13ebf6,_0x2d10d7)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x4a319b){this['container']=_0x4a319b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2a9c39=>{if(qc(_0x2a9c39)){const _0x5e8914=_0x2a9c39['getImmediate']();return _0x5e8914['library']+'/'+_0x5e8914['version'];}else return null;})['filter'](_0x647d6c=>_0x647d6c)['join']('\x20');}}function qc(_0x34927a){const _0x1cdc01=_0x34927a['getComponent']();return(_0x1cdc01==null?void 0x0:_0x1cdc01['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x1228ee,_0x384d5f){try{_0x1228ee['container']['addComponent'](_0x384d5f);}catch(_0x42068a){re['debug']('Component\x20'+_0x384d5f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1228ee['name'],_0x42068a);}}function et(_0x4a6eb7){const _0x1aa31a=_0x4a6eb7['name'];if(gi['has'](_0x1aa31a))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1aa31a+'.'),!0x1;gi['set'](_0x1aa31a,_0x4a6eb7);for(const _0x5c6062 of Le['values']())Ms(_0x5c6062,_0x4a6eb7);for(const _0x29e801 of _i['values']())Ms(_0x29e801,_0x4a6eb7);return!0x0;}function Ui(_0x2c4520,_0x1657eb){const _0x45c5a4=_0x2c4520['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x45c5a4&&_0x45c5a4['triggerHeartbeat'](),_0x2c4520['container']['getProvider'](_0x1657eb);}function H(_0x274c7f){return _0x274c7f==null?!0x1:_0x274c7f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4c0dc5,_0xfe265c,_0x27f7e7){this['_isDeleted']=!0x1,this['_options']={..._0x4c0dc5},this['_config']={..._0xfe265c},this['_name']=_0xfe265c['name'],this['_automaticDataCollectionEnabled']=_0xfe265c['automaticDataCollectionEnabled'],this['_container']=_0x27f7e7,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2af1be){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2af1be;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x49eb9d){this['_isDeleted']=_0x49eb9d;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x15b94a,_0x4b606c={}){let _0x341aae=_0x15b94a;typeof _0x4b606c!='object'&&(_0x4b606c={'name':_0x4b606c});const _0x20506d={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4b606c},_0x564471=_0x20506d['name'];if(typeof _0x564471!='string'||!_0x564471)throw ge['create']('bad-app-name',{'appName':String(_0x564471)});if(_0x341aae||(_0x341aae=$r()),!_0x341aae)throw ge['create']('no-options');const _0x7784c9=Le['get'](_0x564471);if(_0x7784c9){if(De(_0x341aae,_0x7784c9['options'])&&De(_0x20506d,_0x7784c9['config']))return _0x7784c9;throw ge['create']('duplicate-app',{'appName':_0x564471});}const _0x9d58e3=new Ac(_0x564471);for(const _0x63b0ae of gi['values']())_0x9d58e3['addComponent'](_0x63b0ae);const _0x749798=new Il(_0x341aae,_0x20506d,_0x9d58e3);return Le['set'](_0x564471,_0x749798),_0x749798;}function Qr(_0x2f4c8c=pi){const _0x3e850d=Le['get'](_0x2f4c8c);if(!_0x3e850d&&_0x2f4c8c===pi&&$r())return wl();if(!_0x3e850d)throw ge['create']('no-app',{'appName':_0x2f4c8c});return _0x3e850d;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5dd7f8){let _0x1e7f14=!0x1;const _0x301d50=_0x5dd7f8['name'];Le['has'](_0x301d50)?(_0x1e7f14=!0x0,Le['delete'](_0x301d50)):_i['has'](_0x301d50)&&_0x5dd7f8['decRefCount']()<=0x0&&(_i['delete'](_0x301d50),_0x1e7f14=!0x0),_0x1e7f14&&(await Promise['all'](_0x5dd7f8['container']['getProviders']()['map'](_0x28de00=>_0x28de00['delete']())),_0x5dd7f8['isDeleted']=!0x0);}function me(_0x44f3e3,_0x26c2c2,_0x424017){let _0x2c0865=vl[_0x44f3e3]??_0x44f3e3;_0x424017&&(_0x2c0865+='-'+_0x424017);const _0x52024b=_0x2c0865['match'](/\s|\//),_0xb3655b=_0x26c2c2['match'](/\s|\//);if(_0x52024b||_0xb3655b){const _0x2f3b4f=['Unable\x20to\x20register\x20library\x20\x22'+_0x2c0865+'\x22\x20with\x20version\x20\x22'+_0x26c2c2+'\x22:'];_0x52024b&&_0x2f3b4f['push']('library\x20name\x20\x22'+_0x2c0865+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x52024b&&_0xb3655b&&_0x2f3b4f['push']('and'),_0xb3655b&&_0x2f3b4f['push']('version\x20name\x20\x22'+_0x26c2c2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x2f3b4f['join']('\x20'));return;}et(new Me(_0x2c0865+'-version',()=>({'library':_0x2c0865,'version':_0x26c2c2}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2d7e51,_0xacd25a)=>{switch(_0xacd25a){case 0x0:try{_0x2d7e51['createObjectStore'](Rt);}catch(_0xf8c351){console['warn'](_0xf8c351);}}}})['catch'](_0x29402f=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x29402f['message']});})),ei;}async function Sl(_0x407130){try{const _0x12a8a5=(await Jr())['transaction'](Rt),_0x5beb33=await _0x12a8a5['objectStore'](Rt)['get'](Xr(_0x407130));return await _0x12a8a5['done'],_0x5beb33;}catch(_0x44c9d7){if(_0x44c9d7 instanceof Se)re['warn'](_0x44c9d7['message']);else{const _0x564580=ge['create']('idb-get',{'originalErrorMessage':_0x44c9d7==null?void 0x0:_0x44c9d7['message']});re['warn'](_0x564580['message']);}}}async function Ls(_0x15d683,_0x524164){try{const _0x4a9e84=(await Jr())['transaction'](Rt,'readwrite');await _0x4a9e84['objectStore'](Rt)['put'](_0x524164,Xr(_0x15d683)),await _0x4a9e84['done'];}catch(_0x3a9aae){if(_0x3a9aae instanceof Se)re['warn'](_0x3a9aae['message']);else{const _0x247feb=ge['create']('idb-set',{'originalErrorMessage':_0x3a9aae==null?void 0x0:_0x3a9aae['message']});re['warn'](_0x247feb['message']);}}}function Xr(_0xd75170){return _0xd75170['name']+'!'+_0xd75170['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x24f050){this['container']=_0x24f050,this['_heartbeatsCache']=null;const _0x33d593=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x33d593),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x568fc6=>(this['_heartbeatsCache']=_0x568fc6,_0x568fc6));}async['triggerHeartbeat'](){var _0x5868af,_0x4998ec;try{const _0x3182ff=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x322c7c=xs();if(((_0x5868af=this['_heartbeatsCache'])==null?void 0x0:_0x5868af['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4998ec=this['_heartbeatsCache'])==null?void 0x0:_0x4998ec['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x322c7c||this['_heartbeatsCache']['heartbeats']['some'](_0x1961dd=>_0x1961dd['date']===_0x322c7c))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x322c7c,'agent':_0x3182ff}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x6fd7fd=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x6fd7fd,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x10a051){re['warn'](_0x10a051);}}async['getHeartbeatsHeader'](){var _0x578044;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x578044=this['_heartbeatsCache'])==null?void 0x0:_0x578044['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5d71dd=xs(),{heartbeatsToSend:_0x25e29e,unsentEntries:_0x53e686}=kl(this['_heartbeatsCache']['heartbeats']),_0x1be66f=an(JSON['stringify']({'version':0x2,'heartbeats':_0x25e29e}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5d71dd,_0x53e686['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x53e686,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1be66f;}catch(_0x464b9a){return re['warn'](_0x464b9a),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x285bb7,_0x486812=bl){const _0x5a0fa0=[];let _0x2acf6e=_0x285bb7['slice']();for(const _0x362e4e of _0x285bb7){const _0x5d2cec=_0x5a0fa0['find'](_0x20250a=>_0x20250a['agent']===_0x362e4e['agent']);if(_0x5d2cec){if(_0x5d2cec['dates']['push'](_0x362e4e['date']),Fs(_0x5a0fa0)>_0x486812){_0x5d2cec['dates']['pop']();break;}}else{if(_0x5a0fa0['push']({'agent':_0x362e4e['agent'],'dates':[_0x362e4e['date']]}),Fs(_0x5a0fa0)>_0x486812){_0x5a0fa0['pop']();break;}}_0x2acf6e=_0x2acf6e['slice'](0x1);}return{'heartbeatsToSend':_0x5a0fa0,'unsentEntries':_0x2acf6e};}class Nl{constructor(_0x2243cb){this['app']=_0x2243cb,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x222580=await Sl(this['app']);return _0x222580!=null&&_0x222580['heartbeats']?_0x222580:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x302421){if(await this['_canUseIndexedDBPromise']){const _0x10bf14=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x302421['lastSentHeartbeatDate']??_0x10bf14['lastSentHeartbeatDate'],'heartbeats':_0x302421['heartbeats']});}else return;}async['add'](_0x56dc8b){if(await this['_canUseIndexedDBPromise']){const _0x46f698=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x56dc8b['lastSentHeartbeatDate']??_0x46f698['lastSentHeartbeatDate'],'heartbeats':[..._0x46f698['heartbeats'],..._0x56dc8b['heartbeats']]});}else return;}}function Fs(_0x49e29a){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x49e29a}))['length'];}function Pl(_0x137bf4){if(_0x137bf4['length']===0x0)return-0x1;let _0x659eb=0x0,_0x43bc42=_0x137bf4[0x0]['date'];for(let _0x573c95=0x1;_0x573c95<_0x137bf4['length'];_0x573c95++)_0x137bf4[_0x573c95]['date']<_0x43bc42&&(_0x43bc42=_0x137bf4[_0x573c95]['date'],_0x659eb=_0x573c95);return _0x659eb;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4baad0){et(new Me('platform-logger',_0x1dcf8c=>new Gc(_0x1dcf8c),'PRIVATE')),et(new Me('heartbeat',_0x518d72=>new Al(_0x518d72),'PRIVATE')),me(fi,Ds,_0x4baad0),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0xeb94c1){Zr=_0xeb94c1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x4c5895){this['domStorage_']=_0x4c5895,this['prefix_']='firebase:';}['set'](_0x426c05,_0x385c9c){_0x385c9c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x426c05)):this['domStorage_']['setItem'](this['prefixedName_'](_0x426c05),O(_0x385c9c));}['get'](_0x16a9d1){const _0x1d24f7=this['domStorage_']['getItem'](this['prefixedName_'](_0x16a9d1));return _0x1d24f7==null?null:bt(_0x1d24f7);}['remove'](_0x13414f){this['domStorage_']['removeItem'](this['prefixedName_'](_0x13414f));}['prefixedName_'](_0x1fde23){return this['prefix_']+_0x1fde23;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4d34b9,_0x5e767e){_0x5e767e==null?delete this['cache_'][_0x4d34b9]:this['cache_'][_0x4d34b9]=_0x5e767e;}['get'](_0x59326d){return Y(this['cache_'],_0x59326d)?this['cache_'][_0x59326d]:null;}['remove'](_0x231db1){delete this['cache_'][_0x231db1];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x212ecd){try{if(typeof window<'u'&&typeof window[_0x212ecd]<'u'){const _0xbad132=window[_0x212ecd];return _0xbad132['setItem']('firebase:sentinel','cache'),_0xbad132['removeItem']('firebase:sentinel'),new xl(_0xbad132);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x447925=0x1;return function(){return _0x447925++;};}()),no=function(_0x2c5bf8){const _0x114e8d=Tc(_0x2c5bf8),_0x349bec=new Ec();_0x349bec['update'](_0x114e8d);const _0x2e7fb6=_0x349bec['digest']();return Di['encodeByteArray'](_0x2e7fb6);},Bt=function(..._0x2c309c){let _0x66a14='';for(let _0x5b5df3=0x0;_0x5b5df3<_0x2c309c['length'];_0x5b5df3++){const _0x141b57=_0x2c309c[_0x5b5df3];Array['isArray'](_0x141b57)||_0x141b57&&typeof _0x141b57=='object'&&typeof _0x141b57['length']=='number'?_0x66a14+=Bt['apply'](null,_0x141b57):typeof _0x141b57=='object'?_0x66a14+=O(_0x141b57):_0x66a14+=_0x141b57,_0x66a14+='\x20';}return _0x66a14;};let Et=null,Vs=!0x0;const Wl=function(_0x142bae,_0x1353e1){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x498045){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0xaf21df=Bt['apply'](null,_0x498045);Et(_0xaf21df);}},Vt=function(_0xde5c75){return function(..._0xd94c95){L(_0xde5c75,..._0xd94c95);};},mi=function(..._0x421e0c){const _0x2cedff='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x421e0c);Qe['error'](_0x2cedff);},oe=function(..._0x4f926a){const _0x14e749='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4f926a);throw Qe['error'](_0x14e749),new Error(_0x14e749);},U=function(..._0x3d3544){const _0x132d9c='FIREBASE\x20WARNING:\x20'+Bt(..._0x3d3544);Qe['warn'](_0x132d9c);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x40f934){return typeof _0x40f934=='number'&&(_0x40f934!==_0x40f934||_0x40f934===Number['POSITIVE_INFINITY']||_0x40f934===Number['NEGATIVE_INFINITY']);},Vl=function(_0x363da9){if(document['readyState']==='complete')_0x363da9();else{let _0x1b1196=!0x1;const _0xec1f7d=function(){if(!document['body']){setTimeout(_0xec1f7d,Math['floor'](0xa));return;}_0x1b1196||(_0x1b1196=!0x0,_0x363da9());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xec1f7d,!0x1),window['addEventListener']('load',_0xec1f7d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xec1f7d();}),window['attachEvent']('onload',_0xec1f7d));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x141f3f,_0x3f477e){if(_0x141f3f===_0x3f477e)return 0x0;if(_0x141f3f===xe||_0x3f477e===Ie)return-0x1;if(_0x3f477e===xe||_0x141f3f===Ie)return 0x1;{const _0xae64d8=Hs(_0x141f3f),_0x83c5a1=Hs(_0x3f477e);return _0xae64d8!==null?_0x83c5a1!==null?_0xae64d8-_0x83c5a1===0x0?_0x141f3f['length']-_0x3f477e['length']:_0xae64d8-_0x83c5a1:-0x1:_0x83c5a1!==null?0x1:_0x141f3f<_0x3f477e?-0x1:0x1;}},Hl=function(_0x464d9,_0x4d2b22){return _0x464d9===_0x4d2b22?0x0:_0x464d9<_0x4d2b22?-0x1:0x1;},pt=function(_0x145d3c,_0x7c382d){if(_0x7c382d&&_0x145d3c in _0x7c382d)return _0x7c382d[_0x145d3c];throw new Error('Missing\x20required\x20key\x20('+_0x145d3c+')\x20in\x20object:\x20'+O(_0x7c382d));},Bi=function(_0x14daaf){if(typeof _0x14daaf!='object'||_0x14daaf===null)return O(_0x14daaf);const _0x54a9a8=[];for(const _0x3d567e in _0x14daaf)_0x54a9a8['push'](_0x3d567e);_0x54a9a8['sort']();let _0xe4a09='{';for(let _0x2e969b=0x0;_0x2e969b<_0x54a9a8['length'];_0x2e969b++)_0x2e969b!==0x0&&(_0xe4a09+=','),_0xe4a09+=O(_0x54a9a8[_0x2e969b]),_0xe4a09+=':',_0xe4a09+=Bi(_0x14daaf[_0x54a9a8[_0x2e969b]]);return _0xe4a09+='}',_0xe4a09;},io=function(_0x5ac0f0,_0x1c140b){const _0xc8c0b9=_0x5ac0f0['length'];if(_0xc8c0b9<=_0x1c140b)return[_0x5ac0f0];const _0x43ad48=[];for(let _0x46d69f=0x0;_0x46d69f<_0xc8c0b9;_0x46d69f+=_0x1c140b)_0x46d69f+_0x1c140b>_0xc8c0b9?_0x43ad48['push'](_0x5ac0f0['substring'](_0x46d69f,_0xc8c0b9)):_0x43ad48['push'](_0x5ac0f0['substring'](_0x46d69f,_0x46d69f+_0x1c140b));return _0x43ad48;};function x(_0x4b7617,_0x5b4326){for(const _0x372e37 in _0x4b7617)_0x4b7617['hasOwnProperty'](_0x372e37)&&_0x5b4326(_0x372e37,_0x4b7617[_0x372e37]);}const so=function(_0x14b158){f(!Wi(_0x14b158),'Invalid\x20JSON\x20number');const _0x3907c2=0xb,_0xc0b901=0x34,_0xbda444=(0x1<<_0x3907c2-0x1)-0x1;let _0x237828,_0x3d7e10,_0x231f08,_0x8f00fa,_0x4b39f7;_0x14b158===0x0?(_0x3d7e10=0x0,_0x231f08=0x0,_0x237828=0x1/_0x14b158===-0x1/0x0?0x1:0x0):(_0x237828=_0x14b158<0x0,_0x14b158=Math['abs'](_0x14b158),_0x14b158>=Math['pow'](0x2,0x1-_0xbda444)?(_0x8f00fa=Math['min'](Math['floor'](Math['log'](_0x14b158)/Math['LN2']),_0xbda444),_0x3d7e10=_0x8f00fa+_0xbda444,_0x231f08=Math['round'](_0x14b158*Math['pow'](0x2,_0xc0b901-_0x8f00fa)-Math['pow'](0x2,_0xc0b901))):(_0x3d7e10=0x0,_0x231f08=Math['round'](_0x14b158/Math['pow'](0x2,0x1-_0xbda444-_0xc0b901))));const _0x5e0a09=[];for(_0x4b39f7=_0xc0b901;_0x4b39f7;_0x4b39f7-=0x1)_0x5e0a09['push'](_0x231f08%0x2?0x1:0x0),_0x231f08=Math['floor'](_0x231f08/0x2);for(_0x4b39f7=_0x3907c2;_0x4b39f7;_0x4b39f7-=0x1)_0x5e0a09['push'](_0x3d7e10%0x2?0x1:0x0),_0x3d7e10=Math['floor'](_0x3d7e10/0x2);_0x5e0a09['push'](_0x237828?0x1:0x0),_0x5e0a09['reverse']();const _0x5d299c=_0x5e0a09['join']('');let _0x7d346='';for(_0x4b39f7=0x0;_0x4b39f7<0x40;_0x4b39f7+=0x8){let _0x4a7110=parseInt(_0x5d299c['substr'](_0x4b39f7,0x8),0x2)['toString'](0x10);_0x4a7110['length']===0x1&&(_0x4a7110='0'+_0x4a7110),_0x7d346=_0x7d346+_0x4a7110;}return _0x7d346['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x1db9a8,_0xdc52f8){let _0x398e5e='Unknown\x20Error';_0x1db9a8==='too_big'?_0x398e5e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1db9a8==='permission_denied'?_0x398e5e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1db9a8==='unavailable'&&(_0x398e5e='The\x20service\x20is\x20unavailable');const _0x3c335f=new Error(_0x1db9a8+'\x20at\x20'+_0xdc52f8['_path']['toString']()+':\x20'+_0x398e5e);return _0x3c335f['code']=_0x1db9a8['toUpperCase'](),_0x3c335f;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x1bc9a5){if(zl['test'](_0x1bc9a5)){const _0x1eaca8=Number(_0x1bc9a5);if(_0x1eaca8>=jl&&_0x1eaca8<=Kl)return _0x1eaca8;}return null;},lt=function(_0x1bc496){try{_0x1bc496();}catch(_0x44171f){setTimeout(()=>{const _0xfa8ea2=_0x44171f['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xfa8ea2),_0x44171f;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5c3570,_0xebd159){const _0x38aa4d=setTimeout(_0x5c3570,_0xebd159);return typeof _0x38aa4d=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x38aa4d):typeof _0x38aa4d=='object'&&_0x38aa4d['unref']&&_0x38aa4d['unref'](),_0x38aa4d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xb9a1de,_0x253136){this['appCheckProvider']=_0x253136,this['appName']=_0xb9a1de['name'],H(_0xb9a1de)&&_0xb9a1de['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xb9a1de['settings']['appCheckToken']),this['appCheck']=_0x253136==null?void 0x0:_0x253136['getImmediate']({'optional':!0x0}),this['appCheck']||_0x253136==null||_0x253136['get']()['then'](_0x17115a=>this['appCheck']=_0x17115a);}['getToken'](_0x4241f3){if(this['serverAppAppCheckToken']){if(_0x4241f3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x4241f3):new Promise((_0x18a719,_0xcb7fce)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x4241f3)['then'](_0x18a719,_0xcb7fce):_0x18a719(null);},0x0);});}['addTokenChangeListener'](_0x3a6775){var _0x18b9ae;(_0x18b9ae=this['appCheckProvider'])==null||_0x18b9ae['get']()['then'](_0x3cfd07=>_0x3cfd07['addTokenListener'](_0x3a6775));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x7e503a,_0x1ab60a,_0x68ea0b){this['appName_']=_0x7e503a,this['firebaseOptions_']=_0x1ab60a,this['authProvider_']=_0x68ea0b,this['auth_']=null,this['auth_']=_0x68ea0b['getImmediate']({'optional':!0x0}),this['auth_']||_0x68ea0b['onInit'](_0x57c37e=>this['auth_']=_0x57c37e);}['getToken'](_0x22c47f){return this['auth_']?this['auth_']['getToken'](_0x22c47f)['catch'](_0x9e7703=>_0x9e7703&&_0x9e7703['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x9e7703)):new Promise((_0x580ef7,_0x1e1dc9)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x22c47f)['then'](_0x580ef7,_0x1e1dc9):_0x580ef7(null);},0x0);});}['addTokenChangeListener'](_0x3b9707){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3b9707):this['authProvider_']['get']()['then'](_0x423ddd=>_0x423ddd['addAuthTokenListener'](_0x3b9707));}['removeTokenChangeListener'](_0x37e940){this['authProvider_']['get']()['then'](_0x36874c=>_0x36874c['removeAuthTokenListener'](_0x37e940));}['notifyForInvalidToken'](){let _0x2b6b16='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2b6b16+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2b6b16+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2b6b16+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2b6b16);}}class tn{constructor(_0x11ea01){this['accessToken']=_0x11ea01;}['getToken'](_0x3d8e59){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x28a976){_0x28a976(this['accessToken']);}['removeTokenChangeListener'](_0x261c19){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x41731f,_0xb05ede,_0x10afc0,_0x23959b,_0x19d8db=!0x1,_0xa81012='',_0x21274c=!0x1,_0x52a574=!0x1,_0x2fdfb5=null){this['secure']=_0xb05ede,this['namespace']=_0x10afc0,this['webSocketOnly']=_0x23959b,this['nodeAdmin']=_0x19d8db,this['persistenceKey']=_0xa81012,this['includeNamespaceInQueryParams']=_0x21274c,this['isUsingEmulator']=_0x52a574,this['emulatorOptions']=_0x2fdfb5,this['_host']=_0x41731f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x41731f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3a7363){_0x3a7363!==this['internalHost']&&(this['internalHost']=_0x3a7363,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5a0901=this['toURLString']();return this['persistenceKey']&&(_0x5a0901+='<'+this['persistenceKey']+'>'),_0x5a0901;}['toURLString'](){const _0x208286=this['secure']?'https://':'http://',_0x37c9fc=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x208286+this['host']+'/'+_0x37c9fc;}}function Xl(_0x39c3e5){return _0x39c3e5['host']!==_0x39c3e5['internalHost']||_0x39c3e5['isCustomHost']()||_0x39c3e5['includeNamespaceInQueryParams'];}function go(_0x28b544,_0x298d8a,_0x4803f0){f(typeof _0x298d8a=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4803f0=='object','typeof\x20params\x20must\x20==\x20object');let _0x50a4e9;if(_0x298d8a===fo)_0x50a4e9=(_0x28b544['secure']?'wss://':'ws://')+_0x28b544['internalHost']+'/.ws?';else{if(_0x298d8a===po)_0x50a4e9=(_0x28b544['secure']?'https://':'http://')+_0x28b544['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x298d8a);}Xl(_0x28b544)&&(_0x4803f0['ns']=_0x28b544['namespace']);const _0x1222e8=[];return x(_0x4803f0,(_0x561ce4,_0x50105a)=>{_0x1222e8['push'](_0x561ce4+'='+_0x50105a);}),_0x50a4e9+_0x1222e8['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x373df1,_0x2b5200=0x1){Y(this['counters_'],_0x373df1)||(this['counters_'][_0x373df1]=0x0),this['counters_'][_0x373df1]+=_0x2b5200;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x4fc4dc){const _0x47e564=_0x4fc4dc['toString']();return ti[_0x47e564]||(ti[_0x47e564]=new Zl()),ti[_0x47e564];}function eh(_0x5cea75,_0x8e00fd){const _0x4a852d=_0x5cea75['toString']();return ni[_0x4a852d]||(ni[_0x4a852d]=_0x8e00fd()),ni[_0x4a852d];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x13634c){this['onMessage_']=_0x13634c,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x30d53c,_0x372141){this['closeAfterResponse']=_0x30d53c,this['onClose']=_0x372141,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x143039,_0x4bb3a3){for(this['pendingResponses'][_0x143039]=_0x4bb3a3;this['pendingResponses'][this['currentResponseNum']];){const _0x380ca7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5c67bf=0x0;_0x5c67bf<_0x380ca7['length'];++_0x5c67bf)_0x380ca7[_0x5c67bf]&&lt(()=>{this['onMessage_'](_0x380ca7[_0x5c67bf]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x4423d1,_0x1e8777,_0x2c70d4,_0x571a61,_0x49ba8f,_0x3eed66,_0x5c4316){this['connId']=_0x4423d1,this['repoInfo']=_0x1e8777,this['applicationId']=_0x2c70d4,this['appCheckToken']=_0x571a61,this['authToken']=_0x49ba8f,this['transportSessionId']=_0x3eed66,this['lastSessionId']=_0x5c4316,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x4423d1),this['stats_']=Hi(_0x1e8777),this['urlFn']=_0x159833=>(this['appCheckToken']&&(_0x159833[yi]=this['appCheckToken']),go(_0x1e8777,po,_0x159833));}['open'](_0xe561db,_0x5be831){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5be831,this['myPacketOrderer']=new th(_0xe561db),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x43d3a8)=>{const [_0x39ee54,_0x53b7a8,_0x28aea9,_0xc6e4b4,_0x4d551e]=_0x43d3a8;if(this['incrementIncomingBytes_'](_0x43d3a8),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x39ee54===$s)this['id']=_0x53b7a8,this['password']=_0x28aea9;else{if(_0x39ee54===nh)_0x53b7a8?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x53b7a8,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x39ee54);}}},(..._0x2be15b)=>{const [_0x241c8a,_0x278695]=_0x2be15b;this['incrementIncomingBytes_'](_0x2be15b),this['myPacketOrderer']['handleResponse'](_0x241c8a,_0x278695);},()=>{this['onClosed_']();},this['urlFn']);const _0x55d33f={};_0x55d33f[$s]='t',_0x55d33f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x55d33f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x55d33f[ro]=Vi,this['transportSessionId']&&(_0x55d33f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x55d33f[ho]=this['lastSessionId']),this['applicationId']&&(_0x55d33f[uo]=this['applicationId']),this['appCheckToken']&&(_0x55d33f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x55d33f[ao]=co);const _0x311486=this['urlFn'](_0x55d33f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x311486),this['scriptTagHolder']['addTag'](_0x311486,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x124bb2){const _0x316acc=O(_0x124bb2);this['bytesSent']+=_0x316acc['length'],this['stats_']['incrementCounter']('bytes_sent',_0x316acc['length']);const _0x4812b6=Br(_0x316acc),_0x54b84e=io(_0x4812b6,hh);for(let _0xe96554=0x0;_0xe96554<_0x54b84e['length'];_0xe96554++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x54b84e['length'],_0x54b84e[_0xe96554]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4e1a10,_0x1b6852){this['myDisconnFrame']=document['createElement']('iframe');const _0x478210={};_0x478210[lh]='t',_0x478210[mo]=_0x4e1a10,_0x478210[yo]=_0x1b6852,this['myDisconnFrame']['src']=this['urlFn'](_0x478210),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5118c7){const _0x1b3446=O(_0x5118c7)['length'];this['bytesReceived']+=_0x1b3446,this['stats_']['incrementCounter']('bytes_received',_0x1b3446);}}class $i{constructor(_0x32a762,_0x22478f,_0x5aa6db,_0x1e34cb){this['onDisconnect']=_0x5aa6db,this['urlFn']=_0x1e34cb,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x32a762,window[sh+this['uniqueCallbackIdentifier']]=_0x22478f,this['myIFrame']=$i['createIFrame_']();let _0x2a674c='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2a674c='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2e2c18='<html><body>'+_0x2a674c+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2e2c18),this['myIFrame']['doc']['close']();}catch(_0x21f583){L('frame\x20writing\x20exception'),_0x21f583['stack']&&L(_0x21f583['stack']),L(_0x21f583);}}}static['createIFrame_'](){const _0x58bfda=document['createElement']('iframe');if(_0x58bfda['style']['display']='none',document['body']){document['body']['appendChild'](_0x58bfda);try{_0x58bfda['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x51ddda=document['domain'];_0x58bfda['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x51ddda+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x58bfda['contentDocument']?_0x58bfda['doc']=_0x58bfda['contentDocument']:_0x58bfda['contentWindow']?_0x58bfda['doc']=_0x58bfda['contentWindow']['document']:_0x58bfda['document']&&(_0x58bfda['doc']=_0x58bfda['document']),_0x58bfda;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x22c57f=this['onDisconnect'];_0x22c57f&&(this['onDisconnect']=null,_0x22c57f());}['startLongPoll'](_0x578ce2,_0x307173){for(this['myID']=_0x578ce2,this['myPW']=_0x307173,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x50f0ab={};_0x50f0ab[mo]=this['myID'],_0x50f0ab[yo]=this['myPW'],_0x50f0ab[vo]=this['currentSerial'];let _0x33b03e=this['urlFn'](_0x50f0ab),_0x1ac9a5='',_0x2f3242=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x1ac9a5['length']<=Eo;){const _0x5a0de=this['pendingSegs']['shift']();_0x1ac9a5=_0x1ac9a5+'&'+oh+_0x2f3242+'='+_0x5a0de['seg']+'&'+ah+_0x2f3242+'='+_0x5a0de['ts']+'&'+ch+_0x2f3242+'='+_0x5a0de['d'],_0x2f3242++;}return _0x33b03e=_0x33b03e+_0x1ac9a5,this['addLongPollTag_'](_0x33b03e,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x36b4b3,_0x338081,_0x55a6bb){this['pendingSegs']['push']({'seg':_0x36b4b3,'ts':_0x338081,'d':_0x55a6bb}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1be88d,_0x4b8a6a){this['outstandingRequests']['add'](_0x4b8a6a);const _0x106f7b=()=>{this['outstandingRequests']['delete'](_0x4b8a6a),this['newRequest_']();},_0x100391=setTimeout(_0x106f7b,Math['floor'](uh)),_0x5eb998=()=>{clearTimeout(_0x100391),_0x106f7b();};this['addTag'](_0x1be88d,_0x5eb998);}['addTag'](_0x5028ae,_0x453056){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3002ed=this['myIFrame']['doc']['createElement']('script');_0x3002ed['type']='text/javascript',_0x3002ed['async']=!0x0,_0x3002ed['src']=_0x5028ae,_0x3002ed['onload']=_0x3002ed['onreadystatechange']=function(){const _0x269cce=_0x3002ed['readyState'];(!_0x269cce||_0x269cce==='loaded'||_0x269cce==='complete')&&(_0x3002ed['onload']=_0x3002ed['onreadystatechange']=null,_0x3002ed['parentNode']&&_0x3002ed['parentNode']['removeChild'](_0x3002ed),_0x453056());},_0x3002ed['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5028ae),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3002ed);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x50d7d2,_0x440cc0,_0x4d8f10,_0x516ef8,_0x468f3c,_0x2bd38d,_0x27bbb6){this['connId']=_0x50d7d2,this['applicationId']=_0x4d8f10,this['appCheckToken']=_0x516ef8,this['authToken']=_0x468f3c,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x440cc0),this['connURL']=G['connectionURL_'](_0x440cc0,_0x2bd38d,_0x27bbb6,_0x516ef8,_0x4d8f10),this['nodeAdmin']=_0x440cc0['nodeAdmin'];}static['connectionURL_'](_0x482854,_0x5c03d4,_0x528758,_0x1e6a66,_0xbd0fbf){const _0x268443={};return _0x268443[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x268443[ao]=co),_0x5c03d4&&(_0x268443[oo]=_0x5c03d4),_0x528758&&(_0x268443[ho]=_0x528758),_0x1e6a66&&(_0x268443[yi]=_0x1e6a66),_0xbd0fbf&&(_0x268443[uo]=_0xbd0fbf),go(_0x482854,fo,_0x268443);}['open'](_0x4c7291,_0xb8b2f7){this['onDisconnect']=_0xb8b2f7,this['onMessage']=_0x4c7291,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x175d8a;dc(),this['mySock']=new hn(this['connURL'],[],_0x175d8a);}catch(_0x3a3919){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x45fd2d=_0x3a3919['message']||_0x3a3919['data'];_0x45fd2d&&this['log_'](_0x45fd2d),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1cf486=>{this['handleIncomingFrame'](_0x1cf486);},this['mySock']['onerror']=_0x11e57b=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x41cbb9=_0x11e57b['message']||_0x11e57b['data'];_0x41cbb9&&this['log_'](_0x41cbb9),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4edd8e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x493e40=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5a3012=navigator['userAgent']['match'](_0x493e40);_0x5a3012&&_0x5a3012['length']>0x1&&parseFloat(_0x5a3012[0x1])<4.4&&(_0x4edd8e=!0x0);}return!_0x4edd8e&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x44f778){if(this['frames']['push'](_0x44f778),this['frames']['length']===this['totalFrames']){const _0x27076c=this['frames']['join']('');this['frames']=null;const _0x181bca=bt(_0x27076c);this['onMessage'](_0x181bca);}}['handleNewFrameCount_'](_0x1107a5){this['totalFrames']=_0x1107a5,this['frames']=[];}['extractFrameCount_'](_0x12891b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x12891b['length']<=0x6){const _0x5d792a=Number(_0x12891b);if(!isNaN(_0x5d792a))return this['handleNewFrameCount_'](_0x5d792a),null;}return this['handleNewFrameCount_'](0x1),_0x12891b;}['handleIncomingFrame'](_0x2a404c){if(this['mySock']===null)return;const _0x4bfc8c=_0x2a404c['data'];if(this['bytesReceived']+=_0x4bfc8c['length'],this['stats_']['incrementCounter']('bytes_received',_0x4bfc8c['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4bfc8c);else{const _0x55e1c0=this['extractFrameCount_'](_0x4bfc8c);_0x55e1c0!==null&&this['appendFrame_'](_0x55e1c0);}}['send'](_0x480ac1){this['resetKeepAlive']();const _0x308d2c=O(_0x480ac1);this['bytesSent']+=_0x308d2c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x308d2c['length']);const _0xc576fb=io(_0x308d2c,fh);_0xc576fb['length']>0x1&&this['sendString_'](String(_0xc576fb['length']));for(let _0x29f601=0x0;_0x29f601<_0xc576fb['length'];_0x29f601++)this['sendString_'](_0xc576fb[_0x29f601]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x271124){try{this['mySock']['send'](_0x271124);}catch(_0x403ebc){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x403ebc['message']||_0x403ebc['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xbe9b79){this['initTransports_'](_0xbe9b79);}['initTransports_'](_0x5df6b6){const _0x2472f8=G&&G['isAvailable']();let _0x55434a=_0x2472f8&&!G['previouslyFailed']();if(_0x5df6b6['webSocketOnly']&&(_0x2472f8||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x55434a=!0x0),_0x55434a)this['transports_']=[G];else{const _0x2eb3fd=this['transports_']=[];for(const _0x22e1cb of At['ALL_TRANSPORTS'])_0x22e1cb&&_0x22e1cb['isAvailable']()&&_0x2eb3fd['push'](_0x22e1cb);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4f117a,_0x194015,_0x22895a,_0x3698de,_0x26274c,_0x5a90d8,_0x31d6c1,_0x20f679,_0x38324a,_0x56aa20){this['id']=_0x4f117a,this['repoInfo_']=_0x194015,this['applicationId_']=_0x22895a,this['appCheckToken_']=_0x3698de,this['authToken_']=_0x26274c,this['onMessage_']=_0x5a90d8,this['onReady_']=_0x31d6c1,this['onDisconnect_']=_0x20f679,this['onKill_']=_0x38324a,this['lastSessionId']=_0x56aa20,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x194015),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1d09c7=this['transportManager_']['initialTransport']();this['conn_']=new _0x1d09c7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1d09c7['responsesRequiredToBeHealthy']||0x0;const _0x380a4c=this['connReceiver_'](this['conn_']),_0x48cd10=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x380a4c,_0x48cd10);},Math['floor'](0x0));const _0x463a74=_0x1d09c7['healthyTimeout']||0x0;_0x463a74>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x463a74)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3c1596){return _0x36b775=>{_0x3c1596===this['conn_']?this['onConnectionLost_'](_0x36b775):_0x3c1596===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x551018){return _0x3d7707=>{this['state_']!==0x2&&(_0x551018===this['rx_']?this['onPrimaryMessageReceived_'](_0x3d7707):_0x551018===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3d7707):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x213d1e){const _0x3fc9a5={'t':'d','d':_0x213d1e};this['sendData_'](_0x3fc9a5);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x421680){if(ii in _0x421680){const _0x4f40c2=_0x421680[ii];_0x4f40c2===js?this['upgradeIfSecondaryHealthy_']():_0x4f40c2===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4f40c2===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xf5cf37){const _0x20cba3=pt('t',_0xf5cf37),_0x57f0bb=pt('d',_0xf5cf37);if(_0x20cba3==='c')this['onSecondaryControl_'](_0x57f0bb);else{if(_0x20cba3==='d')this['pendingDataMessages']['push'](_0x57f0bb);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x20cba3);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xf1a43c){const _0x4b2229=pt('t',_0xf1a43c),_0x3cbdfe=pt('d',_0xf1a43c);_0x4b2229==='c'?this['onControl_'](_0x3cbdfe):_0x4b2229==='d'&&this['onDataMessage_'](_0x3cbdfe);}['onDataMessage_'](_0x41c5e1){this['onPrimaryResponse_'](),this['onMessage_'](_0x41c5e1);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x18948f){const _0x10903b=pt(ii,_0x18948f);if(Gs in _0x18948f){const _0x25974b=_0x18948f[Gs];if(_0x10903b===Ih){const _0x1679a6={..._0x25974b};this['repoInfo_']['isUsingEmulator']&&(_0x1679a6['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1679a6);}else{if(_0x10903b===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x54bafd=0x0;_0x54bafd<this['pendingDataMessages']['length'];++_0x54bafd)this['onDataMessage_'](this['pendingDataMessages'][_0x54bafd]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x10903b===vh?this['onConnectionShutdown_'](_0x25974b):_0x10903b===qs?this['onReset_'](_0x25974b):_0x10903b===Eh?mi('Server\x20Error:\x20'+_0x25974b):_0x10903b===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x10903b);}}}['onHandshake_'](_0x1098cd){const _0x4ddc1c=_0x1098cd['ts'],_0x4a6197=_0x1098cd['v'],_0x27f462=_0x1098cd['h'];this['sessionId']=_0x1098cd['s'],this['repoInfo_']['host']=_0x27f462,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4ddc1c),Vi!==_0x4a6197&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x50065a=this['transportManager_']['upgradeTransport']();_0x50065a&&this['startUpgrade_'](_0x50065a);}['startUpgrade_'](_0x2c5260){this['secondaryConn_']=new _0x2c5260(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2c5260['responsesRequiredToBeHealthy']||0x0;const _0x1215fd=this['connReceiver_'](this['secondaryConn_']),_0x2b666=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1215fd,_0x2b666),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x343df4){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x343df4),this['repoInfo_']['host']=_0x343df4,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x13cf56,_0x287889){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x13cf56,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x287889,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x278663=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x278663||this['rx_']===_0x278663)&&this['close']();}['onConnectionLost_'](_0x1673d1){this['conn_']=null,!_0x1673d1&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4fa340){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4fa340),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3da89c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3da89c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x45c4ba,_0x1b1098,_0x216627,_0x2866c6){}['merge'](_0x56eaab,_0x2a4b76,_0x22623b,_0x562fed){}['refreshAuthToken'](_0x36f1c5){}['refreshAppCheckToken'](_0x1f01df){}['onDisconnectPut'](_0x2adb08,_0x106c6f,_0x37e2b7){}['onDisconnectMerge'](_0x4b868a,_0x135477,_0x472ea8){}['onDisconnectCancel'](_0x3b476b,_0x1432f8){}['reportStats'](_0x2c0809){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x114a58){this['allowedEvents_']=_0x114a58,this['listeners_']={},f(Array['isArray'](_0x114a58)&&_0x114a58['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2a78fc,..._0x16dce2){if(Array['isArray'](this['listeners_'][_0x2a78fc])){const _0x52c89a=[...this['listeners_'][_0x2a78fc]];for(let _0x4b5212=0x0;_0x4b5212<_0x52c89a['length'];_0x4b5212++)_0x52c89a[_0x4b5212]['callback']['apply'](_0x52c89a[_0x4b5212]['context'],_0x16dce2);}}['on'](_0x2f2d7d,_0x394afe,_0x5c763b){this['validateEventType_'](_0x2f2d7d),this['listeners_'][_0x2f2d7d]=this['listeners_'][_0x2f2d7d]||[],this['listeners_'][_0x2f2d7d]['push']({'callback':_0x394afe,'context':_0x5c763b});const _0x3604eb=this['getInitialEvent'](_0x2f2d7d);_0x3604eb&&_0x394afe['apply'](_0x5c763b,_0x3604eb);}['off'](_0xddafb9,_0x4f4d41,_0x1079e0){this['validateEventType_'](_0xddafb9);const _0x35053b=this['listeners_'][_0xddafb9]||[];for(let _0x4a8476=0x0;_0x4a8476<_0x35053b['length'];_0x4a8476++)if(_0x35053b[_0x4a8476]['callback']===_0x4f4d41&&(!_0x1079e0||_0x1079e0===_0x35053b[_0x4a8476]['context'])){_0x35053b['splice'](_0x4a8476,0x1);return;}}['validateEventType_'](_0x1c4eb9){f(this['allowedEvents_']['find'](_0x58dd57=>_0x58dd57===_0x1c4eb9),'Unknown\x20event:\x20'+_0x1c4eb9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x257c19){return f(_0x257c19==='online','Unknown\x20event\x20type:\x20'+_0x257c19),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0xe0407b,_0x41f038){if(_0x41f038===void 0x0){this['pieces_']=_0xe0407b['split']('/');let _0x10f2bc=0x0;for(let _0x649a72=0x0;_0x649a72<this['pieces_']['length'];_0x649a72++)this['pieces_'][_0x649a72]['length']>0x0&&(this['pieces_'][_0x10f2bc]=this['pieces_'][_0x649a72],_0x10f2bc++);this['pieces_']['length']=_0x10f2bc,this['pieceNum_']=0x0;}else this['pieces_']=_0xe0407b,this['pieceNum_']=_0x41f038;}['toString'](){let _0x5a8140='';for(let _0x177683=this['pieceNum_'];_0x177683<this['pieces_']['length'];_0x177683++)this['pieces_'][_0x177683]!==''&&(_0x5a8140+='/'+this['pieces_'][_0x177683]);return _0x5a8140||'/';}}function w(){return new C('');}function y(_0x21bab4){return _0x21bab4['pieceNum_']>=_0x21bab4['pieces_']['length']?null:_0x21bab4['pieces_'][_0x21bab4['pieceNum_']];}function we(_0x2b5896){return _0x2b5896['pieces_']['length']-_0x2b5896['pieceNum_'];}function b(_0x2647fd){let _0x1d0349=_0x2647fd['pieceNum_'];return _0x1d0349<_0x2647fd['pieces_']['length']&&_0x1d0349++,new C(_0x2647fd['pieces_'],_0x1d0349);}function Gi(_0x4b7e53){return _0x4b7e53['pieceNum_']<_0x4b7e53['pieces_']['length']?_0x4b7e53['pieces_'][_0x4b7e53['pieces_']['length']-0x1]:null;}function Ch(_0x303c5a){let _0x2811c0='';for(let _0x1f191d=_0x303c5a['pieceNum_'];_0x1f191d<_0x303c5a['pieces_']['length'];_0x1f191d++)_0x303c5a['pieces_'][_0x1f191d]!==''&&(_0x2811c0+='/'+encodeURIComponent(String(_0x303c5a['pieces_'][_0x1f191d])));return _0x2811c0||'/';}function kt(_0x27ed2a,_0xa14250=0x0){return _0x27ed2a['pieces_']['slice'](_0x27ed2a['pieceNum_']+_0xa14250);}function To(_0x398928){if(_0x398928['pieceNum_']>=_0x398928['pieces_']['length'])return null;const _0x880803=[];for(let _0x2c5fce=_0x398928['pieceNum_'];_0x2c5fce<_0x398928['pieces_']['length']-0x1;_0x2c5fce++)_0x880803['push'](_0x398928['pieces_'][_0x2c5fce]);return new C(_0x880803,0x0);}function A(_0x47679c,_0x1a6eb3){const _0xd50826=[];for(let _0x260302=_0x47679c['pieceNum_'];_0x260302<_0x47679c['pieces_']['length'];_0x260302++)_0xd50826['push'](_0x47679c['pieces_'][_0x260302]);if(_0x1a6eb3 instanceof C){for(let _0xab8eae=_0x1a6eb3['pieceNum_'];_0xab8eae<_0x1a6eb3['pieces_']['length'];_0xab8eae++)_0xd50826['push'](_0x1a6eb3['pieces_'][_0xab8eae]);}else{const _0x6ed688=_0x1a6eb3['split']('/');for(let _0x11141e=0x0;_0x11141e<_0x6ed688['length'];_0x11141e++)_0x6ed688[_0x11141e]['length']>0x0&&_0xd50826['push'](_0x6ed688[_0x11141e]);}return new C(_0xd50826,0x0);}function v(_0x1d5079){return _0x1d5079['pieceNum_']>=_0x1d5079['pieces_']['length'];}function F(_0x14b242,_0x3f7f73){const _0x70bafd=y(_0x14b242),_0x126dec=y(_0x3f7f73);if(_0x70bafd===null)return _0x3f7f73;if(_0x70bafd===_0x126dec)return F(b(_0x14b242),b(_0x3f7f73));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3f7f73+')\x20is\x20not\x20within\x20outerPath\x20('+_0x14b242+')');}function Th(_0x2be806,_0x3761ce){const _0x170cfc=kt(_0x2be806,0x0),_0x192d2d=kt(_0x3761ce,0x0);for(let _0x4ff7ef=0x0;_0x4ff7ef<_0x170cfc['length']&&_0x4ff7ef<_0x192d2d['length'];_0x4ff7ef++){const _0x3bcc7b=He(_0x170cfc[_0x4ff7ef],_0x192d2d[_0x4ff7ef]);if(_0x3bcc7b!==0x0)return _0x3bcc7b;}return _0x170cfc['length']===_0x192d2d['length']?0x0:_0x170cfc['length']<_0x192d2d['length']?-0x1:0x1;}function qi(_0x19c6c5,_0x415c4c){if(we(_0x19c6c5)!==we(_0x415c4c))return!0x1;for(let _0x54cfc8=_0x19c6c5['pieceNum_'],_0x4a373f=_0x415c4c['pieceNum_'];_0x54cfc8<=_0x19c6c5['pieces_']['length'];_0x54cfc8++,_0x4a373f++)if(_0x19c6c5['pieces_'][_0x54cfc8]!==_0x415c4c['pieces_'][_0x4a373f])return!0x1;return!0x0;}function $(_0x5ce658,_0x43a988){let _0x336af5=_0x5ce658['pieceNum_'],_0x5c215b=_0x43a988['pieceNum_'];if(we(_0x5ce658)>we(_0x43a988))return!0x1;for(;_0x336af5<_0x5ce658['pieces_']['length'];){if(_0x5ce658['pieces_'][_0x336af5]!==_0x43a988['pieces_'][_0x5c215b])return!0x1;++_0x336af5,++_0x5c215b;}return!0x0;}class Sh{constructor(_0x14c1ca,_0x523140){this['errorPrefix_']=_0x523140,this['parts_']=kt(_0x14c1ca,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x238b15=0x0;_0x238b15<this['parts_']['length'];_0x238b15++)this['byteLength_']+=Pn(this['parts_'][_0x238b15]);So(this);}}function bh(_0x2dd71c,_0x4f8433){_0x2dd71c['parts_']['length']>0x0&&(_0x2dd71c['byteLength_']+=0x1),_0x2dd71c['parts_']['push'](_0x4f8433),_0x2dd71c['byteLength_']+=Pn(_0x4f8433),So(_0x2dd71c);}function Rh(_0x1edbb1){const _0x1f2ac1=_0x1edbb1['parts_']['pop']();_0x1edbb1['byteLength_']-=Pn(_0x1f2ac1),_0x1edbb1['parts_']['length']>0x0&&(_0x1edbb1['byteLength_']-=0x1);}function So(_0xaf5379){if(_0xaf5379['byteLength_']>Js)throw new Error(_0xaf5379['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0xaf5379['byteLength_']+').');if(_0xaf5379['parts_']['length']>Qs)throw new Error(_0xaf5379['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0xaf5379));}function Ne(_0x28862d){return _0x28862d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x28862d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x27eacd,_0x4b13c7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4b13c7='visibilitychange',_0x27eacd='hidden'):typeof document['mozHidden']<'u'?(_0x4b13c7='mozvisibilitychange',_0x27eacd='mozHidden'):typeof document['msHidden']<'u'?(_0x4b13c7='msvisibilitychange',_0x27eacd='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4b13c7='webkitvisibilitychange',_0x27eacd='webkitHidden')),this['visible_']=!0x0,_0x4b13c7&&document['addEventListener'](_0x4b13c7,()=>{const _0x8e6302=!document[_0x27eacd];_0x8e6302!==this['visible_']&&(this['visible_']=_0x8e6302,this['trigger']('visible',_0x8e6302));},!0x1);}['getInitialEvent'](_0x316103){return f(_0x316103==='visible','Unknown\x20event\x20type:\x20'+_0x316103),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x45c803,_0x1f6921,_0x40cd4a,_0x225874,_0x1fce59,_0x5bef6f,_0x499923,_0x4d02e2){if(super(),this['repoInfo_']=_0x45c803,this['applicationId_']=_0x1f6921,this['onDataUpdate_']=_0x40cd4a,this['onConnectStatus_']=_0x225874,this['onServerInfoUpdate_']=_0x1fce59,this['authTokenProvider_']=_0x5bef6f,this['appCheckTokenProvider_']=_0x499923,this['authOverride_']=_0x4d02e2,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4d02e2)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x45c803['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x168e7e,_0x2f3041,_0x1507de){const _0x5d53e1=++this['requestNumber_'],_0xcede0b={'r':_0x5d53e1,'a':_0x168e7e,'b':_0x2f3041};this['log_'](O(_0xcede0b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xcede0b),_0x1507de&&(this['requestCBHash_'][_0x5d53e1]=_0x1507de);}['get'](_0x167104){this['initConnection_']();const _0x2b72e6=new Ve(),_0x15ae5b={'action':'g','request':{'p':_0x167104['_path']['toString'](),'q':_0x167104['_queryObject']},'onComplete':_0x437554=>{const _0xa4527c=_0x437554['d'];_0x437554['s']==='ok'?_0x2b72e6['resolve'](_0xa4527c):_0x2b72e6['reject'](_0xa4527c);}};this['outstandingGets_']['push'](_0x15ae5b),this['outstandingGetCount_']++;const _0x550fa5=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x550fa5),_0x2b72e6['promise'];}['listen'](_0x503e0d,_0x258823,_0x322444,_0x585331){this['initConnection_']();const _0x26fa59=_0x503e0d['_queryIdentifier'],_0x3fe088=_0x503e0d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3fe088+'\x20'+_0x26fa59),this['listens']['has'](_0x3fe088)||this['listens']['set'](_0x3fe088,new Map()),f(_0x503e0d['_queryParams']['isDefault']()||!_0x503e0d['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3fe088)['has'](_0x26fa59),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x596ccc={'onComplete':_0x585331,'hashFn':_0x258823,'query':_0x503e0d,'tag':_0x322444};this['listens']['get'](_0x3fe088)['set'](_0x26fa59,_0x596ccc),this['connected_']&&this['sendListen_'](_0x596ccc);}['sendGet_'](_0x1cadf4){const _0x562ddb=this['outstandingGets_'][_0x1cadf4];this['sendRequest']('g',_0x562ddb['request'],_0x31add1=>{delete this['outstandingGets_'][_0x1cadf4],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x562ddb['onComplete']&&_0x562ddb['onComplete'](_0x31add1);});}['sendListen_'](_0x21cdc7){const _0x3306d8=_0x21cdc7['query'],_0x219a3e=_0x3306d8['_path']['toString'](),_0x13b781=_0x3306d8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x219a3e+'\x20for\x20'+_0x13b781);const _0x48fa5f={'p':_0x219a3e},_0x3f8b9d='q';_0x21cdc7['tag']&&(_0x48fa5f['q']=_0x3306d8['_queryObject'],_0x48fa5f['t']=_0x21cdc7['tag']),_0x48fa5f['h']=_0x21cdc7['hashFn'](),this['sendRequest'](_0x3f8b9d,_0x48fa5f,_0x279d70=>{const _0x57c6fb=_0x279d70['d'],_0x17b80c=_0x279d70['s'];ie['warnOnListenWarnings_'](_0x57c6fb,_0x3306d8),(this['listens']['get'](_0x219a3e)&&this['listens']['get'](_0x219a3e)['get'](_0x13b781))===_0x21cdc7&&(this['log_']('listen\x20response',_0x279d70),_0x17b80c!=='ok'&&this['removeListen_'](_0x219a3e,_0x13b781),_0x21cdc7['onComplete']&&_0x21cdc7['onComplete'](_0x17b80c,_0x57c6fb));});}static['warnOnListenWarnings_'](_0x89b267,_0x54553f){if(_0x89b267&&typeof _0x89b267=='object'&&Y(_0x89b267,'w')){const _0x45444c=Oe(_0x89b267,'w');if(Array['isArray'](_0x45444c)&&~_0x45444c['indexOf']('no_index')){const _0x1faf8a='\x22.indexOn\x22:\x20\x22'+_0x54553f['_queryParams']['getIndex']()['toString']()+'\x22',_0x568d08=_0x54553f['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1faf8a+'\x20at\x20'+_0x568d08+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3e456c){this['authToken_']=_0x3e456c,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3e456c);}['reduceReconnectDelayIfAdminCredential_'](_0xf133f0){(_0xf133f0&&_0xf133f0['length']===0x28||vc(_0xf133f0))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x312bcc){this['appCheckToken_']=_0x312bcc,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3085e3=this['authToken_'],_0x1e72a3=yc(_0x3085e3)?'auth':'gauth',_0x577f94={'cred':_0x3085e3};this['authOverride_']===null?_0x577f94['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x577f94['authvar']=this['authOverride_']),this['sendRequest'](_0x1e72a3,_0x577f94,_0x3948ef=>{const _0x537dd2=_0x3948ef['s'],_0x500238=_0x3948ef['d']||'error';this['authToken_']===_0x3085e3&&(_0x537dd2==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x537dd2,_0x500238));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x34f009=>{const _0x5c8e45=_0x34f009['s'],_0xc57672=_0x34f009['d']||'error';_0x5c8e45==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5c8e45,_0xc57672);});}['unlisten'](_0x17cd16,_0x412301){const _0x446ef3=_0x17cd16['_path']['toString'](),_0x3939bd=_0x17cd16['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x446ef3+'\x20'+_0x3939bd),f(_0x17cd16['_queryParams']['isDefault']()||!_0x17cd16['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x446ef3,_0x3939bd)&&this['connected_']&&this['sendUnlisten_'](_0x446ef3,_0x3939bd,_0x17cd16['_queryObject'],_0x412301);}['sendUnlisten_'](_0x3ebb89,_0x4a7078,_0x401c1f,_0xf13859){this['log_']('Unlisten\x20on\x20'+_0x3ebb89+'\x20for\x20'+_0x4a7078);const _0x4e7957={'p':_0x3ebb89},_0x2a0989='n';_0xf13859&&(_0x4e7957['q']=_0x401c1f,_0x4e7957['t']=_0xf13859),this['sendRequest'](_0x2a0989,_0x4e7957);}['onDisconnectPut'](_0x9fe0e9,_0x3e51a1,_0x1e8239){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x9fe0e9,_0x3e51a1,_0x1e8239):this['onDisconnectRequestQueue_']['push']({'pathString':_0x9fe0e9,'action':'o','data':_0x3e51a1,'onComplete':_0x1e8239});}['onDisconnectMerge'](_0x4c5525,_0x1db3a9,_0x359ff0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4c5525,_0x1db3a9,_0x359ff0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4c5525,'action':'om','data':_0x1db3a9,'onComplete':_0x359ff0});}['onDisconnectCancel'](_0x591862,_0x15ca60){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x591862,null,_0x15ca60):this['onDisconnectRequestQueue_']['push']({'pathString':_0x591862,'action':'oc','data':null,'onComplete':_0x15ca60});}['sendOnDisconnect_'](_0x190f6b,_0x2edba5,_0x19aeab,_0x295bd4){const _0xaadc8e={'p':_0x2edba5,'d':_0x19aeab};this['log_']('onDisconnect\x20'+_0x190f6b,_0xaadc8e),this['sendRequest'](_0x190f6b,_0xaadc8e,_0x1a0010=>{_0x295bd4&&setTimeout(()=>{_0x295bd4(_0x1a0010['s'],_0x1a0010['d']);},Math['floor'](0x0));});}['put'](_0x4769e2,_0xaa5f80,_0x2982e4,_0xb5b58d){this['putInternal']('p',_0x4769e2,_0xaa5f80,_0x2982e4,_0xb5b58d);}['merge'](_0x5b2014,_0x36d05f,_0x29dd16,_0x26a838){this['putInternal']('m',_0x5b2014,_0x36d05f,_0x29dd16,_0x26a838);}['putInternal'](_0x4d6275,_0x479141,_0x136f84,_0x572f86,_0x55fd82){this['initConnection_']();const _0x384c5b={'p':_0x479141,'d':_0x136f84};_0x55fd82!==void 0x0&&(_0x384c5b['h']=_0x55fd82),this['outstandingPuts_']['push']({'action':_0x4d6275,'request':_0x384c5b,'onComplete':_0x572f86}),this['outstandingPutCount_']++;const _0x414de2=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x414de2):this['log_']('Buffering\x20put:\x20'+_0x479141);}['sendPut_'](_0x6a24c5){const _0x3a7adf=this['outstandingPuts_'][_0x6a24c5]['action'],_0x3776a2=this['outstandingPuts_'][_0x6a24c5]['request'],_0x16cdb4=this['outstandingPuts_'][_0x6a24c5]['onComplete'];this['outstandingPuts_'][_0x6a24c5]['queued']=this['connected_'],this['sendRequest'](_0x3a7adf,_0x3776a2,_0x3bb6df=>{this['log_'](_0x3a7adf+'\x20response',_0x3bb6df),delete this['outstandingPuts_'][_0x6a24c5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x16cdb4&&_0x16cdb4(_0x3bb6df['s'],_0x3bb6df['d']);});}['reportStats'](_0xc11499){if(this['connected_']){const _0xdc479e={'c':_0xc11499};this['log_']('reportStats',_0xdc479e),this['sendRequest']('s',_0xdc479e,_0xc62f33=>{if(_0xc62f33['s']!=='ok'){const _0x29d440=_0xc62f33['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x29d440);}});}}['onDataMessage_'](_0x15d9cb){if('r'in _0x15d9cb){this['log_']('from\x20server:\x20'+O(_0x15d9cb));const _0x2587be=_0x15d9cb['r'],_0x26052c=this['requestCBHash_'][_0x2587be];_0x26052c&&(delete this['requestCBHash_'][_0x2587be],_0x26052c(_0x15d9cb['b']));}else{if('error'in _0x15d9cb)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x15d9cb['error'];'a'in _0x15d9cb&&this['onDataPush_'](_0x15d9cb['a'],_0x15d9cb['b']);}}['onDataPush_'](_0x56c281,_0x15895a){this['log_']('handleServerMessage',_0x56c281,_0x15895a),_0x56c281==='d'?this['onDataUpdate_'](_0x15895a['p'],_0x15895a['d'],!0x1,_0x15895a['t']):_0x56c281==='m'?this['onDataUpdate_'](_0x15895a['p'],_0x15895a['d'],!0x0,_0x15895a['t']):_0x56c281==='c'?this['onListenRevoked_'](_0x15895a['p'],_0x15895a['q']):_0x56c281==='ac'?this['onAuthRevoked_'](_0x15895a['s'],_0x15895a['d']):_0x56c281==='apc'?this['onAppCheckRevoked_'](_0x15895a['s'],_0x15895a['d']):_0x56c281==='sd'?this['onSecurityDebugPacket_'](_0x15895a):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x56c281)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x38b31d,_0x54b578){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x38b31d),this['lastSessionId']=_0x54b578,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3a7078){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3a7078));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x41a737){_0x41a737&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x41a737;}['onOnline_'](_0x507d26){_0x507d26?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x460536=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x313dde=Math['max'](0x0,this['reconnectDelay_']-_0x460536);_0x313dde=Math['random']()*_0x313dde,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x313dde+'ms'),this['scheduleConnect_'](_0x313dde),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x16178a=this['onDataMessage_']['bind'](this),_0x5f424b=this['onReady_']['bind'](this),_0x2b193f=this['onRealtimeDisconnect_']['bind'](this),_0x747b77=this['id']+':'+ie['nextConnectionId_']++,_0x519bf4=this['lastSessionId'];let _0x42a312=!0x1,_0x14d8d4=null;const _0x29fc4a=function(){_0x14d8d4?_0x14d8d4['close']():(_0x42a312=!0x0,_0x2b193f());},_0x5e7b06=function(_0x50a309){f(_0x14d8d4,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x14d8d4['sendRequest'](_0x50a309);};this['realtime_']={'close':_0x29fc4a,'sendRequest':_0x5e7b06};const _0x5f5714=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4923ed,_0x48731f]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5f5714),this['appCheckTokenProvider_']['getToken'](_0x5f5714)]);_0x42a312?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4923ed&&_0x4923ed['accessToken'],this['appCheckToken_']=_0x48731f&&_0x48731f['token'],_0x14d8d4=new wh(_0x747b77,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x16178a,_0x5f424b,_0x2b193f,_0x4318d2=>{U(_0x4318d2+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x519bf4));}catch(_0x43b68a){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x43b68a),_0x42a312||(this['repoInfo_']['nodeAdmin']&&U(_0x43b68a),_0x29fc4a());}}}['interrupt'](_0x814232){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x814232),this['interruptReasons_'][_0x814232]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5737ee){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5737ee),delete this['interruptReasons_'][_0x5737ee],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2cd57e){const _0x5c137c=_0x2cd57e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5c137c});}['cancelSentTransactions_'](){for(let _0x56ada0=0x0;_0x56ada0<this['outstandingPuts_']['length'];_0x56ada0++){const _0x3e11e9=this['outstandingPuts_'][_0x56ada0];_0x3e11e9&&'h'in _0x3e11e9['request']&&_0x3e11e9['queued']&&(_0x3e11e9['onComplete']&&_0x3e11e9['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x56ada0],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x14164b,_0xfc2eb8){let _0x1e9790;_0xfc2eb8?_0x1e9790=_0xfc2eb8['map'](_0x382fef=>Bi(_0x382fef))['join']('$'):_0x1e9790='default';const _0x3ec727=this['removeListen_'](_0x14164b,_0x1e9790);_0x3ec727&&_0x3ec727['onComplete']&&_0x3ec727['onComplete']('permission_denied');}['removeListen_'](_0x49212c,_0x2fdba0){const _0x2a5778=new C(_0x49212c)['toString']();let _0x1b61de;if(this['listens']['has'](_0x2a5778)){const _0x4d9bf=this['listens']['get'](_0x2a5778);_0x1b61de=_0x4d9bf['get'](_0x2fdba0),_0x4d9bf['delete'](_0x2fdba0),_0x4d9bf['size']===0x0&&this['listens']['delete'](_0x2a5778);}else _0x1b61de=void 0x0;return _0x1b61de;}['onAuthRevoked_'](_0x3042a0,_0x27b76d){L('Auth\x20token\x20revoked:\x20'+_0x3042a0+'/'+_0x27b76d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3042a0==='invalid_token'||_0x3042a0==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2d0ec1,_0x5df084){L('App\x20check\x20token\x20revoked:\x20'+_0x2d0ec1+'/'+_0x5df084),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2d0ec1==='invalid_token'||_0x2d0ec1==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x10ab77){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x10ab77):'msg'in _0x10ab77&&console['log']('FIREBASE:\x20'+_0x10ab77['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3f3ce9 of this['listens']['values']())for(const _0x147ede of _0x3f3ce9['values']())this['sendListen_'](_0x147ede);for(let _0x27aae1=0x0;_0x27aae1<this['outstandingPuts_']['length'];_0x27aae1++)this['outstandingPuts_'][_0x27aae1]&&this['sendPut_'](_0x27aae1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x55dc02=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x55dc02['action'],_0x55dc02['pathString'],_0x55dc02['data'],_0x55dc02['onComplete']);}for(let _0x2d7203=0x0;_0x2d7203<this['outstandingGets_']['length'];_0x2d7203++)this['outstandingGets_'][_0x2d7203]&&this['sendGet_'](_0x2d7203);}['sendConnectStats_'](){const _0xa10bb4={};let _0x16b410='js';_0xa10bb4['sdk.'+_0x16b410+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0xa10bb4['framework.cordova']=0x1:qr()&&(_0xa10bb4['framework.reactnative']=0x1),this['reportStats'](_0xa10bb4);}['shouldReconnect_'](){const _0x19b470=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x19b470;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x197e44,_0x314ade){this['name']=_0x197e44,this['node']=_0x314ade;}static['Wrap'](_0xe96cd3,_0x24d9ca){return new E(_0xe96cd3,_0x24d9ca);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x39d3bd,_0xe19e44){const _0x34e94e=new E(xe,_0x39d3bd),_0x5765dd=new E(xe,_0xe19e44);return this['compare'](_0x34e94e,_0x5765dd)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2412d1){Xt=_0x2412d1;}['compare'](_0x5f2e92,_0x1d7652){return He(_0x5f2e92['name'],_0x1d7652['name']);}['isDefinedOn'](_0x5ef16f){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x46add6,_0x38d272){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3c3e8c,_0x2477e5){return f(typeof _0x3c3e8c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3c3e8c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x53e061,_0x3ebd31,_0x7ef70f,_0x4c84e1,_0x3ee372=null){this['isReverse_']=_0x4c84e1,this['resultGenerator_']=_0x3ee372,this['nodeStack_']=[];let _0x244457=0x1;for(;!_0x53e061['isEmpty']();)if(_0x53e061=_0x53e061,_0x244457=_0x3ebd31?_0x7ef70f(_0x53e061['key'],_0x3ebd31):0x1,_0x4c84e1&&(_0x244457*=-0x1),_0x244457<0x0)this['isReverse_']?_0x53e061=_0x53e061['left']:_0x53e061=_0x53e061['right'];else{if(_0x244457===0x0){this['nodeStack_']['push'](_0x53e061);break;}else this['nodeStack_']['push'](_0x53e061),this['isReverse_']?_0x53e061=_0x53e061['right']:_0x53e061=_0x53e061['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1b543f=this['nodeStack_']['pop'](),_0x1c0443;if(this['resultGenerator_']?_0x1c0443=this['resultGenerator_'](_0x1b543f['key'],_0x1b543f['value']):_0x1c0443={'key':_0x1b543f['key'],'value':_0x1b543f['value']},this['isReverse_']){for(_0x1b543f=_0x1b543f['left'];!_0x1b543f['isEmpty']();)this['nodeStack_']['push'](_0x1b543f),_0x1b543f=_0x1b543f['right'];}else{for(_0x1b543f=_0x1b543f['right'];!_0x1b543f['isEmpty']();)this['nodeStack_']['push'](_0x1b543f),_0x1b543f=_0x1b543f['left'];}return _0x1c0443;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x26b443=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x26b443['key'],_0x26b443['value']):{'key':_0x26b443['key'],'value':_0x26b443['value']};}}class M{constructor(_0x7eacca,_0x16db07,_0x40069c,_0x2c095a,_0x135247){this['key']=_0x7eacca,this['value']=_0x16db07,this['color']=_0x40069c??M['RED'],this['left']=_0x2c095a??B['EMPTY_NODE'],this['right']=_0x135247??B['EMPTY_NODE'];}['copy'](_0x44052d,_0x242485,_0x4322b1,_0x257f54,_0x1e5c90){return new M(_0x44052d??this['key'],_0x242485??this['value'],_0x4322b1??this['color'],_0x257f54??this['left'],_0x1e5c90??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x41cc7c){return this['left']['inorderTraversal'](_0x41cc7c)||!!_0x41cc7c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x41cc7c);}['reverseTraversal'](_0x21a813){return this['right']['reverseTraversal'](_0x21a813)||_0x21a813(this['key'],this['value'])||this['left']['reverseTraversal'](_0x21a813);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x35700c,_0x2b8db7,_0x585826){let _0x1ab614=this;const _0x2063f3=_0x585826(_0x35700c,_0x1ab614['key']);return _0x2063f3<0x0?_0x1ab614=_0x1ab614['copy'](null,null,null,_0x1ab614['left']['insert'](_0x35700c,_0x2b8db7,_0x585826),null):_0x2063f3===0x0?_0x1ab614=_0x1ab614['copy'](null,_0x2b8db7,null,null,null):_0x1ab614=_0x1ab614['copy'](null,null,null,null,_0x1ab614['right']['insert'](_0x35700c,_0x2b8db7,_0x585826)),_0x1ab614['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x55afab=this;return!_0x55afab['left']['isRed_']()&&!_0x55afab['left']['left']['isRed_']()&&(_0x55afab=_0x55afab['moveRedLeft_']()),_0x55afab=_0x55afab['copy'](null,null,null,_0x55afab['left']['removeMin_'](),null),_0x55afab['fixUp_']();}['remove'](_0x2098cb,_0x5596be){let _0x4aaa0b,_0x3b107c;if(_0x4aaa0b=this,_0x5596be(_0x2098cb,_0x4aaa0b['key'])<0x0)!_0x4aaa0b['left']['isEmpty']()&&!_0x4aaa0b['left']['isRed_']()&&!_0x4aaa0b['left']['left']['isRed_']()&&(_0x4aaa0b=_0x4aaa0b['moveRedLeft_']()),_0x4aaa0b=_0x4aaa0b['copy'](null,null,null,_0x4aaa0b['left']['remove'](_0x2098cb,_0x5596be),null);else{if(_0x4aaa0b['left']['isRed_']()&&(_0x4aaa0b=_0x4aaa0b['rotateRight_']()),!_0x4aaa0b['right']['isEmpty']()&&!_0x4aaa0b['right']['isRed_']()&&!_0x4aaa0b['right']['left']['isRed_']()&&(_0x4aaa0b=_0x4aaa0b['moveRedRight_']()),_0x5596be(_0x2098cb,_0x4aaa0b['key'])===0x0){if(_0x4aaa0b['right']['isEmpty']())return B['EMPTY_NODE'];_0x3b107c=_0x4aaa0b['right']['min_'](),_0x4aaa0b=_0x4aaa0b['copy'](_0x3b107c['key'],_0x3b107c['value'],null,null,_0x4aaa0b['right']['removeMin_']());}_0x4aaa0b=_0x4aaa0b['copy'](null,null,null,null,_0x4aaa0b['right']['remove'](_0x2098cb,_0x5596be));}return _0x4aaa0b['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4f5016=this;return _0x4f5016['right']['isRed_']()&&!_0x4f5016['left']['isRed_']()&&(_0x4f5016=_0x4f5016['rotateLeft_']()),_0x4f5016['left']['isRed_']()&&_0x4f5016['left']['left']['isRed_']()&&(_0x4f5016=_0x4f5016['rotateRight_']()),_0x4f5016['left']['isRed_']()&&_0x4f5016['right']['isRed_']()&&(_0x4f5016=_0x4f5016['colorFlip_']()),_0x4f5016;}['moveRedLeft_'](){let _0x4cc74a=this['colorFlip_']();return _0x4cc74a['right']['left']['isRed_']()&&(_0x4cc74a=_0x4cc74a['copy'](null,null,null,null,_0x4cc74a['right']['rotateRight_']()),_0x4cc74a=_0x4cc74a['rotateLeft_'](),_0x4cc74a=_0x4cc74a['colorFlip_']()),_0x4cc74a;}['moveRedRight_'](){let _0x476da7=this['colorFlip_']();return _0x476da7['left']['left']['isRed_']()&&(_0x476da7=_0x476da7['rotateRight_'](),_0x476da7=_0x476da7['colorFlip_']()),_0x476da7;}['rotateLeft_'](){const _0x4113b9=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4113b9,null);}['rotateRight_'](){const _0x10c461=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x10c461);}['colorFlip_'](){const _0xce3d56=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x10d605=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xce3d56,_0x10d605);}['checkMaxDepth_'](){const _0x3227ff=this['check_']();return Math['pow'](0x2,_0x3227ff)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5e7a7a=this['left']['check_']();if(_0x5e7a7a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5e7a7a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x562c3e,_0x32c076,_0x47cfb0,_0x4915a4,_0x2eadf4){return this;}['insert'](_0x3c0b69,_0x518901,_0x17b305){return new M(_0x3c0b69,_0x518901,null);}['remove'](_0x2b29a0,_0x19f2df){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x292ac2){return!0x1;}['reverseTraversal'](_0x33675a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1a6162,_0x5279ec=B['EMPTY_NODE']){this['comparator_']=_0x1a6162,this['root_']=_0x5279ec;}['insert'](_0x42a5b3,_0x50c248){return new B(this['comparator_'],this['root_']['insert'](_0x42a5b3,_0x50c248,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xbfa378){return new B(this['comparator_'],this['root_']['remove'](_0xbfa378,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1e46a6){let _0x3a6ac1,_0x68717b=this['root_'];for(;!_0x68717b['isEmpty']();){if(_0x3a6ac1=this['comparator_'](_0x1e46a6,_0x68717b['key']),_0x3a6ac1===0x0)return _0x68717b['value'];_0x3a6ac1<0x0?_0x68717b=_0x68717b['left']:_0x3a6ac1>0x0&&(_0x68717b=_0x68717b['right']);}return null;}['getPredecessorKey'](_0x5a2093){let _0x2ee628,_0x24ee95=this['root_'],_0x3bd77c=null;for(;!_0x24ee95['isEmpty']();)if(_0x2ee628=this['comparator_'](_0x5a2093,_0x24ee95['key']),_0x2ee628===0x0){if(_0x24ee95['left']['isEmpty']())return _0x3bd77c?_0x3bd77c['key']:null;for(_0x24ee95=_0x24ee95['left'];!_0x24ee95['right']['isEmpty']();)_0x24ee95=_0x24ee95['right'];return _0x24ee95['key'];}else _0x2ee628<0x0?_0x24ee95=_0x24ee95['left']:_0x2ee628>0x0&&(_0x3bd77c=_0x24ee95,_0x24ee95=_0x24ee95['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x39ac8a){return this['root_']['inorderTraversal'](_0x39ac8a);}['reverseTraversal'](_0x3912a9){return this['root_']['reverseTraversal'](_0x3912a9);}['getIterator'](_0x86cbe1){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x86cbe1);}['getIteratorFrom'](_0x1a6816,_0x2b9199){return new Zt(this['root_'],_0x1a6816,this['comparator_'],!0x1,_0x2b9199);}['getReverseIteratorFrom'](_0x3550fe,_0x355139){return new Zt(this['root_'],_0x3550fe,this['comparator_'],!0x0,_0x355139);}['getReverseIterator'](_0x1e5df3){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x1e5df3);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x302627,_0x1d8da0){return He(_0x302627['name'],_0x1d8da0['name']);}function ji(_0x190deb,_0x1c092b){return He(_0x190deb,_0x1c092b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x3c11e8){vi=_0x3c11e8;}const Ro=function(_0x489373){return typeof _0x489373=='number'?'number:'+so(_0x489373):'string:'+_0x489373;},Ao=function(_0x3955fc){if(_0x3955fc['isLeafNode']()){const _0x28325d=_0x3955fc['val']();f(typeof _0x28325d=='string'||typeof _0x28325d=='number'||typeof _0x28325d=='object'&&Y(_0x28325d,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3955fc===vi||_0x3955fc['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3955fc===vi||_0x3955fc['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x577562){er=_0x577562;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x1aede7,_0x5a89f5=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1aede7,this['priorityNode_']=_0x5a89f5,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4e37cf){return new D(this['value_'],_0x4e37cf);}['getImmediateChild'](_0x1f7042){return _0x1f7042==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3ab71b){return v(_0x3ab71b)?this:y(_0x3ab71b)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x34ff3e,_0x1665a1){return null;}['updateImmediateChild'](_0x11d279,_0x82f357){return _0x11d279==='.priority'?this['updatePriority'](_0x82f357):_0x82f357['isEmpty']()&&_0x11d279!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x11d279,_0x82f357)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xd82b5c,_0xbfc398){const _0x434a17=y(_0xd82b5c);return _0x434a17===null?_0xbfc398:_0xbfc398['isEmpty']()&&_0x434a17!=='.priority'?this:(f(_0x434a17!=='.priority'||we(_0xd82b5c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x434a17,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0xd82b5c),_0xbfc398)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x26cf96,_0x357093){return!0x1;}['val'](_0x37c8d5){return _0x37c8d5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x18202f='';this['priorityNode_']['isEmpty']()||(_0x18202f+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x4ea3d3=typeof this['value_'];_0x18202f+=_0x4ea3d3+':',_0x4ea3d3==='number'?_0x18202f+=so(this['value_']):_0x18202f+=this['value_'],this['lazyHash_']=no(_0x18202f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x42342f){return _0x42342f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x42342f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x42342f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x42342f));}['compareToLeafNode_'](_0x1cb6ff){const _0x1993fa=typeof _0x1cb6ff['value_'],_0x28a618=typeof this['value_'],_0x5b80d7=D['VALUE_TYPE_ORDER']['indexOf'](_0x1993fa),_0x12bd5a=D['VALUE_TYPE_ORDER']['indexOf'](_0x28a618);return f(_0x5b80d7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1993fa),f(_0x12bd5a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x28a618),_0x5b80d7===_0x12bd5a?_0x28a618==='object'?0x0:this['value_']<_0x1cb6ff['value_']?-0x1:this['value_']===_0x1cb6ff['value_']?0x0:0x1:_0x12bd5a-_0x5b80d7;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1dde2e){if(_0x1dde2e===this)return!0x0;if(_0x1dde2e['isLeafNode']()){const _0x3d67f6=_0x1dde2e;return this['value_']===_0x3d67f6['value_']&&this['priorityNode_']['equals'](_0x3d67f6['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x141deb){ko=_0x141deb;}function xh(_0x2f00b8){No=_0x2f00b8;}class Fh extends On{['compare'](_0x466dae,_0x55969f){const _0x31e9c5=_0x466dae['node']['getPriority'](),_0x22f52e=_0x55969f['node']['getPriority'](),_0x4477d0=_0x31e9c5['compareTo'](_0x22f52e);return _0x4477d0===0x0?He(_0x466dae['name'],_0x55969f['name']):_0x4477d0;}['isDefinedOn'](_0x492389){return!_0x492389['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x242140,_0xbae872){return!_0x242140['getPriority']()['equals'](_0xbae872['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x5cc8d8,_0x29febf){const _0x2f5e91=ko(_0x5cc8d8);return new E(_0x29febf,new D('[PRIORITY-POST]',_0x2f5e91));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x25006d){const _0x5da3b6=_0x417a98=>parseInt(Math['log'](_0x417a98)/Uh,0xa),_0x5b08d5=_0xd74f46=>parseInt(Array(_0xd74f46+0x1)['join']('1'),0x2);this['count']=_0x5da3b6(_0x25006d+0x1),this['current_']=this['count']-0x1;const _0x2a2045=_0x5b08d5(this['count']);this['bits_']=_0x25006d+0x1&_0x2a2045;}['nextBitIsOne'](){const _0x162ba5=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x162ba5;}}const dn=function(_0x912f12,_0x17d697,_0x6ad64f,_0xbc4b78){_0x912f12['sort'](_0x17d697);const _0x55cbe3=function(_0x259774,_0x5c7243){const _0x3cb60c=_0x5c7243-_0x259774;let _0x3fc011,_0x6bfb1;if(_0x3cb60c===0x0)return null;if(_0x3cb60c===0x1)return _0x3fc011=_0x912f12[_0x259774],_0x6bfb1=_0x6ad64f?_0x6ad64f(_0x3fc011):_0x3fc011,new M(_0x6bfb1,_0x3fc011['node'],M['BLACK'],null,null);{const _0x22fa0d=parseInt(_0x3cb60c/0x2,0xa)+_0x259774,_0x44c70c=_0x55cbe3(_0x259774,_0x22fa0d),_0x502c40=_0x55cbe3(_0x22fa0d+0x1,_0x5c7243);return _0x3fc011=_0x912f12[_0x22fa0d],_0x6bfb1=_0x6ad64f?_0x6ad64f(_0x3fc011):_0x3fc011,new M(_0x6bfb1,_0x3fc011['node'],M['BLACK'],_0x44c70c,_0x502c40);}},_0x5cfb7c=function(_0x16f21c){let _0x4b7fdb=null,_0x560bef=null,_0x4e8b77=_0x912f12['length'];const _0x3cd64c=function(_0x50b0ae,_0x36ae3c){const _0x41c157=_0x4e8b77-_0x50b0ae,_0x13b93f=_0x4e8b77;_0x4e8b77-=_0x50b0ae;const _0x3c55c5=_0x55cbe3(_0x41c157+0x1,_0x13b93f),_0x2cd46e=_0x912f12[_0x41c157],_0x58aa63=_0x6ad64f?_0x6ad64f(_0x2cd46e):_0x2cd46e;_0x592220(new M(_0x58aa63,_0x2cd46e['node'],_0x36ae3c,null,_0x3c55c5));},_0x592220=function(_0x4023c3){_0x4b7fdb?(_0x4b7fdb['left']=_0x4023c3,_0x4b7fdb=_0x4023c3):(_0x560bef=_0x4023c3,_0x4b7fdb=_0x4023c3);};for(let _0x481bec=0x0;_0x481bec<_0x16f21c['count'];++_0x481bec){const _0x20d9af=_0x16f21c['nextBitIsOne'](),_0x5c1d77=Math['pow'](0x2,_0x16f21c['count']-(_0x481bec+0x1));_0x20d9af?_0x3cd64c(_0x5c1d77,M['BLACK']):(_0x3cd64c(_0x5c1d77,M['BLACK']),_0x3cd64c(_0x5c1d77,M['RED']));}return _0x560bef;},_0x2dee3e=new Wh(_0x912f12['length']),_0x172f86=_0x5cfb7c(_0x2dee3e);return new B(_0xbc4b78||_0x17d697,_0x172f86);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x1fb610,_0x52cba5){this['indexes_']=_0x1fb610,this['indexSet_']=_0x52cba5;}['get'](_0x4fe4b0){const _0xd0e46b=Oe(this['indexes_'],_0x4fe4b0);if(!_0xd0e46b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4fe4b0);return _0xd0e46b instanceof B?_0xd0e46b:null;}['hasIndex'](_0x1d0334){return Y(this['indexSet_'],_0x1d0334['toString']());}['addIndex'](_0x534034,_0x1f4997){f(_0x534034!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4f593b=[];let _0x292ef4=!0x1;const _0x65ee22=_0x1f4997['getIterator'](E['Wrap']);let _0x2480d1=_0x65ee22['getNext']();for(;_0x2480d1;)_0x292ef4=_0x292ef4||_0x534034['isDefinedOn'](_0x2480d1['node']),_0x4f593b['push'](_0x2480d1),_0x2480d1=_0x65ee22['getNext']();let _0x1b46b8;_0x292ef4?_0x1b46b8=dn(_0x4f593b,_0x534034['getCompare']()):_0x1b46b8=je;const _0x485bd7=_0x534034['toString'](),_0x109d41={...this['indexSet_']};_0x109d41[_0x485bd7]=_0x534034;const _0x567bcc={...this['indexes_']};return _0x567bcc[_0x485bd7]=_0x1b46b8,new ee(_0x567bcc,_0x109d41);}['addToIndexes'](_0x2d436b,_0x9ce349){const _0x833311=ln(this['indexes_'],(_0x5489b9,_0x459db0)=>{const _0x1f665f=Oe(this['indexSet_'],_0x459db0);if(f(_0x1f665f,'Missing\x20index\x20implementation\x20for\x20'+_0x459db0),_0x5489b9===je){if(_0x1f665f['isDefinedOn'](_0x2d436b['node'])){const _0x1ad3cb=[],_0x3128ef=_0x9ce349['getIterator'](E['Wrap']);let _0x4648f8=_0x3128ef['getNext']();for(;_0x4648f8;)_0x4648f8['name']!==_0x2d436b['name']&&_0x1ad3cb['push'](_0x4648f8),_0x4648f8=_0x3128ef['getNext']();return _0x1ad3cb['push'](_0x2d436b),dn(_0x1ad3cb,_0x1f665f['getCompare']());}else return je;}else{const _0xb2e82=_0x9ce349['get'](_0x2d436b['name']);let _0x5a7e48=_0x5489b9;return _0xb2e82&&(_0x5a7e48=_0x5a7e48['remove'](new E(_0x2d436b['name'],_0xb2e82))),_0x5a7e48['insert'](_0x2d436b,_0x2d436b['node']);}});return new ee(_0x833311,this['indexSet_']);}['removeFromIndexes'](_0x3fc211,_0x5dccd2){const _0xed9cd9=ln(this['indexes_'],_0x163c5c=>{if(_0x163c5c===je)return _0x163c5c;{const _0x4a24dd=_0x5dccd2['get'](_0x3fc211['name']);return _0x4a24dd?_0x163c5c['remove'](new E(_0x3fc211['name'],_0x4a24dd)):_0x163c5c;}});return new ee(_0xed9cd9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2e425e,_0x21d741,_0x3b5ea8){this['children_']=_0x2e425e,this['priorityNode_']=_0x21d741,this['indexMap_']=_0x3b5ea8,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x48891f){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x48891f,this['indexMap_']);}['getImmediateChild'](_0x162e61){if(_0x162e61==='.priority')return this['getPriority']();{const _0x435edb=this['children_']['get'](_0x162e61);return _0x435edb===null?gt:_0x435edb;}}['getChild'](_0x1cb53a){const _0x51ae97=y(_0x1cb53a);return _0x51ae97===null?this:this['getImmediateChild'](_0x51ae97)['getChild'](b(_0x1cb53a));}['hasChild'](_0x4808c6){return this['children_']['get'](_0x4808c6)!==null;}['updateImmediateChild'](_0x2c29d1,_0x13ba8c){if(f(_0x13ba8c,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2c29d1==='.priority')return this['updatePriority'](_0x13ba8c);{const _0xf90522=new E(_0x2c29d1,_0x13ba8c);let _0x14d311,_0x36b76f;_0x13ba8c['isEmpty']()?(_0x14d311=this['children_']['remove'](_0x2c29d1),_0x36b76f=this['indexMap_']['removeFromIndexes'](_0xf90522,this['children_'])):(_0x14d311=this['children_']['insert'](_0x2c29d1,_0x13ba8c),_0x36b76f=this['indexMap_']['addToIndexes'](_0xf90522,this['children_']));const _0x4ecc59=_0x14d311['isEmpty']()?gt:this['priorityNode_'];return new g(_0x14d311,_0x4ecc59,_0x36b76f);}}['updateChild'](_0x3d8465,_0x3400e1){const _0x384474=y(_0x3d8465);if(_0x384474===null)return _0x3400e1;{f(y(_0x3d8465)!=='.priority'||we(_0x3d8465)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x217a46=this['getImmediateChild'](_0x384474)['updateChild'](b(_0x3d8465),_0x3400e1);return this['updateImmediateChild'](_0x384474,_0x217a46);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3a10fe){if(this['isEmpty']())return null;const _0x568ef8={};let _0x38dcd1=0x0,_0x7014e0=0x0,_0x2c06d3=!0x0;if(this['forEachChild'](R,(_0x73a32f,_0x42bf8d)=>{_0x568ef8[_0x73a32f]=_0x42bf8d['val'](_0x3a10fe),_0x38dcd1++,_0x2c06d3&&g['INTEGER_REGEXP_']['test'](_0x73a32f)?_0x7014e0=Math['max'](_0x7014e0,Number(_0x73a32f)):_0x2c06d3=!0x1;}),!_0x3a10fe&&_0x2c06d3&&_0x7014e0<0x2*_0x38dcd1){const _0x4b9bad=[];for(const _0x48d644 in _0x568ef8)_0x4b9bad[_0x48d644]=_0x568ef8[_0x48d644];return _0x4b9bad;}else return _0x3a10fe&&!this['getPriority']()['isEmpty']()&&(_0x568ef8['.priority']=this['getPriority']()['val']()),_0x568ef8;}['hash'](){if(this['lazyHash_']===null){let _0x1fd015='';this['getPriority']()['isEmpty']()||(_0x1fd015+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2a6cc1,_0x4338ed)=>{const _0xdce84d=_0x4338ed['hash']();_0xdce84d!==''&&(_0x1fd015+=':'+_0x2a6cc1+':'+_0xdce84d);}),this['lazyHash_']=_0x1fd015===''?'':no(_0x1fd015);}return this['lazyHash_'];}['getPredecessorChildName'](_0xab9213,_0x3cd26e,_0x625f6f){const _0x50bf52=this['resolveIndex_'](_0x625f6f);if(_0x50bf52){const _0x3ce6a9=_0x50bf52['getPredecessorKey'](new E(_0xab9213,_0x3cd26e));return _0x3ce6a9?_0x3ce6a9['name']:null;}else return this['children_']['getPredecessorKey'](_0xab9213);}['getFirstChildName'](_0x425115){const _0x22247b=this['resolveIndex_'](_0x425115);if(_0x22247b){const _0x2d36e4=_0x22247b['minKey']();return _0x2d36e4&&_0x2d36e4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x47e35b){const _0x5d92fe=this['getFirstChildName'](_0x47e35b);return _0x5d92fe?new E(_0x5d92fe,this['children_']['get'](_0x5d92fe)):null;}['getLastChildName'](_0x3fcabf){const _0x4268de=this['resolveIndex_'](_0x3fcabf);if(_0x4268de){const _0x24e9bd=_0x4268de['maxKey']();return _0x24e9bd&&_0x24e9bd['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x34fce8){const _0x33cfba=this['getLastChildName'](_0x34fce8);return _0x33cfba?new E(_0x33cfba,this['children_']['get'](_0x33cfba)):null;}['forEachChild'](_0x16ff83,_0x576455){const _0x53288d=this['resolveIndex_'](_0x16ff83);return _0x53288d?_0x53288d['inorderTraversal'](_0x2856eb=>_0x576455(_0x2856eb['name'],_0x2856eb['node'])):this['children_']['inorderTraversal'](_0x576455);}['getIterator'](_0x396edb){return this['getIteratorFrom'](_0x396edb['minPost'](),_0x396edb);}['getIteratorFrom'](_0x301965,_0x2a2e60){const _0x3d596c=this['resolveIndex_'](_0x2a2e60);if(_0x3d596c)return _0x3d596c['getIteratorFrom'](_0x301965,_0x25b748=>_0x25b748);{const _0x50b731=this['children_']['getIteratorFrom'](_0x301965['name'],E['Wrap']);let _0x2e45bb=_0x50b731['peek']();for(;_0x2e45bb!=null&&_0x2a2e60['compare'](_0x2e45bb,_0x301965)<0x0;)_0x50b731['getNext'](),_0x2e45bb=_0x50b731['peek']();return _0x50b731;}}['getReverseIterator'](_0x5868b1){return this['getReverseIteratorFrom'](_0x5868b1['maxPost'](),_0x5868b1);}['getReverseIteratorFrom'](_0x4a9601,_0x1c3bfe){const _0x3b6736=this['resolveIndex_'](_0x1c3bfe);if(_0x3b6736)return _0x3b6736['getReverseIteratorFrom'](_0x4a9601,_0x5b451b=>_0x5b451b);{const _0x1afb6f=this['children_']['getReverseIteratorFrom'](_0x4a9601['name'],E['Wrap']);let _0x182065=_0x1afb6f['peek']();for(;_0x182065!=null&&_0x1c3bfe['compare'](_0x182065,_0x4a9601)>0x0;)_0x1afb6f['getNext'](),_0x182065=_0x1afb6f['peek']();return _0x1afb6f;}}['compareTo'](_0x19a03f){return this['isEmpty']()?_0x19a03f['isEmpty']()?0x0:-0x1:_0x19a03f['isLeafNode']()||_0x19a03f['isEmpty']()?0x1:_0x19a03f===Ht?-0x1:0x0;}['withIndex'](_0x1ab4ac){if(_0x1ab4ac===ye||this['indexMap_']['hasIndex'](_0x1ab4ac))return this;{const _0x1f331c=this['indexMap_']['addIndex'](_0x1ab4ac,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1f331c);}}['isIndexed'](_0x553ad4){return _0x553ad4===ye||this['indexMap_']['hasIndex'](_0x553ad4);}['equals'](_0xe4c79b){if(_0xe4c79b===this)return!0x0;if(_0xe4c79b['isLeafNode']())return!0x1;{const _0x242bb2=_0xe4c79b;if(this['getPriority']()['equals'](_0x242bb2['getPriority']())){if(this['children_']['count']()===_0x242bb2['children_']['count']()){const _0x215876=this['getIterator'](R),_0x3428f0=_0x242bb2['getIterator'](R);let _0x4a4d5d=_0x215876['getNext'](),_0x214983=_0x3428f0['getNext']();for(;_0x4a4d5d&&_0x214983;){if(_0x4a4d5d['name']!==_0x214983['name']||!_0x4a4d5d['node']['equals'](_0x214983['node']))return!0x1;_0x4a4d5d=_0x215876['getNext'](),_0x214983=_0x3428f0['getNext']();}return _0x4a4d5d===null&&_0x214983===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3bce7f){return _0x3bce7f===ye?null:this['indexMap_']['get'](_0x3bce7f['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x4a76fc){return _0x4a76fc===this?0x0:0x1;}['equals'](_0x3a8bcc){return _0x3a8bcc===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3cf421){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x212c95,_0x3a3ce4=null){if(_0x212c95===null)return g['EMPTY_NODE'];if(typeof _0x212c95=='object'&&'.priority'in _0x212c95&&(_0x3a3ce4=_0x212c95['.priority']),f(_0x3a3ce4===null||typeof _0x3a3ce4=='string'||typeof _0x3a3ce4=='number'||typeof _0x3a3ce4=='object'&&'.sv'in _0x3a3ce4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3a3ce4),typeof _0x212c95=='object'&&'.value'in _0x212c95&&_0x212c95['.value']!==null&&(_0x212c95=_0x212c95['.value']),typeof _0x212c95!='object'||'.sv'in _0x212c95){const _0x101523=_0x212c95;return new D(_0x101523,N(_0x3a3ce4));}if(!(_0x212c95 instanceof Array)&&Vh){const _0x346995=[];let _0x679e9a=!0x1;if(x(_0x212c95,(_0x561a95,_0x492723)=>{if(_0x561a95['substring'](0x0,0x1)!=='.'){const _0x1ec9ae=N(_0x492723);_0x1ec9ae['isEmpty']()||(_0x679e9a=_0x679e9a||!_0x1ec9ae['getPriority']()['isEmpty'](),_0x346995['push'](new E(_0x561a95,_0x1ec9ae)));}}),_0x346995['length']===0x0)return g['EMPTY_NODE'];const _0x5c2710=dn(_0x346995,Dh,_0x4da435=>_0x4da435['name'],ji);if(_0x679e9a){const _0x4a0906=dn(_0x346995,R['getCompare']());return new g(_0x5c2710,N(_0x3a3ce4),new ee({'.priority':_0x4a0906},{'.priority':R}));}else return new g(_0x5c2710,N(_0x3a3ce4),ee['Default']);}else{let _0x3c01d3=g['EMPTY_NODE'];return x(_0x212c95,(_0x5d8922,_0x1f69a0)=>{if(Y(_0x212c95,_0x5d8922)&&_0x5d8922['substring'](0x0,0x1)!=='.'){const _0x3de205=N(_0x1f69a0);(_0x3de205['isLeafNode']()||!_0x3de205['isEmpty']())&&(_0x3c01d3=_0x3c01d3['updateImmediateChild'](_0x5d8922,_0x3de205));}}),_0x3c01d3['updatePriority'](N(_0x3a3ce4));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3d3e44){super(),this['indexPath_']=_0x3d3e44,f(!v(_0x3d3e44)&&y(_0x3d3e44)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x51687c){return _0x51687c['getChild'](this['indexPath_']);}['isDefinedOn'](_0x14adc3){return!_0x14adc3['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x10aa32,_0x5c4628){const _0x42279f=this['extractChild'](_0x10aa32['node']),_0x2d1371=this['extractChild'](_0x5c4628['node']),_0x1540b2=_0x42279f['compareTo'](_0x2d1371);return _0x1540b2===0x0?He(_0x10aa32['name'],_0x5c4628['name']):_0x1540b2;}['makePost'](_0x43310a,_0x1a748b){const _0x8acdf9=N(_0x43310a),_0x569beb=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x8acdf9);return new E(_0x1a748b,_0x569beb);}['maxPost'](){const _0x481ca1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x481ca1);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x48d56b,_0x462c10){const _0x2101c2=_0x48d56b['node']['compareTo'](_0x462c10['node']);return _0x2101c2===0x0?He(_0x48d56b['name'],_0x462c10['name']):_0x2101c2;}['isDefinedOn'](_0x10da26){return!0x0;}['indexedValueChanged'](_0x22afa4,_0x106dc0){return!_0x22afa4['equals'](_0x106dc0);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x220e04,_0x537c31){const _0x3c58c9=N(_0x220e04);return new E(_0x537c31,_0x3c58c9);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x4c28f6){return{'type':'value','snapshotNode':_0x4c28f6};}function tt(_0x9444f5,_0x14674c){return{'type':'child_added','snapshotNode':_0x14674c,'childName':_0x9444f5};}function Nt(_0x3edeb3,_0x719704){return{'type':'child_removed','snapshotNode':_0x719704,'childName':_0x3edeb3};}function Pt(_0x2668cd,_0x30d67e,_0x47fd6b){return{'type':'child_changed','snapshotNode':_0x30d67e,'childName':_0x2668cd,'oldSnap':_0x47fd6b};}function $h(_0xbfcab0,_0x578754){return{'type':'child_moved','snapshotNode':_0x578754,'childName':_0xbfcab0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x313736){this['index_']=_0x313736;}['updateChild'](_0x42ee2e,_0x5640cd,_0x224dcb,_0x30d875,_0x4c320f,_0x124d27){f(_0x42ee2e['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3941e0=_0x42ee2e['getImmediateChild'](_0x5640cd);return _0x3941e0['getChild'](_0x30d875)['equals'](_0x224dcb['getChild'](_0x30d875))&&_0x3941e0['isEmpty']()===_0x224dcb['isEmpty']()||(_0x124d27!=null&&(_0x224dcb['isEmpty']()?_0x42ee2e['hasChild'](_0x5640cd)?_0x124d27['trackChildChange'](Nt(_0x5640cd,_0x3941e0)):f(_0x42ee2e['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3941e0['isEmpty']()?_0x124d27['trackChildChange'](tt(_0x5640cd,_0x224dcb)):_0x124d27['trackChildChange'](Pt(_0x5640cd,_0x224dcb,_0x3941e0))),_0x42ee2e['isLeafNode']()&&_0x224dcb['isEmpty']())?_0x42ee2e:_0x42ee2e['updateImmediateChild'](_0x5640cd,_0x224dcb)['withIndex'](this['index_']);}['updateFullNode'](_0xf6234f,_0x36e59a,_0x2162c3){return _0x2162c3!=null&&(_0xf6234f['isLeafNode']()||_0xf6234f['forEachChild'](R,(_0x32103e,_0x4f5722)=>{_0x36e59a['hasChild'](_0x32103e)||_0x2162c3['trackChildChange'](Nt(_0x32103e,_0x4f5722));}),_0x36e59a['isLeafNode']()||_0x36e59a['forEachChild'](R,(_0x27879a,_0x239c97)=>{if(_0xf6234f['hasChild'](_0x27879a)){const _0x4c8b5a=_0xf6234f['getImmediateChild'](_0x27879a);_0x4c8b5a['equals'](_0x239c97)||_0x2162c3['trackChildChange'](Pt(_0x27879a,_0x239c97,_0x4c8b5a));}else _0x2162c3['trackChildChange'](tt(_0x27879a,_0x239c97));})),_0x36e59a['withIndex'](this['index_']);}['updatePriority'](_0x8f0994,_0x42be06){return _0x8f0994['isEmpty']()?g['EMPTY_NODE']:_0x8f0994['updatePriority'](_0x42be06);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x3c121d){this['indexedFilter_']=new Yi(_0x3c121d['getIndex']()),this['index_']=_0x3c121d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x3c121d),this['endPost_']=Ot['getEndPost_'](_0x3c121d),this['startIsInclusive_']=!_0x3c121d['startAfterSet_'],this['endIsInclusive_']=!_0x3c121d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5b18a4){const _0x313317=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5b18a4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5b18a4)<0x0,_0x4127a2=this['endIsInclusive_']?this['index_']['compare'](_0x5b18a4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5b18a4,this['getEndPost']())<0x0;return _0x313317&&_0x4127a2;}['updateChild'](_0x3b31d2,_0x1c9275,_0x19d63c,_0x1e72f7,_0x3a1ae1,_0x337ad4){return this['matches'](new E(_0x1c9275,_0x19d63c))||(_0x19d63c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3b31d2,_0x1c9275,_0x19d63c,_0x1e72f7,_0x3a1ae1,_0x337ad4);}['updateFullNode'](_0x20a843,_0x1c46fc,_0x2d0826){_0x1c46fc['isLeafNode']()&&(_0x1c46fc=g['EMPTY_NODE']);let _0x15e6bd=_0x1c46fc['withIndex'](this['index_']);_0x15e6bd=_0x15e6bd['updatePriority'](g['EMPTY_NODE']);const _0x12e3f6=this;return _0x1c46fc['forEachChild'](R,(_0x267dcc,_0x30fbbd)=>{_0x12e3f6['matches'](new E(_0x267dcc,_0x30fbbd))||(_0x15e6bd=_0x15e6bd['updateImmediateChild'](_0x267dcc,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x20a843,_0x15e6bd,_0x2d0826);}['updatePriority'](_0x18ca05,_0x4a8180){return _0x18ca05;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x412523){if(_0x412523['hasStart']()){const _0x29429b=_0x412523['getIndexStartName']();return _0x412523['getIndex']()['makePost'](_0x412523['getIndexStartValue'](),_0x29429b);}else return _0x412523['getIndex']()['minPost']();}static['getEndPost_'](_0x40ef3e){if(_0x40ef3e['hasEnd']()){const _0x1d8269=_0x40ef3e['getIndexEndName']();return _0x40ef3e['getIndex']()['makePost'](_0x40ef3e['getIndexEndValue'](),_0x1d8269);}else return _0x40ef3e['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x43b889){this['withinDirectionalStart']=_0x5145b8=>this['reverse_']?this['withinEndPost'](_0x5145b8):this['withinStartPost'](_0x5145b8),this['withinDirectionalEnd']=_0x2b9cbc=>this['reverse_']?this['withinStartPost'](_0x2b9cbc):this['withinEndPost'](_0x2b9cbc),this['withinStartPost']=_0x36f7bb=>{const _0x3e039c=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x36f7bb);return this['startIsInclusive_']?_0x3e039c<=0x0:_0x3e039c<0x0;},this['withinEndPost']=_0x75b1c2=>{const _0x3175fe=this['index_']['compare'](_0x75b1c2,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3175fe<=0x0:_0x3175fe<0x0;},this['rangedFilter_']=new Ot(_0x43b889),this['index_']=_0x43b889['getIndex'](),this['limit_']=_0x43b889['getLimit'](),this['reverse_']=!_0x43b889['isViewFromLeft'](),this['startIsInclusive_']=!_0x43b889['startAfterSet_'],this['endIsInclusive_']=!_0x43b889['endBeforeSet_'];}['updateChild'](_0x2c1b6f,_0x2e1a96,_0x3514b2,_0x4348ee,_0x174cd5,_0xb03b49){return this['rangedFilter_']['matches'](new E(_0x2e1a96,_0x3514b2))||(_0x3514b2=g['EMPTY_NODE']),_0x2c1b6f['getImmediateChild'](_0x2e1a96)['equals'](_0x3514b2)?_0x2c1b6f:_0x2c1b6f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2c1b6f,_0x2e1a96,_0x3514b2,_0x4348ee,_0x174cd5,_0xb03b49):this['fullLimitUpdateChild_'](_0x2c1b6f,_0x2e1a96,_0x3514b2,_0x174cd5,_0xb03b49);}['updateFullNode'](_0x97c5ea,_0x5dd82c,_0xc14a6a){let _0x4b867a;if(_0x5dd82c['isLeafNode']()||_0x5dd82c['isEmpty']())_0x4b867a=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5dd82c['numChildren']()&&_0x5dd82c['isIndexed'](this['index_'])){_0x4b867a=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x2c9e41;this['reverse_']?_0x2c9e41=_0x5dd82c['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x2c9e41=_0x5dd82c['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2af142=0x0;for(;_0x2c9e41['hasNext']()&&_0x2af142<this['limit_'];){const _0x23c50b=_0x2c9e41['getNext']();if(this['withinDirectionalStart'](_0x23c50b)){if(this['withinDirectionalEnd'](_0x23c50b))_0x4b867a=_0x4b867a['updateImmediateChild'](_0x23c50b['name'],_0x23c50b['node']),_0x2af142++;else break;}else continue;}}else{_0x4b867a=_0x5dd82c['withIndex'](this['index_']),_0x4b867a=_0x4b867a['updatePriority'](g['EMPTY_NODE']);let _0x3ddb77;this['reverse_']?_0x3ddb77=_0x4b867a['getReverseIterator'](this['index_']):_0x3ddb77=_0x4b867a['getIterator'](this['index_']);let _0x29950c=0x0;for(;_0x3ddb77['hasNext']();){const _0x3a9eaf=_0x3ddb77['getNext']();_0x29950c<this['limit_']&&this['withinDirectionalStart'](_0x3a9eaf)&&this['withinDirectionalEnd'](_0x3a9eaf)?_0x29950c++:_0x4b867a=_0x4b867a['updateImmediateChild'](_0x3a9eaf['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x97c5ea,_0x4b867a,_0xc14a6a);}['updatePriority'](_0x1acc96,_0x18c439){return _0x1acc96;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x49b33,_0x34735b,_0x111c5d,_0x53b8fa,_0x186aba){let _0x33d5f0;if(this['reverse_']){const _0x2392a4=this['index_']['getCompare']();_0x33d5f0=(_0x24eb66,_0x575b92)=>_0x2392a4(_0x575b92,_0x24eb66);}else _0x33d5f0=this['index_']['getCompare']();const _0x2b5d25=_0x49b33;f(_0x2b5d25['numChildren']()===this['limit_'],'');const _0x12c04f=new E(_0x34735b,_0x111c5d),_0x23f2ae=this['reverse_']?_0x2b5d25['getFirstChild'](this['index_']):_0x2b5d25['getLastChild'](this['index_']),_0x36b985=this['rangedFilter_']['matches'](_0x12c04f);if(_0x2b5d25['hasChild'](_0x34735b)){const _0x2aca6a=_0x2b5d25['getImmediateChild'](_0x34735b);let _0xfeeb06=_0x53b8fa['getChildAfterChild'](this['index_'],_0x23f2ae,this['reverse_']);for(;_0xfeeb06!=null&&(_0xfeeb06['name']===_0x34735b||_0x2b5d25['hasChild'](_0xfeeb06['name']));)_0xfeeb06=_0x53b8fa['getChildAfterChild'](this['index_'],_0xfeeb06,this['reverse_']);const _0x2722d4=_0xfeeb06==null?0x1:_0x33d5f0(_0xfeeb06,_0x12c04f);if(_0x36b985&&!_0x111c5d['isEmpty']()&&_0x2722d4>=0x0)return _0x186aba!=null&&_0x186aba['trackChildChange'](Pt(_0x34735b,_0x111c5d,_0x2aca6a)),_0x2b5d25['updateImmediateChild'](_0x34735b,_0x111c5d);{_0x186aba!=null&&_0x186aba['trackChildChange'](Nt(_0x34735b,_0x2aca6a));const _0x1e19e4=_0x2b5d25['updateImmediateChild'](_0x34735b,g['EMPTY_NODE']);return _0xfeeb06!=null&&this['rangedFilter_']['matches'](_0xfeeb06)?(_0x186aba!=null&&_0x186aba['trackChildChange'](tt(_0xfeeb06['name'],_0xfeeb06['node'])),_0x1e19e4['updateImmediateChild'](_0xfeeb06['name'],_0xfeeb06['node'])):_0x1e19e4;}}else return _0x111c5d['isEmpty']()?_0x49b33:_0x36b985&&_0x33d5f0(_0x23f2ae,_0x12c04f)>=0x0?(_0x186aba!=null&&(_0x186aba['trackChildChange'](Nt(_0x23f2ae['name'],_0x23f2ae['node'])),_0x186aba['trackChildChange'](tt(_0x34735b,_0x111c5d))),_0x2b5d25['updateImmediateChild'](_0x34735b,_0x111c5d)['updateImmediateChild'](_0x23f2ae['name'],g['EMPTY_NODE'])):_0x49b33;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4075e5=new Qi();return _0x4075e5['limitSet_']=this['limitSet_'],_0x4075e5['limit_']=this['limit_'],_0x4075e5['startSet_']=this['startSet_'],_0x4075e5['startAfterSet_']=this['startAfterSet_'],_0x4075e5['indexStartValue_']=this['indexStartValue_'],_0x4075e5['startNameSet_']=this['startNameSet_'],_0x4075e5['indexStartName_']=this['indexStartName_'],_0x4075e5['endSet_']=this['endSet_'],_0x4075e5['endBeforeSet_']=this['endBeforeSet_'],_0x4075e5['indexEndValue_']=this['indexEndValue_'],_0x4075e5['endNameSet_']=this['endNameSet_'],_0x4075e5['indexEndName_']=this['indexEndName_'],_0x4075e5['index_']=this['index_'],_0x4075e5['viewFrom_']=this['viewFrom_'],_0x4075e5;}}function qh(_0x154bdc){return _0x154bdc['loadsAllData']()?new Yi(_0x154bdc['getIndex']()):_0x154bdc['hasLimit']()?new Gh(_0x154bdc):new Ot(_0x154bdc);}function zh(_0x520f11,_0x300299){const _0x898e48=_0x520f11['copy']();return _0x898e48['limitSet_']=!0x0,_0x898e48['limit_']=_0x300299,_0x898e48['viewFrom_']='l',_0x898e48;}function jh(_0x2121a2,_0x42a59e,_0x83b0ce){const _0x990102=_0x2121a2['copy']();return _0x990102['startSet_']=!0x0,_0x42a59e===void 0x0&&(_0x42a59e=null),_0x990102['indexStartValue_']=_0x42a59e,_0x83b0ce!=null?(_0x990102['startNameSet_']=!0x0,_0x990102['indexStartName_']=_0x83b0ce):(_0x990102['startNameSet_']=!0x1,_0x990102['indexStartName_']=''),_0x990102;}function Kh(_0x3107ba,_0x520f71,_0x2bd7fd){const _0x1a5e0a=_0x3107ba['copy']();return _0x1a5e0a['endSet_']=!0x0,_0x520f71===void 0x0&&(_0x520f71=null),_0x1a5e0a['indexEndValue_']=_0x520f71,_0x2bd7fd!==void 0x0?(_0x1a5e0a['endNameSet_']=!0x0,_0x1a5e0a['indexEndName_']=_0x2bd7fd):(_0x1a5e0a['endNameSet_']=!0x1,_0x1a5e0a['indexEndName_']=''),_0x1a5e0a;}function Do(_0x2e5897,_0x5eca6e){const _0x5d3ac8=_0x2e5897['copy']();return _0x5d3ac8['index_']=_0x5eca6e,_0x5d3ac8;}function tr(_0x21019e){const _0x40b681={};if(_0x21019e['isDefault']())return _0x40b681;let _0x2c3253;if(_0x21019e['index_']===R?_0x2c3253='$priority':_0x21019e['index_']===Po?_0x2c3253='$value':_0x21019e['index_']===ye?_0x2c3253='$key':(f(_0x21019e['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x2c3253=_0x21019e['index_']['toString']()),_0x40b681['orderBy']=O(_0x2c3253),_0x21019e['startSet_']){const _0x2af632=_0x21019e['startAfterSet_']?'startAfter':'startAt';_0x40b681[_0x2af632]=O(_0x21019e['indexStartValue_']),_0x21019e['startNameSet_']&&(_0x40b681[_0x2af632]+=','+O(_0x21019e['indexStartName_']));}if(_0x21019e['endSet_']){const _0x21ca34=_0x21019e['endBeforeSet_']?'endBefore':'endAt';_0x40b681[_0x21ca34]=O(_0x21019e['indexEndValue_']),_0x21019e['endNameSet_']&&(_0x40b681[_0x21ca34]+=','+O(_0x21019e['indexEndName_']));}return _0x21019e['limitSet_']&&(_0x21019e['isViewFromLeft']()?_0x40b681['limitToFirst']=_0x21019e['limit_']:_0x40b681['limitToLast']=_0x21019e['limit_']),_0x40b681;}function nr(_0x19f647){const _0x347b53={};if(_0x19f647['startSet_']&&(_0x347b53['sp']=_0x19f647['indexStartValue_'],_0x19f647['startNameSet_']&&(_0x347b53['sn']=_0x19f647['indexStartName_']),_0x347b53['sin']=!_0x19f647['startAfterSet_']),_0x19f647['endSet_']&&(_0x347b53['ep']=_0x19f647['indexEndValue_'],_0x19f647['endNameSet_']&&(_0x347b53['en']=_0x19f647['indexEndName_']),_0x347b53['ein']=!_0x19f647['endBeforeSet_']),_0x19f647['limitSet_']){_0x347b53['l']=_0x19f647['limit_'];let _0xd4d007=_0x19f647['viewFrom_'];_0xd4d007===''&&(_0x19f647['isViewFromLeft']()?_0xd4d007='l':_0xd4d007='r'),_0x347b53['vf']=_0xd4d007;}return _0x19f647['index_']!==R&&(_0x347b53['i']=_0x19f647['index_']['toString']()),_0x347b53;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x588a55){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5272d0,_0x5497f5){return _0x5497f5!==void 0x0?'tag$'+_0x5497f5:(f(_0x5272d0['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5272d0['_path']['toString']());}constructor(_0x407722,_0x498a07,_0x3d15b2,_0x53f23f){super(),this['repoInfo_']=_0x407722,this['onDataUpdate_']=_0x498a07,this['authTokenProvider_']=_0x3d15b2,this['appCheckTokenProvider_']=_0x53f23f,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x48efa0,_0x397bdd,_0x1be1c3,_0x2703c2){const _0x49c94e=_0x48efa0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x49c94e+'\x20'+_0x48efa0['_queryIdentifier']);const _0x48800c=fn['getListenId_'](_0x48efa0,_0x1be1c3),_0x2c5239={};this['listens_'][_0x48800c]=_0x2c5239;const _0x962cad=tr(_0x48efa0['_queryParams']);this['restRequest_'](_0x49c94e+'.json',_0x962cad,(_0x5e899e,_0x19d63a)=>{let _0x133bd3=_0x19d63a;if(_0x5e899e===0x194&&(_0x133bd3=null,_0x5e899e=null),_0x5e899e===null&&this['onDataUpdate_'](_0x49c94e,_0x133bd3,!0x1,_0x1be1c3),Oe(this['listens_'],_0x48800c)===_0x2c5239){let _0x54348b;_0x5e899e?_0x5e899e===0x191?_0x54348b='permission_denied':_0x54348b='rest_error:'+_0x5e899e:_0x54348b='ok',_0x2703c2(_0x54348b,null);}});}['unlisten'](_0x2b2629,_0x3a6061){const _0x477974=fn['getListenId_'](_0x2b2629,_0x3a6061);delete this['listens_'][_0x477974];}['get'](_0x3f284b){const _0xd27612=tr(_0x3f284b['_queryParams']),_0x5f34ec=_0x3f284b['_path']['toString'](),_0x45f4df=new Ve();return this['restRequest_'](_0x5f34ec+'.json',_0xd27612,(_0x1c9583,_0x18a6b7)=>{let _0x11c48a=_0x18a6b7;_0x1c9583===0x194&&(_0x11c48a=null,_0x1c9583=null),_0x1c9583===null?(this['onDataUpdate_'](_0x5f34ec,_0x11c48a,!0x1,null),_0x45f4df['resolve'](_0x11c48a)):_0x45f4df['reject'](new Error(_0x11c48a));}),_0x45f4df['promise'];}['refreshAuthToken'](_0x3307bf){}['restRequest_'](_0x584eee,_0x3ea3d0={},_0x51a8ad){return _0x3ea3d0['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x212ec6,_0x4fa65a])=>{_0x212ec6&&_0x212ec6['accessToken']&&(_0x3ea3d0['auth']=_0x212ec6['accessToken']),_0x4fa65a&&_0x4fa65a['token']&&(_0x3ea3d0['ac']=_0x4fa65a['token']);const _0xa8a8a7=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x584eee+'?ns='+this['repoInfo_']['namespace']+at(_0x3ea3d0);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xa8a8a7);const _0x3259da=new XMLHttpRequest();_0x3259da['onreadystatechange']=()=>{if(_0x51a8ad&&_0x3259da['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xa8a8a7+'\x20received.\x20status:',_0x3259da['status'],'response:',_0x3259da['responseText']);let _0x5ba3a9=null;if(_0x3259da['status']>=0xc8&&_0x3259da['status']<0x12c){try{_0x5ba3a9=bt(_0x3259da['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xa8a8a7+':\x20'+_0x3259da['responseText']);}_0x51a8ad(null,_0x5ba3a9);}else _0x3259da['status']!==0x191&&_0x3259da['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xa8a8a7+'\x20Status:\x20'+_0x3259da['status']),_0x51a8ad(_0x3259da['status']);_0x51a8ad=null;}},_0x3259da['open']('GET',_0xa8a8a7,!0x0),_0x3259da['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xd09f9a){return this['rootNode_']['getChild'](_0xd09f9a);}['updateSnapshot'](_0x1d4688,_0x49c4df){this['rootNode_']=this['rootNode_']['updateChild'](_0x1d4688,_0x49c4df);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x25037e,_0x1d6303,_0xf7b29b){if(v(_0x1d6303))_0x25037e['value']=_0xf7b29b,_0x25037e['children']['clear']();else{if(_0x25037e['value']!==null)_0x25037e['value']=_0x25037e['value']['updateChild'](_0x1d6303,_0xf7b29b);else{const _0x18aadc=y(_0x1d6303);_0x25037e['children']['has'](_0x18aadc)||_0x25037e['children']['set'](_0x18aadc,pn());const _0x18ab19=_0x25037e['children']['get'](_0x18aadc);_0x1d6303=b(_0x1d6303),Mo(_0x18ab19,_0x1d6303,_0xf7b29b);}}}function Ei(_0x478e15,_0xc59cdb,_0x2c0449){_0x478e15['value']!==null?_0x2c0449(_0xc59cdb,_0x478e15['value']):Qh(_0x478e15,(_0x472fc0,_0x1b0ed7)=>{const _0x98e045=new C(_0xc59cdb['toString']()+'/'+_0x472fc0);Ei(_0x1b0ed7,_0x98e045,_0x2c0449);});}function Qh(_0x3f04a5,_0x50b766){_0x3f04a5['children']['forEach']((_0x21ff69,_0x21ae49)=>{_0x50b766(_0x21ae49,_0x21ff69);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x265f05){this['collection_']=_0x265f05,this['last_']=null;}['get'](){const _0x52a082=this['collection_']['get'](),_0x5111f9={..._0x52a082};return this['last_']&&x(this['last_'],(_0x35888a,_0x1b81ce)=>{_0x5111f9[_0x35888a]=_0x5111f9[_0x35888a]-_0x1b81ce;}),this['last_']=_0x52a082,_0x5111f9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x4082e4,_0x414678){this['server_']=_0x414678,this['statsToReport_']={},this['statsListener_']=new Jh(_0x4082e4);const _0x4c3637=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x4c3637));}['reportStats_'](){const _0x181765=this['statsListener_']['get'](),_0x3867d8={};let _0x487d44=!0x1;x(_0x181765,(_0x8aa8b,_0x51ee74)=>{_0x51ee74>0x0&&Y(this['statsToReport_'],_0x8aa8b)&&(_0x3867d8[_0x8aa8b]=_0x51ee74,_0x487d44=!0x0);}),_0x487d44&&this['server_']['reportStats'](_0x3867d8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x153a07){_0x153a07[_0x153a07['OVERWRITE']=0x0]='OVERWRITE',_0x153a07[_0x153a07['MERGE']=0x1]='MERGE',_0x153a07[_0x153a07['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x153a07[_0x153a07['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2dea1a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2dea1a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x16c4d5,_0x6d6072,_0x3dd50b){this['path']=_0x16c4d5,this['affectedTree']=_0x6d6072,this['revert']=_0x3dd50b,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x149ea3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1e5e5f=this['affectedTree']['subtree'](new C(_0x149ea3));return new _n(w(),_0x1e5e5f,this['revert']);}}else return f(y(this['path'])===_0x149ea3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x4ad0fb,_0x229e0b){this['source']=_0x4ad0fb,this['path']=_0x229e0b,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x32a2a7){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x3a5d44,_0x51b411,_0x2eb598){this['source']=_0x3a5d44,this['path']=_0x51b411,this['snap']=_0x2eb598,this['type']=q['OVERWRITE'];}['operationForChild'](_0x527fa5){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x527fa5)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x36e741,_0x26c71e,_0x461efd){this['source']=_0x36e741,this['path']=_0x26c71e,this['children']=_0x461efd,this['type']=q['MERGE'];}['operationForChild'](_0xbdd466){if(v(this['path'])){const _0xec7a7c=this['children']['subtree'](new C(_0xbdd466));return _0xec7a7c['isEmpty']()?null:_0xec7a7c['value']?new Fe(this['source'],w(),_0xec7a7c['value']):new nt(this['source'],w(),_0xec7a7c);}else return f(y(this['path'])===_0xbdd466,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x1d3748,_0xc7cecd,_0x41e61b){this['node_']=_0x1d3748,this['fullyInitialized_']=_0xc7cecd,this['filtered_']=_0x41e61b;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x9f8002){if(v(_0x9f8002))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1d5118=y(_0x9f8002);return this['isCompleteForChild'](_0x1d5118);}['isCompleteForChild'](_0x4ccaeb){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4ccaeb);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x588aab){this['query_']=_0x588aab,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x545952,_0x4b8390,_0x31cc93,_0x507223){const _0x321fd0=[],_0x3ff583=[];return _0x4b8390['forEach'](_0x4d82c6=>{_0x4d82c6['type']==='child_changed'&&_0x545952['index_']['indexedValueChanged'](_0x4d82c6['oldSnap'],_0x4d82c6['snapshotNode'])&&_0x3ff583['push']($h(_0x4d82c6['childName'],_0x4d82c6['snapshotNode']));}),mt(_0x545952,_0x321fd0,'child_removed',_0x4b8390,_0x507223,_0x31cc93),mt(_0x545952,_0x321fd0,'child_added',_0x4b8390,_0x507223,_0x31cc93),mt(_0x545952,_0x321fd0,'child_moved',_0x3ff583,_0x507223,_0x31cc93),mt(_0x545952,_0x321fd0,'child_changed',_0x4b8390,_0x507223,_0x31cc93),mt(_0x545952,_0x321fd0,'value',_0x4b8390,_0x507223,_0x31cc93),_0x321fd0;}function mt(_0x2ac11a,_0x77e9f6,_0x2ee592,_0xb8c032,_0x52a11e,_0x193626){const _0x1fc33e=_0xb8c032['filter'](_0x10f6ed=>_0x10f6ed['type']===_0x2ee592);_0x1fc33e['sort']((_0x1767ff,_0x2a6a03)=>su(_0x2ac11a,_0x1767ff,_0x2a6a03)),_0x1fc33e['forEach'](_0x2283f3=>{const _0x4f6f4a=iu(_0x2ac11a,_0x2283f3,_0x193626);_0x52a11e['forEach'](_0x43d629=>{_0x43d629['respondsTo'](_0x2283f3['type'])&&_0x77e9f6['push'](_0x43d629['createEvent'](_0x4f6f4a,_0x2ac11a['query_']));});});}function iu(_0x335a95,_0x462a70,_0x181eee){return _0x462a70['type']==='value'||_0x462a70['type']==='child_removed'||(_0x462a70['prevName']=_0x181eee['getPredecessorChildName'](_0x462a70['childName'],_0x462a70['snapshotNode'],_0x335a95['index_'])),_0x462a70;}function su(_0x167f3c,_0x178d45,_0x914222){if(_0x178d45['childName']==null||_0x914222['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x4d9aee=new E(_0x178d45['childName'],_0x178d45['snapshotNode']),_0xa97def=new E(_0x914222['childName'],_0x914222['snapshotNode']);return _0x167f3c['index_']['compare'](_0x4d9aee,_0xa97def);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x24ed70,_0x3656cf){return{'eventCache':_0x24ed70,'serverCache':_0x3656cf};}function wt(_0x5e745c,_0x49e451,_0x23b7a6,_0x27b53f){return Dn(new Ce(_0x49e451,_0x23b7a6,_0x27b53f),_0x5e745c['serverCache']);}function Lo(_0x4c17ec,_0x2cacf3,_0x13c788,_0x30ce22){return Dn(_0x4c17ec['eventCache'],new Ce(_0x2cacf3,_0x13c788,_0x30ce22));}function gn(_0x1832ef){return _0x1832ef['eventCache']['isFullyInitialized']()?_0x1832ef['eventCache']['getNode']():null;}function Ue(_0xf7f61){return _0xf7f61['serverCache']['isFullyInitialized']()?_0xf7f61['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x28a3c7){let _0x41ad41=new S(null);return x(_0x28a3c7,(_0x4a401d,_0x261f8a)=>{_0x41ad41=_0x41ad41['set'](new C(_0x4a401d),_0x261f8a);}),_0x41ad41;}constructor(_0x79ccdd,_0x29dc91=ru()){this['value']=_0x79ccdd,this['children']=_0x29dc91;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2b7cbd,_0x2e6b6d){if(this['value']!=null&&_0x2e6b6d(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2b7cbd))return null;{const _0x8bb44=y(_0x2b7cbd),_0x5534ff=this['children']['get'](_0x8bb44);if(_0x5534ff!==null){const _0x25bcb4=_0x5534ff['findRootMostMatchingPathAndValue'](b(_0x2b7cbd),_0x2e6b6d);return _0x25bcb4!=null?{'path':A(new C(_0x8bb44),_0x25bcb4['path']),'value':_0x25bcb4['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x43b22a){return this['findRootMostMatchingPathAndValue'](_0x43b22a,()=>!0x0);}['subtree'](_0x4a5975){if(v(_0x4a5975))return this;{const _0xe55a87=y(_0x4a5975),_0x18476f=this['children']['get'](_0xe55a87);return _0x18476f!==null?_0x18476f['subtree'](b(_0x4a5975)):new S(null);}}['set'](_0x3e5264,_0x1e08eb){if(v(_0x3e5264))return new S(_0x1e08eb,this['children']);{const _0xc9035a=y(_0x3e5264),_0x20af81=(this['children']['get'](_0xc9035a)||new S(null))['set'](b(_0x3e5264),_0x1e08eb),_0x104b6e=this['children']['insert'](_0xc9035a,_0x20af81);return new S(this['value'],_0x104b6e);}}['remove'](_0x446cb6){if(v(_0x446cb6))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x14dfb8=y(_0x446cb6),_0x3709a9=this['children']['get'](_0x14dfb8);if(_0x3709a9){const _0x55e3ed=_0x3709a9['remove'](b(_0x446cb6));let _0x424f80;return _0x55e3ed['isEmpty']()?_0x424f80=this['children']['remove'](_0x14dfb8):_0x424f80=this['children']['insert'](_0x14dfb8,_0x55e3ed),this['value']===null&&_0x424f80['isEmpty']()?new S(null):new S(this['value'],_0x424f80);}else return this;}}['get'](_0x3ebc30){if(v(_0x3ebc30))return this['value'];{const _0x50ae5a=y(_0x3ebc30),_0x5851d8=this['children']['get'](_0x50ae5a);return _0x5851d8?_0x5851d8['get'](b(_0x3ebc30)):null;}}['setTree'](_0x3dd22e,_0x1ff069){if(v(_0x3dd22e))return _0x1ff069;{const _0x517aed=y(_0x3dd22e),_0x15cb0b=(this['children']['get'](_0x517aed)||new S(null))['setTree'](b(_0x3dd22e),_0x1ff069);let _0x548ae3;return _0x15cb0b['isEmpty']()?_0x548ae3=this['children']['remove'](_0x517aed):_0x548ae3=this['children']['insert'](_0x517aed,_0x15cb0b),new S(this['value'],_0x548ae3);}}['fold'](_0x149b13){return this['fold_'](w(),_0x149b13);}['fold_'](_0x40420c,_0x4aa981){const _0x96eb06={};return this['children']['inorderTraversal']((_0x3154bd,_0x246b05)=>{_0x96eb06[_0x3154bd]=_0x246b05['fold_'](A(_0x40420c,_0x3154bd),_0x4aa981);}),_0x4aa981(_0x40420c,this['value'],_0x96eb06);}['findOnPath'](_0x15dfcc,_0x45f286){return this['findOnPath_'](_0x15dfcc,w(),_0x45f286);}['findOnPath_'](_0x365a20,_0x3e6552,_0x5d334a){const _0x3eb999=this['value']?_0x5d334a(_0x3e6552,this['value']):!0x1;if(_0x3eb999)return _0x3eb999;if(v(_0x365a20))return null;{const _0x26c112=y(_0x365a20),_0x315d8d=this['children']['get'](_0x26c112);return _0x315d8d?_0x315d8d['findOnPath_'](b(_0x365a20),A(_0x3e6552,_0x26c112),_0x5d334a):null;}}['foreachOnPath'](_0x30708f,_0x28684c){return this['foreachOnPath_'](_0x30708f,w(),_0x28684c);}['foreachOnPath_'](_0x40f8e5,_0x5295f2,_0x1e131f){if(v(_0x40f8e5))return this;{this['value']&&_0x1e131f(_0x5295f2,this['value']);const _0x1c0a7d=y(_0x40f8e5),_0x12b9f8=this['children']['get'](_0x1c0a7d);return _0x12b9f8?_0x12b9f8['foreachOnPath_'](b(_0x40f8e5),A(_0x5295f2,_0x1c0a7d),_0x1e131f):new S(null);}}['foreach'](_0x2ab80f){this['foreach_'](w(),_0x2ab80f);}['foreach_'](_0x3e194c,_0x2828b3){this['children']['inorderTraversal']((_0x36f2ba,_0x4f8a8d)=>{_0x4f8a8d['foreach_'](A(_0x3e194c,_0x36f2ba),_0x2828b3);}),this['value']&&_0x2828b3(_0x3e194c,this['value']);}['foreachChild'](_0x3579fb){this['children']['inorderTraversal']((_0x4977da,_0x52d4e8)=>{_0x52d4e8['value']&&_0x3579fb(_0x4977da,_0x52d4e8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x1a8f57){this['writeTree_']=_0x1a8f57;}static['empty'](){return new j(new S(null));}}function Ct(_0x125efe,_0x190032,_0x24de12){if(v(_0x190032))return new j(new S(_0x24de12));{const _0x33bd15=_0x125efe['writeTree_']['findRootMostValueAndPath'](_0x190032);if(_0x33bd15!=null){const _0x371034=_0x33bd15['path'];let _0x4a031f=_0x33bd15['value'];const _0x337cef=F(_0x371034,_0x190032);return _0x4a031f=_0x4a031f['updateChild'](_0x337cef,_0x24de12),new j(_0x125efe['writeTree_']['set'](_0x371034,_0x4a031f));}else{const _0x1e891f=new S(_0x24de12),_0x11c984=_0x125efe['writeTree_']['setTree'](_0x190032,_0x1e891f);return new j(_0x11c984);}}}function Ii(_0x321555,_0x34ff60,_0x441e16){let _0x531f3b=_0x321555;return x(_0x441e16,(_0x1b238d,_0xc76f8c)=>{_0x531f3b=Ct(_0x531f3b,A(_0x34ff60,_0x1b238d),_0xc76f8c);}),_0x531f3b;}function sr(_0x27fa8a,_0x38bcc5){if(v(_0x38bcc5))return j['empty']();{const _0x59aa52=_0x27fa8a['writeTree_']['setTree'](_0x38bcc5,new S(null));return new j(_0x59aa52);}}function wi(_0x2cf770,_0x3ae85f){return $e(_0x2cf770,_0x3ae85f)!=null;}function $e(_0x40991e,_0x4b1c1a){const _0x4db4f4=_0x40991e['writeTree_']['findRootMostValueAndPath'](_0x4b1c1a);return _0x4db4f4!=null?_0x40991e['writeTree_']['get'](_0x4db4f4['path'])['getChild'](F(_0x4db4f4['path'],_0x4b1c1a)):null;}function rr(_0x8d594d){const _0x53a5b5=[],_0x41de77=_0x8d594d['writeTree_']['value'];return _0x41de77!=null?_0x41de77['isLeafNode']()||_0x41de77['forEachChild'](R,(_0x3ab104,_0x149290)=>{_0x53a5b5['push'](new E(_0x3ab104,_0x149290));}):_0x8d594d['writeTree_']['children']['inorderTraversal']((_0x4994c0,_0x24ceba)=>{_0x24ceba['value']!=null&&_0x53a5b5['push'](new E(_0x4994c0,_0x24ceba['value']));}),_0x53a5b5;}function ve(_0x1ecc81,_0x4fa4ec){if(v(_0x4fa4ec))return _0x1ecc81;{const _0x5bd2f1=$e(_0x1ecc81,_0x4fa4ec);return _0x5bd2f1!=null?new j(new S(_0x5bd2f1)):new j(_0x1ecc81['writeTree_']['subtree'](_0x4fa4ec));}}function Ci(_0x42ae75){return _0x42ae75['writeTree_']['isEmpty']();}function it(_0x1bc946,_0x5c5025){return xo(w(),_0x1bc946['writeTree_'],_0x5c5025);}function xo(_0x333b1f,_0x7c440d,_0x1cdabb){if(_0x7c440d['value']!=null)return _0x1cdabb['updateChild'](_0x333b1f,_0x7c440d['value']);{let _0x19b656=null;return _0x7c440d['children']['inorderTraversal']((_0x14304e,_0x59c7ec)=>{_0x14304e==='.priority'?(f(_0x59c7ec['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x19b656=_0x59c7ec['value']):_0x1cdabb=xo(A(_0x333b1f,_0x14304e),_0x59c7ec,_0x1cdabb);}),!_0x1cdabb['getChild'](_0x333b1f)['isEmpty']()&&_0x19b656!==null&&(_0x1cdabb=_0x1cdabb['updateChild'](A(_0x333b1f,'.priority'),_0x19b656)),_0x1cdabb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x48cbcc,_0x4c9774){return Bo(_0x4c9774,_0x48cbcc);}function ou(_0x25544b,_0x2373df,_0x329132,_0x4e9592,_0x6d3be3){f(_0x4e9592>_0x25544b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x6d3be3===void 0x0&&(_0x6d3be3=!0x0),_0x25544b['allWrites']['push']({'path':_0x2373df,'snap':_0x329132,'writeId':_0x4e9592,'visible':_0x6d3be3}),_0x6d3be3&&(_0x25544b['visibleWrites']=Ct(_0x25544b['visibleWrites'],_0x2373df,_0x329132)),_0x25544b['lastWriteId']=_0x4e9592;}function au(_0x4a383c,_0x4bca2d,_0x33d8eb,_0x5a5b20){f(_0x5a5b20>_0x4a383c['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4a383c['allWrites']['push']({'path':_0x4bca2d,'children':_0x33d8eb,'writeId':_0x5a5b20,'visible':!0x0}),_0x4a383c['visibleWrites']=Ii(_0x4a383c['visibleWrites'],_0x4bca2d,_0x33d8eb),_0x4a383c['lastWriteId']=_0x5a5b20;}function cu(_0x5b7fd4,_0x60a066){for(let _0x23a750=0x0;_0x23a750<_0x5b7fd4['allWrites']['length'];_0x23a750++){const _0x28aa37=_0x5b7fd4['allWrites'][_0x23a750];if(_0x28aa37['writeId']===_0x60a066)return _0x28aa37;}return null;}function lu(_0x3fb935,_0x2f3405){const _0x6605cb=_0x3fb935['allWrites']['findIndex'](_0x175824=>_0x175824['writeId']===_0x2f3405);f(_0x6605cb>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x57a549=_0x3fb935['allWrites'][_0x6605cb];_0x3fb935['allWrites']['splice'](_0x6605cb,0x1);let _0x557c90=_0x57a549['visible'],_0x27a26d=!0x1,_0x3812fb=_0x3fb935['allWrites']['length']-0x1;for(;_0x557c90&&_0x3812fb>=0x0;){const _0x23bbaa=_0x3fb935['allWrites'][_0x3812fb];_0x23bbaa['visible']&&(_0x3812fb>=_0x6605cb&&hu(_0x23bbaa,_0x57a549['path'])?_0x557c90=!0x1:$(_0x57a549['path'],_0x23bbaa['path'])&&(_0x27a26d=!0x0)),_0x3812fb--;}if(_0x557c90){if(_0x27a26d)return uu(_0x3fb935),!0x0;if(_0x57a549['snap'])_0x3fb935['visibleWrites']=sr(_0x3fb935['visibleWrites'],_0x57a549['path']);else{const _0x256f90=_0x57a549['children'];x(_0x256f90,_0x527c0c=>{_0x3fb935['visibleWrites']=sr(_0x3fb935['visibleWrites'],A(_0x57a549['path'],_0x527c0c));});}return!0x0;}else return!0x1;}function hu(_0x51d8a6,_0x777a70){if(_0x51d8a6['snap'])return $(_0x51d8a6['path'],_0x777a70);for(const _0x7c3344 in _0x51d8a6['children'])if(_0x51d8a6['children']['hasOwnProperty'](_0x7c3344)&&$(A(_0x51d8a6['path'],_0x7c3344),_0x777a70))return!0x0;return!0x1;}function uu(_0x589417){_0x589417['visibleWrites']=Fo(_0x589417['allWrites'],du,w()),_0x589417['allWrites']['length']>0x0?_0x589417['lastWriteId']=_0x589417['allWrites'][_0x589417['allWrites']['length']-0x1]['writeId']:_0x589417['lastWriteId']=-0x1;}function du(_0x5c8346){return _0x5c8346['visible'];}function Fo(_0x48091e,_0x1e4bda,_0x4a1b91){let _0x1b5c86=j['empty']();for(let _0x52788f=0x0;_0x52788f<_0x48091e['length'];++_0x52788f){const _0x59b4a0=_0x48091e[_0x52788f];if(_0x1e4bda(_0x59b4a0)){const _0x23311f=_0x59b4a0['path'];let _0xe31428;if(_0x59b4a0['snap'])$(_0x4a1b91,_0x23311f)?(_0xe31428=F(_0x4a1b91,_0x23311f),_0x1b5c86=Ct(_0x1b5c86,_0xe31428,_0x59b4a0['snap'])):$(_0x23311f,_0x4a1b91)&&(_0xe31428=F(_0x23311f,_0x4a1b91),_0x1b5c86=Ct(_0x1b5c86,w(),_0x59b4a0['snap']['getChild'](_0xe31428)));else{if(_0x59b4a0['children']){if($(_0x4a1b91,_0x23311f))_0xe31428=F(_0x4a1b91,_0x23311f),_0x1b5c86=Ii(_0x1b5c86,_0xe31428,_0x59b4a0['children']);else{if($(_0x23311f,_0x4a1b91)){if(_0xe31428=F(_0x23311f,_0x4a1b91),v(_0xe31428))_0x1b5c86=Ii(_0x1b5c86,w(),_0x59b4a0['children']);else{const _0x46436d=Oe(_0x59b4a0['children'],y(_0xe31428));if(_0x46436d){const _0x5463e3=_0x46436d['getChild'](b(_0xe31428));_0x1b5c86=Ct(_0x1b5c86,w(),_0x5463e3);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1b5c86;}function Uo(_0x44158a,_0x122a32,_0x4a5424,_0x1d8575,_0x37df30){if(!_0x1d8575&&!_0x37df30){const _0x53ad5e=$e(_0x44158a['visibleWrites'],_0x122a32);if(_0x53ad5e!=null)return _0x53ad5e;{const _0x5e5b51=ve(_0x44158a['visibleWrites'],_0x122a32);if(Ci(_0x5e5b51))return _0x4a5424;if(_0x4a5424==null&&!wi(_0x5e5b51,w()))return null;{const _0x791c64=_0x4a5424||g['EMPTY_NODE'];return it(_0x5e5b51,_0x791c64);}}}else{const _0x53d1b8=ve(_0x44158a['visibleWrites'],_0x122a32);if(!_0x37df30&&Ci(_0x53d1b8))return _0x4a5424;if(!_0x37df30&&_0x4a5424==null&&!wi(_0x53d1b8,w()))return null;{const _0x1c5ed7=function(_0x5a2b22){return(_0x5a2b22['visible']||_0x37df30)&&(!_0x1d8575||!~_0x1d8575['indexOf'](_0x5a2b22['writeId']))&&($(_0x5a2b22['path'],_0x122a32)||$(_0x122a32,_0x5a2b22['path']));},_0x27b1e4=Fo(_0x44158a['allWrites'],_0x1c5ed7,_0x122a32),_0x2a8fd2=_0x4a5424||g['EMPTY_NODE'];return it(_0x27b1e4,_0x2a8fd2);}}}function fu(_0xc5a01a,_0x3cbe6f,_0x175400){let _0x522bc5=g['EMPTY_NODE'];const _0x4e82a2=$e(_0xc5a01a['visibleWrites'],_0x3cbe6f);if(_0x4e82a2)return _0x4e82a2['isLeafNode']()||_0x4e82a2['forEachChild'](R,(_0x56283c,_0x1d5801)=>{_0x522bc5=_0x522bc5['updateImmediateChild'](_0x56283c,_0x1d5801);}),_0x522bc5;if(_0x175400){const _0x1827ad=ve(_0xc5a01a['visibleWrites'],_0x3cbe6f);return _0x175400['forEachChild'](R,(_0x14dbea,_0x52f0cc)=>{const _0x52e7ea=it(ve(_0x1827ad,new C(_0x14dbea)),_0x52f0cc);_0x522bc5=_0x522bc5['updateImmediateChild'](_0x14dbea,_0x52e7ea);}),rr(_0x1827ad)['forEach'](_0x22b1b7=>{_0x522bc5=_0x522bc5['updateImmediateChild'](_0x22b1b7['name'],_0x22b1b7['node']);}),_0x522bc5;}else{const _0xe44aa3=ve(_0xc5a01a['visibleWrites'],_0x3cbe6f);return rr(_0xe44aa3)['forEach'](_0x3b6f3b=>{_0x522bc5=_0x522bc5['updateImmediateChild'](_0x3b6f3b['name'],_0x3b6f3b['node']);}),_0x522bc5;}}function pu(_0x5b5a33,_0xe9df88,_0x125240,_0x411e35,_0x490228){f(_0x411e35||_0x490228,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xd5527f=A(_0xe9df88,_0x125240);if(wi(_0x5b5a33['visibleWrites'],_0xd5527f))return null;{const _0x58780a=ve(_0x5b5a33['visibleWrites'],_0xd5527f);return Ci(_0x58780a)?_0x490228['getChild'](_0x125240):it(_0x58780a,_0x490228['getChild'](_0x125240));}}function _u(_0x7e3dfc,_0x337fe2,_0x217427,_0x51e897){const _0x112dc6=A(_0x337fe2,_0x217427),_0x4ff462=$e(_0x7e3dfc['visibleWrites'],_0x112dc6);if(_0x4ff462!=null)return _0x4ff462;if(_0x51e897['isCompleteForChild'](_0x217427)){const _0x20176e=ve(_0x7e3dfc['visibleWrites'],_0x112dc6);return it(_0x20176e,_0x51e897['getNode']()['getImmediateChild'](_0x217427));}else return null;}function gu(_0x1e5194,_0x401b03){return $e(_0x1e5194['visibleWrites'],_0x401b03);}function mu(_0xd80ce4,_0x327e0a,_0x183a4b,_0x2346b8,_0x57e4b2,_0x405b15,_0x545de6){let _0x16e8b0;const _0x36f75c=ve(_0xd80ce4['visibleWrites'],_0x327e0a),_0xf5f57e=$e(_0x36f75c,w());if(_0xf5f57e!=null)_0x16e8b0=_0xf5f57e;else{if(_0x183a4b!=null)_0x16e8b0=it(_0x36f75c,_0x183a4b);else return[];}if(_0x16e8b0=_0x16e8b0['withIndex'](_0x545de6),!_0x16e8b0['isEmpty']()&&!_0x16e8b0['isLeafNode']()){const _0x52182c=[],_0x24628a=_0x545de6['getCompare'](),_0xdd0fd5=_0x405b15?_0x16e8b0['getReverseIteratorFrom'](_0x2346b8,_0x545de6):_0x16e8b0['getIteratorFrom'](_0x2346b8,_0x545de6);let _0x5bd47a=_0xdd0fd5['getNext']();for(;_0x5bd47a&&_0x52182c['length']<_0x57e4b2;)_0x24628a(_0x5bd47a,_0x2346b8)!==0x0&&_0x52182c['push'](_0x5bd47a),_0x5bd47a=_0xdd0fd5['getNext']();return _0x52182c;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x194485,_0x237ab5,_0x588e1f,_0x1a5a56){return Uo(_0x194485['writeTree'],_0x194485['treePath'],_0x237ab5,_0x588e1f,_0x1a5a56);}function es(_0x52ea80,_0x49104f){return fu(_0x52ea80['writeTree'],_0x52ea80['treePath'],_0x49104f);}function or(_0x2be432,_0x448336,_0x466779,_0x2d7b2f){return pu(_0x2be432['writeTree'],_0x2be432['treePath'],_0x448336,_0x466779,_0x2d7b2f);}function yn(_0x32e12b,_0x5ebd88){return gu(_0x32e12b['writeTree'],A(_0x32e12b['treePath'],_0x5ebd88));}function vu(_0x524710,_0x5cca0f,_0x1625b9,_0x480aa4,_0x424271,_0x3b61ad){return mu(_0x524710['writeTree'],_0x524710['treePath'],_0x5cca0f,_0x1625b9,_0x480aa4,_0x424271,_0x3b61ad);}function ts(_0x3c25f0,_0x453241,_0xf959e1){return _u(_0x3c25f0['writeTree'],_0x3c25f0['treePath'],_0x453241,_0xf959e1);}function Wo(_0x15dec0,_0x7597f0){return Bo(A(_0x15dec0['treePath'],_0x7597f0),_0x15dec0['writeTree']);}function Bo(_0x317be2,_0x5f030a){return{'treePath':_0x317be2,'writeTree':_0x5f030a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4e8743){const _0x29f0ad=_0x4e8743['type'],_0xd600cf=_0x4e8743['childName'];f(_0x29f0ad==='child_added'||_0x29f0ad==='child_changed'||_0x29f0ad==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xd600cf!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3967ab=this['changeMap']['get'](_0xd600cf);if(_0x3967ab){const _0x57d792=_0x3967ab['type'];if(_0x29f0ad==='child_added'&&_0x57d792==='child_removed')this['changeMap']['set'](_0xd600cf,Pt(_0xd600cf,_0x4e8743['snapshotNode'],_0x3967ab['snapshotNode']));else{if(_0x29f0ad==='child_removed'&&_0x57d792==='child_added')this['changeMap']['delete'](_0xd600cf);else{if(_0x29f0ad==='child_removed'&&_0x57d792==='child_changed')this['changeMap']['set'](_0xd600cf,Nt(_0xd600cf,_0x3967ab['oldSnap']));else{if(_0x29f0ad==='child_changed'&&_0x57d792==='child_added')this['changeMap']['set'](_0xd600cf,tt(_0xd600cf,_0x4e8743['snapshotNode']));else{if(_0x29f0ad==='child_changed'&&_0x57d792==='child_changed')this['changeMap']['set'](_0xd600cf,Pt(_0xd600cf,_0x4e8743['snapshotNode'],_0x3967ab['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x4e8743+'\x20occurred\x20after\x20'+_0x3967ab);}}}}}else this['changeMap']['set'](_0xd600cf,_0x4e8743);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x15ddc6){return null;}['getChildAfterChild'](_0x8bdfcc,_0x53202c,_0x2943e5){return null;}}const Vo=new Iu();class ns{constructor(_0x112882,_0x139342,_0x3500e0=null){this['writes_']=_0x112882,this['viewCache_']=_0x139342,this['optCompleteServerCache_']=_0x3500e0;}['getCompleteChild'](_0x39b0b6){const _0x117b34=this['viewCache_']['eventCache'];if(_0x117b34['isCompleteForChild'](_0x39b0b6))return _0x117b34['getNode']()['getImmediateChild'](_0x39b0b6);{const _0x1387de=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x39b0b6,_0x1387de);}}['getChildAfterChild'](_0x111125,_0x34ae05,_0x333344){const _0x50cb82=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x4f7d83=vu(this['writes_'],_0x50cb82,_0x34ae05,0x1,_0x333344,_0x111125);return _0x4f7d83['length']===0x0?null:_0x4f7d83[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0xd58257){return{'filter':_0xd58257};}function Cu(_0x546a78,_0x4a6b9e){f(_0x4a6b9e['eventCache']['getNode']()['isIndexed'](_0x546a78['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4a6b9e['serverCache']['getNode']()['isIndexed'](_0x546a78['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x338713,_0x1eb468,_0x2897b4,_0x53a8ea,_0x2e402d){const _0x564f05=new Eu();let _0x2a0cda,_0x402709;if(_0x2897b4['type']===q['OVERWRITE']){const _0x222be0=_0x2897b4;_0x222be0['source']['fromUser']?_0x2a0cda=Ti(_0x338713,_0x1eb468,_0x222be0['path'],_0x222be0['snap'],_0x53a8ea,_0x2e402d,_0x564f05):(f(_0x222be0['source']['fromServer'],'Unknown\x20source.'),_0x402709=_0x222be0['source']['tagged']||_0x1eb468['serverCache']['isFiltered']()&&!v(_0x222be0['path']),_0x2a0cda=vn(_0x338713,_0x1eb468,_0x222be0['path'],_0x222be0['snap'],_0x53a8ea,_0x2e402d,_0x402709,_0x564f05));}else{if(_0x2897b4['type']===q['MERGE']){const _0xc4b618=_0x2897b4;_0xc4b618['source']['fromUser']?_0x2a0cda=bu(_0x338713,_0x1eb468,_0xc4b618['path'],_0xc4b618['children'],_0x53a8ea,_0x2e402d,_0x564f05):(f(_0xc4b618['source']['fromServer'],'Unknown\x20source.'),_0x402709=_0xc4b618['source']['tagged']||_0x1eb468['serverCache']['isFiltered'](),_0x2a0cda=Si(_0x338713,_0x1eb468,_0xc4b618['path'],_0xc4b618['children'],_0x53a8ea,_0x2e402d,_0x402709,_0x564f05));}else{if(_0x2897b4['type']===q['ACK_USER_WRITE']){const _0x1d2f50=_0x2897b4;_0x1d2f50['revert']?_0x2a0cda=ku(_0x338713,_0x1eb468,_0x1d2f50['path'],_0x53a8ea,_0x2e402d,_0x564f05):_0x2a0cda=Ru(_0x338713,_0x1eb468,_0x1d2f50['path'],_0x1d2f50['affectedTree'],_0x53a8ea,_0x2e402d,_0x564f05);}else{if(_0x2897b4['type']===q['LISTEN_COMPLETE'])_0x2a0cda=Au(_0x338713,_0x1eb468,_0x2897b4['path'],_0x53a8ea,_0x564f05);else throw ot('Unknown\x20operation\x20type:\x20'+_0x2897b4['type']);}}}const _0x3482ca=_0x564f05['getChanges']();return Su(_0x1eb468,_0x2a0cda,_0x3482ca),{'viewCache':_0x2a0cda,'changes':_0x3482ca};}function Su(_0x4eba6e,_0x591b60,_0x422682){const _0x415ff5=_0x591b60['eventCache'];if(_0x415ff5['isFullyInitialized']()){const _0x5742fc=_0x415ff5['getNode']()['isLeafNode']()||_0x415ff5['getNode']()['isEmpty'](),_0x6330f3=gn(_0x4eba6e);(_0x422682['length']>0x0||!_0x4eba6e['eventCache']['isFullyInitialized']()||_0x5742fc&&!_0x415ff5['getNode']()['equals'](_0x6330f3)||!_0x415ff5['getNode']()['getPriority']()['equals'](_0x6330f3['getPriority']()))&&_0x422682['push'](Oo(gn(_0x591b60)));}}function Ho(_0x4ea062,_0x47aa5d,_0x372f4a,_0x10c9a7,_0x1d5dc4,_0x2d4154){const _0x3f44ac=_0x47aa5d['eventCache'];if(yn(_0x10c9a7,_0x372f4a)!=null)return _0x47aa5d;{let _0x41254b,_0x966a45;if(v(_0x372f4a)){if(f(_0x47aa5d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x47aa5d['serverCache']['isFiltered']()){const _0x19d822=Ue(_0x47aa5d),_0x4820cc=_0x19d822 instanceof g?_0x19d822:g['EMPTY_NODE'],_0x5e855f=es(_0x10c9a7,_0x4820cc);_0x41254b=_0x4ea062['filter']['updateFullNode'](_0x47aa5d['eventCache']['getNode'](),_0x5e855f,_0x2d4154);}else{const _0x5b9e7b=mn(_0x10c9a7,Ue(_0x47aa5d));_0x41254b=_0x4ea062['filter']['updateFullNode'](_0x47aa5d['eventCache']['getNode'](),_0x5b9e7b,_0x2d4154);}}else{const _0x586025=y(_0x372f4a);if(_0x586025==='.priority'){f(we(_0x372f4a)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x228204=_0x3f44ac['getNode']();_0x966a45=_0x47aa5d['serverCache']['getNode']();const _0x23cd86=or(_0x10c9a7,_0x372f4a,_0x228204,_0x966a45);_0x23cd86!=null?_0x41254b=_0x4ea062['filter']['updatePriority'](_0x228204,_0x23cd86):_0x41254b=_0x3f44ac['getNode']();}else{const _0x32d9f8=b(_0x372f4a);let _0x39bc9a;if(_0x3f44ac['isCompleteForChild'](_0x586025)){_0x966a45=_0x47aa5d['serverCache']['getNode']();const _0x5bb60e=or(_0x10c9a7,_0x372f4a,_0x3f44ac['getNode'](),_0x966a45);_0x5bb60e!=null?_0x39bc9a=_0x3f44ac['getNode']()['getImmediateChild'](_0x586025)['updateChild'](_0x32d9f8,_0x5bb60e):_0x39bc9a=_0x3f44ac['getNode']()['getImmediateChild'](_0x586025);}else _0x39bc9a=ts(_0x10c9a7,_0x586025,_0x47aa5d['serverCache']);_0x39bc9a!=null?_0x41254b=_0x4ea062['filter']['updateChild'](_0x3f44ac['getNode'](),_0x586025,_0x39bc9a,_0x32d9f8,_0x1d5dc4,_0x2d4154):_0x41254b=_0x3f44ac['getNode']();}}return wt(_0x47aa5d,_0x41254b,_0x3f44ac['isFullyInitialized']()||v(_0x372f4a),_0x4ea062['filter']['filtersNodes']());}}function vn(_0x121215,_0x4085cd,_0x18e926,_0x234303,_0x18e4ff,_0x3fbf1b,_0x21fdb8,_0x4ae62d){const _0x3d3079=_0x4085cd['serverCache'];let _0x1f9099;const _0x4eb958=_0x21fdb8?_0x121215['filter']:_0x121215['filter']['getIndexedFilter']();if(v(_0x18e926))_0x1f9099=_0x4eb958['updateFullNode'](_0x3d3079['getNode'](),_0x234303,null);else{if(_0x4eb958['filtersNodes']()&&!_0x3d3079['isFiltered']()){const _0x4f4cf8=_0x3d3079['getNode']()['updateChild'](_0x18e926,_0x234303);_0x1f9099=_0x4eb958['updateFullNode'](_0x3d3079['getNode'](),_0x4f4cf8,null);}else{const _0x5e36db=y(_0x18e926);if(!_0x3d3079['isCompleteForPath'](_0x18e926)&&we(_0x18e926)>0x1)return _0x4085cd;const _0x173c23=b(_0x18e926),_0x127a1a=_0x3d3079['getNode']()['getImmediateChild'](_0x5e36db)['updateChild'](_0x173c23,_0x234303);_0x5e36db==='.priority'?_0x1f9099=_0x4eb958['updatePriority'](_0x3d3079['getNode'](),_0x127a1a):_0x1f9099=_0x4eb958['updateChild'](_0x3d3079['getNode'](),_0x5e36db,_0x127a1a,_0x173c23,Vo,null);}}const _0x395f44=Lo(_0x4085cd,_0x1f9099,_0x3d3079['isFullyInitialized']()||v(_0x18e926),_0x4eb958['filtersNodes']()),_0x326f91=new ns(_0x18e4ff,_0x395f44,_0x3fbf1b);return Ho(_0x121215,_0x395f44,_0x18e926,_0x18e4ff,_0x326f91,_0x4ae62d);}function Ti(_0x326d3a,_0x5986f0,_0x19adba,_0x59a30b,_0x280cdd,_0x2bf37a,_0x1aae53){const _0x185428=_0x5986f0['eventCache'];let _0x21b34d,_0x1bd8e7;const _0x4d9815=new ns(_0x280cdd,_0x5986f0,_0x2bf37a);if(v(_0x19adba))_0x1bd8e7=_0x326d3a['filter']['updateFullNode'](_0x5986f0['eventCache']['getNode'](),_0x59a30b,_0x1aae53),_0x21b34d=wt(_0x5986f0,_0x1bd8e7,!0x0,_0x326d3a['filter']['filtersNodes']());else{const _0x23ca95=y(_0x19adba);if(_0x23ca95==='.priority')_0x1bd8e7=_0x326d3a['filter']['updatePriority'](_0x5986f0['eventCache']['getNode'](),_0x59a30b),_0x21b34d=wt(_0x5986f0,_0x1bd8e7,_0x185428['isFullyInitialized'](),_0x185428['isFiltered']());else{const _0x567431=b(_0x19adba),_0x4d3ab2=_0x185428['getNode']()['getImmediateChild'](_0x23ca95);let _0x1e6c50;if(v(_0x567431))_0x1e6c50=_0x59a30b;else{const _0x5d3a9b=_0x4d9815['getCompleteChild'](_0x23ca95);_0x5d3a9b!=null?Gi(_0x567431)==='.priority'&&_0x5d3a9b['getChild'](To(_0x567431))['isEmpty']()?_0x1e6c50=_0x5d3a9b:_0x1e6c50=_0x5d3a9b['updateChild'](_0x567431,_0x59a30b):_0x1e6c50=g['EMPTY_NODE'];}if(_0x4d3ab2['equals'](_0x1e6c50))_0x21b34d=_0x5986f0;else{const _0x3411c8=_0x326d3a['filter']['updateChild'](_0x185428['getNode'](),_0x23ca95,_0x1e6c50,_0x567431,_0x4d9815,_0x1aae53);_0x21b34d=wt(_0x5986f0,_0x3411c8,_0x185428['isFullyInitialized'](),_0x326d3a['filter']['filtersNodes']());}}}return _0x21b34d;}function ar(_0x346e29,_0x42fac7){return _0x346e29['eventCache']['isCompleteForChild'](_0x42fac7);}function bu(_0x2a1f2e,_0x5686a2,_0x461b58,_0x4df65d,_0x45fdcc,_0x306158,_0x297de8){let _0x3e8dbd=_0x5686a2;return _0x4df65d['foreach']((_0x103a07,_0x52249f)=>{const _0x1a7754=A(_0x461b58,_0x103a07);ar(_0x5686a2,y(_0x1a7754))&&(_0x3e8dbd=Ti(_0x2a1f2e,_0x3e8dbd,_0x1a7754,_0x52249f,_0x45fdcc,_0x306158,_0x297de8));}),_0x4df65d['foreach']((_0x5ad6ee,_0x1fcc39)=>{const _0x1a5081=A(_0x461b58,_0x5ad6ee);ar(_0x5686a2,y(_0x1a5081))||(_0x3e8dbd=Ti(_0x2a1f2e,_0x3e8dbd,_0x1a5081,_0x1fcc39,_0x45fdcc,_0x306158,_0x297de8));}),_0x3e8dbd;}function cr(_0x1b1f9d,_0x14780e,_0x705ef1){return _0x705ef1['foreach']((_0x108066,_0x6885b)=>{_0x14780e=_0x14780e['updateChild'](_0x108066,_0x6885b);}),_0x14780e;}function Si(_0x3f7ff4,_0x481010,_0x4350fd,_0x2a11c6,_0x9ef61d,_0x414e58,_0xb81fa5,_0x61cdda){if(_0x481010['serverCache']['getNode']()['isEmpty']()&&!_0x481010['serverCache']['isFullyInitialized']())return _0x481010;let _0x71ba35=_0x481010,_0x35f0c1;v(_0x4350fd)?_0x35f0c1=_0x2a11c6:_0x35f0c1=new S(null)['setTree'](_0x4350fd,_0x2a11c6);const _0x51c24b=_0x481010['serverCache']['getNode']();return _0x35f0c1['children']['inorderTraversal']((_0x38f0ea,_0x2a193a)=>{if(_0x51c24b['hasChild'](_0x38f0ea)){const _0x432f68=_0x481010['serverCache']['getNode']()['getImmediateChild'](_0x38f0ea),_0x15ef5d=cr(_0x3f7ff4,_0x432f68,_0x2a193a);_0x71ba35=vn(_0x3f7ff4,_0x71ba35,new C(_0x38f0ea),_0x15ef5d,_0x9ef61d,_0x414e58,_0xb81fa5,_0x61cdda);}}),_0x35f0c1['children']['inorderTraversal']((_0x1ed85b,_0x2824bd)=>{const _0x48e5d2=!_0x481010['serverCache']['isCompleteForChild'](_0x1ed85b)&&_0x2824bd['value']===null;if(!_0x51c24b['hasChild'](_0x1ed85b)&&!_0x48e5d2){const _0x381db3=_0x481010['serverCache']['getNode']()['getImmediateChild'](_0x1ed85b),_0x28eda3=cr(_0x3f7ff4,_0x381db3,_0x2824bd);_0x71ba35=vn(_0x3f7ff4,_0x71ba35,new C(_0x1ed85b),_0x28eda3,_0x9ef61d,_0x414e58,_0xb81fa5,_0x61cdda);}}),_0x71ba35;}function Ru(_0x161d8d,_0xad2362,_0x306741,_0x11b829,_0xdc4d82,_0x47f059,_0x2d8bae){if(yn(_0xdc4d82,_0x306741)!=null)return _0xad2362;const _0x42da93=_0xad2362['serverCache']['isFiltered'](),_0x53457b=_0xad2362['serverCache'];if(_0x11b829['value']!=null){if(v(_0x306741)&&_0x53457b['isFullyInitialized']()||_0x53457b['isCompleteForPath'](_0x306741))return vn(_0x161d8d,_0xad2362,_0x306741,_0x53457b['getNode']()['getChild'](_0x306741),_0xdc4d82,_0x47f059,_0x42da93,_0x2d8bae);if(v(_0x306741)){let _0x5b13c9=new S(null);return _0x53457b['getNode']()['forEachChild'](ye,(_0x2a581f,_0x2b3f6c)=>{_0x5b13c9=_0x5b13c9['set'](new C(_0x2a581f),_0x2b3f6c);}),Si(_0x161d8d,_0xad2362,_0x306741,_0x5b13c9,_0xdc4d82,_0x47f059,_0x42da93,_0x2d8bae);}else return _0xad2362;}else{let _0x317ae0=new S(null);return _0x11b829['foreach']((_0x139069,_0xb825b1)=>{const _0x185e5a=A(_0x306741,_0x139069);_0x53457b['isCompleteForPath'](_0x185e5a)&&(_0x317ae0=_0x317ae0['set'](_0x139069,_0x53457b['getNode']()['getChild'](_0x185e5a)));}),Si(_0x161d8d,_0xad2362,_0x306741,_0x317ae0,_0xdc4d82,_0x47f059,_0x42da93,_0x2d8bae);}}function Au(_0x4e72a8,_0x1c629a,_0x5f1f8b,_0x9e15a5,_0x5972ca){const _0xb6c161=_0x1c629a['serverCache'],_0x2d3246=Lo(_0x1c629a,_0xb6c161['getNode'](),_0xb6c161['isFullyInitialized']()||v(_0x5f1f8b),_0xb6c161['isFiltered']());return Ho(_0x4e72a8,_0x2d3246,_0x5f1f8b,_0x9e15a5,Vo,_0x5972ca);}function ku(_0x2ec33c,_0x4876ed,_0x28e011,_0xf1d8f5,_0x1c9d83,_0x36029b){let _0x396a49;if(yn(_0xf1d8f5,_0x28e011)!=null)return _0x4876ed;{const _0x39dae5=new ns(_0xf1d8f5,_0x4876ed,_0x1c9d83),_0x4e173d=_0x4876ed['eventCache']['getNode']();let _0x423fc9;if(v(_0x28e011)||y(_0x28e011)==='.priority'){let _0xa8c9fb;if(_0x4876ed['serverCache']['isFullyInitialized']())_0xa8c9fb=mn(_0xf1d8f5,Ue(_0x4876ed));else{const _0x2c3afe=_0x4876ed['serverCache']['getNode']();f(_0x2c3afe instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xa8c9fb=es(_0xf1d8f5,_0x2c3afe);}_0xa8c9fb=_0xa8c9fb,_0x423fc9=_0x2ec33c['filter']['updateFullNode'](_0x4e173d,_0xa8c9fb,_0x36029b);}else{const _0x6d22f2=y(_0x28e011);let _0x3dbda1=ts(_0xf1d8f5,_0x6d22f2,_0x4876ed['serverCache']);_0x3dbda1==null&&_0x4876ed['serverCache']['isCompleteForChild'](_0x6d22f2)&&(_0x3dbda1=_0x4e173d['getImmediateChild'](_0x6d22f2)),_0x3dbda1!=null?_0x423fc9=_0x2ec33c['filter']['updateChild'](_0x4e173d,_0x6d22f2,_0x3dbda1,b(_0x28e011),_0x39dae5,_0x36029b):_0x4876ed['eventCache']['getNode']()['hasChild'](_0x6d22f2)?_0x423fc9=_0x2ec33c['filter']['updateChild'](_0x4e173d,_0x6d22f2,g['EMPTY_NODE'],b(_0x28e011),_0x39dae5,_0x36029b):_0x423fc9=_0x4e173d,_0x423fc9['isEmpty']()&&_0x4876ed['serverCache']['isFullyInitialized']()&&(_0x396a49=mn(_0xf1d8f5,Ue(_0x4876ed)),_0x396a49['isLeafNode']()&&(_0x423fc9=_0x2ec33c['filter']['updateFullNode'](_0x423fc9,_0x396a49,_0x36029b)));}return _0x396a49=_0x4876ed['serverCache']['isFullyInitialized']()||yn(_0xf1d8f5,w())!=null,wt(_0x4876ed,_0x423fc9,_0x396a49,_0x2ec33c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x2d5e34,_0x1426cb){this['query_']=_0x2d5e34,this['eventRegistrations_']=[];const _0x5f350c=this['query_']['_queryParams'],_0x546864=new Yi(_0x5f350c['getIndex']()),_0x2f6b11=qh(_0x5f350c);this['processor_']=wu(_0x2f6b11);const _0xdd7ee5=_0x1426cb['serverCache'],_0x2b3aac=_0x1426cb['eventCache'],_0x4094ef=_0x546864['updateFullNode'](g['EMPTY_NODE'],_0xdd7ee5['getNode'](),null),_0x3aec9f=_0x2f6b11['updateFullNode'](g['EMPTY_NODE'],_0x2b3aac['getNode'](),null),_0x5af520=new Ce(_0x4094ef,_0xdd7ee5['isFullyInitialized'](),_0x546864['filtersNodes']()),_0x2767e2=new Ce(_0x3aec9f,_0x2b3aac['isFullyInitialized'](),_0x2f6b11['filtersNodes']());this['viewCache_']=Dn(_0x2767e2,_0x5af520),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x529c60){return _0x529c60['viewCache_']['serverCache']['getNode']();}function Ou(_0x19eeaa){return gn(_0x19eeaa['viewCache_']);}function Du(_0x4040fa,_0x40905c){const _0x202d77=Ue(_0x4040fa['viewCache_']);return _0x202d77&&(_0x4040fa['query']['_queryParams']['loadsAllData']()||!v(_0x40905c)&&!_0x202d77['getImmediateChild'](y(_0x40905c))['isEmpty']())?_0x202d77['getChild'](_0x40905c):null;}function lr(_0x4346d7){return _0x4346d7['eventRegistrations_']['length']===0x0;}function Mu(_0x4f1125,_0x4e0999){_0x4f1125['eventRegistrations_']['push'](_0x4e0999);}function hr(_0x4a8d7c,_0x3d55e4,_0x265861){const _0x509acf=[];if(_0x265861){f(_0x3d55e4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x387cb8=_0x4a8d7c['query']['_path'];_0x4a8d7c['eventRegistrations_']['forEach'](_0x4030cf=>{const _0x4c76c9=_0x4030cf['createCancelEvent'](_0x265861,_0x387cb8);_0x4c76c9&&_0x509acf['push'](_0x4c76c9);});}if(_0x3d55e4){let _0xb8fc4c=[];for(let _0x586287=0x0;_0x586287<_0x4a8d7c['eventRegistrations_']['length'];++_0x586287){const _0x3f6275=_0x4a8d7c['eventRegistrations_'][_0x586287];if(!_0x3f6275['matches'](_0x3d55e4))_0xb8fc4c['push'](_0x3f6275);else{if(_0x3d55e4['hasAnyCallback']()){_0xb8fc4c=_0xb8fc4c['concat'](_0x4a8d7c['eventRegistrations_']['slice'](_0x586287+0x1));break;}}}_0x4a8d7c['eventRegistrations_']=_0xb8fc4c;}else _0x4a8d7c['eventRegistrations_']=[];return _0x509acf;}function ur(_0x5e862f,_0x39f4e2,_0x17a7ad,_0x422a4a){_0x39f4e2['type']===q['MERGE']&&_0x39f4e2['source']['queryId']!==null&&(f(Ue(_0x5e862f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x5e862f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2f8c4e=_0x5e862f['viewCache_'],_0x2a00bd=Tu(_0x5e862f['processor_'],_0x2f8c4e,_0x39f4e2,_0x17a7ad,_0x422a4a);return Cu(_0x5e862f['processor_'],_0x2a00bd['viewCache']),f(_0x2a00bd['viewCache']['serverCache']['isFullyInitialized']()||!_0x2f8c4e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5e862f['viewCache_']=_0x2a00bd['viewCache'],$o(_0x5e862f,_0x2a00bd['changes'],_0x2a00bd['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x3b06f4,_0x2d338a){const _0x33e41d=_0x3b06f4['viewCache_']['eventCache'],_0x557049=[];return _0x33e41d['getNode']()['isLeafNode']()||_0x33e41d['getNode']()['forEachChild'](R,(_0x4eb555,_0x461ed4)=>{_0x557049['push'](tt(_0x4eb555,_0x461ed4));}),_0x33e41d['isFullyInitialized']()&&_0x557049['push'](Oo(_0x33e41d['getNode']())),$o(_0x3b06f4,_0x557049,_0x33e41d['getNode'](),_0x2d338a);}function $o(_0x602bf9,_0x168120,_0x16feb0,_0x3f1cb6){const _0x2fb779=_0x3f1cb6?[_0x3f1cb6]:_0x602bf9['eventRegistrations_'];return nu(_0x602bf9['eventGenerator_'],_0x168120,_0x16feb0,_0x2fb779);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x2b826c){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x2b826c;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x301831){return _0x301831['views']['size']===0x0;}function is(_0x2c61b9,_0x5522f3,_0x52dceb,_0x528899){const _0x1ae70c=_0x5522f3['source']['queryId'];if(_0x1ae70c!==null){const _0xbd361d=_0x2c61b9['views']['get'](_0x1ae70c);return f(_0xbd361d!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xbd361d,_0x5522f3,_0x52dceb,_0x528899);}else{let _0xcc2199=[];for(const _0x4d37ec of _0x2c61b9['views']['values']())_0xcc2199=_0xcc2199['concat'](ur(_0x4d37ec,_0x5522f3,_0x52dceb,_0x528899));return _0xcc2199;}}function qo(_0x38af4c,_0x2fef04,_0x97e4d8,_0x155dd7,_0x558cd2){const _0xa60217=_0x2fef04['_queryIdentifier'],_0x198b06=_0x38af4c['views']['get'](_0xa60217);if(!_0x198b06){let _0x54e6d3=mn(_0x97e4d8,_0x558cd2?_0x155dd7:null),_0x5bbf97=!0x1;_0x54e6d3?_0x5bbf97=!0x0:_0x155dd7 instanceof g?(_0x54e6d3=es(_0x97e4d8,_0x155dd7),_0x5bbf97=!0x1):(_0x54e6d3=g['EMPTY_NODE'],_0x5bbf97=!0x1);const _0xaeb091=Dn(new Ce(_0x54e6d3,_0x5bbf97,!0x1),new Ce(_0x155dd7,_0x558cd2,!0x1));return new Nu(_0x2fef04,_0xaeb091);}return _0x198b06;}function Wu(_0x89287b,_0xf4864f,_0x302b56,_0x28dd90,_0x11ce7d,_0x4fa9b1){const _0xb08c2=qo(_0x89287b,_0xf4864f,_0x28dd90,_0x11ce7d,_0x4fa9b1);return _0x89287b['views']['has'](_0xf4864f['_queryIdentifier'])||_0x89287b['views']['set'](_0xf4864f['_queryIdentifier'],_0xb08c2),Mu(_0xb08c2,_0x302b56),Lu(_0xb08c2,_0x302b56);}function Bu(_0x443764,_0x490ca8,_0x2ea00a,_0x233038){const _0x4097c6=_0x490ca8['_queryIdentifier'],_0x4c2ff0=[];let _0x3d80cd=[];const _0x55405f=Te(_0x443764);if(_0x4097c6==='default'){for(const [_0x36eb01,_0xf4a0a5]of _0x443764['views']['entries']())_0x3d80cd=_0x3d80cd['concat'](hr(_0xf4a0a5,_0x2ea00a,_0x233038)),lr(_0xf4a0a5)&&(_0x443764['views']['delete'](_0x36eb01),_0xf4a0a5['query']['_queryParams']['loadsAllData']()||_0x4c2ff0['push'](_0xf4a0a5['query']));}else{const _0x5df489=_0x443764['views']['get'](_0x4097c6);_0x5df489&&(_0x3d80cd=_0x3d80cd['concat'](hr(_0x5df489,_0x2ea00a,_0x233038)),lr(_0x5df489)&&(_0x443764['views']['delete'](_0x4097c6),_0x5df489['query']['_queryParams']['loadsAllData']()||_0x4c2ff0['push'](_0x5df489['query'])));}return _0x55405f&&!Te(_0x443764)&&_0x4c2ff0['push'](new(Fu())(_0x490ca8['_repo'],_0x490ca8['_path'])),{'removed':_0x4c2ff0,'events':_0x3d80cd};}function zo(_0x3bbfb6){const _0x4b4397=[];for(const _0x2326ac of _0x3bbfb6['views']['values']())_0x2326ac['query']['_queryParams']['loadsAllData']()||_0x4b4397['push'](_0x2326ac);return _0x4b4397;}function Ee(_0xa9193b,_0x54afd9){let _0x1d659f=null;for(const _0x17d24c of _0xa9193b['views']['values']())_0x1d659f=_0x1d659f||Du(_0x17d24c,_0x54afd9);return _0x1d659f;}function jo(_0x457f84,_0x583ee0){if(_0x583ee0['_queryParams']['loadsAllData']())return Ln(_0x457f84);{const _0x35e0b7=_0x583ee0['_queryIdentifier'];return _0x457f84['views']['get'](_0x35e0b7);}}function Ko(_0x4e3066,_0x57f4c7){return jo(_0x4e3066,_0x57f4c7)!=null;}function Te(_0x1d9316){return Ln(_0x1d9316)!=null;}function Ln(_0x412156){for(const _0xbf9dc9 of _0x412156['views']['values']())if(_0xbf9dc9['query']['_queryParams']['loadsAllData']())return _0xbf9dc9;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x4762fe){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x4762fe;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x49d83a){this['listenProvider_']=_0x49d83a,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x385de5,_0x39ede4,_0x3154f1,_0x121e11,_0x23b2b1){return ou(_0x385de5['pendingWriteTree_'],_0x39ede4,_0x3154f1,_0x121e11,_0x23b2b1),_0x23b2b1?ht(_0x385de5,new Fe(Ji(),_0x39ede4,_0x3154f1)):[];}function Gu(_0x29635c,_0xb1097b,_0x2aa76b,_0x195e58){au(_0x29635c['pendingWriteTree_'],_0xb1097b,_0x2aa76b,_0x195e58);const _0x419776=S['fromObject'](_0x2aa76b);return ht(_0x29635c,new nt(Ji(),_0xb1097b,_0x419776));}function pe(_0x262d48,_0x5f4dae,_0x1aff61=!0x1){const _0x1f7022=cu(_0x262d48['pendingWriteTree_'],_0x5f4dae);if(lu(_0x262d48['pendingWriteTree_'],_0x5f4dae)){let _0x412876=new S(null);return _0x1f7022['snap']!=null?_0x412876=_0x412876['set'](w(),!0x0):x(_0x1f7022['children'],_0xa9b587=>{_0x412876=_0x412876['set'](new C(_0xa9b587),!0x0);}),ht(_0x262d48,new _n(_0x1f7022['path'],_0x412876,_0x1aff61));}else return[];}function $t(_0x1ef931,_0x4c45ef,_0x20ede0){return ht(_0x1ef931,new Fe(Xi(),_0x4c45ef,_0x20ede0));}function qu(_0x33b7f9,_0x42352b,_0x35ec83){const _0x431d79=S['fromObject'](_0x35ec83);return ht(_0x33b7f9,new nt(Xi(),_0x42352b,_0x431d79));}function zu(_0x4f4506,_0x3b93e5){return ht(_0x4f4506,new Dt(Xi(),_0x3b93e5));}function ju(_0x4128fe,_0x92c839,_0x43fe0f){const _0x431255=rs(_0x4128fe,_0x43fe0f);if(_0x431255){const _0x59ad3c=os(_0x431255),_0x3075b6=_0x59ad3c['path'],_0x4a7fa8=_0x59ad3c['queryId'],_0x4b9f32=F(_0x3075b6,_0x92c839),_0x5416b1=new Dt(Zi(_0x4a7fa8),_0x4b9f32);return as(_0x4128fe,_0x3075b6,_0x5416b1);}else return[];}function wn(_0x88f750,_0x5a8607,_0x1ca587,_0x18568d,_0x5a8ec2=!0x1){const _0x2c3151=_0x5a8607['_path'],_0x1d2352=_0x88f750['syncPointTree_']['get'](_0x2c3151);let _0xc5d029=[];if(_0x1d2352&&(_0x5a8607['_queryIdentifier']==='default'||Ko(_0x1d2352,_0x5a8607))){const _0x5038e1=Bu(_0x1d2352,_0x5a8607,_0x1ca587,_0x18568d);Uu(_0x1d2352)&&(_0x88f750['syncPointTree_']=_0x88f750['syncPointTree_']['remove'](_0x2c3151));const _0x554d61=_0x5038e1['removed'];if(_0xc5d029=_0x5038e1['events'],!_0x5a8ec2){const _0x5d8f9d=_0x554d61['findIndex'](_0x31e6e7=>_0x31e6e7['_queryParams']['loadsAllData']())!==-0x1,_0x287856=_0x88f750['syncPointTree_']['findOnPath'](_0x2c3151,(_0x2f552c,_0x56e0b4)=>Te(_0x56e0b4));if(_0x5d8f9d&&!_0x287856){const _0x130c6f=_0x88f750['syncPointTree_']['subtree'](_0x2c3151);if(!_0x130c6f['isEmpty']()){const _0x18d50c=Qu(_0x130c6f);for(let _0x20b8cd=0x0;_0x20b8cd<_0x18d50c['length'];++_0x20b8cd){const _0x314669=_0x18d50c[_0x20b8cd],_0x335659=_0x314669['query'],_0x484c57=Xo(_0x88f750,_0x314669);_0x88f750['listenProvider_']['startListening'](Tt(_0x335659),Mt(_0x88f750,_0x335659),_0x484c57['hashFn'],_0x484c57['onComplete']);}}}!_0x287856&&_0x554d61['length']>0x0&&!_0x18568d&&(_0x5d8f9d?_0x88f750['listenProvider_']['stopListening'](Tt(_0x5a8607),null):_0x554d61['forEach'](_0x255d9d=>{const _0x30fbb5=_0x88f750['queryToTagMap']['get'](Fn(_0x255d9d));_0x88f750['listenProvider_']['stopListening'](Tt(_0x255d9d),_0x30fbb5);}));}Ju(_0x88f750,_0x554d61);}return _0xc5d029;}function Yo(_0x243d36,_0x1876a1,_0x39956d,_0x587bcd){const _0x39d789=rs(_0x243d36,_0x587bcd);if(_0x39d789!=null){const _0x34004a=os(_0x39d789),_0x1bd3eb=_0x34004a['path'],_0x297bd4=_0x34004a['queryId'],_0x1f66f3=F(_0x1bd3eb,_0x1876a1),_0x181bdc=new Fe(Zi(_0x297bd4),_0x1f66f3,_0x39956d);return as(_0x243d36,_0x1bd3eb,_0x181bdc);}else return[];}function Ku(_0x284f5e,_0x454570,_0x314780,_0x38d939){const _0xd84708=rs(_0x284f5e,_0x38d939);if(_0xd84708){const _0x19a8dd=os(_0xd84708),_0x67f83b=_0x19a8dd['path'],_0x5e7d71=_0x19a8dd['queryId'],_0x386520=F(_0x67f83b,_0x454570),_0x16ffb3=S['fromObject'](_0x314780),_0x39b047=new nt(Zi(_0x5e7d71),_0x386520,_0x16ffb3);return as(_0x284f5e,_0x67f83b,_0x39b047);}else return[];}function bi(_0x37838a,_0xb7bb92,_0x37a0c3,_0x13a696=!0x1){const _0x1939a4=_0xb7bb92['_path'];let _0x439e30=null,_0x4b2e43=!0x1;_0x37838a['syncPointTree_']['foreachOnPath'](_0x1939a4,(_0x418200,_0x8db221)=>{const _0xebfba5=F(_0x418200,_0x1939a4);_0x439e30=_0x439e30||Ee(_0x8db221,_0xebfba5),_0x4b2e43=_0x4b2e43||Te(_0x8db221);});let _0x3de69e=_0x37838a['syncPointTree_']['get'](_0x1939a4);_0x3de69e?(_0x4b2e43=_0x4b2e43||Te(_0x3de69e),_0x439e30=_0x439e30||Ee(_0x3de69e,w())):(_0x3de69e=new Go(),_0x37838a['syncPointTree_']=_0x37838a['syncPointTree_']['set'](_0x1939a4,_0x3de69e));let _0x835f11;_0x439e30!=null?_0x835f11=!0x0:(_0x835f11=!0x1,_0x439e30=g['EMPTY_NODE'],_0x37838a['syncPointTree_']['subtree'](_0x1939a4)['foreachChild']((_0x47a71a,_0x2c4144)=>{const _0x3d8012=Ee(_0x2c4144,w());_0x3d8012&&(_0x439e30=_0x439e30['updateImmediateChild'](_0x47a71a,_0x3d8012));}));const _0x37b595=Ko(_0x3de69e,_0xb7bb92);if(!_0x37b595&&!_0xb7bb92['_queryParams']['loadsAllData']()){const _0x5f402b=Fn(_0xb7bb92);f(!_0x37838a['queryToTagMap']['has'](_0x5f402b),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x44ee02=Xu();_0x37838a['queryToTagMap']['set'](_0x5f402b,_0x44ee02),_0x37838a['tagToQueryMap']['set'](_0x44ee02,_0x5f402b);}const _0x1128c3=Mn(_0x37838a['pendingWriteTree_'],_0x1939a4);let _0x3dd2ad=Wu(_0x3de69e,_0xb7bb92,_0x37a0c3,_0x1128c3,_0x439e30,_0x835f11);if(!_0x37b595&&!_0x4b2e43&&!_0x13a696){const _0x2ef49c=jo(_0x3de69e,_0xb7bb92);_0x3dd2ad=_0x3dd2ad['concat'](Zu(_0x37838a,_0xb7bb92,_0x2ef49c));}return _0x3dd2ad;}function xn(_0x3938ce,_0x2bb7e5,_0x28c3d9){const _0x5c88b0=_0x3938ce['pendingWriteTree_'],_0x79a581=_0x3938ce['syncPointTree_']['findOnPath'](_0x2bb7e5,(_0x48e7fa,_0x3e531c)=>{const _0x2274f3=F(_0x48e7fa,_0x2bb7e5),_0x32f091=Ee(_0x3e531c,_0x2274f3);if(_0x32f091)return _0x32f091;});return Uo(_0x5c88b0,_0x2bb7e5,_0x79a581,_0x28c3d9,!0x0);}function Yu(_0x18d01e,_0xa19dfb){const _0x4c2208=_0xa19dfb['_path'];let _0x156614=null;_0x18d01e['syncPointTree_']['foreachOnPath'](_0x4c2208,(_0x16ca8e,_0x1c949b)=>{const _0x5797ee=F(_0x16ca8e,_0x4c2208);_0x156614=_0x156614||Ee(_0x1c949b,_0x5797ee);});let _0x2d314c=_0x18d01e['syncPointTree_']['get'](_0x4c2208);_0x2d314c?_0x156614=_0x156614||Ee(_0x2d314c,w()):(_0x2d314c=new Go(),_0x18d01e['syncPointTree_']=_0x18d01e['syncPointTree_']['set'](_0x4c2208,_0x2d314c));const _0x5a60b8=_0x156614!=null,_0x39f338=_0x5a60b8?new Ce(_0x156614,!0x0,!0x1):null,_0x248354=Mn(_0x18d01e['pendingWriteTree_'],_0xa19dfb['_path']),_0x2331ee=qo(_0x2d314c,_0xa19dfb,_0x248354,_0x5a60b8?_0x39f338['getNode']():g['EMPTY_NODE'],_0x5a60b8);return Ou(_0x2331ee);}function ht(_0x186491,_0x4d5474){return Qo(_0x4d5474,_0x186491['syncPointTree_'],null,Mn(_0x186491['pendingWriteTree_'],w()));}function Qo(_0x1c2591,_0x4bf01c,_0x33ff45,_0x4a8b95){if(v(_0x1c2591['path']))return Jo(_0x1c2591,_0x4bf01c,_0x33ff45,_0x4a8b95);{const _0x4ef688=_0x4bf01c['get'](w());_0x33ff45==null&&_0x4ef688!=null&&(_0x33ff45=Ee(_0x4ef688,w()));let _0x746117=[];const _0x15134b=y(_0x1c2591['path']),_0x449674=_0x1c2591['operationForChild'](_0x15134b),_0x3eda6f=_0x4bf01c['children']['get'](_0x15134b);if(_0x3eda6f&&_0x449674){const _0x2f40df=_0x33ff45?_0x33ff45['getImmediateChild'](_0x15134b):null,_0x56dc0d=Wo(_0x4a8b95,_0x15134b);_0x746117=_0x746117['concat'](Qo(_0x449674,_0x3eda6f,_0x2f40df,_0x56dc0d));}return _0x4ef688&&(_0x746117=_0x746117['concat'](is(_0x4ef688,_0x1c2591,_0x4a8b95,_0x33ff45))),_0x746117;}}function Jo(_0x6e23da,_0x1e45fc,_0x301e0d,_0x5145bb){const _0x19f578=_0x1e45fc['get'](w());_0x301e0d==null&&_0x19f578!=null&&(_0x301e0d=Ee(_0x19f578,w()));let _0x3ba2e4=[];return _0x1e45fc['children']['inorderTraversal']((_0x37abcc,_0x3b3e7e)=>{const _0x281163=_0x301e0d?_0x301e0d['getImmediateChild'](_0x37abcc):null,_0x21ecb6=Wo(_0x5145bb,_0x37abcc),_0x1e8c46=_0x6e23da['operationForChild'](_0x37abcc);_0x1e8c46&&(_0x3ba2e4=_0x3ba2e4['concat'](Jo(_0x1e8c46,_0x3b3e7e,_0x281163,_0x21ecb6)));}),_0x19f578&&(_0x3ba2e4=_0x3ba2e4['concat'](is(_0x19f578,_0x6e23da,_0x5145bb,_0x301e0d))),_0x3ba2e4;}function Xo(_0xc0bfd9,_0x5741d9){const _0x2d00a6=_0x5741d9['query'],_0x1e4c8b=Mt(_0xc0bfd9,_0x2d00a6);return{'hashFn':()=>(Pu(_0x5741d9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2accd5=>{if(_0x2accd5==='ok')return _0x1e4c8b?ju(_0xc0bfd9,_0x2d00a6['_path'],_0x1e4c8b):zu(_0xc0bfd9,_0x2d00a6['_path']);{const _0x1cd7d9=ql(_0x2accd5,_0x2d00a6);return wn(_0xc0bfd9,_0x2d00a6,null,_0x1cd7d9);}}};}function Mt(_0x26a188,_0x4f651d){const _0x273e5c=Fn(_0x4f651d);return _0x26a188['queryToTagMap']['get'](_0x273e5c);}function Fn(_0x2303c6){return _0x2303c6['_path']['toString']()+'$'+_0x2303c6['_queryIdentifier'];}function rs(_0x5dbdd3,_0x504847){return _0x5dbdd3['tagToQueryMap']['get'](_0x504847);}function os(_0x4a49ca){const _0x26ec86=_0x4a49ca['indexOf']('$');return f(_0x26ec86!==-0x1&&_0x26ec86<_0x4a49ca['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4a49ca['substr'](_0x26ec86+0x1),'path':new C(_0x4a49ca['substr'](0x0,_0x26ec86))};}function as(_0x5b0ab0,_0x4c13bc,_0x40ec4f){const _0x2cf01c=_0x5b0ab0['syncPointTree_']['get'](_0x4c13bc);f(_0x2cf01c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0xeaa1fc=Mn(_0x5b0ab0['pendingWriteTree_'],_0x4c13bc);return is(_0x2cf01c,_0x40ec4f,_0xeaa1fc,null);}function Qu(_0x4a1afa){return _0x4a1afa['fold']((_0x34a21a,_0x445b1b,_0x474e73)=>{if(_0x445b1b&&Te(_0x445b1b))return[Ln(_0x445b1b)];{let _0x214503=[];return _0x445b1b&&(_0x214503=zo(_0x445b1b)),x(_0x474e73,(_0x31be65,_0x2e59b3)=>{_0x214503=_0x214503['concat'](_0x2e59b3);}),_0x214503;}});}function Tt(_0x59c557){return _0x59c557['_queryParams']['loadsAllData']()&&!_0x59c557['_queryParams']['isDefault']()?new(Hu())(_0x59c557['_repo'],_0x59c557['_path']):_0x59c557;}function Ju(_0x637e1d,_0x45004c){for(let _0x435af9=0x0;_0x435af9<_0x45004c['length'];++_0x435af9){const _0x3e0a96=_0x45004c[_0x435af9];if(!_0x3e0a96['_queryParams']['loadsAllData']()){const _0x55abd7=Fn(_0x3e0a96),_0x4c7a08=_0x637e1d['queryToTagMap']['get'](_0x55abd7);_0x637e1d['queryToTagMap']['delete'](_0x55abd7),_0x637e1d['tagToQueryMap']['delete'](_0x4c7a08);}}}function Xu(){return $u++;}function Zu(_0x3b92fc,_0x6423fa,_0x400497){const _0x2ab82f=_0x6423fa['_path'],_0x37341c=Mt(_0x3b92fc,_0x6423fa),_0x1235d6=Xo(_0x3b92fc,_0x400497),_0x4835b8=_0x3b92fc['listenProvider_']['startListening'](Tt(_0x6423fa),_0x37341c,_0x1235d6['hashFn'],_0x1235d6['onComplete']),_0x150d30=_0x3b92fc['syncPointTree_']['subtree'](_0x2ab82f);if(_0x37341c)f(!Te(_0x150d30['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4a8a3b=_0x150d30['fold']((_0x595b0e,_0x5c9e16,_0x1d239c)=>{if(!v(_0x595b0e)&&_0x5c9e16&&Te(_0x5c9e16))return[Ln(_0x5c9e16)['query']];{let _0x3767bb=[];return _0x5c9e16&&(_0x3767bb=_0x3767bb['concat'](zo(_0x5c9e16)['map'](_0x396217=>_0x396217['query']))),x(_0x1d239c,(_0x3d0d31,_0x526b19)=>{_0x3767bb=_0x3767bb['concat'](_0x526b19);}),_0x3767bb;}});for(let _0xe0841d=0x0;_0xe0841d<_0x4a8a3b['length'];++_0xe0841d){const _0x5bf5cb=_0x4a8a3b[_0xe0841d];_0x3b92fc['listenProvider_']['stopListening'](Tt(_0x5bf5cb),Mt(_0x3b92fc,_0x5bf5cb));}}return _0x4835b8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x2df096){this['node_']=_0x2df096;}['getImmediateChild'](_0x234f17){const _0x24f569=this['node_']['getImmediateChild'](_0x234f17);return new cs(_0x24f569);}['node'](){return this['node_'];}}class ls{constructor(_0x14210b,_0x5a1d63){this['syncTree_']=_0x14210b,this['path_']=_0x5a1d63;}['getImmediateChild'](_0xfce0a0){const _0x37c700=A(this['path_'],_0xfce0a0);return new ls(this['syncTree_'],_0x37c700);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x5d2a51){return _0x5d2a51=_0x5d2a51||{},_0x5d2a51['timestamp']=_0x5d2a51['timestamp']||new Date()['getTime'](),_0x5d2a51;},fr=function(_0x250dca,_0x1e0f1a,_0x21e659){if(!_0x250dca||typeof _0x250dca!='object')return _0x250dca;if(f('.sv'in _0x250dca,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x250dca['.sv']=='string')return td(_0x250dca['.sv'],_0x1e0f1a,_0x21e659);if(typeof _0x250dca['.sv']=='object')return nd(_0x250dca['.sv'],_0x1e0f1a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x250dca,null,0x2));},td=function(_0x532dd6,_0x3fae3d,_0x56c866){switch(_0x532dd6){case'timestamp':return _0x56c866['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x532dd6);}},nd=function(_0x497aa2,_0x56f952,_0x1da821){_0x497aa2['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x497aa2,null,0x2));const _0x21aa26=_0x497aa2['increment'];typeof _0x21aa26!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x21aa26);const _0x19e04a=_0x56f952['node']();if(f(_0x19e04a!==null&&typeof _0x19e04a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x19e04a['isLeafNode']())return _0x21aa26;const _0x49b4b4=_0x19e04a['getValue']();return typeof _0x49b4b4!='number'?_0x21aa26:_0x49b4b4+_0x21aa26;},Zo=function(_0x1fa744,_0x55047c,_0x490626,_0x4368f7){return us(_0x55047c,new ls(_0x490626,_0x1fa744),_0x4368f7);},hs=function(_0x32f1ef,_0x5d75ba,_0x452bed){return us(_0x32f1ef,new cs(_0x5d75ba),_0x452bed);};function us(_0x2b5b52,_0x38e4ee,_0x454ab7){const _0x5f2fd8=_0x2b5b52['getPriority']()['val'](),_0x98cea7=fr(_0x5f2fd8,_0x38e4ee['getImmediateChild']('.priority'),_0x454ab7);let _0xdada33;if(_0x2b5b52['isLeafNode']()){const _0x280afe=_0x2b5b52,_0x2036de=fr(_0x280afe['getValue'](),_0x38e4ee,_0x454ab7);return _0x2036de!==_0x280afe['getValue']()||_0x98cea7!==_0x280afe['getPriority']()['val']()?new D(_0x2036de,N(_0x98cea7)):_0x2b5b52;}else{const _0x349d84=_0x2b5b52;return _0xdada33=_0x349d84,_0x98cea7!==_0x349d84['getPriority']()['val']()&&(_0xdada33=_0xdada33['updatePriority'](new D(_0x98cea7))),_0x349d84['forEachChild'](R,(_0x4b79d3,_0x4f64ef)=>{const _0x35a1b0=us(_0x4f64ef,_0x38e4ee['getImmediateChild'](_0x4b79d3),_0x454ab7);_0x35a1b0!==_0x4f64ef&&(_0xdada33=_0xdada33['updateImmediateChild'](_0x4b79d3,_0x35a1b0));}),_0xdada33;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3496b4='',_0x6fcaf8=null,_0x513f2a={'children':{},'childCount':0x0}){this['name']=_0x3496b4,this['parent']=_0x6fcaf8,this['node']=_0x513f2a;}}function Un(_0x1eca7c,_0x107a8a){let _0x340ca9=_0x107a8a instanceof C?_0x107a8a:new C(_0x107a8a),_0x45fa53=_0x1eca7c,_0x42dbe5=y(_0x340ca9);for(;_0x42dbe5!==null;){const _0x50bbf4=Oe(_0x45fa53['node']['children'],_0x42dbe5)||{'children':{},'childCount':0x0};_0x45fa53=new ds(_0x42dbe5,_0x45fa53,_0x50bbf4),_0x340ca9=b(_0x340ca9),_0x42dbe5=y(_0x340ca9);}return _0x45fa53;}function Ge(_0x47d1a8){return _0x47d1a8['node']['value'];}function fs(_0x39607c,_0xb2017c){_0x39607c['node']['value']=_0xb2017c,Ri(_0x39607c);}function ea(_0x17228e){return _0x17228e['node']['childCount']>0x0;}function id(_0x3ac62e){return Ge(_0x3ac62e)===void 0x0&&!ea(_0x3ac62e);}function Wn(_0x19c438,_0x251590){x(_0x19c438['node']['children'],(_0x1a46c6,_0x563bb8)=>{_0x251590(new ds(_0x1a46c6,_0x19c438,_0x563bb8));});}function ta(_0x3612c7,_0x1ee2e8,_0x5d01de,_0x17dc68){_0x5d01de&&_0x1ee2e8(_0x3612c7),Wn(_0x3612c7,_0x20f437=>{ta(_0x20f437,_0x1ee2e8,!0x0);});}function sd(_0x34e9ce,_0x360dcf,_0x568982){let _0x4fea1e=_0x34e9ce['parent'];for(;_0x4fea1e!==null;){if(_0x360dcf(_0x4fea1e))return!0x0;_0x4fea1e=_0x4fea1e['parent'];}return!0x1;}function Gt(_0x35471e){return new C(_0x35471e['parent']===null?_0x35471e['name']:Gt(_0x35471e['parent'])+'/'+_0x35471e['name']);}function Ri(_0x41f196){_0x41f196['parent']!==null&&rd(_0x41f196['parent'],_0x41f196['name'],_0x41f196);}function rd(_0x10c4ff,_0x1ad736,_0x26de60){const _0x3ac992=id(_0x26de60),_0x2a6773=Y(_0x10c4ff['node']['children'],_0x1ad736);_0x3ac992&&_0x2a6773?(delete _0x10c4ff['node']['children'][_0x1ad736],_0x10c4ff['node']['childCount']--,Ri(_0x10c4ff)):!_0x3ac992&&!_0x2a6773&&(_0x10c4ff['node']['children'][_0x1ad736]=_0x26de60['node'],_0x10c4ff['node']['childCount']++,Ri(_0x10c4ff));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x324f5d){return typeof _0x324f5d=='string'&&_0x324f5d['length']!==0x0&&!od['test'](_0x324f5d);},na=function(_0x3377ea){return typeof _0x3377ea=='string'&&_0x3377ea['length']!==0x0&&!ad['test'](_0x3377ea);},cd=function(_0x29d2f6){return _0x29d2f6&&(_0x29d2f6=_0x29d2f6['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x29d2f6);},Cn=function(_0x2d1744){return _0x2d1744===null||typeof _0x2d1744=='string'||typeof _0x2d1744=='number'&&!Wi(_0x2d1744)||_0x2d1744&&typeof _0x2d1744=='object'&&Y(_0x2d1744,'.sv');},qt=function(_0x87d524,_0x3bde37,_0x5c1157,_0x533066){_0x533066&&_0x3bde37===void 0x0||zt(Nn(_0x87d524,'value'),_0x3bde37,_0x5c1157);},zt=function(_0x1d6d47,_0x4e17d3,_0x4308a5){const _0x16928b=_0x4308a5 instanceof C?new Sh(_0x4308a5,_0x1d6d47):_0x4308a5;if(_0x4e17d3===void 0x0)throw new Error(_0x1d6d47+'contains\x20undefined\x20'+Ne(_0x16928b));if(typeof _0x4e17d3=='function')throw new Error(_0x1d6d47+'contains\x20a\x20function\x20'+Ne(_0x16928b)+'\x20with\x20contents\x20=\x20'+_0x4e17d3['toString']());if(Wi(_0x4e17d3))throw new Error(_0x1d6d47+'contains\x20'+_0x4e17d3['toString']()+'\x20'+Ne(_0x16928b));if(typeof _0x4e17d3=='string'&&_0x4e17d3['length']>oi/0x3&&Pn(_0x4e17d3)>oi)throw new Error(_0x1d6d47+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x16928b)+'\x20(\x27'+_0x4e17d3['substring'](0x0,0x32)+'...\x27)');if(_0x4e17d3&&typeof _0x4e17d3=='object'){let _0x13c58e=!0x1,_0x250715=!0x1;if(x(_0x4e17d3,(_0x2a3d01,_0x3c2d35)=>{if(_0x2a3d01==='.value')_0x13c58e=!0x0;else{if(_0x2a3d01!=='.priority'&&_0x2a3d01!=='.sv'&&(_0x250715=!0x0,!ps(_0x2a3d01)))throw new Error(_0x1d6d47+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2a3d01+')\x20'+Ne(_0x16928b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x16928b,_0x2a3d01),zt(_0x1d6d47,_0x3c2d35,_0x16928b),Rh(_0x16928b);}),_0x13c58e&&_0x250715)throw new Error(_0x1d6d47+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x16928b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x599950,_0x29069f){let _0x3a7cd3,_0x3f99a6;for(_0x3a7cd3=0x0;_0x3a7cd3<_0x29069f['length'];_0x3a7cd3++){_0x3f99a6=_0x29069f[_0x3a7cd3];const _0x2dd22a=kt(_0x3f99a6);for(let _0x3b728b=0x0;_0x3b728b<_0x2dd22a['length'];_0x3b728b++)if(!(_0x2dd22a[_0x3b728b]==='.priority'&&_0x3b728b===_0x2dd22a['length']-0x1)){if(!ps(_0x2dd22a[_0x3b728b]))throw new Error(_0x599950+'contains\x20an\x20invalid\x20key\x20('+_0x2dd22a[_0x3b728b]+')\x20in\x20path\x20'+_0x3f99a6['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x29069f['sort'](Th);let _0x3eade1=null;for(_0x3a7cd3=0x0;_0x3a7cd3<_0x29069f['length'];_0x3a7cd3++){if(_0x3f99a6=_0x29069f[_0x3a7cd3],_0x3eade1!==null&&$(_0x3eade1,_0x3f99a6))throw new Error(_0x599950+'contains\x20a\x20path\x20'+_0x3eade1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3f99a6['toString']());_0x3eade1=_0x3f99a6;}},hd=function(_0x252712,_0x1536d3,_0x5dc6db,_0x59a6aa){const _0x4a8bdd=Nn(_0x252712,'values');if(!(_0x1536d3&&typeof _0x1536d3=='object')||Array['isArray'](_0x1536d3))throw new Error(_0x4a8bdd+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5563bf=[];x(_0x1536d3,(_0x2271c3,_0x442b22)=>{const _0x24f7bb=new C(_0x2271c3);if(zt(_0x4a8bdd,_0x442b22,A(_0x5dc6db,_0x24f7bb)),Gi(_0x24f7bb)==='.priority'&&!Cn(_0x442b22))throw new Error(_0x4a8bdd+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x24f7bb['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5563bf['push'](_0x24f7bb);}),ld(_0x4a8bdd,_0x5563bf);},_s=function(_0x9106b0,_0x1e3bf0,_0x34c9af,_0xb9ebcc){if(!na(_0x34c9af))throw new Error(Nn(_0x9106b0,_0x1e3bf0)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x34c9af+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x3709ff,_0x25b381,_0x46fc63,_0x38fa03){_0x46fc63&&(_0x46fc63=_0x46fc63['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x3709ff,_0x25b381,_0x46fc63);},gs=function(_0x6afcad,_0x20bea6){if(y(_0x20bea6)==='.info')throw new Error(_0x6afcad+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x57a632,_0x5526c7){const _0x415a49=_0x5526c7['path']['toString']();if(typeof _0x5526c7['repoInfo']['host']!='string'||_0x5526c7['repoInfo']['host']['length']===0x0||!ps(_0x5526c7['repoInfo']['namespace'])&&_0x5526c7['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x415a49['length']!==0x0&&!cd(_0x415a49))throw new Error(Nn(_0x57a632,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x27b84c,_0x38687b){let _0x1f1fec=null;for(let _0x2c877a=0x0;_0x2c877a<_0x38687b['length'];_0x2c877a++){const _0x153172=_0x38687b[_0x2c877a],_0x1cbf88=_0x153172['getPath']();_0x1f1fec!==null&&!qi(_0x1cbf88,_0x1f1fec['path'])&&(_0x27b84c['eventLists_']['push'](_0x1f1fec),_0x1f1fec=null),_0x1f1fec===null&&(_0x1f1fec={'events':[],'path':_0x1cbf88}),_0x1f1fec['events']['push'](_0x153172);}_0x1f1fec&&_0x27b84c['eventLists_']['push'](_0x1f1fec);}function ia(_0x37a04a,_0x175540,_0xd28cbf){Bn(_0x37a04a,_0xd28cbf),sa(_0x37a04a,_0x59f55f=>qi(_0x59f55f,_0x175540));}function V(_0x39ba90,_0x27e968,_0x3e65e0){Bn(_0x39ba90,_0x3e65e0),sa(_0x39ba90,_0x5ea5d1=>$(_0x5ea5d1,_0x27e968)||$(_0x27e968,_0x5ea5d1));}function sa(_0x3732c9,_0x1883f9){_0x3732c9['recursionDepth_']++;let _0x5849bf=!0x0;for(let _0x54aaa5=0x0;_0x54aaa5<_0x3732c9['eventLists_']['length'];_0x54aaa5++){const _0x344592=_0x3732c9['eventLists_'][_0x54aaa5];if(_0x344592){const _0x4a9ed6=_0x344592['path'];_0x1883f9(_0x4a9ed6)?(pd(_0x3732c9['eventLists_'][_0x54aaa5]),_0x3732c9['eventLists_'][_0x54aaa5]=null):_0x5849bf=!0x1;}}_0x5849bf&&(_0x3732c9['eventLists_']=[]),_0x3732c9['recursionDepth_']--;}function pd(_0x5134ca){for(let _0x55ddb9=0x0;_0x55ddb9<_0x5134ca['events']['length'];_0x55ddb9++){const _0x54a1d8=_0x5134ca['events'][_0x55ddb9];if(_0x54a1d8!==null){_0x5134ca['events'][_0x55ddb9]=null;const _0x14ed15=_0x54a1d8['getEventRunner']();Et&&L('event:\x20'+_0x54a1d8['toString']()),lt(_0x14ed15);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x23c0d9,_0x94390e,_0x17ef8,_0x4259cb){this['repoInfo_']=_0x23c0d9,this['forceRestClient_']=_0x94390e,this['authTokenProvider_']=_0x17ef8,this['appCheckProvider_']=_0x4259cb,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x454312,_0xa6e598,_0x25dcc9){if(_0x454312['stats_']=Hi(_0x454312['repoInfo_']),_0x454312['forceRestClient_']||Yl())_0x454312['server_']=new fn(_0x454312['repoInfo_'],(_0xe7a6de,_0x4dee7a,_0x36c148,_0xe6004e)=>{pr(_0x454312,_0xe7a6de,_0x4dee7a,_0x36c148,_0xe6004e);},_0x454312['authTokenProvider_'],_0x454312['appCheckProvider_']),setTimeout(()=>_r(_0x454312,!0x0),0x0);else{if(typeof _0x25dcc9<'u'&&_0x25dcc9!==null){if(typeof _0x25dcc9!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x25dcc9);}catch(_0x5a46cf){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5a46cf);}}_0x454312['persistentConnection_']=new ie(_0x454312['repoInfo_'],_0xa6e598,(_0x2935ae,_0x2e9f54,_0x21f2ff,_0x177777)=>{pr(_0x454312,_0x2935ae,_0x2e9f54,_0x21f2ff,_0x177777);},_0x43311d=>{_r(_0x454312,_0x43311d);},_0x156bc7=>{yd(_0x454312,_0x156bc7);},_0x454312['authTokenProvider_'],_0x454312['appCheckProvider_'],_0x25dcc9),_0x454312['server_']=_0x454312['persistentConnection_'];}_0x454312['authTokenProvider_']['addTokenChangeListener'](_0x494454=>{_0x454312['server_']['refreshAuthToken'](_0x494454);}),_0x454312['appCheckProvider_']['addTokenChangeListener'](_0x32146a=>{_0x454312['server_']['refreshAppCheckToken'](_0x32146a['token']);}),_0x454312['statsReporter_']=eh(_0x454312['repoInfo_'],()=>new eu(_0x454312['stats_'],_0x454312['server_'])),_0x454312['infoData_']=new Yh(),_0x454312['infoSyncTree_']=new dr({'startListening':(_0x4b44e6,_0xaa8636,_0x3b58c4,_0x318117)=>{let _0x405870=[];const _0x5ea8d7=_0x454312['infoData_']['getNode'](_0x4b44e6['_path']);return _0x5ea8d7['isEmpty']()||(_0x405870=$t(_0x454312['infoSyncTree_'],_0x4b44e6['_path'],_0x5ea8d7),setTimeout(()=>{_0x318117('ok');},0x0)),_0x405870;},'stopListening':()=>{}}),ms(_0x454312,'connected',!0x1),_0x454312['serverSyncTree_']=new dr({'startListening':(_0x89c250,_0x1b0360,_0x1e6cfe,_0x1fb17c)=>(_0x454312['server_']['listen'](_0x89c250,_0x1e6cfe,_0x1b0360,(_0x4c2ff3,_0x278f96)=>{const _0x5713d7=_0x1fb17c(_0x4c2ff3,_0x278f96);V(_0x454312['eventQueue_'],_0x89c250['_path'],_0x5713d7);}),[]),'stopListening':(_0x3bddcb,_0x312f49)=>{_0x454312['server_']['unlisten'](_0x3bddcb,_0x312f49);}});}function oa(_0x35c2f1){const _0x1e7d3d=_0x35c2f1['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1e7d3d;}function jt(_0x5938bd){return ed({'timestamp':oa(_0x5938bd)});}function pr(_0x3b630a,_0x127dda,_0x41c2af,_0x3a6b21,_0x5ae40c){_0x3b630a['dataUpdateCount']++;const _0x15b9eb=new C(_0x127dda);_0x41c2af=_0x3b630a['interceptServerDataCallback_']?_0x3b630a['interceptServerDataCallback_'](_0x127dda,_0x41c2af):_0x41c2af;let _0x347811=[];if(_0x5ae40c){if(_0x3a6b21){const _0x51d95d=ln(_0x41c2af,_0x37c6e8=>N(_0x37c6e8));_0x347811=Ku(_0x3b630a['serverSyncTree_'],_0x15b9eb,_0x51d95d,_0x5ae40c);}else{const _0x13fa46=N(_0x41c2af);_0x347811=Yo(_0x3b630a['serverSyncTree_'],_0x15b9eb,_0x13fa46,_0x5ae40c);}}else{if(_0x3a6b21){const _0x5894e3=ln(_0x41c2af,_0x2601c1=>N(_0x2601c1));_0x347811=qu(_0x3b630a['serverSyncTree_'],_0x15b9eb,_0x5894e3);}else{const _0x3c8692=N(_0x41c2af);_0x347811=$t(_0x3b630a['serverSyncTree_'],_0x15b9eb,_0x3c8692);}}let _0x48ffa9=_0x15b9eb;_0x347811['length']>0x0&&(_0x48ffa9=st(_0x3b630a,_0x15b9eb)),V(_0x3b630a['eventQueue_'],_0x48ffa9,_0x347811);}function _r(_0x721f53,_0x19fb48){ms(_0x721f53,'connected',_0x19fb48),_0x19fb48===!0x1&&wd(_0x721f53);}function yd(_0x2eb9e7,_0x2a6692){x(_0x2a6692,(_0x286949,_0x14aae9)=>{ms(_0x2eb9e7,_0x286949,_0x14aae9);});}function ms(_0x2e7a69,_0x52c8f8,_0x1796e0){const _0x27cb52=new C('/.info/'+_0x52c8f8),_0x5a334d=N(_0x1796e0);_0x2e7a69['infoData_']['updateSnapshot'](_0x27cb52,_0x5a334d);const _0x494fc1=$t(_0x2e7a69['infoSyncTree_'],_0x27cb52,_0x5a334d);V(_0x2e7a69['eventQueue_'],_0x27cb52,_0x494fc1);}function Vn(_0xa88e15){return _0xa88e15['nextWriteId_']++;}function vd(_0x166a8e,_0x4baf3c,_0x54e057){const _0x3163c5=Yu(_0x166a8e['serverSyncTree_'],_0x4baf3c);return _0x3163c5!=null?Promise['resolve'](_0x3163c5):_0x166a8e['server_']['get'](_0x4baf3c)['then'](_0x5cac2f=>{const _0x2ab4e1=N(_0x5cac2f)['withIndex'](_0x4baf3c['_queryParams']['getIndex']());bi(_0x166a8e['serverSyncTree_'],_0x4baf3c,_0x54e057,!0x0);let _0x340281;if(_0x4baf3c['_queryParams']['loadsAllData']())_0x340281=$t(_0x166a8e['serverSyncTree_'],_0x4baf3c['_path'],_0x2ab4e1);else{const _0x59fdb5=Mt(_0x166a8e['serverSyncTree_'],_0x4baf3c);_0x340281=Yo(_0x166a8e['serverSyncTree_'],_0x4baf3c['_path'],_0x2ab4e1,_0x59fdb5);}return V(_0x166a8e['eventQueue_'],_0x4baf3c['_path'],_0x340281),wn(_0x166a8e['serverSyncTree_'],_0x4baf3c,_0x54e057,null,!0x0),_0x2ab4e1;},_0x2abc29=>(ut(_0x166a8e,'get\x20for\x20query\x20'+O(_0x4baf3c)+'\x20failed:\x20'+_0x2abc29),Promise['reject'](new Error(_0x2abc29))));}function Ed(_0x10583d,_0x1416fc,_0x2ee6d4,_0x18db64,_0xefe766){ut(_0x10583d,'set',{'path':_0x1416fc['toString'](),'value':_0x2ee6d4,'priority':_0x18db64});const _0x16823d=jt(_0x10583d),_0x340e0d=N(_0x2ee6d4,_0x18db64),_0x5f2ae3=xn(_0x10583d['serverSyncTree_'],_0x1416fc),_0x2d938c=hs(_0x340e0d,_0x5f2ae3,_0x16823d),_0x44fe31=Vn(_0x10583d),_0x3b4bb1=ss(_0x10583d['serverSyncTree_'],_0x1416fc,_0x2d938c,_0x44fe31,!0x0);Bn(_0x10583d['eventQueue_'],_0x3b4bb1),_0x10583d['server_']['put'](_0x1416fc['toString'](),_0x340e0d['val'](!0x0),(_0x2cd282,_0x5aadbf)=>{const _0x4a7cea=_0x2cd282==='ok';_0x4a7cea||U('set\x20at\x20'+_0x1416fc+'\x20failed:\x20'+_0x2cd282);const _0x3d7e8e=pe(_0x10583d['serverSyncTree_'],_0x44fe31,!_0x4a7cea);V(_0x10583d['eventQueue_'],_0x1416fc,_0x3d7e8e),Ai(_0x10583d,_0xefe766,_0x2cd282,_0x5aadbf);});const _0x1c31b5=vs(_0x10583d,_0x1416fc);st(_0x10583d,_0x1c31b5),V(_0x10583d['eventQueue_'],_0x1c31b5,[]);}function Id(_0x52c8a8,_0x41d751,_0x4ae940,_0x3f6c31){ut(_0x52c8a8,'update',{'path':_0x41d751['toString'](),'value':_0x4ae940});let _0x410dc6=!0x0;const _0x583c04=jt(_0x52c8a8),_0x2ce97c={};if(x(_0x4ae940,(_0xd16228,_0x55f864)=>{_0x410dc6=!0x1,_0x2ce97c[_0xd16228]=Zo(A(_0x41d751,_0xd16228),N(_0x55f864),_0x52c8a8['serverSyncTree_'],_0x583c04);}),_0x410dc6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x52c8a8,_0x3f6c31,'ok',void 0x0);else{const _0x307246=Vn(_0x52c8a8),_0x88242=Gu(_0x52c8a8['serverSyncTree_'],_0x41d751,_0x2ce97c,_0x307246);Bn(_0x52c8a8['eventQueue_'],_0x88242),_0x52c8a8['server_']['merge'](_0x41d751['toString'](),_0x4ae940,(_0x7c8cd8,_0xdf5a09)=>{const _0x3f5f59=_0x7c8cd8==='ok';_0x3f5f59||U('update\x20at\x20'+_0x41d751+'\x20failed:\x20'+_0x7c8cd8);const _0xbcb241=pe(_0x52c8a8['serverSyncTree_'],_0x307246,!_0x3f5f59),_0x8c3533=_0xbcb241['length']>0x0?st(_0x52c8a8,_0x41d751):_0x41d751;V(_0x52c8a8['eventQueue_'],_0x8c3533,_0xbcb241),Ai(_0x52c8a8,_0x3f6c31,_0x7c8cd8,_0xdf5a09);}),x(_0x4ae940,_0x13cc2d=>{const _0x577420=vs(_0x52c8a8,A(_0x41d751,_0x13cc2d));st(_0x52c8a8,_0x577420);}),V(_0x52c8a8['eventQueue_'],_0x41d751,[]);}}function wd(_0xa2664c){ut(_0xa2664c,'onDisconnectEvents');const _0x2fad4b=jt(_0xa2664c),_0x3d3a8a=pn();Ei(_0xa2664c['onDisconnect_'],w(),(_0x30dd22,_0x48a0ca)=>{const _0x7aa77e=Zo(_0x30dd22,_0x48a0ca,_0xa2664c['serverSyncTree_'],_0x2fad4b);Mo(_0x3d3a8a,_0x30dd22,_0x7aa77e);});let _0x2fec21=[];Ei(_0x3d3a8a,w(),(_0x1e2a47,_0x57b0f1)=>{_0x2fec21=_0x2fec21['concat']($t(_0xa2664c['serverSyncTree_'],_0x1e2a47,_0x57b0f1));const _0x2d5a74=vs(_0xa2664c,_0x1e2a47);st(_0xa2664c,_0x2d5a74);}),_0xa2664c['onDisconnect_']=pn(),V(_0xa2664c['eventQueue_'],w(),_0x2fec21);}function Cd(_0x438d20,_0x12b27f,_0x411f89){let _0x1cda57;y(_0x12b27f['_path'])==='.info'?_0x1cda57=bi(_0x438d20['infoSyncTree_'],_0x12b27f,_0x411f89):_0x1cda57=bi(_0x438d20['serverSyncTree_'],_0x12b27f,_0x411f89),ia(_0x438d20['eventQueue_'],_0x12b27f['_path'],_0x1cda57);}function Td(_0x57c6d2,_0x3b496a,_0x179012){let _0x2f0fee;y(_0x3b496a['_path'])==='.info'?_0x2f0fee=wn(_0x57c6d2['infoSyncTree_'],_0x3b496a,_0x179012):_0x2f0fee=wn(_0x57c6d2['serverSyncTree_'],_0x3b496a,_0x179012),ia(_0x57c6d2['eventQueue_'],_0x3b496a['_path'],_0x2f0fee);}function aa(_0x74c6db){_0x74c6db['persistentConnection_']&&_0x74c6db['persistentConnection_']['interrupt'](ra);}function Sd(_0x2b4396){_0x2b4396['persistentConnection_']&&_0x2b4396['persistentConnection_']['resume'](ra);}function ut(_0x221e9f,..._0x1de994){let _0x439422='';_0x221e9f['persistentConnection_']&&(_0x439422=_0x221e9f['persistentConnection_']['id']+':'),L(_0x439422,..._0x1de994);}function Ai(_0x5cd52b,_0x9c4d3c,_0x43bcb4,_0x1947ab){_0x9c4d3c&&lt(()=>{if(_0x43bcb4==='ok')_0x9c4d3c(null);else{const _0xd14c71=(_0x43bcb4||'error')['toUpperCase']();let _0x1f3d22=_0xd14c71;_0x1947ab&&(_0x1f3d22+=':\x20'+_0x1947ab);const _0x12ae59=new Error(_0x1f3d22);_0x12ae59['code']=_0xd14c71,_0x9c4d3c(_0x12ae59);}});}function bd(_0x27c1c5,_0x47b7d4,_0x2f8cc9,_0x5d5c5e,_0xe1f100,_0xf13441){ut(_0x27c1c5,'transaction\x20on\x20'+_0x47b7d4);const _0x22afbe={'path':_0x47b7d4,'update':_0x2f8cc9,'onComplete':_0x5d5c5e,'status':null,'order':to(),'applyLocally':_0xf13441,'retryCount':0x0,'unwatcher':_0xe1f100,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x356482=ys(_0x27c1c5,_0x47b7d4,void 0x0);_0x22afbe['currentInputSnapshot']=_0x356482;const _0x4e1537=_0x22afbe['update'](_0x356482['val']());if(_0x4e1537===void 0x0)_0x22afbe['unwatcher'](),_0x22afbe['currentOutputSnapshotRaw']=null,_0x22afbe['currentOutputSnapshotResolved']=null,_0x22afbe['onComplete']&&_0x22afbe['onComplete'](null,!0x1,_0x22afbe['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x4e1537,_0x22afbe['path']),_0x22afbe['status']=0x0;const _0x502b51=Un(_0x27c1c5['transactionQueueTree_'],_0x47b7d4),_0x5187a2=Ge(_0x502b51)||[];_0x5187a2['push'](_0x22afbe),fs(_0x502b51,_0x5187a2);let _0x1a6090;typeof _0x4e1537=='object'&&_0x4e1537!==null&&Y(_0x4e1537,'.priority')?(_0x1a6090=Oe(_0x4e1537,'.priority'),f(Cn(_0x1a6090),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1a6090=(xn(_0x27c1c5['serverSyncTree_'],_0x47b7d4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5c04c6=jt(_0x27c1c5),_0x2f98cd=N(_0x4e1537,_0x1a6090),_0xe5f81e=hs(_0x2f98cd,_0x356482,_0x5c04c6);_0x22afbe['currentOutputSnapshotRaw']=_0x2f98cd,_0x22afbe['currentOutputSnapshotResolved']=_0xe5f81e,_0x22afbe['currentWriteId']=Vn(_0x27c1c5);const _0x4a54c4=ss(_0x27c1c5['serverSyncTree_'],_0x47b7d4,_0xe5f81e,_0x22afbe['currentWriteId'],_0x22afbe['applyLocally']);V(_0x27c1c5['eventQueue_'],_0x47b7d4,_0x4a54c4),Hn(_0x27c1c5,_0x27c1c5['transactionQueueTree_']);}}function ys(_0xeb02d9,_0xcc9288,_0x10436a){return xn(_0xeb02d9['serverSyncTree_'],_0xcc9288,_0x10436a)||g['EMPTY_NODE'];}function Hn(_0x287867,_0x437974=_0x287867['transactionQueueTree_']){if(_0x437974||$n(_0x287867,_0x437974),Ge(_0x437974)){const _0x207a75=la(_0x287867,_0x437974);f(_0x207a75['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x207a75['every'](_0x28f1c3=>_0x28f1c3['status']===0x0)&&Rd(_0x287867,Gt(_0x437974),_0x207a75);}else ea(_0x437974)&&Wn(_0x437974,_0x22ec0b=>{Hn(_0x287867,_0x22ec0b);});}function Rd(_0x5df350,_0x3d5031,_0x3dab0c){const _0xb3f80f=_0x3dab0c['map'](_0xdf73d9=>_0xdf73d9['currentWriteId']),_0xfff5c9=ys(_0x5df350,_0x3d5031,_0xb3f80f);let _0x5986fa=_0xfff5c9;const _0x40dd58=_0xfff5c9['hash']();for(let _0x3a408b=0x0;_0x3a408b<_0x3dab0c['length'];_0x3a408b++){const _0x40eeb0=_0x3dab0c[_0x3a408b];f(_0x40eeb0['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x40eeb0['status']=0x1,_0x40eeb0['retryCount']++;const _0x530bc7=F(_0x3d5031,_0x40eeb0['path']);_0x5986fa=_0x5986fa['updateChild'](_0x530bc7,_0x40eeb0['currentOutputSnapshotRaw']);}const _0x47c367=_0x5986fa['val'](!0x0),_0x5a221c=_0x3d5031;_0x5df350['server_']['put'](_0x5a221c['toString'](),_0x47c367,_0x4f6802=>{ut(_0x5df350,'transaction\x20put\x20response',{'path':_0x5a221c['toString'](),'status':_0x4f6802});let _0x29308d=[];if(_0x4f6802==='ok'){const _0x1a7b3a=[];for(let _0x4a3681=0x0;_0x4a3681<_0x3dab0c['length'];_0x4a3681++)_0x3dab0c[_0x4a3681]['status']=0x2,_0x29308d=_0x29308d['concat'](pe(_0x5df350['serverSyncTree_'],_0x3dab0c[_0x4a3681]['currentWriteId'])),_0x3dab0c[_0x4a3681]['onComplete']&&_0x1a7b3a['push'](()=>_0x3dab0c[_0x4a3681]['onComplete'](null,!0x0,_0x3dab0c[_0x4a3681]['currentOutputSnapshotResolved'])),_0x3dab0c[_0x4a3681]['unwatcher']();$n(_0x5df350,Un(_0x5df350['transactionQueueTree_'],_0x3d5031)),Hn(_0x5df350,_0x5df350['transactionQueueTree_']),V(_0x5df350['eventQueue_'],_0x3d5031,_0x29308d);for(let _0x5122f2=0x0;_0x5122f2<_0x1a7b3a['length'];_0x5122f2++)lt(_0x1a7b3a[_0x5122f2]);}else{if(_0x4f6802==='datastale'){for(let _0x86fe67=0x0;_0x86fe67<_0x3dab0c['length'];_0x86fe67++)_0x3dab0c[_0x86fe67]['status']===0x3?_0x3dab0c[_0x86fe67]['status']=0x4:_0x3dab0c[_0x86fe67]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5a221c['toString']()+'\x20failed:\x20'+_0x4f6802);for(let _0x29a21f=0x0;_0x29a21f<_0x3dab0c['length'];_0x29a21f++)_0x3dab0c[_0x29a21f]['status']=0x4,_0x3dab0c[_0x29a21f]['abortReason']=_0x4f6802;}st(_0x5df350,_0x3d5031);}},_0x40dd58);}function st(_0x257e61,_0x19d3ce){const _0x174da5=ca(_0x257e61,_0x19d3ce),_0x47cb31=Gt(_0x174da5),_0x3dae1e=la(_0x257e61,_0x174da5);return Ad(_0x257e61,_0x3dae1e,_0x47cb31),_0x47cb31;}function Ad(_0x5c3bca,_0x51a0f6,_0x1c03bb){if(_0x51a0f6['length']===0x0)return;const _0x420da3=[];let _0x3d4fb5=[];const _0x158a14=_0x51a0f6['filter'](_0x244070=>_0x244070['status']===0x0)['map'](_0x5df043=>_0x5df043['currentWriteId']);for(let _0x1e9182=0x0;_0x1e9182<_0x51a0f6['length'];_0x1e9182++){const _0x32c1d7=_0x51a0f6[_0x1e9182],_0x240cc1=F(_0x1c03bb,_0x32c1d7['path']);let _0x3d2a65=!0x1,_0x48186d;if(f(_0x240cc1!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x32c1d7['status']===0x4)_0x3d2a65=!0x0,_0x48186d=_0x32c1d7['abortReason'],_0x3d4fb5=_0x3d4fb5['concat'](pe(_0x5c3bca['serverSyncTree_'],_0x32c1d7['currentWriteId'],!0x0));else{if(_0x32c1d7['status']===0x0){if(_0x32c1d7['retryCount']>=_d)_0x3d2a65=!0x0,_0x48186d='maxretry',_0x3d4fb5=_0x3d4fb5['concat'](pe(_0x5c3bca['serverSyncTree_'],_0x32c1d7['currentWriteId'],!0x0));else{const _0x35ab2c=ys(_0x5c3bca,_0x32c1d7['path'],_0x158a14);_0x32c1d7['currentInputSnapshot']=_0x35ab2c;const _0x83039a=_0x51a0f6[_0x1e9182]['update'](_0x35ab2c['val']());if(_0x83039a!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x83039a,_0x32c1d7['path']);let _0x1bd6b6=N(_0x83039a);typeof _0x83039a=='object'&&_0x83039a!=null&&Y(_0x83039a,'.priority')||(_0x1bd6b6=_0x1bd6b6['updatePriority'](_0x35ab2c['getPriority']()));const _0x5d0eb3=_0x32c1d7['currentWriteId'],_0x538c23=jt(_0x5c3bca),_0x22dec2=hs(_0x1bd6b6,_0x35ab2c,_0x538c23);_0x32c1d7['currentOutputSnapshotRaw']=_0x1bd6b6,_0x32c1d7['currentOutputSnapshotResolved']=_0x22dec2,_0x32c1d7['currentWriteId']=Vn(_0x5c3bca),_0x158a14['splice'](_0x158a14['indexOf'](_0x5d0eb3),0x1),_0x3d4fb5=_0x3d4fb5['concat'](ss(_0x5c3bca['serverSyncTree_'],_0x32c1d7['path'],_0x22dec2,_0x32c1d7['currentWriteId'],_0x32c1d7['applyLocally'])),_0x3d4fb5=_0x3d4fb5['concat'](pe(_0x5c3bca['serverSyncTree_'],_0x5d0eb3,!0x0));}else _0x3d2a65=!0x0,_0x48186d='nodata',_0x3d4fb5=_0x3d4fb5['concat'](pe(_0x5c3bca['serverSyncTree_'],_0x32c1d7['currentWriteId'],!0x0));}}}V(_0x5c3bca['eventQueue_'],_0x1c03bb,_0x3d4fb5),_0x3d4fb5=[],_0x3d2a65&&(_0x51a0f6[_0x1e9182]['status']=0x2,function(_0x531675){setTimeout(_0x531675,Math['floor'](0x0));}(_0x51a0f6[_0x1e9182]['unwatcher']),_0x51a0f6[_0x1e9182]['onComplete']&&(_0x48186d==='nodata'?_0x420da3['push'](()=>_0x51a0f6[_0x1e9182]['onComplete'](null,!0x1,_0x51a0f6[_0x1e9182]['currentInputSnapshot'])):_0x420da3['push'](()=>_0x51a0f6[_0x1e9182]['onComplete'](new Error(_0x48186d),!0x1,null))));}$n(_0x5c3bca,_0x5c3bca['transactionQueueTree_']);for(let _0xf0eac6=0x0;_0xf0eac6<_0x420da3['length'];_0xf0eac6++)lt(_0x420da3[_0xf0eac6]);Hn(_0x5c3bca,_0x5c3bca['transactionQueueTree_']);}function ca(_0x23a1de,_0x5bbfe3){let _0x3db635,_0x229c57=_0x23a1de['transactionQueueTree_'];for(_0x3db635=y(_0x5bbfe3);_0x3db635!==null&&Ge(_0x229c57)===void 0x0;)_0x229c57=Un(_0x229c57,_0x3db635),_0x5bbfe3=b(_0x5bbfe3),_0x3db635=y(_0x5bbfe3);return _0x229c57;}function la(_0x50c280,_0x2ac969){const _0x4f980e=[];return ha(_0x50c280,_0x2ac969,_0x4f980e),_0x4f980e['sort']((_0x368237,_0x4183dd)=>_0x368237['order']-_0x4183dd['order']),_0x4f980e;}function ha(_0x279c37,_0x158183,_0x36fe69){const _0x10360e=Ge(_0x158183);if(_0x10360e){for(let _0xb1fa9f=0x0;_0xb1fa9f<_0x10360e['length'];_0xb1fa9f++)_0x36fe69['push'](_0x10360e[_0xb1fa9f]);}Wn(_0x158183,_0x1ab7a2=>{ha(_0x279c37,_0x1ab7a2,_0x36fe69);});}function $n(_0x3b7701,_0x3b158c){const _0x49f6ea=Ge(_0x3b158c);if(_0x49f6ea){let _0x554173=0x0;for(let _0x4f1c18=0x0;_0x4f1c18<_0x49f6ea['length'];_0x4f1c18++)_0x49f6ea[_0x4f1c18]['status']!==0x2&&(_0x49f6ea[_0x554173]=_0x49f6ea[_0x4f1c18],_0x554173++);_0x49f6ea['length']=_0x554173,fs(_0x3b158c,_0x49f6ea['length']>0x0?_0x49f6ea:void 0x0);}Wn(_0x3b158c,_0x5f2f9=>{$n(_0x3b7701,_0x5f2f9);});}function vs(_0x4d52a2,_0x1c6060){const _0x59b8a2=Gt(ca(_0x4d52a2,_0x1c6060)),_0xfb36eb=Un(_0x4d52a2['transactionQueueTree_'],_0x1c6060);return sd(_0xfb36eb,_0x468a82=>{ai(_0x4d52a2,_0x468a82);}),ai(_0x4d52a2,_0xfb36eb),ta(_0xfb36eb,_0x52f850=>{ai(_0x4d52a2,_0x52f850);}),_0x59b8a2;}function ai(_0xb74b2b,_0x3e2a8e){const _0x37213d=Ge(_0x3e2a8e);if(_0x37213d){const _0x49e403=[];let _0x34bfaf=[],_0x1e95b6=-0x1;for(let _0x233304=0x0;_0x233304<_0x37213d['length'];_0x233304++)_0x37213d[_0x233304]['status']===0x3||(_0x37213d[_0x233304]['status']===0x1?(f(_0x1e95b6===_0x233304-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1e95b6=_0x233304,_0x37213d[_0x233304]['status']=0x3,_0x37213d[_0x233304]['abortReason']='set'):(f(_0x37213d[_0x233304]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x37213d[_0x233304]['unwatcher'](),_0x34bfaf=_0x34bfaf['concat'](pe(_0xb74b2b['serverSyncTree_'],_0x37213d[_0x233304]['currentWriteId'],!0x0)),_0x37213d[_0x233304]['onComplete']&&_0x49e403['push'](_0x37213d[_0x233304]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1e95b6===-0x1?fs(_0x3e2a8e,void 0x0):_0x37213d['length']=_0x1e95b6+0x1,V(_0xb74b2b['eventQueue_'],Gt(_0x3e2a8e),_0x34bfaf);for(let _0x1e9b0b=0x0;_0x1e9b0b<_0x49e403['length'];_0x1e9b0b++)lt(_0x49e403[_0x1e9b0b]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x2c88ba){let _0x21d4a0='';const _0x2215e5=_0x2c88ba['split']('/');for(let _0x12f1c4=0x0;_0x12f1c4<_0x2215e5['length'];_0x12f1c4++)if(_0x2215e5[_0x12f1c4]['length']>0x0){let _0x10f0d7=_0x2215e5[_0x12f1c4];try{_0x10f0d7=decodeURIComponent(_0x10f0d7['replace'](/\+/g,'\x20'));}catch{}_0x21d4a0+='/'+_0x10f0d7;}return _0x21d4a0;}function Nd(_0x25b008){const _0x2d86bc={};_0x25b008['charAt'](0x0)==='?'&&(_0x25b008=_0x25b008['substring'](0x1));for(const _0x55a548 of _0x25b008['split']('&')){if(_0x55a548['length']===0x0)continue;const _0x43df9f=_0x55a548['split']('=');_0x43df9f['length']===0x2?_0x2d86bc[decodeURIComponent(_0x43df9f[0x0])]=decodeURIComponent(_0x43df9f[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x55a548+'\x27\x20in\x20query\x20\x27'+_0x25b008+'\x27');}return _0x2d86bc;}const gr=function(_0x2860c1,_0x5abc95){const _0x585507=Pd(_0x2860c1),_0x5e60f9=_0x585507['namespace'];_0x585507['domain']==='firebase.com'&&oe(_0x585507['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5e60f9||_0x5e60f9==='undefined')&&_0x585507['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x585507['secure']||Bl();const _0x30f583=_0x585507['scheme']==='ws'||_0x585507['scheme']==='wss';return{'repoInfo':new _o(_0x585507['host'],_0x585507['secure'],_0x5e60f9,_0x30f583,_0x5abc95,'',_0x5e60f9!==_0x585507['subdomain']),'path':new C(_0x585507['pathString'])};},Pd=function(_0x3c7aa3){let _0x5b6680='',_0x5e942c='',_0x5e91a4='',_0x421d70='',_0x1b65de='',_0x202665=!0x0,_0x3feb66='https',_0x11d643=0x1bb;if(typeof _0x3c7aa3=='string'){let _0x3ef22c=_0x3c7aa3['indexOf']('//');_0x3ef22c>=0x0&&(_0x3feb66=_0x3c7aa3['substring'](0x0,_0x3ef22c-0x1),_0x3c7aa3=_0x3c7aa3['substring'](_0x3ef22c+0x2));let _0x2c9dfc=_0x3c7aa3['indexOf']('/');_0x2c9dfc===-0x1&&(_0x2c9dfc=_0x3c7aa3['length']);let _0x34336a=_0x3c7aa3['indexOf']('?');_0x34336a===-0x1&&(_0x34336a=_0x3c7aa3['length']),_0x5b6680=_0x3c7aa3['substring'](0x0,Math['min'](_0x2c9dfc,_0x34336a)),_0x2c9dfc<_0x34336a&&(_0x421d70=kd(_0x3c7aa3['substring'](_0x2c9dfc,_0x34336a)));const _0x1d83c2=Nd(_0x3c7aa3['substring'](Math['min'](_0x3c7aa3['length'],_0x34336a)));_0x3ef22c=_0x5b6680['indexOf'](':'),_0x3ef22c>=0x0?(_0x202665=_0x3feb66==='https'||_0x3feb66==='wss',_0x11d643=parseInt(_0x5b6680['substring'](_0x3ef22c+0x1),0xa)):_0x3ef22c=_0x5b6680['length'];const _0x46cf97=_0x5b6680['slice'](0x0,_0x3ef22c);if(_0x46cf97['toLowerCase']()==='localhost')_0x5e942c='localhost';else{if(_0x46cf97['split']('.')['length']<=0x2)_0x5e942c=_0x46cf97;else{const _0x14fb82=_0x5b6680['indexOf']('.');_0x5e91a4=_0x5b6680['substring'](0x0,_0x14fb82)['toLowerCase'](),_0x5e942c=_0x5b6680['substring'](_0x14fb82+0x1),_0x1b65de=_0x5e91a4;}}'ns'in _0x1d83c2&&(_0x1b65de=_0x1d83c2['ns']);}return{'host':_0x5b6680,'port':_0x11d643,'domain':_0x5e942c,'subdomain':_0x5e91a4,'secure':_0x202665,'scheme':_0x3feb66,'pathString':_0x421d70,'namespace':_0x1b65de};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x363395=0x0;const _0x10303c=[];return function(_0x52e116){const _0xfc0c07=_0x52e116===_0x363395;_0x363395=_0x52e116;let _0x39cc51;const _0x2eb7bc=new Array(0x8);for(_0x39cc51=0x7;_0x39cc51>=0x0;_0x39cc51--)_0x2eb7bc[_0x39cc51]=mr['charAt'](_0x52e116%0x40),_0x52e116=Math['floor'](_0x52e116/0x40);f(_0x52e116===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x20ba7e=_0x2eb7bc['join']('');if(_0xfc0c07){for(_0x39cc51=0xb;_0x39cc51>=0x0&&_0x10303c[_0x39cc51]===0x3f;_0x39cc51--)_0x10303c[_0x39cc51]=0x0;_0x10303c[_0x39cc51]++;}else{for(_0x39cc51=0x0;_0x39cc51<0xc;_0x39cc51++)_0x10303c[_0x39cc51]=Math['floor'](Math['random']()*0x40);}for(_0x39cc51=0x0;_0x39cc51<0xc;_0x39cc51++)_0x20ba7e+=mr['charAt'](_0x10303c[_0x39cc51]);return f(_0x20ba7e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x20ba7e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x40dc6d,_0x293cd6,_0x468eeb,_0x443486){this['eventType']=_0x40dc6d,this['eventRegistration']=_0x293cd6,this['snapshot']=_0x468eeb,this['prevName']=_0x443486;}['getPath'](){const _0x3ea027=this['snapshot']['ref'];return this['eventType']==='value'?_0x3ea027['_path']:_0x3ea027['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x579a02,_0x5b90e4,_0x269f8f){this['eventRegistration']=_0x579a02,this['error']=_0x5b90e4,this['path']=_0x269f8f;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x1ded2c,_0x4d85de){this['snapshotCallback']=_0x1ded2c,this['cancelCallback']=_0x4d85de;}['onValue'](_0xb48b9f,_0x2938ac){this['snapshotCallback']['call'](null,_0xb48b9f,_0x2938ac);}['onCancel'](_0x4df1ab){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4df1ab);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1d9453){return this['snapshotCallback']===_0x1d9453['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1d9453['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1d9453['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5aa9b5,_0x2fb236,_0x1c46e5,_0x1a5bdb){this['_repo']=_0x5aa9b5,this['_path']=_0x2fb236,this['_queryParams']=_0x1c46e5,this['_orderByCalled']=_0x1a5bdb;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4d2987=nr(this['_queryParams']),_0x5805be=Bi(_0x4d2987);return _0x5805be==='{}'?'default':_0x5805be;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x47c63a){if(_0x47c63a=k(_0x47c63a),!(_0x47c63a instanceof be))return!0x1;const _0x2e6e76=this['_repo']===_0x47c63a['_repo'],_0x258463=qi(this['_path'],_0x47c63a['_path']),_0x14642e=this['_queryIdentifier']===_0x47c63a['_queryIdentifier'];return _0x2e6e76&&_0x258463&&_0x14642e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x107286,_0xd226dc){if(_0x107286['_orderByCalled']===!0x0)throw new Error(_0xd226dc+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3880fa){let _0x33a8bb=null,_0x17599f=null;if(_0x3880fa['hasStart']()&&(_0x33a8bb=_0x3880fa['getIndexStartValue']()),_0x3880fa['hasEnd']()&&(_0x17599f=_0x3880fa['getIndexEndValue']()),_0x3880fa['getIndex']()===ye){const _0x336e49='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x24fe2c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3880fa['hasStart']()){if(_0x3880fa['getIndexStartName']()!==xe)throw new Error(_0x336e49);if(typeof _0x33a8bb!='string')throw new Error(_0x24fe2c);}if(_0x3880fa['hasEnd']()){if(_0x3880fa['getIndexEndName']()!==Ie)throw new Error(_0x336e49);if(typeof _0x17599f!='string')throw new Error(_0x24fe2c);}}else{if(_0x3880fa['getIndex']()===R){if(_0x33a8bb!=null&&!Cn(_0x33a8bb)||_0x17599f!=null&&!Cn(_0x17599f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3880fa['getIndex']()instanceof Ki||_0x3880fa['getIndex']()===Po,'unknown\x20index\x20type.'),_0x33a8bb!=null&&typeof _0x33a8bb=='object'||_0x17599f!=null&&typeof _0x17599f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x4bb910){if(_0x4bb910['hasStart']()&&_0x4bb910['hasEnd']()&&_0x4bb910['hasLimit']()&&!_0x4bb910['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x59dffd,_0x6e1e44){super(_0x59dffd,_0x6e1e44,new Qi(),!0x1);}get['parent'](){const _0x5d2587=To(this['_path']);return _0x5d2587===null?null:new Z(this['_repo'],_0x5d2587);}get['root'](){let _0x4e64ac=this;for(;_0x4e64ac['parent']!==null;)_0x4e64ac=_0x4e64ac['parent'];return _0x4e64ac;}}class rt{constructor(_0xe5398b,_0x232185,_0x2dbf17){this['_node']=_0xe5398b,this['ref']=_0x232185,this['_index']=_0x2dbf17;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x58c4b2){const _0x5154de=new C(_0x58c4b2),_0xe1f593=Lt(this['ref'],_0x58c4b2);return new rt(this['_node']['getChild'](_0x5154de),_0xe1f593,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x412a96){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x342bb2,_0x1ac8ff)=>_0x412a96(new rt(_0x1ac8ff,Lt(this['ref'],_0x342bb2),R)));}['hasChild'](_0x156681){const _0x1c2d92=new C(_0x156681);return!this['_node']['getChild'](_0x1c2d92)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x3603cc,_0x5a7d7e){return _0x3603cc=k(_0x3603cc),_0x3603cc['_checkNotDeleted']('ref'),_0x5a7d7e!==void 0x0?Lt(_0x3603cc['_root'],_0x5a7d7e):_0x3603cc['_root'];}function Lt(_0x10b921,_0x2dbeb6){return _0x10b921=k(_0x10b921),y(_0x10b921['_path'])===null?ud('child','path',_0x2dbeb6):_s('child','path',_0x2dbeb6),new Z(_0x10b921['_repo'],A(_0x10b921['_path'],_0x2dbeb6));}function d_(_0x38579e,_0x4a202c){_0x38579e=k(_0x38579e),gs('push',_0x38579e['_path']),qt('push',_0x4a202c,_0x38579e['_path'],!0x0);const _0x51bce7=oa(_0x38579e['_repo']),_0x1bc2ca=Od(_0x51bce7),_0xaff8fe=Lt(_0x38579e,_0x1bc2ca),_0x2941e5=Lt(_0x38579e,_0x1bc2ca);let _0x530ef1;return _0x4a202c!=null?_0x530ef1=Ld(_0x2941e5,_0x4a202c)['then'](()=>_0x2941e5):_0x530ef1=Promise['resolve'](_0x2941e5),_0xaff8fe['then']=_0x530ef1['then']['bind'](_0x530ef1),_0xaff8fe['catch']=_0x530ef1['then']['bind'](_0x530ef1,void 0x0),_0xaff8fe;}function Ld(_0x16774d,_0x2ec47b){_0x16774d=k(_0x16774d),gs('set',_0x16774d['_path']),qt('set',_0x2ec47b,_0x16774d['_path'],!0x1);const _0xd0ad2c=new Ve();return Ed(_0x16774d['_repo'],_0x16774d['_path'],_0x2ec47b,null,_0xd0ad2c['wrapCallback'](()=>{})),_0xd0ad2c['promise'];}function f_(_0x3512a2,_0xe684c4){hd('update',_0xe684c4,_0x3512a2['_path']);const _0x488745=new Ve();return Id(_0x3512a2['_repo'],_0x3512a2['_path'],_0xe684c4,_0x488745['wrapCallback'](()=>{})),_0x488745['promise'];}function p_(_0x5502e2){_0x5502e2=k(_0x5502e2);const _0x2ea581=new ua(()=>{}),_0x3dd9e7=new qn(_0x2ea581);return vd(_0x5502e2['_repo'],_0x5502e2,_0x3dd9e7)['then'](_0x1e444e=>new rt(_0x1e444e,new Z(_0x5502e2['_repo'],_0x5502e2['_path']),_0x5502e2['_queryParams']['getIndex']()));}class qn{constructor(_0xff3d97){this['callbackContext']=_0xff3d97;}['respondsTo'](_0x310260){return _0x310260==='value';}['createEvent'](_0xa4ff0d,_0xf2aaf5){const _0x177f26=_0xf2aaf5['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0xa4ff0d['snapshotNode'],new Z(_0xf2aaf5['_repo'],_0xf2aaf5['_path']),_0x177f26));}['getEventRunner'](_0x369dbc){return _0x369dbc['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x369dbc['error']):()=>this['callbackContext']['onValue'](_0x369dbc['snapshot'],null);}['createCancelEvent'](_0x50de94,_0x5a31db){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x50de94,_0x5a31db):null;}['matches'](_0x1e8fdb){return _0x1e8fdb instanceof qn?!_0x1e8fdb['callbackContext']||!this['callbackContext']?!0x0:_0x1e8fdb['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x2c4d16,_0x4d45a1,_0x1c2335,_0x16baad,_0x17fa7b){const _0xf3e5d3=new ua(_0x1c2335,void 0x0),_0x5a1578=new qn(_0xf3e5d3);return Cd(_0x2c4d16['_repo'],_0x2c4d16,_0x5a1578),()=>Td(_0x2c4d16['_repo'],_0x2c4d16,_0x5a1578);}function Fd(_0x1daa35,_0x5ec7bf,_0x42b093,_0x51ace3){return xd(_0x1daa35,'value',_0x5ec7bf);}class dt{}class pa extends dt{constructor(_0x4fab59,_0x1d02c5){super(),this['_value']=_0x4fab59,this['_key']=_0x1d02c5,this['type']='endAt';}['_apply'](_0x35db49){qt('endAt',this['_value'],_0x35db49['_path'],!0x0);const _0x25a3fd=Kh(_0x35db49['_queryParams'],this['_value'],this['_key']);if(fa(_0x25a3fd),Gn(_0x25a3fd),_0x35db49['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x35db49['_repo'],_0x35db49['_path'],_0x25a3fd,_0x35db49['_orderByCalled']);}}function __(_0x43e09d,_0x24ac2a){return new pa(_0x43e09d,_0x24ac2a);}class _a extends dt{constructor(_0x557128,_0x4cabe3){super(),this['_value']=_0x557128,this['_key']=_0x4cabe3,this['type']='startAt';}['_apply'](_0x392ab2){qt('startAt',this['_value'],_0x392ab2['_path'],!0x0);const _0x40f8b5=jh(_0x392ab2['_queryParams'],this['_value'],this['_key']);if(fa(_0x40f8b5),Gn(_0x40f8b5),_0x392ab2['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x392ab2['_repo'],_0x392ab2['_path'],_0x40f8b5,_0x392ab2['_orderByCalled']);}}function g_(_0x28c4cb=null,_0x47f00a){return new _a(_0x28c4cb,_0x47f00a);}class Ud extends dt{constructor(_0x1b1935){super(),this['_limit']=_0x1b1935,this['type']='limitToFirst';}['_apply'](_0x58849e){if(_0x58849e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x58849e['_repo'],_0x58849e['_path'],zh(_0x58849e['_queryParams'],this['_limit']),_0x58849e['_orderByCalled']);}}function m_(_0x2408a5){if(Math['floor'](_0x2408a5)!==_0x2408a5||_0x2408a5<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x2408a5);}class Wd extends dt{constructor(_0x3767f0){super(),this['_path']=_0x3767f0,this['type']='orderByChild';}['_apply'](_0x2a4109){da(_0x2a4109,'orderByChild');const _0x2d6eac=new C(this['_path']);if(v(_0x2d6eac))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x173dee=new Ki(_0x2d6eac),_0x4e71ef=Do(_0x2a4109['_queryParams'],_0x173dee);return Gn(_0x4e71ef),new be(_0x2a4109['_repo'],_0x2a4109['_path'],_0x4e71ef,!0x0);}}function y_(_0xab99bc){if(_0xab99bc==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xab99bc==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xab99bc==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0xab99bc),new Wd(_0xab99bc);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x10f798){da(_0x10f798,'orderByKey');const _0x60a44b=Do(_0x10f798['_queryParams'],ye);return Gn(_0x60a44b),new be(_0x10f798['_repo'],_0x10f798['_path'],_0x60a44b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x3f65f2,_0x5863b8){super(),this['_value']=_0x3f65f2,this['_key']=_0x5863b8,this['type']='equalTo';}['_apply'](_0x4f7e3b){if(qt('equalTo',this['_value'],_0x4f7e3b['_path'],!0x1),_0x4f7e3b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4f7e3b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x4f7e3b));}}function E_(_0x6bb475,_0x5ae20b){return new Vd(_0x6bb475,_0x5ae20b);}function I_(_0x267134,..._0x2313ea){let _0x2ab83e=k(_0x267134);for(const _0xc4a1bc of _0x2313ea)_0x2ab83e=_0xc4a1bc['_apply'](_0x2ab83e);return _0x2ab83e;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x558a63,_0x540e50,_0x13a7d3,_0x3ecdb6){const _0x138f07=_0x540e50['lastIndexOf'](':'),_0x30a6ab=_0x540e50['substring'](0x0,_0x138f07),_0x5c3908=Wt(_0x30a6ab);_0x558a63['repoInfo_']=new _o(_0x540e50,_0x5c3908,_0x558a63['repoInfo_']['namespace'],_0x558a63['repoInfo_']['webSocketOnly'],_0x558a63['repoInfo_']['nodeAdmin'],_0x558a63['repoInfo_']['persistenceKey'],_0x558a63['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x13a7d3),_0x3ecdb6&&(_0x558a63['authTokenProvider_']=_0x3ecdb6);}function qd(_0x5801c1,_0x404224,_0x3cb212,_0x16cbf7,_0x2bed25){let _0x4f04f8=_0x16cbf7||_0x5801c1['options']['databaseURL'];_0x4f04f8===void 0x0&&(_0x5801c1['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5801c1['options']['projectId']),_0x4f04f8=_0x5801c1['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x293693=gr(_0x4f04f8,_0x2bed25),_0x230d69=_0x293693['repoInfo'],_0x2fa929;typeof process<'u'&&Us&&(_0x2fa929=Us[Hd]),_0x2fa929?(_0x4f04f8='http://'+_0x2fa929+'?ns='+_0x230d69['namespace'],_0x293693=gr(_0x4f04f8,_0x2bed25),_0x230d69=_0x293693['repoInfo']):_0x293693['repoInfo']['secure'];const _0x1b54b6=new Jl(_0x5801c1['name'],_0x5801c1['options'],_0x404224);dd('Invalid\x20Firebase\x20Database\x20URL',_0x293693),v(_0x293693['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x7ded33=jd(_0x230d69,_0x5801c1,_0x1b54b6,new Ql(_0x5801c1,_0x3cb212));return new Kd(_0x7ded33,_0x5801c1);}function zd(_0x9f811,_0x5be674){const _0x29af55=ki[_0x5be674];(!_0x29af55||_0x29af55[_0x9f811['key']]!==_0x9f811)&&oe('Database\x20'+_0x5be674+'('+_0x9f811['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x9f811),delete _0x29af55[_0x9f811['key']];}function jd(_0x3f1364,_0x445328,_0x7e07ed,_0x1ea7a2){let _0x439a11=ki[_0x445328['name']];_0x439a11||(_0x439a11={},ki[_0x445328['name']]=_0x439a11);let _0x55e81d=_0x439a11[_0x3f1364['toURLString']()];return _0x55e81d&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x55e81d=new gd(_0x3f1364,$d,_0x7e07ed,_0x1ea7a2),_0x439a11[_0x3f1364['toURLString']()]=_0x55e81d,_0x55e81d;}class Kd{constructor(_0xba5b0d,_0x18e258){this['_repoInternal']=_0xba5b0d,this['app']=_0x18e258,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1aa9f1){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1aa9f1+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1e4d3=Qr(),_0x251296){const _0x2f3a7c=Ui(_0x1e4d3,'database')['getImmediate']({'identifier':_0x251296});if(!_0x2f3a7c['_instanceStarted']){const _0x455b2d=ac('database');_0x455b2d&&Yd(_0x2f3a7c,..._0x455b2d);}return _0x2f3a7c;}function Yd(_0x1e6982,_0x4c88e0,_0x5c0562,_0x553253={}){_0x1e6982=k(_0x1e6982),_0x1e6982['_checkNotDeleted']('useEmulator');const _0x392063=_0x4c88e0+':'+_0x5c0562,_0x1dd3a6=_0x1e6982['_repoInternal'];if(_0x1e6982['_instanceStarted']){if(_0x392063===_0x1e6982['_repoInternal']['repoInfo_']['host']&&De(_0x553253,_0x1dd3a6['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xc99e88;if(_0x1dd3a6['repoInfo_']['nodeAdmin'])_0x553253['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xc99e88=new tn(tn['OWNER']);else{if(_0x553253['mockUserToken']){const _0x27baca=typeof _0x553253['mockUserToken']=='string'?_0x553253['mockUserToken']:cc(_0x553253['mockUserToken'],_0x1e6982['app']['options']['projectId']);_0xc99e88=new tn(_0x27baca);}}Wt(_0x4c88e0)&&jr(_0x4c88e0),Gd(_0x1dd3a6,_0x392063,_0x553253,_0xc99e88);}function C_(_0x9cbedb){_0x9cbedb=k(_0x9cbedb),_0x9cbedb['_checkNotDeleted']('goOffline'),aa(_0x9cbedb['_repo']);}function T_(_0x3312bf){_0x3312bf=k(_0x3312bf),_0x3312bf['_checkNotDeleted']('goOnline'),Sd(_0x3312bf['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4af75c){Ll(ct),et(new Me('database',(_0x28a4c0,{instanceIdentifier:_0x5f2b9e})=>{const _0x4380de=_0x28a4c0['getProvider']('app')['getImmediate'](),_0x218974=_0x28a4c0['getProvider']('auth-internal'),_0x2209f6=_0x28a4c0['getProvider']('app-check-internal');return qd(_0x4380de,_0x218974,_0x2209f6,_0x5f2b9e);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4af75c),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x20163a,_0x35ba9c){this['committed']=_0x20163a,this['snapshot']=_0x35ba9c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x37de1b,_0x37ce2b,_0xc8c210){if(_0x37de1b=k(_0x37de1b),gs('Reference.transaction',_0x37de1b['_path']),_0x37de1b['key']==='.length'||_0x37de1b['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x37de1b['key']+'\x20is\x20a\x20read-only\x20object.';const _0x535aaa=!0x0,_0x273d58=new Ve(),_0x424994=(_0x46b30d,_0x2ddc7b,_0x38ea03)=>{let _0x560f97=null;_0x46b30d?_0x273d58['reject'](_0x46b30d):(_0x560f97=new rt(_0x38ea03,new Z(_0x37de1b['_repo'],_0x37de1b['_path']),R),_0x273d58['resolve'](new Xd(_0x2ddc7b,_0x560f97)));},_0x1f1ebc=Fd(_0x37de1b,()=>{});return bd(_0x37de1b['_repo'],_0x37de1b['_path'],_0x37ce2b,_0x424994,_0x1f1ebc,_0x535aaa),_0x273d58['promise'];}ie['prototype']['simpleListen']=function(_0x1acbfb,_0x11aed4){this['sendRequest']('q',{'p':_0x1acbfb},_0x11aed4);},ie['prototype']['echo']=function(_0x1db6d7,_0x3de1d1){this['sendRequest']('echo',{'d':_0x1db6d7},_0x3de1d1);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1db310,..._0x5b720a){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1db310,..._0x5b720a);}function nn(_0x9bb990,..._0x1d8ea2){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x9bb990,..._0x1d8ea2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5d927c,..._0x47b653){throw Es(_0x5d927c,..._0x47b653);}function J(_0x3ec4a6,..._0x462da9){return Es(_0x3ec4a6,..._0x462da9);}function ya(_0x577567,_0x26d3bf,_0x2b57f3){const _0x10528f={...Zd(),[_0x26d3bf]:_0x2b57f3};return new Ut('auth','Firebase',_0x10528f)['create'](_0x26d3bf,{'appName':_0x577567['name']});}function se(_0x1e1bd5){return ya(_0x1e1bd5,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x20749b,..._0x1e377c){if(typeof _0x20749b!='string'){const _0x4e31b3=_0x1e377c[0x0],_0x223ee0=[..._0x1e377c['slice'](0x1)];return _0x223ee0[0x0]&&(_0x223ee0[0x0]['appName']=_0x20749b['name']),_0x20749b['_errorFactory']['create'](_0x4e31b3,..._0x223ee0);}return ma['create'](_0x20749b,..._0x1e377c);}function m(_0x45373f,_0x2e32eb,..._0x4d8a98){if(!_0x45373f)throw Es(_0x2e32eb,..._0x4d8a98);}function te(_0x1badf0){const _0x80ea64='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1badf0;throw nn(_0x80ea64),new Error(_0x80ea64);}function ae(_0x48f766,_0x4068c9){_0x48f766||te(_0x4068c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x1d70d1;return typeof self<'u'&&((_0x1d70d1=self['location'])==null?void 0x0:_0x1d70d1['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0xebb54f;return typeof self<'u'&&((_0xebb54f=self['location'])==null?void 0x0:_0xebb54f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x20d705=navigator;return _0x20d705['languages']&&_0x20d705['languages'][0x0]||_0x20d705['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x4f0f78,_0x3f7610){this['shortDelay']=_0x4f0f78,this['longDelay']=_0x3f7610,ae(_0x3f7610>_0x4f0f78,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x4f5f72,_0x5e4a89){ae(_0x4f5f72['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x34e7d9}=_0x4f5f72['emulator'];return _0x5e4a89?''+_0x34e7d9+(_0x5e4a89['startsWith']('/')?_0x5e4a89['slice'](0x1):_0x5e4a89):_0x34e7d9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x37edbd,_0x2d90d7,_0x241fb3){this['fetchImpl']=_0x37edbd,_0x2d90d7&&(this['headersImpl']=_0x2d90d7),_0x241fb3&&(this['responseImpl']=_0x241fb3);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x2660b5,_0x1fe5d1){return _0x2660b5['tenantId']&&!_0x1fe5d1['tenantId']?{..._0x1fe5d1,'tenantId':_0x2660b5['tenantId']}:_0x1fe5d1;}async function Ae(_0x3b8e63,_0x466bba,_0x8f4b67,_0x430857,_0x3bae48={}){return Ea(_0x3b8e63,_0x3bae48,async()=>{let _0x84b1ae={},_0x55467f={};_0x430857&&(_0x466bba==='GET'?_0x55467f=_0x430857:_0x84b1ae={'body':JSON['stringify'](_0x430857)});const _0x598510=at({..._0x55467f,'key':_0x3b8e63['config']['apiKey']})['slice'](0x1),_0x2f073d=await _0x3b8e63['_getAdditionalHeaders']();_0x2f073d['Content-Type']='application/json',_0x3b8e63['languageCode']&&(_0x2f073d['X-Firebase-Locale']=_0x3b8e63['languageCode']);const _0x2e2e76={'method':_0x466bba,'headers':_0x2f073d,..._0x84b1ae};return lc()||(_0x2e2e76['referrerPolicy']='strict-origin-when-cross-origin'),_0x3b8e63['emulatorConfig']&&Wt(_0x3b8e63['emulatorConfig']['host'])&&(_0x2e2e76['credentials']='include'),va['fetch']()(await Ia(_0x3b8e63,_0x3b8e63['config']['apiHost'],_0x8f4b67,_0x598510),_0x2e2e76);});}async function Ea(_0x81df9d,_0x412879,_0x30388e){_0x81df9d['_canInitEmulator']=!0x1;const _0x46873d={...rf,..._0x412879};try{const _0x58609f=new lf(_0x81df9d),_0x299c09=await Promise['race']([_0x30388e(),_0x58609f['promise']]);_0x58609f['clearNetworkTimeout']();const _0x1558df=await _0x299c09['json']();if('needConfirmation'in _0x1558df)throw en(_0x81df9d,'account-exists-with-different-credential',_0x1558df);if(_0x299c09['ok']&&!('errorMessage'in _0x1558df))return _0x1558df;{const _0x1e1ec2=_0x299c09['ok']?_0x1558df['errorMessage']:_0x1558df['error']['message'],[_0x352e4a,_0x32ea36]=_0x1e1ec2['split']('\x20:\x20');if(_0x352e4a==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x81df9d,'credential-already-in-use',_0x1558df);if(_0x352e4a==='EMAIL_EXISTS')throw en(_0x81df9d,'email-already-in-use',_0x1558df);if(_0x352e4a==='USER_DISABLED')throw en(_0x81df9d,'user-disabled',_0x1558df);const _0x333da2=_0x46873d[_0x352e4a]||_0x352e4a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x32ea36)throw ya(_0x81df9d,_0x333da2,_0x32ea36);K(_0x81df9d,_0x333da2);}}catch(_0x5cab1e){if(_0x5cab1e instanceof Se)throw _0x5cab1e;K(_0x81df9d,'network-request-failed',{'message':String(_0x5cab1e)});}}async function Yt(_0x28aeb9,_0x4db6ac,_0xdcf2a1,_0x21aaf8,_0x3d4476={}){const _0xb475da=await Ae(_0x28aeb9,_0x4db6ac,_0xdcf2a1,_0x21aaf8,_0x3d4476);return'mfaPendingCredential'in _0xb475da&&K(_0x28aeb9,'multi-factor-auth-required',{'_serverResponse':_0xb475da}),_0xb475da;}async function Ia(_0x541098,_0x58949f,_0x2c67a3,_0x156945){const _0x2dfbf2=''+_0x58949f+_0x2c67a3+'?'+_0x156945,_0x4e783e=_0x541098,_0x365681=_0x4e783e['config']['emulator']?Is(_0x541098['config'],_0x2dfbf2):_0x541098['config']['apiScheme']+'://'+_0x2dfbf2;return of['includes'](_0x2c67a3)&&(await _0x4e783e['_persistenceManagerAvailable'],_0x4e783e['_getPersistenceType']()==='COOKIE')?_0x4e783e['_getPersistence']()['_getFinalTarget'](_0x365681)['toString']():_0x365681;}function cf(_0x26a718){switch(_0x26a718){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x12c382){this['auth']=_0x12c382,this['timer']=null,this['promise']=new Promise((_0x4ea6aa,_0x373376)=>{this['timer']=setTimeout(()=>_0x373376(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x2e3f93,_0x461d7e,_0x1b0ed9){const _0x2f5a0={'appName':_0x2e3f93['name']};_0x1b0ed9['email']&&(_0x2f5a0['email']=_0x1b0ed9['email']),_0x1b0ed9['phoneNumber']&&(_0x2f5a0['phoneNumber']=_0x1b0ed9['phoneNumber']);const _0x527ed9=J(_0x2e3f93,_0x461d7e,_0x2f5a0);return _0x527ed9['customData']['_tokenResponse']=_0x1b0ed9,_0x527ed9;}function vr(_0xddaae){return _0xddaae!==void 0x0&&_0xddaae['enterprise']!==void 0x0;}class hf{constructor(_0x3a87c5){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3a87c5['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3a87c5['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3a87c5['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4e1fbd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3fe589 of this['recaptchaEnforcementState'])if(_0x3fe589['provider']&&_0x3fe589['provider']===_0x4e1fbd)return cf(_0x3fe589['enforcementState']);return null;}['isProviderEnabled'](_0x216d1e){return this['getProviderEnforcementState'](_0x216d1e)==='ENFORCE'||this['getProviderEnforcementState'](_0x216d1e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x5cdfa4,_0x230884){return Ae(_0x5cdfa4,'GET','/v2/recaptchaConfig',Re(_0x5cdfa4,_0x230884));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x9b3828,_0x417fb6){return Ae(_0x9b3828,'POST','/v1/accounts:delete',_0x417fb6);}async function Sn(_0x53cc49,_0x50d1d3){return Ae(_0x53cc49,'POST','/v1/accounts:lookup',_0x50d1d3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x1eba89){if(_0x1eba89)try{const _0x5ee19a=new Date(Number(_0x1eba89));if(!isNaN(_0x5ee19a['getTime']()))return _0x5ee19a['toUTCString']();}catch{}}async function ff(_0x8fede8,_0x230ad5=!0x1){const _0x9aa926=k(_0x8fede8),_0x480be9=await _0x9aa926['getIdToken'](_0x230ad5),_0x4a5564=ws(_0x480be9);m(_0x4a5564&&_0x4a5564['exp']&&_0x4a5564['auth_time']&&_0x4a5564['iat'],_0x9aa926['auth'],'internal-error');const _0x34967f=typeof _0x4a5564['firebase']=='object'?_0x4a5564['firebase']:void 0x0,_0x48ead8=_0x34967f==null?void 0x0:_0x34967f['sign_in_provider'];return{'claims':_0x4a5564,'token':_0x480be9,'authTime':St(ci(_0x4a5564['auth_time'])),'issuedAtTime':St(ci(_0x4a5564['iat'])),'expirationTime':St(ci(_0x4a5564['exp'])),'signInProvider':_0x48ead8||null,'signInSecondFactor':(_0x34967f==null?void 0x0:_0x34967f['sign_in_second_factor'])||null};}function ci(_0x2bfa31){return Number(_0x2bfa31)*0x3e8;}function ws(_0x34ed1a){const [_0x5de68f,_0x3a43b7,_0x4d9724]=_0x34ed1a['split']('.');if(_0x5de68f===void 0x0||_0x3a43b7===void 0x0||_0x4d9724===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x474f96=cn(_0x3a43b7);return _0x474f96?JSON['parse'](_0x474f96):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x389981){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x389981==null?void 0x0:_0x389981['toString']()),null;}}function Er(_0x57e370){const _0x5ec219=ws(_0x57e370);return m(_0x5ec219,'internal-error'),m(typeof _0x5ec219['exp']<'u','internal-error'),m(typeof _0x5ec219['iat']<'u','internal-error'),Number(_0x5ec219['exp'])-Number(_0x5ec219['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x14874e,_0x2bdd5e,_0x242510=!0x1){if(_0x242510)return _0x2bdd5e;try{return await _0x2bdd5e;}catch(_0x408de4){throw _0x408de4 instanceof Se&&pf(_0x408de4)&&_0x14874e['auth']['currentUser']===_0x14874e&&await _0x14874e['auth']['signOut'](),_0x408de4;}}function pf({code:_0x2e5bd0}){return _0x2e5bd0==='auth/user-disabled'||_0x2e5bd0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3ae4af){this['user']=_0x3ae4af,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5a32f1){if(_0x5a32f1){const _0x5b2b85=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5b2b85;}else{this['errorBackoff']=0x7530;const _0xba6904=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xba6904);}}['schedule'](_0x12b264=!0x1){if(!this['isRunning'])return;const _0x3c02e4=this['getInterval'](_0x12b264);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3c02e4);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x442db3){(_0x442db3==null?void 0x0:_0x442db3['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x1badb8,_0x4c929a){this['createdAt']=_0x1badb8,this['lastLoginAt']=_0x4c929a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x89c004){this['createdAt']=_0x89c004['createdAt'],this['lastLoginAt']=_0x89c004['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x2e2451){var _0x2d810e;const _0x4cb685=_0x2e2451['auth'],_0x349735=await _0x2e2451['getIdToken'](),_0x52b2ab=await xt(_0x2e2451,Sn(_0x4cb685,{'idToken':_0x349735}));m(_0x52b2ab==null?void 0x0:_0x52b2ab['users']['length'],_0x4cb685,'internal-error');const _0x59da6f=_0x52b2ab['users'][0x0];_0x2e2451['_notifyReloadListener'](_0x59da6f);const _0x359ef2=(_0x2d810e=_0x59da6f['providerUserInfo'])!=null&&_0x2d810e['length']?wa(_0x59da6f['providerUserInfo']):[],_0x3fe38b=mf(_0x2e2451['providerData'],_0x359ef2),_0xee7f39=_0x2e2451['isAnonymous'],_0x390c9a=!(_0x2e2451['email']&&_0x59da6f['passwordHash'])&&!(_0x3fe38b!=null&&_0x3fe38b['length']),_0x4a5d08=_0xee7f39?_0x390c9a:!0x1,_0x14d933={'uid':_0x59da6f['localId'],'displayName':_0x59da6f['displayName']||null,'photoURL':_0x59da6f['photoUrl']||null,'email':_0x59da6f['email']||null,'emailVerified':_0x59da6f['emailVerified']||!0x1,'phoneNumber':_0x59da6f['phoneNumber']||null,'tenantId':_0x59da6f['tenantId']||null,'providerData':_0x3fe38b,'metadata':new Pi(_0x59da6f['createdAt'],_0x59da6f['lastLoginAt']),'isAnonymous':_0x4a5d08};Object['assign'](_0x2e2451,_0x14d933);}async function gf(_0x25b24){const _0x3ce5fb=k(_0x25b24);await bn(_0x3ce5fb),await _0x3ce5fb['auth']['_persistUserIfCurrent'](_0x3ce5fb),_0x3ce5fb['auth']['_notifyListenersIfCurrent'](_0x3ce5fb);}function mf(_0x48b7dc,_0x8ee1f8){return[..._0x48b7dc['filter'](_0x2b80ce=>!_0x8ee1f8['some'](_0x303373=>_0x303373['providerId']===_0x2b80ce['providerId'])),..._0x8ee1f8];}function wa(_0x342058){return _0x342058['map'](({providerId:_0x598f72,..._0x2c2af0})=>({'providerId':_0x598f72,'uid':_0x2c2af0['rawId']||'','displayName':_0x2c2af0['displayName']||null,'email':_0x2c2af0['email']||null,'phoneNumber':_0x2c2af0['phoneNumber']||null,'photoURL':_0x2c2af0['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x235bac,_0x335454){const _0x2a5428=await Ea(_0x235bac,{},async()=>{const _0x11f010=at({'grant_type':'refresh_token','refresh_token':_0x335454})['slice'](0x1),{tokenApiHost:_0x398323,apiKey:_0xbaf635}=_0x235bac['config'],_0x4234ff=await Ia(_0x235bac,_0x398323,'/v1/token','key='+_0xbaf635),_0x3152c0=await _0x235bac['_getAdditionalHeaders']();_0x3152c0['Content-Type']='application/x-www-form-urlencoded';const _0x52be56={'method':'POST','headers':_0x3152c0,'body':_0x11f010};return _0x235bac['emulatorConfig']&&Wt(_0x235bac['emulatorConfig']['host'])&&(_0x52be56['credentials']='include'),va['fetch']()(_0x4234ff,_0x52be56);});return{'accessToken':_0x2a5428['access_token'],'expiresIn':_0x2a5428['expires_in'],'refreshToken':_0x2a5428['refresh_token']};}async function vf(_0x36907f,_0x2223e1){return Ae(_0x36907f,'POST','/v2/accounts:revokeToken',Re(_0x36907f,_0x2223e1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5302cc){m(_0x5302cc['idToken'],'internal-error'),m(typeof _0x5302cc['idToken']<'u','internal-error'),m(typeof _0x5302cc['refreshToken']<'u','internal-error');const _0x458e26='expiresIn'in _0x5302cc&&typeof _0x5302cc['expiresIn']<'u'?Number(_0x5302cc['expiresIn']):Er(_0x5302cc['idToken']);this['updateTokensAndExpiration'](_0x5302cc['idToken'],_0x5302cc['refreshToken'],_0x458e26);}['updateFromIdToken'](_0x7f1820){m(_0x7f1820['length']!==0x0,'internal-error');const _0x4575ea=Er(_0x7f1820);this['updateTokensAndExpiration'](_0x7f1820,null,_0x4575ea);}async['getToken'](_0x3edd1b,_0x38e99e=!0x1){return!_0x38e99e&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3edd1b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3edd1b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3f342e,_0x373631){const {accessToken:_0xba21cb,refreshToken:_0x54f44b,expiresIn:_0x1bae41}=await yf(_0x3f342e,_0x373631);this['updateTokensAndExpiration'](_0xba21cb,_0x54f44b,Number(_0x1bae41));}['updateTokensAndExpiration'](_0x3a5d97,_0x5aa593,_0x4fdd44){this['refreshToken']=_0x5aa593||null,this['accessToken']=_0x3a5d97||null,this['expirationTime']=Date['now']()+_0x4fdd44*0x3e8;}static['fromJSON'](_0x58d14e,_0x38cf16){const {refreshToken:_0x11927a,accessToken:_0xe3d8c3,expirationTime:_0x2a2b66}=_0x38cf16,_0x4c1ded=new Je();return _0x11927a&&(m(typeof _0x11927a=='string','internal-error',{'appName':_0x58d14e}),_0x4c1ded['refreshToken']=_0x11927a),_0xe3d8c3&&(m(typeof _0xe3d8c3=='string','internal-error',{'appName':_0x58d14e}),_0x4c1ded['accessToken']=_0xe3d8c3),_0x2a2b66&&(m(typeof _0x2a2b66=='number','internal-error',{'appName':_0x58d14e}),_0x4c1ded['expirationTime']=_0x2a2b66),_0x4c1ded;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xabb2ac){this['accessToken']=_0xabb2ac['accessToken'],this['refreshToken']=_0xabb2ac['refreshToken'],this['expirationTime']=_0xabb2ac['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5212d4,_0x2b9753){m(typeof _0x5212d4=='string'||typeof _0x5212d4>'u','internal-error',{'appName':_0x2b9753});}class z{constructor({uid:_0x216599,auth:_0x5e83b2,stsTokenManager:_0x883874,..._0x57ebfc}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x216599,this['auth']=_0x5e83b2,this['stsTokenManager']=_0x883874,this['accessToken']=_0x883874['accessToken'],this['displayName']=_0x57ebfc['displayName']||null,this['email']=_0x57ebfc['email']||null,this['emailVerified']=_0x57ebfc['emailVerified']||!0x1,this['phoneNumber']=_0x57ebfc['phoneNumber']||null,this['photoURL']=_0x57ebfc['photoURL']||null,this['isAnonymous']=_0x57ebfc['isAnonymous']||!0x1,this['tenantId']=_0x57ebfc['tenantId']||null,this['providerData']=_0x57ebfc['providerData']?[..._0x57ebfc['providerData']]:[],this['metadata']=new Pi(_0x57ebfc['createdAt']||void 0x0,_0x57ebfc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x33d9dc){const _0x2bd029=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x33d9dc));return m(_0x2bd029,this['auth'],'internal-error'),this['accessToken']!==_0x2bd029&&(this['accessToken']=_0x2bd029,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2bd029;}['getIdTokenResult'](_0x2648e2){return ff(this,_0x2648e2);}['reload'](){return gf(this);}['_assign'](_0x476e97){this!==_0x476e97&&(m(this['uid']===_0x476e97['uid'],this['auth'],'internal-error'),this['displayName']=_0x476e97['displayName'],this['photoURL']=_0x476e97['photoURL'],this['email']=_0x476e97['email'],this['emailVerified']=_0x476e97['emailVerified'],this['phoneNumber']=_0x476e97['phoneNumber'],this['isAnonymous']=_0x476e97['isAnonymous'],this['tenantId']=_0x476e97['tenantId'],this['providerData']=_0x476e97['providerData']['map'](_0x30fe98=>({..._0x30fe98})),this['metadata']['_copy'](_0x476e97['metadata']),this['stsTokenManager']['_assign'](_0x476e97['stsTokenManager']));}['_clone'](_0x1c5f72){const _0x4bf3dd=new z({...this,'auth':_0x1c5f72,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4bf3dd['metadata']['_copy'](this['metadata']),_0x4bf3dd;}['_onReload'](_0x14c887){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x14c887,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4356d0){this['reloadListener']?this['reloadListener'](_0x4356d0):this['reloadUserInfo']=_0x4356d0;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5e3ba8,_0x72c824=!0x1){let _0x538269=!0x1;_0x5e3ba8['idToken']&&_0x5e3ba8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5e3ba8),_0x538269=!0x0),_0x72c824&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x538269&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x29c797=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x29c797})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3107f3=>({..._0x3107f3})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x14da64,_0xc20a95){const _0x31ea8a=_0xc20a95['displayName']??void 0x0,_0x4d876a=_0xc20a95['email']??void 0x0,_0x388b7f=_0xc20a95['phoneNumber']??void 0x0,_0x374e6d=_0xc20a95['photoURL']??void 0x0,_0x1a8552=_0xc20a95['tenantId']??void 0x0,_0x3bdbf3=_0xc20a95['_redirectEventId']??void 0x0,_0xec43bb=_0xc20a95['createdAt']??void 0x0,_0x5c8f1e=_0xc20a95['lastLoginAt']??void 0x0,{uid:_0x53f4df,emailVerified:_0xb54a1c,isAnonymous:_0x2943d2,providerData:_0x5a14fe,stsTokenManager:_0x42911b}=_0xc20a95;m(_0x53f4df&&_0x42911b,_0x14da64,'internal-error');const _0x3ec41a=Je['fromJSON'](this['name'],_0x42911b);m(typeof _0x53f4df=='string',_0x14da64,'internal-error'),ce(_0x31ea8a,_0x14da64['name']),ce(_0x4d876a,_0x14da64['name']),m(typeof _0xb54a1c=='boolean',_0x14da64,'internal-error'),m(typeof _0x2943d2=='boolean',_0x14da64,'internal-error'),ce(_0x388b7f,_0x14da64['name']),ce(_0x374e6d,_0x14da64['name']),ce(_0x1a8552,_0x14da64['name']),ce(_0x3bdbf3,_0x14da64['name']),ce(_0xec43bb,_0x14da64['name']),ce(_0x5c8f1e,_0x14da64['name']);const _0x4eb3a3=new z({'uid':_0x53f4df,'auth':_0x14da64,'email':_0x4d876a,'emailVerified':_0xb54a1c,'displayName':_0x31ea8a,'isAnonymous':_0x2943d2,'photoURL':_0x374e6d,'phoneNumber':_0x388b7f,'tenantId':_0x1a8552,'stsTokenManager':_0x3ec41a,'createdAt':_0xec43bb,'lastLoginAt':_0x5c8f1e});return _0x5a14fe&&Array['isArray'](_0x5a14fe)&&(_0x4eb3a3['providerData']=_0x5a14fe['map'](_0x3032b9=>({..._0x3032b9}))),_0x3bdbf3&&(_0x4eb3a3['_redirectEventId']=_0x3bdbf3),_0x4eb3a3;}static async['_fromIdTokenResponse'](_0x198bdc,_0x1d32fd,_0x11d56d=!0x1){const _0x45dd87=new Je();_0x45dd87['updateFromServerResponse'](_0x1d32fd);const _0xad551e=new z({'uid':_0x1d32fd['localId'],'auth':_0x198bdc,'stsTokenManager':_0x45dd87,'isAnonymous':_0x11d56d});return await bn(_0xad551e),_0xad551e;}static async['_fromGetAccountInfoResponse'](_0x29bf84,_0x532f71,_0x5a5efd){const _0x4d6b47=_0x532f71['users'][0x0];m(_0x4d6b47['localId']!==void 0x0,'internal-error');const _0x484f25=_0x4d6b47['providerUserInfo']!==void 0x0?wa(_0x4d6b47['providerUserInfo']):[],_0x1a7752=!(_0x4d6b47['email']&&_0x4d6b47['passwordHash'])&&!(_0x484f25!=null&&_0x484f25['length']),_0x4f368a=new Je();_0x4f368a['updateFromIdToken'](_0x5a5efd);const _0x2bb5ca=new z({'uid':_0x4d6b47['localId'],'auth':_0x29bf84,'stsTokenManager':_0x4f368a,'isAnonymous':_0x1a7752}),_0x5cdfbd={'uid':_0x4d6b47['localId'],'displayName':_0x4d6b47['displayName']||null,'photoURL':_0x4d6b47['photoUrl']||null,'email':_0x4d6b47['email']||null,'emailVerified':_0x4d6b47['emailVerified']||!0x1,'phoneNumber':_0x4d6b47['phoneNumber']||null,'tenantId':_0x4d6b47['tenantId']||null,'providerData':_0x484f25,'metadata':new Pi(_0x4d6b47['createdAt'],_0x4d6b47['lastLoginAt']),'isAnonymous':!(_0x4d6b47['email']&&_0x4d6b47['passwordHash'])&&!(_0x484f25!=null&&_0x484f25['length'])};return Object['assign'](_0x2bb5ca,_0x5cdfbd),_0x2bb5ca;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x3257b3){ae(_0x3257b3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x361afc=Ir['get'](_0x3257b3);return _0x361afc?(ae(_0x361afc instanceof _0x3257b3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x361afc):(_0x361afc=new _0x3257b3(),Ir['set'](_0x3257b3,_0x361afc),_0x361afc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5e2c38,_0x1b6d83){this['storage'][_0x5e2c38]=_0x1b6d83;}async['_get'](_0x3b4cb3){const _0x1a1b93=this['storage'][_0x3b4cb3];return _0x1a1b93===void 0x0?null:_0x1a1b93;}async['_remove'](_0x458ead){delete this['storage'][_0x458ead];}['_addListener'](_0x344c0c,_0x3f86f4){}['_removeListener'](_0x590d4d,_0x1302b7){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x411365,_0x421a7d,_0x3a299e){return'firebase:'+_0x411365+':'+_0x421a7d+':'+_0x3a299e;}class Xe{constructor(_0x3834b2,_0x478b02,_0x3f8b43){this['persistence']=_0x3834b2,this['auth']=_0x478b02,this['userKey']=_0x3f8b43;const {config:_0x213b05,name:_0x1b1bf0}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x213b05['apiKey'],_0x1b1bf0),this['fullPersistenceKey']=sn('persistence',_0x213b05['apiKey'],_0x1b1bf0),this['boundEventHandler']=_0x478b02['_onStorageEvent']['bind'](_0x478b02),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x361811){return this['persistence']['_set'](this['fullUserKey'],_0x361811['toJSON']());}async['getCurrentUser'](){const _0x13cd0a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x13cd0a)return null;if(typeof _0x13cd0a=='string'){const _0x46e30a=await Sn(this['auth'],{'idToken':_0x13cd0a})['catch'](()=>{});return _0x46e30a?z['_fromGetAccountInfoResponse'](this['auth'],_0x46e30a,_0x13cd0a):null;}return z['_fromJSON'](this['auth'],_0x13cd0a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x23b341){if(this['persistence']===_0x23b341)return;const _0x5c7596=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x23b341,_0x5c7596)return this['setCurrentUser'](_0x5c7596);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4a1c9f,_0x2c419c,_0x3de759='authUser'){if(!_0x2c419c['length'])return new Xe(ne(wr),_0x4a1c9f,_0x3de759);const _0x5157cb=(await Promise['all'](_0x2c419c['map'](async _0x102378=>{if(await _0x102378['_isAvailable']())return _0x102378;})))['filter'](_0x2715cb=>_0x2715cb);let _0x183fa7=_0x5157cb[0x0]||ne(wr);const _0xe7334f=sn(_0x3de759,_0x4a1c9f['config']['apiKey'],_0x4a1c9f['name']);let _0x819698=null;for(const _0x3a7502 of _0x2c419c)try{const _0x455e6f=await _0x3a7502['_get'](_0xe7334f);if(_0x455e6f){let _0x4f5d8f;if(typeof _0x455e6f=='string'){const _0x11ee16=await Sn(_0x4a1c9f,{'idToken':_0x455e6f})['catch'](()=>{});if(!_0x11ee16)break;_0x4f5d8f=await z['_fromGetAccountInfoResponse'](_0x4a1c9f,_0x11ee16,_0x455e6f);}else _0x4f5d8f=z['_fromJSON'](_0x4a1c9f,_0x455e6f);_0x3a7502!==_0x183fa7&&(_0x819698=_0x4f5d8f),_0x183fa7=_0x3a7502;break;}}catch{}const _0x1cbf66=_0x5157cb['filter'](_0x3a0342=>_0x3a0342['_shouldAllowMigration']);return!_0x183fa7['_shouldAllowMigration']||!_0x1cbf66['length']?new Xe(_0x183fa7,_0x4a1c9f,_0x3de759):(_0x183fa7=_0x1cbf66[0x0],_0x819698&&await _0x183fa7['_set'](_0xe7334f,_0x819698['toJSON']()),await Promise['all'](_0x2c419c['map'](async _0xa7f90=>{if(_0xa7f90!==_0x183fa7)try{await _0xa7f90['_remove'](_0xe7334f);}catch{}})),new Xe(_0x183fa7,_0x4a1c9f,_0x3de759));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x12ec91){const _0xd32ffa=_0x12ec91['toLowerCase']();if(_0xd32ffa['includes']('opera/')||_0xd32ffa['includes']('opr/')||_0xd32ffa['includes']('opios/'))return'Opera';if(Ra(_0xd32ffa))return'IEMobile';if(_0xd32ffa['includes']('msie')||_0xd32ffa['includes']('trident/'))return'IE';if(_0xd32ffa['includes']('edge/'))return'Edge';if(Ta(_0xd32ffa))return'Firefox';if(_0xd32ffa['includes']('silk/'))return'Silk';if(ka(_0xd32ffa))return'Blackberry';if(Na(_0xd32ffa))return'Webos';if(Sa(_0xd32ffa))return'Safari';if((_0xd32ffa['includes']('chrome/')||ba(_0xd32ffa))&&!_0xd32ffa['includes']('edge/'))return'Chrome';if(Aa(_0xd32ffa))return'Android';{const _0xfb0324=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2bea38=_0x12ec91['match'](_0xfb0324);if((_0x2bea38==null?void 0x0:_0x2bea38['length'])===0x2)return _0x2bea38[0x1];}return'Other';}function Ta(_0x32ba2d=W()){return/firefox\//i['test'](_0x32ba2d);}function Sa(_0x366ba9=W()){const _0x16102c=_0x366ba9['toLowerCase']();return _0x16102c['includes']('safari/')&&!_0x16102c['includes']('chrome/')&&!_0x16102c['includes']('crios/')&&!_0x16102c['includes']('android');}function ba(_0x1a234c=W()){return/crios\//i['test'](_0x1a234c);}function Ra(_0x2bfcad=W()){return/iemobile/i['test'](_0x2bfcad);}function Aa(_0x5aa5d2=W()){return/android/i['test'](_0x5aa5d2);}function ka(_0x267410=W()){return/blackberry/i['test'](_0x267410);}function Na(_0x2332c0=W()){return/webos/i['test'](_0x2332c0);}function Cs(_0x15d4c9=W()){return/iphone|ipad|ipod/i['test'](_0x15d4c9)||/macintosh/i['test'](_0x15d4c9)&&/mobile/i['test'](_0x15d4c9);}function Ef(_0xe22a51=W()){var _0x5a9120;return Cs(_0xe22a51)&&!!((_0x5a9120=window['navigator'])!=null&&_0x5a9120['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2cbd75=W()){return Cs(_0x2cbd75)||Aa(_0x2cbd75)||Na(_0x2cbd75)||ka(_0x2cbd75)||/windows phone/i['test'](_0x2cbd75)||Ra(_0x2cbd75);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x38793f,_0x5f25b2=[]){let _0x11f0b3;switch(_0x38793f){case'Browser':_0x11f0b3=Cr(W());break;case'Worker':_0x11f0b3=Cr(W())+'-'+_0x38793f;break;default:_0x11f0b3=_0x38793f;}const _0x164def=_0x5f25b2['length']?_0x5f25b2['join'](','):'FirebaseCore-web';return _0x11f0b3+'/JsCore/'+ct+'/'+_0x164def;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x19cdc5){this['auth']=_0x19cdc5,this['queue']=[];}['pushCallback'](_0x2bd43a,_0x2a51ba){const _0x2c2c24=_0x47c1d1=>new Promise((_0x4e4344,_0x4156d9)=>{try{const _0x2b3062=_0x2bd43a(_0x47c1d1);_0x4e4344(_0x2b3062);}catch(_0x3fcf01){_0x4156d9(_0x3fcf01);}});_0x2c2c24['onAbort']=_0x2a51ba,this['queue']['push'](_0x2c2c24);const _0x125554=this['queue']['length']-0x1;return()=>{this['queue'][_0x125554]=()=>Promise['resolve']();};}async['runMiddleware'](_0x55ff9f){if(this['auth']['currentUser']===_0x55ff9f)return;const _0x2079e6=[];try{for(const _0x596b85 of this['queue'])await _0x596b85(_0x55ff9f),_0x596b85['onAbort']&&_0x2079e6['push'](_0x596b85['onAbort']);}catch(_0x15bb42){_0x2079e6['reverse']();for(const _0x213cc8 of _0x2079e6)try{_0x213cc8();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x15bb42==null?void 0x0:_0x15bb42['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x432837,_0x42c6c3={}){return Ae(_0x432837,'GET','/v2/passwordPolicy',Re(_0x432837,_0x42c6c3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x13e6b4){var _0x319894;const _0x52ecdb=_0x13e6b4['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x52ecdb['minPasswordLength']??Tf,_0x52ecdb['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x52ecdb['maxPasswordLength']),_0x52ecdb['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x52ecdb['containsLowercaseCharacter']),_0x52ecdb['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x52ecdb['containsUppercaseCharacter']),_0x52ecdb['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x52ecdb['containsNumericCharacter']),_0x52ecdb['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x52ecdb['containsNonAlphanumericCharacter']),this['enforcementState']=_0x13e6b4['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x319894=_0x13e6b4['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x319894['join'](''))??'',this['forceUpgradeOnSignin']=_0x13e6b4['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x13e6b4['schemaVersion'];}['validatePassword'](_0x2b28d2){const _0x305bd1={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2b28d2,_0x305bd1),this['validatePasswordCharacterOptions'](_0x2b28d2,_0x305bd1),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['meetsMinPasswordLength']??!0x0),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['meetsMaxPasswordLength']??!0x0),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['containsLowercaseLetter']??!0x0),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['containsUppercaseLetter']??!0x0),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['containsNumericCharacter']??!0x0),_0x305bd1['isValid']&&(_0x305bd1['isValid']=_0x305bd1['containsNonAlphanumericCharacter']??!0x0),_0x305bd1;}['validatePasswordLengthOptions'](_0x1bcc6a,_0x1a2643){const _0x5ac274=this['customStrengthOptions']['minPasswordLength'],_0x5da90f=this['customStrengthOptions']['maxPasswordLength'];_0x5ac274&&(_0x1a2643['meetsMinPasswordLength']=_0x1bcc6a['length']>=_0x5ac274),_0x5da90f&&(_0x1a2643['meetsMaxPasswordLength']=_0x1bcc6a['length']<=_0x5da90f);}['validatePasswordCharacterOptions'](_0x3a2e22,_0x250647){this['updatePasswordCharacterOptionsStatuses'](_0x250647,!0x1,!0x1,!0x1,!0x1);let _0x5d648e;for(let _0x3b7b68=0x0;_0x3b7b68<_0x3a2e22['length'];_0x3b7b68++)_0x5d648e=_0x3a2e22['charAt'](_0x3b7b68),this['updatePasswordCharacterOptionsStatuses'](_0x250647,_0x5d648e>='a'&&_0x5d648e<='z',_0x5d648e>='A'&&_0x5d648e<='Z',_0x5d648e>='0'&&_0x5d648e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5d648e));}['updatePasswordCharacterOptionsStatuses'](_0x395936,_0x4c275a,_0x1d2e01,_0x16b2f9,_0x32edd4){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x395936['containsLowercaseLetter']||(_0x395936['containsLowercaseLetter']=_0x4c275a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x395936['containsUppercaseLetter']||(_0x395936['containsUppercaseLetter']=_0x1d2e01)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x395936['containsNumericCharacter']||(_0x395936['containsNumericCharacter']=_0x16b2f9)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x395936['containsNonAlphanumericCharacter']||(_0x395936['containsNonAlphanumericCharacter']=_0x32edd4));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1d84f6,_0x232a7c,_0x590572,_0x26f25e){this['app']=_0x1d84f6,this['heartbeatServiceProvider']=_0x232a7c,this['appCheckServiceProvider']=_0x590572,this['config']=_0x26f25e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1d84f6['name'],this['clientVersion']=_0x26f25e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4116ae=>this['_resolvePersistenceManagerAvailable']=_0x4116ae);}['_initializeWithPersistence'](_0x927dcf,_0x3c2d7e){return _0x3c2d7e&&(this['_popupRedirectResolver']=ne(_0x3c2d7e)),this['_initializationPromise']=this['queue'](async()=>{var _0xa3d71a,_0x348337,_0x243004;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x927dcf),(_0xa3d71a=this['_resolvePersistenceManagerAvailable'])==null||_0xa3d71a['call'](this),!this['_deleted'])){if((_0x348337=this['_popupRedirectResolver'])!=null&&_0x348337['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3c2d7e),this['lastNotifiedUid']=((_0x243004=this['currentUser'])==null?void 0x0:_0x243004['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3ac69b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3ac69b)){if(this['currentUser']&&_0x3ac69b&&this['currentUser']['uid']===_0x3ac69b['uid']){this['_currentUser']['_assign'](_0x3ac69b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3ac69b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4ca4ec){try{const _0x4ce02a=await Sn(this,{'idToken':_0x4ca4ec}),_0x226858=await z['_fromGetAccountInfoResponse'](this,_0x4ce02a,_0x4ca4ec);await this['directlySetCurrentUser'](_0x226858);}catch(_0x59d974){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x59d974),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x8f340){var _0x2a13e3;if(H(this['app'])){const _0x4da672=this['app']['settings']['authIdToken'];return _0x4da672?new Promise(_0x4b47fb=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4da672)['then'](_0x4b47fb,_0x4b47fb));}):this['directlySetCurrentUser'](null);}const _0x480f20=await this['assertedPersistence']['getCurrentUser']();let _0x1f3cd5=_0x480f20,_0x33c00c=!0x1;if(_0x8f340&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2ee7b0=(_0x2a13e3=this['redirectUser'])==null?void 0x0:_0x2a13e3['_redirectEventId'],_0x22756c=_0x1f3cd5==null?void 0x0:_0x1f3cd5['_redirectEventId'],_0x50564e=await this['tryRedirectSignIn'](_0x8f340);(!_0x2ee7b0||_0x2ee7b0===_0x22756c)&&(_0x50564e!=null&&_0x50564e['user'])&&(_0x1f3cd5=_0x50564e['user'],_0x33c00c=!0x0);}if(!_0x1f3cd5)return this['directlySetCurrentUser'](null);if(!_0x1f3cd5['_redirectEventId']){if(_0x33c00c)try{await this['beforeStateQueue']['runMiddleware'](_0x1f3cd5);}catch(_0x3203a2){_0x1f3cd5=_0x480f20,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3203a2));}return _0x1f3cd5?this['reloadAndSetCurrentUserOrClear'](_0x1f3cd5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1f3cd5['_redirectEventId']?this['directlySetCurrentUser'](_0x1f3cd5):this['reloadAndSetCurrentUserOrClear'](_0x1f3cd5);}async['tryRedirectSignIn'](_0x252654){let _0x17446b=null;try{_0x17446b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x252654,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x17446b;}async['reloadAndSetCurrentUserOrClear'](_0x5f28ef){try{await bn(_0x5f28ef);}catch(_0x5ae0c0){if((_0x5ae0c0==null?void 0x0:_0x5ae0c0['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5f28ef);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5f2df8){if(H(this['app']))return Promise['reject'](se(this));const _0xe6cb53=_0x5f2df8?k(_0x5f2df8):null;return _0xe6cb53&&m(_0xe6cb53['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xe6cb53&&_0xe6cb53['_clone'](this));}async['_updateCurrentUser'](_0x419f74,_0x3bcedd=!0x1){if(!this['_deleted'])return _0x419f74&&m(this['tenantId']===_0x419f74['tenantId'],this,'tenant-id-mismatch'),_0x3bcedd||await this['beforeStateQueue']['runMiddleware'](_0x419f74),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x419f74),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4bd535){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x4bd535));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5818f7){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1c0c2a=this['_getPasswordPolicyInternal']();return _0x1c0c2a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1c0c2a['validatePassword'](_0x5818f7);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5dd345=await Cf(this),_0x5ca1a6=new Sf(_0x5dd345);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5ca1a6:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5ca1a6;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3a7e24){this['_errorFactory']=new Ut('auth','Firebase',_0x3a7e24());}['onAuthStateChanged'](_0x2a19a0,_0x3965bd,_0x55a55a){return this['registerStateListener'](this['authStateSubscription'],_0x2a19a0,_0x3965bd,_0x55a55a);}['beforeAuthStateChanged'](_0x44c47e,_0x30a825){return this['beforeStateQueue']['pushCallback'](_0x44c47e,_0x30a825);}['onIdTokenChanged'](_0x1b2f53,_0x41fbad,_0x36d5d6){return this['registerStateListener'](this['idTokenSubscription'],_0x1b2f53,_0x41fbad,_0x36d5d6);}['authStateReady'](){return new Promise((_0xb3150e,_0x10101c)=>{if(this['currentUser'])_0xb3150e();else{const _0x169a55=this['onAuthStateChanged'](()=>{_0x169a55(),_0xb3150e();},_0x10101c);}});}async['revokeAccessToken'](_0x4117ae){if(this['currentUser']){const _0x39e76d=await this['currentUser']['getIdToken'](),_0x139531={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4117ae,'idToken':_0x39e76d};this['tenantId']!=null&&(_0x139531['tenantId']=this['tenantId']),await vf(this,_0x139531);}}['toJSON'](){var _0x215e16;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x215e16=this['_currentUser'])==null?void 0x0:_0x215e16['toJSON']()};}async['_setRedirectUser'](_0x165db4,_0x488765){const _0x4f4331=await this['getOrInitRedirectPersistenceManager'](_0x488765);return _0x165db4===null?_0x4f4331['removeCurrentUser']():_0x4f4331['setCurrentUser'](_0x165db4);}async['getOrInitRedirectPersistenceManager'](_0x510292){if(!this['redirectPersistenceManager']){const _0x3b2bc4=_0x510292&&ne(_0x510292)||this['_popupRedirectResolver'];m(_0x3b2bc4,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3b2bc4['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x13e05b){var _0x3e2cef,_0x35e128;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3e2cef=this['_currentUser'])==null?void 0x0:_0x3e2cef['_redirectEventId'])===_0x13e05b?this['_currentUser']:((_0x35e128=this['redirectUser'])==null?void 0x0:_0x35e128['_redirectEventId'])===_0x13e05b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4c73e5){if(_0x4c73e5===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4c73e5));}['_notifyListenersIfCurrent'](_0x42ad58){_0x42ad58===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x148928;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4aa05d=((_0x148928=this['currentUser'])==null?void 0x0:_0x148928['uid'])??null;this['lastNotifiedUid']!==_0x4aa05d&&(this['lastNotifiedUid']=_0x4aa05d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x219875,_0x139613,_0x1c96e2,_0xc2a1e0){if(this['_deleted'])return()=>{};const _0x1743e7=typeof _0x139613=='function'?_0x139613:_0x139613['next']['bind'](_0x139613);let _0x554c6e=!0x1;const _0x37f39d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x37f39d,this,'internal-error'),_0x37f39d['then'](()=>{_0x554c6e||_0x1743e7(this['currentUser']);}),typeof _0x139613=='function'){const _0x469c78=_0x219875['addObserver'](_0x139613,_0x1c96e2,_0xc2a1e0);return()=>{_0x554c6e=!0x0,_0x469c78();};}else{const _0x1ecd30=_0x219875['addObserver'](_0x139613);return()=>{_0x554c6e=!0x0,_0x1ecd30();};}}async['directlySetCurrentUser'](_0x5bf3d1){this['currentUser']&&this['currentUser']!==_0x5bf3d1&&this['_currentUser']['_stopProactiveRefresh'](),_0x5bf3d1&&this['isProactiveRefreshEnabled']&&_0x5bf3d1['_startProactiveRefresh'](),this['currentUser']=_0x5bf3d1,_0x5bf3d1?await this['assertedPersistence']['setCurrentUser'](_0x5bf3d1):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5eb1ed){return this['operations']=this['operations']['then'](_0x5eb1ed,_0x5eb1ed),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x180cbb){!_0x180cbb||this['frameworks']['includes'](_0x180cbb)||(this['frameworks']['push'](_0x180cbb),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2e5c85;const _0x3effe5={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3effe5['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x556025=await((_0x2e5c85=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2e5c85['getHeartbeatsHeader']());_0x556025&&(_0x3effe5['X-Firebase-Client']=_0x556025);const _0x5bf2e6=await this['_getAppCheckToken']();return _0x5bf2e6&&(_0x3effe5['X-Firebase-AppCheck']=_0x5bf2e6),_0x3effe5;}async['_getAppCheckToken'](){var _0x488278;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x337b09=await((_0x488278=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x488278['getToken']());return _0x337b09!=null&&_0x337b09['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x337b09['error']),_0x337b09==null?void 0x0:_0x337b09['token'];}}function qe(_0x4234fe){return k(_0x4234fe);}class Tr{constructor(_0x488fcc){this['auth']=_0x488fcc,this['observer']=null,this['addObserver']=Ic(_0x4a6b70=>this['observer']=_0x4a6b70);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2f39df){zn=_0x2f39df;}function Da(_0x3201b0){return zn['loadJS'](_0x3201b0);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4fac96){return'__'+_0x4fac96+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x15753b){_0x15753b();}['execute'](_0x1ce354,_0x51925b){return Promise['resolve']('token');}['render'](_0x2763e6,_0x448b59){return'';}}class Of{['ready'](_0x47bcc6){_0x47bcc6();}['execute'](_0x26cc4f,_0x1b0da2){return Promise['resolve']('token');}['render'](_0x96400,_0x2ef3ca){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5d9137){this['type']=Df,this['auth']=qe(_0x5d9137);}async['verify'](_0x41db49='verify',_0x47f1e8=!0x1){async function _0x4c76f1(_0x462a13){if(!_0x47f1e8){if(_0x462a13['tenantId']==null&&_0x462a13['_agentRecaptchaConfig']!=null)return _0x462a13['_agentRecaptchaConfig']['siteKey'];if(_0x462a13['tenantId']!=null&&_0x462a13['_tenantRecaptchaConfigs'][_0x462a13['tenantId']]!==void 0x0)return _0x462a13['_tenantRecaptchaConfigs'][_0x462a13['tenantId']]['siteKey'];}return new Promise(async(_0x4f5965,_0x4ccdc4)=>{uf(_0x462a13,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x16f13f=>{if(_0x16f13f['recaptchaKey']===void 0x0)_0x4ccdc4(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xd1e726=new hf(_0x16f13f);return _0x462a13['tenantId']==null?_0x462a13['_agentRecaptchaConfig']=_0xd1e726:_0x462a13['_tenantRecaptchaConfigs'][_0x462a13['tenantId']]=_0xd1e726,_0x4f5965(_0xd1e726['siteKey']);}})['catch'](_0x403669=>{_0x4ccdc4(_0x403669);});});}function _0x8f3d5(_0x220ed4,_0x5023f9,_0x1abbd0){const _0x4d83da=window['grecaptcha'];vr(_0x4d83da)?_0x4d83da['enterprise']['ready'](()=>{_0x4d83da['enterprise']['execute'](_0x220ed4,{'action':_0x41db49})['then'](_0x25ad34=>{_0x5023f9(_0x25ad34);})['catch'](()=>{_0x5023f9(Ma);});}):_0x1abbd0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x46b717,_0x9aea64)=>{_0x4c76f1(this['auth'])['then'](async _0xbdd3f9=>{if(!_0x47f1e8&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x8f3d5(_0xbdd3f9,_0x46b717,_0x9aea64);else{if(typeof window>'u'){_0x9aea64(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3fa66a=Af();_0x3fa66a['length']!==0x0&&(_0x3fa66a+=_0xbdd3f9+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x23a9bb;(_0x23a9bb=le['scriptInjectionDeferred'])==null||_0x23a9bb['resolve']();},Da(_0x3fa66a)['then'](()=>{var _0x5bc0f1;return(_0x5bc0f1=le['scriptInjectionDeferred'])==null?void 0x0:_0x5bc0f1['promise'];})['then'](()=>{_0x8f3d5(_0xbdd3f9,_0x46b717,_0x9aea64);})['catch'](_0x138310=>{_0x9aea64(_0x138310);});}})['catch'](_0x37ee5e=>{_0x9aea64(_0x37ee5e);});});}}le['scriptInjectionDeferred']=null;async function br(_0x155abd,_0x1448b1,_0x34c58e,_0x19ac81=!0x1,_0x2e7dba=!0x1){const _0x39312a=new le(_0x155abd);let _0x2c06e4;if(_0x2e7dba)_0x2c06e4=Ma;else try{_0x2c06e4=await _0x39312a['verify'](_0x34c58e);}catch{_0x2c06e4=await _0x39312a['verify'](_0x34c58e,!0x0);}const _0x181dd5={..._0x1448b1};if(_0x34c58e==='mfaSmsEnrollment'||_0x34c58e==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x181dd5){const _0x38ed44=_0x181dd5['phoneEnrollmentInfo']['phoneNumber'],_0x1e5b89=_0x181dd5['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x181dd5,{'phoneEnrollmentInfo':{'phoneNumber':_0x38ed44,'recaptchaToken':_0x1e5b89,'captchaResponse':_0x2c06e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x181dd5){const _0x20537d=_0x181dd5['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x181dd5,{'phoneSignInInfo':{'recaptchaToken':_0x20537d,'captchaResponse':_0x2c06e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x181dd5;}return _0x19ac81?Object['assign'](_0x181dd5,{'captchaResp':_0x2c06e4}):Object['assign'](_0x181dd5,{'captchaResponse':_0x2c06e4}),Object['assign'](_0x181dd5,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x181dd5,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x181dd5;}async function Oi(_0x2dc924,_0xef484,_0x11ce51,_0x10d458,_0x4d2433){var _0x15283e;if((_0x15283e=_0x2dc924['_getRecaptchaConfig']())!=null&&_0x15283e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x22fb9d=await br(_0x2dc924,_0xef484,_0x11ce51,_0x11ce51==='getOobCode');return _0x10d458(_0x2dc924,_0x22fb9d);}else return _0x10d458(_0x2dc924,_0xef484)['catch'](async _0x52c5c8=>{if(_0x52c5c8['code']==='auth/missing-recaptcha-token'){console['log'](_0x11ce51+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xb68f4a=await br(_0x2dc924,_0xef484,_0x11ce51,_0x11ce51==='getOobCode');return _0x10d458(_0x2dc924,_0xb68f4a);}else return Promise['reject'](_0x52c5c8);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x898e1f,_0x568acb){const _0x256bc2=Ui(_0x898e1f,'auth');if(_0x256bc2['isInitialized']()){const _0x1e0054=_0x256bc2['getImmediate'](),_0x549b27=_0x256bc2['getOptions']();if(De(_0x549b27,_0x568acb??{}))return _0x1e0054;K(_0x1e0054,'already-initialized');}return _0x256bc2['initialize']({'options':_0x568acb});}function Lf(_0xb83ee3,_0x36096d){const _0x4e8a14=(_0x36096d==null?void 0x0:_0x36096d['persistence'])||[],_0x878cde=(Array['isArray'](_0x4e8a14)?_0x4e8a14:[_0x4e8a14])['map'](ne);_0x36096d!=null&&_0x36096d['errorMap']&&_0xb83ee3['_updateErrorMap'](_0x36096d['errorMap']),_0xb83ee3['_initializeWithPersistence'](_0x878cde,_0x36096d==null?void 0x0:_0x36096d['popupRedirectResolver']);}function xf(_0x1802df,_0x4a4f18,_0x1f3a9d){const _0x25886=qe(_0x1802df);m(/^https?:\/\//['test'](_0x4a4f18),_0x25886,'invalid-emulator-scheme');const _0xc422cc=!0x1,_0x400a42=La(_0x4a4f18),{host:_0x38a38b,port:_0x288249}=Ff(_0x4a4f18),_0x599872=_0x288249===null?'':':'+_0x288249,_0x38d899={'url':_0x400a42+'//'+_0x38a38b+_0x599872+'/'},_0xc80f20=Object['freeze']({'host':_0x38a38b,'port':_0x288249,'protocol':_0x400a42['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0xc422cc})});if(!_0x25886['_canInitEmulator']){m(_0x25886['config']['emulator']&&_0x25886['emulatorConfig'],_0x25886,'emulator-config-failed'),m(De(_0x38d899,_0x25886['config']['emulator'])&&De(_0xc80f20,_0x25886['emulatorConfig']),_0x25886,'emulator-config-failed');return;}_0x25886['config']['emulator']=_0x38d899,_0x25886['emulatorConfig']=_0xc80f20,_0x25886['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x38a38b)?jr(_0x400a42+'//'+_0x38a38b+_0x599872):Uf();}function La(_0x3d2732){const _0x8c1709=_0x3d2732['indexOf'](':');return _0x8c1709<0x0?'':_0x3d2732['substr'](0x0,_0x8c1709+0x1);}function Ff(_0x17c16f){const _0x1bf615=La(_0x17c16f),_0x1c8755=/(\/\/)?([^?#/]+)/['exec'](_0x17c16f['substr'](_0x1bf615['length']));if(!_0x1c8755)return{'host':'','port':null};const _0x4e8dc8=_0x1c8755[0x2]['split']('@')['pop']()||'',_0x390252=/^(\[[^\]]+\])(:|$)/['exec'](_0x4e8dc8);if(_0x390252){const _0x569a19=_0x390252[0x1];return{'host':_0x569a19,'port':Rr(_0x4e8dc8['substr'](_0x569a19['length']+0x1))};}else{const [_0xac5dab,_0x688f66]=_0x4e8dc8['split'](':');return{'host':_0xac5dab,'port':Rr(_0x688f66)};}}function Rr(_0x146570){if(!_0x146570)return null;const _0x1bfc42=Number(_0x146570);return isNaN(_0x1bfc42)?null:_0x1bfc42;}function Uf(){function _0x5e459b(){const _0x18ea8d=document['createElement']('p'),_0x45fcde=_0x18ea8d['style'];_0x18ea8d['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x45fcde['position']='fixed',_0x45fcde['width']='100%',_0x45fcde['backgroundColor']='#ffffff',_0x45fcde['border']='.1em\x20solid\x20#000000',_0x45fcde['color']='#b50000',_0x45fcde['bottom']='0px',_0x45fcde['left']='0px',_0x45fcde['margin']='0px',_0x45fcde['zIndex']='10000',_0x45fcde['textAlign']='center',_0x18ea8d['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x18ea8d);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5e459b):_0x5e459b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x4884e5,_0x467e55){this['providerId']=_0x4884e5,this['signInMethod']=_0x467e55;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x54d6ac){return te('not\x20implemented');}['_linkToIdToken'](_0x1178d0,_0x4d071a){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x43671f){return te('not\x20implemented');}}async function Wf(_0x45937e,_0x56ad63){return Ae(_0x45937e,'POST','/v1/accounts:signUp',_0x56ad63);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0xc5172a,_0x2e3c85){return Yt(_0xc5172a,'POST','/v1/accounts:signInWithPassword',Re(_0xc5172a,_0x2e3c85));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x222b74,_0x3db2c8){return Yt(_0x222b74,'POST','/v1/accounts:signInWithEmailLink',Re(_0x222b74,_0x3db2c8));}async function Hf(_0x3f2bd4,_0x55e590){return Yt(_0x3f2bd4,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3f2bd4,_0x55e590));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x420352,_0xb0fc9,_0xfa570c,_0x6dbfc8=null){super('password',_0xfa570c),this['_email']=_0x420352,this['_password']=_0xb0fc9,this['_tenantId']=_0x6dbfc8;}static['_fromEmailAndPassword'](_0x532506,_0x226dc7){return new Ft(_0x532506,_0x226dc7,'password');}static['_fromEmailAndCode'](_0x5393f8,_0x27eff4,_0x42590e=null){return new Ft(_0x5393f8,_0x27eff4,'emailLink',_0x42590e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x416118){const _0x27fbb3=typeof _0x416118=='string'?JSON['parse'](_0x416118):_0x416118;if(_0x27fbb3!=null&&_0x27fbb3['email']&&(_0x27fbb3!=null&&_0x27fbb3['password'])){if(_0x27fbb3['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x27fbb3['email'],_0x27fbb3['password']);if(_0x27fbb3['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x27fbb3['email'],_0x27fbb3['password'],_0x27fbb3['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4873ff){switch(this['signInMethod']){case'password':const _0x4733ba={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4873ff,_0x4733ba,'signInWithPassword',Bf);case'emailLink':return Vf(_0x4873ff,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x4873ff,'internal-error');}}async['_linkToIdToken'](_0x5709ae,_0x427911){switch(this['signInMethod']){case'password':const _0x3b2064={'idToken':_0x427911,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5709ae,_0x3b2064,'signUpPassword',Wf);case'emailLink':return Hf(_0x5709ae,{'idToken':_0x427911,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5709ae,'internal-error');}}['_getReauthenticationResolver'](_0x1259f5){return this['_getIdTokenResponse'](_0x1259f5);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x15396a,_0x5e4798){return Yt(_0x15396a,'POST','/v1/accounts:signInWithIdp',Re(_0x15396a,_0x5e4798));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x229263){const _0x1cefff=new We(_0x229263['providerId'],_0x229263['signInMethod']);return _0x229263['idToken']||_0x229263['accessToken']?(_0x229263['idToken']&&(_0x1cefff['idToken']=_0x229263['idToken']),_0x229263['accessToken']&&(_0x1cefff['accessToken']=_0x229263['accessToken']),_0x229263['nonce']&&!_0x229263['pendingToken']&&(_0x1cefff['nonce']=_0x229263['nonce']),_0x229263['pendingToken']&&(_0x1cefff['pendingToken']=_0x229263['pendingToken'])):_0x229263['oauthToken']&&_0x229263['oauthTokenSecret']?(_0x1cefff['accessToken']=_0x229263['oauthToken'],_0x1cefff['secret']=_0x229263['oauthTokenSecret']):K('argument-error'),_0x1cefff;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1abd1c){const _0x467fc4=typeof _0x1abd1c=='string'?JSON['parse'](_0x1abd1c):_0x1abd1c,{providerId:_0x38328e,signInMethod:_0x228fd7,..._0xc37798}=_0x467fc4;if(!_0x38328e||!_0x228fd7)return null;const _0x28c112=new We(_0x38328e,_0x228fd7);return _0x28c112['idToken']=_0xc37798['idToken']||void 0x0,_0x28c112['accessToken']=_0xc37798['accessToken']||void 0x0,_0x28c112['secret']=_0xc37798['secret'],_0x28c112['nonce']=_0xc37798['nonce'],_0x28c112['pendingToken']=_0xc37798['pendingToken']||null,_0x28c112;}['_getIdTokenResponse'](_0x7a1c25){const _0x2816a6=this['buildRequest']();return Ze(_0x7a1c25,_0x2816a6);}['_linkToIdToken'](_0x4639ca,_0x590017){const _0x535ce5=this['buildRequest']();return _0x535ce5['idToken']=_0x590017,Ze(_0x4639ca,_0x535ce5);}['_getReauthenticationResolver'](_0x492c09){const _0x5cb19b=this['buildRequest']();return _0x5cb19b['autoCreate']=!0x1,Ze(_0x492c09,_0x5cb19b);}['buildRequest'](){const _0x3ba26b={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3ba26b['pendingToken']=this['pendingToken'];else{const _0x210e84={};this['idToken']&&(_0x210e84['id_token']=this['idToken']),this['accessToken']&&(_0x210e84['access_token']=this['accessToken']),this['secret']&&(_0x210e84['oauth_token_secret']=this['secret']),_0x210e84['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x210e84['nonce']=this['nonce']),_0x3ba26b['postBody']=at(_0x210e84);}return _0x3ba26b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x238a83){switch(_0x238a83){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x252188){const _0x596b7d=yt(vt(_0x252188))['link'],_0x650aa3=_0x596b7d?yt(vt(_0x596b7d))['deep_link_id']:null,_0x17d8ee=yt(vt(_0x252188))['deep_link_id'];return(_0x17d8ee?yt(vt(_0x17d8ee))['link']:null)||_0x17d8ee||_0x650aa3||_0x596b7d||_0x252188;}class Ss{constructor(_0x592e19){const _0x246d61=yt(vt(_0x592e19)),_0x4687b7=_0x246d61['apiKey']??null,_0x5e5371=_0x246d61['oobCode']??null,_0x39d669=Gf(_0x246d61['mode']??null);m(_0x4687b7&&_0x5e5371&&_0x39d669,'argument-error'),this['apiKey']=_0x4687b7,this['operation']=_0x39d669,this['code']=_0x5e5371,this['continueUrl']=_0x246d61['continueUrl']??null,this['languageCode']=_0x246d61['lang']??null,this['tenantId']=_0x246d61['tenantId']??null;}static['parseLink'](_0x363bbc){const _0x2cef6b=qf(_0x363bbc);try{return new Ss(_0x2cef6b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x536a1d,_0x551151){return Ft['_fromEmailAndPassword'](_0x536a1d,_0x551151);}static['credentialWithLink'](_0x1a161d,_0x27391a){const _0x3db754=Ss['parseLink'](_0x27391a);return m(_0x3db754,'argument-error'),Ft['_fromEmailAndCode'](_0x1a161d,_0x3db754['code'],_0x3db754['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x158136){this['providerId']=_0x158136,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1b470b){this['defaultLanguageCode']=_0x1b470b;}['setCustomParameters'](_0x32bfab){return this['customParameters']=_0x32bfab,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xaae359){return this['scopes']['includes'](_0xaae359)||this['scopes']['push'](_0xaae359),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3fc2bd){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3fc2bd});}static['credentialFromResult'](_0x3aeab3){return he['credentialFromTaggedObject'](_0x3aeab3);}static['credentialFromError'](_0x7b087b){return he['credentialFromTaggedObject'](_0x7b087b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5d94c4}){if(!_0x5d94c4||!('oauthAccessToken'in _0x5d94c4)||!_0x5d94c4['oauthAccessToken'])return null;try{return he['credential'](_0x5d94c4['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x18c5ce,_0x13ac1f){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x18c5ce,'accessToken':_0x13ac1f});}static['credentialFromResult'](_0x34f455){return ue['credentialFromTaggedObject'](_0x34f455);}static['credentialFromError'](_0x4b5eeb){return ue['credentialFromTaggedObject'](_0x4b5eeb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x91e168}){if(!_0x91e168)return null;const {oauthIdToken:_0x5a74b0,oauthAccessToken:_0x3aceef}=_0x91e168;if(!_0x5a74b0&&!_0x3aceef)return null;try{return ue['credential'](_0x5a74b0,_0x3aceef);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x351282){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x351282});}static['credentialFromResult'](_0x3567e7){return de['credentialFromTaggedObject'](_0x3567e7);}static['credentialFromError'](_0x1bc2c5){return de['credentialFromTaggedObject'](_0x1bc2c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x248e53}){if(!_0x248e53||!('oauthAccessToken'in _0x248e53)||!_0x248e53['oauthAccessToken'])return null;try{return de['credential'](_0x248e53['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x8a04e6,_0x931eb5){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x8a04e6,'oauthTokenSecret':_0x931eb5});}static['credentialFromResult'](_0x54addd){return fe['credentialFromTaggedObject'](_0x54addd);}static['credentialFromError'](_0x31bb9f){return fe['credentialFromTaggedObject'](_0x31bb9f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4354c5}){if(!_0x4354c5)return null;const {oauthAccessToken:_0x4999f6,oauthTokenSecret:_0x2da3af}=_0x4354c5;if(!_0x4999f6||!_0x2da3af)return null;try{return fe['credential'](_0x4999f6,_0x2da3af);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x6ae1af,_0xcaec6e){return Yt(_0x6ae1af,'POST','/v1/accounts:signUp',Re(_0x6ae1af,_0xcaec6e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xbe8fdd){this['user']=_0xbe8fdd['user'],this['providerId']=_0xbe8fdd['providerId'],this['_tokenResponse']=_0xbe8fdd['_tokenResponse'],this['operationType']=_0xbe8fdd['operationType'];}static async['_fromIdTokenResponse'](_0x43b5e5,_0x2b8a8c,_0x58de31,_0x55fd56=!0x1){const _0x3d1754=await z['_fromIdTokenResponse'](_0x43b5e5,_0x58de31,_0x55fd56),_0x4ffc89=Ar(_0x58de31);return new Be({'user':_0x3d1754,'providerId':_0x4ffc89,'_tokenResponse':_0x58de31,'operationType':_0x2b8a8c});}static async['_forOperation'](_0x3dc5b5,_0x471ebe,_0x2f5ab0){await _0x3dc5b5['_updateTokensIfNecessary'](_0x2f5ab0,!0x0);const _0x59b7e1=Ar(_0x2f5ab0);return new Be({'user':_0x3dc5b5,'providerId':_0x59b7e1,'_tokenResponse':_0x2f5ab0,'operationType':_0x471ebe});}}function Ar(_0x321107){return _0x321107['providerId']?_0x321107['providerId']:'phoneNumber'in _0x321107?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x29cecb,_0x1d2da1,_0x2d7289,_0x4bb53f){super(_0x1d2da1['code'],_0x1d2da1['message']),this['operationType']=_0x2d7289,this['user']=_0x4bb53f,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x29cecb['name'],'tenantId':_0x29cecb['tenantId']??void 0x0,'_serverResponse':_0x1d2da1['customData']['_serverResponse'],'operationType':_0x2d7289};}static['_fromErrorAndOperation'](_0x36bc7a,_0x593f84,_0x2b3db6,_0x1f2de7){return new Rn(_0x36bc7a,_0x593f84,_0x2b3db6,_0x1f2de7);}}function Fa(_0x3d10b2,_0x1f1b84,_0x502725,_0x9bc3d2){return(_0x1f1b84==='reauthenticate'?_0x502725['_getReauthenticationResolver'](_0x3d10b2):_0x502725['_getIdTokenResponse'](_0x3d10b2))['catch'](_0xd56aac=>{throw _0xd56aac['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3d10b2,_0xd56aac,_0x1f1b84,_0x9bc3d2):_0xd56aac;});}async function jf(_0x537a23,_0x3f99db,_0x318ed7=!0x1){const _0x1e80c9=await xt(_0x537a23,_0x3f99db['_linkToIdToken'](_0x537a23['auth'],await _0x537a23['getIdToken']()),_0x318ed7);return Be['_forOperation'](_0x537a23,'link',_0x1e80c9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x58970b,_0xe6469e,_0x20bab6=!0x1){const {auth:_0x499c02}=_0x58970b;if(H(_0x499c02['app']))return Promise['reject'](se(_0x499c02));const _0x1088fc='reauthenticate';try{const _0x2e4848=await xt(_0x58970b,Fa(_0x499c02,_0x1088fc,_0xe6469e,_0x58970b),_0x20bab6);m(_0x2e4848['idToken'],_0x499c02,'internal-error');const _0x91eed1=ws(_0x2e4848['idToken']);m(_0x91eed1,_0x499c02,'internal-error');const {sub:_0x35ff39}=_0x91eed1;return m(_0x58970b['uid']===_0x35ff39,_0x499c02,'user-mismatch'),Be['_forOperation'](_0x58970b,_0x1088fc,_0x2e4848);}catch(_0x18bff2){throw(_0x18bff2==null?void 0x0:_0x18bff2['code'])==='auth/user-not-found'&&K(_0x499c02,'user-mismatch'),_0x18bff2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x440d92,_0x58feb0,_0xed81c9=!0x1){if(H(_0x440d92['app']))return Promise['reject'](se(_0x440d92));const _0x3e4102='signIn',_0x56ab9b=await Fa(_0x440d92,_0x3e4102,_0x58feb0),_0x307d97=await Be['_fromIdTokenResponse'](_0x440d92,_0x3e4102,_0x56ab9b);return _0xed81c9||await _0x440d92['_updateCurrentUser'](_0x307d97['user']),_0x307d97;}async function Yf(_0x5a4879,_0x3c32af){return Ua(qe(_0x5a4879),_0x3c32af);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0xd22b2a){const _0x1a022f=qe(_0xd22b2a);_0x1a022f['_getPasswordPolicyInternal']()&&await _0x1a022f['_updatePasswordPolicy']();}async function R_(_0x33e543,_0x4cc595,_0x3a7217){if(H(_0x33e543['app']))return Promise['reject'](se(_0x33e543));const _0x3b87f5=qe(_0x33e543),_0x215bbf=await Oi(_0x3b87f5,{'returnSecureToken':!0x0,'email':_0x4cc595,'password':_0x3a7217,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x2adbfc=>{throw _0x2adbfc['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x33e543),_0x2adbfc;}),_0x573d0b=await Be['_fromIdTokenResponse'](_0x3b87f5,'signIn',_0x215bbf);return await _0x3b87f5['_updateCurrentUser'](_0x573d0b['user']),_0x573d0b;}function A_(_0x511860,_0x264c7c,_0x1837a2){return H(_0x511860['app'])?Promise['reject'](se(_0x511860)):Yf(k(_0x511860),ft['credential'](_0x264c7c,_0x1837a2))['catch'](async _0x4940fa=>{throw _0x4940fa['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x511860),_0x4940fa;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x393fd5,_0x5f27b7){return k(_0x393fd5)['setPersistence'](_0x5f27b7);}function Qf(_0x2b1b73,_0x1df9c3,_0x24fe8e,_0x569a06){return k(_0x2b1b73)['onIdTokenChanged'](_0x1df9c3,_0x24fe8e,_0x569a06);}function Jf(_0x2ddada,_0x28d49a,_0x1373b8){return k(_0x2ddada)['beforeAuthStateChanged'](_0x28d49a,_0x1373b8);}function N_(_0x3fc389,_0x28e90d,_0x3443a4,_0x30b4f8){return k(_0x3fc389)['onAuthStateChanged'](_0x28e90d,_0x3443a4,_0x30b4f8);}function P_(_0x3ff726){return k(_0x3ff726)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x350c8d,_0x3e949b){this['storageRetriever']=_0x350c8d,this['type']=_0x3e949b;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4e2d56,_0x2e3763){return this['storage']['setItem'](_0x4e2d56,JSON['stringify'](_0x2e3763)),Promise['resolve']();}['_get'](_0x71cc1f){const _0x1d3082=this['storage']['getItem'](_0x71cc1f);return Promise['resolve'](_0x1d3082?JSON['parse'](_0x1d3082):null);}['_remove'](_0x345cbf){return this['storage']['removeItem'](_0x345cbf),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4c0819,_0x2eaa2d)=>this['onStorageEvent'](_0x4c0819,_0x2eaa2d),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x191986){for(const _0x12814b of Object['keys'](this['listeners'])){const _0x1d2dc1=this['storage']['getItem'](_0x12814b),_0x6fda60=this['localCache'][_0x12814b];_0x1d2dc1!==_0x6fda60&&_0x191986(_0x12814b,_0x6fda60,_0x1d2dc1);}}['onStorageEvent'](_0x31125e,_0x5cf1bb=!0x1){if(!_0x31125e['key']){this['forAllChangedKeys']((_0x291e93,_0x1e1860,_0x381054)=>{this['notifyListeners'](_0x291e93,_0x381054);});return;}const _0x5a7235=_0x31125e['key'];_0x5cf1bb?this['detachListener']():this['stopPolling']();const _0x57638c=()=>{const _0x42db43=this['storage']['getItem'](_0x5a7235);!_0x5cf1bb&&this['localCache'][_0x5a7235]===_0x42db43||this['notifyListeners'](_0x5a7235,_0x42db43);},_0x34f973=this['storage']['getItem'](_0x5a7235);If()&&_0x34f973!==_0x31125e['newValue']&&_0x31125e['newValue']!==_0x31125e['oldValue']?setTimeout(_0x57638c,Zf):_0x57638c();}['notifyListeners'](_0x22e596,_0x229415){this['localCache'][_0x22e596]=_0x229415;const _0x28e6ef=this['listeners'][_0x22e596];if(_0x28e6ef){for(const _0x1463f2 of Array['from'](_0x28e6ef))_0x1463f2(_0x229415&&JSON['parse'](_0x229415));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3a9bc4,_0x18a526,_0x368312)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3a9bc4,'oldValue':_0x18a526,'newValue':_0x368312}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x362ac1,_0x3962e6){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x362ac1]||(this['listeners'][_0x362ac1]=new Set(),this['localCache'][_0x362ac1]=this['storage']['getItem'](_0x362ac1)),this['listeners'][_0x362ac1]['add'](_0x3962e6);}['_removeListener'](_0x4148d2,_0x255099){this['listeners'][_0x4148d2]&&(this['listeners'][_0x4148d2]['delete'](_0x255099),this['listeners'][_0x4148d2]['size']===0x0&&delete this['listeners'][_0x4148d2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2a8dd8,_0x48cf47){await super['_set'](_0x2a8dd8,_0x48cf47),this['localCache'][_0x2a8dd8]=JSON['stringify'](_0x48cf47);}async['_get'](_0x3bdf14){const _0x16ba02=await super['_get'](_0x3bdf14);return this['localCache'][_0x3bdf14]=JSON['stringify'](_0x16ba02),_0x16ba02;}async['_remove'](_0x420565){await super['_remove'](_0x420565),delete this['localCache'][_0x420565];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2ddd3a,_0x2f00a7){}['_removeListener'](_0x39a975,_0x4c7ef3){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1dfc9f){return Promise['all'](_0x1dfc9f['map'](async _0x39393f=>{try{return{'fulfilled':!0x0,'value':await _0x39393f};}catch(_0x314aee){return{'fulfilled':!0x1,'reason':_0x314aee};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x413720){this['eventTarget']=_0x413720,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x18d324){const _0x4b9ebd=this['receivers']['find'](_0x3c9c7c=>_0x3c9c7c['isListeningto'](_0x18d324));if(_0x4b9ebd)return _0x4b9ebd;const _0x57a2c8=new jn(_0x18d324);return this['receivers']['push'](_0x57a2c8),_0x57a2c8;}['isListeningto'](_0x43662a){return this['eventTarget']===_0x43662a;}async['handleEvent'](_0x7728ce){const _0x23d745=_0x7728ce,{eventId:_0x2a309e,eventType:_0x26e1e2,data:_0x48bd83}=_0x23d745['data'],_0x5ae462=this['handlersMap'][_0x26e1e2];if(!(_0x5ae462!=null&&_0x5ae462['size']))return;_0x23d745['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2a309e,'eventType':_0x26e1e2});const _0x191e18=Array['from'](_0x5ae462)['map'](async _0x840c83=>_0x840c83(_0x23d745['origin'],_0x48bd83)),_0x13a6af=await tp(_0x191e18);_0x23d745['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2a309e,'eventType':_0x26e1e2,'response':_0x13a6af});}['_subscribe'](_0x48993b,_0x2e8528){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x48993b]||(this['handlersMap'][_0x48993b]=new Set()),this['handlersMap'][_0x48993b]['add'](_0x2e8528);}['_unsubscribe'](_0x3172b7,_0x30ccfd){this['handlersMap'][_0x3172b7]&&_0x30ccfd&&this['handlersMap'][_0x3172b7]['delete'](_0x30ccfd),(!_0x30ccfd||this['handlersMap'][_0x3172b7]['size']===0x0)&&delete this['handlersMap'][_0x3172b7],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x1c18fd='',_0x2c167c=0xa){let _0x4981ec='';for(let _0x2ba110=0x0;_0x2ba110<_0x2c167c;_0x2ba110++)_0x4981ec+=Math['floor'](Math['random']()*0xa);return _0x1c18fd+_0x4981ec;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x4a30b2){this['target']=_0x4a30b2,this['handlers']=new Set();}['removeMessageHandler'](_0x4b8a7e){_0x4b8a7e['messageChannel']&&(_0x4b8a7e['messageChannel']['port1']['removeEventListener']('message',_0x4b8a7e['onMessage']),_0x4b8a7e['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4b8a7e);}async['_send'](_0x4b6992,_0x498770,_0x3e995d=0x32){const _0x22db98=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x22db98)throw new Error('connection_unavailable');let _0x407a92,_0x4ae944;return new Promise((_0x44c5a7,_0x5e9fc2)=>{const _0x4d8638=bs('',0x14);_0x22db98['port1']['start']();const _0x22f6b8=setTimeout(()=>{_0x5e9fc2(new Error('unsupported_event'));},_0x3e995d);_0x4ae944={'messageChannel':_0x22db98,'onMessage'(_0x292a37){const _0x2da4cd=_0x292a37;if(_0x2da4cd['data']['eventId']===_0x4d8638)switch(_0x2da4cd['data']['status']){case'ack':clearTimeout(_0x22f6b8),_0x407a92=setTimeout(()=>{_0x5e9fc2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x407a92),_0x44c5a7(_0x2da4cd['data']['response']);break;default:clearTimeout(_0x22f6b8),clearTimeout(_0x407a92),_0x5e9fc2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4ae944),_0x22db98['port1']['addEventListener']('message',_0x4ae944['onMessage']),this['target']['postMessage']({'eventType':_0x4b6992,'eventId':_0x4d8638,'data':_0x498770},[_0x22db98['port2']]);})['finally'](()=>{_0x4ae944&&this['removeMessageHandler'](_0x4ae944);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x15e66f){X()['location']['href']=_0x15e66f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x42c6ff;return((_0x42c6ff=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x42c6ff['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5bfcc4){this['request']=_0x5bfcc4;}['toPromise'](){return new Promise((_0x1878f8,_0x153fb6)=>{this['request']['addEventListener']('success',()=>{_0x1878f8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x153fb6(this['request']['error']);});});}}function Kn(_0x15b27c,_0x107892){return _0x15b27c['transaction']([kn],_0x107892?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5889c3=indexedDB['deleteDatabase'](qa);return new Jt(_0x5889c3)['toPromise']();}function ja(){const _0x10516e=indexedDB['open'](qa,ap);return new Promise((_0x5f4a19,_0x15e9a9)=>{_0x10516e['addEventListener']('error',()=>{_0x15e9a9(_0x10516e['error']);}),_0x10516e['addEventListener']('upgradeneeded',()=>{const _0x53e3be=_0x10516e['result'];try{_0x53e3be['createObjectStore'](kn,{'keyPath':za});}catch(_0x4df1fd){_0x15e9a9(_0x4df1fd);}}),_0x10516e['addEventListener']('success',async()=>{const _0x3136f8=_0x10516e['result'];_0x3136f8['objectStoreNames']['contains'](kn)?_0x5f4a19(_0x3136f8):(_0x3136f8['close'](),await cp(),_0x5f4a19(await ja()));});});}async function kr(_0x56a4,_0x96fe26,_0x461ad4){const _0x4b0a92=Kn(_0x56a4,!0x0)['put']({[za]:_0x96fe26,'value':_0x461ad4});return new Jt(_0x4b0a92)['toPromise']();}async function lp(_0x2c0861,_0x5ec54a){const _0x75bdd4=Kn(_0x2c0861,!0x1)['get'](_0x5ec54a),_0x3aa673=await new Jt(_0x75bdd4)['toPromise']();return _0x3aa673===void 0x0?null:_0x3aa673['value'];}function Nr(_0xb074f3,_0xa45b4){const _0x29e949=Kn(_0xb074f3,!0x0)['delete'](_0xa45b4);return new Jt(_0x29e949)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x263c0c){let _0x23c708=0x0;for(;;)try{const _0x244490=await this['_openDb']();return await _0x263c0c(_0x244490);}catch(_0x5d6ead){if(_0x23c708++>up)throw _0x5d6ead;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x5501dc,_0x36c8f6)=>({'keyProcessed':(await this['_poll']())['includes'](_0x36c8f6['key'])})),this['receiver']['_subscribe']('ping',async(_0x1fd74f,_0x65fe26)=>['keyChanged']);}async['initializeSender'](){var _0x10d525,_0x51bc9c;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4084ca=await this['sender']['_send']('ping',{},0x320);_0x4084ca&&(_0x10d525=_0x4084ca[0x0])!=null&&_0x10d525['fulfilled']&&(_0x51bc9c=_0x4084ca[0x0])!=null&&_0x51bc9c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x398694){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x398694},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3eeb16=>{await kr(_0x3eeb16,An,'1'),await Nr(_0x3eeb16,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5c9563){this['pendingWrites']++;try{await _0x5c9563();}finally{this['pendingWrites']--;}}async['_set'](_0x5f0dba,_0x242008){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x540c9c=>kr(_0x540c9c,_0x5f0dba,_0x242008)),this['localCache'][_0x5f0dba]=_0x242008,this['notifyServiceWorker'](_0x5f0dba)));}async['_get'](_0x3e53e6){const _0x2ef768=await this['_withRetries'](_0x52bb2c=>lp(_0x52bb2c,_0x3e53e6));return this['localCache'][_0x3e53e6]=_0x2ef768,_0x2ef768;}async['_remove'](_0x34937f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x55401f=>Nr(_0x55401f,_0x34937f)),delete this['localCache'][_0x34937f],this['notifyServiceWorker'](_0x34937f)));}async['_poll'](){const _0x442535=await this['_withRetries'](_0x390862=>{const _0x40dddc=Kn(_0x390862,!0x1)['getAll']();return new Jt(_0x40dddc)['toPromise']();});if(!_0x442535)return[];if(this['pendingWrites']!==0x0)return[];const _0x5b47c5=[],_0x4be4c1=new Set();if(_0x442535['length']!==0x0){for(const {fbase_key:_0x15d687,value:_0x552554}of _0x442535)_0x4be4c1['add'](_0x15d687),JSON['stringify'](this['localCache'][_0x15d687])!==JSON['stringify'](_0x552554)&&(this['notifyListeners'](_0x15d687,_0x552554),_0x5b47c5['push'](_0x15d687));}for(const _0x2460e8 of Object['keys'](this['localCache']))this['localCache'][_0x2460e8]&&!_0x4be4c1['has'](_0x2460e8)&&(this['notifyListeners'](_0x2460e8,null),_0x5b47c5['push'](_0x2460e8));return _0x5b47c5;}['notifyListeners'](_0x5196f7,_0x1e0a6e){this['localCache'][_0x5196f7]=_0x1e0a6e;const _0xb05617=this['listeners'][_0x5196f7];if(_0xb05617){for(const _0x4e9f2a of Array['from'](_0xb05617))_0x4e9f2a(_0x1e0a6e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x6f4eec,_0x403980){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x6f4eec]||(this['listeners'][_0x6f4eec]=new Set(),this['_get'](_0x6f4eec)),this['listeners'][_0x6f4eec]['add'](_0x403980);}['_removeListener'](_0xd9387b,_0x294135){this['listeners'][_0xd9387b]&&(this['listeners'][_0xd9387b]['delete'](_0x294135),this['listeners'][_0xd9387b]['size']===0x0&&delete this['listeners'][_0xd9387b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x28895e,_0x28aca4){return _0x28aca4?ne(_0x28aca4):(m(_0x28895e['_popupRedirectResolver'],_0x28895e,'argument-error'),_0x28895e['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x52ce74){super('custom','custom'),this['params']=_0x52ce74;}['_getIdTokenResponse'](_0x2a57b1){return Ze(_0x2a57b1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x509315,_0x1ada49){return Ze(_0x509315,this['_buildIdpRequest'](_0x1ada49));}['_getReauthenticationResolver'](_0x137c8b){return Ze(_0x137c8b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1f4063){const _0xd6d79a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1f4063&&(_0xd6d79a['idToken']=_0x1f4063),_0xd6d79a;}}function pp(_0x45c431){return Ua(_0x45c431['auth'],new Rs(_0x45c431),_0x45c431['bypassAuthState']);}function _p(_0x8e1b5b){const {auth:_0x123697,user:_0x5a79fc}=_0x8e1b5b;return m(_0x5a79fc,_0x123697,'internal-error'),Kf(_0x5a79fc,new Rs(_0x8e1b5b),_0x8e1b5b['bypassAuthState']);}async function gp(_0x3ea0cf){const {auth:_0x54fc3d,user:_0x44a438}=_0x3ea0cf;return m(_0x44a438,_0x54fc3d,'internal-error'),jf(_0x44a438,new Rs(_0x3ea0cf),_0x3ea0cf['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0xe75a7f,_0x26a24c,_0x194797,_0x5be9b6,_0x2ec2d2=!0x1){this['auth']=_0xe75a7f,this['resolver']=_0x194797,this['user']=_0x5be9b6,this['bypassAuthState']=_0x2ec2d2,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x26a24c)?_0x26a24c:[_0x26a24c];}['execute'](){return new Promise(async(_0x204315,_0x12b8af)=>{this['pendingPromise']={'resolve':_0x204315,'reject':_0x12b8af};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x36a458){this['reject'](_0x36a458);}});}async['onAuthEvent'](_0x2b6805){const {urlResponse:_0x1e8cff,sessionId:_0x442082,postBody:_0x5e899d,tenantId:_0x57fcc8,error:_0x58c431,type:_0x4a04ce}=_0x2b6805;if(_0x58c431){this['reject'](_0x58c431);return;}const _0x46aa11={'auth':this['auth'],'requestUri':_0x1e8cff,'sessionId':_0x442082,'tenantId':_0x57fcc8||void 0x0,'postBody':_0x5e899d||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4a04ce)(_0x46aa11));}catch(_0x50ed51){this['reject'](_0x50ed51);}}['onError'](_0x366210){this['reject'](_0x366210);}['getIdpTask'](_0x445971){switch(_0x445971){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x30f708){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x30f708),this['unregisterAndCleanUp']();}['reject'](_0x509e11){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x509e11),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x365ff0,_0x2776c1,_0x5a0789,_0x5ec263,_0x454c06){super(_0x365ff0,_0x2776c1,_0x5ec263,_0x454c06),this['provider']=_0x5a0789,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x368b17=await this['execute']();return m(_0x368b17,this['auth'],'internal-error'),_0x368b17;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xce9ed5=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xce9ed5),this['authWindow']['associatedEvent']=_0xce9ed5,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1627ce=>{this['reject'](_0x1627ce);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5aaf1=>{_0x5aaf1||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xfb6476;return((_0xfb6476=this['authWindow'])==null?void 0x0:_0xfb6476['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x477494=()=>{var _0x482ccc,_0x17cd44;if((_0x17cd44=(_0x482ccc=this['authWindow'])==null?void 0x0:_0x482ccc['window'])!=null&&_0x17cd44['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x477494,mp['get']());};_0x477494();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x437f2e,_0x4ef21b,_0x56286f=!0x1){super(_0x437f2e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4ef21b,void 0x0,_0x56286f),this['eventId']=null;}async['execute'](){let _0x195726=rn['get'](this['auth']['_key']());if(!_0x195726){try{const _0x38521b=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x195726=()=>Promise['resolve'](_0x38521b);}catch(_0x12aaa9){_0x195726=()=>Promise['reject'](_0x12aaa9);}rn['set'](this['auth']['_key'](),_0x195726);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x195726();}async['onAuthEvent'](_0x142e42){if(_0x142e42['type']==='signInViaRedirect')return super['onAuthEvent'](_0x142e42);if(_0x142e42['type']==='unknown'){this['resolve'](null);return;}if(_0x142e42['eventId']){const _0x4d4f92=await this['auth']['_redirectUserForId'](_0x142e42['eventId']);if(_0x4d4f92)return this['user']=_0x4d4f92,super['onAuthEvent'](_0x142e42);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x1db17e,_0x33b90b){const _0x13bcde=Cp(_0x33b90b),_0x47ce80=wp(_0x1db17e);if(!await _0x47ce80['_isAvailable']())return!0x1;const _0x381834=await _0x47ce80['_get'](_0x13bcde)==='true';return await _0x47ce80['_remove'](_0x13bcde),_0x381834;}function Ip(_0x2c275e,_0x419577){rn['set'](_0x2c275e['_key'](),_0x419577);}function wp(_0x48925c){return ne(_0x48925c['_redirectPersistence']);}function Cp(_0x1f8ff0){return sn(yp,_0x1f8ff0['config']['apiKey'],_0x1f8ff0['name']);}async function Tp(_0x4b4c68,_0xf4cf6,_0xe8df7e=!0x1){if(H(_0x4b4c68['app']))return Promise['reject'](se(_0x4b4c68));const _0x15b267=qe(_0x4b4c68),_0x13b660=fp(_0x15b267,_0xf4cf6),_0xac5412=await new vp(_0x15b267,_0x13b660,_0xe8df7e)['execute']();return _0xac5412&&!_0xe8df7e&&(delete _0xac5412['user']['_redirectEventId'],await _0x15b267['_persistUserIfCurrent'](_0xac5412['user']),await _0x15b267['_setRedirectUser'](null,_0xf4cf6)),_0xac5412;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x58436f){this['auth']=_0x58436f,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xc64d61){this['consumers']['add'](_0xc64d61),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xc64d61)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xc64d61),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xd0b6b3){this['consumers']['delete'](_0xd0b6b3);}['onEvent'](_0x4d3597){if(this['hasEventBeenHandled'](_0x4d3597))return!0x1;let _0xccd516=!0x1;return this['consumers']['forEach'](_0x355847=>{this['isEventForConsumer'](_0x4d3597,_0x355847)&&(_0xccd516=!0x0,this['sendToConsumer'](_0x4d3597,_0x355847),this['saveEventToCache'](_0x4d3597));}),this['hasHandledPotentialRedirect']||!Rp(_0x4d3597)||(this['hasHandledPotentialRedirect']=!0x0,_0xccd516||(this['queuedRedirectEvent']=_0x4d3597,_0xccd516=!0x0)),_0xccd516;}['sendToConsumer'](_0x157b4f,_0x49a9fe){var _0x5cc753;if(_0x157b4f['error']&&!Qa(_0x157b4f)){const _0x442a62=((_0x5cc753=_0x157b4f['error']['code'])==null?void 0x0:_0x5cc753['split']('auth/')[0x1])||'internal-error';_0x49a9fe['onError'](J(this['auth'],_0x442a62));}else _0x49a9fe['onAuthEvent'](_0x157b4f);}['isEventForConsumer'](_0x523c94,_0x814b1a){const _0x14e664=_0x814b1a['eventId']===null||!!_0x523c94['eventId']&&_0x523c94['eventId']===_0x814b1a['eventId'];return _0x814b1a['filter']['includes'](_0x523c94['type'])&&_0x14e664;}['hasEventBeenHandled'](_0x51dd24){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x51dd24));}['saveEventToCache'](_0x3c49ad){this['cachedEventUids']['add'](Pr(_0x3c49ad)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2fe73a){return[_0x2fe73a['type'],_0x2fe73a['eventId'],_0x2fe73a['sessionId'],_0x2fe73a['tenantId']]['filter'](_0x55707b=>_0x55707b)['join']('-');}function Qa({type:_0x472bcf,error:_0x199d4b}){return _0x472bcf==='unknown'&&(_0x199d4b==null?void 0x0:_0x199d4b['code'])==='auth/no-auth-event';}function Rp(_0xb9b42b){switch(_0xb9b42b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0xb9b42b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x34cf26,_0x15c5b5={}){return Ae(_0x34cf26,'GET','/v1/projects',_0x15c5b5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3a782b){if(_0x3a782b['config']['emulator'])return;const {authorizedDomains:_0x184581}=await Ap(_0x3a782b);for(const _0x2df216 of _0x184581)try{if(Op(_0x2df216))return;}catch{}K(_0x3a782b,'unauthorized-domain');}function Op(_0x4fd043){const _0xdca8b=Ni(),{protocol:_0x179b59,hostname:_0x3c2ed1}=new URL(_0xdca8b);if(_0x4fd043['startsWith']('chrome-extension://')){const _0x176ada=new URL(_0x4fd043);return _0x176ada['hostname']===''&&_0x3c2ed1===''?_0x179b59==='chrome-extension:'&&_0x4fd043['replace']('chrome-extension://','')===_0xdca8b['replace']('chrome-extension://',''):_0x179b59==='chrome-extension:'&&_0x176ada['hostname']===_0x3c2ed1;}if(!Np['test'](_0x179b59))return!0x1;if(kp['test'](_0x4fd043))return _0x3c2ed1===_0x4fd043;const _0x138f3f=_0x4fd043['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x138f3f+'|'+_0x138f3f+')$','i')['test'](_0x3c2ed1);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x56302d=X()['___jsl'];if(_0x56302d!=null&&_0x56302d['H']){for(const _0x1ec91f of Object['keys'](_0x56302d['H']))if(_0x56302d['H'][_0x1ec91f]['r']=_0x56302d['H'][_0x1ec91f]['r']||[],_0x56302d['H'][_0x1ec91f]['L']=_0x56302d['H'][_0x1ec91f]['L']||[],_0x56302d['H'][_0x1ec91f]['r']=[..._0x56302d['H'][_0x1ec91f]['L']],_0x56302d['CP']){for(let _0x215743=0x0;_0x215743<_0x56302d['CP']['length'];_0x215743++)_0x56302d['CP'][_0x215743]=null;}}}function Mp(_0x41fb70){return new Promise((_0x2733c9,_0x30414c)=>{var _0x2a0c32,_0x195546,_0x1e68f7;function _0x5e847d(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2733c9(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x30414c(J(_0x41fb70,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x195546=(_0x2a0c32=X()['gapi'])==null?void 0x0:_0x2a0c32['iframes'])!=null&&_0x195546['Iframe'])_0x2733c9(gapi['iframes']['getContext']());else{if((_0x1e68f7=X()['gapi'])!=null&&_0x1e68f7['load'])_0x5e847d();else{const _0x12fb6f=Nf('iframefcb');return X()[_0x12fb6f]=()=>{gapi['load']?_0x5e847d():_0x30414c(J(_0x41fb70,'network-request-failed'));},Da(kf()+'?onload='+_0x12fb6f)['catch'](_0x3fbfb6=>_0x30414c(_0x3fbfb6));}}})['catch'](_0x5984c2=>{throw on=null,_0x5984c2;});}let on=null;function Lp(_0x433e13){return on=on||Mp(_0x433e13),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x2ffa70){const _0x49a63b=_0x2ffa70['config'];m(_0x49a63b['authDomain'],_0x2ffa70,'auth-domain-config-required');const _0xaa7342=_0x49a63b['emulator']?Is(_0x49a63b,Up):'https://'+_0x2ffa70['config']['authDomain']+'/'+Fp,_0x5bf5ad={'apiKey':_0x49a63b['apiKey'],'appName':_0x2ffa70['name'],'v':ct},_0x35ff97=Bp['get'](_0x2ffa70['config']['apiHost']);_0x35ff97&&(_0x5bf5ad['eid']=_0x35ff97);const _0x57730b=_0x2ffa70['_getFrameworks']();return _0x57730b['length']&&(_0x5bf5ad['fw']=_0x57730b['join'](',')),_0xaa7342+'?'+at(_0x5bf5ad)['slice'](0x1);}async function Hp(_0x5af74f){const _0x451479=await Lp(_0x5af74f),_0x147db2=X()['gapi'];return m(_0x147db2,_0x5af74f,'internal-error'),_0x451479['open']({'where':document['body'],'url':Vp(_0x5af74f),'messageHandlersFilter':_0x147db2['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x5cf23f=>new Promise(async(_0x16d87a,_0x15f824)=>{await _0x5cf23f['restyle']({'setHideOnLeave':!0x1});const _0x55cdc1=J(_0x5af74f,'network-request-failed'),_0x5dd79c=X()['setTimeout'](()=>{_0x15f824(_0x55cdc1);},xp['get']());function _0x4130e7(){X()['clearTimeout'](_0x5dd79c),_0x16d87a(_0x5cf23f);}_0x5cf23f['ping'](_0x4130e7)['then'](_0x4130e7,()=>{_0x15f824(_0x55cdc1);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x33e4d0){this['window']=_0x33e4d0,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x6335ec,_0x521cdd,_0xdc86ff,_0x20dd81=Gp,_0x3bc686=qp){const _0xd66919=Math['max']((window['screen']['availHeight']-_0x3bc686)/0x2,0x0)['toString'](),_0x7b32f7=Math['max']((window['screen']['availWidth']-_0x20dd81)/0x2,0x0)['toString']();let _0x19c4e5='';const _0x311c73={...$p,'width':_0x20dd81['toString'](),'height':_0x3bc686['toString'](),'top':_0xd66919,'left':_0x7b32f7},_0x4c52b2=W()['toLowerCase']();_0xdc86ff&&(_0x19c4e5=ba(_0x4c52b2)?zp:_0xdc86ff),Ta(_0x4c52b2)&&(_0x521cdd=_0x521cdd||jp,_0x311c73['scrollbars']='yes');const _0x17d976=Object['entries'](_0x311c73)['reduce']((_0x14e211,[_0x4e72b2,_0x1ea677])=>''+_0x14e211+_0x4e72b2+'='+_0x1ea677+',','');if(Ef(_0x4c52b2)&&_0x19c4e5!=='_self')return Yp(_0x521cdd||'',_0x19c4e5),new Dr(null);const _0x4bac9e=window['open'](_0x521cdd||'',_0x19c4e5,_0x17d976);m(_0x4bac9e,_0x6335ec,'popup-blocked');try{_0x4bac9e['focus']();}catch{}return new Dr(_0x4bac9e);}function Yp(_0x1c16eb,_0x1a4a78){const _0x466329=document['createElement']('a');_0x466329['href']=_0x1c16eb,_0x466329['target']=_0x1a4a78;const _0x233595=document['createEvent']('MouseEvent');_0x233595['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x466329['dispatchEvent'](_0x233595);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x49e2bb,_0x33aa50,_0x2d9d45,_0x304ff8,_0x1ec99f,_0x4c96aa){m(_0x49e2bb['config']['authDomain'],_0x49e2bb,'auth-domain-config-required'),m(_0x49e2bb['config']['apiKey'],_0x49e2bb,'invalid-api-key');const _0x4e43f7={'apiKey':_0x49e2bb['config']['apiKey'],'appName':_0x49e2bb['name'],'authType':_0x2d9d45,'redirectUrl':_0x304ff8,'v':ct,'eventId':_0x1ec99f};if(_0x33aa50 instanceof xa){_0x33aa50['setDefaultLanguage'](_0x49e2bb['languageCode']),_0x4e43f7['providerId']=_0x33aa50['providerId']||'',hi(_0x33aa50['getCustomParameters']())||(_0x4e43f7['customParameters']=JSON['stringify'](_0x33aa50['getCustomParameters']()));for(const [_0x1ebc04,_0x2b7602]of Object['entries']({}))_0x4e43f7[_0x1ebc04]=_0x2b7602;}if(_0x33aa50 instanceof Qt){const _0x4d5080=_0x33aa50['getScopes']()['filter'](_0x238850=>_0x238850!=='');_0x4d5080['length']>0x0&&(_0x4e43f7['scopes']=_0x4d5080['join'](','));}_0x49e2bb['tenantId']&&(_0x4e43f7['tid']=_0x49e2bb['tenantId']);const _0x421bf6=_0x4e43f7;for(const _0x451c7b of Object['keys'](_0x421bf6))_0x421bf6[_0x451c7b]===void 0x0&&delete _0x421bf6[_0x451c7b];const _0x5abc38=await _0x49e2bb['_getAppCheckToken'](),_0x11188e=_0x5abc38?'#'+Xp+'='+encodeURIComponent(_0x5abc38):'';return Zp(_0x49e2bb)+'?'+at(_0x421bf6)['slice'](0x1)+_0x11188e;}function Zp({config:_0x55f4ad}){return _0x55f4ad['emulator']?Is(_0x55f4ad,Jp):'https://'+_0x55f4ad['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x47ee21,_0x3cfadd,_0x28afa7,_0x44bf6d){var _0x592944;ae((_0x592944=this['eventManagers'][_0x47ee21['_key']()])==null?void 0x0:_0x592944['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x49ac76=await Mr(_0x47ee21,_0x3cfadd,_0x28afa7,Ni(),_0x44bf6d);return Kp(_0x47ee21,_0x49ac76,bs());}async['_openRedirect'](_0x16a9da,_0x5f292c,_0x45a8d7,_0x3f8d17){await this['_originValidation'](_0x16a9da);const _0x595aa0=await Mr(_0x16a9da,_0x5f292c,_0x45a8d7,Ni(),_0x3f8d17);return ip(_0x595aa0),new Promise(()=>{});}['_initialize'](_0x396bda){const _0x50acdc=_0x396bda['_key']();if(this['eventManagers'][_0x50acdc]){const {manager:_0xb696ac,promise:_0x52251a}=this['eventManagers'][_0x50acdc];return _0xb696ac?Promise['resolve'](_0xb696ac):(ae(_0x52251a,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x52251a);}const _0x58794a=this['initAndGetManager'](_0x396bda);return this['eventManagers'][_0x50acdc]={'promise':_0x58794a},_0x58794a['catch'](()=>{delete this['eventManagers'][_0x50acdc];}),_0x58794a;}async['initAndGetManager'](_0x73990b){const _0x3d5251=await Hp(_0x73990b),_0x247aec=new bp(_0x73990b);return _0x3d5251['register']('authEvent',_0x302f6b=>(m(_0x302f6b==null?void 0x0:_0x302f6b['authEvent'],_0x73990b,'invalid-auth-event'),{'status':_0x247aec['onEvent'](_0x302f6b['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x73990b['_key']()]={'manager':_0x247aec},this['iframes'][_0x73990b['_key']()]=_0x3d5251,_0x247aec;}['_isIframeWebStorageSupported'](_0x545dcb,_0x4bc1f0){this['iframes'][_0x545dcb['_key']()]['send'](li,{'type':li},_0x469e2f=>{var _0x559bc1;const _0x527019=(_0x559bc1=_0x469e2f==null?void 0x0:_0x469e2f[0x0])==null?void 0x0:_0x559bc1[li];_0x527019!==void 0x0&&_0x4bc1f0(!!_0x527019),K(_0x545dcb,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x24ba02){const _0xa8d764=_0x24ba02['_key']();return this['originValidationPromises'][_0xa8d764]||(this['originValidationPromises'][_0xa8d764]=Pp(_0x24ba02)),this['originValidationPromises'][_0xa8d764];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x54fb84){this['auth']=_0x54fb84,this['internalListeners']=new Map();}['getUid'](){var _0x466475;return this['assertAuthConfigured'](),((_0x466475=this['auth']['currentUser'])==null?void 0x0:_0x466475['uid'])||null;}async['getToken'](_0x3ded6f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3ded6f)}:null;}['addAuthTokenListener'](_0x2a94e6){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2a94e6))return;const _0xb65bfd=this['auth']['onIdTokenChanged'](_0xc57e01=>{_0x2a94e6((_0xc57e01==null?void 0x0:_0xc57e01['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2a94e6,_0xb65bfd),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3d19df){this['assertAuthConfigured']();const _0x581235=this['internalListeners']['get'](_0x3d19df);_0x581235&&(this['internalListeners']['delete'](_0x3d19df),_0x581235(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0xa5854){switch(_0xa5854){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x1c48ab){et(new Me('auth',(_0x27a4d6,{options:_0x2dff2e})=>{const _0x585774=_0x27a4d6['getProvider']('app')['getImmediate'](),_0x2a5c59=_0x27a4d6['getProvider']('heartbeat'),_0x43e50c=_0x27a4d6['getProvider']('app-check-internal'),{apiKey:_0xf816ad,authDomain:_0x3b88cf}=_0x585774['options'];m(_0xf816ad&&!_0xf816ad['includes'](':'),'invalid-api-key',{'appName':_0x585774['name']});const _0x4e2975={'apiKey':_0xf816ad,'authDomain':_0x3b88cf,'clientPlatform':_0x1c48ab,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x1c48ab)},_0x12d352=new bf(_0x585774,_0x2a5c59,_0x43e50c,_0x4e2975);return Lf(_0x12d352,_0x2dff2e),_0x12d352;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x4ac2e2,_0x16968d,_0x2f3c06)=>{_0x4ac2e2['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0xa43a0c=>{const _0x30b508=qe(_0xa43a0c['getProvider']('auth')['getImmediate']());return(_0x31b8ee=>new n_(_0x31b8ee))(_0x30b508);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x1c48ab)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x3a1a40=>async _0x2ad32b=>{const _0x39b84a=_0x2ad32b&&await _0x2ad32b['getIdTokenResult'](),_0x5b9bbc=_0x39b84a&&(new Date()['getTime']()-Date['parse'](_0x39b84a['issuedAtTime']))/0x3e8;if(_0x5b9bbc&&_0x5b9bbc>o_)return;const _0x583fa1=_0x39b84a==null?void 0x0:_0x39b84a['token'];Fr!==_0x583fa1&&(Fr=_0x583fa1,await fetch(_0x3a1a40,{'method':_0x583fa1?'POST':'DELETE','headers':_0x583fa1?{'Authorization':'Bearer\x20'+_0x583fa1}:{}}));};function O_(_0x1ac1a0=Qr()){const _0x53dcb4=Ui(_0x1ac1a0,'auth');if(_0x53dcb4['isInitialized']())return _0x53dcb4['getImmediate']();const _0x1bb4d1=Mf(_0x1ac1a0,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x417007=Gr('authTokenSyncURL');if(_0x417007&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3b64ac=new URL(_0x417007,location['origin']);if(location['origin']===_0x3b64ac['origin']){const _0x565789=a_(_0x3b64ac['toString']());Jf(_0x1bb4d1,_0x565789,()=>_0x565789(_0x1bb4d1['currentUser'])),Qf(_0x1bb4d1,_0x1b50d3=>_0x565789(_0x1b50d3));}}const _0x39019f=Hr('auth');return _0x39019f&&xf(_0x1bb4d1,'http://'+_0x39019f),_0x1bb4d1;}function c_(){var _0x4e18e3;return((_0x4e18e3=document['getElementsByTagName']('head'))==null?void 0x0:_0x4e18e3[0x0])??document;}Rf({'loadJS'(_0x56f135){return new Promise((_0x591f7b,_0x218c98)=>{const _0x48acf3=document['createElement']('script');_0x48acf3['setAttribute']('src',_0x56f135),_0x48acf3['onload']=_0x591f7b,_0x48acf3['onerror']=_0x1f5dea=>{const _0xb2f5aa=J('internal-error');_0xb2f5aa['customData']=_0x1f5dea,_0x218c98(_0xb2f5aa);},_0x48acf3['type']='text/javascript',_0x48acf3['charset']='UTF-8',c_()['appendChild'](_0x48acf3);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};