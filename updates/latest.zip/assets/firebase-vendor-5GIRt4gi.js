const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3c36cd,_0xefade9){if(!_0x3c36cd)throw ot(_0xefade9);},ot=function(_0x3e8eca){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3e8eca);},Wr=function(_0x17cb78){const _0x4c6dcc=[];let _0x43c837=0x0;for(let _0x1e0b24=0x0;_0x1e0b24<_0x17cb78['length'];_0x1e0b24++){let _0x3bf379=_0x17cb78['charCodeAt'](_0x1e0b24);_0x3bf379<0x80?_0x4c6dcc[_0x43c837++]=_0x3bf379:_0x3bf379<0x800?(_0x4c6dcc[_0x43c837++]=_0x3bf379>>0x6|0xc0,_0x4c6dcc[_0x43c837++]=_0x3bf379&0x3f|0x80):(_0x3bf379&0xfc00)===0xd800&&_0x1e0b24+0x1<_0x17cb78['length']&&(_0x17cb78['charCodeAt'](_0x1e0b24+0x1)&0xfc00)===0xdc00?(_0x3bf379=0x10000+((_0x3bf379&0x3ff)<<0xa)+(_0x17cb78['charCodeAt'](++_0x1e0b24)&0x3ff),_0x4c6dcc[_0x43c837++]=_0x3bf379>>0x12|0xf0,_0x4c6dcc[_0x43c837++]=_0x3bf379>>0xc&0x3f|0x80,_0x4c6dcc[_0x43c837++]=_0x3bf379>>0x6&0x3f|0x80,_0x4c6dcc[_0x43c837++]=_0x3bf379&0x3f|0x80):(_0x4c6dcc[_0x43c837++]=_0x3bf379>>0xc|0xe0,_0x4c6dcc[_0x43c837++]=_0x3bf379>>0x6&0x3f|0x80,_0x4c6dcc[_0x43c837++]=_0x3bf379&0x3f|0x80);}return _0x4c6dcc;},Za=function(_0x170e89){const _0x5e0aed=[];let _0xfb1eae=0x0,_0x57e26e=0x0;for(;_0xfb1eae<_0x170e89['length'];){const _0x1ac85c=_0x170e89[_0xfb1eae++];if(_0x1ac85c<0x80)_0x5e0aed[_0x57e26e++]=String['fromCharCode'](_0x1ac85c);else{if(_0x1ac85c>0xbf&&_0x1ac85c<0xe0){const _0x351b53=_0x170e89[_0xfb1eae++];_0x5e0aed[_0x57e26e++]=String['fromCharCode']((_0x1ac85c&0x1f)<<0x6|_0x351b53&0x3f);}else{if(_0x1ac85c>0xef&&_0x1ac85c<0x16d){const _0x46e15a=_0x170e89[_0xfb1eae++],_0x21aab9=_0x170e89[_0xfb1eae++],_0x12c94c=_0x170e89[_0xfb1eae++],_0x30f739=((_0x1ac85c&0x7)<<0x12|(_0x46e15a&0x3f)<<0xc|(_0x21aab9&0x3f)<<0x6|_0x12c94c&0x3f)-0x10000;_0x5e0aed[_0x57e26e++]=String['fromCharCode'](0xd800+(_0x30f739>>0xa)),_0x5e0aed[_0x57e26e++]=String['fromCharCode'](0xdc00+(_0x30f739&0x3ff));}else{const _0x2dedff=_0x170e89[_0xfb1eae++],_0x27545d=_0x170e89[_0xfb1eae++];_0x5e0aed[_0x57e26e++]=String['fromCharCode']((_0x1ac85c&0xf)<<0xc|(_0x2dedff&0x3f)<<0x6|_0x27545d&0x3f);}}}}return _0x5e0aed['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x283038,_0x108f7e){if(!Array['isArray'](_0x283038))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x435ddf=_0x108f7e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x57d5c0=[];for(let _0x282131=0x0;_0x282131<_0x283038['length'];_0x282131+=0x3){const _0x237c0f=_0x283038[_0x282131],_0xa85f9f=_0x282131+0x1<_0x283038['length'],_0x304b34=_0xa85f9f?_0x283038[_0x282131+0x1]:0x0,_0x31c587=_0x282131+0x2<_0x283038['length'],_0x1dfd6b=_0x31c587?_0x283038[_0x282131+0x2]:0x0,_0x1801fa=_0x237c0f>>0x2,_0x4f6b84=(_0x237c0f&0x3)<<0x4|_0x304b34>>0x4;let _0x55115b=(_0x304b34&0xf)<<0x2|_0x1dfd6b>>0x6,_0x115795=_0x1dfd6b&0x3f;_0x31c587||(_0x115795=0x40,_0xa85f9f||(_0x55115b=0x40)),_0x57d5c0['push'](_0x435ddf[_0x1801fa],_0x435ddf[_0x4f6b84],_0x435ddf[_0x55115b],_0x435ddf[_0x115795]);}return _0x57d5c0['join']('');},'encodeString'(_0x2909be,_0x8e50b5){return this['HAS_NATIVE_SUPPORT']&&!_0x8e50b5?btoa(_0x2909be):this['encodeByteArray'](Wr(_0x2909be),_0x8e50b5);},'decodeString'(_0x38bf94,_0x50bc64){return this['HAS_NATIVE_SUPPORT']&&!_0x50bc64?atob(_0x38bf94):Za(this['decodeStringToByteArray'](_0x38bf94,_0x50bc64));},'decodeStringToByteArray'(_0x358170,_0x4b5e38){this['init_']();const _0x3d2865=_0x4b5e38?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5de358=[];for(let _0x4ed34a=0x0;_0x4ed34a<_0x358170['length'];){const _0x17d340=_0x3d2865[_0x358170['charAt'](_0x4ed34a++)],_0x53e304=_0x4ed34a<_0x358170['length']?_0x3d2865[_0x358170['charAt'](_0x4ed34a)]:0x0;++_0x4ed34a;const _0x5036c5=_0x4ed34a<_0x358170['length']?_0x3d2865[_0x358170['charAt'](_0x4ed34a)]:0x40;++_0x4ed34a;const _0x22ebe6=_0x4ed34a<_0x358170['length']?_0x3d2865[_0x358170['charAt'](_0x4ed34a)]:0x40;if(++_0x4ed34a,_0x17d340==null||_0x53e304==null||_0x5036c5==null||_0x22ebe6==null)throw new ec();const _0x205412=_0x17d340<<0x2|_0x53e304>>0x4;if(_0x5de358['push'](_0x205412),_0x5036c5!==0x40){const _0x222969=_0x53e304<<0x4&0xf0|_0x5036c5>>0x2;if(_0x5de358['push'](_0x222969),_0x22ebe6!==0x40){const _0x5de8de=_0x5036c5<<0x6&0xc0|_0x22ebe6;_0x5de358['push'](_0x5de8de);}}}return _0x5de358;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5e3fa1=0x0;_0x5e3fa1<this['ENCODED_VALS']['length'];_0x5e3fa1++)this['byteToCharMap_'][_0x5e3fa1]=this['ENCODED_VALS']['charAt'](_0x5e3fa1),this['charToByteMap_'][this['byteToCharMap_'][_0x5e3fa1]]=_0x5e3fa1,this['byteToCharMapWebSafe_'][_0x5e3fa1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5e3fa1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5e3fa1]]=_0x5e3fa1,_0x5e3fa1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5e3fa1)]=_0x5e3fa1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5e3fa1)]=_0x5e3fa1);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x1a6bba){const _0x37cac7=Wr(_0x1a6bba);return Di['encodeByteArray'](_0x37cac7,!0x0);},an=function(_0xe5b5d5){return Br(_0xe5b5d5)['replace'](/\./g,'');},cn=function(_0x42691c){try{return Di['decodeString'](_0x42691c,!0x0);}catch(_0x2dab2c){console['error']('base64Decode\x20failed:\x20',_0x2dab2c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x320013){return Vr(void 0x0,_0x320013);}function Vr(_0x227746,_0x166c1b){if(!(_0x166c1b instanceof Object))return _0x166c1b;switch(_0x166c1b['constructor']){case Date:const _0x544407=_0x166c1b;return new Date(_0x544407['getTime']());case Object:_0x227746===void 0x0&&(_0x227746={});break;case Array:_0x227746=[];break;default:return _0x166c1b;}for(const _0x3e29ad in _0x166c1b)!_0x166c1b['hasOwnProperty'](_0x3e29ad)||!nc(_0x3e29ad)||(_0x227746[_0x3e29ad]=Vr(_0x227746[_0x3e29ad],_0x166c1b[_0x3e29ad]));return _0x227746;}function nc(_0x3c276d){return _0x3c276d!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x53fabf=As['__FIREBASE_DEFAULTS__'];if(_0x53fabf)return JSON['parse'](_0x53fabf);},oc=()=>{if(typeof document>'u')return;let _0x101ba7;try{_0x101ba7=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2f7e62=_0x101ba7&&cn(_0x101ba7[0x1]);return _0x2f7e62&&JSON['parse'](_0x2f7e62);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x337195){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x337195);return;}},Hr=_0x3a635c=>{var _0x310a9f,_0x273f29;return(_0x273f29=(_0x310a9f=Mi())==null?void 0x0:_0x310a9f['emulatorHosts'])==null?void 0x0:_0x273f29[_0x3a635c];},ac=_0xa7f999=>{const _0x1f864c=Hr(_0xa7f999);if(!_0x1f864c)return;const _0x47f891=_0x1f864c['lastIndexOf'](':');if(_0x47f891<=0x0||_0x47f891+0x1===_0x1f864c['length'])throw new Error('Invalid\x20host\x20'+_0x1f864c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x209f4d=parseInt(_0x1f864c['substring'](_0x47f891+0x1),0xa);return _0x1f864c[0x0]==='['?[_0x1f864c['substring'](0x1,_0x47f891-0x1),_0x209f4d]:[_0x1f864c['substring'](0x0,_0x47f891),_0x209f4d];},$r=()=>{var _0x139f36;return(_0x139f36=Mi())==null?void 0x0:_0x139f36['config'];},Gr=_0x38af33=>{var _0x3453c8;return(_0x3453c8=Mi())==null?void 0x0:_0x3453c8['_'+_0x38af33];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1e130e,_0x32fa7b)=>{this['resolve']=_0x1e130e,this['reject']=_0x32fa7b;});}['wrapCallback'](_0x20fb3e){return(_0x41ddea,_0x2a1026)=>{_0x41ddea?this['reject'](_0x41ddea):this['resolve'](_0x2a1026),typeof _0x20fb3e=='function'&&(this['promise']['catch'](()=>{}),_0x20fb3e['length']===0x1?_0x20fb3e(_0x41ddea):_0x20fb3e(_0x41ddea,_0x2a1026));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3d7c22,_0x3263e6){if(_0x3d7c22['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xafd3b9={'alg':'none','type':'JWT'},_0xf01744=_0x3263e6||'demo-project',_0x28d281=_0x3d7c22['iat']||0x0,_0x122e09=_0x3d7c22['sub']||_0x3d7c22['user_id'];if(!_0x122e09)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x30726e={'iss':'https://securetoken.google.com/'+_0xf01744,'aud':_0xf01744,'iat':_0x28d281,'exp':_0x28d281+0xe10,'auth_time':_0x28d281,'sub':_0x122e09,'user_id':_0x122e09,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3d7c22};return[an(JSON['stringify'](_0xafd3b9)),an(JSON['stringify'](_0x30726e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x5d9a00=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5d9a00=='object'&&_0x5d9a00['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x503ec9=W();return _0x503ec9['indexOf']('MSIE\x20')>=0x0||_0x503ec9['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x16296b,_0x18648c)=>{try{let _0x2b4ff7=!0x0;const _0x252e2a='validate-browser-context-for-indexeddb-analytics-module',_0x488a70=self['indexedDB']['open'](_0x252e2a);_0x488a70['onsuccess']=()=>{_0x488a70['result']['close'](),_0x2b4ff7||self['indexedDB']['deleteDatabase'](_0x252e2a),_0x16296b(!0x0);},_0x488a70['onupgradeneeded']=()=>{_0x2b4ff7=!0x1;},_0x488a70['onerror']=()=>{var _0x3b214c;_0x18648c(((_0x3b214c=_0x488a70['error'])==null?void 0x0:_0x3b214c['message'])||'');};}catch(_0x4cc909){_0x18648c(_0x4cc909);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x284465,_0x53ae28,_0x56b4d6){super(_0x53ae28),this['code']=_0x284465,this['customData']=_0x56b4d6,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x6be82a,_0x175842,_0x3877c4){this['service']=_0x6be82a,this['serviceName']=_0x175842,this['errors']=_0x3877c4;}['create'](_0x4a1b19,..._0x1405cb){const _0x4c31a6=_0x1405cb[0x0]||{},_0x3ad22a=this['service']+'/'+_0x4a1b19,_0x40240e=this['errors'][_0x4a1b19],_0x14c0b0=_0x40240e?gc(_0x40240e,_0x4c31a6):'Error',_0x3c4257=this['serviceName']+':\x20'+_0x14c0b0+'\x20('+_0x3ad22a+').';return new Se(_0x3ad22a,_0x3c4257,_0x4c31a6);}}function gc(_0x172759,_0x38c8df){return _0x172759['replace'](mc,(_0x41c1ff,_0x9b3645)=>{const _0xf3bd12=_0x38c8df[_0x9b3645];return _0xf3bd12!=null?String(_0xf3bd12):'<'+_0x9b3645+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x3c05a0){return JSON['parse'](_0x3c05a0);}function O(_0x59d506){return JSON['stringify'](_0x59d506);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x599410){let _0x440183={},_0x3cbf09={},_0x4df567={},_0x5d95b4='';try{const _0x2577a5=_0x599410['split']('.');_0x440183=bt(cn(_0x2577a5[0x0])||''),_0x3cbf09=bt(cn(_0x2577a5[0x1])||''),_0x5d95b4=_0x2577a5[0x2],_0x4df567=_0x3cbf09['d']||{},delete _0x3cbf09['d'];}catch{}return{'header':_0x440183,'claims':_0x3cbf09,'data':_0x4df567,'signature':_0x5d95b4};},yc=function(_0x3ea7b4){const _0x4d92e6=zr(_0x3ea7b4),_0x3a84bd=_0x4d92e6['claims'];return!!_0x3a84bd&&typeof _0x3a84bd=='object'&&_0x3a84bd['hasOwnProperty']('iat');},vc=function(_0x598775){const _0x5de706=zr(_0x598775)['claims'];return typeof _0x5de706=='object'&&_0x5de706['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x32e8ce,_0x5a5656){return Object['prototype']['hasOwnProperty']['call'](_0x32e8ce,_0x5a5656);}function Oe(_0x4d10d4,_0x3b6c13){if(Object['prototype']['hasOwnProperty']['call'](_0x4d10d4,_0x3b6c13))return _0x4d10d4[_0x3b6c13];}function hi(_0xaa104a){for(const _0x532866 in _0xaa104a)if(Object['prototype']['hasOwnProperty']['call'](_0xaa104a,_0x532866))return!0x1;return!0x0;}function ln(_0x535f76,_0x33de55,_0xbe1985){const _0x3f2fa4={};for(const _0x4d722a in _0x535f76)Object['prototype']['hasOwnProperty']['call'](_0x535f76,_0x4d722a)&&(_0x3f2fa4[_0x4d722a]=_0x33de55['call'](_0xbe1985,_0x535f76[_0x4d722a],_0x4d722a,_0x535f76));return _0x3f2fa4;}function De(_0x53c4fc,_0x2c7cc1){if(_0x53c4fc===_0x2c7cc1)return!0x0;const _0x411fee=Object['keys'](_0x53c4fc),_0x1ff177=Object['keys'](_0x2c7cc1);for(const _0xbfcf26 of _0x411fee){if(!_0x1ff177['includes'](_0xbfcf26))return!0x1;const _0x270b45=_0x53c4fc[_0xbfcf26],_0x32e862=_0x2c7cc1[_0xbfcf26];if(ks(_0x270b45)&&ks(_0x32e862)){if(!De(_0x270b45,_0x32e862))return!0x1;}else{if(_0x270b45!==_0x32e862)return!0x1;}}for(const _0x5ae525 of _0x1ff177)if(!_0x411fee['includes'](_0x5ae525))return!0x1;return!0x0;}function ks(_0x33643b){return _0x33643b!==null&&typeof _0x33643b=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x38f42b){const _0x5e42cd=[];for(const [_0x260130,_0xca7ae6]of Object['entries'](_0x38f42b))Array['isArray'](_0xca7ae6)?_0xca7ae6['forEach'](_0x24cbae=>{_0x5e42cd['push'](encodeURIComponent(_0x260130)+'='+encodeURIComponent(_0x24cbae));}):_0x5e42cd['push'](encodeURIComponent(_0x260130)+'='+encodeURIComponent(_0xca7ae6));return _0x5e42cd['length']?'&'+_0x5e42cd['join']('&'):'';}function yt(_0x2c987b){const _0xf08ef7={};return _0x2c987b['replace'](/^\?/,'')['split']('&')['forEach'](_0xb0c856=>{if(_0xb0c856){const [_0x74df91,_0x363739]=_0xb0c856['split']('=');_0xf08ef7[decodeURIComponent(_0x74df91)]=decodeURIComponent(_0x363739);}}),_0xf08ef7;}function vt(_0x45e796){const _0x44b67b=_0x45e796['indexOf']('?');if(!_0x44b67b)return'';const _0x5641ac=_0x45e796['indexOf']('#',_0x44b67b);return _0x45e796['substring'](_0x44b67b,_0x5641ac>0x0?_0x5641ac:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1381ef=0x1;_0x1381ef<this['blockSize'];++_0x1381ef)this['pad_'][_0x1381ef]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1a66d3,_0x17228b){_0x17228b||(_0x17228b=0x0);const _0x4f33ac=this['W_'];if(typeof _0x1a66d3=='string'){for(let _0x10ba54=0x0;_0x10ba54<0x10;_0x10ba54++)_0x4f33ac[_0x10ba54]=_0x1a66d3['charCodeAt'](_0x17228b)<<0x18|_0x1a66d3['charCodeAt'](_0x17228b+0x1)<<0x10|_0x1a66d3['charCodeAt'](_0x17228b+0x2)<<0x8|_0x1a66d3['charCodeAt'](_0x17228b+0x3),_0x17228b+=0x4;}else{for(let _0x486f7d=0x0;_0x486f7d<0x10;_0x486f7d++)_0x4f33ac[_0x486f7d]=_0x1a66d3[_0x17228b]<<0x18|_0x1a66d3[_0x17228b+0x1]<<0x10|_0x1a66d3[_0x17228b+0x2]<<0x8|_0x1a66d3[_0x17228b+0x3],_0x17228b+=0x4;}for(let _0x1a6f9d=0x10;_0x1a6f9d<0x50;_0x1a6f9d++){const _0x10146e=_0x4f33ac[_0x1a6f9d-0x3]^_0x4f33ac[_0x1a6f9d-0x8]^_0x4f33ac[_0x1a6f9d-0xe]^_0x4f33ac[_0x1a6f9d-0x10];_0x4f33ac[_0x1a6f9d]=(_0x10146e<<0x1|_0x10146e>>>0x1f)&0xffffffff;}let _0x21eaee=this['chain_'][0x0],_0xb8c03b=this['chain_'][0x1],_0x513b41=this['chain_'][0x2],_0x36fa34=this['chain_'][0x3],_0x2be381=this['chain_'][0x4],_0x3a0813,_0x4ddaf7;for(let _0x1e7070=0x0;_0x1e7070<0x50;_0x1e7070++){_0x1e7070<0x28?_0x1e7070<0x14?(_0x3a0813=_0x36fa34^_0xb8c03b&(_0x513b41^_0x36fa34),_0x4ddaf7=0x5a827999):(_0x3a0813=_0xb8c03b^_0x513b41^_0x36fa34,_0x4ddaf7=0x6ed9eba1):_0x1e7070<0x3c?(_0x3a0813=_0xb8c03b&_0x513b41|_0x36fa34&(_0xb8c03b|_0x513b41),_0x4ddaf7=0x8f1bbcdc):(_0x3a0813=_0xb8c03b^_0x513b41^_0x36fa34,_0x4ddaf7=0xca62c1d6);const _0x1714f0=(_0x21eaee<<0x5|_0x21eaee>>>0x1b)+_0x3a0813+_0x2be381+_0x4ddaf7+_0x4f33ac[_0x1e7070]&0xffffffff;_0x2be381=_0x36fa34,_0x36fa34=_0x513b41,_0x513b41=(_0xb8c03b<<0x1e|_0xb8c03b>>>0x2)&0xffffffff,_0xb8c03b=_0x21eaee,_0x21eaee=_0x1714f0;}this['chain_'][0x0]=this['chain_'][0x0]+_0x21eaee&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xb8c03b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x513b41&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x36fa34&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2be381&0xffffffff;}['update'](_0x29b1cb,_0x3778e5){if(_0x29b1cb==null)return;_0x3778e5===void 0x0&&(_0x3778e5=_0x29b1cb['length']);const _0x1e4189=_0x3778e5-this['blockSize'];let _0x24162a=0x0;const _0x13126e=this['buf_'];let _0x3d8981=this['inbuf_'];for(;_0x24162a<_0x3778e5;){if(_0x3d8981===0x0){for(;_0x24162a<=_0x1e4189;)this['compress_'](_0x29b1cb,_0x24162a),_0x24162a+=this['blockSize'];}if(typeof _0x29b1cb=='string'){for(;_0x24162a<_0x3778e5;)if(_0x13126e[_0x3d8981]=_0x29b1cb['charCodeAt'](_0x24162a),++_0x3d8981,++_0x24162a,_0x3d8981===this['blockSize']){this['compress_'](_0x13126e),_0x3d8981=0x0;break;}}else{for(;_0x24162a<_0x3778e5;)if(_0x13126e[_0x3d8981]=_0x29b1cb[_0x24162a],++_0x3d8981,++_0x24162a,_0x3d8981===this['blockSize']){this['compress_'](_0x13126e),_0x3d8981=0x0;break;}}}this['inbuf_']=_0x3d8981,this['total_']+=_0x3778e5;}['digest'](){const _0x5cbe6e=[];let _0x20474c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x18aa04=this['blockSize']-0x1;_0x18aa04>=0x38;_0x18aa04--)this['buf_'][_0x18aa04]=_0x20474c&0xff,_0x20474c/=0x100;this['compress_'](this['buf_']);let _0x279a7e=0x0;for(let _0x16f594=0x0;_0x16f594<0x5;_0x16f594++)for(let _0x2bfc7f=0x18;_0x2bfc7f>=0x0;_0x2bfc7f-=0x8)_0x5cbe6e[_0x279a7e]=this['chain_'][_0x16f594]>>_0x2bfc7f&0xff,++_0x279a7e;return _0x5cbe6e;}}function Ic(_0x84012b,_0x22cc93){const _0x29dca5=new wc(_0x84012b,_0x22cc93);return _0x29dca5['subscribe']['bind'](_0x29dca5);}class wc{constructor(_0x29cbad,_0x162ad1){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x162ad1,this['task']['then'](()=>{_0x29cbad(this);})['catch'](_0x5b577c=>{this['error'](_0x5b577c);});}['next'](_0xda1624){this['forEachObserver'](_0x2d712c=>{_0x2d712c['next'](_0xda1624);});}['error'](_0x445d68){this['forEachObserver'](_0x3ed2f6=>{_0x3ed2f6['error'](_0x445d68);}),this['close'](_0x445d68);}['complete'](){this['forEachObserver'](_0x9fb68b=>{_0x9fb68b['complete']();}),this['close']();}['subscribe'](_0x198e5d,_0x446f5d,_0x14d8f6){let _0x398a5e;if(_0x198e5d===void 0x0&&_0x446f5d===void 0x0&&_0x14d8f6===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x198e5d,['next','error','complete'])?_0x398a5e=_0x198e5d:_0x398a5e={'next':_0x198e5d,'error':_0x446f5d,'complete':_0x14d8f6},_0x398a5e['next']===void 0x0&&(_0x398a5e['next']=Qn),_0x398a5e['error']===void 0x0&&(_0x398a5e['error']=Qn),_0x398a5e['complete']===void 0x0&&(_0x398a5e['complete']=Qn);const _0x1a5106=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x398a5e['error'](this['finalError']):_0x398a5e['complete']();}catch{}}),this['observers']['push'](_0x398a5e),_0x1a5106;}['unsubscribeOne'](_0x50d11d){this['observers']===void 0x0||this['observers'][_0x50d11d]===void 0x0||(delete this['observers'][_0x50d11d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2ca848){if(!this['finalized']){for(let _0x36b692=0x0;_0x36b692<this['observers']['length'];_0x36b692++)this['sendOne'](_0x36b692,_0x2ca848);}}['sendOne'](_0x1103f4,_0x142e1a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1103f4]!==void 0x0)try{_0x142e1a(this['observers'][_0x1103f4]);}catch(_0x571f24){typeof console<'u'&&console['error']&&console['error'](_0x571f24);}});}['close'](_0x17665c){this['finalized']||(this['finalized']=!0x0,_0x17665c!==void 0x0&&(this['finalError']=_0x17665c),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1c341a,_0x4d67b6){if(typeof _0x1c341a!='object'||_0x1c341a===null)return!0x1;for(const _0xe6e8d8 of _0x4d67b6)if(_0xe6e8d8 in _0x1c341a&&typeof _0x1c341a[_0xe6e8d8]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x2b1b6e,_0x47254a){return _0x2b1b6e+'\x20failed:\x20'+_0x47254a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x4367f9){const _0x1a29dc=[];let _0x27163e=0x0;for(let _0x1476b3=0x0;_0x1476b3<_0x4367f9['length'];_0x1476b3++){let _0x20af60=_0x4367f9['charCodeAt'](_0x1476b3);if(_0x20af60>=0xd800&&_0x20af60<=0xdbff){const _0x265289=_0x20af60-0xd800;_0x1476b3++,f(_0x1476b3<_0x4367f9['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x361b7d=_0x4367f9['charCodeAt'](_0x1476b3)-0xdc00;_0x20af60=0x10000+(_0x265289<<0xa)+_0x361b7d;}_0x20af60<0x80?_0x1a29dc[_0x27163e++]=_0x20af60:_0x20af60<0x800?(_0x1a29dc[_0x27163e++]=_0x20af60>>0x6|0xc0,_0x1a29dc[_0x27163e++]=_0x20af60&0x3f|0x80):_0x20af60<0x10000?(_0x1a29dc[_0x27163e++]=_0x20af60>>0xc|0xe0,_0x1a29dc[_0x27163e++]=_0x20af60>>0x6&0x3f|0x80,_0x1a29dc[_0x27163e++]=_0x20af60&0x3f|0x80):(_0x1a29dc[_0x27163e++]=_0x20af60>>0x12|0xf0,_0x1a29dc[_0x27163e++]=_0x20af60>>0xc&0x3f|0x80,_0x1a29dc[_0x27163e++]=_0x20af60>>0x6&0x3f|0x80,_0x1a29dc[_0x27163e++]=_0x20af60&0x3f|0x80);}return _0x1a29dc;},Pn=function(_0x4b525f){let _0x340a64=0x0;for(let _0x54d859=0x0;_0x54d859<_0x4b525f['length'];_0x54d859++){const _0x805c64=_0x4b525f['charCodeAt'](_0x54d859);_0x805c64<0x80?_0x340a64++:_0x805c64<0x800?_0x340a64+=0x2:_0x805c64>=0xd800&&_0x805c64<=0xdbff?(_0x340a64+=0x4,_0x54d859++):_0x340a64+=0x3;}return _0x340a64;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x3e0b74){return _0x3e0b74&&_0x3e0b74['_delegate']?_0x3e0b74['_delegate']:_0x3e0b74;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x441d9){try{return(_0x441d9['startsWith']('http://')||_0x441d9['startsWith']('https://')?new URL(_0x441d9)['hostname']:_0x441d9)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x396bad){return(await fetch(_0x396bad,{'credentials':'include'}))['ok'];}class Me{constructor(_0x462bbf,_0x4ba5eb,_0x2e8ad8){this['name']=_0x462bbf,this['instanceFactory']=_0x4ba5eb,this['type']=_0x2e8ad8,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4049bc){return this['instantiationMode']=_0x4049bc,this;}['setMultipleInstances'](_0xab7afa){return this['multipleInstances']=_0xab7afa,this;}['setServiceProps'](_0x14ee4d){return this['serviceProps']=_0x14ee4d,this;}['setInstanceCreatedCallback'](_0xbeda04){return this['onInstanceCreated']=_0xbeda04,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x3cebc4,_0xba99af){this['name']=_0x3cebc4,this['container']=_0xba99af,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x8e4853){const _0x403325=this['normalizeInstanceIdentifier'](_0x8e4853);if(!this['instancesDeferred']['has'](_0x403325)){const _0x3b5010=new Ve();if(this['instancesDeferred']['set'](_0x403325,_0x3b5010),this['isInitialized'](_0x403325)||this['shouldAutoInitialize']())try{const _0x1895f3=this['getOrInitializeService']({'instanceIdentifier':_0x403325});_0x1895f3&&_0x3b5010['resolve'](_0x1895f3);}catch{}}return this['instancesDeferred']['get'](_0x403325)['promise'];}['getImmediate'](_0x3d9ea5){const _0x1eccdb=this['normalizeInstanceIdentifier'](_0x3d9ea5==null?void 0x0:_0x3d9ea5['identifier']),_0x20354b=(_0x3d9ea5==null?void 0x0:_0x3d9ea5['optional'])??!0x1;if(this['isInitialized'](_0x1eccdb)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1eccdb});}catch(_0x5b3376){if(_0x20354b)return null;throw _0x5b3376;}else{if(_0x20354b)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x19a17a){if(_0x19a17a['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x19a17a['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x19a17a,!!this['shouldAutoInitialize']()){if(Rc(_0x19a17a))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1e5b2a,_0xf21ef8]of this['instancesDeferred']['entries']()){const _0x5207de=this['normalizeInstanceIdentifier'](_0x1e5b2a);try{const _0x18a23d=this['getOrInitializeService']({'instanceIdentifier':_0x5207de});_0xf21ef8['resolve'](_0x18a23d);}catch{}}}}['clearInstance'](_0x7ae058=ke){this['instancesDeferred']['delete'](_0x7ae058),this['instancesOptions']['delete'](_0x7ae058),this['instances']['delete'](_0x7ae058);}async['delete'](){const _0x227680=Array['from'](this['instances']['values']());await Promise['all']([..._0x227680['filter'](_0xbbabc=>'INTERNAL'in _0xbbabc)['map'](_0xae8163=>_0xae8163['INTERNAL']['delete']()),..._0x227680['filter'](_0x2108f1=>'_delete'in _0x2108f1)['map'](_0x2e9d25=>_0x2e9d25['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x599120=ke){return this['instances']['has'](_0x599120);}['getOptions'](_0xf46ab5=ke){return this['instancesOptions']['get'](_0xf46ab5)||{};}['initialize'](_0xd4470d={}){const {options:_0x4d62b2={}}=_0xd4470d,_0x470c39=this['normalizeInstanceIdentifier'](_0xd4470d['instanceIdentifier']);if(this['isInitialized'](_0x470c39))throw Error(this['name']+'('+_0x470c39+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x42d8f0=this['getOrInitializeService']({'instanceIdentifier':_0x470c39,'options':_0x4d62b2});for(const [_0xae64b1,_0x5225fb]of this['instancesDeferred']['entries']()){const _0x1df600=this['normalizeInstanceIdentifier'](_0xae64b1);_0x470c39===_0x1df600&&_0x5225fb['resolve'](_0x42d8f0);}return _0x42d8f0;}['onInit'](_0x479faa,_0x40e375){const _0x1aa198=this['normalizeInstanceIdentifier'](_0x40e375),_0x265cf8=this['onInitCallbacks']['get'](_0x1aa198)??new Set();_0x265cf8['add'](_0x479faa),this['onInitCallbacks']['set'](_0x1aa198,_0x265cf8);const _0x8c9597=this['instances']['get'](_0x1aa198);return _0x8c9597&&_0x479faa(_0x8c9597,_0x1aa198),()=>{_0x265cf8['delete'](_0x479faa);};}['invokeOnInitCallbacks'](_0x5881e4,_0x526d08){const _0x57a38a=this['onInitCallbacks']['get'](_0x526d08);if(_0x57a38a){for(const _0x596624 of _0x57a38a)try{_0x596624(_0x5881e4,_0x526d08);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x43ead9,options:_0xea6d56={}}){let _0x295c2c=this['instances']['get'](_0x43ead9);if(!_0x295c2c&&this['component']&&(_0x295c2c=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x43ead9),'options':_0xea6d56}),this['instances']['set'](_0x43ead9,_0x295c2c),this['instancesOptions']['set'](_0x43ead9,_0xea6d56),this['invokeOnInitCallbacks'](_0x295c2c,_0x43ead9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x43ead9,_0x295c2c);}catch{}return _0x295c2c||null;}['normalizeInstanceIdentifier'](_0x2b8ca3=ke){return this['component']?this['component']['multipleInstances']?_0x2b8ca3:ke:_0x2b8ca3;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x3e9ef1){return _0x3e9ef1===ke?void 0x0:_0x3e9ef1;}function Rc(_0x5b408a){return _0x5b408a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1816e3){this['name']=_0x1816e3,this['providers']=new Map();}['addComponent'](_0x87cfea){const _0x4bab1f=this['getProvider'](_0x87cfea['name']);if(_0x4bab1f['isComponentSet']())throw new Error('Component\x20'+_0x87cfea['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4bab1f['setComponent'](_0x87cfea);}['addOrOverwriteComponent'](_0x1db177){this['getProvider'](_0x1db177['name'])['isComponentSet']()&&this['providers']['delete'](_0x1db177['name']),this['addComponent'](_0x1db177);}['getProvider'](_0x4b3c6f){if(this['providers']['has'](_0x4b3c6f))return this['providers']['get'](_0x4b3c6f);const _0x4eef42=new Sc(_0x4b3c6f,this);return this['providers']['set'](_0x4b3c6f,_0x4eef42),_0x4eef42;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1c391e){_0x1c391e[_0x1c391e['DEBUG']=0x0]='DEBUG',_0x1c391e[_0x1c391e['VERBOSE']=0x1]='VERBOSE',_0x1c391e[_0x1c391e['INFO']=0x2]='INFO',_0x1c391e[_0x1c391e['WARN']=0x3]='WARN',_0x1c391e[_0x1c391e['ERROR']=0x4]='ERROR',_0x1c391e[_0x1c391e['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x33350e,_0x2c4dcd,..._0x365466)=>{if(_0x2c4dcd<_0x33350e['logLevel'])return;const _0xad53e2=new Date()['toISOString'](),_0x5c1f48=Pc[_0x2c4dcd];if(_0x5c1f48)console[_0x5c1f48]('['+_0xad53e2+']\x20\x20'+_0x33350e['name']+':',..._0x365466);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2c4dcd+')');};class xi{constructor(_0x3e4139){this['name']=_0x3e4139,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x534808){if(!(_0x534808 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x534808+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x534808;}['setLogLevel'](_0x212f22){this['_logLevel']=typeof _0x212f22=='string'?kc[_0x212f22]:_0x212f22;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5befc5){if(typeof _0x5befc5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5befc5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5c1140){this['_userLogHandler']=_0x5c1140;}['debug'](..._0x1128e0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1128e0),this['_logHandler'](this,T['DEBUG'],..._0x1128e0);}['log'](..._0xe5c33f){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xe5c33f),this['_logHandler'](this,T['VERBOSE'],..._0xe5c33f);}['info'](..._0x1f1851){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1f1851),this['_logHandler'](this,T['INFO'],..._0x1f1851);}['warn'](..._0x4c19c2){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4c19c2),this['_logHandler'](this,T['WARN'],..._0x4c19c2);}['error'](..._0x3db220){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3db220),this['_logHandler'](this,T['ERROR'],..._0x3db220);}}const Dc=(_0x199464,_0x5d6e27)=>_0x5d6e27['some'](_0xc1cbf3=>_0x199464 instanceof _0xc1cbf3);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x564f09){const _0x4f3d94=new Promise((_0x1f8cb6,_0x435ab0)=>{const _0x57733a=()=>{_0x564f09['removeEventListener']('success',_0x1cfad4),_0x564f09['removeEventListener']('error',_0x2589b3);},_0x1cfad4=()=>{_0x1f8cb6(_e(_0x564f09['result'])),_0x57733a();},_0x2589b3=()=>{_0x435ab0(_0x564f09['error']),_0x57733a();};_0x564f09['addEventListener']('success',_0x1cfad4),_0x564f09['addEventListener']('error',_0x2589b3);});return _0x4f3d94['then'](_0x477d93=>{_0x477d93 instanceof IDBCursor&&Kr['set'](_0x477d93,_0x564f09);})['catch'](()=>{}),Fi['set'](_0x4f3d94,_0x564f09),_0x4f3d94;}function Fc(_0x5c6760){if(ui['has'](_0x5c6760))return;const _0x45fa95=new Promise((_0x528558,_0x122229)=>{const _0x4d2a7a=()=>{_0x5c6760['removeEventListener']('complete',_0x572e72),_0x5c6760['removeEventListener']('error',_0x29fbd5),_0x5c6760['removeEventListener']('abort',_0x29fbd5);},_0x572e72=()=>{_0x528558(),_0x4d2a7a();},_0x29fbd5=()=>{_0x122229(_0x5c6760['error']||new DOMException('AbortError','AbortError')),_0x4d2a7a();};_0x5c6760['addEventListener']('complete',_0x572e72),_0x5c6760['addEventListener']('error',_0x29fbd5),_0x5c6760['addEventListener']('abort',_0x29fbd5);});ui['set'](_0x5c6760,_0x45fa95);}let di={'get'(_0x4cac46,_0x5c8d10,_0x40356e){if(_0x4cac46 instanceof IDBTransaction){if(_0x5c8d10==='done')return ui['get'](_0x4cac46);if(_0x5c8d10==='objectStoreNames')return _0x4cac46['objectStoreNames']||Yr['get'](_0x4cac46);if(_0x5c8d10==='store')return _0x40356e['objectStoreNames'][0x1]?void 0x0:_0x40356e['objectStore'](_0x40356e['objectStoreNames'][0x0]);}return _e(_0x4cac46[_0x5c8d10]);},'set'(_0x3daee5,_0x120282,_0x1e6188){return _0x3daee5[_0x120282]=_0x1e6188,!0x0;},'has'(_0x4bd0b1,_0x39a0e7){return _0x4bd0b1 instanceof IDBTransaction&&(_0x39a0e7==='done'||_0x39a0e7==='store')?!0x0:_0x39a0e7 in _0x4bd0b1;}};function Uc(_0x28dcd4){di=_0x28dcd4(di);}function Wc(_0x27b5da){return _0x27b5da===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x569f01,..._0x460486){const _0x254c06=_0x27b5da['call'](Xn(this),_0x569f01,..._0x460486);return Yr['set'](_0x254c06,_0x569f01['sort']?_0x569f01['sort']():[_0x569f01]),_e(_0x254c06);}:Lc()['includes'](_0x27b5da)?function(..._0x78d779){return _0x27b5da['apply'](Xn(this),_0x78d779),_e(Kr['get'](this));}:function(..._0x5601ad){return _e(_0x27b5da['apply'](Xn(this),_0x5601ad));};}function Bc(_0x49b68b){return typeof _0x49b68b=='function'?Wc(_0x49b68b):(_0x49b68b instanceof IDBTransaction&&Fc(_0x49b68b),Dc(_0x49b68b,Mc())?new Proxy(_0x49b68b,di):_0x49b68b);}function _e(_0x4d69ef){if(_0x4d69ef instanceof IDBRequest)return xc(_0x4d69ef);if(Jn['has'](_0x4d69ef))return Jn['get'](_0x4d69ef);const _0x8c22e6=Bc(_0x4d69ef);return _0x8c22e6!==_0x4d69ef&&(Jn['set'](_0x4d69ef,_0x8c22e6),Fi['set'](_0x8c22e6,_0x4d69ef)),_0x8c22e6;}const Xn=_0x13d979=>Fi['get'](_0x13d979);function Vc(_0xd4c864,_0x19f0ea,{blocked:_0x392685,upgrade:_0x1e07c8,blocking:_0x5798af,terminated:_0x173a55}={}){const _0x1c580b=indexedDB['open'](_0xd4c864,_0x19f0ea),_0x172a03=_e(_0x1c580b);return _0x1e07c8&&_0x1c580b['addEventListener']('upgradeneeded',_0x5b23f5=>{_0x1e07c8(_e(_0x1c580b['result']),_0x5b23f5['oldVersion'],_0x5b23f5['newVersion'],_e(_0x1c580b['transaction']),_0x5b23f5);}),_0x392685&&_0x1c580b['addEventListener']('blocked',_0x1d8d53=>_0x392685(_0x1d8d53['oldVersion'],_0x1d8d53['newVersion'],_0x1d8d53)),_0x172a03['then'](_0x50dc22=>{_0x173a55&&_0x50dc22['addEventListener']('close',()=>_0x173a55()),_0x5798af&&_0x50dc22['addEventListener']('versionchange',_0x22e134=>_0x5798af(_0x22e134['oldVersion'],_0x22e134['newVersion'],_0x22e134));})['catch'](()=>{}),_0x172a03;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x3cdc5f,_0x2a0308){if(!(_0x3cdc5f instanceof IDBDatabase&&!(_0x2a0308 in _0x3cdc5f)&&typeof _0x2a0308=='string'))return;if(Zn['get'](_0x2a0308))return Zn['get'](_0x2a0308);const _0x44b040=_0x2a0308['replace'](/FromIndex$/,''),_0x3b811f=_0x2a0308!==_0x44b040,_0x4503f7=$c['includes'](_0x44b040);if(!(_0x44b040 in(_0x3b811f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4503f7||Hc['includes'](_0x44b040)))return;const _0x59fdc6=async function(_0x54afbd,..._0x561568){const _0x4f156b=this['transaction'](_0x54afbd,_0x4503f7?'readwrite':'readonly');let _0x2066a2=_0x4f156b['store'];return _0x3b811f&&(_0x2066a2=_0x2066a2['index'](_0x561568['shift']())),(await Promise['all']([_0x2066a2[_0x44b040](..._0x561568),_0x4503f7&&_0x4f156b['done']]))[0x0];};return Zn['set'](_0x2a0308,_0x59fdc6),_0x59fdc6;}Uc(_0x822cbf=>({..._0x822cbf,'get':(_0x41ea7e,_0x2199a8,_0x2bdcfc)=>Os(_0x41ea7e,_0x2199a8)||_0x822cbf['get'](_0x41ea7e,_0x2199a8,_0x2bdcfc),'has':(_0x328108,_0x4a38a3)=>!!Os(_0x328108,_0x4a38a3)||_0x822cbf['has'](_0x328108,_0x4a38a3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x103d75){this['container']=_0x103d75;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1001eb=>{if(qc(_0x1001eb)){const _0x357aa6=_0x1001eb['getImmediate']();return _0x357aa6['library']+'/'+_0x357aa6['version'];}else return null;})['filter'](_0x2ccebb=>_0x2ccebb)['join']('\x20');}}function qc(_0x2c88a7){const _0x234c95=_0x2c88a7['getComponent']();return(_0x234c95==null?void 0x0:_0x234c95['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3a814f,_0x2411a4){try{_0x3a814f['container']['addComponent'](_0x2411a4);}catch(_0x4149f9){re['debug']('Component\x20'+_0x2411a4['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3a814f['name'],_0x4149f9);}}function et(_0x5da25b){const _0x501833=_0x5da25b['name'];if(gi['has'](_0x501833))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x501833+'.'),!0x1;gi['set'](_0x501833,_0x5da25b);for(const _0x4e8be6 of Le['values']())Ms(_0x4e8be6,_0x5da25b);for(const _0x2a9639 of _i['values']())Ms(_0x2a9639,_0x5da25b);return!0x0;}function Ui(_0x26e5c1,_0x2f87f5){const _0x69b478=_0x26e5c1['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x69b478&&_0x69b478['triggerHeartbeat'](),_0x26e5c1['container']['getProvider'](_0x2f87f5);}function H(_0x1e636a){return _0x1e636a==null?!0x1:_0x1e636a['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x4ec71c,_0x44edde,_0x452b28){this['_isDeleted']=!0x1,this['_options']={..._0x4ec71c},this['_config']={..._0x44edde},this['_name']=_0x44edde['name'],this['_automaticDataCollectionEnabled']=_0x44edde['automaticDataCollectionEnabled'],this['_container']=_0x452b28,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x39acb3){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x39acb3;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x9e60ae){this['_isDeleted']=_0x9e60ae;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x40f3a6,_0x26a479={}){let _0xa7551f=_0x40f3a6;typeof _0x26a479!='object'&&(_0x26a479={'name':_0x26a479});const _0x3a40b0={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x26a479},_0x18e707=_0x3a40b0['name'];if(typeof _0x18e707!='string'||!_0x18e707)throw ge['create']('bad-app-name',{'appName':String(_0x18e707)});if(_0xa7551f||(_0xa7551f=$r()),!_0xa7551f)throw ge['create']('no-options');const _0x325023=Le['get'](_0x18e707);if(_0x325023){if(De(_0xa7551f,_0x325023['options'])&&De(_0x3a40b0,_0x325023['config']))return _0x325023;throw ge['create']('duplicate-app',{'appName':_0x18e707});}const _0x2bf383=new Ac(_0x18e707);for(const _0x43049a of gi['values']())_0x2bf383['addComponent'](_0x43049a);const _0x593785=new Il(_0xa7551f,_0x3a40b0,_0x2bf383);return Le['set'](_0x18e707,_0x593785),_0x593785;}function Qr(_0x2bdf84=pi){const _0x3d3efb=Le['get'](_0x2bdf84);if(!_0x3d3efb&&_0x2bdf84===pi&&$r())return wl();if(!_0x3d3efb)throw ge['create']('no-app',{'appName':_0x2bdf84});return _0x3d3efb;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3d45cf){let _0x16f3b2=!0x1;const _0x219665=_0x3d45cf['name'];Le['has'](_0x219665)?(_0x16f3b2=!0x0,Le['delete'](_0x219665)):_i['has'](_0x219665)&&_0x3d45cf['decRefCount']()<=0x0&&(_i['delete'](_0x219665),_0x16f3b2=!0x0),_0x16f3b2&&(await Promise['all'](_0x3d45cf['container']['getProviders']()['map'](_0x5b6afc=>_0x5b6afc['delete']())),_0x3d45cf['isDeleted']=!0x0);}function me(_0x415787,_0x1c6205,_0x16cae0){let _0xcafef0=vl[_0x415787]??_0x415787;_0x16cae0&&(_0xcafef0+='-'+_0x16cae0);const _0x247dc6=_0xcafef0['match'](/\s|\//),_0x5f584f=_0x1c6205['match'](/\s|\//);if(_0x247dc6||_0x5f584f){const _0x211cfb=['Unable\x20to\x20register\x20library\x20\x22'+_0xcafef0+'\x22\x20with\x20version\x20\x22'+_0x1c6205+'\x22:'];_0x247dc6&&_0x211cfb['push']('library\x20name\x20\x22'+_0xcafef0+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x247dc6&&_0x5f584f&&_0x211cfb['push']('and'),_0x5f584f&&_0x211cfb['push']('version\x20name\x20\x22'+_0x1c6205+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x211cfb['join']('\x20'));return;}et(new Me(_0xcafef0+'-version',()=>({'library':_0xcafef0,'version':_0x1c6205}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x52e7db,_0x48c1dc)=>{switch(_0x48c1dc){case 0x0:try{_0x52e7db['createObjectStore'](Rt);}catch(_0x504135){console['warn'](_0x504135);}}}})['catch'](_0x38731e=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x38731e['message']});})),ei;}async function Sl(_0x307360){try{const _0x27a54c=(await Jr())['transaction'](Rt),_0x37f9d5=await _0x27a54c['objectStore'](Rt)['get'](Xr(_0x307360));return await _0x27a54c['done'],_0x37f9d5;}catch(_0x5023e1){if(_0x5023e1 instanceof Se)re['warn'](_0x5023e1['message']);else{const _0x4782d6=ge['create']('idb-get',{'originalErrorMessage':_0x5023e1==null?void 0x0:_0x5023e1['message']});re['warn'](_0x4782d6['message']);}}}async function Ls(_0xcb8e52,_0x3e2dc1){try{const _0x3856a4=(await Jr())['transaction'](Rt,'readwrite');await _0x3856a4['objectStore'](Rt)['put'](_0x3e2dc1,Xr(_0xcb8e52)),await _0x3856a4['done'];}catch(_0x455281){if(_0x455281 instanceof Se)re['warn'](_0x455281['message']);else{const _0x42639c=ge['create']('idb-set',{'originalErrorMessage':_0x455281==null?void 0x0:_0x455281['message']});re['warn'](_0x42639c['message']);}}}function Xr(_0x4c7ee6){return _0x4c7ee6['name']+'!'+_0x4c7ee6['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2f4901){this['container']=_0x2f4901,this['_heartbeatsCache']=null;const _0x47e383=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x47e383),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xb0b3c0=>(this['_heartbeatsCache']=_0xb0b3c0,_0xb0b3c0));}async['triggerHeartbeat'](){var _0x415a82,_0x2ac14b;try{const _0x13eee5=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x153970=xs();if(((_0x415a82=this['_heartbeatsCache'])==null?void 0x0:_0x415a82['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2ac14b=this['_heartbeatsCache'])==null?void 0x0:_0x2ac14b['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x153970||this['_heartbeatsCache']['heartbeats']['some'](_0x21e170=>_0x21e170['date']===_0x153970))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x153970,'agent':_0x13eee5}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x55c2c1=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x55c2c1,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2ad299){re['warn'](_0x2ad299);}}async['getHeartbeatsHeader'](){var _0x2b9085;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x2b9085=this['_heartbeatsCache'])==null?void 0x0:_0x2b9085['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x372ead=xs(),{heartbeatsToSend:_0x59841b,unsentEntries:_0xc2da3b}=kl(this['_heartbeatsCache']['heartbeats']),_0x229ac7=an(JSON['stringify']({'version':0x2,'heartbeats':_0x59841b}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x372ead,_0xc2da3b['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xc2da3b,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x229ac7;}catch(_0x5d2cfe){return re['warn'](_0x5d2cfe),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x415335,_0x4d0d35=bl){const _0x166c4b=[];let _0x160db0=_0x415335['slice']();for(const _0x3f1c0e of _0x415335){const _0x3eb21b=_0x166c4b['find'](_0x343113=>_0x343113['agent']===_0x3f1c0e['agent']);if(_0x3eb21b){if(_0x3eb21b['dates']['push'](_0x3f1c0e['date']),Fs(_0x166c4b)>_0x4d0d35){_0x3eb21b['dates']['pop']();break;}}else{if(_0x166c4b['push']({'agent':_0x3f1c0e['agent'],'dates':[_0x3f1c0e['date']]}),Fs(_0x166c4b)>_0x4d0d35){_0x166c4b['pop']();break;}}_0x160db0=_0x160db0['slice'](0x1);}return{'heartbeatsToSend':_0x166c4b,'unsentEntries':_0x160db0};}class Nl{constructor(_0x50107f){this['app']=_0x50107f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x22e8b0=await Sl(this['app']);return _0x22e8b0!=null&&_0x22e8b0['heartbeats']?_0x22e8b0:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x51e8e3){if(await this['_canUseIndexedDBPromise']){const _0x59384f=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x51e8e3['lastSentHeartbeatDate']??_0x59384f['lastSentHeartbeatDate'],'heartbeats':_0x51e8e3['heartbeats']});}else return;}async['add'](_0x4563c0){if(await this['_canUseIndexedDBPromise']){const _0x20b741=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4563c0['lastSentHeartbeatDate']??_0x20b741['lastSentHeartbeatDate'],'heartbeats':[..._0x20b741['heartbeats'],..._0x4563c0['heartbeats']]});}else return;}}function Fs(_0x362112){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x362112}))['length'];}function Pl(_0x2fbe31){if(_0x2fbe31['length']===0x0)return-0x1;let _0x159022=0x0,_0x201877=_0x2fbe31[0x0]['date'];for(let _0xa7453e=0x1;_0xa7453e<_0x2fbe31['length'];_0xa7453e++)_0x2fbe31[_0xa7453e]['date']<_0x201877&&(_0x201877=_0x2fbe31[_0xa7453e]['date'],_0x159022=_0xa7453e);return _0x159022;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x37a000){et(new Me('platform-logger',_0x8f8535=>new Gc(_0x8f8535),'PRIVATE')),et(new Me('heartbeat',_0x10a70a=>new Al(_0x10a70a),'PRIVATE')),me(fi,Ds,_0x37a000),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x41bc3a){Zr=_0x41bc3a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x4b4008){this['domStorage_']=_0x4b4008,this['prefix_']='firebase:';}['set'](_0x1111b7,_0x22d297){_0x22d297==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1111b7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1111b7),O(_0x22d297));}['get'](_0x43659c){const _0x5dc06c=this['domStorage_']['getItem'](this['prefixedName_'](_0x43659c));return _0x5dc06c==null?null:bt(_0x5dc06c);}['remove'](_0x18cf76){this['domStorage_']['removeItem'](this['prefixedName_'](_0x18cf76));}['prefixedName_'](_0x3b9278){return this['prefix_']+_0x3b9278;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2446e9,_0x20c207){_0x20c207==null?delete this['cache_'][_0x2446e9]:this['cache_'][_0x2446e9]=_0x20c207;}['get'](_0x42bea1){return Y(this['cache_'],_0x42bea1)?this['cache_'][_0x42bea1]:null;}['remove'](_0x1040a0){delete this['cache_'][_0x1040a0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x30aec0){try{if(typeof window<'u'&&typeof window[_0x30aec0]<'u'){const _0x4d2d5e=window[_0x30aec0];return _0x4d2d5e['setItem']('firebase:sentinel','cache'),_0x4d2d5e['removeItem']('firebase:sentinel'),new xl(_0x4d2d5e);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0xdf0fff=0x1;return function(){return _0xdf0fff++;};}()),no=function(_0x554f70){const _0xcaf4be=Tc(_0x554f70),_0x7ac07a=new Ec();_0x7ac07a['update'](_0xcaf4be);const _0x20877a=_0x7ac07a['digest']();return Di['encodeByteArray'](_0x20877a);},Bt=function(..._0x243b5a){let _0x5dfdd5='';for(let _0x324846=0x0;_0x324846<_0x243b5a['length'];_0x324846++){const _0x42eb7f=_0x243b5a[_0x324846];Array['isArray'](_0x42eb7f)||_0x42eb7f&&typeof _0x42eb7f=='object'&&typeof _0x42eb7f['length']=='number'?_0x5dfdd5+=Bt['apply'](null,_0x42eb7f):typeof _0x42eb7f=='object'?_0x5dfdd5+=O(_0x42eb7f):_0x5dfdd5+=_0x42eb7f,_0x5dfdd5+='\x20';}return _0x5dfdd5;};let Et=null,Vs=!0x0;const Wl=function(_0x7e1835,_0x149d60){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x31fc1a){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x28b336=Bt['apply'](null,_0x31fc1a);Et(_0x28b336);}},Vt=function(_0x2068ed){return function(..._0x3458f5){L(_0x2068ed,..._0x3458f5);};},mi=function(..._0x295cdd){const _0x2bea28='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x295cdd);Qe['error'](_0x2bea28);},oe=function(..._0x591cec){const _0x338d17='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x591cec);throw Qe['error'](_0x338d17),new Error(_0x338d17);},U=function(..._0x3b01b3){const _0x3d065f='FIREBASE\x20WARNING:\x20'+Bt(..._0x3b01b3);Qe['warn'](_0x3d065f);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x4f3b18){return typeof _0x4f3b18=='number'&&(_0x4f3b18!==_0x4f3b18||_0x4f3b18===Number['POSITIVE_INFINITY']||_0x4f3b18===Number['NEGATIVE_INFINITY']);},Vl=function(_0x5eb8f8){if(document['readyState']==='complete')_0x5eb8f8();else{let _0x223381=!0x1;const _0x482e8c=function(){if(!document['body']){setTimeout(_0x482e8c,Math['floor'](0xa));return;}_0x223381||(_0x223381=!0x0,_0x5eb8f8());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x482e8c,!0x1),window['addEventListener']('load',_0x482e8c,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x482e8c();}),window['attachEvent']('onload',_0x482e8c));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x894f84,_0x5d42c2){if(_0x894f84===_0x5d42c2)return 0x0;if(_0x894f84===xe||_0x5d42c2===Ie)return-0x1;if(_0x5d42c2===xe||_0x894f84===Ie)return 0x1;{const _0x3859f2=Hs(_0x894f84),_0x5abfe1=Hs(_0x5d42c2);return _0x3859f2!==null?_0x5abfe1!==null?_0x3859f2-_0x5abfe1===0x0?_0x894f84['length']-_0x5d42c2['length']:_0x3859f2-_0x5abfe1:-0x1:_0x5abfe1!==null?0x1:_0x894f84<_0x5d42c2?-0x1:0x1;}},Hl=function(_0x2c8fee,_0x4f9ff6){return _0x2c8fee===_0x4f9ff6?0x0:_0x2c8fee<_0x4f9ff6?-0x1:0x1;},pt=function(_0x5f0891,_0x5d0684){if(_0x5d0684&&_0x5f0891 in _0x5d0684)return _0x5d0684[_0x5f0891];throw new Error('Missing\x20required\x20key\x20('+_0x5f0891+')\x20in\x20object:\x20'+O(_0x5d0684));},Bi=function(_0x5f1849){if(typeof _0x5f1849!='object'||_0x5f1849===null)return O(_0x5f1849);const _0x385f53=[];for(const _0xd40d46 in _0x5f1849)_0x385f53['push'](_0xd40d46);_0x385f53['sort']();let _0x267609='{';for(let _0x45dc80=0x0;_0x45dc80<_0x385f53['length'];_0x45dc80++)_0x45dc80!==0x0&&(_0x267609+=','),_0x267609+=O(_0x385f53[_0x45dc80]),_0x267609+=':',_0x267609+=Bi(_0x5f1849[_0x385f53[_0x45dc80]]);return _0x267609+='}',_0x267609;},io=function(_0x27c56b,_0x2771ce){const _0x4a47ae=_0x27c56b['length'];if(_0x4a47ae<=_0x2771ce)return[_0x27c56b];const _0xfeeaa2=[];for(let _0x4499bb=0x0;_0x4499bb<_0x4a47ae;_0x4499bb+=_0x2771ce)_0x4499bb+_0x2771ce>_0x4a47ae?_0xfeeaa2['push'](_0x27c56b['substring'](_0x4499bb,_0x4a47ae)):_0xfeeaa2['push'](_0x27c56b['substring'](_0x4499bb,_0x4499bb+_0x2771ce));return _0xfeeaa2;};function x(_0x23f794,_0x9abc83){for(const _0x39ed6d in _0x23f794)_0x23f794['hasOwnProperty'](_0x39ed6d)&&_0x9abc83(_0x39ed6d,_0x23f794[_0x39ed6d]);}const so=function(_0x37d8a3){f(!Wi(_0x37d8a3),'Invalid\x20JSON\x20number');const _0x1c1f3a=0xb,_0x1923ae=0x34,_0x12678b=(0x1<<_0x1c1f3a-0x1)-0x1;let _0x5f23a0,_0x3ce161,_0x401101,_0x2f9f7f,_0x4bf21e;_0x37d8a3===0x0?(_0x3ce161=0x0,_0x401101=0x0,_0x5f23a0=0x1/_0x37d8a3===-0x1/0x0?0x1:0x0):(_0x5f23a0=_0x37d8a3<0x0,_0x37d8a3=Math['abs'](_0x37d8a3),_0x37d8a3>=Math['pow'](0x2,0x1-_0x12678b)?(_0x2f9f7f=Math['min'](Math['floor'](Math['log'](_0x37d8a3)/Math['LN2']),_0x12678b),_0x3ce161=_0x2f9f7f+_0x12678b,_0x401101=Math['round'](_0x37d8a3*Math['pow'](0x2,_0x1923ae-_0x2f9f7f)-Math['pow'](0x2,_0x1923ae))):(_0x3ce161=0x0,_0x401101=Math['round'](_0x37d8a3/Math['pow'](0x2,0x1-_0x12678b-_0x1923ae))));const _0x5a1541=[];for(_0x4bf21e=_0x1923ae;_0x4bf21e;_0x4bf21e-=0x1)_0x5a1541['push'](_0x401101%0x2?0x1:0x0),_0x401101=Math['floor'](_0x401101/0x2);for(_0x4bf21e=_0x1c1f3a;_0x4bf21e;_0x4bf21e-=0x1)_0x5a1541['push'](_0x3ce161%0x2?0x1:0x0),_0x3ce161=Math['floor'](_0x3ce161/0x2);_0x5a1541['push'](_0x5f23a0?0x1:0x0),_0x5a1541['reverse']();const _0x10bfa2=_0x5a1541['join']('');let _0x52f146='';for(_0x4bf21e=0x0;_0x4bf21e<0x40;_0x4bf21e+=0x8){let _0x29cfb3=parseInt(_0x10bfa2['substr'](_0x4bf21e,0x8),0x2)['toString'](0x10);_0x29cfb3['length']===0x1&&(_0x29cfb3='0'+_0x29cfb3),_0x52f146=_0x52f146+_0x29cfb3;}return _0x52f146['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x26604b,_0xad382e){let _0x301525='Unknown\x20Error';_0x26604b==='too_big'?_0x301525='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x26604b==='permission_denied'?_0x301525='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x26604b==='unavailable'&&(_0x301525='The\x20service\x20is\x20unavailable');const _0x539bce=new Error(_0x26604b+'\x20at\x20'+_0xad382e['_path']['toString']()+':\x20'+_0x301525);return _0x539bce['code']=_0x26604b['toUpperCase'](),_0x539bce;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x21f4d8){if(zl['test'](_0x21f4d8)){const _0x3d7ba6=Number(_0x21f4d8);if(_0x3d7ba6>=jl&&_0x3d7ba6<=Kl)return _0x3d7ba6;}return null;},lt=function(_0x4698f8){try{_0x4698f8();}catch(_0x3a1a8c){setTimeout(()=>{const _0x2ac7a8=_0x3a1a8c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2ac7a8),_0x3a1a8c;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3b8c40,_0x41dfe2){const _0x29668b=setTimeout(_0x3b8c40,_0x41dfe2);return typeof _0x29668b=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x29668b):typeof _0x29668b=='object'&&_0x29668b['unref']&&_0x29668b['unref'](),_0x29668b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x1d3cfa,_0xd9a48f){this['appCheckProvider']=_0xd9a48f,this['appName']=_0x1d3cfa['name'],H(_0x1d3cfa)&&_0x1d3cfa['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1d3cfa['settings']['appCheckToken']),this['appCheck']=_0xd9a48f==null?void 0x0:_0xd9a48f['getImmediate']({'optional':!0x0}),this['appCheck']||_0xd9a48f==null||_0xd9a48f['get']()['then'](_0x311505=>this['appCheck']=_0x311505);}['getToken'](_0x5f00bf){if(this['serverAppAppCheckToken']){if(_0x5f00bf)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5f00bf):new Promise((_0x2c5ccd,_0x2f1ee8)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5f00bf)['then'](_0x2c5ccd,_0x2f1ee8):_0x2c5ccd(null);},0x0);});}['addTokenChangeListener'](_0x45f1f7){var _0x1da0c2;(_0x1da0c2=this['appCheckProvider'])==null||_0x1da0c2['get']()['then'](_0x4297bc=>_0x4297bc['addTokenListener'](_0x45f1f7));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x209d2f,_0x3b5b9d,_0x973b69){this['appName_']=_0x209d2f,this['firebaseOptions_']=_0x3b5b9d,this['authProvider_']=_0x973b69,this['auth_']=null,this['auth_']=_0x973b69['getImmediate']({'optional':!0x0}),this['auth_']||_0x973b69['onInit'](_0x80be61=>this['auth_']=_0x80be61);}['getToken'](_0x306c5c){return this['auth_']?this['auth_']['getToken'](_0x306c5c)['catch'](_0x4e0d43=>_0x4e0d43&&_0x4e0d43['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4e0d43)):new Promise((_0x37fbf3,_0x2105ca)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x306c5c)['then'](_0x37fbf3,_0x2105ca):_0x37fbf3(null);},0x0);});}['addTokenChangeListener'](_0x78d524){this['auth_']?this['auth_']['addAuthTokenListener'](_0x78d524):this['authProvider_']['get']()['then'](_0x21892b=>_0x21892b['addAuthTokenListener'](_0x78d524));}['removeTokenChangeListener'](_0x400031){this['authProvider_']['get']()['then'](_0x5aed98=>_0x5aed98['removeAuthTokenListener'](_0x400031));}['notifyForInvalidToken'](){let _0x5d24e7='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5d24e7+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5d24e7+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5d24e7+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5d24e7);}}class tn{constructor(_0x2a1634){this['accessToken']=_0x2a1634;}['getToken'](_0x57d3a0){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x45cc3c){_0x45cc3c(this['accessToken']);}['removeTokenChangeListener'](_0x2caa56){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x11c609,_0x4bace0,_0x1247c4,_0x4c4dcc,_0x533357=!0x1,_0x3f92a7='',_0x52d2f9=!0x1,_0x2bf0fb=!0x1,_0x1f86d9=null){this['secure']=_0x4bace0,this['namespace']=_0x1247c4,this['webSocketOnly']=_0x4c4dcc,this['nodeAdmin']=_0x533357,this['persistenceKey']=_0x3f92a7,this['includeNamespaceInQueryParams']=_0x52d2f9,this['isUsingEmulator']=_0x2bf0fb,this['emulatorOptions']=_0x1f86d9,this['_host']=_0x11c609['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x11c609)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x23264a){_0x23264a!==this['internalHost']&&(this['internalHost']=_0x23264a,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2dceec=this['toURLString']();return this['persistenceKey']&&(_0x2dceec+='<'+this['persistenceKey']+'>'),_0x2dceec;}['toURLString'](){const _0x83b9fb=this['secure']?'https://':'http://',_0x276550=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x83b9fb+this['host']+'/'+_0x276550;}}function Xl(_0xa4b87a){return _0xa4b87a['host']!==_0xa4b87a['internalHost']||_0xa4b87a['isCustomHost']()||_0xa4b87a['includeNamespaceInQueryParams'];}function go(_0x11f662,_0x19fb02,_0x5cd7b8){f(typeof _0x19fb02=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5cd7b8=='object','typeof\x20params\x20must\x20==\x20object');let _0x219439;if(_0x19fb02===fo)_0x219439=(_0x11f662['secure']?'wss://':'ws://')+_0x11f662['internalHost']+'/.ws?';else{if(_0x19fb02===po)_0x219439=(_0x11f662['secure']?'https://':'http://')+_0x11f662['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x19fb02);}Xl(_0x11f662)&&(_0x5cd7b8['ns']=_0x11f662['namespace']);const _0x4c0af9=[];return x(_0x5cd7b8,(_0x302f6b,_0x1887b0)=>{_0x4c0af9['push'](_0x302f6b+'='+_0x1887b0);}),_0x219439+_0x4c0af9['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x39ab64,_0x3530d8=0x1){Y(this['counters_'],_0x39ab64)||(this['counters_'][_0x39ab64]=0x0),this['counters_'][_0x39ab64]+=_0x3530d8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x558a0d){const _0x12d8b3=_0x558a0d['toString']();return ti[_0x12d8b3]||(ti[_0x12d8b3]=new Zl()),ti[_0x12d8b3];}function eh(_0x4a1d3d,_0x5a3015){const _0x5f20b4=_0x4a1d3d['toString']();return ni[_0x5f20b4]||(ni[_0x5f20b4]=_0x5a3015()),ni[_0x5f20b4];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x8f9f0e){this['onMessage_']=_0x8f9f0e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x15aae1,_0x4e79da){this['closeAfterResponse']=_0x15aae1,this['onClose']=_0x4e79da,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x52ace4,_0x3e0ceb){for(this['pendingResponses'][_0x52ace4]=_0x3e0ceb;this['pendingResponses'][this['currentResponseNum']];){const _0x446a64=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x443617=0x0;_0x443617<_0x446a64['length'];++_0x443617)_0x446a64[_0x443617]&&lt(()=>{this['onMessage_'](_0x446a64[_0x443617]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x52982e,_0x48b867,_0x5e25d0,_0x56530e,_0x3426c9,_0x2be869,_0x17662d){this['connId']=_0x52982e,this['repoInfo']=_0x48b867,this['applicationId']=_0x5e25d0,this['appCheckToken']=_0x56530e,this['authToken']=_0x3426c9,this['transportSessionId']=_0x2be869,this['lastSessionId']=_0x17662d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x52982e),this['stats_']=Hi(_0x48b867),this['urlFn']=_0x12fb31=>(this['appCheckToken']&&(_0x12fb31[yi]=this['appCheckToken']),go(_0x48b867,po,_0x12fb31));}['open'](_0x188dd0,_0x3b1d4a){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3b1d4a,this['myPacketOrderer']=new th(_0x188dd0),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x4d2ab9)=>{const [_0x414f4c,_0x90682b,_0x516be0,_0x5b4a95,_0x1af538]=_0x4d2ab9;if(this['incrementIncomingBytes_'](_0x4d2ab9),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x414f4c===$s)this['id']=_0x90682b,this['password']=_0x516be0;else{if(_0x414f4c===nh)_0x90682b?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x90682b,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x414f4c);}}},(..._0xab5556)=>{const [_0x3d9967,_0x8f8fbc]=_0xab5556;this['incrementIncomingBytes_'](_0xab5556),this['myPacketOrderer']['handleResponse'](_0x3d9967,_0x8f8fbc);},()=>{this['onClosed_']();},this['urlFn']);const _0x5b76f7={};_0x5b76f7[$s]='t',_0x5b76f7[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5b76f7[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5b76f7[ro]=Vi,this['transportSessionId']&&(_0x5b76f7[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x5b76f7[ho]=this['lastSessionId']),this['applicationId']&&(_0x5b76f7[uo]=this['applicationId']),this['appCheckToken']&&(_0x5b76f7[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5b76f7[ao]=co);const _0x411ba9=this['urlFn'](_0x5b76f7);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x411ba9),this['scriptTagHolder']['addTag'](_0x411ba9,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4d0972){const _0x2b843d=O(_0x4d0972);this['bytesSent']+=_0x2b843d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2b843d['length']);const _0x210239=Br(_0x2b843d),_0x3aed30=io(_0x210239,hh);for(let _0x4888b3=0x0;_0x4888b3<_0x3aed30['length'];_0x4888b3++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3aed30['length'],_0x3aed30[_0x4888b3]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x13970c,_0x1236a8){this['myDisconnFrame']=document['createElement']('iframe');const _0x171d97={};_0x171d97[lh]='t',_0x171d97[mo]=_0x13970c,_0x171d97[yo]=_0x1236a8,this['myDisconnFrame']['src']=this['urlFn'](_0x171d97),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4b16ce){const _0x57b6ae=O(_0x4b16ce)['length'];this['bytesReceived']+=_0x57b6ae,this['stats_']['incrementCounter']('bytes_received',_0x57b6ae);}}class $i{constructor(_0x1ccd18,_0x196bfa,_0x4d0651,_0x197fe6){this['onDisconnect']=_0x4d0651,this['urlFn']=_0x197fe6,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x1ccd18,window[sh+this['uniqueCallbackIdentifier']]=_0x196bfa,this['myIFrame']=$i['createIFrame_']();let _0x5ad6c9='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5ad6c9='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x372f0c='<html><body>'+_0x5ad6c9+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x372f0c),this['myIFrame']['doc']['close']();}catch(_0x4c4124){L('frame\x20writing\x20exception'),_0x4c4124['stack']&&L(_0x4c4124['stack']),L(_0x4c4124);}}}static['createIFrame_'](){const _0x18b12c=document['createElement']('iframe');if(_0x18b12c['style']['display']='none',document['body']){document['body']['appendChild'](_0x18b12c);try{_0x18b12c['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xa75632=document['domain'];_0x18b12c['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xa75632+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x18b12c['contentDocument']?_0x18b12c['doc']=_0x18b12c['contentDocument']:_0x18b12c['contentWindow']?_0x18b12c['doc']=_0x18b12c['contentWindow']['document']:_0x18b12c['document']&&(_0x18b12c['doc']=_0x18b12c['document']),_0x18b12c;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x207eb9=this['onDisconnect'];_0x207eb9&&(this['onDisconnect']=null,_0x207eb9());}['startLongPoll'](_0x5466fa,_0x233946){for(this['myID']=_0x5466fa,this['myPW']=_0x233946,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x12b068={};_0x12b068[mo]=this['myID'],_0x12b068[yo]=this['myPW'],_0x12b068[vo]=this['currentSerial'];let _0x5bc1c6=this['urlFn'](_0x12b068),_0x2c0129='',_0x9643ed=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2c0129['length']<=Eo;){const _0x1671e3=this['pendingSegs']['shift']();_0x2c0129=_0x2c0129+'&'+oh+_0x9643ed+'='+_0x1671e3['seg']+'&'+ah+_0x9643ed+'='+_0x1671e3['ts']+'&'+ch+_0x9643ed+'='+_0x1671e3['d'],_0x9643ed++;}return _0x5bc1c6=_0x5bc1c6+_0x2c0129,this['addLongPollTag_'](_0x5bc1c6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4d54c6,_0x288e20,_0x16f0af){this['pendingSegs']['push']({'seg':_0x4d54c6,'ts':_0x288e20,'d':_0x16f0af}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x17b55a,_0x318f6f){this['outstandingRequests']['add'](_0x318f6f);const _0x3f6be6=()=>{this['outstandingRequests']['delete'](_0x318f6f),this['newRequest_']();},_0x535629=setTimeout(_0x3f6be6,Math['floor'](uh)),_0x456755=()=>{clearTimeout(_0x535629),_0x3f6be6();};this['addTag'](_0x17b55a,_0x456755);}['addTag'](_0x25c943,_0x453c21){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x107024=this['myIFrame']['doc']['createElement']('script');_0x107024['type']='text/javascript',_0x107024['async']=!0x0,_0x107024['src']=_0x25c943,_0x107024['onload']=_0x107024['onreadystatechange']=function(){const _0x22c790=_0x107024['readyState'];(!_0x22c790||_0x22c790==='loaded'||_0x22c790==='complete')&&(_0x107024['onload']=_0x107024['onreadystatechange']=null,_0x107024['parentNode']&&_0x107024['parentNode']['removeChild'](_0x107024),_0x453c21());},_0x107024['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x25c943),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x107024);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x2b6658,_0x24967b,_0x5204b8,_0x2fd266,_0x196376,_0x2b852e,_0xbd7a0){this['connId']=_0x2b6658,this['applicationId']=_0x5204b8,this['appCheckToken']=_0x2fd266,this['authToken']=_0x196376,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x24967b),this['connURL']=G['connectionURL_'](_0x24967b,_0x2b852e,_0xbd7a0,_0x2fd266,_0x5204b8),this['nodeAdmin']=_0x24967b['nodeAdmin'];}static['connectionURL_'](_0x1c5bdd,_0x3724b0,_0x181c06,_0x4ac31c,_0x12160a){const _0x2710d4={};return _0x2710d4[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2710d4[ao]=co),_0x3724b0&&(_0x2710d4[oo]=_0x3724b0),_0x181c06&&(_0x2710d4[ho]=_0x181c06),_0x4ac31c&&(_0x2710d4[yi]=_0x4ac31c),_0x12160a&&(_0x2710d4[uo]=_0x12160a),go(_0x1c5bdd,fo,_0x2710d4);}['open'](_0x2a4504,_0x175398){this['onDisconnect']=_0x175398,this['onMessage']=_0x2a4504,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x515a57;dc(),this['mySock']=new hn(this['connURL'],[],_0x515a57);}catch(_0xb125c0){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2d6298=_0xb125c0['message']||_0xb125c0['data'];_0x2d6298&&this['log_'](_0x2d6298),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x466c39=>{this['handleIncomingFrame'](_0x466c39);},this['mySock']['onerror']=_0xf2f5a5=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3bd059=_0xf2f5a5['message']||_0xf2f5a5['data'];_0x3bd059&&this['log_'](_0x3bd059),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x352e97=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x29746c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3a2454=navigator['userAgent']['match'](_0x29746c);_0x3a2454&&_0x3a2454['length']>0x1&&parseFloat(_0x3a2454[0x1])<4.4&&(_0x352e97=!0x0);}return!_0x352e97&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x41a735){if(this['frames']['push'](_0x41a735),this['frames']['length']===this['totalFrames']){const _0x1d211e=this['frames']['join']('');this['frames']=null;const _0x2510f1=bt(_0x1d211e);this['onMessage'](_0x2510f1);}}['handleNewFrameCount_'](_0x45ab0f){this['totalFrames']=_0x45ab0f,this['frames']=[];}['extractFrameCount_'](_0x37f037){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x37f037['length']<=0x6){const _0x447857=Number(_0x37f037);if(!isNaN(_0x447857))return this['handleNewFrameCount_'](_0x447857),null;}return this['handleNewFrameCount_'](0x1),_0x37f037;}['handleIncomingFrame'](_0x5379e5){if(this['mySock']===null)return;const _0x50e529=_0x5379e5['data'];if(this['bytesReceived']+=_0x50e529['length'],this['stats_']['incrementCounter']('bytes_received',_0x50e529['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x50e529);else{const _0x271f87=this['extractFrameCount_'](_0x50e529);_0x271f87!==null&&this['appendFrame_'](_0x271f87);}}['send'](_0xc59c9c){this['resetKeepAlive']();const _0x2b22b6=O(_0xc59c9c);this['bytesSent']+=_0x2b22b6['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2b22b6['length']);const _0x440b7f=io(_0x2b22b6,fh);_0x440b7f['length']>0x1&&this['sendString_'](String(_0x440b7f['length']));for(let _0x1ea255=0x0;_0x1ea255<_0x440b7f['length'];_0x1ea255++)this['sendString_'](_0x440b7f[_0x1ea255]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x1d37d2){try{this['mySock']['send'](_0x1d37d2);}catch(_0x168b9c){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x168b9c['message']||_0x168b9c['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x18fb2c){this['initTransports_'](_0x18fb2c);}['initTransports_'](_0x4efbd5){const _0x4388d1=G&&G['isAvailable']();let _0x4b4325=_0x4388d1&&!G['previouslyFailed']();if(_0x4efbd5['webSocketOnly']&&(_0x4388d1||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4b4325=!0x0),_0x4b4325)this['transports_']=[G];else{const _0x33c763=this['transports_']=[];for(const _0x10627a of At['ALL_TRANSPORTS'])_0x10627a&&_0x10627a['isAvailable']()&&_0x33c763['push'](_0x10627a);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x21effd,_0x5ce446,_0x1071c8,_0x5dbfcf,_0x3b603c,_0x541d9b,_0x15ea49,_0x13799e,_0x43217c,_0xfa5b90){this['id']=_0x21effd,this['repoInfo_']=_0x5ce446,this['applicationId_']=_0x1071c8,this['appCheckToken_']=_0x5dbfcf,this['authToken_']=_0x3b603c,this['onMessage_']=_0x541d9b,this['onReady_']=_0x15ea49,this['onDisconnect_']=_0x13799e,this['onKill_']=_0x43217c,this['lastSessionId']=_0xfa5b90,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x5ce446),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1338e5=this['transportManager_']['initialTransport']();this['conn_']=new _0x1338e5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1338e5['responsesRequiredToBeHealthy']||0x0;const _0x4fc143=this['connReceiver_'](this['conn_']),_0x5b062b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4fc143,_0x5b062b);},Math['floor'](0x0));const _0xd6efdd=_0x1338e5['healthyTimeout']||0x0;_0xd6efdd>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xd6efdd)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x58121a){return _0x192738=>{_0x58121a===this['conn_']?this['onConnectionLost_'](_0x192738):_0x58121a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x38f916){return _0x23734c=>{this['state_']!==0x2&&(_0x38f916===this['rx_']?this['onPrimaryMessageReceived_'](_0x23734c):_0x38f916===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x23734c):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xa7706a){const _0xf437f5={'t':'d','d':_0xa7706a};this['sendData_'](_0xf437f5);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2ede47){if(ii in _0x2ede47){const _0xd66f52=_0x2ede47[ii];_0xd66f52===js?this['upgradeIfSecondaryHealthy_']():_0xd66f52===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xd66f52===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x46709c){const _0x35f3f7=pt('t',_0x46709c),_0x45788c=pt('d',_0x46709c);if(_0x35f3f7==='c')this['onSecondaryControl_'](_0x45788c);else{if(_0x35f3f7==='d')this['pendingDataMessages']['push'](_0x45788c);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x35f3f7);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x26a73d){const _0x54cedb=pt('t',_0x26a73d),_0x3178cc=pt('d',_0x26a73d);_0x54cedb==='c'?this['onControl_'](_0x3178cc):_0x54cedb==='d'&&this['onDataMessage_'](_0x3178cc);}['onDataMessage_'](_0x18c91c){this['onPrimaryResponse_'](),this['onMessage_'](_0x18c91c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2aa520){const _0x31c3d6=pt(ii,_0x2aa520);if(Gs in _0x2aa520){const _0x15d92d=_0x2aa520[Gs];if(_0x31c3d6===Ih){const _0x53500a={..._0x15d92d};this['repoInfo_']['isUsingEmulator']&&(_0x53500a['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x53500a);}else{if(_0x31c3d6===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2b01f8=0x0;_0x2b01f8<this['pendingDataMessages']['length'];++_0x2b01f8)this['onDataMessage_'](this['pendingDataMessages'][_0x2b01f8]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x31c3d6===vh?this['onConnectionShutdown_'](_0x15d92d):_0x31c3d6===qs?this['onReset_'](_0x15d92d):_0x31c3d6===Eh?mi('Server\x20Error:\x20'+_0x15d92d):_0x31c3d6===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x31c3d6);}}}['onHandshake_'](_0x2a7f08){const _0x2cdc24=_0x2a7f08['ts'],_0x142b2d=_0x2a7f08['v'],_0xe64252=_0x2a7f08['h'];this['sessionId']=_0x2a7f08['s'],this['repoInfo_']['host']=_0xe64252,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2cdc24),Vi!==_0x142b2d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x306d0d=this['transportManager_']['upgradeTransport']();_0x306d0d&&this['startUpgrade_'](_0x306d0d);}['startUpgrade_'](_0x5974dc){this['secondaryConn_']=new _0x5974dc(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5974dc['responsesRequiredToBeHealthy']||0x0;const _0x531852=this['connReceiver_'](this['secondaryConn_']),_0x1d5e89=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x531852,_0x1d5e89),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xb956a0){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xb956a0),this['repoInfo_']['host']=_0xb956a0,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4ecfd5,_0x3c1e7a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4ecfd5,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3c1e7a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4b6bbd=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4b6bbd||this['rx_']===_0x4b6bbd)&&this['close']();}['onConnectionLost_'](_0x430ecc){this['conn_']=null,!_0x430ecc&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4040c2){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4040c2),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1f1b51){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1f1b51);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x19b093,_0x447e99,_0x4a405a,_0x34e2a6){}['merge'](_0x1c4edb,_0x56aaac,_0x27c2c1,_0x3b8dc4){}['refreshAuthToken'](_0x351a17){}['refreshAppCheckToken'](_0x1fe05e){}['onDisconnectPut'](_0x420b21,_0x5edc3,_0x530b76){}['onDisconnectMerge'](_0x35dff4,_0x6f89b0,_0x5f1791){}['onDisconnectCancel'](_0x3436c2,_0x1a82ad){}['reportStats'](_0x38eef8){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4bc719){this['allowedEvents_']=_0x4bc719,this['listeners_']={},f(Array['isArray'](_0x4bc719)&&_0x4bc719['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x48876b,..._0x19577e){if(Array['isArray'](this['listeners_'][_0x48876b])){const _0x5518b0=[...this['listeners_'][_0x48876b]];for(let _0x2a83bb=0x0;_0x2a83bb<_0x5518b0['length'];_0x2a83bb++)_0x5518b0[_0x2a83bb]['callback']['apply'](_0x5518b0[_0x2a83bb]['context'],_0x19577e);}}['on'](_0x1aed75,_0x1afaeb,_0x58562b){this['validateEventType_'](_0x1aed75),this['listeners_'][_0x1aed75]=this['listeners_'][_0x1aed75]||[],this['listeners_'][_0x1aed75]['push']({'callback':_0x1afaeb,'context':_0x58562b});const _0x3e5e5=this['getInitialEvent'](_0x1aed75);_0x3e5e5&&_0x1afaeb['apply'](_0x58562b,_0x3e5e5);}['off'](_0x52857a,_0x258335,_0x3ead81){this['validateEventType_'](_0x52857a);const _0x51bb0a=this['listeners_'][_0x52857a]||[];for(let _0x12d077=0x0;_0x12d077<_0x51bb0a['length'];_0x12d077++)if(_0x51bb0a[_0x12d077]['callback']===_0x258335&&(!_0x3ead81||_0x3ead81===_0x51bb0a[_0x12d077]['context'])){_0x51bb0a['splice'](_0x12d077,0x1);return;}}['validateEventType_'](_0xb6c28){f(this['allowedEvents_']['find'](_0x5df534=>_0x5df534===_0xb6c28),'Unknown\x20event:\x20'+_0xb6c28);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x388c84){return f(_0x388c84==='online','Unknown\x20event\x20type:\x20'+_0x388c84),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x2bcc7c,_0x44a1cc){if(_0x44a1cc===void 0x0){this['pieces_']=_0x2bcc7c['split']('/');let _0x66c3d7=0x0;for(let _0x17488a=0x0;_0x17488a<this['pieces_']['length'];_0x17488a++)this['pieces_'][_0x17488a]['length']>0x0&&(this['pieces_'][_0x66c3d7]=this['pieces_'][_0x17488a],_0x66c3d7++);this['pieces_']['length']=_0x66c3d7,this['pieceNum_']=0x0;}else this['pieces_']=_0x2bcc7c,this['pieceNum_']=_0x44a1cc;}['toString'](){let _0x57cf10='';for(let _0xd48497=this['pieceNum_'];_0xd48497<this['pieces_']['length'];_0xd48497++)this['pieces_'][_0xd48497]!==''&&(_0x57cf10+='/'+this['pieces_'][_0xd48497]);return _0x57cf10||'/';}}function w(){return new C('');}function y(_0x428b9e){return _0x428b9e['pieceNum_']>=_0x428b9e['pieces_']['length']?null:_0x428b9e['pieces_'][_0x428b9e['pieceNum_']];}function we(_0x13f94a){return _0x13f94a['pieces_']['length']-_0x13f94a['pieceNum_'];}function b(_0x551062){let _0x1b8997=_0x551062['pieceNum_'];return _0x1b8997<_0x551062['pieces_']['length']&&_0x1b8997++,new C(_0x551062['pieces_'],_0x1b8997);}function Gi(_0x5ddabe){return _0x5ddabe['pieceNum_']<_0x5ddabe['pieces_']['length']?_0x5ddabe['pieces_'][_0x5ddabe['pieces_']['length']-0x1]:null;}function Ch(_0x3e69b0){let _0x552c60='';for(let _0x246f42=_0x3e69b0['pieceNum_'];_0x246f42<_0x3e69b0['pieces_']['length'];_0x246f42++)_0x3e69b0['pieces_'][_0x246f42]!==''&&(_0x552c60+='/'+encodeURIComponent(String(_0x3e69b0['pieces_'][_0x246f42])));return _0x552c60||'/';}function kt(_0x133220,_0x237d88=0x0){return _0x133220['pieces_']['slice'](_0x133220['pieceNum_']+_0x237d88);}function To(_0x1a3d23){if(_0x1a3d23['pieceNum_']>=_0x1a3d23['pieces_']['length'])return null;const _0xadbed3=[];for(let _0x41979b=_0x1a3d23['pieceNum_'];_0x41979b<_0x1a3d23['pieces_']['length']-0x1;_0x41979b++)_0xadbed3['push'](_0x1a3d23['pieces_'][_0x41979b]);return new C(_0xadbed3,0x0);}function A(_0x2ed5c4,_0x318c7c){const _0x2b25d7=[];for(let _0x413e4f=_0x2ed5c4['pieceNum_'];_0x413e4f<_0x2ed5c4['pieces_']['length'];_0x413e4f++)_0x2b25d7['push'](_0x2ed5c4['pieces_'][_0x413e4f]);if(_0x318c7c instanceof C){for(let _0x127366=_0x318c7c['pieceNum_'];_0x127366<_0x318c7c['pieces_']['length'];_0x127366++)_0x2b25d7['push'](_0x318c7c['pieces_'][_0x127366]);}else{const _0x5e4ce5=_0x318c7c['split']('/');for(let _0x4e0c01=0x0;_0x4e0c01<_0x5e4ce5['length'];_0x4e0c01++)_0x5e4ce5[_0x4e0c01]['length']>0x0&&_0x2b25d7['push'](_0x5e4ce5[_0x4e0c01]);}return new C(_0x2b25d7,0x0);}function v(_0x4607cb){return _0x4607cb['pieceNum_']>=_0x4607cb['pieces_']['length'];}function F(_0x50aa65,_0x2c1d7b){const _0x23f9bc=y(_0x50aa65),_0x1cd2e5=y(_0x2c1d7b);if(_0x23f9bc===null)return _0x2c1d7b;if(_0x23f9bc===_0x1cd2e5)return F(b(_0x50aa65),b(_0x2c1d7b));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2c1d7b+')\x20is\x20not\x20within\x20outerPath\x20('+_0x50aa65+')');}function Th(_0x118aa6,_0x275ca2){const _0x35372c=kt(_0x118aa6,0x0),_0x4a8e6f=kt(_0x275ca2,0x0);for(let _0xbe59b3=0x0;_0xbe59b3<_0x35372c['length']&&_0xbe59b3<_0x4a8e6f['length'];_0xbe59b3++){const _0x4d0e13=He(_0x35372c[_0xbe59b3],_0x4a8e6f[_0xbe59b3]);if(_0x4d0e13!==0x0)return _0x4d0e13;}return _0x35372c['length']===_0x4a8e6f['length']?0x0:_0x35372c['length']<_0x4a8e6f['length']?-0x1:0x1;}function qi(_0x3ad955,_0x40620c){if(we(_0x3ad955)!==we(_0x40620c))return!0x1;for(let _0x5741a4=_0x3ad955['pieceNum_'],_0x54cf62=_0x40620c['pieceNum_'];_0x5741a4<=_0x3ad955['pieces_']['length'];_0x5741a4++,_0x54cf62++)if(_0x3ad955['pieces_'][_0x5741a4]!==_0x40620c['pieces_'][_0x54cf62])return!0x1;return!0x0;}function $(_0x104a1a,_0x10666d){let _0x4a8d4b=_0x104a1a['pieceNum_'],_0xa4baf3=_0x10666d['pieceNum_'];if(we(_0x104a1a)>we(_0x10666d))return!0x1;for(;_0x4a8d4b<_0x104a1a['pieces_']['length'];){if(_0x104a1a['pieces_'][_0x4a8d4b]!==_0x10666d['pieces_'][_0xa4baf3])return!0x1;++_0x4a8d4b,++_0xa4baf3;}return!0x0;}class Sh{constructor(_0x307520,_0x26eb8f){this['errorPrefix_']=_0x26eb8f,this['parts_']=kt(_0x307520,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5c02b9=0x0;_0x5c02b9<this['parts_']['length'];_0x5c02b9++)this['byteLength_']+=Pn(this['parts_'][_0x5c02b9]);So(this);}}function bh(_0x173df9,_0x249c17){_0x173df9['parts_']['length']>0x0&&(_0x173df9['byteLength_']+=0x1),_0x173df9['parts_']['push'](_0x249c17),_0x173df9['byteLength_']+=Pn(_0x249c17),So(_0x173df9);}function Rh(_0x4911ca){const _0x47345f=_0x4911ca['parts_']['pop']();_0x4911ca['byteLength_']-=Pn(_0x47345f),_0x4911ca['parts_']['length']>0x0&&(_0x4911ca['byteLength_']-=0x1);}function So(_0x416a5e){if(_0x416a5e['byteLength_']>Js)throw new Error(_0x416a5e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x416a5e['byteLength_']+').');if(_0x416a5e['parts_']['length']>Qs)throw new Error(_0x416a5e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x416a5e));}function Ne(_0x19f5ce){return _0x19f5ce['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x19f5ce['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x93c37c,_0x4ad0f0;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4ad0f0='visibilitychange',_0x93c37c='hidden'):typeof document['mozHidden']<'u'?(_0x4ad0f0='mozvisibilitychange',_0x93c37c='mozHidden'):typeof document['msHidden']<'u'?(_0x4ad0f0='msvisibilitychange',_0x93c37c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4ad0f0='webkitvisibilitychange',_0x93c37c='webkitHidden')),this['visible_']=!0x0,_0x4ad0f0&&document['addEventListener'](_0x4ad0f0,()=>{const _0x288610=!document[_0x93c37c];_0x288610!==this['visible_']&&(this['visible_']=_0x288610,this['trigger']('visible',_0x288610));},!0x1);}['getInitialEvent'](_0x2e206c){return f(_0x2e206c==='visible','Unknown\x20event\x20type:\x20'+_0x2e206c),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5c77d8,_0x5480f3,_0x252e0,_0x2803cf,_0x5632e7,_0x3fa21a,_0x20631b,_0x182979){if(super(),this['repoInfo_']=_0x5c77d8,this['applicationId_']=_0x5480f3,this['onDataUpdate_']=_0x252e0,this['onConnectStatus_']=_0x2803cf,this['onServerInfoUpdate_']=_0x5632e7,this['authTokenProvider_']=_0x3fa21a,this['appCheckTokenProvider_']=_0x20631b,this['authOverride_']=_0x182979,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x182979)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5c77d8['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x26c6eb,_0x5235b3,_0x328877){const _0x72c96f=++this['requestNumber_'],_0x2f9ecf={'r':_0x72c96f,'a':_0x26c6eb,'b':_0x5235b3};this['log_'](O(_0x2f9ecf)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2f9ecf),_0x328877&&(this['requestCBHash_'][_0x72c96f]=_0x328877);}['get'](_0x5e3cc4){this['initConnection_']();const _0x4e4548=new Ve(),_0x581e88={'action':'g','request':{'p':_0x5e3cc4['_path']['toString'](),'q':_0x5e3cc4['_queryObject']},'onComplete':_0x3a0da2=>{const _0xaee65f=_0x3a0da2['d'];_0x3a0da2['s']==='ok'?_0x4e4548['resolve'](_0xaee65f):_0x4e4548['reject'](_0xaee65f);}};this['outstandingGets_']['push'](_0x581e88),this['outstandingGetCount_']++;const _0x3dd48d=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3dd48d),_0x4e4548['promise'];}['listen'](_0x5de12b,_0x5938f5,_0x307b78,_0x42dcc1){this['initConnection_']();const _0x489d8d=_0x5de12b['_queryIdentifier'],_0x3084cb=_0x5de12b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3084cb+'\x20'+_0x489d8d),this['listens']['has'](_0x3084cb)||this['listens']['set'](_0x3084cb,new Map()),f(_0x5de12b['_queryParams']['isDefault']()||!_0x5de12b['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3084cb)['has'](_0x489d8d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1d169d={'onComplete':_0x42dcc1,'hashFn':_0x5938f5,'query':_0x5de12b,'tag':_0x307b78};this['listens']['get'](_0x3084cb)['set'](_0x489d8d,_0x1d169d),this['connected_']&&this['sendListen_'](_0x1d169d);}['sendGet_'](_0x3d4648){const _0x184056=this['outstandingGets_'][_0x3d4648];this['sendRequest']('g',_0x184056['request'],_0x458ca2=>{delete this['outstandingGets_'][_0x3d4648],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x184056['onComplete']&&_0x184056['onComplete'](_0x458ca2);});}['sendListen_'](_0x5e4568){const _0x5423a7=_0x5e4568['query'],_0x4ee9ba=_0x5423a7['_path']['toString'](),_0x3014b0=_0x5423a7['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4ee9ba+'\x20for\x20'+_0x3014b0);const _0x394a77={'p':_0x4ee9ba},_0x585b29='q';_0x5e4568['tag']&&(_0x394a77['q']=_0x5423a7['_queryObject'],_0x394a77['t']=_0x5e4568['tag']),_0x394a77['h']=_0x5e4568['hashFn'](),this['sendRequest'](_0x585b29,_0x394a77,_0x2763cf=>{const _0x59afa4=_0x2763cf['d'],_0x2d8fba=_0x2763cf['s'];ie['warnOnListenWarnings_'](_0x59afa4,_0x5423a7),(this['listens']['get'](_0x4ee9ba)&&this['listens']['get'](_0x4ee9ba)['get'](_0x3014b0))===_0x5e4568&&(this['log_']('listen\x20response',_0x2763cf),_0x2d8fba!=='ok'&&this['removeListen_'](_0x4ee9ba,_0x3014b0),_0x5e4568['onComplete']&&_0x5e4568['onComplete'](_0x2d8fba,_0x59afa4));});}static['warnOnListenWarnings_'](_0x43f150,_0x1b5f0b){if(_0x43f150&&typeof _0x43f150=='object'&&Y(_0x43f150,'w')){const _0x4cf516=Oe(_0x43f150,'w');if(Array['isArray'](_0x4cf516)&&~_0x4cf516['indexOf']('no_index')){const _0x321399='\x22.indexOn\x22:\x20\x22'+_0x1b5f0b['_queryParams']['getIndex']()['toString']()+'\x22',_0x1f1dfd=_0x1b5f0b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x321399+'\x20at\x20'+_0x1f1dfd+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3aa916){this['authToken_']=_0x3aa916,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3aa916);}['reduceReconnectDelayIfAdminCredential_'](_0x44728d){(_0x44728d&&_0x44728d['length']===0x28||vc(_0x44728d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0xa8d5d9){this['appCheckToken_']=_0xa8d5d9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x17d5b1=this['authToken_'],_0x13c97f=yc(_0x17d5b1)?'auth':'gauth',_0x2f1cad={'cred':_0x17d5b1};this['authOverride_']===null?_0x2f1cad['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x2f1cad['authvar']=this['authOverride_']),this['sendRequest'](_0x13c97f,_0x2f1cad,_0x4bf984=>{const _0x5ab504=_0x4bf984['s'],_0x4b8867=_0x4bf984['d']||'error';this['authToken_']===_0x17d5b1&&(_0x5ab504==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5ab504,_0x4b8867));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1db463=>{const _0x7521ad=_0x1db463['s'],_0x4f1b67=_0x1db463['d']||'error';_0x7521ad==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x7521ad,_0x4f1b67);});}['unlisten'](_0xf1fa69,_0x339d37){const _0x37e3a9=_0xf1fa69['_path']['toString'](),_0x27acbc=_0xf1fa69['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x37e3a9+'\x20'+_0x27acbc),f(_0xf1fa69['_queryParams']['isDefault']()||!_0xf1fa69['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x37e3a9,_0x27acbc)&&this['connected_']&&this['sendUnlisten_'](_0x37e3a9,_0x27acbc,_0xf1fa69['_queryObject'],_0x339d37);}['sendUnlisten_'](_0x474589,_0x3fa5c3,_0x55b81e,_0x265364){this['log_']('Unlisten\x20on\x20'+_0x474589+'\x20for\x20'+_0x3fa5c3);const _0x56c09c={'p':_0x474589},_0x27bc36='n';_0x265364&&(_0x56c09c['q']=_0x55b81e,_0x56c09c['t']=_0x265364),this['sendRequest'](_0x27bc36,_0x56c09c);}['onDisconnectPut'](_0x49f831,_0x2bb4dd,_0x1b1393){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x49f831,_0x2bb4dd,_0x1b1393):this['onDisconnectRequestQueue_']['push']({'pathString':_0x49f831,'action':'o','data':_0x2bb4dd,'onComplete':_0x1b1393});}['onDisconnectMerge'](_0x257ab0,_0x2f15e4,_0x5e273e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x257ab0,_0x2f15e4,_0x5e273e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x257ab0,'action':'om','data':_0x2f15e4,'onComplete':_0x5e273e});}['onDisconnectCancel'](_0x4ec469,_0x4f4aeb){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4ec469,null,_0x4f4aeb):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4ec469,'action':'oc','data':null,'onComplete':_0x4f4aeb});}['sendOnDisconnect_'](_0xacaf3c,_0x41d19a,_0x5c629c,_0xcfa418){const _0x24fc15={'p':_0x41d19a,'d':_0x5c629c};this['log_']('onDisconnect\x20'+_0xacaf3c,_0x24fc15),this['sendRequest'](_0xacaf3c,_0x24fc15,_0x262c3d=>{_0xcfa418&&setTimeout(()=>{_0xcfa418(_0x262c3d['s'],_0x262c3d['d']);},Math['floor'](0x0));});}['put'](_0x446c1c,_0x536ad3,_0x3c1987,_0x3851d6){this['putInternal']('p',_0x446c1c,_0x536ad3,_0x3c1987,_0x3851d6);}['merge'](_0x32ede7,_0x4763f2,_0x3d6dcf,_0x1e7af1){this['putInternal']('m',_0x32ede7,_0x4763f2,_0x3d6dcf,_0x1e7af1);}['putInternal'](_0x45e62a,_0x5bc7db,_0x243f8a,_0x490a76,_0x27394b){this['initConnection_']();const _0x38e184={'p':_0x5bc7db,'d':_0x243f8a};_0x27394b!==void 0x0&&(_0x38e184['h']=_0x27394b),this['outstandingPuts_']['push']({'action':_0x45e62a,'request':_0x38e184,'onComplete':_0x490a76}),this['outstandingPutCount_']++;const _0x4bae2f=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4bae2f):this['log_']('Buffering\x20put:\x20'+_0x5bc7db);}['sendPut_'](_0x3bfb18){const _0x1e9a1c=this['outstandingPuts_'][_0x3bfb18]['action'],_0x39de03=this['outstandingPuts_'][_0x3bfb18]['request'],_0x5459db=this['outstandingPuts_'][_0x3bfb18]['onComplete'];this['outstandingPuts_'][_0x3bfb18]['queued']=this['connected_'],this['sendRequest'](_0x1e9a1c,_0x39de03,_0x2a2ccc=>{this['log_'](_0x1e9a1c+'\x20response',_0x2a2ccc),delete this['outstandingPuts_'][_0x3bfb18],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5459db&&_0x5459db(_0x2a2ccc['s'],_0x2a2ccc['d']);});}['reportStats'](_0x63d3ff){if(this['connected_']){const _0x5a7790={'c':_0x63d3ff};this['log_']('reportStats',_0x5a7790),this['sendRequest']('s',_0x5a7790,_0x1ad973=>{if(_0x1ad973['s']!=='ok'){const _0x31d9be=_0x1ad973['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x31d9be);}});}}['onDataMessage_'](_0x34fa20){if('r'in _0x34fa20){this['log_']('from\x20server:\x20'+O(_0x34fa20));const _0x24da98=_0x34fa20['r'],_0x589842=this['requestCBHash_'][_0x24da98];_0x589842&&(delete this['requestCBHash_'][_0x24da98],_0x589842(_0x34fa20['b']));}else{if('error'in _0x34fa20)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x34fa20['error'];'a'in _0x34fa20&&this['onDataPush_'](_0x34fa20['a'],_0x34fa20['b']);}}['onDataPush_'](_0x35f726,_0x361b99){this['log_']('handleServerMessage',_0x35f726,_0x361b99),_0x35f726==='d'?this['onDataUpdate_'](_0x361b99['p'],_0x361b99['d'],!0x1,_0x361b99['t']):_0x35f726==='m'?this['onDataUpdate_'](_0x361b99['p'],_0x361b99['d'],!0x0,_0x361b99['t']):_0x35f726==='c'?this['onListenRevoked_'](_0x361b99['p'],_0x361b99['q']):_0x35f726==='ac'?this['onAuthRevoked_'](_0x361b99['s'],_0x361b99['d']):_0x35f726==='apc'?this['onAppCheckRevoked_'](_0x361b99['s'],_0x361b99['d']):_0x35f726==='sd'?this['onSecurityDebugPacket_'](_0x361b99):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x35f726)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4e88a5,_0x527b16){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4e88a5),this['lastSessionId']=_0x527b16,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5d45a3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5d45a3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2e6a63){_0x2e6a63&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2e6a63;}['onOnline_'](_0xa14b91){_0xa14b91?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x9049a3=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xffd5a5=Math['max'](0x0,this['reconnectDelay_']-_0x9049a3);_0xffd5a5=Math['random']()*_0xffd5a5,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xffd5a5+'ms'),this['scheduleConnect_'](_0xffd5a5),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1b42d7=this['onDataMessage_']['bind'](this),_0x59268f=this['onReady_']['bind'](this),_0x214fe7=this['onRealtimeDisconnect_']['bind'](this),_0x28a607=this['id']+':'+ie['nextConnectionId_']++,_0x2d9ce3=this['lastSessionId'];let _0x42cadc=!0x1,_0xda9e03=null;const _0x42891a=function(){_0xda9e03?_0xda9e03['close']():(_0x42cadc=!0x0,_0x214fe7());},_0x151647=function(_0x25ef51){f(_0xda9e03,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0xda9e03['sendRequest'](_0x25ef51);};this['realtime_']={'close':_0x42891a,'sendRequest':_0x151647};const _0xb50b93=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x11f690,_0x144206]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xb50b93),this['appCheckTokenProvider_']['getToken'](_0xb50b93)]);_0x42cadc?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x11f690&&_0x11f690['accessToken'],this['appCheckToken_']=_0x144206&&_0x144206['token'],_0xda9e03=new wh(_0x28a607,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1b42d7,_0x59268f,_0x214fe7,_0x580deb=>{U(_0x580deb+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x2d9ce3));}catch(_0xea830f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xea830f),_0x42cadc||(this['repoInfo_']['nodeAdmin']&&U(_0xea830f),_0x42891a());}}}['interrupt'](_0x3346ef){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3346ef),this['interruptReasons_'][_0x3346ef]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x149e43){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x149e43),delete this['interruptReasons_'][_0x149e43],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3cbcf2){const _0x3561ce=_0x3cbcf2-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3561ce});}['cancelSentTransactions_'](){for(let _0x1cc99e=0x0;_0x1cc99e<this['outstandingPuts_']['length'];_0x1cc99e++){const _0x1ded0e=this['outstandingPuts_'][_0x1cc99e];_0x1ded0e&&'h'in _0x1ded0e['request']&&_0x1ded0e['queued']&&(_0x1ded0e['onComplete']&&_0x1ded0e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1cc99e],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x40603c,_0x4ab93d){let _0x1a47b0;_0x4ab93d?_0x1a47b0=_0x4ab93d['map'](_0x1fbc2f=>Bi(_0x1fbc2f))['join']('$'):_0x1a47b0='default';const _0x1480f5=this['removeListen_'](_0x40603c,_0x1a47b0);_0x1480f5&&_0x1480f5['onComplete']&&_0x1480f5['onComplete']('permission_denied');}['removeListen_'](_0x5a6158,_0xe356e3){const _0x3c2d74=new C(_0x5a6158)['toString']();let _0x32e6ce;if(this['listens']['has'](_0x3c2d74)){const _0x263d49=this['listens']['get'](_0x3c2d74);_0x32e6ce=_0x263d49['get'](_0xe356e3),_0x263d49['delete'](_0xe356e3),_0x263d49['size']===0x0&&this['listens']['delete'](_0x3c2d74);}else _0x32e6ce=void 0x0;return _0x32e6ce;}['onAuthRevoked_'](_0x48e170,_0x248dfd){L('Auth\x20token\x20revoked:\x20'+_0x48e170+'/'+_0x248dfd),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x48e170==='invalid_token'||_0x48e170==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x324e4c,_0x115f9c){L('App\x20check\x20token\x20revoked:\x20'+_0x324e4c+'/'+_0x115f9c),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x324e4c==='invalid_token'||_0x324e4c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1bc4b4){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1bc4b4):'msg'in _0x1bc4b4&&console['log']('FIREBASE:\x20'+_0x1bc4b4['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4177f0 of this['listens']['values']())for(const _0x4b2b30 of _0x4177f0['values']())this['sendListen_'](_0x4b2b30);for(let _0x5b266a=0x0;_0x5b266a<this['outstandingPuts_']['length'];_0x5b266a++)this['outstandingPuts_'][_0x5b266a]&&this['sendPut_'](_0x5b266a);for(;this['onDisconnectRequestQueue_']['length'];){const _0x222cb0=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x222cb0['action'],_0x222cb0['pathString'],_0x222cb0['data'],_0x222cb0['onComplete']);}for(let _0x251861=0x0;_0x251861<this['outstandingGets_']['length'];_0x251861++)this['outstandingGets_'][_0x251861]&&this['sendGet_'](_0x251861);}['sendConnectStats_'](){const _0x4bfa45={};let _0x41c0c3='js';_0x4bfa45['sdk.'+_0x41c0c3+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x4bfa45['framework.cordova']=0x1:qr()&&(_0x4bfa45['framework.reactnative']=0x1),this['reportStats'](_0x4bfa45);}['shouldReconnect_'](){const _0x1f2287=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x1f2287;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x34b002,_0x3a557b){this['name']=_0x34b002,this['node']=_0x3a557b;}static['Wrap'](_0x43487e,_0x24fe92){return new E(_0x43487e,_0x24fe92);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x97d5e1,_0x508e16){const _0x2297c7=new E(xe,_0x97d5e1),_0xd8a76f=new E(xe,_0x508e16);return this['compare'](_0x2297c7,_0xd8a76f)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x594560){Xt=_0x594560;}['compare'](_0x5338d9,_0x1f91b4){return He(_0x5338d9['name'],_0x1f91b4['name']);}['isDefinedOn'](_0x286014){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x46bfa5,_0x398f4e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x47f855,_0x56216d){return f(typeof _0x47f855=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x47f855,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x959d02,_0x464e57,_0x5b3711,_0x30fc7f,_0x18dbc7=null){this['isReverse_']=_0x30fc7f,this['resultGenerator_']=_0x18dbc7,this['nodeStack_']=[];let _0x31a3f2=0x1;for(;!_0x959d02['isEmpty']();)if(_0x959d02=_0x959d02,_0x31a3f2=_0x464e57?_0x5b3711(_0x959d02['key'],_0x464e57):0x1,_0x30fc7f&&(_0x31a3f2*=-0x1),_0x31a3f2<0x0)this['isReverse_']?_0x959d02=_0x959d02['left']:_0x959d02=_0x959d02['right'];else{if(_0x31a3f2===0x0){this['nodeStack_']['push'](_0x959d02);break;}else this['nodeStack_']['push'](_0x959d02),this['isReverse_']?_0x959d02=_0x959d02['right']:_0x959d02=_0x959d02['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3ac22a=this['nodeStack_']['pop'](),_0x1cebb0;if(this['resultGenerator_']?_0x1cebb0=this['resultGenerator_'](_0x3ac22a['key'],_0x3ac22a['value']):_0x1cebb0={'key':_0x3ac22a['key'],'value':_0x3ac22a['value']},this['isReverse_']){for(_0x3ac22a=_0x3ac22a['left'];!_0x3ac22a['isEmpty']();)this['nodeStack_']['push'](_0x3ac22a),_0x3ac22a=_0x3ac22a['right'];}else{for(_0x3ac22a=_0x3ac22a['right'];!_0x3ac22a['isEmpty']();)this['nodeStack_']['push'](_0x3ac22a),_0x3ac22a=_0x3ac22a['left'];}return _0x1cebb0;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xe4b846=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xe4b846['key'],_0xe4b846['value']):{'key':_0xe4b846['key'],'value':_0xe4b846['value']};}}class M{constructor(_0x1b687e,_0x4ea7ab,_0x27ea4a,_0x502a4a,_0x56074c){this['key']=_0x1b687e,this['value']=_0x4ea7ab,this['color']=_0x27ea4a??M['RED'],this['left']=_0x502a4a??B['EMPTY_NODE'],this['right']=_0x56074c??B['EMPTY_NODE'];}['copy'](_0x245332,_0x35513f,_0x5ee757,_0x5262ec,_0x20aca2){return new M(_0x245332??this['key'],_0x35513f??this['value'],_0x5ee757??this['color'],_0x5262ec??this['left'],_0x20aca2??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x26e7f8){return this['left']['inorderTraversal'](_0x26e7f8)||!!_0x26e7f8(this['key'],this['value'])||this['right']['inorderTraversal'](_0x26e7f8);}['reverseTraversal'](_0x4b84a5){return this['right']['reverseTraversal'](_0x4b84a5)||_0x4b84a5(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4b84a5);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3b26d0,_0x4cdc99,_0x322b77){let _0x555776=this;const _0x4260b9=_0x322b77(_0x3b26d0,_0x555776['key']);return _0x4260b9<0x0?_0x555776=_0x555776['copy'](null,null,null,_0x555776['left']['insert'](_0x3b26d0,_0x4cdc99,_0x322b77),null):_0x4260b9===0x0?_0x555776=_0x555776['copy'](null,_0x4cdc99,null,null,null):_0x555776=_0x555776['copy'](null,null,null,null,_0x555776['right']['insert'](_0x3b26d0,_0x4cdc99,_0x322b77)),_0x555776['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x11c538=this;return!_0x11c538['left']['isRed_']()&&!_0x11c538['left']['left']['isRed_']()&&(_0x11c538=_0x11c538['moveRedLeft_']()),_0x11c538=_0x11c538['copy'](null,null,null,_0x11c538['left']['removeMin_'](),null),_0x11c538['fixUp_']();}['remove'](_0x17541d,_0x56bd40){let _0x2839bf,_0x4086e5;if(_0x2839bf=this,_0x56bd40(_0x17541d,_0x2839bf['key'])<0x0)!_0x2839bf['left']['isEmpty']()&&!_0x2839bf['left']['isRed_']()&&!_0x2839bf['left']['left']['isRed_']()&&(_0x2839bf=_0x2839bf['moveRedLeft_']()),_0x2839bf=_0x2839bf['copy'](null,null,null,_0x2839bf['left']['remove'](_0x17541d,_0x56bd40),null);else{if(_0x2839bf['left']['isRed_']()&&(_0x2839bf=_0x2839bf['rotateRight_']()),!_0x2839bf['right']['isEmpty']()&&!_0x2839bf['right']['isRed_']()&&!_0x2839bf['right']['left']['isRed_']()&&(_0x2839bf=_0x2839bf['moveRedRight_']()),_0x56bd40(_0x17541d,_0x2839bf['key'])===0x0){if(_0x2839bf['right']['isEmpty']())return B['EMPTY_NODE'];_0x4086e5=_0x2839bf['right']['min_'](),_0x2839bf=_0x2839bf['copy'](_0x4086e5['key'],_0x4086e5['value'],null,null,_0x2839bf['right']['removeMin_']());}_0x2839bf=_0x2839bf['copy'](null,null,null,null,_0x2839bf['right']['remove'](_0x17541d,_0x56bd40));}return _0x2839bf['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x32e74c=this;return _0x32e74c['right']['isRed_']()&&!_0x32e74c['left']['isRed_']()&&(_0x32e74c=_0x32e74c['rotateLeft_']()),_0x32e74c['left']['isRed_']()&&_0x32e74c['left']['left']['isRed_']()&&(_0x32e74c=_0x32e74c['rotateRight_']()),_0x32e74c['left']['isRed_']()&&_0x32e74c['right']['isRed_']()&&(_0x32e74c=_0x32e74c['colorFlip_']()),_0x32e74c;}['moveRedLeft_'](){let _0xbd45d6=this['colorFlip_']();return _0xbd45d6['right']['left']['isRed_']()&&(_0xbd45d6=_0xbd45d6['copy'](null,null,null,null,_0xbd45d6['right']['rotateRight_']()),_0xbd45d6=_0xbd45d6['rotateLeft_'](),_0xbd45d6=_0xbd45d6['colorFlip_']()),_0xbd45d6;}['moveRedRight_'](){let _0x3dab23=this['colorFlip_']();return _0x3dab23['left']['left']['isRed_']()&&(_0x3dab23=_0x3dab23['rotateRight_'](),_0x3dab23=_0x3dab23['colorFlip_']()),_0x3dab23;}['rotateLeft_'](){const _0xe24d45=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xe24d45,null);}['rotateRight_'](){const _0x5d58ab=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5d58ab);}['colorFlip_'](){const _0x529e58=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x181601=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x529e58,_0x181601);}['checkMaxDepth_'](){const _0x573bfd=this['check_']();return Math['pow'](0x2,_0x573bfd)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x61325f=this['left']['check_']();if(_0x61325f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x61325f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x48045c,_0x5b7915,_0xc1577c,_0x10d783,_0x3a56f3){return this;}['insert'](_0x1bcd0c,_0x4204bb,_0x3b459e){return new M(_0x1bcd0c,_0x4204bb,null);}['remove'](_0x1c6d48,_0x39046b){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4a6e51){return!0x1;}['reverseTraversal'](_0xefb0af){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0xec3a25,_0x2410e3=B['EMPTY_NODE']){this['comparator_']=_0xec3a25,this['root_']=_0x2410e3;}['insert'](_0x4f86a0,_0x210bb9){return new B(this['comparator_'],this['root_']['insert'](_0x4f86a0,_0x210bb9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x27fae9){return new B(this['comparator_'],this['root_']['remove'](_0x27fae9,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x22f6fc){let _0x2de04a,_0x19af1e=this['root_'];for(;!_0x19af1e['isEmpty']();){if(_0x2de04a=this['comparator_'](_0x22f6fc,_0x19af1e['key']),_0x2de04a===0x0)return _0x19af1e['value'];_0x2de04a<0x0?_0x19af1e=_0x19af1e['left']:_0x2de04a>0x0&&(_0x19af1e=_0x19af1e['right']);}return null;}['getPredecessorKey'](_0x287dab){let _0x377945,_0x26aa65=this['root_'],_0x24d6ff=null;for(;!_0x26aa65['isEmpty']();)if(_0x377945=this['comparator_'](_0x287dab,_0x26aa65['key']),_0x377945===0x0){if(_0x26aa65['left']['isEmpty']())return _0x24d6ff?_0x24d6ff['key']:null;for(_0x26aa65=_0x26aa65['left'];!_0x26aa65['right']['isEmpty']();)_0x26aa65=_0x26aa65['right'];return _0x26aa65['key'];}else _0x377945<0x0?_0x26aa65=_0x26aa65['left']:_0x377945>0x0&&(_0x24d6ff=_0x26aa65,_0x26aa65=_0x26aa65['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5adf65){return this['root_']['inorderTraversal'](_0x5adf65);}['reverseTraversal'](_0x2e6e6a){return this['root_']['reverseTraversal'](_0x2e6e6a);}['getIterator'](_0x49249e){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x49249e);}['getIteratorFrom'](_0x2488c8,_0x123c03){return new Zt(this['root_'],_0x2488c8,this['comparator_'],!0x1,_0x123c03);}['getReverseIteratorFrom'](_0x16541b,_0x255145){return new Zt(this['root_'],_0x16541b,this['comparator_'],!0x0,_0x255145);}['getReverseIterator'](_0x3a0800){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3a0800);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0xe77de8,_0x58ef7c){return He(_0xe77de8['name'],_0x58ef7c['name']);}function ji(_0x2e26f2,_0x503c8a){return He(_0x2e26f2,_0x503c8a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x4b039){vi=_0x4b039;}const Ro=function(_0x494514){return typeof _0x494514=='number'?'number:'+so(_0x494514):'string:'+_0x494514;},Ao=function(_0x310687){if(_0x310687['isLeafNode']()){const _0x577d74=_0x310687['val']();f(typeof _0x577d74=='string'||typeof _0x577d74=='number'||typeof _0x577d74=='object'&&Y(_0x577d74,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x310687===vi||_0x310687['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x310687===vi||_0x310687['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x27b313){er=_0x27b313;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x5e98b7,_0x17bb5d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x5e98b7,this['priorityNode_']=_0x17bb5d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5de9fd){return new D(this['value_'],_0x5de9fd);}['getImmediateChild'](_0x4a4122){return _0x4a4122==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x424df4){return v(_0x424df4)?this:y(_0x424df4)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x48b534,_0x1472a2){return null;}['updateImmediateChild'](_0xc2d3ef,_0x16d7fa){return _0xc2d3ef==='.priority'?this['updatePriority'](_0x16d7fa):_0x16d7fa['isEmpty']()&&_0xc2d3ef!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xc2d3ef,_0x16d7fa)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x40e655,_0x412dc7){const _0x4a9844=y(_0x40e655);return _0x4a9844===null?_0x412dc7:_0x412dc7['isEmpty']()&&_0x4a9844!=='.priority'?this:(f(_0x4a9844!=='.priority'||we(_0x40e655)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4a9844,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x40e655),_0x412dc7)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x17654f,_0x109e1c){return!0x1;}['val'](_0x17449e){return _0x17449e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2cb748='';this['priorityNode_']['isEmpty']()||(_0x2cb748+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2b3122=typeof this['value_'];_0x2cb748+=_0x2b3122+':',_0x2b3122==='number'?_0x2cb748+=so(this['value_']):_0x2cb748+=this['value_'],this['lazyHash_']=no(_0x2cb748);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xda7351){return _0xda7351===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xda7351 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xda7351['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xda7351));}['compareToLeafNode_'](_0x3dd590){const _0xf42329=typeof _0x3dd590['value_'],_0x4143c2=typeof this['value_'],_0x13c879=D['VALUE_TYPE_ORDER']['indexOf'](_0xf42329),_0x1ea11e=D['VALUE_TYPE_ORDER']['indexOf'](_0x4143c2);return f(_0x13c879>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xf42329),f(_0x1ea11e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4143c2),_0x13c879===_0x1ea11e?_0x4143c2==='object'?0x0:this['value_']<_0x3dd590['value_']?-0x1:this['value_']===_0x3dd590['value_']?0x0:0x1:_0x1ea11e-_0x13c879;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xec6ffb){if(_0xec6ffb===this)return!0x0;if(_0xec6ffb['isLeafNode']()){const _0x53c05a=_0xec6ffb;return this['value_']===_0x53c05a['value_']&&this['priorityNode_']['equals'](_0x53c05a['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4cb821){ko=_0x4cb821;}function xh(_0x3f34e9){No=_0x3f34e9;}class Fh extends On{['compare'](_0x3c0b23,_0x3b04e1){const _0x125971=_0x3c0b23['node']['getPriority'](),_0x851578=_0x3b04e1['node']['getPriority'](),_0x331d24=_0x125971['compareTo'](_0x851578);return _0x331d24===0x0?He(_0x3c0b23['name'],_0x3b04e1['name']):_0x331d24;}['isDefinedOn'](_0xe55293){return!_0xe55293['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x9d1736,_0xef5113){return!_0x9d1736['getPriority']()['equals'](_0xef5113['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xd75407,_0x41fd86){const _0x724c2b=ko(_0xd75407);return new E(_0x41fd86,new D('[PRIORITY-POST]',_0x724c2b));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x194fc3){const _0xccc91c=_0x5a2620=>parseInt(Math['log'](_0x5a2620)/Uh,0xa),_0x1730ff=_0x5e580b=>parseInt(Array(_0x5e580b+0x1)['join']('1'),0x2);this['count']=_0xccc91c(_0x194fc3+0x1),this['current_']=this['count']-0x1;const _0x2d98e9=_0x1730ff(this['count']);this['bits_']=_0x194fc3+0x1&_0x2d98e9;}['nextBitIsOne'](){const _0x4c7d4f=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4c7d4f;}}const dn=function(_0x25ae0e,_0x41acfa,_0x1bb527,_0x1a17fa){_0x25ae0e['sort'](_0x41acfa);const _0x1ea009=function(_0xff1c2d,_0x5a8de2){const _0x3305bb=_0x5a8de2-_0xff1c2d;let _0x1665a2,_0x51a6ee;if(_0x3305bb===0x0)return null;if(_0x3305bb===0x1)return _0x1665a2=_0x25ae0e[_0xff1c2d],_0x51a6ee=_0x1bb527?_0x1bb527(_0x1665a2):_0x1665a2,new M(_0x51a6ee,_0x1665a2['node'],M['BLACK'],null,null);{const _0x5f1cbd=parseInt(_0x3305bb/0x2,0xa)+_0xff1c2d,_0x302003=_0x1ea009(_0xff1c2d,_0x5f1cbd),_0x2474b6=_0x1ea009(_0x5f1cbd+0x1,_0x5a8de2);return _0x1665a2=_0x25ae0e[_0x5f1cbd],_0x51a6ee=_0x1bb527?_0x1bb527(_0x1665a2):_0x1665a2,new M(_0x51a6ee,_0x1665a2['node'],M['BLACK'],_0x302003,_0x2474b6);}},_0x34db9d=function(_0x552ab1){let _0x1131f=null,_0x49e38d=null,_0x29e28b=_0x25ae0e['length'];const _0x2ed3cf=function(_0x156636,_0x560b8b){const _0x7e715e=_0x29e28b-_0x156636,_0x5e6cbd=_0x29e28b;_0x29e28b-=_0x156636;const _0x5ddb67=_0x1ea009(_0x7e715e+0x1,_0x5e6cbd),_0x58bf25=_0x25ae0e[_0x7e715e],_0x3e50c0=_0x1bb527?_0x1bb527(_0x58bf25):_0x58bf25;_0x19654f(new M(_0x3e50c0,_0x58bf25['node'],_0x560b8b,null,_0x5ddb67));},_0x19654f=function(_0x28a60c){_0x1131f?(_0x1131f['left']=_0x28a60c,_0x1131f=_0x28a60c):(_0x49e38d=_0x28a60c,_0x1131f=_0x28a60c);};for(let _0x57487f=0x0;_0x57487f<_0x552ab1['count'];++_0x57487f){const _0x3c5b41=_0x552ab1['nextBitIsOne'](),_0x2fe5b4=Math['pow'](0x2,_0x552ab1['count']-(_0x57487f+0x1));_0x3c5b41?_0x2ed3cf(_0x2fe5b4,M['BLACK']):(_0x2ed3cf(_0x2fe5b4,M['BLACK']),_0x2ed3cf(_0x2fe5b4,M['RED']));}return _0x49e38d;},_0x526c13=new Wh(_0x25ae0e['length']),_0xf7258=_0x34db9d(_0x526c13);return new B(_0x1a17fa||_0x41acfa,_0xf7258);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5a81cd,_0xd95f93){this['indexes_']=_0x5a81cd,this['indexSet_']=_0xd95f93;}['get'](_0x2ca640){const _0x37d1c9=Oe(this['indexes_'],_0x2ca640);if(!_0x37d1c9)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2ca640);return _0x37d1c9 instanceof B?_0x37d1c9:null;}['hasIndex'](_0xb4f6a7){return Y(this['indexSet_'],_0xb4f6a7['toString']());}['addIndex'](_0x35033e,_0x5f3853){f(_0x35033e!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x5634fe=[];let _0x5fee79=!0x1;const _0x36f7f7=_0x5f3853['getIterator'](E['Wrap']);let _0x241f02=_0x36f7f7['getNext']();for(;_0x241f02;)_0x5fee79=_0x5fee79||_0x35033e['isDefinedOn'](_0x241f02['node']),_0x5634fe['push'](_0x241f02),_0x241f02=_0x36f7f7['getNext']();let _0x2272c9;_0x5fee79?_0x2272c9=dn(_0x5634fe,_0x35033e['getCompare']()):_0x2272c9=je;const _0x376cb4=_0x35033e['toString'](),_0x1972f2={...this['indexSet_']};_0x1972f2[_0x376cb4]=_0x35033e;const _0x351bf8={...this['indexes_']};return _0x351bf8[_0x376cb4]=_0x2272c9,new ee(_0x351bf8,_0x1972f2);}['addToIndexes'](_0x47262,_0x60cb68){const _0x45504e=ln(this['indexes_'],(_0x6e4462,_0x1737d0)=>{const _0x4afa64=Oe(this['indexSet_'],_0x1737d0);if(f(_0x4afa64,'Missing\x20index\x20implementation\x20for\x20'+_0x1737d0),_0x6e4462===je){if(_0x4afa64['isDefinedOn'](_0x47262['node'])){const _0x2920e2=[],_0x46f84e=_0x60cb68['getIterator'](E['Wrap']);let _0x545859=_0x46f84e['getNext']();for(;_0x545859;)_0x545859['name']!==_0x47262['name']&&_0x2920e2['push'](_0x545859),_0x545859=_0x46f84e['getNext']();return _0x2920e2['push'](_0x47262),dn(_0x2920e2,_0x4afa64['getCompare']());}else return je;}else{const _0x105f5d=_0x60cb68['get'](_0x47262['name']);let _0x332787=_0x6e4462;return _0x105f5d&&(_0x332787=_0x332787['remove'](new E(_0x47262['name'],_0x105f5d))),_0x332787['insert'](_0x47262,_0x47262['node']);}});return new ee(_0x45504e,this['indexSet_']);}['removeFromIndexes'](_0x58f472,_0x1f635a){const _0x199c77=ln(this['indexes_'],_0xd62018=>{if(_0xd62018===je)return _0xd62018;{const _0x213d31=_0x1f635a['get'](_0x58f472['name']);return _0x213d31?_0xd62018['remove'](new E(_0x58f472['name'],_0x213d31)):_0xd62018;}});return new ee(_0x199c77,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x164b42,_0x53f799,_0x30d4b0){this['children_']=_0x164b42,this['priorityNode_']=_0x53f799,this['indexMap_']=_0x30d4b0,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x269c74){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x269c74,this['indexMap_']);}['getImmediateChild'](_0x47a11e){if(_0x47a11e==='.priority')return this['getPriority']();{const _0x1d0fbb=this['children_']['get'](_0x47a11e);return _0x1d0fbb===null?gt:_0x1d0fbb;}}['getChild'](_0x2e4f08){const _0x3552c5=y(_0x2e4f08);return _0x3552c5===null?this:this['getImmediateChild'](_0x3552c5)['getChild'](b(_0x2e4f08));}['hasChild'](_0x5e9e99){return this['children_']['get'](_0x5e9e99)!==null;}['updateImmediateChild'](_0x5cba7c,_0x553150){if(f(_0x553150,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5cba7c==='.priority')return this['updatePriority'](_0x553150);{const _0x19cfbe=new E(_0x5cba7c,_0x553150);let _0x34fefa,_0x5b9404;_0x553150['isEmpty']()?(_0x34fefa=this['children_']['remove'](_0x5cba7c),_0x5b9404=this['indexMap_']['removeFromIndexes'](_0x19cfbe,this['children_'])):(_0x34fefa=this['children_']['insert'](_0x5cba7c,_0x553150),_0x5b9404=this['indexMap_']['addToIndexes'](_0x19cfbe,this['children_']));const _0x11c742=_0x34fefa['isEmpty']()?gt:this['priorityNode_'];return new g(_0x34fefa,_0x11c742,_0x5b9404);}}['updateChild'](_0x12122f,_0x4fd507){const _0x14b48a=y(_0x12122f);if(_0x14b48a===null)return _0x4fd507;{f(y(_0x12122f)!=='.priority'||we(_0x12122f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x336604=this['getImmediateChild'](_0x14b48a)['updateChild'](b(_0x12122f),_0x4fd507);return this['updateImmediateChild'](_0x14b48a,_0x336604);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x24f1f4){if(this['isEmpty']())return null;const _0x1c2a70={};let _0x1344d5=0x0,_0x4b6794=0x0,_0xa05fa=!0x0;if(this['forEachChild'](R,(_0x2e916c,_0x2d492d)=>{_0x1c2a70[_0x2e916c]=_0x2d492d['val'](_0x24f1f4),_0x1344d5++,_0xa05fa&&g['INTEGER_REGEXP_']['test'](_0x2e916c)?_0x4b6794=Math['max'](_0x4b6794,Number(_0x2e916c)):_0xa05fa=!0x1;}),!_0x24f1f4&&_0xa05fa&&_0x4b6794<0x2*_0x1344d5){const _0x1867c7=[];for(const _0xb3903e in _0x1c2a70)_0x1867c7[_0xb3903e]=_0x1c2a70[_0xb3903e];return _0x1867c7;}else return _0x24f1f4&&!this['getPriority']()['isEmpty']()&&(_0x1c2a70['.priority']=this['getPriority']()['val']()),_0x1c2a70;}['hash'](){if(this['lazyHash_']===null){let _0x2496f='';this['getPriority']()['isEmpty']()||(_0x2496f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5cb854,_0x581c9f)=>{const _0x1338fd=_0x581c9f['hash']();_0x1338fd!==''&&(_0x2496f+=':'+_0x5cb854+':'+_0x1338fd);}),this['lazyHash_']=_0x2496f===''?'':no(_0x2496f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1ae898,_0x37f44a,_0x5ad76e){const _0x2c11dc=this['resolveIndex_'](_0x5ad76e);if(_0x2c11dc){const _0x181ebb=_0x2c11dc['getPredecessorKey'](new E(_0x1ae898,_0x37f44a));return _0x181ebb?_0x181ebb['name']:null;}else return this['children_']['getPredecessorKey'](_0x1ae898);}['getFirstChildName'](_0x147981){const _0x45ecc3=this['resolveIndex_'](_0x147981);if(_0x45ecc3){const _0x19850f=_0x45ecc3['minKey']();return _0x19850f&&_0x19850f['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xee076b){const _0x15dcab=this['getFirstChildName'](_0xee076b);return _0x15dcab?new E(_0x15dcab,this['children_']['get'](_0x15dcab)):null;}['getLastChildName'](_0x23bdb6){const _0xfc45d5=this['resolveIndex_'](_0x23bdb6);if(_0xfc45d5){const _0x460e14=_0xfc45d5['maxKey']();return _0x460e14&&_0x460e14['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2c6e0e){const _0x3cfed5=this['getLastChildName'](_0x2c6e0e);return _0x3cfed5?new E(_0x3cfed5,this['children_']['get'](_0x3cfed5)):null;}['forEachChild'](_0x3ad98f,_0x5aef61){const _0x51e2f1=this['resolveIndex_'](_0x3ad98f);return _0x51e2f1?_0x51e2f1['inorderTraversal'](_0x966325=>_0x5aef61(_0x966325['name'],_0x966325['node'])):this['children_']['inorderTraversal'](_0x5aef61);}['getIterator'](_0x502ca9){return this['getIteratorFrom'](_0x502ca9['minPost'](),_0x502ca9);}['getIteratorFrom'](_0x1f8e62,_0x511d75){const _0x16bb6e=this['resolveIndex_'](_0x511d75);if(_0x16bb6e)return _0x16bb6e['getIteratorFrom'](_0x1f8e62,_0x48ea95=>_0x48ea95);{const _0x31bfb4=this['children_']['getIteratorFrom'](_0x1f8e62['name'],E['Wrap']);let _0x476e05=_0x31bfb4['peek']();for(;_0x476e05!=null&&_0x511d75['compare'](_0x476e05,_0x1f8e62)<0x0;)_0x31bfb4['getNext'](),_0x476e05=_0x31bfb4['peek']();return _0x31bfb4;}}['getReverseIterator'](_0x125668){return this['getReverseIteratorFrom'](_0x125668['maxPost'](),_0x125668);}['getReverseIteratorFrom'](_0x2b09ad,_0x44d46a){const _0x116415=this['resolveIndex_'](_0x44d46a);if(_0x116415)return _0x116415['getReverseIteratorFrom'](_0x2b09ad,_0x18614c=>_0x18614c);{const _0xa275ec=this['children_']['getReverseIteratorFrom'](_0x2b09ad['name'],E['Wrap']);let _0xc0101f=_0xa275ec['peek']();for(;_0xc0101f!=null&&_0x44d46a['compare'](_0xc0101f,_0x2b09ad)>0x0;)_0xa275ec['getNext'](),_0xc0101f=_0xa275ec['peek']();return _0xa275ec;}}['compareTo'](_0x56ea27){return this['isEmpty']()?_0x56ea27['isEmpty']()?0x0:-0x1:_0x56ea27['isLeafNode']()||_0x56ea27['isEmpty']()?0x1:_0x56ea27===Ht?-0x1:0x0;}['withIndex'](_0x33a717){if(_0x33a717===ye||this['indexMap_']['hasIndex'](_0x33a717))return this;{const _0x302104=this['indexMap_']['addIndex'](_0x33a717,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x302104);}}['isIndexed'](_0x14a5d2){return _0x14a5d2===ye||this['indexMap_']['hasIndex'](_0x14a5d2);}['equals'](_0x3ba6a1){if(_0x3ba6a1===this)return!0x0;if(_0x3ba6a1['isLeafNode']())return!0x1;{const _0x11b7a9=_0x3ba6a1;if(this['getPriority']()['equals'](_0x11b7a9['getPriority']())){if(this['children_']['count']()===_0x11b7a9['children_']['count']()){const _0x2763bf=this['getIterator'](R),_0x398038=_0x11b7a9['getIterator'](R);let _0x4283f0=_0x2763bf['getNext'](),_0x3b4108=_0x398038['getNext']();for(;_0x4283f0&&_0x3b4108;){if(_0x4283f0['name']!==_0x3b4108['name']||!_0x4283f0['node']['equals'](_0x3b4108['node']))return!0x1;_0x4283f0=_0x2763bf['getNext'](),_0x3b4108=_0x398038['getNext']();}return _0x4283f0===null&&_0x3b4108===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x51427b){return _0x51427b===ye?null:this['indexMap_']['get'](_0x51427b['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0xe049cd){return _0xe049cd===this?0x0:0x1;}['equals'](_0x37cd9a){return _0x37cd9a===this;}['getPriority'](){return this;}['getImmediateChild'](_0x127c18){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x31e7c6,_0x1f918a=null){if(_0x31e7c6===null)return g['EMPTY_NODE'];if(typeof _0x31e7c6=='object'&&'.priority'in _0x31e7c6&&(_0x1f918a=_0x31e7c6['.priority']),f(_0x1f918a===null||typeof _0x1f918a=='string'||typeof _0x1f918a=='number'||typeof _0x1f918a=='object'&&'.sv'in _0x1f918a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1f918a),typeof _0x31e7c6=='object'&&'.value'in _0x31e7c6&&_0x31e7c6['.value']!==null&&(_0x31e7c6=_0x31e7c6['.value']),typeof _0x31e7c6!='object'||'.sv'in _0x31e7c6){const _0x50b4ab=_0x31e7c6;return new D(_0x50b4ab,N(_0x1f918a));}if(!(_0x31e7c6 instanceof Array)&&Vh){const _0x2b2199=[];let _0x2d16b1=!0x1;if(x(_0x31e7c6,(_0x14dbb1,_0x1adcd9)=>{if(_0x14dbb1['substring'](0x0,0x1)!=='.'){const _0x4351e3=N(_0x1adcd9);_0x4351e3['isEmpty']()||(_0x2d16b1=_0x2d16b1||!_0x4351e3['getPriority']()['isEmpty'](),_0x2b2199['push'](new E(_0x14dbb1,_0x4351e3)));}}),_0x2b2199['length']===0x0)return g['EMPTY_NODE'];const _0x5142f4=dn(_0x2b2199,Dh,_0x484b6c=>_0x484b6c['name'],ji);if(_0x2d16b1){const _0x33ba92=dn(_0x2b2199,R['getCompare']());return new g(_0x5142f4,N(_0x1f918a),new ee({'.priority':_0x33ba92},{'.priority':R}));}else return new g(_0x5142f4,N(_0x1f918a),ee['Default']);}else{let _0x4c10a1=g['EMPTY_NODE'];return x(_0x31e7c6,(_0x4afe9a,_0x183441)=>{if(Y(_0x31e7c6,_0x4afe9a)&&_0x4afe9a['substring'](0x0,0x1)!=='.'){const _0x20c907=N(_0x183441);(_0x20c907['isLeafNode']()||!_0x20c907['isEmpty']())&&(_0x4c10a1=_0x4c10a1['updateImmediateChild'](_0x4afe9a,_0x20c907));}}),_0x4c10a1['updatePriority'](N(_0x1f918a));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x5a5469){super(),this['indexPath_']=_0x5a5469,f(!v(_0x5a5469)&&y(_0x5a5469)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x30870a){return _0x30870a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3d50a5){return!_0x3d50a5['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3ad873,_0xb6cbc4){const _0x44406b=this['extractChild'](_0x3ad873['node']),_0x460735=this['extractChild'](_0xb6cbc4['node']),_0x58f475=_0x44406b['compareTo'](_0x460735);return _0x58f475===0x0?He(_0x3ad873['name'],_0xb6cbc4['name']):_0x58f475;}['makePost'](_0xdda5c8,_0xdba152){const _0x302079=N(_0xdda5c8),_0x461211=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x302079);return new E(_0xdba152,_0x461211);}['maxPost'](){const _0x32b96d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x32b96d);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x39e174,_0x488ef1){const _0x212daa=_0x39e174['node']['compareTo'](_0x488ef1['node']);return _0x212daa===0x0?He(_0x39e174['name'],_0x488ef1['name']):_0x212daa;}['isDefinedOn'](_0x5a3cad){return!0x0;}['indexedValueChanged'](_0x1aa270,_0x1b4cd6){return!_0x1aa270['equals'](_0x1b4cd6);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1c4d2b,_0xe7017){const _0x1f6e68=N(_0x1c4d2b);return new E(_0xe7017,_0x1f6e68);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x24fa94){return{'type':'value','snapshotNode':_0x24fa94};}function tt(_0x42f36c,_0x3b7493){return{'type':'child_added','snapshotNode':_0x3b7493,'childName':_0x42f36c};}function Nt(_0x8741e7,_0x52e5de){return{'type':'child_removed','snapshotNode':_0x52e5de,'childName':_0x8741e7};}function Pt(_0x5ed2b5,_0x41346d,_0x1b2cb2){return{'type':'child_changed','snapshotNode':_0x41346d,'childName':_0x5ed2b5,'oldSnap':_0x1b2cb2};}function $h(_0x51a09d,_0x37af31){return{'type':'child_moved','snapshotNode':_0x37af31,'childName':_0x51a09d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x78d486){this['index_']=_0x78d486;}['updateChild'](_0x5a2513,_0x18c372,_0x3e9558,_0x2c6b4e,_0x1305b5,_0x90b6f0){f(_0x5a2513['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1290ee=_0x5a2513['getImmediateChild'](_0x18c372);return _0x1290ee['getChild'](_0x2c6b4e)['equals'](_0x3e9558['getChild'](_0x2c6b4e))&&_0x1290ee['isEmpty']()===_0x3e9558['isEmpty']()||(_0x90b6f0!=null&&(_0x3e9558['isEmpty']()?_0x5a2513['hasChild'](_0x18c372)?_0x90b6f0['trackChildChange'](Nt(_0x18c372,_0x1290ee)):f(_0x5a2513['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1290ee['isEmpty']()?_0x90b6f0['trackChildChange'](tt(_0x18c372,_0x3e9558)):_0x90b6f0['trackChildChange'](Pt(_0x18c372,_0x3e9558,_0x1290ee))),_0x5a2513['isLeafNode']()&&_0x3e9558['isEmpty']())?_0x5a2513:_0x5a2513['updateImmediateChild'](_0x18c372,_0x3e9558)['withIndex'](this['index_']);}['updateFullNode'](_0x1a0aef,_0x180aac,_0x35af8e){return _0x35af8e!=null&&(_0x1a0aef['isLeafNode']()||_0x1a0aef['forEachChild'](R,(_0x400971,_0x18a2bb)=>{_0x180aac['hasChild'](_0x400971)||_0x35af8e['trackChildChange'](Nt(_0x400971,_0x18a2bb));}),_0x180aac['isLeafNode']()||_0x180aac['forEachChild'](R,(_0x44c5e7,_0x31e849)=>{if(_0x1a0aef['hasChild'](_0x44c5e7)){const _0x10f91a=_0x1a0aef['getImmediateChild'](_0x44c5e7);_0x10f91a['equals'](_0x31e849)||_0x35af8e['trackChildChange'](Pt(_0x44c5e7,_0x31e849,_0x10f91a));}else _0x35af8e['trackChildChange'](tt(_0x44c5e7,_0x31e849));})),_0x180aac['withIndex'](this['index_']);}['updatePriority'](_0x2950e6,_0x5afc90){return _0x2950e6['isEmpty']()?g['EMPTY_NODE']:_0x2950e6['updatePriority'](_0x5afc90);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x194237){this['indexedFilter_']=new Yi(_0x194237['getIndex']()),this['index_']=_0x194237['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x194237),this['endPost_']=Ot['getEndPost_'](_0x194237),this['startIsInclusive_']=!_0x194237['startAfterSet_'],this['endIsInclusive_']=!_0x194237['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5acc26){const _0x29461a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5acc26)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5acc26)<0x0,_0x3a4f2a=this['endIsInclusive_']?this['index_']['compare'](_0x5acc26,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5acc26,this['getEndPost']())<0x0;return _0x29461a&&_0x3a4f2a;}['updateChild'](_0x4e76b5,_0x185bb9,_0x6d55f,_0x53f526,_0x16c273,_0x1f3ecb){return this['matches'](new E(_0x185bb9,_0x6d55f))||(_0x6d55f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4e76b5,_0x185bb9,_0x6d55f,_0x53f526,_0x16c273,_0x1f3ecb);}['updateFullNode'](_0x484b09,_0x5d9653,_0x5828ab){_0x5d9653['isLeafNode']()&&(_0x5d9653=g['EMPTY_NODE']);let _0x37e5b1=_0x5d9653['withIndex'](this['index_']);_0x37e5b1=_0x37e5b1['updatePriority'](g['EMPTY_NODE']);const _0x531543=this;return _0x5d9653['forEachChild'](R,(_0x218058,_0x29190f)=>{_0x531543['matches'](new E(_0x218058,_0x29190f))||(_0x37e5b1=_0x37e5b1['updateImmediateChild'](_0x218058,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x484b09,_0x37e5b1,_0x5828ab);}['updatePriority'](_0x4be17c,_0x50498b){return _0x4be17c;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x34c036){if(_0x34c036['hasStart']()){const _0x379b1a=_0x34c036['getIndexStartName']();return _0x34c036['getIndex']()['makePost'](_0x34c036['getIndexStartValue'](),_0x379b1a);}else return _0x34c036['getIndex']()['minPost']();}static['getEndPost_'](_0xff0bb0){if(_0xff0bb0['hasEnd']()){const _0x3ca952=_0xff0bb0['getIndexEndName']();return _0xff0bb0['getIndex']()['makePost'](_0xff0bb0['getIndexEndValue'](),_0x3ca952);}else return _0xff0bb0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x17d118){this['withinDirectionalStart']=_0x49457a=>this['reverse_']?this['withinEndPost'](_0x49457a):this['withinStartPost'](_0x49457a),this['withinDirectionalEnd']=_0x34104e=>this['reverse_']?this['withinStartPost'](_0x34104e):this['withinEndPost'](_0x34104e),this['withinStartPost']=_0x967bb0=>{const _0xcb44b1=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x967bb0);return this['startIsInclusive_']?_0xcb44b1<=0x0:_0xcb44b1<0x0;},this['withinEndPost']=_0x1ba03e=>{const _0x1a6b88=this['index_']['compare'](_0x1ba03e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1a6b88<=0x0:_0x1a6b88<0x0;},this['rangedFilter_']=new Ot(_0x17d118),this['index_']=_0x17d118['getIndex'](),this['limit_']=_0x17d118['getLimit'](),this['reverse_']=!_0x17d118['isViewFromLeft'](),this['startIsInclusive_']=!_0x17d118['startAfterSet_'],this['endIsInclusive_']=!_0x17d118['endBeforeSet_'];}['updateChild'](_0x5c5de7,_0x348ef0,_0x40fa61,_0x22ff5e,_0x4f256c,_0x57247e){return this['rangedFilter_']['matches'](new E(_0x348ef0,_0x40fa61))||(_0x40fa61=g['EMPTY_NODE']),_0x5c5de7['getImmediateChild'](_0x348ef0)['equals'](_0x40fa61)?_0x5c5de7:_0x5c5de7['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5c5de7,_0x348ef0,_0x40fa61,_0x22ff5e,_0x4f256c,_0x57247e):this['fullLimitUpdateChild_'](_0x5c5de7,_0x348ef0,_0x40fa61,_0x4f256c,_0x57247e);}['updateFullNode'](_0x142c32,_0x5b417b,_0x232319){let _0x124102;if(_0x5b417b['isLeafNode']()||_0x5b417b['isEmpty']())_0x124102=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5b417b['numChildren']()&&_0x5b417b['isIndexed'](this['index_'])){_0x124102=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xbbb48c;this['reverse_']?_0xbbb48c=_0x5b417b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xbbb48c=_0x5b417b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5c8b5c=0x0;for(;_0xbbb48c['hasNext']()&&_0x5c8b5c<this['limit_'];){const _0x356797=_0xbbb48c['getNext']();if(this['withinDirectionalStart'](_0x356797)){if(this['withinDirectionalEnd'](_0x356797))_0x124102=_0x124102['updateImmediateChild'](_0x356797['name'],_0x356797['node']),_0x5c8b5c++;else break;}else continue;}}else{_0x124102=_0x5b417b['withIndex'](this['index_']),_0x124102=_0x124102['updatePriority'](g['EMPTY_NODE']);let _0x49908e;this['reverse_']?_0x49908e=_0x124102['getReverseIterator'](this['index_']):_0x49908e=_0x124102['getIterator'](this['index_']);let _0x50d0af=0x0;for(;_0x49908e['hasNext']();){const _0x4b03af=_0x49908e['getNext']();_0x50d0af<this['limit_']&&this['withinDirectionalStart'](_0x4b03af)&&this['withinDirectionalEnd'](_0x4b03af)?_0x50d0af++:_0x124102=_0x124102['updateImmediateChild'](_0x4b03af['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x142c32,_0x124102,_0x232319);}['updatePriority'](_0x5c35dc,_0x525984){return _0x5c35dc;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3fea67,_0x3d963c,_0xd908db,_0x5e510c,_0x59a297){let _0x189065;if(this['reverse_']){const _0xdc330d=this['index_']['getCompare']();_0x189065=(_0x16a7ba,_0x92735c)=>_0xdc330d(_0x92735c,_0x16a7ba);}else _0x189065=this['index_']['getCompare']();const _0x2f7b49=_0x3fea67;f(_0x2f7b49['numChildren']()===this['limit_'],'');const _0x1c438e=new E(_0x3d963c,_0xd908db),_0x4457ec=this['reverse_']?_0x2f7b49['getFirstChild'](this['index_']):_0x2f7b49['getLastChild'](this['index_']),_0x4ef8a1=this['rangedFilter_']['matches'](_0x1c438e);if(_0x2f7b49['hasChild'](_0x3d963c)){const _0x20d1a1=_0x2f7b49['getImmediateChild'](_0x3d963c);let _0x506ce4=_0x5e510c['getChildAfterChild'](this['index_'],_0x4457ec,this['reverse_']);for(;_0x506ce4!=null&&(_0x506ce4['name']===_0x3d963c||_0x2f7b49['hasChild'](_0x506ce4['name']));)_0x506ce4=_0x5e510c['getChildAfterChild'](this['index_'],_0x506ce4,this['reverse_']);const _0x17a6e7=_0x506ce4==null?0x1:_0x189065(_0x506ce4,_0x1c438e);if(_0x4ef8a1&&!_0xd908db['isEmpty']()&&_0x17a6e7>=0x0)return _0x59a297!=null&&_0x59a297['trackChildChange'](Pt(_0x3d963c,_0xd908db,_0x20d1a1)),_0x2f7b49['updateImmediateChild'](_0x3d963c,_0xd908db);{_0x59a297!=null&&_0x59a297['trackChildChange'](Nt(_0x3d963c,_0x20d1a1));const _0x265d1e=_0x2f7b49['updateImmediateChild'](_0x3d963c,g['EMPTY_NODE']);return _0x506ce4!=null&&this['rangedFilter_']['matches'](_0x506ce4)?(_0x59a297!=null&&_0x59a297['trackChildChange'](tt(_0x506ce4['name'],_0x506ce4['node'])),_0x265d1e['updateImmediateChild'](_0x506ce4['name'],_0x506ce4['node'])):_0x265d1e;}}else return _0xd908db['isEmpty']()?_0x3fea67:_0x4ef8a1&&_0x189065(_0x4457ec,_0x1c438e)>=0x0?(_0x59a297!=null&&(_0x59a297['trackChildChange'](Nt(_0x4457ec['name'],_0x4457ec['node'])),_0x59a297['trackChildChange'](tt(_0x3d963c,_0xd908db))),_0x2f7b49['updateImmediateChild'](_0x3d963c,_0xd908db)['updateImmediateChild'](_0x4457ec['name'],g['EMPTY_NODE'])):_0x3fea67;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x393958=new Qi();return _0x393958['limitSet_']=this['limitSet_'],_0x393958['limit_']=this['limit_'],_0x393958['startSet_']=this['startSet_'],_0x393958['startAfterSet_']=this['startAfterSet_'],_0x393958['indexStartValue_']=this['indexStartValue_'],_0x393958['startNameSet_']=this['startNameSet_'],_0x393958['indexStartName_']=this['indexStartName_'],_0x393958['endSet_']=this['endSet_'],_0x393958['endBeforeSet_']=this['endBeforeSet_'],_0x393958['indexEndValue_']=this['indexEndValue_'],_0x393958['endNameSet_']=this['endNameSet_'],_0x393958['indexEndName_']=this['indexEndName_'],_0x393958['index_']=this['index_'],_0x393958['viewFrom_']=this['viewFrom_'],_0x393958;}}function qh(_0x3911b4){return _0x3911b4['loadsAllData']()?new Yi(_0x3911b4['getIndex']()):_0x3911b4['hasLimit']()?new Gh(_0x3911b4):new Ot(_0x3911b4);}function zh(_0x18704a,_0x4a457c){const _0x2b9b51=_0x18704a['copy']();return _0x2b9b51['limitSet_']=!0x0,_0x2b9b51['limit_']=_0x4a457c,_0x2b9b51['viewFrom_']='l',_0x2b9b51;}function jh(_0x43cb5f,_0x1a9c83,_0x5a4552){const _0x26a34d=_0x43cb5f['copy']();return _0x26a34d['startSet_']=!0x0,_0x1a9c83===void 0x0&&(_0x1a9c83=null),_0x26a34d['indexStartValue_']=_0x1a9c83,_0x5a4552!=null?(_0x26a34d['startNameSet_']=!0x0,_0x26a34d['indexStartName_']=_0x5a4552):(_0x26a34d['startNameSet_']=!0x1,_0x26a34d['indexStartName_']=''),_0x26a34d;}function Kh(_0x299d29,_0x535c4e,_0x1e00de){const _0x32812f=_0x299d29['copy']();return _0x32812f['endSet_']=!0x0,_0x535c4e===void 0x0&&(_0x535c4e=null),_0x32812f['indexEndValue_']=_0x535c4e,_0x1e00de!==void 0x0?(_0x32812f['endNameSet_']=!0x0,_0x32812f['indexEndName_']=_0x1e00de):(_0x32812f['endNameSet_']=!0x1,_0x32812f['indexEndName_']=''),_0x32812f;}function Do(_0x6c5748,_0x59daa7){const _0x4a5c27=_0x6c5748['copy']();return _0x4a5c27['index_']=_0x59daa7,_0x4a5c27;}function tr(_0x5ddc7c){const _0x54e321={};if(_0x5ddc7c['isDefault']())return _0x54e321;let _0x3fb0e7;if(_0x5ddc7c['index_']===R?_0x3fb0e7='$priority':_0x5ddc7c['index_']===Po?_0x3fb0e7='$value':_0x5ddc7c['index_']===ye?_0x3fb0e7='$key':(f(_0x5ddc7c['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x3fb0e7=_0x5ddc7c['index_']['toString']()),_0x54e321['orderBy']=O(_0x3fb0e7),_0x5ddc7c['startSet_']){const _0x193eba=_0x5ddc7c['startAfterSet_']?'startAfter':'startAt';_0x54e321[_0x193eba]=O(_0x5ddc7c['indexStartValue_']),_0x5ddc7c['startNameSet_']&&(_0x54e321[_0x193eba]+=','+O(_0x5ddc7c['indexStartName_']));}if(_0x5ddc7c['endSet_']){const _0x1d91c4=_0x5ddc7c['endBeforeSet_']?'endBefore':'endAt';_0x54e321[_0x1d91c4]=O(_0x5ddc7c['indexEndValue_']),_0x5ddc7c['endNameSet_']&&(_0x54e321[_0x1d91c4]+=','+O(_0x5ddc7c['indexEndName_']));}return _0x5ddc7c['limitSet_']&&(_0x5ddc7c['isViewFromLeft']()?_0x54e321['limitToFirst']=_0x5ddc7c['limit_']:_0x54e321['limitToLast']=_0x5ddc7c['limit_']),_0x54e321;}function nr(_0x2acf2e){const _0x53e481={};if(_0x2acf2e['startSet_']&&(_0x53e481['sp']=_0x2acf2e['indexStartValue_'],_0x2acf2e['startNameSet_']&&(_0x53e481['sn']=_0x2acf2e['indexStartName_']),_0x53e481['sin']=!_0x2acf2e['startAfterSet_']),_0x2acf2e['endSet_']&&(_0x53e481['ep']=_0x2acf2e['indexEndValue_'],_0x2acf2e['endNameSet_']&&(_0x53e481['en']=_0x2acf2e['indexEndName_']),_0x53e481['ein']=!_0x2acf2e['endBeforeSet_']),_0x2acf2e['limitSet_']){_0x53e481['l']=_0x2acf2e['limit_'];let _0x38ddc2=_0x2acf2e['viewFrom_'];_0x38ddc2===''&&(_0x2acf2e['isViewFromLeft']()?_0x38ddc2='l':_0x38ddc2='r'),_0x53e481['vf']=_0x38ddc2;}return _0x2acf2e['index_']!==R&&(_0x53e481['i']=_0x2acf2e['index_']['toString']()),_0x53e481;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x27e41b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x350122,_0xaf0fbc){return _0xaf0fbc!==void 0x0?'tag$'+_0xaf0fbc:(f(_0x350122['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x350122['_path']['toString']());}constructor(_0x164480,_0x3f9128,_0x42ce85,_0x40f6ab){super(),this['repoInfo_']=_0x164480,this['onDataUpdate_']=_0x3f9128,this['authTokenProvider_']=_0x42ce85,this['appCheckTokenProvider_']=_0x40f6ab,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2fbfdf,_0x47c307,_0x1e1422,_0x464036){const _0x55763d=_0x2fbfdf['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x55763d+'\x20'+_0x2fbfdf['_queryIdentifier']);const _0x123d8c=fn['getListenId_'](_0x2fbfdf,_0x1e1422),_0x527644={};this['listens_'][_0x123d8c]=_0x527644;const _0x10eaed=tr(_0x2fbfdf['_queryParams']);this['restRequest_'](_0x55763d+'.json',_0x10eaed,(_0x3c0d89,_0x3d22e5)=>{let _0x480f9e=_0x3d22e5;if(_0x3c0d89===0x194&&(_0x480f9e=null,_0x3c0d89=null),_0x3c0d89===null&&this['onDataUpdate_'](_0x55763d,_0x480f9e,!0x1,_0x1e1422),Oe(this['listens_'],_0x123d8c)===_0x527644){let _0x129e66;_0x3c0d89?_0x3c0d89===0x191?_0x129e66='permission_denied':_0x129e66='rest_error:'+_0x3c0d89:_0x129e66='ok',_0x464036(_0x129e66,null);}});}['unlisten'](_0x1e183f,_0x1b4c9f){const _0x43ad52=fn['getListenId_'](_0x1e183f,_0x1b4c9f);delete this['listens_'][_0x43ad52];}['get'](_0x186646){const _0x5d2b33=tr(_0x186646['_queryParams']),_0x2c5e70=_0x186646['_path']['toString'](),_0x58efed=new Ve();return this['restRequest_'](_0x2c5e70+'.json',_0x5d2b33,(_0x2b4121,_0x2ef3e7)=>{let _0x46edab=_0x2ef3e7;_0x2b4121===0x194&&(_0x46edab=null,_0x2b4121=null),_0x2b4121===null?(this['onDataUpdate_'](_0x2c5e70,_0x46edab,!0x1,null),_0x58efed['resolve'](_0x46edab)):_0x58efed['reject'](new Error(_0x46edab));}),_0x58efed['promise'];}['refreshAuthToken'](_0x28357c){}['restRequest_'](_0x443959,_0x37d0c9={},_0x2dbef7){return _0x37d0c9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2eba00,_0x52b10a])=>{_0x2eba00&&_0x2eba00['accessToken']&&(_0x37d0c9['auth']=_0x2eba00['accessToken']),_0x52b10a&&_0x52b10a['token']&&(_0x37d0c9['ac']=_0x52b10a['token']);const _0x2cb233=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x443959+'?ns='+this['repoInfo_']['namespace']+at(_0x37d0c9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2cb233);const _0x398f1a=new XMLHttpRequest();_0x398f1a['onreadystatechange']=()=>{if(_0x2dbef7&&_0x398f1a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2cb233+'\x20received.\x20status:',_0x398f1a['status'],'response:',_0x398f1a['responseText']);let _0x144c76=null;if(_0x398f1a['status']>=0xc8&&_0x398f1a['status']<0x12c){try{_0x144c76=bt(_0x398f1a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2cb233+':\x20'+_0x398f1a['responseText']);}_0x2dbef7(null,_0x144c76);}else _0x398f1a['status']!==0x191&&_0x398f1a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2cb233+'\x20Status:\x20'+_0x398f1a['status']),_0x2dbef7(_0x398f1a['status']);_0x2dbef7=null;}},_0x398f1a['open']('GET',_0x2cb233,!0x0),_0x398f1a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x349ac0){return this['rootNode_']['getChild'](_0x349ac0);}['updateSnapshot'](_0x25cfe8,_0x3c14a9){this['rootNode_']=this['rootNode_']['updateChild'](_0x25cfe8,_0x3c14a9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x42e639,_0x137647,_0x56c74b){if(v(_0x137647))_0x42e639['value']=_0x56c74b,_0x42e639['children']['clear']();else{if(_0x42e639['value']!==null)_0x42e639['value']=_0x42e639['value']['updateChild'](_0x137647,_0x56c74b);else{const _0x568a09=y(_0x137647);_0x42e639['children']['has'](_0x568a09)||_0x42e639['children']['set'](_0x568a09,pn());const _0x3563e7=_0x42e639['children']['get'](_0x568a09);_0x137647=b(_0x137647),Mo(_0x3563e7,_0x137647,_0x56c74b);}}}function Ei(_0x122f71,_0x10f4da,_0xf0999f){_0x122f71['value']!==null?_0xf0999f(_0x10f4da,_0x122f71['value']):Qh(_0x122f71,(_0x1557db,_0x1c1821)=>{const _0x22bce7=new C(_0x10f4da['toString']()+'/'+_0x1557db);Ei(_0x1c1821,_0x22bce7,_0xf0999f);});}function Qh(_0x32fb78,_0x4239a2){_0x32fb78['children']['forEach']((_0x2d2518,_0x5f2cb1)=>{_0x4239a2(_0x5f2cb1,_0x2d2518);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x2fa357){this['collection_']=_0x2fa357,this['last_']=null;}['get'](){const _0x51c026=this['collection_']['get'](),_0x59165e={..._0x51c026};return this['last_']&&x(this['last_'],(_0x14e8f2,_0x56cf4e)=>{_0x59165e[_0x14e8f2]=_0x59165e[_0x14e8f2]-_0x56cf4e;}),this['last_']=_0x51c026,_0x59165e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x94b59b,_0x457e6b){this['server_']=_0x457e6b,this['statsToReport_']={},this['statsListener_']=new Jh(_0x94b59b);const _0x371e40=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x371e40));}['reportStats_'](){const _0xfc15c5=this['statsListener_']['get'](),_0x1afc73={};let _0x219bb9=!0x1;x(_0xfc15c5,(_0x1c1fd9,_0x49b388)=>{_0x49b388>0x0&&Y(this['statsToReport_'],_0x1c1fd9)&&(_0x1afc73[_0x1c1fd9]=_0x49b388,_0x219bb9=!0x0);}),_0x219bb9&&this['server_']['reportStats'](_0x1afc73),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0xa21548){_0xa21548[_0xa21548['OVERWRITE']=0x0]='OVERWRITE',_0xa21548[_0xa21548['MERGE']=0x1]='MERGE',_0xa21548[_0xa21548['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xa21548[_0xa21548['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x773567){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x773567,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4b7881,_0x387e16,_0x11deb5){this['path']=_0x4b7881,this['affectedTree']=_0x387e16,this['revert']=_0x11deb5,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x173d18){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x253835=this['affectedTree']['subtree'](new C(_0x173d18));return new _n(w(),_0x253835,this['revert']);}}else return f(y(this['path'])===_0x173d18,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x199090,_0x451aa3){this['source']=_0x199090,this['path']=_0x451aa3,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x15f846){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x16bfe7,_0xe75b6f,_0x465261){this['source']=_0x16bfe7,this['path']=_0xe75b6f,this['snap']=_0x465261,this['type']=q['OVERWRITE'];}['operationForChild'](_0x236c98){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x236c98)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xfea99e,_0x386320,_0x40e02e){this['source']=_0xfea99e,this['path']=_0x386320,this['children']=_0x40e02e,this['type']=q['MERGE'];}['operationForChild'](_0x2c7233){if(v(this['path'])){const _0x2e3409=this['children']['subtree'](new C(_0x2c7233));return _0x2e3409['isEmpty']()?null:_0x2e3409['value']?new Fe(this['source'],w(),_0x2e3409['value']):new nt(this['source'],w(),_0x2e3409);}else return f(y(this['path'])===_0x2c7233,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x354145,_0x209bc2,_0x42a77c){this['node_']=_0x354145,this['fullyInitialized_']=_0x209bc2,this['filtered_']=_0x42a77c;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x22f2f0){if(v(_0x22f2f0))return this['isFullyInitialized']()&&!this['filtered_'];const _0x334dbf=y(_0x22f2f0);return this['isCompleteForChild'](_0x334dbf);}['isCompleteForChild'](_0x135cd9){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x135cd9);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x3b324a){this['query_']=_0x3b324a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0xaf7935,_0x329309,_0x1fbc81,_0x32f7f6){const _0x4062e7=[],_0x19ea4f=[];return _0x329309['forEach'](_0xb137c0=>{_0xb137c0['type']==='child_changed'&&_0xaf7935['index_']['indexedValueChanged'](_0xb137c0['oldSnap'],_0xb137c0['snapshotNode'])&&_0x19ea4f['push']($h(_0xb137c0['childName'],_0xb137c0['snapshotNode']));}),mt(_0xaf7935,_0x4062e7,'child_removed',_0x329309,_0x32f7f6,_0x1fbc81),mt(_0xaf7935,_0x4062e7,'child_added',_0x329309,_0x32f7f6,_0x1fbc81),mt(_0xaf7935,_0x4062e7,'child_moved',_0x19ea4f,_0x32f7f6,_0x1fbc81),mt(_0xaf7935,_0x4062e7,'child_changed',_0x329309,_0x32f7f6,_0x1fbc81),mt(_0xaf7935,_0x4062e7,'value',_0x329309,_0x32f7f6,_0x1fbc81),_0x4062e7;}function mt(_0x2aae32,_0x4d68f9,_0x372578,_0x4e032b,_0x5eeb6f,_0x337dc7){const _0x4b4840=_0x4e032b['filter'](_0x482838=>_0x482838['type']===_0x372578);_0x4b4840['sort']((_0x182b0d,_0x5aeb50)=>su(_0x2aae32,_0x182b0d,_0x5aeb50)),_0x4b4840['forEach'](_0x4c1709=>{const _0x409ad2=iu(_0x2aae32,_0x4c1709,_0x337dc7);_0x5eeb6f['forEach'](_0x3b8126=>{_0x3b8126['respondsTo'](_0x4c1709['type'])&&_0x4d68f9['push'](_0x3b8126['createEvent'](_0x409ad2,_0x2aae32['query_']));});});}function iu(_0x5a1ab6,_0x511ced,_0x3aea66){return _0x511ced['type']==='value'||_0x511ced['type']==='child_removed'||(_0x511ced['prevName']=_0x3aea66['getPredecessorChildName'](_0x511ced['childName'],_0x511ced['snapshotNode'],_0x5a1ab6['index_'])),_0x511ced;}function su(_0x1ad3a4,_0x29eef2,_0x9cc8f4){if(_0x29eef2['childName']==null||_0x9cc8f4['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x556d46=new E(_0x29eef2['childName'],_0x29eef2['snapshotNode']),_0x4c4b06=new E(_0x9cc8f4['childName'],_0x9cc8f4['snapshotNode']);return _0x1ad3a4['index_']['compare'](_0x556d46,_0x4c4b06);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x89a5b8,_0x22b4d2){return{'eventCache':_0x89a5b8,'serverCache':_0x22b4d2};}function wt(_0x205722,_0x1d1e78,_0x15d2f0,_0x21bc5f){return Dn(new Ce(_0x1d1e78,_0x15d2f0,_0x21bc5f),_0x205722['serverCache']);}function Lo(_0x1a0ad9,_0x572ad0,_0xc49f9a,_0x37ca06){return Dn(_0x1a0ad9['eventCache'],new Ce(_0x572ad0,_0xc49f9a,_0x37ca06));}function gn(_0x119a8c){return _0x119a8c['eventCache']['isFullyInitialized']()?_0x119a8c['eventCache']['getNode']():null;}function Ue(_0x43ef70){return _0x43ef70['serverCache']['isFullyInitialized']()?_0x43ef70['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3ffef6){let _0x1b558a=new S(null);return x(_0x3ffef6,(_0x440197,_0x399813)=>{_0x1b558a=_0x1b558a['set'](new C(_0x440197),_0x399813);}),_0x1b558a;}constructor(_0x4c1a89,_0x9fb604=ru()){this['value']=_0x4c1a89,this['children']=_0x9fb604;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xc63850,_0x1cd1da){if(this['value']!=null&&_0x1cd1da(this['value']))return{'path':w(),'value':this['value']};if(v(_0xc63850))return null;{const _0x124f6d=y(_0xc63850),_0x9af4db=this['children']['get'](_0x124f6d);if(_0x9af4db!==null){const _0x2f73f1=_0x9af4db['findRootMostMatchingPathAndValue'](b(_0xc63850),_0x1cd1da);return _0x2f73f1!=null?{'path':A(new C(_0x124f6d),_0x2f73f1['path']),'value':_0x2f73f1['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4fd127){return this['findRootMostMatchingPathAndValue'](_0x4fd127,()=>!0x0);}['subtree'](_0x55dc5a){if(v(_0x55dc5a))return this;{const _0xc63a54=y(_0x55dc5a),_0x33de4a=this['children']['get'](_0xc63a54);return _0x33de4a!==null?_0x33de4a['subtree'](b(_0x55dc5a)):new S(null);}}['set'](_0xf93328,_0x315593){if(v(_0xf93328))return new S(_0x315593,this['children']);{const _0x37050c=y(_0xf93328),_0xf471fc=(this['children']['get'](_0x37050c)||new S(null))['set'](b(_0xf93328),_0x315593),_0x12bec9=this['children']['insert'](_0x37050c,_0xf471fc);return new S(this['value'],_0x12bec9);}}['remove'](_0x2a0be3){if(v(_0x2a0be3))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3e784a=y(_0x2a0be3),_0x427f03=this['children']['get'](_0x3e784a);if(_0x427f03){const _0x2ef4a7=_0x427f03['remove'](b(_0x2a0be3));let _0x5ab6b7;return _0x2ef4a7['isEmpty']()?_0x5ab6b7=this['children']['remove'](_0x3e784a):_0x5ab6b7=this['children']['insert'](_0x3e784a,_0x2ef4a7),this['value']===null&&_0x5ab6b7['isEmpty']()?new S(null):new S(this['value'],_0x5ab6b7);}else return this;}}['get'](_0x51f043){if(v(_0x51f043))return this['value'];{const _0x5db80a=y(_0x51f043),_0x2a563f=this['children']['get'](_0x5db80a);return _0x2a563f?_0x2a563f['get'](b(_0x51f043)):null;}}['setTree'](_0x584cf4,_0x69c24){if(v(_0x584cf4))return _0x69c24;{const _0x11af59=y(_0x584cf4),_0x42c572=(this['children']['get'](_0x11af59)||new S(null))['setTree'](b(_0x584cf4),_0x69c24);let _0x13b55a;return _0x42c572['isEmpty']()?_0x13b55a=this['children']['remove'](_0x11af59):_0x13b55a=this['children']['insert'](_0x11af59,_0x42c572),new S(this['value'],_0x13b55a);}}['fold'](_0x53db7c){return this['fold_'](w(),_0x53db7c);}['fold_'](_0x35ed8b,_0x5e7119){const _0x28d75f={};return this['children']['inorderTraversal']((_0x2bc6dc,_0x549505)=>{_0x28d75f[_0x2bc6dc]=_0x549505['fold_'](A(_0x35ed8b,_0x2bc6dc),_0x5e7119);}),_0x5e7119(_0x35ed8b,this['value'],_0x28d75f);}['findOnPath'](_0x5b5947,_0x41d70c){return this['findOnPath_'](_0x5b5947,w(),_0x41d70c);}['findOnPath_'](_0x17931b,_0x42e42e,_0x1ad45c){const _0xdc1bc1=this['value']?_0x1ad45c(_0x42e42e,this['value']):!0x1;if(_0xdc1bc1)return _0xdc1bc1;if(v(_0x17931b))return null;{const _0x171650=y(_0x17931b),_0x5cbd3b=this['children']['get'](_0x171650);return _0x5cbd3b?_0x5cbd3b['findOnPath_'](b(_0x17931b),A(_0x42e42e,_0x171650),_0x1ad45c):null;}}['foreachOnPath'](_0x159805,_0x349c00){return this['foreachOnPath_'](_0x159805,w(),_0x349c00);}['foreachOnPath_'](_0x2c0881,_0x490b26,_0x10da41){if(v(_0x2c0881))return this;{this['value']&&_0x10da41(_0x490b26,this['value']);const _0x5422c9=y(_0x2c0881),_0x4e075b=this['children']['get'](_0x5422c9);return _0x4e075b?_0x4e075b['foreachOnPath_'](b(_0x2c0881),A(_0x490b26,_0x5422c9),_0x10da41):new S(null);}}['foreach'](_0x417e6f){this['foreach_'](w(),_0x417e6f);}['foreach_'](_0x5b23aa,_0x482e16){this['children']['inorderTraversal']((_0x6f8af5,_0x268615)=>{_0x268615['foreach_'](A(_0x5b23aa,_0x6f8af5),_0x482e16);}),this['value']&&_0x482e16(_0x5b23aa,this['value']);}['foreachChild'](_0x432536){this['children']['inorderTraversal']((_0x3fb312,_0x4977ce)=>{_0x4977ce['value']&&_0x432536(_0x3fb312,_0x4977ce['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x21afeb){this['writeTree_']=_0x21afeb;}static['empty'](){return new j(new S(null));}}function Ct(_0x4000f2,_0x410bf2,_0x73b4a2){if(v(_0x410bf2))return new j(new S(_0x73b4a2));{const _0x3d9f66=_0x4000f2['writeTree_']['findRootMostValueAndPath'](_0x410bf2);if(_0x3d9f66!=null){const _0x2658c0=_0x3d9f66['path'];let _0x451d70=_0x3d9f66['value'];const _0x42fe09=F(_0x2658c0,_0x410bf2);return _0x451d70=_0x451d70['updateChild'](_0x42fe09,_0x73b4a2),new j(_0x4000f2['writeTree_']['set'](_0x2658c0,_0x451d70));}else{const _0x402238=new S(_0x73b4a2),_0x17dd90=_0x4000f2['writeTree_']['setTree'](_0x410bf2,_0x402238);return new j(_0x17dd90);}}}function Ii(_0x4c0097,_0x5be980,_0x52f793){let _0x1d1668=_0x4c0097;return x(_0x52f793,(_0x50d56a,_0x2a88ea)=>{_0x1d1668=Ct(_0x1d1668,A(_0x5be980,_0x50d56a),_0x2a88ea);}),_0x1d1668;}function sr(_0x158dfd,_0xec9df6){if(v(_0xec9df6))return j['empty']();{const _0x2b3f24=_0x158dfd['writeTree_']['setTree'](_0xec9df6,new S(null));return new j(_0x2b3f24);}}function wi(_0x1056e9,_0x1833a8){return $e(_0x1056e9,_0x1833a8)!=null;}function $e(_0xe2a534,_0x33b23f){const _0x5cd43a=_0xe2a534['writeTree_']['findRootMostValueAndPath'](_0x33b23f);return _0x5cd43a!=null?_0xe2a534['writeTree_']['get'](_0x5cd43a['path'])['getChild'](F(_0x5cd43a['path'],_0x33b23f)):null;}function rr(_0x3b59a9){const _0x2cd4c1=[],_0x59cb12=_0x3b59a9['writeTree_']['value'];return _0x59cb12!=null?_0x59cb12['isLeafNode']()||_0x59cb12['forEachChild'](R,(_0x26e398,_0x5c667f)=>{_0x2cd4c1['push'](new E(_0x26e398,_0x5c667f));}):_0x3b59a9['writeTree_']['children']['inorderTraversal']((_0x2b2578,_0x4f4891)=>{_0x4f4891['value']!=null&&_0x2cd4c1['push'](new E(_0x2b2578,_0x4f4891['value']));}),_0x2cd4c1;}function ve(_0x37230c,_0x1a90a9){if(v(_0x1a90a9))return _0x37230c;{const _0x517da3=$e(_0x37230c,_0x1a90a9);return _0x517da3!=null?new j(new S(_0x517da3)):new j(_0x37230c['writeTree_']['subtree'](_0x1a90a9));}}function Ci(_0x26e5e0){return _0x26e5e0['writeTree_']['isEmpty']();}function it(_0x277700,_0x4924e9){return xo(w(),_0x277700['writeTree_'],_0x4924e9);}function xo(_0xda6145,_0x32f0b0,_0xbbee14){if(_0x32f0b0['value']!=null)return _0xbbee14['updateChild'](_0xda6145,_0x32f0b0['value']);{let _0x2eb61=null;return _0x32f0b0['children']['inorderTraversal']((_0x2f1df6,_0x1dcc63)=>{_0x2f1df6==='.priority'?(f(_0x1dcc63['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2eb61=_0x1dcc63['value']):_0xbbee14=xo(A(_0xda6145,_0x2f1df6),_0x1dcc63,_0xbbee14);}),!_0xbbee14['getChild'](_0xda6145)['isEmpty']()&&_0x2eb61!==null&&(_0xbbee14=_0xbbee14['updateChild'](A(_0xda6145,'.priority'),_0x2eb61)),_0xbbee14;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5bc586,_0xf6ecd5){return Bo(_0xf6ecd5,_0x5bc586);}function ou(_0x117e92,_0x5c70fd,_0x3f23ed,_0x15e7b6,_0x250e2f){f(_0x15e7b6>_0x117e92['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x250e2f===void 0x0&&(_0x250e2f=!0x0),_0x117e92['allWrites']['push']({'path':_0x5c70fd,'snap':_0x3f23ed,'writeId':_0x15e7b6,'visible':_0x250e2f}),_0x250e2f&&(_0x117e92['visibleWrites']=Ct(_0x117e92['visibleWrites'],_0x5c70fd,_0x3f23ed)),_0x117e92['lastWriteId']=_0x15e7b6;}function au(_0x3d450f,_0x54b0db,_0x22a759,_0x422720){f(_0x422720>_0x3d450f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3d450f['allWrites']['push']({'path':_0x54b0db,'children':_0x22a759,'writeId':_0x422720,'visible':!0x0}),_0x3d450f['visibleWrites']=Ii(_0x3d450f['visibleWrites'],_0x54b0db,_0x22a759),_0x3d450f['lastWriteId']=_0x422720;}function cu(_0x24a5df,_0x30927a){for(let _0x191c98=0x0;_0x191c98<_0x24a5df['allWrites']['length'];_0x191c98++){const _0x2ea2b7=_0x24a5df['allWrites'][_0x191c98];if(_0x2ea2b7['writeId']===_0x30927a)return _0x2ea2b7;}return null;}function lu(_0x37960b,_0x5cc692){const _0x4ac5c7=_0x37960b['allWrites']['findIndex'](_0x2ca7a6=>_0x2ca7a6['writeId']===_0x5cc692);f(_0x4ac5c7>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x39a930=_0x37960b['allWrites'][_0x4ac5c7];_0x37960b['allWrites']['splice'](_0x4ac5c7,0x1);let _0x124964=_0x39a930['visible'],_0x4337e0=!0x1,_0x44dde2=_0x37960b['allWrites']['length']-0x1;for(;_0x124964&&_0x44dde2>=0x0;){const _0x509af7=_0x37960b['allWrites'][_0x44dde2];_0x509af7['visible']&&(_0x44dde2>=_0x4ac5c7&&hu(_0x509af7,_0x39a930['path'])?_0x124964=!0x1:$(_0x39a930['path'],_0x509af7['path'])&&(_0x4337e0=!0x0)),_0x44dde2--;}if(_0x124964){if(_0x4337e0)return uu(_0x37960b),!0x0;if(_0x39a930['snap'])_0x37960b['visibleWrites']=sr(_0x37960b['visibleWrites'],_0x39a930['path']);else{const _0x1349b2=_0x39a930['children'];x(_0x1349b2,_0x3f4887=>{_0x37960b['visibleWrites']=sr(_0x37960b['visibleWrites'],A(_0x39a930['path'],_0x3f4887));});}return!0x0;}else return!0x1;}function hu(_0x56b85a,_0x37f664){if(_0x56b85a['snap'])return $(_0x56b85a['path'],_0x37f664);for(const _0x532a40 in _0x56b85a['children'])if(_0x56b85a['children']['hasOwnProperty'](_0x532a40)&&$(A(_0x56b85a['path'],_0x532a40),_0x37f664))return!0x0;return!0x1;}function uu(_0x45fa16){_0x45fa16['visibleWrites']=Fo(_0x45fa16['allWrites'],du,w()),_0x45fa16['allWrites']['length']>0x0?_0x45fa16['lastWriteId']=_0x45fa16['allWrites'][_0x45fa16['allWrites']['length']-0x1]['writeId']:_0x45fa16['lastWriteId']=-0x1;}function du(_0x186232){return _0x186232['visible'];}function Fo(_0x20b73a,_0x48c25f,_0x5ad4b9){let _0x4ac2b3=j['empty']();for(let _0x565bb1=0x0;_0x565bb1<_0x20b73a['length'];++_0x565bb1){const _0x1d85ce=_0x20b73a[_0x565bb1];if(_0x48c25f(_0x1d85ce)){const _0xeb59c6=_0x1d85ce['path'];let _0x5ed355;if(_0x1d85ce['snap'])$(_0x5ad4b9,_0xeb59c6)?(_0x5ed355=F(_0x5ad4b9,_0xeb59c6),_0x4ac2b3=Ct(_0x4ac2b3,_0x5ed355,_0x1d85ce['snap'])):$(_0xeb59c6,_0x5ad4b9)&&(_0x5ed355=F(_0xeb59c6,_0x5ad4b9),_0x4ac2b3=Ct(_0x4ac2b3,w(),_0x1d85ce['snap']['getChild'](_0x5ed355)));else{if(_0x1d85ce['children']){if($(_0x5ad4b9,_0xeb59c6))_0x5ed355=F(_0x5ad4b9,_0xeb59c6),_0x4ac2b3=Ii(_0x4ac2b3,_0x5ed355,_0x1d85ce['children']);else{if($(_0xeb59c6,_0x5ad4b9)){if(_0x5ed355=F(_0xeb59c6,_0x5ad4b9),v(_0x5ed355))_0x4ac2b3=Ii(_0x4ac2b3,w(),_0x1d85ce['children']);else{const _0x2e371f=Oe(_0x1d85ce['children'],y(_0x5ed355));if(_0x2e371f){const _0x1a9f96=_0x2e371f['getChild'](b(_0x5ed355));_0x4ac2b3=Ct(_0x4ac2b3,w(),_0x1a9f96);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4ac2b3;}function Uo(_0x4ba045,_0x169ba4,_0x530a66,_0x51feb6,_0x101434){if(!_0x51feb6&&!_0x101434){const _0x287aa4=$e(_0x4ba045['visibleWrites'],_0x169ba4);if(_0x287aa4!=null)return _0x287aa4;{const _0x1dac06=ve(_0x4ba045['visibleWrites'],_0x169ba4);if(Ci(_0x1dac06))return _0x530a66;if(_0x530a66==null&&!wi(_0x1dac06,w()))return null;{const _0x53e019=_0x530a66||g['EMPTY_NODE'];return it(_0x1dac06,_0x53e019);}}}else{const _0x3565c5=ve(_0x4ba045['visibleWrites'],_0x169ba4);if(!_0x101434&&Ci(_0x3565c5))return _0x530a66;if(!_0x101434&&_0x530a66==null&&!wi(_0x3565c5,w()))return null;{const _0x5d7a59=function(_0xfc1837){return(_0xfc1837['visible']||_0x101434)&&(!_0x51feb6||!~_0x51feb6['indexOf'](_0xfc1837['writeId']))&&($(_0xfc1837['path'],_0x169ba4)||$(_0x169ba4,_0xfc1837['path']));},_0x37ccc4=Fo(_0x4ba045['allWrites'],_0x5d7a59,_0x169ba4),_0x2af26a=_0x530a66||g['EMPTY_NODE'];return it(_0x37ccc4,_0x2af26a);}}}function fu(_0x311f67,_0xcecbea,_0x2af17d){let _0x247c0c=g['EMPTY_NODE'];const _0x2a321d=$e(_0x311f67['visibleWrites'],_0xcecbea);if(_0x2a321d)return _0x2a321d['isLeafNode']()||_0x2a321d['forEachChild'](R,(_0x5acf59,_0x4c45db)=>{_0x247c0c=_0x247c0c['updateImmediateChild'](_0x5acf59,_0x4c45db);}),_0x247c0c;if(_0x2af17d){const _0x4a9b36=ve(_0x311f67['visibleWrites'],_0xcecbea);return _0x2af17d['forEachChild'](R,(_0x3d8a90,_0x21403a)=>{const _0x2da255=it(ve(_0x4a9b36,new C(_0x3d8a90)),_0x21403a);_0x247c0c=_0x247c0c['updateImmediateChild'](_0x3d8a90,_0x2da255);}),rr(_0x4a9b36)['forEach'](_0x222b39=>{_0x247c0c=_0x247c0c['updateImmediateChild'](_0x222b39['name'],_0x222b39['node']);}),_0x247c0c;}else{const _0x311de5=ve(_0x311f67['visibleWrites'],_0xcecbea);return rr(_0x311de5)['forEach'](_0x5499b2=>{_0x247c0c=_0x247c0c['updateImmediateChild'](_0x5499b2['name'],_0x5499b2['node']);}),_0x247c0c;}}function pu(_0x450779,_0x1978f3,_0x19bbc9,_0x435341,_0x51d2c2){f(_0x435341||_0x51d2c2,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2249ba=A(_0x1978f3,_0x19bbc9);if(wi(_0x450779['visibleWrites'],_0x2249ba))return null;{const _0x5571a7=ve(_0x450779['visibleWrites'],_0x2249ba);return Ci(_0x5571a7)?_0x51d2c2['getChild'](_0x19bbc9):it(_0x5571a7,_0x51d2c2['getChild'](_0x19bbc9));}}function _u(_0x5b9a1b,_0x5a1bff,_0x1f6b0c,_0x402a67){const _0xa5570f=A(_0x5a1bff,_0x1f6b0c),_0x4ec23c=$e(_0x5b9a1b['visibleWrites'],_0xa5570f);if(_0x4ec23c!=null)return _0x4ec23c;if(_0x402a67['isCompleteForChild'](_0x1f6b0c)){const _0x46e60d=ve(_0x5b9a1b['visibleWrites'],_0xa5570f);return it(_0x46e60d,_0x402a67['getNode']()['getImmediateChild'](_0x1f6b0c));}else return null;}function gu(_0x5e079f,_0x5272ce){return $e(_0x5e079f['visibleWrites'],_0x5272ce);}function mu(_0x394572,_0x2b00c1,_0x267c1f,_0x5a148f,_0x2a0ede,_0x5852b1,_0x55057c){let _0x4cd3e5;const _0x15eb79=ve(_0x394572['visibleWrites'],_0x2b00c1),_0x3bce82=$e(_0x15eb79,w());if(_0x3bce82!=null)_0x4cd3e5=_0x3bce82;else{if(_0x267c1f!=null)_0x4cd3e5=it(_0x15eb79,_0x267c1f);else return[];}if(_0x4cd3e5=_0x4cd3e5['withIndex'](_0x55057c),!_0x4cd3e5['isEmpty']()&&!_0x4cd3e5['isLeafNode']()){const _0x5255c2=[],_0x584e75=_0x55057c['getCompare'](),_0x5c4e9c=_0x5852b1?_0x4cd3e5['getReverseIteratorFrom'](_0x5a148f,_0x55057c):_0x4cd3e5['getIteratorFrom'](_0x5a148f,_0x55057c);let _0x3a0d48=_0x5c4e9c['getNext']();for(;_0x3a0d48&&_0x5255c2['length']<_0x2a0ede;)_0x584e75(_0x3a0d48,_0x5a148f)!==0x0&&_0x5255c2['push'](_0x3a0d48),_0x3a0d48=_0x5c4e9c['getNext']();return _0x5255c2;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xb12a80,_0x4db842,_0x1fe475,_0x3b9948){return Uo(_0xb12a80['writeTree'],_0xb12a80['treePath'],_0x4db842,_0x1fe475,_0x3b9948);}function es(_0x5e17f5,_0x18dd1f){return fu(_0x5e17f5['writeTree'],_0x5e17f5['treePath'],_0x18dd1f);}function or(_0x2cf90d,_0xcb4923,_0x28d264,_0x168434){return pu(_0x2cf90d['writeTree'],_0x2cf90d['treePath'],_0xcb4923,_0x28d264,_0x168434);}function yn(_0x436cc9,_0x2cf656){return gu(_0x436cc9['writeTree'],A(_0x436cc9['treePath'],_0x2cf656));}function vu(_0xb30b3c,_0xdaab79,_0x34d3a2,_0x112741,_0xfc6ae7,_0x5c59db){return mu(_0xb30b3c['writeTree'],_0xb30b3c['treePath'],_0xdaab79,_0x34d3a2,_0x112741,_0xfc6ae7,_0x5c59db);}function ts(_0xabd1c6,_0x56d6b6,_0x47965e){return _u(_0xabd1c6['writeTree'],_0xabd1c6['treePath'],_0x56d6b6,_0x47965e);}function Wo(_0x52e3e8,_0xaee199){return Bo(A(_0x52e3e8['treePath'],_0xaee199),_0x52e3e8['writeTree']);}function Bo(_0x319139,_0x49ad6a){return{'treePath':_0x319139,'writeTree':_0x49ad6a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3c880b){const _0x1754fb=_0x3c880b['type'],_0x30019b=_0x3c880b['childName'];f(_0x1754fb==='child_added'||_0x1754fb==='child_changed'||_0x1754fb==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x30019b!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x47bb92=this['changeMap']['get'](_0x30019b);if(_0x47bb92){const _0x55c32e=_0x47bb92['type'];if(_0x1754fb==='child_added'&&_0x55c32e==='child_removed')this['changeMap']['set'](_0x30019b,Pt(_0x30019b,_0x3c880b['snapshotNode'],_0x47bb92['snapshotNode']));else{if(_0x1754fb==='child_removed'&&_0x55c32e==='child_added')this['changeMap']['delete'](_0x30019b);else{if(_0x1754fb==='child_removed'&&_0x55c32e==='child_changed')this['changeMap']['set'](_0x30019b,Nt(_0x30019b,_0x47bb92['oldSnap']));else{if(_0x1754fb==='child_changed'&&_0x55c32e==='child_added')this['changeMap']['set'](_0x30019b,tt(_0x30019b,_0x3c880b['snapshotNode']));else{if(_0x1754fb==='child_changed'&&_0x55c32e==='child_changed')this['changeMap']['set'](_0x30019b,Pt(_0x30019b,_0x3c880b['snapshotNode'],_0x47bb92['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3c880b+'\x20occurred\x20after\x20'+_0x47bb92);}}}}}else this['changeMap']['set'](_0x30019b,_0x3c880b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x37eb94){return null;}['getChildAfterChild'](_0x5d66bf,_0x918116,_0x409fe8){return null;}}const Vo=new Iu();class ns{constructor(_0x1c3804,_0x5d6d91,_0x3993fa=null){this['writes_']=_0x1c3804,this['viewCache_']=_0x5d6d91,this['optCompleteServerCache_']=_0x3993fa;}['getCompleteChild'](_0x5560cf){const _0x451b2f=this['viewCache_']['eventCache'];if(_0x451b2f['isCompleteForChild'](_0x5560cf))return _0x451b2f['getNode']()['getImmediateChild'](_0x5560cf);{const _0x3ca662=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5560cf,_0x3ca662);}}['getChildAfterChild'](_0x4f9b01,_0x4dcabb,_0xed3381){const _0x5ed426=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x1520d8=vu(this['writes_'],_0x5ed426,_0x4dcabb,0x1,_0xed3381,_0x4f9b01);return _0x1520d8['length']===0x0?null:_0x1520d8[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x293340){return{'filter':_0x293340};}function Cu(_0x4edb07,_0x5c9350){f(_0x5c9350['eventCache']['getNode']()['isIndexed'](_0x4edb07['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5c9350['serverCache']['getNode']()['isIndexed'](_0x4edb07['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x660dbd,_0x29eb4c,_0x515b8e,_0x5ade35,_0x490297){const _0x5213d9=new Eu();let _0x4e07a7,_0x5de3b8;if(_0x515b8e['type']===q['OVERWRITE']){const _0xeb9182=_0x515b8e;_0xeb9182['source']['fromUser']?_0x4e07a7=Ti(_0x660dbd,_0x29eb4c,_0xeb9182['path'],_0xeb9182['snap'],_0x5ade35,_0x490297,_0x5213d9):(f(_0xeb9182['source']['fromServer'],'Unknown\x20source.'),_0x5de3b8=_0xeb9182['source']['tagged']||_0x29eb4c['serverCache']['isFiltered']()&&!v(_0xeb9182['path']),_0x4e07a7=vn(_0x660dbd,_0x29eb4c,_0xeb9182['path'],_0xeb9182['snap'],_0x5ade35,_0x490297,_0x5de3b8,_0x5213d9));}else{if(_0x515b8e['type']===q['MERGE']){const _0x55ed9b=_0x515b8e;_0x55ed9b['source']['fromUser']?_0x4e07a7=bu(_0x660dbd,_0x29eb4c,_0x55ed9b['path'],_0x55ed9b['children'],_0x5ade35,_0x490297,_0x5213d9):(f(_0x55ed9b['source']['fromServer'],'Unknown\x20source.'),_0x5de3b8=_0x55ed9b['source']['tagged']||_0x29eb4c['serverCache']['isFiltered'](),_0x4e07a7=Si(_0x660dbd,_0x29eb4c,_0x55ed9b['path'],_0x55ed9b['children'],_0x5ade35,_0x490297,_0x5de3b8,_0x5213d9));}else{if(_0x515b8e['type']===q['ACK_USER_WRITE']){const _0x571154=_0x515b8e;_0x571154['revert']?_0x4e07a7=ku(_0x660dbd,_0x29eb4c,_0x571154['path'],_0x5ade35,_0x490297,_0x5213d9):_0x4e07a7=Ru(_0x660dbd,_0x29eb4c,_0x571154['path'],_0x571154['affectedTree'],_0x5ade35,_0x490297,_0x5213d9);}else{if(_0x515b8e['type']===q['LISTEN_COMPLETE'])_0x4e07a7=Au(_0x660dbd,_0x29eb4c,_0x515b8e['path'],_0x5ade35,_0x5213d9);else throw ot('Unknown\x20operation\x20type:\x20'+_0x515b8e['type']);}}}const _0x2baea4=_0x5213d9['getChanges']();return Su(_0x29eb4c,_0x4e07a7,_0x2baea4),{'viewCache':_0x4e07a7,'changes':_0x2baea4};}function Su(_0x1db247,_0x91936b,_0x4f2e10){const _0x34483f=_0x91936b['eventCache'];if(_0x34483f['isFullyInitialized']()){const _0x461f41=_0x34483f['getNode']()['isLeafNode']()||_0x34483f['getNode']()['isEmpty'](),_0x93e0c2=gn(_0x1db247);(_0x4f2e10['length']>0x0||!_0x1db247['eventCache']['isFullyInitialized']()||_0x461f41&&!_0x34483f['getNode']()['equals'](_0x93e0c2)||!_0x34483f['getNode']()['getPriority']()['equals'](_0x93e0c2['getPriority']()))&&_0x4f2e10['push'](Oo(gn(_0x91936b)));}}function Ho(_0x19309c,_0x37e591,_0x15c144,_0x15c254,_0x2b1211,_0x4e20f4){const _0x12e795=_0x37e591['eventCache'];if(yn(_0x15c254,_0x15c144)!=null)return _0x37e591;{let _0x36e105,_0x431aca;if(v(_0x15c144)){if(f(_0x37e591['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x37e591['serverCache']['isFiltered']()){const _0x2056cb=Ue(_0x37e591),_0x5cf3fe=_0x2056cb instanceof g?_0x2056cb:g['EMPTY_NODE'],_0x44be17=es(_0x15c254,_0x5cf3fe);_0x36e105=_0x19309c['filter']['updateFullNode'](_0x37e591['eventCache']['getNode'](),_0x44be17,_0x4e20f4);}else{const _0x4a6869=mn(_0x15c254,Ue(_0x37e591));_0x36e105=_0x19309c['filter']['updateFullNode'](_0x37e591['eventCache']['getNode'](),_0x4a6869,_0x4e20f4);}}else{const _0x4afade=y(_0x15c144);if(_0x4afade==='.priority'){f(we(_0x15c144)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x52f39a=_0x12e795['getNode']();_0x431aca=_0x37e591['serverCache']['getNode']();const _0x31fd73=or(_0x15c254,_0x15c144,_0x52f39a,_0x431aca);_0x31fd73!=null?_0x36e105=_0x19309c['filter']['updatePriority'](_0x52f39a,_0x31fd73):_0x36e105=_0x12e795['getNode']();}else{const _0x27c48c=b(_0x15c144);let _0x5d391e;if(_0x12e795['isCompleteForChild'](_0x4afade)){_0x431aca=_0x37e591['serverCache']['getNode']();const _0x3f3b7a=or(_0x15c254,_0x15c144,_0x12e795['getNode'](),_0x431aca);_0x3f3b7a!=null?_0x5d391e=_0x12e795['getNode']()['getImmediateChild'](_0x4afade)['updateChild'](_0x27c48c,_0x3f3b7a):_0x5d391e=_0x12e795['getNode']()['getImmediateChild'](_0x4afade);}else _0x5d391e=ts(_0x15c254,_0x4afade,_0x37e591['serverCache']);_0x5d391e!=null?_0x36e105=_0x19309c['filter']['updateChild'](_0x12e795['getNode'](),_0x4afade,_0x5d391e,_0x27c48c,_0x2b1211,_0x4e20f4):_0x36e105=_0x12e795['getNode']();}}return wt(_0x37e591,_0x36e105,_0x12e795['isFullyInitialized']()||v(_0x15c144),_0x19309c['filter']['filtersNodes']());}}function vn(_0x33c4a2,_0x2e9677,_0x482f44,_0x99e988,_0x2b86c4,_0x473bfb,_0x835729,_0x3cf521){const _0x503732=_0x2e9677['serverCache'];let _0x5c6926;const _0x855df8=_0x835729?_0x33c4a2['filter']:_0x33c4a2['filter']['getIndexedFilter']();if(v(_0x482f44))_0x5c6926=_0x855df8['updateFullNode'](_0x503732['getNode'](),_0x99e988,null);else{if(_0x855df8['filtersNodes']()&&!_0x503732['isFiltered']()){const _0x5133c6=_0x503732['getNode']()['updateChild'](_0x482f44,_0x99e988);_0x5c6926=_0x855df8['updateFullNode'](_0x503732['getNode'](),_0x5133c6,null);}else{const _0x408d7b=y(_0x482f44);if(!_0x503732['isCompleteForPath'](_0x482f44)&&we(_0x482f44)>0x1)return _0x2e9677;const _0x323fb4=b(_0x482f44),_0x4e9072=_0x503732['getNode']()['getImmediateChild'](_0x408d7b)['updateChild'](_0x323fb4,_0x99e988);_0x408d7b==='.priority'?_0x5c6926=_0x855df8['updatePriority'](_0x503732['getNode'](),_0x4e9072):_0x5c6926=_0x855df8['updateChild'](_0x503732['getNode'](),_0x408d7b,_0x4e9072,_0x323fb4,Vo,null);}}const _0x1b44a6=Lo(_0x2e9677,_0x5c6926,_0x503732['isFullyInitialized']()||v(_0x482f44),_0x855df8['filtersNodes']()),_0x2198ed=new ns(_0x2b86c4,_0x1b44a6,_0x473bfb);return Ho(_0x33c4a2,_0x1b44a6,_0x482f44,_0x2b86c4,_0x2198ed,_0x3cf521);}function Ti(_0x37da4e,_0x51a7fd,_0x114073,_0x358299,_0x53659f,_0x464fc6,_0x23a34d){const _0x4f0d28=_0x51a7fd['eventCache'];let _0x4124cb,_0x31d5b0;const _0x431879=new ns(_0x53659f,_0x51a7fd,_0x464fc6);if(v(_0x114073))_0x31d5b0=_0x37da4e['filter']['updateFullNode'](_0x51a7fd['eventCache']['getNode'](),_0x358299,_0x23a34d),_0x4124cb=wt(_0x51a7fd,_0x31d5b0,!0x0,_0x37da4e['filter']['filtersNodes']());else{const _0x325191=y(_0x114073);if(_0x325191==='.priority')_0x31d5b0=_0x37da4e['filter']['updatePriority'](_0x51a7fd['eventCache']['getNode'](),_0x358299),_0x4124cb=wt(_0x51a7fd,_0x31d5b0,_0x4f0d28['isFullyInitialized'](),_0x4f0d28['isFiltered']());else{const _0x420c0c=b(_0x114073),_0x2adedf=_0x4f0d28['getNode']()['getImmediateChild'](_0x325191);let _0x2d239a;if(v(_0x420c0c))_0x2d239a=_0x358299;else{const _0x3dc510=_0x431879['getCompleteChild'](_0x325191);_0x3dc510!=null?Gi(_0x420c0c)==='.priority'&&_0x3dc510['getChild'](To(_0x420c0c))['isEmpty']()?_0x2d239a=_0x3dc510:_0x2d239a=_0x3dc510['updateChild'](_0x420c0c,_0x358299):_0x2d239a=g['EMPTY_NODE'];}if(_0x2adedf['equals'](_0x2d239a))_0x4124cb=_0x51a7fd;else{const _0x513ae9=_0x37da4e['filter']['updateChild'](_0x4f0d28['getNode'](),_0x325191,_0x2d239a,_0x420c0c,_0x431879,_0x23a34d);_0x4124cb=wt(_0x51a7fd,_0x513ae9,_0x4f0d28['isFullyInitialized'](),_0x37da4e['filter']['filtersNodes']());}}}return _0x4124cb;}function ar(_0x407340,_0x587055){return _0x407340['eventCache']['isCompleteForChild'](_0x587055);}function bu(_0x3a550d,_0x3ee742,_0x1a02c1,_0x52e2ec,_0xaa4ae9,_0x502b9c,_0x8b9414){let _0x59c5ef=_0x3ee742;return _0x52e2ec['foreach']((_0x265e71,_0x340702)=>{const _0x5a219e=A(_0x1a02c1,_0x265e71);ar(_0x3ee742,y(_0x5a219e))&&(_0x59c5ef=Ti(_0x3a550d,_0x59c5ef,_0x5a219e,_0x340702,_0xaa4ae9,_0x502b9c,_0x8b9414));}),_0x52e2ec['foreach']((_0x501c18,_0x59db08)=>{const _0x59d933=A(_0x1a02c1,_0x501c18);ar(_0x3ee742,y(_0x59d933))||(_0x59c5ef=Ti(_0x3a550d,_0x59c5ef,_0x59d933,_0x59db08,_0xaa4ae9,_0x502b9c,_0x8b9414));}),_0x59c5ef;}function cr(_0x1a5775,_0x46b4f2,_0x50fa3e){return _0x50fa3e['foreach']((_0x41aeb2,_0x3abcab)=>{_0x46b4f2=_0x46b4f2['updateChild'](_0x41aeb2,_0x3abcab);}),_0x46b4f2;}function Si(_0x5e5376,_0x39dce8,_0x172b50,_0x285b53,_0x20a1d0,_0x5c5b2d,_0x429b7d,_0x499848){if(_0x39dce8['serverCache']['getNode']()['isEmpty']()&&!_0x39dce8['serverCache']['isFullyInitialized']())return _0x39dce8;let _0x4fafcc=_0x39dce8,_0x3ae054;v(_0x172b50)?_0x3ae054=_0x285b53:_0x3ae054=new S(null)['setTree'](_0x172b50,_0x285b53);const _0x3847b6=_0x39dce8['serverCache']['getNode']();return _0x3ae054['children']['inorderTraversal']((_0x104cdc,_0x50ed49)=>{if(_0x3847b6['hasChild'](_0x104cdc)){const _0x6aebe9=_0x39dce8['serverCache']['getNode']()['getImmediateChild'](_0x104cdc),_0x4e07df=cr(_0x5e5376,_0x6aebe9,_0x50ed49);_0x4fafcc=vn(_0x5e5376,_0x4fafcc,new C(_0x104cdc),_0x4e07df,_0x20a1d0,_0x5c5b2d,_0x429b7d,_0x499848);}}),_0x3ae054['children']['inorderTraversal']((_0x252f50,_0x1f9240)=>{const _0x1d160a=!_0x39dce8['serverCache']['isCompleteForChild'](_0x252f50)&&_0x1f9240['value']===null;if(!_0x3847b6['hasChild'](_0x252f50)&&!_0x1d160a){const _0x36fb6e=_0x39dce8['serverCache']['getNode']()['getImmediateChild'](_0x252f50),_0x33529e=cr(_0x5e5376,_0x36fb6e,_0x1f9240);_0x4fafcc=vn(_0x5e5376,_0x4fafcc,new C(_0x252f50),_0x33529e,_0x20a1d0,_0x5c5b2d,_0x429b7d,_0x499848);}}),_0x4fafcc;}function Ru(_0x3a2c20,_0x305e24,_0x2d14f7,_0x2b209f,_0x5d8a56,_0x5b5401,_0x4d173f){if(yn(_0x5d8a56,_0x2d14f7)!=null)return _0x305e24;const _0x1bf718=_0x305e24['serverCache']['isFiltered'](),_0x2616bf=_0x305e24['serverCache'];if(_0x2b209f['value']!=null){if(v(_0x2d14f7)&&_0x2616bf['isFullyInitialized']()||_0x2616bf['isCompleteForPath'](_0x2d14f7))return vn(_0x3a2c20,_0x305e24,_0x2d14f7,_0x2616bf['getNode']()['getChild'](_0x2d14f7),_0x5d8a56,_0x5b5401,_0x1bf718,_0x4d173f);if(v(_0x2d14f7)){let _0x280f1d=new S(null);return _0x2616bf['getNode']()['forEachChild'](ye,(_0xde9a65,_0x4a7c50)=>{_0x280f1d=_0x280f1d['set'](new C(_0xde9a65),_0x4a7c50);}),Si(_0x3a2c20,_0x305e24,_0x2d14f7,_0x280f1d,_0x5d8a56,_0x5b5401,_0x1bf718,_0x4d173f);}else return _0x305e24;}else{let _0x317161=new S(null);return _0x2b209f['foreach']((_0x4eba70,_0x586950)=>{const _0xab1db3=A(_0x2d14f7,_0x4eba70);_0x2616bf['isCompleteForPath'](_0xab1db3)&&(_0x317161=_0x317161['set'](_0x4eba70,_0x2616bf['getNode']()['getChild'](_0xab1db3)));}),Si(_0x3a2c20,_0x305e24,_0x2d14f7,_0x317161,_0x5d8a56,_0x5b5401,_0x1bf718,_0x4d173f);}}function Au(_0x224f7e,_0x773794,_0x37efc8,_0x1747c9,_0x3199a1){const _0x2b9311=_0x773794['serverCache'],_0x49394a=Lo(_0x773794,_0x2b9311['getNode'](),_0x2b9311['isFullyInitialized']()||v(_0x37efc8),_0x2b9311['isFiltered']());return Ho(_0x224f7e,_0x49394a,_0x37efc8,_0x1747c9,Vo,_0x3199a1);}function ku(_0x49207a,_0x1f4b29,_0x8141,_0x53a4c0,_0x494aa0,_0x576a19){let _0x5f07fe;if(yn(_0x53a4c0,_0x8141)!=null)return _0x1f4b29;{const _0xf19c35=new ns(_0x53a4c0,_0x1f4b29,_0x494aa0),_0x2dfbcd=_0x1f4b29['eventCache']['getNode']();let _0x14b487;if(v(_0x8141)||y(_0x8141)==='.priority'){let _0x560753;if(_0x1f4b29['serverCache']['isFullyInitialized']())_0x560753=mn(_0x53a4c0,Ue(_0x1f4b29));else{const _0x20f650=_0x1f4b29['serverCache']['getNode']();f(_0x20f650 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x560753=es(_0x53a4c0,_0x20f650);}_0x560753=_0x560753,_0x14b487=_0x49207a['filter']['updateFullNode'](_0x2dfbcd,_0x560753,_0x576a19);}else{const _0x4ec013=y(_0x8141);let _0x30448a=ts(_0x53a4c0,_0x4ec013,_0x1f4b29['serverCache']);_0x30448a==null&&_0x1f4b29['serverCache']['isCompleteForChild'](_0x4ec013)&&(_0x30448a=_0x2dfbcd['getImmediateChild'](_0x4ec013)),_0x30448a!=null?_0x14b487=_0x49207a['filter']['updateChild'](_0x2dfbcd,_0x4ec013,_0x30448a,b(_0x8141),_0xf19c35,_0x576a19):_0x1f4b29['eventCache']['getNode']()['hasChild'](_0x4ec013)?_0x14b487=_0x49207a['filter']['updateChild'](_0x2dfbcd,_0x4ec013,g['EMPTY_NODE'],b(_0x8141),_0xf19c35,_0x576a19):_0x14b487=_0x2dfbcd,_0x14b487['isEmpty']()&&_0x1f4b29['serverCache']['isFullyInitialized']()&&(_0x5f07fe=mn(_0x53a4c0,Ue(_0x1f4b29)),_0x5f07fe['isLeafNode']()&&(_0x14b487=_0x49207a['filter']['updateFullNode'](_0x14b487,_0x5f07fe,_0x576a19)));}return _0x5f07fe=_0x1f4b29['serverCache']['isFullyInitialized']()||yn(_0x53a4c0,w())!=null,wt(_0x1f4b29,_0x14b487,_0x5f07fe,_0x49207a['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x4d780e,_0x19b7df){this['query_']=_0x4d780e,this['eventRegistrations_']=[];const _0x131567=this['query_']['_queryParams'],_0xc95743=new Yi(_0x131567['getIndex']()),_0x24a749=qh(_0x131567);this['processor_']=wu(_0x24a749);const _0x2be87e=_0x19b7df['serverCache'],_0x5c9eba=_0x19b7df['eventCache'],_0x51f0e5=_0xc95743['updateFullNode'](g['EMPTY_NODE'],_0x2be87e['getNode'](),null),_0x235c62=_0x24a749['updateFullNode'](g['EMPTY_NODE'],_0x5c9eba['getNode'](),null),_0xf529c1=new Ce(_0x51f0e5,_0x2be87e['isFullyInitialized'](),_0xc95743['filtersNodes']()),_0x21d174=new Ce(_0x235c62,_0x5c9eba['isFullyInitialized'](),_0x24a749['filtersNodes']());this['viewCache_']=Dn(_0x21d174,_0xf529c1),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x453c08){return _0x453c08['viewCache_']['serverCache']['getNode']();}function Ou(_0x203553){return gn(_0x203553['viewCache_']);}function Du(_0x82cc2a,_0x14e427){const _0x3315a3=Ue(_0x82cc2a['viewCache_']);return _0x3315a3&&(_0x82cc2a['query']['_queryParams']['loadsAllData']()||!v(_0x14e427)&&!_0x3315a3['getImmediateChild'](y(_0x14e427))['isEmpty']())?_0x3315a3['getChild'](_0x14e427):null;}function lr(_0x2d0db9){return _0x2d0db9['eventRegistrations_']['length']===0x0;}function Mu(_0x2585ef,_0x37cd01){_0x2585ef['eventRegistrations_']['push'](_0x37cd01);}function hr(_0x4949ad,_0x52bd33,_0x220725){const _0x4c61d8=[];if(_0x220725){f(_0x52bd33==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3af715=_0x4949ad['query']['_path'];_0x4949ad['eventRegistrations_']['forEach'](_0x5e7373=>{const _0x26dd1d=_0x5e7373['createCancelEvent'](_0x220725,_0x3af715);_0x26dd1d&&_0x4c61d8['push'](_0x26dd1d);});}if(_0x52bd33){let _0x67bcfd=[];for(let _0x263635=0x0;_0x263635<_0x4949ad['eventRegistrations_']['length'];++_0x263635){const _0x34cbfd=_0x4949ad['eventRegistrations_'][_0x263635];if(!_0x34cbfd['matches'](_0x52bd33))_0x67bcfd['push'](_0x34cbfd);else{if(_0x52bd33['hasAnyCallback']()){_0x67bcfd=_0x67bcfd['concat'](_0x4949ad['eventRegistrations_']['slice'](_0x263635+0x1));break;}}}_0x4949ad['eventRegistrations_']=_0x67bcfd;}else _0x4949ad['eventRegistrations_']=[];return _0x4c61d8;}function ur(_0x231595,_0x5049e3,_0x52b10e,_0x3f345d){_0x5049e3['type']===q['MERGE']&&_0x5049e3['source']['queryId']!==null&&(f(Ue(_0x231595['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x231595['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x483675=_0x231595['viewCache_'],_0x5ab171=Tu(_0x231595['processor_'],_0x483675,_0x5049e3,_0x52b10e,_0x3f345d);return Cu(_0x231595['processor_'],_0x5ab171['viewCache']),f(_0x5ab171['viewCache']['serverCache']['isFullyInitialized']()||!_0x483675['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x231595['viewCache_']=_0x5ab171['viewCache'],$o(_0x231595,_0x5ab171['changes'],_0x5ab171['viewCache']['eventCache']['getNode'](),null);}function Lu(_0xdb6af2,_0x5b4d31){const _0x286de7=_0xdb6af2['viewCache_']['eventCache'],_0x4c5d07=[];return _0x286de7['getNode']()['isLeafNode']()||_0x286de7['getNode']()['forEachChild'](R,(_0x227ceb,_0x21334c)=>{_0x4c5d07['push'](tt(_0x227ceb,_0x21334c));}),_0x286de7['isFullyInitialized']()&&_0x4c5d07['push'](Oo(_0x286de7['getNode']())),$o(_0xdb6af2,_0x4c5d07,_0x286de7['getNode'](),_0x5b4d31);}function $o(_0x5ca996,_0x18dc3c,_0x456892,_0x4d5069){const _0x47eedf=_0x4d5069?[_0x4d5069]:_0x5ca996['eventRegistrations_'];return nu(_0x5ca996['eventGenerator_'],_0x18dc3c,_0x456892,_0x47eedf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x50ca97){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x50ca97;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x266277){return _0x266277['views']['size']===0x0;}function is(_0x299091,_0x5ed523,_0x39a220,_0x1af03b){const _0x1fe35e=_0x5ed523['source']['queryId'];if(_0x1fe35e!==null){const _0x474cd6=_0x299091['views']['get'](_0x1fe35e);return f(_0x474cd6!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x474cd6,_0x5ed523,_0x39a220,_0x1af03b);}else{let _0x1988d2=[];for(const _0x5eaa71 of _0x299091['views']['values']())_0x1988d2=_0x1988d2['concat'](ur(_0x5eaa71,_0x5ed523,_0x39a220,_0x1af03b));return _0x1988d2;}}function qo(_0x182ed8,_0x712e92,_0x23561c,_0x4d704e,_0xdcb213){const _0x63f2a2=_0x712e92['_queryIdentifier'],_0x53e6cf=_0x182ed8['views']['get'](_0x63f2a2);if(!_0x53e6cf){let _0x3b14f0=mn(_0x23561c,_0xdcb213?_0x4d704e:null),_0x225c79=!0x1;_0x3b14f0?_0x225c79=!0x0:_0x4d704e instanceof g?(_0x3b14f0=es(_0x23561c,_0x4d704e),_0x225c79=!0x1):(_0x3b14f0=g['EMPTY_NODE'],_0x225c79=!0x1);const _0x1a3782=Dn(new Ce(_0x3b14f0,_0x225c79,!0x1),new Ce(_0x4d704e,_0xdcb213,!0x1));return new Nu(_0x712e92,_0x1a3782);}return _0x53e6cf;}function Wu(_0x39e152,_0x2db6ee,_0x2bd974,_0x19c15f,_0x1254cb,_0x4b9c90){const _0x4cd679=qo(_0x39e152,_0x2db6ee,_0x19c15f,_0x1254cb,_0x4b9c90);return _0x39e152['views']['has'](_0x2db6ee['_queryIdentifier'])||_0x39e152['views']['set'](_0x2db6ee['_queryIdentifier'],_0x4cd679),Mu(_0x4cd679,_0x2bd974),Lu(_0x4cd679,_0x2bd974);}function Bu(_0x37ac96,_0x86a85d,_0x4cd75f,_0x2fcbe6){const _0x5afdd0=_0x86a85d['_queryIdentifier'],_0x3b0cda=[];let _0xce0a1b=[];const _0x3ba40f=Te(_0x37ac96);if(_0x5afdd0==='default'){for(const [_0x3373ec,_0x296da6]of _0x37ac96['views']['entries']())_0xce0a1b=_0xce0a1b['concat'](hr(_0x296da6,_0x4cd75f,_0x2fcbe6)),lr(_0x296da6)&&(_0x37ac96['views']['delete'](_0x3373ec),_0x296da6['query']['_queryParams']['loadsAllData']()||_0x3b0cda['push'](_0x296da6['query']));}else{const _0x1fe066=_0x37ac96['views']['get'](_0x5afdd0);_0x1fe066&&(_0xce0a1b=_0xce0a1b['concat'](hr(_0x1fe066,_0x4cd75f,_0x2fcbe6)),lr(_0x1fe066)&&(_0x37ac96['views']['delete'](_0x5afdd0),_0x1fe066['query']['_queryParams']['loadsAllData']()||_0x3b0cda['push'](_0x1fe066['query'])));}return _0x3ba40f&&!Te(_0x37ac96)&&_0x3b0cda['push'](new(Fu())(_0x86a85d['_repo'],_0x86a85d['_path'])),{'removed':_0x3b0cda,'events':_0xce0a1b};}function zo(_0xebad5d){const _0x3cb8ca=[];for(const _0x51bf26 of _0xebad5d['views']['values']())_0x51bf26['query']['_queryParams']['loadsAllData']()||_0x3cb8ca['push'](_0x51bf26);return _0x3cb8ca;}function Ee(_0xfdc173,_0x20ec07){let _0x1e87de=null;for(const _0x49eb40 of _0xfdc173['views']['values']())_0x1e87de=_0x1e87de||Du(_0x49eb40,_0x20ec07);return _0x1e87de;}function jo(_0x4ae253,_0x4205c6){if(_0x4205c6['_queryParams']['loadsAllData']())return Ln(_0x4ae253);{const _0x5d3480=_0x4205c6['_queryIdentifier'];return _0x4ae253['views']['get'](_0x5d3480);}}function Ko(_0x19f351,_0x35517a){return jo(_0x19f351,_0x35517a)!=null;}function Te(_0x25ff0f){return Ln(_0x25ff0f)!=null;}function Ln(_0x5f0fac){for(const _0x17fd2a of _0x5f0fac['views']['values']())if(_0x17fd2a['query']['_queryParams']['loadsAllData']())return _0x17fd2a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xe5e839){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xe5e839;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x328d30){this['listenProvider_']=_0x328d30,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x58c19a,_0x193a41,_0x43b4b6,_0x2b070e,_0x337621){return ou(_0x58c19a['pendingWriteTree_'],_0x193a41,_0x43b4b6,_0x2b070e,_0x337621),_0x337621?ht(_0x58c19a,new Fe(Ji(),_0x193a41,_0x43b4b6)):[];}function Gu(_0x35f1a7,_0x403c55,_0x3a27b3,_0xb41539){au(_0x35f1a7['pendingWriteTree_'],_0x403c55,_0x3a27b3,_0xb41539);const _0x2ca4b3=S['fromObject'](_0x3a27b3);return ht(_0x35f1a7,new nt(Ji(),_0x403c55,_0x2ca4b3));}function pe(_0x9c44ae,_0x35cb12,_0x30ef66=!0x1){const _0x40ab45=cu(_0x9c44ae['pendingWriteTree_'],_0x35cb12);if(lu(_0x9c44ae['pendingWriteTree_'],_0x35cb12)){let _0x5523f4=new S(null);return _0x40ab45['snap']!=null?_0x5523f4=_0x5523f4['set'](w(),!0x0):x(_0x40ab45['children'],_0x165ecd=>{_0x5523f4=_0x5523f4['set'](new C(_0x165ecd),!0x0);}),ht(_0x9c44ae,new _n(_0x40ab45['path'],_0x5523f4,_0x30ef66));}else return[];}function $t(_0x352032,_0x5251c7,_0x4b24be){return ht(_0x352032,new Fe(Xi(),_0x5251c7,_0x4b24be));}function qu(_0x4f1908,_0x5ed727,_0x4952a0){const _0x3e2a11=S['fromObject'](_0x4952a0);return ht(_0x4f1908,new nt(Xi(),_0x5ed727,_0x3e2a11));}function zu(_0x2507fa,_0x21c95f){return ht(_0x2507fa,new Dt(Xi(),_0x21c95f));}function ju(_0x2c54bd,_0x3fdf27,_0x4c7a9f){const _0x43418c=rs(_0x2c54bd,_0x4c7a9f);if(_0x43418c){const _0x558d95=os(_0x43418c),_0x55b7ab=_0x558d95['path'],_0x343815=_0x558d95['queryId'],_0x14e825=F(_0x55b7ab,_0x3fdf27),_0xf20445=new Dt(Zi(_0x343815),_0x14e825);return as(_0x2c54bd,_0x55b7ab,_0xf20445);}else return[];}function wn(_0x5d064a,_0x2eace9,_0x2ff9f0,_0x3f8193,_0x314005=!0x1){const _0x500559=_0x2eace9['_path'],_0x278cf3=_0x5d064a['syncPointTree_']['get'](_0x500559);let _0x52dbcb=[];if(_0x278cf3&&(_0x2eace9['_queryIdentifier']==='default'||Ko(_0x278cf3,_0x2eace9))){const _0x283583=Bu(_0x278cf3,_0x2eace9,_0x2ff9f0,_0x3f8193);Uu(_0x278cf3)&&(_0x5d064a['syncPointTree_']=_0x5d064a['syncPointTree_']['remove'](_0x500559));const _0x260824=_0x283583['removed'];if(_0x52dbcb=_0x283583['events'],!_0x314005){const _0x3fcc14=_0x260824['findIndex'](_0x136693=>_0x136693['_queryParams']['loadsAllData']())!==-0x1,_0x2eb49a=_0x5d064a['syncPointTree_']['findOnPath'](_0x500559,(_0x1dee56,_0x202fad)=>Te(_0x202fad));if(_0x3fcc14&&!_0x2eb49a){const _0x19a767=_0x5d064a['syncPointTree_']['subtree'](_0x500559);if(!_0x19a767['isEmpty']()){const _0x32aa6f=Qu(_0x19a767);for(let _0xe3f8ab=0x0;_0xe3f8ab<_0x32aa6f['length'];++_0xe3f8ab){const _0x286268=_0x32aa6f[_0xe3f8ab],_0x13ba0e=_0x286268['query'],_0xb148f=Xo(_0x5d064a,_0x286268);_0x5d064a['listenProvider_']['startListening'](Tt(_0x13ba0e),Mt(_0x5d064a,_0x13ba0e),_0xb148f['hashFn'],_0xb148f['onComplete']);}}}!_0x2eb49a&&_0x260824['length']>0x0&&!_0x3f8193&&(_0x3fcc14?_0x5d064a['listenProvider_']['stopListening'](Tt(_0x2eace9),null):_0x260824['forEach'](_0x3a0d8a=>{const _0x1ee64f=_0x5d064a['queryToTagMap']['get'](Fn(_0x3a0d8a));_0x5d064a['listenProvider_']['stopListening'](Tt(_0x3a0d8a),_0x1ee64f);}));}Ju(_0x5d064a,_0x260824);}return _0x52dbcb;}function Yo(_0x9e0a00,_0x507849,_0x442bcb,_0xb7dec0){const _0xd54c6a=rs(_0x9e0a00,_0xb7dec0);if(_0xd54c6a!=null){const _0x5f2bd1=os(_0xd54c6a),_0x39fce9=_0x5f2bd1['path'],_0x5918ee=_0x5f2bd1['queryId'],_0x31afb4=F(_0x39fce9,_0x507849),_0x25dd98=new Fe(Zi(_0x5918ee),_0x31afb4,_0x442bcb);return as(_0x9e0a00,_0x39fce9,_0x25dd98);}else return[];}function Ku(_0x39651c,_0x2a5c4d,_0x51ab5c,_0x337007){const _0x1617b2=rs(_0x39651c,_0x337007);if(_0x1617b2){const _0x3983dd=os(_0x1617b2),_0x24c2bb=_0x3983dd['path'],_0x5a57dc=_0x3983dd['queryId'],_0x3b7a8a=F(_0x24c2bb,_0x2a5c4d),_0x54d485=S['fromObject'](_0x51ab5c),_0x3a2ef6=new nt(Zi(_0x5a57dc),_0x3b7a8a,_0x54d485);return as(_0x39651c,_0x24c2bb,_0x3a2ef6);}else return[];}function bi(_0x301cc8,_0x3b7aca,_0x5f05e3,_0x67c88=!0x1){const _0x225dab=_0x3b7aca['_path'];let _0x32135e=null,_0x29677b=!0x1;_0x301cc8['syncPointTree_']['foreachOnPath'](_0x225dab,(_0x55b72d,_0x2c256b)=>{const _0xe2d346=F(_0x55b72d,_0x225dab);_0x32135e=_0x32135e||Ee(_0x2c256b,_0xe2d346),_0x29677b=_0x29677b||Te(_0x2c256b);});let _0x50954e=_0x301cc8['syncPointTree_']['get'](_0x225dab);_0x50954e?(_0x29677b=_0x29677b||Te(_0x50954e),_0x32135e=_0x32135e||Ee(_0x50954e,w())):(_0x50954e=new Go(),_0x301cc8['syncPointTree_']=_0x301cc8['syncPointTree_']['set'](_0x225dab,_0x50954e));let _0x2c2e28;_0x32135e!=null?_0x2c2e28=!0x0:(_0x2c2e28=!0x1,_0x32135e=g['EMPTY_NODE'],_0x301cc8['syncPointTree_']['subtree'](_0x225dab)['foreachChild']((_0x38b93c,_0x43abeb)=>{const _0x534682=Ee(_0x43abeb,w());_0x534682&&(_0x32135e=_0x32135e['updateImmediateChild'](_0x38b93c,_0x534682));}));const _0x5a2596=Ko(_0x50954e,_0x3b7aca);if(!_0x5a2596&&!_0x3b7aca['_queryParams']['loadsAllData']()){const _0x2c202f=Fn(_0x3b7aca);f(!_0x301cc8['queryToTagMap']['has'](_0x2c202f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2d79a4=Xu();_0x301cc8['queryToTagMap']['set'](_0x2c202f,_0x2d79a4),_0x301cc8['tagToQueryMap']['set'](_0x2d79a4,_0x2c202f);}const _0x2c8862=Mn(_0x301cc8['pendingWriteTree_'],_0x225dab);let _0x13d113=Wu(_0x50954e,_0x3b7aca,_0x5f05e3,_0x2c8862,_0x32135e,_0x2c2e28);if(!_0x5a2596&&!_0x29677b&&!_0x67c88){const _0x4e7872=jo(_0x50954e,_0x3b7aca);_0x13d113=_0x13d113['concat'](Zu(_0x301cc8,_0x3b7aca,_0x4e7872));}return _0x13d113;}function xn(_0x45e4d8,_0x3c7b8e,_0x4f34e8){const _0x19b095=_0x45e4d8['pendingWriteTree_'],_0x47faff=_0x45e4d8['syncPointTree_']['findOnPath'](_0x3c7b8e,(_0x4f7cb8,_0x15530b)=>{const _0x40c5bb=F(_0x4f7cb8,_0x3c7b8e),_0x4d49d7=Ee(_0x15530b,_0x40c5bb);if(_0x4d49d7)return _0x4d49d7;});return Uo(_0x19b095,_0x3c7b8e,_0x47faff,_0x4f34e8,!0x0);}function Yu(_0x427996,_0x457e42){const _0xe81834=_0x457e42['_path'];let _0x4c435f=null;_0x427996['syncPointTree_']['foreachOnPath'](_0xe81834,(_0x3a8582,_0x2a5a17)=>{const _0x4fcb96=F(_0x3a8582,_0xe81834);_0x4c435f=_0x4c435f||Ee(_0x2a5a17,_0x4fcb96);});let _0x2fde68=_0x427996['syncPointTree_']['get'](_0xe81834);_0x2fde68?_0x4c435f=_0x4c435f||Ee(_0x2fde68,w()):(_0x2fde68=new Go(),_0x427996['syncPointTree_']=_0x427996['syncPointTree_']['set'](_0xe81834,_0x2fde68));const _0x1d03ff=_0x4c435f!=null,_0x257edb=_0x1d03ff?new Ce(_0x4c435f,!0x0,!0x1):null,_0x17c41d=Mn(_0x427996['pendingWriteTree_'],_0x457e42['_path']),_0x3b1950=qo(_0x2fde68,_0x457e42,_0x17c41d,_0x1d03ff?_0x257edb['getNode']():g['EMPTY_NODE'],_0x1d03ff);return Ou(_0x3b1950);}function ht(_0x3e6d3d,_0x201d44){return Qo(_0x201d44,_0x3e6d3d['syncPointTree_'],null,Mn(_0x3e6d3d['pendingWriteTree_'],w()));}function Qo(_0x3fba77,_0x14a3d5,_0x31654c,_0x404d07){if(v(_0x3fba77['path']))return Jo(_0x3fba77,_0x14a3d5,_0x31654c,_0x404d07);{const _0xf19ae0=_0x14a3d5['get'](w());_0x31654c==null&&_0xf19ae0!=null&&(_0x31654c=Ee(_0xf19ae0,w()));let _0x4f5bab=[];const _0x145bef=y(_0x3fba77['path']),_0x5b5a91=_0x3fba77['operationForChild'](_0x145bef),_0x42f917=_0x14a3d5['children']['get'](_0x145bef);if(_0x42f917&&_0x5b5a91){const _0x3e2e3c=_0x31654c?_0x31654c['getImmediateChild'](_0x145bef):null,_0x6586cc=Wo(_0x404d07,_0x145bef);_0x4f5bab=_0x4f5bab['concat'](Qo(_0x5b5a91,_0x42f917,_0x3e2e3c,_0x6586cc));}return _0xf19ae0&&(_0x4f5bab=_0x4f5bab['concat'](is(_0xf19ae0,_0x3fba77,_0x404d07,_0x31654c))),_0x4f5bab;}}function Jo(_0x49fc7c,_0x44069f,_0x477014,_0x478f5b){const _0x54caab=_0x44069f['get'](w());_0x477014==null&&_0x54caab!=null&&(_0x477014=Ee(_0x54caab,w()));let _0x509415=[];return _0x44069f['children']['inorderTraversal']((_0x50e969,_0x2ca98f)=>{const _0x4a3ca5=_0x477014?_0x477014['getImmediateChild'](_0x50e969):null,_0x9be1ab=Wo(_0x478f5b,_0x50e969),_0x40edec=_0x49fc7c['operationForChild'](_0x50e969);_0x40edec&&(_0x509415=_0x509415['concat'](Jo(_0x40edec,_0x2ca98f,_0x4a3ca5,_0x9be1ab)));}),_0x54caab&&(_0x509415=_0x509415['concat'](is(_0x54caab,_0x49fc7c,_0x478f5b,_0x477014))),_0x509415;}function Xo(_0x35e475,_0x2da022){const _0x146b70=_0x2da022['query'],_0x17c32b=Mt(_0x35e475,_0x146b70);return{'hashFn':()=>(Pu(_0x2da022)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x34d4bf=>{if(_0x34d4bf==='ok')return _0x17c32b?ju(_0x35e475,_0x146b70['_path'],_0x17c32b):zu(_0x35e475,_0x146b70['_path']);{const _0x1517b0=ql(_0x34d4bf,_0x146b70);return wn(_0x35e475,_0x146b70,null,_0x1517b0);}}};}function Mt(_0x2490bc,_0x284f95){const _0x604470=Fn(_0x284f95);return _0x2490bc['queryToTagMap']['get'](_0x604470);}function Fn(_0x5f15e2){return _0x5f15e2['_path']['toString']()+'$'+_0x5f15e2['_queryIdentifier'];}function rs(_0x6759fe,_0x3e6bea){return _0x6759fe['tagToQueryMap']['get'](_0x3e6bea);}function os(_0x35bd9a){const _0x2fbace=_0x35bd9a['indexOf']('$');return f(_0x2fbace!==-0x1&&_0x2fbace<_0x35bd9a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x35bd9a['substr'](_0x2fbace+0x1),'path':new C(_0x35bd9a['substr'](0x0,_0x2fbace))};}function as(_0x4eb805,_0x20a8d9,_0x4cc32f){const _0x4580b5=_0x4eb805['syncPointTree_']['get'](_0x20a8d9);f(_0x4580b5,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x11b67d=Mn(_0x4eb805['pendingWriteTree_'],_0x20a8d9);return is(_0x4580b5,_0x4cc32f,_0x11b67d,null);}function Qu(_0x404802){return _0x404802['fold']((_0xb47476,_0x23816d,_0x16b82e)=>{if(_0x23816d&&Te(_0x23816d))return[Ln(_0x23816d)];{let _0x1ad99d=[];return _0x23816d&&(_0x1ad99d=zo(_0x23816d)),x(_0x16b82e,(_0x122bce,_0xd00c6f)=>{_0x1ad99d=_0x1ad99d['concat'](_0xd00c6f);}),_0x1ad99d;}});}function Tt(_0x1bf802){return _0x1bf802['_queryParams']['loadsAllData']()&&!_0x1bf802['_queryParams']['isDefault']()?new(Hu())(_0x1bf802['_repo'],_0x1bf802['_path']):_0x1bf802;}function Ju(_0x468f8a,_0x5d1989){for(let _0x3ac996=0x0;_0x3ac996<_0x5d1989['length'];++_0x3ac996){const _0x5c632a=_0x5d1989[_0x3ac996];if(!_0x5c632a['_queryParams']['loadsAllData']()){const _0x35e58e=Fn(_0x5c632a),_0x1243e9=_0x468f8a['queryToTagMap']['get'](_0x35e58e);_0x468f8a['queryToTagMap']['delete'](_0x35e58e),_0x468f8a['tagToQueryMap']['delete'](_0x1243e9);}}}function Xu(){return $u++;}function Zu(_0x4d622c,_0x40610c,_0x1bc94d){const _0x1f44d8=_0x40610c['_path'],_0x16dbf0=Mt(_0x4d622c,_0x40610c),_0x12333a=Xo(_0x4d622c,_0x1bc94d),_0x556182=_0x4d622c['listenProvider_']['startListening'](Tt(_0x40610c),_0x16dbf0,_0x12333a['hashFn'],_0x12333a['onComplete']),_0x21fc79=_0x4d622c['syncPointTree_']['subtree'](_0x1f44d8);if(_0x16dbf0)f(!Te(_0x21fc79['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x474902=_0x21fc79['fold']((_0x69097d,_0x344516,_0x3ef3a0)=>{if(!v(_0x69097d)&&_0x344516&&Te(_0x344516))return[Ln(_0x344516)['query']];{let _0x40ab09=[];return _0x344516&&(_0x40ab09=_0x40ab09['concat'](zo(_0x344516)['map'](_0x11375c=>_0x11375c['query']))),x(_0x3ef3a0,(_0x237d5a,_0x23a36c)=>{_0x40ab09=_0x40ab09['concat'](_0x23a36c);}),_0x40ab09;}});for(let _0x1a5d91=0x0;_0x1a5d91<_0x474902['length'];++_0x1a5d91){const _0x34a555=_0x474902[_0x1a5d91];_0x4d622c['listenProvider_']['stopListening'](Tt(_0x34a555),Mt(_0x4d622c,_0x34a555));}}return _0x556182;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x3568df){this['node_']=_0x3568df;}['getImmediateChild'](_0x2ef975){const _0x246059=this['node_']['getImmediateChild'](_0x2ef975);return new cs(_0x246059);}['node'](){return this['node_'];}}class ls{constructor(_0x17509c,_0x27dd21){this['syncTree_']=_0x17509c,this['path_']=_0x27dd21;}['getImmediateChild'](_0x5d00e5){const _0xdc1285=A(this['path_'],_0x5d00e5);return new ls(this['syncTree_'],_0xdc1285);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x1f314a){return _0x1f314a=_0x1f314a||{},_0x1f314a['timestamp']=_0x1f314a['timestamp']||new Date()['getTime'](),_0x1f314a;},fr=function(_0x4ba16f,_0x1ee0f8,_0x3028eb){if(!_0x4ba16f||typeof _0x4ba16f!='object')return _0x4ba16f;if(f('.sv'in _0x4ba16f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4ba16f['.sv']=='string')return td(_0x4ba16f['.sv'],_0x1ee0f8,_0x3028eb);if(typeof _0x4ba16f['.sv']=='object')return nd(_0x4ba16f['.sv'],_0x1ee0f8);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4ba16f,null,0x2));},td=function(_0x5e897a,_0x205338,_0x4c04df){switch(_0x5e897a){case'timestamp':return _0x4c04df['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x5e897a);}},nd=function(_0x254f8b,_0x5082f9,_0x44c5b9){_0x254f8b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x254f8b,null,0x2));const _0x390a91=_0x254f8b['increment'];typeof _0x390a91!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x390a91);const _0x10ae7a=_0x5082f9['node']();if(f(_0x10ae7a!==null&&typeof _0x10ae7a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x10ae7a['isLeafNode']())return _0x390a91;const _0x22536b=_0x10ae7a['getValue']();return typeof _0x22536b!='number'?_0x390a91:_0x22536b+_0x390a91;},Zo=function(_0x1f0b54,_0x5a3ba8,_0x231b91,_0x673504){return us(_0x5a3ba8,new ls(_0x231b91,_0x1f0b54),_0x673504);},hs=function(_0xf9ec1e,_0x21e149,_0x51c3fd){return us(_0xf9ec1e,new cs(_0x21e149),_0x51c3fd);};function us(_0x1f702e,_0x321d39,_0x238d47){const _0x46d8dc=_0x1f702e['getPriority']()['val'](),_0x57c0f7=fr(_0x46d8dc,_0x321d39['getImmediateChild']('.priority'),_0x238d47);let _0x37ef3d;if(_0x1f702e['isLeafNode']()){const _0xa056e2=_0x1f702e,_0x190f41=fr(_0xa056e2['getValue'](),_0x321d39,_0x238d47);return _0x190f41!==_0xa056e2['getValue']()||_0x57c0f7!==_0xa056e2['getPriority']()['val']()?new D(_0x190f41,N(_0x57c0f7)):_0x1f702e;}else{const _0x1b838d=_0x1f702e;return _0x37ef3d=_0x1b838d,_0x57c0f7!==_0x1b838d['getPriority']()['val']()&&(_0x37ef3d=_0x37ef3d['updatePriority'](new D(_0x57c0f7))),_0x1b838d['forEachChild'](R,(_0x4a9896,_0x2558e2)=>{const _0x333d26=us(_0x2558e2,_0x321d39['getImmediateChild'](_0x4a9896),_0x238d47);_0x333d26!==_0x2558e2&&(_0x37ef3d=_0x37ef3d['updateImmediateChild'](_0x4a9896,_0x333d26));}),_0x37ef3d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4ac109='',_0x4c3be3=null,_0x5da848={'children':{},'childCount':0x0}){this['name']=_0x4ac109,this['parent']=_0x4c3be3,this['node']=_0x5da848;}}function Un(_0x2564db,_0x317c68){let _0x7ac7f2=_0x317c68 instanceof C?_0x317c68:new C(_0x317c68),_0x3a9f4a=_0x2564db,_0x1beca2=y(_0x7ac7f2);for(;_0x1beca2!==null;){const _0x55fb61=Oe(_0x3a9f4a['node']['children'],_0x1beca2)||{'children':{},'childCount':0x0};_0x3a9f4a=new ds(_0x1beca2,_0x3a9f4a,_0x55fb61),_0x7ac7f2=b(_0x7ac7f2),_0x1beca2=y(_0x7ac7f2);}return _0x3a9f4a;}function Ge(_0x33058a){return _0x33058a['node']['value'];}function fs(_0x2bfc8f,_0x31b7bd){_0x2bfc8f['node']['value']=_0x31b7bd,Ri(_0x2bfc8f);}function ea(_0xa8e698){return _0xa8e698['node']['childCount']>0x0;}function id(_0x576e38){return Ge(_0x576e38)===void 0x0&&!ea(_0x576e38);}function Wn(_0x4c93e7,_0x55cb0e){x(_0x4c93e7['node']['children'],(_0x378462,_0x1891b4)=>{_0x55cb0e(new ds(_0x378462,_0x4c93e7,_0x1891b4));});}function ta(_0x460ea9,_0x3b2e96,_0x3c7856,_0x2cd006){_0x3c7856&&_0x3b2e96(_0x460ea9),Wn(_0x460ea9,_0x4b0b3f=>{ta(_0x4b0b3f,_0x3b2e96,!0x0);});}function sd(_0x12846e,_0xfffc79,_0x4a5c06){let _0x2ffcff=_0x12846e['parent'];for(;_0x2ffcff!==null;){if(_0xfffc79(_0x2ffcff))return!0x0;_0x2ffcff=_0x2ffcff['parent'];}return!0x1;}function Gt(_0x2dbce8){return new C(_0x2dbce8['parent']===null?_0x2dbce8['name']:Gt(_0x2dbce8['parent'])+'/'+_0x2dbce8['name']);}function Ri(_0xfa6a20){_0xfa6a20['parent']!==null&&rd(_0xfa6a20['parent'],_0xfa6a20['name'],_0xfa6a20);}function rd(_0x309064,_0x2e0f26,_0x424056){const _0x7cbfb3=id(_0x424056),_0x369aa9=Y(_0x309064['node']['children'],_0x2e0f26);_0x7cbfb3&&_0x369aa9?(delete _0x309064['node']['children'][_0x2e0f26],_0x309064['node']['childCount']--,Ri(_0x309064)):!_0x7cbfb3&&!_0x369aa9&&(_0x309064['node']['children'][_0x2e0f26]=_0x424056['node'],_0x309064['node']['childCount']++,Ri(_0x309064));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2c1fd7){return typeof _0x2c1fd7=='string'&&_0x2c1fd7['length']!==0x0&&!od['test'](_0x2c1fd7);},na=function(_0x239697){return typeof _0x239697=='string'&&_0x239697['length']!==0x0&&!ad['test'](_0x239697);},cd=function(_0xd61e4a){return _0xd61e4a&&(_0xd61e4a=_0xd61e4a['replace'](/^\/*\.info(\/|$)/,'/')),na(_0xd61e4a);},Cn=function(_0x3d6f86){return _0x3d6f86===null||typeof _0x3d6f86=='string'||typeof _0x3d6f86=='number'&&!Wi(_0x3d6f86)||_0x3d6f86&&typeof _0x3d6f86=='object'&&Y(_0x3d6f86,'.sv');},qt=function(_0x4714e0,_0xe6e175,_0x196fa5,_0x4c40cd){_0x4c40cd&&_0xe6e175===void 0x0||zt(Nn(_0x4714e0,'value'),_0xe6e175,_0x196fa5);},zt=function(_0x54352e,_0x4cd85f,_0x178c37){const _0x5cf645=_0x178c37 instanceof C?new Sh(_0x178c37,_0x54352e):_0x178c37;if(_0x4cd85f===void 0x0)throw new Error(_0x54352e+'contains\x20undefined\x20'+Ne(_0x5cf645));if(typeof _0x4cd85f=='function')throw new Error(_0x54352e+'contains\x20a\x20function\x20'+Ne(_0x5cf645)+'\x20with\x20contents\x20=\x20'+_0x4cd85f['toString']());if(Wi(_0x4cd85f))throw new Error(_0x54352e+'contains\x20'+_0x4cd85f['toString']()+'\x20'+Ne(_0x5cf645));if(typeof _0x4cd85f=='string'&&_0x4cd85f['length']>oi/0x3&&Pn(_0x4cd85f)>oi)throw new Error(_0x54352e+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x5cf645)+'\x20(\x27'+_0x4cd85f['substring'](0x0,0x32)+'...\x27)');if(_0x4cd85f&&typeof _0x4cd85f=='object'){let _0x27d6bf=!0x1,_0x5959f7=!0x1;if(x(_0x4cd85f,(_0x25ec41,_0x60205)=>{if(_0x25ec41==='.value')_0x27d6bf=!0x0;else{if(_0x25ec41!=='.priority'&&_0x25ec41!=='.sv'&&(_0x5959f7=!0x0,!ps(_0x25ec41)))throw new Error(_0x54352e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x25ec41+')\x20'+Ne(_0x5cf645)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x5cf645,_0x25ec41),zt(_0x54352e,_0x60205,_0x5cf645),Rh(_0x5cf645);}),_0x27d6bf&&_0x5959f7)throw new Error(_0x54352e+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x5cf645)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x22462c,_0x357e55){let _0x57e873,_0x4f21d9;for(_0x57e873=0x0;_0x57e873<_0x357e55['length'];_0x57e873++){_0x4f21d9=_0x357e55[_0x57e873];const _0x5baeb3=kt(_0x4f21d9);for(let _0x1862b6=0x0;_0x1862b6<_0x5baeb3['length'];_0x1862b6++)if(!(_0x5baeb3[_0x1862b6]==='.priority'&&_0x1862b6===_0x5baeb3['length']-0x1)){if(!ps(_0x5baeb3[_0x1862b6]))throw new Error(_0x22462c+'contains\x20an\x20invalid\x20key\x20('+_0x5baeb3[_0x1862b6]+')\x20in\x20path\x20'+_0x4f21d9['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x357e55['sort'](Th);let _0x31c5b1=null;for(_0x57e873=0x0;_0x57e873<_0x357e55['length'];_0x57e873++){if(_0x4f21d9=_0x357e55[_0x57e873],_0x31c5b1!==null&&$(_0x31c5b1,_0x4f21d9))throw new Error(_0x22462c+'contains\x20a\x20path\x20'+_0x31c5b1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4f21d9['toString']());_0x31c5b1=_0x4f21d9;}},hd=function(_0x49428e,_0xd122fa,_0x2715d9,_0x448708){const _0x559ff1=Nn(_0x49428e,'values');if(!(_0xd122fa&&typeof _0xd122fa=='object')||Array['isArray'](_0xd122fa))throw new Error(_0x559ff1+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x48a495=[];x(_0xd122fa,(_0x2a4d7c,_0x4467e1)=>{const _0x375ab4=new C(_0x2a4d7c);if(zt(_0x559ff1,_0x4467e1,A(_0x2715d9,_0x375ab4)),Gi(_0x375ab4)==='.priority'&&!Cn(_0x4467e1))throw new Error(_0x559ff1+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x375ab4['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x48a495['push'](_0x375ab4);}),ld(_0x559ff1,_0x48a495);},_s=function(_0x308f46,_0x3d0785,_0x497b4a,_0x138edb){if(!na(_0x497b4a))throw new Error(Nn(_0x308f46,_0x3d0785)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x497b4a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x31a86d,_0xf6411e,_0x319100,_0x38baaf){_0x319100&&(_0x319100=_0x319100['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x31a86d,_0xf6411e,_0x319100);},gs=function(_0x370b13,_0x110a80){if(y(_0x110a80)==='.info')throw new Error(_0x370b13+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x10eebe,_0x405a05){const _0x2f278d=_0x405a05['path']['toString']();if(typeof _0x405a05['repoInfo']['host']!='string'||_0x405a05['repoInfo']['host']['length']===0x0||!ps(_0x405a05['repoInfo']['namespace'])&&_0x405a05['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2f278d['length']!==0x0&&!cd(_0x2f278d))throw new Error(Nn(_0x10eebe,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x2bc075,_0x376a99){let _0x590ca4=null;for(let _0x2ab12c=0x0;_0x2ab12c<_0x376a99['length'];_0x2ab12c++){const _0x88486f=_0x376a99[_0x2ab12c],_0x375c30=_0x88486f['getPath']();_0x590ca4!==null&&!qi(_0x375c30,_0x590ca4['path'])&&(_0x2bc075['eventLists_']['push'](_0x590ca4),_0x590ca4=null),_0x590ca4===null&&(_0x590ca4={'events':[],'path':_0x375c30}),_0x590ca4['events']['push'](_0x88486f);}_0x590ca4&&_0x2bc075['eventLists_']['push'](_0x590ca4);}function ia(_0x1ff5b0,_0x1d423f,_0x229306){Bn(_0x1ff5b0,_0x229306),sa(_0x1ff5b0,_0x6cfa1=>qi(_0x6cfa1,_0x1d423f));}function V(_0x101ae9,_0x4c9dc5,_0x86bcec){Bn(_0x101ae9,_0x86bcec),sa(_0x101ae9,_0x1c52ec=>$(_0x1c52ec,_0x4c9dc5)||$(_0x4c9dc5,_0x1c52ec));}function sa(_0x25a34a,_0x405716){_0x25a34a['recursionDepth_']++;let _0x3dd628=!0x0;for(let _0x572a30=0x0;_0x572a30<_0x25a34a['eventLists_']['length'];_0x572a30++){const _0x45c941=_0x25a34a['eventLists_'][_0x572a30];if(_0x45c941){const _0xae0f89=_0x45c941['path'];_0x405716(_0xae0f89)?(pd(_0x25a34a['eventLists_'][_0x572a30]),_0x25a34a['eventLists_'][_0x572a30]=null):_0x3dd628=!0x1;}}_0x3dd628&&(_0x25a34a['eventLists_']=[]),_0x25a34a['recursionDepth_']--;}function pd(_0x2ee873){for(let _0x422915=0x0;_0x422915<_0x2ee873['events']['length'];_0x422915++){const _0x20ea0e=_0x2ee873['events'][_0x422915];if(_0x20ea0e!==null){_0x2ee873['events'][_0x422915]=null;const _0x2af177=_0x20ea0e['getEventRunner']();Et&&L('event:\x20'+_0x20ea0e['toString']()),lt(_0x2af177);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x134b5c,_0x100a9b,_0x551d72,_0x40f5fb){this['repoInfo_']=_0x134b5c,this['forceRestClient_']=_0x100a9b,this['authTokenProvider_']=_0x551d72,this['appCheckProvider_']=_0x40f5fb,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x572d04,_0x20124c,_0x48ef68){if(_0x572d04['stats_']=Hi(_0x572d04['repoInfo_']),_0x572d04['forceRestClient_']||Yl())_0x572d04['server_']=new fn(_0x572d04['repoInfo_'],(_0x33797b,_0xf3252f,_0x2fcb6e,_0x49d1cb)=>{pr(_0x572d04,_0x33797b,_0xf3252f,_0x2fcb6e,_0x49d1cb);},_0x572d04['authTokenProvider_'],_0x572d04['appCheckProvider_']),setTimeout(()=>_r(_0x572d04,!0x0),0x0);else{if(typeof _0x48ef68<'u'&&_0x48ef68!==null){if(typeof _0x48ef68!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x48ef68);}catch(_0x478d1c){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x478d1c);}}_0x572d04['persistentConnection_']=new ie(_0x572d04['repoInfo_'],_0x20124c,(_0x1880f8,_0x343f65,_0x108fe1,_0x25279e)=>{pr(_0x572d04,_0x1880f8,_0x343f65,_0x108fe1,_0x25279e);},_0x4d8531=>{_r(_0x572d04,_0x4d8531);},_0x44cf62=>{yd(_0x572d04,_0x44cf62);},_0x572d04['authTokenProvider_'],_0x572d04['appCheckProvider_'],_0x48ef68),_0x572d04['server_']=_0x572d04['persistentConnection_'];}_0x572d04['authTokenProvider_']['addTokenChangeListener'](_0x17b00f=>{_0x572d04['server_']['refreshAuthToken'](_0x17b00f);}),_0x572d04['appCheckProvider_']['addTokenChangeListener'](_0x1174b3=>{_0x572d04['server_']['refreshAppCheckToken'](_0x1174b3['token']);}),_0x572d04['statsReporter_']=eh(_0x572d04['repoInfo_'],()=>new eu(_0x572d04['stats_'],_0x572d04['server_'])),_0x572d04['infoData_']=new Yh(),_0x572d04['infoSyncTree_']=new dr({'startListening':(_0x188f73,_0x5e0a3b,_0x478634,_0x870fc3)=>{let _0x23ba71=[];const _0x145877=_0x572d04['infoData_']['getNode'](_0x188f73['_path']);return _0x145877['isEmpty']()||(_0x23ba71=$t(_0x572d04['infoSyncTree_'],_0x188f73['_path'],_0x145877),setTimeout(()=>{_0x870fc3('ok');},0x0)),_0x23ba71;},'stopListening':()=>{}}),ms(_0x572d04,'connected',!0x1),_0x572d04['serverSyncTree_']=new dr({'startListening':(_0x216654,_0xefff64,_0x39cd6b,_0x433d7e)=>(_0x572d04['server_']['listen'](_0x216654,_0x39cd6b,_0xefff64,(_0x41c841,_0x32d25c)=>{const _0x2ea98e=_0x433d7e(_0x41c841,_0x32d25c);V(_0x572d04['eventQueue_'],_0x216654['_path'],_0x2ea98e);}),[]),'stopListening':(_0x173311,_0x13183e)=>{_0x572d04['server_']['unlisten'](_0x173311,_0x13183e);}});}function oa(_0x3ebe84){const _0x4496f5=_0x3ebe84['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4496f5;}function jt(_0x4a422b){return ed({'timestamp':oa(_0x4a422b)});}function pr(_0x1d9780,_0x485fdd,_0x4fc7a4,_0x1e51d6,_0x5c2e67){_0x1d9780['dataUpdateCount']++;const _0x6e71f4=new C(_0x485fdd);_0x4fc7a4=_0x1d9780['interceptServerDataCallback_']?_0x1d9780['interceptServerDataCallback_'](_0x485fdd,_0x4fc7a4):_0x4fc7a4;let _0x345586=[];if(_0x5c2e67){if(_0x1e51d6){const _0x47df60=ln(_0x4fc7a4,_0x2f86d8=>N(_0x2f86d8));_0x345586=Ku(_0x1d9780['serverSyncTree_'],_0x6e71f4,_0x47df60,_0x5c2e67);}else{const _0x30ff66=N(_0x4fc7a4);_0x345586=Yo(_0x1d9780['serverSyncTree_'],_0x6e71f4,_0x30ff66,_0x5c2e67);}}else{if(_0x1e51d6){const _0x2dcb49=ln(_0x4fc7a4,_0xfae39d=>N(_0xfae39d));_0x345586=qu(_0x1d9780['serverSyncTree_'],_0x6e71f4,_0x2dcb49);}else{const _0x18d904=N(_0x4fc7a4);_0x345586=$t(_0x1d9780['serverSyncTree_'],_0x6e71f4,_0x18d904);}}let _0x383687=_0x6e71f4;_0x345586['length']>0x0&&(_0x383687=st(_0x1d9780,_0x6e71f4)),V(_0x1d9780['eventQueue_'],_0x383687,_0x345586);}function _r(_0x503e55,_0x147eda){ms(_0x503e55,'connected',_0x147eda),_0x147eda===!0x1&&wd(_0x503e55);}function yd(_0x202c33,_0x4feeea){x(_0x4feeea,(_0x2a5b23,_0x1b3dbe)=>{ms(_0x202c33,_0x2a5b23,_0x1b3dbe);});}function ms(_0x42dd83,_0x5341f3,_0x3f28e9){const _0x4e6150=new C('/.info/'+_0x5341f3),_0x3533bf=N(_0x3f28e9);_0x42dd83['infoData_']['updateSnapshot'](_0x4e6150,_0x3533bf);const _0x10900c=$t(_0x42dd83['infoSyncTree_'],_0x4e6150,_0x3533bf);V(_0x42dd83['eventQueue_'],_0x4e6150,_0x10900c);}function Vn(_0x336d56){return _0x336d56['nextWriteId_']++;}function vd(_0x2a715d,_0x25efa7,_0x31a6c1){const _0x45223a=Yu(_0x2a715d['serverSyncTree_'],_0x25efa7);return _0x45223a!=null?Promise['resolve'](_0x45223a):_0x2a715d['server_']['get'](_0x25efa7)['then'](_0x2bb9e7=>{const _0x434b5b=N(_0x2bb9e7)['withIndex'](_0x25efa7['_queryParams']['getIndex']());bi(_0x2a715d['serverSyncTree_'],_0x25efa7,_0x31a6c1,!0x0);let _0x7c4ac;if(_0x25efa7['_queryParams']['loadsAllData']())_0x7c4ac=$t(_0x2a715d['serverSyncTree_'],_0x25efa7['_path'],_0x434b5b);else{const _0x628444=Mt(_0x2a715d['serverSyncTree_'],_0x25efa7);_0x7c4ac=Yo(_0x2a715d['serverSyncTree_'],_0x25efa7['_path'],_0x434b5b,_0x628444);}return V(_0x2a715d['eventQueue_'],_0x25efa7['_path'],_0x7c4ac),wn(_0x2a715d['serverSyncTree_'],_0x25efa7,_0x31a6c1,null,!0x0),_0x434b5b;},_0x2ce66d=>(ut(_0x2a715d,'get\x20for\x20query\x20'+O(_0x25efa7)+'\x20failed:\x20'+_0x2ce66d),Promise['reject'](new Error(_0x2ce66d))));}function Ed(_0x5cd9a5,_0x4c778a,_0x3bc032,_0x507952,_0x22709c){ut(_0x5cd9a5,'set',{'path':_0x4c778a['toString'](),'value':_0x3bc032,'priority':_0x507952});const _0x3bdf41=jt(_0x5cd9a5),_0xcef9e8=N(_0x3bc032,_0x507952),_0x23dbb7=xn(_0x5cd9a5['serverSyncTree_'],_0x4c778a),_0x48642f=hs(_0xcef9e8,_0x23dbb7,_0x3bdf41),_0x5f2008=Vn(_0x5cd9a5),_0x1f7395=ss(_0x5cd9a5['serverSyncTree_'],_0x4c778a,_0x48642f,_0x5f2008,!0x0);Bn(_0x5cd9a5['eventQueue_'],_0x1f7395),_0x5cd9a5['server_']['put'](_0x4c778a['toString'](),_0xcef9e8['val'](!0x0),(_0x1b5979,_0x58e8c9)=>{const _0x19e499=_0x1b5979==='ok';_0x19e499||U('set\x20at\x20'+_0x4c778a+'\x20failed:\x20'+_0x1b5979);const _0x3ee22d=pe(_0x5cd9a5['serverSyncTree_'],_0x5f2008,!_0x19e499);V(_0x5cd9a5['eventQueue_'],_0x4c778a,_0x3ee22d),Ai(_0x5cd9a5,_0x22709c,_0x1b5979,_0x58e8c9);});const _0x2d4cce=vs(_0x5cd9a5,_0x4c778a);st(_0x5cd9a5,_0x2d4cce),V(_0x5cd9a5['eventQueue_'],_0x2d4cce,[]);}function Id(_0x18ddc,_0x125fb8,_0x5a84a9,_0x23082f){ut(_0x18ddc,'update',{'path':_0x125fb8['toString'](),'value':_0x5a84a9});let _0x4a25c5=!0x0;const _0x37d475=jt(_0x18ddc),_0x22539a={};if(x(_0x5a84a9,(_0x3efbba,_0x4e972e)=>{_0x4a25c5=!0x1,_0x22539a[_0x3efbba]=Zo(A(_0x125fb8,_0x3efbba),N(_0x4e972e),_0x18ddc['serverSyncTree_'],_0x37d475);}),_0x4a25c5)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x18ddc,_0x23082f,'ok',void 0x0);else{const _0xbbeb28=Vn(_0x18ddc),_0xf0e1ed=Gu(_0x18ddc['serverSyncTree_'],_0x125fb8,_0x22539a,_0xbbeb28);Bn(_0x18ddc['eventQueue_'],_0xf0e1ed),_0x18ddc['server_']['merge'](_0x125fb8['toString'](),_0x5a84a9,(_0x3a39bf,_0x6e3a6)=>{const _0xcffb91=_0x3a39bf==='ok';_0xcffb91||U('update\x20at\x20'+_0x125fb8+'\x20failed:\x20'+_0x3a39bf);const _0x5313fb=pe(_0x18ddc['serverSyncTree_'],_0xbbeb28,!_0xcffb91),_0x31b432=_0x5313fb['length']>0x0?st(_0x18ddc,_0x125fb8):_0x125fb8;V(_0x18ddc['eventQueue_'],_0x31b432,_0x5313fb),Ai(_0x18ddc,_0x23082f,_0x3a39bf,_0x6e3a6);}),x(_0x5a84a9,_0x26e1e2=>{const _0xb69cd3=vs(_0x18ddc,A(_0x125fb8,_0x26e1e2));st(_0x18ddc,_0xb69cd3);}),V(_0x18ddc['eventQueue_'],_0x125fb8,[]);}}function wd(_0x7dbd68){ut(_0x7dbd68,'onDisconnectEvents');const _0x1dba19=jt(_0x7dbd68),_0x13346e=pn();Ei(_0x7dbd68['onDisconnect_'],w(),(_0x1ba49f,_0x1aa720)=>{const _0x4f3ff9=Zo(_0x1ba49f,_0x1aa720,_0x7dbd68['serverSyncTree_'],_0x1dba19);Mo(_0x13346e,_0x1ba49f,_0x4f3ff9);});let _0x56343a=[];Ei(_0x13346e,w(),(_0x13cf95,_0x5e9232)=>{_0x56343a=_0x56343a['concat']($t(_0x7dbd68['serverSyncTree_'],_0x13cf95,_0x5e9232));const _0x285a2d=vs(_0x7dbd68,_0x13cf95);st(_0x7dbd68,_0x285a2d);}),_0x7dbd68['onDisconnect_']=pn(),V(_0x7dbd68['eventQueue_'],w(),_0x56343a);}function Cd(_0x5d0e4c,_0x275ded,_0x1d32a5){let _0x74edd2;y(_0x275ded['_path'])==='.info'?_0x74edd2=bi(_0x5d0e4c['infoSyncTree_'],_0x275ded,_0x1d32a5):_0x74edd2=bi(_0x5d0e4c['serverSyncTree_'],_0x275ded,_0x1d32a5),ia(_0x5d0e4c['eventQueue_'],_0x275ded['_path'],_0x74edd2);}function Td(_0x50ce27,_0x2c8559,_0x55214e){let _0x5b82f5;y(_0x2c8559['_path'])==='.info'?_0x5b82f5=wn(_0x50ce27['infoSyncTree_'],_0x2c8559,_0x55214e):_0x5b82f5=wn(_0x50ce27['serverSyncTree_'],_0x2c8559,_0x55214e),ia(_0x50ce27['eventQueue_'],_0x2c8559['_path'],_0x5b82f5);}function aa(_0x591e87){_0x591e87['persistentConnection_']&&_0x591e87['persistentConnection_']['interrupt'](ra);}function Sd(_0x4e2763){_0x4e2763['persistentConnection_']&&_0x4e2763['persistentConnection_']['resume'](ra);}function ut(_0x3f918b,..._0x163821){let _0x482e69='';_0x3f918b['persistentConnection_']&&(_0x482e69=_0x3f918b['persistentConnection_']['id']+':'),L(_0x482e69,..._0x163821);}function Ai(_0x2e12f2,_0x2f7b85,_0x14f5b4,_0x179a91){_0x2f7b85&&lt(()=>{if(_0x14f5b4==='ok')_0x2f7b85(null);else{const _0x41d4f5=(_0x14f5b4||'error')['toUpperCase']();let _0x4b8508=_0x41d4f5;_0x179a91&&(_0x4b8508+=':\x20'+_0x179a91);const _0x188a42=new Error(_0x4b8508);_0x188a42['code']=_0x41d4f5,_0x2f7b85(_0x188a42);}});}function bd(_0x485f4a,_0x1c9239,_0x1f7d3c,_0x5cb4c1,_0xbc7443,_0x45e221){ut(_0x485f4a,'transaction\x20on\x20'+_0x1c9239);const _0x115aba={'path':_0x1c9239,'update':_0x1f7d3c,'onComplete':_0x5cb4c1,'status':null,'order':to(),'applyLocally':_0x45e221,'retryCount':0x0,'unwatcher':_0xbc7443,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2c94c4=ys(_0x485f4a,_0x1c9239,void 0x0);_0x115aba['currentInputSnapshot']=_0x2c94c4;const _0x3fe8bf=_0x115aba['update'](_0x2c94c4['val']());if(_0x3fe8bf===void 0x0)_0x115aba['unwatcher'](),_0x115aba['currentOutputSnapshotRaw']=null,_0x115aba['currentOutputSnapshotResolved']=null,_0x115aba['onComplete']&&_0x115aba['onComplete'](null,!0x1,_0x115aba['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3fe8bf,_0x115aba['path']),_0x115aba['status']=0x0;const _0x1313a5=Un(_0x485f4a['transactionQueueTree_'],_0x1c9239),_0x5502cc=Ge(_0x1313a5)||[];_0x5502cc['push'](_0x115aba),fs(_0x1313a5,_0x5502cc);let _0x1747ce;typeof _0x3fe8bf=='object'&&_0x3fe8bf!==null&&Y(_0x3fe8bf,'.priority')?(_0x1747ce=Oe(_0x3fe8bf,'.priority'),f(Cn(_0x1747ce),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1747ce=(xn(_0x485f4a['serverSyncTree_'],_0x1c9239)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x53bf0c=jt(_0x485f4a),_0x47fcb1=N(_0x3fe8bf,_0x1747ce),_0x72e767=hs(_0x47fcb1,_0x2c94c4,_0x53bf0c);_0x115aba['currentOutputSnapshotRaw']=_0x47fcb1,_0x115aba['currentOutputSnapshotResolved']=_0x72e767,_0x115aba['currentWriteId']=Vn(_0x485f4a);const _0xcaf28e=ss(_0x485f4a['serverSyncTree_'],_0x1c9239,_0x72e767,_0x115aba['currentWriteId'],_0x115aba['applyLocally']);V(_0x485f4a['eventQueue_'],_0x1c9239,_0xcaf28e),Hn(_0x485f4a,_0x485f4a['transactionQueueTree_']);}}function ys(_0x10a194,_0x3b0417,_0x1de17b){return xn(_0x10a194['serverSyncTree_'],_0x3b0417,_0x1de17b)||g['EMPTY_NODE'];}function Hn(_0x270ca9,_0x248e92=_0x270ca9['transactionQueueTree_']){if(_0x248e92||$n(_0x270ca9,_0x248e92),Ge(_0x248e92)){const _0xae4ab8=la(_0x270ca9,_0x248e92);f(_0xae4ab8['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xae4ab8['every'](_0xa424a=>_0xa424a['status']===0x0)&&Rd(_0x270ca9,Gt(_0x248e92),_0xae4ab8);}else ea(_0x248e92)&&Wn(_0x248e92,_0x56719=>{Hn(_0x270ca9,_0x56719);});}function Rd(_0x1002b9,_0x373860,_0x12d776){const _0x5afe69=_0x12d776['map'](_0x184ed5=>_0x184ed5['currentWriteId']),_0x1d6479=ys(_0x1002b9,_0x373860,_0x5afe69);let _0x130245=_0x1d6479;const _0x4f2234=_0x1d6479['hash']();for(let _0x4b6d80=0x0;_0x4b6d80<_0x12d776['length'];_0x4b6d80++){const _0x155588=_0x12d776[_0x4b6d80];f(_0x155588['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x155588['status']=0x1,_0x155588['retryCount']++;const _0x204107=F(_0x373860,_0x155588['path']);_0x130245=_0x130245['updateChild'](_0x204107,_0x155588['currentOutputSnapshotRaw']);}const _0x2f5520=_0x130245['val'](!0x0),_0x2badc9=_0x373860;_0x1002b9['server_']['put'](_0x2badc9['toString'](),_0x2f5520,_0x22d098=>{ut(_0x1002b9,'transaction\x20put\x20response',{'path':_0x2badc9['toString'](),'status':_0x22d098});let _0x1adbda=[];if(_0x22d098==='ok'){const _0x4e8d54=[];for(let _0x37b710=0x0;_0x37b710<_0x12d776['length'];_0x37b710++)_0x12d776[_0x37b710]['status']=0x2,_0x1adbda=_0x1adbda['concat'](pe(_0x1002b9['serverSyncTree_'],_0x12d776[_0x37b710]['currentWriteId'])),_0x12d776[_0x37b710]['onComplete']&&_0x4e8d54['push'](()=>_0x12d776[_0x37b710]['onComplete'](null,!0x0,_0x12d776[_0x37b710]['currentOutputSnapshotResolved'])),_0x12d776[_0x37b710]['unwatcher']();$n(_0x1002b9,Un(_0x1002b9['transactionQueueTree_'],_0x373860)),Hn(_0x1002b9,_0x1002b9['transactionQueueTree_']),V(_0x1002b9['eventQueue_'],_0x373860,_0x1adbda);for(let _0x38983b=0x0;_0x38983b<_0x4e8d54['length'];_0x38983b++)lt(_0x4e8d54[_0x38983b]);}else{if(_0x22d098==='datastale'){for(let _0x492b76=0x0;_0x492b76<_0x12d776['length'];_0x492b76++)_0x12d776[_0x492b76]['status']===0x3?_0x12d776[_0x492b76]['status']=0x4:_0x12d776[_0x492b76]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2badc9['toString']()+'\x20failed:\x20'+_0x22d098);for(let _0xb99985=0x0;_0xb99985<_0x12d776['length'];_0xb99985++)_0x12d776[_0xb99985]['status']=0x4,_0x12d776[_0xb99985]['abortReason']=_0x22d098;}st(_0x1002b9,_0x373860);}},_0x4f2234);}function st(_0x889e1,_0x1c91a3){const _0x4e94e6=ca(_0x889e1,_0x1c91a3),_0x5664bc=Gt(_0x4e94e6),_0x5c2b42=la(_0x889e1,_0x4e94e6);return Ad(_0x889e1,_0x5c2b42,_0x5664bc),_0x5664bc;}function Ad(_0x1044c7,_0x204aea,_0x28f88f){if(_0x204aea['length']===0x0)return;const _0x123f7e=[];let _0x3e06f0=[];const _0x414bc3=_0x204aea['filter'](_0x2d2126=>_0x2d2126['status']===0x0)['map'](_0x40092f=>_0x40092f['currentWriteId']);for(let _0x2227b3=0x0;_0x2227b3<_0x204aea['length'];_0x2227b3++){const _0x1b233c=_0x204aea[_0x2227b3],_0x20b955=F(_0x28f88f,_0x1b233c['path']);let _0x447f4b=!0x1,_0x6ea4ab;if(f(_0x20b955!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1b233c['status']===0x4)_0x447f4b=!0x0,_0x6ea4ab=_0x1b233c['abortReason'],_0x3e06f0=_0x3e06f0['concat'](pe(_0x1044c7['serverSyncTree_'],_0x1b233c['currentWriteId'],!0x0));else{if(_0x1b233c['status']===0x0){if(_0x1b233c['retryCount']>=_d)_0x447f4b=!0x0,_0x6ea4ab='maxretry',_0x3e06f0=_0x3e06f0['concat'](pe(_0x1044c7['serverSyncTree_'],_0x1b233c['currentWriteId'],!0x0));else{const _0x10eb0a=ys(_0x1044c7,_0x1b233c['path'],_0x414bc3);_0x1b233c['currentInputSnapshot']=_0x10eb0a;const _0x2cbb0a=_0x204aea[_0x2227b3]['update'](_0x10eb0a['val']());if(_0x2cbb0a!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2cbb0a,_0x1b233c['path']);let _0x24bc49=N(_0x2cbb0a);typeof _0x2cbb0a=='object'&&_0x2cbb0a!=null&&Y(_0x2cbb0a,'.priority')||(_0x24bc49=_0x24bc49['updatePriority'](_0x10eb0a['getPriority']()));const _0x5979e9=_0x1b233c['currentWriteId'],_0x1a8db3=jt(_0x1044c7),_0x27dee5=hs(_0x24bc49,_0x10eb0a,_0x1a8db3);_0x1b233c['currentOutputSnapshotRaw']=_0x24bc49,_0x1b233c['currentOutputSnapshotResolved']=_0x27dee5,_0x1b233c['currentWriteId']=Vn(_0x1044c7),_0x414bc3['splice'](_0x414bc3['indexOf'](_0x5979e9),0x1),_0x3e06f0=_0x3e06f0['concat'](ss(_0x1044c7['serverSyncTree_'],_0x1b233c['path'],_0x27dee5,_0x1b233c['currentWriteId'],_0x1b233c['applyLocally'])),_0x3e06f0=_0x3e06f0['concat'](pe(_0x1044c7['serverSyncTree_'],_0x5979e9,!0x0));}else _0x447f4b=!0x0,_0x6ea4ab='nodata',_0x3e06f0=_0x3e06f0['concat'](pe(_0x1044c7['serverSyncTree_'],_0x1b233c['currentWriteId'],!0x0));}}}V(_0x1044c7['eventQueue_'],_0x28f88f,_0x3e06f0),_0x3e06f0=[],_0x447f4b&&(_0x204aea[_0x2227b3]['status']=0x2,function(_0xefb7b0){setTimeout(_0xefb7b0,Math['floor'](0x0));}(_0x204aea[_0x2227b3]['unwatcher']),_0x204aea[_0x2227b3]['onComplete']&&(_0x6ea4ab==='nodata'?_0x123f7e['push'](()=>_0x204aea[_0x2227b3]['onComplete'](null,!0x1,_0x204aea[_0x2227b3]['currentInputSnapshot'])):_0x123f7e['push'](()=>_0x204aea[_0x2227b3]['onComplete'](new Error(_0x6ea4ab),!0x1,null))));}$n(_0x1044c7,_0x1044c7['transactionQueueTree_']);for(let _0x6c1702=0x0;_0x6c1702<_0x123f7e['length'];_0x6c1702++)lt(_0x123f7e[_0x6c1702]);Hn(_0x1044c7,_0x1044c7['transactionQueueTree_']);}function ca(_0x37185d,_0x194f0a){let _0x4ea775,_0x55ead8=_0x37185d['transactionQueueTree_'];for(_0x4ea775=y(_0x194f0a);_0x4ea775!==null&&Ge(_0x55ead8)===void 0x0;)_0x55ead8=Un(_0x55ead8,_0x4ea775),_0x194f0a=b(_0x194f0a),_0x4ea775=y(_0x194f0a);return _0x55ead8;}function la(_0x932d71,_0x236705){const _0x45ff55=[];return ha(_0x932d71,_0x236705,_0x45ff55),_0x45ff55['sort']((_0x10ad24,_0x328d2f)=>_0x10ad24['order']-_0x328d2f['order']),_0x45ff55;}function ha(_0x939394,_0x35d8e3,_0x4689c0){const _0x5c5656=Ge(_0x35d8e3);if(_0x5c5656){for(let _0x239aa7=0x0;_0x239aa7<_0x5c5656['length'];_0x239aa7++)_0x4689c0['push'](_0x5c5656[_0x239aa7]);}Wn(_0x35d8e3,_0xa3b37a=>{ha(_0x939394,_0xa3b37a,_0x4689c0);});}function $n(_0xb2fe0d,_0x267cce){const _0x4808ac=Ge(_0x267cce);if(_0x4808ac){let _0x163ec4=0x0;for(let _0x2fe1b8=0x0;_0x2fe1b8<_0x4808ac['length'];_0x2fe1b8++)_0x4808ac[_0x2fe1b8]['status']!==0x2&&(_0x4808ac[_0x163ec4]=_0x4808ac[_0x2fe1b8],_0x163ec4++);_0x4808ac['length']=_0x163ec4,fs(_0x267cce,_0x4808ac['length']>0x0?_0x4808ac:void 0x0);}Wn(_0x267cce,_0x27dcff=>{$n(_0xb2fe0d,_0x27dcff);});}function vs(_0x51be6b,_0x4ae971){const _0x37d835=Gt(ca(_0x51be6b,_0x4ae971)),_0xa0cfa4=Un(_0x51be6b['transactionQueueTree_'],_0x4ae971);return sd(_0xa0cfa4,_0xef939a=>{ai(_0x51be6b,_0xef939a);}),ai(_0x51be6b,_0xa0cfa4),ta(_0xa0cfa4,_0x533606=>{ai(_0x51be6b,_0x533606);}),_0x37d835;}function ai(_0x1a993d,_0x156492){const _0x4e2538=Ge(_0x156492);if(_0x4e2538){const _0x454c30=[];let _0x5b6251=[],_0x526789=-0x1;for(let _0x414c96=0x0;_0x414c96<_0x4e2538['length'];_0x414c96++)_0x4e2538[_0x414c96]['status']===0x3||(_0x4e2538[_0x414c96]['status']===0x1?(f(_0x526789===_0x414c96-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x526789=_0x414c96,_0x4e2538[_0x414c96]['status']=0x3,_0x4e2538[_0x414c96]['abortReason']='set'):(f(_0x4e2538[_0x414c96]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4e2538[_0x414c96]['unwatcher'](),_0x5b6251=_0x5b6251['concat'](pe(_0x1a993d['serverSyncTree_'],_0x4e2538[_0x414c96]['currentWriteId'],!0x0)),_0x4e2538[_0x414c96]['onComplete']&&_0x454c30['push'](_0x4e2538[_0x414c96]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x526789===-0x1?fs(_0x156492,void 0x0):_0x4e2538['length']=_0x526789+0x1,V(_0x1a993d['eventQueue_'],Gt(_0x156492),_0x5b6251);for(let _0x1b32a7=0x0;_0x1b32a7<_0x454c30['length'];_0x1b32a7++)lt(_0x454c30[_0x1b32a7]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x115f90){let _0xdaa5c1='';const _0x73532a=_0x115f90['split']('/');for(let _0x3dedb8=0x0;_0x3dedb8<_0x73532a['length'];_0x3dedb8++)if(_0x73532a[_0x3dedb8]['length']>0x0){let _0x2e0f45=_0x73532a[_0x3dedb8];try{_0x2e0f45=decodeURIComponent(_0x2e0f45['replace'](/\+/g,'\x20'));}catch{}_0xdaa5c1+='/'+_0x2e0f45;}return _0xdaa5c1;}function Nd(_0x3995f6){const _0x16172f={};_0x3995f6['charAt'](0x0)==='?'&&(_0x3995f6=_0x3995f6['substring'](0x1));for(const _0x492e61 of _0x3995f6['split']('&')){if(_0x492e61['length']===0x0)continue;const _0x5df982=_0x492e61['split']('=');_0x5df982['length']===0x2?_0x16172f[decodeURIComponent(_0x5df982[0x0])]=decodeURIComponent(_0x5df982[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x492e61+'\x27\x20in\x20query\x20\x27'+_0x3995f6+'\x27');}return _0x16172f;}const gr=function(_0x568d8f,_0x263250){const _0x1a5037=Pd(_0x568d8f),_0x4df352=_0x1a5037['namespace'];_0x1a5037['domain']==='firebase.com'&&oe(_0x1a5037['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4df352||_0x4df352==='undefined')&&_0x1a5037['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1a5037['secure']||Bl();const _0x1e892d=_0x1a5037['scheme']==='ws'||_0x1a5037['scheme']==='wss';return{'repoInfo':new _o(_0x1a5037['host'],_0x1a5037['secure'],_0x4df352,_0x1e892d,_0x263250,'',_0x4df352!==_0x1a5037['subdomain']),'path':new C(_0x1a5037['pathString'])};},Pd=function(_0x4a70a0){let _0x245a66='',_0x15676c='',_0x2eef81='',_0x50f627='',_0x1dfadd='',_0x1f49b3=!0x0,_0x2f1f5a='https',_0x31dceb=0x1bb;if(typeof _0x4a70a0=='string'){let _0x30c0ca=_0x4a70a0['indexOf']('//');_0x30c0ca>=0x0&&(_0x2f1f5a=_0x4a70a0['substring'](0x0,_0x30c0ca-0x1),_0x4a70a0=_0x4a70a0['substring'](_0x30c0ca+0x2));let _0x41c26a=_0x4a70a0['indexOf']('/');_0x41c26a===-0x1&&(_0x41c26a=_0x4a70a0['length']);let _0xe75b3c=_0x4a70a0['indexOf']('?');_0xe75b3c===-0x1&&(_0xe75b3c=_0x4a70a0['length']),_0x245a66=_0x4a70a0['substring'](0x0,Math['min'](_0x41c26a,_0xe75b3c)),_0x41c26a<_0xe75b3c&&(_0x50f627=kd(_0x4a70a0['substring'](_0x41c26a,_0xe75b3c)));const _0x5a55eb=Nd(_0x4a70a0['substring'](Math['min'](_0x4a70a0['length'],_0xe75b3c)));_0x30c0ca=_0x245a66['indexOf'](':'),_0x30c0ca>=0x0?(_0x1f49b3=_0x2f1f5a==='https'||_0x2f1f5a==='wss',_0x31dceb=parseInt(_0x245a66['substring'](_0x30c0ca+0x1),0xa)):_0x30c0ca=_0x245a66['length'];const _0x325c13=_0x245a66['slice'](0x0,_0x30c0ca);if(_0x325c13['toLowerCase']()==='localhost')_0x15676c='localhost';else{if(_0x325c13['split']('.')['length']<=0x2)_0x15676c=_0x325c13;else{const _0x1a60c9=_0x245a66['indexOf']('.');_0x2eef81=_0x245a66['substring'](0x0,_0x1a60c9)['toLowerCase'](),_0x15676c=_0x245a66['substring'](_0x1a60c9+0x1),_0x1dfadd=_0x2eef81;}}'ns'in _0x5a55eb&&(_0x1dfadd=_0x5a55eb['ns']);}return{'host':_0x245a66,'port':_0x31dceb,'domain':_0x15676c,'subdomain':_0x2eef81,'secure':_0x1f49b3,'scheme':_0x2f1f5a,'pathString':_0x50f627,'namespace':_0x1dfadd};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x300f2c=0x0;const _0x5a78f3=[];return function(_0x44856d){const _0x4f24e9=_0x44856d===_0x300f2c;_0x300f2c=_0x44856d;let _0x52ef70;const _0x258ae9=new Array(0x8);for(_0x52ef70=0x7;_0x52ef70>=0x0;_0x52ef70--)_0x258ae9[_0x52ef70]=mr['charAt'](_0x44856d%0x40),_0x44856d=Math['floor'](_0x44856d/0x40);f(_0x44856d===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0xee2675=_0x258ae9['join']('');if(_0x4f24e9){for(_0x52ef70=0xb;_0x52ef70>=0x0&&_0x5a78f3[_0x52ef70]===0x3f;_0x52ef70--)_0x5a78f3[_0x52ef70]=0x0;_0x5a78f3[_0x52ef70]++;}else{for(_0x52ef70=0x0;_0x52ef70<0xc;_0x52ef70++)_0x5a78f3[_0x52ef70]=Math['floor'](Math['random']()*0x40);}for(_0x52ef70=0x0;_0x52ef70<0xc;_0x52ef70++)_0xee2675+=mr['charAt'](_0x5a78f3[_0x52ef70]);return f(_0xee2675['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0xee2675;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x175b87,_0xfe570f,_0x1020e4,_0x220c52){this['eventType']=_0x175b87,this['eventRegistration']=_0xfe570f,this['snapshot']=_0x1020e4,this['prevName']=_0x220c52;}['getPath'](){const _0x4b277f=this['snapshot']['ref'];return this['eventType']==='value'?_0x4b277f['_path']:_0x4b277f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x5accf3,_0x4803,_0x3dc388){this['eventRegistration']=_0x5accf3,this['error']=_0x4803,this['path']=_0x3dc388;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x2b868c,_0x3dfdad){this['snapshotCallback']=_0x2b868c,this['cancelCallback']=_0x3dfdad;}['onValue'](_0xd9a445,_0x2d436a){this['snapshotCallback']['call'](null,_0xd9a445,_0x2d436a);}['onCancel'](_0xacc96b){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xacc96b);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x592a1f){return this['snapshotCallback']===_0x592a1f['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x592a1f['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x592a1f['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x183895,_0x593d34,_0x5edcac,_0x31bb39){this['_repo']=_0x183895,this['_path']=_0x593d34,this['_queryParams']=_0x5edcac,this['_orderByCalled']=_0x31bb39;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2d4b53=nr(this['_queryParams']),_0x51d261=Bi(_0x2d4b53);return _0x51d261==='{}'?'default':_0x51d261;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x3a6115){if(_0x3a6115=k(_0x3a6115),!(_0x3a6115 instanceof be))return!0x1;const _0x451d86=this['_repo']===_0x3a6115['_repo'],_0x560ca4=qi(this['_path'],_0x3a6115['_path']),_0x3c2119=this['_queryIdentifier']===_0x3a6115['_queryIdentifier'];return _0x451d86&&_0x560ca4&&_0x3c2119;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x144a6a,_0x3edfaa){if(_0x144a6a['_orderByCalled']===!0x0)throw new Error(_0x3edfaa+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0xb4ad0f){let _0x5a7b31=null,_0x555507=null;if(_0xb4ad0f['hasStart']()&&(_0x5a7b31=_0xb4ad0f['getIndexStartValue']()),_0xb4ad0f['hasEnd']()&&(_0x555507=_0xb4ad0f['getIndexEndValue']()),_0xb4ad0f['getIndex']()===ye){const _0x540a15='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x322e7a='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xb4ad0f['hasStart']()){if(_0xb4ad0f['getIndexStartName']()!==xe)throw new Error(_0x540a15);if(typeof _0x5a7b31!='string')throw new Error(_0x322e7a);}if(_0xb4ad0f['hasEnd']()){if(_0xb4ad0f['getIndexEndName']()!==Ie)throw new Error(_0x540a15);if(typeof _0x555507!='string')throw new Error(_0x322e7a);}}else{if(_0xb4ad0f['getIndex']()===R){if(_0x5a7b31!=null&&!Cn(_0x5a7b31)||_0x555507!=null&&!Cn(_0x555507))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xb4ad0f['getIndex']()instanceof Ki||_0xb4ad0f['getIndex']()===Po,'unknown\x20index\x20type.'),_0x5a7b31!=null&&typeof _0x5a7b31=='object'||_0x555507!=null&&typeof _0x555507=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0xc0523a){if(_0xc0523a['hasStart']()&&_0xc0523a['hasEnd']()&&_0xc0523a['hasLimit']()&&!_0xc0523a['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0xc9e1be,_0xcfd9d1){super(_0xc9e1be,_0xcfd9d1,new Qi(),!0x1);}get['parent'](){const _0x2c215f=To(this['_path']);return _0x2c215f===null?null:new Z(this['_repo'],_0x2c215f);}get['root'](){let _0x3cab27=this;for(;_0x3cab27['parent']!==null;)_0x3cab27=_0x3cab27['parent'];return _0x3cab27;}}class rt{constructor(_0x4780ff,_0x3b1864,_0x2d0638){this['_node']=_0x4780ff,this['ref']=_0x3b1864,this['_index']=_0x2d0638;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xf5cbb7){const _0x5a44ca=new C(_0xf5cbb7),_0x5f2d10=Lt(this['ref'],_0xf5cbb7);return new rt(this['_node']['getChild'](_0x5a44ca),_0x5f2d10,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x79ab77){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5886fa,_0xfc9a2f)=>_0x79ab77(new rt(_0xfc9a2f,Lt(this['ref'],_0x5886fa),R)));}['hasChild'](_0x3a6b87){const _0x3f42a5=new C(_0x3a6b87);return!this['_node']['getChild'](_0x3f42a5)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x14dd24,_0x48d1cf){return _0x14dd24=k(_0x14dd24),_0x14dd24['_checkNotDeleted']('ref'),_0x48d1cf!==void 0x0?Lt(_0x14dd24['_root'],_0x48d1cf):_0x14dd24['_root'];}function Lt(_0x48055a,_0x584ca2){return _0x48055a=k(_0x48055a),y(_0x48055a['_path'])===null?ud('child','path',_0x584ca2):_s('child','path',_0x584ca2),new Z(_0x48055a['_repo'],A(_0x48055a['_path'],_0x584ca2));}function d_(_0x467c8d,_0x12375c){_0x467c8d=k(_0x467c8d),gs('push',_0x467c8d['_path']),qt('push',_0x12375c,_0x467c8d['_path'],!0x0);const _0xb7f1e4=oa(_0x467c8d['_repo']),_0x1d050f=Od(_0xb7f1e4),_0x50372b=Lt(_0x467c8d,_0x1d050f),_0x3edeb6=Lt(_0x467c8d,_0x1d050f);let _0x404f3e;return _0x12375c!=null?_0x404f3e=Ld(_0x3edeb6,_0x12375c)['then'](()=>_0x3edeb6):_0x404f3e=Promise['resolve'](_0x3edeb6),_0x50372b['then']=_0x404f3e['then']['bind'](_0x404f3e),_0x50372b['catch']=_0x404f3e['then']['bind'](_0x404f3e,void 0x0),_0x50372b;}function Ld(_0x2b77c1,_0x530d17){_0x2b77c1=k(_0x2b77c1),gs('set',_0x2b77c1['_path']),qt('set',_0x530d17,_0x2b77c1['_path'],!0x1);const _0x1a869d=new Ve();return Ed(_0x2b77c1['_repo'],_0x2b77c1['_path'],_0x530d17,null,_0x1a869d['wrapCallback'](()=>{})),_0x1a869d['promise'];}function f_(_0xfc824,_0x1e64a9){hd('update',_0x1e64a9,_0xfc824['_path']);const _0x57e35f=new Ve();return Id(_0xfc824['_repo'],_0xfc824['_path'],_0x1e64a9,_0x57e35f['wrapCallback'](()=>{})),_0x57e35f['promise'];}function p_(_0x4409a7){_0x4409a7=k(_0x4409a7);const _0x5e9420=new ua(()=>{}),_0x3182ae=new qn(_0x5e9420);return vd(_0x4409a7['_repo'],_0x4409a7,_0x3182ae)['then'](_0x3d1473=>new rt(_0x3d1473,new Z(_0x4409a7['_repo'],_0x4409a7['_path']),_0x4409a7['_queryParams']['getIndex']()));}class qn{constructor(_0x3d76ee){this['callbackContext']=_0x3d76ee;}['respondsTo'](_0x249a25){return _0x249a25==='value';}['createEvent'](_0x9c4e41,_0x3f0caa){const _0x5d8beb=_0x3f0caa['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x9c4e41['snapshotNode'],new Z(_0x3f0caa['_repo'],_0x3f0caa['_path']),_0x5d8beb));}['getEventRunner'](_0x267b54){return _0x267b54['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x267b54['error']):()=>this['callbackContext']['onValue'](_0x267b54['snapshot'],null);}['createCancelEvent'](_0x5dc571,_0x4ce6cf){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x5dc571,_0x4ce6cf):null;}['matches'](_0x2c357d){return _0x2c357d instanceof qn?!_0x2c357d['callbackContext']||!this['callbackContext']?!0x0:_0x2c357d['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x1ade98,_0x47da91,_0x4d4272,_0x3c3df3,_0x30ae39){const _0x38d1a0=new ua(_0x4d4272,void 0x0),_0x1c00f6=new qn(_0x38d1a0);return Cd(_0x1ade98['_repo'],_0x1ade98,_0x1c00f6),()=>Td(_0x1ade98['_repo'],_0x1ade98,_0x1c00f6);}function Fd(_0x31fc35,_0x396fd0,_0x1f1796,_0x35c0e8){return xd(_0x31fc35,'value',_0x396fd0);}class dt{}class pa extends dt{constructor(_0x10320a,_0x507b96){super(),this['_value']=_0x10320a,this['_key']=_0x507b96,this['type']='endAt';}['_apply'](_0x11c64d){qt('endAt',this['_value'],_0x11c64d['_path'],!0x0);const _0xa95c3a=Kh(_0x11c64d['_queryParams'],this['_value'],this['_key']);if(fa(_0xa95c3a),Gn(_0xa95c3a),_0x11c64d['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x11c64d['_repo'],_0x11c64d['_path'],_0xa95c3a,_0x11c64d['_orderByCalled']);}}function __(_0x34c9d6,_0x4168bc){return new pa(_0x34c9d6,_0x4168bc);}class _a extends dt{constructor(_0x3734ff,_0x1ef1d7){super(),this['_value']=_0x3734ff,this['_key']=_0x1ef1d7,this['type']='startAt';}['_apply'](_0x15903c){qt('startAt',this['_value'],_0x15903c['_path'],!0x0);const _0x431da4=jh(_0x15903c['_queryParams'],this['_value'],this['_key']);if(fa(_0x431da4),Gn(_0x431da4),_0x15903c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x15903c['_repo'],_0x15903c['_path'],_0x431da4,_0x15903c['_orderByCalled']);}}function g_(_0xd399d9=null,_0x16ef07){return new _a(_0xd399d9,_0x16ef07);}class Ud extends dt{constructor(_0x1178f4){super(),this['_limit']=_0x1178f4,this['type']='limitToFirst';}['_apply'](_0xc4064d){if(_0xc4064d['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0xc4064d['_repo'],_0xc4064d['_path'],zh(_0xc4064d['_queryParams'],this['_limit']),_0xc4064d['_orderByCalled']);}}function m_(_0x358cc2){if(Math['floor'](_0x358cc2)!==_0x358cc2||_0x358cc2<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x358cc2);}class Wd extends dt{constructor(_0x21da3a){super(),this['_path']=_0x21da3a,this['type']='orderByChild';}['_apply'](_0x35ce41){da(_0x35ce41,'orderByChild');const _0xf5dabd=new C(this['_path']);if(v(_0xf5dabd))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x514e47=new Ki(_0xf5dabd),_0x11bd8c=Do(_0x35ce41['_queryParams'],_0x514e47);return Gn(_0x11bd8c),new be(_0x35ce41['_repo'],_0x35ce41['_path'],_0x11bd8c,!0x0);}}function y_(_0x3bf611){if(_0x3bf611==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3bf611==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3bf611==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x3bf611),new Wd(_0x3bf611);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x441ebc){da(_0x441ebc,'orderByKey');const _0x5e6722=Do(_0x441ebc['_queryParams'],ye);return Gn(_0x5e6722),new be(_0x441ebc['_repo'],_0x441ebc['_path'],_0x5e6722,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x596409,_0x137dfa){super(),this['_value']=_0x596409,this['_key']=_0x137dfa,this['type']='equalTo';}['_apply'](_0x873344){if(qt('equalTo',this['_value'],_0x873344['_path'],!0x1),_0x873344['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x873344['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x873344));}}function E_(_0x5fbae4,_0x34be2a){return new Vd(_0x5fbae4,_0x34be2a);}function I_(_0x531046,..._0x274836){let _0x53563a=k(_0x531046);for(const _0x56bef4 of _0x274836)_0x53563a=_0x56bef4['_apply'](_0x53563a);return _0x53563a;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x1feb9a,_0x3b2053,_0x97d481,_0x37463c){const _0x250e15=_0x3b2053['lastIndexOf'](':'),_0x1894b1=_0x3b2053['substring'](0x0,_0x250e15),_0x31cdf6=Wt(_0x1894b1);_0x1feb9a['repoInfo_']=new _o(_0x3b2053,_0x31cdf6,_0x1feb9a['repoInfo_']['namespace'],_0x1feb9a['repoInfo_']['webSocketOnly'],_0x1feb9a['repoInfo_']['nodeAdmin'],_0x1feb9a['repoInfo_']['persistenceKey'],_0x1feb9a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x97d481),_0x37463c&&(_0x1feb9a['authTokenProvider_']=_0x37463c);}function qd(_0x139474,_0xd95550,_0x134770,_0x25f63d,_0x21b85d){let _0x5e8a08=_0x25f63d||_0x139474['options']['databaseURL'];_0x5e8a08===void 0x0&&(_0x139474['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x139474['options']['projectId']),_0x5e8a08=_0x139474['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3ed81b=gr(_0x5e8a08,_0x21b85d),_0x28d8ad=_0x3ed81b['repoInfo'],_0x303ab2;typeof process<'u'&&Us&&(_0x303ab2=Us[Hd]),_0x303ab2?(_0x5e8a08='http://'+_0x303ab2+'?ns='+_0x28d8ad['namespace'],_0x3ed81b=gr(_0x5e8a08,_0x21b85d),_0x28d8ad=_0x3ed81b['repoInfo']):_0x3ed81b['repoInfo']['secure'];const _0x104da1=new Jl(_0x139474['name'],_0x139474['options'],_0xd95550);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3ed81b),v(_0x3ed81b['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3c0cfa=jd(_0x28d8ad,_0x139474,_0x104da1,new Ql(_0x139474,_0x134770));return new Kd(_0x3c0cfa,_0x139474);}function zd(_0xfcae0e,_0x2a6907){const _0x4b0dc0=ki[_0x2a6907];(!_0x4b0dc0||_0x4b0dc0[_0xfcae0e['key']]!==_0xfcae0e)&&oe('Database\x20'+_0x2a6907+'('+_0xfcae0e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0xfcae0e),delete _0x4b0dc0[_0xfcae0e['key']];}function jd(_0x378d39,_0x417c3c,_0x571996,_0x5f3cfe){let _0x10b130=ki[_0x417c3c['name']];_0x10b130||(_0x10b130={},ki[_0x417c3c['name']]=_0x10b130);let _0x5046a9=_0x10b130[_0x378d39['toURLString']()];return _0x5046a9&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x5046a9=new gd(_0x378d39,$d,_0x571996,_0x5f3cfe),_0x10b130[_0x378d39['toURLString']()]=_0x5046a9,_0x5046a9;}class Kd{constructor(_0x23eaba,_0x507d1f){this['_repoInternal']=_0x23eaba,this['app']=_0x507d1f,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x566c66){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x566c66+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x5b08af=Qr(),_0x198b45){const _0x19bbed=Ui(_0x5b08af,'database')['getImmediate']({'identifier':_0x198b45});if(!_0x19bbed['_instanceStarted']){const _0x3c6fe3=ac('database');_0x3c6fe3&&Yd(_0x19bbed,..._0x3c6fe3);}return _0x19bbed;}function Yd(_0x18747d,_0x4edb1b,_0x16a86c,_0x272464={}){_0x18747d=k(_0x18747d),_0x18747d['_checkNotDeleted']('useEmulator');const _0x1cdfe9=_0x4edb1b+':'+_0x16a86c,_0x353774=_0x18747d['_repoInternal'];if(_0x18747d['_instanceStarted']){if(_0x1cdfe9===_0x18747d['_repoInternal']['repoInfo_']['host']&&De(_0x272464,_0x353774['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3d800d;if(_0x353774['repoInfo_']['nodeAdmin'])_0x272464['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3d800d=new tn(tn['OWNER']);else{if(_0x272464['mockUserToken']){const _0x46bc7a=typeof _0x272464['mockUserToken']=='string'?_0x272464['mockUserToken']:cc(_0x272464['mockUserToken'],_0x18747d['app']['options']['projectId']);_0x3d800d=new tn(_0x46bc7a);}}Wt(_0x4edb1b)&&jr(_0x4edb1b),Gd(_0x353774,_0x1cdfe9,_0x272464,_0x3d800d);}function C_(_0xd95b09){_0xd95b09=k(_0xd95b09),_0xd95b09['_checkNotDeleted']('goOffline'),aa(_0xd95b09['_repo']);}function T_(_0x70daf6){_0x70daf6=k(_0x70daf6),_0x70daf6['_checkNotDeleted']('goOnline'),Sd(_0x70daf6['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x104658){Ll(ct),et(new Me('database',(_0x12e432,{instanceIdentifier:_0x1100d8})=>{const _0x248be8=_0x12e432['getProvider']('app')['getImmediate'](),_0x3c709a=_0x12e432['getProvider']('auth-internal'),_0x27112e=_0x12e432['getProvider']('app-check-internal');return qd(_0x248be8,_0x3c709a,_0x27112e,_0x1100d8);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x104658),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x2c4b76,_0x250da9){this['committed']=_0x2c4b76,this['snapshot']=_0x250da9;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x41ec77,_0x86ba16,_0x1e1f99){if(_0x41ec77=k(_0x41ec77),gs('Reference.transaction',_0x41ec77['_path']),_0x41ec77['key']==='.length'||_0x41ec77['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x41ec77['key']+'\x20is\x20a\x20read-only\x20object.';const _0x4da0da=!0x0,_0x42ac7a=new Ve(),_0x4c84e8=(_0x44ad3b,_0x1690e2,_0x857eaf)=>{let _0xa8c6f6=null;_0x44ad3b?_0x42ac7a['reject'](_0x44ad3b):(_0xa8c6f6=new rt(_0x857eaf,new Z(_0x41ec77['_repo'],_0x41ec77['_path']),R),_0x42ac7a['resolve'](new Xd(_0x1690e2,_0xa8c6f6)));},_0x1afb97=Fd(_0x41ec77,()=>{});return bd(_0x41ec77['_repo'],_0x41ec77['_path'],_0x86ba16,_0x4c84e8,_0x1afb97,_0x4da0da),_0x42ac7a['promise'];}ie['prototype']['simpleListen']=function(_0x4f61a5,_0x5ca61c){this['sendRequest']('q',{'p':_0x4f61a5},_0x5ca61c);},ie['prototype']['echo']=function(_0x2442b4,_0x27e637){this['sendRequest']('echo',{'d':_0x2442b4},_0x27e637);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x3d9138,..._0x24b6c2){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x3d9138,..._0x24b6c2);}function nn(_0x4d861e,..._0x360558){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x4d861e,..._0x360558);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x1d1e5d,..._0xbcb629){throw Es(_0x1d1e5d,..._0xbcb629);}function J(_0x40579f,..._0x4e51f5){return Es(_0x40579f,..._0x4e51f5);}function ya(_0x14f2a9,_0x3ac7aa,_0x35df86){const _0x2e61d6={...Zd(),[_0x3ac7aa]:_0x35df86};return new Ut('auth','Firebase',_0x2e61d6)['create'](_0x3ac7aa,{'appName':_0x14f2a9['name']});}function se(_0x5418f8){return ya(_0x5418f8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5e74f2,..._0x40bb05){if(typeof _0x5e74f2!='string'){const _0x47c1c2=_0x40bb05[0x0],_0x23da3e=[..._0x40bb05['slice'](0x1)];return _0x23da3e[0x0]&&(_0x23da3e[0x0]['appName']=_0x5e74f2['name']),_0x5e74f2['_errorFactory']['create'](_0x47c1c2,..._0x23da3e);}return ma['create'](_0x5e74f2,..._0x40bb05);}function m(_0x3fd105,_0x3749cf,..._0x1125d4){if(!_0x3fd105)throw Es(_0x3749cf,..._0x1125d4);}function te(_0x548644){const _0x27f4e0='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x548644;throw nn(_0x27f4e0),new Error(_0x27f4e0);}function ae(_0x30c7c1,_0x7ab2d){_0x30c7c1||te(_0x7ab2d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x1efc2c;return typeof self<'u'&&((_0x1efc2c=self['location'])==null?void 0x0:_0x1efc2c['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0xec1352;return typeof self<'u'&&((_0xec1352=self['location'])==null?void 0x0:_0xec1352['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x22d9a0=navigator;return _0x22d9a0['languages']&&_0x22d9a0['languages'][0x0]||_0x22d9a0['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1fb03c,_0x353817){this['shortDelay']=_0x1fb03c,this['longDelay']=_0x353817,ae(_0x353817>_0x1fb03c,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1f81a7,_0x5b7315){ae(_0x1f81a7['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2014ed}=_0x1f81a7['emulator'];return _0x5b7315?''+_0x2014ed+(_0x5b7315['startsWith']('/')?_0x5b7315['slice'](0x1):_0x5b7315):_0x2014ed;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5751f0,_0x4f9878,_0x4503ee){this['fetchImpl']=_0x5751f0,_0x4f9878&&(this['headersImpl']=_0x4f9878),_0x4503ee&&(this['responseImpl']=_0x4503ee);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x1af687,_0x34e678){return _0x1af687['tenantId']&&!_0x34e678['tenantId']?{..._0x34e678,'tenantId':_0x1af687['tenantId']}:_0x34e678;}async function Ae(_0x4723a2,_0x590b53,_0x4096be,_0x24b1b8,_0x54443e={}){return Ea(_0x4723a2,_0x54443e,async()=>{let _0x470784={},_0xca9e2={};_0x24b1b8&&(_0x590b53==='GET'?_0xca9e2=_0x24b1b8:_0x470784={'body':JSON['stringify'](_0x24b1b8)});const _0x1229cd=at({..._0xca9e2,'key':_0x4723a2['config']['apiKey']})['slice'](0x1),_0x4482d3=await _0x4723a2['_getAdditionalHeaders']();_0x4482d3['Content-Type']='application/json',_0x4723a2['languageCode']&&(_0x4482d3['X-Firebase-Locale']=_0x4723a2['languageCode']);const _0x1580fc={'method':_0x590b53,'headers':_0x4482d3,..._0x470784};return lc()||(_0x1580fc['referrerPolicy']='strict-origin-when-cross-origin'),_0x4723a2['emulatorConfig']&&Wt(_0x4723a2['emulatorConfig']['host'])&&(_0x1580fc['credentials']='include'),va['fetch']()(await Ia(_0x4723a2,_0x4723a2['config']['apiHost'],_0x4096be,_0x1229cd),_0x1580fc);});}async function Ea(_0x5ad692,_0x4e6c70,_0x4b5ab9){_0x5ad692['_canInitEmulator']=!0x1;const _0xd05e29={...rf,..._0x4e6c70};try{const _0x3140b0=new lf(_0x5ad692),_0x55b3a1=await Promise['race']([_0x4b5ab9(),_0x3140b0['promise']]);_0x3140b0['clearNetworkTimeout']();const _0x17fb06=await _0x55b3a1['json']();if('needConfirmation'in _0x17fb06)throw en(_0x5ad692,'account-exists-with-different-credential',_0x17fb06);if(_0x55b3a1['ok']&&!('errorMessage'in _0x17fb06))return _0x17fb06;{const _0x1612bd=_0x55b3a1['ok']?_0x17fb06['errorMessage']:_0x17fb06['error']['message'],[_0x12ee27,_0x199a30]=_0x1612bd['split']('\x20:\x20');if(_0x12ee27==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5ad692,'credential-already-in-use',_0x17fb06);if(_0x12ee27==='EMAIL_EXISTS')throw en(_0x5ad692,'email-already-in-use',_0x17fb06);if(_0x12ee27==='USER_DISABLED')throw en(_0x5ad692,'user-disabled',_0x17fb06);const _0x212491=_0xd05e29[_0x12ee27]||_0x12ee27['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x199a30)throw ya(_0x5ad692,_0x212491,_0x199a30);K(_0x5ad692,_0x212491);}}catch(_0x388dd2){if(_0x388dd2 instanceof Se)throw _0x388dd2;K(_0x5ad692,'network-request-failed',{'message':String(_0x388dd2)});}}async function Yt(_0x14f4a4,_0x4ab469,_0x4b3547,_0x5c7ca6,_0x2a82ff={}){const _0x51f45d=await Ae(_0x14f4a4,_0x4ab469,_0x4b3547,_0x5c7ca6,_0x2a82ff);return'mfaPendingCredential'in _0x51f45d&&K(_0x14f4a4,'multi-factor-auth-required',{'_serverResponse':_0x51f45d}),_0x51f45d;}async function Ia(_0xe80dba,_0x3f2335,_0x3486f9,_0x5c38f6){const _0x3e2027=''+_0x3f2335+_0x3486f9+'?'+_0x5c38f6,_0x574f70=_0xe80dba,_0x2c1768=_0x574f70['config']['emulator']?Is(_0xe80dba['config'],_0x3e2027):_0xe80dba['config']['apiScheme']+'://'+_0x3e2027;return of['includes'](_0x3486f9)&&(await _0x574f70['_persistenceManagerAvailable'],_0x574f70['_getPersistenceType']()==='COOKIE')?_0x574f70['_getPersistence']()['_getFinalTarget'](_0x2c1768)['toString']():_0x2c1768;}function cf(_0xd508e5){switch(_0xd508e5){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x196471){this['auth']=_0x196471,this['timer']=null,this['promise']=new Promise((_0x5b416d,_0x23879a)=>{this['timer']=setTimeout(()=>_0x23879a(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x2106a5,_0x34390f,_0x431a48){const _0x444217={'appName':_0x2106a5['name']};_0x431a48['email']&&(_0x444217['email']=_0x431a48['email']),_0x431a48['phoneNumber']&&(_0x444217['phoneNumber']=_0x431a48['phoneNumber']);const _0x4dcbfe=J(_0x2106a5,_0x34390f,_0x444217);return _0x4dcbfe['customData']['_tokenResponse']=_0x431a48,_0x4dcbfe;}function vr(_0x276d80){return _0x276d80!==void 0x0&&_0x276d80['enterprise']!==void 0x0;}class hf{constructor(_0x4fd27b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4fd27b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4fd27b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4fd27b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3f0042){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2daaad of this['recaptchaEnforcementState'])if(_0x2daaad['provider']&&_0x2daaad['provider']===_0x3f0042)return cf(_0x2daaad['enforcementState']);return null;}['isProviderEnabled'](_0x5272f1){return this['getProviderEnforcementState'](_0x5272f1)==='ENFORCE'||this['getProviderEnforcementState'](_0x5272f1)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x25542f,_0x3b053a){return Ae(_0x25542f,'GET','/v2/recaptchaConfig',Re(_0x25542f,_0x3b053a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x18258f,_0x329293){return Ae(_0x18258f,'POST','/v1/accounts:delete',_0x329293);}async function Sn(_0x34e672,_0x2f509d){return Ae(_0x34e672,'POST','/v1/accounts:lookup',_0x2f509d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x24c046){if(_0x24c046)try{const _0xb514db=new Date(Number(_0x24c046));if(!isNaN(_0xb514db['getTime']()))return _0xb514db['toUTCString']();}catch{}}async function ff(_0xb03357,_0x32689f=!0x1){const _0x3eaa3c=k(_0xb03357),_0x44e431=await _0x3eaa3c['getIdToken'](_0x32689f),_0x1af064=ws(_0x44e431);m(_0x1af064&&_0x1af064['exp']&&_0x1af064['auth_time']&&_0x1af064['iat'],_0x3eaa3c['auth'],'internal-error');const _0x295d89=typeof _0x1af064['firebase']=='object'?_0x1af064['firebase']:void 0x0,_0x471533=_0x295d89==null?void 0x0:_0x295d89['sign_in_provider'];return{'claims':_0x1af064,'token':_0x44e431,'authTime':St(ci(_0x1af064['auth_time'])),'issuedAtTime':St(ci(_0x1af064['iat'])),'expirationTime':St(ci(_0x1af064['exp'])),'signInProvider':_0x471533||null,'signInSecondFactor':(_0x295d89==null?void 0x0:_0x295d89['sign_in_second_factor'])||null};}function ci(_0x4cd7ea){return Number(_0x4cd7ea)*0x3e8;}function ws(_0x17cd48){const [_0x46cb64,_0x575d69,_0x40d233]=_0x17cd48['split']('.');if(_0x46cb64===void 0x0||_0x575d69===void 0x0||_0x40d233===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4bae02=cn(_0x575d69);return _0x4bae02?JSON['parse'](_0x4bae02):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x208b03){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x208b03==null?void 0x0:_0x208b03['toString']()),null;}}function Er(_0x51d4b5){const _0x355f36=ws(_0x51d4b5);return m(_0x355f36,'internal-error'),m(typeof _0x355f36['exp']<'u','internal-error'),m(typeof _0x355f36['iat']<'u','internal-error'),Number(_0x355f36['exp'])-Number(_0x355f36['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4f214a,_0x3a6b0f,_0x17cc67=!0x1){if(_0x17cc67)return _0x3a6b0f;try{return await _0x3a6b0f;}catch(_0x252967){throw _0x252967 instanceof Se&&pf(_0x252967)&&_0x4f214a['auth']['currentUser']===_0x4f214a&&await _0x4f214a['auth']['signOut'](),_0x252967;}}function pf({code:_0x562740}){return _0x562740==='auth/user-disabled'||_0x562740==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x410c18){this['user']=_0x410c18,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x116d0e){if(_0x116d0e){const _0x15b806=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x15b806;}else{this['errorBackoff']=0x7530;const _0x4f8157=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4f8157);}}['schedule'](_0x223fba=!0x1){if(!this['isRunning'])return;const _0x1f474a=this['getInterval'](_0x223fba);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1f474a);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5dd559){(_0x5dd559==null?void 0x0:_0x5dd559['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x381b29,_0x147eac){this['createdAt']=_0x381b29,this['lastLoginAt']=_0x147eac,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x17e066){this['createdAt']=_0x17e066['createdAt'],this['lastLoginAt']=_0x17e066['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0xf30577){var _0x2e7496;const _0x4e0eb9=_0xf30577['auth'],_0xa76346=await _0xf30577['getIdToken'](),_0x18a5dd=await xt(_0xf30577,Sn(_0x4e0eb9,{'idToken':_0xa76346}));m(_0x18a5dd==null?void 0x0:_0x18a5dd['users']['length'],_0x4e0eb9,'internal-error');const _0x3eb908=_0x18a5dd['users'][0x0];_0xf30577['_notifyReloadListener'](_0x3eb908);const _0x5a241d=(_0x2e7496=_0x3eb908['providerUserInfo'])!=null&&_0x2e7496['length']?wa(_0x3eb908['providerUserInfo']):[],_0x560b98=mf(_0xf30577['providerData'],_0x5a241d),_0x313602=_0xf30577['isAnonymous'],_0x3dce25=!(_0xf30577['email']&&_0x3eb908['passwordHash'])&&!(_0x560b98!=null&&_0x560b98['length']),_0x3be916=_0x313602?_0x3dce25:!0x1,_0x216bd0={'uid':_0x3eb908['localId'],'displayName':_0x3eb908['displayName']||null,'photoURL':_0x3eb908['photoUrl']||null,'email':_0x3eb908['email']||null,'emailVerified':_0x3eb908['emailVerified']||!0x1,'phoneNumber':_0x3eb908['phoneNumber']||null,'tenantId':_0x3eb908['tenantId']||null,'providerData':_0x560b98,'metadata':new Pi(_0x3eb908['createdAt'],_0x3eb908['lastLoginAt']),'isAnonymous':_0x3be916};Object['assign'](_0xf30577,_0x216bd0);}async function gf(_0xe9a034){const _0x276ac5=k(_0xe9a034);await bn(_0x276ac5),await _0x276ac5['auth']['_persistUserIfCurrent'](_0x276ac5),_0x276ac5['auth']['_notifyListenersIfCurrent'](_0x276ac5);}function mf(_0x3876c1,_0x756e3b){return[..._0x3876c1['filter'](_0x7f4d4f=>!_0x756e3b['some'](_0x3c79b4=>_0x3c79b4['providerId']===_0x7f4d4f['providerId'])),..._0x756e3b];}function wa(_0x5d17da){return _0x5d17da['map'](({providerId:_0x1c8eb6,..._0x115980})=>({'providerId':_0x1c8eb6,'uid':_0x115980['rawId']||'','displayName':_0x115980['displayName']||null,'email':_0x115980['email']||null,'phoneNumber':_0x115980['phoneNumber']||null,'photoURL':_0x115980['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x95579d,_0x183c1b){const _0xfb1678=await Ea(_0x95579d,{},async()=>{const _0x1d73ad=at({'grant_type':'refresh_token','refresh_token':_0x183c1b})['slice'](0x1),{tokenApiHost:_0x53692c,apiKey:_0x41771a}=_0x95579d['config'],_0x45a081=await Ia(_0x95579d,_0x53692c,'/v1/token','key='+_0x41771a),_0x1ea117=await _0x95579d['_getAdditionalHeaders']();_0x1ea117['Content-Type']='application/x-www-form-urlencoded';const _0x6c3c25={'method':'POST','headers':_0x1ea117,'body':_0x1d73ad};return _0x95579d['emulatorConfig']&&Wt(_0x95579d['emulatorConfig']['host'])&&(_0x6c3c25['credentials']='include'),va['fetch']()(_0x45a081,_0x6c3c25);});return{'accessToken':_0xfb1678['access_token'],'expiresIn':_0xfb1678['expires_in'],'refreshToken':_0xfb1678['refresh_token']};}async function vf(_0x285982,_0x15b2c5){return Ae(_0x285982,'POST','/v2/accounts:revokeToken',Re(_0x285982,_0x15b2c5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x21bf2b){m(_0x21bf2b['idToken'],'internal-error'),m(typeof _0x21bf2b['idToken']<'u','internal-error'),m(typeof _0x21bf2b['refreshToken']<'u','internal-error');const _0x4bf6a8='expiresIn'in _0x21bf2b&&typeof _0x21bf2b['expiresIn']<'u'?Number(_0x21bf2b['expiresIn']):Er(_0x21bf2b['idToken']);this['updateTokensAndExpiration'](_0x21bf2b['idToken'],_0x21bf2b['refreshToken'],_0x4bf6a8);}['updateFromIdToken'](_0x3130e3){m(_0x3130e3['length']!==0x0,'internal-error');const _0x10b0f1=Er(_0x3130e3);this['updateTokensAndExpiration'](_0x3130e3,null,_0x10b0f1);}async['getToken'](_0x3cc28a,_0x27e270=!0x1){return!_0x27e270&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3cc28a,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3cc28a,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2f99f1,_0x171812){const {accessToken:_0x37bc56,refreshToken:_0x442ff9,expiresIn:_0xc39d46}=await yf(_0x2f99f1,_0x171812);this['updateTokensAndExpiration'](_0x37bc56,_0x442ff9,Number(_0xc39d46));}['updateTokensAndExpiration'](_0xd924df,_0x1fd7fa,_0x36effe){this['refreshToken']=_0x1fd7fa||null,this['accessToken']=_0xd924df||null,this['expirationTime']=Date['now']()+_0x36effe*0x3e8;}static['fromJSON'](_0x137ddf,_0x16ddb5){const {refreshToken:_0x4ffb35,accessToken:_0x3266ae,expirationTime:_0x2b313f}=_0x16ddb5,_0x3273c1=new Je();return _0x4ffb35&&(m(typeof _0x4ffb35=='string','internal-error',{'appName':_0x137ddf}),_0x3273c1['refreshToken']=_0x4ffb35),_0x3266ae&&(m(typeof _0x3266ae=='string','internal-error',{'appName':_0x137ddf}),_0x3273c1['accessToken']=_0x3266ae),_0x2b313f&&(m(typeof _0x2b313f=='number','internal-error',{'appName':_0x137ddf}),_0x3273c1['expirationTime']=_0x2b313f),_0x3273c1;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x109826){this['accessToken']=_0x109826['accessToken'],this['refreshToken']=_0x109826['refreshToken'],this['expirationTime']=_0x109826['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x2c52ef,_0x531b3d){m(typeof _0x2c52ef=='string'||typeof _0x2c52ef>'u','internal-error',{'appName':_0x531b3d});}class z{constructor({uid:_0x48b119,auth:_0x388e08,stsTokenManager:_0x377efc,..._0x36eafa}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x48b119,this['auth']=_0x388e08,this['stsTokenManager']=_0x377efc,this['accessToken']=_0x377efc['accessToken'],this['displayName']=_0x36eafa['displayName']||null,this['email']=_0x36eafa['email']||null,this['emailVerified']=_0x36eafa['emailVerified']||!0x1,this['phoneNumber']=_0x36eafa['phoneNumber']||null,this['photoURL']=_0x36eafa['photoURL']||null,this['isAnonymous']=_0x36eafa['isAnonymous']||!0x1,this['tenantId']=_0x36eafa['tenantId']||null,this['providerData']=_0x36eafa['providerData']?[..._0x36eafa['providerData']]:[],this['metadata']=new Pi(_0x36eafa['createdAt']||void 0x0,_0x36eafa['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4f3acb){const _0x50e498=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4f3acb));return m(_0x50e498,this['auth'],'internal-error'),this['accessToken']!==_0x50e498&&(this['accessToken']=_0x50e498,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x50e498;}['getIdTokenResult'](_0x463744){return ff(this,_0x463744);}['reload'](){return gf(this);}['_assign'](_0x154f26){this!==_0x154f26&&(m(this['uid']===_0x154f26['uid'],this['auth'],'internal-error'),this['displayName']=_0x154f26['displayName'],this['photoURL']=_0x154f26['photoURL'],this['email']=_0x154f26['email'],this['emailVerified']=_0x154f26['emailVerified'],this['phoneNumber']=_0x154f26['phoneNumber'],this['isAnonymous']=_0x154f26['isAnonymous'],this['tenantId']=_0x154f26['tenantId'],this['providerData']=_0x154f26['providerData']['map'](_0x33b086=>({..._0x33b086})),this['metadata']['_copy'](_0x154f26['metadata']),this['stsTokenManager']['_assign'](_0x154f26['stsTokenManager']));}['_clone'](_0xab38e9){const _0x390f7d=new z({...this,'auth':_0xab38e9,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x390f7d['metadata']['_copy'](this['metadata']),_0x390f7d;}['_onReload'](_0x290b1c){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x290b1c,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x45d9e7){this['reloadListener']?this['reloadListener'](_0x45d9e7):this['reloadUserInfo']=_0x45d9e7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5751dd,_0xc8b74f=!0x1){let _0x56bd19=!0x1;_0x5751dd['idToken']&&_0x5751dd['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5751dd),_0x56bd19=!0x0),_0xc8b74f&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x56bd19&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x42b13a=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x42b13a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x7fccd6=>({..._0x7fccd6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x34b2ff,_0x48443d){const _0x55cb1c=_0x48443d['displayName']??void 0x0,_0x5a03dc=_0x48443d['email']??void 0x0,_0x5a0535=_0x48443d['phoneNumber']??void 0x0,_0x270bc8=_0x48443d['photoURL']??void 0x0,_0x4fa38c=_0x48443d['tenantId']??void 0x0,_0x319e89=_0x48443d['_redirectEventId']??void 0x0,_0x5f58c9=_0x48443d['createdAt']??void 0x0,_0x2c1b8e=_0x48443d['lastLoginAt']??void 0x0,{uid:_0x45cd7f,emailVerified:_0x49a8c2,isAnonymous:_0x4ec2ee,providerData:_0x3188ca,stsTokenManager:_0xf259dd}=_0x48443d;m(_0x45cd7f&&_0xf259dd,_0x34b2ff,'internal-error');const _0x2b990b=Je['fromJSON'](this['name'],_0xf259dd);m(typeof _0x45cd7f=='string',_0x34b2ff,'internal-error'),ce(_0x55cb1c,_0x34b2ff['name']),ce(_0x5a03dc,_0x34b2ff['name']),m(typeof _0x49a8c2=='boolean',_0x34b2ff,'internal-error'),m(typeof _0x4ec2ee=='boolean',_0x34b2ff,'internal-error'),ce(_0x5a0535,_0x34b2ff['name']),ce(_0x270bc8,_0x34b2ff['name']),ce(_0x4fa38c,_0x34b2ff['name']),ce(_0x319e89,_0x34b2ff['name']),ce(_0x5f58c9,_0x34b2ff['name']),ce(_0x2c1b8e,_0x34b2ff['name']);const _0x51510b=new z({'uid':_0x45cd7f,'auth':_0x34b2ff,'email':_0x5a03dc,'emailVerified':_0x49a8c2,'displayName':_0x55cb1c,'isAnonymous':_0x4ec2ee,'photoURL':_0x270bc8,'phoneNumber':_0x5a0535,'tenantId':_0x4fa38c,'stsTokenManager':_0x2b990b,'createdAt':_0x5f58c9,'lastLoginAt':_0x2c1b8e});return _0x3188ca&&Array['isArray'](_0x3188ca)&&(_0x51510b['providerData']=_0x3188ca['map'](_0x409364=>({..._0x409364}))),_0x319e89&&(_0x51510b['_redirectEventId']=_0x319e89),_0x51510b;}static async['_fromIdTokenResponse'](_0x3351bb,_0x1db924,_0x246ac9=!0x1){const _0x4adfea=new Je();_0x4adfea['updateFromServerResponse'](_0x1db924);const _0x1972b5=new z({'uid':_0x1db924['localId'],'auth':_0x3351bb,'stsTokenManager':_0x4adfea,'isAnonymous':_0x246ac9});return await bn(_0x1972b5),_0x1972b5;}static async['_fromGetAccountInfoResponse'](_0x4851da,_0x45d2c3,_0x5e565d){const _0x2a5145=_0x45d2c3['users'][0x0];m(_0x2a5145['localId']!==void 0x0,'internal-error');const _0x42d707=_0x2a5145['providerUserInfo']!==void 0x0?wa(_0x2a5145['providerUserInfo']):[],_0x590839=!(_0x2a5145['email']&&_0x2a5145['passwordHash'])&&!(_0x42d707!=null&&_0x42d707['length']),_0x1defbb=new Je();_0x1defbb['updateFromIdToken'](_0x5e565d);const _0x2a7bc1=new z({'uid':_0x2a5145['localId'],'auth':_0x4851da,'stsTokenManager':_0x1defbb,'isAnonymous':_0x590839}),_0x184ac3={'uid':_0x2a5145['localId'],'displayName':_0x2a5145['displayName']||null,'photoURL':_0x2a5145['photoUrl']||null,'email':_0x2a5145['email']||null,'emailVerified':_0x2a5145['emailVerified']||!0x1,'phoneNumber':_0x2a5145['phoneNumber']||null,'tenantId':_0x2a5145['tenantId']||null,'providerData':_0x42d707,'metadata':new Pi(_0x2a5145['createdAt'],_0x2a5145['lastLoginAt']),'isAnonymous':!(_0x2a5145['email']&&_0x2a5145['passwordHash'])&&!(_0x42d707!=null&&_0x42d707['length'])};return Object['assign'](_0x2a7bc1,_0x184ac3),_0x2a7bc1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x3dbf9e){ae(_0x3dbf9e instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2cac40=Ir['get'](_0x3dbf9e);return _0x2cac40?(ae(_0x2cac40 instanceof _0x3dbf9e,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2cac40):(_0x2cac40=new _0x3dbf9e(),Ir['set'](_0x3dbf9e,_0x2cac40),_0x2cac40);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x809dc8,_0x5e47c1){this['storage'][_0x809dc8]=_0x5e47c1;}async['_get'](_0x243292){const _0xa99637=this['storage'][_0x243292];return _0xa99637===void 0x0?null:_0xa99637;}async['_remove'](_0x161181){delete this['storage'][_0x161181];}['_addListener'](_0x58031a,_0x393a67){}['_removeListener'](_0x1cfa3f,_0x1ece46){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x541abc,_0x1c2736,_0xf87d5a){return'firebase:'+_0x541abc+':'+_0x1c2736+':'+_0xf87d5a;}class Xe{constructor(_0x2ea09a,_0x19d59e,_0x263a36){this['persistence']=_0x2ea09a,this['auth']=_0x19d59e,this['userKey']=_0x263a36;const {config:_0x4fac79,name:_0x34a3d7}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x4fac79['apiKey'],_0x34a3d7),this['fullPersistenceKey']=sn('persistence',_0x4fac79['apiKey'],_0x34a3d7),this['boundEventHandler']=_0x19d59e['_onStorageEvent']['bind'](_0x19d59e),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x28518c){return this['persistence']['_set'](this['fullUserKey'],_0x28518c['toJSON']());}async['getCurrentUser'](){const _0x454cf4=await this['persistence']['_get'](this['fullUserKey']);if(!_0x454cf4)return null;if(typeof _0x454cf4=='string'){const _0x2700f5=await Sn(this['auth'],{'idToken':_0x454cf4})['catch'](()=>{});return _0x2700f5?z['_fromGetAccountInfoResponse'](this['auth'],_0x2700f5,_0x454cf4):null;}return z['_fromJSON'](this['auth'],_0x454cf4);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0xaaa9c8){if(this['persistence']===_0xaaa9c8)return;const _0xe87395=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0xaaa9c8,_0xe87395)return this['setCurrentUser'](_0xe87395);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5beb18,_0x3b39d9,_0x2372ed='authUser'){if(!_0x3b39d9['length'])return new Xe(ne(wr),_0x5beb18,_0x2372ed);const _0x584a6e=(await Promise['all'](_0x3b39d9['map'](async _0x131b82=>{if(await _0x131b82['_isAvailable']())return _0x131b82;})))['filter'](_0x5361d0=>_0x5361d0);let _0x3beaaf=_0x584a6e[0x0]||ne(wr);const _0x12c220=sn(_0x2372ed,_0x5beb18['config']['apiKey'],_0x5beb18['name']);let _0xe133dd=null;for(const _0x514417 of _0x3b39d9)try{const _0x2caef8=await _0x514417['_get'](_0x12c220);if(_0x2caef8){let _0x353326;if(typeof _0x2caef8=='string'){const _0x573b54=await Sn(_0x5beb18,{'idToken':_0x2caef8})['catch'](()=>{});if(!_0x573b54)break;_0x353326=await z['_fromGetAccountInfoResponse'](_0x5beb18,_0x573b54,_0x2caef8);}else _0x353326=z['_fromJSON'](_0x5beb18,_0x2caef8);_0x514417!==_0x3beaaf&&(_0xe133dd=_0x353326),_0x3beaaf=_0x514417;break;}}catch{}const _0x256011=_0x584a6e['filter'](_0x487581=>_0x487581['_shouldAllowMigration']);return!_0x3beaaf['_shouldAllowMigration']||!_0x256011['length']?new Xe(_0x3beaaf,_0x5beb18,_0x2372ed):(_0x3beaaf=_0x256011[0x0],_0xe133dd&&await _0x3beaaf['_set'](_0x12c220,_0xe133dd['toJSON']()),await Promise['all'](_0x3b39d9['map'](async _0x551f47=>{if(_0x551f47!==_0x3beaaf)try{await _0x551f47['_remove'](_0x12c220);}catch{}})),new Xe(_0x3beaaf,_0x5beb18,_0x2372ed));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0xade7b4){const _0x19b9d2=_0xade7b4['toLowerCase']();if(_0x19b9d2['includes']('opera/')||_0x19b9d2['includes']('opr/')||_0x19b9d2['includes']('opios/'))return'Opera';if(Ra(_0x19b9d2))return'IEMobile';if(_0x19b9d2['includes']('msie')||_0x19b9d2['includes']('trident/'))return'IE';if(_0x19b9d2['includes']('edge/'))return'Edge';if(Ta(_0x19b9d2))return'Firefox';if(_0x19b9d2['includes']('silk/'))return'Silk';if(ka(_0x19b9d2))return'Blackberry';if(Na(_0x19b9d2))return'Webos';if(Sa(_0x19b9d2))return'Safari';if((_0x19b9d2['includes']('chrome/')||ba(_0x19b9d2))&&!_0x19b9d2['includes']('edge/'))return'Chrome';if(Aa(_0x19b9d2))return'Android';{const _0x23b469=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x250427=_0xade7b4['match'](_0x23b469);if((_0x250427==null?void 0x0:_0x250427['length'])===0x2)return _0x250427[0x1];}return'Other';}function Ta(_0x56b12d=W()){return/firefox\//i['test'](_0x56b12d);}function Sa(_0x407d6d=W()){const _0x28a3e8=_0x407d6d['toLowerCase']();return _0x28a3e8['includes']('safari/')&&!_0x28a3e8['includes']('chrome/')&&!_0x28a3e8['includes']('crios/')&&!_0x28a3e8['includes']('android');}function ba(_0x42638=W()){return/crios\//i['test'](_0x42638);}function Ra(_0x49a821=W()){return/iemobile/i['test'](_0x49a821);}function Aa(_0xf1851=W()){return/android/i['test'](_0xf1851);}function ka(_0x441354=W()){return/blackberry/i['test'](_0x441354);}function Na(_0x4888ec=W()){return/webos/i['test'](_0x4888ec);}function Cs(_0x18540c=W()){return/iphone|ipad|ipod/i['test'](_0x18540c)||/macintosh/i['test'](_0x18540c)&&/mobile/i['test'](_0x18540c);}function Ef(_0x420732=W()){var _0x2cc062;return Cs(_0x420732)&&!!((_0x2cc062=window['navigator'])!=null&&_0x2cc062['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x40a1d3=W()){return Cs(_0x40a1d3)||Aa(_0x40a1d3)||Na(_0x40a1d3)||ka(_0x40a1d3)||/windows phone/i['test'](_0x40a1d3)||Ra(_0x40a1d3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x43e60c,_0x253fcd=[]){let _0x2c8c73;switch(_0x43e60c){case'Browser':_0x2c8c73=Cr(W());break;case'Worker':_0x2c8c73=Cr(W())+'-'+_0x43e60c;break;default:_0x2c8c73=_0x43e60c;}const _0x3ae7ed=_0x253fcd['length']?_0x253fcd['join'](','):'FirebaseCore-web';return _0x2c8c73+'/JsCore/'+ct+'/'+_0x3ae7ed;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5d5739){this['auth']=_0x5d5739,this['queue']=[];}['pushCallback'](_0x5718e1,_0x2913a6){const _0x33edf4=_0xb02606=>new Promise((_0x9e2116,_0x21a09e)=>{try{const _0x454f3e=_0x5718e1(_0xb02606);_0x9e2116(_0x454f3e);}catch(_0x584789){_0x21a09e(_0x584789);}});_0x33edf4['onAbort']=_0x2913a6,this['queue']['push'](_0x33edf4);const _0x4c4611=this['queue']['length']-0x1;return()=>{this['queue'][_0x4c4611]=()=>Promise['resolve']();};}async['runMiddleware'](_0x420814){if(this['auth']['currentUser']===_0x420814)return;const _0x579926=[];try{for(const _0x48506c of this['queue'])await _0x48506c(_0x420814),_0x48506c['onAbort']&&_0x579926['push'](_0x48506c['onAbort']);}catch(_0x40542d){_0x579926['reverse']();for(const _0x5a7e47 of _0x579926)try{_0x5a7e47();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x40542d==null?void 0x0:_0x40542d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5d724a,_0x30b595={}){return Ae(_0x5d724a,'GET','/v2/passwordPolicy',Re(_0x5d724a,_0x30b595));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x78f85){var _0x3cfbcb;const _0xa6a50=_0x78f85['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xa6a50['minPasswordLength']??Tf,_0xa6a50['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xa6a50['maxPasswordLength']),_0xa6a50['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xa6a50['containsLowercaseCharacter']),_0xa6a50['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xa6a50['containsUppercaseCharacter']),_0xa6a50['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xa6a50['containsNumericCharacter']),_0xa6a50['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xa6a50['containsNonAlphanumericCharacter']),this['enforcementState']=_0x78f85['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3cfbcb=_0x78f85['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3cfbcb['join'](''))??'',this['forceUpgradeOnSignin']=_0x78f85['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x78f85['schemaVersion'];}['validatePassword'](_0x3016f7){const _0x2ddd2a={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x3016f7,_0x2ddd2a),this['validatePasswordCharacterOptions'](_0x3016f7,_0x2ddd2a),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['meetsMinPasswordLength']??!0x0),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['meetsMaxPasswordLength']??!0x0),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['containsLowercaseLetter']??!0x0),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['containsUppercaseLetter']??!0x0),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['containsNumericCharacter']??!0x0),_0x2ddd2a['isValid']&&(_0x2ddd2a['isValid']=_0x2ddd2a['containsNonAlphanumericCharacter']??!0x0),_0x2ddd2a;}['validatePasswordLengthOptions'](_0x296e11,_0xde6f9d){const _0x5521ae=this['customStrengthOptions']['minPasswordLength'],_0x3a7fb9=this['customStrengthOptions']['maxPasswordLength'];_0x5521ae&&(_0xde6f9d['meetsMinPasswordLength']=_0x296e11['length']>=_0x5521ae),_0x3a7fb9&&(_0xde6f9d['meetsMaxPasswordLength']=_0x296e11['length']<=_0x3a7fb9);}['validatePasswordCharacterOptions'](_0x215b8e,_0x5a6287){this['updatePasswordCharacterOptionsStatuses'](_0x5a6287,!0x1,!0x1,!0x1,!0x1);let _0x76826f;for(let _0x3516ca=0x0;_0x3516ca<_0x215b8e['length'];_0x3516ca++)_0x76826f=_0x215b8e['charAt'](_0x3516ca),this['updatePasswordCharacterOptionsStatuses'](_0x5a6287,_0x76826f>='a'&&_0x76826f<='z',_0x76826f>='A'&&_0x76826f<='Z',_0x76826f>='0'&&_0x76826f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x76826f));}['updatePasswordCharacterOptionsStatuses'](_0x423c87,_0x33e646,_0x59b5f3,_0x34150d,_0x148db1){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x423c87['containsLowercaseLetter']||(_0x423c87['containsLowercaseLetter']=_0x33e646)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x423c87['containsUppercaseLetter']||(_0x423c87['containsUppercaseLetter']=_0x59b5f3)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x423c87['containsNumericCharacter']||(_0x423c87['containsNumericCharacter']=_0x34150d)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x423c87['containsNonAlphanumericCharacter']||(_0x423c87['containsNonAlphanumericCharacter']=_0x148db1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x23827b,_0x13510b,_0x10b3f6,_0x388514){this['app']=_0x23827b,this['heartbeatServiceProvider']=_0x13510b,this['appCheckServiceProvider']=_0x10b3f6,this['config']=_0x388514,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x23827b['name'],this['clientVersion']=_0x388514['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x577ff6=>this['_resolvePersistenceManagerAvailable']=_0x577ff6);}['_initializeWithPersistence'](_0xb9975e,_0x285d70){return _0x285d70&&(this['_popupRedirectResolver']=ne(_0x285d70)),this['_initializationPromise']=this['queue'](async()=>{var _0x56d7fc,_0x330ccd,_0x815c2d;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0xb9975e),(_0x56d7fc=this['_resolvePersistenceManagerAvailable'])==null||_0x56d7fc['call'](this),!this['_deleted'])){if((_0x330ccd=this['_popupRedirectResolver'])!=null&&_0x330ccd['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x285d70),this['lastNotifiedUid']=((_0x815c2d=this['currentUser'])==null?void 0x0:_0x815c2d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xb8d975=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xb8d975)){if(this['currentUser']&&_0xb8d975&&this['currentUser']['uid']===_0xb8d975['uid']){this['_currentUser']['_assign'](_0xb8d975),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xb8d975,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1d3ed5){try{const _0x57bbb0=await Sn(this,{'idToken':_0x1d3ed5}),_0x1edb0f=await z['_fromGetAccountInfoResponse'](this,_0x57bbb0,_0x1d3ed5);await this['directlySetCurrentUser'](_0x1edb0f);}catch(_0xab76eb){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xab76eb),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x66fa92){var _0x56e1d4;if(H(this['app'])){const _0xa56f65=this['app']['settings']['authIdToken'];return _0xa56f65?new Promise(_0x141668=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xa56f65)['then'](_0x141668,_0x141668));}):this['directlySetCurrentUser'](null);}const _0x4e51ba=await this['assertedPersistence']['getCurrentUser']();let _0x1ae5d7=_0x4e51ba,_0x1df0e3=!0x1;if(_0x66fa92&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1a7738=(_0x56e1d4=this['redirectUser'])==null?void 0x0:_0x56e1d4['_redirectEventId'],_0x4ce00c=_0x1ae5d7==null?void 0x0:_0x1ae5d7['_redirectEventId'],_0x58e809=await this['tryRedirectSignIn'](_0x66fa92);(!_0x1a7738||_0x1a7738===_0x4ce00c)&&(_0x58e809!=null&&_0x58e809['user'])&&(_0x1ae5d7=_0x58e809['user'],_0x1df0e3=!0x0);}if(!_0x1ae5d7)return this['directlySetCurrentUser'](null);if(!_0x1ae5d7['_redirectEventId']){if(_0x1df0e3)try{await this['beforeStateQueue']['runMiddleware'](_0x1ae5d7);}catch(_0x3ddb35){_0x1ae5d7=_0x4e51ba,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3ddb35));}return _0x1ae5d7?this['reloadAndSetCurrentUserOrClear'](_0x1ae5d7):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1ae5d7['_redirectEventId']?this['directlySetCurrentUser'](_0x1ae5d7):this['reloadAndSetCurrentUserOrClear'](_0x1ae5d7);}async['tryRedirectSignIn'](_0x44aacd){let _0x22a501=null;try{_0x22a501=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x44aacd,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x22a501;}async['reloadAndSetCurrentUserOrClear'](_0x5385bd){try{await bn(_0x5385bd);}catch(_0x283013){if((_0x283013==null?void 0x0:_0x283013['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5385bd);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x4a71fe){if(H(this['app']))return Promise['reject'](se(this));const _0x16a56e=_0x4a71fe?k(_0x4a71fe):null;return _0x16a56e&&m(_0x16a56e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x16a56e&&_0x16a56e['_clone'](this));}async['_updateCurrentUser'](_0xa2cac8,_0x1be0d1=!0x1){if(!this['_deleted'])return _0xa2cac8&&m(this['tenantId']===_0xa2cac8['tenantId'],this,'tenant-id-mismatch'),_0x1be0d1||await this['beforeStateQueue']['runMiddleware'](_0xa2cac8),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xa2cac8),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x18910f){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x18910f));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x324c8f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x16b725=this['_getPasswordPolicyInternal']();return _0x16b725['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x16b725['validatePassword'](_0x324c8f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x6e7565=await Cf(this),_0x3a538e=new Sf(_0x6e7565);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3a538e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3a538e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x270318){this['_errorFactory']=new Ut('auth','Firebase',_0x270318());}['onAuthStateChanged'](_0x37334b,_0x537966,_0x487c73){return this['registerStateListener'](this['authStateSubscription'],_0x37334b,_0x537966,_0x487c73);}['beforeAuthStateChanged'](_0xd1ba53,_0x17574f){return this['beforeStateQueue']['pushCallback'](_0xd1ba53,_0x17574f);}['onIdTokenChanged'](_0x2d4e21,_0x1e60e6,_0xbf2016){return this['registerStateListener'](this['idTokenSubscription'],_0x2d4e21,_0x1e60e6,_0xbf2016);}['authStateReady'](){return new Promise((_0x62f617,_0x5b9abc)=>{if(this['currentUser'])_0x62f617();else{const _0x432a64=this['onAuthStateChanged'](()=>{_0x432a64(),_0x62f617();},_0x5b9abc);}});}async['revokeAccessToken'](_0x564f5a){if(this['currentUser']){const _0x4f8210=await this['currentUser']['getIdToken'](),_0x3c7b2f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x564f5a,'idToken':_0x4f8210};this['tenantId']!=null&&(_0x3c7b2f['tenantId']=this['tenantId']),await vf(this,_0x3c7b2f);}}['toJSON'](){var _0x57ab97;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x57ab97=this['_currentUser'])==null?void 0x0:_0x57ab97['toJSON']()};}async['_setRedirectUser'](_0x502988,_0x5010d0){const _0x321acb=await this['getOrInitRedirectPersistenceManager'](_0x5010d0);return _0x502988===null?_0x321acb['removeCurrentUser']():_0x321acb['setCurrentUser'](_0x502988);}async['getOrInitRedirectPersistenceManager'](_0x2ccfaa){if(!this['redirectPersistenceManager']){const _0x1b8e1d=_0x2ccfaa&&ne(_0x2ccfaa)||this['_popupRedirectResolver'];m(_0x1b8e1d,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x1b8e1d['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x32b2a3){var _0x18e448,_0x25eb32;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x18e448=this['_currentUser'])==null?void 0x0:_0x18e448['_redirectEventId'])===_0x32b2a3?this['_currentUser']:((_0x25eb32=this['redirectUser'])==null?void 0x0:_0x25eb32['_redirectEventId'])===_0x32b2a3?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2257b1){if(_0x2257b1===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2257b1));}['_notifyListenersIfCurrent'](_0x4bb9fb){_0x4bb9fb===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2628fe;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5f55f6=((_0x2628fe=this['currentUser'])==null?void 0x0:_0x2628fe['uid'])??null;this['lastNotifiedUid']!==_0x5f55f6&&(this['lastNotifiedUid']=_0x5f55f6,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x46d5fc,_0x56b106,_0x65679c,_0x2f5653){if(this['_deleted'])return()=>{};const _0x1c517f=typeof _0x56b106=='function'?_0x56b106:_0x56b106['next']['bind'](_0x56b106);let _0x4b2f69=!0x1;const _0x44670=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x44670,this,'internal-error'),_0x44670['then'](()=>{_0x4b2f69||_0x1c517f(this['currentUser']);}),typeof _0x56b106=='function'){const _0x4e8ed8=_0x46d5fc['addObserver'](_0x56b106,_0x65679c,_0x2f5653);return()=>{_0x4b2f69=!0x0,_0x4e8ed8();};}else{const _0x278c79=_0x46d5fc['addObserver'](_0x56b106);return()=>{_0x4b2f69=!0x0,_0x278c79();};}}async['directlySetCurrentUser'](_0x20e873){this['currentUser']&&this['currentUser']!==_0x20e873&&this['_currentUser']['_stopProactiveRefresh'](),_0x20e873&&this['isProactiveRefreshEnabled']&&_0x20e873['_startProactiveRefresh'](),this['currentUser']=_0x20e873,_0x20e873?await this['assertedPersistence']['setCurrentUser'](_0x20e873):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x39fb47){return this['operations']=this['operations']['then'](_0x39fb47,_0x39fb47),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x15858a){!_0x15858a||this['frameworks']['includes'](_0x15858a)||(this['frameworks']['push'](_0x15858a),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x9d5a4b;const _0x439f0a={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x439f0a['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4f3c5e=await((_0x9d5a4b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x9d5a4b['getHeartbeatsHeader']());_0x4f3c5e&&(_0x439f0a['X-Firebase-Client']=_0x4f3c5e);const _0x4b234f=await this['_getAppCheckToken']();return _0x4b234f&&(_0x439f0a['X-Firebase-AppCheck']=_0x4b234f),_0x439f0a;}async['_getAppCheckToken'](){var _0x5a941a;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5ebe0f=await((_0x5a941a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a941a['getToken']());return _0x5ebe0f!=null&&_0x5ebe0f['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5ebe0f['error']),_0x5ebe0f==null?void 0x0:_0x5ebe0f['token'];}}function qe(_0xf86edb){return k(_0xf86edb);}class Tr{constructor(_0x4feb8c){this['auth']=_0x4feb8c,this['observer']=null,this['addObserver']=Ic(_0xa098c1=>this['observer']=_0xa098c1);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x34725e){zn=_0x34725e;}function Da(_0x1c371a){return zn['loadJS'](_0x1c371a);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x584476){return'__'+_0x584476+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x4b1fec){_0x4b1fec();}['execute'](_0x1d29b0,_0x75059f){return Promise['resolve']('token');}['render'](_0x1b2624,_0x59a9a1){return'';}}class Of{['ready'](_0x4faa1f){_0x4faa1f();}['execute'](_0x403255,_0x1b0501){return Promise['resolve']('token');}['render'](_0x36866a,_0x232299){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x262f77){this['type']=Df,this['auth']=qe(_0x262f77);}async['verify'](_0x24085b='verify',_0x584ed1=!0x1){async function _0x50434a(_0x4e968b){if(!_0x584ed1){if(_0x4e968b['tenantId']==null&&_0x4e968b['_agentRecaptchaConfig']!=null)return _0x4e968b['_agentRecaptchaConfig']['siteKey'];if(_0x4e968b['tenantId']!=null&&_0x4e968b['_tenantRecaptchaConfigs'][_0x4e968b['tenantId']]!==void 0x0)return _0x4e968b['_tenantRecaptchaConfigs'][_0x4e968b['tenantId']]['siteKey'];}return new Promise(async(_0x4cf2e5,_0x4f6ef2)=>{uf(_0x4e968b,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3a6d12=>{if(_0x3a6d12['recaptchaKey']===void 0x0)_0x4f6ef2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x50698b=new hf(_0x3a6d12);return _0x4e968b['tenantId']==null?_0x4e968b['_agentRecaptchaConfig']=_0x50698b:_0x4e968b['_tenantRecaptchaConfigs'][_0x4e968b['tenantId']]=_0x50698b,_0x4cf2e5(_0x50698b['siteKey']);}})['catch'](_0xdbd32=>{_0x4f6ef2(_0xdbd32);});});}function _0x67467b(_0x29238e,_0x4f8d5e,_0x2fda0c){const _0xdea86=window['grecaptcha'];vr(_0xdea86)?_0xdea86['enterprise']['ready'](()=>{_0xdea86['enterprise']['execute'](_0x29238e,{'action':_0x24085b})['then'](_0x2a2d63=>{_0x4f8d5e(_0x2a2d63);})['catch'](()=>{_0x4f8d5e(Ma);});}):_0x2fda0c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x26d08d,_0x1104b0)=>{_0x50434a(this['auth'])['then'](async _0x3cc74f=>{if(!_0x584ed1&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x67467b(_0x3cc74f,_0x26d08d,_0x1104b0);else{if(typeof window>'u'){_0x1104b0(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x473d63=Af();_0x473d63['length']!==0x0&&(_0x473d63+=_0x3cc74f+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x12d78d;(_0x12d78d=le['scriptInjectionDeferred'])==null||_0x12d78d['resolve']();},Da(_0x473d63)['then'](()=>{var _0x24d185;return(_0x24d185=le['scriptInjectionDeferred'])==null?void 0x0:_0x24d185['promise'];})['then'](()=>{_0x67467b(_0x3cc74f,_0x26d08d,_0x1104b0);})['catch'](_0x1c2d57=>{_0x1104b0(_0x1c2d57);});}})['catch'](_0x3d77ea=>{_0x1104b0(_0x3d77ea);});});}}le['scriptInjectionDeferred']=null;async function br(_0x1dabac,_0x2e9e63,_0xea4f81,_0xa04f99=!0x1,_0x2634e2=!0x1){const _0x488797=new le(_0x1dabac);let _0x41cfdb;if(_0x2634e2)_0x41cfdb=Ma;else try{_0x41cfdb=await _0x488797['verify'](_0xea4f81);}catch{_0x41cfdb=await _0x488797['verify'](_0xea4f81,!0x0);}const _0x5a9c17={..._0x2e9e63};if(_0xea4f81==='mfaSmsEnrollment'||_0xea4f81==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5a9c17){const _0x32c8dd=_0x5a9c17['phoneEnrollmentInfo']['phoneNumber'],_0x27ae97=_0x5a9c17['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5a9c17,{'phoneEnrollmentInfo':{'phoneNumber':_0x32c8dd,'recaptchaToken':_0x27ae97,'captchaResponse':_0x41cfdb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5a9c17){const _0x29ca4f=_0x5a9c17['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5a9c17,{'phoneSignInInfo':{'recaptchaToken':_0x29ca4f,'captchaResponse':_0x41cfdb,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5a9c17;}return _0xa04f99?Object['assign'](_0x5a9c17,{'captchaResp':_0x41cfdb}):Object['assign'](_0x5a9c17,{'captchaResponse':_0x41cfdb}),Object['assign'](_0x5a9c17,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5a9c17,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5a9c17;}async function Oi(_0x3c0db3,_0x5ff620,_0x1cd53e,_0x1feac7,_0x117cd0){var _0x12dbfd;if((_0x12dbfd=_0x3c0db3['_getRecaptchaConfig']())!=null&&_0x12dbfd['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3eb7d3=await br(_0x3c0db3,_0x5ff620,_0x1cd53e,_0x1cd53e==='getOobCode');return _0x1feac7(_0x3c0db3,_0x3eb7d3);}else return _0x1feac7(_0x3c0db3,_0x5ff620)['catch'](async _0x76ee5f=>{if(_0x76ee5f['code']==='auth/missing-recaptcha-token'){console['log'](_0x1cd53e+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3c0fb9=await br(_0x3c0db3,_0x5ff620,_0x1cd53e,_0x1cd53e==='getOobCode');return _0x1feac7(_0x3c0db3,_0x3c0fb9);}else return Promise['reject'](_0x76ee5f);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x3f22b1,_0x48502c){const _0x5c3a95=Ui(_0x3f22b1,'auth');if(_0x5c3a95['isInitialized']()){const _0x89bab6=_0x5c3a95['getImmediate'](),_0x19696d=_0x5c3a95['getOptions']();if(De(_0x19696d,_0x48502c??{}))return _0x89bab6;K(_0x89bab6,'already-initialized');}return _0x5c3a95['initialize']({'options':_0x48502c});}function Lf(_0x2974d1,_0x33f9ab){const _0x295147=(_0x33f9ab==null?void 0x0:_0x33f9ab['persistence'])||[],_0x14a8bf=(Array['isArray'](_0x295147)?_0x295147:[_0x295147])['map'](ne);_0x33f9ab!=null&&_0x33f9ab['errorMap']&&_0x2974d1['_updateErrorMap'](_0x33f9ab['errorMap']),_0x2974d1['_initializeWithPersistence'](_0x14a8bf,_0x33f9ab==null?void 0x0:_0x33f9ab['popupRedirectResolver']);}function xf(_0x2fadcd,_0x6c18ff,_0x16fd08){const _0x147dc5=qe(_0x2fadcd);m(/^https?:\/\//['test'](_0x6c18ff),_0x147dc5,'invalid-emulator-scheme');const _0xdf45f8=!0x1,_0x44eb04=La(_0x6c18ff),{host:_0x518dc6,port:_0x2648ab}=Ff(_0x6c18ff),_0x80e084=_0x2648ab===null?'':':'+_0x2648ab,_0x268724={'url':_0x44eb04+'//'+_0x518dc6+_0x80e084+'/'},_0x55821b=Object['freeze']({'host':_0x518dc6,'port':_0x2648ab,'protocol':_0x44eb04['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0xdf45f8})});if(!_0x147dc5['_canInitEmulator']){m(_0x147dc5['config']['emulator']&&_0x147dc5['emulatorConfig'],_0x147dc5,'emulator-config-failed'),m(De(_0x268724,_0x147dc5['config']['emulator'])&&De(_0x55821b,_0x147dc5['emulatorConfig']),_0x147dc5,'emulator-config-failed');return;}_0x147dc5['config']['emulator']=_0x268724,_0x147dc5['emulatorConfig']=_0x55821b,_0x147dc5['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x518dc6)?jr(_0x44eb04+'//'+_0x518dc6+_0x80e084):Uf();}function La(_0x544b1a){const _0x3ac2f3=_0x544b1a['indexOf'](':');return _0x3ac2f3<0x0?'':_0x544b1a['substr'](0x0,_0x3ac2f3+0x1);}function Ff(_0x3283c3){const _0x4d6a74=La(_0x3283c3),_0x5db951=/(\/\/)?([^?#/]+)/['exec'](_0x3283c3['substr'](_0x4d6a74['length']));if(!_0x5db951)return{'host':'','port':null};const _0x70f2da=_0x5db951[0x2]['split']('@')['pop']()||'',_0x38c7ff=/^(\[[^\]]+\])(:|$)/['exec'](_0x70f2da);if(_0x38c7ff){const _0x86aaba=_0x38c7ff[0x1];return{'host':_0x86aaba,'port':Rr(_0x70f2da['substr'](_0x86aaba['length']+0x1))};}else{const [_0x1d7121,_0x219315]=_0x70f2da['split'](':');return{'host':_0x1d7121,'port':Rr(_0x219315)};}}function Rr(_0x42785a){if(!_0x42785a)return null;const _0x346ec4=Number(_0x42785a);return isNaN(_0x346ec4)?null:_0x346ec4;}function Uf(){function _0x120b8c(){const _0x1ed937=document['createElement']('p'),_0x1d2f0e=_0x1ed937['style'];_0x1ed937['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1d2f0e['position']='fixed',_0x1d2f0e['width']='100%',_0x1d2f0e['backgroundColor']='#ffffff',_0x1d2f0e['border']='.1em\x20solid\x20#000000',_0x1d2f0e['color']='#b50000',_0x1d2f0e['bottom']='0px',_0x1d2f0e['left']='0px',_0x1d2f0e['margin']='0px',_0x1d2f0e['zIndex']='10000',_0x1d2f0e['textAlign']='center',_0x1ed937['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1ed937);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x120b8c):_0x120b8c());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x4601a2,_0x2240f6){this['providerId']=_0x4601a2,this['signInMethod']=_0x2240f6;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x57f89a){return te('not\x20implemented');}['_linkToIdToken'](_0x38bc1a,_0x15a782){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1c1f9e){return te('not\x20implemented');}}async function Wf(_0x2ab76f,_0x299452){return Ae(_0x2ab76f,'POST','/v1/accounts:signUp',_0x299452);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x23e686,_0x397987){return Yt(_0x23e686,'POST','/v1/accounts:signInWithPassword',Re(_0x23e686,_0x397987));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x2a890e,_0x15e1eb){return Yt(_0x2a890e,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2a890e,_0x15e1eb));}async function Hf(_0x3a4ef0,_0x3b280e){return Yt(_0x3a4ef0,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3a4ef0,_0x3b280e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x535a08,_0x3ca357,_0x189090,_0x40a5ec=null){super('password',_0x189090),this['_email']=_0x535a08,this['_password']=_0x3ca357,this['_tenantId']=_0x40a5ec;}static['_fromEmailAndPassword'](_0x48121b,_0x298643){return new Ft(_0x48121b,_0x298643,'password');}static['_fromEmailAndCode'](_0x3780b5,_0x21939f,_0x2e251e=null){return new Ft(_0x3780b5,_0x21939f,'emailLink',_0x2e251e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x413a8a){const _0xc78b6=typeof _0x413a8a=='string'?JSON['parse'](_0x413a8a):_0x413a8a;if(_0xc78b6!=null&&_0xc78b6['email']&&(_0xc78b6!=null&&_0xc78b6['password'])){if(_0xc78b6['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xc78b6['email'],_0xc78b6['password']);if(_0xc78b6['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xc78b6['email'],_0xc78b6['password'],_0xc78b6['tenantId']);}return null;}async['_getIdTokenResponse'](_0x144083){switch(this['signInMethod']){case'password':const _0x35976f={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x144083,_0x35976f,'signInWithPassword',Bf);case'emailLink':return Vf(_0x144083,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x144083,'internal-error');}}async['_linkToIdToken'](_0xf90676,_0x2491be){switch(this['signInMethod']){case'password':const _0x21eed5={'idToken':_0x2491be,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0xf90676,_0x21eed5,'signUpPassword',Wf);case'emailLink':return Hf(_0xf90676,{'idToken':_0x2491be,'email':this['_email'],'oobCode':this['_password']});default:K(_0xf90676,'internal-error');}}['_getReauthenticationResolver'](_0x467258){return this['_getIdTokenResponse'](_0x467258);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x358365,_0x12b069){return Yt(_0x358365,'POST','/v1/accounts:signInWithIdp',Re(_0x358365,_0x12b069));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2f4618){const _0x20f36d=new We(_0x2f4618['providerId'],_0x2f4618['signInMethod']);return _0x2f4618['idToken']||_0x2f4618['accessToken']?(_0x2f4618['idToken']&&(_0x20f36d['idToken']=_0x2f4618['idToken']),_0x2f4618['accessToken']&&(_0x20f36d['accessToken']=_0x2f4618['accessToken']),_0x2f4618['nonce']&&!_0x2f4618['pendingToken']&&(_0x20f36d['nonce']=_0x2f4618['nonce']),_0x2f4618['pendingToken']&&(_0x20f36d['pendingToken']=_0x2f4618['pendingToken'])):_0x2f4618['oauthToken']&&_0x2f4618['oauthTokenSecret']?(_0x20f36d['accessToken']=_0x2f4618['oauthToken'],_0x20f36d['secret']=_0x2f4618['oauthTokenSecret']):K('argument-error'),_0x20f36d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x51e2f0){const _0x43e72d=typeof _0x51e2f0=='string'?JSON['parse'](_0x51e2f0):_0x51e2f0,{providerId:_0x370fc1,signInMethod:_0x3e1b2f,..._0x27ac2e}=_0x43e72d;if(!_0x370fc1||!_0x3e1b2f)return null;const _0x3c6763=new We(_0x370fc1,_0x3e1b2f);return _0x3c6763['idToken']=_0x27ac2e['idToken']||void 0x0,_0x3c6763['accessToken']=_0x27ac2e['accessToken']||void 0x0,_0x3c6763['secret']=_0x27ac2e['secret'],_0x3c6763['nonce']=_0x27ac2e['nonce'],_0x3c6763['pendingToken']=_0x27ac2e['pendingToken']||null,_0x3c6763;}['_getIdTokenResponse'](_0x41f22d){const _0x21c914=this['buildRequest']();return Ze(_0x41f22d,_0x21c914);}['_linkToIdToken'](_0x42617e,_0x4863d7){const _0x584d28=this['buildRequest']();return _0x584d28['idToken']=_0x4863d7,Ze(_0x42617e,_0x584d28);}['_getReauthenticationResolver'](_0x164dbc){const _0x4e946a=this['buildRequest']();return _0x4e946a['autoCreate']=!0x1,Ze(_0x164dbc,_0x4e946a);}['buildRequest'](){const _0x22f2d1={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x22f2d1['pendingToken']=this['pendingToken'];else{const _0x1d45a3={};this['idToken']&&(_0x1d45a3['id_token']=this['idToken']),this['accessToken']&&(_0x1d45a3['access_token']=this['accessToken']),this['secret']&&(_0x1d45a3['oauth_token_secret']=this['secret']),_0x1d45a3['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1d45a3['nonce']=this['nonce']),_0x22f2d1['postBody']=at(_0x1d45a3);}return _0x22f2d1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1179aa){switch(_0x1179aa){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x39930e){const _0x476b8d=yt(vt(_0x39930e))['link'],_0xea9986=_0x476b8d?yt(vt(_0x476b8d))['deep_link_id']:null,_0x13d864=yt(vt(_0x39930e))['deep_link_id'];return(_0x13d864?yt(vt(_0x13d864))['link']:null)||_0x13d864||_0xea9986||_0x476b8d||_0x39930e;}class Ss{constructor(_0x4599b7){const _0x18714b=yt(vt(_0x4599b7)),_0xd03779=_0x18714b['apiKey']??null,_0x58ab9a=_0x18714b['oobCode']??null,_0x3f355a=Gf(_0x18714b['mode']??null);m(_0xd03779&&_0x58ab9a&&_0x3f355a,'argument-error'),this['apiKey']=_0xd03779,this['operation']=_0x3f355a,this['code']=_0x58ab9a,this['continueUrl']=_0x18714b['continueUrl']??null,this['languageCode']=_0x18714b['lang']??null,this['tenantId']=_0x18714b['tenantId']??null;}static['parseLink'](_0x5ee23c){const _0x107a7f=qf(_0x5ee23c);try{return new Ss(_0x107a7f);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x39a30a,_0x22802f){return Ft['_fromEmailAndPassword'](_0x39a30a,_0x22802f);}static['credentialWithLink'](_0x54f086,_0x3c13bd){const _0x316eb7=Ss['parseLink'](_0x3c13bd);return m(_0x316eb7,'argument-error'),Ft['_fromEmailAndCode'](_0x54f086,_0x316eb7['code'],_0x316eb7['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x43623c){this['providerId']=_0x43623c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x55e441){this['defaultLanguageCode']=_0x55e441;}['setCustomParameters'](_0x2bc350){return this['customParameters']=_0x2bc350,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x503bd1){return this['scopes']['includes'](_0x503bd1)||this['scopes']['push'](_0x503bd1),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x27da8e){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x27da8e});}static['credentialFromResult'](_0x3f8479){return he['credentialFromTaggedObject'](_0x3f8479);}static['credentialFromError'](_0xbb37b0){return he['credentialFromTaggedObject'](_0xbb37b0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x32b451}){if(!_0x32b451||!('oauthAccessToken'in _0x32b451)||!_0x32b451['oauthAccessToken'])return null;try{return he['credential'](_0x32b451['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3e8d54,_0x3fe399){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3e8d54,'accessToken':_0x3fe399});}static['credentialFromResult'](_0x26a1a4){return ue['credentialFromTaggedObject'](_0x26a1a4);}static['credentialFromError'](_0x321c43){return ue['credentialFromTaggedObject'](_0x321c43['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x12ba6b}){if(!_0x12ba6b)return null;const {oauthIdToken:_0x39237f,oauthAccessToken:_0x361a3a}=_0x12ba6b;if(!_0x39237f&&!_0x361a3a)return null;try{return ue['credential'](_0x39237f,_0x361a3a);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x4b2203){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4b2203});}static['credentialFromResult'](_0x4c3cff){return de['credentialFromTaggedObject'](_0x4c3cff);}static['credentialFromError'](_0x154c62){return de['credentialFromTaggedObject'](_0x154c62['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4796ee}){if(!_0x4796ee||!('oauthAccessToken'in _0x4796ee)||!_0x4796ee['oauthAccessToken'])return null;try{return de['credential'](_0x4796ee['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2341f3,_0x4ac850){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2341f3,'oauthTokenSecret':_0x4ac850});}static['credentialFromResult'](_0x359f87){return fe['credentialFromTaggedObject'](_0x359f87);}static['credentialFromError'](_0x3733d6){return fe['credentialFromTaggedObject'](_0x3733d6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2efae3}){if(!_0x2efae3)return null;const {oauthAccessToken:_0x19e0ad,oauthTokenSecret:_0x671408}=_0x2efae3;if(!_0x19e0ad||!_0x671408)return null;try{return fe['credential'](_0x19e0ad,_0x671408);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3f703d,_0x509fe8){return Yt(_0x3f703d,'POST','/v1/accounts:signUp',Re(_0x3f703d,_0x509fe8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4467df){this['user']=_0x4467df['user'],this['providerId']=_0x4467df['providerId'],this['_tokenResponse']=_0x4467df['_tokenResponse'],this['operationType']=_0x4467df['operationType'];}static async['_fromIdTokenResponse'](_0x477696,_0x21560c,_0x507c62,_0x45b2ab=!0x1){const _0x86ae9c=await z['_fromIdTokenResponse'](_0x477696,_0x507c62,_0x45b2ab),_0x1a0920=Ar(_0x507c62);return new Be({'user':_0x86ae9c,'providerId':_0x1a0920,'_tokenResponse':_0x507c62,'operationType':_0x21560c});}static async['_forOperation'](_0x1682f1,_0x39fed6,_0x143781){await _0x1682f1['_updateTokensIfNecessary'](_0x143781,!0x0);const _0x44a951=Ar(_0x143781);return new Be({'user':_0x1682f1,'providerId':_0x44a951,'_tokenResponse':_0x143781,'operationType':_0x39fed6});}}function Ar(_0x2699d7){return _0x2699d7['providerId']?_0x2699d7['providerId']:'phoneNumber'in _0x2699d7?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x368f55,_0x46f2ed,_0x1b16fe,_0x52c55c){super(_0x46f2ed['code'],_0x46f2ed['message']),this['operationType']=_0x1b16fe,this['user']=_0x52c55c,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x368f55['name'],'tenantId':_0x368f55['tenantId']??void 0x0,'_serverResponse':_0x46f2ed['customData']['_serverResponse'],'operationType':_0x1b16fe};}static['_fromErrorAndOperation'](_0x297cdf,_0x198f7c,_0x287990,_0x2620a8){return new Rn(_0x297cdf,_0x198f7c,_0x287990,_0x2620a8);}}function Fa(_0x50bacc,_0x22bd38,_0x64451d,_0x5b51f1){return(_0x22bd38==='reauthenticate'?_0x64451d['_getReauthenticationResolver'](_0x50bacc):_0x64451d['_getIdTokenResponse'](_0x50bacc))['catch'](_0x2ff8d7=>{throw _0x2ff8d7['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x50bacc,_0x2ff8d7,_0x22bd38,_0x5b51f1):_0x2ff8d7;});}async function jf(_0x18b7fb,_0x298a21,_0x3243d6=!0x1){const _0x3734ac=await xt(_0x18b7fb,_0x298a21['_linkToIdToken'](_0x18b7fb['auth'],await _0x18b7fb['getIdToken']()),_0x3243d6);return Be['_forOperation'](_0x18b7fb,'link',_0x3734ac);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x52d29b,_0x2ca7a8,_0x279c70=!0x1){const {auth:_0x1a31a9}=_0x52d29b;if(H(_0x1a31a9['app']))return Promise['reject'](se(_0x1a31a9));const _0x40ab19='reauthenticate';try{const _0x4841ae=await xt(_0x52d29b,Fa(_0x1a31a9,_0x40ab19,_0x2ca7a8,_0x52d29b),_0x279c70);m(_0x4841ae['idToken'],_0x1a31a9,'internal-error');const _0xa3ec8c=ws(_0x4841ae['idToken']);m(_0xa3ec8c,_0x1a31a9,'internal-error');const {sub:_0x260cc1}=_0xa3ec8c;return m(_0x52d29b['uid']===_0x260cc1,_0x1a31a9,'user-mismatch'),Be['_forOperation'](_0x52d29b,_0x40ab19,_0x4841ae);}catch(_0x1d462d){throw(_0x1d462d==null?void 0x0:_0x1d462d['code'])==='auth/user-not-found'&&K(_0x1a31a9,'user-mismatch'),_0x1d462d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x326386,_0x2682fa,_0x35e888=!0x1){if(H(_0x326386['app']))return Promise['reject'](se(_0x326386));const _0x7564cc='signIn',_0x53b66b=await Fa(_0x326386,_0x7564cc,_0x2682fa),_0x32bc55=await Be['_fromIdTokenResponse'](_0x326386,_0x7564cc,_0x53b66b);return _0x35e888||await _0x326386['_updateCurrentUser'](_0x32bc55['user']),_0x32bc55;}async function Yf(_0x49f14c,_0x42c1dc){return Ua(qe(_0x49f14c),_0x42c1dc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x41f325){const _0x2b376c=qe(_0x41f325);_0x2b376c['_getPasswordPolicyInternal']()&&await _0x2b376c['_updatePasswordPolicy']();}async function R_(_0x13515e,_0x227399,_0x34ca06){if(H(_0x13515e['app']))return Promise['reject'](se(_0x13515e));const _0x3add5b=qe(_0x13515e),_0x1f2d0d=await Oi(_0x3add5b,{'returnSecureToken':!0x0,'email':_0x227399,'password':_0x34ca06,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x4eef1c=>{throw _0x4eef1c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x13515e),_0x4eef1c;}),_0xf963e0=await Be['_fromIdTokenResponse'](_0x3add5b,'signIn',_0x1f2d0d);return await _0x3add5b['_updateCurrentUser'](_0xf963e0['user']),_0xf963e0;}function A_(_0x42cfbe,_0x2c8b0c,_0x299b9d){return H(_0x42cfbe['app'])?Promise['reject'](se(_0x42cfbe)):Yf(k(_0x42cfbe),ft['credential'](_0x2c8b0c,_0x299b9d))['catch'](async _0x16f986=>{throw _0x16f986['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x42cfbe),_0x16f986;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x1e9eaa,_0x397de1){return k(_0x1e9eaa)['setPersistence'](_0x397de1);}function Qf(_0x574827,_0x32d4ec,_0x4a1cee,_0x5bf8e7){return k(_0x574827)['onIdTokenChanged'](_0x32d4ec,_0x4a1cee,_0x5bf8e7);}function Jf(_0x56088e,_0x19a9c8,_0x299c54){return k(_0x56088e)['beforeAuthStateChanged'](_0x19a9c8,_0x299c54);}function N_(_0x30659a,_0x599cca,_0x130662,_0x5fdc6){return k(_0x30659a)['onAuthStateChanged'](_0x599cca,_0x130662,_0x5fdc6);}function P_(_0x5b97c1){return k(_0x5b97c1)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xdfbb47,_0x2edf08){this['storageRetriever']=_0xdfbb47,this['type']=_0x2edf08;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x42d55f,_0x4fc985){return this['storage']['setItem'](_0x42d55f,JSON['stringify'](_0x4fc985)),Promise['resolve']();}['_get'](_0x221f90){const _0x1b4af7=this['storage']['getItem'](_0x221f90);return Promise['resolve'](_0x1b4af7?JSON['parse'](_0x1b4af7):null);}['_remove'](_0x2a445f){return this['storage']['removeItem'](_0x2a445f),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3e8fa2,_0x168018)=>this['onStorageEvent'](_0x3e8fa2,_0x168018),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x312e34){for(const _0xd7f2fb of Object['keys'](this['listeners'])){const _0x249355=this['storage']['getItem'](_0xd7f2fb),_0x10e75e=this['localCache'][_0xd7f2fb];_0x249355!==_0x10e75e&&_0x312e34(_0xd7f2fb,_0x10e75e,_0x249355);}}['onStorageEvent'](_0x55e90e,_0x46acd6=!0x1){if(!_0x55e90e['key']){this['forAllChangedKeys']((_0x48781b,_0x53b1d7,_0x180760)=>{this['notifyListeners'](_0x48781b,_0x180760);});return;}const _0x4f4322=_0x55e90e['key'];_0x46acd6?this['detachListener']():this['stopPolling']();const _0x322842=()=>{const _0x3d62e2=this['storage']['getItem'](_0x4f4322);!_0x46acd6&&this['localCache'][_0x4f4322]===_0x3d62e2||this['notifyListeners'](_0x4f4322,_0x3d62e2);},_0x486324=this['storage']['getItem'](_0x4f4322);If()&&_0x486324!==_0x55e90e['newValue']&&_0x55e90e['newValue']!==_0x55e90e['oldValue']?setTimeout(_0x322842,Zf):_0x322842();}['notifyListeners'](_0x5019e8,_0x4add2e){this['localCache'][_0x5019e8]=_0x4add2e;const _0xd78523=this['listeners'][_0x5019e8];if(_0xd78523){for(const _0x4ea2e5 of Array['from'](_0xd78523))_0x4ea2e5(_0x4add2e&&JSON['parse'](_0x4add2e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x37dbd6,_0x223758,_0x5d47cb)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x37dbd6,'oldValue':_0x223758,'newValue':_0x5d47cb}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x1b73f7,_0x1683a8){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x1b73f7]||(this['listeners'][_0x1b73f7]=new Set(),this['localCache'][_0x1b73f7]=this['storage']['getItem'](_0x1b73f7)),this['listeners'][_0x1b73f7]['add'](_0x1683a8);}['_removeListener'](_0x146d0b,_0x456625){this['listeners'][_0x146d0b]&&(this['listeners'][_0x146d0b]['delete'](_0x456625),this['listeners'][_0x146d0b]['size']===0x0&&delete this['listeners'][_0x146d0b]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x600762,_0x4030ca){await super['_set'](_0x600762,_0x4030ca),this['localCache'][_0x600762]=JSON['stringify'](_0x4030ca);}async['_get'](_0x399f3b){const _0x510190=await super['_get'](_0x399f3b);return this['localCache'][_0x399f3b]=JSON['stringify'](_0x510190),_0x510190;}async['_remove'](_0x47f30b){await super['_remove'](_0x47f30b),delete this['localCache'][_0x47f30b];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x181bb6,_0x2ac04a){}['_removeListener'](_0x59d3b9,_0x378a90){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x3f08f0){return Promise['all'](_0x3f08f0['map'](async _0x1e6d16=>{try{return{'fulfilled':!0x0,'value':await _0x1e6d16};}catch(_0x44a50c){return{'fulfilled':!0x1,'reason':_0x44a50c};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x4891e2){this['eventTarget']=_0x4891e2,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x528c1d){const _0x20d0d3=this['receivers']['find'](_0x119b36=>_0x119b36['isListeningto'](_0x528c1d));if(_0x20d0d3)return _0x20d0d3;const _0x51e593=new jn(_0x528c1d);return this['receivers']['push'](_0x51e593),_0x51e593;}['isListeningto'](_0x182e57){return this['eventTarget']===_0x182e57;}async['handleEvent'](_0x533df3){const _0x299f45=_0x533df3,{eventId:_0x186b53,eventType:_0x44508c,data:_0x54f664}=_0x299f45['data'],_0x112482=this['handlersMap'][_0x44508c];if(!(_0x112482!=null&&_0x112482['size']))return;_0x299f45['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x186b53,'eventType':_0x44508c});const _0x3a6dd9=Array['from'](_0x112482)['map'](async _0x12fcfd=>_0x12fcfd(_0x299f45['origin'],_0x54f664)),_0x619ac6=await tp(_0x3a6dd9);_0x299f45['ports'][0x0]['postMessage']({'status':'done','eventId':_0x186b53,'eventType':_0x44508c,'response':_0x619ac6});}['_subscribe'](_0x30e7d4,_0xaa8e6e){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x30e7d4]||(this['handlersMap'][_0x30e7d4]=new Set()),this['handlersMap'][_0x30e7d4]['add'](_0xaa8e6e);}['_unsubscribe'](_0xac12bc,_0x5b931d){this['handlersMap'][_0xac12bc]&&_0x5b931d&&this['handlersMap'][_0xac12bc]['delete'](_0x5b931d),(!_0x5b931d||this['handlersMap'][_0xac12bc]['size']===0x0)&&delete this['handlersMap'][_0xac12bc],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x5dbcdc='',_0x4422a9=0xa){let _0x1807ab='';for(let _0x2ca95f=0x0;_0x2ca95f<_0x4422a9;_0x2ca95f++)_0x1807ab+=Math['floor'](Math['random']()*0xa);return _0x5dbcdc+_0x1807ab;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x56cfa8){this['target']=_0x56cfa8,this['handlers']=new Set();}['removeMessageHandler'](_0xf7bf3f){_0xf7bf3f['messageChannel']&&(_0xf7bf3f['messageChannel']['port1']['removeEventListener']('message',_0xf7bf3f['onMessage']),_0xf7bf3f['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xf7bf3f);}async['_send'](_0xf9e4c,_0x796613,_0x100f06=0x32){const _0x38bd3f=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x38bd3f)throw new Error('connection_unavailable');let _0x203d89,_0xa7988b;return new Promise((_0x188ba8,_0xc2f90c)=>{const _0x2925bb=bs('',0x14);_0x38bd3f['port1']['start']();const _0x5d8a64=setTimeout(()=>{_0xc2f90c(new Error('unsupported_event'));},_0x100f06);_0xa7988b={'messageChannel':_0x38bd3f,'onMessage'(_0x3d8c5d){const _0x110c50=_0x3d8c5d;if(_0x110c50['data']['eventId']===_0x2925bb)switch(_0x110c50['data']['status']){case'ack':clearTimeout(_0x5d8a64),_0x203d89=setTimeout(()=>{_0xc2f90c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x203d89),_0x188ba8(_0x110c50['data']['response']);break;default:clearTimeout(_0x5d8a64),clearTimeout(_0x203d89),_0xc2f90c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xa7988b),_0x38bd3f['port1']['addEventListener']('message',_0xa7988b['onMessage']),this['target']['postMessage']({'eventType':_0xf9e4c,'eventId':_0x2925bb,'data':_0x796613},[_0x38bd3f['port2']]);})['finally'](()=>{_0xa7988b&&this['removeMessageHandler'](_0xa7988b);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x1b5f91){X()['location']['href']=_0x1b5f91;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x187c36;return((_0x187c36=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x187c36['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3fa80c){this['request']=_0x3fa80c;}['toPromise'](){return new Promise((_0x925eb1,_0x1b993c)=>{this['request']['addEventListener']('success',()=>{_0x925eb1(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1b993c(this['request']['error']);});});}}function Kn(_0x41df05,_0x3826b1){return _0x41df05['transaction']([kn],_0x3826b1?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x268fc1=indexedDB['deleteDatabase'](qa);return new Jt(_0x268fc1)['toPromise']();}function ja(){const _0x26fe9f=indexedDB['open'](qa,ap);return new Promise((_0x126cea,_0x4af570)=>{_0x26fe9f['addEventListener']('error',()=>{_0x4af570(_0x26fe9f['error']);}),_0x26fe9f['addEventListener']('upgradeneeded',()=>{const _0x596593=_0x26fe9f['result'];try{_0x596593['createObjectStore'](kn,{'keyPath':za});}catch(_0x555de9){_0x4af570(_0x555de9);}}),_0x26fe9f['addEventListener']('success',async()=>{const _0x112de8=_0x26fe9f['result'];_0x112de8['objectStoreNames']['contains'](kn)?_0x126cea(_0x112de8):(_0x112de8['close'](),await cp(),_0x126cea(await ja()));});});}async function kr(_0x2ba3be,_0x52bb75,_0x279f8e){const _0x2a1362=Kn(_0x2ba3be,!0x0)['put']({[za]:_0x52bb75,'value':_0x279f8e});return new Jt(_0x2a1362)['toPromise']();}async function lp(_0x202883,_0x580c75){const _0x1bd62d=Kn(_0x202883,!0x1)['get'](_0x580c75),_0x515966=await new Jt(_0x1bd62d)['toPromise']();return _0x515966===void 0x0?null:_0x515966['value'];}function Nr(_0x8a5b03,_0x323201){const _0x4de9b8=Kn(_0x8a5b03,!0x0)['delete'](_0x323201);return new Jt(_0x4de9b8)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x437b0e){let _0x119bc2=0x0;for(;;)try{const _0x1b6b56=await this['_openDb']();return await _0x437b0e(_0x1b6b56);}catch(_0x4fc76c){if(_0x119bc2++>up)throw _0x4fc76c;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1a5ea8,_0x2206c1)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2206c1['key'])})),this['receiver']['_subscribe']('ping',async(_0x472482,_0x1a2f75)=>['keyChanged']);}async['initializeSender'](){var _0x1874e6,_0x24198e;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4a7b3e=await this['sender']['_send']('ping',{},0x320);_0x4a7b3e&&(_0x1874e6=_0x4a7b3e[0x0])!=null&&_0x1874e6['fulfilled']&&(_0x24198e=_0x4a7b3e[0x0])!=null&&_0x24198e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x244760){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x244760},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x56d4c4=>{await kr(_0x56d4c4,An,'1'),await Nr(_0x56d4c4,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x53231a){this['pendingWrites']++;try{await _0x53231a();}finally{this['pendingWrites']--;}}async['_set'](_0x3345f8,_0x1a845f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xdd9236=>kr(_0xdd9236,_0x3345f8,_0x1a845f)),this['localCache'][_0x3345f8]=_0x1a845f,this['notifyServiceWorker'](_0x3345f8)));}async['_get'](_0x366a55){const _0x52487c=await this['_withRetries'](_0x1aa5b2=>lp(_0x1aa5b2,_0x366a55));return this['localCache'][_0x366a55]=_0x52487c,_0x52487c;}async['_remove'](_0x7399b0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x11127a=>Nr(_0x11127a,_0x7399b0)),delete this['localCache'][_0x7399b0],this['notifyServiceWorker'](_0x7399b0)));}async['_poll'](){const _0x3842bb=await this['_withRetries'](_0x375392=>{const _0x12f26b=Kn(_0x375392,!0x1)['getAll']();return new Jt(_0x12f26b)['toPromise']();});if(!_0x3842bb)return[];if(this['pendingWrites']!==0x0)return[];const _0x1a13e1=[],_0x2db03f=new Set();if(_0x3842bb['length']!==0x0){for(const {fbase_key:_0x291899,value:_0x47c0f4}of _0x3842bb)_0x2db03f['add'](_0x291899),JSON['stringify'](this['localCache'][_0x291899])!==JSON['stringify'](_0x47c0f4)&&(this['notifyListeners'](_0x291899,_0x47c0f4),_0x1a13e1['push'](_0x291899));}for(const _0x18bf34 of Object['keys'](this['localCache']))this['localCache'][_0x18bf34]&&!_0x2db03f['has'](_0x18bf34)&&(this['notifyListeners'](_0x18bf34,null),_0x1a13e1['push'](_0x18bf34));return _0x1a13e1;}['notifyListeners'](_0x24373f,_0x33343c){this['localCache'][_0x24373f]=_0x33343c;const _0x17d6d0=this['listeners'][_0x24373f];if(_0x17d6d0){for(const _0x25dd20 of Array['from'](_0x17d6d0))_0x25dd20(_0x33343c);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5951aa,_0x1d8984){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5951aa]||(this['listeners'][_0x5951aa]=new Set(),this['_get'](_0x5951aa)),this['listeners'][_0x5951aa]['add'](_0x1d8984);}['_removeListener'](_0x4664b9,_0x4ebbe3){this['listeners'][_0x4664b9]&&(this['listeners'][_0x4664b9]['delete'](_0x4ebbe3),this['listeners'][_0x4664b9]['size']===0x0&&delete this['listeners'][_0x4664b9]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x499e30,_0x5a1d75){return _0x5a1d75?ne(_0x5a1d75):(m(_0x499e30['_popupRedirectResolver'],_0x499e30,'argument-error'),_0x499e30['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x232ab5){super('custom','custom'),this['params']=_0x232ab5;}['_getIdTokenResponse'](_0x442641){return Ze(_0x442641,this['_buildIdpRequest']());}['_linkToIdToken'](_0x27ed6c,_0x247d16){return Ze(_0x27ed6c,this['_buildIdpRequest'](_0x247d16));}['_getReauthenticationResolver'](_0xb94d85){return Ze(_0xb94d85,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x42e3e9){const _0x3defff={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x42e3e9&&(_0x3defff['idToken']=_0x42e3e9),_0x3defff;}}function pp(_0x4664ca){return Ua(_0x4664ca['auth'],new Rs(_0x4664ca),_0x4664ca['bypassAuthState']);}function _p(_0x543651){const {auth:_0x2c488a,user:_0x5013d0}=_0x543651;return m(_0x5013d0,_0x2c488a,'internal-error'),Kf(_0x5013d0,new Rs(_0x543651),_0x543651['bypassAuthState']);}async function gp(_0x3cc990){const {auth:_0x502a77,user:_0x306a84}=_0x3cc990;return m(_0x306a84,_0x502a77,'internal-error'),jf(_0x306a84,new Rs(_0x3cc990),_0x3cc990['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x1a6079,_0x225acd,_0x18452e,_0x36880c,_0x3e7b7b=!0x1){this['auth']=_0x1a6079,this['resolver']=_0x18452e,this['user']=_0x36880c,this['bypassAuthState']=_0x3e7b7b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x225acd)?_0x225acd:[_0x225acd];}['execute'](){return new Promise(async(_0x5ecd87,_0x135d4a)=>{this['pendingPromise']={'resolve':_0x5ecd87,'reject':_0x135d4a};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x256aaf){this['reject'](_0x256aaf);}});}async['onAuthEvent'](_0x5cf324){const {urlResponse:_0x146c55,sessionId:_0x58e18c,postBody:_0x150dd0,tenantId:_0x299fcf,error:_0x4db258,type:_0x158c20}=_0x5cf324;if(_0x4db258){this['reject'](_0x4db258);return;}const _0x5f4433={'auth':this['auth'],'requestUri':_0x146c55,'sessionId':_0x58e18c,'tenantId':_0x299fcf||void 0x0,'postBody':_0x150dd0||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x158c20)(_0x5f4433));}catch(_0x570983){this['reject'](_0x570983);}}['onError'](_0x30c6a7){this['reject'](_0x30c6a7);}['getIdpTask'](_0x5205b9){switch(_0x5205b9){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x8dfecd){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x8dfecd),this['unregisterAndCleanUp']();}['reject'](_0x423c69){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x423c69),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x6dcaa8,_0x2af5e0,_0x10ef25,_0x53b891,_0xea9662){super(_0x6dcaa8,_0x2af5e0,_0x53b891,_0xea9662),this['provider']=_0x10ef25,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x484a7f=await this['execute']();return m(_0x484a7f,this['auth'],'internal-error'),_0x484a7f;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x47ec6e=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x47ec6e),this['authWindow']['associatedEvent']=_0x47ec6e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2adcd7=>{this['reject'](_0x2adcd7);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x57e48c=>{_0x57e48c||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x7f6823;return((_0x7f6823=this['authWindow'])==null?void 0x0:_0x7f6823['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3516f7=()=>{var _0x231262,_0x3c8265;if((_0x3c8265=(_0x231262=this['authWindow'])==null?void 0x0:_0x231262['window'])!=null&&_0x3c8265['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3516f7,mp['get']());};_0x3516f7();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x10fd7b,_0x36499a,_0x12d832=!0x1){super(_0x10fd7b,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x36499a,void 0x0,_0x12d832),this['eventId']=null;}async['execute'](){let _0x3f7bdd=rn['get'](this['auth']['_key']());if(!_0x3f7bdd){try{const _0x44c338=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3f7bdd=()=>Promise['resolve'](_0x44c338);}catch(_0xcec66c){_0x3f7bdd=()=>Promise['reject'](_0xcec66c);}rn['set'](this['auth']['_key'](),_0x3f7bdd);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3f7bdd();}async['onAuthEvent'](_0x2de9f6){if(_0x2de9f6['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2de9f6);if(_0x2de9f6['type']==='unknown'){this['resolve'](null);return;}if(_0x2de9f6['eventId']){const _0x572102=await this['auth']['_redirectUserForId'](_0x2de9f6['eventId']);if(_0x572102)return this['user']=_0x572102,super['onAuthEvent'](_0x2de9f6);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x455ffb,_0x550f43){const _0x1bd351=Cp(_0x550f43),_0x1841f6=wp(_0x455ffb);if(!await _0x1841f6['_isAvailable']())return!0x1;const _0x5d36af=await _0x1841f6['_get'](_0x1bd351)==='true';return await _0x1841f6['_remove'](_0x1bd351),_0x5d36af;}function Ip(_0x3dbb64,_0x2ac098){rn['set'](_0x3dbb64['_key'](),_0x2ac098);}function wp(_0x317af1){return ne(_0x317af1['_redirectPersistence']);}function Cp(_0x165800){return sn(yp,_0x165800['config']['apiKey'],_0x165800['name']);}async function Tp(_0x56c511,_0xac0173,_0x5f2e91=!0x1){if(H(_0x56c511['app']))return Promise['reject'](se(_0x56c511));const _0x54c50c=qe(_0x56c511),_0x311d43=fp(_0x54c50c,_0xac0173),_0x4cd006=await new vp(_0x54c50c,_0x311d43,_0x5f2e91)['execute']();return _0x4cd006&&!_0x5f2e91&&(delete _0x4cd006['user']['_redirectEventId'],await _0x54c50c['_persistUserIfCurrent'](_0x4cd006['user']),await _0x54c50c['_setRedirectUser'](null,_0xac0173)),_0x4cd006;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xf46223){this['auth']=_0xf46223,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4151cf){this['consumers']['add'](_0x4151cf),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4151cf)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4151cf),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x492e8d){this['consumers']['delete'](_0x492e8d);}['onEvent'](_0x4b1738){if(this['hasEventBeenHandled'](_0x4b1738))return!0x1;let _0x27723e=!0x1;return this['consumers']['forEach'](_0x5a1c85=>{this['isEventForConsumer'](_0x4b1738,_0x5a1c85)&&(_0x27723e=!0x0,this['sendToConsumer'](_0x4b1738,_0x5a1c85),this['saveEventToCache'](_0x4b1738));}),this['hasHandledPotentialRedirect']||!Rp(_0x4b1738)||(this['hasHandledPotentialRedirect']=!0x0,_0x27723e||(this['queuedRedirectEvent']=_0x4b1738,_0x27723e=!0x0)),_0x27723e;}['sendToConsumer'](_0x3b759a,_0x3c87af){var _0x168fc3;if(_0x3b759a['error']&&!Qa(_0x3b759a)){const _0x4a5530=((_0x168fc3=_0x3b759a['error']['code'])==null?void 0x0:_0x168fc3['split']('auth/')[0x1])||'internal-error';_0x3c87af['onError'](J(this['auth'],_0x4a5530));}else _0x3c87af['onAuthEvent'](_0x3b759a);}['isEventForConsumer'](_0x33a675,_0x337033){const _0x167b9e=_0x337033['eventId']===null||!!_0x33a675['eventId']&&_0x33a675['eventId']===_0x337033['eventId'];return _0x337033['filter']['includes'](_0x33a675['type'])&&_0x167b9e;}['hasEventBeenHandled'](_0x2ca159){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2ca159));}['saveEventToCache'](_0x10909c){this['cachedEventUids']['add'](Pr(_0x10909c)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2ea0fa){return[_0x2ea0fa['type'],_0x2ea0fa['eventId'],_0x2ea0fa['sessionId'],_0x2ea0fa['tenantId']]['filter'](_0x40de67=>_0x40de67)['join']('-');}function Qa({type:_0x26fd3d,error:_0x11b23d}){return _0x26fd3d==='unknown'&&(_0x11b23d==null?void 0x0:_0x11b23d['code'])==='auth/no-auth-event';}function Rp(_0x1f11cf){switch(_0x1f11cf['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x1f11cf);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4f2f2b,_0x5e6ec8={}){return Ae(_0x4f2f2b,'GET','/v1/projects',_0x5e6ec8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x20ecff){if(_0x20ecff['config']['emulator'])return;const {authorizedDomains:_0x23a428}=await Ap(_0x20ecff);for(const _0x250c95 of _0x23a428)try{if(Op(_0x250c95))return;}catch{}K(_0x20ecff,'unauthorized-domain');}function Op(_0x52ce25){const _0x3201a4=Ni(),{protocol:_0x2e0204,hostname:_0x305e5e}=new URL(_0x3201a4);if(_0x52ce25['startsWith']('chrome-extension://')){const _0x28ee71=new URL(_0x52ce25);return _0x28ee71['hostname']===''&&_0x305e5e===''?_0x2e0204==='chrome-extension:'&&_0x52ce25['replace']('chrome-extension://','')===_0x3201a4['replace']('chrome-extension://',''):_0x2e0204==='chrome-extension:'&&_0x28ee71['hostname']===_0x305e5e;}if(!Np['test'](_0x2e0204))return!0x1;if(kp['test'](_0x52ce25))return _0x305e5e===_0x52ce25;const _0x2d8229=_0x52ce25['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2d8229+'|'+_0x2d8229+')$','i')['test'](_0x305e5e);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x40a958=X()['___jsl'];if(_0x40a958!=null&&_0x40a958['H']){for(const _0xbdfbc1 of Object['keys'](_0x40a958['H']))if(_0x40a958['H'][_0xbdfbc1]['r']=_0x40a958['H'][_0xbdfbc1]['r']||[],_0x40a958['H'][_0xbdfbc1]['L']=_0x40a958['H'][_0xbdfbc1]['L']||[],_0x40a958['H'][_0xbdfbc1]['r']=[..._0x40a958['H'][_0xbdfbc1]['L']],_0x40a958['CP']){for(let _0xb77a78=0x0;_0xb77a78<_0x40a958['CP']['length'];_0xb77a78++)_0x40a958['CP'][_0xb77a78]=null;}}}function Mp(_0x1d7a3c){return new Promise((_0x3c2339,_0x10c37b)=>{var _0x3fd7ea,_0x5de9e8,_0x4d051a;function _0xd65811(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3c2339(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x10c37b(J(_0x1d7a3c,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5de9e8=(_0x3fd7ea=X()['gapi'])==null?void 0x0:_0x3fd7ea['iframes'])!=null&&_0x5de9e8['Iframe'])_0x3c2339(gapi['iframes']['getContext']());else{if((_0x4d051a=X()['gapi'])!=null&&_0x4d051a['load'])_0xd65811();else{const _0x4909ed=Nf('iframefcb');return X()[_0x4909ed]=()=>{gapi['load']?_0xd65811():_0x10c37b(J(_0x1d7a3c,'network-request-failed'));},Da(kf()+'?onload='+_0x4909ed)['catch'](_0x1294bf=>_0x10c37b(_0x1294bf));}}})['catch'](_0x13629a=>{throw on=null,_0x13629a;});}let on=null;function Lp(_0x220acd){return on=on||Mp(_0x220acd),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x22850e){const _0x513b7c=_0x22850e['config'];m(_0x513b7c['authDomain'],_0x22850e,'auth-domain-config-required');const _0x532517=_0x513b7c['emulator']?Is(_0x513b7c,Up):'https://'+_0x22850e['config']['authDomain']+'/'+Fp,_0x41657b={'apiKey':_0x513b7c['apiKey'],'appName':_0x22850e['name'],'v':ct},_0x12a6eb=Bp['get'](_0x22850e['config']['apiHost']);_0x12a6eb&&(_0x41657b['eid']=_0x12a6eb);const _0x193494=_0x22850e['_getFrameworks']();return _0x193494['length']&&(_0x41657b['fw']=_0x193494['join'](',')),_0x532517+'?'+at(_0x41657b)['slice'](0x1);}async function Hp(_0x16b0ce){const _0x5e877c=await Lp(_0x16b0ce),_0x66f724=X()['gapi'];return m(_0x66f724,_0x16b0ce,'internal-error'),_0x5e877c['open']({'where':document['body'],'url':Vp(_0x16b0ce),'messageHandlersFilter':_0x66f724['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x51e963=>new Promise(async(_0x25f4da,_0x240309)=>{await _0x51e963['restyle']({'setHideOnLeave':!0x1});const _0x1bcc4d=J(_0x16b0ce,'network-request-failed'),_0x2c5195=X()['setTimeout'](()=>{_0x240309(_0x1bcc4d);},xp['get']());function _0x251597(){X()['clearTimeout'](_0x2c5195),_0x25f4da(_0x51e963);}_0x51e963['ping'](_0x251597)['then'](_0x251597,()=>{_0x240309(_0x1bcc4d);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1ccafa){this['window']=_0x1ccafa,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x54bd26,_0x3c497e,_0x129ab9,_0x534c8f=Gp,_0x47ba6f=qp){const _0x4306dc=Math['max']((window['screen']['availHeight']-_0x47ba6f)/0x2,0x0)['toString'](),_0x5b6b87=Math['max']((window['screen']['availWidth']-_0x534c8f)/0x2,0x0)['toString']();let _0x1bc779='';const _0x51abe9={...$p,'width':_0x534c8f['toString'](),'height':_0x47ba6f['toString'](),'top':_0x4306dc,'left':_0x5b6b87},_0x479046=W()['toLowerCase']();_0x129ab9&&(_0x1bc779=ba(_0x479046)?zp:_0x129ab9),Ta(_0x479046)&&(_0x3c497e=_0x3c497e||jp,_0x51abe9['scrollbars']='yes');const _0x29b318=Object['entries'](_0x51abe9)['reduce']((_0x2ef074,[_0x4315d7,_0x55d8a5])=>''+_0x2ef074+_0x4315d7+'='+_0x55d8a5+',','');if(Ef(_0x479046)&&_0x1bc779!=='_self')return Yp(_0x3c497e||'',_0x1bc779),new Dr(null);const _0x240ce7=window['open'](_0x3c497e||'',_0x1bc779,_0x29b318);m(_0x240ce7,_0x54bd26,'popup-blocked');try{_0x240ce7['focus']();}catch{}return new Dr(_0x240ce7);}function Yp(_0x7e337d,_0xfb382a){const _0x1998ca=document['createElement']('a');_0x1998ca['href']=_0x7e337d,_0x1998ca['target']=_0xfb382a;const _0x68eb35=document['createEvent']('MouseEvent');_0x68eb35['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1998ca['dispatchEvent'](_0x68eb35);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x1d6cbc,_0x21ceb3,_0x4e5d09,_0x4da00c,_0x367ecb,_0x8e35be){m(_0x1d6cbc['config']['authDomain'],_0x1d6cbc,'auth-domain-config-required'),m(_0x1d6cbc['config']['apiKey'],_0x1d6cbc,'invalid-api-key');const _0x50880d={'apiKey':_0x1d6cbc['config']['apiKey'],'appName':_0x1d6cbc['name'],'authType':_0x4e5d09,'redirectUrl':_0x4da00c,'v':ct,'eventId':_0x367ecb};if(_0x21ceb3 instanceof xa){_0x21ceb3['setDefaultLanguage'](_0x1d6cbc['languageCode']),_0x50880d['providerId']=_0x21ceb3['providerId']||'',hi(_0x21ceb3['getCustomParameters']())||(_0x50880d['customParameters']=JSON['stringify'](_0x21ceb3['getCustomParameters']()));for(const [_0x3c9cbe,_0x25e657]of Object['entries']({}))_0x50880d[_0x3c9cbe]=_0x25e657;}if(_0x21ceb3 instanceof Qt){const _0x23c822=_0x21ceb3['getScopes']()['filter'](_0x5ef9f8=>_0x5ef9f8!=='');_0x23c822['length']>0x0&&(_0x50880d['scopes']=_0x23c822['join'](','));}_0x1d6cbc['tenantId']&&(_0x50880d['tid']=_0x1d6cbc['tenantId']);const _0x57e0ad=_0x50880d;for(const _0x3390cd of Object['keys'](_0x57e0ad))_0x57e0ad[_0x3390cd]===void 0x0&&delete _0x57e0ad[_0x3390cd];const _0x4a5061=await _0x1d6cbc['_getAppCheckToken'](),_0x4c23a3=_0x4a5061?'#'+Xp+'='+encodeURIComponent(_0x4a5061):'';return Zp(_0x1d6cbc)+'?'+at(_0x57e0ad)['slice'](0x1)+_0x4c23a3;}function Zp({config:_0x3e0c71}){return _0x3e0c71['emulator']?Is(_0x3e0c71,Jp):'https://'+_0x3e0c71['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x5c7e97,_0x1aa771,_0x1100d5,_0x33a67c){var _0x711e69;ae((_0x711e69=this['eventManagers'][_0x5c7e97['_key']()])==null?void 0x0:_0x711e69['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x633391=await Mr(_0x5c7e97,_0x1aa771,_0x1100d5,Ni(),_0x33a67c);return Kp(_0x5c7e97,_0x633391,bs());}async['_openRedirect'](_0x24bcaf,_0x18d75b,_0x421bb1,_0x3c3852){await this['_originValidation'](_0x24bcaf);const _0x3d2d47=await Mr(_0x24bcaf,_0x18d75b,_0x421bb1,Ni(),_0x3c3852);return ip(_0x3d2d47),new Promise(()=>{});}['_initialize'](_0x48d67d){const _0x900a61=_0x48d67d['_key']();if(this['eventManagers'][_0x900a61]){const {manager:_0x28f44b,promise:_0x15a871}=this['eventManagers'][_0x900a61];return _0x28f44b?Promise['resolve'](_0x28f44b):(ae(_0x15a871,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x15a871);}const _0x4e0662=this['initAndGetManager'](_0x48d67d);return this['eventManagers'][_0x900a61]={'promise':_0x4e0662},_0x4e0662['catch'](()=>{delete this['eventManagers'][_0x900a61];}),_0x4e0662;}async['initAndGetManager'](_0x500f84){const _0x48e3ce=await Hp(_0x500f84),_0x49d242=new bp(_0x500f84);return _0x48e3ce['register']('authEvent',_0x2bf1fa=>(m(_0x2bf1fa==null?void 0x0:_0x2bf1fa['authEvent'],_0x500f84,'invalid-auth-event'),{'status':_0x49d242['onEvent'](_0x2bf1fa['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x500f84['_key']()]={'manager':_0x49d242},this['iframes'][_0x500f84['_key']()]=_0x48e3ce,_0x49d242;}['_isIframeWebStorageSupported'](_0x5261e5,_0x2ef95c){this['iframes'][_0x5261e5['_key']()]['send'](li,{'type':li},_0x41ca5d=>{var _0x1ef887;const _0x4a3cb9=(_0x1ef887=_0x41ca5d==null?void 0x0:_0x41ca5d[0x0])==null?void 0x0:_0x1ef887[li];_0x4a3cb9!==void 0x0&&_0x2ef95c(!!_0x4a3cb9),K(_0x5261e5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xa12724){const _0xb03bfa=_0xa12724['_key']();return this['originValidationPromises'][_0xb03bfa]||(this['originValidationPromises'][_0xb03bfa]=Pp(_0xa12724)),this['originValidationPromises'][_0xb03bfa];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x4dc8f7){this['auth']=_0x4dc8f7,this['internalListeners']=new Map();}['getUid'](){var _0x238ab7;return this['assertAuthConfigured'](),((_0x238ab7=this['auth']['currentUser'])==null?void 0x0:_0x238ab7['uid'])||null;}async['getToken'](_0x27384a){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x27384a)}:null;}['addAuthTokenListener'](_0x2445e4){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2445e4))return;const _0x478cb1=this['auth']['onIdTokenChanged'](_0x4dbe24=>{_0x2445e4((_0x4dbe24==null?void 0x0:_0x4dbe24['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2445e4,_0x478cb1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x40d1ab){this['assertAuthConfigured']();const _0x9479c2=this['internalListeners']['get'](_0x40d1ab);_0x9479c2&&(this['internalListeners']['delete'](_0x40d1ab),_0x9479c2(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x3394fd){switch(_0x3394fd){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x193c39){et(new Me('auth',(_0x156edb,{options:_0x40b9af})=>{const _0x3e9ce=_0x156edb['getProvider']('app')['getImmediate'](),_0xee3f7b=_0x156edb['getProvider']('heartbeat'),_0x308dd9=_0x156edb['getProvider']('app-check-internal'),{apiKey:_0xc29a45,authDomain:_0x373d9a}=_0x3e9ce['options'];m(_0xc29a45&&!_0xc29a45['includes'](':'),'invalid-api-key',{'appName':_0x3e9ce['name']});const _0x3d8a7d={'apiKey':_0xc29a45,'authDomain':_0x373d9a,'clientPlatform':_0x193c39,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x193c39)},_0x5b8a44=new bf(_0x3e9ce,_0xee3f7b,_0x308dd9,_0x3d8a7d);return Lf(_0x5b8a44,_0x40b9af),_0x5b8a44;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x42f235,_0x45fb7f,_0x5b6985)=>{_0x42f235['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0xb597eb=>{const _0x15f00b=qe(_0xb597eb['getProvider']('auth')['getImmediate']());return(_0x135d86=>new n_(_0x135d86))(_0x15f00b);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x193c39)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2c2ee4=>async _0x2610a1=>{const _0x233b55=_0x2610a1&&await _0x2610a1['getIdTokenResult'](),_0x472a73=_0x233b55&&(new Date()['getTime']()-Date['parse'](_0x233b55['issuedAtTime']))/0x3e8;if(_0x472a73&&_0x472a73>o_)return;const _0x35d128=_0x233b55==null?void 0x0:_0x233b55['token'];Fr!==_0x35d128&&(Fr=_0x35d128,await fetch(_0x2c2ee4,{'method':_0x35d128?'POST':'DELETE','headers':_0x35d128?{'Authorization':'Bearer\x20'+_0x35d128}:{}}));};function O_(_0x1da1bd=Qr()){const _0x940602=Ui(_0x1da1bd,'auth');if(_0x940602['isInitialized']())return _0x940602['getImmediate']();const _0x1adaae=Mf(_0x1da1bd,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x1b929b=Gr('authTokenSyncURL');if(_0x1b929b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4aa9cf=new URL(_0x1b929b,location['origin']);if(location['origin']===_0x4aa9cf['origin']){const _0xa59071=a_(_0x4aa9cf['toString']());Jf(_0x1adaae,_0xa59071,()=>_0xa59071(_0x1adaae['currentUser'])),Qf(_0x1adaae,_0x236fe8=>_0xa59071(_0x236fe8));}}const _0x29b0e9=Hr('auth');return _0x29b0e9&&xf(_0x1adaae,'http://'+_0x29b0e9),_0x1adaae;}function c_(){var _0x13b0dd;return((_0x13b0dd=document['getElementsByTagName']('head'))==null?void 0x0:_0x13b0dd[0x0])??document;}Rf({'loadJS'(_0x4612b1){return new Promise((_0x359550,_0x4cd220)=>{const _0x3b99d5=document['createElement']('script');_0x3b99d5['setAttribute']('src',_0x4612b1),_0x3b99d5['onload']=_0x359550,_0x3b99d5['onerror']=_0x2d1f37=>{const _0x3ba76f=J('internal-error');_0x3ba76f['customData']=_0x2d1f37,_0x4cd220(_0x3ba76f);},_0x3b99d5['type']='text/javascript',_0x3b99d5['charset']='UTF-8',c_()['appendChild'](_0x3b99d5);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};