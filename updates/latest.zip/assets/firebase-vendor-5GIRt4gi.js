const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x15d3ed,_0x9e479){if(!_0x15d3ed)throw ot(_0x9e479);},ot=function(_0x2ecf7c){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2ecf7c);},Wr=function(_0x252f6f){const _0x3a1a86=[];let _0x5c3e05=0x0;for(let _0x206210=0x0;_0x206210<_0x252f6f['length'];_0x206210++){let _0x556c3e=_0x252f6f['charCodeAt'](_0x206210);_0x556c3e<0x80?_0x3a1a86[_0x5c3e05++]=_0x556c3e:_0x556c3e<0x800?(_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0x6|0xc0,_0x3a1a86[_0x5c3e05++]=_0x556c3e&0x3f|0x80):(_0x556c3e&0xfc00)===0xd800&&_0x206210+0x1<_0x252f6f['length']&&(_0x252f6f['charCodeAt'](_0x206210+0x1)&0xfc00)===0xdc00?(_0x556c3e=0x10000+((_0x556c3e&0x3ff)<<0xa)+(_0x252f6f['charCodeAt'](++_0x206210)&0x3ff),_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0x12|0xf0,_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0xc&0x3f|0x80,_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0x6&0x3f|0x80,_0x3a1a86[_0x5c3e05++]=_0x556c3e&0x3f|0x80):(_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0xc|0xe0,_0x3a1a86[_0x5c3e05++]=_0x556c3e>>0x6&0x3f|0x80,_0x3a1a86[_0x5c3e05++]=_0x556c3e&0x3f|0x80);}return _0x3a1a86;},Za=function(_0x3fe455){const _0x385b1c=[];let _0x58f05b=0x0,_0x20ce06=0x0;for(;_0x58f05b<_0x3fe455['length'];){const _0x3a9055=_0x3fe455[_0x58f05b++];if(_0x3a9055<0x80)_0x385b1c[_0x20ce06++]=String['fromCharCode'](_0x3a9055);else{if(_0x3a9055>0xbf&&_0x3a9055<0xe0){const _0x1fa211=_0x3fe455[_0x58f05b++];_0x385b1c[_0x20ce06++]=String['fromCharCode']((_0x3a9055&0x1f)<<0x6|_0x1fa211&0x3f);}else{if(_0x3a9055>0xef&&_0x3a9055<0x16d){const _0x8d604f=_0x3fe455[_0x58f05b++],_0x5a6514=_0x3fe455[_0x58f05b++],_0x2b86ab=_0x3fe455[_0x58f05b++],_0x31c31a=((_0x3a9055&0x7)<<0x12|(_0x8d604f&0x3f)<<0xc|(_0x5a6514&0x3f)<<0x6|_0x2b86ab&0x3f)-0x10000;_0x385b1c[_0x20ce06++]=String['fromCharCode'](0xd800+(_0x31c31a>>0xa)),_0x385b1c[_0x20ce06++]=String['fromCharCode'](0xdc00+(_0x31c31a&0x3ff));}else{const _0x28d069=_0x3fe455[_0x58f05b++],_0x5d9fd7=_0x3fe455[_0x58f05b++];_0x385b1c[_0x20ce06++]=String['fromCharCode']((_0x3a9055&0xf)<<0xc|(_0x28d069&0x3f)<<0x6|_0x5d9fd7&0x3f);}}}}return _0x385b1c['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x9c2dea,_0xa1d316){if(!Array['isArray'](_0x9c2dea))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2a4c80=_0xa1d316?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x42303e=[];for(let _0x5bedc1=0x0;_0x5bedc1<_0x9c2dea['length'];_0x5bedc1+=0x3){const _0x1c9a2d=_0x9c2dea[_0x5bedc1],_0x240b3d=_0x5bedc1+0x1<_0x9c2dea['length'],_0xa72ef=_0x240b3d?_0x9c2dea[_0x5bedc1+0x1]:0x0,_0x14e6a4=_0x5bedc1+0x2<_0x9c2dea['length'],_0x364d0b=_0x14e6a4?_0x9c2dea[_0x5bedc1+0x2]:0x0,_0x4f2bc4=_0x1c9a2d>>0x2,_0x4d125c=(_0x1c9a2d&0x3)<<0x4|_0xa72ef>>0x4;let _0x49c839=(_0xa72ef&0xf)<<0x2|_0x364d0b>>0x6,_0x51191e=_0x364d0b&0x3f;_0x14e6a4||(_0x51191e=0x40,_0x240b3d||(_0x49c839=0x40)),_0x42303e['push'](_0x2a4c80[_0x4f2bc4],_0x2a4c80[_0x4d125c],_0x2a4c80[_0x49c839],_0x2a4c80[_0x51191e]);}return _0x42303e['join']('');},'encodeString'(_0x45ab67,_0x517452){return this['HAS_NATIVE_SUPPORT']&&!_0x517452?btoa(_0x45ab67):this['encodeByteArray'](Wr(_0x45ab67),_0x517452);},'decodeString'(_0x5b1e95,_0x183514){return this['HAS_NATIVE_SUPPORT']&&!_0x183514?atob(_0x5b1e95):Za(this['decodeStringToByteArray'](_0x5b1e95,_0x183514));},'decodeStringToByteArray'(_0x296bf7,_0x3b18c4){this['init_']();const _0x1dac5c=_0x3b18c4?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2d44ec=[];for(let _0x240365=0x0;_0x240365<_0x296bf7['length'];){const _0x44a5e2=_0x1dac5c[_0x296bf7['charAt'](_0x240365++)],_0x22ea5f=_0x240365<_0x296bf7['length']?_0x1dac5c[_0x296bf7['charAt'](_0x240365)]:0x0;++_0x240365;const _0x5a5c5b=_0x240365<_0x296bf7['length']?_0x1dac5c[_0x296bf7['charAt'](_0x240365)]:0x40;++_0x240365;const _0x429844=_0x240365<_0x296bf7['length']?_0x1dac5c[_0x296bf7['charAt'](_0x240365)]:0x40;if(++_0x240365,_0x44a5e2==null||_0x22ea5f==null||_0x5a5c5b==null||_0x429844==null)throw new ec();const _0x26cd0d=_0x44a5e2<<0x2|_0x22ea5f>>0x4;if(_0x2d44ec['push'](_0x26cd0d),_0x5a5c5b!==0x40){const _0x2a1f9b=_0x22ea5f<<0x4&0xf0|_0x5a5c5b>>0x2;if(_0x2d44ec['push'](_0x2a1f9b),_0x429844!==0x40){const _0x1431e3=_0x5a5c5b<<0x6&0xc0|_0x429844;_0x2d44ec['push'](_0x1431e3);}}}return _0x2d44ec;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1eb80b=0x0;_0x1eb80b<this['ENCODED_VALS']['length'];_0x1eb80b++)this['byteToCharMap_'][_0x1eb80b]=this['ENCODED_VALS']['charAt'](_0x1eb80b),this['charToByteMap_'][this['byteToCharMap_'][_0x1eb80b]]=_0x1eb80b,this['byteToCharMapWebSafe_'][_0x1eb80b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1eb80b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1eb80b]]=_0x1eb80b,_0x1eb80b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1eb80b)]=_0x1eb80b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1eb80b)]=_0x1eb80b);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x4117fa){const _0x10200f=Wr(_0x4117fa);return Di['encodeByteArray'](_0x10200f,!0x0);},an=function(_0x5b6e8c){return Br(_0x5b6e8c)['replace'](/\./g,'');},cn=function(_0x58742f){try{return Di['decodeString'](_0x58742f,!0x0);}catch(_0x1f2b5f){console['error']('base64Decode\x20failed:\x20',_0x1f2b5f);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x34ebe3){return Vr(void 0x0,_0x34ebe3);}function Vr(_0x8f7dfe,_0x50a24f){if(!(_0x50a24f instanceof Object))return _0x50a24f;switch(_0x50a24f['constructor']){case Date:const _0x2aa38d=_0x50a24f;return new Date(_0x2aa38d['getTime']());case Object:_0x8f7dfe===void 0x0&&(_0x8f7dfe={});break;case Array:_0x8f7dfe=[];break;default:return _0x50a24f;}for(const _0x443137 in _0x50a24f)!_0x50a24f['hasOwnProperty'](_0x443137)||!nc(_0x443137)||(_0x8f7dfe[_0x443137]=Vr(_0x8f7dfe[_0x443137],_0x50a24f[_0x443137]));return _0x8f7dfe;}function nc(_0x488a11){return _0x488a11!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x3df3f8=As['__FIREBASE_DEFAULTS__'];if(_0x3df3f8)return JSON['parse'](_0x3df3f8);},oc=()=>{if(typeof document>'u')return;let _0x5ec658;try{_0x5ec658=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2674f7=_0x5ec658&&cn(_0x5ec658[0x1]);return _0x2674f7&&JSON['parse'](_0x2674f7);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x3b6d02){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3b6d02);return;}},Hr=_0x420ccb=>{var _0x100ed4,_0xa76f06;return(_0xa76f06=(_0x100ed4=Mi())==null?void 0x0:_0x100ed4['emulatorHosts'])==null?void 0x0:_0xa76f06[_0x420ccb];},ac=_0x2d0ac7=>{const _0x124f17=Hr(_0x2d0ac7);if(!_0x124f17)return;const _0x4bdbea=_0x124f17['lastIndexOf'](':');if(_0x4bdbea<=0x0||_0x4bdbea+0x1===_0x124f17['length'])throw new Error('Invalid\x20host\x20'+_0x124f17+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x74d2f8=parseInt(_0x124f17['substring'](_0x4bdbea+0x1),0xa);return _0x124f17[0x0]==='['?[_0x124f17['substring'](0x1,_0x4bdbea-0x1),_0x74d2f8]:[_0x124f17['substring'](0x0,_0x4bdbea),_0x74d2f8];},$r=()=>{var _0x31da16;return(_0x31da16=Mi())==null?void 0x0:_0x31da16['config'];},Gr=_0x22ac96=>{var _0x21d303;return(_0x21d303=Mi())==null?void 0x0:_0x21d303['_'+_0x22ac96];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x474ff5,_0x1f8f85)=>{this['resolve']=_0x474ff5,this['reject']=_0x1f8f85;});}['wrapCallback'](_0x41e2c6){return(_0x43d0cb,_0x2847ac)=>{_0x43d0cb?this['reject'](_0x43d0cb):this['resolve'](_0x2847ac),typeof _0x41e2c6=='function'&&(this['promise']['catch'](()=>{}),_0x41e2c6['length']===0x1?_0x41e2c6(_0x43d0cb):_0x41e2c6(_0x43d0cb,_0x2847ac));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x4bc24e,_0x555c3e){if(_0x4bc24e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x25d51c={'alg':'none','type':'JWT'},_0x29b257=_0x555c3e||'demo-project',_0x49f5f4=_0x4bc24e['iat']||0x0,_0x28f8ab=_0x4bc24e['sub']||_0x4bc24e['user_id'];if(!_0x28f8ab)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xffa509={'iss':'https://securetoken.google.com/'+_0x29b257,'aud':_0x29b257,'iat':_0x49f5f4,'exp':_0x49f5f4+0xe10,'auth_time':_0x49f5f4,'sub':_0x28f8ab,'user_id':_0x28f8ab,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4bc24e};return[an(JSON['stringify'](_0x25d51c)),an(JSON['stringify'](_0xffa509)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x2f4669=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2f4669=='object'&&_0x2f4669['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x4e835b=W();return _0x4e835b['indexOf']('MSIE\x20')>=0x0||_0x4e835b['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x59eb8a,_0x4e7996)=>{try{let _0x1263aa=!0x0;const _0x524891='validate-browser-context-for-indexeddb-analytics-module',_0x469b9a=self['indexedDB']['open'](_0x524891);_0x469b9a['onsuccess']=()=>{_0x469b9a['result']['close'](),_0x1263aa||self['indexedDB']['deleteDatabase'](_0x524891),_0x59eb8a(!0x0);},_0x469b9a['onupgradeneeded']=()=>{_0x1263aa=!0x1;},_0x469b9a['onerror']=()=>{var _0x2620cf;_0x4e7996(((_0x2620cf=_0x469b9a['error'])==null?void 0x0:_0x2620cf['message'])||'');};}catch(_0x53e505){_0x4e7996(_0x53e505);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x3fa707,_0xb648cb,_0x28bf11){super(_0xb648cb),this['code']=_0x3fa707,this['customData']=_0x28bf11,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0xdaee43,_0xd5183,_0x3ca1e3){this['service']=_0xdaee43,this['serviceName']=_0xd5183,this['errors']=_0x3ca1e3;}['create'](_0x2ad909,..._0x18c47b){const _0x45f216=_0x18c47b[0x0]||{},_0x231405=this['service']+'/'+_0x2ad909,_0x14acb3=this['errors'][_0x2ad909],_0x4db9a5=_0x14acb3?gc(_0x14acb3,_0x45f216):'Error',_0x338d55=this['serviceName']+':\x20'+_0x4db9a5+'\x20('+_0x231405+').';return new Se(_0x231405,_0x338d55,_0x45f216);}}function gc(_0xddfd65,_0x8faa40){return _0xddfd65['replace'](mc,(_0x2cb8ca,_0xbc40db)=>{const _0x28e87b=_0x8faa40[_0xbc40db];return _0x28e87b!=null?String(_0x28e87b):'<'+_0xbc40db+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x59bd90){return JSON['parse'](_0x59bd90);}function O(_0x2d1f46){return JSON['stringify'](_0x2d1f46);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x690535){let _0x5e7cc9={},_0x464f99={},_0x511676={},_0x57ad9e='';try{const _0x5c3b55=_0x690535['split']('.');_0x5e7cc9=bt(cn(_0x5c3b55[0x0])||''),_0x464f99=bt(cn(_0x5c3b55[0x1])||''),_0x57ad9e=_0x5c3b55[0x2],_0x511676=_0x464f99['d']||{},delete _0x464f99['d'];}catch{}return{'header':_0x5e7cc9,'claims':_0x464f99,'data':_0x511676,'signature':_0x57ad9e};},yc=function(_0x354c26){const _0x20827e=zr(_0x354c26),_0x534329=_0x20827e['claims'];return!!_0x534329&&typeof _0x534329=='object'&&_0x534329['hasOwnProperty']('iat');},vc=function(_0x913ceb){const _0x1d30a9=zr(_0x913ceb)['claims'];return typeof _0x1d30a9=='object'&&_0x1d30a9['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x27c43b,_0x2d6bf0){return Object['prototype']['hasOwnProperty']['call'](_0x27c43b,_0x2d6bf0);}function Oe(_0x5f3763,_0x6ca851){if(Object['prototype']['hasOwnProperty']['call'](_0x5f3763,_0x6ca851))return _0x5f3763[_0x6ca851];}function hi(_0x113f64){for(const _0x251aec in _0x113f64)if(Object['prototype']['hasOwnProperty']['call'](_0x113f64,_0x251aec))return!0x1;return!0x0;}function ln(_0x15f72b,_0x8231e5,_0x1f59ad){const _0x124b45={};for(const _0x11329d in _0x15f72b)Object['prototype']['hasOwnProperty']['call'](_0x15f72b,_0x11329d)&&(_0x124b45[_0x11329d]=_0x8231e5['call'](_0x1f59ad,_0x15f72b[_0x11329d],_0x11329d,_0x15f72b));return _0x124b45;}function De(_0x10a94e,_0x1b46a0){if(_0x10a94e===_0x1b46a0)return!0x0;const _0x49a88d=Object['keys'](_0x10a94e),_0x4ac118=Object['keys'](_0x1b46a0);for(const _0x5f510 of _0x49a88d){if(!_0x4ac118['includes'](_0x5f510))return!0x1;const _0x15a0a3=_0x10a94e[_0x5f510],_0x1594db=_0x1b46a0[_0x5f510];if(ks(_0x15a0a3)&&ks(_0x1594db)){if(!De(_0x15a0a3,_0x1594db))return!0x1;}else{if(_0x15a0a3!==_0x1594db)return!0x1;}}for(const _0x4dd2a9 of _0x4ac118)if(!_0x49a88d['includes'](_0x4dd2a9))return!0x1;return!0x0;}function ks(_0x194b90){return _0x194b90!==null&&typeof _0x194b90=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x9ea12){const _0x212a22=[];for(const [_0x21da0d,_0x570763]of Object['entries'](_0x9ea12))Array['isArray'](_0x570763)?_0x570763['forEach'](_0x2bb991=>{_0x212a22['push'](encodeURIComponent(_0x21da0d)+'='+encodeURIComponent(_0x2bb991));}):_0x212a22['push'](encodeURIComponent(_0x21da0d)+'='+encodeURIComponent(_0x570763));return _0x212a22['length']?'&'+_0x212a22['join']('&'):'';}function yt(_0x28ac1c){const _0x10b615={};return _0x28ac1c['replace'](/^\?/,'')['split']('&')['forEach'](_0x3cee9b=>{if(_0x3cee9b){const [_0x5af446,_0xa59ba3]=_0x3cee9b['split']('=');_0x10b615[decodeURIComponent(_0x5af446)]=decodeURIComponent(_0xa59ba3);}}),_0x10b615;}function vt(_0x3373d8){const _0x2d499b=_0x3373d8['indexOf']('?');if(!_0x2d499b)return'';const _0x3ec5f6=_0x3373d8['indexOf']('#',_0x2d499b);return _0x3373d8['substring'](_0x2d499b,_0x3ec5f6>0x0?_0x3ec5f6:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3bbdc0=0x1;_0x3bbdc0<this['blockSize'];++_0x3bbdc0)this['pad_'][_0x3bbdc0]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x224884,_0x219cfe){_0x219cfe||(_0x219cfe=0x0);const _0x5a9ad0=this['W_'];if(typeof _0x224884=='string'){for(let _0x458004=0x0;_0x458004<0x10;_0x458004++)_0x5a9ad0[_0x458004]=_0x224884['charCodeAt'](_0x219cfe)<<0x18|_0x224884['charCodeAt'](_0x219cfe+0x1)<<0x10|_0x224884['charCodeAt'](_0x219cfe+0x2)<<0x8|_0x224884['charCodeAt'](_0x219cfe+0x3),_0x219cfe+=0x4;}else{for(let _0x4b8fc0=0x0;_0x4b8fc0<0x10;_0x4b8fc0++)_0x5a9ad0[_0x4b8fc0]=_0x224884[_0x219cfe]<<0x18|_0x224884[_0x219cfe+0x1]<<0x10|_0x224884[_0x219cfe+0x2]<<0x8|_0x224884[_0x219cfe+0x3],_0x219cfe+=0x4;}for(let _0x476b27=0x10;_0x476b27<0x50;_0x476b27++){const _0x1c32ef=_0x5a9ad0[_0x476b27-0x3]^_0x5a9ad0[_0x476b27-0x8]^_0x5a9ad0[_0x476b27-0xe]^_0x5a9ad0[_0x476b27-0x10];_0x5a9ad0[_0x476b27]=(_0x1c32ef<<0x1|_0x1c32ef>>>0x1f)&0xffffffff;}let _0xe0b5bd=this['chain_'][0x0],_0x211a20=this['chain_'][0x1],_0x4f254d=this['chain_'][0x2],_0x5dba1f=this['chain_'][0x3],_0x6edd62=this['chain_'][0x4],_0x1f9d70,_0x357d3f;for(let _0x5c849f=0x0;_0x5c849f<0x50;_0x5c849f++){_0x5c849f<0x28?_0x5c849f<0x14?(_0x1f9d70=_0x5dba1f^_0x211a20&(_0x4f254d^_0x5dba1f),_0x357d3f=0x5a827999):(_0x1f9d70=_0x211a20^_0x4f254d^_0x5dba1f,_0x357d3f=0x6ed9eba1):_0x5c849f<0x3c?(_0x1f9d70=_0x211a20&_0x4f254d|_0x5dba1f&(_0x211a20|_0x4f254d),_0x357d3f=0x8f1bbcdc):(_0x1f9d70=_0x211a20^_0x4f254d^_0x5dba1f,_0x357d3f=0xca62c1d6);const _0x441342=(_0xe0b5bd<<0x5|_0xe0b5bd>>>0x1b)+_0x1f9d70+_0x6edd62+_0x357d3f+_0x5a9ad0[_0x5c849f]&0xffffffff;_0x6edd62=_0x5dba1f,_0x5dba1f=_0x4f254d,_0x4f254d=(_0x211a20<<0x1e|_0x211a20>>>0x2)&0xffffffff,_0x211a20=_0xe0b5bd,_0xe0b5bd=_0x441342;}this['chain_'][0x0]=this['chain_'][0x0]+_0xe0b5bd&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x211a20&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4f254d&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5dba1f&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x6edd62&0xffffffff;}['update'](_0x1751ef,_0x51506b){if(_0x1751ef==null)return;_0x51506b===void 0x0&&(_0x51506b=_0x1751ef['length']);const _0x2a4279=_0x51506b-this['blockSize'];let _0x53b29c=0x0;const _0x595f56=this['buf_'];let _0xe7bda5=this['inbuf_'];for(;_0x53b29c<_0x51506b;){if(_0xe7bda5===0x0){for(;_0x53b29c<=_0x2a4279;)this['compress_'](_0x1751ef,_0x53b29c),_0x53b29c+=this['blockSize'];}if(typeof _0x1751ef=='string'){for(;_0x53b29c<_0x51506b;)if(_0x595f56[_0xe7bda5]=_0x1751ef['charCodeAt'](_0x53b29c),++_0xe7bda5,++_0x53b29c,_0xe7bda5===this['blockSize']){this['compress_'](_0x595f56),_0xe7bda5=0x0;break;}}else{for(;_0x53b29c<_0x51506b;)if(_0x595f56[_0xe7bda5]=_0x1751ef[_0x53b29c],++_0xe7bda5,++_0x53b29c,_0xe7bda5===this['blockSize']){this['compress_'](_0x595f56),_0xe7bda5=0x0;break;}}}this['inbuf_']=_0xe7bda5,this['total_']+=_0x51506b;}['digest'](){const _0xb2f6e=[];let _0x17572e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3bf34a=this['blockSize']-0x1;_0x3bf34a>=0x38;_0x3bf34a--)this['buf_'][_0x3bf34a]=_0x17572e&0xff,_0x17572e/=0x100;this['compress_'](this['buf_']);let _0x2d348f=0x0;for(let _0x5f3c6f=0x0;_0x5f3c6f<0x5;_0x5f3c6f++)for(let _0x14d421=0x18;_0x14d421>=0x0;_0x14d421-=0x8)_0xb2f6e[_0x2d348f]=this['chain_'][_0x5f3c6f]>>_0x14d421&0xff,++_0x2d348f;return _0xb2f6e;}}function Ic(_0x47ae69,_0x1c497d){const _0x19f75b=new wc(_0x47ae69,_0x1c497d);return _0x19f75b['subscribe']['bind'](_0x19f75b);}class wc{constructor(_0x252e68,_0x32598b){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x32598b,this['task']['then'](()=>{_0x252e68(this);})['catch'](_0x153de9=>{this['error'](_0x153de9);});}['next'](_0x420c98){this['forEachObserver'](_0x4bab83=>{_0x4bab83['next'](_0x420c98);});}['error'](_0x55e549){this['forEachObserver'](_0x52d8bf=>{_0x52d8bf['error'](_0x55e549);}),this['close'](_0x55e549);}['complete'](){this['forEachObserver'](_0x587056=>{_0x587056['complete']();}),this['close']();}['subscribe'](_0x55f571,_0x34817a,_0x2002f0){let _0x4268fb;if(_0x55f571===void 0x0&&_0x34817a===void 0x0&&_0x2002f0===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x55f571,['next','error','complete'])?_0x4268fb=_0x55f571:_0x4268fb={'next':_0x55f571,'error':_0x34817a,'complete':_0x2002f0},_0x4268fb['next']===void 0x0&&(_0x4268fb['next']=Qn),_0x4268fb['error']===void 0x0&&(_0x4268fb['error']=Qn),_0x4268fb['complete']===void 0x0&&(_0x4268fb['complete']=Qn);const _0x361a6f=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4268fb['error'](this['finalError']):_0x4268fb['complete']();}catch{}}),this['observers']['push'](_0x4268fb),_0x361a6f;}['unsubscribeOne'](_0xfa4171){this['observers']===void 0x0||this['observers'][_0xfa4171]===void 0x0||(delete this['observers'][_0xfa4171],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xcab522){if(!this['finalized']){for(let _0x131bd2=0x0;_0x131bd2<this['observers']['length'];_0x131bd2++)this['sendOne'](_0x131bd2,_0xcab522);}}['sendOne'](_0x31ceb2,_0x11bb88){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x31ceb2]!==void 0x0)try{_0x11bb88(this['observers'][_0x31ceb2]);}catch(_0x47cb4e){typeof console<'u'&&console['error']&&console['error'](_0x47cb4e);}});}['close'](_0x40e3a9){this['finalized']||(this['finalized']=!0x0,_0x40e3a9!==void 0x0&&(this['finalError']=_0x40e3a9),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x5b4bc3,_0x350982){if(typeof _0x5b4bc3!='object'||_0x5b4bc3===null)return!0x1;for(const _0x214b60 of _0x350982)if(_0x214b60 in _0x5b4bc3&&typeof _0x5b4bc3[_0x214b60]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3cac8d,_0xce5515){return _0x3cac8d+'\x20failed:\x20'+_0xce5515+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x1337b1){const _0x317c05=[];let _0x2217af=0x0;for(let _0x479383=0x0;_0x479383<_0x1337b1['length'];_0x479383++){let _0x48a526=_0x1337b1['charCodeAt'](_0x479383);if(_0x48a526>=0xd800&&_0x48a526<=0xdbff){const _0x2f39b5=_0x48a526-0xd800;_0x479383++,f(_0x479383<_0x1337b1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x510a28=_0x1337b1['charCodeAt'](_0x479383)-0xdc00;_0x48a526=0x10000+(_0x2f39b5<<0xa)+_0x510a28;}_0x48a526<0x80?_0x317c05[_0x2217af++]=_0x48a526:_0x48a526<0x800?(_0x317c05[_0x2217af++]=_0x48a526>>0x6|0xc0,_0x317c05[_0x2217af++]=_0x48a526&0x3f|0x80):_0x48a526<0x10000?(_0x317c05[_0x2217af++]=_0x48a526>>0xc|0xe0,_0x317c05[_0x2217af++]=_0x48a526>>0x6&0x3f|0x80,_0x317c05[_0x2217af++]=_0x48a526&0x3f|0x80):(_0x317c05[_0x2217af++]=_0x48a526>>0x12|0xf0,_0x317c05[_0x2217af++]=_0x48a526>>0xc&0x3f|0x80,_0x317c05[_0x2217af++]=_0x48a526>>0x6&0x3f|0x80,_0x317c05[_0x2217af++]=_0x48a526&0x3f|0x80);}return _0x317c05;},Pn=function(_0x432354){let _0x569007=0x0;for(let _0x90f2b=0x0;_0x90f2b<_0x432354['length'];_0x90f2b++){const _0x7c8016=_0x432354['charCodeAt'](_0x90f2b);_0x7c8016<0x80?_0x569007++:_0x7c8016<0x800?_0x569007+=0x2:_0x7c8016>=0xd800&&_0x7c8016<=0xdbff?(_0x569007+=0x4,_0x90f2b++):_0x569007+=0x3;}return _0x569007;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x1afdd6){return _0x1afdd6&&_0x1afdd6['_delegate']?_0x1afdd6['_delegate']:_0x1afdd6;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x2e19c2){try{return(_0x2e19c2['startsWith']('http://')||_0x2e19c2['startsWith']('https://')?new URL(_0x2e19c2)['hostname']:_0x2e19c2)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0xa375aa){return(await fetch(_0xa375aa,{'credentials':'include'}))['ok'];}class Me{constructor(_0x44f761,_0xbc486a,_0x392976){this['name']=_0x44f761,this['instanceFactory']=_0xbc486a,this['type']=_0x392976,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x45ba2f){return this['instantiationMode']=_0x45ba2f,this;}['setMultipleInstances'](_0x35cc39){return this['multipleInstances']=_0x35cc39,this;}['setServiceProps'](_0x2de10e){return this['serviceProps']=_0x2de10e,this;}['setInstanceCreatedCallback'](_0x490cc0){return this['onInstanceCreated']=_0x490cc0,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x12278e,_0x488fc0){this['name']=_0x12278e,this['container']=_0x488fc0,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1b88f5){const _0x281451=this['normalizeInstanceIdentifier'](_0x1b88f5);if(!this['instancesDeferred']['has'](_0x281451)){const _0xe2d09d=new Ve();if(this['instancesDeferred']['set'](_0x281451,_0xe2d09d),this['isInitialized'](_0x281451)||this['shouldAutoInitialize']())try{const _0x36afcd=this['getOrInitializeService']({'instanceIdentifier':_0x281451});_0x36afcd&&_0xe2d09d['resolve'](_0x36afcd);}catch{}}return this['instancesDeferred']['get'](_0x281451)['promise'];}['getImmediate'](_0x57a46d){const _0x3d0623=this['normalizeInstanceIdentifier'](_0x57a46d==null?void 0x0:_0x57a46d['identifier']),_0x24918f=(_0x57a46d==null?void 0x0:_0x57a46d['optional'])??!0x1;if(this['isInitialized'](_0x3d0623)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3d0623});}catch(_0x2d3d09){if(_0x24918f)return null;throw _0x2d3d09;}else{if(_0x24918f)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x542a94){if(_0x542a94['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x542a94['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x542a94,!!this['shouldAutoInitialize']()){if(Rc(_0x542a94))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1b10dc,_0x1a343c]of this['instancesDeferred']['entries']()){const _0x4a4a38=this['normalizeInstanceIdentifier'](_0x1b10dc);try{const _0x28b5d2=this['getOrInitializeService']({'instanceIdentifier':_0x4a4a38});_0x1a343c['resolve'](_0x28b5d2);}catch{}}}}['clearInstance'](_0x43b582=ke){this['instancesDeferred']['delete'](_0x43b582),this['instancesOptions']['delete'](_0x43b582),this['instances']['delete'](_0x43b582);}async['delete'](){const _0x34bd49=Array['from'](this['instances']['values']());await Promise['all']([..._0x34bd49['filter'](_0x1d363e=>'INTERNAL'in _0x1d363e)['map'](_0xe8d08e=>_0xe8d08e['INTERNAL']['delete']()),..._0x34bd49['filter'](_0x10de93=>'_delete'in _0x10de93)['map'](_0x495436=>_0x495436['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x122d61=ke){return this['instances']['has'](_0x122d61);}['getOptions'](_0x504f70=ke){return this['instancesOptions']['get'](_0x504f70)||{};}['initialize'](_0x3d45ba={}){const {options:_0xf9a90e={}}=_0x3d45ba,_0x47c642=this['normalizeInstanceIdentifier'](_0x3d45ba['instanceIdentifier']);if(this['isInitialized'](_0x47c642))throw Error(this['name']+'('+_0x47c642+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x51d5ff=this['getOrInitializeService']({'instanceIdentifier':_0x47c642,'options':_0xf9a90e});for(const [_0x32a1ce,_0x273ae3]of this['instancesDeferred']['entries']()){const _0x3ce23b=this['normalizeInstanceIdentifier'](_0x32a1ce);_0x47c642===_0x3ce23b&&_0x273ae3['resolve'](_0x51d5ff);}return _0x51d5ff;}['onInit'](_0xfb5edd,_0x1ed761){const _0x4647da=this['normalizeInstanceIdentifier'](_0x1ed761),_0x2d5c95=this['onInitCallbacks']['get'](_0x4647da)??new Set();_0x2d5c95['add'](_0xfb5edd),this['onInitCallbacks']['set'](_0x4647da,_0x2d5c95);const _0x2b3b88=this['instances']['get'](_0x4647da);return _0x2b3b88&&_0xfb5edd(_0x2b3b88,_0x4647da),()=>{_0x2d5c95['delete'](_0xfb5edd);};}['invokeOnInitCallbacks'](_0xd187a2,_0x4f3049){const _0x53fac6=this['onInitCallbacks']['get'](_0x4f3049);if(_0x53fac6){for(const _0x1ca0e5 of _0x53fac6)try{_0x1ca0e5(_0xd187a2,_0x4f3049);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4aaf33,options:_0x382a1b={}}){let _0x22f87c=this['instances']['get'](_0x4aaf33);if(!_0x22f87c&&this['component']&&(_0x22f87c=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4aaf33),'options':_0x382a1b}),this['instances']['set'](_0x4aaf33,_0x22f87c),this['instancesOptions']['set'](_0x4aaf33,_0x382a1b),this['invokeOnInitCallbacks'](_0x22f87c,_0x4aaf33),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4aaf33,_0x22f87c);}catch{}return _0x22f87c||null;}['normalizeInstanceIdentifier'](_0x5f06da=ke){return this['component']?this['component']['multipleInstances']?_0x5f06da:ke:_0x5f06da;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x293a5d){return _0x293a5d===ke?void 0x0:_0x293a5d;}function Rc(_0x7f3685){return _0x7f3685['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5583c8){this['name']=_0x5583c8,this['providers']=new Map();}['addComponent'](_0x1720d9){const _0xb03476=this['getProvider'](_0x1720d9['name']);if(_0xb03476['isComponentSet']())throw new Error('Component\x20'+_0x1720d9['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xb03476['setComponent'](_0x1720d9);}['addOrOverwriteComponent'](_0xb62393){this['getProvider'](_0xb62393['name'])['isComponentSet']()&&this['providers']['delete'](_0xb62393['name']),this['addComponent'](_0xb62393);}['getProvider'](_0x4875f5){if(this['providers']['has'](_0x4875f5))return this['providers']['get'](_0x4875f5);const _0x39cccd=new Sc(_0x4875f5,this);return this['providers']['set'](_0x4875f5,_0x39cccd),_0x39cccd;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x54a5af){_0x54a5af[_0x54a5af['DEBUG']=0x0]='DEBUG',_0x54a5af[_0x54a5af['VERBOSE']=0x1]='VERBOSE',_0x54a5af[_0x54a5af['INFO']=0x2]='INFO',_0x54a5af[_0x54a5af['WARN']=0x3]='WARN',_0x54a5af[_0x54a5af['ERROR']=0x4]='ERROR',_0x54a5af[_0x54a5af['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x539f7a,_0x303321,..._0x2e5f7b)=>{if(_0x303321<_0x539f7a['logLevel'])return;const _0x2e302d=new Date()['toISOString'](),_0x4e79e3=Pc[_0x303321];if(_0x4e79e3)console[_0x4e79e3]('['+_0x2e302d+']\x20\x20'+_0x539f7a['name']+':',..._0x2e5f7b);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x303321+')');};class xi{constructor(_0x14f4fc){this['name']=_0x14f4fc,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x42b6e3){if(!(_0x42b6e3 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x42b6e3+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x42b6e3;}['setLogLevel'](_0x1ffa89){this['_logLevel']=typeof _0x1ffa89=='string'?kc[_0x1ffa89]:_0x1ffa89;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x362dab){if(typeof _0x362dab!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x362dab;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3488a3){this['_userLogHandler']=_0x3488a3;}['debug'](..._0x4ac6b1){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4ac6b1),this['_logHandler'](this,T['DEBUG'],..._0x4ac6b1);}['log'](..._0x5cbbd9){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5cbbd9),this['_logHandler'](this,T['VERBOSE'],..._0x5cbbd9);}['info'](..._0x396d92){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x396d92),this['_logHandler'](this,T['INFO'],..._0x396d92);}['warn'](..._0x111259){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x111259),this['_logHandler'](this,T['WARN'],..._0x111259);}['error'](..._0x326f5c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x326f5c),this['_logHandler'](this,T['ERROR'],..._0x326f5c);}}const Dc=(_0x16bdf8,_0x4fad1c)=>_0x4fad1c['some'](_0x2d4a1d=>_0x16bdf8 instanceof _0x2d4a1d);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x44664a){const _0x530d08=new Promise((_0x2a205b,_0xb9a3d6)=>{const _0x590836=()=>{_0x44664a['removeEventListener']('success',_0x214b50),_0x44664a['removeEventListener']('error',_0x3c9297);},_0x214b50=()=>{_0x2a205b(_e(_0x44664a['result'])),_0x590836();},_0x3c9297=()=>{_0xb9a3d6(_0x44664a['error']),_0x590836();};_0x44664a['addEventListener']('success',_0x214b50),_0x44664a['addEventListener']('error',_0x3c9297);});return _0x530d08['then'](_0x318043=>{_0x318043 instanceof IDBCursor&&Kr['set'](_0x318043,_0x44664a);})['catch'](()=>{}),Fi['set'](_0x530d08,_0x44664a),_0x530d08;}function Fc(_0x447f10){if(ui['has'](_0x447f10))return;const _0x5e55c1=new Promise((_0x220614,_0x561ee8)=>{const _0x31dff4=()=>{_0x447f10['removeEventListener']('complete',_0x523388),_0x447f10['removeEventListener']('error',_0x4a2ccb),_0x447f10['removeEventListener']('abort',_0x4a2ccb);},_0x523388=()=>{_0x220614(),_0x31dff4();},_0x4a2ccb=()=>{_0x561ee8(_0x447f10['error']||new DOMException('AbortError','AbortError')),_0x31dff4();};_0x447f10['addEventListener']('complete',_0x523388),_0x447f10['addEventListener']('error',_0x4a2ccb),_0x447f10['addEventListener']('abort',_0x4a2ccb);});ui['set'](_0x447f10,_0x5e55c1);}let di={'get'(_0x235f37,_0x266454,_0x3141d7){if(_0x235f37 instanceof IDBTransaction){if(_0x266454==='done')return ui['get'](_0x235f37);if(_0x266454==='objectStoreNames')return _0x235f37['objectStoreNames']||Yr['get'](_0x235f37);if(_0x266454==='store')return _0x3141d7['objectStoreNames'][0x1]?void 0x0:_0x3141d7['objectStore'](_0x3141d7['objectStoreNames'][0x0]);}return _e(_0x235f37[_0x266454]);},'set'(_0x1b685d,_0x38f9ad,_0xfde09a){return _0x1b685d[_0x38f9ad]=_0xfde09a,!0x0;},'has'(_0xd9ffaa,_0x48f9cf){return _0xd9ffaa instanceof IDBTransaction&&(_0x48f9cf==='done'||_0x48f9cf==='store')?!0x0:_0x48f9cf in _0xd9ffaa;}};function Uc(_0xbaa948){di=_0xbaa948(di);}function Wc(_0x37fa85){return _0x37fa85===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x289b0e,..._0x20050d){const _0x28ac07=_0x37fa85['call'](Xn(this),_0x289b0e,..._0x20050d);return Yr['set'](_0x28ac07,_0x289b0e['sort']?_0x289b0e['sort']():[_0x289b0e]),_e(_0x28ac07);}:Lc()['includes'](_0x37fa85)?function(..._0x1bbc35){return _0x37fa85['apply'](Xn(this),_0x1bbc35),_e(Kr['get'](this));}:function(..._0x3acad9){return _e(_0x37fa85['apply'](Xn(this),_0x3acad9));};}function Bc(_0x1b6667){return typeof _0x1b6667=='function'?Wc(_0x1b6667):(_0x1b6667 instanceof IDBTransaction&&Fc(_0x1b6667),Dc(_0x1b6667,Mc())?new Proxy(_0x1b6667,di):_0x1b6667);}function _e(_0x22aed7){if(_0x22aed7 instanceof IDBRequest)return xc(_0x22aed7);if(Jn['has'](_0x22aed7))return Jn['get'](_0x22aed7);const _0x28e031=Bc(_0x22aed7);return _0x28e031!==_0x22aed7&&(Jn['set'](_0x22aed7,_0x28e031),Fi['set'](_0x28e031,_0x22aed7)),_0x28e031;}const Xn=_0x453974=>Fi['get'](_0x453974);function Vc(_0x15ba9e,_0x22d1ac,{blocked:_0x57e9f3,upgrade:_0x1af32d,blocking:_0x3f0166,terminated:_0x238837}={}){const _0x11344b=indexedDB['open'](_0x15ba9e,_0x22d1ac),_0x13b3dd=_e(_0x11344b);return _0x1af32d&&_0x11344b['addEventListener']('upgradeneeded',_0x553411=>{_0x1af32d(_e(_0x11344b['result']),_0x553411['oldVersion'],_0x553411['newVersion'],_e(_0x11344b['transaction']),_0x553411);}),_0x57e9f3&&_0x11344b['addEventListener']('blocked',_0x3a8d78=>_0x57e9f3(_0x3a8d78['oldVersion'],_0x3a8d78['newVersion'],_0x3a8d78)),_0x13b3dd['then'](_0x266be1=>{_0x238837&&_0x266be1['addEventListener']('close',()=>_0x238837()),_0x3f0166&&_0x266be1['addEventListener']('versionchange',_0x461ae5=>_0x3f0166(_0x461ae5['oldVersion'],_0x461ae5['newVersion'],_0x461ae5));})['catch'](()=>{}),_0x13b3dd;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2cd44a,_0x1306a8){if(!(_0x2cd44a instanceof IDBDatabase&&!(_0x1306a8 in _0x2cd44a)&&typeof _0x1306a8=='string'))return;if(Zn['get'](_0x1306a8))return Zn['get'](_0x1306a8);const _0x3ea1bc=_0x1306a8['replace'](/FromIndex$/,''),_0x18e865=_0x1306a8!==_0x3ea1bc,_0x136e28=$c['includes'](_0x3ea1bc);if(!(_0x3ea1bc in(_0x18e865?IDBIndex:IDBObjectStore)['prototype'])||!(_0x136e28||Hc['includes'](_0x3ea1bc)))return;const _0x1baf4a=async function(_0x5b4e66,..._0x1ff5b7){const _0xe2059d=this['transaction'](_0x5b4e66,_0x136e28?'readwrite':'readonly');let _0x40c79d=_0xe2059d['store'];return _0x18e865&&(_0x40c79d=_0x40c79d['index'](_0x1ff5b7['shift']())),(await Promise['all']([_0x40c79d[_0x3ea1bc](..._0x1ff5b7),_0x136e28&&_0xe2059d['done']]))[0x0];};return Zn['set'](_0x1306a8,_0x1baf4a),_0x1baf4a;}Uc(_0x38a69=>({..._0x38a69,'get':(_0x4a1d34,_0x2365a3,_0x3e0f42)=>Os(_0x4a1d34,_0x2365a3)||_0x38a69['get'](_0x4a1d34,_0x2365a3,_0x3e0f42),'has':(_0x441c71,_0x286864)=>!!Os(_0x441c71,_0x286864)||_0x38a69['has'](_0x441c71,_0x286864)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0xe59420){this['container']=_0xe59420;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2b364f=>{if(qc(_0x2b364f)){const _0x2377ac=_0x2b364f['getImmediate']();return _0x2377ac['library']+'/'+_0x2377ac['version'];}else return null;})['filter'](_0x1dd18f=>_0x1dd18f)['join']('\x20');}}function qc(_0x250836){const _0x272c65=_0x250836['getComponent']();return(_0x272c65==null?void 0x0:_0x272c65['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3fef7a,_0x450e80){try{_0x3fef7a['container']['addComponent'](_0x450e80);}catch(_0x2beb78){re['debug']('Component\x20'+_0x450e80['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3fef7a['name'],_0x2beb78);}}function et(_0x5e8f24){const _0x1d3d79=_0x5e8f24['name'];if(gi['has'](_0x1d3d79))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1d3d79+'.'),!0x1;gi['set'](_0x1d3d79,_0x5e8f24);for(const _0x347648 of Le['values']())Ms(_0x347648,_0x5e8f24);for(const _0x1ea12d of _i['values']())Ms(_0x1ea12d,_0x5e8f24);return!0x0;}function Ui(_0x348343,_0x3a47d7){const _0x3fae5d=_0x348343['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3fae5d&&_0x3fae5d['triggerHeartbeat'](),_0x348343['container']['getProvider'](_0x3a47d7);}function H(_0x58baa6){return _0x58baa6==null?!0x1:_0x58baa6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x393b8a,_0x5b40e2,_0x34befd){this['_isDeleted']=!0x1,this['_options']={..._0x393b8a},this['_config']={..._0x5b40e2},this['_name']=_0x5b40e2['name'],this['_automaticDataCollectionEnabled']=_0x5b40e2['automaticDataCollectionEnabled'],this['_container']=_0x34befd,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x272a47){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x272a47;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1e3b09){this['_isDeleted']=_0x1e3b09;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x39eed6,_0x3f1d37={}){let _0x421d0d=_0x39eed6;typeof _0x3f1d37!='object'&&(_0x3f1d37={'name':_0x3f1d37});const _0x46f3bc={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x3f1d37},_0xb7e3eb=_0x46f3bc['name'];if(typeof _0xb7e3eb!='string'||!_0xb7e3eb)throw ge['create']('bad-app-name',{'appName':String(_0xb7e3eb)});if(_0x421d0d||(_0x421d0d=$r()),!_0x421d0d)throw ge['create']('no-options');const _0x3edebf=Le['get'](_0xb7e3eb);if(_0x3edebf){if(De(_0x421d0d,_0x3edebf['options'])&&De(_0x46f3bc,_0x3edebf['config']))return _0x3edebf;throw ge['create']('duplicate-app',{'appName':_0xb7e3eb});}const _0x3d3737=new Ac(_0xb7e3eb);for(const _0x98be1d of gi['values']())_0x3d3737['addComponent'](_0x98be1d);const _0x3ac928=new Il(_0x421d0d,_0x46f3bc,_0x3d3737);return Le['set'](_0xb7e3eb,_0x3ac928),_0x3ac928;}function Qr(_0x50d204=pi){const _0x44fe93=Le['get'](_0x50d204);if(!_0x44fe93&&_0x50d204===pi&&$r())return wl();if(!_0x44fe93)throw ge['create']('no-app',{'appName':_0x50d204});return _0x44fe93;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3926a1){let _0x1311fc=!0x1;const _0x3bfd86=_0x3926a1['name'];Le['has'](_0x3bfd86)?(_0x1311fc=!0x0,Le['delete'](_0x3bfd86)):_i['has'](_0x3bfd86)&&_0x3926a1['decRefCount']()<=0x0&&(_i['delete'](_0x3bfd86),_0x1311fc=!0x0),_0x1311fc&&(await Promise['all'](_0x3926a1['container']['getProviders']()['map'](_0x3d20a9=>_0x3d20a9['delete']())),_0x3926a1['isDeleted']=!0x0);}function me(_0x4c2f64,_0x1b1466,_0x1c4295){let _0x233fb2=vl[_0x4c2f64]??_0x4c2f64;_0x1c4295&&(_0x233fb2+='-'+_0x1c4295);const _0x323f47=_0x233fb2['match'](/\s|\//),_0x4ddd39=_0x1b1466['match'](/\s|\//);if(_0x323f47||_0x4ddd39){const _0x3ac166=['Unable\x20to\x20register\x20library\x20\x22'+_0x233fb2+'\x22\x20with\x20version\x20\x22'+_0x1b1466+'\x22:'];_0x323f47&&_0x3ac166['push']('library\x20name\x20\x22'+_0x233fb2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x323f47&&_0x4ddd39&&_0x3ac166['push']('and'),_0x4ddd39&&_0x3ac166['push']('version\x20name\x20\x22'+_0x1b1466+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3ac166['join']('\x20'));return;}et(new Me(_0x233fb2+'-version',()=>({'library':_0x233fb2,'version':_0x1b1466}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0xeabdc2,_0x20e172)=>{switch(_0x20e172){case 0x0:try{_0xeabdc2['createObjectStore'](Rt);}catch(_0x3457ae){console['warn'](_0x3457ae);}}}})['catch'](_0x3cf265=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3cf265['message']});})),ei;}async function Sl(_0x141dfa){try{const _0x4807fe=(await Jr())['transaction'](Rt),_0x27a9a0=await _0x4807fe['objectStore'](Rt)['get'](Xr(_0x141dfa));return await _0x4807fe['done'],_0x27a9a0;}catch(_0x76f259){if(_0x76f259 instanceof Se)re['warn'](_0x76f259['message']);else{const _0x5716ff=ge['create']('idb-get',{'originalErrorMessage':_0x76f259==null?void 0x0:_0x76f259['message']});re['warn'](_0x5716ff['message']);}}}async function Ls(_0x21a6a1,_0xddcf7c){try{const _0x5a7573=(await Jr())['transaction'](Rt,'readwrite');await _0x5a7573['objectStore'](Rt)['put'](_0xddcf7c,Xr(_0x21a6a1)),await _0x5a7573['done'];}catch(_0x54dbf9){if(_0x54dbf9 instanceof Se)re['warn'](_0x54dbf9['message']);else{const _0x1b03e0=ge['create']('idb-set',{'originalErrorMessage':_0x54dbf9==null?void 0x0:_0x54dbf9['message']});re['warn'](_0x1b03e0['message']);}}}function Xr(_0x1643b4){return _0x1643b4['name']+'!'+_0x1643b4['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2a570f){this['container']=_0x2a570f,this['_heartbeatsCache']=null;const _0x1335a1=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x1335a1),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1228b6=>(this['_heartbeatsCache']=_0x1228b6,_0x1228b6));}async['triggerHeartbeat'](){var _0x461c79,_0x57f9cb;try{const _0x4b8297=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2115ea=xs();if(((_0x461c79=this['_heartbeatsCache'])==null?void 0x0:_0x461c79['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x57f9cb=this['_heartbeatsCache'])==null?void 0x0:_0x57f9cb['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2115ea||this['_heartbeatsCache']['heartbeats']['some'](_0x6f5ace=>_0x6f5ace['date']===_0x2115ea))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2115ea,'agent':_0x4b8297}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x30f87f=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x30f87f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x23b7f6){re['warn'](_0x23b7f6);}}async['getHeartbeatsHeader'](){var _0x42c677;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x42c677=this['_heartbeatsCache'])==null?void 0x0:_0x42c677['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2e5062=xs(),{heartbeatsToSend:_0x36c34a,unsentEntries:_0x333f32}=kl(this['_heartbeatsCache']['heartbeats']),_0x56082b=an(JSON['stringify']({'version':0x2,'heartbeats':_0x36c34a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2e5062,_0x333f32['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x333f32,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x56082b;}catch(_0x539bd5){return re['warn'](_0x539bd5),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x59962f,_0x385a06=bl){const _0x5253b8=[];let _0x508690=_0x59962f['slice']();for(const _0x134518 of _0x59962f){const _0x21062a=_0x5253b8['find'](_0x4732bd=>_0x4732bd['agent']===_0x134518['agent']);if(_0x21062a){if(_0x21062a['dates']['push'](_0x134518['date']),Fs(_0x5253b8)>_0x385a06){_0x21062a['dates']['pop']();break;}}else{if(_0x5253b8['push']({'agent':_0x134518['agent'],'dates':[_0x134518['date']]}),Fs(_0x5253b8)>_0x385a06){_0x5253b8['pop']();break;}}_0x508690=_0x508690['slice'](0x1);}return{'heartbeatsToSend':_0x5253b8,'unsentEntries':_0x508690};}class Nl{constructor(_0x5aa393){this['app']=_0x5aa393,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5dc8b9=await Sl(this['app']);return _0x5dc8b9!=null&&_0x5dc8b9['heartbeats']?_0x5dc8b9:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1fc5ce){if(await this['_canUseIndexedDBPromise']){const _0x222ded=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1fc5ce['lastSentHeartbeatDate']??_0x222ded['lastSentHeartbeatDate'],'heartbeats':_0x1fc5ce['heartbeats']});}else return;}async['add'](_0x2c6b44){if(await this['_canUseIndexedDBPromise']){const _0x2c953c=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2c6b44['lastSentHeartbeatDate']??_0x2c953c['lastSentHeartbeatDate'],'heartbeats':[..._0x2c953c['heartbeats'],..._0x2c6b44['heartbeats']]});}else return;}}function Fs(_0x1916b9){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1916b9}))['length'];}function Pl(_0x5885bd){if(_0x5885bd['length']===0x0)return-0x1;let _0x4d63b8=0x0,_0xb9a97f=_0x5885bd[0x0]['date'];for(let _0x235124=0x1;_0x235124<_0x5885bd['length'];_0x235124++)_0x5885bd[_0x235124]['date']<_0xb9a97f&&(_0xb9a97f=_0x5885bd[_0x235124]['date'],_0x4d63b8=_0x235124);return _0x4d63b8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x2dee14){et(new Me('platform-logger',_0x38a93b=>new Gc(_0x38a93b),'PRIVATE')),et(new Me('heartbeat',_0x4d56f3=>new Al(_0x4d56f3),'PRIVATE')),me(fi,Ds,_0x2dee14),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x163e9b){Zr=_0x163e9b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x356084){this['domStorage_']=_0x356084,this['prefix_']='firebase:';}['set'](_0xbebc20,_0xa215f3){_0xa215f3==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xbebc20)):this['domStorage_']['setItem'](this['prefixedName_'](_0xbebc20),O(_0xa215f3));}['get'](_0x4910ef){const _0x4657a0=this['domStorage_']['getItem'](this['prefixedName_'](_0x4910ef));return _0x4657a0==null?null:bt(_0x4657a0);}['remove'](_0x465262){this['domStorage_']['removeItem'](this['prefixedName_'](_0x465262));}['prefixedName_'](_0x5e2c84){return this['prefix_']+_0x5e2c84;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x574fd8,_0x55ca62){_0x55ca62==null?delete this['cache_'][_0x574fd8]:this['cache_'][_0x574fd8]=_0x55ca62;}['get'](_0xbf2d6d){return Y(this['cache_'],_0xbf2d6d)?this['cache_'][_0xbf2d6d]:null;}['remove'](_0x7def77){delete this['cache_'][_0x7def77];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x2d2a5b){try{if(typeof window<'u'&&typeof window[_0x2d2a5b]<'u'){const _0xd06098=window[_0x2d2a5b];return _0xd06098['setItem']('firebase:sentinel','cache'),_0xd06098['removeItem']('firebase:sentinel'),new xl(_0xd06098);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x3952a0=0x1;return function(){return _0x3952a0++;};}()),no=function(_0xaad8){const _0x2caa1f=Tc(_0xaad8),_0x545788=new Ec();_0x545788['update'](_0x2caa1f);const _0x259722=_0x545788['digest']();return Di['encodeByteArray'](_0x259722);},Bt=function(..._0x4e15c7){let _0xf51ddb='';for(let _0x3d67c1=0x0;_0x3d67c1<_0x4e15c7['length'];_0x3d67c1++){const _0x3b2f4c=_0x4e15c7[_0x3d67c1];Array['isArray'](_0x3b2f4c)||_0x3b2f4c&&typeof _0x3b2f4c=='object'&&typeof _0x3b2f4c['length']=='number'?_0xf51ddb+=Bt['apply'](null,_0x3b2f4c):typeof _0x3b2f4c=='object'?_0xf51ddb+=O(_0x3b2f4c):_0xf51ddb+=_0x3b2f4c,_0xf51ddb+='\x20';}return _0xf51ddb;};let Et=null,Vs=!0x0;const Wl=function(_0x482fdc,_0x1731e0){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x12dde1){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x348b59=Bt['apply'](null,_0x12dde1);Et(_0x348b59);}},Vt=function(_0x142c0c){return function(..._0x496fe0){L(_0x142c0c,..._0x496fe0);};},mi=function(..._0x10c62a){const _0x2b2b25='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x10c62a);Qe['error'](_0x2b2b25);},oe=function(..._0x17cb1e){const _0x3bb008='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x17cb1e);throw Qe['error'](_0x3bb008),new Error(_0x3bb008);},U=function(..._0x1e8b89){const _0x1ab7e5='FIREBASE\x20WARNING:\x20'+Bt(..._0x1e8b89);Qe['warn'](_0x1ab7e5);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x224aba){return typeof _0x224aba=='number'&&(_0x224aba!==_0x224aba||_0x224aba===Number['POSITIVE_INFINITY']||_0x224aba===Number['NEGATIVE_INFINITY']);},Vl=function(_0x230dff){if(document['readyState']==='complete')_0x230dff();else{let _0x59a91e=!0x1;const _0x1a8b8b=function(){if(!document['body']){setTimeout(_0x1a8b8b,Math['floor'](0xa));return;}_0x59a91e||(_0x59a91e=!0x0,_0x230dff());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1a8b8b,!0x1),window['addEventListener']('load',_0x1a8b8b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1a8b8b();}),window['attachEvent']('onload',_0x1a8b8b));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x5135e4,_0x3d3f12){if(_0x5135e4===_0x3d3f12)return 0x0;if(_0x5135e4===xe||_0x3d3f12===Ie)return-0x1;if(_0x3d3f12===xe||_0x5135e4===Ie)return 0x1;{const _0x54b887=Hs(_0x5135e4),_0x13a367=Hs(_0x3d3f12);return _0x54b887!==null?_0x13a367!==null?_0x54b887-_0x13a367===0x0?_0x5135e4['length']-_0x3d3f12['length']:_0x54b887-_0x13a367:-0x1:_0x13a367!==null?0x1:_0x5135e4<_0x3d3f12?-0x1:0x1;}},Hl=function(_0x2c739a,_0x40ebdd){return _0x2c739a===_0x40ebdd?0x0:_0x2c739a<_0x40ebdd?-0x1:0x1;},pt=function(_0x259c12,_0x4514a4){if(_0x4514a4&&_0x259c12 in _0x4514a4)return _0x4514a4[_0x259c12];throw new Error('Missing\x20required\x20key\x20('+_0x259c12+')\x20in\x20object:\x20'+O(_0x4514a4));},Bi=function(_0x54f695){if(typeof _0x54f695!='object'||_0x54f695===null)return O(_0x54f695);const _0x133557=[];for(const _0x56bc47 in _0x54f695)_0x133557['push'](_0x56bc47);_0x133557['sort']();let _0x52245a='{';for(let _0x40d0b2=0x0;_0x40d0b2<_0x133557['length'];_0x40d0b2++)_0x40d0b2!==0x0&&(_0x52245a+=','),_0x52245a+=O(_0x133557[_0x40d0b2]),_0x52245a+=':',_0x52245a+=Bi(_0x54f695[_0x133557[_0x40d0b2]]);return _0x52245a+='}',_0x52245a;},io=function(_0x58a253,_0x1f8103){const _0x420a48=_0x58a253['length'];if(_0x420a48<=_0x1f8103)return[_0x58a253];const _0x19f418=[];for(let _0x4da4fa=0x0;_0x4da4fa<_0x420a48;_0x4da4fa+=_0x1f8103)_0x4da4fa+_0x1f8103>_0x420a48?_0x19f418['push'](_0x58a253['substring'](_0x4da4fa,_0x420a48)):_0x19f418['push'](_0x58a253['substring'](_0x4da4fa,_0x4da4fa+_0x1f8103));return _0x19f418;};function x(_0x36f4f2,_0x5c3aa9){for(const _0x5646e0 in _0x36f4f2)_0x36f4f2['hasOwnProperty'](_0x5646e0)&&_0x5c3aa9(_0x5646e0,_0x36f4f2[_0x5646e0]);}const so=function(_0x4c6589){f(!Wi(_0x4c6589),'Invalid\x20JSON\x20number');const _0x2837b5=0xb,_0x17640b=0x34,_0x4e7214=(0x1<<_0x2837b5-0x1)-0x1;let _0x24d51d,_0xf8d9a2,_0x31609d,_0x49c0c6,_0x4bb55f;_0x4c6589===0x0?(_0xf8d9a2=0x0,_0x31609d=0x0,_0x24d51d=0x1/_0x4c6589===-0x1/0x0?0x1:0x0):(_0x24d51d=_0x4c6589<0x0,_0x4c6589=Math['abs'](_0x4c6589),_0x4c6589>=Math['pow'](0x2,0x1-_0x4e7214)?(_0x49c0c6=Math['min'](Math['floor'](Math['log'](_0x4c6589)/Math['LN2']),_0x4e7214),_0xf8d9a2=_0x49c0c6+_0x4e7214,_0x31609d=Math['round'](_0x4c6589*Math['pow'](0x2,_0x17640b-_0x49c0c6)-Math['pow'](0x2,_0x17640b))):(_0xf8d9a2=0x0,_0x31609d=Math['round'](_0x4c6589/Math['pow'](0x2,0x1-_0x4e7214-_0x17640b))));const _0x51e110=[];for(_0x4bb55f=_0x17640b;_0x4bb55f;_0x4bb55f-=0x1)_0x51e110['push'](_0x31609d%0x2?0x1:0x0),_0x31609d=Math['floor'](_0x31609d/0x2);for(_0x4bb55f=_0x2837b5;_0x4bb55f;_0x4bb55f-=0x1)_0x51e110['push'](_0xf8d9a2%0x2?0x1:0x0),_0xf8d9a2=Math['floor'](_0xf8d9a2/0x2);_0x51e110['push'](_0x24d51d?0x1:0x0),_0x51e110['reverse']();const _0x47c28c=_0x51e110['join']('');let _0x22b6f4='';for(_0x4bb55f=0x0;_0x4bb55f<0x40;_0x4bb55f+=0x8){let _0x5f04fa=parseInt(_0x47c28c['substr'](_0x4bb55f,0x8),0x2)['toString'](0x10);_0x5f04fa['length']===0x1&&(_0x5f04fa='0'+_0x5f04fa),_0x22b6f4=_0x22b6f4+_0x5f04fa;}return _0x22b6f4['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x539349,_0x4e2f9d){let _0x29495a='Unknown\x20Error';_0x539349==='too_big'?_0x29495a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x539349==='permission_denied'?_0x29495a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x539349==='unavailable'&&(_0x29495a='The\x20service\x20is\x20unavailable');const _0x259af0=new Error(_0x539349+'\x20at\x20'+_0x4e2f9d['_path']['toString']()+':\x20'+_0x29495a);return _0x259af0['code']=_0x539349['toUpperCase'](),_0x259af0;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x2ba6ca){if(zl['test'](_0x2ba6ca)){const _0x14228c=Number(_0x2ba6ca);if(_0x14228c>=jl&&_0x14228c<=Kl)return _0x14228c;}return null;},lt=function(_0x239a1d){try{_0x239a1d();}catch(_0x4dbe3c){setTimeout(()=>{const _0x569004=_0x4dbe3c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x569004),_0x4dbe3c;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3784b4,_0x95ce5e){const _0x12700a=setTimeout(_0x3784b4,_0x95ce5e);return typeof _0x12700a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x12700a):typeof _0x12700a=='object'&&_0x12700a['unref']&&_0x12700a['unref'](),_0x12700a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x18cab9,_0x5af319){this['appCheckProvider']=_0x5af319,this['appName']=_0x18cab9['name'],H(_0x18cab9)&&_0x18cab9['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x18cab9['settings']['appCheckToken']),this['appCheck']=_0x5af319==null?void 0x0:_0x5af319['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5af319==null||_0x5af319['get']()['then'](_0x2241c4=>this['appCheck']=_0x2241c4);}['getToken'](_0x1c948f){if(this['serverAppAppCheckToken']){if(_0x1c948f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1c948f):new Promise((_0x1c7b08,_0x3e77bd)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1c948f)['then'](_0x1c7b08,_0x3e77bd):_0x1c7b08(null);},0x0);});}['addTokenChangeListener'](_0x7817de){var _0x5265d0;(_0x5265d0=this['appCheckProvider'])==null||_0x5265d0['get']()['then'](_0x726f54=>_0x726f54['addTokenListener'](_0x7817de));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x413228,_0x5e7475,_0x5ed4c7){this['appName_']=_0x413228,this['firebaseOptions_']=_0x5e7475,this['authProvider_']=_0x5ed4c7,this['auth_']=null,this['auth_']=_0x5ed4c7['getImmediate']({'optional':!0x0}),this['auth_']||_0x5ed4c7['onInit'](_0x37cc3e=>this['auth_']=_0x37cc3e);}['getToken'](_0x57661f){return this['auth_']?this['auth_']['getToken'](_0x57661f)['catch'](_0x5e0ec0=>_0x5e0ec0&&_0x5e0ec0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5e0ec0)):new Promise((_0x59e1c8,_0x2c79be)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x57661f)['then'](_0x59e1c8,_0x2c79be):_0x59e1c8(null);},0x0);});}['addTokenChangeListener'](_0x7d1f1e){this['auth_']?this['auth_']['addAuthTokenListener'](_0x7d1f1e):this['authProvider_']['get']()['then'](_0xec8cd6=>_0xec8cd6['addAuthTokenListener'](_0x7d1f1e));}['removeTokenChangeListener'](_0x4e940f){this['authProvider_']['get']()['then'](_0x2d4e2d=>_0x2d4e2d['removeAuthTokenListener'](_0x4e940f));}['notifyForInvalidToken'](){let _0x241170='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x241170+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x241170+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x241170+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x241170);}}class tn{constructor(_0xacd07e){this['accessToken']=_0xacd07e;}['getToken'](_0x1589c7){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x23f10f){_0x23f10f(this['accessToken']);}['removeTokenChangeListener'](_0x46b2ca){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x382219,_0x5abe5b,_0x436e2d,_0x2f576c,_0x2a253b=!0x1,_0x24f9ec='',_0x50becd=!0x1,_0x50e1d3=!0x1,_0x19a79e=null){this['secure']=_0x5abe5b,this['namespace']=_0x436e2d,this['webSocketOnly']=_0x2f576c,this['nodeAdmin']=_0x2a253b,this['persistenceKey']=_0x24f9ec,this['includeNamespaceInQueryParams']=_0x50becd,this['isUsingEmulator']=_0x50e1d3,this['emulatorOptions']=_0x19a79e,this['_host']=_0x382219['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x382219)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x433a38){_0x433a38!==this['internalHost']&&(this['internalHost']=_0x433a38,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x46bd89=this['toURLString']();return this['persistenceKey']&&(_0x46bd89+='<'+this['persistenceKey']+'>'),_0x46bd89;}['toURLString'](){const _0x357350=this['secure']?'https://':'http://',_0x3312fe=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x357350+this['host']+'/'+_0x3312fe;}}function Xl(_0x261ec0){return _0x261ec0['host']!==_0x261ec0['internalHost']||_0x261ec0['isCustomHost']()||_0x261ec0['includeNamespaceInQueryParams'];}function go(_0x40a085,_0x9eabc,_0x2aa870){f(typeof _0x9eabc=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2aa870=='object','typeof\x20params\x20must\x20==\x20object');let _0x69143;if(_0x9eabc===fo)_0x69143=(_0x40a085['secure']?'wss://':'ws://')+_0x40a085['internalHost']+'/.ws?';else{if(_0x9eabc===po)_0x69143=(_0x40a085['secure']?'https://':'http://')+_0x40a085['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x9eabc);}Xl(_0x40a085)&&(_0x2aa870['ns']=_0x40a085['namespace']);const _0x101592=[];return x(_0x2aa870,(_0x2d9f00,_0x39c958)=>{_0x101592['push'](_0x2d9f00+'='+_0x39c958);}),_0x69143+_0x101592['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0xe90685,_0x21d194=0x1){Y(this['counters_'],_0xe90685)||(this['counters_'][_0xe90685]=0x0),this['counters_'][_0xe90685]+=_0x21d194;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x50e5a3){const _0x285a60=_0x50e5a3['toString']();return ti[_0x285a60]||(ti[_0x285a60]=new Zl()),ti[_0x285a60];}function eh(_0x3b32b9,_0x45034d){const _0x12aa21=_0x3b32b9['toString']();return ni[_0x12aa21]||(ni[_0x12aa21]=_0x45034d()),ni[_0x12aa21];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x949f03){this['onMessage_']=_0x949f03,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x46672a,_0x1fe15b){this['closeAfterResponse']=_0x46672a,this['onClose']=_0x1fe15b,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2b3874,_0x47b2e8){for(this['pendingResponses'][_0x2b3874]=_0x47b2e8;this['pendingResponses'][this['currentResponseNum']];){const _0xddbb03=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4c9342=0x0;_0x4c9342<_0xddbb03['length'];++_0x4c9342)_0xddbb03[_0x4c9342]&&lt(()=>{this['onMessage_'](_0xddbb03[_0x4c9342]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1d2e5a,_0x326b44,_0x11565f,_0x53c670,_0x2626b7,_0x4a06e4,_0x3ab006){this['connId']=_0x1d2e5a,this['repoInfo']=_0x326b44,this['applicationId']=_0x11565f,this['appCheckToken']=_0x53c670,this['authToken']=_0x2626b7,this['transportSessionId']=_0x4a06e4,this['lastSessionId']=_0x3ab006,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1d2e5a),this['stats_']=Hi(_0x326b44),this['urlFn']=_0x131526=>(this['appCheckToken']&&(_0x131526[yi]=this['appCheckToken']),go(_0x326b44,po,_0x131526));}['open'](_0x333f84,_0x2a0ad9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2a0ad9,this['myPacketOrderer']=new th(_0x333f84),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x496b44)=>{const [_0x2c7136,_0x345d4c,_0x485ed9,_0x3f087b,_0x15b8a4]=_0x496b44;if(this['incrementIncomingBytes_'](_0x496b44),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2c7136===$s)this['id']=_0x345d4c,this['password']=_0x485ed9;else{if(_0x2c7136===nh)_0x345d4c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x345d4c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2c7136);}}},(..._0x3910cb)=>{const [_0x5e85fc,_0x346005]=_0x3910cb;this['incrementIncomingBytes_'](_0x3910cb),this['myPacketOrderer']['handleResponse'](_0x5e85fc,_0x346005);},()=>{this['onClosed_']();},this['urlFn']);const _0x4f66f2={};_0x4f66f2[$s]='t',_0x4f66f2[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4f66f2[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4f66f2[ro]=Vi,this['transportSessionId']&&(_0x4f66f2[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4f66f2[ho]=this['lastSessionId']),this['applicationId']&&(_0x4f66f2[uo]=this['applicationId']),this['appCheckToken']&&(_0x4f66f2[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4f66f2[ao]=co);const _0x28bd07=this['urlFn'](_0x4f66f2);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x28bd07),this['scriptTagHolder']['addTag'](_0x28bd07,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5a6b4e){const _0x16c405=O(_0x5a6b4e);this['bytesSent']+=_0x16c405['length'],this['stats_']['incrementCounter']('bytes_sent',_0x16c405['length']);const _0x792049=Br(_0x16c405),_0x505c0a=io(_0x792049,hh);for(let _0x1aaf62=0x0;_0x1aaf62<_0x505c0a['length'];_0x1aaf62++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x505c0a['length'],_0x505c0a[_0x1aaf62]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x58b1d7,_0x3d1120){this['myDisconnFrame']=document['createElement']('iframe');const _0x3d41ae={};_0x3d41ae[lh]='t',_0x3d41ae[mo]=_0x58b1d7,_0x3d41ae[yo]=_0x3d1120,this['myDisconnFrame']['src']=this['urlFn'](_0x3d41ae),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x26f9f4){const _0xaf4ffe=O(_0x26f9f4)['length'];this['bytesReceived']+=_0xaf4ffe,this['stats_']['incrementCounter']('bytes_received',_0xaf4ffe);}}class $i{constructor(_0x19ea08,_0x564fdd,_0x2dde20,_0x4c4652){this['onDisconnect']=_0x2dde20,this['urlFn']=_0x4c4652,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x19ea08,window[sh+this['uniqueCallbackIdentifier']]=_0x564fdd,this['myIFrame']=$i['createIFrame_']();let _0x515671='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x515671='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x43994c='<html><body>'+_0x515671+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x43994c),this['myIFrame']['doc']['close']();}catch(_0x3f6d52){L('frame\x20writing\x20exception'),_0x3f6d52['stack']&&L(_0x3f6d52['stack']),L(_0x3f6d52);}}}static['createIFrame_'](){const _0x57acfb=document['createElement']('iframe');if(_0x57acfb['style']['display']='none',document['body']){document['body']['appendChild'](_0x57acfb);try{_0x57acfb['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2e4bb0=document['domain'];_0x57acfb['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2e4bb0+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x57acfb['contentDocument']?_0x57acfb['doc']=_0x57acfb['contentDocument']:_0x57acfb['contentWindow']?_0x57acfb['doc']=_0x57acfb['contentWindow']['document']:_0x57acfb['document']&&(_0x57acfb['doc']=_0x57acfb['document']),_0x57acfb;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0xec2576=this['onDisconnect'];_0xec2576&&(this['onDisconnect']=null,_0xec2576());}['startLongPoll'](_0x3e9d07,_0x2c167e){for(this['myID']=_0x3e9d07,this['myPW']=_0x2c167e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2d8aca={};_0x2d8aca[mo]=this['myID'],_0x2d8aca[yo]=this['myPW'],_0x2d8aca[vo]=this['currentSerial'];let _0x3a7b29=this['urlFn'](_0x2d8aca),_0x27577f='',_0x17e5e9=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x27577f['length']<=Eo;){const _0x13e817=this['pendingSegs']['shift']();_0x27577f=_0x27577f+'&'+oh+_0x17e5e9+'='+_0x13e817['seg']+'&'+ah+_0x17e5e9+'='+_0x13e817['ts']+'&'+ch+_0x17e5e9+'='+_0x13e817['d'],_0x17e5e9++;}return _0x3a7b29=_0x3a7b29+_0x27577f,this['addLongPollTag_'](_0x3a7b29,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x14ebd8,_0x1e0c21,_0x4398c6){this['pendingSegs']['push']({'seg':_0x14ebd8,'ts':_0x1e0c21,'d':_0x4398c6}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5ab9ac,_0x11da8e){this['outstandingRequests']['add'](_0x11da8e);const _0x3a0d59=()=>{this['outstandingRequests']['delete'](_0x11da8e),this['newRequest_']();},_0x516f36=setTimeout(_0x3a0d59,Math['floor'](uh)),_0x776e10=()=>{clearTimeout(_0x516f36),_0x3a0d59();};this['addTag'](_0x5ab9ac,_0x776e10);}['addTag'](_0x509091,_0x32d5f4){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x259d60=this['myIFrame']['doc']['createElement']('script');_0x259d60['type']='text/javascript',_0x259d60['async']=!0x0,_0x259d60['src']=_0x509091,_0x259d60['onload']=_0x259d60['onreadystatechange']=function(){const _0x26cee8=_0x259d60['readyState'];(!_0x26cee8||_0x26cee8==='loaded'||_0x26cee8==='complete')&&(_0x259d60['onload']=_0x259d60['onreadystatechange']=null,_0x259d60['parentNode']&&_0x259d60['parentNode']['removeChild'](_0x259d60),_0x32d5f4());},_0x259d60['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x509091),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x259d60);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x3a3770,_0x421fdf,_0x192a1f,_0x4f9bd6,_0x147e47,_0x40f7ce,_0x2214c2){this['connId']=_0x3a3770,this['applicationId']=_0x192a1f,this['appCheckToken']=_0x4f9bd6,this['authToken']=_0x147e47,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x421fdf),this['connURL']=G['connectionURL_'](_0x421fdf,_0x40f7ce,_0x2214c2,_0x4f9bd6,_0x192a1f),this['nodeAdmin']=_0x421fdf['nodeAdmin'];}static['connectionURL_'](_0x39b433,_0x4c113f,_0x5e6b7f,_0x40a751,_0x365b48){const _0x5d3259={};return _0x5d3259[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5d3259[ao]=co),_0x4c113f&&(_0x5d3259[oo]=_0x4c113f),_0x5e6b7f&&(_0x5d3259[ho]=_0x5e6b7f),_0x40a751&&(_0x5d3259[yi]=_0x40a751),_0x365b48&&(_0x5d3259[uo]=_0x365b48),go(_0x39b433,fo,_0x5d3259);}['open'](_0x6dce37,_0x2123c2){this['onDisconnect']=_0x2123c2,this['onMessage']=_0x6dce37,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x2d6e3e;dc(),this['mySock']=new hn(this['connURL'],[],_0x2d6e3e);}catch(_0x391a9c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x423789=_0x391a9c['message']||_0x391a9c['data'];_0x423789&&this['log_'](_0x423789),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x274c19=>{this['handleIncomingFrame'](_0x274c19);},this['mySock']['onerror']=_0x401a09=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x92a125=_0x401a09['message']||_0x401a09['data'];_0x92a125&&this['log_'](_0x92a125),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xb756aa=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x49b16b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x14e760=navigator['userAgent']['match'](_0x49b16b);_0x14e760&&_0x14e760['length']>0x1&&parseFloat(_0x14e760[0x1])<4.4&&(_0xb756aa=!0x0);}return!_0xb756aa&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x276d34){if(this['frames']['push'](_0x276d34),this['frames']['length']===this['totalFrames']){const _0x41b2bc=this['frames']['join']('');this['frames']=null;const _0x17d776=bt(_0x41b2bc);this['onMessage'](_0x17d776);}}['handleNewFrameCount_'](_0x5e3c54){this['totalFrames']=_0x5e3c54,this['frames']=[];}['extractFrameCount_'](_0x18d1ef){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x18d1ef['length']<=0x6){const _0x4ba3a3=Number(_0x18d1ef);if(!isNaN(_0x4ba3a3))return this['handleNewFrameCount_'](_0x4ba3a3),null;}return this['handleNewFrameCount_'](0x1),_0x18d1ef;}['handleIncomingFrame'](_0x10a698){if(this['mySock']===null)return;const _0xac0f36=_0x10a698['data'];if(this['bytesReceived']+=_0xac0f36['length'],this['stats_']['incrementCounter']('bytes_received',_0xac0f36['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xac0f36);else{const _0x1e8c50=this['extractFrameCount_'](_0xac0f36);_0x1e8c50!==null&&this['appendFrame_'](_0x1e8c50);}}['send'](_0x5558e4){this['resetKeepAlive']();const _0x3a965d=O(_0x5558e4);this['bytesSent']+=_0x3a965d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3a965d['length']);const _0x3c1024=io(_0x3a965d,fh);_0x3c1024['length']>0x1&&this['sendString_'](String(_0x3c1024['length']));for(let _0x1d4d88=0x0;_0x1d4d88<_0x3c1024['length'];_0x1d4d88++)this['sendString_'](_0x3c1024[_0x1d4d88]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x2ce153){try{this['mySock']['send'](_0x2ce153);}catch(_0x453c47){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x453c47['message']||_0x453c47['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x345247){this['initTransports_'](_0x345247);}['initTransports_'](_0x580e0a){const _0x3d5b25=G&&G['isAvailable']();let _0x4283e4=_0x3d5b25&&!G['previouslyFailed']();if(_0x580e0a['webSocketOnly']&&(_0x3d5b25||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4283e4=!0x0),_0x4283e4)this['transports_']=[G];else{const _0x1ee2a4=this['transports_']=[];for(const _0x25ab59 of At['ALL_TRANSPORTS'])_0x25ab59&&_0x25ab59['isAvailable']()&&_0x1ee2a4['push'](_0x25ab59);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4b7321,_0x40a16d,_0x2555bb,_0xb7b40c,_0xb91b6b,_0x42dabe,_0x35c0fc,_0x38199f,_0x340470,_0x237346){this['id']=_0x4b7321,this['repoInfo_']=_0x40a16d,this['applicationId_']=_0x2555bb,this['appCheckToken_']=_0xb7b40c,this['authToken_']=_0xb91b6b,this['onMessage_']=_0x42dabe,this['onReady_']=_0x35c0fc,this['onDisconnect_']=_0x38199f,this['onKill_']=_0x340470,this['lastSessionId']=_0x237346,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x40a16d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x54b881=this['transportManager_']['initialTransport']();this['conn_']=new _0x54b881(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x54b881['responsesRequiredToBeHealthy']||0x0;const _0x3678cd=this['connReceiver_'](this['conn_']),_0x583cba=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3678cd,_0x583cba);},Math['floor'](0x0));const _0x1ff2a8=_0x54b881['healthyTimeout']||0x0;_0x1ff2a8>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1ff2a8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x27f036){return _0x42b952=>{_0x27f036===this['conn_']?this['onConnectionLost_'](_0x42b952):_0x27f036===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x13d123){return _0x38dc65=>{this['state_']!==0x2&&(_0x13d123===this['rx_']?this['onPrimaryMessageReceived_'](_0x38dc65):_0x13d123===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x38dc65):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xe43ec5){const _0x13bd77={'t':'d','d':_0xe43ec5};this['sendData_'](_0x13bd77);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4b13e6){if(ii in _0x4b13e6){const _0xda2630=_0x4b13e6[ii];_0xda2630===js?this['upgradeIfSecondaryHealthy_']():_0xda2630===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xda2630===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x34a256){const _0x4ceedc=pt('t',_0x34a256),_0x40bf41=pt('d',_0x34a256);if(_0x4ceedc==='c')this['onSecondaryControl_'](_0x40bf41);else{if(_0x4ceedc==='d')this['pendingDataMessages']['push'](_0x40bf41);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4ceedc);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4c746a){const _0x4409b1=pt('t',_0x4c746a),_0x4d2259=pt('d',_0x4c746a);_0x4409b1==='c'?this['onControl_'](_0x4d2259):_0x4409b1==='d'&&this['onDataMessage_'](_0x4d2259);}['onDataMessage_'](_0x1d4f0c){this['onPrimaryResponse_'](),this['onMessage_'](_0x1d4f0c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3f7fb5){const _0xb49e5e=pt(ii,_0x3f7fb5);if(Gs in _0x3f7fb5){const _0x19e253=_0x3f7fb5[Gs];if(_0xb49e5e===Ih){const _0x1000c8={..._0x19e253};this['repoInfo_']['isUsingEmulator']&&(_0x1000c8['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1000c8);}else{if(_0xb49e5e===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x390564=0x0;_0x390564<this['pendingDataMessages']['length'];++_0x390564)this['onDataMessage_'](this['pendingDataMessages'][_0x390564]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xb49e5e===vh?this['onConnectionShutdown_'](_0x19e253):_0xb49e5e===qs?this['onReset_'](_0x19e253):_0xb49e5e===Eh?mi('Server\x20Error:\x20'+_0x19e253):_0xb49e5e===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0xb49e5e);}}}['onHandshake_'](_0xf1a6ed){const _0x3eabe1=_0xf1a6ed['ts'],_0x2a1e6d=_0xf1a6ed['v'],_0x27bf70=_0xf1a6ed['h'];this['sessionId']=_0xf1a6ed['s'],this['repoInfo_']['host']=_0x27bf70,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3eabe1),Vi!==_0x2a1e6d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xccc2dc=this['transportManager_']['upgradeTransport']();_0xccc2dc&&this['startUpgrade_'](_0xccc2dc);}['startUpgrade_'](_0x47e30c){this['secondaryConn_']=new _0x47e30c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x47e30c['responsesRequiredToBeHealthy']||0x0;const _0x4ed219=this['connReceiver_'](this['secondaryConn_']),_0xf9fa2e=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4ed219,_0xf9fa2e),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x254081){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x254081),this['repoInfo_']['host']=_0x254081,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1b9653,_0x146232){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1b9653,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x146232,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5a931e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5a931e||this['rx_']===_0x5a931e)&&this['close']();}['onConnectionLost_'](_0x193d4e){this['conn_']=null,!_0x193d4e&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xd9165c){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xd9165c),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4dba40){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4dba40);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x40c165,_0x9b7ea0,_0x175f20,_0x5080a1){}['merge'](_0x3ad7ae,_0x52464d,_0x5d115d,_0x351ff4){}['refreshAuthToken'](_0x34992c){}['refreshAppCheckToken'](_0x131817){}['onDisconnectPut'](_0x6cad21,_0x439bef,_0x155f1f){}['onDisconnectMerge'](_0x53f646,_0x5828de,_0x20fc1e){}['onDisconnectCancel'](_0x49f3fa,_0x228c67){}['reportStats'](_0x5ac15d){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4455cd){this['allowedEvents_']=_0x4455cd,this['listeners_']={},f(Array['isArray'](_0x4455cd)&&_0x4455cd['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x69d4cb,..._0x18a522){if(Array['isArray'](this['listeners_'][_0x69d4cb])){const _0x2c8fab=[...this['listeners_'][_0x69d4cb]];for(let _0x3eb71f=0x0;_0x3eb71f<_0x2c8fab['length'];_0x3eb71f++)_0x2c8fab[_0x3eb71f]['callback']['apply'](_0x2c8fab[_0x3eb71f]['context'],_0x18a522);}}['on'](_0x3ea579,_0x1f581a,_0x5588a9){this['validateEventType_'](_0x3ea579),this['listeners_'][_0x3ea579]=this['listeners_'][_0x3ea579]||[],this['listeners_'][_0x3ea579]['push']({'callback':_0x1f581a,'context':_0x5588a9});const _0x28979b=this['getInitialEvent'](_0x3ea579);_0x28979b&&_0x1f581a['apply'](_0x5588a9,_0x28979b);}['off'](_0x3e994e,_0x190725,_0x4add86){this['validateEventType_'](_0x3e994e);const _0x51048f=this['listeners_'][_0x3e994e]||[];for(let _0x4e0495=0x0;_0x4e0495<_0x51048f['length'];_0x4e0495++)if(_0x51048f[_0x4e0495]['callback']===_0x190725&&(!_0x4add86||_0x4add86===_0x51048f[_0x4e0495]['context'])){_0x51048f['splice'](_0x4e0495,0x1);return;}}['validateEventType_'](_0x3ec96d){f(this['allowedEvents_']['find'](_0xad1574=>_0xad1574===_0x3ec96d),'Unknown\x20event:\x20'+_0x3ec96d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4a5cc8){return f(_0x4a5cc8==='online','Unknown\x20event\x20type:\x20'+_0x4a5cc8),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x20dc2a,_0x15cc4e){if(_0x15cc4e===void 0x0){this['pieces_']=_0x20dc2a['split']('/');let _0x5e099a=0x0;for(let _0x504062=0x0;_0x504062<this['pieces_']['length'];_0x504062++)this['pieces_'][_0x504062]['length']>0x0&&(this['pieces_'][_0x5e099a]=this['pieces_'][_0x504062],_0x5e099a++);this['pieces_']['length']=_0x5e099a,this['pieceNum_']=0x0;}else this['pieces_']=_0x20dc2a,this['pieceNum_']=_0x15cc4e;}['toString'](){let _0x13b0a1='';for(let _0x285a55=this['pieceNum_'];_0x285a55<this['pieces_']['length'];_0x285a55++)this['pieces_'][_0x285a55]!==''&&(_0x13b0a1+='/'+this['pieces_'][_0x285a55]);return _0x13b0a1||'/';}}function w(){return new C('');}function y(_0x2c6a89){return _0x2c6a89['pieceNum_']>=_0x2c6a89['pieces_']['length']?null:_0x2c6a89['pieces_'][_0x2c6a89['pieceNum_']];}function we(_0x33f02a){return _0x33f02a['pieces_']['length']-_0x33f02a['pieceNum_'];}function b(_0xdacbb4){let _0x507d83=_0xdacbb4['pieceNum_'];return _0x507d83<_0xdacbb4['pieces_']['length']&&_0x507d83++,new C(_0xdacbb4['pieces_'],_0x507d83);}function Gi(_0x20f375){return _0x20f375['pieceNum_']<_0x20f375['pieces_']['length']?_0x20f375['pieces_'][_0x20f375['pieces_']['length']-0x1]:null;}function Ch(_0x44b3dc){let _0x4c3adf='';for(let _0x12ef12=_0x44b3dc['pieceNum_'];_0x12ef12<_0x44b3dc['pieces_']['length'];_0x12ef12++)_0x44b3dc['pieces_'][_0x12ef12]!==''&&(_0x4c3adf+='/'+encodeURIComponent(String(_0x44b3dc['pieces_'][_0x12ef12])));return _0x4c3adf||'/';}function kt(_0x2e0cc4,_0x510a9b=0x0){return _0x2e0cc4['pieces_']['slice'](_0x2e0cc4['pieceNum_']+_0x510a9b);}function To(_0x366ed5){if(_0x366ed5['pieceNum_']>=_0x366ed5['pieces_']['length'])return null;const _0x159afe=[];for(let _0x39ca89=_0x366ed5['pieceNum_'];_0x39ca89<_0x366ed5['pieces_']['length']-0x1;_0x39ca89++)_0x159afe['push'](_0x366ed5['pieces_'][_0x39ca89]);return new C(_0x159afe,0x0);}function A(_0x44300a,_0x5a00d2){const _0x116c74=[];for(let _0x426dd4=_0x44300a['pieceNum_'];_0x426dd4<_0x44300a['pieces_']['length'];_0x426dd4++)_0x116c74['push'](_0x44300a['pieces_'][_0x426dd4]);if(_0x5a00d2 instanceof C){for(let _0x260f14=_0x5a00d2['pieceNum_'];_0x260f14<_0x5a00d2['pieces_']['length'];_0x260f14++)_0x116c74['push'](_0x5a00d2['pieces_'][_0x260f14]);}else{const _0x499c9e=_0x5a00d2['split']('/');for(let _0x3d7f16=0x0;_0x3d7f16<_0x499c9e['length'];_0x3d7f16++)_0x499c9e[_0x3d7f16]['length']>0x0&&_0x116c74['push'](_0x499c9e[_0x3d7f16]);}return new C(_0x116c74,0x0);}function v(_0x9bae14){return _0x9bae14['pieceNum_']>=_0x9bae14['pieces_']['length'];}function F(_0x1fd320,_0xf82f1e){const _0x15e38a=y(_0x1fd320),_0x32a099=y(_0xf82f1e);if(_0x15e38a===null)return _0xf82f1e;if(_0x15e38a===_0x32a099)return F(b(_0x1fd320),b(_0xf82f1e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xf82f1e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1fd320+')');}function Th(_0x167293,_0x11370a){const _0x3b560e=kt(_0x167293,0x0),_0x2ca5b1=kt(_0x11370a,0x0);for(let _0x44c4bc=0x0;_0x44c4bc<_0x3b560e['length']&&_0x44c4bc<_0x2ca5b1['length'];_0x44c4bc++){const _0x276ae2=He(_0x3b560e[_0x44c4bc],_0x2ca5b1[_0x44c4bc]);if(_0x276ae2!==0x0)return _0x276ae2;}return _0x3b560e['length']===_0x2ca5b1['length']?0x0:_0x3b560e['length']<_0x2ca5b1['length']?-0x1:0x1;}function qi(_0x39141c,_0x2f86ab){if(we(_0x39141c)!==we(_0x2f86ab))return!0x1;for(let _0x18880c=_0x39141c['pieceNum_'],_0x33c914=_0x2f86ab['pieceNum_'];_0x18880c<=_0x39141c['pieces_']['length'];_0x18880c++,_0x33c914++)if(_0x39141c['pieces_'][_0x18880c]!==_0x2f86ab['pieces_'][_0x33c914])return!0x1;return!0x0;}function $(_0xacdac,_0x5409ea){let _0x309ce2=_0xacdac['pieceNum_'],_0x230626=_0x5409ea['pieceNum_'];if(we(_0xacdac)>we(_0x5409ea))return!0x1;for(;_0x309ce2<_0xacdac['pieces_']['length'];){if(_0xacdac['pieces_'][_0x309ce2]!==_0x5409ea['pieces_'][_0x230626])return!0x1;++_0x309ce2,++_0x230626;}return!0x0;}class Sh{constructor(_0x1ed299,_0x4aa645){this['errorPrefix_']=_0x4aa645,this['parts_']=kt(_0x1ed299,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4997dd=0x0;_0x4997dd<this['parts_']['length'];_0x4997dd++)this['byteLength_']+=Pn(this['parts_'][_0x4997dd]);So(this);}}function bh(_0x4fbc80,_0x283492){_0x4fbc80['parts_']['length']>0x0&&(_0x4fbc80['byteLength_']+=0x1),_0x4fbc80['parts_']['push'](_0x283492),_0x4fbc80['byteLength_']+=Pn(_0x283492),So(_0x4fbc80);}function Rh(_0x5708c9){const _0x3de07e=_0x5708c9['parts_']['pop']();_0x5708c9['byteLength_']-=Pn(_0x3de07e),_0x5708c9['parts_']['length']>0x0&&(_0x5708c9['byteLength_']-=0x1);}function So(_0x44bad5){if(_0x44bad5['byteLength_']>Js)throw new Error(_0x44bad5['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x44bad5['byteLength_']+').');if(_0x44bad5['parts_']['length']>Qs)throw new Error(_0x44bad5['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x44bad5));}function Ne(_0x5d5d47){return _0x5d5d47['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5d5d47['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x1e2bdd,_0x318782;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x318782='visibilitychange',_0x1e2bdd='hidden'):typeof document['mozHidden']<'u'?(_0x318782='mozvisibilitychange',_0x1e2bdd='mozHidden'):typeof document['msHidden']<'u'?(_0x318782='msvisibilitychange',_0x1e2bdd='msHidden'):typeof document['webkitHidden']<'u'&&(_0x318782='webkitvisibilitychange',_0x1e2bdd='webkitHidden')),this['visible_']=!0x0,_0x318782&&document['addEventListener'](_0x318782,()=>{const _0x34cfe3=!document[_0x1e2bdd];_0x34cfe3!==this['visible_']&&(this['visible_']=_0x34cfe3,this['trigger']('visible',_0x34cfe3));},!0x1);}['getInitialEvent'](_0x1f1ade){return f(_0x1f1ade==='visible','Unknown\x20event\x20type:\x20'+_0x1f1ade),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5d204b,_0x205805,_0x43c468,_0x2a6736,_0x52f1cd,_0x276073,_0x591663,_0x2a6599){if(super(),this['repoInfo_']=_0x5d204b,this['applicationId_']=_0x205805,this['onDataUpdate_']=_0x43c468,this['onConnectStatus_']=_0x2a6736,this['onServerInfoUpdate_']=_0x52f1cd,this['authTokenProvider_']=_0x276073,this['appCheckTokenProvider_']=_0x591663,this['authOverride_']=_0x2a6599,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2a6599)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5d204b['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x322757,_0x4da5fc,_0x4a31f3){const _0x3c3df8=++this['requestNumber_'],_0x3b8f07={'r':_0x3c3df8,'a':_0x322757,'b':_0x4da5fc};this['log_'](O(_0x3b8f07)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3b8f07),_0x4a31f3&&(this['requestCBHash_'][_0x3c3df8]=_0x4a31f3);}['get'](_0x1507dc){this['initConnection_']();const _0x460727=new Ve(),_0x124d75={'action':'g','request':{'p':_0x1507dc['_path']['toString'](),'q':_0x1507dc['_queryObject']},'onComplete':_0x1d9b5c=>{const _0x33b5ca=_0x1d9b5c['d'];_0x1d9b5c['s']==='ok'?_0x460727['resolve'](_0x33b5ca):_0x460727['reject'](_0x33b5ca);}};this['outstandingGets_']['push'](_0x124d75),this['outstandingGetCount_']++;const _0x533eee=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x533eee),_0x460727['promise'];}['listen'](_0x1d3fc7,_0x507f05,_0x41d328,_0x1af2cb){this['initConnection_']();const _0x4b1ceb=_0x1d3fc7['_queryIdentifier'],_0x4f5aa7=_0x1d3fc7['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4f5aa7+'\x20'+_0x4b1ceb),this['listens']['has'](_0x4f5aa7)||this['listens']['set'](_0x4f5aa7,new Map()),f(_0x1d3fc7['_queryParams']['isDefault']()||!_0x1d3fc7['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4f5aa7)['has'](_0x4b1ceb),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x3ff592={'onComplete':_0x1af2cb,'hashFn':_0x507f05,'query':_0x1d3fc7,'tag':_0x41d328};this['listens']['get'](_0x4f5aa7)['set'](_0x4b1ceb,_0x3ff592),this['connected_']&&this['sendListen_'](_0x3ff592);}['sendGet_'](_0x3a6428){const _0x34ca89=this['outstandingGets_'][_0x3a6428];this['sendRequest']('g',_0x34ca89['request'],_0x5dd6a9=>{delete this['outstandingGets_'][_0x3a6428],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x34ca89['onComplete']&&_0x34ca89['onComplete'](_0x5dd6a9);});}['sendListen_'](_0x1b7e04){const _0x1de841=_0x1b7e04['query'],_0x26a025=_0x1de841['_path']['toString'](),_0x5b681c=_0x1de841['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x26a025+'\x20for\x20'+_0x5b681c);const _0x14b992={'p':_0x26a025},_0x374071='q';_0x1b7e04['tag']&&(_0x14b992['q']=_0x1de841['_queryObject'],_0x14b992['t']=_0x1b7e04['tag']),_0x14b992['h']=_0x1b7e04['hashFn'](),this['sendRequest'](_0x374071,_0x14b992,_0x518d78=>{const _0x407279=_0x518d78['d'],_0x461d3e=_0x518d78['s'];ie['warnOnListenWarnings_'](_0x407279,_0x1de841),(this['listens']['get'](_0x26a025)&&this['listens']['get'](_0x26a025)['get'](_0x5b681c))===_0x1b7e04&&(this['log_']('listen\x20response',_0x518d78),_0x461d3e!=='ok'&&this['removeListen_'](_0x26a025,_0x5b681c),_0x1b7e04['onComplete']&&_0x1b7e04['onComplete'](_0x461d3e,_0x407279));});}static['warnOnListenWarnings_'](_0x334865,_0x4a6afd){if(_0x334865&&typeof _0x334865=='object'&&Y(_0x334865,'w')){const _0x415c02=Oe(_0x334865,'w');if(Array['isArray'](_0x415c02)&&~_0x415c02['indexOf']('no_index')){const _0x5a4375='\x22.indexOn\x22:\x20\x22'+_0x4a6afd['_queryParams']['getIndex']()['toString']()+'\x22',_0xc8b255=_0x4a6afd['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5a4375+'\x20at\x20'+_0xc8b255+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x545e11){this['authToken_']=_0x545e11,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x545e11);}['reduceReconnectDelayIfAdminCredential_'](_0x1d3f36){(_0x1d3f36&&_0x1d3f36['length']===0x28||vc(_0x1d3f36))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1caf1d){this['appCheckToken_']=_0x1caf1d,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x9ea952=this['authToken_'],_0x39a23e=yc(_0x9ea952)?'auth':'gauth',_0x2354b9={'cred':_0x9ea952};this['authOverride_']===null?_0x2354b9['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x2354b9['authvar']=this['authOverride_']),this['sendRequest'](_0x39a23e,_0x2354b9,_0x303c02=>{const _0x39412c=_0x303c02['s'],_0x1acad4=_0x303c02['d']||'error';this['authToken_']===_0x9ea952&&(_0x39412c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x39412c,_0x1acad4));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1ac74b=>{const _0x42f6b6=_0x1ac74b['s'],_0x5cac81=_0x1ac74b['d']||'error';_0x42f6b6==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x42f6b6,_0x5cac81);});}['unlisten'](_0x513b47,_0x309656){const _0xe294b2=_0x513b47['_path']['toString'](),_0x23b635=_0x513b47['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xe294b2+'\x20'+_0x23b635),f(_0x513b47['_queryParams']['isDefault']()||!_0x513b47['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xe294b2,_0x23b635)&&this['connected_']&&this['sendUnlisten_'](_0xe294b2,_0x23b635,_0x513b47['_queryObject'],_0x309656);}['sendUnlisten_'](_0x255713,_0x555fa7,_0x1ec9df,_0x254981){this['log_']('Unlisten\x20on\x20'+_0x255713+'\x20for\x20'+_0x555fa7);const _0x4b772b={'p':_0x255713},_0x5c4ed0='n';_0x254981&&(_0x4b772b['q']=_0x1ec9df,_0x4b772b['t']=_0x254981),this['sendRequest'](_0x5c4ed0,_0x4b772b);}['onDisconnectPut'](_0x48ab7c,_0x346c83,_0x5bcaa4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x48ab7c,_0x346c83,_0x5bcaa4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x48ab7c,'action':'o','data':_0x346c83,'onComplete':_0x5bcaa4});}['onDisconnectMerge'](_0xf7b12d,_0x206171,_0x181b30){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xf7b12d,_0x206171,_0x181b30):this['onDisconnectRequestQueue_']['push']({'pathString':_0xf7b12d,'action':'om','data':_0x206171,'onComplete':_0x181b30});}['onDisconnectCancel'](_0x36a487,_0x50a55e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x36a487,null,_0x50a55e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x36a487,'action':'oc','data':null,'onComplete':_0x50a55e});}['sendOnDisconnect_'](_0x235358,_0x48a35d,_0x29f6c9,_0x23ac7f){const _0x2aebc7={'p':_0x48a35d,'d':_0x29f6c9};this['log_']('onDisconnect\x20'+_0x235358,_0x2aebc7),this['sendRequest'](_0x235358,_0x2aebc7,_0x25961c=>{_0x23ac7f&&setTimeout(()=>{_0x23ac7f(_0x25961c['s'],_0x25961c['d']);},Math['floor'](0x0));});}['put'](_0x41b22f,_0x4a8954,_0x21ad00,_0x270c58){this['putInternal']('p',_0x41b22f,_0x4a8954,_0x21ad00,_0x270c58);}['merge'](_0x4c8f14,_0x1ecd2c,_0x51948e,_0x513f34){this['putInternal']('m',_0x4c8f14,_0x1ecd2c,_0x51948e,_0x513f34);}['putInternal'](_0x5200ee,_0x503cf4,_0x486368,_0x313d5c,_0x15db69){this['initConnection_']();const _0x422e97={'p':_0x503cf4,'d':_0x486368};_0x15db69!==void 0x0&&(_0x422e97['h']=_0x15db69),this['outstandingPuts_']['push']({'action':_0x5200ee,'request':_0x422e97,'onComplete':_0x313d5c}),this['outstandingPutCount_']++;const _0x31e582=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x31e582):this['log_']('Buffering\x20put:\x20'+_0x503cf4);}['sendPut_'](_0x3e3d47){const _0x53bbe1=this['outstandingPuts_'][_0x3e3d47]['action'],_0x443175=this['outstandingPuts_'][_0x3e3d47]['request'],_0x4370d7=this['outstandingPuts_'][_0x3e3d47]['onComplete'];this['outstandingPuts_'][_0x3e3d47]['queued']=this['connected_'],this['sendRequest'](_0x53bbe1,_0x443175,_0x1e917d=>{this['log_'](_0x53bbe1+'\x20response',_0x1e917d),delete this['outstandingPuts_'][_0x3e3d47],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4370d7&&_0x4370d7(_0x1e917d['s'],_0x1e917d['d']);});}['reportStats'](_0x4306ef){if(this['connected_']){const _0x5e8770={'c':_0x4306ef};this['log_']('reportStats',_0x5e8770),this['sendRequest']('s',_0x5e8770,_0x1d6d8d=>{if(_0x1d6d8d['s']!=='ok'){const _0x250a7c=_0x1d6d8d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x250a7c);}});}}['onDataMessage_'](_0x10f519){if('r'in _0x10f519){this['log_']('from\x20server:\x20'+O(_0x10f519));const _0x10dcbc=_0x10f519['r'],_0x4169f8=this['requestCBHash_'][_0x10dcbc];_0x4169f8&&(delete this['requestCBHash_'][_0x10dcbc],_0x4169f8(_0x10f519['b']));}else{if('error'in _0x10f519)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x10f519['error'];'a'in _0x10f519&&this['onDataPush_'](_0x10f519['a'],_0x10f519['b']);}}['onDataPush_'](_0x39a09d,_0x50ab22){this['log_']('handleServerMessage',_0x39a09d,_0x50ab22),_0x39a09d==='d'?this['onDataUpdate_'](_0x50ab22['p'],_0x50ab22['d'],!0x1,_0x50ab22['t']):_0x39a09d==='m'?this['onDataUpdate_'](_0x50ab22['p'],_0x50ab22['d'],!0x0,_0x50ab22['t']):_0x39a09d==='c'?this['onListenRevoked_'](_0x50ab22['p'],_0x50ab22['q']):_0x39a09d==='ac'?this['onAuthRevoked_'](_0x50ab22['s'],_0x50ab22['d']):_0x39a09d==='apc'?this['onAppCheckRevoked_'](_0x50ab22['s'],_0x50ab22['d']):_0x39a09d==='sd'?this['onSecurityDebugPacket_'](_0x50ab22):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x39a09d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x574e2b,_0x295cac){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x574e2b),this['lastSessionId']=_0x295cac,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x6194f3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x6194f3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x17cc2e){_0x17cc2e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x17cc2e;}['onOnline_'](_0x268da3){_0x268da3?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2d07b4=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x319709=Math['max'](0x0,this['reconnectDelay_']-_0x2d07b4);_0x319709=Math['random']()*_0x319709,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x319709+'ms'),this['scheduleConnect_'](_0x319709),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4ad8bf=this['onDataMessage_']['bind'](this),_0x52fff0=this['onReady_']['bind'](this),_0x426fe3=this['onRealtimeDisconnect_']['bind'](this),_0x14c96a=this['id']+':'+ie['nextConnectionId_']++,_0x4a23fd=this['lastSessionId'];let _0xab85f=!0x1,_0x35d33b=null;const _0x1f598a=function(){_0x35d33b?_0x35d33b['close']():(_0xab85f=!0x0,_0x426fe3());},_0x478d5b=function(_0xb5971f){f(_0x35d33b,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x35d33b['sendRequest'](_0xb5971f);};this['realtime_']={'close':_0x1f598a,'sendRequest':_0x478d5b};const _0x1d2463=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3bf0c0,_0x449def]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1d2463),this['appCheckTokenProvider_']['getToken'](_0x1d2463)]);_0xab85f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3bf0c0&&_0x3bf0c0['accessToken'],this['appCheckToken_']=_0x449def&&_0x449def['token'],_0x35d33b=new wh(_0x14c96a,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4ad8bf,_0x52fff0,_0x426fe3,_0x3f970b=>{U(_0x3f970b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x4a23fd));}catch(_0x48a5f2){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x48a5f2),_0xab85f||(this['repoInfo_']['nodeAdmin']&&U(_0x48a5f2),_0x1f598a());}}}['interrupt'](_0x1e3595){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1e3595),this['interruptReasons_'][_0x1e3595]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x22d37d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x22d37d),delete this['interruptReasons_'][_0x22d37d],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1c00ef){const _0x129dae=_0x1c00ef-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x129dae});}['cancelSentTransactions_'](){for(let _0x525851=0x0;_0x525851<this['outstandingPuts_']['length'];_0x525851++){const _0x47cd3a=this['outstandingPuts_'][_0x525851];_0x47cd3a&&'h'in _0x47cd3a['request']&&_0x47cd3a['queued']&&(_0x47cd3a['onComplete']&&_0x47cd3a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x525851],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2c561a,_0x2067a8){let _0xce2444;_0x2067a8?_0xce2444=_0x2067a8['map'](_0x2b24f7=>Bi(_0x2b24f7))['join']('$'):_0xce2444='default';const _0x125746=this['removeListen_'](_0x2c561a,_0xce2444);_0x125746&&_0x125746['onComplete']&&_0x125746['onComplete']('permission_denied');}['removeListen_'](_0x296ef1,_0x6da9c0){const _0xa9a5d5=new C(_0x296ef1)['toString']();let _0x533089;if(this['listens']['has'](_0xa9a5d5)){const _0x319f69=this['listens']['get'](_0xa9a5d5);_0x533089=_0x319f69['get'](_0x6da9c0),_0x319f69['delete'](_0x6da9c0),_0x319f69['size']===0x0&&this['listens']['delete'](_0xa9a5d5);}else _0x533089=void 0x0;return _0x533089;}['onAuthRevoked_'](_0x15ccd0,_0x387114){L('Auth\x20token\x20revoked:\x20'+_0x15ccd0+'/'+_0x387114),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x15ccd0==='invalid_token'||_0x15ccd0==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x49bdf3,_0x5860fa){L('App\x20check\x20token\x20revoked:\x20'+_0x49bdf3+'/'+_0x5860fa),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x49bdf3==='invalid_token'||_0x49bdf3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4b9a79){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4b9a79):'msg'in _0x4b9a79&&console['log']('FIREBASE:\x20'+_0x4b9a79['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3c7db9 of this['listens']['values']())for(const _0x47907a of _0x3c7db9['values']())this['sendListen_'](_0x47907a);for(let _0x227ee8=0x0;_0x227ee8<this['outstandingPuts_']['length'];_0x227ee8++)this['outstandingPuts_'][_0x227ee8]&&this['sendPut_'](_0x227ee8);for(;this['onDisconnectRequestQueue_']['length'];){const _0x27e8e1=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x27e8e1['action'],_0x27e8e1['pathString'],_0x27e8e1['data'],_0x27e8e1['onComplete']);}for(let _0x2fa05b=0x0;_0x2fa05b<this['outstandingGets_']['length'];_0x2fa05b++)this['outstandingGets_'][_0x2fa05b]&&this['sendGet_'](_0x2fa05b);}['sendConnectStats_'](){const _0x1ee94f={};let _0x4d3569='js';_0x1ee94f['sdk.'+_0x4d3569+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1ee94f['framework.cordova']=0x1:qr()&&(_0x1ee94f['framework.reactnative']=0x1),this['reportStats'](_0x1ee94f);}['shouldReconnect_'](){const _0x37d48a=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x37d48a;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xf44990,_0x12445f){this['name']=_0xf44990,this['node']=_0x12445f;}static['Wrap'](_0x133fc5,_0x14d329){return new E(_0x133fc5,_0x14d329);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5e9bfb,_0x4ac479){const _0x481728=new E(xe,_0x5e9bfb),_0xcc446b=new E(xe,_0x4ac479);return this['compare'](_0x481728,_0xcc446b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x507e12){Xt=_0x507e12;}['compare'](_0x3824ef,_0x58da74){return He(_0x3824ef['name'],_0x58da74['name']);}['isDefinedOn'](_0xdf54e7){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2d0ab9,_0x3fad2e){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x57e080,_0x1a12fc){return f(typeof _0x57e080=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x57e080,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4af8ff,_0x4a8d7d,_0xfd0bb7,_0x247d2a,_0x40ee8f=null){this['isReverse_']=_0x247d2a,this['resultGenerator_']=_0x40ee8f,this['nodeStack_']=[];let _0x3e7aa5=0x1;for(;!_0x4af8ff['isEmpty']();)if(_0x4af8ff=_0x4af8ff,_0x3e7aa5=_0x4a8d7d?_0xfd0bb7(_0x4af8ff['key'],_0x4a8d7d):0x1,_0x247d2a&&(_0x3e7aa5*=-0x1),_0x3e7aa5<0x0)this['isReverse_']?_0x4af8ff=_0x4af8ff['left']:_0x4af8ff=_0x4af8ff['right'];else{if(_0x3e7aa5===0x0){this['nodeStack_']['push'](_0x4af8ff);break;}else this['nodeStack_']['push'](_0x4af8ff),this['isReverse_']?_0x4af8ff=_0x4af8ff['right']:_0x4af8ff=_0x4af8ff['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x168412=this['nodeStack_']['pop'](),_0x3845e8;if(this['resultGenerator_']?_0x3845e8=this['resultGenerator_'](_0x168412['key'],_0x168412['value']):_0x3845e8={'key':_0x168412['key'],'value':_0x168412['value']},this['isReverse_']){for(_0x168412=_0x168412['left'];!_0x168412['isEmpty']();)this['nodeStack_']['push'](_0x168412),_0x168412=_0x168412['right'];}else{for(_0x168412=_0x168412['right'];!_0x168412['isEmpty']();)this['nodeStack_']['push'](_0x168412),_0x168412=_0x168412['left'];}return _0x3845e8;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x410d5b=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x410d5b['key'],_0x410d5b['value']):{'key':_0x410d5b['key'],'value':_0x410d5b['value']};}}class M{constructor(_0x2522b8,_0x510007,_0x324ea2,_0x9b8d94,_0x19cd78){this['key']=_0x2522b8,this['value']=_0x510007,this['color']=_0x324ea2??M['RED'],this['left']=_0x9b8d94??B['EMPTY_NODE'],this['right']=_0x19cd78??B['EMPTY_NODE'];}['copy'](_0x338f07,_0x5ecd07,_0x3d9419,_0xd1e43c,_0xd338be){return new M(_0x338f07??this['key'],_0x5ecd07??this['value'],_0x3d9419??this['color'],_0xd1e43c??this['left'],_0xd338be??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x54392c){return this['left']['inorderTraversal'](_0x54392c)||!!_0x54392c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x54392c);}['reverseTraversal'](_0x49db8f){return this['right']['reverseTraversal'](_0x49db8f)||_0x49db8f(this['key'],this['value'])||this['left']['reverseTraversal'](_0x49db8f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2186b9,_0x4f5e91,_0x3e2ba9){let _0x34049e=this;const _0xcf9d3d=_0x3e2ba9(_0x2186b9,_0x34049e['key']);return _0xcf9d3d<0x0?_0x34049e=_0x34049e['copy'](null,null,null,_0x34049e['left']['insert'](_0x2186b9,_0x4f5e91,_0x3e2ba9),null):_0xcf9d3d===0x0?_0x34049e=_0x34049e['copy'](null,_0x4f5e91,null,null,null):_0x34049e=_0x34049e['copy'](null,null,null,null,_0x34049e['right']['insert'](_0x2186b9,_0x4f5e91,_0x3e2ba9)),_0x34049e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x773ad6=this;return!_0x773ad6['left']['isRed_']()&&!_0x773ad6['left']['left']['isRed_']()&&(_0x773ad6=_0x773ad6['moveRedLeft_']()),_0x773ad6=_0x773ad6['copy'](null,null,null,_0x773ad6['left']['removeMin_'](),null),_0x773ad6['fixUp_']();}['remove'](_0xceb62b,_0x58c1e8){let _0xade928,_0x49d8ff;if(_0xade928=this,_0x58c1e8(_0xceb62b,_0xade928['key'])<0x0)!_0xade928['left']['isEmpty']()&&!_0xade928['left']['isRed_']()&&!_0xade928['left']['left']['isRed_']()&&(_0xade928=_0xade928['moveRedLeft_']()),_0xade928=_0xade928['copy'](null,null,null,_0xade928['left']['remove'](_0xceb62b,_0x58c1e8),null);else{if(_0xade928['left']['isRed_']()&&(_0xade928=_0xade928['rotateRight_']()),!_0xade928['right']['isEmpty']()&&!_0xade928['right']['isRed_']()&&!_0xade928['right']['left']['isRed_']()&&(_0xade928=_0xade928['moveRedRight_']()),_0x58c1e8(_0xceb62b,_0xade928['key'])===0x0){if(_0xade928['right']['isEmpty']())return B['EMPTY_NODE'];_0x49d8ff=_0xade928['right']['min_'](),_0xade928=_0xade928['copy'](_0x49d8ff['key'],_0x49d8ff['value'],null,null,_0xade928['right']['removeMin_']());}_0xade928=_0xade928['copy'](null,null,null,null,_0xade928['right']['remove'](_0xceb62b,_0x58c1e8));}return _0xade928['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x386248=this;return _0x386248['right']['isRed_']()&&!_0x386248['left']['isRed_']()&&(_0x386248=_0x386248['rotateLeft_']()),_0x386248['left']['isRed_']()&&_0x386248['left']['left']['isRed_']()&&(_0x386248=_0x386248['rotateRight_']()),_0x386248['left']['isRed_']()&&_0x386248['right']['isRed_']()&&(_0x386248=_0x386248['colorFlip_']()),_0x386248;}['moveRedLeft_'](){let _0x2f12e3=this['colorFlip_']();return _0x2f12e3['right']['left']['isRed_']()&&(_0x2f12e3=_0x2f12e3['copy'](null,null,null,null,_0x2f12e3['right']['rotateRight_']()),_0x2f12e3=_0x2f12e3['rotateLeft_'](),_0x2f12e3=_0x2f12e3['colorFlip_']()),_0x2f12e3;}['moveRedRight_'](){let _0x6bcc55=this['colorFlip_']();return _0x6bcc55['left']['left']['isRed_']()&&(_0x6bcc55=_0x6bcc55['rotateRight_'](),_0x6bcc55=_0x6bcc55['colorFlip_']()),_0x6bcc55;}['rotateLeft_'](){const _0x66fc73=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x66fc73,null);}['rotateRight_'](){const _0x12bb57=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x12bb57);}['colorFlip_'](){const _0xa47f7b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xa65578=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xa47f7b,_0xa65578);}['checkMaxDepth_'](){const _0x885ef2=this['check_']();return Math['pow'](0x2,_0x885ef2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xba58b=this['left']['check_']();if(_0xba58b!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xba58b+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x1ee649,_0x862a50,_0x5a68d4,_0x42b812,_0x27d3e0){return this;}['insert'](_0x4de133,_0x51421c,_0x1d5586){return new M(_0x4de133,_0x51421c,null);}['remove'](_0x3ecfd4,_0x341cd0){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x21b7bf){return!0x1;}['reverseTraversal'](_0x357e87){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x42b92f,_0x1962aa=B['EMPTY_NODE']){this['comparator_']=_0x42b92f,this['root_']=_0x1962aa;}['insert'](_0x4a428f,_0x14b62b){return new B(this['comparator_'],this['root_']['insert'](_0x4a428f,_0x14b62b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x37bc32){return new B(this['comparator_'],this['root_']['remove'](_0x37bc32,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3e1d9b){let _0x7157bf,_0xd9e471=this['root_'];for(;!_0xd9e471['isEmpty']();){if(_0x7157bf=this['comparator_'](_0x3e1d9b,_0xd9e471['key']),_0x7157bf===0x0)return _0xd9e471['value'];_0x7157bf<0x0?_0xd9e471=_0xd9e471['left']:_0x7157bf>0x0&&(_0xd9e471=_0xd9e471['right']);}return null;}['getPredecessorKey'](_0x165d67){let _0x345733,_0x2bc33b=this['root_'],_0x6feda7=null;for(;!_0x2bc33b['isEmpty']();)if(_0x345733=this['comparator_'](_0x165d67,_0x2bc33b['key']),_0x345733===0x0){if(_0x2bc33b['left']['isEmpty']())return _0x6feda7?_0x6feda7['key']:null;for(_0x2bc33b=_0x2bc33b['left'];!_0x2bc33b['right']['isEmpty']();)_0x2bc33b=_0x2bc33b['right'];return _0x2bc33b['key'];}else _0x345733<0x0?_0x2bc33b=_0x2bc33b['left']:_0x345733>0x0&&(_0x6feda7=_0x2bc33b,_0x2bc33b=_0x2bc33b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x340de5){return this['root_']['inorderTraversal'](_0x340de5);}['reverseTraversal'](_0x382f16){return this['root_']['reverseTraversal'](_0x382f16);}['getIterator'](_0x37e1d1){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x37e1d1);}['getIteratorFrom'](_0x38ec10,_0x3b0c14){return new Zt(this['root_'],_0x38ec10,this['comparator_'],!0x1,_0x3b0c14);}['getReverseIteratorFrom'](_0x512209,_0x22ca93){return new Zt(this['root_'],_0x512209,this['comparator_'],!0x0,_0x22ca93);}['getReverseIterator'](_0x5d52ca){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x5d52ca);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x569b95,_0x169085){return He(_0x569b95['name'],_0x169085['name']);}function ji(_0x382862,_0x38877f){return He(_0x382862,_0x38877f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x480591){vi=_0x480591;}const Ro=function(_0x3c4bce){return typeof _0x3c4bce=='number'?'number:'+so(_0x3c4bce):'string:'+_0x3c4bce;},Ao=function(_0x41a4d2){if(_0x41a4d2['isLeafNode']()){const _0xfc455c=_0x41a4d2['val']();f(typeof _0xfc455c=='string'||typeof _0xfc455c=='number'||typeof _0xfc455c=='object'&&Y(_0xfc455c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x41a4d2===vi||_0x41a4d2['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x41a4d2===vi||_0x41a4d2['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x42fe8d){er=_0x42fe8d;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2c0c74,_0x27875f=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2c0c74,this['priorityNode_']=_0x27875f,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x48b3ad){return new D(this['value_'],_0x48b3ad);}['getImmediateChild'](_0x41356b){return _0x41356b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4aa2eb){return v(_0x4aa2eb)?this:y(_0x4aa2eb)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3b6441,_0xf44b49){return null;}['updateImmediateChild'](_0x67ea1e,_0x26802f){return _0x67ea1e==='.priority'?this['updatePriority'](_0x26802f):_0x26802f['isEmpty']()&&_0x67ea1e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x67ea1e,_0x26802f)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x24222a,_0x1125c6){const _0x3f11f0=y(_0x24222a);return _0x3f11f0===null?_0x1125c6:_0x1125c6['isEmpty']()&&_0x3f11f0!=='.priority'?this:(f(_0x3f11f0!=='.priority'||we(_0x24222a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3f11f0,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x24222a),_0x1125c6)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4afb3a,_0xd36887){return!0x1;}['val'](_0x45d186){return _0x45d186&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xda1fb8='';this['priorityNode_']['isEmpty']()||(_0xda1fb8+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x19cfba=typeof this['value_'];_0xda1fb8+=_0x19cfba+':',_0x19cfba==='number'?_0xda1fb8+=so(this['value_']):_0xda1fb8+=this['value_'],this['lazyHash_']=no(_0xda1fb8);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x43b354){return _0x43b354===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x43b354 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x43b354['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x43b354));}['compareToLeafNode_'](_0x23c70e){const _0x2674bd=typeof _0x23c70e['value_'],_0xf1ac62=typeof this['value_'],_0x5ebe97=D['VALUE_TYPE_ORDER']['indexOf'](_0x2674bd),_0x1a4c58=D['VALUE_TYPE_ORDER']['indexOf'](_0xf1ac62);return f(_0x5ebe97>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2674bd),f(_0x1a4c58>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xf1ac62),_0x5ebe97===_0x1a4c58?_0xf1ac62==='object'?0x0:this['value_']<_0x23c70e['value_']?-0x1:this['value_']===_0x23c70e['value_']?0x0:0x1:_0x1a4c58-_0x5ebe97;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x546e1e){if(_0x546e1e===this)return!0x0;if(_0x546e1e['isLeafNode']()){const _0x4eeff8=_0x546e1e;return this['value_']===_0x4eeff8['value_']&&this['priorityNode_']['equals'](_0x4eeff8['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x2a8390){ko=_0x2a8390;}function xh(_0x1e28f2){No=_0x1e28f2;}class Fh extends On{['compare'](_0xd8bd79,_0x6b1fa5){const _0x2cc750=_0xd8bd79['node']['getPriority'](),_0x3fcdbc=_0x6b1fa5['node']['getPriority'](),_0x591fed=_0x2cc750['compareTo'](_0x3fcdbc);return _0x591fed===0x0?He(_0xd8bd79['name'],_0x6b1fa5['name']):_0x591fed;}['isDefinedOn'](_0x3a4e87){return!_0x3a4e87['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3f17cb,_0x29bbac){return!_0x3f17cb['getPriority']()['equals'](_0x29bbac['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x32734b,_0x2c06dc){const _0x24a1a0=ko(_0x32734b);return new E(_0x2c06dc,new D('[PRIORITY-POST]',_0x24a1a0));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x58eb62){const _0x152feb=_0x56df6e=>parseInt(Math['log'](_0x56df6e)/Uh,0xa),_0x27bd1b=_0xffd1c6=>parseInt(Array(_0xffd1c6+0x1)['join']('1'),0x2);this['count']=_0x152feb(_0x58eb62+0x1),this['current_']=this['count']-0x1;const _0x32bf9f=_0x27bd1b(this['count']);this['bits_']=_0x58eb62+0x1&_0x32bf9f;}['nextBitIsOne'](){const _0x4813bc=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4813bc;}}const dn=function(_0xca297c,_0xb81b1d,_0xbaf937,_0x344ae9){_0xca297c['sort'](_0xb81b1d);const _0x33b139=function(_0x1341f5,_0x26ee64){const _0x3d5a1b=_0x26ee64-_0x1341f5;let _0x2be996,_0x32bbbb;if(_0x3d5a1b===0x0)return null;if(_0x3d5a1b===0x1)return _0x2be996=_0xca297c[_0x1341f5],_0x32bbbb=_0xbaf937?_0xbaf937(_0x2be996):_0x2be996,new M(_0x32bbbb,_0x2be996['node'],M['BLACK'],null,null);{const _0x31b94b=parseInt(_0x3d5a1b/0x2,0xa)+_0x1341f5,_0x15123e=_0x33b139(_0x1341f5,_0x31b94b),_0x325f78=_0x33b139(_0x31b94b+0x1,_0x26ee64);return _0x2be996=_0xca297c[_0x31b94b],_0x32bbbb=_0xbaf937?_0xbaf937(_0x2be996):_0x2be996,new M(_0x32bbbb,_0x2be996['node'],M['BLACK'],_0x15123e,_0x325f78);}},_0x30e9bd=function(_0x54bde9){let _0x3e567b=null,_0x3dec7d=null,_0x5538ed=_0xca297c['length'];const _0x52b01c=function(_0x410458,_0x247320){const _0x28b32b=_0x5538ed-_0x410458,_0x492be0=_0x5538ed;_0x5538ed-=_0x410458;const _0x209873=_0x33b139(_0x28b32b+0x1,_0x492be0),_0x64b4b2=_0xca297c[_0x28b32b],_0x48a058=_0xbaf937?_0xbaf937(_0x64b4b2):_0x64b4b2;_0x2b00c9(new M(_0x48a058,_0x64b4b2['node'],_0x247320,null,_0x209873));},_0x2b00c9=function(_0x4cfa11){_0x3e567b?(_0x3e567b['left']=_0x4cfa11,_0x3e567b=_0x4cfa11):(_0x3dec7d=_0x4cfa11,_0x3e567b=_0x4cfa11);};for(let _0x2acb17=0x0;_0x2acb17<_0x54bde9['count'];++_0x2acb17){const _0xbdc84b=_0x54bde9['nextBitIsOne'](),_0x2a2a7d=Math['pow'](0x2,_0x54bde9['count']-(_0x2acb17+0x1));_0xbdc84b?_0x52b01c(_0x2a2a7d,M['BLACK']):(_0x52b01c(_0x2a2a7d,M['BLACK']),_0x52b01c(_0x2a2a7d,M['RED']));}return _0x3dec7d;},_0x3afaf9=new Wh(_0xca297c['length']),_0x4da1b3=_0x30e9bd(_0x3afaf9);return new B(_0x344ae9||_0xb81b1d,_0x4da1b3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0xfd7762,_0x49b9c2){this['indexes_']=_0xfd7762,this['indexSet_']=_0x49b9c2;}['get'](_0x1af86c){const _0x5eee4a=Oe(this['indexes_'],_0x1af86c);if(!_0x5eee4a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1af86c);return _0x5eee4a instanceof B?_0x5eee4a:null;}['hasIndex'](_0x3d2e44){return Y(this['indexSet_'],_0x3d2e44['toString']());}['addIndex'](_0x1e1202,_0x11e146){f(_0x1e1202!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x557444=[];let _0x574903=!0x1;const _0x59abe9=_0x11e146['getIterator'](E['Wrap']);let _0x1fa6eb=_0x59abe9['getNext']();for(;_0x1fa6eb;)_0x574903=_0x574903||_0x1e1202['isDefinedOn'](_0x1fa6eb['node']),_0x557444['push'](_0x1fa6eb),_0x1fa6eb=_0x59abe9['getNext']();let _0x242b30;_0x574903?_0x242b30=dn(_0x557444,_0x1e1202['getCompare']()):_0x242b30=je;const _0x20ab3a=_0x1e1202['toString'](),_0x4b47cd={...this['indexSet_']};_0x4b47cd[_0x20ab3a]=_0x1e1202;const _0x2a04c1={...this['indexes_']};return _0x2a04c1[_0x20ab3a]=_0x242b30,new ee(_0x2a04c1,_0x4b47cd);}['addToIndexes'](_0x32668e,_0x64af67){const _0x25cbda=ln(this['indexes_'],(_0x7ea493,_0x4ff5d8)=>{const _0x5b2953=Oe(this['indexSet_'],_0x4ff5d8);if(f(_0x5b2953,'Missing\x20index\x20implementation\x20for\x20'+_0x4ff5d8),_0x7ea493===je){if(_0x5b2953['isDefinedOn'](_0x32668e['node'])){const _0x558155=[],_0x141a63=_0x64af67['getIterator'](E['Wrap']);let _0x3f4cf=_0x141a63['getNext']();for(;_0x3f4cf;)_0x3f4cf['name']!==_0x32668e['name']&&_0x558155['push'](_0x3f4cf),_0x3f4cf=_0x141a63['getNext']();return _0x558155['push'](_0x32668e),dn(_0x558155,_0x5b2953['getCompare']());}else return je;}else{const _0x52a2dd=_0x64af67['get'](_0x32668e['name']);let _0x6135e2=_0x7ea493;return _0x52a2dd&&(_0x6135e2=_0x6135e2['remove'](new E(_0x32668e['name'],_0x52a2dd))),_0x6135e2['insert'](_0x32668e,_0x32668e['node']);}});return new ee(_0x25cbda,this['indexSet_']);}['removeFromIndexes'](_0x744db3,_0x41b897){const _0x153f41=ln(this['indexes_'],_0x39422e=>{if(_0x39422e===je)return _0x39422e;{const _0x5c7187=_0x41b897['get'](_0x744db3['name']);return _0x5c7187?_0x39422e['remove'](new E(_0x744db3['name'],_0x5c7187)):_0x39422e;}});return new ee(_0x153f41,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x59d708,_0x5c1ae9,_0x3ce5b0){this['children_']=_0x59d708,this['priorityNode_']=_0x5c1ae9,this['indexMap_']=_0x3ce5b0,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x26c15a){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x26c15a,this['indexMap_']);}['getImmediateChild'](_0x420c28){if(_0x420c28==='.priority')return this['getPriority']();{const _0x4acdc0=this['children_']['get'](_0x420c28);return _0x4acdc0===null?gt:_0x4acdc0;}}['getChild'](_0x41ac44){const _0x105abc=y(_0x41ac44);return _0x105abc===null?this:this['getImmediateChild'](_0x105abc)['getChild'](b(_0x41ac44));}['hasChild'](_0x2925b7){return this['children_']['get'](_0x2925b7)!==null;}['updateImmediateChild'](_0x31a387,_0x1a87c3){if(f(_0x1a87c3,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x31a387==='.priority')return this['updatePriority'](_0x1a87c3);{const _0x276fb5=new E(_0x31a387,_0x1a87c3);let _0x5d5e8f,_0x1eac76;_0x1a87c3['isEmpty']()?(_0x5d5e8f=this['children_']['remove'](_0x31a387),_0x1eac76=this['indexMap_']['removeFromIndexes'](_0x276fb5,this['children_'])):(_0x5d5e8f=this['children_']['insert'](_0x31a387,_0x1a87c3),_0x1eac76=this['indexMap_']['addToIndexes'](_0x276fb5,this['children_']));const _0x801fac=_0x5d5e8f['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5d5e8f,_0x801fac,_0x1eac76);}}['updateChild'](_0x4c5158,_0x580f5e){const _0x59e704=y(_0x4c5158);if(_0x59e704===null)return _0x580f5e;{f(y(_0x4c5158)!=='.priority'||we(_0x4c5158)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5d10bb=this['getImmediateChild'](_0x59e704)['updateChild'](b(_0x4c5158),_0x580f5e);return this['updateImmediateChild'](_0x59e704,_0x5d10bb);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1e6d35){if(this['isEmpty']())return null;const _0x438ae4={};let _0x1e43c1=0x0,_0x437b4a=0x0,_0x15973d=!0x0;if(this['forEachChild'](R,(_0x5d39c0,_0x1ebaf4)=>{_0x438ae4[_0x5d39c0]=_0x1ebaf4['val'](_0x1e6d35),_0x1e43c1++,_0x15973d&&g['INTEGER_REGEXP_']['test'](_0x5d39c0)?_0x437b4a=Math['max'](_0x437b4a,Number(_0x5d39c0)):_0x15973d=!0x1;}),!_0x1e6d35&&_0x15973d&&_0x437b4a<0x2*_0x1e43c1){const _0x5e0dff=[];for(const _0xc7a396 in _0x438ae4)_0x5e0dff[_0xc7a396]=_0x438ae4[_0xc7a396];return _0x5e0dff;}else return _0x1e6d35&&!this['getPriority']()['isEmpty']()&&(_0x438ae4['.priority']=this['getPriority']()['val']()),_0x438ae4;}['hash'](){if(this['lazyHash_']===null){let _0x228a4e='';this['getPriority']()['isEmpty']()||(_0x228a4e+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x539546,_0x44f1f0)=>{const _0x4d7049=_0x44f1f0['hash']();_0x4d7049!==''&&(_0x228a4e+=':'+_0x539546+':'+_0x4d7049);}),this['lazyHash_']=_0x228a4e===''?'':no(_0x228a4e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4ca3f,_0x5c5633,_0x2c27c3){const _0x499829=this['resolveIndex_'](_0x2c27c3);if(_0x499829){const _0x2b5db5=_0x499829['getPredecessorKey'](new E(_0x4ca3f,_0x5c5633));return _0x2b5db5?_0x2b5db5['name']:null;}else return this['children_']['getPredecessorKey'](_0x4ca3f);}['getFirstChildName'](_0x5df9a7){const _0x548fcb=this['resolveIndex_'](_0x5df9a7);if(_0x548fcb){const _0x24d695=_0x548fcb['minKey']();return _0x24d695&&_0x24d695['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x28469c){const _0x7b7e59=this['getFirstChildName'](_0x28469c);return _0x7b7e59?new E(_0x7b7e59,this['children_']['get'](_0x7b7e59)):null;}['getLastChildName'](_0x33a1a8){const _0x2abdc5=this['resolveIndex_'](_0x33a1a8);if(_0x2abdc5){const _0x339b97=_0x2abdc5['maxKey']();return _0x339b97&&_0x339b97['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5d3dfe){const _0x4a6f58=this['getLastChildName'](_0x5d3dfe);return _0x4a6f58?new E(_0x4a6f58,this['children_']['get'](_0x4a6f58)):null;}['forEachChild'](_0x137699,_0x54d25a){const _0x8139cb=this['resolveIndex_'](_0x137699);return _0x8139cb?_0x8139cb['inorderTraversal'](_0x190380=>_0x54d25a(_0x190380['name'],_0x190380['node'])):this['children_']['inorderTraversal'](_0x54d25a);}['getIterator'](_0x54825f){return this['getIteratorFrom'](_0x54825f['minPost'](),_0x54825f);}['getIteratorFrom'](_0x43f953,_0x153872){const _0x5d37b5=this['resolveIndex_'](_0x153872);if(_0x5d37b5)return _0x5d37b5['getIteratorFrom'](_0x43f953,_0x14df2d=>_0x14df2d);{const _0x3ac2ad=this['children_']['getIteratorFrom'](_0x43f953['name'],E['Wrap']);let _0x2e6ba6=_0x3ac2ad['peek']();for(;_0x2e6ba6!=null&&_0x153872['compare'](_0x2e6ba6,_0x43f953)<0x0;)_0x3ac2ad['getNext'](),_0x2e6ba6=_0x3ac2ad['peek']();return _0x3ac2ad;}}['getReverseIterator'](_0x433259){return this['getReverseIteratorFrom'](_0x433259['maxPost'](),_0x433259);}['getReverseIteratorFrom'](_0x52dd9e,_0x3e68ac){const _0x13ee5f=this['resolveIndex_'](_0x3e68ac);if(_0x13ee5f)return _0x13ee5f['getReverseIteratorFrom'](_0x52dd9e,_0xb33077=>_0xb33077);{const _0x2292dd=this['children_']['getReverseIteratorFrom'](_0x52dd9e['name'],E['Wrap']);let _0x1c3f3b=_0x2292dd['peek']();for(;_0x1c3f3b!=null&&_0x3e68ac['compare'](_0x1c3f3b,_0x52dd9e)>0x0;)_0x2292dd['getNext'](),_0x1c3f3b=_0x2292dd['peek']();return _0x2292dd;}}['compareTo'](_0x29aab5){return this['isEmpty']()?_0x29aab5['isEmpty']()?0x0:-0x1:_0x29aab5['isLeafNode']()||_0x29aab5['isEmpty']()?0x1:_0x29aab5===Ht?-0x1:0x0;}['withIndex'](_0x31afc6){if(_0x31afc6===ye||this['indexMap_']['hasIndex'](_0x31afc6))return this;{const _0x285fd4=this['indexMap_']['addIndex'](_0x31afc6,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x285fd4);}}['isIndexed'](_0x5de0f5){return _0x5de0f5===ye||this['indexMap_']['hasIndex'](_0x5de0f5);}['equals'](_0x11dfee){if(_0x11dfee===this)return!0x0;if(_0x11dfee['isLeafNode']())return!0x1;{const _0x5dd7dc=_0x11dfee;if(this['getPriority']()['equals'](_0x5dd7dc['getPriority']())){if(this['children_']['count']()===_0x5dd7dc['children_']['count']()){const _0x59e129=this['getIterator'](R),_0x300cae=_0x5dd7dc['getIterator'](R);let _0x3c769b=_0x59e129['getNext'](),_0x3fe4f5=_0x300cae['getNext']();for(;_0x3c769b&&_0x3fe4f5;){if(_0x3c769b['name']!==_0x3fe4f5['name']||!_0x3c769b['node']['equals'](_0x3fe4f5['node']))return!0x1;_0x3c769b=_0x59e129['getNext'](),_0x3fe4f5=_0x300cae['getNext']();}return _0x3c769b===null&&_0x3fe4f5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1bde57){return _0x1bde57===ye?null:this['indexMap_']['get'](_0x1bde57['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x28e525){return _0x28e525===this?0x0:0x1;}['equals'](_0x3e1a16){return _0x3e1a16===this;}['getPriority'](){return this;}['getImmediateChild'](_0x299694){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x50b4ff,_0xc5d7a1=null){if(_0x50b4ff===null)return g['EMPTY_NODE'];if(typeof _0x50b4ff=='object'&&'.priority'in _0x50b4ff&&(_0xc5d7a1=_0x50b4ff['.priority']),f(_0xc5d7a1===null||typeof _0xc5d7a1=='string'||typeof _0xc5d7a1=='number'||typeof _0xc5d7a1=='object'&&'.sv'in _0xc5d7a1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xc5d7a1),typeof _0x50b4ff=='object'&&'.value'in _0x50b4ff&&_0x50b4ff['.value']!==null&&(_0x50b4ff=_0x50b4ff['.value']),typeof _0x50b4ff!='object'||'.sv'in _0x50b4ff){const _0x59c50f=_0x50b4ff;return new D(_0x59c50f,N(_0xc5d7a1));}if(!(_0x50b4ff instanceof Array)&&Vh){const _0x193e05=[];let _0x320b44=!0x1;if(x(_0x50b4ff,(_0x11fb71,_0x233c01)=>{if(_0x11fb71['substring'](0x0,0x1)!=='.'){const _0xef11d6=N(_0x233c01);_0xef11d6['isEmpty']()||(_0x320b44=_0x320b44||!_0xef11d6['getPriority']()['isEmpty'](),_0x193e05['push'](new E(_0x11fb71,_0xef11d6)));}}),_0x193e05['length']===0x0)return g['EMPTY_NODE'];const _0x427c4a=dn(_0x193e05,Dh,_0xf544d1=>_0xf544d1['name'],ji);if(_0x320b44){const _0x56c412=dn(_0x193e05,R['getCompare']());return new g(_0x427c4a,N(_0xc5d7a1),new ee({'.priority':_0x56c412},{'.priority':R}));}else return new g(_0x427c4a,N(_0xc5d7a1),ee['Default']);}else{let _0x5833b3=g['EMPTY_NODE'];return x(_0x50b4ff,(_0x47cf2d,_0x1fdc5f)=>{if(Y(_0x50b4ff,_0x47cf2d)&&_0x47cf2d['substring'](0x0,0x1)!=='.'){const _0x305621=N(_0x1fdc5f);(_0x305621['isLeafNode']()||!_0x305621['isEmpty']())&&(_0x5833b3=_0x5833b3['updateImmediateChild'](_0x47cf2d,_0x305621));}}),_0x5833b3['updatePriority'](N(_0xc5d7a1));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x412b7f){super(),this['indexPath_']=_0x412b7f,f(!v(_0x412b7f)&&y(_0x412b7f)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2c9c24){return _0x2c9c24['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4d755d){return!_0x4d755d['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x338ff0,_0x2007bc){const _0xe313e8=this['extractChild'](_0x338ff0['node']),_0x4b785c=this['extractChild'](_0x2007bc['node']),_0xedd492=_0xe313e8['compareTo'](_0x4b785c);return _0xedd492===0x0?He(_0x338ff0['name'],_0x2007bc['name']):_0xedd492;}['makePost'](_0x1c8bd9,_0xb9d6cd){const _0x58471b=N(_0x1c8bd9),_0x5a03d2=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x58471b);return new E(_0xb9d6cd,_0x5a03d2);}['maxPost'](){const _0x301b56=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x301b56);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x29bf51,_0x12852f){const _0x436511=_0x29bf51['node']['compareTo'](_0x12852f['node']);return _0x436511===0x0?He(_0x29bf51['name'],_0x12852f['name']):_0x436511;}['isDefinedOn'](_0x56f88f){return!0x0;}['indexedValueChanged'](_0x2ee4fe,_0x3b7ce1){return!_0x2ee4fe['equals'](_0x3b7ce1);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3084b0,_0x1156d1){const _0x13d323=N(_0x3084b0);return new E(_0x1156d1,_0x13d323);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0xb57b8d){return{'type':'value','snapshotNode':_0xb57b8d};}function tt(_0x591247,_0x11dc3b){return{'type':'child_added','snapshotNode':_0x11dc3b,'childName':_0x591247};}function Nt(_0xcf033c,_0x5ba455){return{'type':'child_removed','snapshotNode':_0x5ba455,'childName':_0xcf033c};}function Pt(_0x596edd,_0x283ca1,_0x52d96a){return{'type':'child_changed','snapshotNode':_0x283ca1,'childName':_0x596edd,'oldSnap':_0x52d96a};}function $h(_0x52aa87,_0x2f480b){return{'type':'child_moved','snapshotNode':_0x2f480b,'childName':_0x52aa87};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x43dd07){this['index_']=_0x43dd07;}['updateChild'](_0x14a77d,_0x2641fa,_0x4bb392,_0x48ecb7,_0x4782b0,_0x2efb06){f(_0x14a77d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2d6e97=_0x14a77d['getImmediateChild'](_0x2641fa);return _0x2d6e97['getChild'](_0x48ecb7)['equals'](_0x4bb392['getChild'](_0x48ecb7))&&_0x2d6e97['isEmpty']()===_0x4bb392['isEmpty']()||(_0x2efb06!=null&&(_0x4bb392['isEmpty']()?_0x14a77d['hasChild'](_0x2641fa)?_0x2efb06['trackChildChange'](Nt(_0x2641fa,_0x2d6e97)):f(_0x14a77d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2d6e97['isEmpty']()?_0x2efb06['trackChildChange'](tt(_0x2641fa,_0x4bb392)):_0x2efb06['trackChildChange'](Pt(_0x2641fa,_0x4bb392,_0x2d6e97))),_0x14a77d['isLeafNode']()&&_0x4bb392['isEmpty']())?_0x14a77d:_0x14a77d['updateImmediateChild'](_0x2641fa,_0x4bb392)['withIndex'](this['index_']);}['updateFullNode'](_0x2e29b0,_0x21dd59,_0x1c0f68){return _0x1c0f68!=null&&(_0x2e29b0['isLeafNode']()||_0x2e29b0['forEachChild'](R,(_0x2f5be4,_0x45a6fa)=>{_0x21dd59['hasChild'](_0x2f5be4)||_0x1c0f68['trackChildChange'](Nt(_0x2f5be4,_0x45a6fa));}),_0x21dd59['isLeafNode']()||_0x21dd59['forEachChild'](R,(_0x2b00e8,_0x26ea82)=>{if(_0x2e29b0['hasChild'](_0x2b00e8)){const _0x5e1866=_0x2e29b0['getImmediateChild'](_0x2b00e8);_0x5e1866['equals'](_0x26ea82)||_0x1c0f68['trackChildChange'](Pt(_0x2b00e8,_0x26ea82,_0x5e1866));}else _0x1c0f68['trackChildChange'](tt(_0x2b00e8,_0x26ea82));})),_0x21dd59['withIndex'](this['index_']);}['updatePriority'](_0x4fbb22,_0x3996b5){return _0x4fbb22['isEmpty']()?g['EMPTY_NODE']:_0x4fbb22['updatePriority'](_0x3996b5);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0xcb78ab){this['indexedFilter_']=new Yi(_0xcb78ab['getIndex']()),this['index_']=_0xcb78ab['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0xcb78ab),this['endPost_']=Ot['getEndPost_'](_0xcb78ab),this['startIsInclusive_']=!_0xcb78ab['startAfterSet_'],this['endIsInclusive_']=!_0xcb78ab['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4c8137){const _0xea9772=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4c8137)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4c8137)<0x0,_0x34a978=this['endIsInclusive_']?this['index_']['compare'](_0x4c8137,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4c8137,this['getEndPost']())<0x0;return _0xea9772&&_0x34a978;}['updateChild'](_0x15a748,_0x31e91d,_0x50b42e,_0x1db0dc,_0x2626be,_0x140b4f){return this['matches'](new E(_0x31e91d,_0x50b42e))||(_0x50b42e=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x15a748,_0x31e91d,_0x50b42e,_0x1db0dc,_0x2626be,_0x140b4f);}['updateFullNode'](_0x4f2b91,_0x24b4ef,_0x2d70ae){_0x24b4ef['isLeafNode']()&&(_0x24b4ef=g['EMPTY_NODE']);let _0x2909e9=_0x24b4ef['withIndex'](this['index_']);_0x2909e9=_0x2909e9['updatePriority'](g['EMPTY_NODE']);const _0x1b6fbe=this;return _0x24b4ef['forEachChild'](R,(_0x4cd87d,_0x19cd86)=>{_0x1b6fbe['matches'](new E(_0x4cd87d,_0x19cd86))||(_0x2909e9=_0x2909e9['updateImmediateChild'](_0x4cd87d,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4f2b91,_0x2909e9,_0x2d70ae);}['updatePriority'](_0x446c71,_0x5de612){return _0x446c71;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3af619){if(_0x3af619['hasStart']()){const _0x1369a7=_0x3af619['getIndexStartName']();return _0x3af619['getIndex']()['makePost'](_0x3af619['getIndexStartValue'](),_0x1369a7);}else return _0x3af619['getIndex']()['minPost']();}static['getEndPost_'](_0x5888de){if(_0x5888de['hasEnd']()){const _0x1f7464=_0x5888de['getIndexEndName']();return _0x5888de['getIndex']()['makePost'](_0x5888de['getIndexEndValue'](),_0x1f7464);}else return _0x5888de['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xfd3ecb){this['withinDirectionalStart']=_0x2fc631=>this['reverse_']?this['withinEndPost'](_0x2fc631):this['withinStartPost'](_0x2fc631),this['withinDirectionalEnd']=_0x4f7730=>this['reverse_']?this['withinStartPost'](_0x4f7730):this['withinEndPost'](_0x4f7730),this['withinStartPost']=_0x1c6e21=>{const _0x12f657=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1c6e21);return this['startIsInclusive_']?_0x12f657<=0x0:_0x12f657<0x0;},this['withinEndPost']=_0x17965d=>{const _0xc308d2=this['index_']['compare'](_0x17965d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xc308d2<=0x0:_0xc308d2<0x0;},this['rangedFilter_']=new Ot(_0xfd3ecb),this['index_']=_0xfd3ecb['getIndex'](),this['limit_']=_0xfd3ecb['getLimit'](),this['reverse_']=!_0xfd3ecb['isViewFromLeft'](),this['startIsInclusive_']=!_0xfd3ecb['startAfterSet_'],this['endIsInclusive_']=!_0xfd3ecb['endBeforeSet_'];}['updateChild'](_0xb932ab,_0x400047,_0x3cdb31,_0x458f07,_0x5d5043,_0x9b3146){return this['rangedFilter_']['matches'](new E(_0x400047,_0x3cdb31))||(_0x3cdb31=g['EMPTY_NODE']),_0xb932ab['getImmediateChild'](_0x400047)['equals'](_0x3cdb31)?_0xb932ab:_0xb932ab['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xb932ab,_0x400047,_0x3cdb31,_0x458f07,_0x5d5043,_0x9b3146):this['fullLimitUpdateChild_'](_0xb932ab,_0x400047,_0x3cdb31,_0x5d5043,_0x9b3146);}['updateFullNode'](_0x20e9a0,_0xc91d0b,_0x43cf2d){let _0x5dce55;if(_0xc91d0b['isLeafNode']()||_0xc91d0b['isEmpty']())_0x5dce55=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xc91d0b['numChildren']()&&_0xc91d0b['isIndexed'](this['index_'])){_0x5dce55=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x454142;this['reverse_']?_0x454142=_0xc91d0b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x454142=_0xc91d0b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4737bf=0x0;for(;_0x454142['hasNext']()&&_0x4737bf<this['limit_'];){const _0x3d3dbe=_0x454142['getNext']();if(this['withinDirectionalStart'](_0x3d3dbe)){if(this['withinDirectionalEnd'](_0x3d3dbe))_0x5dce55=_0x5dce55['updateImmediateChild'](_0x3d3dbe['name'],_0x3d3dbe['node']),_0x4737bf++;else break;}else continue;}}else{_0x5dce55=_0xc91d0b['withIndex'](this['index_']),_0x5dce55=_0x5dce55['updatePriority'](g['EMPTY_NODE']);let _0x85defc;this['reverse_']?_0x85defc=_0x5dce55['getReverseIterator'](this['index_']):_0x85defc=_0x5dce55['getIterator'](this['index_']);let _0x4bbbc1=0x0;for(;_0x85defc['hasNext']();){const _0x3a2882=_0x85defc['getNext']();_0x4bbbc1<this['limit_']&&this['withinDirectionalStart'](_0x3a2882)&&this['withinDirectionalEnd'](_0x3a2882)?_0x4bbbc1++:_0x5dce55=_0x5dce55['updateImmediateChild'](_0x3a2882['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x20e9a0,_0x5dce55,_0x43cf2d);}['updatePriority'](_0xb52d81,_0x445d04){return _0xb52d81;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x548084,_0x3306a4,_0x2b9ecc,_0x4c1af0,_0x10378){let _0x39f260;if(this['reverse_']){const _0x5e9f9f=this['index_']['getCompare']();_0x39f260=(_0x2fbc53,_0x53245e)=>_0x5e9f9f(_0x53245e,_0x2fbc53);}else _0x39f260=this['index_']['getCompare']();const _0x5b5465=_0x548084;f(_0x5b5465['numChildren']()===this['limit_'],'');const _0x19c9d2=new E(_0x3306a4,_0x2b9ecc),_0x5bff14=this['reverse_']?_0x5b5465['getFirstChild'](this['index_']):_0x5b5465['getLastChild'](this['index_']),_0x59fb7f=this['rangedFilter_']['matches'](_0x19c9d2);if(_0x5b5465['hasChild'](_0x3306a4)){const _0x1c9867=_0x5b5465['getImmediateChild'](_0x3306a4);let _0x3df3ae=_0x4c1af0['getChildAfterChild'](this['index_'],_0x5bff14,this['reverse_']);for(;_0x3df3ae!=null&&(_0x3df3ae['name']===_0x3306a4||_0x5b5465['hasChild'](_0x3df3ae['name']));)_0x3df3ae=_0x4c1af0['getChildAfterChild'](this['index_'],_0x3df3ae,this['reverse_']);const _0x4f6d84=_0x3df3ae==null?0x1:_0x39f260(_0x3df3ae,_0x19c9d2);if(_0x59fb7f&&!_0x2b9ecc['isEmpty']()&&_0x4f6d84>=0x0)return _0x10378!=null&&_0x10378['trackChildChange'](Pt(_0x3306a4,_0x2b9ecc,_0x1c9867)),_0x5b5465['updateImmediateChild'](_0x3306a4,_0x2b9ecc);{_0x10378!=null&&_0x10378['trackChildChange'](Nt(_0x3306a4,_0x1c9867));const _0x15cdd0=_0x5b5465['updateImmediateChild'](_0x3306a4,g['EMPTY_NODE']);return _0x3df3ae!=null&&this['rangedFilter_']['matches'](_0x3df3ae)?(_0x10378!=null&&_0x10378['trackChildChange'](tt(_0x3df3ae['name'],_0x3df3ae['node'])),_0x15cdd0['updateImmediateChild'](_0x3df3ae['name'],_0x3df3ae['node'])):_0x15cdd0;}}else return _0x2b9ecc['isEmpty']()?_0x548084:_0x59fb7f&&_0x39f260(_0x5bff14,_0x19c9d2)>=0x0?(_0x10378!=null&&(_0x10378['trackChildChange'](Nt(_0x5bff14['name'],_0x5bff14['node'])),_0x10378['trackChildChange'](tt(_0x3306a4,_0x2b9ecc))),_0x5b5465['updateImmediateChild'](_0x3306a4,_0x2b9ecc)['updateImmediateChild'](_0x5bff14['name'],g['EMPTY_NODE'])):_0x548084;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5a5173=new Qi();return _0x5a5173['limitSet_']=this['limitSet_'],_0x5a5173['limit_']=this['limit_'],_0x5a5173['startSet_']=this['startSet_'],_0x5a5173['startAfterSet_']=this['startAfterSet_'],_0x5a5173['indexStartValue_']=this['indexStartValue_'],_0x5a5173['startNameSet_']=this['startNameSet_'],_0x5a5173['indexStartName_']=this['indexStartName_'],_0x5a5173['endSet_']=this['endSet_'],_0x5a5173['endBeforeSet_']=this['endBeforeSet_'],_0x5a5173['indexEndValue_']=this['indexEndValue_'],_0x5a5173['endNameSet_']=this['endNameSet_'],_0x5a5173['indexEndName_']=this['indexEndName_'],_0x5a5173['index_']=this['index_'],_0x5a5173['viewFrom_']=this['viewFrom_'],_0x5a5173;}}function qh(_0x289388){return _0x289388['loadsAllData']()?new Yi(_0x289388['getIndex']()):_0x289388['hasLimit']()?new Gh(_0x289388):new Ot(_0x289388);}function zh(_0xd01669,_0x11d4f4){const _0x3e6e74=_0xd01669['copy']();return _0x3e6e74['limitSet_']=!0x0,_0x3e6e74['limit_']=_0x11d4f4,_0x3e6e74['viewFrom_']='l',_0x3e6e74;}function jh(_0x1aa634,_0x3ba66e,_0x28311e){const _0x467d77=_0x1aa634['copy']();return _0x467d77['startSet_']=!0x0,_0x3ba66e===void 0x0&&(_0x3ba66e=null),_0x467d77['indexStartValue_']=_0x3ba66e,_0x28311e!=null?(_0x467d77['startNameSet_']=!0x0,_0x467d77['indexStartName_']=_0x28311e):(_0x467d77['startNameSet_']=!0x1,_0x467d77['indexStartName_']=''),_0x467d77;}function Kh(_0x41eba8,_0x577693,_0x44e750){const _0x2a63a2=_0x41eba8['copy']();return _0x2a63a2['endSet_']=!0x0,_0x577693===void 0x0&&(_0x577693=null),_0x2a63a2['indexEndValue_']=_0x577693,_0x44e750!==void 0x0?(_0x2a63a2['endNameSet_']=!0x0,_0x2a63a2['indexEndName_']=_0x44e750):(_0x2a63a2['endNameSet_']=!0x1,_0x2a63a2['indexEndName_']=''),_0x2a63a2;}function Do(_0x47fac8,_0x6fcb28){const _0x53c8e9=_0x47fac8['copy']();return _0x53c8e9['index_']=_0x6fcb28,_0x53c8e9;}function tr(_0x31e283){const _0x2adb1d={};if(_0x31e283['isDefault']())return _0x2adb1d;let _0x181acb;if(_0x31e283['index_']===R?_0x181acb='$priority':_0x31e283['index_']===Po?_0x181acb='$value':_0x31e283['index_']===ye?_0x181acb='$key':(f(_0x31e283['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x181acb=_0x31e283['index_']['toString']()),_0x2adb1d['orderBy']=O(_0x181acb),_0x31e283['startSet_']){const _0x306561=_0x31e283['startAfterSet_']?'startAfter':'startAt';_0x2adb1d[_0x306561]=O(_0x31e283['indexStartValue_']),_0x31e283['startNameSet_']&&(_0x2adb1d[_0x306561]+=','+O(_0x31e283['indexStartName_']));}if(_0x31e283['endSet_']){const _0x5bb3a1=_0x31e283['endBeforeSet_']?'endBefore':'endAt';_0x2adb1d[_0x5bb3a1]=O(_0x31e283['indexEndValue_']),_0x31e283['endNameSet_']&&(_0x2adb1d[_0x5bb3a1]+=','+O(_0x31e283['indexEndName_']));}return _0x31e283['limitSet_']&&(_0x31e283['isViewFromLeft']()?_0x2adb1d['limitToFirst']=_0x31e283['limit_']:_0x2adb1d['limitToLast']=_0x31e283['limit_']),_0x2adb1d;}function nr(_0x544f4b){const _0x142e47={};if(_0x544f4b['startSet_']&&(_0x142e47['sp']=_0x544f4b['indexStartValue_'],_0x544f4b['startNameSet_']&&(_0x142e47['sn']=_0x544f4b['indexStartName_']),_0x142e47['sin']=!_0x544f4b['startAfterSet_']),_0x544f4b['endSet_']&&(_0x142e47['ep']=_0x544f4b['indexEndValue_'],_0x544f4b['endNameSet_']&&(_0x142e47['en']=_0x544f4b['indexEndName_']),_0x142e47['ein']=!_0x544f4b['endBeforeSet_']),_0x544f4b['limitSet_']){_0x142e47['l']=_0x544f4b['limit_'];let _0x1e2f5d=_0x544f4b['viewFrom_'];_0x1e2f5d===''&&(_0x544f4b['isViewFromLeft']()?_0x1e2f5d='l':_0x1e2f5d='r'),_0x142e47['vf']=_0x1e2f5d;}return _0x544f4b['index_']!==R&&(_0x142e47['i']=_0x544f4b['index_']['toString']()),_0x142e47;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1cf69a){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xb9e656,_0x187756){return _0x187756!==void 0x0?'tag$'+_0x187756:(f(_0xb9e656['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xb9e656['_path']['toString']());}constructor(_0x561aa2,_0x225038,_0x5df955,_0x3a8fb1){super(),this['repoInfo_']=_0x561aa2,this['onDataUpdate_']=_0x225038,this['authTokenProvider_']=_0x5df955,this['appCheckTokenProvider_']=_0x3a8fb1,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4236f5,_0x1b7076,_0x3c1365,_0x30a507){const _0x2f8a77=_0x4236f5['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2f8a77+'\x20'+_0x4236f5['_queryIdentifier']);const _0x69e801=fn['getListenId_'](_0x4236f5,_0x3c1365),_0x1b56ef={};this['listens_'][_0x69e801]=_0x1b56ef;const _0x4e754d=tr(_0x4236f5['_queryParams']);this['restRequest_'](_0x2f8a77+'.json',_0x4e754d,(_0x365e0a,_0x1f801c)=>{let _0x41e516=_0x1f801c;if(_0x365e0a===0x194&&(_0x41e516=null,_0x365e0a=null),_0x365e0a===null&&this['onDataUpdate_'](_0x2f8a77,_0x41e516,!0x1,_0x3c1365),Oe(this['listens_'],_0x69e801)===_0x1b56ef){let _0x24c3bd;_0x365e0a?_0x365e0a===0x191?_0x24c3bd='permission_denied':_0x24c3bd='rest_error:'+_0x365e0a:_0x24c3bd='ok',_0x30a507(_0x24c3bd,null);}});}['unlisten'](_0x430d57,_0x3c0734){const _0x889cd5=fn['getListenId_'](_0x430d57,_0x3c0734);delete this['listens_'][_0x889cd5];}['get'](_0x1523dc){const _0x3eda36=tr(_0x1523dc['_queryParams']),_0x5a1136=_0x1523dc['_path']['toString'](),_0xfd7d0f=new Ve();return this['restRequest_'](_0x5a1136+'.json',_0x3eda36,(_0x668d29,_0x139746)=>{let _0x433a08=_0x139746;_0x668d29===0x194&&(_0x433a08=null,_0x668d29=null),_0x668d29===null?(this['onDataUpdate_'](_0x5a1136,_0x433a08,!0x1,null),_0xfd7d0f['resolve'](_0x433a08)):_0xfd7d0f['reject'](new Error(_0x433a08));}),_0xfd7d0f['promise'];}['refreshAuthToken'](_0x392e33){}['restRequest_'](_0x4c8261,_0x3db77f={},_0x48b9df){return _0x3db77f['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4ecafa,_0x29d1bf])=>{_0x4ecafa&&_0x4ecafa['accessToken']&&(_0x3db77f['auth']=_0x4ecafa['accessToken']),_0x29d1bf&&_0x29d1bf['token']&&(_0x3db77f['ac']=_0x29d1bf['token']);const _0x40b537=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4c8261+'?ns='+this['repoInfo_']['namespace']+at(_0x3db77f);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x40b537);const _0x5baa0d=new XMLHttpRequest();_0x5baa0d['onreadystatechange']=()=>{if(_0x48b9df&&_0x5baa0d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x40b537+'\x20received.\x20status:',_0x5baa0d['status'],'response:',_0x5baa0d['responseText']);let _0x5e1501=null;if(_0x5baa0d['status']>=0xc8&&_0x5baa0d['status']<0x12c){try{_0x5e1501=bt(_0x5baa0d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x40b537+':\x20'+_0x5baa0d['responseText']);}_0x48b9df(null,_0x5e1501);}else _0x5baa0d['status']!==0x191&&_0x5baa0d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x40b537+'\x20Status:\x20'+_0x5baa0d['status']),_0x48b9df(_0x5baa0d['status']);_0x48b9df=null;}},_0x5baa0d['open']('GET',_0x40b537,!0x0),_0x5baa0d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x226839){return this['rootNode_']['getChild'](_0x226839);}['updateSnapshot'](_0x287308,_0x2bb8a9){this['rootNode_']=this['rootNode_']['updateChild'](_0x287308,_0x2bb8a9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0xd86c25,_0x500ed9,_0x1eceef){if(v(_0x500ed9))_0xd86c25['value']=_0x1eceef,_0xd86c25['children']['clear']();else{if(_0xd86c25['value']!==null)_0xd86c25['value']=_0xd86c25['value']['updateChild'](_0x500ed9,_0x1eceef);else{const _0x568106=y(_0x500ed9);_0xd86c25['children']['has'](_0x568106)||_0xd86c25['children']['set'](_0x568106,pn());const _0x13fca8=_0xd86c25['children']['get'](_0x568106);_0x500ed9=b(_0x500ed9),Mo(_0x13fca8,_0x500ed9,_0x1eceef);}}}function Ei(_0x5bd8f1,_0x2235ee,_0x19d9b3){_0x5bd8f1['value']!==null?_0x19d9b3(_0x2235ee,_0x5bd8f1['value']):Qh(_0x5bd8f1,(_0x243664,_0x2b7402)=>{const _0x1b3d4e=new C(_0x2235ee['toString']()+'/'+_0x243664);Ei(_0x2b7402,_0x1b3d4e,_0x19d9b3);});}function Qh(_0x2f148f,_0x11e016){_0x2f148f['children']['forEach']((_0xebde0,_0x13901f)=>{_0x11e016(_0x13901f,_0xebde0);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x3c4b40){this['collection_']=_0x3c4b40,this['last_']=null;}['get'](){const _0x455705=this['collection_']['get'](),_0x15ddb8={..._0x455705};return this['last_']&&x(this['last_'],(_0x3cf0b6,_0x1c2114)=>{_0x15ddb8[_0x3cf0b6]=_0x15ddb8[_0x3cf0b6]-_0x1c2114;}),this['last_']=_0x455705,_0x15ddb8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x179b1e,_0x53e8a7){this['server_']=_0x53e8a7,this['statsToReport_']={},this['statsListener_']=new Jh(_0x179b1e);const _0x1c2b5c=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1c2b5c));}['reportStats_'](){const _0x7f1a09=this['statsListener_']['get'](),_0x4151a3={};let _0x324172=!0x1;x(_0x7f1a09,(_0x3ae6a7,_0x67c09e)=>{_0x67c09e>0x0&&Y(this['statsToReport_'],_0x3ae6a7)&&(_0x4151a3[_0x3ae6a7]=_0x67c09e,_0x324172=!0x0);}),_0x324172&&this['server_']['reportStats'](_0x4151a3),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x11fd66){_0x11fd66[_0x11fd66['OVERWRITE']=0x0]='OVERWRITE',_0x11fd66[_0x11fd66['MERGE']=0x1]='MERGE',_0x11fd66[_0x11fd66['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x11fd66[_0x11fd66['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x5ed53a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5ed53a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x1fab1d,_0x4d707f,_0x1cf120){this['path']=_0x1fab1d,this['affectedTree']=_0x4d707f,this['revert']=_0x1cf120,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x1ae3a1){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x39aa54=this['affectedTree']['subtree'](new C(_0x1ae3a1));return new _n(w(),_0x39aa54,this['revert']);}}else return f(y(this['path'])===_0x1ae3a1,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x48bd75,_0x26a204){this['source']=_0x48bd75,this['path']=_0x26a204,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3c8761){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2d147a,_0x33c68b,_0x1ddae7){this['source']=_0x2d147a,this['path']=_0x33c68b,this['snap']=_0x1ddae7,this['type']=q['OVERWRITE'];}['operationForChild'](_0x9f77d9){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x9f77d9)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x254fc7,_0x161d44,_0x11d139){this['source']=_0x254fc7,this['path']=_0x161d44,this['children']=_0x11d139,this['type']=q['MERGE'];}['operationForChild'](_0x37a17d){if(v(this['path'])){const _0x223d7a=this['children']['subtree'](new C(_0x37a17d));return _0x223d7a['isEmpty']()?null:_0x223d7a['value']?new Fe(this['source'],w(),_0x223d7a['value']):new nt(this['source'],w(),_0x223d7a);}else return f(y(this['path'])===_0x37a17d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x59ea5f,_0xde3f1a,_0x4e3edd){this['node_']=_0x59ea5f,this['fullyInitialized_']=_0xde3f1a,this['filtered_']=_0x4e3edd;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3ee944){if(v(_0x3ee944))return this['isFullyInitialized']()&&!this['filtered_'];const _0x51c574=y(_0x3ee944);return this['isCompleteForChild'](_0x51c574);}['isCompleteForChild'](_0x5004c2){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5004c2);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x5d1eac){this['query_']=_0x5d1eac,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x5caace,_0x54251a,_0x104730,_0x3df0fc){const _0x1cefca=[],_0x425446=[];return _0x54251a['forEach'](_0x90bdb5=>{_0x90bdb5['type']==='child_changed'&&_0x5caace['index_']['indexedValueChanged'](_0x90bdb5['oldSnap'],_0x90bdb5['snapshotNode'])&&_0x425446['push']($h(_0x90bdb5['childName'],_0x90bdb5['snapshotNode']));}),mt(_0x5caace,_0x1cefca,'child_removed',_0x54251a,_0x3df0fc,_0x104730),mt(_0x5caace,_0x1cefca,'child_added',_0x54251a,_0x3df0fc,_0x104730),mt(_0x5caace,_0x1cefca,'child_moved',_0x425446,_0x3df0fc,_0x104730),mt(_0x5caace,_0x1cefca,'child_changed',_0x54251a,_0x3df0fc,_0x104730),mt(_0x5caace,_0x1cefca,'value',_0x54251a,_0x3df0fc,_0x104730),_0x1cefca;}function mt(_0x609795,_0x3c5d74,_0x1ae7c3,_0xf454a5,_0x28d8c7,_0x15b3ca){const _0x52a958=_0xf454a5['filter'](_0xc3e6c5=>_0xc3e6c5['type']===_0x1ae7c3);_0x52a958['sort']((_0x4ef711,_0x35cf9d)=>su(_0x609795,_0x4ef711,_0x35cf9d)),_0x52a958['forEach'](_0x2aab77=>{const _0x68cf42=iu(_0x609795,_0x2aab77,_0x15b3ca);_0x28d8c7['forEach'](_0x53826b=>{_0x53826b['respondsTo'](_0x2aab77['type'])&&_0x3c5d74['push'](_0x53826b['createEvent'](_0x68cf42,_0x609795['query_']));});});}function iu(_0x396f5a,_0x245bd9,_0x1f8d99){return _0x245bd9['type']==='value'||_0x245bd9['type']==='child_removed'||(_0x245bd9['prevName']=_0x1f8d99['getPredecessorChildName'](_0x245bd9['childName'],_0x245bd9['snapshotNode'],_0x396f5a['index_'])),_0x245bd9;}function su(_0x49eb99,_0x5db83f,_0x3bc65c){if(_0x5db83f['childName']==null||_0x3bc65c['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x2e6d16=new E(_0x5db83f['childName'],_0x5db83f['snapshotNode']),_0x4b89ea=new E(_0x3bc65c['childName'],_0x3bc65c['snapshotNode']);return _0x49eb99['index_']['compare'](_0x2e6d16,_0x4b89ea);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x1cc577,_0x3a42d0){return{'eventCache':_0x1cc577,'serverCache':_0x3a42d0};}function wt(_0x220f9b,_0x126db8,_0x5d27db,_0x477b7d){return Dn(new Ce(_0x126db8,_0x5d27db,_0x477b7d),_0x220f9b['serverCache']);}function Lo(_0x345718,_0xcfad3b,_0x177096,_0x3d863f){return Dn(_0x345718['eventCache'],new Ce(_0xcfad3b,_0x177096,_0x3d863f));}function gn(_0x3b2db5){return _0x3b2db5['eventCache']['isFullyInitialized']()?_0x3b2db5['eventCache']['getNode']():null;}function Ue(_0x2bfdbf){return _0x2bfdbf['serverCache']['isFullyInitialized']()?_0x2bfdbf['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x23c54a){let _0xeb6b38=new S(null);return x(_0x23c54a,(_0x1affdb,_0x4f0297)=>{_0xeb6b38=_0xeb6b38['set'](new C(_0x1affdb),_0x4f0297);}),_0xeb6b38;}constructor(_0xa5b1c1,_0x5af27b=ru()){this['value']=_0xa5b1c1,this['children']=_0x5af27b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x52fcda,_0x5f4f91){if(this['value']!=null&&_0x5f4f91(this['value']))return{'path':w(),'value':this['value']};if(v(_0x52fcda))return null;{const _0x2c8848=y(_0x52fcda),_0x2a4f0e=this['children']['get'](_0x2c8848);if(_0x2a4f0e!==null){const _0x3970c9=_0x2a4f0e['findRootMostMatchingPathAndValue'](b(_0x52fcda),_0x5f4f91);return _0x3970c9!=null?{'path':A(new C(_0x2c8848),_0x3970c9['path']),'value':_0x3970c9['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x91b141){return this['findRootMostMatchingPathAndValue'](_0x91b141,()=>!0x0);}['subtree'](_0x1a9ca2){if(v(_0x1a9ca2))return this;{const _0x4b2dce=y(_0x1a9ca2),_0x11cc8a=this['children']['get'](_0x4b2dce);return _0x11cc8a!==null?_0x11cc8a['subtree'](b(_0x1a9ca2)):new S(null);}}['set'](_0xc55c23,_0x3a364c){if(v(_0xc55c23))return new S(_0x3a364c,this['children']);{const _0x4ca875=y(_0xc55c23),_0x5db6ec=(this['children']['get'](_0x4ca875)||new S(null))['set'](b(_0xc55c23),_0x3a364c),_0x23d27b=this['children']['insert'](_0x4ca875,_0x5db6ec);return new S(this['value'],_0x23d27b);}}['remove'](_0x46e0b3){if(v(_0x46e0b3))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x159084=y(_0x46e0b3),_0x23368b=this['children']['get'](_0x159084);if(_0x23368b){const _0x577535=_0x23368b['remove'](b(_0x46e0b3));let _0x52050f;return _0x577535['isEmpty']()?_0x52050f=this['children']['remove'](_0x159084):_0x52050f=this['children']['insert'](_0x159084,_0x577535),this['value']===null&&_0x52050f['isEmpty']()?new S(null):new S(this['value'],_0x52050f);}else return this;}}['get'](_0x1ff3b0){if(v(_0x1ff3b0))return this['value'];{const _0x8e7a8d=y(_0x1ff3b0),_0x4601a1=this['children']['get'](_0x8e7a8d);return _0x4601a1?_0x4601a1['get'](b(_0x1ff3b0)):null;}}['setTree'](_0xa967f9,_0x44b141){if(v(_0xa967f9))return _0x44b141;{const _0x3abf04=y(_0xa967f9),_0x1d0939=(this['children']['get'](_0x3abf04)||new S(null))['setTree'](b(_0xa967f9),_0x44b141);let _0xf798fc;return _0x1d0939['isEmpty']()?_0xf798fc=this['children']['remove'](_0x3abf04):_0xf798fc=this['children']['insert'](_0x3abf04,_0x1d0939),new S(this['value'],_0xf798fc);}}['fold'](_0x5c9375){return this['fold_'](w(),_0x5c9375);}['fold_'](_0x38b199,_0x25fe05){const _0x48b7eb={};return this['children']['inorderTraversal']((_0x335fdf,_0x3c08cf)=>{_0x48b7eb[_0x335fdf]=_0x3c08cf['fold_'](A(_0x38b199,_0x335fdf),_0x25fe05);}),_0x25fe05(_0x38b199,this['value'],_0x48b7eb);}['findOnPath'](_0xb89641,_0x2c69f7){return this['findOnPath_'](_0xb89641,w(),_0x2c69f7);}['findOnPath_'](_0xf9371a,_0x5c392f,_0x50225b){const _0x1c6f06=this['value']?_0x50225b(_0x5c392f,this['value']):!0x1;if(_0x1c6f06)return _0x1c6f06;if(v(_0xf9371a))return null;{const _0x3b026e=y(_0xf9371a),_0x5ba435=this['children']['get'](_0x3b026e);return _0x5ba435?_0x5ba435['findOnPath_'](b(_0xf9371a),A(_0x5c392f,_0x3b026e),_0x50225b):null;}}['foreachOnPath'](_0x5aef67,_0x43936a){return this['foreachOnPath_'](_0x5aef67,w(),_0x43936a);}['foreachOnPath_'](_0x2c0ade,_0x546f1c,_0x39e249){if(v(_0x2c0ade))return this;{this['value']&&_0x39e249(_0x546f1c,this['value']);const _0x560213=y(_0x2c0ade),_0x17f565=this['children']['get'](_0x560213);return _0x17f565?_0x17f565['foreachOnPath_'](b(_0x2c0ade),A(_0x546f1c,_0x560213),_0x39e249):new S(null);}}['foreach'](_0x25e25a){this['foreach_'](w(),_0x25e25a);}['foreach_'](_0x2678c1,_0x5ebf46){this['children']['inorderTraversal']((_0x484858,_0x2eaaa7)=>{_0x2eaaa7['foreach_'](A(_0x2678c1,_0x484858),_0x5ebf46);}),this['value']&&_0x5ebf46(_0x2678c1,this['value']);}['foreachChild'](_0x3921ff){this['children']['inorderTraversal']((_0x3aecde,_0x5a4c10)=>{_0x5a4c10['value']&&_0x3921ff(_0x3aecde,_0x5a4c10['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x1a7a28){this['writeTree_']=_0x1a7a28;}static['empty'](){return new j(new S(null));}}function Ct(_0xbf6a05,_0xaf6a09,_0xe3d2a4){if(v(_0xaf6a09))return new j(new S(_0xe3d2a4));{const _0x4f7d05=_0xbf6a05['writeTree_']['findRootMostValueAndPath'](_0xaf6a09);if(_0x4f7d05!=null){const _0x47351d=_0x4f7d05['path'];let _0x56fb5a=_0x4f7d05['value'];const _0x52672d=F(_0x47351d,_0xaf6a09);return _0x56fb5a=_0x56fb5a['updateChild'](_0x52672d,_0xe3d2a4),new j(_0xbf6a05['writeTree_']['set'](_0x47351d,_0x56fb5a));}else{const _0x2f9e08=new S(_0xe3d2a4),_0x15c83f=_0xbf6a05['writeTree_']['setTree'](_0xaf6a09,_0x2f9e08);return new j(_0x15c83f);}}}function Ii(_0x4beaee,_0x2db81b,_0x1a619a){let _0x520c4b=_0x4beaee;return x(_0x1a619a,(_0x5a41a2,_0x1bf9a8)=>{_0x520c4b=Ct(_0x520c4b,A(_0x2db81b,_0x5a41a2),_0x1bf9a8);}),_0x520c4b;}function sr(_0x52dff9,_0x26fbb6){if(v(_0x26fbb6))return j['empty']();{const _0x179bd7=_0x52dff9['writeTree_']['setTree'](_0x26fbb6,new S(null));return new j(_0x179bd7);}}function wi(_0x4b3f9,_0x157b53){return $e(_0x4b3f9,_0x157b53)!=null;}function $e(_0x4277b9,_0x4a36d6){const _0x3036f4=_0x4277b9['writeTree_']['findRootMostValueAndPath'](_0x4a36d6);return _0x3036f4!=null?_0x4277b9['writeTree_']['get'](_0x3036f4['path'])['getChild'](F(_0x3036f4['path'],_0x4a36d6)):null;}function rr(_0x102931){const _0xb9223d=[],_0xd5db71=_0x102931['writeTree_']['value'];return _0xd5db71!=null?_0xd5db71['isLeafNode']()||_0xd5db71['forEachChild'](R,(_0x32b7b8,_0x224271)=>{_0xb9223d['push'](new E(_0x32b7b8,_0x224271));}):_0x102931['writeTree_']['children']['inorderTraversal']((_0xd2221a,_0x492808)=>{_0x492808['value']!=null&&_0xb9223d['push'](new E(_0xd2221a,_0x492808['value']));}),_0xb9223d;}function ve(_0x223743,_0x4eb3aa){if(v(_0x4eb3aa))return _0x223743;{const _0x1ad5c4=$e(_0x223743,_0x4eb3aa);return _0x1ad5c4!=null?new j(new S(_0x1ad5c4)):new j(_0x223743['writeTree_']['subtree'](_0x4eb3aa));}}function Ci(_0x29b7c3){return _0x29b7c3['writeTree_']['isEmpty']();}function it(_0x38800,_0x119b81){return xo(w(),_0x38800['writeTree_'],_0x119b81);}function xo(_0x26a203,_0x3aa1b5,_0x2b18c9){if(_0x3aa1b5['value']!=null)return _0x2b18c9['updateChild'](_0x26a203,_0x3aa1b5['value']);{let _0x27cc68=null;return _0x3aa1b5['children']['inorderTraversal']((_0x4fb422,_0x551cc8)=>{_0x4fb422==='.priority'?(f(_0x551cc8['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x27cc68=_0x551cc8['value']):_0x2b18c9=xo(A(_0x26a203,_0x4fb422),_0x551cc8,_0x2b18c9);}),!_0x2b18c9['getChild'](_0x26a203)['isEmpty']()&&_0x27cc68!==null&&(_0x2b18c9=_0x2b18c9['updateChild'](A(_0x26a203,'.priority'),_0x27cc68)),_0x2b18c9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1f0cef,_0x3862e3){return Bo(_0x3862e3,_0x1f0cef);}function ou(_0x212bbf,_0x179995,_0x229d29,_0x1e7f6e,_0x229c3e){f(_0x1e7f6e>_0x212bbf['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x229c3e===void 0x0&&(_0x229c3e=!0x0),_0x212bbf['allWrites']['push']({'path':_0x179995,'snap':_0x229d29,'writeId':_0x1e7f6e,'visible':_0x229c3e}),_0x229c3e&&(_0x212bbf['visibleWrites']=Ct(_0x212bbf['visibleWrites'],_0x179995,_0x229d29)),_0x212bbf['lastWriteId']=_0x1e7f6e;}function au(_0x3c3f7f,_0x3902c2,_0x591d1d,_0x4ead12){f(_0x4ead12>_0x3c3f7f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3c3f7f['allWrites']['push']({'path':_0x3902c2,'children':_0x591d1d,'writeId':_0x4ead12,'visible':!0x0}),_0x3c3f7f['visibleWrites']=Ii(_0x3c3f7f['visibleWrites'],_0x3902c2,_0x591d1d),_0x3c3f7f['lastWriteId']=_0x4ead12;}function cu(_0x1002de,_0xa2f11c){for(let _0x47d01d=0x0;_0x47d01d<_0x1002de['allWrites']['length'];_0x47d01d++){const _0x149059=_0x1002de['allWrites'][_0x47d01d];if(_0x149059['writeId']===_0xa2f11c)return _0x149059;}return null;}function lu(_0x2d102c,_0x548918){const _0x1a014d=_0x2d102c['allWrites']['findIndex'](_0x511dc3=>_0x511dc3['writeId']===_0x548918);f(_0x1a014d>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x30cdda=_0x2d102c['allWrites'][_0x1a014d];_0x2d102c['allWrites']['splice'](_0x1a014d,0x1);let _0x8b9bd3=_0x30cdda['visible'],_0xf30383=!0x1,_0x1deb9c=_0x2d102c['allWrites']['length']-0x1;for(;_0x8b9bd3&&_0x1deb9c>=0x0;){const _0x419d1c=_0x2d102c['allWrites'][_0x1deb9c];_0x419d1c['visible']&&(_0x1deb9c>=_0x1a014d&&hu(_0x419d1c,_0x30cdda['path'])?_0x8b9bd3=!0x1:$(_0x30cdda['path'],_0x419d1c['path'])&&(_0xf30383=!0x0)),_0x1deb9c--;}if(_0x8b9bd3){if(_0xf30383)return uu(_0x2d102c),!0x0;if(_0x30cdda['snap'])_0x2d102c['visibleWrites']=sr(_0x2d102c['visibleWrites'],_0x30cdda['path']);else{const _0x5bf01c=_0x30cdda['children'];x(_0x5bf01c,_0xd5f0f=>{_0x2d102c['visibleWrites']=sr(_0x2d102c['visibleWrites'],A(_0x30cdda['path'],_0xd5f0f));});}return!0x0;}else return!0x1;}function hu(_0x36a539,_0x487cd8){if(_0x36a539['snap'])return $(_0x36a539['path'],_0x487cd8);for(const _0x23eff2 in _0x36a539['children'])if(_0x36a539['children']['hasOwnProperty'](_0x23eff2)&&$(A(_0x36a539['path'],_0x23eff2),_0x487cd8))return!0x0;return!0x1;}function uu(_0x1b109a){_0x1b109a['visibleWrites']=Fo(_0x1b109a['allWrites'],du,w()),_0x1b109a['allWrites']['length']>0x0?_0x1b109a['lastWriteId']=_0x1b109a['allWrites'][_0x1b109a['allWrites']['length']-0x1]['writeId']:_0x1b109a['lastWriteId']=-0x1;}function du(_0x1292cc){return _0x1292cc['visible'];}function Fo(_0x4ccd95,_0x4d6c1e,_0x345166){let _0x5a690e=j['empty']();for(let _0x1a589c=0x0;_0x1a589c<_0x4ccd95['length'];++_0x1a589c){const _0x2952d8=_0x4ccd95[_0x1a589c];if(_0x4d6c1e(_0x2952d8)){const _0x34578e=_0x2952d8['path'];let _0x48522f;if(_0x2952d8['snap'])$(_0x345166,_0x34578e)?(_0x48522f=F(_0x345166,_0x34578e),_0x5a690e=Ct(_0x5a690e,_0x48522f,_0x2952d8['snap'])):$(_0x34578e,_0x345166)&&(_0x48522f=F(_0x34578e,_0x345166),_0x5a690e=Ct(_0x5a690e,w(),_0x2952d8['snap']['getChild'](_0x48522f)));else{if(_0x2952d8['children']){if($(_0x345166,_0x34578e))_0x48522f=F(_0x345166,_0x34578e),_0x5a690e=Ii(_0x5a690e,_0x48522f,_0x2952d8['children']);else{if($(_0x34578e,_0x345166)){if(_0x48522f=F(_0x34578e,_0x345166),v(_0x48522f))_0x5a690e=Ii(_0x5a690e,w(),_0x2952d8['children']);else{const _0x1ba9f2=Oe(_0x2952d8['children'],y(_0x48522f));if(_0x1ba9f2){const _0x5d70e4=_0x1ba9f2['getChild'](b(_0x48522f));_0x5a690e=Ct(_0x5a690e,w(),_0x5d70e4);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5a690e;}function Uo(_0x1a120d,_0x4b6978,_0x18c8f3,_0x33c65a,_0x257fe0){if(!_0x33c65a&&!_0x257fe0){const _0x53c481=$e(_0x1a120d['visibleWrites'],_0x4b6978);if(_0x53c481!=null)return _0x53c481;{const _0x3414c0=ve(_0x1a120d['visibleWrites'],_0x4b6978);if(Ci(_0x3414c0))return _0x18c8f3;if(_0x18c8f3==null&&!wi(_0x3414c0,w()))return null;{const _0x55fbc5=_0x18c8f3||g['EMPTY_NODE'];return it(_0x3414c0,_0x55fbc5);}}}else{const _0x2c4917=ve(_0x1a120d['visibleWrites'],_0x4b6978);if(!_0x257fe0&&Ci(_0x2c4917))return _0x18c8f3;if(!_0x257fe0&&_0x18c8f3==null&&!wi(_0x2c4917,w()))return null;{const _0x541c5c=function(_0x23b176){return(_0x23b176['visible']||_0x257fe0)&&(!_0x33c65a||!~_0x33c65a['indexOf'](_0x23b176['writeId']))&&($(_0x23b176['path'],_0x4b6978)||$(_0x4b6978,_0x23b176['path']));},_0x3bf07b=Fo(_0x1a120d['allWrites'],_0x541c5c,_0x4b6978),_0x34b2e7=_0x18c8f3||g['EMPTY_NODE'];return it(_0x3bf07b,_0x34b2e7);}}}function fu(_0xe54c15,_0x53b0b9,_0x2c285c){let _0x3071df=g['EMPTY_NODE'];const _0x54ea0b=$e(_0xe54c15['visibleWrites'],_0x53b0b9);if(_0x54ea0b)return _0x54ea0b['isLeafNode']()||_0x54ea0b['forEachChild'](R,(_0x30f13f,_0xc2049e)=>{_0x3071df=_0x3071df['updateImmediateChild'](_0x30f13f,_0xc2049e);}),_0x3071df;if(_0x2c285c){const _0x39a90e=ve(_0xe54c15['visibleWrites'],_0x53b0b9);return _0x2c285c['forEachChild'](R,(_0x2e5f54,_0x75aade)=>{const _0x10270d=it(ve(_0x39a90e,new C(_0x2e5f54)),_0x75aade);_0x3071df=_0x3071df['updateImmediateChild'](_0x2e5f54,_0x10270d);}),rr(_0x39a90e)['forEach'](_0x2273e1=>{_0x3071df=_0x3071df['updateImmediateChild'](_0x2273e1['name'],_0x2273e1['node']);}),_0x3071df;}else{const _0x13ce2c=ve(_0xe54c15['visibleWrites'],_0x53b0b9);return rr(_0x13ce2c)['forEach'](_0x59e216=>{_0x3071df=_0x3071df['updateImmediateChild'](_0x59e216['name'],_0x59e216['node']);}),_0x3071df;}}function pu(_0x445a97,_0x34b9ee,_0x1ccb9c,_0x44d83e,_0x2335cf){f(_0x44d83e||_0x2335cf,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1ccc6d=A(_0x34b9ee,_0x1ccb9c);if(wi(_0x445a97['visibleWrites'],_0x1ccc6d))return null;{const _0x5ecf83=ve(_0x445a97['visibleWrites'],_0x1ccc6d);return Ci(_0x5ecf83)?_0x2335cf['getChild'](_0x1ccb9c):it(_0x5ecf83,_0x2335cf['getChild'](_0x1ccb9c));}}function _u(_0x2c4b85,_0x3bb911,_0x2a5072,_0x4277d9){const _0x5553c1=A(_0x3bb911,_0x2a5072),_0x4b4fa6=$e(_0x2c4b85['visibleWrites'],_0x5553c1);if(_0x4b4fa6!=null)return _0x4b4fa6;if(_0x4277d9['isCompleteForChild'](_0x2a5072)){const _0x5642a9=ve(_0x2c4b85['visibleWrites'],_0x5553c1);return it(_0x5642a9,_0x4277d9['getNode']()['getImmediateChild'](_0x2a5072));}else return null;}function gu(_0xeaeed4,_0x8a55a){return $e(_0xeaeed4['visibleWrites'],_0x8a55a);}function mu(_0x395718,_0x28239f,_0x45bbfb,_0xf8af5c,_0x27a9a3,_0x3bc457,_0x37842b){let _0x49fb5f;const _0x3b1aa0=ve(_0x395718['visibleWrites'],_0x28239f),_0x564627=$e(_0x3b1aa0,w());if(_0x564627!=null)_0x49fb5f=_0x564627;else{if(_0x45bbfb!=null)_0x49fb5f=it(_0x3b1aa0,_0x45bbfb);else return[];}if(_0x49fb5f=_0x49fb5f['withIndex'](_0x37842b),!_0x49fb5f['isEmpty']()&&!_0x49fb5f['isLeafNode']()){const _0x2bb960=[],_0x1e92f2=_0x37842b['getCompare'](),_0x5b7300=_0x3bc457?_0x49fb5f['getReverseIteratorFrom'](_0xf8af5c,_0x37842b):_0x49fb5f['getIteratorFrom'](_0xf8af5c,_0x37842b);let _0x741daa=_0x5b7300['getNext']();for(;_0x741daa&&_0x2bb960['length']<_0x27a9a3;)_0x1e92f2(_0x741daa,_0xf8af5c)!==0x0&&_0x2bb960['push'](_0x741daa),_0x741daa=_0x5b7300['getNext']();return _0x2bb960;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5136a9,_0x4733cb,_0x4f8daf,_0xe24d83){return Uo(_0x5136a9['writeTree'],_0x5136a9['treePath'],_0x4733cb,_0x4f8daf,_0xe24d83);}function es(_0x3e85c8,_0x1a8ca0){return fu(_0x3e85c8['writeTree'],_0x3e85c8['treePath'],_0x1a8ca0);}function or(_0x49d291,_0x41bdec,_0x2008fa,_0xd2eb9){return pu(_0x49d291['writeTree'],_0x49d291['treePath'],_0x41bdec,_0x2008fa,_0xd2eb9);}function yn(_0x3c8922,_0x2db5a8){return gu(_0x3c8922['writeTree'],A(_0x3c8922['treePath'],_0x2db5a8));}function vu(_0x394691,_0x224b00,_0x1fd743,_0x444c78,_0x7ea465,_0x4c5103){return mu(_0x394691['writeTree'],_0x394691['treePath'],_0x224b00,_0x1fd743,_0x444c78,_0x7ea465,_0x4c5103);}function ts(_0x2e412f,_0xe7243e,_0x43408e){return _u(_0x2e412f['writeTree'],_0x2e412f['treePath'],_0xe7243e,_0x43408e);}function Wo(_0x273ca5,_0x476763){return Bo(A(_0x273ca5['treePath'],_0x476763),_0x273ca5['writeTree']);}function Bo(_0x3e4386,_0xa1dd61){return{'treePath':_0x3e4386,'writeTree':_0xa1dd61};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1e848a){const _0x64ed9b=_0x1e848a['type'],_0x375cc0=_0x1e848a['childName'];f(_0x64ed9b==='child_added'||_0x64ed9b==='child_changed'||_0x64ed9b==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x375cc0!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1e727a=this['changeMap']['get'](_0x375cc0);if(_0x1e727a){const _0x20dfcf=_0x1e727a['type'];if(_0x64ed9b==='child_added'&&_0x20dfcf==='child_removed')this['changeMap']['set'](_0x375cc0,Pt(_0x375cc0,_0x1e848a['snapshotNode'],_0x1e727a['snapshotNode']));else{if(_0x64ed9b==='child_removed'&&_0x20dfcf==='child_added')this['changeMap']['delete'](_0x375cc0);else{if(_0x64ed9b==='child_removed'&&_0x20dfcf==='child_changed')this['changeMap']['set'](_0x375cc0,Nt(_0x375cc0,_0x1e727a['oldSnap']));else{if(_0x64ed9b==='child_changed'&&_0x20dfcf==='child_added')this['changeMap']['set'](_0x375cc0,tt(_0x375cc0,_0x1e848a['snapshotNode']));else{if(_0x64ed9b==='child_changed'&&_0x20dfcf==='child_changed')this['changeMap']['set'](_0x375cc0,Pt(_0x375cc0,_0x1e848a['snapshotNode'],_0x1e727a['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x1e848a+'\x20occurred\x20after\x20'+_0x1e727a);}}}}}else this['changeMap']['set'](_0x375cc0,_0x1e848a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x591c44){return null;}['getChildAfterChild'](_0x4639a9,_0x14d2ef,_0x5c7471){return null;}}const Vo=new Iu();class ns{constructor(_0x8ccadb,_0x5e9ba0,_0x92df3=null){this['writes_']=_0x8ccadb,this['viewCache_']=_0x5e9ba0,this['optCompleteServerCache_']=_0x92df3;}['getCompleteChild'](_0x16b2ac){const _0x1e17b5=this['viewCache_']['eventCache'];if(_0x1e17b5['isCompleteForChild'](_0x16b2ac))return _0x1e17b5['getNode']()['getImmediateChild'](_0x16b2ac);{const _0x5d4d76=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x16b2ac,_0x5d4d76);}}['getChildAfterChild'](_0x1e271b,_0x1b9088,_0x44351a){const _0x119d2e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x7f0ae0=vu(this['writes_'],_0x119d2e,_0x1b9088,0x1,_0x44351a,_0x1e271b);return _0x7f0ae0['length']===0x0?null:_0x7f0ae0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x70fdc5){return{'filter':_0x70fdc5};}function Cu(_0x1c1018,_0x46f208){f(_0x46f208['eventCache']['getNode']()['isIndexed'](_0x1c1018['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x46f208['serverCache']['getNode']()['isIndexed'](_0x1c1018['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5c6e2b,_0x5e84a9,_0x3b2ebd,_0x1ab18e,_0x3f9831){const _0x533ef8=new Eu();let _0x948ad1,_0x264077;if(_0x3b2ebd['type']===q['OVERWRITE']){const _0x4170a4=_0x3b2ebd;_0x4170a4['source']['fromUser']?_0x948ad1=Ti(_0x5c6e2b,_0x5e84a9,_0x4170a4['path'],_0x4170a4['snap'],_0x1ab18e,_0x3f9831,_0x533ef8):(f(_0x4170a4['source']['fromServer'],'Unknown\x20source.'),_0x264077=_0x4170a4['source']['tagged']||_0x5e84a9['serverCache']['isFiltered']()&&!v(_0x4170a4['path']),_0x948ad1=vn(_0x5c6e2b,_0x5e84a9,_0x4170a4['path'],_0x4170a4['snap'],_0x1ab18e,_0x3f9831,_0x264077,_0x533ef8));}else{if(_0x3b2ebd['type']===q['MERGE']){const _0x50483f=_0x3b2ebd;_0x50483f['source']['fromUser']?_0x948ad1=bu(_0x5c6e2b,_0x5e84a9,_0x50483f['path'],_0x50483f['children'],_0x1ab18e,_0x3f9831,_0x533ef8):(f(_0x50483f['source']['fromServer'],'Unknown\x20source.'),_0x264077=_0x50483f['source']['tagged']||_0x5e84a9['serverCache']['isFiltered'](),_0x948ad1=Si(_0x5c6e2b,_0x5e84a9,_0x50483f['path'],_0x50483f['children'],_0x1ab18e,_0x3f9831,_0x264077,_0x533ef8));}else{if(_0x3b2ebd['type']===q['ACK_USER_WRITE']){const _0x3c274a=_0x3b2ebd;_0x3c274a['revert']?_0x948ad1=ku(_0x5c6e2b,_0x5e84a9,_0x3c274a['path'],_0x1ab18e,_0x3f9831,_0x533ef8):_0x948ad1=Ru(_0x5c6e2b,_0x5e84a9,_0x3c274a['path'],_0x3c274a['affectedTree'],_0x1ab18e,_0x3f9831,_0x533ef8);}else{if(_0x3b2ebd['type']===q['LISTEN_COMPLETE'])_0x948ad1=Au(_0x5c6e2b,_0x5e84a9,_0x3b2ebd['path'],_0x1ab18e,_0x533ef8);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3b2ebd['type']);}}}const _0x3c3aa7=_0x533ef8['getChanges']();return Su(_0x5e84a9,_0x948ad1,_0x3c3aa7),{'viewCache':_0x948ad1,'changes':_0x3c3aa7};}function Su(_0x39bf56,_0x47db41,_0x4ce69b){const _0x121585=_0x47db41['eventCache'];if(_0x121585['isFullyInitialized']()){const _0x1c9686=_0x121585['getNode']()['isLeafNode']()||_0x121585['getNode']()['isEmpty'](),_0x558ae8=gn(_0x39bf56);(_0x4ce69b['length']>0x0||!_0x39bf56['eventCache']['isFullyInitialized']()||_0x1c9686&&!_0x121585['getNode']()['equals'](_0x558ae8)||!_0x121585['getNode']()['getPriority']()['equals'](_0x558ae8['getPriority']()))&&_0x4ce69b['push'](Oo(gn(_0x47db41)));}}function Ho(_0x53a3bf,_0x33e50d,_0x4c8369,_0x4f4d33,_0x4eff4b,_0x2e2e4a){const _0x53afed=_0x33e50d['eventCache'];if(yn(_0x4f4d33,_0x4c8369)!=null)return _0x33e50d;{let _0xa24e8d,_0x3d61f1;if(v(_0x4c8369)){if(f(_0x33e50d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x33e50d['serverCache']['isFiltered']()){const _0x54c0f8=Ue(_0x33e50d),_0x4b0b32=_0x54c0f8 instanceof g?_0x54c0f8:g['EMPTY_NODE'],_0x551f58=es(_0x4f4d33,_0x4b0b32);_0xa24e8d=_0x53a3bf['filter']['updateFullNode'](_0x33e50d['eventCache']['getNode'](),_0x551f58,_0x2e2e4a);}else{const _0x310767=mn(_0x4f4d33,Ue(_0x33e50d));_0xa24e8d=_0x53a3bf['filter']['updateFullNode'](_0x33e50d['eventCache']['getNode'](),_0x310767,_0x2e2e4a);}}else{const _0x53521c=y(_0x4c8369);if(_0x53521c==='.priority'){f(we(_0x4c8369)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x102ef3=_0x53afed['getNode']();_0x3d61f1=_0x33e50d['serverCache']['getNode']();const _0x2f2f45=or(_0x4f4d33,_0x4c8369,_0x102ef3,_0x3d61f1);_0x2f2f45!=null?_0xa24e8d=_0x53a3bf['filter']['updatePriority'](_0x102ef3,_0x2f2f45):_0xa24e8d=_0x53afed['getNode']();}else{const _0x5d76c3=b(_0x4c8369);let _0x585d22;if(_0x53afed['isCompleteForChild'](_0x53521c)){_0x3d61f1=_0x33e50d['serverCache']['getNode']();const _0x2ba1a6=or(_0x4f4d33,_0x4c8369,_0x53afed['getNode'](),_0x3d61f1);_0x2ba1a6!=null?_0x585d22=_0x53afed['getNode']()['getImmediateChild'](_0x53521c)['updateChild'](_0x5d76c3,_0x2ba1a6):_0x585d22=_0x53afed['getNode']()['getImmediateChild'](_0x53521c);}else _0x585d22=ts(_0x4f4d33,_0x53521c,_0x33e50d['serverCache']);_0x585d22!=null?_0xa24e8d=_0x53a3bf['filter']['updateChild'](_0x53afed['getNode'](),_0x53521c,_0x585d22,_0x5d76c3,_0x4eff4b,_0x2e2e4a):_0xa24e8d=_0x53afed['getNode']();}}return wt(_0x33e50d,_0xa24e8d,_0x53afed['isFullyInitialized']()||v(_0x4c8369),_0x53a3bf['filter']['filtersNodes']());}}function vn(_0x381cf7,_0x3a945e,_0x2e27ae,_0x736e7c,_0x20ca6a,_0x5bcc1e,_0x30294d,_0x3218f9){const _0x27d590=_0x3a945e['serverCache'];let _0x3879cc;const _0x4fed45=_0x30294d?_0x381cf7['filter']:_0x381cf7['filter']['getIndexedFilter']();if(v(_0x2e27ae))_0x3879cc=_0x4fed45['updateFullNode'](_0x27d590['getNode'](),_0x736e7c,null);else{if(_0x4fed45['filtersNodes']()&&!_0x27d590['isFiltered']()){const _0x46248f=_0x27d590['getNode']()['updateChild'](_0x2e27ae,_0x736e7c);_0x3879cc=_0x4fed45['updateFullNode'](_0x27d590['getNode'](),_0x46248f,null);}else{const _0x206643=y(_0x2e27ae);if(!_0x27d590['isCompleteForPath'](_0x2e27ae)&&we(_0x2e27ae)>0x1)return _0x3a945e;const _0x5992e3=b(_0x2e27ae),_0x3606f2=_0x27d590['getNode']()['getImmediateChild'](_0x206643)['updateChild'](_0x5992e3,_0x736e7c);_0x206643==='.priority'?_0x3879cc=_0x4fed45['updatePriority'](_0x27d590['getNode'](),_0x3606f2):_0x3879cc=_0x4fed45['updateChild'](_0x27d590['getNode'](),_0x206643,_0x3606f2,_0x5992e3,Vo,null);}}const _0x57ee2e=Lo(_0x3a945e,_0x3879cc,_0x27d590['isFullyInitialized']()||v(_0x2e27ae),_0x4fed45['filtersNodes']()),_0x35d88a=new ns(_0x20ca6a,_0x57ee2e,_0x5bcc1e);return Ho(_0x381cf7,_0x57ee2e,_0x2e27ae,_0x20ca6a,_0x35d88a,_0x3218f9);}function Ti(_0x3e746f,_0x13f2f9,_0x3c3455,_0x4549d4,_0x2cdd56,_0x202a66,_0x61426f){const _0x148b06=_0x13f2f9['eventCache'];let _0x2806d1,_0x29bf38;const _0x1bb9c9=new ns(_0x2cdd56,_0x13f2f9,_0x202a66);if(v(_0x3c3455))_0x29bf38=_0x3e746f['filter']['updateFullNode'](_0x13f2f9['eventCache']['getNode'](),_0x4549d4,_0x61426f),_0x2806d1=wt(_0x13f2f9,_0x29bf38,!0x0,_0x3e746f['filter']['filtersNodes']());else{const _0xd9cc3a=y(_0x3c3455);if(_0xd9cc3a==='.priority')_0x29bf38=_0x3e746f['filter']['updatePriority'](_0x13f2f9['eventCache']['getNode'](),_0x4549d4),_0x2806d1=wt(_0x13f2f9,_0x29bf38,_0x148b06['isFullyInitialized'](),_0x148b06['isFiltered']());else{const _0x557595=b(_0x3c3455),_0x1c21c6=_0x148b06['getNode']()['getImmediateChild'](_0xd9cc3a);let _0x5584a2;if(v(_0x557595))_0x5584a2=_0x4549d4;else{const _0x47074b=_0x1bb9c9['getCompleteChild'](_0xd9cc3a);_0x47074b!=null?Gi(_0x557595)==='.priority'&&_0x47074b['getChild'](To(_0x557595))['isEmpty']()?_0x5584a2=_0x47074b:_0x5584a2=_0x47074b['updateChild'](_0x557595,_0x4549d4):_0x5584a2=g['EMPTY_NODE'];}if(_0x1c21c6['equals'](_0x5584a2))_0x2806d1=_0x13f2f9;else{const _0x3cba33=_0x3e746f['filter']['updateChild'](_0x148b06['getNode'](),_0xd9cc3a,_0x5584a2,_0x557595,_0x1bb9c9,_0x61426f);_0x2806d1=wt(_0x13f2f9,_0x3cba33,_0x148b06['isFullyInitialized'](),_0x3e746f['filter']['filtersNodes']());}}}return _0x2806d1;}function ar(_0x295604,_0x4b4cab){return _0x295604['eventCache']['isCompleteForChild'](_0x4b4cab);}function bu(_0x42619d,_0x162aa7,_0x299100,_0x5ed1a2,_0x175584,_0xe82651,_0x262da1){let _0x3d182b=_0x162aa7;return _0x5ed1a2['foreach']((_0x495ce8,_0x59c522)=>{const _0x5f0ad3=A(_0x299100,_0x495ce8);ar(_0x162aa7,y(_0x5f0ad3))&&(_0x3d182b=Ti(_0x42619d,_0x3d182b,_0x5f0ad3,_0x59c522,_0x175584,_0xe82651,_0x262da1));}),_0x5ed1a2['foreach']((_0x2eaa64,_0x2ee362)=>{const _0x2a505b=A(_0x299100,_0x2eaa64);ar(_0x162aa7,y(_0x2a505b))||(_0x3d182b=Ti(_0x42619d,_0x3d182b,_0x2a505b,_0x2ee362,_0x175584,_0xe82651,_0x262da1));}),_0x3d182b;}function cr(_0xcf263f,_0x3778b7,_0x1a88c7){return _0x1a88c7['foreach']((_0x59c076,_0x50f260)=>{_0x3778b7=_0x3778b7['updateChild'](_0x59c076,_0x50f260);}),_0x3778b7;}function Si(_0x3d8b82,_0x31d58d,_0x86490a,_0x5c4b18,_0x3253e3,_0x34eabb,_0x30c8e0,_0x46ec77){if(_0x31d58d['serverCache']['getNode']()['isEmpty']()&&!_0x31d58d['serverCache']['isFullyInitialized']())return _0x31d58d;let _0xa2751b=_0x31d58d,_0xee641c;v(_0x86490a)?_0xee641c=_0x5c4b18:_0xee641c=new S(null)['setTree'](_0x86490a,_0x5c4b18);const _0x453531=_0x31d58d['serverCache']['getNode']();return _0xee641c['children']['inorderTraversal']((_0x285bc5,_0x57cb48)=>{if(_0x453531['hasChild'](_0x285bc5)){const _0x49e63c=_0x31d58d['serverCache']['getNode']()['getImmediateChild'](_0x285bc5),_0x3d7a43=cr(_0x3d8b82,_0x49e63c,_0x57cb48);_0xa2751b=vn(_0x3d8b82,_0xa2751b,new C(_0x285bc5),_0x3d7a43,_0x3253e3,_0x34eabb,_0x30c8e0,_0x46ec77);}}),_0xee641c['children']['inorderTraversal']((_0xcfec41,_0x2398ad)=>{const _0x42c324=!_0x31d58d['serverCache']['isCompleteForChild'](_0xcfec41)&&_0x2398ad['value']===null;if(!_0x453531['hasChild'](_0xcfec41)&&!_0x42c324){const _0x1c1e85=_0x31d58d['serverCache']['getNode']()['getImmediateChild'](_0xcfec41),_0x472db9=cr(_0x3d8b82,_0x1c1e85,_0x2398ad);_0xa2751b=vn(_0x3d8b82,_0xa2751b,new C(_0xcfec41),_0x472db9,_0x3253e3,_0x34eabb,_0x30c8e0,_0x46ec77);}}),_0xa2751b;}function Ru(_0x33c555,_0x3c3c13,_0x56a91d,_0x50cfb0,_0x4160a1,_0x5b0f5d,_0x498093){if(yn(_0x4160a1,_0x56a91d)!=null)return _0x3c3c13;const _0x3f6868=_0x3c3c13['serverCache']['isFiltered'](),_0x5a481f=_0x3c3c13['serverCache'];if(_0x50cfb0['value']!=null){if(v(_0x56a91d)&&_0x5a481f['isFullyInitialized']()||_0x5a481f['isCompleteForPath'](_0x56a91d))return vn(_0x33c555,_0x3c3c13,_0x56a91d,_0x5a481f['getNode']()['getChild'](_0x56a91d),_0x4160a1,_0x5b0f5d,_0x3f6868,_0x498093);if(v(_0x56a91d)){let _0x141170=new S(null);return _0x5a481f['getNode']()['forEachChild'](ye,(_0x339331,_0x3e6187)=>{_0x141170=_0x141170['set'](new C(_0x339331),_0x3e6187);}),Si(_0x33c555,_0x3c3c13,_0x56a91d,_0x141170,_0x4160a1,_0x5b0f5d,_0x3f6868,_0x498093);}else return _0x3c3c13;}else{let _0x3da1f9=new S(null);return _0x50cfb0['foreach']((_0x468e6c,_0x169c1d)=>{const _0x1cb403=A(_0x56a91d,_0x468e6c);_0x5a481f['isCompleteForPath'](_0x1cb403)&&(_0x3da1f9=_0x3da1f9['set'](_0x468e6c,_0x5a481f['getNode']()['getChild'](_0x1cb403)));}),Si(_0x33c555,_0x3c3c13,_0x56a91d,_0x3da1f9,_0x4160a1,_0x5b0f5d,_0x3f6868,_0x498093);}}function Au(_0x14203b,_0x32eb29,_0x369d85,_0x4d9097,_0x131f96){const _0xf11b5f=_0x32eb29['serverCache'],_0x4df1d9=Lo(_0x32eb29,_0xf11b5f['getNode'](),_0xf11b5f['isFullyInitialized']()||v(_0x369d85),_0xf11b5f['isFiltered']());return Ho(_0x14203b,_0x4df1d9,_0x369d85,_0x4d9097,Vo,_0x131f96);}function ku(_0x4bec08,_0x21b493,_0x66f51c,_0x5bf608,_0x3c5687,_0x27fb6c){let _0x3d5cb9;if(yn(_0x5bf608,_0x66f51c)!=null)return _0x21b493;{const _0x21f752=new ns(_0x5bf608,_0x21b493,_0x3c5687),_0x423aee=_0x21b493['eventCache']['getNode']();let _0x3344de;if(v(_0x66f51c)||y(_0x66f51c)==='.priority'){let _0x40b8de;if(_0x21b493['serverCache']['isFullyInitialized']())_0x40b8de=mn(_0x5bf608,Ue(_0x21b493));else{const _0x15857d=_0x21b493['serverCache']['getNode']();f(_0x15857d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x40b8de=es(_0x5bf608,_0x15857d);}_0x40b8de=_0x40b8de,_0x3344de=_0x4bec08['filter']['updateFullNode'](_0x423aee,_0x40b8de,_0x27fb6c);}else{const _0x18b224=y(_0x66f51c);let _0x2cb4fe=ts(_0x5bf608,_0x18b224,_0x21b493['serverCache']);_0x2cb4fe==null&&_0x21b493['serverCache']['isCompleteForChild'](_0x18b224)&&(_0x2cb4fe=_0x423aee['getImmediateChild'](_0x18b224)),_0x2cb4fe!=null?_0x3344de=_0x4bec08['filter']['updateChild'](_0x423aee,_0x18b224,_0x2cb4fe,b(_0x66f51c),_0x21f752,_0x27fb6c):_0x21b493['eventCache']['getNode']()['hasChild'](_0x18b224)?_0x3344de=_0x4bec08['filter']['updateChild'](_0x423aee,_0x18b224,g['EMPTY_NODE'],b(_0x66f51c),_0x21f752,_0x27fb6c):_0x3344de=_0x423aee,_0x3344de['isEmpty']()&&_0x21b493['serverCache']['isFullyInitialized']()&&(_0x3d5cb9=mn(_0x5bf608,Ue(_0x21b493)),_0x3d5cb9['isLeafNode']()&&(_0x3344de=_0x4bec08['filter']['updateFullNode'](_0x3344de,_0x3d5cb9,_0x27fb6c)));}return _0x3d5cb9=_0x21b493['serverCache']['isFullyInitialized']()||yn(_0x5bf608,w())!=null,wt(_0x21b493,_0x3344de,_0x3d5cb9,_0x4bec08['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x297330,_0x144896){this['query_']=_0x297330,this['eventRegistrations_']=[];const _0x3fb505=this['query_']['_queryParams'],_0x1139ed=new Yi(_0x3fb505['getIndex']()),_0x41524a=qh(_0x3fb505);this['processor_']=wu(_0x41524a);const _0x4f3b79=_0x144896['serverCache'],_0x437a73=_0x144896['eventCache'],_0x2a734b=_0x1139ed['updateFullNode'](g['EMPTY_NODE'],_0x4f3b79['getNode'](),null),_0x1828c1=_0x41524a['updateFullNode'](g['EMPTY_NODE'],_0x437a73['getNode'](),null),_0x306573=new Ce(_0x2a734b,_0x4f3b79['isFullyInitialized'](),_0x1139ed['filtersNodes']()),_0x496735=new Ce(_0x1828c1,_0x437a73['isFullyInitialized'](),_0x41524a['filtersNodes']());this['viewCache_']=Dn(_0x496735,_0x306573),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3106b4){return _0x3106b4['viewCache_']['serverCache']['getNode']();}function Ou(_0x7e3ac0){return gn(_0x7e3ac0['viewCache_']);}function Du(_0x37c2ef,_0x1ec686){const _0x77b391=Ue(_0x37c2ef['viewCache_']);return _0x77b391&&(_0x37c2ef['query']['_queryParams']['loadsAllData']()||!v(_0x1ec686)&&!_0x77b391['getImmediateChild'](y(_0x1ec686))['isEmpty']())?_0x77b391['getChild'](_0x1ec686):null;}function lr(_0xb9005e){return _0xb9005e['eventRegistrations_']['length']===0x0;}function Mu(_0x544853,_0x389113){_0x544853['eventRegistrations_']['push'](_0x389113);}function hr(_0x32aad0,_0x4e9632,_0x10be69){const _0x41ce72=[];if(_0x10be69){f(_0x4e9632==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x26a000=_0x32aad0['query']['_path'];_0x32aad0['eventRegistrations_']['forEach'](_0x3daa64=>{const _0x255aab=_0x3daa64['createCancelEvent'](_0x10be69,_0x26a000);_0x255aab&&_0x41ce72['push'](_0x255aab);});}if(_0x4e9632){let _0x4389a1=[];for(let _0x557088=0x0;_0x557088<_0x32aad0['eventRegistrations_']['length'];++_0x557088){const _0x3d1d8c=_0x32aad0['eventRegistrations_'][_0x557088];if(!_0x3d1d8c['matches'](_0x4e9632))_0x4389a1['push'](_0x3d1d8c);else{if(_0x4e9632['hasAnyCallback']()){_0x4389a1=_0x4389a1['concat'](_0x32aad0['eventRegistrations_']['slice'](_0x557088+0x1));break;}}}_0x32aad0['eventRegistrations_']=_0x4389a1;}else _0x32aad0['eventRegistrations_']=[];return _0x41ce72;}function ur(_0x446495,_0xf30431,_0x4047c4,_0x48e6c3){_0xf30431['type']===q['MERGE']&&_0xf30431['source']['queryId']!==null&&(f(Ue(_0x446495['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x446495['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x45dd2d=_0x446495['viewCache_'],_0x30a545=Tu(_0x446495['processor_'],_0x45dd2d,_0xf30431,_0x4047c4,_0x48e6c3);return Cu(_0x446495['processor_'],_0x30a545['viewCache']),f(_0x30a545['viewCache']['serverCache']['isFullyInitialized']()||!_0x45dd2d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x446495['viewCache_']=_0x30a545['viewCache'],$o(_0x446495,_0x30a545['changes'],_0x30a545['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x23d973,_0x313b40){const _0x56c1fc=_0x23d973['viewCache_']['eventCache'],_0x469a81=[];return _0x56c1fc['getNode']()['isLeafNode']()||_0x56c1fc['getNode']()['forEachChild'](R,(_0x1b1c9c,_0x2a6620)=>{_0x469a81['push'](tt(_0x1b1c9c,_0x2a6620));}),_0x56c1fc['isFullyInitialized']()&&_0x469a81['push'](Oo(_0x56c1fc['getNode']())),$o(_0x23d973,_0x469a81,_0x56c1fc['getNode'](),_0x313b40);}function $o(_0x3b9598,_0x2460ae,_0x2482e5,_0x3f3091){const _0x3865a2=_0x3f3091?[_0x3f3091]:_0x3b9598['eventRegistrations_'];return nu(_0x3b9598['eventGenerator_'],_0x2460ae,_0x2482e5,_0x3865a2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0xcd59e9){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0xcd59e9;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x1f8c64){return _0x1f8c64['views']['size']===0x0;}function is(_0x7de979,_0x25f61a,_0x5101d2,_0x4ce56a){const _0x4d2ae1=_0x25f61a['source']['queryId'];if(_0x4d2ae1!==null){const _0x57a126=_0x7de979['views']['get'](_0x4d2ae1);return f(_0x57a126!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x57a126,_0x25f61a,_0x5101d2,_0x4ce56a);}else{let _0x41f8d2=[];for(const _0x72849e of _0x7de979['views']['values']())_0x41f8d2=_0x41f8d2['concat'](ur(_0x72849e,_0x25f61a,_0x5101d2,_0x4ce56a));return _0x41f8d2;}}function qo(_0x550bfe,_0x44997d,_0x1fb5cf,_0x559f31,_0x169b0b){const _0x2430dc=_0x44997d['_queryIdentifier'],_0xef554=_0x550bfe['views']['get'](_0x2430dc);if(!_0xef554){let _0x2e8d55=mn(_0x1fb5cf,_0x169b0b?_0x559f31:null),_0xe6f70d=!0x1;_0x2e8d55?_0xe6f70d=!0x0:_0x559f31 instanceof g?(_0x2e8d55=es(_0x1fb5cf,_0x559f31),_0xe6f70d=!0x1):(_0x2e8d55=g['EMPTY_NODE'],_0xe6f70d=!0x1);const _0x37d4b6=Dn(new Ce(_0x2e8d55,_0xe6f70d,!0x1),new Ce(_0x559f31,_0x169b0b,!0x1));return new Nu(_0x44997d,_0x37d4b6);}return _0xef554;}function Wu(_0x48bb39,_0x243567,_0x127da6,_0x3cb806,_0x53c457,_0x235e8b){const _0x53d515=qo(_0x48bb39,_0x243567,_0x3cb806,_0x53c457,_0x235e8b);return _0x48bb39['views']['has'](_0x243567['_queryIdentifier'])||_0x48bb39['views']['set'](_0x243567['_queryIdentifier'],_0x53d515),Mu(_0x53d515,_0x127da6),Lu(_0x53d515,_0x127da6);}function Bu(_0x246243,_0x2713bb,_0x234125,_0x1c081a){const _0x1ef211=_0x2713bb['_queryIdentifier'],_0x3f612d=[];let _0x1bf2f2=[];const _0x34d0e8=Te(_0x246243);if(_0x1ef211==='default'){for(const [_0x4dd8d1,_0x730808]of _0x246243['views']['entries']())_0x1bf2f2=_0x1bf2f2['concat'](hr(_0x730808,_0x234125,_0x1c081a)),lr(_0x730808)&&(_0x246243['views']['delete'](_0x4dd8d1),_0x730808['query']['_queryParams']['loadsAllData']()||_0x3f612d['push'](_0x730808['query']));}else{const _0x214853=_0x246243['views']['get'](_0x1ef211);_0x214853&&(_0x1bf2f2=_0x1bf2f2['concat'](hr(_0x214853,_0x234125,_0x1c081a)),lr(_0x214853)&&(_0x246243['views']['delete'](_0x1ef211),_0x214853['query']['_queryParams']['loadsAllData']()||_0x3f612d['push'](_0x214853['query'])));}return _0x34d0e8&&!Te(_0x246243)&&_0x3f612d['push'](new(Fu())(_0x2713bb['_repo'],_0x2713bb['_path'])),{'removed':_0x3f612d,'events':_0x1bf2f2};}function zo(_0x4828a2){const _0x1cafa0=[];for(const _0x2d699d of _0x4828a2['views']['values']())_0x2d699d['query']['_queryParams']['loadsAllData']()||_0x1cafa0['push'](_0x2d699d);return _0x1cafa0;}function Ee(_0x9a7c93,_0x368ccb){let _0x349063=null;for(const _0x23c1c4 of _0x9a7c93['views']['values']())_0x349063=_0x349063||Du(_0x23c1c4,_0x368ccb);return _0x349063;}function jo(_0x522e9f,_0xa199e6){if(_0xa199e6['_queryParams']['loadsAllData']())return Ln(_0x522e9f);{const _0x4d747f=_0xa199e6['_queryIdentifier'];return _0x522e9f['views']['get'](_0x4d747f);}}function Ko(_0x341cb7,_0x151424){return jo(_0x341cb7,_0x151424)!=null;}function Te(_0x28cba7){return Ln(_0x28cba7)!=null;}function Ln(_0x276bcf){for(const _0x5ded67 of _0x276bcf['views']['values']())if(_0x5ded67['query']['_queryParams']['loadsAllData']())return _0x5ded67;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x48b0bd){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x48b0bd;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x7dc1b6){this['listenProvider_']=_0x7dc1b6,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x17e9b4,_0x254117,_0x25b406,_0x5c0a4a,_0x24f71f){return ou(_0x17e9b4['pendingWriteTree_'],_0x254117,_0x25b406,_0x5c0a4a,_0x24f71f),_0x24f71f?ht(_0x17e9b4,new Fe(Ji(),_0x254117,_0x25b406)):[];}function Gu(_0x400849,_0x1aec2d,_0x2bc9af,_0x50ebc7){au(_0x400849['pendingWriteTree_'],_0x1aec2d,_0x2bc9af,_0x50ebc7);const _0x527419=S['fromObject'](_0x2bc9af);return ht(_0x400849,new nt(Ji(),_0x1aec2d,_0x527419));}function pe(_0x1b8b0e,_0x3f137a,_0x91b1d0=!0x1){const _0x58e90d=cu(_0x1b8b0e['pendingWriteTree_'],_0x3f137a);if(lu(_0x1b8b0e['pendingWriteTree_'],_0x3f137a)){let _0xdca231=new S(null);return _0x58e90d['snap']!=null?_0xdca231=_0xdca231['set'](w(),!0x0):x(_0x58e90d['children'],_0x15e678=>{_0xdca231=_0xdca231['set'](new C(_0x15e678),!0x0);}),ht(_0x1b8b0e,new _n(_0x58e90d['path'],_0xdca231,_0x91b1d0));}else return[];}function $t(_0xf4bd7c,_0x1f4688,_0x40869a){return ht(_0xf4bd7c,new Fe(Xi(),_0x1f4688,_0x40869a));}function qu(_0x580eae,_0x526bcc,_0x4a27e5){const _0x2e214b=S['fromObject'](_0x4a27e5);return ht(_0x580eae,new nt(Xi(),_0x526bcc,_0x2e214b));}function zu(_0x36d38d,_0x1790e8){return ht(_0x36d38d,new Dt(Xi(),_0x1790e8));}function ju(_0x119b15,_0x308491,_0x165768){const _0x582f63=rs(_0x119b15,_0x165768);if(_0x582f63){const _0x431cda=os(_0x582f63),_0x25bb28=_0x431cda['path'],_0x5a6bf1=_0x431cda['queryId'],_0x54d702=F(_0x25bb28,_0x308491),_0x429b9c=new Dt(Zi(_0x5a6bf1),_0x54d702);return as(_0x119b15,_0x25bb28,_0x429b9c);}else return[];}function wn(_0x2c9b19,_0x26614b,_0x85bbc5,_0x971462,_0x5456c3=!0x1){const _0x294a2e=_0x26614b['_path'],_0xc29422=_0x2c9b19['syncPointTree_']['get'](_0x294a2e);let _0x3c595b=[];if(_0xc29422&&(_0x26614b['_queryIdentifier']==='default'||Ko(_0xc29422,_0x26614b))){const _0x487259=Bu(_0xc29422,_0x26614b,_0x85bbc5,_0x971462);Uu(_0xc29422)&&(_0x2c9b19['syncPointTree_']=_0x2c9b19['syncPointTree_']['remove'](_0x294a2e));const _0x385aed=_0x487259['removed'];if(_0x3c595b=_0x487259['events'],!_0x5456c3){const _0x4dca05=_0x385aed['findIndex'](_0x1df7cf=>_0x1df7cf['_queryParams']['loadsAllData']())!==-0x1,_0x525384=_0x2c9b19['syncPointTree_']['findOnPath'](_0x294a2e,(_0x176084,_0x357055)=>Te(_0x357055));if(_0x4dca05&&!_0x525384){const _0x24ee6a=_0x2c9b19['syncPointTree_']['subtree'](_0x294a2e);if(!_0x24ee6a['isEmpty']()){const _0x277038=Qu(_0x24ee6a);for(let _0xe7f10c=0x0;_0xe7f10c<_0x277038['length'];++_0xe7f10c){const _0x3598b1=_0x277038[_0xe7f10c],_0x238ab7=_0x3598b1['query'],_0x4e007e=Xo(_0x2c9b19,_0x3598b1);_0x2c9b19['listenProvider_']['startListening'](Tt(_0x238ab7),Mt(_0x2c9b19,_0x238ab7),_0x4e007e['hashFn'],_0x4e007e['onComplete']);}}}!_0x525384&&_0x385aed['length']>0x0&&!_0x971462&&(_0x4dca05?_0x2c9b19['listenProvider_']['stopListening'](Tt(_0x26614b),null):_0x385aed['forEach'](_0x145618=>{const _0x520456=_0x2c9b19['queryToTagMap']['get'](Fn(_0x145618));_0x2c9b19['listenProvider_']['stopListening'](Tt(_0x145618),_0x520456);}));}Ju(_0x2c9b19,_0x385aed);}return _0x3c595b;}function Yo(_0x4387f0,_0x1d88e8,_0x151f3c,_0x8c5995){const _0x5acb19=rs(_0x4387f0,_0x8c5995);if(_0x5acb19!=null){const _0x540a61=os(_0x5acb19),_0x36ab76=_0x540a61['path'],_0x363a17=_0x540a61['queryId'],_0x422c78=F(_0x36ab76,_0x1d88e8),_0x166794=new Fe(Zi(_0x363a17),_0x422c78,_0x151f3c);return as(_0x4387f0,_0x36ab76,_0x166794);}else return[];}function Ku(_0x25a137,_0xe33c6,_0x43d03f,_0x5bc7bf){const _0x32e91d=rs(_0x25a137,_0x5bc7bf);if(_0x32e91d){const _0x5e3402=os(_0x32e91d),_0x2399dd=_0x5e3402['path'],_0x4a0367=_0x5e3402['queryId'],_0x40c5ab=F(_0x2399dd,_0xe33c6),_0x47ff5f=S['fromObject'](_0x43d03f),_0x532530=new nt(Zi(_0x4a0367),_0x40c5ab,_0x47ff5f);return as(_0x25a137,_0x2399dd,_0x532530);}else return[];}function bi(_0x193b71,_0x1bea0c,_0x504e9d,_0x4d8020=!0x1){const _0x208db6=_0x1bea0c['_path'];let _0x30f5af=null,_0x2165e3=!0x1;_0x193b71['syncPointTree_']['foreachOnPath'](_0x208db6,(_0x470bf7,_0x8d8a95)=>{const _0x40a453=F(_0x470bf7,_0x208db6);_0x30f5af=_0x30f5af||Ee(_0x8d8a95,_0x40a453),_0x2165e3=_0x2165e3||Te(_0x8d8a95);});let _0x100c7b=_0x193b71['syncPointTree_']['get'](_0x208db6);_0x100c7b?(_0x2165e3=_0x2165e3||Te(_0x100c7b),_0x30f5af=_0x30f5af||Ee(_0x100c7b,w())):(_0x100c7b=new Go(),_0x193b71['syncPointTree_']=_0x193b71['syncPointTree_']['set'](_0x208db6,_0x100c7b));let _0x260fac;_0x30f5af!=null?_0x260fac=!0x0:(_0x260fac=!0x1,_0x30f5af=g['EMPTY_NODE'],_0x193b71['syncPointTree_']['subtree'](_0x208db6)['foreachChild']((_0x30c636,_0x3f6ae8)=>{const _0x473a30=Ee(_0x3f6ae8,w());_0x473a30&&(_0x30f5af=_0x30f5af['updateImmediateChild'](_0x30c636,_0x473a30));}));const _0x1ed36c=Ko(_0x100c7b,_0x1bea0c);if(!_0x1ed36c&&!_0x1bea0c['_queryParams']['loadsAllData']()){const _0x28f8b1=Fn(_0x1bea0c);f(!_0x193b71['queryToTagMap']['has'](_0x28f8b1),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x492beb=Xu();_0x193b71['queryToTagMap']['set'](_0x28f8b1,_0x492beb),_0x193b71['tagToQueryMap']['set'](_0x492beb,_0x28f8b1);}const _0x246758=Mn(_0x193b71['pendingWriteTree_'],_0x208db6);let _0x5b89ec=Wu(_0x100c7b,_0x1bea0c,_0x504e9d,_0x246758,_0x30f5af,_0x260fac);if(!_0x1ed36c&&!_0x2165e3&&!_0x4d8020){const _0x4d096a=jo(_0x100c7b,_0x1bea0c);_0x5b89ec=_0x5b89ec['concat'](Zu(_0x193b71,_0x1bea0c,_0x4d096a));}return _0x5b89ec;}function xn(_0x36dae1,_0x211912,_0x44c43c){const _0x39487f=_0x36dae1['pendingWriteTree_'],_0x309f91=_0x36dae1['syncPointTree_']['findOnPath'](_0x211912,(_0x1932d6,_0x6aa07a)=>{const _0x3faf2b=F(_0x1932d6,_0x211912),_0x39eeab=Ee(_0x6aa07a,_0x3faf2b);if(_0x39eeab)return _0x39eeab;});return Uo(_0x39487f,_0x211912,_0x309f91,_0x44c43c,!0x0);}function Yu(_0x29992c,_0x436266){const _0x2beaed=_0x436266['_path'];let _0x2520a6=null;_0x29992c['syncPointTree_']['foreachOnPath'](_0x2beaed,(_0x2ebd73,_0x220d94)=>{const _0x5bc70b=F(_0x2ebd73,_0x2beaed);_0x2520a6=_0x2520a6||Ee(_0x220d94,_0x5bc70b);});let _0x271a58=_0x29992c['syncPointTree_']['get'](_0x2beaed);_0x271a58?_0x2520a6=_0x2520a6||Ee(_0x271a58,w()):(_0x271a58=new Go(),_0x29992c['syncPointTree_']=_0x29992c['syncPointTree_']['set'](_0x2beaed,_0x271a58));const _0x11b770=_0x2520a6!=null,_0x37079e=_0x11b770?new Ce(_0x2520a6,!0x0,!0x1):null,_0x495e9d=Mn(_0x29992c['pendingWriteTree_'],_0x436266['_path']),_0x5597a0=qo(_0x271a58,_0x436266,_0x495e9d,_0x11b770?_0x37079e['getNode']():g['EMPTY_NODE'],_0x11b770);return Ou(_0x5597a0);}function ht(_0x53a372,_0x3a0f6a){return Qo(_0x3a0f6a,_0x53a372['syncPointTree_'],null,Mn(_0x53a372['pendingWriteTree_'],w()));}function Qo(_0x5608aa,_0x393770,_0x15ad67,_0x157dc0){if(v(_0x5608aa['path']))return Jo(_0x5608aa,_0x393770,_0x15ad67,_0x157dc0);{const _0x4d1f71=_0x393770['get'](w());_0x15ad67==null&&_0x4d1f71!=null&&(_0x15ad67=Ee(_0x4d1f71,w()));let _0x2b9dba=[];const _0x414882=y(_0x5608aa['path']),_0x5dc7fc=_0x5608aa['operationForChild'](_0x414882),_0x570e40=_0x393770['children']['get'](_0x414882);if(_0x570e40&&_0x5dc7fc){const _0x3771a1=_0x15ad67?_0x15ad67['getImmediateChild'](_0x414882):null,_0x5d7db3=Wo(_0x157dc0,_0x414882);_0x2b9dba=_0x2b9dba['concat'](Qo(_0x5dc7fc,_0x570e40,_0x3771a1,_0x5d7db3));}return _0x4d1f71&&(_0x2b9dba=_0x2b9dba['concat'](is(_0x4d1f71,_0x5608aa,_0x157dc0,_0x15ad67))),_0x2b9dba;}}function Jo(_0x5efb24,_0x4d45a4,_0x3e7879,_0x2e4560){const _0x1c2193=_0x4d45a4['get'](w());_0x3e7879==null&&_0x1c2193!=null&&(_0x3e7879=Ee(_0x1c2193,w()));let _0x1fef16=[];return _0x4d45a4['children']['inorderTraversal']((_0x44e226,_0x1c4126)=>{const _0x3e92b0=_0x3e7879?_0x3e7879['getImmediateChild'](_0x44e226):null,_0x1248de=Wo(_0x2e4560,_0x44e226),_0x56db93=_0x5efb24['operationForChild'](_0x44e226);_0x56db93&&(_0x1fef16=_0x1fef16['concat'](Jo(_0x56db93,_0x1c4126,_0x3e92b0,_0x1248de)));}),_0x1c2193&&(_0x1fef16=_0x1fef16['concat'](is(_0x1c2193,_0x5efb24,_0x2e4560,_0x3e7879))),_0x1fef16;}function Xo(_0xe9b8a5,_0x2c35f8){const _0x1fecbe=_0x2c35f8['query'],_0x1fabdf=Mt(_0xe9b8a5,_0x1fecbe);return{'hashFn':()=>(Pu(_0x2c35f8)||g['EMPTY_NODE'])['hash'](),'onComplete':_0xfe7a22=>{if(_0xfe7a22==='ok')return _0x1fabdf?ju(_0xe9b8a5,_0x1fecbe['_path'],_0x1fabdf):zu(_0xe9b8a5,_0x1fecbe['_path']);{const _0x32cc8b=ql(_0xfe7a22,_0x1fecbe);return wn(_0xe9b8a5,_0x1fecbe,null,_0x32cc8b);}}};}function Mt(_0x7858cd,_0x8c92cb){const _0x59e966=Fn(_0x8c92cb);return _0x7858cd['queryToTagMap']['get'](_0x59e966);}function Fn(_0x28e49c){return _0x28e49c['_path']['toString']()+'$'+_0x28e49c['_queryIdentifier'];}function rs(_0x44634e,_0x1cb5fb){return _0x44634e['tagToQueryMap']['get'](_0x1cb5fb);}function os(_0x1368b4){const _0x1e35c6=_0x1368b4['indexOf']('$');return f(_0x1e35c6!==-0x1&&_0x1e35c6<_0x1368b4['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1368b4['substr'](_0x1e35c6+0x1),'path':new C(_0x1368b4['substr'](0x0,_0x1e35c6))};}function as(_0xbe407,_0x2f6af0,_0x4536a0){const _0x483c19=_0xbe407['syncPointTree_']['get'](_0x2f6af0);f(_0x483c19,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4668a9=Mn(_0xbe407['pendingWriteTree_'],_0x2f6af0);return is(_0x483c19,_0x4536a0,_0x4668a9,null);}function Qu(_0x4296a8){return _0x4296a8['fold']((_0x2364d6,_0x3a99db,_0x10fc4a)=>{if(_0x3a99db&&Te(_0x3a99db))return[Ln(_0x3a99db)];{let _0x4485ac=[];return _0x3a99db&&(_0x4485ac=zo(_0x3a99db)),x(_0x10fc4a,(_0x540c0a,_0x5e4300)=>{_0x4485ac=_0x4485ac['concat'](_0x5e4300);}),_0x4485ac;}});}function Tt(_0x236ee8){return _0x236ee8['_queryParams']['loadsAllData']()&&!_0x236ee8['_queryParams']['isDefault']()?new(Hu())(_0x236ee8['_repo'],_0x236ee8['_path']):_0x236ee8;}function Ju(_0x37fcce,_0xebc5){for(let _0x5ba03a=0x0;_0x5ba03a<_0xebc5['length'];++_0x5ba03a){const _0x5691f4=_0xebc5[_0x5ba03a];if(!_0x5691f4['_queryParams']['loadsAllData']()){const _0x3a940e=Fn(_0x5691f4),_0x18c627=_0x37fcce['queryToTagMap']['get'](_0x3a940e);_0x37fcce['queryToTagMap']['delete'](_0x3a940e),_0x37fcce['tagToQueryMap']['delete'](_0x18c627);}}}function Xu(){return $u++;}function Zu(_0xd31d4f,_0x307d4b,_0x185b3f){const _0x4e51c4=_0x307d4b['_path'],_0x1b70b9=Mt(_0xd31d4f,_0x307d4b),_0x23ab59=Xo(_0xd31d4f,_0x185b3f),_0x2b12e5=_0xd31d4f['listenProvider_']['startListening'](Tt(_0x307d4b),_0x1b70b9,_0x23ab59['hashFn'],_0x23ab59['onComplete']),_0x12337a=_0xd31d4f['syncPointTree_']['subtree'](_0x4e51c4);if(_0x1b70b9)f(!Te(_0x12337a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x391c01=_0x12337a['fold']((_0x4f9261,_0x4e3c1d,_0x4a7b94)=>{if(!v(_0x4f9261)&&_0x4e3c1d&&Te(_0x4e3c1d))return[Ln(_0x4e3c1d)['query']];{let _0x10fbb5=[];return _0x4e3c1d&&(_0x10fbb5=_0x10fbb5['concat'](zo(_0x4e3c1d)['map'](_0x1fe73b=>_0x1fe73b['query']))),x(_0x4a7b94,(_0x3c4284,_0x3c17e9)=>{_0x10fbb5=_0x10fbb5['concat'](_0x3c17e9);}),_0x10fbb5;}});for(let _0x393a4f=0x0;_0x393a4f<_0x391c01['length'];++_0x393a4f){const _0x2d8ce8=_0x391c01[_0x393a4f];_0xd31d4f['listenProvider_']['stopListening'](Tt(_0x2d8ce8),Mt(_0xd31d4f,_0x2d8ce8));}}return _0x2b12e5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x57d908){this['node_']=_0x57d908;}['getImmediateChild'](_0x291ee0){const _0x14ed01=this['node_']['getImmediateChild'](_0x291ee0);return new cs(_0x14ed01);}['node'](){return this['node_'];}}class ls{constructor(_0x4dcf9f,_0x46b8f1){this['syncTree_']=_0x4dcf9f,this['path_']=_0x46b8f1;}['getImmediateChild'](_0x47ae79){const _0x517437=A(this['path_'],_0x47ae79);return new ls(this['syncTree_'],_0x517437);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x2a01c8){return _0x2a01c8=_0x2a01c8||{},_0x2a01c8['timestamp']=_0x2a01c8['timestamp']||new Date()['getTime'](),_0x2a01c8;},fr=function(_0x40bb97,_0x482d82,_0x21b919){if(!_0x40bb97||typeof _0x40bb97!='object')return _0x40bb97;if(f('.sv'in _0x40bb97,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x40bb97['.sv']=='string')return td(_0x40bb97['.sv'],_0x482d82,_0x21b919);if(typeof _0x40bb97['.sv']=='object')return nd(_0x40bb97['.sv'],_0x482d82);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x40bb97,null,0x2));},td=function(_0x49eb30,_0x4d5820,_0x32da15){switch(_0x49eb30){case'timestamp':return _0x32da15['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x49eb30);}},nd=function(_0x5406f4,_0x3efcd4,_0x4d5dbf){_0x5406f4['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5406f4,null,0x2));const _0x2cf40c=_0x5406f4['increment'];typeof _0x2cf40c!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2cf40c);const _0x1fe5fe=_0x3efcd4['node']();if(f(_0x1fe5fe!==null&&typeof _0x1fe5fe<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1fe5fe['isLeafNode']())return _0x2cf40c;const _0x40fc2a=_0x1fe5fe['getValue']();return typeof _0x40fc2a!='number'?_0x2cf40c:_0x40fc2a+_0x2cf40c;},Zo=function(_0x3218ed,_0x364248,_0x5e1ae5,_0x493116){return us(_0x364248,new ls(_0x5e1ae5,_0x3218ed),_0x493116);},hs=function(_0x576e34,_0x4369f3,_0x71554c){return us(_0x576e34,new cs(_0x4369f3),_0x71554c);};function us(_0x44d83b,_0x576162,_0x27d763){const _0x1058df=_0x44d83b['getPriority']()['val'](),_0x37e538=fr(_0x1058df,_0x576162['getImmediateChild']('.priority'),_0x27d763);let _0x45d774;if(_0x44d83b['isLeafNode']()){const _0x497644=_0x44d83b,_0x57bfc6=fr(_0x497644['getValue'](),_0x576162,_0x27d763);return _0x57bfc6!==_0x497644['getValue']()||_0x37e538!==_0x497644['getPriority']()['val']()?new D(_0x57bfc6,N(_0x37e538)):_0x44d83b;}else{const _0x1bc563=_0x44d83b;return _0x45d774=_0x1bc563,_0x37e538!==_0x1bc563['getPriority']()['val']()&&(_0x45d774=_0x45d774['updatePriority'](new D(_0x37e538))),_0x1bc563['forEachChild'](R,(_0x533309,_0x5f18d7)=>{const _0x25a03d=us(_0x5f18d7,_0x576162['getImmediateChild'](_0x533309),_0x27d763);_0x25a03d!==_0x5f18d7&&(_0x45d774=_0x45d774['updateImmediateChild'](_0x533309,_0x25a03d));}),_0x45d774;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x489a11='',_0x23ff94=null,_0x561665={'children':{},'childCount':0x0}){this['name']=_0x489a11,this['parent']=_0x23ff94,this['node']=_0x561665;}}function Un(_0x4a2b86,_0x3f9e87){let _0xcfd38e=_0x3f9e87 instanceof C?_0x3f9e87:new C(_0x3f9e87),_0x493d96=_0x4a2b86,_0x4f5884=y(_0xcfd38e);for(;_0x4f5884!==null;){const _0x20b14d=Oe(_0x493d96['node']['children'],_0x4f5884)||{'children':{},'childCount':0x0};_0x493d96=new ds(_0x4f5884,_0x493d96,_0x20b14d),_0xcfd38e=b(_0xcfd38e),_0x4f5884=y(_0xcfd38e);}return _0x493d96;}function Ge(_0x1b238b){return _0x1b238b['node']['value'];}function fs(_0x309e76,_0x142a6f){_0x309e76['node']['value']=_0x142a6f,Ri(_0x309e76);}function ea(_0x5d815e){return _0x5d815e['node']['childCount']>0x0;}function id(_0x2fdc5a){return Ge(_0x2fdc5a)===void 0x0&&!ea(_0x2fdc5a);}function Wn(_0x4e6aff,_0x22c2ab){x(_0x4e6aff['node']['children'],(_0x4ac595,_0x5d17a9)=>{_0x22c2ab(new ds(_0x4ac595,_0x4e6aff,_0x5d17a9));});}function ta(_0x45eeb4,_0x5d2db0,_0x2fc295,_0x4c8875){_0x2fc295&&_0x5d2db0(_0x45eeb4),Wn(_0x45eeb4,_0x1d3cd=>{ta(_0x1d3cd,_0x5d2db0,!0x0);});}function sd(_0xac7df1,_0x40396e,_0x8e8c7c){let _0x1299df=_0xac7df1['parent'];for(;_0x1299df!==null;){if(_0x40396e(_0x1299df))return!0x0;_0x1299df=_0x1299df['parent'];}return!0x1;}function Gt(_0x2a15cb){return new C(_0x2a15cb['parent']===null?_0x2a15cb['name']:Gt(_0x2a15cb['parent'])+'/'+_0x2a15cb['name']);}function Ri(_0x456862){_0x456862['parent']!==null&&rd(_0x456862['parent'],_0x456862['name'],_0x456862);}function rd(_0x2260d5,_0x3417f8,_0xab669b){const _0x203896=id(_0xab669b),_0x3dc4a7=Y(_0x2260d5['node']['children'],_0x3417f8);_0x203896&&_0x3dc4a7?(delete _0x2260d5['node']['children'][_0x3417f8],_0x2260d5['node']['childCount']--,Ri(_0x2260d5)):!_0x203896&&!_0x3dc4a7&&(_0x2260d5['node']['children'][_0x3417f8]=_0xab669b['node'],_0x2260d5['node']['childCount']++,Ri(_0x2260d5));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x32996f){return typeof _0x32996f=='string'&&_0x32996f['length']!==0x0&&!od['test'](_0x32996f);},na=function(_0x37f3b5){return typeof _0x37f3b5=='string'&&_0x37f3b5['length']!==0x0&&!ad['test'](_0x37f3b5);},cd=function(_0x387d0d){return _0x387d0d&&(_0x387d0d=_0x387d0d['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x387d0d);},Cn=function(_0x53b2ef){return _0x53b2ef===null||typeof _0x53b2ef=='string'||typeof _0x53b2ef=='number'&&!Wi(_0x53b2ef)||_0x53b2ef&&typeof _0x53b2ef=='object'&&Y(_0x53b2ef,'.sv');},qt=function(_0x1a6437,_0x37525c,_0x48318d,_0x71d695){_0x71d695&&_0x37525c===void 0x0||zt(Nn(_0x1a6437,'value'),_0x37525c,_0x48318d);},zt=function(_0xaa2a5a,_0x4ed31d,_0x54c70d){const _0x15e50f=_0x54c70d instanceof C?new Sh(_0x54c70d,_0xaa2a5a):_0x54c70d;if(_0x4ed31d===void 0x0)throw new Error(_0xaa2a5a+'contains\x20undefined\x20'+Ne(_0x15e50f));if(typeof _0x4ed31d=='function')throw new Error(_0xaa2a5a+'contains\x20a\x20function\x20'+Ne(_0x15e50f)+'\x20with\x20contents\x20=\x20'+_0x4ed31d['toString']());if(Wi(_0x4ed31d))throw new Error(_0xaa2a5a+'contains\x20'+_0x4ed31d['toString']()+'\x20'+Ne(_0x15e50f));if(typeof _0x4ed31d=='string'&&_0x4ed31d['length']>oi/0x3&&Pn(_0x4ed31d)>oi)throw new Error(_0xaa2a5a+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x15e50f)+'\x20(\x27'+_0x4ed31d['substring'](0x0,0x32)+'...\x27)');if(_0x4ed31d&&typeof _0x4ed31d=='object'){let _0xef8f67=!0x1,_0x5473da=!0x1;if(x(_0x4ed31d,(_0x17c8fe,_0x2984ca)=>{if(_0x17c8fe==='.value')_0xef8f67=!0x0;else{if(_0x17c8fe!=='.priority'&&_0x17c8fe!=='.sv'&&(_0x5473da=!0x0,!ps(_0x17c8fe)))throw new Error(_0xaa2a5a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x17c8fe+')\x20'+Ne(_0x15e50f)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x15e50f,_0x17c8fe),zt(_0xaa2a5a,_0x2984ca,_0x15e50f),Rh(_0x15e50f);}),_0xef8f67&&_0x5473da)throw new Error(_0xaa2a5a+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x15e50f)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x14df82,_0x4358a1){let _0x1bd984,_0x64bd69;for(_0x1bd984=0x0;_0x1bd984<_0x4358a1['length'];_0x1bd984++){_0x64bd69=_0x4358a1[_0x1bd984];const _0x3e7e95=kt(_0x64bd69);for(let _0x1ce73c=0x0;_0x1ce73c<_0x3e7e95['length'];_0x1ce73c++)if(!(_0x3e7e95[_0x1ce73c]==='.priority'&&_0x1ce73c===_0x3e7e95['length']-0x1)){if(!ps(_0x3e7e95[_0x1ce73c]))throw new Error(_0x14df82+'contains\x20an\x20invalid\x20key\x20('+_0x3e7e95[_0x1ce73c]+')\x20in\x20path\x20'+_0x64bd69['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4358a1['sort'](Th);let _0x4d5c37=null;for(_0x1bd984=0x0;_0x1bd984<_0x4358a1['length'];_0x1bd984++){if(_0x64bd69=_0x4358a1[_0x1bd984],_0x4d5c37!==null&&$(_0x4d5c37,_0x64bd69))throw new Error(_0x14df82+'contains\x20a\x20path\x20'+_0x4d5c37['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x64bd69['toString']());_0x4d5c37=_0x64bd69;}},hd=function(_0x6691e3,_0x1df63f,_0x5964ee,_0xc4e08a){const _0xe5fe80=Nn(_0x6691e3,'values');if(!(_0x1df63f&&typeof _0x1df63f=='object')||Array['isArray'](_0x1df63f))throw new Error(_0xe5fe80+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x100a20=[];x(_0x1df63f,(_0x5e10db,_0x4048af)=>{const _0xae0f5d=new C(_0x5e10db);if(zt(_0xe5fe80,_0x4048af,A(_0x5964ee,_0xae0f5d)),Gi(_0xae0f5d)==='.priority'&&!Cn(_0x4048af))throw new Error(_0xe5fe80+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xae0f5d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x100a20['push'](_0xae0f5d);}),ld(_0xe5fe80,_0x100a20);},_s=function(_0x5c9148,_0x2d3f32,_0x5f5769,_0x3cc28f){if(!na(_0x5f5769))throw new Error(Nn(_0x5c9148,_0x2d3f32)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5f5769+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x2a95c8,_0x188db9,_0x5d8f27,_0xfe367){_0x5d8f27&&(_0x5d8f27=_0x5d8f27['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x2a95c8,_0x188db9,_0x5d8f27);},gs=function(_0x4bf610,_0x1cf115){if(y(_0x1cf115)==='.info')throw new Error(_0x4bf610+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1fea21,_0x1f6a86){const _0xd705b0=_0x1f6a86['path']['toString']();if(typeof _0x1f6a86['repoInfo']['host']!='string'||_0x1f6a86['repoInfo']['host']['length']===0x0||!ps(_0x1f6a86['repoInfo']['namespace'])&&_0x1f6a86['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xd705b0['length']!==0x0&&!cd(_0xd705b0))throw new Error(Nn(_0x1fea21,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x536e17,_0x1be939){let _0x493900=null;for(let _0x2bf8ef=0x0;_0x2bf8ef<_0x1be939['length'];_0x2bf8ef++){const _0x26b289=_0x1be939[_0x2bf8ef],_0x58ad7e=_0x26b289['getPath']();_0x493900!==null&&!qi(_0x58ad7e,_0x493900['path'])&&(_0x536e17['eventLists_']['push'](_0x493900),_0x493900=null),_0x493900===null&&(_0x493900={'events':[],'path':_0x58ad7e}),_0x493900['events']['push'](_0x26b289);}_0x493900&&_0x536e17['eventLists_']['push'](_0x493900);}function ia(_0x4191a2,_0x1b8ecc,_0x438fef){Bn(_0x4191a2,_0x438fef),sa(_0x4191a2,_0x182816=>qi(_0x182816,_0x1b8ecc));}function V(_0x30e3bd,_0x35f856,_0x4021ec){Bn(_0x30e3bd,_0x4021ec),sa(_0x30e3bd,_0x5ebf8b=>$(_0x5ebf8b,_0x35f856)||$(_0x35f856,_0x5ebf8b));}function sa(_0x2dba8b,_0x4d8139){_0x2dba8b['recursionDepth_']++;let _0x259ec1=!0x0;for(let _0x53555b=0x0;_0x53555b<_0x2dba8b['eventLists_']['length'];_0x53555b++){const _0x766e6c=_0x2dba8b['eventLists_'][_0x53555b];if(_0x766e6c){const _0x3720e5=_0x766e6c['path'];_0x4d8139(_0x3720e5)?(pd(_0x2dba8b['eventLists_'][_0x53555b]),_0x2dba8b['eventLists_'][_0x53555b]=null):_0x259ec1=!0x1;}}_0x259ec1&&(_0x2dba8b['eventLists_']=[]),_0x2dba8b['recursionDepth_']--;}function pd(_0x4ce125){for(let _0x4cbb0f=0x0;_0x4cbb0f<_0x4ce125['events']['length'];_0x4cbb0f++){const _0x4ba056=_0x4ce125['events'][_0x4cbb0f];if(_0x4ba056!==null){_0x4ce125['events'][_0x4cbb0f]=null;const _0x5c9eb4=_0x4ba056['getEventRunner']();Et&&L('event:\x20'+_0x4ba056['toString']()),lt(_0x5c9eb4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x268cc8,_0x26c242,_0x59be39,_0x5badb0){this['repoInfo_']=_0x268cc8,this['forceRestClient_']=_0x26c242,this['authTokenProvider_']=_0x59be39,this['appCheckProvider_']=_0x5badb0,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x31ea76,_0x5250e3,_0x1f8308){if(_0x31ea76['stats_']=Hi(_0x31ea76['repoInfo_']),_0x31ea76['forceRestClient_']||Yl())_0x31ea76['server_']=new fn(_0x31ea76['repoInfo_'],(_0x2b0a34,_0x33e9b5,_0x93939b,_0x9714da)=>{pr(_0x31ea76,_0x2b0a34,_0x33e9b5,_0x93939b,_0x9714da);},_0x31ea76['authTokenProvider_'],_0x31ea76['appCheckProvider_']),setTimeout(()=>_r(_0x31ea76,!0x0),0x0);else{if(typeof _0x1f8308<'u'&&_0x1f8308!==null){if(typeof _0x1f8308!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1f8308);}catch(_0x47e634){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x47e634);}}_0x31ea76['persistentConnection_']=new ie(_0x31ea76['repoInfo_'],_0x5250e3,(_0x1d3c06,_0x4c7320,_0x5e3c85,_0x3670c8)=>{pr(_0x31ea76,_0x1d3c06,_0x4c7320,_0x5e3c85,_0x3670c8);},_0x409000=>{_r(_0x31ea76,_0x409000);},_0xab70c4=>{yd(_0x31ea76,_0xab70c4);},_0x31ea76['authTokenProvider_'],_0x31ea76['appCheckProvider_'],_0x1f8308),_0x31ea76['server_']=_0x31ea76['persistentConnection_'];}_0x31ea76['authTokenProvider_']['addTokenChangeListener'](_0x2bec89=>{_0x31ea76['server_']['refreshAuthToken'](_0x2bec89);}),_0x31ea76['appCheckProvider_']['addTokenChangeListener'](_0x3cbaa1=>{_0x31ea76['server_']['refreshAppCheckToken'](_0x3cbaa1['token']);}),_0x31ea76['statsReporter_']=eh(_0x31ea76['repoInfo_'],()=>new eu(_0x31ea76['stats_'],_0x31ea76['server_'])),_0x31ea76['infoData_']=new Yh(),_0x31ea76['infoSyncTree_']=new dr({'startListening':(_0x5981f2,_0x3ca40d,_0x27e090,_0x2f7570)=>{let _0x39d4e2=[];const _0x58e84d=_0x31ea76['infoData_']['getNode'](_0x5981f2['_path']);return _0x58e84d['isEmpty']()||(_0x39d4e2=$t(_0x31ea76['infoSyncTree_'],_0x5981f2['_path'],_0x58e84d),setTimeout(()=>{_0x2f7570('ok');},0x0)),_0x39d4e2;},'stopListening':()=>{}}),ms(_0x31ea76,'connected',!0x1),_0x31ea76['serverSyncTree_']=new dr({'startListening':(_0xeb3759,_0x445de0,_0x10599b,_0x5acc1d)=>(_0x31ea76['server_']['listen'](_0xeb3759,_0x10599b,_0x445de0,(_0x1d2c76,_0x41563a)=>{const _0x1d6fd3=_0x5acc1d(_0x1d2c76,_0x41563a);V(_0x31ea76['eventQueue_'],_0xeb3759['_path'],_0x1d6fd3);}),[]),'stopListening':(_0x5e054f,_0x32c6f3)=>{_0x31ea76['server_']['unlisten'](_0x5e054f,_0x32c6f3);}});}function oa(_0xe3bbee){const _0x100110=_0xe3bbee['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x100110;}function jt(_0x466905){return ed({'timestamp':oa(_0x466905)});}function pr(_0x2aee0e,_0x48b8f8,_0x110567,_0x519e4b,_0x5242ad){_0x2aee0e['dataUpdateCount']++;const _0x58d0da=new C(_0x48b8f8);_0x110567=_0x2aee0e['interceptServerDataCallback_']?_0x2aee0e['interceptServerDataCallback_'](_0x48b8f8,_0x110567):_0x110567;let _0x3ccee6=[];if(_0x5242ad){if(_0x519e4b){const _0x4b3067=ln(_0x110567,_0x2bea85=>N(_0x2bea85));_0x3ccee6=Ku(_0x2aee0e['serverSyncTree_'],_0x58d0da,_0x4b3067,_0x5242ad);}else{const _0x32c3c0=N(_0x110567);_0x3ccee6=Yo(_0x2aee0e['serverSyncTree_'],_0x58d0da,_0x32c3c0,_0x5242ad);}}else{if(_0x519e4b){const _0x42ff5d=ln(_0x110567,_0x4fba50=>N(_0x4fba50));_0x3ccee6=qu(_0x2aee0e['serverSyncTree_'],_0x58d0da,_0x42ff5d);}else{const _0x371413=N(_0x110567);_0x3ccee6=$t(_0x2aee0e['serverSyncTree_'],_0x58d0da,_0x371413);}}let _0x3159aa=_0x58d0da;_0x3ccee6['length']>0x0&&(_0x3159aa=st(_0x2aee0e,_0x58d0da)),V(_0x2aee0e['eventQueue_'],_0x3159aa,_0x3ccee6);}function _r(_0x183f40,_0xf330bf){ms(_0x183f40,'connected',_0xf330bf),_0xf330bf===!0x1&&wd(_0x183f40);}function yd(_0x29239f,_0x204675){x(_0x204675,(_0xc22f50,_0x4168b5)=>{ms(_0x29239f,_0xc22f50,_0x4168b5);});}function ms(_0x398d44,_0x1bc20a,_0x293df3){const _0x1f233b=new C('/.info/'+_0x1bc20a),_0x421b08=N(_0x293df3);_0x398d44['infoData_']['updateSnapshot'](_0x1f233b,_0x421b08);const _0x38ea53=$t(_0x398d44['infoSyncTree_'],_0x1f233b,_0x421b08);V(_0x398d44['eventQueue_'],_0x1f233b,_0x38ea53);}function Vn(_0x83130c){return _0x83130c['nextWriteId_']++;}function vd(_0x1e84bd,_0x855e8d,_0x3be982){const _0x288e58=Yu(_0x1e84bd['serverSyncTree_'],_0x855e8d);return _0x288e58!=null?Promise['resolve'](_0x288e58):_0x1e84bd['server_']['get'](_0x855e8d)['then'](_0x589e34=>{const _0x97720c=N(_0x589e34)['withIndex'](_0x855e8d['_queryParams']['getIndex']());bi(_0x1e84bd['serverSyncTree_'],_0x855e8d,_0x3be982,!0x0);let _0x4d65ff;if(_0x855e8d['_queryParams']['loadsAllData']())_0x4d65ff=$t(_0x1e84bd['serverSyncTree_'],_0x855e8d['_path'],_0x97720c);else{const _0x5e4151=Mt(_0x1e84bd['serverSyncTree_'],_0x855e8d);_0x4d65ff=Yo(_0x1e84bd['serverSyncTree_'],_0x855e8d['_path'],_0x97720c,_0x5e4151);}return V(_0x1e84bd['eventQueue_'],_0x855e8d['_path'],_0x4d65ff),wn(_0x1e84bd['serverSyncTree_'],_0x855e8d,_0x3be982,null,!0x0),_0x97720c;},_0x45c832=>(ut(_0x1e84bd,'get\x20for\x20query\x20'+O(_0x855e8d)+'\x20failed:\x20'+_0x45c832),Promise['reject'](new Error(_0x45c832))));}function Ed(_0x14277f,_0x3447f8,_0x2f586c,_0x30ab55,_0x40e88a){ut(_0x14277f,'set',{'path':_0x3447f8['toString'](),'value':_0x2f586c,'priority':_0x30ab55});const _0x5fa043=jt(_0x14277f),_0x1b375d=N(_0x2f586c,_0x30ab55),_0x1bf2e4=xn(_0x14277f['serverSyncTree_'],_0x3447f8),_0x38ef6d=hs(_0x1b375d,_0x1bf2e4,_0x5fa043),_0x4f5a9b=Vn(_0x14277f),_0x1c7b8d=ss(_0x14277f['serverSyncTree_'],_0x3447f8,_0x38ef6d,_0x4f5a9b,!0x0);Bn(_0x14277f['eventQueue_'],_0x1c7b8d),_0x14277f['server_']['put'](_0x3447f8['toString'](),_0x1b375d['val'](!0x0),(_0x5253a4,_0x1a027e)=>{const _0x9c8e49=_0x5253a4==='ok';_0x9c8e49||U('set\x20at\x20'+_0x3447f8+'\x20failed:\x20'+_0x5253a4);const _0x1d9b62=pe(_0x14277f['serverSyncTree_'],_0x4f5a9b,!_0x9c8e49);V(_0x14277f['eventQueue_'],_0x3447f8,_0x1d9b62),Ai(_0x14277f,_0x40e88a,_0x5253a4,_0x1a027e);});const _0x401564=vs(_0x14277f,_0x3447f8);st(_0x14277f,_0x401564),V(_0x14277f['eventQueue_'],_0x401564,[]);}function Id(_0x4a0d09,_0x5f5456,_0x4e5d9e,_0xb0dfa8){ut(_0x4a0d09,'update',{'path':_0x5f5456['toString'](),'value':_0x4e5d9e});let _0x15e809=!0x0;const _0xce7399=jt(_0x4a0d09),_0x5b0f4d={};if(x(_0x4e5d9e,(_0x2433b8,_0x50dd78)=>{_0x15e809=!0x1,_0x5b0f4d[_0x2433b8]=Zo(A(_0x5f5456,_0x2433b8),N(_0x50dd78),_0x4a0d09['serverSyncTree_'],_0xce7399);}),_0x15e809)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x4a0d09,_0xb0dfa8,'ok',void 0x0);else{const _0xd8b533=Vn(_0x4a0d09),_0x2e49e7=Gu(_0x4a0d09['serverSyncTree_'],_0x5f5456,_0x5b0f4d,_0xd8b533);Bn(_0x4a0d09['eventQueue_'],_0x2e49e7),_0x4a0d09['server_']['merge'](_0x5f5456['toString'](),_0x4e5d9e,(_0x17c95d,_0x344183)=>{const _0x56b934=_0x17c95d==='ok';_0x56b934||U('update\x20at\x20'+_0x5f5456+'\x20failed:\x20'+_0x17c95d);const _0x17143=pe(_0x4a0d09['serverSyncTree_'],_0xd8b533,!_0x56b934),_0x4f5d9e=_0x17143['length']>0x0?st(_0x4a0d09,_0x5f5456):_0x5f5456;V(_0x4a0d09['eventQueue_'],_0x4f5d9e,_0x17143),Ai(_0x4a0d09,_0xb0dfa8,_0x17c95d,_0x344183);}),x(_0x4e5d9e,_0x456850=>{const _0x332268=vs(_0x4a0d09,A(_0x5f5456,_0x456850));st(_0x4a0d09,_0x332268);}),V(_0x4a0d09['eventQueue_'],_0x5f5456,[]);}}function wd(_0x4bd392){ut(_0x4bd392,'onDisconnectEvents');const _0x45d7fd=jt(_0x4bd392),_0x301529=pn();Ei(_0x4bd392['onDisconnect_'],w(),(_0xc0ea04,_0x5675a4)=>{const _0x2f3c62=Zo(_0xc0ea04,_0x5675a4,_0x4bd392['serverSyncTree_'],_0x45d7fd);Mo(_0x301529,_0xc0ea04,_0x2f3c62);});let _0x3e205f=[];Ei(_0x301529,w(),(_0x110c6e,_0x4cf499)=>{_0x3e205f=_0x3e205f['concat']($t(_0x4bd392['serverSyncTree_'],_0x110c6e,_0x4cf499));const _0xdf6312=vs(_0x4bd392,_0x110c6e);st(_0x4bd392,_0xdf6312);}),_0x4bd392['onDisconnect_']=pn(),V(_0x4bd392['eventQueue_'],w(),_0x3e205f);}function Cd(_0x31aa15,_0x4372a8,_0x443d47){let _0x5bb9d6;y(_0x4372a8['_path'])==='.info'?_0x5bb9d6=bi(_0x31aa15['infoSyncTree_'],_0x4372a8,_0x443d47):_0x5bb9d6=bi(_0x31aa15['serverSyncTree_'],_0x4372a8,_0x443d47),ia(_0x31aa15['eventQueue_'],_0x4372a8['_path'],_0x5bb9d6);}function Td(_0x4dcdb3,_0xb59576,_0x3d73d6){let _0x2fc164;y(_0xb59576['_path'])==='.info'?_0x2fc164=wn(_0x4dcdb3['infoSyncTree_'],_0xb59576,_0x3d73d6):_0x2fc164=wn(_0x4dcdb3['serverSyncTree_'],_0xb59576,_0x3d73d6),ia(_0x4dcdb3['eventQueue_'],_0xb59576['_path'],_0x2fc164);}function aa(_0x4c6493){_0x4c6493['persistentConnection_']&&_0x4c6493['persistentConnection_']['interrupt'](ra);}function Sd(_0x54ffb4){_0x54ffb4['persistentConnection_']&&_0x54ffb4['persistentConnection_']['resume'](ra);}function ut(_0x108d8f,..._0x20b49e){let _0x61799d='';_0x108d8f['persistentConnection_']&&(_0x61799d=_0x108d8f['persistentConnection_']['id']+':'),L(_0x61799d,..._0x20b49e);}function Ai(_0x354782,_0x59d9cb,_0x4174ce,_0x3a218c){_0x59d9cb&&lt(()=>{if(_0x4174ce==='ok')_0x59d9cb(null);else{const _0x189c99=(_0x4174ce||'error')['toUpperCase']();let _0xe28e5a=_0x189c99;_0x3a218c&&(_0xe28e5a+=':\x20'+_0x3a218c);const _0x4866ee=new Error(_0xe28e5a);_0x4866ee['code']=_0x189c99,_0x59d9cb(_0x4866ee);}});}function bd(_0x59e733,_0xf43b71,_0x3d99a8,_0x50335d,_0x428c23,_0x1481f9){ut(_0x59e733,'transaction\x20on\x20'+_0xf43b71);const _0x12f1bd={'path':_0xf43b71,'update':_0x3d99a8,'onComplete':_0x50335d,'status':null,'order':to(),'applyLocally':_0x1481f9,'retryCount':0x0,'unwatcher':_0x428c23,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x28785b=ys(_0x59e733,_0xf43b71,void 0x0);_0x12f1bd['currentInputSnapshot']=_0x28785b;const _0x417a52=_0x12f1bd['update'](_0x28785b['val']());if(_0x417a52===void 0x0)_0x12f1bd['unwatcher'](),_0x12f1bd['currentOutputSnapshotRaw']=null,_0x12f1bd['currentOutputSnapshotResolved']=null,_0x12f1bd['onComplete']&&_0x12f1bd['onComplete'](null,!0x1,_0x12f1bd['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x417a52,_0x12f1bd['path']),_0x12f1bd['status']=0x0;const _0x3c60a6=Un(_0x59e733['transactionQueueTree_'],_0xf43b71),_0x449494=Ge(_0x3c60a6)||[];_0x449494['push'](_0x12f1bd),fs(_0x3c60a6,_0x449494);let _0x5ed81a;typeof _0x417a52=='object'&&_0x417a52!==null&&Y(_0x417a52,'.priority')?(_0x5ed81a=Oe(_0x417a52,'.priority'),f(Cn(_0x5ed81a),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5ed81a=(xn(_0x59e733['serverSyncTree_'],_0xf43b71)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5f55e6=jt(_0x59e733),_0x4179e3=N(_0x417a52,_0x5ed81a),_0x29fec4=hs(_0x4179e3,_0x28785b,_0x5f55e6);_0x12f1bd['currentOutputSnapshotRaw']=_0x4179e3,_0x12f1bd['currentOutputSnapshotResolved']=_0x29fec4,_0x12f1bd['currentWriteId']=Vn(_0x59e733);const _0x4a80a3=ss(_0x59e733['serverSyncTree_'],_0xf43b71,_0x29fec4,_0x12f1bd['currentWriteId'],_0x12f1bd['applyLocally']);V(_0x59e733['eventQueue_'],_0xf43b71,_0x4a80a3),Hn(_0x59e733,_0x59e733['transactionQueueTree_']);}}function ys(_0x3e1e31,_0x3d7ca5,_0x415751){return xn(_0x3e1e31['serverSyncTree_'],_0x3d7ca5,_0x415751)||g['EMPTY_NODE'];}function Hn(_0x484585,_0x4b6208=_0x484585['transactionQueueTree_']){if(_0x4b6208||$n(_0x484585,_0x4b6208),Ge(_0x4b6208)){const _0x1b7aca=la(_0x484585,_0x4b6208);f(_0x1b7aca['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1b7aca['every'](_0x183813=>_0x183813['status']===0x0)&&Rd(_0x484585,Gt(_0x4b6208),_0x1b7aca);}else ea(_0x4b6208)&&Wn(_0x4b6208,_0x3fcfe4=>{Hn(_0x484585,_0x3fcfe4);});}function Rd(_0x3cf675,_0x5f2267,_0x99f2ac){const _0x2a8532=_0x99f2ac['map'](_0x45d744=>_0x45d744['currentWriteId']),_0x276210=ys(_0x3cf675,_0x5f2267,_0x2a8532);let _0x14eae1=_0x276210;const _0x2ea977=_0x276210['hash']();for(let _0x49a690=0x0;_0x49a690<_0x99f2ac['length'];_0x49a690++){const _0x2a9f7a=_0x99f2ac[_0x49a690];f(_0x2a9f7a['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2a9f7a['status']=0x1,_0x2a9f7a['retryCount']++;const _0x58a0b6=F(_0x5f2267,_0x2a9f7a['path']);_0x14eae1=_0x14eae1['updateChild'](_0x58a0b6,_0x2a9f7a['currentOutputSnapshotRaw']);}const _0x50ecdd=_0x14eae1['val'](!0x0),_0x5d7dcf=_0x5f2267;_0x3cf675['server_']['put'](_0x5d7dcf['toString'](),_0x50ecdd,_0x168f95=>{ut(_0x3cf675,'transaction\x20put\x20response',{'path':_0x5d7dcf['toString'](),'status':_0x168f95});let _0x138abc=[];if(_0x168f95==='ok'){const _0x231464=[];for(let _0x4cb1df=0x0;_0x4cb1df<_0x99f2ac['length'];_0x4cb1df++)_0x99f2ac[_0x4cb1df]['status']=0x2,_0x138abc=_0x138abc['concat'](pe(_0x3cf675['serverSyncTree_'],_0x99f2ac[_0x4cb1df]['currentWriteId'])),_0x99f2ac[_0x4cb1df]['onComplete']&&_0x231464['push'](()=>_0x99f2ac[_0x4cb1df]['onComplete'](null,!0x0,_0x99f2ac[_0x4cb1df]['currentOutputSnapshotResolved'])),_0x99f2ac[_0x4cb1df]['unwatcher']();$n(_0x3cf675,Un(_0x3cf675['transactionQueueTree_'],_0x5f2267)),Hn(_0x3cf675,_0x3cf675['transactionQueueTree_']),V(_0x3cf675['eventQueue_'],_0x5f2267,_0x138abc);for(let _0x36206a=0x0;_0x36206a<_0x231464['length'];_0x36206a++)lt(_0x231464[_0x36206a]);}else{if(_0x168f95==='datastale'){for(let _0x3724a5=0x0;_0x3724a5<_0x99f2ac['length'];_0x3724a5++)_0x99f2ac[_0x3724a5]['status']===0x3?_0x99f2ac[_0x3724a5]['status']=0x4:_0x99f2ac[_0x3724a5]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5d7dcf['toString']()+'\x20failed:\x20'+_0x168f95);for(let _0x260ead=0x0;_0x260ead<_0x99f2ac['length'];_0x260ead++)_0x99f2ac[_0x260ead]['status']=0x4,_0x99f2ac[_0x260ead]['abortReason']=_0x168f95;}st(_0x3cf675,_0x5f2267);}},_0x2ea977);}function st(_0x165890,_0x4e2346){const _0x3a2052=ca(_0x165890,_0x4e2346),_0x31b1bc=Gt(_0x3a2052),_0x156ad8=la(_0x165890,_0x3a2052);return Ad(_0x165890,_0x156ad8,_0x31b1bc),_0x31b1bc;}function Ad(_0x18b3d0,_0xa0a71a,_0x390b39){if(_0xa0a71a['length']===0x0)return;const _0x530bb0=[];let _0x363344=[];const _0x43c796=_0xa0a71a['filter'](_0x20c3b6=>_0x20c3b6['status']===0x0)['map'](_0x24e9a1=>_0x24e9a1['currentWriteId']);for(let _0x4a0fe0=0x0;_0x4a0fe0<_0xa0a71a['length'];_0x4a0fe0++){const _0x2e77c4=_0xa0a71a[_0x4a0fe0],_0x4ba54c=F(_0x390b39,_0x2e77c4['path']);let _0x1d5dfe=!0x1,_0x1909e9;if(f(_0x4ba54c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2e77c4['status']===0x4)_0x1d5dfe=!0x0,_0x1909e9=_0x2e77c4['abortReason'],_0x363344=_0x363344['concat'](pe(_0x18b3d0['serverSyncTree_'],_0x2e77c4['currentWriteId'],!0x0));else{if(_0x2e77c4['status']===0x0){if(_0x2e77c4['retryCount']>=_d)_0x1d5dfe=!0x0,_0x1909e9='maxretry',_0x363344=_0x363344['concat'](pe(_0x18b3d0['serverSyncTree_'],_0x2e77c4['currentWriteId'],!0x0));else{const _0x2d1700=ys(_0x18b3d0,_0x2e77c4['path'],_0x43c796);_0x2e77c4['currentInputSnapshot']=_0x2d1700;const _0x1dd450=_0xa0a71a[_0x4a0fe0]['update'](_0x2d1700['val']());if(_0x1dd450!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1dd450,_0x2e77c4['path']);let _0x57309a=N(_0x1dd450);typeof _0x1dd450=='object'&&_0x1dd450!=null&&Y(_0x1dd450,'.priority')||(_0x57309a=_0x57309a['updatePriority'](_0x2d1700['getPriority']()));const _0x146338=_0x2e77c4['currentWriteId'],_0x5ccb85=jt(_0x18b3d0),_0x31ea7f=hs(_0x57309a,_0x2d1700,_0x5ccb85);_0x2e77c4['currentOutputSnapshotRaw']=_0x57309a,_0x2e77c4['currentOutputSnapshotResolved']=_0x31ea7f,_0x2e77c4['currentWriteId']=Vn(_0x18b3d0),_0x43c796['splice'](_0x43c796['indexOf'](_0x146338),0x1),_0x363344=_0x363344['concat'](ss(_0x18b3d0['serverSyncTree_'],_0x2e77c4['path'],_0x31ea7f,_0x2e77c4['currentWriteId'],_0x2e77c4['applyLocally'])),_0x363344=_0x363344['concat'](pe(_0x18b3d0['serverSyncTree_'],_0x146338,!0x0));}else _0x1d5dfe=!0x0,_0x1909e9='nodata',_0x363344=_0x363344['concat'](pe(_0x18b3d0['serverSyncTree_'],_0x2e77c4['currentWriteId'],!0x0));}}}V(_0x18b3d0['eventQueue_'],_0x390b39,_0x363344),_0x363344=[],_0x1d5dfe&&(_0xa0a71a[_0x4a0fe0]['status']=0x2,function(_0x203075){setTimeout(_0x203075,Math['floor'](0x0));}(_0xa0a71a[_0x4a0fe0]['unwatcher']),_0xa0a71a[_0x4a0fe0]['onComplete']&&(_0x1909e9==='nodata'?_0x530bb0['push'](()=>_0xa0a71a[_0x4a0fe0]['onComplete'](null,!0x1,_0xa0a71a[_0x4a0fe0]['currentInputSnapshot'])):_0x530bb0['push'](()=>_0xa0a71a[_0x4a0fe0]['onComplete'](new Error(_0x1909e9),!0x1,null))));}$n(_0x18b3d0,_0x18b3d0['transactionQueueTree_']);for(let _0x285ff4=0x0;_0x285ff4<_0x530bb0['length'];_0x285ff4++)lt(_0x530bb0[_0x285ff4]);Hn(_0x18b3d0,_0x18b3d0['transactionQueueTree_']);}function ca(_0x297311,_0xd950ce){let _0x4873b2,_0x5a646a=_0x297311['transactionQueueTree_'];for(_0x4873b2=y(_0xd950ce);_0x4873b2!==null&&Ge(_0x5a646a)===void 0x0;)_0x5a646a=Un(_0x5a646a,_0x4873b2),_0xd950ce=b(_0xd950ce),_0x4873b2=y(_0xd950ce);return _0x5a646a;}function la(_0x5f02cc,_0x1cbcb2){const _0x4c1a93=[];return ha(_0x5f02cc,_0x1cbcb2,_0x4c1a93),_0x4c1a93['sort']((_0x591c3f,_0x317783)=>_0x591c3f['order']-_0x317783['order']),_0x4c1a93;}function ha(_0x17eb80,_0x1a5e79,_0x14dc36){const _0xf3f911=Ge(_0x1a5e79);if(_0xf3f911){for(let _0x5362a4=0x0;_0x5362a4<_0xf3f911['length'];_0x5362a4++)_0x14dc36['push'](_0xf3f911[_0x5362a4]);}Wn(_0x1a5e79,_0x474fba=>{ha(_0x17eb80,_0x474fba,_0x14dc36);});}function $n(_0x3b64a7,_0x4de147){const _0x560b02=Ge(_0x4de147);if(_0x560b02){let _0x30a2cf=0x0;for(let _0x236332=0x0;_0x236332<_0x560b02['length'];_0x236332++)_0x560b02[_0x236332]['status']!==0x2&&(_0x560b02[_0x30a2cf]=_0x560b02[_0x236332],_0x30a2cf++);_0x560b02['length']=_0x30a2cf,fs(_0x4de147,_0x560b02['length']>0x0?_0x560b02:void 0x0);}Wn(_0x4de147,_0x1311ee=>{$n(_0x3b64a7,_0x1311ee);});}function vs(_0x4cc622,_0x5b531d){const _0x5c9e71=Gt(ca(_0x4cc622,_0x5b531d)),_0x56fe19=Un(_0x4cc622['transactionQueueTree_'],_0x5b531d);return sd(_0x56fe19,_0x53ac82=>{ai(_0x4cc622,_0x53ac82);}),ai(_0x4cc622,_0x56fe19),ta(_0x56fe19,_0x306fb1=>{ai(_0x4cc622,_0x306fb1);}),_0x5c9e71;}function ai(_0x2188ca,_0x303245){const _0x1d594b=Ge(_0x303245);if(_0x1d594b){const _0x21daa0=[];let _0x28fbaf=[],_0x58f9b4=-0x1;for(let _0x3259f3=0x0;_0x3259f3<_0x1d594b['length'];_0x3259f3++)_0x1d594b[_0x3259f3]['status']===0x3||(_0x1d594b[_0x3259f3]['status']===0x1?(f(_0x58f9b4===_0x3259f3-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x58f9b4=_0x3259f3,_0x1d594b[_0x3259f3]['status']=0x3,_0x1d594b[_0x3259f3]['abortReason']='set'):(f(_0x1d594b[_0x3259f3]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1d594b[_0x3259f3]['unwatcher'](),_0x28fbaf=_0x28fbaf['concat'](pe(_0x2188ca['serverSyncTree_'],_0x1d594b[_0x3259f3]['currentWriteId'],!0x0)),_0x1d594b[_0x3259f3]['onComplete']&&_0x21daa0['push'](_0x1d594b[_0x3259f3]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x58f9b4===-0x1?fs(_0x303245,void 0x0):_0x1d594b['length']=_0x58f9b4+0x1,V(_0x2188ca['eventQueue_'],Gt(_0x303245),_0x28fbaf);for(let _0x20e47b=0x0;_0x20e47b<_0x21daa0['length'];_0x20e47b++)lt(_0x21daa0[_0x20e47b]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x34d036){let _0x31cf7f='';const _0x2ee7a1=_0x34d036['split']('/');for(let _0x168959=0x0;_0x168959<_0x2ee7a1['length'];_0x168959++)if(_0x2ee7a1[_0x168959]['length']>0x0){let _0x597d53=_0x2ee7a1[_0x168959];try{_0x597d53=decodeURIComponent(_0x597d53['replace'](/\+/g,'\x20'));}catch{}_0x31cf7f+='/'+_0x597d53;}return _0x31cf7f;}function Nd(_0x39a255){const _0x17d218={};_0x39a255['charAt'](0x0)==='?'&&(_0x39a255=_0x39a255['substring'](0x1));for(const _0x433db6 of _0x39a255['split']('&')){if(_0x433db6['length']===0x0)continue;const _0x36fdaa=_0x433db6['split']('=');_0x36fdaa['length']===0x2?_0x17d218[decodeURIComponent(_0x36fdaa[0x0])]=decodeURIComponent(_0x36fdaa[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x433db6+'\x27\x20in\x20query\x20\x27'+_0x39a255+'\x27');}return _0x17d218;}const gr=function(_0x2892c8,_0x9f625){const _0x1ef76f=Pd(_0x2892c8),_0x5845f0=_0x1ef76f['namespace'];_0x1ef76f['domain']==='firebase.com'&&oe(_0x1ef76f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5845f0||_0x5845f0==='undefined')&&_0x1ef76f['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1ef76f['secure']||Bl();const _0x2e0f06=_0x1ef76f['scheme']==='ws'||_0x1ef76f['scheme']==='wss';return{'repoInfo':new _o(_0x1ef76f['host'],_0x1ef76f['secure'],_0x5845f0,_0x2e0f06,_0x9f625,'',_0x5845f0!==_0x1ef76f['subdomain']),'path':new C(_0x1ef76f['pathString'])};},Pd=function(_0x8d454){let _0x212818='',_0x155528='',_0x2ac43f='',_0x5b2acc='',_0x19b89c='',_0xe4d269=!0x0,_0x550da2='https',_0xa7d346=0x1bb;if(typeof _0x8d454=='string'){let _0x48eeba=_0x8d454['indexOf']('//');_0x48eeba>=0x0&&(_0x550da2=_0x8d454['substring'](0x0,_0x48eeba-0x1),_0x8d454=_0x8d454['substring'](_0x48eeba+0x2));let _0x1b0aa2=_0x8d454['indexOf']('/');_0x1b0aa2===-0x1&&(_0x1b0aa2=_0x8d454['length']);let _0x196b4e=_0x8d454['indexOf']('?');_0x196b4e===-0x1&&(_0x196b4e=_0x8d454['length']),_0x212818=_0x8d454['substring'](0x0,Math['min'](_0x1b0aa2,_0x196b4e)),_0x1b0aa2<_0x196b4e&&(_0x5b2acc=kd(_0x8d454['substring'](_0x1b0aa2,_0x196b4e)));const _0x12755f=Nd(_0x8d454['substring'](Math['min'](_0x8d454['length'],_0x196b4e)));_0x48eeba=_0x212818['indexOf'](':'),_0x48eeba>=0x0?(_0xe4d269=_0x550da2==='https'||_0x550da2==='wss',_0xa7d346=parseInt(_0x212818['substring'](_0x48eeba+0x1),0xa)):_0x48eeba=_0x212818['length'];const _0x361876=_0x212818['slice'](0x0,_0x48eeba);if(_0x361876['toLowerCase']()==='localhost')_0x155528='localhost';else{if(_0x361876['split']('.')['length']<=0x2)_0x155528=_0x361876;else{const _0x5902d8=_0x212818['indexOf']('.');_0x2ac43f=_0x212818['substring'](0x0,_0x5902d8)['toLowerCase'](),_0x155528=_0x212818['substring'](_0x5902d8+0x1),_0x19b89c=_0x2ac43f;}}'ns'in _0x12755f&&(_0x19b89c=_0x12755f['ns']);}return{'host':_0x212818,'port':_0xa7d346,'domain':_0x155528,'subdomain':_0x2ac43f,'secure':_0xe4d269,'scheme':_0x550da2,'pathString':_0x5b2acc,'namespace':_0x19b89c};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x33b1ee=0x0;const _0x3b780b=[];return function(_0x578fde){const _0x541295=_0x578fde===_0x33b1ee;_0x33b1ee=_0x578fde;let _0x4dfde9;const _0x18caf5=new Array(0x8);for(_0x4dfde9=0x7;_0x4dfde9>=0x0;_0x4dfde9--)_0x18caf5[_0x4dfde9]=mr['charAt'](_0x578fde%0x40),_0x578fde=Math['floor'](_0x578fde/0x40);f(_0x578fde===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1bf1cf=_0x18caf5['join']('');if(_0x541295){for(_0x4dfde9=0xb;_0x4dfde9>=0x0&&_0x3b780b[_0x4dfde9]===0x3f;_0x4dfde9--)_0x3b780b[_0x4dfde9]=0x0;_0x3b780b[_0x4dfde9]++;}else{for(_0x4dfde9=0x0;_0x4dfde9<0xc;_0x4dfde9++)_0x3b780b[_0x4dfde9]=Math['floor'](Math['random']()*0x40);}for(_0x4dfde9=0x0;_0x4dfde9<0xc;_0x4dfde9++)_0x1bf1cf+=mr['charAt'](_0x3b780b[_0x4dfde9]);return f(_0x1bf1cf['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1bf1cf;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x114c2e,_0x5ed2de,_0x31a454,_0x25b536){this['eventType']=_0x114c2e,this['eventRegistration']=_0x5ed2de,this['snapshot']=_0x31a454,this['prevName']=_0x25b536;}['getPath'](){const _0x232b0f=this['snapshot']['ref'];return this['eventType']==='value'?_0x232b0f['_path']:_0x232b0f['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x4f8dd2,_0x2b8a3b,_0x977015){this['eventRegistration']=_0x4f8dd2,this['error']=_0x2b8a3b,this['path']=_0x977015;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x3c3cdc,_0x32fcd1){this['snapshotCallback']=_0x3c3cdc,this['cancelCallback']=_0x32fcd1;}['onValue'](_0x602c3c,_0x392782){this['snapshotCallback']['call'](null,_0x602c3c,_0x392782);}['onCancel'](_0x52cb4c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x52cb4c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x34c7ec){return this['snapshotCallback']===_0x34c7ec['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x34c7ec['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x34c7ec['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x440403,_0x3b641d,_0x4f1954,_0xd2487f){this['_repo']=_0x440403,this['_path']=_0x3b641d,this['_queryParams']=_0x4f1954,this['_orderByCalled']=_0xd2487f;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5e6aa2=nr(this['_queryParams']),_0x598b03=Bi(_0x5e6aa2);return _0x598b03==='{}'?'default':_0x598b03;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x535ec5){if(_0x535ec5=k(_0x535ec5),!(_0x535ec5 instanceof be))return!0x1;const _0x574bc2=this['_repo']===_0x535ec5['_repo'],_0x485af5=qi(this['_path'],_0x535ec5['_path']),_0x569504=this['_queryIdentifier']===_0x535ec5['_queryIdentifier'];return _0x574bc2&&_0x485af5&&_0x569504;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x258a25,_0x1d1966){if(_0x258a25['_orderByCalled']===!0x0)throw new Error(_0x1d1966+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x464276){let _0x56c281=null,_0x22dcbb=null;if(_0x464276['hasStart']()&&(_0x56c281=_0x464276['getIndexStartValue']()),_0x464276['hasEnd']()&&(_0x22dcbb=_0x464276['getIndexEndValue']()),_0x464276['getIndex']()===ye){const _0x33c732='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x17df5f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x464276['hasStart']()){if(_0x464276['getIndexStartName']()!==xe)throw new Error(_0x33c732);if(typeof _0x56c281!='string')throw new Error(_0x17df5f);}if(_0x464276['hasEnd']()){if(_0x464276['getIndexEndName']()!==Ie)throw new Error(_0x33c732);if(typeof _0x22dcbb!='string')throw new Error(_0x17df5f);}}else{if(_0x464276['getIndex']()===R){if(_0x56c281!=null&&!Cn(_0x56c281)||_0x22dcbb!=null&&!Cn(_0x22dcbb))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x464276['getIndex']()instanceof Ki||_0x464276['getIndex']()===Po,'unknown\x20index\x20type.'),_0x56c281!=null&&typeof _0x56c281=='object'||_0x22dcbb!=null&&typeof _0x22dcbb=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x3747d5){if(_0x3747d5['hasStart']()&&_0x3747d5['hasEnd']()&&_0x3747d5['hasLimit']()&&!_0x3747d5['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x5aab3b,_0x25f635){super(_0x5aab3b,_0x25f635,new Qi(),!0x1);}get['parent'](){const _0x5b7e93=To(this['_path']);return _0x5b7e93===null?null:new Z(this['_repo'],_0x5b7e93);}get['root'](){let _0x33b502=this;for(;_0x33b502['parent']!==null;)_0x33b502=_0x33b502['parent'];return _0x33b502;}}class rt{constructor(_0x1ca8e9,_0x8bfd71,_0x11e9a8){this['_node']=_0x1ca8e9,this['ref']=_0x8bfd71,this['_index']=_0x11e9a8;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x20c105){const _0xeab9c7=new C(_0x20c105),_0x2f843f=Lt(this['ref'],_0x20c105);return new rt(this['_node']['getChild'](_0xeab9c7),_0x2f843f,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x13c52f){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4e1a0e,_0x4c5e13)=>_0x13c52f(new rt(_0x4c5e13,Lt(this['ref'],_0x4e1a0e),R)));}['hasChild'](_0x2b1e06){const _0x227c62=new C(_0x2b1e06);return!this['_node']['getChild'](_0x227c62)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x486eb4,_0x23b184){return _0x486eb4=k(_0x486eb4),_0x486eb4['_checkNotDeleted']('ref'),_0x23b184!==void 0x0?Lt(_0x486eb4['_root'],_0x23b184):_0x486eb4['_root'];}function Lt(_0x25a305,_0x9dd99e){return _0x25a305=k(_0x25a305),y(_0x25a305['_path'])===null?ud('child','path',_0x9dd99e):_s('child','path',_0x9dd99e),new Z(_0x25a305['_repo'],A(_0x25a305['_path'],_0x9dd99e));}function d_(_0x174492,_0x25bcc0){_0x174492=k(_0x174492),gs('push',_0x174492['_path']),qt('push',_0x25bcc0,_0x174492['_path'],!0x0);const _0x284139=oa(_0x174492['_repo']),_0x5eb1e4=Od(_0x284139),_0x437ef9=Lt(_0x174492,_0x5eb1e4),_0x37b1f8=Lt(_0x174492,_0x5eb1e4);let _0x46f71f;return _0x25bcc0!=null?_0x46f71f=Ld(_0x37b1f8,_0x25bcc0)['then'](()=>_0x37b1f8):_0x46f71f=Promise['resolve'](_0x37b1f8),_0x437ef9['then']=_0x46f71f['then']['bind'](_0x46f71f),_0x437ef9['catch']=_0x46f71f['then']['bind'](_0x46f71f,void 0x0),_0x437ef9;}function Ld(_0x24c0a2,_0x4c6f8c){_0x24c0a2=k(_0x24c0a2),gs('set',_0x24c0a2['_path']),qt('set',_0x4c6f8c,_0x24c0a2['_path'],!0x1);const _0x2a9b2a=new Ve();return Ed(_0x24c0a2['_repo'],_0x24c0a2['_path'],_0x4c6f8c,null,_0x2a9b2a['wrapCallback'](()=>{})),_0x2a9b2a['promise'];}function f_(_0x521ea3,_0x3b5d14){hd('update',_0x3b5d14,_0x521ea3['_path']);const _0x1014fa=new Ve();return Id(_0x521ea3['_repo'],_0x521ea3['_path'],_0x3b5d14,_0x1014fa['wrapCallback'](()=>{})),_0x1014fa['promise'];}function p_(_0x5efe79){_0x5efe79=k(_0x5efe79);const _0x122f88=new ua(()=>{}),_0x12e897=new qn(_0x122f88);return vd(_0x5efe79['_repo'],_0x5efe79,_0x12e897)['then'](_0x2b3395=>new rt(_0x2b3395,new Z(_0x5efe79['_repo'],_0x5efe79['_path']),_0x5efe79['_queryParams']['getIndex']()));}class qn{constructor(_0xf58830){this['callbackContext']=_0xf58830;}['respondsTo'](_0x3f752c){return _0x3f752c==='value';}['createEvent'](_0x21adb3,_0x4dd03a){const _0x49e54e=_0x4dd03a['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x21adb3['snapshotNode'],new Z(_0x4dd03a['_repo'],_0x4dd03a['_path']),_0x49e54e));}['getEventRunner'](_0x472c93){return _0x472c93['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x472c93['error']):()=>this['callbackContext']['onValue'](_0x472c93['snapshot'],null);}['createCancelEvent'](_0x2ab0be,_0xc056f2){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x2ab0be,_0xc056f2):null;}['matches'](_0x263702){return _0x263702 instanceof qn?!_0x263702['callbackContext']||!this['callbackContext']?!0x0:_0x263702['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4cad8e,_0x182366,_0x3d239e,_0x89cce0,_0x1c6a7e){const _0x35a78f=new ua(_0x3d239e,void 0x0),_0x2ee76d=new qn(_0x35a78f);return Cd(_0x4cad8e['_repo'],_0x4cad8e,_0x2ee76d),()=>Td(_0x4cad8e['_repo'],_0x4cad8e,_0x2ee76d);}function Fd(_0x37fbc2,_0x1a08c9,_0x39a0b8,_0x22dd9c){return xd(_0x37fbc2,'value',_0x1a08c9);}class dt{}class pa extends dt{constructor(_0x448937,_0x4e4857){super(),this['_value']=_0x448937,this['_key']=_0x4e4857,this['type']='endAt';}['_apply'](_0x184ef4){qt('endAt',this['_value'],_0x184ef4['_path'],!0x0);const _0x474900=Kh(_0x184ef4['_queryParams'],this['_value'],this['_key']);if(fa(_0x474900),Gn(_0x474900),_0x184ef4['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x184ef4['_repo'],_0x184ef4['_path'],_0x474900,_0x184ef4['_orderByCalled']);}}function __(_0x3824b8,_0x240135){return new pa(_0x3824b8,_0x240135);}class _a extends dt{constructor(_0x2dd4ee,_0x3cf255){super(),this['_value']=_0x2dd4ee,this['_key']=_0x3cf255,this['type']='startAt';}['_apply'](_0x1749c4){qt('startAt',this['_value'],_0x1749c4['_path'],!0x0);const _0x106fad=jh(_0x1749c4['_queryParams'],this['_value'],this['_key']);if(fa(_0x106fad),Gn(_0x106fad),_0x1749c4['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1749c4['_repo'],_0x1749c4['_path'],_0x106fad,_0x1749c4['_orderByCalled']);}}function g_(_0x36fbb6=null,_0x241034){return new _a(_0x36fbb6,_0x241034);}class Ud extends dt{constructor(_0x72f7af){super(),this['_limit']=_0x72f7af,this['type']='limitToFirst';}['_apply'](_0x1126d2){if(_0x1126d2['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1126d2['_repo'],_0x1126d2['_path'],zh(_0x1126d2['_queryParams'],this['_limit']),_0x1126d2['_orderByCalled']);}}function m_(_0x7d17b5){if(Math['floor'](_0x7d17b5)!==_0x7d17b5||_0x7d17b5<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x7d17b5);}class Wd extends dt{constructor(_0x3efec2){super(),this['_path']=_0x3efec2,this['type']='orderByChild';}['_apply'](_0x1d1189){da(_0x1d1189,'orderByChild');const _0x1b079b=new C(this['_path']);if(v(_0x1b079b))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5cd11f=new Ki(_0x1b079b),_0x268afd=Do(_0x1d1189['_queryParams'],_0x5cd11f);return Gn(_0x268afd),new be(_0x1d1189['_repo'],_0x1d1189['_path'],_0x268afd,!0x0);}}function y_(_0x2606ef){if(_0x2606ef==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2606ef==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2606ef==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2606ef),new Wd(_0x2606ef);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x58f101){da(_0x58f101,'orderByKey');const _0xa4611b=Do(_0x58f101['_queryParams'],ye);return Gn(_0xa4611b),new be(_0x58f101['_repo'],_0x58f101['_path'],_0xa4611b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x37ae60,_0x1ea0a8){super(),this['_value']=_0x37ae60,this['_key']=_0x1ea0a8,this['type']='equalTo';}['_apply'](_0x56e717){if(qt('equalTo',this['_value'],_0x56e717['_path'],!0x1),_0x56e717['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x56e717['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x56e717));}}function E_(_0x3a860e,_0x31d2a3){return new Vd(_0x3a860e,_0x31d2a3);}function I_(_0x13d2ed,..._0x77018b){let _0x890437=k(_0x13d2ed);for(const _0x3597df of _0x77018b)_0x890437=_0x3597df['_apply'](_0x890437);return _0x890437;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x4de0f1,_0x85b28,_0x33d5f8,_0x30edc1){const _0x56e8ce=_0x85b28['lastIndexOf'](':'),_0x350e4a=_0x85b28['substring'](0x0,_0x56e8ce),_0x2ca41c=Wt(_0x350e4a);_0x4de0f1['repoInfo_']=new _o(_0x85b28,_0x2ca41c,_0x4de0f1['repoInfo_']['namespace'],_0x4de0f1['repoInfo_']['webSocketOnly'],_0x4de0f1['repoInfo_']['nodeAdmin'],_0x4de0f1['repoInfo_']['persistenceKey'],_0x4de0f1['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x33d5f8),_0x30edc1&&(_0x4de0f1['authTokenProvider_']=_0x30edc1);}function qd(_0x424450,_0x964376,_0x498e08,_0x45a61d,_0x1cbbf9){let _0x2b1479=_0x45a61d||_0x424450['options']['databaseURL'];_0x2b1479===void 0x0&&(_0x424450['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x424450['options']['projectId']),_0x2b1479=_0x424450['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4a2543=gr(_0x2b1479,_0x1cbbf9),_0x3f9383=_0x4a2543['repoInfo'],_0x1dce2b;typeof process<'u'&&Us&&(_0x1dce2b=Us[Hd]),_0x1dce2b?(_0x2b1479='http://'+_0x1dce2b+'?ns='+_0x3f9383['namespace'],_0x4a2543=gr(_0x2b1479,_0x1cbbf9),_0x3f9383=_0x4a2543['repoInfo']):_0x4a2543['repoInfo']['secure'];const _0x4d54b1=new Jl(_0x424450['name'],_0x424450['options'],_0x964376);dd('Invalid\x20Firebase\x20Database\x20URL',_0x4a2543),v(_0x4a2543['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x345f84=jd(_0x3f9383,_0x424450,_0x4d54b1,new Ql(_0x424450,_0x498e08));return new Kd(_0x345f84,_0x424450);}function zd(_0x538db2,_0x503491){const _0x5da957=ki[_0x503491];(!_0x5da957||_0x5da957[_0x538db2['key']]!==_0x538db2)&&oe('Database\x20'+_0x503491+'('+_0x538db2['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x538db2),delete _0x5da957[_0x538db2['key']];}function jd(_0x11c0d8,_0x181fa1,_0x187ea9,_0x45a3b8){let _0x453980=ki[_0x181fa1['name']];_0x453980||(_0x453980={},ki[_0x181fa1['name']]=_0x453980);let _0x1a32b0=_0x453980[_0x11c0d8['toURLString']()];return _0x1a32b0&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1a32b0=new gd(_0x11c0d8,$d,_0x187ea9,_0x45a3b8),_0x453980[_0x11c0d8['toURLString']()]=_0x1a32b0,_0x1a32b0;}class Kd{constructor(_0x1adb00,_0x36d94d){this['_repoInternal']=_0x1adb00,this['app']=_0x36d94d,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x209f40){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x209f40+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x125023=Qr(),_0x3ba465){const _0x120d8c=Ui(_0x125023,'database')['getImmediate']({'identifier':_0x3ba465});if(!_0x120d8c['_instanceStarted']){const _0x40cdc9=ac('database');_0x40cdc9&&Yd(_0x120d8c,..._0x40cdc9);}return _0x120d8c;}function Yd(_0x5d94e5,_0x191e12,_0x2cf176,_0x205c1c={}){_0x5d94e5=k(_0x5d94e5),_0x5d94e5['_checkNotDeleted']('useEmulator');const _0x2ced43=_0x191e12+':'+_0x2cf176,_0x1c2705=_0x5d94e5['_repoInternal'];if(_0x5d94e5['_instanceStarted']){if(_0x2ced43===_0x5d94e5['_repoInternal']['repoInfo_']['host']&&De(_0x205c1c,_0x1c2705['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x225e50;if(_0x1c2705['repoInfo_']['nodeAdmin'])_0x205c1c['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x225e50=new tn(tn['OWNER']);else{if(_0x205c1c['mockUserToken']){const _0x5de4=typeof _0x205c1c['mockUserToken']=='string'?_0x205c1c['mockUserToken']:cc(_0x205c1c['mockUserToken'],_0x5d94e5['app']['options']['projectId']);_0x225e50=new tn(_0x5de4);}}Wt(_0x191e12)&&jr(_0x191e12),Gd(_0x1c2705,_0x2ced43,_0x205c1c,_0x225e50);}function C_(_0x214f80){_0x214f80=k(_0x214f80),_0x214f80['_checkNotDeleted']('goOffline'),aa(_0x214f80['_repo']);}function T_(_0x333473){_0x333473=k(_0x333473),_0x333473['_checkNotDeleted']('goOnline'),Sd(_0x333473['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x19ad0a){Ll(ct),et(new Me('database',(_0x456af2,{instanceIdentifier:_0x57b2ad})=>{const _0x53c655=_0x456af2['getProvider']('app')['getImmediate'](),_0x5bea88=_0x456af2['getProvider']('auth-internal'),_0x5a967d=_0x456af2['getProvider']('app-check-internal');return qd(_0x53c655,_0x5bea88,_0x5a967d,_0x57b2ad);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x19ad0a),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x453cfe,_0x5269b8){this['committed']=_0x453cfe,this['snapshot']=_0x5269b8;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x307b5d,_0x3e4cf2,_0xeecc46){if(_0x307b5d=k(_0x307b5d),gs('Reference.transaction',_0x307b5d['_path']),_0x307b5d['key']==='.length'||_0x307b5d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x307b5d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x467d10=!0x0,_0x3b0c00=new Ve(),_0x29e5e5=(_0x56e813,_0x5bf2d6,_0x3cfd7b)=>{let _0x2a1661=null;_0x56e813?_0x3b0c00['reject'](_0x56e813):(_0x2a1661=new rt(_0x3cfd7b,new Z(_0x307b5d['_repo'],_0x307b5d['_path']),R),_0x3b0c00['resolve'](new Xd(_0x5bf2d6,_0x2a1661)));},_0x2de72d=Fd(_0x307b5d,()=>{});return bd(_0x307b5d['_repo'],_0x307b5d['_path'],_0x3e4cf2,_0x29e5e5,_0x2de72d,_0x467d10),_0x3b0c00['promise'];}ie['prototype']['simpleListen']=function(_0x4f1ba4,_0x2cb626){this['sendRequest']('q',{'p':_0x4f1ba4},_0x2cb626);},ie['prototype']['echo']=function(_0x1e0be9,_0x530258){this['sendRequest']('echo',{'d':_0x1e0be9},_0x530258);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1e0268,..._0x10ac38){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1e0268,..._0x10ac38);}function nn(_0x1c6ca7,..._0x1d765c){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x1c6ca7,..._0x1d765c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x32cb34,..._0x3641b7){throw Es(_0x32cb34,..._0x3641b7);}function J(_0x2a8dbc,..._0x32b8ad){return Es(_0x2a8dbc,..._0x32b8ad);}function ya(_0x130158,_0x359a89,_0x5b85b8){const _0x3316e4={...Zd(),[_0x359a89]:_0x5b85b8};return new Ut('auth','Firebase',_0x3316e4)['create'](_0x359a89,{'appName':_0x130158['name']});}function se(_0x3ca3c5){return ya(_0x3ca3c5,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x15578e,..._0x18a7d4){if(typeof _0x15578e!='string'){const _0x1dbdde=_0x18a7d4[0x0],_0x27c269=[..._0x18a7d4['slice'](0x1)];return _0x27c269[0x0]&&(_0x27c269[0x0]['appName']=_0x15578e['name']),_0x15578e['_errorFactory']['create'](_0x1dbdde,..._0x27c269);}return ma['create'](_0x15578e,..._0x18a7d4);}function m(_0x3fd5ad,_0x2d3be5,..._0x1b1f13){if(!_0x3fd5ad)throw Es(_0x2d3be5,..._0x1b1f13);}function te(_0x7d6ef8){const _0x46f779='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x7d6ef8;throw nn(_0x46f779),new Error(_0x46f779);}function ae(_0x42c562,_0x3f0fdc){_0x42c562||te(_0x3f0fdc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x208931;return typeof self<'u'&&((_0x208931=self['location'])==null?void 0x0:_0x208931['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5957fe;return typeof self<'u'&&((_0x5957fe=self['location'])==null?void 0x0:_0x5957fe['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x2cd222=navigator;return _0x2cd222['languages']&&_0x2cd222['languages'][0x0]||_0x2cd222['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1c1ed1,_0x5b5e0d){this['shortDelay']=_0x1c1ed1,this['longDelay']=_0x5b5e0d,ae(_0x5b5e0d>_0x1c1ed1,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1b39a1,_0x41c1e8){ae(_0x1b39a1['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5c73f2}=_0x1b39a1['emulator'];return _0x41c1e8?''+_0x5c73f2+(_0x41c1e8['startsWith']('/')?_0x41c1e8['slice'](0x1):_0x41c1e8):_0x5c73f2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x57074a,_0xc31c45,_0x5eb589){this['fetchImpl']=_0x57074a,_0xc31c45&&(this['headersImpl']=_0xc31c45),_0x5eb589&&(this['responseImpl']=_0x5eb589);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x2f9a69,_0x11a985){return _0x2f9a69['tenantId']&&!_0x11a985['tenantId']?{..._0x11a985,'tenantId':_0x2f9a69['tenantId']}:_0x11a985;}async function Ae(_0x48c15b,_0x4c51c5,_0x1e6e47,_0x303920,_0x47b2eb={}){return Ea(_0x48c15b,_0x47b2eb,async()=>{let _0x5312a4={},_0x13a218={};_0x303920&&(_0x4c51c5==='GET'?_0x13a218=_0x303920:_0x5312a4={'body':JSON['stringify'](_0x303920)});const _0x491cca=at({..._0x13a218,'key':_0x48c15b['config']['apiKey']})['slice'](0x1),_0x23f01e=await _0x48c15b['_getAdditionalHeaders']();_0x23f01e['Content-Type']='application/json',_0x48c15b['languageCode']&&(_0x23f01e['X-Firebase-Locale']=_0x48c15b['languageCode']);const _0xf12f80={'method':_0x4c51c5,'headers':_0x23f01e,..._0x5312a4};return lc()||(_0xf12f80['referrerPolicy']='strict-origin-when-cross-origin'),_0x48c15b['emulatorConfig']&&Wt(_0x48c15b['emulatorConfig']['host'])&&(_0xf12f80['credentials']='include'),va['fetch']()(await Ia(_0x48c15b,_0x48c15b['config']['apiHost'],_0x1e6e47,_0x491cca),_0xf12f80);});}async function Ea(_0x1ab488,_0x296dca,_0x3786ea){_0x1ab488['_canInitEmulator']=!0x1;const _0x386315={...rf,..._0x296dca};try{const _0xb189eb=new lf(_0x1ab488),_0x3352c8=await Promise['race']([_0x3786ea(),_0xb189eb['promise']]);_0xb189eb['clearNetworkTimeout']();const _0x2da7ca=await _0x3352c8['json']();if('needConfirmation'in _0x2da7ca)throw en(_0x1ab488,'account-exists-with-different-credential',_0x2da7ca);if(_0x3352c8['ok']&&!('errorMessage'in _0x2da7ca))return _0x2da7ca;{const _0x6b2fda=_0x3352c8['ok']?_0x2da7ca['errorMessage']:_0x2da7ca['error']['message'],[_0x21f291,_0x6809f8]=_0x6b2fda['split']('\x20:\x20');if(_0x21f291==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1ab488,'credential-already-in-use',_0x2da7ca);if(_0x21f291==='EMAIL_EXISTS')throw en(_0x1ab488,'email-already-in-use',_0x2da7ca);if(_0x21f291==='USER_DISABLED')throw en(_0x1ab488,'user-disabled',_0x2da7ca);const _0x841d05=_0x386315[_0x21f291]||_0x21f291['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x6809f8)throw ya(_0x1ab488,_0x841d05,_0x6809f8);K(_0x1ab488,_0x841d05);}}catch(_0x2defc0){if(_0x2defc0 instanceof Se)throw _0x2defc0;K(_0x1ab488,'network-request-failed',{'message':String(_0x2defc0)});}}async function Yt(_0x19ed36,_0x5a95e1,_0xa5bfec,_0x25ba75,_0x11bd19={}){const _0x1f8b1e=await Ae(_0x19ed36,_0x5a95e1,_0xa5bfec,_0x25ba75,_0x11bd19);return'mfaPendingCredential'in _0x1f8b1e&&K(_0x19ed36,'multi-factor-auth-required',{'_serverResponse':_0x1f8b1e}),_0x1f8b1e;}async function Ia(_0x137080,_0x446ec5,_0x571214,_0x46466d){const _0x2b8522=''+_0x446ec5+_0x571214+'?'+_0x46466d,_0x8e0fa=_0x137080,_0x11b172=_0x8e0fa['config']['emulator']?Is(_0x137080['config'],_0x2b8522):_0x137080['config']['apiScheme']+'://'+_0x2b8522;return of['includes'](_0x571214)&&(await _0x8e0fa['_persistenceManagerAvailable'],_0x8e0fa['_getPersistenceType']()==='COOKIE')?_0x8e0fa['_getPersistence']()['_getFinalTarget'](_0x11b172)['toString']():_0x11b172;}function cf(_0x1b902a){switch(_0x1b902a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x360e4e){this['auth']=_0x360e4e,this['timer']=null,this['promise']=new Promise((_0x9fd4f4,_0xb2a21c)=>{this['timer']=setTimeout(()=>_0xb2a21c(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x16b4bf,_0x4921c4,_0x49086d){const _0x1d938f={'appName':_0x16b4bf['name']};_0x49086d['email']&&(_0x1d938f['email']=_0x49086d['email']),_0x49086d['phoneNumber']&&(_0x1d938f['phoneNumber']=_0x49086d['phoneNumber']);const _0x313ba7=J(_0x16b4bf,_0x4921c4,_0x1d938f);return _0x313ba7['customData']['_tokenResponse']=_0x49086d,_0x313ba7;}function vr(_0x1ff263){return _0x1ff263!==void 0x0&&_0x1ff263['enterprise']!==void 0x0;}class hf{constructor(_0x31d781){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x31d781['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x31d781['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x31d781['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x31ad88){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5500d5 of this['recaptchaEnforcementState'])if(_0x5500d5['provider']&&_0x5500d5['provider']===_0x31ad88)return cf(_0x5500d5['enforcementState']);return null;}['isProviderEnabled'](_0x30eaed){return this['getProviderEnforcementState'](_0x30eaed)==='ENFORCE'||this['getProviderEnforcementState'](_0x30eaed)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x1d081f,_0x2be57d){return Ae(_0x1d081f,'GET','/v2/recaptchaConfig',Re(_0x1d081f,_0x2be57d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x3087af,_0x3a18bc){return Ae(_0x3087af,'POST','/v1/accounts:delete',_0x3a18bc);}async function Sn(_0x502a62,_0x4aec76){return Ae(_0x502a62,'POST','/v1/accounts:lookup',_0x4aec76);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x478a18){if(_0x478a18)try{const _0x234a5a=new Date(Number(_0x478a18));if(!isNaN(_0x234a5a['getTime']()))return _0x234a5a['toUTCString']();}catch{}}async function ff(_0x271d99,_0x516448=!0x1){const _0x43bb83=k(_0x271d99),_0x15d094=await _0x43bb83['getIdToken'](_0x516448),_0x2ae9f3=ws(_0x15d094);m(_0x2ae9f3&&_0x2ae9f3['exp']&&_0x2ae9f3['auth_time']&&_0x2ae9f3['iat'],_0x43bb83['auth'],'internal-error');const _0x12510f=typeof _0x2ae9f3['firebase']=='object'?_0x2ae9f3['firebase']:void 0x0,_0x1c93cf=_0x12510f==null?void 0x0:_0x12510f['sign_in_provider'];return{'claims':_0x2ae9f3,'token':_0x15d094,'authTime':St(ci(_0x2ae9f3['auth_time'])),'issuedAtTime':St(ci(_0x2ae9f3['iat'])),'expirationTime':St(ci(_0x2ae9f3['exp'])),'signInProvider':_0x1c93cf||null,'signInSecondFactor':(_0x12510f==null?void 0x0:_0x12510f['sign_in_second_factor'])||null};}function ci(_0x5a235b){return Number(_0x5a235b)*0x3e8;}function ws(_0x24fe3a){const [_0x1e279e,_0x25928f,_0x421cb0]=_0x24fe3a['split']('.');if(_0x1e279e===void 0x0||_0x25928f===void 0x0||_0x421cb0===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x120b01=cn(_0x25928f);return _0x120b01?JSON['parse'](_0x120b01):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x7a6215){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x7a6215==null?void 0x0:_0x7a6215['toString']()),null;}}function Er(_0x53a982){const _0x5900c1=ws(_0x53a982);return m(_0x5900c1,'internal-error'),m(typeof _0x5900c1['exp']<'u','internal-error'),m(typeof _0x5900c1['iat']<'u','internal-error'),Number(_0x5900c1['exp'])-Number(_0x5900c1['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x1b3f00,_0x478fdb,_0x2ae959=!0x1){if(_0x2ae959)return _0x478fdb;try{return await _0x478fdb;}catch(_0x4e42bb){throw _0x4e42bb instanceof Se&&pf(_0x4e42bb)&&_0x1b3f00['auth']['currentUser']===_0x1b3f00&&await _0x1b3f00['auth']['signOut'](),_0x4e42bb;}}function pf({code:_0x2e54fb}){return _0x2e54fb==='auth/user-disabled'||_0x2e54fb==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xf5c61c){this['user']=_0xf5c61c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5ec03a){if(_0x5ec03a){const _0x1ee298=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1ee298;}else{this['errorBackoff']=0x7530;const _0x275f24=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x275f24);}}['schedule'](_0x4b1dab=!0x1){if(!this['isRunning'])return;const _0x2b5d8d=this['getInterval'](_0x4b1dab);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2b5d8d);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x474e79){(_0x474e79==null?void 0x0:_0x474e79['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x1d7a40,_0x42f17a){this['createdAt']=_0x1d7a40,this['lastLoginAt']=_0x42f17a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x48ef27){this['createdAt']=_0x48ef27['createdAt'],this['lastLoginAt']=_0x48ef27['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5cad81){var _0x50696b;const _0x4ab5d5=_0x5cad81['auth'],_0x525f83=await _0x5cad81['getIdToken'](),_0x55df34=await xt(_0x5cad81,Sn(_0x4ab5d5,{'idToken':_0x525f83}));m(_0x55df34==null?void 0x0:_0x55df34['users']['length'],_0x4ab5d5,'internal-error');const _0x2362d3=_0x55df34['users'][0x0];_0x5cad81['_notifyReloadListener'](_0x2362d3);const _0x562bbc=(_0x50696b=_0x2362d3['providerUserInfo'])!=null&&_0x50696b['length']?wa(_0x2362d3['providerUserInfo']):[],_0x30dbef=mf(_0x5cad81['providerData'],_0x562bbc),_0x359a68=_0x5cad81['isAnonymous'],_0x5c768f=!(_0x5cad81['email']&&_0x2362d3['passwordHash'])&&!(_0x30dbef!=null&&_0x30dbef['length']),_0x56d82b=_0x359a68?_0x5c768f:!0x1,_0xda819={'uid':_0x2362d3['localId'],'displayName':_0x2362d3['displayName']||null,'photoURL':_0x2362d3['photoUrl']||null,'email':_0x2362d3['email']||null,'emailVerified':_0x2362d3['emailVerified']||!0x1,'phoneNumber':_0x2362d3['phoneNumber']||null,'tenantId':_0x2362d3['tenantId']||null,'providerData':_0x30dbef,'metadata':new Pi(_0x2362d3['createdAt'],_0x2362d3['lastLoginAt']),'isAnonymous':_0x56d82b};Object['assign'](_0x5cad81,_0xda819);}async function gf(_0x42f72e){const _0x493dcc=k(_0x42f72e);await bn(_0x493dcc),await _0x493dcc['auth']['_persistUserIfCurrent'](_0x493dcc),_0x493dcc['auth']['_notifyListenersIfCurrent'](_0x493dcc);}function mf(_0x3be8d0,_0x5689d9){return[..._0x3be8d0['filter'](_0x406ca3=>!_0x5689d9['some'](_0x2326a2=>_0x2326a2['providerId']===_0x406ca3['providerId'])),..._0x5689d9];}function wa(_0x2055db){return _0x2055db['map'](({providerId:_0x402d3f,..._0x52c931})=>({'providerId':_0x402d3f,'uid':_0x52c931['rawId']||'','displayName':_0x52c931['displayName']||null,'email':_0x52c931['email']||null,'phoneNumber':_0x52c931['phoneNumber']||null,'photoURL':_0x52c931['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x13918,_0x4cfe14){const _0x52231c=await Ea(_0x13918,{},async()=>{const _0x2b3871=at({'grant_type':'refresh_token','refresh_token':_0x4cfe14})['slice'](0x1),{tokenApiHost:_0x388aa0,apiKey:_0x46617}=_0x13918['config'],_0x58e969=await Ia(_0x13918,_0x388aa0,'/v1/token','key='+_0x46617),_0x6c352b=await _0x13918['_getAdditionalHeaders']();_0x6c352b['Content-Type']='application/x-www-form-urlencoded';const _0x4facf5={'method':'POST','headers':_0x6c352b,'body':_0x2b3871};return _0x13918['emulatorConfig']&&Wt(_0x13918['emulatorConfig']['host'])&&(_0x4facf5['credentials']='include'),va['fetch']()(_0x58e969,_0x4facf5);});return{'accessToken':_0x52231c['access_token'],'expiresIn':_0x52231c['expires_in'],'refreshToken':_0x52231c['refresh_token']};}async function vf(_0x225db6,_0xf8071b){return Ae(_0x225db6,'POST','/v2/accounts:revokeToken',Re(_0x225db6,_0xf8071b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4e9070){m(_0x4e9070['idToken'],'internal-error'),m(typeof _0x4e9070['idToken']<'u','internal-error'),m(typeof _0x4e9070['refreshToken']<'u','internal-error');const _0x8ad5d0='expiresIn'in _0x4e9070&&typeof _0x4e9070['expiresIn']<'u'?Number(_0x4e9070['expiresIn']):Er(_0x4e9070['idToken']);this['updateTokensAndExpiration'](_0x4e9070['idToken'],_0x4e9070['refreshToken'],_0x8ad5d0);}['updateFromIdToken'](_0x22ce39){m(_0x22ce39['length']!==0x0,'internal-error');const _0x401bd0=Er(_0x22ce39);this['updateTokensAndExpiration'](_0x22ce39,null,_0x401bd0);}async['getToken'](_0x3bc1d0,_0x422518=!0x1){return!_0x422518&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3bc1d0,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3bc1d0,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2afdc5,_0x417154){const {accessToken:_0x1790b6,refreshToken:_0x3c9462,expiresIn:_0x202c9a}=await yf(_0x2afdc5,_0x417154);this['updateTokensAndExpiration'](_0x1790b6,_0x3c9462,Number(_0x202c9a));}['updateTokensAndExpiration'](_0x2f5a88,_0x148234,_0x3ddb95){this['refreshToken']=_0x148234||null,this['accessToken']=_0x2f5a88||null,this['expirationTime']=Date['now']()+_0x3ddb95*0x3e8;}static['fromJSON'](_0x165ce2,_0x1c8f0a){const {refreshToken:_0x38b32b,accessToken:_0x1500ca,expirationTime:_0x29b03c}=_0x1c8f0a,_0x122515=new Je();return _0x38b32b&&(m(typeof _0x38b32b=='string','internal-error',{'appName':_0x165ce2}),_0x122515['refreshToken']=_0x38b32b),_0x1500ca&&(m(typeof _0x1500ca=='string','internal-error',{'appName':_0x165ce2}),_0x122515['accessToken']=_0x1500ca),_0x29b03c&&(m(typeof _0x29b03c=='number','internal-error',{'appName':_0x165ce2}),_0x122515['expirationTime']=_0x29b03c),_0x122515;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x515bbe){this['accessToken']=_0x515bbe['accessToken'],this['refreshToken']=_0x515bbe['refreshToken'],this['expirationTime']=_0x515bbe['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x9e617f,_0xd41395){m(typeof _0x9e617f=='string'||typeof _0x9e617f>'u','internal-error',{'appName':_0xd41395});}class z{constructor({uid:_0x2c356e,auth:_0x5a00ff,stsTokenManager:_0x55b6f4,..._0x2878ea}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2c356e,this['auth']=_0x5a00ff,this['stsTokenManager']=_0x55b6f4,this['accessToken']=_0x55b6f4['accessToken'],this['displayName']=_0x2878ea['displayName']||null,this['email']=_0x2878ea['email']||null,this['emailVerified']=_0x2878ea['emailVerified']||!0x1,this['phoneNumber']=_0x2878ea['phoneNumber']||null,this['photoURL']=_0x2878ea['photoURL']||null,this['isAnonymous']=_0x2878ea['isAnonymous']||!0x1,this['tenantId']=_0x2878ea['tenantId']||null,this['providerData']=_0x2878ea['providerData']?[..._0x2878ea['providerData']]:[],this['metadata']=new Pi(_0x2878ea['createdAt']||void 0x0,_0x2878ea['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2ff81d){const _0x117200=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2ff81d));return m(_0x117200,this['auth'],'internal-error'),this['accessToken']!==_0x117200&&(this['accessToken']=_0x117200,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x117200;}['getIdTokenResult'](_0x4c26cd){return ff(this,_0x4c26cd);}['reload'](){return gf(this);}['_assign'](_0x5ecdfe){this!==_0x5ecdfe&&(m(this['uid']===_0x5ecdfe['uid'],this['auth'],'internal-error'),this['displayName']=_0x5ecdfe['displayName'],this['photoURL']=_0x5ecdfe['photoURL'],this['email']=_0x5ecdfe['email'],this['emailVerified']=_0x5ecdfe['emailVerified'],this['phoneNumber']=_0x5ecdfe['phoneNumber'],this['isAnonymous']=_0x5ecdfe['isAnonymous'],this['tenantId']=_0x5ecdfe['tenantId'],this['providerData']=_0x5ecdfe['providerData']['map'](_0x497726=>({..._0x497726})),this['metadata']['_copy'](_0x5ecdfe['metadata']),this['stsTokenManager']['_assign'](_0x5ecdfe['stsTokenManager']));}['_clone'](_0x3df3e9){const _0x3023a5=new z({...this,'auth':_0x3df3e9,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3023a5['metadata']['_copy'](this['metadata']),_0x3023a5;}['_onReload'](_0x1c935d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1c935d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3c32ac){this['reloadListener']?this['reloadListener'](_0x3c32ac):this['reloadUserInfo']=_0x3c32ac;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1b1b4b,_0x34327c=!0x1){let _0x291a37=!0x1;_0x1b1b4b['idToken']&&_0x1b1b4b['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1b1b4b),_0x291a37=!0x0),_0x34327c&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x291a37&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x342e99=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x342e99})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1d87f5=>({..._0x1d87f5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x244e47,_0xa75794){const _0x38cbcb=_0xa75794['displayName']??void 0x0,_0x4048f3=_0xa75794['email']??void 0x0,_0x4c865d=_0xa75794['phoneNumber']??void 0x0,_0x4535fd=_0xa75794['photoURL']??void 0x0,_0x365e1d=_0xa75794['tenantId']??void 0x0,_0x4afa7b=_0xa75794['_redirectEventId']??void 0x0,_0x1c6405=_0xa75794['createdAt']??void 0x0,_0x34a5df=_0xa75794['lastLoginAt']??void 0x0,{uid:_0x205097,emailVerified:_0x58c181,isAnonymous:_0x335500,providerData:_0x19bc3c,stsTokenManager:_0x9e9134}=_0xa75794;m(_0x205097&&_0x9e9134,_0x244e47,'internal-error');const _0xd66492=Je['fromJSON'](this['name'],_0x9e9134);m(typeof _0x205097=='string',_0x244e47,'internal-error'),ce(_0x38cbcb,_0x244e47['name']),ce(_0x4048f3,_0x244e47['name']),m(typeof _0x58c181=='boolean',_0x244e47,'internal-error'),m(typeof _0x335500=='boolean',_0x244e47,'internal-error'),ce(_0x4c865d,_0x244e47['name']),ce(_0x4535fd,_0x244e47['name']),ce(_0x365e1d,_0x244e47['name']),ce(_0x4afa7b,_0x244e47['name']),ce(_0x1c6405,_0x244e47['name']),ce(_0x34a5df,_0x244e47['name']);const _0x4f9add=new z({'uid':_0x205097,'auth':_0x244e47,'email':_0x4048f3,'emailVerified':_0x58c181,'displayName':_0x38cbcb,'isAnonymous':_0x335500,'photoURL':_0x4535fd,'phoneNumber':_0x4c865d,'tenantId':_0x365e1d,'stsTokenManager':_0xd66492,'createdAt':_0x1c6405,'lastLoginAt':_0x34a5df});return _0x19bc3c&&Array['isArray'](_0x19bc3c)&&(_0x4f9add['providerData']=_0x19bc3c['map'](_0x427c41=>({..._0x427c41}))),_0x4afa7b&&(_0x4f9add['_redirectEventId']=_0x4afa7b),_0x4f9add;}static async['_fromIdTokenResponse'](_0x7b0fcb,_0x3eb9e9,_0x370799=!0x1){const _0x2913bc=new Je();_0x2913bc['updateFromServerResponse'](_0x3eb9e9);const _0x5bfe2c=new z({'uid':_0x3eb9e9['localId'],'auth':_0x7b0fcb,'stsTokenManager':_0x2913bc,'isAnonymous':_0x370799});return await bn(_0x5bfe2c),_0x5bfe2c;}static async['_fromGetAccountInfoResponse'](_0x192740,_0x413ae2,_0x4803fe){const _0x106442=_0x413ae2['users'][0x0];m(_0x106442['localId']!==void 0x0,'internal-error');const _0x4b553=_0x106442['providerUserInfo']!==void 0x0?wa(_0x106442['providerUserInfo']):[],_0x45af95=!(_0x106442['email']&&_0x106442['passwordHash'])&&!(_0x4b553!=null&&_0x4b553['length']),_0xa8a90b=new Je();_0xa8a90b['updateFromIdToken'](_0x4803fe);const _0x11b461=new z({'uid':_0x106442['localId'],'auth':_0x192740,'stsTokenManager':_0xa8a90b,'isAnonymous':_0x45af95}),_0x239bac={'uid':_0x106442['localId'],'displayName':_0x106442['displayName']||null,'photoURL':_0x106442['photoUrl']||null,'email':_0x106442['email']||null,'emailVerified':_0x106442['emailVerified']||!0x1,'phoneNumber':_0x106442['phoneNumber']||null,'tenantId':_0x106442['tenantId']||null,'providerData':_0x4b553,'metadata':new Pi(_0x106442['createdAt'],_0x106442['lastLoginAt']),'isAnonymous':!(_0x106442['email']&&_0x106442['passwordHash'])&&!(_0x4b553!=null&&_0x4b553['length'])};return Object['assign'](_0x11b461,_0x239bac),_0x11b461;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x193b88){ae(_0x193b88 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5e79ee=Ir['get'](_0x193b88);return _0x5e79ee?(ae(_0x5e79ee instanceof _0x193b88,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5e79ee):(_0x5e79ee=new _0x193b88(),Ir['set'](_0x193b88,_0x5e79ee),_0x5e79ee);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x314f0b,_0x21d274){this['storage'][_0x314f0b]=_0x21d274;}async['_get'](_0x463d26){const _0x2d4ece=this['storage'][_0x463d26];return _0x2d4ece===void 0x0?null:_0x2d4ece;}async['_remove'](_0x598188){delete this['storage'][_0x598188];}['_addListener'](_0x2b738f,_0x1d423a){}['_removeListener'](_0x30ca66,_0x2a6567){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x47ebdc,_0x2c0baa,_0x5a86a6){return'firebase:'+_0x47ebdc+':'+_0x2c0baa+':'+_0x5a86a6;}class Xe{constructor(_0x2626f4,_0xeb53bc,_0x32aaa2){this['persistence']=_0x2626f4,this['auth']=_0xeb53bc,this['userKey']=_0x32aaa2;const {config:_0x23bd81,name:_0x125563}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x23bd81['apiKey'],_0x125563),this['fullPersistenceKey']=sn('persistence',_0x23bd81['apiKey'],_0x125563),this['boundEventHandler']=_0xeb53bc['_onStorageEvent']['bind'](_0xeb53bc),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3ef5bb){return this['persistence']['_set'](this['fullUserKey'],_0x3ef5bb['toJSON']());}async['getCurrentUser'](){const _0x32a942=await this['persistence']['_get'](this['fullUserKey']);if(!_0x32a942)return null;if(typeof _0x32a942=='string'){const _0x4da7d5=await Sn(this['auth'],{'idToken':_0x32a942})['catch'](()=>{});return _0x4da7d5?z['_fromGetAccountInfoResponse'](this['auth'],_0x4da7d5,_0x32a942):null;}return z['_fromJSON'](this['auth'],_0x32a942);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x180b8d){if(this['persistence']===_0x180b8d)return;const _0x51c3d0=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x180b8d,_0x51c3d0)return this['setCurrentUser'](_0x51c3d0);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x187287,_0x561dbb,_0x14a0f1='authUser'){if(!_0x561dbb['length'])return new Xe(ne(wr),_0x187287,_0x14a0f1);const _0x1595fd=(await Promise['all'](_0x561dbb['map'](async _0x25529b=>{if(await _0x25529b['_isAvailable']())return _0x25529b;})))['filter'](_0x53f37a=>_0x53f37a);let _0x2e49d7=_0x1595fd[0x0]||ne(wr);const _0x2edb8c=sn(_0x14a0f1,_0x187287['config']['apiKey'],_0x187287['name']);let _0x480ddd=null;for(const _0x987851 of _0x561dbb)try{const _0x47d53f=await _0x987851['_get'](_0x2edb8c);if(_0x47d53f){let _0x4f77d7;if(typeof _0x47d53f=='string'){const _0x4e9d9f=await Sn(_0x187287,{'idToken':_0x47d53f})['catch'](()=>{});if(!_0x4e9d9f)break;_0x4f77d7=await z['_fromGetAccountInfoResponse'](_0x187287,_0x4e9d9f,_0x47d53f);}else _0x4f77d7=z['_fromJSON'](_0x187287,_0x47d53f);_0x987851!==_0x2e49d7&&(_0x480ddd=_0x4f77d7),_0x2e49d7=_0x987851;break;}}catch{}const _0x3a1acf=_0x1595fd['filter'](_0x403514=>_0x403514['_shouldAllowMigration']);return!_0x2e49d7['_shouldAllowMigration']||!_0x3a1acf['length']?new Xe(_0x2e49d7,_0x187287,_0x14a0f1):(_0x2e49d7=_0x3a1acf[0x0],_0x480ddd&&await _0x2e49d7['_set'](_0x2edb8c,_0x480ddd['toJSON']()),await Promise['all'](_0x561dbb['map'](async _0x5de8c7=>{if(_0x5de8c7!==_0x2e49d7)try{await _0x5de8c7['_remove'](_0x2edb8c);}catch{}})),new Xe(_0x2e49d7,_0x187287,_0x14a0f1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3f53ce){const _0x4b6cff=_0x3f53ce['toLowerCase']();if(_0x4b6cff['includes']('opera/')||_0x4b6cff['includes']('opr/')||_0x4b6cff['includes']('opios/'))return'Opera';if(Ra(_0x4b6cff))return'IEMobile';if(_0x4b6cff['includes']('msie')||_0x4b6cff['includes']('trident/'))return'IE';if(_0x4b6cff['includes']('edge/'))return'Edge';if(Ta(_0x4b6cff))return'Firefox';if(_0x4b6cff['includes']('silk/'))return'Silk';if(ka(_0x4b6cff))return'Blackberry';if(Na(_0x4b6cff))return'Webos';if(Sa(_0x4b6cff))return'Safari';if((_0x4b6cff['includes']('chrome/')||ba(_0x4b6cff))&&!_0x4b6cff['includes']('edge/'))return'Chrome';if(Aa(_0x4b6cff))return'Android';{const _0x12c406=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x375302=_0x3f53ce['match'](_0x12c406);if((_0x375302==null?void 0x0:_0x375302['length'])===0x2)return _0x375302[0x1];}return'Other';}function Ta(_0x2d4b9b=W()){return/firefox\//i['test'](_0x2d4b9b);}function Sa(_0x17f0e8=W()){const _0xccbcc0=_0x17f0e8['toLowerCase']();return _0xccbcc0['includes']('safari/')&&!_0xccbcc0['includes']('chrome/')&&!_0xccbcc0['includes']('crios/')&&!_0xccbcc0['includes']('android');}function ba(_0x31e5cc=W()){return/crios\//i['test'](_0x31e5cc);}function Ra(_0x5ed54d=W()){return/iemobile/i['test'](_0x5ed54d);}function Aa(_0x3ecde3=W()){return/android/i['test'](_0x3ecde3);}function ka(_0x2eda9c=W()){return/blackberry/i['test'](_0x2eda9c);}function Na(_0xf864ff=W()){return/webos/i['test'](_0xf864ff);}function Cs(_0x6eac6c=W()){return/iphone|ipad|ipod/i['test'](_0x6eac6c)||/macintosh/i['test'](_0x6eac6c)&&/mobile/i['test'](_0x6eac6c);}function Ef(_0x351a50=W()){var _0x423e50;return Cs(_0x351a50)&&!!((_0x423e50=window['navigator'])!=null&&_0x423e50['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0xd0eefa=W()){return Cs(_0xd0eefa)||Aa(_0xd0eefa)||Na(_0xd0eefa)||ka(_0xd0eefa)||/windows phone/i['test'](_0xd0eefa)||Ra(_0xd0eefa);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x13006e,_0x377700=[]){let _0x5ef8e2;switch(_0x13006e){case'Browser':_0x5ef8e2=Cr(W());break;case'Worker':_0x5ef8e2=Cr(W())+'-'+_0x13006e;break;default:_0x5ef8e2=_0x13006e;}const _0x3da549=_0x377700['length']?_0x377700['join'](','):'FirebaseCore-web';return _0x5ef8e2+'/JsCore/'+ct+'/'+_0x3da549;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x19022d){this['auth']=_0x19022d,this['queue']=[];}['pushCallback'](_0x9b5119,_0x453b8e){const _0x358e88=_0x5caf52=>new Promise((_0x49f1d7,_0x28ad0e)=>{try{const _0x11cc48=_0x9b5119(_0x5caf52);_0x49f1d7(_0x11cc48);}catch(_0x38e227){_0x28ad0e(_0x38e227);}});_0x358e88['onAbort']=_0x453b8e,this['queue']['push'](_0x358e88);const _0x598e77=this['queue']['length']-0x1;return()=>{this['queue'][_0x598e77]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3b3b54){if(this['auth']['currentUser']===_0x3b3b54)return;const _0x493b6d=[];try{for(const _0x476c02 of this['queue'])await _0x476c02(_0x3b3b54),_0x476c02['onAbort']&&_0x493b6d['push'](_0x476c02['onAbort']);}catch(_0x34a0e6){_0x493b6d['reverse']();for(const _0x13f4ff of _0x493b6d)try{_0x13f4ff();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x34a0e6==null?void 0x0:_0x34a0e6['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x29d8b9,_0x2b6f78={}){return Ae(_0x29d8b9,'GET','/v2/passwordPolicy',Re(_0x29d8b9,_0x2b6f78));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x56a600){var _0x1f89f2;const _0x2fa409=_0x56a600['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2fa409['minPasswordLength']??Tf,_0x2fa409['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2fa409['maxPasswordLength']),_0x2fa409['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2fa409['containsLowercaseCharacter']),_0x2fa409['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2fa409['containsUppercaseCharacter']),_0x2fa409['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2fa409['containsNumericCharacter']),_0x2fa409['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2fa409['containsNonAlphanumericCharacter']),this['enforcementState']=_0x56a600['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1f89f2=_0x56a600['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1f89f2['join'](''))??'',this['forceUpgradeOnSignin']=_0x56a600['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x56a600['schemaVersion'];}['validatePassword'](_0x207e09){const _0x343d36={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x207e09,_0x343d36),this['validatePasswordCharacterOptions'](_0x207e09,_0x343d36),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['meetsMinPasswordLength']??!0x0),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['meetsMaxPasswordLength']??!0x0),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['containsLowercaseLetter']??!0x0),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['containsUppercaseLetter']??!0x0),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['containsNumericCharacter']??!0x0),_0x343d36['isValid']&&(_0x343d36['isValid']=_0x343d36['containsNonAlphanumericCharacter']??!0x0),_0x343d36;}['validatePasswordLengthOptions'](_0x472374,_0x8a3aa4){const _0x36bd0b=this['customStrengthOptions']['minPasswordLength'],_0x2d6dfe=this['customStrengthOptions']['maxPasswordLength'];_0x36bd0b&&(_0x8a3aa4['meetsMinPasswordLength']=_0x472374['length']>=_0x36bd0b),_0x2d6dfe&&(_0x8a3aa4['meetsMaxPasswordLength']=_0x472374['length']<=_0x2d6dfe);}['validatePasswordCharacterOptions'](_0x2c8252,_0x4698d7){this['updatePasswordCharacterOptionsStatuses'](_0x4698d7,!0x1,!0x1,!0x1,!0x1);let _0x1c4216;for(let _0xea1483=0x0;_0xea1483<_0x2c8252['length'];_0xea1483++)_0x1c4216=_0x2c8252['charAt'](_0xea1483),this['updatePasswordCharacterOptionsStatuses'](_0x4698d7,_0x1c4216>='a'&&_0x1c4216<='z',_0x1c4216>='A'&&_0x1c4216<='Z',_0x1c4216>='0'&&_0x1c4216<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1c4216));}['updatePasswordCharacterOptionsStatuses'](_0x516622,_0x2e8d9a,_0x402024,_0x35ef68,_0x568821){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x516622['containsLowercaseLetter']||(_0x516622['containsLowercaseLetter']=_0x2e8d9a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x516622['containsUppercaseLetter']||(_0x516622['containsUppercaseLetter']=_0x402024)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x516622['containsNumericCharacter']||(_0x516622['containsNumericCharacter']=_0x35ef68)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x516622['containsNonAlphanumericCharacter']||(_0x516622['containsNonAlphanumericCharacter']=_0x568821));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x309cc4,_0x1afa19,_0x41c087,_0x2ff852){this['app']=_0x309cc4,this['heartbeatServiceProvider']=_0x1afa19,this['appCheckServiceProvider']=_0x41c087,this['config']=_0x2ff852,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x309cc4['name'],this['clientVersion']=_0x2ff852['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4fd41f=>this['_resolvePersistenceManagerAvailable']=_0x4fd41f);}['_initializeWithPersistence'](_0x573d44,_0x507cb1){return _0x507cb1&&(this['_popupRedirectResolver']=ne(_0x507cb1)),this['_initializationPromise']=this['queue'](async()=>{var _0x3efc9d,_0x3619e8,_0xe6a253;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x573d44),(_0x3efc9d=this['_resolvePersistenceManagerAvailable'])==null||_0x3efc9d['call'](this),!this['_deleted'])){if((_0x3619e8=this['_popupRedirectResolver'])!=null&&_0x3619e8['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x507cb1),this['lastNotifiedUid']=((_0xe6a253=this['currentUser'])==null?void 0x0:_0xe6a253['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2f41a5=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2f41a5)){if(this['currentUser']&&_0x2f41a5&&this['currentUser']['uid']===_0x2f41a5['uid']){this['_currentUser']['_assign'](_0x2f41a5),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2f41a5,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1d8ca2){try{const _0x1be0ee=await Sn(this,{'idToken':_0x1d8ca2}),_0x36e243=await z['_fromGetAccountInfoResponse'](this,_0x1be0ee,_0x1d8ca2);await this['directlySetCurrentUser'](_0x36e243);}catch(_0x4a22bd){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4a22bd),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x169417){var _0x2ccb07;if(H(this['app'])){const _0x2a0af9=this['app']['settings']['authIdToken'];return _0x2a0af9?new Promise(_0x12b26d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2a0af9)['then'](_0x12b26d,_0x12b26d));}):this['directlySetCurrentUser'](null);}const _0x2b429f=await this['assertedPersistence']['getCurrentUser']();let _0x556436=_0x2b429f,_0x69d7ee=!0x1;if(_0x169417&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5a670a=(_0x2ccb07=this['redirectUser'])==null?void 0x0:_0x2ccb07['_redirectEventId'],_0x309834=_0x556436==null?void 0x0:_0x556436['_redirectEventId'],_0x559629=await this['tryRedirectSignIn'](_0x169417);(!_0x5a670a||_0x5a670a===_0x309834)&&(_0x559629!=null&&_0x559629['user'])&&(_0x556436=_0x559629['user'],_0x69d7ee=!0x0);}if(!_0x556436)return this['directlySetCurrentUser'](null);if(!_0x556436['_redirectEventId']){if(_0x69d7ee)try{await this['beforeStateQueue']['runMiddleware'](_0x556436);}catch(_0x532a96){_0x556436=_0x2b429f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x532a96));}return _0x556436?this['reloadAndSetCurrentUserOrClear'](_0x556436):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x556436['_redirectEventId']?this['directlySetCurrentUser'](_0x556436):this['reloadAndSetCurrentUserOrClear'](_0x556436);}async['tryRedirectSignIn'](_0x3c4a55){let _0x1b1c42=null;try{_0x1b1c42=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3c4a55,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1b1c42;}async['reloadAndSetCurrentUserOrClear'](_0x300542){try{await bn(_0x300542);}catch(_0x17acf1){if((_0x17acf1==null?void 0x0:_0x17acf1['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x300542);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x276ce2){if(H(this['app']))return Promise['reject'](se(this));const _0x426585=_0x276ce2?k(_0x276ce2):null;return _0x426585&&m(_0x426585['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x426585&&_0x426585['_clone'](this));}async['_updateCurrentUser'](_0x177883,_0x5012e0=!0x1){if(!this['_deleted'])return _0x177883&&m(this['tenantId']===_0x177883['tenantId'],this,'tenant-id-mismatch'),_0x5012e0||await this['beforeStateQueue']['runMiddleware'](_0x177883),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x177883),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xed27e0){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xed27e0));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1444a6){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4fcab0=this['_getPasswordPolicyInternal']();return _0x4fcab0['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4fcab0['validatePassword'](_0x1444a6);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x8b3340=await Cf(this),_0x52c3ee=new Sf(_0x8b3340);this['tenantId']===null?this['_projectPasswordPolicy']=_0x52c3ee:this['_tenantPasswordPolicies'][this['tenantId']]=_0x52c3ee;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x264ca7){this['_errorFactory']=new Ut('auth','Firebase',_0x264ca7());}['onAuthStateChanged'](_0x48c480,_0x16b013,_0x1c4d06){return this['registerStateListener'](this['authStateSubscription'],_0x48c480,_0x16b013,_0x1c4d06);}['beforeAuthStateChanged'](_0x4d8b8e,_0x59e72a){return this['beforeStateQueue']['pushCallback'](_0x4d8b8e,_0x59e72a);}['onIdTokenChanged'](_0x641358,_0xddbdd5,_0x259e10){return this['registerStateListener'](this['idTokenSubscription'],_0x641358,_0xddbdd5,_0x259e10);}['authStateReady'](){return new Promise((_0x44e6dd,_0x165fb2)=>{if(this['currentUser'])_0x44e6dd();else{const _0x3a23b9=this['onAuthStateChanged'](()=>{_0x3a23b9(),_0x44e6dd();},_0x165fb2);}});}async['revokeAccessToken'](_0x3376f8){if(this['currentUser']){const _0x261021=await this['currentUser']['getIdToken'](),_0xbc9b3b={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3376f8,'idToken':_0x261021};this['tenantId']!=null&&(_0xbc9b3b['tenantId']=this['tenantId']),await vf(this,_0xbc9b3b);}}['toJSON'](){var _0x44ef34;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x44ef34=this['_currentUser'])==null?void 0x0:_0x44ef34['toJSON']()};}async['_setRedirectUser'](_0x2a0d83,_0x3ce656){const _0x40edcf=await this['getOrInitRedirectPersistenceManager'](_0x3ce656);return _0x2a0d83===null?_0x40edcf['removeCurrentUser']():_0x40edcf['setCurrentUser'](_0x2a0d83);}async['getOrInitRedirectPersistenceManager'](_0x29c000){if(!this['redirectPersistenceManager']){const _0x2f4d74=_0x29c000&&ne(_0x29c000)||this['_popupRedirectResolver'];m(_0x2f4d74,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x2f4d74['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x655c29){var _0x3fc258,_0x21ea56;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3fc258=this['_currentUser'])==null?void 0x0:_0x3fc258['_redirectEventId'])===_0x655c29?this['_currentUser']:((_0x21ea56=this['redirectUser'])==null?void 0x0:_0x21ea56['_redirectEventId'])===_0x655c29?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x27e9ab){if(_0x27e9ab===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x27e9ab));}['_notifyListenersIfCurrent'](_0x155a03){_0x155a03===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x29e71c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5719e9=((_0x29e71c=this['currentUser'])==null?void 0x0:_0x29e71c['uid'])??null;this['lastNotifiedUid']!==_0x5719e9&&(this['lastNotifiedUid']=_0x5719e9,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x20a3da,_0x495a49,_0x13a017,_0x3cca17){if(this['_deleted'])return()=>{};const _0x5ed85b=typeof _0x495a49=='function'?_0x495a49:_0x495a49['next']['bind'](_0x495a49);let _0x5aab06=!0x1;const _0x21d4e3=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x21d4e3,this,'internal-error'),_0x21d4e3['then'](()=>{_0x5aab06||_0x5ed85b(this['currentUser']);}),typeof _0x495a49=='function'){const _0x152fab=_0x20a3da['addObserver'](_0x495a49,_0x13a017,_0x3cca17);return()=>{_0x5aab06=!0x0,_0x152fab();};}else{const _0x15e976=_0x20a3da['addObserver'](_0x495a49);return()=>{_0x5aab06=!0x0,_0x15e976();};}}async['directlySetCurrentUser'](_0x5a8005){this['currentUser']&&this['currentUser']!==_0x5a8005&&this['_currentUser']['_stopProactiveRefresh'](),_0x5a8005&&this['isProactiveRefreshEnabled']&&_0x5a8005['_startProactiveRefresh'](),this['currentUser']=_0x5a8005,_0x5a8005?await this['assertedPersistence']['setCurrentUser'](_0x5a8005):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x20bbdf){return this['operations']=this['operations']['then'](_0x20bbdf,_0x20bbdf),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1c4446){!_0x1c4446||this['frameworks']['includes'](_0x1c4446)||(this['frameworks']['push'](_0x1c4446),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x51de52;const _0x318703={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x318703['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4126c3=await((_0x51de52=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x51de52['getHeartbeatsHeader']());_0x4126c3&&(_0x318703['X-Firebase-Client']=_0x4126c3);const _0x58d0c3=await this['_getAppCheckToken']();return _0x58d0c3&&(_0x318703['X-Firebase-AppCheck']=_0x58d0c3),_0x318703;}async['_getAppCheckToken'](){var _0x40374b;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1e9c75=await((_0x40374b=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x40374b['getToken']());return _0x1e9c75!=null&&_0x1e9c75['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1e9c75['error']),_0x1e9c75==null?void 0x0:_0x1e9c75['token'];}}function qe(_0x27fd3c){return k(_0x27fd3c);}class Tr{constructor(_0x45a0f0){this['auth']=_0x45a0f0,this['observer']=null,this['addObserver']=Ic(_0x4a7a08=>this['observer']=_0x4a7a08);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x24c656){zn=_0x24c656;}function Da(_0x369a3d){return zn['loadJS'](_0x369a3d);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x342cd1){return'__'+_0x342cd1+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x103111){_0x103111();}['execute'](_0x41353b,_0x250576){return Promise['resolve']('token');}['render'](_0x477e46,_0x4482a6){return'';}}class Of{['ready'](_0x264915){_0x264915();}['execute'](_0x369d48,_0x2a1933){return Promise['resolve']('token');}['render'](_0x28bb1a,_0x47c1bb){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x26363d){this['type']=Df,this['auth']=qe(_0x26363d);}async['verify'](_0xf8477d='verify',_0x24de6d=!0x1){async function _0x2b2502(_0x494e33){if(!_0x24de6d){if(_0x494e33['tenantId']==null&&_0x494e33['_agentRecaptchaConfig']!=null)return _0x494e33['_agentRecaptchaConfig']['siteKey'];if(_0x494e33['tenantId']!=null&&_0x494e33['_tenantRecaptchaConfigs'][_0x494e33['tenantId']]!==void 0x0)return _0x494e33['_tenantRecaptchaConfigs'][_0x494e33['tenantId']]['siteKey'];}return new Promise(async(_0x4f4a3f,_0x108ff1)=>{uf(_0x494e33,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x9108bc=>{if(_0x9108bc['recaptchaKey']===void 0x0)_0x108ff1(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5aae7f=new hf(_0x9108bc);return _0x494e33['tenantId']==null?_0x494e33['_agentRecaptchaConfig']=_0x5aae7f:_0x494e33['_tenantRecaptchaConfigs'][_0x494e33['tenantId']]=_0x5aae7f,_0x4f4a3f(_0x5aae7f['siteKey']);}})['catch'](_0x231348=>{_0x108ff1(_0x231348);});});}function _0x40597d(_0x211f73,_0x3fe46a,_0x4219f3){const _0x514578=window['grecaptcha'];vr(_0x514578)?_0x514578['enterprise']['ready'](()=>{_0x514578['enterprise']['execute'](_0x211f73,{'action':_0xf8477d})['then'](_0x14d45b=>{_0x3fe46a(_0x14d45b);})['catch'](()=>{_0x3fe46a(Ma);});}):_0x4219f3(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x32b727,_0x4358af)=>{_0x2b2502(this['auth'])['then'](async _0x551cf0=>{if(!_0x24de6d&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x40597d(_0x551cf0,_0x32b727,_0x4358af);else{if(typeof window>'u'){_0x4358af(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4214f7=Af();_0x4214f7['length']!==0x0&&(_0x4214f7+=_0x551cf0+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x3c081c;(_0x3c081c=le['scriptInjectionDeferred'])==null||_0x3c081c['resolve']();},Da(_0x4214f7)['then'](()=>{var _0xc4fdf1;return(_0xc4fdf1=le['scriptInjectionDeferred'])==null?void 0x0:_0xc4fdf1['promise'];})['then'](()=>{_0x40597d(_0x551cf0,_0x32b727,_0x4358af);})['catch'](_0x10dddc=>{_0x4358af(_0x10dddc);});}})['catch'](_0x1cbacc=>{_0x4358af(_0x1cbacc);});});}}le['scriptInjectionDeferred']=null;async function br(_0x58ffec,_0xe9a9e2,_0x4c998c,_0x5b63bc=!0x1,_0xa9a462=!0x1){const _0x2e76e5=new le(_0x58ffec);let _0x228768;if(_0xa9a462)_0x228768=Ma;else try{_0x228768=await _0x2e76e5['verify'](_0x4c998c);}catch{_0x228768=await _0x2e76e5['verify'](_0x4c998c,!0x0);}const _0x208ca8={..._0xe9a9e2};if(_0x4c998c==='mfaSmsEnrollment'||_0x4c998c==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x208ca8){const _0xd2a96d=_0x208ca8['phoneEnrollmentInfo']['phoneNumber'],_0x3f088b=_0x208ca8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x208ca8,{'phoneEnrollmentInfo':{'phoneNumber':_0xd2a96d,'recaptchaToken':_0x3f088b,'captchaResponse':_0x228768,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x208ca8){const _0x39dce7=_0x208ca8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x208ca8,{'phoneSignInInfo':{'recaptchaToken':_0x39dce7,'captchaResponse':_0x228768,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x208ca8;}return _0x5b63bc?Object['assign'](_0x208ca8,{'captchaResp':_0x228768}):Object['assign'](_0x208ca8,{'captchaResponse':_0x228768}),Object['assign'](_0x208ca8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x208ca8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x208ca8;}async function Oi(_0x3b8ef0,_0x4a6693,_0x31a624,_0x1f033b,_0x55904f){var _0x5b6ce4;if((_0x5b6ce4=_0x3b8ef0['_getRecaptchaConfig']())!=null&&_0x5b6ce4['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x59c671=await br(_0x3b8ef0,_0x4a6693,_0x31a624,_0x31a624==='getOobCode');return _0x1f033b(_0x3b8ef0,_0x59c671);}else return _0x1f033b(_0x3b8ef0,_0x4a6693)['catch'](async _0x3b133a=>{if(_0x3b133a['code']==='auth/missing-recaptcha-token'){console['log'](_0x31a624+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4c63e3=await br(_0x3b8ef0,_0x4a6693,_0x31a624,_0x31a624==='getOobCode');return _0x1f033b(_0x3b8ef0,_0x4c63e3);}else return Promise['reject'](_0x3b133a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5f3bec,_0x468b7c){const _0x1b5e83=Ui(_0x5f3bec,'auth');if(_0x1b5e83['isInitialized']()){const _0x17c35b=_0x1b5e83['getImmediate'](),_0xe79689=_0x1b5e83['getOptions']();if(De(_0xe79689,_0x468b7c??{}))return _0x17c35b;K(_0x17c35b,'already-initialized');}return _0x1b5e83['initialize']({'options':_0x468b7c});}function Lf(_0x3ea87c,_0x47a17b){const _0x429ff7=(_0x47a17b==null?void 0x0:_0x47a17b['persistence'])||[],_0x140c3a=(Array['isArray'](_0x429ff7)?_0x429ff7:[_0x429ff7])['map'](ne);_0x47a17b!=null&&_0x47a17b['errorMap']&&_0x3ea87c['_updateErrorMap'](_0x47a17b['errorMap']),_0x3ea87c['_initializeWithPersistence'](_0x140c3a,_0x47a17b==null?void 0x0:_0x47a17b['popupRedirectResolver']);}function xf(_0x530b81,_0x1c23ff,_0x5703c3){const _0x5d3097=qe(_0x530b81);m(/^https?:\/\//['test'](_0x1c23ff),_0x5d3097,'invalid-emulator-scheme');const _0x275b77=!0x1,_0x2224ed=La(_0x1c23ff),{host:_0x1b21d9,port:_0x16d7da}=Ff(_0x1c23ff),_0x4b3db1=_0x16d7da===null?'':':'+_0x16d7da,_0x4e4774={'url':_0x2224ed+'//'+_0x1b21d9+_0x4b3db1+'/'},_0x402958=Object['freeze']({'host':_0x1b21d9,'port':_0x16d7da,'protocol':_0x2224ed['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x275b77})});if(!_0x5d3097['_canInitEmulator']){m(_0x5d3097['config']['emulator']&&_0x5d3097['emulatorConfig'],_0x5d3097,'emulator-config-failed'),m(De(_0x4e4774,_0x5d3097['config']['emulator'])&&De(_0x402958,_0x5d3097['emulatorConfig']),_0x5d3097,'emulator-config-failed');return;}_0x5d3097['config']['emulator']=_0x4e4774,_0x5d3097['emulatorConfig']=_0x402958,_0x5d3097['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x1b21d9)?jr(_0x2224ed+'//'+_0x1b21d9+_0x4b3db1):Uf();}function La(_0x3130ff){const _0x18df34=_0x3130ff['indexOf'](':');return _0x18df34<0x0?'':_0x3130ff['substr'](0x0,_0x18df34+0x1);}function Ff(_0x245c99){const _0x33c273=La(_0x245c99),_0x505f6d=/(\/\/)?([^?#/]+)/['exec'](_0x245c99['substr'](_0x33c273['length']));if(!_0x505f6d)return{'host':'','port':null};const _0x4ab9fd=_0x505f6d[0x2]['split']('@')['pop']()||'',_0x359644=/^(\[[^\]]+\])(:|$)/['exec'](_0x4ab9fd);if(_0x359644){const _0x2e7040=_0x359644[0x1];return{'host':_0x2e7040,'port':Rr(_0x4ab9fd['substr'](_0x2e7040['length']+0x1))};}else{const [_0x77dfae,_0x4c5298]=_0x4ab9fd['split'](':');return{'host':_0x77dfae,'port':Rr(_0x4c5298)};}}function Rr(_0x5f1611){if(!_0x5f1611)return null;const _0x513862=Number(_0x5f1611);return isNaN(_0x513862)?null:_0x513862;}function Uf(){function _0x16fe40(){const _0x48c15a=document['createElement']('p'),_0x37341c=_0x48c15a['style'];_0x48c15a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x37341c['position']='fixed',_0x37341c['width']='100%',_0x37341c['backgroundColor']='#ffffff',_0x37341c['border']='.1em\x20solid\x20#000000',_0x37341c['color']='#b50000',_0x37341c['bottom']='0px',_0x37341c['left']='0px',_0x37341c['margin']='0px',_0x37341c['zIndex']='10000',_0x37341c['textAlign']='center',_0x48c15a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x48c15a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x16fe40):_0x16fe40());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1e2197,_0x52d067){this['providerId']=_0x1e2197,this['signInMethod']=_0x52d067;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xa4cfd){return te('not\x20implemented');}['_linkToIdToken'](_0x36a834,_0x326ac8){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xb7def0){return te('not\x20implemented');}}async function Wf(_0x197bcf,_0x3caf1b){return Ae(_0x197bcf,'POST','/v1/accounts:signUp',_0x3caf1b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x21f05b,_0x4921d9){return Yt(_0x21f05b,'POST','/v1/accounts:signInWithPassword',Re(_0x21f05b,_0x4921d9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x26f5c3,_0x5360ab){return Yt(_0x26f5c3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x26f5c3,_0x5360ab));}async function Hf(_0x305e4d,_0x241963){return Yt(_0x305e4d,'POST','/v1/accounts:signInWithEmailLink',Re(_0x305e4d,_0x241963));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x291fc6,_0x4eee9f,_0x2f8e97,_0x344786=null){super('password',_0x2f8e97),this['_email']=_0x291fc6,this['_password']=_0x4eee9f,this['_tenantId']=_0x344786;}static['_fromEmailAndPassword'](_0x4744f8,_0xa486e5){return new Ft(_0x4744f8,_0xa486e5,'password');}static['_fromEmailAndCode'](_0x53af42,_0x28f253,_0x2052f4=null){return new Ft(_0x53af42,_0x28f253,'emailLink',_0x2052f4);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x10185e){const _0x19f0bd=typeof _0x10185e=='string'?JSON['parse'](_0x10185e):_0x10185e;if(_0x19f0bd!=null&&_0x19f0bd['email']&&(_0x19f0bd!=null&&_0x19f0bd['password'])){if(_0x19f0bd['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x19f0bd['email'],_0x19f0bd['password']);if(_0x19f0bd['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x19f0bd['email'],_0x19f0bd['password'],_0x19f0bd['tenantId']);}return null;}async['_getIdTokenResponse'](_0x51b209){switch(this['signInMethod']){case'password':const _0x5150fb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x51b209,_0x5150fb,'signInWithPassword',Bf);case'emailLink':return Vf(_0x51b209,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x51b209,'internal-error');}}async['_linkToIdToken'](_0x543d74,_0x39f747){switch(this['signInMethod']){case'password':const _0x33c4e3={'idToken':_0x39f747,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x543d74,_0x33c4e3,'signUpPassword',Wf);case'emailLink':return Hf(_0x543d74,{'idToken':_0x39f747,'email':this['_email'],'oobCode':this['_password']});default:K(_0x543d74,'internal-error');}}['_getReauthenticationResolver'](_0x31b6a6){return this['_getIdTokenResponse'](_0x31b6a6);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x139dfe,_0x1d067b){return Yt(_0x139dfe,'POST','/v1/accounts:signInWithIdp',Re(_0x139dfe,_0x1d067b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0xb0ecd4){const _0x1b4df1=new We(_0xb0ecd4['providerId'],_0xb0ecd4['signInMethod']);return _0xb0ecd4['idToken']||_0xb0ecd4['accessToken']?(_0xb0ecd4['idToken']&&(_0x1b4df1['idToken']=_0xb0ecd4['idToken']),_0xb0ecd4['accessToken']&&(_0x1b4df1['accessToken']=_0xb0ecd4['accessToken']),_0xb0ecd4['nonce']&&!_0xb0ecd4['pendingToken']&&(_0x1b4df1['nonce']=_0xb0ecd4['nonce']),_0xb0ecd4['pendingToken']&&(_0x1b4df1['pendingToken']=_0xb0ecd4['pendingToken'])):_0xb0ecd4['oauthToken']&&_0xb0ecd4['oauthTokenSecret']?(_0x1b4df1['accessToken']=_0xb0ecd4['oauthToken'],_0x1b4df1['secret']=_0xb0ecd4['oauthTokenSecret']):K('argument-error'),_0x1b4df1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x51808b){const _0x2844f8=typeof _0x51808b=='string'?JSON['parse'](_0x51808b):_0x51808b,{providerId:_0x4d8062,signInMethod:_0x382312,..._0x18c105}=_0x2844f8;if(!_0x4d8062||!_0x382312)return null;const _0x46737d=new We(_0x4d8062,_0x382312);return _0x46737d['idToken']=_0x18c105['idToken']||void 0x0,_0x46737d['accessToken']=_0x18c105['accessToken']||void 0x0,_0x46737d['secret']=_0x18c105['secret'],_0x46737d['nonce']=_0x18c105['nonce'],_0x46737d['pendingToken']=_0x18c105['pendingToken']||null,_0x46737d;}['_getIdTokenResponse'](_0x2caf55){const _0x4bfa4b=this['buildRequest']();return Ze(_0x2caf55,_0x4bfa4b);}['_linkToIdToken'](_0x365fcb,_0x5d74bb){const _0x39d2f6=this['buildRequest']();return _0x39d2f6['idToken']=_0x5d74bb,Ze(_0x365fcb,_0x39d2f6);}['_getReauthenticationResolver'](_0x1dba37){const _0x1b1344=this['buildRequest']();return _0x1b1344['autoCreate']=!0x1,Ze(_0x1dba37,_0x1b1344);}['buildRequest'](){const _0x289413={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x289413['pendingToken']=this['pendingToken'];else{const _0x67d998={};this['idToken']&&(_0x67d998['id_token']=this['idToken']),this['accessToken']&&(_0x67d998['access_token']=this['accessToken']),this['secret']&&(_0x67d998['oauth_token_secret']=this['secret']),_0x67d998['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x67d998['nonce']=this['nonce']),_0x289413['postBody']=at(_0x67d998);}return _0x289413;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1851e6){switch(_0x1851e6){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x429020){const _0x5b949b=yt(vt(_0x429020))['link'],_0x497333=_0x5b949b?yt(vt(_0x5b949b))['deep_link_id']:null,_0x2ef199=yt(vt(_0x429020))['deep_link_id'];return(_0x2ef199?yt(vt(_0x2ef199))['link']:null)||_0x2ef199||_0x497333||_0x5b949b||_0x429020;}class Ss{constructor(_0x3c5095){const _0x5ccd31=yt(vt(_0x3c5095)),_0x578aac=_0x5ccd31['apiKey']??null,_0x3b6aa3=_0x5ccd31['oobCode']??null,_0xb817e6=Gf(_0x5ccd31['mode']??null);m(_0x578aac&&_0x3b6aa3&&_0xb817e6,'argument-error'),this['apiKey']=_0x578aac,this['operation']=_0xb817e6,this['code']=_0x3b6aa3,this['continueUrl']=_0x5ccd31['continueUrl']??null,this['languageCode']=_0x5ccd31['lang']??null,this['tenantId']=_0x5ccd31['tenantId']??null;}static['parseLink'](_0x42b3fd){const _0x277969=qf(_0x42b3fd);try{return new Ss(_0x277969);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4c2436,_0x336784){return Ft['_fromEmailAndPassword'](_0x4c2436,_0x336784);}static['credentialWithLink'](_0x5835b2,_0x136019){const _0x4dc4d6=Ss['parseLink'](_0x136019);return m(_0x4dc4d6,'argument-error'),Ft['_fromEmailAndCode'](_0x5835b2,_0x4dc4d6['code'],_0x4dc4d6['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0xbde2df){this['providerId']=_0xbde2df,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1777f4){this['defaultLanguageCode']=_0x1777f4;}['setCustomParameters'](_0xa3fec4){return this['customParameters']=_0xa3fec4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x14888a){return this['scopes']['includes'](_0x14888a)||this['scopes']['push'](_0x14888a),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x31f5db){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x31f5db});}static['credentialFromResult'](_0x109579){return he['credentialFromTaggedObject'](_0x109579);}static['credentialFromError'](_0x158c1d){return he['credentialFromTaggedObject'](_0x158c1d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4d452e}){if(!_0x4d452e||!('oauthAccessToken'in _0x4d452e)||!_0x4d452e['oauthAccessToken'])return null;try{return he['credential'](_0x4d452e['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3f9167,_0x3a2cc5){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3f9167,'accessToken':_0x3a2cc5});}static['credentialFromResult'](_0x3c97da){return ue['credentialFromTaggedObject'](_0x3c97da);}static['credentialFromError'](_0x41b0e3){return ue['credentialFromTaggedObject'](_0x41b0e3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2a62c8}){if(!_0x2a62c8)return null;const {oauthIdToken:_0x2d6b1d,oauthAccessToken:_0x11f4a3}=_0x2a62c8;if(!_0x2d6b1d&&!_0x11f4a3)return null;try{return ue['credential'](_0x2d6b1d,_0x11f4a3);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x34eb01){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x34eb01});}static['credentialFromResult'](_0x8e9f04){return de['credentialFromTaggedObject'](_0x8e9f04);}static['credentialFromError'](_0xe2c087){return de['credentialFromTaggedObject'](_0xe2c087['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59b837}){if(!_0x59b837||!('oauthAccessToken'in _0x59b837)||!_0x59b837['oauthAccessToken'])return null;try{return de['credential'](_0x59b837['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x20d15f,_0x231afc){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x20d15f,'oauthTokenSecret':_0x231afc});}static['credentialFromResult'](_0x5075fc){return fe['credentialFromTaggedObject'](_0x5075fc);}static['credentialFromError'](_0x3b6620){return fe['credentialFromTaggedObject'](_0x3b6620['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x58f2b0}){if(!_0x58f2b0)return null;const {oauthAccessToken:_0xda3baa,oauthTokenSecret:_0x34bb5a}=_0x58f2b0;if(!_0xda3baa||!_0x34bb5a)return null;try{return fe['credential'](_0xda3baa,_0x34bb5a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x40e0d4,_0x405988){return Yt(_0x40e0d4,'POST','/v1/accounts:signUp',Re(_0x40e0d4,_0x405988));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x2f8eaf){this['user']=_0x2f8eaf['user'],this['providerId']=_0x2f8eaf['providerId'],this['_tokenResponse']=_0x2f8eaf['_tokenResponse'],this['operationType']=_0x2f8eaf['operationType'];}static async['_fromIdTokenResponse'](_0x390456,_0x12b315,_0x117fb9,_0x2ea58e=!0x1){const _0x28a27f=await z['_fromIdTokenResponse'](_0x390456,_0x117fb9,_0x2ea58e),_0x1cf81a=Ar(_0x117fb9);return new Be({'user':_0x28a27f,'providerId':_0x1cf81a,'_tokenResponse':_0x117fb9,'operationType':_0x12b315});}static async['_forOperation'](_0x228360,_0x4fc48d,_0x590a91){await _0x228360['_updateTokensIfNecessary'](_0x590a91,!0x0);const _0x1bd3c9=Ar(_0x590a91);return new Be({'user':_0x228360,'providerId':_0x1bd3c9,'_tokenResponse':_0x590a91,'operationType':_0x4fc48d});}}function Ar(_0x1a36e5){return _0x1a36e5['providerId']?_0x1a36e5['providerId']:'phoneNumber'in _0x1a36e5?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5e0b81,_0xdf30e3,_0x2bb015,_0x47db03){super(_0xdf30e3['code'],_0xdf30e3['message']),this['operationType']=_0x2bb015,this['user']=_0x47db03,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5e0b81['name'],'tenantId':_0x5e0b81['tenantId']??void 0x0,'_serverResponse':_0xdf30e3['customData']['_serverResponse'],'operationType':_0x2bb015};}static['_fromErrorAndOperation'](_0x4e961e,_0x40461a,_0x593006,_0x585568){return new Rn(_0x4e961e,_0x40461a,_0x593006,_0x585568);}}function Fa(_0x338619,_0x141409,_0x53e157,_0xb393b2){return(_0x141409==='reauthenticate'?_0x53e157['_getReauthenticationResolver'](_0x338619):_0x53e157['_getIdTokenResponse'](_0x338619))['catch'](_0x3e90fd=>{throw _0x3e90fd['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x338619,_0x3e90fd,_0x141409,_0xb393b2):_0x3e90fd;});}async function jf(_0x51912e,_0x390490,_0x32505a=!0x1){const _0x2166d2=await xt(_0x51912e,_0x390490['_linkToIdToken'](_0x51912e['auth'],await _0x51912e['getIdToken']()),_0x32505a);return Be['_forOperation'](_0x51912e,'link',_0x2166d2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x25ed03,_0xa75252,_0x14caa6=!0x1){const {auth:_0x249196}=_0x25ed03;if(H(_0x249196['app']))return Promise['reject'](se(_0x249196));const _0x3b2598='reauthenticate';try{const _0x3e52e6=await xt(_0x25ed03,Fa(_0x249196,_0x3b2598,_0xa75252,_0x25ed03),_0x14caa6);m(_0x3e52e6['idToken'],_0x249196,'internal-error');const _0x5d9314=ws(_0x3e52e6['idToken']);m(_0x5d9314,_0x249196,'internal-error');const {sub:_0x19ce97}=_0x5d9314;return m(_0x25ed03['uid']===_0x19ce97,_0x249196,'user-mismatch'),Be['_forOperation'](_0x25ed03,_0x3b2598,_0x3e52e6);}catch(_0x460a59){throw(_0x460a59==null?void 0x0:_0x460a59['code'])==='auth/user-not-found'&&K(_0x249196,'user-mismatch'),_0x460a59;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x368c75,_0x222d1b,_0x1d6ce3=!0x1){if(H(_0x368c75['app']))return Promise['reject'](se(_0x368c75));const _0x90a81d='signIn',_0x48e246=await Fa(_0x368c75,_0x90a81d,_0x222d1b),_0x4e8e01=await Be['_fromIdTokenResponse'](_0x368c75,_0x90a81d,_0x48e246);return _0x1d6ce3||await _0x368c75['_updateCurrentUser'](_0x4e8e01['user']),_0x4e8e01;}async function Yf(_0x506744,_0x3a61e0){return Ua(qe(_0x506744),_0x3a61e0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x583b75){const _0x5158d2=qe(_0x583b75);_0x5158d2['_getPasswordPolicyInternal']()&&await _0x5158d2['_updatePasswordPolicy']();}async function R_(_0x526998,_0x4f5381,_0x7f7eac){if(H(_0x526998['app']))return Promise['reject'](se(_0x526998));const _0x362aec=qe(_0x526998),_0x384738=await Oi(_0x362aec,{'returnSecureToken':!0x0,'email':_0x4f5381,'password':_0x7f7eac,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x577325=>{throw _0x577325['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x526998),_0x577325;}),_0x57ac8e=await Be['_fromIdTokenResponse'](_0x362aec,'signIn',_0x384738);return await _0x362aec['_updateCurrentUser'](_0x57ac8e['user']),_0x57ac8e;}function A_(_0x708c62,_0xd3d942,_0x592969){return H(_0x708c62['app'])?Promise['reject'](se(_0x708c62)):Yf(k(_0x708c62),ft['credential'](_0xd3d942,_0x592969))['catch'](async _0x126597=>{throw _0x126597['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x708c62),_0x126597;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x266f91,_0x48321e){return k(_0x266f91)['setPersistence'](_0x48321e);}function Qf(_0x1c136e,_0x226a23,_0x4d2bf4,_0x3c8e40){return k(_0x1c136e)['onIdTokenChanged'](_0x226a23,_0x4d2bf4,_0x3c8e40);}function Jf(_0x24ea09,_0x5df73c,_0x41bc60){return k(_0x24ea09)['beforeAuthStateChanged'](_0x5df73c,_0x41bc60);}function N_(_0x1bfe6c,_0x5d2078,_0x489974,_0x4c2e1b){return k(_0x1bfe6c)['onAuthStateChanged'](_0x5d2078,_0x489974,_0x4c2e1b);}function P_(_0xc0bcb){return k(_0xc0bcb)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xa21766,_0x105b48){this['storageRetriever']=_0xa21766,this['type']=_0x105b48;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x40c7b6,_0x5eeb12){return this['storage']['setItem'](_0x40c7b6,JSON['stringify'](_0x5eeb12)),Promise['resolve']();}['_get'](_0x45f3e0){const _0x2f65cf=this['storage']['getItem'](_0x45f3e0);return Promise['resolve'](_0x2f65cf?JSON['parse'](_0x2f65cf):null);}['_remove'](_0x2674ee){return this['storage']['removeItem'](_0x2674ee),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4ba8de,_0x1012bd)=>this['onStorageEvent'](_0x4ba8de,_0x1012bd),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x25bd44){for(const _0x26d913 of Object['keys'](this['listeners'])){const _0x243f60=this['storage']['getItem'](_0x26d913),_0xfef1aa=this['localCache'][_0x26d913];_0x243f60!==_0xfef1aa&&_0x25bd44(_0x26d913,_0xfef1aa,_0x243f60);}}['onStorageEvent'](_0x56fd9f,_0x1c7cdf=!0x1){if(!_0x56fd9f['key']){this['forAllChangedKeys']((_0x1016b9,_0x25c3b1,_0x12874f)=>{this['notifyListeners'](_0x1016b9,_0x12874f);});return;}const _0x57b40d=_0x56fd9f['key'];_0x1c7cdf?this['detachListener']():this['stopPolling']();const _0x3917a8=()=>{const _0x454215=this['storage']['getItem'](_0x57b40d);!_0x1c7cdf&&this['localCache'][_0x57b40d]===_0x454215||this['notifyListeners'](_0x57b40d,_0x454215);},_0x3b7267=this['storage']['getItem'](_0x57b40d);If()&&_0x3b7267!==_0x56fd9f['newValue']&&_0x56fd9f['newValue']!==_0x56fd9f['oldValue']?setTimeout(_0x3917a8,Zf):_0x3917a8();}['notifyListeners'](_0x1cc323,_0x21ef98){this['localCache'][_0x1cc323]=_0x21ef98;const _0x2959d4=this['listeners'][_0x1cc323];if(_0x2959d4){for(const _0x15c2bf of Array['from'](_0x2959d4))_0x15c2bf(_0x21ef98&&JSON['parse'](_0x21ef98));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2a3bc6,_0x4fe251,_0x45932f)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2a3bc6,'oldValue':_0x4fe251,'newValue':_0x45932f}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x168c17,_0x259a9a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x168c17]||(this['listeners'][_0x168c17]=new Set(),this['localCache'][_0x168c17]=this['storage']['getItem'](_0x168c17)),this['listeners'][_0x168c17]['add'](_0x259a9a);}['_removeListener'](_0x36f4cd,_0x3c38f6){this['listeners'][_0x36f4cd]&&(this['listeners'][_0x36f4cd]['delete'](_0x3c38f6),this['listeners'][_0x36f4cd]['size']===0x0&&delete this['listeners'][_0x36f4cd]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5acf3b,_0x35bb4c){await super['_set'](_0x5acf3b,_0x35bb4c),this['localCache'][_0x5acf3b]=JSON['stringify'](_0x35bb4c);}async['_get'](_0x5ccf93){const _0x3817a7=await super['_get'](_0x5ccf93);return this['localCache'][_0x5ccf93]=JSON['stringify'](_0x3817a7),_0x3817a7;}async['_remove'](_0x8cd3be){await super['_remove'](_0x8cd3be),delete this['localCache'][_0x8cd3be];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x53ae8d,_0x1c99be){}['_removeListener'](_0x5614ac,_0x31b455){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xa1b667){return Promise['all'](_0xa1b667['map'](async _0x686f71=>{try{return{'fulfilled':!0x0,'value':await _0x686f71};}catch(_0x4b736e){return{'fulfilled':!0x1,'reason':_0x4b736e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x74d168){this['eventTarget']=_0x74d168,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x38d32c){const _0x57e3a4=this['receivers']['find'](_0x330da0=>_0x330da0['isListeningto'](_0x38d32c));if(_0x57e3a4)return _0x57e3a4;const _0x2fe9f9=new jn(_0x38d32c);return this['receivers']['push'](_0x2fe9f9),_0x2fe9f9;}['isListeningto'](_0x53139f){return this['eventTarget']===_0x53139f;}async['handleEvent'](_0x11cc51){const _0xb445c0=_0x11cc51,{eventId:_0x3bf070,eventType:_0x1105bd,data:_0x44a4b2}=_0xb445c0['data'],_0x2af82e=this['handlersMap'][_0x1105bd];if(!(_0x2af82e!=null&&_0x2af82e['size']))return;_0xb445c0['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3bf070,'eventType':_0x1105bd});const _0x3d3e1f=Array['from'](_0x2af82e)['map'](async _0x36035c=>_0x36035c(_0xb445c0['origin'],_0x44a4b2)),_0x54236a=await tp(_0x3d3e1f);_0xb445c0['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3bf070,'eventType':_0x1105bd,'response':_0x54236a});}['_subscribe'](_0x4f706d,_0x1e81a6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4f706d]||(this['handlersMap'][_0x4f706d]=new Set()),this['handlersMap'][_0x4f706d]['add'](_0x1e81a6);}['_unsubscribe'](_0x127b4a,_0x34d788){this['handlersMap'][_0x127b4a]&&_0x34d788&&this['handlersMap'][_0x127b4a]['delete'](_0x34d788),(!_0x34d788||this['handlersMap'][_0x127b4a]['size']===0x0)&&delete this['handlersMap'][_0x127b4a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x1b193d='',_0x1a3f40=0xa){let _0x477633='';for(let _0x323c29=0x0;_0x323c29<_0x1a3f40;_0x323c29++)_0x477633+=Math['floor'](Math['random']()*0xa);return _0x1b193d+_0x477633;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x1054d4){this['target']=_0x1054d4,this['handlers']=new Set();}['removeMessageHandler'](_0x13bff2){_0x13bff2['messageChannel']&&(_0x13bff2['messageChannel']['port1']['removeEventListener']('message',_0x13bff2['onMessage']),_0x13bff2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x13bff2);}async['_send'](_0x5ee63c,_0x173e2f,_0x120fce=0x32){const _0x4da207=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4da207)throw new Error('connection_unavailable');let _0x35aa,_0x420c66;return new Promise((_0x471f6f,_0x5e4651)=>{const _0x4c5788=bs('',0x14);_0x4da207['port1']['start']();const _0x1d68db=setTimeout(()=>{_0x5e4651(new Error('unsupported_event'));},_0x120fce);_0x420c66={'messageChannel':_0x4da207,'onMessage'(_0x132027){const _0x223240=_0x132027;if(_0x223240['data']['eventId']===_0x4c5788)switch(_0x223240['data']['status']){case'ack':clearTimeout(_0x1d68db),_0x35aa=setTimeout(()=>{_0x5e4651(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x35aa),_0x471f6f(_0x223240['data']['response']);break;default:clearTimeout(_0x1d68db),clearTimeout(_0x35aa),_0x5e4651(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x420c66),_0x4da207['port1']['addEventListener']('message',_0x420c66['onMessage']),this['target']['postMessage']({'eventType':_0x5ee63c,'eventId':_0x4c5788,'data':_0x173e2f},[_0x4da207['port2']]);})['finally'](()=>{_0x420c66&&this['removeMessageHandler'](_0x420c66);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x1a9468){X()['location']['href']=_0x1a9468;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x17d89c;return((_0x17d89c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x17d89c['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3fe4df){this['request']=_0x3fe4df;}['toPromise'](){return new Promise((_0x3ebf3c,_0x500433)=>{this['request']['addEventListener']('success',()=>{_0x3ebf3c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x500433(this['request']['error']);});});}}function Kn(_0x4d2f8e,_0x30f0ee){return _0x4d2f8e['transaction']([kn],_0x30f0ee?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x393b33=indexedDB['deleteDatabase'](qa);return new Jt(_0x393b33)['toPromise']();}function ja(){const _0x4d1fa9=indexedDB['open'](qa,ap);return new Promise((_0x58679e,_0x52cafa)=>{_0x4d1fa9['addEventListener']('error',()=>{_0x52cafa(_0x4d1fa9['error']);}),_0x4d1fa9['addEventListener']('upgradeneeded',()=>{const _0x54a935=_0x4d1fa9['result'];try{_0x54a935['createObjectStore'](kn,{'keyPath':za});}catch(_0x18ffcc){_0x52cafa(_0x18ffcc);}}),_0x4d1fa9['addEventListener']('success',async()=>{const _0x6ec277=_0x4d1fa9['result'];_0x6ec277['objectStoreNames']['contains'](kn)?_0x58679e(_0x6ec277):(_0x6ec277['close'](),await cp(),_0x58679e(await ja()));});});}async function kr(_0x517a41,_0x49fc61,_0x3c652f){const _0x5b22c8=Kn(_0x517a41,!0x0)['put']({[za]:_0x49fc61,'value':_0x3c652f});return new Jt(_0x5b22c8)['toPromise']();}async function lp(_0x4e94bf,_0x1abe72){const _0x469fea=Kn(_0x4e94bf,!0x1)['get'](_0x1abe72),_0x3fe7a6=await new Jt(_0x469fea)['toPromise']();return _0x3fe7a6===void 0x0?null:_0x3fe7a6['value'];}function Nr(_0x2a133d,_0x49596a){const _0x349a20=Kn(_0x2a133d,!0x0)['delete'](_0x49596a);return new Jt(_0x349a20)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0xf3776f){let _0x38caae=0x0;for(;;)try{const _0xed98eb=await this['_openDb']();return await _0xf3776f(_0xed98eb);}catch(_0x8c4e55){if(_0x38caae++>up)throw _0x8c4e55;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x8f3d9c,_0x3cb7c0)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3cb7c0['key'])})),this['receiver']['_subscribe']('ping',async(_0x14f15e,_0x9bf478)=>['keyChanged']);}async['initializeSender'](){var _0x56d3dd,_0x563e2d;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x42422e=await this['sender']['_send']('ping',{},0x320);_0x42422e&&(_0x56d3dd=_0x42422e[0x0])!=null&&_0x56d3dd['fulfilled']&&(_0x563e2d=_0x42422e[0x0])!=null&&_0x563e2d['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1cdc31){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1cdc31},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2d76b6=>{await kr(_0x2d76b6,An,'1'),await Nr(_0x2d76b6,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4a4ed2){this['pendingWrites']++;try{await _0x4a4ed2();}finally{this['pendingWrites']--;}}async['_set'](_0x42ede0,_0x4c9dde){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3df992=>kr(_0x3df992,_0x42ede0,_0x4c9dde)),this['localCache'][_0x42ede0]=_0x4c9dde,this['notifyServiceWorker'](_0x42ede0)));}async['_get'](_0x399817){const _0x36c30b=await this['_withRetries'](_0x154fd5=>lp(_0x154fd5,_0x399817));return this['localCache'][_0x399817]=_0x36c30b,_0x36c30b;}async['_remove'](_0x52c1be){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x76b519=>Nr(_0x76b519,_0x52c1be)),delete this['localCache'][_0x52c1be],this['notifyServiceWorker'](_0x52c1be)));}async['_poll'](){const _0x3d09bf=await this['_withRetries'](_0x2bbb47=>{const _0x1c639b=Kn(_0x2bbb47,!0x1)['getAll']();return new Jt(_0x1c639b)['toPromise']();});if(!_0x3d09bf)return[];if(this['pendingWrites']!==0x0)return[];const _0xfe8277=[],_0x56fefe=new Set();if(_0x3d09bf['length']!==0x0){for(const {fbase_key:_0x168df3,value:_0x8cf93f}of _0x3d09bf)_0x56fefe['add'](_0x168df3),JSON['stringify'](this['localCache'][_0x168df3])!==JSON['stringify'](_0x8cf93f)&&(this['notifyListeners'](_0x168df3,_0x8cf93f),_0xfe8277['push'](_0x168df3));}for(const _0x31f90b of Object['keys'](this['localCache']))this['localCache'][_0x31f90b]&&!_0x56fefe['has'](_0x31f90b)&&(this['notifyListeners'](_0x31f90b,null),_0xfe8277['push'](_0x31f90b));return _0xfe8277;}['notifyListeners'](_0x47d1b6,_0x33db3e){this['localCache'][_0x47d1b6]=_0x33db3e;const _0x50a55f=this['listeners'][_0x47d1b6];if(_0x50a55f){for(const _0x3c0bd1 of Array['from'](_0x50a55f))_0x3c0bd1(_0x33db3e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x124e52,_0x136d57){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x124e52]||(this['listeners'][_0x124e52]=new Set(),this['_get'](_0x124e52)),this['listeners'][_0x124e52]['add'](_0x136d57);}['_removeListener'](_0x174787,_0x5d7315){this['listeners'][_0x174787]&&(this['listeners'][_0x174787]['delete'](_0x5d7315),this['listeners'][_0x174787]['size']===0x0&&delete this['listeners'][_0x174787]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x1824c8,_0x130576){return _0x130576?ne(_0x130576):(m(_0x1824c8['_popupRedirectResolver'],_0x1824c8,'argument-error'),_0x1824c8['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4c8444){super('custom','custom'),this['params']=_0x4c8444;}['_getIdTokenResponse'](_0x4dd364){return Ze(_0x4dd364,this['_buildIdpRequest']());}['_linkToIdToken'](_0x45e605,_0x371c85){return Ze(_0x45e605,this['_buildIdpRequest'](_0x371c85));}['_getReauthenticationResolver'](_0xe772ab){return Ze(_0xe772ab,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2bf714){const _0x3294d8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2bf714&&(_0x3294d8['idToken']=_0x2bf714),_0x3294d8;}}function pp(_0x7f248){return Ua(_0x7f248['auth'],new Rs(_0x7f248),_0x7f248['bypassAuthState']);}function _p(_0x3eb72a){const {auth:_0x2f628a,user:_0x424b02}=_0x3eb72a;return m(_0x424b02,_0x2f628a,'internal-error'),Kf(_0x424b02,new Rs(_0x3eb72a),_0x3eb72a['bypassAuthState']);}async function gp(_0x1904ff){const {auth:_0x45e785,user:_0x4eacba}=_0x1904ff;return m(_0x4eacba,_0x45e785,'internal-error'),jf(_0x4eacba,new Rs(_0x1904ff),_0x1904ff['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x379735,_0x240c60,_0x26a360,_0x3a9d5d,_0x3efe7d=!0x1){this['auth']=_0x379735,this['resolver']=_0x26a360,this['user']=_0x3a9d5d,this['bypassAuthState']=_0x3efe7d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x240c60)?_0x240c60:[_0x240c60];}['execute'](){return new Promise(async(_0x97054a,_0x1b416e)=>{this['pendingPromise']={'resolve':_0x97054a,'reject':_0x1b416e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x9d3952){this['reject'](_0x9d3952);}});}async['onAuthEvent'](_0x2a5b91){const {urlResponse:_0x424b30,sessionId:_0x2f0ee7,postBody:_0xc26760,tenantId:_0xf5b609,error:_0x515e2a,type:_0x300d53}=_0x2a5b91;if(_0x515e2a){this['reject'](_0x515e2a);return;}const _0x56afef={'auth':this['auth'],'requestUri':_0x424b30,'sessionId':_0x2f0ee7,'tenantId':_0xf5b609||void 0x0,'postBody':_0xc26760||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x300d53)(_0x56afef));}catch(_0x51fbdb){this['reject'](_0x51fbdb);}}['onError'](_0x2882c7){this['reject'](_0x2882c7);}['getIdpTask'](_0xc95dc2){switch(_0xc95dc2){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x1ba29b){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1ba29b),this['unregisterAndCleanUp']();}['reject'](_0x3cf04c){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3cf04c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x15b1b5,_0x514f74,_0x49e2fa,_0x14e1d2,_0x4d1519){super(_0x15b1b5,_0x514f74,_0x14e1d2,_0x4d1519),this['provider']=_0x49e2fa,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x1ab68e=await this['execute']();return m(_0x1ab68e,this['auth'],'internal-error'),_0x1ab68e;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2b7db8=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2b7db8),this['authWindow']['associatedEvent']=_0x2b7db8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2f1c50=>{this['reject'](_0x2f1c50);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3e09d9=>{_0x3e09d9||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2ef35c;return((_0x2ef35c=this['authWindow'])==null?void 0x0:_0x2ef35c['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5b6707=()=>{var _0x4a951a,_0x441118;if((_0x441118=(_0x4a951a=this['authWindow'])==null?void 0x0:_0x4a951a['window'])!=null&&_0x441118['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5b6707,mp['get']());};_0x5b6707();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x577da6,_0x97906f,_0x565cdd=!0x1){super(_0x577da6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x97906f,void 0x0,_0x565cdd),this['eventId']=null;}async['execute'](){let _0xf90915=rn['get'](this['auth']['_key']());if(!_0xf90915){try{const _0x19ec82=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0xf90915=()=>Promise['resolve'](_0x19ec82);}catch(_0x2931e8){_0xf90915=()=>Promise['reject'](_0x2931e8);}rn['set'](this['auth']['_key'](),_0xf90915);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xf90915();}async['onAuthEvent'](_0x24a2c5){if(_0x24a2c5['type']==='signInViaRedirect')return super['onAuthEvent'](_0x24a2c5);if(_0x24a2c5['type']==='unknown'){this['resolve'](null);return;}if(_0x24a2c5['eventId']){const _0x3c2a14=await this['auth']['_redirectUserForId'](_0x24a2c5['eventId']);if(_0x3c2a14)return this['user']=_0x3c2a14,super['onAuthEvent'](_0x24a2c5);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x1d5ff4,_0x37f7ab){const _0x353402=Cp(_0x37f7ab),_0x2d4b42=wp(_0x1d5ff4);if(!await _0x2d4b42['_isAvailable']())return!0x1;const _0x4f6388=await _0x2d4b42['_get'](_0x353402)==='true';return await _0x2d4b42['_remove'](_0x353402),_0x4f6388;}function Ip(_0x5b725e,_0x270648){rn['set'](_0x5b725e['_key'](),_0x270648);}function wp(_0x19fe92){return ne(_0x19fe92['_redirectPersistence']);}function Cp(_0x4f6975){return sn(yp,_0x4f6975['config']['apiKey'],_0x4f6975['name']);}async function Tp(_0x292fb2,_0x378f22,_0x5ec9b0=!0x1){if(H(_0x292fb2['app']))return Promise['reject'](se(_0x292fb2));const _0x72e3a6=qe(_0x292fb2),_0xe36aab=fp(_0x72e3a6,_0x378f22),_0x4addd5=await new vp(_0x72e3a6,_0xe36aab,_0x5ec9b0)['execute']();return _0x4addd5&&!_0x5ec9b0&&(delete _0x4addd5['user']['_redirectEventId'],await _0x72e3a6['_persistUserIfCurrent'](_0x4addd5['user']),await _0x72e3a6['_setRedirectUser'](null,_0x378f22)),_0x4addd5;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x343a94){this['auth']=_0x343a94,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x163416){this['consumers']['add'](_0x163416),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x163416)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x163416),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xa09962){this['consumers']['delete'](_0xa09962);}['onEvent'](_0x4388fa){if(this['hasEventBeenHandled'](_0x4388fa))return!0x1;let _0x3e5188=!0x1;return this['consumers']['forEach'](_0x4b2c80=>{this['isEventForConsumer'](_0x4388fa,_0x4b2c80)&&(_0x3e5188=!0x0,this['sendToConsumer'](_0x4388fa,_0x4b2c80),this['saveEventToCache'](_0x4388fa));}),this['hasHandledPotentialRedirect']||!Rp(_0x4388fa)||(this['hasHandledPotentialRedirect']=!0x0,_0x3e5188||(this['queuedRedirectEvent']=_0x4388fa,_0x3e5188=!0x0)),_0x3e5188;}['sendToConsumer'](_0x120bd4,_0xda9151){var _0x24bd20;if(_0x120bd4['error']&&!Qa(_0x120bd4)){const _0x5420f9=((_0x24bd20=_0x120bd4['error']['code'])==null?void 0x0:_0x24bd20['split']('auth/')[0x1])||'internal-error';_0xda9151['onError'](J(this['auth'],_0x5420f9));}else _0xda9151['onAuthEvent'](_0x120bd4);}['isEventForConsumer'](_0x612c21,_0x2aa860){const _0x1afa54=_0x2aa860['eventId']===null||!!_0x612c21['eventId']&&_0x612c21['eventId']===_0x2aa860['eventId'];return _0x2aa860['filter']['includes'](_0x612c21['type'])&&_0x1afa54;}['hasEventBeenHandled'](_0x41a589){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x41a589));}['saveEventToCache'](_0x3c9adf){this['cachedEventUids']['add'](Pr(_0x3c9adf)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x460e86){return[_0x460e86['type'],_0x460e86['eventId'],_0x460e86['sessionId'],_0x460e86['tenantId']]['filter'](_0x539f1b=>_0x539f1b)['join']('-');}function Qa({type:_0x26df2b,error:_0x240dbd}){return _0x26df2b==='unknown'&&(_0x240dbd==null?void 0x0:_0x240dbd['code'])==='auth/no-auth-event';}function Rp(_0x18fdd7){switch(_0x18fdd7['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x18fdd7);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x12d1aa,_0x304e06={}){return Ae(_0x12d1aa,'GET','/v1/projects',_0x304e06);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x1c837a){if(_0x1c837a['config']['emulator'])return;const {authorizedDomains:_0x2ed7bb}=await Ap(_0x1c837a);for(const _0x1c0f53 of _0x2ed7bb)try{if(Op(_0x1c0f53))return;}catch{}K(_0x1c837a,'unauthorized-domain');}function Op(_0x44a971){const _0x4d90ee=Ni(),{protocol:_0x37e190,hostname:_0x2a7442}=new URL(_0x4d90ee);if(_0x44a971['startsWith']('chrome-extension://')){const _0x4f2fba=new URL(_0x44a971);return _0x4f2fba['hostname']===''&&_0x2a7442===''?_0x37e190==='chrome-extension:'&&_0x44a971['replace']('chrome-extension://','')===_0x4d90ee['replace']('chrome-extension://',''):_0x37e190==='chrome-extension:'&&_0x4f2fba['hostname']===_0x2a7442;}if(!Np['test'](_0x37e190))return!0x1;if(kp['test'](_0x44a971))return _0x2a7442===_0x44a971;const _0x19036b=_0x44a971['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x19036b+'|'+_0x19036b+')$','i')['test'](_0x2a7442);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x2c3918=X()['___jsl'];if(_0x2c3918!=null&&_0x2c3918['H']){for(const _0xd85f77 of Object['keys'](_0x2c3918['H']))if(_0x2c3918['H'][_0xd85f77]['r']=_0x2c3918['H'][_0xd85f77]['r']||[],_0x2c3918['H'][_0xd85f77]['L']=_0x2c3918['H'][_0xd85f77]['L']||[],_0x2c3918['H'][_0xd85f77]['r']=[..._0x2c3918['H'][_0xd85f77]['L']],_0x2c3918['CP']){for(let _0x483006=0x0;_0x483006<_0x2c3918['CP']['length'];_0x483006++)_0x2c3918['CP'][_0x483006]=null;}}}function Mp(_0x5b047a){return new Promise((_0x175d0,_0x18d5af)=>{var _0x1a2394,_0x19a7f0,_0x420954;function _0x359db5(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x175d0(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x18d5af(J(_0x5b047a,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x19a7f0=(_0x1a2394=X()['gapi'])==null?void 0x0:_0x1a2394['iframes'])!=null&&_0x19a7f0['Iframe'])_0x175d0(gapi['iframes']['getContext']());else{if((_0x420954=X()['gapi'])!=null&&_0x420954['load'])_0x359db5();else{const _0x20aa1c=Nf('iframefcb');return X()[_0x20aa1c]=()=>{gapi['load']?_0x359db5():_0x18d5af(J(_0x5b047a,'network-request-failed'));},Da(kf()+'?onload='+_0x20aa1c)['catch'](_0x5be1b0=>_0x18d5af(_0x5be1b0));}}})['catch'](_0x5b53c0=>{throw on=null,_0x5b53c0;});}let on=null;function Lp(_0x3fba8d){return on=on||Mp(_0x3fba8d),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3dbd46){const _0x1fdafd=_0x3dbd46['config'];m(_0x1fdafd['authDomain'],_0x3dbd46,'auth-domain-config-required');const _0x45d05a=_0x1fdafd['emulator']?Is(_0x1fdafd,Up):'https://'+_0x3dbd46['config']['authDomain']+'/'+Fp,_0x21b5c6={'apiKey':_0x1fdafd['apiKey'],'appName':_0x3dbd46['name'],'v':ct},_0x30e826=Bp['get'](_0x3dbd46['config']['apiHost']);_0x30e826&&(_0x21b5c6['eid']=_0x30e826);const _0x1558c2=_0x3dbd46['_getFrameworks']();return _0x1558c2['length']&&(_0x21b5c6['fw']=_0x1558c2['join'](',')),_0x45d05a+'?'+at(_0x21b5c6)['slice'](0x1);}async function Hp(_0x69474b){const _0x476a52=await Lp(_0x69474b),_0x6f1621=X()['gapi'];return m(_0x6f1621,_0x69474b,'internal-error'),_0x476a52['open']({'where':document['body'],'url':Vp(_0x69474b),'messageHandlersFilter':_0x6f1621['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x1e2e69=>new Promise(async(_0x9e7f4f,_0x4fd27d)=>{await _0x1e2e69['restyle']({'setHideOnLeave':!0x1});const _0x526177=J(_0x69474b,'network-request-failed'),_0x36cecf=X()['setTimeout'](()=>{_0x4fd27d(_0x526177);},xp['get']());function _0x44fbc2(){X()['clearTimeout'](_0x36cecf),_0x9e7f4f(_0x1e2e69);}_0x1e2e69['ping'](_0x44fbc2)['then'](_0x44fbc2,()=>{_0x4fd27d(_0x526177);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xd8b21a){this['window']=_0xd8b21a,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x1a4cc7,_0x2189ce,_0x101867,_0x145e23=Gp,_0x4cad45=qp){const _0x1cbbd9=Math['max']((window['screen']['availHeight']-_0x4cad45)/0x2,0x0)['toString'](),_0x3395de=Math['max']((window['screen']['availWidth']-_0x145e23)/0x2,0x0)['toString']();let _0x39fd5e='';const _0x3ce2ff={...$p,'width':_0x145e23['toString'](),'height':_0x4cad45['toString'](),'top':_0x1cbbd9,'left':_0x3395de},_0x15a846=W()['toLowerCase']();_0x101867&&(_0x39fd5e=ba(_0x15a846)?zp:_0x101867),Ta(_0x15a846)&&(_0x2189ce=_0x2189ce||jp,_0x3ce2ff['scrollbars']='yes');const _0xd22183=Object['entries'](_0x3ce2ff)['reduce']((_0x260290,[_0x175aa0,_0x41e8f0])=>''+_0x260290+_0x175aa0+'='+_0x41e8f0+',','');if(Ef(_0x15a846)&&_0x39fd5e!=='_self')return Yp(_0x2189ce||'',_0x39fd5e),new Dr(null);const _0x758ee1=window['open'](_0x2189ce||'',_0x39fd5e,_0xd22183);m(_0x758ee1,_0x1a4cc7,'popup-blocked');try{_0x758ee1['focus']();}catch{}return new Dr(_0x758ee1);}function Yp(_0x40c63e,_0x58dfc7){const _0x2c63a3=document['createElement']('a');_0x2c63a3['href']=_0x40c63e,_0x2c63a3['target']=_0x58dfc7;const _0x519e45=document['createEvent']('MouseEvent');_0x519e45['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2c63a3['dispatchEvent'](_0x519e45);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x570404,_0x4f8eb9,_0x507df8,_0x2222e4,_0xb0b1d0,_0x35bf6c){m(_0x570404['config']['authDomain'],_0x570404,'auth-domain-config-required'),m(_0x570404['config']['apiKey'],_0x570404,'invalid-api-key');const _0x4e1e36={'apiKey':_0x570404['config']['apiKey'],'appName':_0x570404['name'],'authType':_0x507df8,'redirectUrl':_0x2222e4,'v':ct,'eventId':_0xb0b1d0};if(_0x4f8eb9 instanceof xa){_0x4f8eb9['setDefaultLanguage'](_0x570404['languageCode']),_0x4e1e36['providerId']=_0x4f8eb9['providerId']||'',hi(_0x4f8eb9['getCustomParameters']())||(_0x4e1e36['customParameters']=JSON['stringify'](_0x4f8eb9['getCustomParameters']()));for(const [_0x52e4ea,_0x2b0b31]of Object['entries']({}))_0x4e1e36[_0x52e4ea]=_0x2b0b31;}if(_0x4f8eb9 instanceof Qt){const _0x3c8346=_0x4f8eb9['getScopes']()['filter'](_0x42d26b=>_0x42d26b!=='');_0x3c8346['length']>0x0&&(_0x4e1e36['scopes']=_0x3c8346['join'](','));}_0x570404['tenantId']&&(_0x4e1e36['tid']=_0x570404['tenantId']);const _0x4d23b2=_0x4e1e36;for(const _0x378ccb of Object['keys'](_0x4d23b2))_0x4d23b2[_0x378ccb]===void 0x0&&delete _0x4d23b2[_0x378ccb];const _0x373876=await _0x570404['_getAppCheckToken'](),_0x4c92b9=_0x373876?'#'+Xp+'='+encodeURIComponent(_0x373876):'';return Zp(_0x570404)+'?'+at(_0x4d23b2)['slice'](0x1)+_0x4c92b9;}function Zp({config:_0x5ebb12}){return _0x5ebb12['emulator']?Is(_0x5ebb12,Jp):'https://'+_0x5ebb12['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x411f06,_0x197634,_0x1199fc,_0xc88190){var _0x5ab7a0;ae((_0x5ab7a0=this['eventManagers'][_0x411f06['_key']()])==null?void 0x0:_0x5ab7a0['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1a66e9=await Mr(_0x411f06,_0x197634,_0x1199fc,Ni(),_0xc88190);return Kp(_0x411f06,_0x1a66e9,bs());}async['_openRedirect'](_0x4e7618,_0x4a468e,_0x444958,_0xc96833){await this['_originValidation'](_0x4e7618);const _0x8e8d3c=await Mr(_0x4e7618,_0x4a468e,_0x444958,Ni(),_0xc96833);return ip(_0x8e8d3c),new Promise(()=>{});}['_initialize'](_0x312da9){const _0x45c7f2=_0x312da9['_key']();if(this['eventManagers'][_0x45c7f2]){const {manager:_0x4c72b9,promise:_0x31c433}=this['eventManagers'][_0x45c7f2];return _0x4c72b9?Promise['resolve'](_0x4c72b9):(ae(_0x31c433,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x31c433);}const _0x1b7721=this['initAndGetManager'](_0x312da9);return this['eventManagers'][_0x45c7f2]={'promise':_0x1b7721},_0x1b7721['catch'](()=>{delete this['eventManagers'][_0x45c7f2];}),_0x1b7721;}async['initAndGetManager'](_0x1a998f){const _0x22e28e=await Hp(_0x1a998f),_0x319385=new bp(_0x1a998f);return _0x22e28e['register']('authEvent',_0xf9c2fb=>(m(_0xf9c2fb==null?void 0x0:_0xf9c2fb['authEvent'],_0x1a998f,'invalid-auth-event'),{'status':_0x319385['onEvent'](_0xf9c2fb['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1a998f['_key']()]={'manager':_0x319385},this['iframes'][_0x1a998f['_key']()]=_0x22e28e,_0x319385;}['_isIframeWebStorageSupported'](_0x4bb612,_0x316e73){this['iframes'][_0x4bb612['_key']()]['send'](li,{'type':li},_0x1e93bf=>{var _0x562090;const _0x508104=(_0x562090=_0x1e93bf==null?void 0x0:_0x1e93bf[0x0])==null?void 0x0:_0x562090[li];_0x508104!==void 0x0&&_0x316e73(!!_0x508104),K(_0x4bb612,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x49cda2){const _0x1cf14b=_0x49cda2['_key']();return this['originValidationPromises'][_0x1cf14b]||(this['originValidationPromises'][_0x1cf14b]=Pp(_0x49cda2)),this['originValidationPromises'][_0x1cf14b];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x5404d9){this['auth']=_0x5404d9,this['internalListeners']=new Map();}['getUid'](){var _0x199f77;return this['assertAuthConfigured'](),((_0x199f77=this['auth']['currentUser'])==null?void 0x0:_0x199f77['uid'])||null;}async['getToken'](_0x57f0fc){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x57f0fc)}:null;}['addAuthTokenListener'](_0x12f9f3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x12f9f3))return;const _0x381121=this['auth']['onIdTokenChanged'](_0x18f5c1=>{_0x12f9f3((_0x18f5c1==null?void 0x0:_0x18f5c1['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x12f9f3,_0x381121),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x379ff3){this['assertAuthConfigured']();const _0x10ba7d=this['internalListeners']['get'](_0x379ff3);_0x10ba7d&&(this['internalListeners']['delete'](_0x379ff3),_0x10ba7d(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x48d0c0){switch(_0x48d0c0){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x4b1fa0){et(new Me('auth',(_0x3cc8ff,{options:_0x269bb1})=>{const _0x4cafce=_0x3cc8ff['getProvider']('app')['getImmediate'](),_0x2245b8=_0x3cc8ff['getProvider']('heartbeat'),_0x87b190=_0x3cc8ff['getProvider']('app-check-internal'),{apiKey:_0x25c6ce,authDomain:_0x3663fc}=_0x4cafce['options'];m(_0x25c6ce&&!_0x25c6ce['includes'](':'),'invalid-api-key',{'appName':_0x4cafce['name']});const _0x25128d={'apiKey':_0x25c6ce,'authDomain':_0x3663fc,'clientPlatform':_0x4b1fa0,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x4b1fa0)},_0x548601=new bf(_0x4cafce,_0x2245b8,_0x87b190,_0x25128d);return Lf(_0x548601,_0x269bb1),_0x548601;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2a5304,_0x5f425a,_0x4c66c3)=>{_0x2a5304['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x2d3ed1=>{const _0x2af9a7=qe(_0x2d3ed1['getProvider']('auth')['getImmediate']());return(_0x2909f8=>new n_(_0x2909f8))(_0x2af9a7);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x4b1fa0)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x33f42c=>async _0x3c9ca9=>{const _0x325f06=_0x3c9ca9&&await _0x3c9ca9['getIdTokenResult'](),_0xe4cc87=_0x325f06&&(new Date()['getTime']()-Date['parse'](_0x325f06['issuedAtTime']))/0x3e8;if(_0xe4cc87&&_0xe4cc87>o_)return;const _0x4ee128=_0x325f06==null?void 0x0:_0x325f06['token'];Fr!==_0x4ee128&&(Fr=_0x4ee128,await fetch(_0x33f42c,{'method':_0x4ee128?'POST':'DELETE','headers':_0x4ee128?{'Authorization':'Bearer\x20'+_0x4ee128}:{}}));};function O_(_0x4f63f9=Qr()){const _0x55701a=Ui(_0x4f63f9,'auth');if(_0x55701a['isInitialized']())return _0x55701a['getImmediate']();const _0x149cd6=Mf(_0x4f63f9,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x34363f=Gr('authTokenSyncURL');if(_0x34363f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3c337e=new URL(_0x34363f,location['origin']);if(location['origin']===_0x3c337e['origin']){const _0x9eb5a=a_(_0x3c337e['toString']());Jf(_0x149cd6,_0x9eb5a,()=>_0x9eb5a(_0x149cd6['currentUser'])),Qf(_0x149cd6,_0x38af43=>_0x9eb5a(_0x38af43));}}const _0x207fee=Hr('auth');return _0x207fee&&xf(_0x149cd6,'http://'+_0x207fee),_0x149cd6;}function c_(){var _0x276738;return((_0x276738=document['getElementsByTagName']('head'))==null?void 0x0:_0x276738[0x0])??document;}Rf({'loadJS'(_0x5c52a2){return new Promise((_0x3d017d,_0xf8869a)=>{const _0x48d526=document['createElement']('script');_0x48d526['setAttribute']('src',_0x5c52a2),_0x48d526['onload']=_0x3d017d,_0x48d526['onerror']=_0x4b855e=>{const _0x49b650=J('internal-error');_0x49b650['customData']=_0x4b855e,_0xf8869a(_0x49b650);},_0x48d526['type']='text/javascript',_0x48d526['charset']='UTF-8',c_()['appendChild'](_0x48d526);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};