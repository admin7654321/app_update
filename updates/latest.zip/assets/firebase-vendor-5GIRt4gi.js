const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3bb546,_0x50f67c){if(!_0x3bb546)throw ot(_0x50f67c);},ot=function(_0x90f2c5){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x90f2c5);},Wr=function(_0x49105e){const _0xf6356b=[];let _0x2308bd=0x0;for(let _0x86183a=0x0;_0x86183a<_0x49105e['length'];_0x86183a++){let _0x51d5d2=_0x49105e['charCodeAt'](_0x86183a);_0x51d5d2<0x80?_0xf6356b[_0x2308bd++]=_0x51d5d2:_0x51d5d2<0x800?(_0xf6356b[_0x2308bd++]=_0x51d5d2>>0x6|0xc0,_0xf6356b[_0x2308bd++]=_0x51d5d2&0x3f|0x80):(_0x51d5d2&0xfc00)===0xd800&&_0x86183a+0x1<_0x49105e['length']&&(_0x49105e['charCodeAt'](_0x86183a+0x1)&0xfc00)===0xdc00?(_0x51d5d2=0x10000+((_0x51d5d2&0x3ff)<<0xa)+(_0x49105e['charCodeAt'](++_0x86183a)&0x3ff),_0xf6356b[_0x2308bd++]=_0x51d5d2>>0x12|0xf0,_0xf6356b[_0x2308bd++]=_0x51d5d2>>0xc&0x3f|0x80,_0xf6356b[_0x2308bd++]=_0x51d5d2>>0x6&0x3f|0x80,_0xf6356b[_0x2308bd++]=_0x51d5d2&0x3f|0x80):(_0xf6356b[_0x2308bd++]=_0x51d5d2>>0xc|0xe0,_0xf6356b[_0x2308bd++]=_0x51d5d2>>0x6&0x3f|0x80,_0xf6356b[_0x2308bd++]=_0x51d5d2&0x3f|0x80);}return _0xf6356b;},Za=function(_0xcfdd1c){const _0x46a606=[];let _0xb5bcc1=0x0,_0x1252c8=0x0;for(;_0xb5bcc1<_0xcfdd1c['length'];){const _0x25bcec=_0xcfdd1c[_0xb5bcc1++];if(_0x25bcec<0x80)_0x46a606[_0x1252c8++]=String['fromCharCode'](_0x25bcec);else{if(_0x25bcec>0xbf&&_0x25bcec<0xe0){const _0x17df79=_0xcfdd1c[_0xb5bcc1++];_0x46a606[_0x1252c8++]=String['fromCharCode']((_0x25bcec&0x1f)<<0x6|_0x17df79&0x3f);}else{if(_0x25bcec>0xef&&_0x25bcec<0x16d){const _0x2f39c5=_0xcfdd1c[_0xb5bcc1++],_0x3c68d7=_0xcfdd1c[_0xb5bcc1++],_0xda13a3=_0xcfdd1c[_0xb5bcc1++],_0x111fc5=((_0x25bcec&0x7)<<0x12|(_0x2f39c5&0x3f)<<0xc|(_0x3c68d7&0x3f)<<0x6|_0xda13a3&0x3f)-0x10000;_0x46a606[_0x1252c8++]=String['fromCharCode'](0xd800+(_0x111fc5>>0xa)),_0x46a606[_0x1252c8++]=String['fromCharCode'](0xdc00+(_0x111fc5&0x3ff));}else{const _0x1a4e55=_0xcfdd1c[_0xb5bcc1++],_0x60d2b8=_0xcfdd1c[_0xb5bcc1++];_0x46a606[_0x1252c8++]=String['fromCharCode']((_0x25bcec&0xf)<<0xc|(_0x1a4e55&0x3f)<<0x6|_0x60d2b8&0x3f);}}}}return _0x46a606['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x152b80,_0x5d14da){if(!Array['isArray'](_0x152b80))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x56873d=_0x5d14da?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4c0d13=[];for(let _0x4a6c76=0x0;_0x4a6c76<_0x152b80['length'];_0x4a6c76+=0x3){const _0x5eb426=_0x152b80[_0x4a6c76],_0x47a923=_0x4a6c76+0x1<_0x152b80['length'],_0x3a5e01=_0x47a923?_0x152b80[_0x4a6c76+0x1]:0x0,_0xf39476=_0x4a6c76+0x2<_0x152b80['length'],_0x423087=_0xf39476?_0x152b80[_0x4a6c76+0x2]:0x0,_0x5431f8=_0x5eb426>>0x2,_0x5131b4=(_0x5eb426&0x3)<<0x4|_0x3a5e01>>0x4;let _0x4d6c15=(_0x3a5e01&0xf)<<0x2|_0x423087>>0x6,_0x35ac07=_0x423087&0x3f;_0xf39476||(_0x35ac07=0x40,_0x47a923||(_0x4d6c15=0x40)),_0x4c0d13['push'](_0x56873d[_0x5431f8],_0x56873d[_0x5131b4],_0x56873d[_0x4d6c15],_0x56873d[_0x35ac07]);}return _0x4c0d13['join']('');},'encodeString'(_0x18b2c9,_0x3ad1ba){return this['HAS_NATIVE_SUPPORT']&&!_0x3ad1ba?btoa(_0x18b2c9):this['encodeByteArray'](Wr(_0x18b2c9),_0x3ad1ba);},'decodeString'(_0x593932,_0x4e98a5){return this['HAS_NATIVE_SUPPORT']&&!_0x4e98a5?atob(_0x593932):Za(this['decodeStringToByteArray'](_0x593932,_0x4e98a5));},'decodeStringToByteArray'(_0x3a1a7c,_0x2bb2f8){this['init_']();const _0xa264b3=_0x2bb2f8?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x19f977=[];for(let _0x52d40b=0x0;_0x52d40b<_0x3a1a7c['length'];){const _0x489314=_0xa264b3[_0x3a1a7c['charAt'](_0x52d40b++)],_0xddc98f=_0x52d40b<_0x3a1a7c['length']?_0xa264b3[_0x3a1a7c['charAt'](_0x52d40b)]:0x0;++_0x52d40b;const _0x4d5225=_0x52d40b<_0x3a1a7c['length']?_0xa264b3[_0x3a1a7c['charAt'](_0x52d40b)]:0x40;++_0x52d40b;const _0x514404=_0x52d40b<_0x3a1a7c['length']?_0xa264b3[_0x3a1a7c['charAt'](_0x52d40b)]:0x40;if(++_0x52d40b,_0x489314==null||_0xddc98f==null||_0x4d5225==null||_0x514404==null)throw new ec();const _0x4c6168=_0x489314<<0x2|_0xddc98f>>0x4;if(_0x19f977['push'](_0x4c6168),_0x4d5225!==0x40){const _0x908525=_0xddc98f<<0x4&0xf0|_0x4d5225>>0x2;if(_0x19f977['push'](_0x908525),_0x514404!==0x40){const _0x3fa4c2=_0x4d5225<<0x6&0xc0|_0x514404;_0x19f977['push'](_0x3fa4c2);}}}return _0x19f977;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5b8625=0x0;_0x5b8625<this['ENCODED_VALS']['length'];_0x5b8625++)this['byteToCharMap_'][_0x5b8625]=this['ENCODED_VALS']['charAt'](_0x5b8625),this['charToByteMap_'][this['byteToCharMap_'][_0x5b8625]]=_0x5b8625,this['byteToCharMapWebSafe_'][_0x5b8625]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5b8625),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5b8625]]=_0x5b8625,_0x5b8625>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5b8625)]=_0x5b8625,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5b8625)]=_0x5b8625);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x466296){const _0x4d8952=Wr(_0x466296);return Di['encodeByteArray'](_0x4d8952,!0x0);},an=function(_0x46f65d){return Br(_0x46f65d)['replace'](/\./g,'');},cn=function(_0x12dedb){try{return Di['decodeString'](_0x12dedb,!0x0);}catch(_0x3d6a52){console['error']('base64Decode\x20failed:\x20',_0x3d6a52);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x430ad4){return Vr(void 0x0,_0x430ad4);}function Vr(_0x365d78,_0x50c58a){if(!(_0x50c58a instanceof Object))return _0x50c58a;switch(_0x50c58a['constructor']){case Date:const _0x81a638=_0x50c58a;return new Date(_0x81a638['getTime']());case Object:_0x365d78===void 0x0&&(_0x365d78={});break;case Array:_0x365d78=[];break;default:return _0x50c58a;}for(const _0x251792 in _0x50c58a)!_0x50c58a['hasOwnProperty'](_0x251792)||!nc(_0x251792)||(_0x365d78[_0x251792]=Vr(_0x365d78[_0x251792],_0x50c58a[_0x251792]));return _0x365d78;}function nc(_0x34646d){return _0x34646d!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x56007e=As['__FIREBASE_DEFAULTS__'];if(_0x56007e)return JSON['parse'](_0x56007e);},oc=()=>{if(typeof document>'u')return;let _0x5aea48;try{_0x5aea48=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x34e52c=_0x5aea48&&cn(_0x5aea48[0x1]);return _0x34e52c&&JSON['parse'](_0x34e52c);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0xf4cc4a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xf4cc4a);return;}},Hr=_0x5701b5=>{var _0x4c24ca,_0x300851;return(_0x300851=(_0x4c24ca=Mi())==null?void 0x0:_0x4c24ca['emulatorHosts'])==null?void 0x0:_0x300851[_0x5701b5];},ac=_0x2e620a=>{const _0x5aa8ec=Hr(_0x2e620a);if(!_0x5aa8ec)return;const _0x5cb723=_0x5aa8ec['lastIndexOf'](':');if(_0x5cb723<=0x0||_0x5cb723+0x1===_0x5aa8ec['length'])throw new Error('Invalid\x20host\x20'+_0x5aa8ec+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x404520=parseInt(_0x5aa8ec['substring'](_0x5cb723+0x1),0xa);return _0x5aa8ec[0x0]==='['?[_0x5aa8ec['substring'](0x1,_0x5cb723-0x1),_0x404520]:[_0x5aa8ec['substring'](0x0,_0x5cb723),_0x404520];},$r=()=>{var _0x483244;return(_0x483244=Mi())==null?void 0x0:_0x483244['config'];},Gr=_0x270eec=>{var _0x986caa;return(_0x986caa=Mi())==null?void 0x0:_0x986caa['_'+_0x270eec];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x59f590,_0x4337dd)=>{this['resolve']=_0x59f590,this['reject']=_0x4337dd;});}['wrapCallback'](_0x19d739){return(_0x305c26,_0x479d2c)=>{_0x305c26?this['reject'](_0x305c26):this['resolve'](_0x479d2c),typeof _0x19d739=='function'&&(this['promise']['catch'](()=>{}),_0x19d739['length']===0x1?_0x19d739(_0x305c26):_0x19d739(_0x305c26,_0x479d2c));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x298db1,_0x1a1682){if(_0x298db1['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x48dabb={'alg':'none','type':'JWT'},_0x3eab93=_0x1a1682||'demo-project',_0x425c57=_0x298db1['iat']||0x0,_0x415022=_0x298db1['sub']||_0x298db1['user_id'];if(!_0x415022)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2c571e={'iss':'https://securetoken.google.com/'+_0x3eab93,'aud':_0x3eab93,'iat':_0x425c57,'exp':_0x425c57+0xe10,'auth_time':_0x425c57,'sub':_0x415022,'user_id':_0x415022,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x298db1};return[an(JSON['stringify'](_0x48dabb)),an(JSON['stringify'](_0x2c571e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x548b90=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x548b90=='object'&&_0x548b90['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x3a0a87=W();return _0x3a0a87['indexOf']('MSIE\x20')>=0x0||_0x3a0a87['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x3aa4b3,_0x30dbd6)=>{try{let _0x358483=!0x0;const _0x5a2a5c='validate-browser-context-for-indexeddb-analytics-module',_0x109c5d=self['indexedDB']['open'](_0x5a2a5c);_0x109c5d['onsuccess']=()=>{_0x109c5d['result']['close'](),_0x358483||self['indexedDB']['deleteDatabase'](_0x5a2a5c),_0x3aa4b3(!0x0);},_0x109c5d['onupgradeneeded']=()=>{_0x358483=!0x1;},_0x109c5d['onerror']=()=>{var _0x4507c4;_0x30dbd6(((_0x4507c4=_0x109c5d['error'])==null?void 0x0:_0x4507c4['message'])||'');};}catch(_0x4f6093){_0x30dbd6(_0x4f6093);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x38e3e1,_0x25804f,_0x3a38ca){super(_0x25804f),this['code']=_0x38e3e1,this['customData']=_0x3a38ca,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x3af7f7,_0x14e2f2,_0x3c09d0){this['service']=_0x3af7f7,this['serviceName']=_0x14e2f2,this['errors']=_0x3c09d0;}['create'](_0x2550f3,..._0xf4849){const _0x2e1d95=_0xf4849[0x0]||{},_0x5c4859=this['service']+'/'+_0x2550f3,_0x57ac3c=this['errors'][_0x2550f3],_0x57af2e=_0x57ac3c?gc(_0x57ac3c,_0x2e1d95):'Error',_0x30b034=this['serviceName']+':\x20'+_0x57af2e+'\x20('+_0x5c4859+').';return new Se(_0x5c4859,_0x30b034,_0x2e1d95);}}function gc(_0x531ba5,_0x33f63c){return _0x531ba5['replace'](mc,(_0x21b438,_0x3e1059)=>{const _0x3548f5=_0x33f63c[_0x3e1059];return _0x3548f5!=null?String(_0x3548f5):'<'+_0x3e1059+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x5b14db){return JSON['parse'](_0x5b14db);}function O(_0x20c6c6){return JSON['stringify'](_0x20c6c6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xfe8a3e){let _0x310ab0={},_0x4fd653={},_0x213423={},_0x25eeaf='';try{const _0x30bd4f=_0xfe8a3e['split']('.');_0x310ab0=bt(cn(_0x30bd4f[0x0])||''),_0x4fd653=bt(cn(_0x30bd4f[0x1])||''),_0x25eeaf=_0x30bd4f[0x2],_0x213423=_0x4fd653['d']||{},delete _0x4fd653['d'];}catch{}return{'header':_0x310ab0,'claims':_0x4fd653,'data':_0x213423,'signature':_0x25eeaf};},yc=function(_0x2b6c9b){const _0x449a6c=zr(_0x2b6c9b),_0x151c65=_0x449a6c['claims'];return!!_0x151c65&&typeof _0x151c65=='object'&&_0x151c65['hasOwnProperty']('iat');},vc=function(_0x2b3a21){const _0x1511a4=zr(_0x2b3a21)['claims'];return typeof _0x1511a4=='object'&&_0x1511a4['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1e39fc,_0x58672b){return Object['prototype']['hasOwnProperty']['call'](_0x1e39fc,_0x58672b);}function Oe(_0x262385,_0x47753c){if(Object['prototype']['hasOwnProperty']['call'](_0x262385,_0x47753c))return _0x262385[_0x47753c];}function hi(_0x51fe77){for(const _0x1be14c in _0x51fe77)if(Object['prototype']['hasOwnProperty']['call'](_0x51fe77,_0x1be14c))return!0x1;return!0x0;}function ln(_0x1f25c1,_0x149921,_0x255973){const _0xe945f5={};for(const _0x350873 in _0x1f25c1)Object['prototype']['hasOwnProperty']['call'](_0x1f25c1,_0x350873)&&(_0xe945f5[_0x350873]=_0x149921['call'](_0x255973,_0x1f25c1[_0x350873],_0x350873,_0x1f25c1));return _0xe945f5;}function De(_0x331c43,_0x2b94da){if(_0x331c43===_0x2b94da)return!0x0;const _0x11cb88=Object['keys'](_0x331c43),_0x4a0261=Object['keys'](_0x2b94da);for(const _0x33e7f3 of _0x11cb88){if(!_0x4a0261['includes'](_0x33e7f3))return!0x1;const _0x272904=_0x331c43[_0x33e7f3],_0x1013c4=_0x2b94da[_0x33e7f3];if(ks(_0x272904)&&ks(_0x1013c4)){if(!De(_0x272904,_0x1013c4))return!0x1;}else{if(_0x272904!==_0x1013c4)return!0x1;}}for(const _0x53c9da of _0x4a0261)if(!_0x11cb88['includes'](_0x53c9da))return!0x1;return!0x0;}function ks(_0x3400c5){return _0x3400c5!==null&&typeof _0x3400c5=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x57cd89){const _0x1c7da5=[];for(const [_0x32a89a,_0x40af31]of Object['entries'](_0x57cd89))Array['isArray'](_0x40af31)?_0x40af31['forEach'](_0x361b7d=>{_0x1c7da5['push'](encodeURIComponent(_0x32a89a)+'='+encodeURIComponent(_0x361b7d));}):_0x1c7da5['push'](encodeURIComponent(_0x32a89a)+'='+encodeURIComponent(_0x40af31));return _0x1c7da5['length']?'&'+_0x1c7da5['join']('&'):'';}function yt(_0x416028){const _0x50de98={};return _0x416028['replace'](/^\?/,'')['split']('&')['forEach'](_0x14c8b8=>{if(_0x14c8b8){const [_0x4084ac,_0x2ae9dc]=_0x14c8b8['split']('=');_0x50de98[decodeURIComponent(_0x4084ac)]=decodeURIComponent(_0x2ae9dc);}}),_0x50de98;}function vt(_0x2be3fb){const _0x3a65c5=_0x2be3fb['indexOf']('?');if(!_0x3a65c5)return'';const _0x6ea9b5=_0x2be3fb['indexOf']('#',_0x3a65c5);return _0x2be3fb['substring'](_0x3a65c5,_0x6ea9b5>0x0?_0x6ea9b5:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x9a4387=0x1;_0x9a4387<this['blockSize'];++_0x9a4387)this['pad_'][_0x9a4387]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x394af7,_0x37a43e){_0x37a43e||(_0x37a43e=0x0);const _0x12c2cf=this['W_'];if(typeof _0x394af7=='string'){for(let _0x7f538d=0x0;_0x7f538d<0x10;_0x7f538d++)_0x12c2cf[_0x7f538d]=_0x394af7['charCodeAt'](_0x37a43e)<<0x18|_0x394af7['charCodeAt'](_0x37a43e+0x1)<<0x10|_0x394af7['charCodeAt'](_0x37a43e+0x2)<<0x8|_0x394af7['charCodeAt'](_0x37a43e+0x3),_0x37a43e+=0x4;}else{for(let _0x51430=0x0;_0x51430<0x10;_0x51430++)_0x12c2cf[_0x51430]=_0x394af7[_0x37a43e]<<0x18|_0x394af7[_0x37a43e+0x1]<<0x10|_0x394af7[_0x37a43e+0x2]<<0x8|_0x394af7[_0x37a43e+0x3],_0x37a43e+=0x4;}for(let _0x47c566=0x10;_0x47c566<0x50;_0x47c566++){const _0x147606=_0x12c2cf[_0x47c566-0x3]^_0x12c2cf[_0x47c566-0x8]^_0x12c2cf[_0x47c566-0xe]^_0x12c2cf[_0x47c566-0x10];_0x12c2cf[_0x47c566]=(_0x147606<<0x1|_0x147606>>>0x1f)&0xffffffff;}let _0x19678e=this['chain_'][0x0],_0x14b023=this['chain_'][0x1],_0x5180fd=this['chain_'][0x2],_0x2a97fd=this['chain_'][0x3],_0x5aa0b3=this['chain_'][0x4],_0x32f5f4,_0x460be5;for(let _0x12b4df=0x0;_0x12b4df<0x50;_0x12b4df++){_0x12b4df<0x28?_0x12b4df<0x14?(_0x32f5f4=_0x2a97fd^_0x14b023&(_0x5180fd^_0x2a97fd),_0x460be5=0x5a827999):(_0x32f5f4=_0x14b023^_0x5180fd^_0x2a97fd,_0x460be5=0x6ed9eba1):_0x12b4df<0x3c?(_0x32f5f4=_0x14b023&_0x5180fd|_0x2a97fd&(_0x14b023|_0x5180fd),_0x460be5=0x8f1bbcdc):(_0x32f5f4=_0x14b023^_0x5180fd^_0x2a97fd,_0x460be5=0xca62c1d6);const _0x5a037e=(_0x19678e<<0x5|_0x19678e>>>0x1b)+_0x32f5f4+_0x5aa0b3+_0x460be5+_0x12c2cf[_0x12b4df]&0xffffffff;_0x5aa0b3=_0x2a97fd,_0x2a97fd=_0x5180fd,_0x5180fd=(_0x14b023<<0x1e|_0x14b023>>>0x2)&0xffffffff,_0x14b023=_0x19678e,_0x19678e=_0x5a037e;}this['chain_'][0x0]=this['chain_'][0x0]+_0x19678e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x14b023&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5180fd&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2a97fd&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5aa0b3&0xffffffff;}['update'](_0x3ad51f,_0x1e3efa){if(_0x3ad51f==null)return;_0x1e3efa===void 0x0&&(_0x1e3efa=_0x3ad51f['length']);const _0x1d0fcb=_0x1e3efa-this['blockSize'];let _0x166753=0x0;const _0x4c6866=this['buf_'];let _0x2e6a74=this['inbuf_'];for(;_0x166753<_0x1e3efa;){if(_0x2e6a74===0x0){for(;_0x166753<=_0x1d0fcb;)this['compress_'](_0x3ad51f,_0x166753),_0x166753+=this['blockSize'];}if(typeof _0x3ad51f=='string'){for(;_0x166753<_0x1e3efa;)if(_0x4c6866[_0x2e6a74]=_0x3ad51f['charCodeAt'](_0x166753),++_0x2e6a74,++_0x166753,_0x2e6a74===this['blockSize']){this['compress_'](_0x4c6866),_0x2e6a74=0x0;break;}}else{for(;_0x166753<_0x1e3efa;)if(_0x4c6866[_0x2e6a74]=_0x3ad51f[_0x166753],++_0x2e6a74,++_0x166753,_0x2e6a74===this['blockSize']){this['compress_'](_0x4c6866),_0x2e6a74=0x0;break;}}}this['inbuf_']=_0x2e6a74,this['total_']+=_0x1e3efa;}['digest'](){const _0x34e518=[];let _0xddff2f=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x309e86=this['blockSize']-0x1;_0x309e86>=0x38;_0x309e86--)this['buf_'][_0x309e86]=_0xddff2f&0xff,_0xddff2f/=0x100;this['compress_'](this['buf_']);let _0x267465=0x0;for(let _0x5979ba=0x0;_0x5979ba<0x5;_0x5979ba++)for(let _0xb60921=0x18;_0xb60921>=0x0;_0xb60921-=0x8)_0x34e518[_0x267465]=this['chain_'][_0x5979ba]>>_0xb60921&0xff,++_0x267465;return _0x34e518;}}function Ic(_0x51d4ce,_0x44277c){const _0x37acf2=new wc(_0x51d4ce,_0x44277c);return _0x37acf2['subscribe']['bind'](_0x37acf2);}class wc{constructor(_0x1243cc,_0x20f9c2){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x20f9c2,this['task']['then'](()=>{_0x1243cc(this);})['catch'](_0x1b1930=>{this['error'](_0x1b1930);});}['next'](_0x2be400){this['forEachObserver'](_0x4bff68=>{_0x4bff68['next'](_0x2be400);});}['error'](_0x4364a0){this['forEachObserver'](_0x14b113=>{_0x14b113['error'](_0x4364a0);}),this['close'](_0x4364a0);}['complete'](){this['forEachObserver'](_0x39930d=>{_0x39930d['complete']();}),this['close']();}['subscribe'](_0x5928a3,_0x1541bc,_0x2751de){let _0x308db4;if(_0x5928a3===void 0x0&&_0x1541bc===void 0x0&&_0x2751de===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x5928a3,['next','error','complete'])?_0x308db4=_0x5928a3:_0x308db4={'next':_0x5928a3,'error':_0x1541bc,'complete':_0x2751de},_0x308db4['next']===void 0x0&&(_0x308db4['next']=Qn),_0x308db4['error']===void 0x0&&(_0x308db4['error']=Qn),_0x308db4['complete']===void 0x0&&(_0x308db4['complete']=Qn);const _0x398e56=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x308db4['error'](this['finalError']):_0x308db4['complete']();}catch{}}),this['observers']['push'](_0x308db4),_0x398e56;}['unsubscribeOne'](_0x24ec0e){this['observers']===void 0x0||this['observers'][_0x24ec0e]===void 0x0||(delete this['observers'][_0x24ec0e],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x6c0992){if(!this['finalized']){for(let _0x4ca7a4=0x0;_0x4ca7a4<this['observers']['length'];_0x4ca7a4++)this['sendOne'](_0x4ca7a4,_0x6c0992);}}['sendOne'](_0x4721b7,_0x1d1e25){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4721b7]!==void 0x0)try{_0x1d1e25(this['observers'][_0x4721b7]);}catch(_0x2ebf37){typeof console<'u'&&console['error']&&console['error'](_0x2ebf37);}});}['close'](_0x68bc05){this['finalized']||(this['finalized']=!0x0,_0x68bc05!==void 0x0&&(this['finalError']=_0x68bc05),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1e3999,_0x4b43dc){if(typeof _0x1e3999!='object'||_0x1e3999===null)return!0x1;for(const _0x1d1b2a of _0x4b43dc)if(_0x1d1b2a in _0x1e3999&&typeof _0x1e3999[_0x1d1b2a]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3efe0b,_0x5c7042){return _0x3efe0b+'\x20failed:\x20'+_0x5c7042+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x17c956){const _0x15ef32=[];let _0xeaed53=0x0;for(let _0xba560b=0x0;_0xba560b<_0x17c956['length'];_0xba560b++){let _0x18e1ca=_0x17c956['charCodeAt'](_0xba560b);if(_0x18e1ca>=0xd800&&_0x18e1ca<=0xdbff){const _0x48c008=_0x18e1ca-0xd800;_0xba560b++,f(_0xba560b<_0x17c956['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x13f05c=_0x17c956['charCodeAt'](_0xba560b)-0xdc00;_0x18e1ca=0x10000+(_0x48c008<<0xa)+_0x13f05c;}_0x18e1ca<0x80?_0x15ef32[_0xeaed53++]=_0x18e1ca:_0x18e1ca<0x800?(_0x15ef32[_0xeaed53++]=_0x18e1ca>>0x6|0xc0,_0x15ef32[_0xeaed53++]=_0x18e1ca&0x3f|0x80):_0x18e1ca<0x10000?(_0x15ef32[_0xeaed53++]=_0x18e1ca>>0xc|0xe0,_0x15ef32[_0xeaed53++]=_0x18e1ca>>0x6&0x3f|0x80,_0x15ef32[_0xeaed53++]=_0x18e1ca&0x3f|0x80):(_0x15ef32[_0xeaed53++]=_0x18e1ca>>0x12|0xf0,_0x15ef32[_0xeaed53++]=_0x18e1ca>>0xc&0x3f|0x80,_0x15ef32[_0xeaed53++]=_0x18e1ca>>0x6&0x3f|0x80,_0x15ef32[_0xeaed53++]=_0x18e1ca&0x3f|0x80);}return _0x15ef32;},Pn=function(_0x4ad683){let _0x3397e6=0x0;for(let _0x982545=0x0;_0x982545<_0x4ad683['length'];_0x982545++){const _0x2d7233=_0x4ad683['charCodeAt'](_0x982545);_0x2d7233<0x80?_0x3397e6++:_0x2d7233<0x800?_0x3397e6+=0x2:_0x2d7233>=0xd800&&_0x2d7233<=0xdbff?(_0x3397e6+=0x4,_0x982545++):_0x3397e6+=0x3;}return _0x3397e6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x13465a){return _0x13465a&&_0x13465a['_delegate']?_0x13465a['_delegate']:_0x13465a;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x436a6a){try{return(_0x436a6a['startsWith']('http://')||_0x436a6a['startsWith']('https://')?new URL(_0x436a6a)['hostname']:_0x436a6a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0xdb300c){return(await fetch(_0xdb300c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x8510ea,_0x52ae01,_0x1281a9){this['name']=_0x8510ea,this['instanceFactory']=_0x52ae01,this['type']=_0x1281a9,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0xc5d7ce){return this['instantiationMode']=_0xc5d7ce,this;}['setMultipleInstances'](_0x37e24e){return this['multipleInstances']=_0x37e24e,this;}['setServiceProps'](_0x576550){return this['serviceProps']=_0x576550,this;}['setInstanceCreatedCallback'](_0x369d83){return this['onInstanceCreated']=_0x369d83,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x18895b,_0x524808){this['name']=_0x18895b,this['container']=_0x524808,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x590d00){const _0xc0aaef=this['normalizeInstanceIdentifier'](_0x590d00);if(!this['instancesDeferred']['has'](_0xc0aaef)){const _0x70e763=new Ve();if(this['instancesDeferred']['set'](_0xc0aaef,_0x70e763),this['isInitialized'](_0xc0aaef)||this['shouldAutoInitialize']())try{const _0x1f4525=this['getOrInitializeService']({'instanceIdentifier':_0xc0aaef});_0x1f4525&&_0x70e763['resolve'](_0x1f4525);}catch{}}return this['instancesDeferred']['get'](_0xc0aaef)['promise'];}['getImmediate'](_0x38e1ba){const _0x2927b3=this['normalizeInstanceIdentifier'](_0x38e1ba==null?void 0x0:_0x38e1ba['identifier']),_0x5e3b1e=(_0x38e1ba==null?void 0x0:_0x38e1ba['optional'])??!0x1;if(this['isInitialized'](_0x2927b3)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2927b3});}catch(_0x201cba){if(_0x5e3b1e)return null;throw _0x201cba;}else{if(_0x5e3b1e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x163673){if(_0x163673['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x163673['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x163673,!!this['shouldAutoInitialize']()){if(Rc(_0x163673))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3c566a,_0x5e4c83]of this['instancesDeferred']['entries']()){const _0x511a7b=this['normalizeInstanceIdentifier'](_0x3c566a);try{const _0x4a906d=this['getOrInitializeService']({'instanceIdentifier':_0x511a7b});_0x5e4c83['resolve'](_0x4a906d);}catch{}}}}['clearInstance'](_0x515cad=ke){this['instancesDeferred']['delete'](_0x515cad),this['instancesOptions']['delete'](_0x515cad),this['instances']['delete'](_0x515cad);}async['delete'](){const _0x281972=Array['from'](this['instances']['values']());await Promise['all']([..._0x281972['filter'](_0x577a30=>'INTERNAL'in _0x577a30)['map'](_0x2abed5=>_0x2abed5['INTERNAL']['delete']()),..._0x281972['filter'](_0x3d330a=>'_delete'in _0x3d330a)['map'](_0x247cc9=>_0x247cc9['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4b5fec=ke){return this['instances']['has'](_0x4b5fec);}['getOptions'](_0x3eaabf=ke){return this['instancesOptions']['get'](_0x3eaabf)||{};}['initialize'](_0x102443={}){const {options:_0x20fb76={}}=_0x102443,_0x41ee51=this['normalizeInstanceIdentifier'](_0x102443['instanceIdentifier']);if(this['isInitialized'](_0x41ee51))throw Error(this['name']+'('+_0x41ee51+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2b3f3a=this['getOrInitializeService']({'instanceIdentifier':_0x41ee51,'options':_0x20fb76});for(const [_0x46b953,_0x36e12c]of this['instancesDeferred']['entries']()){const _0x296dfd=this['normalizeInstanceIdentifier'](_0x46b953);_0x41ee51===_0x296dfd&&_0x36e12c['resolve'](_0x2b3f3a);}return _0x2b3f3a;}['onInit'](_0x3da7f5,_0xd305e){const _0x528587=this['normalizeInstanceIdentifier'](_0xd305e),_0x5e82c9=this['onInitCallbacks']['get'](_0x528587)??new Set();_0x5e82c9['add'](_0x3da7f5),this['onInitCallbacks']['set'](_0x528587,_0x5e82c9);const _0x621fdb=this['instances']['get'](_0x528587);return _0x621fdb&&_0x3da7f5(_0x621fdb,_0x528587),()=>{_0x5e82c9['delete'](_0x3da7f5);};}['invokeOnInitCallbacks'](_0xcb0d32,_0x3219ff){const _0x100992=this['onInitCallbacks']['get'](_0x3219ff);if(_0x100992){for(const _0x4dc2c5 of _0x100992)try{_0x4dc2c5(_0xcb0d32,_0x3219ff);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4e53e8,options:_0x2bf27a={}}){let _0x3b387a=this['instances']['get'](_0x4e53e8);if(!_0x3b387a&&this['component']&&(_0x3b387a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4e53e8),'options':_0x2bf27a}),this['instances']['set'](_0x4e53e8,_0x3b387a),this['instancesOptions']['set'](_0x4e53e8,_0x2bf27a),this['invokeOnInitCallbacks'](_0x3b387a,_0x4e53e8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4e53e8,_0x3b387a);}catch{}return _0x3b387a||null;}['normalizeInstanceIdentifier'](_0x4696e6=ke){return this['component']?this['component']['multipleInstances']?_0x4696e6:ke:_0x4696e6;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x52e4da){return _0x52e4da===ke?void 0x0:_0x52e4da;}function Rc(_0x1b48f8){return _0x1b48f8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2c533b){this['name']=_0x2c533b,this['providers']=new Map();}['addComponent'](_0x4d6187){const _0x15df8d=this['getProvider'](_0x4d6187['name']);if(_0x15df8d['isComponentSet']())throw new Error('Component\x20'+_0x4d6187['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x15df8d['setComponent'](_0x4d6187);}['addOrOverwriteComponent'](_0x204b1a){this['getProvider'](_0x204b1a['name'])['isComponentSet']()&&this['providers']['delete'](_0x204b1a['name']),this['addComponent'](_0x204b1a);}['getProvider'](_0x1d0cdd){if(this['providers']['has'](_0x1d0cdd))return this['providers']['get'](_0x1d0cdd);const _0x3d0d67=new Sc(_0x1d0cdd,this);return this['providers']['set'](_0x1d0cdd,_0x3d0d67),_0x3d0d67;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x39c1c4){_0x39c1c4[_0x39c1c4['DEBUG']=0x0]='DEBUG',_0x39c1c4[_0x39c1c4['VERBOSE']=0x1]='VERBOSE',_0x39c1c4[_0x39c1c4['INFO']=0x2]='INFO',_0x39c1c4[_0x39c1c4['WARN']=0x3]='WARN',_0x39c1c4[_0x39c1c4['ERROR']=0x4]='ERROR',_0x39c1c4[_0x39c1c4['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2e4807,_0x29c477,..._0x1cda9c)=>{if(_0x29c477<_0x2e4807['logLevel'])return;const _0x215286=new Date()['toISOString'](),_0x2de14e=Pc[_0x29c477];if(_0x2de14e)console[_0x2de14e]('['+_0x215286+']\x20\x20'+_0x2e4807['name']+':',..._0x1cda9c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x29c477+')');};class xi{constructor(_0x5cc58d){this['name']=_0x5cc58d,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x294509){if(!(_0x294509 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x294509+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x294509;}['setLogLevel'](_0x59eca0){this['_logLevel']=typeof _0x59eca0=='string'?kc[_0x59eca0]:_0x59eca0;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x972ba7){if(typeof _0x972ba7!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x972ba7;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x58746d){this['_userLogHandler']=_0x58746d;}['debug'](..._0x2e419c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2e419c),this['_logHandler'](this,T['DEBUG'],..._0x2e419c);}['log'](..._0x2c651d){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2c651d),this['_logHandler'](this,T['VERBOSE'],..._0x2c651d);}['info'](..._0x63c0c7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x63c0c7),this['_logHandler'](this,T['INFO'],..._0x63c0c7);}['warn'](..._0x38e13d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x38e13d),this['_logHandler'](this,T['WARN'],..._0x38e13d);}['error'](..._0x5e94a3){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5e94a3),this['_logHandler'](this,T['ERROR'],..._0x5e94a3);}}const Dc=(_0x2c8cb7,_0x4b34b)=>_0x4b34b['some'](_0x47d0f3=>_0x2c8cb7 instanceof _0x47d0f3);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x161d3e){const _0x27a122=new Promise((_0x50577a,_0xd24609)=>{const _0x133552=()=>{_0x161d3e['removeEventListener']('success',_0x34532d),_0x161d3e['removeEventListener']('error',_0xdfe2f2);},_0x34532d=()=>{_0x50577a(_e(_0x161d3e['result'])),_0x133552();},_0xdfe2f2=()=>{_0xd24609(_0x161d3e['error']),_0x133552();};_0x161d3e['addEventListener']('success',_0x34532d),_0x161d3e['addEventListener']('error',_0xdfe2f2);});return _0x27a122['then'](_0x44ef7e=>{_0x44ef7e instanceof IDBCursor&&Kr['set'](_0x44ef7e,_0x161d3e);})['catch'](()=>{}),Fi['set'](_0x27a122,_0x161d3e),_0x27a122;}function Fc(_0xed1291){if(ui['has'](_0xed1291))return;const _0x21c145=new Promise((_0x1caae9,_0x365a3e)=>{const _0x4d0d19=()=>{_0xed1291['removeEventListener']('complete',_0x5385b6),_0xed1291['removeEventListener']('error',_0x3090a2),_0xed1291['removeEventListener']('abort',_0x3090a2);},_0x5385b6=()=>{_0x1caae9(),_0x4d0d19();},_0x3090a2=()=>{_0x365a3e(_0xed1291['error']||new DOMException('AbortError','AbortError')),_0x4d0d19();};_0xed1291['addEventListener']('complete',_0x5385b6),_0xed1291['addEventListener']('error',_0x3090a2),_0xed1291['addEventListener']('abort',_0x3090a2);});ui['set'](_0xed1291,_0x21c145);}let di={'get'(_0x61da19,_0x30cb81,_0x452046){if(_0x61da19 instanceof IDBTransaction){if(_0x30cb81==='done')return ui['get'](_0x61da19);if(_0x30cb81==='objectStoreNames')return _0x61da19['objectStoreNames']||Yr['get'](_0x61da19);if(_0x30cb81==='store')return _0x452046['objectStoreNames'][0x1]?void 0x0:_0x452046['objectStore'](_0x452046['objectStoreNames'][0x0]);}return _e(_0x61da19[_0x30cb81]);},'set'(_0x13a7d6,_0x7e9084,_0x3bf8d){return _0x13a7d6[_0x7e9084]=_0x3bf8d,!0x0;},'has'(_0x49147b,_0x182359){return _0x49147b instanceof IDBTransaction&&(_0x182359==='done'||_0x182359==='store')?!0x0:_0x182359 in _0x49147b;}};function Uc(_0x2b4d1e){di=_0x2b4d1e(di);}function Wc(_0x3f2551){return _0x3f2551===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5ab0ea,..._0x250f54){const _0x515aa7=_0x3f2551['call'](Xn(this),_0x5ab0ea,..._0x250f54);return Yr['set'](_0x515aa7,_0x5ab0ea['sort']?_0x5ab0ea['sort']():[_0x5ab0ea]),_e(_0x515aa7);}:Lc()['includes'](_0x3f2551)?function(..._0xbbad53){return _0x3f2551['apply'](Xn(this),_0xbbad53),_e(Kr['get'](this));}:function(..._0x5311fd){return _e(_0x3f2551['apply'](Xn(this),_0x5311fd));};}function Bc(_0x14014d){return typeof _0x14014d=='function'?Wc(_0x14014d):(_0x14014d instanceof IDBTransaction&&Fc(_0x14014d),Dc(_0x14014d,Mc())?new Proxy(_0x14014d,di):_0x14014d);}function _e(_0x257a8d){if(_0x257a8d instanceof IDBRequest)return xc(_0x257a8d);if(Jn['has'](_0x257a8d))return Jn['get'](_0x257a8d);const _0x30b51e=Bc(_0x257a8d);return _0x30b51e!==_0x257a8d&&(Jn['set'](_0x257a8d,_0x30b51e),Fi['set'](_0x30b51e,_0x257a8d)),_0x30b51e;}const Xn=_0xefe409=>Fi['get'](_0xefe409);function Vc(_0x6eb538,_0x2835f4,{blocked:_0x1081e8,upgrade:_0x5bf2eb,blocking:_0x4f4d9b,terminated:_0x430216}={}){const _0x1d4da8=indexedDB['open'](_0x6eb538,_0x2835f4),_0x49dbeb=_e(_0x1d4da8);return _0x5bf2eb&&_0x1d4da8['addEventListener']('upgradeneeded',_0xef3f98=>{_0x5bf2eb(_e(_0x1d4da8['result']),_0xef3f98['oldVersion'],_0xef3f98['newVersion'],_e(_0x1d4da8['transaction']),_0xef3f98);}),_0x1081e8&&_0x1d4da8['addEventListener']('blocked',_0x54ef4f=>_0x1081e8(_0x54ef4f['oldVersion'],_0x54ef4f['newVersion'],_0x54ef4f)),_0x49dbeb['then'](_0x41f903=>{_0x430216&&_0x41f903['addEventListener']('close',()=>_0x430216()),_0x4f4d9b&&_0x41f903['addEventListener']('versionchange',_0x1350eb=>_0x4f4d9b(_0x1350eb['oldVersion'],_0x1350eb['newVersion'],_0x1350eb));})['catch'](()=>{}),_0x49dbeb;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x16c3ec,_0x276f72){if(!(_0x16c3ec instanceof IDBDatabase&&!(_0x276f72 in _0x16c3ec)&&typeof _0x276f72=='string'))return;if(Zn['get'](_0x276f72))return Zn['get'](_0x276f72);const _0x5d10e3=_0x276f72['replace'](/FromIndex$/,''),_0x4195ed=_0x276f72!==_0x5d10e3,_0x53550b=$c['includes'](_0x5d10e3);if(!(_0x5d10e3 in(_0x4195ed?IDBIndex:IDBObjectStore)['prototype'])||!(_0x53550b||Hc['includes'](_0x5d10e3)))return;const _0x2fedfd=async function(_0x1d9f34,..._0x2c4b04){const _0x2f423a=this['transaction'](_0x1d9f34,_0x53550b?'readwrite':'readonly');let _0x2bb7e9=_0x2f423a['store'];return _0x4195ed&&(_0x2bb7e9=_0x2bb7e9['index'](_0x2c4b04['shift']())),(await Promise['all']([_0x2bb7e9[_0x5d10e3](..._0x2c4b04),_0x53550b&&_0x2f423a['done']]))[0x0];};return Zn['set'](_0x276f72,_0x2fedfd),_0x2fedfd;}Uc(_0x138d8c=>({..._0x138d8c,'get':(_0x2aabd4,_0x3d429c,_0x41d169)=>Os(_0x2aabd4,_0x3d429c)||_0x138d8c['get'](_0x2aabd4,_0x3d429c,_0x41d169),'has':(_0x5eec8e,_0x20acc1)=>!!Os(_0x5eec8e,_0x20acc1)||_0x138d8c['has'](_0x5eec8e,_0x20acc1)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x35718b){this['container']=_0x35718b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1db120=>{if(qc(_0x1db120)){const _0x496ab7=_0x1db120['getImmediate']();return _0x496ab7['library']+'/'+_0x496ab7['version'];}else return null;})['filter'](_0xd591c3=>_0xd591c3)['join']('\x20');}}function qc(_0x1e7821){const _0x5e8fc8=_0x1e7821['getComponent']();return(_0x5e8fc8==null?void 0x0:_0x5e8fc8['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x257801,_0x3a23d1){try{_0x257801['container']['addComponent'](_0x3a23d1);}catch(_0xd2d7ae){re['debug']('Component\x20'+_0x3a23d1['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x257801['name'],_0xd2d7ae);}}function et(_0x121d05){const _0x348220=_0x121d05['name'];if(gi['has'](_0x348220))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x348220+'.'),!0x1;gi['set'](_0x348220,_0x121d05);for(const _0x1d1a3b of Le['values']())Ms(_0x1d1a3b,_0x121d05);for(const _0x1b356d of _i['values']())Ms(_0x1b356d,_0x121d05);return!0x0;}function Ui(_0x2e94b5,_0x174b34){const _0x58e983=_0x2e94b5['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x58e983&&_0x58e983['triggerHeartbeat'](),_0x2e94b5['container']['getProvider'](_0x174b34);}function H(_0x479c88){return _0x479c88==null?!0x1:_0x479c88['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x533418,_0x58b483,_0x4fc715){this['_isDeleted']=!0x1,this['_options']={..._0x533418},this['_config']={..._0x58b483},this['_name']=_0x58b483['name'],this['_automaticDataCollectionEnabled']=_0x58b483['automaticDataCollectionEnabled'],this['_container']=_0x4fc715,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x37a473){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x37a473;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0xbc24e3){this['_isDeleted']=_0xbc24e3;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x100935,_0xf51f87={}){let _0x2942a3=_0x100935;typeof _0xf51f87!='object'&&(_0xf51f87={'name':_0xf51f87});const _0x5e93f4={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0xf51f87},_0x2c595e=_0x5e93f4['name'];if(typeof _0x2c595e!='string'||!_0x2c595e)throw ge['create']('bad-app-name',{'appName':String(_0x2c595e)});if(_0x2942a3||(_0x2942a3=$r()),!_0x2942a3)throw ge['create']('no-options');const _0x1742d4=Le['get'](_0x2c595e);if(_0x1742d4){if(De(_0x2942a3,_0x1742d4['options'])&&De(_0x5e93f4,_0x1742d4['config']))return _0x1742d4;throw ge['create']('duplicate-app',{'appName':_0x2c595e});}const _0x2b6a0a=new Ac(_0x2c595e);for(const _0x56a27b of gi['values']())_0x2b6a0a['addComponent'](_0x56a27b);const _0x4cd4ac=new Il(_0x2942a3,_0x5e93f4,_0x2b6a0a);return Le['set'](_0x2c595e,_0x4cd4ac),_0x4cd4ac;}function Qr(_0x6dd5eb=pi){const _0x11b082=Le['get'](_0x6dd5eb);if(!_0x11b082&&_0x6dd5eb===pi&&$r())return wl();if(!_0x11b082)throw ge['create']('no-app',{'appName':_0x6dd5eb});return _0x11b082;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5edc2b){let _0x3760dc=!0x1;const _0x36a873=_0x5edc2b['name'];Le['has'](_0x36a873)?(_0x3760dc=!0x0,Le['delete'](_0x36a873)):_i['has'](_0x36a873)&&_0x5edc2b['decRefCount']()<=0x0&&(_i['delete'](_0x36a873),_0x3760dc=!0x0),_0x3760dc&&(await Promise['all'](_0x5edc2b['container']['getProviders']()['map'](_0x35e806=>_0x35e806['delete']())),_0x5edc2b['isDeleted']=!0x0);}function me(_0x45e486,_0x4db7f8,_0x4565de){let _0x327420=vl[_0x45e486]??_0x45e486;_0x4565de&&(_0x327420+='-'+_0x4565de);const _0x4ab35e=_0x327420['match'](/\s|\//),_0x261b73=_0x4db7f8['match'](/\s|\//);if(_0x4ab35e||_0x261b73){const _0x5aaec0=['Unable\x20to\x20register\x20library\x20\x22'+_0x327420+'\x22\x20with\x20version\x20\x22'+_0x4db7f8+'\x22:'];_0x4ab35e&&_0x5aaec0['push']('library\x20name\x20\x22'+_0x327420+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4ab35e&&_0x261b73&&_0x5aaec0['push']('and'),_0x261b73&&_0x5aaec0['push']('version\x20name\x20\x22'+_0x4db7f8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5aaec0['join']('\x20'));return;}et(new Me(_0x327420+'-version',()=>({'library':_0x327420,'version':_0x4db7f8}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3bca21,_0x5c8761)=>{switch(_0x5c8761){case 0x0:try{_0x3bca21['createObjectStore'](Rt);}catch(_0x4b9b56){console['warn'](_0x4b9b56);}}}})['catch'](_0x5da697=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5da697['message']});})),ei;}async function Sl(_0x511e75){try{const _0x4e11dc=(await Jr())['transaction'](Rt),_0x5d3e8c=await _0x4e11dc['objectStore'](Rt)['get'](Xr(_0x511e75));return await _0x4e11dc['done'],_0x5d3e8c;}catch(_0x3eba7c){if(_0x3eba7c instanceof Se)re['warn'](_0x3eba7c['message']);else{const _0x1baa42=ge['create']('idb-get',{'originalErrorMessage':_0x3eba7c==null?void 0x0:_0x3eba7c['message']});re['warn'](_0x1baa42['message']);}}}async function Ls(_0x44e63c,_0x4e980b){try{const _0xf6ac3b=(await Jr())['transaction'](Rt,'readwrite');await _0xf6ac3b['objectStore'](Rt)['put'](_0x4e980b,Xr(_0x44e63c)),await _0xf6ac3b['done'];}catch(_0x5ac8c5){if(_0x5ac8c5 instanceof Se)re['warn'](_0x5ac8c5['message']);else{const _0x122337=ge['create']('idb-set',{'originalErrorMessage':_0x5ac8c5==null?void 0x0:_0x5ac8c5['message']});re['warn'](_0x122337['message']);}}}function Xr(_0x3ef424){return _0x3ef424['name']+'!'+_0x3ef424['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x56aa4c){this['container']=_0x56aa4c,this['_heartbeatsCache']=null;const _0x541511=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x541511),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1cedd1=>(this['_heartbeatsCache']=_0x1cedd1,_0x1cedd1));}async['triggerHeartbeat'](){var _0x2ab3e6,_0x57d7e9;try{const _0x571351=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xe057=xs();if(((_0x2ab3e6=this['_heartbeatsCache'])==null?void 0x0:_0x2ab3e6['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x57d7e9=this['_heartbeatsCache'])==null?void 0x0:_0x57d7e9['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xe057||this['_heartbeatsCache']['heartbeats']['some'](_0x404ffc=>_0x404ffc['date']===_0xe057))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xe057,'agent':_0x571351}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x5742f1=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5742f1,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x40c953){re['warn'](_0x40c953);}}async['getHeartbeatsHeader'](){var _0x4735e1;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4735e1=this['_heartbeatsCache'])==null?void 0x0:_0x4735e1['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x349a78=xs(),{heartbeatsToSend:_0x2322b9,unsentEntries:_0x31361a}=kl(this['_heartbeatsCache']['heartbeats']),_0x4341b1=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2322b9}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x349a78,_0x31361a['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x31361a,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4341b1;}catch(_0x1532f6){return re['warn'](_0x1532f6),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x16599c,_0x281f62=bl){const _0x27b417=[];let _0x4dd317=_0x16599c['slice']();for(const _0x7df9df of _0x16599c){const _0x42257f=_0x27b417['find'](_0x155ec7=>_0x155ec7['agent']===_0x7df9df['agent']);if(_0x42257f){if(_0x42257f['dates']['push'](_0x7df9df['date']),Fs(_0x27b417)>_0x281f62){_0x42257f['dates']['pop']();break;}}else{if(_0x27b417['push']({'agent':_0x7df9df['agent'],'dates':[_0x7df9df['date']]}),Fs(_0x27b417)>_0x281f62){_0x27b417['pop']();break;}}_0x4dd317=_0x4dd317['slice'](0x1);}return{'heartbeatsToSend':_0x27b417,'unsentEntries':_0x4dd317};}class Nl{constructor(_0x265a11){this['app']=_0x265a11,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xfefae4=await Sl(this['app']);return _0xfefae4!=null&&_0xfefae4['heartbeats']?_0xfefae4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x24c397){if(await this['_canUseIndexedDBPromise']){const _0x429826=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x24c397['lastSentHeartbeatDate']??_0x429826['lastSentHeartbeatDate'],'heartbeats':_0x24c397['heartbeats']});}else return;}async['add'](_0x3bdff8){if(await this['_canUseIndexedDBPromise']){const _0x10a381=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3bdff8['lastSentHeartbeatDate']??_0x10a381['lastSentHeartbeatDate'],'heartbeats':[..._0x10a381['heartbeats'],..._0x3bdff8['heartbeats']]});}else return;}}function Fs(_0x1316c6){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1316c6}))['length'];}function Pl(_0x21fc61){if(_0x21fc61['length']===0x0)return-0x1;let _0x45c8c2=0x0,_0x3799d2=_0x21fc61[0x0]['date'];for(let _0x2b8644=0x1;_0x2b8644<_0x21fc61['length'];_0x2b8644++)_0x21fc61[_0x2b8644]['date']<_0x3799d2&&(_0x3799d2=_0x21fc61[_0x2b8644]['date'],_0x45c8c2=_0x2b8644);return _0x45c8c2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4dbb6a){et(new Me('platform-logger',_0x1742bf=>new Gc(_0x1742bf),'PRIVATE')),et(new Me('heartbeat',_0x13feae=>new Al(_0x13feae),'PRIVATE')),me(fi,Ds,_0x4dbb6a),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x2ebf73){Zr=_0x2ebf73;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x599e03){this['domStorage_']=_0x599e03,this['prefix_']='firebase:';}['set'](_0x55438d,_0x3b2d9a){_0x3b2d9a==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x55438d)):this['domStorage_']['setItem'](this['prefixedName_'](_0x55438d),O(_0x3b2d9a));}['get'](_0x1606ea){const _0x13e39d=this['domStorage_']['getItem'](this['prefixedName_'](_0x1606ea));return _0x13e39d==null?null:bt(_0x13e39d);}['remove'](_0x2e751a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2e751a));}['prefixedName_'](_0x169b8a){return this['prefix_']+_0x169b8a;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x40bc72,_0xb67220){_0xb67220==null?delete this['cache_'][_0x40bc72]:this['cache_'][_0x40bc72]=_0xb67220;}['get'](_0x358923){return Y(this['cache_'],_0x358923)?this['cache_'][_0x358923]:null;}['remove'](_0x2b74a0){delete this['cache_'][_0x2b74a0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x41f4e8){try{if(typeof window<'u'&&typeof window[_0x41f4e8]<'u'){const _0x3f7f84=window[_0x41f4e8];return _0x3f7f84['setItem']('firebase:sentinel','cache'),_0x3f7f84['removeItem']('firebase:sentinel'),new xl(_0x3f7f84);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x311adb=0x1;return function(){return _0x311adb++;};}()),no=function(_0xef28fd){const _0x2efe2c=Tc(_0xef28fd),_0x61dccc=new Ec();_0x61dccc['update'](_0x2efe2c);const _0x1d4fc7=_0x61dccc['digest']();return Di['encodeByteArray'](_0x1d4fc7);},Bt=function(..._0x4b45f6){let _0x30cafb='';for(let _0xf00e7d=0x0;_0xf00e7d<_0x4b45f6['length'];_0xf00e7d++){const _0xfe2e35=_0x4b45f6[_0xf00e7d];Array['isArray'](_0xfe2e35)||_0xfe2e35&&typeof _0xfe2e35=='object'&&typeof _0xfe2e35['length']=='number'?_0x30cafb+=Bt['apply'](null,_0xfe2e35):typeof _0xfe2e35=='object'?_0x30cafb+=O(_0xfe2e35):_0x30cafb+=_0xfe2e35,_0x30cafb+='\x20';}return _0x30cafb;};let Et=null,Vs=!0x0;const Wl=function(_0xe36050,_0x4477a6){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x572034){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x43c9e4=Bt['apply'](null,_0x572034);Et(_0x43c9e4);}},Vt=function(_0x29b5c0){return function(..._0x5baccf){L(_0x29b5c0,..._0x5baccf);};},mi=function(..._0x1bb14a){const _0x5e82c0='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x1bb14a);Qe['error'](_0x5e82c0);},oe=function(..._0x52de5c){const _0x5ad158='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x52de5c);throw Qe['error'](_0x5ad158),new Error(_0x5ad158);},U=function(..._0xdf360e){const _0x152745='FIREBASE\x20WARNING:\x20'+Bt(..._0xdf360e);Qe['warn'](_0x152745);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x1c8237){return typeof _0x1c8237=='number'&&(_0x1c8237!==_0x1c8237||_0x1c8237===Number['POSITIVE_INFINITY']||_0x1c8237===Number['NEGATIVE_INFINITY']);},Vl=function(_0x586eb1){if(document['readyState']==='complete')_0x586eb1();else{let _0x1a8991=!0x1;const _0x41e431=function(){if(!document['body']){setTimeout(_0x41e431,Math['floor'](0xa));return;}_0x1a8991||(_0x1a8991=!0x0,_0x586eb1());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x41e431,!0x1),window['addEventListener']('load',_0x41e431,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x41e431();}),window['attachEvent']('onload',_0x41e431));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x1d422c,_0x3f8ef2){if(_0x1d422c===_0x3f8ef2)return 0x0;if(_0x1d422c===xe||_0x3f8ef2===Ie)return-0x1;if(_0x3f8ef2===xe||_0x1d422c===Ie)return 0x1;{const _0x22d462=Hs(_0x1d422c),_0xc020d9=Hs(_0x3f8ef2);return _0x22d462!==null?_0xc020d9!==null?_0x22d462-_0xc020d9===0x0?_0x1d422c['length']-_0x3f8ef2['length']:_0x22d462-_0xc020d9:-0x1:_0xc020d9!==null?0x1:_0x1d422c<_0x3f8ef2?-0x1:0x1;}},Hl=function(_0x58d6ef,_0x3a4184){return _0x58d6ef===_0x3a4184?0x0:_0x58d6ef<_0x3a4184?-0x1:0x1;},pt=function(_0x13c806,_0x52c1e2){if(_0x52c1e2&&_0x13c806 in _0x52c1e2)return _0x52c1e2[_0x13c806];throw new Error('Missing\x20required\x20key\x20('+_0x13c806+')\x20in\x20object:\x20'+O(_0x52c1e2));},Bi=function(_0x5e436f){if(typeof _0x5e436f!='object'||_0x5e436f===null)return O(_0x5e436f);const _0x568aec=[];for(const _0x4ec241 in _0x5e436f)_0x568aec['push'](_0x4ec241);_0x568aec['sort']();let _0x32c499='{';for(let _0xbd4a0d=0x0;_0xbd4a0d<_0x568aec['length'];_0xbd4a0d++)_0xbd4a0d!==0x0&&(_0x32c499+=','),_0x32c499+=O(_0x568aec[_0xbd4a0d]),_0x32c499+=':',_0x32c499+=Bi(_0x5e436f[_0x568aec[_0xbd4a0d]]);return _0x32c499+='}',_0x32c499;},io=function(_0x4b31b0,_0x2057ae){const _0x8478c2=_0x4b31b0['length'];if(_0x8478c2<=_0x2057ae)return[_0x4b31b0];const _0x263f8d=[];for(let _0xee17b5=0x0;_0xee17b5<_0x8478c2;_0xee17b5+=_0x2057ae)_0xee17b5+_0x2057ae>_0x8478c2?_0x263f8d['push'](_0x4b31b0['substring'](_0xee17b5,_0x8478c2)):_0x263f8d['push'](_0x4b31b0['substring'](_0xee17b5,_0xee17b5+_0x2057ae));return _0x263f8d;};function x(_0x2bd64c,_0x44cea3){for(const _0x2413d0 in _0x2bd64c)_0x2bd64c['hasOwnProperty'](_0x2413d0)&&_0x44cea3(_0x2413d0,_0x2bd64c[_0x2413d0]);}const so=function(_0x506caf){f(!Wi(_0x506caf),'Invalid\x20JSON\x20number');const _0xea61bb=0xb,_0x5908b9=0x34,_0x3a5c15=(0x1<<_0xea61bb-0x1)-0x1;let _0x2f74f7,_0x5e15da,_0x7cc646,_0x299506,_0x37afc6;_0x506caf===0x0?(_0x5e15da=0x0,_0x7cc646=0x0,_0x2f74f7=0x1/_0x506caf===-0x1/0x0?0x1:0x0):(_0x2f74f7=_0x506caf<0x0,_0x506caf=Math['abs'](_0x506caf),_0x506caf>=Math['pow'](0x2,0x1-_0x3a5c15)?(_0x299506=Math['min'](Math['floor'](Math['log'](_0x506caf)/Math['LN2']),_0x3a5c15),_0x5e15da=_0x299506+_0x3a5c15,_0x7cc646=Math['round'](_0x506caf*Math['pow'](0x2,_0x5908b9-_0x299506)-Math['pow'](0x2,_0x5908b9))):(_0x5e15da=0x0,_0x7cc646=Math['round'](_0x506caf/Math['pow'](0x2,0x1-_0x3a5c15-_0x5908b9))));const _0xbef7b3=[];for(_0x37afc6=_0x5908b9;_0x37afc6;_0x37afc6-=0x1)_0xbef7b3['push'](_0x7cc646%0x2?0x1:0x0),_0x7cc646=Math['floor'](_0x7cc646/0x2);for(_0x37afc6=_0xea61bb;_0x37afc6;_0x37afc6-=0x1)_0xbef7b3['push'](_0x5e15da%0x2?0x1:0x0),_0x5e15da=Math['floor'](_0x5e15da/0x2);_0xbef7b3['push'](_0x2f74f7?0x1:0x0),_0xbef7b3['reverse']();const _0x1959b9=_0xbef7b3['join']('');let _0x56970b='';for(_0x37afc6=0x0;_0x37afc6<0x40;_0x37afc6+=0x8){let _0x519741=parseInt(_0x1959b9['substr'](_0x37afc6,0x8),0x2)['toString'](0x10);_0x519741['length']===0x1&&(_0x519741='0'+_0x519741),_0x56970b=_0x56970b+_0x519741;}return _0x56970b['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x100cc8,_0x3796a1){let _0x595faa='Unknown\x20Error';_0x100cc8==='too_big'?_0x595faa='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x100cc8==='permission_denied'?_0x595faa='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x100cc8==='unavailable'&&(_0x595faa='The\x20service\x20is\x20unavailable');const _0x1e2d1d=new Error(_0x100cc8+'\x20at\x20'+_0x3796a1['_path']['toString']()+':\x20'+_0x595faa);return _0x1e2d1d['code']=_0x100cc8['toUpperCase'](),_0x1e2d1d;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x1b9bd4){if(zl['test'](_0x1b9bd4)){const _0xd4e8c6=Number(_0x1b9bd4);if(_0xd4e8c6>=jl&&_0xd4e8c6<=Kl)return _0xd4e8c6;}return null;},lt=function(_0x2683a6){try{_0x2683a6();}catch(_0x270c5){setTimeout(()=>{const _0x3219f3=_0x270c5['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x3219f3),_0x270c5;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3437e1,_0x156d11){const _0x5f5c7c=setTimeout(_0x3437e1,_0x156d11);return typeof _0x5f5c7c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5f5c7c):typeof _0x5f5c7c=='object'&&_0x5f5c7c['unref']&&_0x5f5c7c['unref'](),_0x5f5c7c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0xab7487,_0xa22c15){this['appCheckProvider']=_0xa22c15,this['appName']=_0xab7487['name'],H(_0xab7487)&&_0xab7487['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xab7487['settings']['appCheckToken']),this['appCheck']=_0xa22c15==null?void 0x0:_0xa22c15['getImmediate']({'optional':!0x0}),this['appCheck']||_0xa22c15==null||_0xa22c15['get']()['then'](_0x5cadb5=>this['appCheck']=_0x5cadb5);}['getToken'](_0x3f31cc){if(this['serverAppAppCheckToken']){if(_0x3f31cc)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3f31cc):new Promise((_0x36e502,_0x18241c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3f31cc)['then'](_0x36e502,_0x18241c):_0x36e502(null);},0x0);});}['addTokenChangeListener'](_0x1165c9){var _0x136953;(_0x136953=this['appCheckProvider'])==null||_0x136953['get']()['then'](_0x46ca2c=>_0x46ca2c['addTokenListener'](_0x1165c9));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1422e9,_0x597de5,_0x515171){this['appName_']=_0x1422e9,this['firebaseOptions_']=_0x597de5,this['authProvider_']=_0x515171,this['auth_']=null,this['auth_']=_0x515171['getImmediate']({'optional':!0x0}),this['auth_']||_0x515171['onInit'](_0x1a9d0e=>this['auth_']=_0x1a9d0e);}['getToken'](_0xefe386){return this['auth_']?this['auth_']['getToken'](_0xefe386)['catch'](_0x15ac3f=>_0x15ac3f&&_0x15ac3f['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x15ac3f)):new Promise((_0x4d3ec6,_0x1bcc04)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xefe386)['then'](_0x4d3ec6,_0x1bcc04):_0x4d3ec6(null);},0x0);});}['addTokenChangeListener'](_0x3afea2){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3afea2):this['authProvider_']['get']()['then'](_0x31cb91=>_0x31cb91['addAuthTokenListener'](_0x3afea2));}['removeTokenChangeListener'](_0x43fda9){this['authProvider_']['get']()['then'](_0x19598e=>_0x19598e['removeAuthTokenListener'](_0x43fda9));}['notifyForInvalidToken'](){let _0x573107='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x573107+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x573107+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x573107+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x573107);}}class tn{constructor(_0x359a92){this['accessToken']=_0x359a92;}['getToken'](_0x26be23){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5bfc99){_0x5bfc99(this['accessToken']);}['removeTokenChangeListener'](_0x5cb2ed){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1bdc9d,_0x19e4d0,_0x2704ef,_0x5ddc5e,_0x5c123c=!0x1,_0x5b4e46='',_0x167847=!0x1,_0x3bfa16=!0x1,_0x4792f7=null){this['secure']=_0x19e4d0,this['namespace']=_0x2704ef,this['webSocketOnly']=_0x5ddc5e,this['nodeAdmin']=_0x5c123c,this['persistenceKey']=_0x5b4e46,this['includeNamespaceInQueryParams']=_0x167847,this['isUsingEmulator']=_0x3bfa16,this['emulatorOptions']=_0x4792f7,this['_host']=_0x1bdc9d['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1bdc9d)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2a256e){_0x2a256e!==this['internalHost']&&(this['internalHost']=_0x2a256e,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3731a4=this['toURLString']();return this['persistenceKey']&&(_0x3731a4+='<'+this['persistenceKey']+'>'),_0x3731a4;}['toURLString'](){const _0x3ad09c=this['secure']?'https://':'http://',_0x2fe2e3=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3ad09c+this['host']+'/'+_0x2fe2e3;}}function Xl(_0x356d82){return _0x356d82['host']!==_0x356d82['internalHost']||_0x356d82['isCustomHost']()||_0x356d82['includeNamespaceInQueryParams'];}function go(_0x590879,_0x285eb4,_0x1fc380){f(typeof _0x285eb4=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1fc380=='object','typeof\x20params\x20must\x20==\x20object');let _0x4f4ed4;if(_0x285eb4===fo)_0x4f4ed4=(_0x590879['secure']?'wss://':'ws://')+_0x590879['internalHost']+'/.ws?';else{if(_0x285eb4===po)_0x4f4ed4=(_0x590879['secure']?'https://':'http://')+_0x590879['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x285eb4);}Xl(_0x590879)&&(_0x1fc380['ns']=_0x590879['namespace']);const _0x5c0564=[];return x(_0x1fc380,(_0x580bfe,_0x392841)=>{_0x5c0564['push'](_0x580bfe+'='+_0x392841);}),_0x4f4ed4+_0x5c0564['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x2d13fe,_0x585ac3=0x1){Y(this['counters_'],_0x2d13fe)||(this['counters_'][_0x2d13fe]=0x0),this['counters_'][_0x2d13fe]+=_0x585ac3;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x488c7d){const _0x12ea98=_0x488c7d['toString']();return ti[_0x12ea98]||(ti[_0x12ea98]=new Zl()),ti[_0x12ea98];}function eh(_0x48dd57,_0x1e365f){const _0x56556a=_0x48dd57['toString']();return ni[_0x56556a]||(ni[_0x56556a]=_0x1e365f()),ni[_0x56556a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x11473a){this['onMessage_']=_0x11473a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5428c2,_0x10d3de){this['closeAfterResponse']=_0x5428c2,this['onClose']=_0x10d3de,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x41f1bc,_0x4fb4e0){for(this['pendingResponses'][_0x41f1bc]=_0x4fb4e0;this['pendingResponses'][this['currentResponseNum']];){const _0xd5dd94=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4fc4f2=0x0;_0x4fc4f2<_0xd5dd94['length'];++_0x4fc4f2)_0xd5dd94[_0x4fc4f2]&&lt(()=>{this['onMessage_'](_0xd5dd94[_0x4fc4f2]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x468c52,_0x10930f,_0x7ea79f,_0x45cfb2,_0x5946f7,_0x5194ff,_0x49e5c5){this['connId']=_0x468c52,this['repoInfo']=_0x10930f,this['applicationId']=_0x7ea79f,this['appCheckToken']=_0x45cfb2,this['authToken']=_0x5946f7,this['transportSessionId']=_0x5194ff,this['lastSessionId']=_0x49e5c5,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x468c52),this['stats_']=Hi(_0x10930f),this['urlFn']=_0x180132=>(this['appCheckToken']&&(_0x180132[yi]=this['appCheckToken']),go(_0x10930f,po,_0x180132));}['open'](_0x7dcddb,_0x242a88){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x242a88,this['myPacketOrderer']=new th(_0x7dcddb),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x46f032)=>{const [_0x23a489,_0x1774ff,_0x4a1991,_0x527841,_0x22529b]=_0x46f032;if(this['incrementIncomingBytes_'](_0x46f032),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x23a489===$s)this['id']=_0x1774ff,this['password']=_0x4a1991;else{if(_0x23a489===nh)_0x1774ff?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1774ff,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x23a489);}}},(..._0x248f9e)=>{const [_0x4bcf9b,_0x2be751]=_0x248f9e;this['incrementIncomingBytes_'](_0x248f9e),this['myPacketOrderer']['handleResponse'](_0x4bcf9b,_0x2be751);},()=>{this['onClosed_']();},this['urlFn']);const _0xfbc73c={};_0xfbc73c[$s]='t',_0xfbc73c[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xfbc73c[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xfbc73c[ro]=Vi,this['transportSessionId']&&(_0xfbc73c[oo]=this['transportSessionId']),this['lastSessionId']&&(_0xfbc73c[ho]=this['lastSessionId']),this['applicationId']&&(_0xfbc73c[uo]=this['applicationId']),this['appCheckToken']&&(_0xfbc73c[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xfbc73c[ao]=co);const _0x55c74e=this['urlFn'](_0xfbc73c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x55c74e),this['scriptTagHolder']['addTag'](_0x55c74e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x38fdc3){const _0xd58773=O(_0x38fdc3);this['bytesSent']+=_0xd58773['length'],this['stats_']['incrementCounter']('bytes_sent',_0xd58773['length']);const _0x11b4ef=Br(_0xd58773),_0x5da899=io(_0x11b4ef,hh);for(let _0x3dc330=0x0;_0x3dc330<_0x5da899['length'];_0x3dc330++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5da899['length'],_0x5da899[_0x3dc330]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1059ab,_0x492c37){this['myDisconnFrame']=document['createElement']('iframe');const _0x56ba93={};_0x56ba93[lh]='t',_0x56ba93[mo]=_0x1059ab,_0x56ba93[yo]=_0x492c37,this['myDisconnFrame']['src']=this['urlFn'](_0x56ba93),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x41a85d){const _0x1ff9c6=O(_0x41a85d)['length'];this['bytesReceived']+=_0x1ff9c6,this['stats_']['incrementCounter']('bytes_received',_0x1ff9c6);}}class $i{constructor(_0x504707,_0x4bdaaa,_0x38c935,_0x5868f5){this['onDisconnect']=_0x38c935,this['urlFn']=_0x5868f5,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x504707,window[sh+this['uniqueCallbackIdentifier']]=_0x4bdaaa,this['myIFrame']=$i['createIFrame_']();let _0x471fc7='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x471fc7='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4394ff='<html><body>'+_0x471fc7+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4394ff),this['myIFrame']['doc']['close']();}catch(_0x418e9b){L('frame\x20writing\x20exception'),_0x418e9b['stack']&&L(_0x418e9b['stack']),L(_0x418e9b);}}}static['createIFrame_'](){const _0x4571bc=document['createElement']('iframe');if(_0x4571bc['style']['display']='none',document['body']){document['body']['appendChild'](_0x4571bc);try{_0x4571bc['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x312e70=document['domain'];_0x4571bc['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x312e70+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4571bc['contentDocument']?_0x4571bc['doc']=_0x4571bc['contentDocument']:_0x4571bc['contentWindow']?_0x4571bc['doc']=_0x4571bc['contentWindow']['document']:_0x4571bc['document']&&(_0x4571bc['doc']=_0x4571bc['document']),_0x4571bc;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1f3ffb=this['onDisconnect'];_0x1f3ffb&&(this['onDisconnect']=null,_0x1f3ffb());}['startLongPoll'](_0x1aa7bd,_0x450864){for(this['myID']=_0x1aa7bd,this['myPW']=_0x450864,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x43eff3={};_0x43eff3[mo]=this['myID'],_0x43eff3[yo]=this['myPW'],_0x43eff3[vo]=this['currentSerial'];let _0x2dfcc7=this['urlFn'](_0x43eff3),_0x3bcdba='',_0x14d004=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x3bcdba['length']<=Eo;){const _0x2a5d99=this['pendingSegs']['shift']();_0x3bcdba=_0x3bcdba+'&'+oh+_0x14d004+'='+_0x2a5d99['seg']+'&'+ah+_0x14d004+'='+_0x2a5d99['ts']+'&'+ch+_0x14d004+'='+_0x2a5d99['d'],_0x14d004++;}return _0x2dfcc7=_0x2dfcc7+_0x3bcdba,this['addLongPollTag_'](_0x2dfcc7,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x156bfc,_0x16d58a,_0xab3516){this['pendingSegs']['push']({'seg':_0x156bfc,'ts':_0x16d58a,'d':_0xab3516}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xf92d9f,_0x52cfa9){this['outstandingRequests']['add'](_0x52cfa9);const _0xc0aaac=()=>{this['outstandingRequests']['delete'](_0x52cfa9),this['newRequest_']();},_0x2bc9e5=setTimeout(_0xc0aaac,Math['floor'](uh)),_0x790aca=()=>{clearTimeout(_0x2bc9e5),_0xc0aaac();};this['addTag'](_0xf92d9f,_0x790aca);}['addTag'](_0x5c8c87,_0x12b72d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5e11b7=this['myIFrame']['doc']['createElement']('script');_0x5e11b7['type']='text/javascript',_0x5e11b7['async']=!0x0,_0x5e11b7['src']=_0x5c8c87,_0x5e11b7['onload']=_0x5e11b7['onreadystatechange']=function(){const _0x127eb5=_0x5e11b7['readyState'];(!_0x127eb5||_0x127eb5==='loaded'||_0x127eb5==='complete')&&(_0x5e11b7['onload']=_0x5e11b7['onreadystatechange']=null,_0x5e11b7['parentNode']&&_0x5e11b7['parentNode']['removeChild'](_0x5e11b7),_0x12b72d());},_0x5e11b7['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5c8c87),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5e11b7);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x512d08,_0x19a483,_0x6a5328,_0x2f4392,_0x221de5,_0x290e66,_0x256c80){this['connId']=_0x512d08,this['applicationId']=_0x6a5328,this['appCheckToken']=_0x2f4392,this['authToken']=_0x221de5,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x19a483),this['connURL']=G['connectionURL_'](_0x19a483,_0x290e66,_0x256c80,_0x2f4392,_0x6a5328),this['nodeAdmin']=_0x19a483['nodeAdmin'];}static['connectionURL_'](_0xe94f39,_0x59e8fc,_0x50db88,_0x1e7206,_0x4e0820){const _0x4cf39f={};return _0x4cf39f[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4cf39f[ao]=co),_0x59e8fc&&(_0x4cf39f[oo]=_0x59e8fc),_0x50db88&&(_0x4cf39f[ho]=_0x50db88),_0x1e7206&&(_0x4cf39f[yi]=_0x1e7206),_0x4e0820&&(_0x4cf39f[uo]=_0x4e0820),go(_0xe94f39,fo,_0x4cf39f);}['open'](_0x29728b,_0x43acf6){this['onDisconnect']=_0x43acf6,this['onMessage']=_0x29728b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x5eae3f;dc(),this['mySock']=new hn(this['connURL'],[],_0x5eae3f);}catch(_0xee2c44){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x189052=_0xee2c44['message']||_0xee2c44['data'];_0x189052&&this['log_'](_0x189052),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x220f47=>{this['handleIncomingFrame'](_0x220f47);},this['mySock']['onerror']=_0x2b5da5=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x194b24=_0x2b5da5['message']||_0x2b5da5['data'];_0x194b24&&this['log_'](_0x194b24),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x340ef3=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x31e680=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x47c29a=navigator['userAgent']['match'](_0x31e680);_0x47c29a&&_0x47c29a['length']>0x1&&parseFloat(_0x47c29a[0x1])<4.4&&(_0x340ef3=!0x0);}return!_0x340ef3&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x780c48){if(this['frames']['push'](_0x780c48),this['frames']['length']===this['totalFrames']){const _0x471ccf=this['frames']['join']('');this['frames']=null;const _0x1f7043=bt(_0x471ccf);this['onMessage'](_0x1f7043);}}['handleNewFrameCount_'](_0x5c6854){this['totalFrames']=_0x5c6854,this['frames']=[];}['extractFrameCount_'](_0x42bf7b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x42bf7b['length']<=0x6){const _0x4bf056=Number(_0x42bf7b);if(!isNaN(_0x4bf056))return this['handleNewFrameCount_'](_0x4bf056),null;}return this['handleNewFrameCount_'](0x1),_0x42bf7b;}['handleIncomingFrame'](_0x5ae275){if(this['mySock']===null)return;const _0x4052c3=_0x5ae275['data'];if(this['bytesReceived']+=_0x4052c3['length'],this['stats_']['incrementCounter']('bytes_received',_0x4052c3['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4052c3);else{const _0x22ec65=this['extractFrameCount_'](_0x4052c3);_0x22ec65!==null&&this['appendFrame_'](_0x22ec65);}}['send'](_0x541161){this['resetKeepAlive']();const _0x5c1e11=O(_0x541161);this['bytesSent']+=_0x5c1e11['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5c1e11['length']);const _0x311ed7=io(_0x5c1e11,fh);_0x311ed7['length']>0x1&&this['sendString_'](String(_0x311ed7['length']));for(let _0x19ca9d=0x0;_0x19ca9d<_0x311ed7['length'];_0x19ca9d++)this['sendString_'](_0x311ed7[_0x19ca9d]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x232776){try{this['mySock']['send'](_0x232776);}catch(_0x1b591a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1b591a['message']||_0x1b591a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2178b5){this['initTransports_'](_0x2178b5);}['initTransports_'](_0x5214d4){const _0x56ccbf=G&&G['isAvailable']();let _0x4e13c8=_0x56ccbf&&!G['previouslyFailed']();if(_0x5214d4['webSocketOnly']&&(_0x56ccbf||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4e13c8=!0x0),_0x4e13c8)this['transports_']=[G];else{const _0x49e378=this['transports_']=[];for(const _0x1fa191 of At['ALL_TRANSPORTS'])_0x1fa191&&_0x1fa191['isAvailable']()&&_0x49e378['push'](_0x1fa191);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x3fa91f,_0x1bd212,_0xd03e30,_0x424f37,_0x33a78b,_0x2553b1,_0x339e0e,_0x2c353b,_0x310362,_0x22ed9b){this['id']=_0x3fa91f,this['repoInfo_']=_0x1bd212,this['applicationId_']=_0xd03e30,this['appCheckToken_']=_0x424f37,this['authToken_']=_0x33a78b,this['onMessage_']=_0x2553b1,this['onReady_']=_0x339e0e,this['onDisconnect_']=_0x2c353b,this['onKill_']=_0x310362,this['lastSessionId']=_0x22ed9b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x1bd212),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x159174=this['transportManager_']['initialTransport']();this['conn_']=new _0x159174(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x159174['responsesRequiredToBeHealthy']||0x0;const _0x30cf92=this['connReceiver_'](this['conn_']),_0x59a37f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x30cf92,_0x59a37f);},Math['floor'](0x0));const _0x2e4c4f=_0x159174['healthyTimeout']||0x0;_0x2e4c4f>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2e4c4f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1844e8){return _0x1d91ae=>{_0x1844e8===this['conn_']?this['onConnectionLost_'](_0x1d91ae):_0x1844e8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1b0ff0){return _0xca66d4=>{this['state_']!==0x2&&(_0x1b0ff0===this['rx_']?this['onPrimaryMessageReceived_'](_0xca66d4):_0x1b0ff0===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xca66d4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3dfb5f){const _0x1233c3={'t':'d','d':_0x3dfb5f};this['sendData_'](_0x1233c3);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1aefe7){if(ii in _0x1aefe7){const _0x58a71b=_0x1aefe7[ii];_0x58a71b===js?this['upgradeIfSecondaryHealthy_']():_0x58a71b===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x58a71b===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3c9f2a){const _0x11e5f6=pt('t',_0x3c9f2a),_0x4df22b=pt('d',_0x3c9f2a);if(_0x11e5f6==='c')this['onSecondaryControl_'](_0x4df22b);else{if(_0x11e5f6==='d')this['pendingDataMessages']['push'](_0x4df22b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x11e5f6);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3ca82f){const _0x2625c7=pt('t',_0x3ca82f),_0xefe21e=pt('d',_0x3ca82f);_0x2625c7==='c'?this['onControl_'](_0xefe21e):_0x2625c7==='d'&&this['onDataMessage_'](_0xefe21e);}['onDataMessage_'](_0x4c1681){this['onPrimaryResponse_'](),this['onMessage_'](_0x4c1681);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5dda3a){const _0x2dc306=pt(ii,_0x5dda3a);if(Gs in _0x5dda3a){const _0x1bbc13=_0x5dda3a[Gs];if(_0x2dc306===Ih){const _0x64cb4={..._0x1bbc13};this['repoInfo_']['isUsingEmulator']&&(_0x64cb4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x64cb4);}else{if(_0x2dc306===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1fdb09=0x0;_0x1fdb09<this['pendingDataMessages']['length'];++_0x1fdb09)this['onDataMessage_'](this['pendingDataMessages'][_0x1fdb09]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2dc306===vh?this['onConnectionShutdown_'](_0x1bbc13):_0x2dc306===qs?this['onReset_'](_0x1bbc13):_0x2dc306===Eh?mi('Server\x20Error:\x20'+_0x1bbc13):_0x2dc306===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x2dc306);}}}['onHandshake_'](_0x2dc901){const _0x310e7f=_0x2dc901['ts'],_0x369345=_0x2dc901['v'],_0x126fbe=_0x2dc901['h'];this['sessionId']=_0x2dc901['s'],this['repoInfo_']['host']=_0x126fbe,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x310e7f),Vi!==_0x369345&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x517150=this['transportManager_']['upgradeTransport']();_0x517150&&this['startUpgrade_'](_0x517150);}['startUpgrade_'](_0x423148){this['secondaryConn_']=new _0x423148(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x423148['responsesRequiredToBeHealthy']||0x0;const _0x284877=this['connReceiver_'](this['secondaryConn_']),_0x18d0d9=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x284877,_0x18d0d9),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x1c0daa){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1c0daa),this['repoInfo_']['host']=_0x1c0daa,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3aa586,_0x3c01f2){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3aa586,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3c01f2,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x6070ce=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x6070ce||this['rx_']===_0x6070ce)&&this['close']();}['onConnectionLost_'](_0xf2c605){this['conn_']=null,!_0xf2c605&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5520cc){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5520cc),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x297b85){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x297b85);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0xa888f6,_0xde78cb,_0x1dad65,_0x196642){}['merge'](_0x55749a,_0x548006,_0x15d29e,_0x5a683){}['refreshAuthToken'](_0x1acd9b){}['refreshAppCheckToken'](_0x41cf57){}['onDisconnectPut'](_0x5e2ed8,_0x153102,_0x46e8c6){}['onDisconnectMerge'](_0x13eb08,_0x931af4,_0x142525){}['onDisconnectCancel'](_0x626fb9,_0xe9539a){}['reportStats'](_0x52dc1f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x196f74){this['allowedEvents_']=_0x196f74,this['listeners_']={},f(Array['isArray'](_0x196f74)&&_0x196f74['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2af81a,..._0x3669e7){if(Array['isArray'](this['listeners_'][_0x2af81a])){const _0x25a2c9=[...this['listeners_'][_0x2af81a]];for(let _0x202973=0x0;_0x202973<_0x25a2c9['length'];_0x202973++)_0x25a2c9[_0x202973]['callback']['apply'](_0x25a2c9[_0x202973]['context'],_0x3669e7);}}['on'](_0x205d1c,_0x395c50,_0x5497cf){this['validateEventType_'](_0x205d1c),this['listeners_'][_0x205d1c]=this['listeners_'][_0x205d1c]||[],this['listeners_'][_0x205d1c]['push']({'callback':_0x395c50,'context':_0x5497cf});const _0x71cd8a=this['getInitialEvent'](_0x205d1c);_0x71cd8a&&_0x395c50['apply'](_0x5497cf,_0x71cd8a);}['off'](_0x5a184f,_0x2eb42d,_0x49d362){this['validateEventType_'](_0x5a184f);const _0x46e1c6=this['listeners_'][_0x5a184f]||[];for(let _0x2fe6b9=0x0;_0x2fe6b9<_0x46e1c6['length'];_0x2fe6b9++)if(_0x46e1c6[_0x2fe6b9]['callback']===_0x2eb42d&&(!_0x49d362||_0x49d362===_0x46e1c6[_0x2fe6b9]['context'])){_0x46e1c6['splice'](_0x2fe6b9,0x1);return;}}['validateEventType_'](_0x2b1a78){f(this['allowedEvents_']['find'](_0x2e031e=>_0x2e031e===_0x2b1a78),'Unknown\x20event:\x20'+_0x2b1a78);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x61ee1a){return f(_0x61ee1a==='online','Unknown\x20event\x20type:\x20'+_0x61ee1a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x43589d,_0x36fda6){if(_0x36fda6===void 0x0){this['pieces_']=_0x43589d['split']('/');let _0x2d5686=0x0;for(let _0x532c07=0x0;_0x532c07<this['pieces_']['length'];_0x532c07++)this['pieces_'][_0x532c07]['length']>0x0&&(this['pieces_'][_0x2d5686]=this['pieces_'][_0x532c07],_0x2d5686++);this['pieces_']['length']=_0x2d5686,this['pieceNum_']=0x0;}else this['pieces_']=_0x43589d,this['pieceNum_']=_0x36fda6;}['toString'](){let _0x423e35='';for(let _0x24bc69=this['pieceNum_'];_0x24bc69<this['pieces_']['length'];_0x24bc69++)this['pieces_'][_0x24bc69]!==''&&(_0x423e35+='/'+this['pieces_'][_0x24bc69]);return _0x423e35||'/';}}function w(){return new C('');}function y(_0x549734){return _0x549734['pieceNum_']>=_0x549734['pieces_']['length']?null:_0x549734['pieces_'][_0x549734['pieceNum_']];}function we(_0xbe5653){return _0xbe5653['pieces_']['length']-_0xbe5653['pieceNum_'];}function b(_0x102308){let _0x5717ba=_0x102308['pieceNum_'];return _0x5717ba<_0x102308['pieces_']['length']&&_0x5717ba++,new C(_0x102308['pieces_'],_0x5717ba);}function Gi(_0xf75bf8){return _0xf75bf8['pieceNum_']<_0xf75bf8['pieces_']['length']?_0xf75bf8['pieces_'][_0xf75bf8['pieces_']['length']-0x1]:null;}function Ch(_0x30dc81){let _0x286b11='';for(let _0x5b9933=_0x30dc81['pieceNum_'];_0x5b9933<_0x30dc81['pieces_']['length'];_0x5b9933++)_0x30dc81['pieces_'][_0x5b9933]!==''&&(_0x286b11+='/'+encodeURIComponent(String(_0x30dc81['pieces_'][_0x5b9933])));return _0x286b11||'/';}function kt(_0x566d67,_0x303631=0x0){return _0x566d67['pieces_']['slice'](_0x566d67['pieceNum_']+_0x303631);}function To(_0x1b8bcd){if(_0x1b8bcd['pieceNum_']>=_0x1b8bcd['pieces_']['length'])return null;const _0x48bd5d=[];for(let _0x227589=_0x1b8bcd['pieceNum_'];_0x227589<_0x1b8bcd['pieces_']['length']-0x1;_0x227589++)_0x48bd5d['push'](_0x1b8bcd['pieces_'][_0x227589]);return new C(_0x48bd5d,0x0);}function A(_0x4f6972,_0x31f788){const _0x291e95=[];for(let _0x402e05=_0x4f6972['pieceNum_'];_0x402e05<_0x4f6972['pieces_']['length'];_0x402e05++)_0x291e95['push'](_0x4f6972['pieces_'][_0x402e05]);if(_0x31f788 instanceof C){for(let _0x50419b=_0x31f788['pieceNum_'];_0x50419b<_0x31f788['pieces_']['length'];_0x50419b++)_0x291e95['push'](_0x31f788['pieces_'][_0x50419b]);}else{const _0x124a4b=_0x31f788['split']('/');for(let _0x3396d4=0x0;_0x3396d4<_0x124a4b['length'];_0x3396d4++)_0x124a4b[_0x3396d4]['length']>0x0&&_0x291e95['push'](_0x124a4b[_0x3396d4]);}return new C(_0x291e95,0x0);}function v(_0x3d0bd9){return _0x3d0bd9['pieceNum_']>=_0x3d0bd9['pieces_']['length'];}function F(_0x1b56c8,_0x247860){const _0x2676ea=y(_0x1b56c8),_0x4f38=y(_0x247860);if(_0x2676ea===null)return _0x247860;if(_0x2676ea===_0x4f38)return F(b(_0x1b56c8),b(_0x247860));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x247860+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1b56c8+')');}function Th(_0xca972b,_0x2d60e7){const _0x306865=kt(_0xca972b,0x0),_0x16c81c=kt(_0x2d60e7,0x0);for(let _0x327807=0x0;_0x327807<_0x306865['length']&&_0x327807<_0x16c81c['length'];_0x327807++){const _0x5baa6d=He(_0x306865[_0x327807],_0x16c81c[_0x327807]);if(_0x5baa6d!==0x0)return _0x5baa6d;}return _0x306865['length']===_0x16c81c['length']?0x0:_0x306865['length']<_0x16c81c['length']?-0x1:0x1;}function qi(_0x40a176,_0x2f1093){if(we(_0x40a176)!==we(_0x2f1093))return!0x1;for(let _0x5bac2e=_0x40a176['pieceNum_'],_0x347b6b=_0x2f1093['pieceNum_'];_0x5bac2e<=_0x40a176['pieces_']['length'];_0x5bac2e++,_0x347b6b++)if(_0x40a176['pieces_'][_0x5bac2e]!==_0x2f1093['pieces_'][_0x347b6b])return!0x1;return!0x0;}function $(_0x302aa6,_0x23e98f){let _0x4c5d93=_0x302aa6['pieceNum_'],_0x233b9b=_0x23e98f['pieceNum_'];if(we(_0x302aa6)>we(_0x23e98f))return!0x1;for(;_0x4c5d93<_0x302aa6['pieces_']['length'];){if(_0x302aa6['pieces_'][_0x4c5d93]!==_0x23e98f['pieces_'][_0x233b9b])return!0x1;++_0x4c5d93,++_0x233b9b;}return!0x0;}class Sh{constructor(_0x1b8b91,_0x194f2f){this['errorPrefix_']=_0x194f2f,this['parts_']=kt(_0x1b8b91,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x210ef8=0x0;_0x210ef8<this['parts_']['length'];_0x210ef8++)this['byteLength_']+=Pn(this['parts_'][_0x210ef8]);So(this);}}function bh(_0x1c7c51,_0x304717){_0x1c7c51['parts_']['length']>0x0&&(_0x1c7c51['byteLength_']+=0x1),_0x1c7c51['parts_']['push'](_0x304717),_0x1c7c51['byteLength_']+=Pn(_0x304717),So(_0x1c7c51);}function Rh(_0x48063e){const _0x2712eb=_0x48063e['parts_']['pop']();_0x48063e['byteLength_']-=Pn(_0x2712eb),_0x48063e['parts_']['length']>0x0&&(_0x48063e['byteLength_']-=0x1);}function So(_0x1d661e){if(_0x1d661e['byteLength_']>Js)throw new Error(_0x1d661e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x1d661e['byteLength_']+').');if(_0x1d661e['parts_']['length']>Qs)throw new Error(_0x1d661e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x1d661e));}function Ne(_0x5c5258){return _0x5c5258['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5c5258['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x381089,_0x125c20;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x125c20='visibilitychange',_0x381089='hidden'):typeof document['mozHidden']<'u'?(_0x125c20='mozvisibilitychange',_0x381089='mozHidden'):typeof document['msHidden']<'u'?(_0x125c20='msvisibilitychange',_0x381089='msHidden'):typeof document['webkitHidden']<'u'&&(_0x125c20='webkitvisibilitychange',_0x381089='webkitHidden')),this['visible_']=!0x0,_0x125c20&&document['addEventListener'](_0x125c20,()=>{const _0x412d61=!document[_0x381089];_0x412d61!==this['visible_']&&(this['visible_']=_0x412d61,this['trigger']('visible',_0x412d61));},!0x1);}['getInitialEvent'](_0x14a793){return f(_0x14a793==='visible','Unknown\x20event\x20type:\x20'+_0x14a793),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x353ecf,_0x594491,_0x2eb400,_0x602e89,_0x2503e3,_0x354b51,_0x15d82e,_0x4f27a7){if(super(),this['repoInfo_']=_0x353ecf,this['applicationId_']=_0x594491,this['onDataUpdate_']=_0x2eb400,this['onConnectStatus_']=_0x602e89,this['onServerInfoUpdate_']=_0x2503e3,this['authTokenProvider_']=_0x354b51,this['appCheckTokenProvider_']=_0x15d82e,this['authOverride_']=_0x4f27a7,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4f27a7)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x353ecf['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1fce3b,_0x4f8bdd,_0x38a4c5){const _0x28e748=++this['requestNumber_'],_0x2018cd={'r':_0x28e748,'a':_0x1fce3b,'b':_0x4f8bdd};this['log_'](O(_0x2018cd)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2018cd),_0x38a4c5&&(this['requestCBHash_'][_0x28e748]=_0x38a4c5);}['get'](_0x5763ff){this['initConnection_']();const _0x52c036=new Ve(),_0x35b4d3={'action':'g','request':{'p':_0x5763ff['_path']['toString'](),'q':_0x5763ff['_queryObject']},'onComplete':_0x3100e8=>{const _0x219e2f=_0x3100e8['d'];_0x3100e8['s']==='ok'?_0x52c036['resolve'](_0x219e2f):_0x52c036['reject'](_0x219e2f);}};this['outstandingGets_']['push'](_0x35b4d3),this['outstandingGetCount_']++;const _0x227eaf=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x227eaf),_0x52c036['promise'];}['listen'](_0x38d499,_0x3a9d46,_0x135dea,_0x1bc122){this['initConnection_']();const _0x1b195a=_0x38d499['_queryIdentifier'],_0x4b0363=_0x38d499['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4b0363+'\x20'+_0x1b195a),this['listens']['has'](_0x4b0363)||this['listens']['set'](_0x4b0363,new Map()),f(_0x38d499['_queryParams']['isDefault']()||!_0x38d499['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4b0363)['has'](_0x1b195a),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1631d4={'onComplete':_0x1bc122,'hashFn':_0x3a9d46,'query':_0x38d499,'tag':_0x135dea};this['listens']['get'](_0x4b0363)['set'](_0x1b195a,_0x1631d4),this['connected_']&&this['sendListen_'](_0x1631d4);}['sendGet_'](_0x42beb0){const _0x9cf6ef=this['outstandingGets_'][_0x42beb0];this['sendRequest']('g',_0x9cf6ef['request'],_0x13d89f=>{delete this['outstandingGets_'][_0x42beb0],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x9cf6ef['onComplete']&&_0x9cf6ef['onComplete'](_0x13d89f);});}['sendListen_'](_0x5e8ad6){const _0x42340c=_0x5e8ad6['query'],_0x2d5756=_0x42340c['_path']['toString'](),_0x2e11fb=_0x42340c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2d5756+'\x20for\x20'+_0x2e11fb);const _0x4bc40d={'p':_0x2d5756},_0x2757dd='q';_0x5e8ad6['tag']&&(_0x4bc40d['q']=_0x42340c['_queryObject'],_0x4bc40d['t']=_0x5e8ad6['tag']),_0x4bc40d['h']=_0x5e8ad6['hashFn'](),this['sendRequest'](_0x2757dd,_0x4bc40d,_0x150031=>{const _0x791d4=_0x150031['d'],_0x4e86e2=_0x150031['s'];ie['warnOnListenWarnings_'](_0x791d4,_0x42340c),(this['listens']['get'](_0x2d5756)&&this['listens']['get'](_0x2d5756)['get'](_0x2e11fb))===_0x5e8ad6&&(this['log_']('listen\x20response',_0x150031),_0x4e86e2!=='ok'&&this['removeListen_'](_0x2d5756,_0x2e11fb),_0x5e8ad6['onComplete']&&_0x5e8ad6['onComplete'](_0x4e86e2,_0x791d4));});}static['warnOnListenWarnings_'](_0x57fcf7,_0x76c80d){if(_0x57fcf7&&typeof _0x57fcf7=='object'&&Y(_0x57fcf7,'w')){const _0x45d6f0=Oe(_0x57fcf7,'w');if(Array['isArray'](_0x45d6f0)&&~_0x45d6f0['indexOf']('no_index')){const _0x7350c8='\x22.indexOn\x22:\x20\x22'+_0x76c80d['_queryParams']['getIndex']()['toString']()+'\x22',_0x6f7931=_0x76c80d['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x7350c8+'\x20at\x20'+_0x6f7931+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x28aa8d){this['authToken_']=_0x28aa8d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x28aa8d);}['reduceReconnectDelayIfAdminCredential_'](_0x352ef0){(_0x352ef0&&_0x352ef0['length']===0x28||vc(_0x352ef0))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1a431e){this['appCheckToken_']=_0x1a431e,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x26c384=this['authToken_'],_0x2b2253=yc(_0x26c384)?'auth':'gauth',_0xcd5a14={'cred':_0x26c384};this['authOverride_']===null?_0xcd5a14['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xcd5a14['authvar']=this['authOverride_']),this['sendRequest'](_0x2b2253,_0xcd5a14,_0x4eda70=>{const _0x5ee2c8=_0x4eda70['s'],_0x55af7d=_0x4eda70['d']||'error';this['authToken_']===_0x26c384&&(_0x5ee2c8==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5ee2c8,_0x55af7d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x27029a=>{const _0x583e73=_0x27029a['s'],_0x25bc37=_0x27029a['d']||'error';_0x583e73==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x583e73,_0x25bc37);});}['unlisten'](_0xa139cc,_0x119145){const _0x39b271=_0xa139cc['_path']['toString'](),_0x34c3e9=_0xa139cc['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x39b271+'\x20'+_0x34c3e9),f(_0xa139cc['_queryParams']['isDefault']()||!_0xa139cc['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x39b271,_0x34c3e9)&&this['connected_']&&this['sendUnlisten_'](_0x39b271,_0x34c3e9,_0xa139cc['_queryObject'],_0x119145);}['sendUnlisten_'](_0x338461,_0x3c2202,_0x30d4f6,_0x4f38e4){this['log_']('Unlisten\x20on\x20'+_0x338461+'\x20for\x20'+_0x3c2202);const _0x5e3122={'p':_0x338461},_0x16a814='n';_0x4f38e4&&(_0x5e3122['q']=_0x30d4f6,_0x5e3122['t']=_0x4f38e4),this['sendRequest'](_0x16a814,_0x5e3122);}['onDisconnectPut'](_0x26e5f1,_0x52933d,_0x97ac3e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x26e5f1,_0x52933d,_0x97ac3e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x26e5f1,'action':'o','data':_0x52933d,'onComplete':_0x97ac3e});}['onDisconnectMerge'](_0x4136ca,_0x45c752,_0x3d041c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4136ca,_0x45c752,_0x3d041c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4136ca,'action':'om','data':_0x45c752,'onComplete':_0x3d041c});}['onDisconnectCancel'](_0x5c3b46,_0x52c20d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5c3b46,null,_0x52c20d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c3b46,'action':'oc','data':null,'onComplete':_0x52c20d});}['sendOnDisconnect_'](_0x43d795,_0x3e5a78,_0x2eed2f,_0x3531fe){const _0x5a2b6a={'p':_0x3e5a78,'d':_0x2eed2f};this['log_']('onDisconnect\x20'+_0x43d795,_0x5a2b6a),this['sendRequest'](_0x43d795,_0x5a2b6a,_0x1af530=>{_0x3531fe&&setTimeout(()=>{_0x3531fe(_0x1af530['s'],_0x1af530['d']);},Math['floor'](0x0));});}['put'](_0x4c6944,_0x12f54e,_0xe43b2a,_0x2df9d0){this['putInternal']('p',_0x4c6944,_0x12f54e,_0xe43b2a,_0x2df9d0);}['merge'](_0x3f4c01,_0x3a0021,_0x8a1484,_0x4e939e){this['putInternal']('m',_0x3f4c01,_0x3a0021,_0x8a1484,_0x4e939e);}['putInternal'](_0x45d778,_0x315ead,_0x31df2f,_0x279915,_0x1a6667){this['initConnection_']();const _0x4b8ad9={'p':_0x315ead,'d':_0x31df2f};_0x1a6667!==void 0x0&&(_0x4b8ad9['h']=_0x1a6667),this['outstandingPuts_']['push']({'action':_0x45d778,'request':_0x4b8ad9,'onComplete':_0x279915}),this['outstandingPutCount_']++;const _0xf14bd5=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xf14bd5):this['log_']('Buffering\x20put:\x20'+_0x315ead);}['sendPut_'](_0x4ad765){const _0x151cbe=this['outstandingPuts_'][_0x4ad765]['action'],_0xc83dc2=this['outstandingPuts_'][_0x4ad765]['request'],_0x18c38=this['outstandingPuts_'][_0x4ad765]['onComplete'];this['outstandingPuts_'][_0x4ad765]['queued']=this['connected_'],this['sendRequest'](_0x151cbe,_0xc83dc2,_0x529b22=>{this['log_'](_0x151cbe+'\x20response',_0x529b22),delete this['outstandingPuts_'][_0x4ad765],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x18c38&&_0x18c38(_0x529b22['s'],_0x529b22['d']);});}['reportStats'](_0x25e543){if(this['connected_']){const _0x9d107e={'c':_0x25e543};this['log_']('reportStats',_0x9d107e),this['sendRequest']('s',_0x9d107e,_0x4e569d=>{if(_0x4e569d['s']!=='ok'){const _0x3fa9b7=_0x4e569d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3fa9b7);}});}}['onDataMessage_'](_0x460555){if('r'in _0x460555){this['log_']('from\x20server:\x20'+O(_0x460555));const _0x2f9e1e=_0x460555['r'],_0x5592d7=this['requestCBHash_'][_0x2f9e1e];_0x5592d7&&(delete this['requestCBHash_'][_0x2f9e1e],_0x5592d7(_0x460555['b']));}else{if('error'in _0x460555)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x460555['error'];'a'in _0x460555&&this['onDataPush_'](_0x460555['a'],_0x460555['b']);}}['onDataPush_'](_0x2097f4,_0x2d49be){this['log_']('handleServerMessage',_0x2097f4,_0x2d49be),_0x2097f4==='d'?this['onDataUpdate_'](_0x2d49be['p'],_0x2d49be['d'],!0x1,_0x2d49be['t']):_0x2097f4==='m'?this['onDataUpdate_'](_0x2d49be['p'],_0x2d49be['d'],!0x0,_0x2d49be['t']):_0x2097f4==='c'?this['onListenRevoked_'](_0x2d49be['p'],_0x2d49be['q']):_0x2097f4==='ac'?this['onAuthRevoked_'](_0x2d49be['s'],_0x2d49be['d']):_0x2097f4==='apc'?this['onAppCheckRevoked_'](_0x2d49be['s'],_0x2d49be['d']):_0x2097f4==='sd'?this['onSecurityDebugPacket_'](_0x2d49be):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2097f4)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x34d72b,_0x58bc02){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x34d72b),this['lastSessionId']=_0x58bc02,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2eff85){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2eff85));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1898dd){_0x1898dd&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1898dd;}['onOnline_'](_0x188f61){_0x188f61?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5e94b3=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3166ff=Math['max'](0x0,this['reconnectDelay_']-_0x5e94b3);_0x3166ff=Math['random']()*_0x3166ff,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3166ff+'ms'),this['scheduleConnect_'](_0x3166ff),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3f3b0c=this['onDataMessage_']['bind'](this),_0x2746c5=this['onReady_']['bind'](this),_0x48945f=this['onRealtimeDisconnect_']['bind'](this),_0x54e8b8=this['id']+':'+ie['nextConnectionId_']++,_0xa5d252=this['lastSessionId'];let _0x436e63=!0x1,_0x50fc59=null;const _0x1bef3f=function(){_0x50fc59?_0x50fc59['close']():(_0x436e63=!0x0,_0x48945f());},_0x8bb29c=function(_0x419809){f(_0x50fc59,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x50fc59['sendRequest'](_0x419809);};this['realtime_']={'close':_0x1bef3f,'sendRequest':_0x8bb29c};const _0x40e03a=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x11c0ef,_0x461d95]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x40e03a),this['appCheckTokenProvider_']['getToken'](_0x40e03a)]);_0x436e63?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x11c0ef&&_0x11c0ef['accessToken'],this['appCheckToken_']=_0x461d95&&_0x461d95['token'],_0x50fc59=new wh(_0x54e8b8,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3f3b0c,_0x2746c5,_0x48945f,_0x4d8717=>{U(_0x4d8717+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0xa5d252));}catch(_0x11a9c1){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x11a9c1),_0x436e63||(this['repoInfo_']['nodeAdmin']&&U(_0x11a9c1),_0x1bef3f());}}}['interrupt'](_0x25f9db){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x25f9db),this['interruptReasons_'][_0x25f9db]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x6577bb){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x6577bb),delete this['interruptReasons_'][_0x6577bb],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x167058){const _0x43ef96=_0x167058-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x43ef96});}['cancelSentTransactions_'](){for(let _0x2fbe4f=0x0;_0x2fbe4f<this['outstandingPuts_']['length'];_0x2fbe4f++){const _0x3ed5f4=this['outstandingPuts_'][_0x2fbe4f];_0x3ed5f4&&'h'in _0x3ed5f4['request']&&_0x3ed5f4['queued']&&(_0x3ed5f4['onComplete']&&_0x3ed5f4['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2fbe4f],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x13d32f,_0x4cbdcc){let _0x3a4318;_0x4cbdcc?_0x3a4318=_0x4cbdcc['map'](_0x1dbf68=>Bi(_0x1dbf68))['join']('$'):_0x3a4318='default';const _0x2421ec=this['removeListen_'](_0x13d32f,_0x3a4318);_0x2421ec&&_0x2421ec['onComplete']&&_0x2421ec['onComplete']('permission_denied');}['removeListen_'](_0x5dabac,_0x204ba4){const _0x55c75e=new C(_0x5dabac)['toString']();let _0x41c9b4;if(this['listens']['has'](_0x55c75e)){const _0x1b713d=this['listens']['get'](_0x55c75e);_0x41c9b4=_0x1b713d['get'](_0x204ba4),_0x1b713d['delete'](_0x204ba4),_0x1b713d['size']===0x0&&this['listens']['delete'](_0x55c75e);}else _0x41c9b4=void 0x0;return _0x41c9b4;}['onAuthRevoked_'](_0x24ae87,_0x3c0191){L('Auth\x20token\x20revoked:\x20'+_0x24ae87+'/'+_0x3c0191),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x24ae87==='invalid_token'||_0x24ae87==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xd888d6,_0x303df5){L('App\x20check\x20token\x20revoked:\x20'+_0xd888d6+'/'+_0x303df5),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xd888d6==='invalid_token'||_0xd888d6==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x63a599){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x63a599):'msg'in _0x63a599&&console['log']('FIREBASE:\x20'+_0x63a599['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x553a9d of this['listens']['values']())for(const _0x34158f of _0x553a9d['values']())this['sendListen_'](_0x34158f);for(let _0x3fada0=0x0;_0x3fada0<this['outstandingPuts_']['length'];_0x3fada0++)this['outstandingPuts_'][_0x3fada0]&&this['sendPut_'](_0x3fada0);for(;this['onDisconnectRequestQueue_']['length'];){const _0x547ad7=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x547ad7['action'],_0x547ad7['pathString'],_0x547ad7['data'],_0x547ad7['onComplete']);}for(let _0x4b466b=0x0;_0x4b466b<this['outstandingGets_']['length'];_0x4b466b++)this['outstandingGets_'][_0x4b466b]&&this['sendGet_'](_0x4b466b);}['sendConnectStats_'](){const _0x5d4274={};let _0x471913='js';_0x5d4274['sdk.'+_0x471913+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x5d4274['framework.cordova']=0x1:qr()&&(_0x5d4274['framework.reactnative']=0x1),this['reportStats'](_0x5d4274);}['shouldReconnect_'](){const _0xd96476=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0xd96476;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xc9c0f2,_0x10c2b4){this['name']=_0xc9c0f2,this['node']=_0x10c2b4;}static['Wrap'](_0x308578,_0x56731e){return new E(_0x308578,_0x56731e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x22d29e,_0x20e676){const _0x2d8289=new E(xe,_0x22d29e),_0x30571c=new E(xe,_0x20e676);return this['compare'](_0x2d8289,_0x30571c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x9d6957){Xt=_0x9d6957;}['compare'](_0x515c29,_0x10b2ba){return He(_0x515c29['name'],_0x10b2ba['name']);}['isDefinedOn'](_0x2bcbf3){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x57d90b,_0x520871){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x120003,_0x49cef1){return f(typeof _0x120003=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x120003,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x548cae,_0x1a6f36,_0x2f43f9,_0xa265c4,_0x8050c3=null){this['isReverse_']=_0xa265c4,this['resultGenerator_']=_0x8050c3,this['nodeStack_']=[];let _0x5c5f82=0x1;for(;!_0x548cae['isEmpty']();)if(_0x548cae=_0x548cae,_0x5c5f82=_0x1a6f36?_0x2f43f9(_0x548cae['key'],_0x1a6f36):0x1,_0xa265c4&&(_0x5c5f82*=-0x1),_0x5c5f82<0x0)this['isReverse_']?_0x548cae=_0x548cae['left']:_0x548cae=_0x548cae['right'];else{if(_0x5c5f82===0x0){this['nodeStack_']['push'](_0x548cae);break;}else this['nodeStack_']['push'](_0x548cae),this['isReverse_']?_0x548cae=_0x548cae['right']:_0x548cae=_0x548cae['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x287c3c=this['nodeStack_']['pop'](),_0x4fbf52;if(this['resultGenerator_']?_0x4fbf52=this['resultGenerator_'](_0x287c3c['key'],_0x287c3c['value']):_0x4fbf52={'key':_0x287c3c['key'],'value':_0x287c3c['value']},this['isReverse_']){for(_0x287c3c=_0x287c3c['left'];!_0x287c3c['isEmpty']();)this['nodeStack_']['push'](_0x287c3c),_0x287c3c=_0x287c3c['right'];}else{for(_0x287c3c=_0x287c3c['right'];!_0x287c3c['isEmpty']();)this['nodeStack_']['push'](_0x287c3c),_0x287c3c=_0x287c3c['left'];}return _0x4fbf52;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4a7054=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4a7054['key'],_0x4a7054['value']):{'key':_0x4a7054['key'],'value':_0x4a7054['value']};}}class M{constructor(_0x577e4d,_0x10cf6f,_0x2f3938,_0x5024e7,_0x157302){this['key']=_0x577e4d,this['value']=_0x10cf6f,this['color']=_0x2f3938??M['RED'],this['left']=_0x5024e7??B['EMPTY_NODE'],this['right']=_0x157302??B['EMPTY_NODE'];}['copy'](_0x4a9957,_0x48c9d5,_0x5b1159,_0x1c7733,_0x515444){return new M(_0x4a9957??this['key'],_0x48c9d5??this['value'],_0x5b1159??this['color'],_0x1c7733??this['left'],_0x515444??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x410b04){return this['left']['inorderTraversal'](_0x410b04)||!!_0x410b04(this['key'],this['value'])||this['right']['inorderTraversal'](_0x410b04);}['reverseTraversal'](_0xff056a){return this['right']['reverseTraversal'](_0xff056a)||_0xff056a(this['key'],this['value'])||this['left']['reverseTraversal'](_0xff056a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2d8992,_0x18b912,_0x2839ca){let _0x2cfcf=this;const _0x3098ef=_0x2839ca(_0x2d8992,_0x2cfcf['key']);return _0x3098ef<0x0?_0x2cfcf=_0x2cfcf['copy'](null,null,null,_0x2cfcf['left']['insert'](_0x2d8992,_0x18b912,_0x2839ca),null):_0x3098ef===0x0?_0x2cfcf=_0x2cfcf['copy'](null,_0x18b912,null,null,null):_0x2cfcf=_0x2cfcf['copy'](null,null,null,null,_0x2cfcf['right']['insert'](_0x2d8992,_0x18b912,_0x2839ca)),_0x2cfcf['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5ee509=this;return!_0x5ee509['left']['isRed_']()&&!_0x5ee509['left']['left']['isRed_']()&&(_0x5ee509=_0x5ee509['moveRedLeft_']()),_0x5ee509=_0x5ee509['copy'](null,null,null,_0x5ee509['left']['removeMin_'](),null),_0x5ee509['fixUp_']();}['remove'](_0x4b7ef6,_0x491518){let _0x53a974,_0x5217fa;if(_0x53a974=this,_0x491518(_0x4b7ef6,_0x53a974['key'])<0x0)!_0x53a974['left']['isEmpty']()&&!_0x53a974['left']['isRed_']()&&!_0x53a974['left']['left']['isRed_']()&&(_0x53a974=_0x53a974['moveRedLeft_']()),_0x53a974=_0x53a974['copy'](null,null,null,_0x53a974['left']['remove'](_0x4b7ef6,_0x491518),null);else{if(_0x53a974['left']['isRed_']()&&(_0x53a974=_0x53a974['rotateRight_']()),!_0x53a974['right']['isEmpty']()&&!_0x53a974['right']['isRed_']()&&!_0x53a974['right']['left']['isRed_']()&&(_0x53a974=_0x53a974['moveRedRight_']()),_0x491518(_0x4b7ef6,_0x53a974['key'])===0x0){if(_0x53a974['right']['isEmpty']())return B['EMPTY_NODE'];_0x5217fa=_0x53a974['right']['min_'](),_0x53a974=_0x53a974['copy'](_0x5217fa['key'],_0x5217fa['value'],null,null,_0x53a974['right']['removeMin_']());}_0x53a974=_0x53a974['copy'](null,null,null,null,_0x53a974['right']['remove'](_0x4b7ef6,_0x491518));}return _0x53a974['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4ebad5=this;return _0x4ebad5['right']['isRed_']()&&!_0x4ebad5['left']['isRed_']()&&(_0x4ebad5=_0x4ebad5['rotateLeft_']()),_0x4ebad5['left']['isRed_']()&&_0x4ebad5['left']['left']['isRed_']()&&(_0x4ebad5=_0x4ebad5['rotateRight_']()),_0x4ebad5['left']['isRed_']()&&_0x4ebad5['right']['isRed_']()&&(_0x4ebad5=_0x4ebad5['colorFlip_']()),_0x4ebad5;}['moveRedLeft_'](){let _0x360a78=this['colorFlip_']();return _0x360a78['right']['left']['isRed_']()&&(_0x360a78=_0x360a78['copy'](null,null,null,null,_0x360a78['right']['rotateRight_']()),_0x360a78=_0x360a78['rotateLeft_'](),_0x360a78=_0x360a78['colorFlip_']()),_0x360a78;}['moveRedRight_'](){let _0x4192d8=this['colorFlip_']();return _0x4192d8['left']['left']['isRed_']()&&(_0x4192d8=_0x4192d8['rotateRight_'](),_0x4192d8=_0x4192d8['colorFlip_']()),_0x4192d8;}['rotateLeft_'](){const _0x1bc33a=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1bc33a,null);}['rotateRight_'](){const _0x19e25f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x19e25f);}['colorFlip_'](){const _0x38fa42=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2918bc=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x38fa42,_0x2918bc);}['checkMaxDepth_'](){const _0x57b66e=this['check_']();return Math['pow'](0x2,_0x57b66e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x33f1d1=this['left']['check_']();if(_0x33f1d1!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x33f1d1+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0xa057e1,_0xe8540d,_0x18912a,_0x4d5829,_0x43c67c){return this;}['insert'](_0x4e5617,_0x575478,_0xb482c0){return new M(_0x4e5617,_0x575478,null);}['remove'](_0x6c198b,_0x348942){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3bd78b){return!0x1;}['reverseTraversal'](_0x2209dd){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4c1676,_0x54e7a7=B['EMPTY_NODE']){this['comparator_']=_0x4c1676,this['root_']=_0x54e7a7;}['insert'](_0x1c5834,_0x97cb40){return new B(this['comparator_'],this['root_']['insert'](_0x1c5834,_0x97cb40,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2e10ad){return new B(this['comparator_'],this['root_']['remove'](_0x2e10ad,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x15bc07){let _0x2e1838,_0x5189a7=this['root_'];for(;!_0x5189a7['isEmpty']();){if(_0x2e1838=this['comparator_'](_0x15bc07,_0x5189a7['key']),_0x2e1838===0x0)return _0x5189a7['value'];_0x2e1838<0x0?_0x5189a7=_0x5189a7['left']:_0x2e1838>0x0&&(_0x5189a7=_0x5189a7['right']);}return null;}['getPredecessorKey'](_0x5d6c6c){let _0x3a1096,_0x22a2db=this['root_'],_0x6e9f41=null;for(;!_0x22a2db['isEmpty']();)if(_0x3a1096=this['comparator_'](_0x5d6c6c,_0x22a2db['key']),_0x3a1096===0x0){if(_0x22a2db['left']['isEmpty']())return _0x6e9f41?_0x6e9f41['key']:null;for(_0x22a2db=_0x22a2db['left'];!_0x22a2db['right']['isEmpty']();)_0x22a2db=_0x22a2db['right'];return _0x22a2db['key'];}else _0x3a1096<0x0?_0x22a2db=_0x22a2db['left']:_0x3a1096>0x0&&(_0x6e9f41=_0x22a2db,_0x22a2db=_0x22a2db['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xf7bbc){return this['root_']['inorderTraversal'](_0xf7bbc);}['reverseTraversal'](_0x5e039b){return this['root_']['reverseTraversal'](_0x5e039b);}['getIterator'](_0x151af4){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x151af4);}['getIteratorFrom'](_0x32886c,_0x5c31d6){return new Zt(this['root_'],_0x32886c,this['comparator_'],!0x1,_0x5c31d6);}['getReverseIteratorFrom'](_0x336efd,_0x302674){return new Zt(this['root_'],_0x336efd,this['comparator_'],!0x0,_0x302674);}['getReverseIterator'](_0x22b591){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x22b591);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x5a2fcc,_0x101fc3){return He(_0x5a2fcc['name'],_0x101fc3['name']);}function ji(_0x495f54,_0xf6bf72){return He(_0x495f54,_0xf6bf72);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x14632a){vi=_0x14632a;}const Ro=function(_0x4e82e5){return typeof _0x4e82e5=='number'?'number:'+so(_0x4e82e5):'string:'+_0x4e82e5;},Ao=function(_0x13fd62){if(_0x13fd62['isLeafNode']()){const _0x537e54=_0x13fd62['val']();f(typeof _0x537e54=='string'||typeof _0x537e54=='number'||typeof _0x537e54=='object'&&Y(_0x537e54,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x13fd62===vi||_0x13fd62['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x13fd62===vi||_0x13fd62['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x4f8d09){er=_0x4f8d09;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4c69a6,_0x23aee1=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4c69a6,this['priorityNode_']=_0x23aee1,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x26dc45){return new D(this['value_'],_0x26dc45);}['getImmediateChild'](_0x1e58df){return _0x1e58df==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x347dcf){return v(_0x347dcf)?this:y(_0x347dcf)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x49eb91,_0x4762c6){return null;}['updateImmediateChild'](_0x496a21,_0x3ae907){return _0x496a21==='.priority'?this['updatePriority'](_0x3ae907):_0x3ae907['isEmpty']()&&_0x496a21!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x496a21,_0x3ae907)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5b3e64,_0x18fc78){const _0x7ff31e=y(_0x5b3e64);return _0x7ff31e===null?_0x18fc78:_0x18fc78['isEmpty']()&&_0x7ff31e!=='.priority'?this:(f(_0x7ff31e!=='.priority'||we(_0x5b3e64)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x7ff31e,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x5b3e64),_0x18fc78)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2b47b5,_0x103422){return!0x1;}['val'](_0x5bca0c){return _0x5bca0c&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4cd156='';this['priorityNode_']['isEmpty']()||(_0x4cd156+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x3f7e18=typeof this['value_'];_0x4cd156+=_0x3f7e18+':',_0x3f7e18==='number'?_0x4cd156+=so(this['value_']):_0x4cd156+=this['value_'],this['lazyHash_']=no(_0x4cd156);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4a24d9){return _0x4a24d9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4a24d9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4a24d9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4a24d9));}['compareToLeafNode_'](_0x2862af){const _0x5744fa=typeof _0x2862af['value_'],_0x5f3115=typeof this['value_'],_0x2a5c52=D['VALUE_TYPE_ORDER']['indexOf'](_0x5744fa),_0x7531c4=D['VALUE_TYPE_ORDER']['indexOf'](_0x5f3115);return f(_0x2a5c52>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5744fa),f(_0x7531c4>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5f3115),_0x2a5c52===_0x7531c4?_0x5f3115==='object'?0x0:this['value_']<_0x2862af['value_']?-0x1:this['value_']===_0x2862af['value_']?0x0:0x1:_0x7531c4-_0x2a5c52;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x407d1d){if(_0x407d1d===this)return!0x0;if(_0x407d1d['isLeafNode']()){const _0x29218e=_0x407d1d;return this['value_']===_0x29218e['value_']&&this['priorityNode_']['equals'](_0x29218e['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3a7ef8){ko=_0x3a7ef8;}function xh(_0x14caf3){No=_0x14caf3;}class Fh extends On{['compare'](_0xfddef9,_0x57c34e){const _0x298ee7=_0xfddef9['node']['getPriority'](),_0x1292bb=_0x57c34e['node']['getPriority'](),_0x3abf82=_0x298ee7['compareTo'](_0x1292bb);return _0x3abf82===0x0?He(_0xfddef9['name'],_0x57c34e['name']):_0x3abf82;}['isDefinedOn'](_0x440c4b){return!_0x440c4b['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x93e277,_0x418f99){return!_0x93e277['getPriority']()['equals'](_0x418f99['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0xe4fdee,_0x4212c1){const _0x39064b=ko(_0xe4fdee);return new E(_0x4212c1,new D('[PRIORITY-POST]',_0x39064b));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x59f0ee){const _0xbc3bef=_0x209570=>parseInt(Math['log'](_0x209570)/Uh,0xa),_0x255085=_0x5f3fce=>parseInt(Array(_0x5f3fce+0x1)['join']('1'),0x2);this['count']=_0xbc3bef(_0x59f0ee+0x1),this['current_']=this['count']-0x1;const _0x12a777=_0x255085(this['count']);this['bits_']=_0x59f0ee+0x1&_0x12a777;}['nextBitIsOne'](){const _0x7c37c3=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x7c37c3;}}const dn=function(_0x19b61b,_0x52bffe,_0x228624,_0x196f21){_0x19b61b['sort'](_0x52bffe);const _0x1a7bed=function(_0x2be7be,_0x2e6853){const _0xf1bb8f=_0x2e6853-_0x2be7be;let _0x1cc451,_0x749f01;if(_0xf1bb8f===0x0)return null;if(_0xf1bb8f===0x1)return _0x1cc451=_0x19b61b[_0x2be7be],_0x749f01=_0x228624?_0x228624(_0x1cc451):_0x1cc451,new M(_0x749f01,_0x1cc451['node'],M['BLACK'],null,null);{const _0x754a18=parseInt(_0xf1bb8f/0x2,0xa)+_0x2be7be,_0x53787d=_0x1a7bed(_0x2be7be,_0x754a18),_0x34331f=_0x1a7bed(_0x754a18+0x1,_0x2e6853);return _0x1cc451=_0x19b61b[_0x754a18],_0x749f01=_0x228624?_0x228624(_0x1cc451):_0x1cc451,new M(_0x749f01,_0x1cc451['node'],M['BLACK'],_0x53787d,_0x34331f);}},_0x346e07=function(_0x5a26fb){let _0x3c7f1a=null,_0x2c8438=null,_0x3978d3=_0x19b61b['length'];const _0x3ef173=function(_0x583d7a,_0x142d42){const _0xaa18b9=_0x3978d3-_0x583d7a,_0x4349c9=_0x3978d3;_0x3978d3-=_0x583d7a;const _0x4f5c52=_0x1a7bed(_0xaa18b9+0x1,_0x4349c9),_0x325ef1=_0x19b61b[_0xaa18b9],_0xee99b7=_0x228624?_0x228624(_0x325ef1):_0x325ef1;_0x43cd5c(new M(_0xee99b7,_0x325ef1['node'],_0x142d42,null,_0x4f5c52));},_0x43cd5c=function(_0x3ab1fe){_0x3c7f1a?(_0x3c7f1a['left']=_0x3ab1fe,_0x3c7f1a=_0x3ab1fe):(_0x2c8438=_0x3ab1fe,_0x3c7f1a=_0x3ab1fe);};for(let _0x14a713=0x0;_0x14a713<_0x5a26fb['count'];++_0x14a713){const _0x24dc23=_0x5a26fb['nextBitIsOne'](),_0x5c7c32=Math['pow'](0x2,_0x5a26fb['count']-(_0x14a713+0x1));_0x24dc23?_0x3ef173(_0x5c7c32,M['BLACK']):(_0x3ef173(_0x5c7c32,M['BLACK']),_0x3ef173(_0x5c7c32,M['RED']));}return _0x2c8438;},_0x2b8cee=new Wh(_0x19b61b['length']),_0x485c7b=_0x346e07(_0x2b8cee);return new B(_0x196f21||_0x52bffe,_0x485c7b);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x3306e9,_0x26b807){this['indexes_']=_0x3306e9,this['indexSet_']=_0x26b807;}['get'](_0x141611){const _0x2fbe82=Oe(this['indexes_'],_0x141611);if(!_0x2fbe82)throw new Error('No\x20index\x20defined\x20for\x20'+_0x141611);return _0x2fbe82 instanceof B?_0x2fbe82:null;}['hasIndex'](_0x382d8e){return Y(this['indexSet_'],_0x382d8e['toString']());}['addIndex'](_0x207f59,_0x391aaf){f(_0x207f59!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x14fe3e=[];let _0x508218=!0x1;const _0x140cf9=_0x391aaf['getIterator'](E['Wrap']);let _0x5bc2d1=_0x140cf9['getNext']();for(;_0x5bc2d1;)_0x508218=_0x508218||_0x207f59['isDefinedOn'](_0x5bc2d1['node']),_0x14fe3e['push'](_0x5bc2d1),_0x5bc2d1=_0x140cf9['getNext']();let _0x5bf8ff;_0x508218?_0x5bf8ff=dn(_0x14fe3e,_0x207f59['getCompare']()):_0x5bf8ff=je;const _0x1dd184=_0x207f59['toString'](),_0x12f706={...this['indexSet_']};_0x12f706[_0x1dd184]=_0x207f59;const _0x5003ab={...this['indexes_']};return _0x5003ab[_0x1dd184]=_0x5bf8ff,new ee(_0x5003ab,_0x12f706);}['addToIndexes'](_0x266edd,_0x343eb6){const _0x4720a0=ln(this['indexes_'],(_0x385280,_0x35a36d)=>{const _0x18a96c=Oe(this['indexSet_'],_0x35a36d);if(f(_0x18a96c,'Missing\x20index\x20implementation\x20for\x20'+_0x35a36d),_0x385280===je){if(_0x18a96c['isDefinedOn'](_0x266edd['node'])){const _0x2f99e9=[],_0x29ec0f=_0x343eb6['getIterator'](E['Wrap']);let _0x1324b4=_0x29ec0f['getNext']();for(;_0x1324b4;)_0x1324b4['name']!==_0x266edd['name']&&_0x2f99e9['push'](_0x1324b4),_0x1324b4=_0x29ec0f['getNext']();return _0x2f99e9['push'](_0x266edd),dn(_0x2f99e9,_0x18a96c['getCompare']());}else return je;}else{const _0x256e25=_0x343eb6['get'](_0x266edd['name']);let _0x30f3c4=_0x385280;return _0x256e25&&(_0x30f3c4=_0x30f3c4['remove'](new E(_0x266edd['name'],_0x256e25))),_0x30f3c4['insert'](_0x266edd,_0x266edd['node']);}});return new ee(_0x4720a0,this['indexSet_']);}['removeFromIndexes'](_0x305098,_0x8be860){const _0x3472ea=ln(this['indexes_'],_0x33d5b4=>{if(_0x33d5b4===je)return _0x33d5b4;{const _0x3e061c=_0x8be860['get'](_0x305098['name']);return _0x3e061c?_0x33d5b4['remove'](new E(_0x305098['name'],_0x3e061c)):_0x33d5b4;}});return new ee(_0x3472ea,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x52f061,_0x2c07c9,_0x21722e){this['children_']=_0x52f061,this['priorityNode_']=_0x2c07c9,this['indexMap_']=_0x21722e,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x3a3ca7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3a3ca7,this['indexMap_']);}['getImmediateChild'](_0x2e9a83){if(_0x2e9a83==='.priority')return this['getPriority']();{const _0x37b0b0=this['children_']['get'](_0x2e9a83);return _0x37b0b0===null?gt:_0x37b0b0;}}['getChild'](_0x582f2b){const _0x147708=y(_0x582f2b);return _0x147708===null?this:this['getImmediateChild'](_0x147708)['getChild'](b(_0x582f2b));}['hasChild'](_0x1db2e6){return this['children_']['get'](_0x1db2e6)!==null;}['updateImmediateChild'](_0x23ac08,_0x41a35b){if(f(_0x41a35b,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x23ac08==='.priority')return this['updatePriority'](_0x41a35b);{const _0x14c0e3=new E(_0x23ac08,_0x41a35b);let _0x139814,_0x567c1b;_0x41a35b['isEmpty']()?(_0x139814=this['children_']['remove'](_0x23ac08),_0x567c1b=this['indexMap_']['removeFromIndexes'](_0x14c0e3,this['children_'])):(_0x139814=this['children_']['insert'](_0x23ac08,_0x41a35b),_0x567c1b=this['indexMap_']['addToIndexes'](_0x14c0e3,this['children_']));const _0x2c4fb3=_0x139814['isEmpty']()?gt:this['priorityNode_'];return new g(_0x139814,_0x2c4fb3,_0x567c1b);}}['updateChild'](_0x55b40e,_0x1d8bd8){const _0x4e9291=y(_0x55b40e);if(_0x4e9291===null)return _0x1d8bd8;{f(y(_0x55b40e)!=='.priority'||we(_0x55b40e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2f81fd=this['getImmediateChild'](_0x4e9291)['updateChild'](b(_0x55b40e),_0x1d8bd8);return this['updateImmediateChild'](_0x4e9291,_0x2f81fd);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2e8595){if(this['isEmpty']())return null;const _0x171abf={};let _0x27e38b=0x0,_0x44b32f=0x0,_0x199123=!0x0;if(this['forEachChild'](R,(_0x22a6f4,_0xa9f52c)=>{_0x171abf[_0x22a6f4]=_0xa9f52c['val'](_0x2e8595),_0x27e38b++,_0x199123&&g['INTEGER_REGEXP_']['test'](_0x22a6f4)?_0x44b32f=Math['max'](_0x44b32f,Number(_0x22a6f4)):_0x199123=!0x1;}),!_0x2e8595&&_0x199123&&_0x44b32f<0x2*_0x27e38b){const _0x1861b9=[];for(const _0x42d064 in _0x171abf)_0x1861b9[_0x42d064]=_0x171abf[_0x42d064];return _0x1861b9;}else return _0x2e8595&&!this['getPriority']()['isEmpty']()&&(_0x171abf['.priority']=this['getPriority']()['val']()),_0x171abf;}['hash'](){if(this['lazyHash_']===null){let _0x3eb4e1='';this['getPriority']()['isEmpty']()||(_0x3eb4e1+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2c5046,_0x301dd0)=>{const _0x32540a=_0x301dd0['hash']();_0x32540a!==''&&(_0x3eb4e1+=':'+_0x2c5046+':'+_0x32540a);}),this['lazyHash_']=_0x3eb4e1===''?'':no(_0x3eb4e1);}return this['lazyHash_'];}['getPredecessorChildName'](_0x41f65d,_0x33818d,_0x434a9b){const _0x14f6e3=this['resolveIndex_'](_0x434a9b);if(_0x14f6e3){const _0x3635a3=_0x14f6e3['getPredecessorKey'](new E(_0x41f65d,_0x33818d));return _0x3635a3?_0x3635a3['name']:null;}else return this['children_']['getPredecessorKey'](_0x41f65d);}['getFirstChildName'](_0x3250b9){const _0x1f1cc2=this['resolveIndex_'](_0x3250b9);if(_0x1f1cc2){const _0x1ec83c=_0x1f1cc2['minKey']();return _0x1ec83c&&_0x1ec83c['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3ee9e0){const _0x408514=this['getFirstChildName'](_0x3ee9e0);return _0x408514?new E(_0x408514,this['children_']['get'](_0x408514)):null;}['getLastChildName'](_0x476f70){const _0x41f616=this['resolveIndex_'](_0x476f70);if(_0x41f616){const _0x3b5edb=_0x41f616['maxKey']();return _0x3b5edb&&_0x3b5edb['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1a0db4){const _0x286873=this['getLastChildName'](_0x1a0db4);return _0x286873?new E(_0x286873,this['children_']['get'](_0x286873)):null;}['forEachChild'](_0x1170b8,_0x4d724e){const _0x452c0a=this['resolveIndex_'](_0x1170b8);return _0x452c0a?_0x452c0a['inorderTraversal'](_0x3b555c=>_0x4d724e(_0x3b555c['name'],_0x3b555c['node'])):this['children_']['inorderTraversal'](_0x4d724e);}['getIterator'](_0x294700){return this['getIteratorFrom'](_0x294700['minPost'](),_0x294700);}['getIteratorFrom'](_0x173c63,_0x3ed370){const _0xfec1a9=this['resolveIndex_'](_0x3ed370);if(_0xfec1a9)return _0xfec1a9['getIteratorFrom'](_0x173c63,_0x5e2c04=>_0x5e2c04);{const _0x1bb93f=this['children_']['getIteratorFrom'](_0x173c63['name'],E['Wrap']);let _0x2859c7=_0x1bb93f['peek']();for(;_0x2859c7!=null&&_0x3ed370['compare'](_0x2859c7,_0x173c63)<0x0;)_0x1bb93f['getNext'](),_0x2859c7=_0x1bb93f['peek']();return _0x1bb93f;}}['getReverseIterator'](_0x3461bb){return this['getReverseIteratorFrom'](_0x3461bb['maxPost'](),_0x3461bb);}['getReverseIteratorFrom'](_0x16e6af,_0x1d0848){const _0x3493c9=this['resolveIndex_'](_0x1d0848);if(_0x3493c9)return _0x3493c9['getReverseIteratorFrom'](_0x16e6af,_0x4ee1fc=>_0x4ee1fc);{const _0xb3c5da=this['children_']['getReverseIteratorFrom'](_0x16e6af['name'],E['Wrap']);let _0x3081a1=_0xb3c5da['peek']();for(;_0x3081a1!=null&&_0x1d0848['compare'](_0x3081a1,_0x16e6af)>0x0;)_0xb3c5da['getNext'](),_0x3081a1=_0xb3c5da['peek']();return _0xb3c5da;}}['compareTo'](_0x3488a9){return this['isEmpty']()?_0x3488a9['isEmpty']()?0x0:-0x1:_0x3488a9['isLeafNode']()||_0x3488a9['isEmpty']()?0x1:_0x3488a9===Ht?-0x1:0x0;}['withIndex'](_0x14b285){if(_0x14b285===ye||this['indexMap_']['hasIndex'](_0x14b285))return this;{const _0x378866=this['indexMap_']['addIndex'](_0x14b285,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x378866);}}['isIndexed'](_0x4c37bb){return _0x4c37bb===ye||this['indexMap_']['hasIndex'](_0x4c37bb);}['equals'](_0x46517e){if(_0x46517e===this)return!0x0;if(_0x46517e['isLeafNode']())return!0x1;{const _0x5cda53=_0x46517e;if(this['getPriority']()['equals'](_0x5cda53['getPriority']())){if(this['children_']['count']()===_0x5cda53['children_']['count']()){const _0x3df7fc=this['getIterator'](R),_0x5a1f88=_0x5cda53['getIterator'](R);let _0x5eaece=_0x3df7fc['getNext'](),_0x129641=_0x5a1f88['getNext']();for(;_0x5eaece&&_0x129641;){if(_0x5eaece['name']!==_0x129641['name']||!_0x5eaece['node']['equals'](_0x129641['node']))return!0x1;_0x5eaece=_0x3df7fc['getNext'](),_0x129641=_0x5a1f88['getNext']();}return _0x5eaece===null&&_0x129641===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x39f933){return _0x39f933===ye?null:this['indexMap_']['get'](_0x39f933['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x4bcd74){return _0x4bcd74===this?0x0:0x1;}['equals'](_0x210312){return _0x210312===this;}['getPriority'](){return this;}['getImmediateChild'](_0x17e987){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x3a0e95,_0x11d4d5=null){if(_0x3a0e95===null)return g['EMPTY_NODE'];if(typeof _0x3a0e95=='object'&&'.priority'in _0x3a0e95&&(_0x11d4d5=_0x3a0e95['.priority']),f(_0x11d4d5===null||typeof _0x11d4d5=='string'||typeof _0x11d4d5=='number'||typeof _0x11d4d5=='object'&&'.sv'in _0x11d4d5,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x11d4d5),typeof _0x3a0e95=='object'&&'.value'in _0x3a0e95&&_0x3a0e95['.value']!==null&&(_0x3a0e95=_0x3a0e95['.value']),typeof _0x3a0e95!='object'||'.sv'in _0x3a0e95){const _0x2b8747=_0x3a0e95;return new D(_0x2b8747,N(_0x11d4d5));}if(!(_0x3a0e95 instanceof Array)&&Vh){const _0x2ef43f=[];let _0x5e91c5=!0x1;if(x(_0x3a0e95,(_0x51c0e0,_0x4ad505)=>{if(_0x51c0e0['substring'](0x0,0x1)!=='.'){const _0x4628f8=N(_0x4ad505);_0x4628f8['isEmpty']()||(_0x5e91c5=_0x5e91c5||!_0x4628f8['getPriority']()['isEmpty'](),_0x2ef43f['push'](new E(_0x51c0e0,_0x4628f8)));}}),_0x2ef43f['length']===0x0)return g['EMPTY_NODE'];const _0x49cd8e=dn(_0x2ef43f,Dh,_0x4b30cc=>_0x4b30cc['name'],ji);if(_0x5e91c5){const _0x297e51=dn(_0x2ef43f,R['getCompare']());return new g(_0x49cd8e,N(_0x11d4d5),new ee({'.priority':_0x297e51},{'.priority':R}));}else return new g(_0x49cd8e,N(_0x11d4d5),ee['Default']);}else{let _0xd442c1=g['EMPTY_NODE'];return x(_0x3a0e95,(_0x112ab1,_0xc5b2ec)=>{if(Y(_0x3a0e95,_0x112ab1)&&_0x112ab1['substring'](0x0,0x1)!=='.'){const _0x4be7a3=N(_0xc5b2ec);(_0x4be7a3['isLeafNode']()||!_0x4be7a3['isEmpty']())&&(_0xd442c1=_0xd442c1['updateImmediateChild'](_0x112ab1,_0x4be7a3));}}),_0xd442c1['updatePriority'](N(_0x11d4d5));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2f1374){super(),this['indexPath_']=_0x2f1374,f(!v(_0x2f1374)&&y(_0x2f1374)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x252021){return _0x252021['getChild'](this['indexPath_']);}['isDefinedOn'](_0xaa741a){return!_0xaa741a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4f148b,_0x424451){const _0x4b2073=this['extractChild'](_0x4f148b['node']),_0x38e259=this['extractChild'](_0x424451['node']),_0x5355c2=_0x4b2073['compareTo'](_0x38e259);return _0x5355c2===0x0?He(_0x4f148b['name'],_0x424451['name']):_0x5355c2;}['makePost'](_0x111691,_0x37bc49){const _0x27d402=N(_0x111691),_0x503a20=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x27d402);return new E(_0x37bc49,_0x503a20);}['maxPost'](){const _0x55a9ff=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x55a9ff);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x386db7,_0xf366ff){const _0x247b31=_0x386db7['node']['compareTo'](_0xf366ff['node']);return _0x247b31===0x0?He(_0x386db7['name'],_0xf366ff['name']):_0x247b31;}['isDefinedOn'](_0x252975){return!0x0;}['indexedValueChanged'](_0x337518,_0x2f0750){return!_0x337518['equals'](_0x2f0750);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xe61317,_0x3a9028){const _0x41c778=N(_0xe61317);return new E(_0x3a9028,_0x41c778);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x14e402){return{'type':'value','snapshotNode':_0x14e402};}function tt(_0x3ee828,_0x2f69db){return{'type':'child_added','snapshotNode':_0x2f69db,'childName':_0x3ee828};}function Nt(_0x3f7e49,_0x21191b){return{'type':'child_removed','snapshotNode':_0x21191b,'childName':_0x3f7e49};}function Pt(_0x2f7b99,_0x133d2c,_0xd68ae3){return{'type':'child_changed','snapshotNode':_0x133d2c,'childName':_0x2f7b99,'oldSnap':_0xd68ae3};}function $h(_0x3f8796,_0x4e186b){return{'type':'child_moved','snapshotNode':_0x4e186b,'childName':_0x3f8796};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x2e26eb){this['index_']=_0x2e26eb;}['updateChild'](_0x39fe43,_0xb7bb40,_0x28ecec,_0x39cb89,_0x1a9100,_0x58f640){f(_0x39fe43['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x591314=_0x39fe43['getImmediateChild'](_0xb7bb40);return _0x591314['getChild'](_0x39cb89)['equals'](_0x28ecec['getChild'](_0x39cb89))&&_0x591314['isEmpty']()===_0x28ecec['isEmpty']()||(_0x58f640!=null&&(_0x28ecec['isEmpty']()?_0x39fe43['hasChild'](_0xb7bb40)?_0x58f640['trackChildChange'](Nt(_0xb7bb40,_0x591314)):f(_0x39fe43['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x591314['isEmpty']()?_0x58f640['trackChildChange'](tt(_0xb7bb40,_0x28ecec)):_0x58f640['trackChildChange'](Pt(_0xb7bb40,_0x28ecec,_0x591314))),_0x39fe43['isLeafNode']()&&_0x28ecec['isEmpty']())?_0x39fe43:_0x39fe43['updateImmediateChild'](_0xb7bb40,_0x28ecec)['withIndex'](this['index_']);}['updateFullNode'](_0x18ac25,_0x28e204,_0x542818){return _0x542818!=null&&(_0x18ac25['isLeafNode']()||_0x18ac25['forEachChild'](R,(_0x60e653,_0x20d1c9)=>{_0x28e204['hasChild'](_0x60e653)||_0x542818['trackChildChange'](Nt(_0x60e653,_0x20d1c9));}),_0x28e204['isLeafNode']()||_0x28e204['forEachChild'](R,(_0x4faf08,_0x231954)=>{if(_0x18ac25['hasChild'](_0x4faf08)){const _0x484eca=_0x18ac25['getImmediateChild'](_0x4faf08);_0x484eca['equals'](_0x231954)||_0x542818['trackChildChange'](Pt(_0x4faf08,_0x231954,_0x484eca));}else _0x542818['trackChildChange'](tt(_0x4faf08,_0x231954));})),_0x28e204['withIndex'](this['index_']);}['updatePriority'](_0x1feddc,_0x477c4b){return _0x1feddc['isEmpty']()?g['EMPTY_NODE']:_0x1feddc['updatePriority'](_0x477c4b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x1dbd7d){this['indexedFilter_']=new Yi(_0x1dbd7d['getIndex']()),this['index_']=_0x1dbd7d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x1dbd7d),this['endPost_']=Ot['getEndPost_'](_0x1dbd7d),this['startIsInclusive_']=!_0x1dbd7d['startAfterSet_'],this['endIsInclusive_']=!_0x1dbd7d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x408aa4){const _0x59c59a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x408aa4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x408aa4)<0x0,_0x23a058=this['endIsInclusive_']?this['index_']['compare'](_0x408aa4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x408aa4,this['getEndPost']())<0x0;return _0x59c59a&&_0x23a058;}['updateChild'](_0x481f9f,_0x95ddb,_0x42b367,_0x310fe3,_0x28dfc3,_0x5ef898){return this['matches'](new E(_0x95ddb,_0x42b367))||(_0x42b367=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x481f9f,_0x95ddb,_0x42b367,_0x310fe3,_0x28dfc3,_0x5ef898);}['updateFullNode'](_0x3827b1,_0x4e28c7,_0xf180d1){_0x4e28c7['isLeafNode']()&&(_0x4e28c7=g['EMPTY_NODE']);let _0x1d0ab2=_0x4e28c7['withIndex'](this['index_']);_0x1d0ab2=_0x1d0ab2['updatePriority'](g['EMPTY_NODE']);const _0x593d2d=this;return _0x4e28c7['forEachChild'](R,(_0x18432c,_0x1c4378)=>{_0x593d2d['matches'](new E(_0x18432c,_0x1c4378))||(_0x1d0ab2=_0x1d0ab2['updateImmediateChild'](_0x18432c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3827b1,_0x1d0ab2,_0xf180d1);}['updatePriority'](_0x58fb92,_0x247670){return _0x58fb92;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x13bdb1){if(_0x13bdb1['hasStart']()){const _0x1922b7=_0x13bdb1['getIndexStartName']();return _0x13bdb1['getIndex']()['makePost'](_0x13bdb1['getIndexStartValue'](),_0x1922b7);}else return _0x13bdb1['getIndex']()['minPost']();}static['getEndPost_'](_0x3eaac){if(_0x3eaac['hasEnd']()){const _0x4b7e86=_0x3eaac['getIndexEndName']();return _0x3eaac['getIndex']()['makePost'](_0x3eaac['getIndexEndValue'](),_0x4b7e86);}else return _0x3eaac['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x3d4aee){this['withinDirectionalStart']=_0x2c7845=>this['reverse_']?this['withinEndPost'](_0x2c7845):this['withinStartPost'](_0x2c7845),this['withinDirectionalEnd']=_0x4233b2=>this['reverse_']?this['withinStartPost'](_0x4233b2):this['withinEndPost'](_0x4233b2),this['withinStartPost']=_0x435743=>{const _0x216224=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x435743);return this['startIsInclusive_']?_0x216224<=0x0:_0x216224<0x0;},this['withinEndPost']=_0x481f5a=>{const _0x1e0e69=this['index_']['compare'](_0x481f5a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1e0e69<=0x0:_0x1e0e69<0x0;},this['rangedFilter_']=new Ot(_0x3d4aee),this['index_']=_0x3d4aee['getIndex'](),this['limit_']=_0x3d4aee['getLimit'](),this['reverse_']=!_0x3d4aee['isViewFromLeft'](),this['startIsInclusive_']=!_0x3d4aee['startAfterSet_'],this['endIsInclusive_']=!_0x3d4aee['endBeforeSet_'];}['updateChild'](_0x37d9a3,_0x60dfd1,_0x2e954f,_0x484d2e,_0x2e41b9,_0x3657b8){return this['rangedFilter_']['matches'](new E(_0x60dfd1,_0x2e954f))||(_0x2e954f=g['EMPTY_NODE']),_0x37d9a3['getImmediateChild'](_0x60dfd1)['equals'](_0x2e954f)?_0x37d9a3:_0x37d9a3['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x37d9a3,_0x60dfd1,_0x2e954f,_0x484d2e,_0x2e41b9,_0x3657b8):this['fullLimitUpdateChild_'](_0x37d9a3,_0x60dfd1,_0x2e954f,_0x2e41b9,_0x3657b8);}['updateFullNode'](_0x42677b,_0x1a71f0,_0x2b1810){let _0x4edd62;if(_0x1a71f0['isLeafNode']()||_0x1a71f0['isEmpty']())_0x4edd62=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1a71f0['numChildren']()&&_0x1a71f0['isIndexed'](this['index_'])){_0x4edd62=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1517cd;this['reverse_']?_0x1517cd=_0x1a71f0['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1517cd=_0x1a71f0['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4369ed=0x0;for(;_0x1517cd['hasNext']()&&_0x4369ed<this['limit_'];){const _0x1f4453=_0x1517cd['getNext']();if(this['withinDirectionalStart'](_0x1f4453)){if(this['withinDirectionalEnd'](_0x1f4453))_0x4edd62=_0x4edd62['updateImmediateChild'](_0x1f4453['name'],_0x1f4453['node']),_0x4369ed++;else break;}else continue;}}else{_0x4edd62=_0x1a71f0['withIndex'](this['index_']),_0x4edd62=_0x4edd62['updatePriority'](g['EMPTY_NODE']);let _0x1df8ae;this['reverse_']?_0x1df8ae=_0x4edd62['getReverseIterator'](this['index_']):_0x1df8ae=_0x4edd62['getIterator'](this['index_']);let _0x31bf1a=0x0;for(;_0x1df8ae['hasNext']();){const _0x3fb5b6=_0x1df8ae['getNext']();_0x31bf1a<this['limit_']&&this['withinDirectionalStart'](_0x3fb5b6)&&this['withinDirectionalEnd'](_0x3fb5b6)?_0x31bf1a++:_0x4edd62=_0x4edd62['updateImmediateChild'](_0x3fb5b6['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x42677b,_0x4edd62,_0x2b1810);}['updatePriority'](_0x1fb9c5,_0x9a1ba6){return _0x1fb9c5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1f650e,_0x13d768,_0x1bc4d4,_0x36c4ef,_0x3d41c1){let _0x478dd9;if(this['reverse_']){const _0x344332=this['index_']['getCompare']();_0x478dd9=(_0x37478e,_0x1d301c)=>_0x344332(_0x1d301c,_0x37478e);}else _0x478dd9=this['index_']['getCompare']();const _0x3b69b1=_0x1f650e;f(_0x3b69b1['numChildren']()===this['limit_'],'');const _0x33bfc0=new E(_0x13d768,_0x1bc4d4),_0x180c86=this['reverse_']?_0x3b69b1['getFirstChild'](this['index_']):_0x3b69b1['getLastChild'](this['index_']),_0x519e42=this['rangedFilter_']['matches'](_0x33bfc0);if(_0x3b69b1['hasChild'](_0x13d768)){const _0xd6e006=_0x3b69b1['getImmediateChild'](_0x13d768);let _0x87eb7e=_0x36c4ef['getChildAfterChild'](this['index_'],_0x180c86,this['reverse_']);for(;_0x87eb7e!=null&&(_0x87eb7e['name']===_0x13d768||_0x3b69b1['hasChild'](_0x87eb7e['name']));)_0x87eb7e=_0x36c4ef['getChildAfterChild'](this['index_'],_0x87eb7e,this['reverse_']);const _0x15b3ac=_0x87eb7e==null?0x1:_0x478dd9(_0x87eb7e,_0x33bfc0);if(_0x519e42&&!_0x1bc4d4['isEmpty']()&&_0x15b3ac>=0x0)return _0x3d41c1!=null&&_0x3d41c1['trackChildChange'](Pt(_0x13d768,_0x1bc4d4,_0xd6e006)),_0x3b69b1['updateImmediateChild'](_0x13d768,_0x1bc4d4);{_0x3d41c1!=null&&_0x3d41c1['trackChildChange'](Nt(_0x13d768,_0xd6e006));const _0x3c0767=_0x3b69b1['updateImmediateChild'](_0x13d768,g['EMPTY_NODE']);return _0x87eb7e!=null&&this['rangedFilter_']['matches'](_0x87eb7e)?(_0x3d41c1!=null&&_0x3d41c1['trackChildChange'](tt(_0x87eb7e['name'],_0x87eb7e['node'])),_0x3c0767['updateImmediateChild'](_0x87eb7e['name'],_0x87eb7e['node'])):_0x3c0767;}}else return _0x1bc4d4['isEmpty']()?_0x1f650e:_0x519e42&&_0x478dd9(_0x180c86,_0x33bfc0)>=0x0?(_0x3d41c1!=null&&(_0x3d41c1['trackChildChange'](Nt(_0x180c86['name'],_0x180c86['node'])),_0x3d41c1['trackChildChange'](tt(_0x13d768,_0x1bc4d4))),_0x3b69b1['updateImmediateChild'](_0x13d768,_0x1bc4d4)['updateImmediateChild'](_0x180c86['name'],g['EMPTY_NODE'])):_0x1f650e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5c44a8=new Qi();return _0x5c44a8['limitSet_']=this['limitSet_'],_0x5c44a8['limit_']=this['limit_'],_0x5c44a8['startSet_']=this['startSet_'],_0x5c44a8['startAfterSet_']=this['startAfterSet_'],_0x5c44a8['indexStartValue_']=this['indexStartValue_'],_0x5c44a8['startNameSet_']=this['startNameSet_'],_0x5c44a8['indexStartName_']=this['indexStartName_'],_0x5c44a8['endSet_']=this['endSet_'],_0x5c44a8['endBeforeSet_']=this['endBeforeSet_'],_0x5c44a8['indexEndValue_']=this['indexEndValue_'],_0x5c44a8['endNameSet_']=this['endNameSet_'],_0x5c44a8['indexEndName_']=this['indexEndName_'],_0x5c44a8['index_']=this['index_'],_0x5c44a8['viewFrom_']=this['viewFrom_'],_0x5c44a8;}}function qh(_0x3d188d){return _0x3d188d['loadsAllData']()?new Yi(_0x3d188d['getIndex']()):_0x3d188d['hasLimit']()?new Gh(_0x3d188d):new Ot(_0x3d188d);}function zh(_0x5aa4ac,_0x4e00b6){const _0x45e331=_0x5aa4ac['copy']();return _0x45e331['limitSet_']=!0x0,_0x45e331['limit_']=_0x4e00b6,_0x45e331['viewFrom_']='l',_0x45e331;}function jh(_0x45892c,_0x3dcbc9,_0x16802b){const _0x355c58=_0x45892c['copy']();return _0x355c58['startSet_']=!0x0,_0x3dcbc9===void 0x0&&(_0x3dcbc9=null),_0x355c58['indexStartValue_']=_0x3dcbc9,_0x16802b!=null?(_0x355c58['startNameSet_']=!0x0,_0x355c58['indexStartName_']=_0x16802b):(_0x355c58['startNameSet_']=!0x1,_0x355c58['indexStartName_']=''),_0x355c58;}function Kh(_0x22c975,_0x3429fc,_0x22e30f){const _0x8f6ef8=_0x22c975['copy']();return _0x8f6ef8['endSet_']=!0x0,_0x3429fc===void 0x0&&(_0x3429fc=null),_0x8f6ef8['indexEndValue_']=_0x3429fc,_0x22e30f!==void 0x0?(_0x8f6ef8['endNameSet_']=!0x0,_0x8f6ef8['indexEndName_']=_0x22e30f):(_0x8f6ef8['endNameSet_']=!0x1,_0x8f6ef8['indexEndName_']=''),_0x8f6ef8;}function Do(_0x5380de,_0x50a658){const _0x424f0c=_0x5380de['copy']();return _0x424f0c['index_']=_0x50a658,_0x424f0c;}function tr(_0x96b498){const _0x4d3677={};if(_0x96b498['isDefault']())return _0x4d3677;let _0x2f79bc;if(_0x96b498['index_']===R?_0x2f79bc='$priority':_0x96b498['index_']===Po?_0x2f79bc='$value':_0x96b498['index_']===ye?_0x2f79bc='$key':(f(_0x96b498['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x2f79bc=_0x96b498['index_']['toString']()),_0x4d3677['orderBy']=O(_0x2f79bc),_0x96b498['startSet_']){const _0x50cf05=_0x96b498['startAfterSet_']?'startAfter':'startAt';_0x4d3677[_0x50cf05]=O(_0x96b498['indexStartValue_']),_0x96b498['startNameSet_']&&(_0x4d3677[_0x50cf05]+=','+O(_0x96b498['indexStartName_']));}if(_0x96b498['endSet_']){const _0x42e75f=_0x96b498['endBeforeSet_']?'endBefore':'endAt';_0x4d3677[_0x42e75f]=O(_0x96b498['indexEndValue_']),_0x96b498['endNameSet_']&&(_0x4d3677[_0x42e75f]+=','+O(_0x96b498['indexEndName_']));}return _0x96b498['limitSet_']&&(_0x96b498['isViewFromLeft']()?_0x4d3677['limitToFirst']=_0x96b498['limit_']:_0x4d3677['limitToLast']=_0x96b498['limit_']),_0x4d3677;}function nr(_0x143d46){const _0xf8facb={};if(_0x143d46['startSet_']&&(_0xf8facb['sp']=_0x143d46['indexStartValue_'],_0x143d46['startNameSet_']&&(_0xf8facb['sn']=_0x143d46['indexStartName_']),_0xf8facb['sin']=!_0x143d46['startAfterSet_']),_0x143d46['endSet_']&&(_0xf8facb['ep']=_0x143d46['indexEndValue_'],_0x143d46['endNameSet_']&&(_0xf8facb['en']=_0x143d46['indexEndName_']),_0xf8facb['ein']=!_0x143d46['endBeforeSet_']),_0x143d46['limitSet_']){_0xf8facb['l']=_0x143d46['limit_'];let _0x556074=_0x143d46['viewFrom_'];_0x556074===''&&(_0x143d46['isViewFromLeft']()?_0x556074='l':_0x556074='r'),_0xf8facb['vf']=_0x556074;}return _0x143d46['index_']!==R&&(_0xf8facb['i']=_0x143d46['index_']['toString']()),_0xf8facb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x12fe72){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x27ebd4,_0x43d7ad){return _0x43d7ad!==void 0x0?'tag$'+_0x43d7ad:(f(_0x27ebd4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x27ebd4['_path']['toString']());}constructor(_0x3599e2,_0x36ce4f,_0x3bef82,_0x4b9d66){super(),this['repoInfo_']=_0x3599e2,this['onDataUpdate_']=_0x36ce4f,this['authTokenProvider_']=_0x3bef82,this['appCheckTokenProvider_']=_0x4b9d66,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4140db,_0x1b06c3,_0x26780c,_0x272619){const _0x49d22e=_0x4140db['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x49d22e+'\x20'+_0x4140db['_queryIdentifier']);const _0x46140b=fn['getListenId_'](_0x4140db,_0x26780c),_0x188211={};this['listens_'][_0x46140b]=_0x188211;const _0x5ec3ae=tr(_0x4140db['_queryParams']);this['restRequest_'](_0x49d22e+'.json',_0x5ec3ae,(_0x52cb7f,_0x23fe9a)=>{let _0x906ee4=_0x23fe9a;if(_0x52cb7f===0x194&&(_0x906ee4=null,_0x52cb7f=null),_0x52cb7f===null&&this['onDataUpdate_'](_0x49d22e,_0x906ee4,!0x1,_0x26780c),Oe(this['listens_'],_0x46140b)===_0x188211){let _0x2920db;_0x52cb7f?_0x52cb7f===0x191?_0x2920db='permission_denied':_0x2920db='rest_error:'+_0x52cb7f:_0x2920db='ok',_0x272619(_0x2920db,null);}});}['unlisten'](_0x19292a,_0x548c2f){const _0x536467=fn['getListenId_'](_0x19292a,_0x548c2f);delete this['listens_'][_0x536467];}['get'](_0x3a5882){const _0x23e4e2=tr(_0x3a5882['_queryParams']),_0x3a1221=_0x3a5882['_path']['toString'](),_0x46beb6=new Ve();return this['restRequest_'](_0x3a1221+'.json',_0x23e4e2,(_0x291cc2,_0x164d2c)=>{let _0x759175=_0x164d2c;_0x291cc2===0x194&&(_0x759175=null,_0x291cc2=null),_0x291cc2===null?(this['onDataUpdate_'](_0x3a1221,_0x759175,!0x1,null),_0x46beb6['resolve'](_0x759175)):_0x46beb6['reject'](new Error(_0x759175));}),_0x46beb6['promise'];}['refreshAuthToken'](_0x32c7e6){}['restRequest_'](_0x252534,_0x372d01={},_0x30c508){return _0x372d01['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3854ad,_0x29b114])=>{_0x3854ad&&_0x3854ad['accessToken']&&(_0x372d01['auth']=_0x3854ad['accessToken']),_0x29b114&&_0x29b114['token']&&(_0x372d01['ac']=_0x29b114['token']);const _0x2926d0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x252534+'?ns='+this['repoInfo_']['namespace']+at(_0x372d01);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2926d0);const _0x5dd3e0=new XMLHttpRequest();_0x5dd3e0['onreadystatechange']=()=>{if(_0x30c508&&_0x5dd3e0['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2926d0+'\x20received.\x20status:',_0x5dd3e0['status'],'response:',_0x5dd3e0['responseText']);let _0x2656f1=null;if(_0x5dd3e0['status']>=0xc8&&_0x5dd3e0['status']<0x12c){try{_0x2656f1=bt(_0x5dd3e0['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2926d0+':\x20'+_0x5dd3e0['responseText']);}_0x30c508(null,_0x2656f1);}else _0x5dd3e0['status']!==0x191&&_0x5dd3e0['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2926d0+'\x20Status:\x20'+_0x5dd3e0['status']),_0x30c508(_0x5dd3e0['status']);_0x30c508=null;}},_0x5dd3e0['open']('GET',_0x2926d0,!0x0),_0x5dd3e0['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x15d569){return this['rootNode_']['getChild'](_0x15d569);}['updateSnapshot'](_0x2600c5,_0x363551){this['rootNode_']=this['rootNode_']['updateChild'](_0x2600c5,_0x363551);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x183bce,_0x3b6e5c,_0xed947f){if(v(_0x3b6e5c))_0x183bce['value']=_0xed947f,_0x183bce['children']['clear']();else{if(_0x183bce['value']!==null)_0x183bce['value']=_0x183bce['value']['updateChild'](_0x3b6e5c,_0xed947f);else{const _0x413a28=y(_0x3b6e5c);_0x183bce['children']['has'](_0x413a28)||_0x183bce['children']['set'](_0x413a28,pn());const _0xeeb938=_0x183bce['children']['get'](_0x413a28);_0x3b6e5c=b(_0x3b6e5c),Mo(_0xeeb938,_0x3b6e5c,_0xed947f);}}}function Ei(_0x25ecc7,_0x197668,_0x59ca62){_0x25ecc7['value']!==null?_0x59ca62(_0x197668,_0x25ecc7['value']):Qh(_0x25ecc7,(_0x5dec3e,_0x5db8a1)=>{const _0x2706ed=new C(_0x197668['toString']()+'/'+_0x5dec3e);Ei(_0x5db8a1,_0x2706ed,_0x59ca62);});}function Qh(_0x9b7151,_0x5184d6){_0x9b7151['children']['forEach']((_0x5d1cba,_0x8fc613)=>{_0x5184d6(_0x8fc613,_0x5d1cba);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x3bdc1f){this['collection_']=_0x3bdc1f,this['last_']=null;}['get'](){const _0x358147=this['collection_']['get'](),_0x30ba8a={..._0x358147};return this['last_']&&x(this['last_'],(_0x159529,_0x4e670d)=>{_0x30ba8a[_0x159529]=_0x30ba8a[_0x159529]-_0x4e670d;}),this['last_']=_0x358147,_0x30ba8a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x37bc7c,_0x1fbe4b){this['server_']=_0x1fbe4b,this['statsToReport_']={},this['statsListener_']=new Jh(_0x37bc7c);const _0x1dc36a=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1dc36a));}['reportStats_'](){const _0x415d5f=this['statsListener_']['get'](),_0x4a8161={};let _0x2259cc=!0x1;x(_0x415d5f,(_0x8982c0,_0x356484)=>{_0x356484>0x0&&Y(this['statsToReport_'],_0x8982c0)&&(_0x4a8161[_0x8982c0]=_0x356484,_0x2259cc=!0x0);}),_0x2259cc&&this['server_']['reportStats'](_0x4a8161),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x23d567){_0x23d567[_0x23d567['OVERWRITE']=0x0]='OVERWRITE',_0x23d567[_0x23d567['MERGE']=0x1]='MERGE',_0x23d567[_0x23d567['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x23d567[_0x23d567['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x41afb6){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x41afb6,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x319a84,_0x15dd84,_0x2b4f4b){this['path']=_0x319a84,this['affectedTree']=_0x15dd84,this['revert']=_0x2b4f4b,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x2032af){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x30a45d=this['affectedTree']['subtree'](new C(_0x2032af));return new _n(w(),_0x30a45d,this['revert']);}}else return f(y(this['path'])===_0x2032af,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x134404,_0xe1c827){this['source']=_0x134404,this['path']=_0xe1c827,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x374897){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2443e0,_0x3b484b,_0x17bcbd){this['source']=_0x2443e0,this['path']=_0x3b484b,this['snap']=_0x17bcbd,this['type']=q['OVERWRITE'];}['operationForChild'](_0x5210da){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x5210da)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x2c54df,_0x4a396b,_0x19f98f){this['source']=_0x2c54df,this['path']=_0x4a396b,this['children']=_0x19f98f,this['type']=q['MERGE'];}['operationForChild'](_0x156b5f){if(v(this['path'])){const _0x11810a=this['children']['subtree'](new C(_0x156b5f));return _0x11810a['isEmpty']()?null:_0x11810a['value']?new Fe(this['source'],w(),_0x11810a['value']):new nt(this['source'],w(),_0x11810a);}else return f(y(this['path'])===_0x156b5f,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x488a3c,_0x4b58d8,_0x10e8be){this['node_']=_0x488a3c,this['fullyInitialized_']=_0x4b58d8,this['filtered_']=_0x10e8be;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x507c75){if(v(_0x507c75))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1fb5fc=y(_0x507c75);return this['isCompleteForChild'](_0x1fb5fc);}['isCompleteForChild'](_0xa2a1c8){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0xa2a1c8);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4cc495){this['query_']=_0x4cc495,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4d66af,_0x115230,_0x11e41f,_0x3f51f0){const _0x6f4dc9=[],_0x5e9d62=[];return _0x115230['forEach'](_0x21df1e=>{_0x21df1e['type']==='child_changed'&&_0x4d66af['index_']['indexedValueChanged'](_0x21df1e['oldSnap'],_0x21df1e['snapshotNode'])&&_0x5e9d62['push']($h(_0x21df1e['childName'],_0x21df1e['snapshotNode']));}),mt(_0x4d66af,_0x6f4dc9,'child_removed',_0x115230,_0x3f51f0,_0x11e41f),mt(_0x4d66af,_0x6f4dc9,'child_added',_0x115230,_0x3f51f0,_0x11e41f),mt(_0x4d66af,_0x6f4dc9,'child_moved',_0x5e9d62,_0x3f51f0,_0x11e41f),mt(_0x4d66af,_0x6f4dc9,'child_changed',_0x115230,_0x3f51f0,_0x11e41f),mt(_0x4d66af,_0x6f4dc9,'value',_0x115230,_0x3f51f0,_0x11e41f),_0x6f4dc9;}function mt(_0x18d459,_0x5ba608,_0x21cdd7,_0x2ed0d4,_0x331a47,_0x1b3f6e){const _0x4991cd=_0x2ed0d4['filter'](_0x52e67a=>_0x52e67a['type']===_0x21cdd7);_0x4991cd['sort']((_0x90afbc,_0x20dc6e)=>su(_0x18d459,_0x90afbc,_0x20dc6e)),_0x4991cd['forEach'](_0x4d3222=>{const _0x44f6f2=iu(_0x18d459,_0x4d3222,_0x1b3f6e);_0x331a47['forEach'](_0x4f467a=>{_0x4f467a['respondsTo'](_0x4d3222['type'])&&_0x5ba608['push'](_0x4f467a['createEvent'](_0x44f6f2,_0x18d459['query_']));});});}function iu(_0x551e7d,_0x5840bd,_0x1f6969){return _0x5840bd['type']==='value'||_0x5840bd['type']==='child_removed'||(_0x5840bd['prevName']=_0x1f6969['getPredecessorChildName'](_0x5840bd['childName'],_0x5840bd['snapshotNode'],_0x551e7d['index_'])),_0x5840bd;}function su(_0x157f9b,_0xcf9bed,_0x5399ea){if(_0xcf9bed['childName']==null||_0x5399ea['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x16019d=new E(_0xcf9bed['childName'],_0xcf9bed['snapshotNode']),_0x63b3ac=new E(_0x5399ea['childName'],_0x5399ea['snapshotNode']);return _0x157f9b['index_']['compare'](_0x16019d,_0x63b3ac);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x18af21,_0x2f1474){return{'eventCache':_0x18af21,'serverCache':_0x2f1474};}function wt(_0x3b815b,_0x48d070,_0xcfdf38,_0x1036c8){return Dn(new Ce(_0x48d070,_0xcfdf38,_0x1036c8),_0x3b815b['serverCache']);}function Lo(_0x28b8fb,_0x1a2b53,_0x268933,_0x11bb4a){return Dn(_0x28b8fb['eventCache'],new Ce(_0x1a2b53,_0x268933,_0x11bb4a));}function gn(_0x51a9b3){return _0x51a9b3['eventCache']['isFullyInitialized']()?_0x51a9b3['eventCache']['getNode']():null;}function Ue(_0x4150b3){return _0x4150b3['serverCache']['isFullyInitialized']()?_0x4150b3['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x221bc3){let _0x215955=new S(null);return x(_0x221bc3,(_0x2d68b6,_0x1da266)=>{_0x215955=_0x215955['set'](new C(_0x2d68b6),_0x1da266);}),_0x215955;}constructor(_0x53fda8,_0x4541b=ru()){this['value']=_0x53fda8,this['children']=_0x4541b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3029f0,_0x45f10b){if(this['value']!=null&&_0x45f10b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3029f0))return null;{const _0xf3faf6=y(_0x3029f0),_0x324a4a=this['children']['get'](_0xf3faf6);if(_0x324a4a!==null){const _0x568337=_0x324a4a['findRootMostMatchingPathAndValue'](b(_0x3029f0),_0x45f10b);return _0x568337!=null?{'path':A(new C(_0xf3faf6),_0x568337['path']),'value':_0x568337['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xabecdc){return this['findRootMostMatchingPathAndValue'](_0xabecdc,()=>!0x0);}['subtree'](_0x368c5b){if(v(_0x368c5b))return this;{const _0x5b4202=y(_0x368c5b),_0x3077d4=this['children']['get'](_0x5b4202);return _0x3077d4!==null?_0x3077d4['subtree'](b(_0x368c5b)):new S(null);}}['set'](_0x1fb435,_0x18c367){if(v(_0x1fb435))return new S(_0x18c367,this['children']);{const _0x4e95b7=y(_0x1fb435),_0xc68aad=(this['children']['get'](_0x4e95b7)||new S(null))['set'](b(_0x1fb435),_0x18c367),_0x45c22e=this['children']['insert'](_0x4e95b7,_0xc68aad);return new S(this['value'],_0x45c22e);}}['remove'](_0x7ce2bd){if(v(_0x7ce2bd))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x310eb9=y(_0x7ce2bd),_0x5c0ae7=this['children']['get'](_0x310eb9);if(_0x5c0ae7){const _0x3796f7=_0x5c0ae7['remove'](b(_0x7ce2bd));let _0x292090;return _0x3796f7['isEmpty']()?_0x292090=this['children']['remove'](_0x310eb9):_0x292090=this['children']['insert'](_0x310eb9,_0x3796f7),this['value']===null&&_0x292090['isEmpty']()?new S(null):new S(this['value'],_0x292090);}else return this;}}['get'](_0x32b2ef){if(v(_0x32b2ef))return this['value'];{const _0x1e0cdf=y(_0x32b2ef),_0x2989c4=this['children']['get'](_0x1e0cdf);return _0x2989c4?_0x2989c4['get'](b(_0x32b2ef)):null;}}['setTree'](_0x1ebb12,_0x418504){if(v(_0x1ebb12))return _0x418504;{const _0x71d5d2=y(_0x1ebb12),_0x2ef85f=(this['children']['get'](_0x71d5d2)||new S(null))['setTree'](b(_0x1ebb12),_0x418504);let _0x38474e;return _0x2ef85f['isEmpty']()?_0x38474e=this['children']['remove'](_0x71d5d2):_0x38474e=this['children']['insert'](_0x71d5d2,_0x2ef85f),new S(this['value'],_0x38474e);}}['fold'](_0x561ad9){return this['fold_'](w(),_0x561ad9);}['fold_'](_0x9e928,_0xa6ffb1){const _0x215e01={};return this['children']['inorderTraversal']((_0x5955f3,_0x1abdb5)=>{_0x215e01[_0x5955f3]=_0x1abdb5['fold_'](A(_0x9e928,_0x5955f3),_0xa6ffb1);}),_0xa6ffb1(_0x9e928,this['value'],_0x215e01);}['findOnPath'](_0x21f9fb,_0x376ae5){return this['findOnPath_'](_0x21f9fb,w(),_0x376ae5);}['findOnPath_'](_0x55a2d8,_0x3bd80f,_0x2a7421){const _0x224efb=this['value']?_0x2a7421(_0x3bd80f,this['value']):!0x1;if(_0x224efb)return _0x224efb;if(v(_0x55a2d8))return null;{const _0x7393cb=y(_0x55a2d8),_0x2fd57f=this['children']['get'](_0x7393cb);return _0x2fd57f?_0x2fd57f['findOnPath_'](b(_0x55a2d8),A(_0x3bd80f,_0x7393cb),_0x2a7421):null;}}['foreachOnPath'](_0x147459,_0x250c80){return this['foreachOnPath_'](_0x147459,w(),_0x250c80);}['foreachOnPath_'](_0x335f6e,_0x52f591,_0x3a9328){if(v(_0x335f6e))return this;{this['value']&&_0x3a9328(_0x52f591,this['value']);const _0x441721=y(_0x335f6e),_0x5cb564=this['children']['get'](_0x441721);return _0x5cb564?_0x5cb564['foreachOnPath_'](b(_0x335f6e),A(_0x52f591,_0x441721),_0x3a9328):new S(null);}}['foreach'](_0x560a9d){this['foreach_'](w(),_0x560a9d);}['foreach_'](_0x41cad3,_0x32908a){this['children']['inorderTraversal']((_0x1f296a,_0x29cbe4)=>{_0x29cbe4['foreach_'](A(_0x41cad3,_0x1f296a),_0x32908a);}),this['value']&&_0x32908a(_0x41cad3,this['value']);}['foreachChild'](_0x317643){this['children']['inorderTraversal']((_0x4f66ae,_0x377556)=>{_0x377556['value']&&_0x317643(_0x4f66ae,_0x377556['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x17af8c){this['writeTree_']=_0x17af8c;}static['empty'](){return new j(new S(null));}}function Ct(_0x373c6e,_0x2e7745,_0x441ac1){if(v(_0x2e7745))return new j(new S(_0x441ac1));{const _0x1e8099=_0x373c6e['writeTree_']['findRootMostValueAndPath'](_0x2e7745);if(_0x1e8099!=null){const _0x26f15e=_0x1e8099['path'];let _0x4dca8a=_0x1e8099['value'];const _0xd9ed66=F(_0x26f15e,_0x2e7745);return _0x4dca8a=_0x4dca8a['updateChild'](_0xd9ed66,_0x441ac1),new j(_0x373c6e['writeTree_']['set'](_0x26f15e,_0x4dca8a));}else{const _0x32a8c6=new S(_0x441ac1),_0x31e430=_0x373c6e['writeTree_']['setTree'](_0x2e7745,_0x32a8c6);return new j(_0x31e430);}}}function Ii(_0x51bd6a,_0x4a4db2,_0x1ce206){let _0x3c9bce=_0x51bd6a;return x(_0x1ce206,(_0x195a86,_0x2e9a27)=>{_0x3c9bce=Ct(_0x3c9bce,A(_0x4a4db2,_0x195a86),_0x2e9a27);}),_0x3c9bce;}function sr(_0x3cbd72,_0x42a8d5){if(v(_0x42a8d5))return j['empty']();{const _0x5b12a5=_0x3cbd72['writeTree_']['setTree'](_0x42a8d5,new S(null));return new j(_0x5b12a5);}}function wi(_0xdc91ac,_0x52744a){return $e(_0xdc91ac,_0x52744a)!=null;}function $e(_0x42a59e,_0x833b7f){const _0x38a889=_0x42a59e['writeTree_']['findRootMostValueAndPath'](_0x833b7f);return _0x38a889!=null?_0x42a59e['writeTree_']['get'](_0x38a889['path'])['getChild'](F(_0x38a889['path'],_0x833b7f)):null;}function rr(_0x4fc5d5){const _0x1d07f2=[],_0x946efc=_0x4fc5d5['writeTree_']['value'];return _0x946efc!=null?_0x946efc['isLeafNode']()||_0x946efc['forEachChild'](R,(_0x5b37bb,_0x363418)=>{_0x1d07f2['push'](new E(_0x5b37bb,_0x363418));}):_0x4fc5d5['writeTree_']['children']['inorderTraversal']((_0xbb1dab,_0x1e690d)=>{_0x1e690d['value']!=null&&_0x1d07f2['push'](new E(_0xbb1dab,_0x1e690d['value']));}),_0x1d07f2;}function ve(_0x11f564,_0x2ce436){if(v(_0x2ce436))return _0x11f564;{const _0x312df8=$e(_0x11f564,_0x2ce436);return _0x312df8!=null?new j(new S(_0x312df8)):new j(_0x11f564['writeTree_']['subtree'](_0x2ce436));}}function Ci(_0x5a07e9){return _0x5a07e9['writeTree_']['isEmpty']();}function it(_0x1224ad,_0x3d19ad){return xo(w(),_0x1224ad['writeTree_'],_0x3d19ad);}function xo(_0x2fb64f,_0x3277ca,_0x54634c){if(_0x3277ca['value']!=null)return _0x54634c['updateChild'](_0x2fb64f,_0x3277ca['value']);{let _0x2cb2c6=null;return _0x3277ca['children']['inorderTraversal']((_0x139ca6,_0x56746a)=>{_0x139ca6==='.priority'?(f(_0x56746a['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2cb2c6=_0x56746a['value']):_0x54634c=xo(A(_0x2fb64f,_0x139ca6),_0x56746a,_0x54634c);}),!_0x54634c['getChild'](_0x2fb64f)['isEmpty']()&&_0x2cb2c6!==null&&(_0x54634c=_0x54634c['updateChild'](A(_0x2fb64f,'.priority'),_0x2cb2c6)),_0x54634c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x435119,_0x333881){return Bo(_0x333881,_0x435119);}function ou(_0x51ccd6,_0x1760c2,_0x2273ef,_0x2fe53e,_0x6c093){f(_0x2fe53e>_0x51ccd6['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x6c093===void 0x0&&(_0x6c093=!0x0),_0x51ccd6['allWrites']['push']({'path':_0x1760c2,'snap':_0x2273ef,'writeId':_0x2fe53e,'visible':_0x6c093}),_0x6c093&&(_0x51ccd6['visibleWrites']=Ct(_0x51ccd6['visibleWrites'],_0x1760c2,_0x2273ef)),_0x51ccd6['lastWriteId']=_0x2fe53e;}function au(_0x395c6d,_0x304c91,_0x109c92,_0x213e8f){f(_0x213e8f>_0x395c6d['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x395c6d['allWrites']['push']({'path':_0x304c91,'children':_0x109c92,'writeId':_0x213e8f,'visible':!0x0}),_0x395c6d['visibleWrites']=Ii(_0x395c6d['visibleWrites'],_0x304c91,_0x109c92),_0x395c6d['lastWriteId']=_0x213e8f;}function cu(_0x39733b,_0x1e0d55){for(let _0x5f17bd=0x0;_0x5f17bd<_0x39733b['allWrites']['length'];_0x5f17bd++){const _0x2ef213=_0x39733b['allWrites'][_0x5f17bd];if(_0x2ef213['writeId']===_0x1e0d55)return _0x2ef213;}return null;}function lu(_0x22ff63,_0x44afae){const _0x29f014=_0x22ff63['allWrites']['findIndex'](_0x555074=>_0x555074['writeId']===_0x44afae);f(_0x29f014>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x49c167=_0x22ff63['allWrites'][_0x29f014];_0x22ff63['allWrites']['splice'](_0x29f014,0x1);let _0xd1fad=_0x49c167['visible'],_0x26faee=!0x1,_0x163bf2=_0x22ff63['allWrites']['length']-0x1;for(;_0xd1fad&&_0x163bf2>=0x0;){const _0x4cc042=_0x22ff63['allWrites'][_0x163bf2];_0x4cc042['visible']&&(_0x163bf2>=_0x29f014&&hu(_0x4cc042,_0x49c167['path'])?_0xd1fad=!0x1:$(_0x49c167['path'],_0x4cc042['path'])&&(_0x26faee=!0x0)),_0x163bf2--;}if(_0xd1fad){if(_0x26faee)return uu(_0x22ff63),!0x0;if(_0x49c167['snap'])_0x22ff63['visibleWrites']=sr(_0x22ff63['visibleWrites'],_0x49c167['path']);else{const _0x188f4a=_0x49c167['children'];x(_0x188f4a,_0x232124=>{_0x22ff63['visibleWrites']=sr(_0x22ff63['visibleWrites'],A(_0x49c167['path'],_0x232124));});}return!0x0;}else return!0x1;}function hu(_0x345122,_0x2a5279){if(_0x345122['snap'])return $(_0x345122['path'],_0x2a5279);for(const _0x30c8d1 in _0x345122['children'])if(_0x345122['children']['hasOwnProperty'](_0x30c8d1)&&$(A(_0x345122['path'],_0x30c8d1),_0x2a5279))return!0x0;return!0x1;}function uu(_0x265577){_0x265577['visibleWrites']=Fo(_0x265577['allWrites'],du,w()),_0x265577['allWrites']['length']>0x0?_0x265577['lastWriteId']=_0x265577['allWrites'][_0x265577['allWrites']['length']-0x1]['writeId']:_0x265577['lastWriteId']=-0x1;}function du(_0x33dcd0){return _0x33dcd0['visible'];}function Fo(_0x3a2ed0,_0xe4053f,_0x782c85){let _0x238dfd=j['empty']();for(let _0x5092e9=0x0;_0x5092e9<_0x3a2ed0['length'];++_0x5092e9){const _0x2fc9af=_0x3a2ed0[_0x5092e9];if(_0xe4053f(_0x2fc9af)){const _0x164a64=_0x2fc9af['path'];let _0x10c455;if(_0x2fc9af['snap'])$(_0x782c85,_0x164a64)?(_0x10c455=F(_0x782c85,_0x164a64),_0x238dfd=Ct(_0x238dfd,_0x10c455,_0x2fc9af['snap'])):$(_0x164a64,_0x782c85)&&(_0x10c455=F(_0x164a64,_0x782c85),_0x238dfd=Ct(_0x238dfd,w(),_0x2fc9af['snap']['getChild'](_0x10c455)));else{if(_0x2fc9af['children']){if($(_0x782c85,_0x164a64))_0x10c455=F(_0x782c85,_0x164a64),_0x238dfd=Ii(_0x238dfd,_0x10c455,_0x2fc9af['children']);else{if($(_0x164a64,_0x782c85)){if(_0x10c455=F(_0x164a64,_0x782c85),v(_0x10c455))_0x238dfd=Ii(_0x238dfd,w(),_0x2fc9af['children']);else{const _0x158b3f=Oe(_0x2fc9af['children'],y(_0x10c455));if(_0x158b3f){const _0x210a1f=_0x158b3f['getChild'](b(_0x10c455));_0x238dfd=Ct(_0x238dfd,w(),_0x210a1f);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x238dfd;}function Uo(_0x550bf3,_0x5b337f,_0x26cd3a,_0x4a1916,_0x49f9c9){if(!_0x4a1916&&!_0x49f9c9){const _0x5c1cff=$e(_0x550bf3['visibleWrites'],_0x5b337f);if(_0x5c1cff!=null)return _0x5c1cff;{const _0x34e570=ve(_0x550bf3['visibleWrites'],_0x5b337f);if(Ci(_0x34e570))return _0x26cd3a;if(_0x26cd3a==null&&!wi(_0x34e570,w()))return null;{const _0x1ad7ee=_0x26cd3a||g['EMPTY_NODE'];return it(_0x34e570,_0x1ad7ee);}}}else{const _0x4b1c8d=ve(_0x550bf3['visibleWrites'],_0x5b337f);if(!_0x49f9c9&&Ci(_0x4b1c8d))return _0x26cd3a;if(!_0x49f9c9&&_0x26cd3a==null&&!wi(_0x4b1c8d,w()))return null;{const _0x27cfba=function(_0x22a0c5){return(_0x22a0c5['visible']||_0x49f9c9)&&(!_0x4a1916||!~_0x4a1916['indexOf'](_0x22a0c5['writeId']))&&($(_0x22a0c5['path'],_0x5b337f)||$(_0x5b337f,_0x22a0c5['path']));},_0x315254=Fo(_0x550bf3['allWrites'],_0x27cfba,_0x5b337f),_0x3c77ac=_0x26cd3a||g['EMPTY_NODE'];return it(_0x315254,_0x3c77ac);}}}function fu(_0x7855e8,_0x4c84ea,_0xed996c){let _0x339be9=g['EMPTY_NODE'];const _0xca5d3f=$e(_0x7855e8['visibleWrites'],_0x4c84ea);if(_0xca5d3f)return _0xca5d3f['isLeafNode']()||_0xca5d3f['forEachChild'](R,(_0x56521b,_0x5033af)=>{_0x339be9=_0x339be9['updateImmediateChild'](_0x56521b,_0x5033af);}),_0x339be9;if(_0xed996c){const _0x2894f2=ve(_0x7855e8['visibleWrites'],_0x4c84ea);return _0xed996c['forEachChild'](R,(_0x419511,_0x233a8e)=>{const _0x382e75=it(ve(_0x2894f2,new C(_0x419511)),_0x233a8e);_0x339be9=_0x339be9['updateImmediateChild'](_0x419511,_0x382e75);}),rr(_0x2894f2)['forEach'](_0x4b1d92=>{_0x339be9=_0x339be9['updateImmediateChild'](_0x4b1d92['name'],_0x4b1d92['node']);}),_0x339be9;}else{const _0x55bda2=ve(_0x7855e8['visibleWrites'],_0x4c84ea);return rr(_0x55bda2)['forEach'](_0x18fbdb=>{_0x339be9=_0x339be9['updateImmediateChild'](_0x18fbdb['name'],_0x18fbdb['node']);}),_0x339be9;}}function pu(_0x30a426,_0x3c4275,_0x25bfdf,_0x58e8e5,_0x3d03cb){f(_0x58e8e5||_0x3d03cb,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2b26b3=A(_0x3c4275,_0x25bfdf);if(wi(_0x30a426['visibleWrites'],_0x2b26b3))return null;{const _0x148646=ve(_0x30a426['visibleWrites'],_0x2b26b3);return Ci(_0x148646)?_0x3d03cb['getChild'](_0x25bfdf):it(_0x148646,_0x3d03cb['getChild'](_0x25bfdf));}}function _u(_0x562a20,_0x408d73,_0x5158f4,_0x1c0323){const _0x4b2aa1=A(_0x408d73,_0x5158f4),_0x39058c=$e(_0x562a20['visibleWrites'],_0x4b2aa1);if(_0x39058c!=null)return _0x39058c;if(_0x1c0323['isCompleteForChild'](_0x5158f4)){const _0x4b1a50=ve(_0x562a20['visibleWrites'],_0x4b2aa1);return it(_0x4b1a50,_0x1c0323['getNode']()['getImmediateChild'](_0x5158f4));}else return null;}function gu(_0x4341ad,_0x6fcc22){return $e(_0x4341ad['visibleWrites'],_0x6fcc22);}function mu(_0x103b38,_0x10d121,_0x5da902,_0x3851f8,_0x145712,_0x41d434,_0x5c04a6){let _0x169871;const _0x34a275=ve(_0x103b38['visibleWrites'],_0x10d121),_0x374f27=$e(_0x34a275,w());if(_0x374f27!=null)_0x169871=_0x374f27;else{if(_0x5da902!=null)_0x169871=it(_0x34a275,_0x5da902);else return[];}if(_0x169871=_0x169871['withIndex'](_0x5c04a6),!_0x169871['isEmpty']()&&!_0x169871['isLeafNode']()){const _0x120648=[],_0xd4b994=_0x5c04a6['getCompare'](),_0x5e2169=_0x41d434?_0x169871['getReverseIteratorFrom'](_0x3851f8,_0x5c04a6):_0x169871['getIteratorFrom'](_0x3851f8,_0x5c04a6);let _0x4c36b6=_0x5e2169['getNext']();for(;_0x4c36b6&&_0x120648['length']<_0x145712;)_0xd4b994(_0x4c36b6,_0x3851f8)!==0x0&&_0x120648['push'](_0x4c36b6),_0x4c36b6=_0x5e2169['getNext']();return _0x120648;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xa55c2,_0x2f3dea,_0x3ea4d7,_0x8b4bfe){return Uo(_0xa55c2['writeTree'],_0xa55c2['treePath'],_0x2f3dea,_0x3ea4d7,_0x8b4bfe);}function es(_0x5909cc,_0x6fc098){return fu(_0x5909cc['writeTree'],_0x5909cc['treePath'],_0x6fc098);}function or(_0x3e2a10,_0x158cce,_0x481f85,_0x3ec40c){return pu(_0x3e2a10['writeTree'],_0x3e2a10['treePath'],_0x158cce,_0x481f85,_0x3ec40c);}function yn(_0x404357,_0x2cca33){return gu(_0x404357['writeTree'],A(_0x404357['treePath'],_0x2cca33));}function vu(_0x54e8c6,_0x4d2f24,_0x332f60,_0x42c07c,_0x250012,_0x4bacfd){return mu(_0x54e8c6['writeTree'],_0x54e8c6['treePath'],_0x4d2f24,_0x332f60,_0x42c07c,_0x250012,_0x4bacfd);}function ts(_0x5530c2,_0x428f63,_0x4d57ba){return _u(_0x5530c2['writeTree'],_0x5530c2['treePath'],_0x428f63,_0x4d57ba);}function Wo(_0x2bd58e,_0x51a5c8){return Bo(A(_0x2bd58e['treePath'],_0x51a5c8),_0x2bd58e['writeTree']);}function Bo(_0x1cb0e5,_0x3756f1){return{'treePath':_0x1cb0e5,'writeTree':_0x3756f1};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xa26321){const _0x307de6=_0xa26321['type'],_0x12bb72=_0xa26321['childName'];f(_0x307de6==='child_added'||_0x307de6==='child_changed'||_0x307de6==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x12bb72!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3d64d9=this['changeMap']['get'](_0x12bb72);if(_0x3d64d9){const _0x2eec5f=_0x3d64d9['type'];if(_0x307de6==='child_added'&&_0x2eec5f==='child_removed')this['changeMap']['set'](_0x12bb72,Pt(_0x12bb72,_0xa26321['snapshotNode'],_0x3d64d9['snapshotNode']));else{if(_0x307de6==='child_removed'&&_0x2eec5f==='child_added')this['changeMap']['delete'](_0x12bb72);else{if(_0x307de6==='child_removed'&&_0x2eec5f==='child_changed')this['changeMap']['set'](_0x12bb72,Nt(_0x12bb72,_0x3d64d9['oldSnap']));else{if(_0x307de6==='child_changed'&&_0x2eec5f==='child_added')this['changeMap']['set'](_0x12bb72,tt(_0x12bb72,_0xa26321['snapshotNode']));else{if(_0x307de6==='child_changed'&&_0x2eec5f==='child_changed')this['changeMap']['set'](_0x12bb72,Pt(_0x12bb72,_0xa26321['snapshotNode'],_0x3d64d9['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0xa26321+'\x20occurred\x20after\x20'+_0x3d64d9);}}}}}else this['changeMap']['set'](_0x12bb72,_0xa26321);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x1e99a3){return null;}['getChildAfterChild'](_0x4b77f2,_0x38c6d6,_0x36fa53){return null;}}const Vo=new Iu();class ns{constructor(_0x1d5cac,_0x5d8111,_0x3702b4=null){this['writes_']=_0x1d5cac,this['viewCache_']=_0x5d8111,this['optCompleteServerCache_']=_0x3702b4;}['getCompleteChild'](_0x5d19a6){const _0x34cbb7=this['viewCache_']['eventCache'];if(_0x34cbb7['isCompleteForChild'](_0x5d19a6))return _0x34cbb7['getNode']()['getImmediateChild'](_0x5d19a6);{const _0x42c89d=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5d19a6,_0x42c89d);}}['getChildAfterChild'](_0x81e893,_0x280c33,_0x2e1cc2){const _0x7d88c1=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x360b03=vu(this['writes_'],_0x7d88c1,_0x280c33,0x1,_0x2e1cc2,_0x81e893);return _0x360b03['length']===0x0?null:_0x360b03[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0xce0cfe){return{'filter':_0xce0cfe};}function Cu(_0x58d89f,_0x6b65dc){f(_0x6b65dc['eventCache']['getNode']()['isIndexed'](_0x58d89f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x6b65dc['serverCache']['getNode']()['isIndexed'](_0x58d89f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x198d73,_0x5a960d,_0x541ba0,_0x8a2b0d,_0x363474){const _0x4447f5=new Eu();let _0x30e227,_0x3ffbd4;if(_0x541ba0['type']===q['OVERWRITE']){const _0x4653ee=_0x541ba0;_0x4653ee['source']['fromUser']?_0x30e227=Ti(_0x198d73,_0x5a960d,_0x4653ee['path'],_0x4653ee['snap'],_0x8a2b0d,_0x363474,_0x4447f5):(f(_0x4653ee['source']['fromServer'],'Unknown\x20source.'),_0x3ffbd4=_0x4653ee['source']['tagged']||_0x5a960d['serverCache']['isFiltered']()&&!v(_0x4653ee['path']),_0x30e227=vn(_0x198d73,_0x5a960d,_0x4653ee['path'],_0x4653ee['snap'],_0x8a2b0d,_0x363474,_0x3ffbd4,_0x4447f5));}else{if(_0x541ba0['type']===q['MERGE']){const _0x32b1d0=_0x541ba0;_0x32b1d0['source']['fromUser']?_0x30e227=bu(_0x198d73,_0x5a960d,_0x32b1d0['path'],_0x32b1d0['children'],_0x8a2b0d,_0x363474,_0x4447f5):(f(_0x32b1d0['source']['fromServer'],'Unknown\x20source.'),_0x3ffbd4=_0x32b1d0['source']['tagged']||_0x5a960d['serverCache']['isFiltered'](),_0x30e227=Si(_0x198d73,_0x5a960d,_0x32b1d0['path'],_0x32b1d0['children'],_0x8a2b0d,_0x363474,_0x3ffbd4,_0x4447f5));}else{if(_0x541ba0['type']===q['ACK_USER_WRITE']){const _0x38539f=_0x541ba0;_0x38539f['revert']?_0x30e227=ku(_0x198d73,_0x5a960d,_0x38539f['path'],_0x8a2b0d,_0x363474,_0x4447f5):_0x30e227=Ru(_0x198d73,_0x5a960d,_0x38539f['path'],_0x38539f['affectedTree'],_0x8a2b0d,_0x363474,_0x4447f5);}else{if(_0x541ba0['type']===q['LISTEN_COMPLETE'])_0x30e227=Au(_0x198d73,_0x5a960d,_0x541ba0['path'],_0x8a2b0d,_0x4447f5);else throw ot('Unknown\x20operation\x20type:\x20'+_0x541ba0['type']);}}}const _0x3fd966=_0x4447f5['getChanges']();return Su(_0x5a960d,_0x30e227,_0x3fd966),{'viewCache':_0x30e227,'changes':_0x3fd966};}function Su(_0x3c722f,_0x1870eb,_0x2c29ad){const _0x540347=_0x1870eb['eventCache'];if(_0x540347['isFullyInitialized']()){const _0x78d175=_0x540347['getNode']()['isLeafNode']()||_0x540347['getNode']()['isEmpty'](),_0x52cfc6=gn(_0x3c722f);(_0x2c29ad['length']>0x0||!_0x3c722f['eventCache']['isFullyInitialized']()||_0x78d175&&!_0x540347['getNode']()['equals'](_0x52cfc6)||!_0x540347['getNode']()['getPriority']()['equals'](_0x52cfc6['getPriority']()))&&_0x2c29ad['push'](Oo(gn(_0x1870eb)));}}function Ho(_0x55d130,_0x1b5f47,_0x59620a,_0x2ee35b,_0x486769,_0x53c12f){const _0x353534=_0x1b5f47['eventCache'];if(yn(_0x2ee35b,_0x59620a)!=null)return _0x1b5f47;{let _0x104503,_0x28aad1;if(v(_0x59620a)){if(f(_0x1b5f47['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1b5f47['serverCache']['isFiltered']()){const _0x122366=Ue(_0x1b5f47),_0x418c31=_0x122366 instanceof g?_0x122366:g['EMPTY_NODE'],_0x36d870=es(_0x2ee35b,_0x418c31);_0x104503=_0x55d130['filter']['updateFullNode'](_0x1b5f47['eventCache']['getNode'](),_0x36d870,_0x53c12f);}else{const _0x48c082=mn(_0x2ee35b,Ue(_0x1b5f47));_0x104503=_0x55d130['filter']['updateFullNode'](_0x1b5f47['eventCache']['getNode'](),_0x48c082,_0x53c12f);}}else{const _0x16debf=y(_0x59620a);if(_0x16debf==='.priority'){f(we(_0x59620a)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x300fd9=_0x353534['getNode']();_0x28aad1=_0x1b5f47['serverCache']['getNode']();const _0x55e37f=or(_0x2ee35b,_0x59620a,_0x300fd9,_0x28aad1);_0x55e37f!=null?_0x104503=_0x55d130['filter']['updatePriority'](_0x300fd9,_0x55e37f):_0x104503=_0x353534['getNode']();}else{const _0x3f5373=b(_0x59620a);let _0x4bc9f2;if(_0x353534['isCompleteForChild'](_0x16debf)){_0x28aad1=_0x1b5f47['serverCache']['getNode']();const _0x55e8ad=or(_0x2ee35b,_0x59620a,_0x353534['getNode'](),_0x28aad1);_0x55e8ad!=null?_0x4bc9f2=_0x353534['getNode']()['getImmediateChild'](_0x16debf)['updateChild'](_0x3f5373,_0x55e8ad):_0x4bc9f2=_0x353534['getNode']()['getImmediateChild'](_0x16debf);}else _0x4bc9f2=ts(_0x2ee35b,_0x16debf,_0x1b5f47['serverCache']);_0x4bc9f2!=null?_0x104503=_0x55d130['filter']['updateChild'](_0x353534['getNode'](),_0x16debf,_0x4bc9f2,_0x3f5373,_0x486769,_0x53c12f):_0x104503=_0x353534['getNode']();}}return wt(_0x1b5f47,_0x104503,_0x353534['isFullyInitialized']()||v(_0x59620a),_0x55d130['filter']['filtersNodes']());}}function vn(_0x485dc6,_0x134f77,_0x25d210,_0x4c2650,_0x279c71,_0x50a093,_0x4874a7,_0x52b387){const _0x165c52=_0x134f77['serverCache'];let _0x22257e;const _0x422edb=_0x4874a7?_0x485dc6['filter']:_0x485dc6['filter']['getIndexedFilter']();if(v(_0x25d210))_0x22257e=_0x422edb['updateFullNode'](_0x165c52['getNode'](),_0x4c2650,null);else{if(_0x422edb['filtersNodes']()&&!_0x165c52['isFiltered']()){const _0x54076d=_0x165c52['getNode']()['updateChild'](_0x25d210,_0x4c2650);_0x22257e=_0x422edb['updateFullNode'](_0x165c52['getNode'](),_0x54076d,null);}else{const _0x456e30=y(_0x25d210);if(!_0x165c52['isCompleteForPath'](_0x25d210)&&we(_0x25d210)>0x1)return _0x134f77;const _0x2bfece=b(_0x25d210),_0x1cc517=_0x165c52['getNode']()['getImmediateChild'](_0x456e30)['updateChild'](_0x2bfece,_0x4c2650);_0x456e30==='.priority'?_0x22257e=_0x422edb['updatePriority'](_0x165c52['getNode'](),_0x1cc517):_0x22257e=_0x422edb['updateChild'](_0x165c52['getNode'](),_0x456e30,_0x1cc517,_0x2bfece,Vo,null);}}const _0x50436a=Lo(_0x134f77,_0x22257e,_0x165c52['isFullyInitialized']()||v(_0x25d210),_0x422edb['filtersNodes']()),_0x52185d=new ns(_0x279c71,_0x50436a,_0x50a093);return Ho(_0x485dc6,_0x50436a,_0x25d210,_0x279c71,_0x52185d,_0x52b387);}function Ti(_0x2ff440,_0x567206,_0x230fbf,_0x3c28f9,_0xde4237,_0x2d4121,_0x31e192){const _0x443ee2=_0x567206['eventCache'];let _0x260de5,_0x42516f;const _0x54ed37=new ns(_0xde4237,_0x567206,_0x2d4121);if(v(_0x230fbf))_0x42516f=_0x2ff440['filter']['updateFullNode'](_0x567206['eventCache']['getNode'](),_0x3c28f9,_0x31e192),_0x260de5=wt(_0x567206,_0x42516f,!0x0,_0x2ff440['filter']['filtersNodes']());else{const _0x347ed7=y(_0x230fbf);if(_0x347ed7==='.priority')_0x42516f=_0x2ff440['filter']['updatePriority'](_0x567206['eventCache']['getNode'](),_0x3c28f9),_0x260de5=wt(_0x567206,_0x42516f,_0x443ee2['isFullyInitialized'](),_0x443ee2['isFiltered']());else{const _0x5c01b5=b(_0x230fbf),_0x87a248=_0x443ee2['getNode']()['getImmediateChild'](_0x347ed7);let _0x5218ab;if(v(_0x5c01b5))_0x5218ab=_0x3c28f9;else{const _0x172a85=_0x54ed37['getCompleteChild'](_0x347ed7);_0x172a85!=null?Gi(_0x5c01b5)==='.priority'&&_0x172a85['getChild'](To(_0x5c01b5))['isEmpty']()?_0x5218ab=_0x172a85:_0x5218ab=_0x172a85['updateChild'](_0x5c01b5,_0x3c28f9):_0x5218ab=g['EMPTY_NODE'];}if(_0x87a248['equals'](_0x5218ab))_0x260de5=_0x567206;else{const _0x198e11=_0x2ff440['filter']['updateChild'](_0x443ee2['getNode'](),_0x347ed7,_0x5218ab,_0x5c01b5,_0x54ed37,_0x31e192);_0x260de5=wt(_0x567206,_0x198e11,_0x443ee2['isFullyInitialized'](),_0x2ff440['filter']['filtersNodes']());}}}return _0x260de5;}function ar(_0x1f18d6,_0x2b4651){return _0x1f18d6['eventCache']['isCompleteForChild'](_0x2b4651);}function bu(_0x77393f,_0x1cc4ed,_0xba7d32,_0x5ac1d0,_0x541e2e,_0x27cc51,_0x492657){let _0x32e02e=_0x1cc4ed;return _0x5ac1d0['foreach']((_0x5e662e,_0x2325b3)=>{const _0x4b0e9c=A(_0xba7d32,_0x5e662e);ar(_0x1cc4ed,y(_0x4b0e9c))&&(_0x32e02e=Ti(_0x77393f,_0x32e02e,_0x4b0e9c,_0x2325b3,_0x541e2e,_0x27cc51,_0x492657));}),_0x5ac1d0['foreach']((_0x74e5f8,_0x2fd686)=>{const _0x58482a=A(_0xba7d32,_0x74e5f8);ar(_0x1cc4ed,y(_0x58482a))||(_0x32e02e=Ti(_0x77393f,_0x32e02e,_0x58482a,_0x2fd686,_0x541e2e,_0x27cc51,_0x492657));}),_0x32e02e;}function cr(_0x58e6b9,_0x3f3600,_0x2cf543){return _0x2cf543['foreach']((_0x446437,_0x539113)=>{_0x3f3600=_0x3f3600['updateChild'](_0x446437,_0x539113);}),_0x3f3600;}function Si(_0x329474,_0x12a825,_0x1851ab,_0x3e3b90,_0x55a8eb,_0x1baadd,_0x3cdbb1,_0x31fb31){if(_0x12a825['serverCache']['getNode']()['isEmpty']()&&!_0x12a825['serverCache']['isFullyInitialized']())return _0x12a825;let _0x381c23=_0x12a825,_0xdfaa90;v(_0x1851ab)?_0xdfaa90=_0x3e3b90:_0xdfaa90=new S(null)['setTree'](_0x1851ab,_0x3e3b90);const _0x261aac=_0x12a825['serverCache']['getNode']();return _0xdfaa90['children']['inorderTraversal']((_0x3bfb40,_0x440f88)=>{if(_0x261aac['hasChild'](_0x3bfb40)){const _0x3fa097=_0x12a825['serverCache']['getNode']()['getImmediateChild'](_0x3bfb40),_0x247d42=cr(_0x329474,_0x3fa097,_0x440f88);_0x381c23=vn(_0x329474,_0x381c23,new C(_0x3bfb40),_0x247d42,_0x55a8eb,_0x1baadd,_0x3cdbb1,_0x31fb31);}}),_0xdfaa90['children']['inorderTraversal']((_0xbf1d88,_0x36ca99)=>{const _0x304426=!_0x12a825['serverCache']['isCompleteForChild'](_0xbf1d88)&&_0x36ca99['value']===null;if(!_0x261aac['hasChild'](_0xbf1d88)&&!_0x304426){const _0x28e63d=_0x12a825['serverCache']['getNode']()['getImmediateChild'](_0xbf1d88),_0x177e4d=cr(_0x329474,_0x28e63d,_0x36ca99);_0x381c23=vn(_0x329474,_0x381c23,new C(_0xbf1d88),_0x177e4d,_0x55a8eb,_0x1baadd,_0x3cdbb1,_0x31fb31);}}),_0x381c23;}function Ru(_0x4c09ec,_0x421ae0,_0x3020c2,_0x28513f,_0x111ffb,_0x26a868,_0x239feb){if(yn(_0x111ffb,_0x3020c2)!=null)return _0x421ae0;const _0x458ac4=_0x421ae0['serverCache']['isFiltered'](),_0x418705=_0x421ae0['serverCache'];if(_0x28513f['value']!=null){if(v(_0x3020c2)&&_0x418705['isFullyInitialized']()||_0x418705['isCompleteForPath'](_0x3020c2))return vn(_0x4c09ec,_0x421ae0,_0x3020c2,_0x418705['getNode']()['getChild'](_0x3020c2),_0x111ffb,_0x26a868,_0x458ac4,_0x239feb);if(v(_0x3020c2)){let _0x54e253=new S(null);return _0x418705['getNode']()['forEachChild'](ye,(_0xb90876,_0x53ca28)=>{_0x54e253=_0x54e253['set'](new C(_0xb90876),_0x53ca28);}),Si(_0x4c09ec,_0x421ae0,_0x3020c2,_0x54e253,_0x111ffb,_0x26a868,_0x458ac4,_0x239feb);}else return _0x421ae0;}else{let _0x172b88=new S(null);return _0x28513f['foreach']((_0x28604c,_0xbecace)=>{const _0x4c6be3=A(_0x3020c2,_0x28604c);_0x418705['isCompleteForPath'](_0x4c6be3)&&(_0x172b88=_0x172b88['set'](_0x28604c,_0x418705['getNode']()['getChild'](_0x4c6be3)));}),Si(_0x4c09ec,_0x421ae0,_0x3020c2,_0x172b88,_0x111ffb,_0x26a868,_0x458ac4,_0x239feb);}}function Au(_0x18f29c,_0x4a60ad,_0x1e8967,_0x443224,_0x11404c){const _0x49041e=_0x4a60ad['serverCache'],_0x3e9d19=Lo(_0x4a60ad,_0x49041e['getNode'](),_0x49041e['isFullyInitialized']()||v(_0x1e8967),_0x49041e['isFiltered']());return Ho(_0x18f29c,_0x3e9d19,_0x1e8967,_0x443224,Vo,_0x11404c);}function ku(_0x3ac0d3,_0x4c10c8,_0x10421d,_0x292a10,_0x3a1c4e,_0x55e123){let _0x200042;if(yn(_0x292a10,_0x10421d)!=null)return _0x4c10c8;{const _0x279baf=new ns(_0x292a10,_0x4c10c8,_0x3a1c4e),_0x26c6f7=_0x4c10c8['eventCache']['getNode']();let _0x1e07d8;if(v(_0x10421d)||y(_0x10421d)==='.priority'){let _0x57c4ca;if(_0x4c10c8['serverCache']['isFullyInitialized']())_0x57c4ca=mn(_0x292a10,Ue(_0x4c10c8));else{const _0x524945=_0x4c10c8['serverCache']['getNode']();f(_0x524945 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x57c4ca=es(_0x292a10,_0x524945);}_0x57c4ca=_0x57c4ca,_0x1e07d8=_0x3ac0d3['filter']['updateFullNode'](_0x26c6f7,_0x57c4ca,_0x55e123);}else{const _0x459afe=y(_0x10421d);let _0x3eccd2=ts(_0x292a10,_0x459afe,_0x4c10c8['serverCache']);_0x3eccd2==null&&_0x4c10c8['serverCache']['isCompleteForChild'](_0x459afe)&&(_0x3eccd2=_0x26c6f7['getImmediateChild'](_0x459afe)),_0x3eccd2!=null?_0x1e07d8=_0x3ac0d3['filter']['updateChild'](_0x26c6f7,_0x459afe,_0x3eccd2,b(_0x10421d),_0x279baf,_0x55e123):_0x4c10c8['eventCache']['getNode']()['hasChild'](_0x459afe)?_0x1e07d8=_0x3ac0d3['filter']['updateChild'](_0x26c6f7,_0x459afe,g['EMPTY_NODE'],b(_0x10421d),_0x279baf,_0x55e123):_0x1e07d8=_0x26c6f7,_0x1e07d8['isEmpty']()&&_0x4c10c8['serverCache']['isFullyInitialized']()&&(_0x200042=mn(_0x292a10,Ue(_0x4c10c8)),_0x200042['isLeafNode']()&&(_0x1e07d8=_0x3ac0d3['filter']['updateFullNode'](_0x1e07d8,_0x200042,_0x55e123)));}return _0x200042=_0x4c10c8['serverCache']['isFullyInitialized']()||yn(_0x292a10,w())!=null,wt(_0x4c10c8,_0x1e07d8,_0x200042,_0x3ac0d3['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x581ba8,_0xcc0b5e){this['query_']=_0x581ba8,this['eventRegistrations_']=[];const _0x6ed3b4=this['query_']['_queryParams'],_0x8494c9=new Yi(_0x6ed3b4['getIndex']()),_0x1b26f9=qh(_0x6ed3b4);this['processor_']=wu(_0x1b26f9);const _0x478b03=_0xcc0b5e['serverCache'],_0x55547a=_0xcc0b5e['eventCache'],_0x264279=_0x8494c9['updateFullNode'](g['EMPTY_NODE'],_0x478b03['getNode'](),null),_0x1cd901=_0x1b26f9['updateFullNode'](g['EMPTY_NODE'],_0x55547a['getNode'](),null),_0x4e6aa8=new Ce(_0x264279,_0x478b03['isFullyInitialized'](),_0x8494c9['filtersNodes']()),_0xf77239=new Ce(_0x1cd901,_0x55547a['isFullyInitialized'](),_0x1b26f9['filtersNodes']());this['viewCache_']=Dn(_0xf77239,_0x4e6aa8),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x1660a7){return _0x1660a7['viewCache_']['serverCache']['getNode']();}function Ou(_0x39306f){return gn(_0x39306f['viewCache_']);}function Du(_0x4f52cc,_0x2e20f5){const _0xb7d442=Ue(_0x4f52cc['viewCache_']);return _0xb7d442&&(_0x4f52cc['query']['_queryParams']['loadsAllData']()||!v(_0x2e20f5)&&!_0xb7d442['getImmediateChild'](y(_0x2e20f5))['isEmpty']())?_0xb7d442['getChild'](_0x2e20f5):null;}function lr(_0x263c71){return _0x263c71['eventRegistrations_']['length']===0x0;}function Mu(_0x37b527,_0x1436cd){_0x37b527['eventRegistrations_']['push'](_0x1436cd);}function hr(_0x4bf0f1,_0x5098a5,_0x32e107){const _0x37d8db=[];if(_0x32e107){f(_0x5098a5==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3933ce=_0x4bf0f1['query']['_path'];_0x4bf0f1['eventRegistrations_']['forEach'](_0x533fc6=>{const _0x3fef36=_0x533fc6['createCancelEvent'](_0x32e107,_0x3933ce);_0x3fef36&&_0x37d8db['push'](_0x3fef36);});}if(_0x5098a5){let _0x5a9e7f=[];for(let _0x314d93=0x0;_0x314d93<_0x4bf0f1['eventRegistrations_']['length'];++_0x314d93){const _0x1395a9=_0x4bf0f1['eventRegistrations_'][_0x314d93];if(!_0x1395a9['matches'](_0x5098a5))_0x5a9e7f['push'](_0x1395a9);else{if(_0x5098a5['hasAnyCallback']()){_0x5a9e7f=_0x5a9e7f['concat'](_0x4bf0f1['eventRegistrations_']['slice'](_0x314d93+0x1));break;}}}_0x4bf0f1['eventRegistrations_']=_0x5a9e7f;}else _0x4bf0f1['eventRegistrations_']=[];return _0x37d8db;}function ur(_0x48ec23,_0x532235,_0x2535d9,_0x30fa49){_0x532235['type']===q['MERGE']&&_0x532235['source']['queryId']!==null&&(f(Ue(_0x48ec23['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x48ec23['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5eee7a=_0x48ec23['viewCache_'],_0x553d09=Tu(_0x48ec23['processor_'],_0x5eee7a,_0x532235,_0x2535d9,_0x30fa49);return Cu(_0x48ec23['processor_'],_0x553d09['viewCache']),f(_0x553d09['viewCache']['serverCache']['isFullyInitialized']()||!_0x5eee7a['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x48ec23['viewCache_']=_0x553d09['viewCache'],$o(_0x48ec23,_0x553d09['changes'],_0x553d09['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x706c67,_0x16c041){const _0x8ba28c=_0x706c67['viewCache_']['eventCache'],_0x528a55=[];return _0x8ba28c['getNode']()['isLeafNode']()||_0x8ba28c['getNode']()['forEachChild'](R,(_0x4f907b,_0x3f7a8a)=>{_0x528a55['push'](tt(_0x4f907b,_0x3f7a8a));}),_0x8ba28c['isFullyInitialized']()&&_0x528a55['push'](Oo(_0x8ba28c['getNode']())),$o(_0x706c67,_0x528a55,_0x8ba28c['getNode'](),_0x16c041);}function $o(_0x249d6e,_0x166ac7,_0x279c8e,_0x490930){const _0x142d85=_0x490930?[_0x490930]:_0x249d6e['eventRegistrations_'];return nu(_0x249d6e['eventGenerator_'],_0x166ac7,_0x279c8e,_0x142d85);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x5c0edb){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x5c0edb;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x452062){return _0x452062['views']['size']===0x0;}function is(_0x46d2a3,_0x108b5f,_0x1685d7,_0x75f95a){const _0x5572d5=_0x108b5f['source']['queryId'];if(_0x5572d5!==null){const _0xb9d9a0=_0x46d2a3['views']['get'](_0x5572d5);return f(_0xb9d9a0!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xb9d9a0,_0x108b5f,_0x1685d7,_0x75f95a);}else{let _0x2e4347=[];for(const _0x18e105 of _0x46d2a3['views']['values']())_0x2e4347=_0x2e4347['concat'](ur(_0x18e105,_0x108b5f,_0x1685d7,_0x75f95a));return _0x2e4347;}}function qo(_0x176276,_0xe150d2,_0x3e4cfb,_0x2361f3,_0x43ecb4){const _0x323b1a=_0xe150d2['_queryIdentifier'],_0x5591ae=_0x176276['views']['get'](_0x323b1a);if(!_0x5591ae){let _0x271dd9=mn(_0x3e4cfb,_0x43ecb4?_0x2361f3:null),_0x507cb6=!0x1;_0x271dd9?_0x507cb6=!0x0:_0x2361f3 instanceof g?(_0x271dd9=es(_0x3e4cfb,_0x2361f3),_0x507cb6=!0x1):(_0x271dd9=g['EMPTY_NODE'],_0x507cb6=!0x1);const _0x29fed8=Dn(new Ce(_0x271dd9,_0x507cb6,!0x1),new Ce(_0x2361f3,_0x43ecb4,!0x1));return new Nu(_0xe150d2,_0x29fed8);}return _0x5591ae;}function Wu(_0x3b7f32,_0x380b28,_0x51920e,_0xf7e80c,_0x45d459,_0x55ffd1){const _0x53a416=qo(_0x3b7f32,_0x380b28,_0xf7e80c,_0x45d459,_0x55ffd1);return _0x3b7f32['views']['has'](_0x380b28['_queryIdentifier'])||_0x3b7f32['views']['set'](_0x380b28['_queryIdentifier'],_0x53a416),Mu(_0x53a416,_0x51920e),Lu(_0x53a416,_0x51920e);}function Bu(_0x5acf6d,_0x3db5dc,_0x90ad78,_0x4c3a1d){const _0x3c960b=_0x3db5dc['_queryIdentifier'],_0x35196e=[];let _0x93fd22=[];const _0xdf2300=Te(_0x5acf6d);if(_0x3c960b==='default'){for(const [_0x21384f,_0x4ce3e5]of _0x5acf6d['views']['entries']())_0x93fd22=_0x93fd22['concat'](hr(_0x4ce3e5,_0x90ad78,_0x4c3a1d)),lr(_0x4ce3e5)&&(_0x5acf6d['views']['delete'](_0x21384f),_0x4ce3e5['query']['_queryParams']['loadsAllData']()||_0x35196e['push'](_0x4ce3e5['query']));}else{const _0x2767f6=_0x5acf6d['views']['get'](_0x3c960b);_0x2767f6&&(_0x93fd22=_0x93fd22['concat'](hr(_0x2767f6,_0x90ad78,_0x4c3a1d)),lr(_0x2767f6)&&(_0x5acf6d['views']['delete'](_0x3c960b),_0x2767f6['query']['_queryParams']['loadsAllData']()||_0x35196e['push'](_0x2767f6['query'])));}return _0xdf2300&&!Te(_0x5acf6d)&&_0x35196e['push'](new(Fu())(_0x3db5dc['_repo'],_0x3db5dc['_path'])),{'removed':_0x35196e,'events':_0x93fd22};}function zo(_0x3c2c0c){const _0x5cd9e0=[];for(const _0x24163f of _0x3c2c0c['views']['values']())_0x24163f['query']['_queryParams']['loadsAllData']()||_0x5cd9e0['push'](_0x24163f);return _0x5cd9e0;}function Ee(_0x4538d7,_0x4dc4e3){let _0x179f36=null;for(const _0x3db168 of _0x4538d7['views']['values']())_0x179f36=_0x179f36||Du(_0x3db168,_0x4dc4e3);return _0x179f36;}function jo(_0x217974,_0x420f27){if(_0x420f27['_queryParams']['loadsAllData']())return Ln(_0x217974);{const _0x4a0564=_0x420f27['_queryIdentifier'];return _0x217974['views']['get'](_0x4a0564);}}function Ko(_0x188cc5,_0x1c049d){return jo(_0x188cc5,_0x1c049d)!=null;}function Te(_0x5ba89f){return Ln(_0x5ba89f)!=null;}function Ln(_0x2cfab8){for(const _0x2ef993 of _0x2cfab8['views']['values']())if(_0x2ef993['query']['_queryParams']['loadsAllData']())return _0x2ef993;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x5e3524){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x5e3524;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x446be0){this['listenProvider_']=_0x446be0,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x5e00bf,_0x3ae59f,_0x2187f,_0x18c8df,_0x3f3cea){return ou(_0x5e00bf['pendingWriteTree_'],_0x3ae59f,_0x2187f,_0x18c8df,_0x3f3cea),_0x3f3cea?ht(_0x5e00bf,new Fe(Ji(),_0x3ae59f,_0x2187f)):[];}function Gu(_0x1892bf,_0x4a3abd,_0x21d7d0,_0x5902ae){au(_0x1892bf['pendingWriteTree_'],_0x4a3abd,_0x21d7d0,_0x5902ae);const _0x4a965a=S['fromObject'](_0x21d7d0);return ht(_0x1892bf,new nt(Ji(),_0x4a3abd,_0x4a965a));}function pe(_0x5113e1,_0x4e7d72,_0x574246=!0x1){const _0x3f9d35=cu(_0x5113e1['pendingWriteTree_'],_0x4e7d72);if(lu(_0x5113e1['pendingWriteTree_'],_0x4e7d72)){let _0x8af7c4=new S(null);return _0x3f9d35['snap']!=null?_0x8af7c4=_0x8af7c4['set'](w(),!0x0):x(_0x3f9d35['children'],_0x377e54=>{_0x8af7c4=_0x8af7c4['set'](new C(_0x377e54),!0x0);}),ht(_0x5113e1,new _n(_0x3f9d35['path'],_0x8af7c4,_0x574246));}else return[];}function $t(_0x5e1085,_0x12181f,_0x5ec343){return ht(_0x5e1085,new Fe(Xi(),_0x12181f,_0x5ec343));}function qu(_0x136c96,_0x2d211d,_0x57d3e8){const _0x4db0df=S['fromObject'](_0x57d3e8);return ht(_0x136c96,new nt(Xi(),_0x2d211d,_0x4db0df));}function zu(_0x1bbec6,_0x509a58){return ht(_0x1bbec6,new Dt(Xi(),_0x509a58));}function ju(_0x25f53e,_0x362373,_0x6f16ac){const _0x125ff2=rs(_0x25f53e,_0x6f16ac);if(_0x125ff2){const _0x4966c1=os(_0x125ff2),_0x37e752=_0x4966c1['path'],_0x4ea0b9=_0x4966c1['queryId'],_0x573efc=F(_0x37e752,_0x362373),_0x5e3b8b=new Dt(Zi(_0x4ea0b9),_0x573efc);return as(_0x25f53e,_0x37e752,_0x5e3b8b);}else return[];}function wn(_0x32bb36,_0x36ffc3,_0x2e60c3,_0x49f5b3,_0x39d784=!0x1){const _0x34781d=_0x36ffc3['_path'],_0x2d5ad5=_0x32bb36['syncPointTree_']['get'](_0x34781d);let _0x16f7a5=[];if(_0x2d5ad5&&(_0x36ffc3['_queryIdentifier']==='default'||Ko(_0x2d5ad5,_0x36ffc3))){const _0x96598d=Bu(_0x2d5ad5,_0x36ffc3,_0x2e60c3,_0x49f5b3);Uu(_0x2d5ad5)&&(_0x32bb36['syncPointTree_']=_0x32bb36['syncPointTree_']['remove'](_0x34781d));const _0x3b757d=_0x96598d['removed'];if(_0x16f7a5=_0x96598d['events'],!_0x39d784){const _0x3bb069=_0x3b757d['findIndex'](_0x1350aa=>_0x1350aa['_queryParams']['loadsAllData']())!==-0x1,_0x19853d=_0x32bb36['syncPointTree_']['findOnPath'](_0x34781d,(_0x4641ac,_0x35db1e)=>Te(_0x35db1e));if(_0x3bb069&&!_0x19853d){const _0x51badf=_0x32bb36['syncPointTree_']['subtree'](_0x34781d);if(!_0x51badf['isEmpty']()){const _0xc6217b=Qu(_0x51badf);for(let _0x4abd13=0x0;_0x4abd13<_0xc6217b['length'];++_0x4abd13){const _0x19f1c8=_0xc6217b[_0x4abd13],_0x2d1a6c=_0x19f1c8['query'],_0x203012=Xo(_0x32bb36,_0x19f1c8);_0x32bb36['listenProvider_']['startListening'](Tt(_0x2d1a6c),Mt(_0x32bb36,_0x2d1a6c),_0x203012['hashFn'],_0x203012['onComplete']);}}}!_0x19853d&&_0x3b757d['length']>0x0&&!_0x49f5b3&&(_0x3bb069?_0x32bb36['listenProvider_']['stopListening'](Tt(_0x36ffc3),null):_0x3b757d['forEach'](_0x4bf088=>{const _0x2a5309=_0x32bb36['queryToTagMap']['get'](Fn(_0x4bf088));_0x32bb36['listenProvider_']['stopListening'](Tt(_0x4bf088),_0x2a5309);}));}Ju(_0x32bb36,_0x3b757d);}return _0x16f7a5;}function Yo(_0x3c8cf9,_0x12bd34,_0x2121e3,_0x2b659a){const _0x48a5de=rs(_0x3c8cf9,_0x2b659a);if(_0x48a5de!=null){const _0x413ea5=os(_0x48a5de),_0x498b52=_0x413ea5['path'],_0x358d4c=_0x413ea5['queryId'],_0x27d4b1=F(_0x498b52,_0x12bd34),_0x1c39ee=new Fe(Zi(_0x358d4c),_0x27d4b1,_0x2121e3);return as(_0x3c8cf9,_0x498b52,_0x1c39ee);}else return[];}function Ku(_0x4df5fd,_0x55a08b,_0x4c9a0c,_0x362d7d){const _0x5313ca=rs(_0x4df5fd,_0x362d7d);if(_0x5313ca){const _0x1c8a4c=os(_0x5313ca),_0x5bc352=_0x1c8a4c['path'],_0x4496c1=_0x1c8a4c['queryId'],_0x5f0bcf=F(_0x5bc352,_0x55a08b),_0x4275c4=S['fromObject'](_0x4c9a0c),_0x31e9b1=new nt(Zi(_0x4496c1),_0x5f0bcf,_0x4275c4);return as(_0x4df5fd,_0x5bc352,_0x31e9b1);}else return[];}function bi(_0x376c4f,_0x313914,_0x3c18ef,_0x59be5e=!0x1){const _0x1c6271=_0x313914['_path'];let _0x3fc05c=null,_0xc90dd7=!0x1;_0x376c4f['syncPointTree_']['foreachOnPath'](_0x1c6271,(_0xcfa862,_0x2002b4)=>{const _0x23c0c0=F(_0xcfa862,_0x1c6271);_0x3fc05c=_0x3fc05c||Ee(_0x2002b4,_0x23c0c0),_0xc90dd7=_0xc90dd7||Te(_0x2002b4);});let _0x5ab72e=_0x376c4f['syncPointTree_']['get'](_0x1c6271);_0x5ab72e?(_0xc90dd7=_0xc90dd7||Te(_0x5ab72e),_0x3fc05c=_0x3fc05c||Ee(_0x5ab72e,w())):(_0x5ab72e=new Go(),_0x376c4f['syncPointTree_']=_0x376c4f['syncPointTree_']['set'](_0x1c6271,_0x5ab72e));let _0x37033b;_0x3fc05c!=null?_0x37033b=!0x0:(_0x37033b=!0x1,_0x3fc05c=g['EMPTY_NODE'],_0x376c4f['syncPointTree_']['subtree'](_0x1c6271)['foreachChild']((_0x149f09,_0x405e95)=>{const _0x475a33=Ee(_0x405e95,w());_0x475a33&&(_0x3fc05c=_0x3fc05c['updateImmediateChild'](_0x149f09,_0x475a33));}));const _0x384a42=Ko(_0x5ab72e,_0x313914);if(!_0x384a42&&!_0x313914['_queryParams']['loadsAllData']()){const _0x4dae2e=Fn(_0x313914);f(!_0x376c4f['queryToTagMap']['has'](_0x4dae2e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xddd310=Xu();_0x376c4f['queryToTagMap']['set'](_0x4dae2e,_0xddd310),_0x376c4f['tagToQueryMap']['set'](_0xddd310,_0x4dae2e);}const _0x1f50d6=Mn(_0x376c4f['pendingWriteTree_'],_0x1c6271);let _0x1f8149=Wu(_0x5ab72e,_0x313914,_0x3c18ef,_0x1f50d6,_0x3fc05c,_0x37033b);if(!_0x384a42&&!_0xc90dd7&&!_0x59be5e){const _0x51c9ec=jo(_0x5ab72e,_0x313914);_0x1f8149=_0x1f8149['concat'](Zu(_0x376c4f,_0x313914,_0x51c9ec));}return _0x1f8149;}function xn(_0x52e876,_0x2e20a0,_0x5835a7){const _0x221146=_0x52e876['pendingWriteTree_'],_0x5e09cb=_0x52e876['syncPointTree_']['findOnPath'](_0x2e20a0,(_0xda768a,_0x22852f)=>{const _0x2d47d4=F(_0xda768a,_0x2e20a0),_0x4ca743=Ee(_0x22852f,_0x2d47d4);if(_0x4ca743)return _0x4ca743;});return Uo(_0x221146,_0x2e20a0,_0x5e09cb,_0x5835a7,!0x0);}function Yu(_0x83faa,_0x324c68){const _0x14cc54=_0x324c68['_path'];let _0x10a6e6=null;_0x83faa['syncPointTree_']['foreachOnPath'](_0x14cc54,(_0x5d4de7,_0x4a9572)=>{const _0x145197=F(_0x5d4de7,_0x14cc54);_0x10a6e6=_0x10a6e6||Ee(_0x4a9572,_0x145197);});let _0x3ae346=_0x83faa['syncPointTree_']['get'](_0x14cc54);_0x3ae346?_0x10a6e6=_0x10a6e6||Ee(_0x3ae346,w()):(_0x3ae346=new Go(),_0x83faa['syncPointTree_']=_0x83faa['syncPointTree_']['set'](_0x14cc54,_0x3ae346));const _0x15e66b=_0x10a6e6!=null,_0x5354ec=_0x15e66b?new Ce(_0x10a6e6,!0x0,!0x1):null,_0x59147f=Mn(_0x83faa['pendingWriteTree_'],_0x324c68['_path']),_0x3de3b9=qo(_0x3ae346,_0x324c68,_0x59147f,_0x15e66b?_0x5354ec['getNode']():g['EMPTY_NODE'],_0x15e66b);return Ou(_0x3de3b9);}function ht(_0x2f39f5,_0x103155){return Qo(_0x103155,_0x2f39f5['syncPointTree_'],null,Mn(_0x2f39f5['pendingWriteTree_'],w()));}function Qo(_0x569758,_0x414dd4,_0x2f9299,_0x560bf9){if(v(_0x569758['path']))return Jo(_0x569758,_0x414dd4,_0x2f9299,_0x560bf9);{const _0x4c2062=_0x414dd4['get'](w());_0x2f9299==null&&_0x4c2062!=null&&(_0x2f9299=Ee(_0x4c2062,w()));let _0x1988bd=[];const _0x50bb5d=y(_0x569758['path']),_0x38db09=_0x569758['operationForChild'](_0x50bb5d),_0x402010=_0x414dd4['children']['get'](_0x50bb5d);if(_0x402010&&_0x38db09){const _0x48af0c=_0x2f9299?_0x2f9299['getImmediateChild'](_0x50bb5d):null,_0x2b8d95=Wo(_0x560bf9,_0x50bb5d);_0x1988bd=_0x1988bd['concat'](Qo(_0x38db09,_0x402010,_0x48af0c,_0x2b8d95));}return _0x4c2062&&(_0x1988bd=_0x1988bd['concat'](is(_0x4c2062,_0x569758,_0x560bf9,_0x2f9299))),_0x1988bd;}}function Jo(_0x3ef75b,_0x339e1f,_0x1e82f6,_0x400745){const _0xd29031=_0x339e1f['get'](w());_0x1e82f6==null&&_0xd29031!=null&&(_0x1e82f6=Ee(_0xd29031,w()));let _0x58ebca=[];return _0x339e1f['children']['inorderTraversal']((_0x38b8e4,_0x4853e2)=>{const _0x20eb0f=_0x1e82f6?_0x1e82f6['getImmediateChild'](_0x38b8e4):null,_0x4cf7fb=Wo(_0x400745,_0x38b8e4),_0x13a293=_0x3ef75b['operationForChild'](_0x38b8e4);_0x13a293&&(_0x58ebca=_0x58ebca['concat'](Jo(_0x13a293,_0x4853e2,_0x20eb0f,_0x4cf7fb)));}),_0xd29031&&(_0x58ebca=_0x58ebca['concat'](is(_0xd29031,_0x3ef75b,_0x400745,_0x1e82f6))),_0x58ebca;}function Xo(_0x2e90d9,_0x2ae300){const _0x2b8570=_0x2ae300['query'],_0x2147ff=Mt(_0x2e90d9,_0x2b8570);return{'hashFn':()=>(Pu(_0x2ae300)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x551e66=>{if(_0x551e66==='ok')return _0x2147ff?ju(_0x2e90d9,_0x2b8570['_path'],_0x2147ff):zu(_0x2e90d9,_0x2b8570['_path']);{const _0x5f4a8a=ql(_0x551e66,_0x2b8570);return wn(_0x2e90d9,_0x2b8570,null,_0x5f4a8a);}}};}function Mt(_0x26d8eb,_0x1a1971){const _0x4a4f20=Fn(_0x1a1971);return _0x26d8eb['queryToTagMap']['get'](_0x4a4f20);}function Fn(_0x5e5a73){return _0x5e5a73['_path']['toString']()+'$'+_0x5e5a73['_queryIdentifier'];}function rs(_0x2ef4fd,_0x400182){return _0x2ef4fd['tagToQueryMap']['get'](_0x400182);}function os(_0x2dfef9){const _0x42e559=_0x2dfef9['indexOf']('$');return f(_0x42e559!==-0x1&&_0x42e559<_0x2dfef9['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2dfef9['substr'](_0x42e559+0x1),'path':new C(_0x2dfef9['substr'](0x0,_0x42e559))};}function as(_0x55e928,_0x3528e2,_0x401a37){const _0x4f4b5f=_0x55e928['syncPointTree_']['get'](_0x3528e2);f(_0x4f4b5f,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5051b0=Mn(_0x55e928['pendingWriteTree_'],_0x3528e2);return is(_0x4f4b5f,_0x401a37,_0x5051b0,null);}function Qu(_0x3c1bc8){return _0x3c1bc8['fold']((_0x2c25af,_0x482b8c,_0x1a7224)=>{if(_0x482b8c&&Te(_0x482b8c))return[Ln(_0x482b8c)];{let _0x4e9450=[];return _0x482b8c&&(_0x4e9450=zo(_0x482b8c)),x(_0x1a7224,(_0x21e0ad,_0x41b538)=>{_0x4e9450=_0x4e9450['concat'](_0x41b538);}),_0x4e9450;}});}function Tt(_0x31c269){return _0x31c269['_queryParams']['loadsAllData']()&&!_0x31c269['_queryParams']['isDefault']()?new(Hu())(_0x31c269['_repo'],_0x31c269['_path']):_0x31c269;}function Ju(_0x2e11f7,_0x25bae4){for(let _0xb3e9c3=0x0;_0xb3e9c3<_0x25bae4['length'];++_0xb3e9c3){const _0x157e69=_0x25bae4[_0xb3e9c3];if(!_0x157e69['_queryParams']['loadsAllData']()){const _0x124467=Fn(_0x157e69),_0x3a83c0=_0x2e11f7['queryToTagMap']['get'](_0x124467);_0x2e11f7['queryToTagMap']['delete'](_0x124467),_0x2e11f7['tagToQueryMap']['delete'](_0x3a83c0);}}}function Xu(){return $u++;}function Zu(_0x3772e3,_0x201e68,_0x1c8054){const _0x6f2879=_0x201e68['_path'],_0x306b4c=Mt(_0x3772e3,_0x201e68),_0x3e587b=Xo(_0x3772e3,_0x1c8054),_0x1bf795=_0x3772e3['listenProvider_']['startListening'](Tt(_0x201e68),_0x306b4c,_0x3e587b['hashFn'],_0x3e587b['onComplete']),_0x3beff0=_0x3772e3['syncPointTree_']['subtree'](_0x6f2879);if(_0x306b4c)f(!Te(_0x3beff0['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4f84e3=_0x3beff0['fold']((_0x5c666b,_0x493f37,_0x4984f8)=>{if(!v(_0x5c666b)&&_0x493f37&&Te(_0x493f37))return[Ln(_0x493f37)['query']];{let _0x346d9d=[];return _0x493f37&&(_0x346d9d=_0x346d9d['concat'](zo(_0x493f37)['map'](_0x2880dc=>_0x2880dc['query']))),x(_0x4984f8,(_0x6c570b,_0x15ba33)=>{_0x346d9d=_0x346d9d['concat'](_0x15ba33);}),_0x346d9d;}});for(let _0x5ebce9=0x0;_0x5ebce9<_0x4f84e3['length'];++_0x5ebce9){const _0x52ca52=_0x4f84e3[_0x5ebce9];_0x3772e3['listenProvider_']['stopListening'](Tt(_0x52ca52),Mt(_0x3772e3,_0x52ca52));}}return _0x1bf795;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x503ffa){this['node_']=_0x503ffa;}['getImmediateChild'](_0x17106e){const _0x27bf1b=this['node_']['getImmediateChild'](_0x17106e);return new cs(_0x27bf1b);}['node'](){return this['node_'];}}class ls{constructor(_0xfa998b,_0x4ab014){this['syncTree_']=_0xfa998b,this['path_']=_0x4ab014;}['getImmediateChild'](_0x1a3359){const _0x3bb574=A(this['path_'],_0x1a3359);return new ls(this['syncTree_'],_0x3bb574);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x486d92){return _0x486d92=_0x486d92||{},_0x486d92['timestamp']=_0x486d92['timestamp']||new Date()['getTime'](),_0x486d92;},fr=function(_0x1334e9,_0x3f85cf,_0x14b1b1){if(!_0x1334e9||typeof _0x1334e9!='object')return _0x1334e9;if(f('.sv'in _0x1334e9,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1334e9['.sv']=='string')return td(_0x1334e9['.sv'],_0x3f85cf,_0x14b1b1);if(typeof _0x1334e9['.sv']=='object')return nd(_0x1334e9['.sv'],_0x3f85cf);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1334e9,null,0x2));},td=function(_0x2a6858,_0x21c779,_0x13c47f){switch(_0x2a6858){case'timestamp':return _0x13c47f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2a6858);}},nd=function(_0x12e3be,_0x5c91a9,_0x135605){_0x12e3be['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x12e3be,null,0x2));const _0x507b7d=_0x12e3be['increment'];typeof _0x507b7d!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x507b7d);const _0x203aea=_0x5c91a9['node']();if(f(_0x203aea!==null&&typeof _0x203aea<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x203aea['isLeafNode']())return _0x507b7d;const _0x4e646d=_0x203aea['getValue']();return typeof _0x4e646d!='number'?_0x507b7d:_0x4e646d+_0x507b7d;},Zo=function(_0x333b13,_0x1543b5,_0x35043a,_0x59d4e1){return us(_0x1543b5,new ls(_0x35043a,_0x333b13),_0x59d4e1);},hs=function(_0x56f882,_0x265545,_0x3610b1){return us(_0x56f882,new cs(_0x265545),_0x3610b1);};function us(_0x3f5392,_0x49943e,_0x19e7ff){const _0x3ccbaf=_0x3f5392['getPriority']()['val'](),_0x3b5403=fr(_0x3ccbaf,_0x49943e['getImmediateChild']('.priority'),_0x19e7ff);let _0x34b9bc;if(_0x3f5392['isLeafNode']()){const _0x54b3e5=_0x3f5392,_0x8b7644=fr(_0x54b3e5['getValue'](),_0x49943e,_0x19e7ff);return _0x8b7644!==_0x54b3e5['getValue']()||_0x3b5403!==_0x54b3e5['getPriority']()['val']()?new D(_0x8b7644,N(_0x3b5403)):_0x3f5392;}else{const _0x1b7c0a=_0x3f5392;return _0x34b9bc=_0x1b7c0a,_0x3b5403!==_0x1b7c0a['getPriority']()['val']()&&(_0x34b9bc=_0x34b9bc['updatePriority'](new D(_0x3b5403))),_0x1b7c0a['forEachChild'](R,(_0x539370,_0x2aa2e6)=>{const _0x1302f3=us(_0x2aa2e6,_0x49943e['getImmediateChild'](_0x539370),_0x19e7ff);_0x1302f3!==_0x2aa2e6&&(_0x34b9bc=_0x34b9bc['updateImmediateChild'](_0x539370,_0x1302f3));}),_0x34b9bc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3c42a9='',_0x58f8c4=null,_0x439e81={'children':{},'childCount':0x0}){this['name']=_0x3c42a9,this['parent']=_0x58f8c4,this['node']=_0x439e81;}}function Un(_0x4805c5,_0x4ad378){let _0x3cd2d1=_0x4ad378 instanceof C?_0x4ad378:new C(_0x4ad378),_0x2a2646=_0x4805c5,_0x41f5aa=y(_0x3cd2d1);for(;_0x41f5aa!==null;){const _0x551b78=Oe(_0x2a2646['node']['children'],_0x41f5aa)||{'children':{},'childCount':0x0};_0x2a2646=new ds(_0x41f5aa,_0x2a2646,_0x551b78),_0x3cd2d1=b(_0x3cd2d1),_0x41f5aa=y(_0x3cd2d1);}return _0x2a2646;}function Ge(_0x53201d){return _0x53201d['node']['value'];}function fs(_0x558df6,_0x2500cb){_0x558df6['node']['value']=_0x2500cb,Ri(_0x558df6);}function ea(_0x55e7aa){return _0x55e7aa['node']['childCount']>0x0;}function id(_0x13ab2c){return Ge(_0x13ab2c)===void 0x0&&!ea(_0x13ab2c);}function Wn(_0x3a084d,_0x512dba){x(_0x3a084d['node']['children'],(_0x58ab4b,_0x3bacf1)=>{_0x512dba(new ds(_0x58ab4b,_0x3a084d,_0x3bacf1));});}function ta(_0x20ed74,_0x331756,_0x48d7c2,_0x4c47f4){_0x48d7c2&&_0x331756(_0x20ed74),Wn(_0x20ed74,_0x1b96b9=>{ta(_0x1b96b9,_0x331756,!0x0);});}function sd(_0x4e9297,_0x266a5e,_0x96a0b){let _0x315939=_0x4e9297['parent'];for(;_0x315939!==null;){if(_0x266a5e(_0x315939))return!0x0;_0x315939=_0x315939['parent'];}return!0x1;}function Gt(_0x10814b){return new C(_0x10814b['parent']===null?_0x10814b['name']:Gt(_0x10814b['parent'])+'/'+_0x10814b['name']);}function Ri(_0x2a1688){_0x2a1688['parent']!==null&&rd(_0x2a1688['parent'],_0x2a1688['name'],_0x2a1688);}function rd(_0x5131d9,_0x972137,_0x6f3963){const _0xb19503=id(_0x6f3963),_0x2d3f34=Y(_0x5131d9['node']['children'],_0x972137);_0xb19503&&_0x2d3f34?(delete _0x5131d9['node']['children'][_0x972137],_0x5131d9['node']['childCount']--,Ri(_0x5131d9)):!_0xb19503&&!_0x2d3f34&&(_0x5131d9['node']['children'][_0x972137]=_0x6f3963['node'],_0x5131d9['node']['childCount']++,Ri(_0x5131d9));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x4288b5){return typeof _0x4288b5=='string'&&_0x4288b5['length']!==0x0&&!od['test'](_0x4288b5);},na=function(_0x595c99){return typeof _0x595c99=='string'&&_0x595c99['length']!==0x0&&!ad['test'](_0x595c99);},cd=function(_0x102964){return _0x102964&&(_0x102964=_0x102964['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x102964);},Cn=function(_0x63f88b){return _0x63f88b===null||typeof _0x63f88b=='string'||typeof _0x63f88b=='number'&&!Wi(_0x63f88b)||_0x63f88b&&typeof _0x63f88b=='object'&&Y(_0x63f88b,'.sv');},qt=function(_0x4f52f4,_0x5cae4d,_0x14904e,_0x1af001){_0x1af001&&_0x5cae4d===void 0x0||zt(Nn(_0x4f52f4,'value'),_0x5cae4d,_0x14904e);},zt=function(_0x354534,_0x4395bd,_0x5b5e03){const _0x53a9ed=_0x5b5e03 instanceof C?new Sh(_0x5b5e03,_0x354534):_0x5b5e03;if(_0x4395bd===void 0x0)throw new Error(_0x354534+'contains\x20undefined\x20'+Ne(_0x53a9ed));if(typeof _0x4395bd=='function')throw new Error(_0x354534+'contains\x20a\x20function\x20'+Ne(_0x53a9ed)+'\x20with\x20contents\x20=\x20'+_0x4395bd['toString']());if(Wi(_0x4395bd))throw new Error(_0x354534+'contains\x20'+_0x4395bd['toString']()+'\x20'+Ne(_0x53a9ed));if(typeof _0x4395bd=='string'&&_0x4395bd['length']>oi/0x3&&Pn(_0x4395bd)>oi)throw new Error(_0x354534+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x53a9ed)+'\x20(\x27'+_0x4395bd['substring'](0x0,0x32)+'...\x27)');if(_0x4395bd&&typeof _0x4395bd=='object'){let _0x53f6a7=!0x1,_0x5709c9=!0x1;if(x(_0x4395bd,(_0x43f8f4,_0x348a2e)=>{if(_0x43f8f4==='.value')_0x53f6a7=!0x0;else{if(_0x43f8f4!=='.priority'&&_0x43f8f4!=='.sv'&&(_0x5709c9=!0x0,!ps(_0x43f8f4)))throw new Error(_0x354534+'\x20contains\x20an\x20invalid\x20key\x20('+_0x43f8f4+')\x20'+Ne(_0x53a9ed)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x53a9ed,_0x43f8f4),zt(_0x354534,_0x348a2e,_0x53a9ed),Rh(_0x53a9ed);}),_0x53f6a7&&_0x5709c9)throw new Error(_0x354534+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x53a9ed)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x52d200,_0x5b0892){let _0x4b0980,_0x4ac0fe;for(_0x4b0980=0x0;_0x4b0980<_0x5b0892['length'];_0x4b0980++){_0x4ac0fe=_0x5b0892[_0x4b0980];const _0x2e0534=kt(_0x4ac0fe);for(let _0x3c2e97=0x0;_0x3c2e97<_0x2e0534['length'];_0x3c2e97++)if(!(_0x2e0534[_0x3c2e97]==='.priority'&&_0x3c2e97===_0x2e0534['length']-0x1)){if(!ps(_0x2e0534[_0x3c2e97]))throw new Error(_0x52d200+'contains\x20an\x20invalid\x20key\x20('+_0x2e0534[_0x3c2e97]+')\x20in\x20path\x20'+_0x4ac0fe['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5b0892['sort'](Th);let _0x1c7366=null;for(_0x4b0980=0x0;_0x4b0980<_0x5b0892['length'];_0x4b0980++){if(_0x4ac0fe=_0x5b0892[_0x4b0980],_0x1c7366!==null&&$(_0x1c7366,_0x4ac0fe))throw new Error(_0x52d200+'contains\x20a\x20path\x20'+_0x1c7366['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4ac0fe['toString']());_0x1c7366=_0x4ac0fe;}},hd=function(_0x14b0ef,_0x590d89,_0x1e4ce5,_0x3da9cc){const _0x13f1a3=Nn(_0x14b0ef,'values');if(!(_0x590d89&&typeof _0x590d89=='object')||Array['isArray'](_0x590d89))throw new Error(_0x13f1a3+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4568b9=[];x(_0x590d89,(_0x587dc6,_0x457ed7)=>{const _0x5cc9d8=new C(_0x587dc6);if(zt(_0x13f1a3,_0x457ed7,A(_0x1e4ce5,_0x5cc9d8)),Gi(_0x5cc9d8)==='.priority'&&!Cn(_0x457ed7))throw new Error(_0x13f1a3+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5cc9d8['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4568b9['push'](_0x5cc9d8);}),ld(_0x13f1a3,_0x4568b9);},_s=function(_0x47e6be,_0x4655ba,_0x3fd79a,_0x485910){if(!na(_0x3fd79a))throw new Error(Nn(_0x47e6be,_0x4655ba)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3fd79a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x335b34,_0x310039,_0x38c5b8,_0x3d2e0e){_0x38c5b8&&(_0x38c5b8=_0x38c5b8['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x335b34,_0x310039,_0x38c5b8);},gs=function(_0x54072f,_0x194cbb){if(y(_0x194cbb)==='.info')throw new Error(_0x54072f+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1a1603,_0x4113aa){const _0x507d31=_0x4113aa['path']['toString']();if(typeof _0x4113aa['repoInfo']['host']!='string'||_0x4113aa['repoInfo']['host']['length']===0x0||!ps(_0x4113aa['repoInfo']['namespace'])&&_0x4113aa['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x507d31['length']!==0x0&&!cd(_0x507d31))throw new Error(Nn(_0x1a1603,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0xd9ea86,_0x75c7a6){let _0x429706=null;for(let _0x529a94=0x0;_0x529a94<_0x75c7a6['length'];_0x529a94++){const _0x1e65fe=_0x75c7a6[_0x529a94],_0x36e95c=_0x1e65fe['getPath']();_0x429706!==null&&!qi(_0x36e95c,_0x429706['path'])&&(_0xd9ea86['eventLists_']['push'](_0x429706),_0x429706=null),_0x429706===null&&(_0x429706={'events':[],'path':_0x36e95c}),_0x429706['events']['push'](_0x1e65fe);}_0x429706&&_0xd9ea86['eventLists_']['push'](_0x429706);}function ia(_0x2a4eb9,_0x3f010c,_0x5b1c59){Bn(_0x2a4eb9,_0x5b1c59),sa(_0x2a4eb9,_0x2afc30=>qi(_0x2afc30,_0x3f010c));}function V(_0x3266f4,_0x2e51d5,_0x19f86e){Bn(_0x3266f4,_0x19f86e),sa(_0x3266f4,_0x1922bb=>$(_0x1922bb,_0x2e51d5)||$(_0x2e51d5,_0x1922bb));}function sa(_0x5073a2,_0x7e9569){_0x5073a2['recursionDepth_']++;let _0xcc3ac8=!0x0;for(let _0x2bff07=0x0;_0x2bff07<_0x5073a2['eventLists_']['length'];_0x2bff07++){const _0x5026de=_0x5073a2['eventLists_'][_0x2bff07];if(_0x5026de){const _0x52e393=_0x5026de['path'];_0x7e9569(_0x52e393)?(pd(_0x5073a2['eventLists_'][_0x2bff07]),_0x5073a2['eventLists_'][_0x2bff07]=null):_0xcc3ac8=!0x1;}}_0xcc3ac8&&(_0x5073a2['eventLists_']=[]),_0x5073a2['recursionDepth_']--;}function pd(_0x3c902a){for(let _0x1415db=0x0;_0x1415db<_0x3c902a['events']['length'];_0x1415db++){const _0x17892a=_0x3c902a['events'][_0x1415db];if(_0x17892a!==null){_0x3c902a['events'][_0x1415db]=null;const _0x4a5f85=_0x17892a['getEventRunner']();Et&&L('event:\x20'+_0x17892a['toString']()),lt(_0x4a5f85);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x322490,_0x23fc17,_0x26ecbf,_0x452b4f){this['repoInfo_']=_0x322490,this['forceRestClient_']=_0x23fc17,this['authTokenProvider_']=_0x26ecbf,this['appCheckProvider_']=_0x452b4f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x505473,_0x523c04,_0x1d896c){if(_0x505473['stats_']=Hi(_0x505473['repoInfo_']),_0x505473['forceRestClient_']||Yl())_0x505473['server_']=new fn(_0x505473['repoInfo_'],(_0x5970e3,_0x3a82d7,_0x48cf9d,_0x42c450)=>{pr(_0x505473,_0x5970e3,_0x3a82d7,_0x48cf9d,_0x42c450);},_0x505473['authTokenProvider_'],_0x505473['appCheckProvider_']),setTimeout(()=>_r(_0x505473,!0x0),0x0);else{if(typeof _0x1d896c<'u'&&_0x1d896c!==null){if(typeof _0x1d896c!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1d896c);}catch(_0x2ed32e){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2ed32e);}}_0x505473['persistentConnection_']=new ie(_0x505473['repoInfo_'],_0x523c04,(_0x3c2acd,_0x93f3e5,_0x3f8871,_0x5727a9)=>{pr(_0x505473,_0x3c2acd,_0x93f3e5,_0x3f8871,_0x5727a9);},_0x19084f=>{_r(_0x505473,_0x19084f);},_0x4809e6=>{yd(_0x505473,_0x4809e6);},_0x505473['authTokenProvider_'],_0x505473['appCheckProvider_'],_0x1d896c),_0x505473['server_']=_0x505473['persistentConnection_'];}_0x505473['authTokenProvider_']['addTokenChangeListener'](_0x5e1a59=>{_0x505473['server_']['refreshAuthToken'](_0x5e1a59);}),_0x505473['appCheckProvider_']['addTokenChangeListener'](_0x51b424=>{_0x505473['server_']['refreshAppCheckToken'](_0x51b424['token']);}),_0x505473['statsReporter_']=eh(_0x505473['repoInfo_'],()=>new eu(_0x505473['stats_'],_0x505473['server_'])),_0x505473['infoData_']=new Yh(),_0x505473['infoSyncTree_']=new dr({'startListening':(_0x4617de,_0x5db002,_0x1ed50c,_0x4f76a5)=>{let _0x3f982b=[];const _0x45c547=_0x505473['infoData_']['getNode'](_0x4617de['_path']);return _0x45c547['isEmpty']()||(_0x3f982b=$t(_0x505473['infoSyncTree_'],_0x4617de['_path'],_0x45c547),setTimeout(()=>{_0x4f76a5('ok');},0x0)),_0x3f982b;},'stopListening':()=>{}}),ms(_0x505473,'connected',!0x1),_0x505473['serverSyncTree_']=new dr({'startListening':(_0x36fe0a,_0x221bfc,_0x9faf4f,_0x546e05)=>(_0x505473['server_']['listen'](_0x36fe0a,_0x9faf4f,_0x221bfc,(_0xe1a573,_0xeb48cd)=>{const _0xd344b2=_0x546e05(_0xe1a573,_0xeb48cd);V(_0x505473['eventQueue_'],_0x36fe0a['_path'],_0xd344b2);}),[]),'stopListening':(_0x258831,_0x135cd4)=>{_0x505473['server_']['unlisten'](_0x258831,_0x135cd4);}});}function oa(_0x29cc4d){const _0x42b282=_0x29cc4d['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x42b282;}function jt(_0x40ff6f){return ed({'timestamp':oa(_0x40ff6f)});}function pr(_0x561af3,_0x3244ca,_0x96990c,_0x442aed,_0x5212cc){_0x561af3['dataUpdateCount']++;const _0x494773=new C(_0x3244ca);_0x96990c=_0x561af3['interceptServerDataCallback_']?_0x561af3['interceptServerDataCallback_'](_0x3244ca,_0x96990c):_0x96990c;let _0x5e9f5b=[];if(_0x5212cc){if(_0x442aed){const _0x913ee0=ln(_0x96990c,_0x300603=>N(_0x300603));_0x5e9f5b=Ku(_0x561af3['serverSyncTree_'],_0x494773,_0x913ee0,_0x5212cc);}else{const _0x284ca3=N(_0x96990c);_0x5e9f5b=Yo(_0x561af3['serverSyncTree_'],_0x494773,_0x284ca3,_0x5212cc);}}else{if(_0x442aed){const _0x107098=ln(_0x96990c,_0x52f3c4=>N(_0x52f3c4));_0x5e9f5b=qu(_0x561af3['serverSyncTree_'],_0x494773,_0x107098);}else{const _0x346277=N(_0x96990c);_0x5e9f5b=$t(_0x561af3['serverSyncTree_'],_0x494773,_0x346277);}}let _0x448d52=_0x494773;_0x5e9f5b['length']>0x0&&(_0x448d52=st(_0x561af3,_0x494773)),V(_0x561af3['eventQueue_'],_0x448d52,_0x5e9f5b);}function _r(_0x53a585,_0x541eae){ms(_0x53a585,'connected',_0x541eae),_0x541eae===!0x1&&wd(_0x53a585);}function yd(_0x2290f3,_0x498bfe){x(_0x498bfe,(_0x3e2623,_0x6d1860)=>{ms(_0x2290f3,_0x3e2623,_0x6d1860);});}function ms(_0x2027d3,_0x2b6eb6,_0x21075a){const _0x5a198c=new C('/.info/'+_0x2b6eb6),_0x3e72f0=N(_0x21075a);_0x2027d3['infoData_']['updateSnapshot'](_0x5a198c,_0x3e72f0);const _0x473f5b=$t(_0x2027d3['infoSyncTree_'],_0x5a198c,_0x3e72f0);V(_0x2027d3['eventQueue_'],_0x5a198c,_0x473f5b);}function Vn(_0xcd2da7){return _0xcd2da7['nextWriteId_']++;}function vd(_0x5e0734,_0x295820,_0xaead1f){const _0x401264=Yu(_0x5e0734['serverSyncTree_'],_0x295820);return _0x401264!=null?Promise['resolve'](_0x401264):_0x5e0734['server_']['get'](_0x295820)['then'](_0x49977e=>{const _0x5bb68a=N(_0x49977e)['withIndex'](_0x295820['_queryParams']['getIndex']());bi(_0x5e0734['serverSyncTree_'],_0x295820,_0xaead1f,!0x0);let _0x3ab8d7;if(_0x295820['_queryParams']['loadsAllData']())_0x3ab8d7=$t(_0x5e0734['serverSyncTree_'],_0x295820['_path'],_0x5bb68a);else{const _0xeb2722=Mt(_0x5e0734['serverSyncTree_'],_0x295820);_0x3ab8d7=Yo(_0x5e0734['serverSyncTree_'],_0x295820['_path'],_0x5bb68a,_0xeb2722);}return V(_0x5e0734['eventQueue_'],_0x295820['_path'],_0x3ab8d7),wn(_0x5e0734['serverSyncTree_'],_0x295820,_0xaead1f,null,!0x0),_0x5bb68a;},_0x1a53ff=>(ut(_0x5e0734,'get\x20for\x20query\x20'+O(_0x295820)+'\x20failed:\x20'+_0x1a53ff),Promise['reject'](new Error(_0x1a53ff))));}function Ed(_0x1f839b,_0x32b96e,_0x2a4862,_0x192179,_0x2e7459){ut(_0x1f839b,'set',{'path':_0x32b96e['toString'](),'value':_0x2a4862,'priority':_0x192179});const _0x5e75df=jt(_0x1f839b),_0x459948=N(_0x2a4862,_0x192179),_0x109e92=xn(_0x1f839b['serverSyncTree_'],_0x32b96e),_0x11a184=hs(_0x459948,_0x109e92,_0x5e75df),_0x29da48=Vn(_0x1f839b),_0x56977b=ss(_0x1f839b['serverSyncTree_'],_0x32b96e,_0x11a184,_0x29da48,!0x0);Bn(_0x1f839b['eventQueue_'],_0x56977b),_0x1f839b['server_']['put'](_0x32b96e['toString'](),_0x459948['val'](!0x0),(_0x327989,_0x346374)=>{const _0x23f866=_0x327989==='ok';_0x23f866||U('set\x20at\x20'+_0x32b96e+'\x20failed:\x20'+_0x327989);const _0xe357ed=pe(_0x1f839b['serverSyncTree_'],_0x29da48,!_0x23f866);V(_0x1f839b['eventQueue_'],_0x32b96e,_0xe357ed),Ai(_0x1f839b,_0x2e7459,_0x327989,_0x346374);});const _0x782d79=vs(_0x1f839b,_0x32b96e);st(_0x1f839b,_0x782d79),V(_0x1f839b['eventQueue_'],_0x782d79,[]);}function Id(_0x11caac,_0x1a4df3,_0x2a161e,_0x2e3f48){ut(_0x11caac,'update',{'path':_0x1a4df3['toString'](),'value':_0x2a161e});let _0x16ddc3=!0x0;const _0x5c85b3=jt(_0x11caac),_0x3389dd={};if(x(_0x2a161e,(_0x29bd0d,_0x2a9845)=>{_0x16ddc3=!0x1,_0x3389dd[_0x29bd0d]=Zo(A(_0x1a4df3,_0x29bd0d),N(_0x2a9845),_0x11caac['serverSyncTree_'],_0x5c85b3);}),_0x16ddc3)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x11caac,_0x2e3f48,'ok',void 0x0);else{const _0x1997f4=Vn(_0x11caac),_0x19089d=Gu(_0x11caac['serverSyncTree_'],_0x1a4df3,_0x3389dd,_0x1997f4);Bn(_0x11caac['eventQueue_'],_0x19089d),_0x11caac['server_']['merge'](_0x1a4df3['toString'](),_0x2a161e,(_0x998895,_0x412813)=>{const _0x4b20c3=_0x998895==='ok';_0x4b20c3||U('update\x20at\x20'+_0x1a4df3+'\x20failed:\x20'+_0x998895);const _0x3eb84b=pe(_0x11caac['serverSyncTree_'],_0x1997f4,!_0x4b20c3),_0x32a562=_0x3eb84b['length']>0x0?st(_0x11caac,_0x1a4df3):_0x1a4df3;V(_0x11caac['eventQueue_'],_0x32a562,_0x3eb84b),Ai(_0x11caac,_0x2e3f48,_0x998895,_0x412813);}),x(_0x2a161e,_0x1c2e0d=>{const _0x4f2382=vs(_0x11caac,A(_0x1a4df3,_0x1c2e0d));st(_0x11caac,_0x4f2382);}),V(_0x11caac['eventQueue_'],_0x1a4df3,[]);}}function wd(_0x1aa92b){ut(_0x1aa92b,'onDisconnectEvents');const _0x352a3a=jt(_0x1aa92b),_0x387b4c=pn();Ei(_0x1aa92b['onDisconnect_'],w(),(_0x93aead,_0x59ff5a)=>{const _0x422803=Zo(_0x93aead,_0x59ff5a,_0x1aa92b['serverSyncTree_'],_0x352a3a);Mo(_0x387b4c,_0x93aead,_0x422803);});let _0x4e96e7=[];Ei(_0x387b4c,w(),(_0x262c59,_0x556815)=>{_0x4e96e7=_0x4e96e7['concat']($t(_0x1aa92b['serverSyncTree_'],_0x262c59,_0x556815));const _0x420b9b=vs(_0x1aa92b,_0x262c59);st(_0x1aa92b,_0x420b9b);}),_0x1aa92b['onDisconnect_']=pn(),V(_0x1aa92b['eventQueue_'],w(),_0x4e96e7);}function Cd(_0x50c79d,_0x181200,_0x2ac6bd){let _0x117875;y(_0x181200['_path'])==='.info'?_0x117875=bi(_0x50c79d['infoSyncTree_'],_0x181200,_0x2ac6bd):_0x117875=bi(_0x50c79d['serverSyncTree_'],_0x181200,_0x2ac6bd),ia(_0x50c79d['eventQueue_'],_0x181200['_path'],_0x117875);}function Td(_0x9705c8,_0x4360ab,_0x50b0c4){let _0x18a2da;y(_0x4360ab['_path'])==='.info'?_0x18a2da=wn(_0x9705c8['infoSyncTree_'],_0x4360ab,_0x50b0c4):_0x18a2da=wn(_0x9705c8['serverSyncTree_'],_0x4360ab,_0x50b0c4),ia(_0x9705c8['eventQueue_'],_0x4360ab['_path'],_0x18a2da);}function aa(_0x575745){_0x575745['persistentConnection_']&&_0x575745['persistentConnection_']['interrupt'](ra);}function Sd(_0x374282){_0x374282['persistentConnection_']&&_0x374282['persistentConnection_']['resume'](ra);}function ut(_0x1fb2d3,..._0x5755a1){let _0x2cf047='';_0x1fb2d3['persistentConnection_']&&(_0x2cf047=_0x1fb2d3['persistentConnection_']['id']+':'),L(_0x2cf047,..._0x5755a1);}function Ai(_0x10944c,_0x2ea614,_0x415b43,_0x2d4c4b){_0x2ea614&&lt(()=>{if(_0x415b43==='ok')_0x2ea614(null);else{const _0x17976e=(_0x415b43||'error')['toUpperCase']();let _0xf1bada=_0x17976e;_0x2d4c4b&&(_0xf1bada+=':\x20'+_0x2d4c4b);const _0x5ad566=new Error(_0xf1bada);_0x5ad566['code']=_0x17976e,_0x2ea614(_0x5ad566);}});}function bd(_0x2f4c54,_0x3b8160,_0x4629c0,_0x56defd,_0x465333,_0xb5ff01){ut(_0x2f4c54,'transaction\x20on\x20'+_0x3b8160);const _0x436f68={'path':_0x3b8160,'update':_0x4629c0,'onComplete':_0x56defd,'status':null,'order':to(),'applyLocally':_0xb5ff01,'retryCount':0x0,'unwatcher':_0x465333,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x905ba7=ys(_0x2f4c54,_0x3b8160,void 0x0);_0x436f68['currentInputSnapshot']=_0x905ba7;const _0x20c80c=_0x436f68['update'](_0x905ba7['val']());if(_0x20c80c===void 0x0)_0x436f68['unwatcher'](),_0x436f68['currentOutputSnapshotRaw']=null,_0x436f68['currentOutputSnapshotResolved']=null,_0x436f68['onComplete']&&_0x436f68['onComplete'](null,!0x1,_0x436f68['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x20c80c,_0x436f68['path']),_0x436f68['status']=0x0;const _0xfbb79d=Un(_0x2f4c54['transactionQueueTree_'],_0x3b8160),_0x5d92e7=Ge(_0xfbb79d)||[];_0x5d92e7['push'](_0x436f68),fs(_0xfbb79d,_0x5d92e7);let _0x245e11;typeof _0x20c80c=='object'&&_0x20c80c!==null&&Y(_0x20c80c,'.priority')?(_0x245e11=Oe(_0x20c80c,'.priority'),f(Cn(_0x245e11),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x245e11=(xn(_0x2f4c54['serverSyncTree_'],_0x3b8160)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2c1697=jt(_0x2f4c54),_0x1338a9=N(_0x20c80c,_0x245e11),_0x154bf6=hs(_0x1338a9,_0x905ba7,_0x2c1697);_0x436f68['currentOutputSnapshotRaw']=_0x1338a9,_0x436f68['currentOutputSnapshotResolved']=_0x154bf6,_0x436f68['currentWriteId']=Vn(_0x2f4c54);const _0x32336f=ss(_0x2f4c54['serverSyncTree_'],_0x3b8160,_0x154bf6,_0x436f68['currentWriteId'],_0x436f68['applyLocally']);V(_0x2f4c54['eventQueue_'],_0x3b8160,_0x32336f),Hn(_0x2f4c54,_0x2f4c54['transactionQueueTree_']);}}function ys(_0xb7e262,_0x51409e,_0x16ed05){return xn(_0xb7e262['serverSyncTree_'],_0x51409e,_0x16ed05)||g['EMPTY_NODE'];}function Hn(_0x5716cc,_0x328103=_0x5716cc['transactionQueueTree_']){if(_0x328103||$n(_0x5716cc,_0x328103),Ge(_0x328103)){const _0x1d6802=la(_0x5716cc,_0x328103);f(_0x1d6802['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1d6802['every'](_0x388bd0=>_0x388bd0['status']===0x0)&&Rd(_0x5716cc,Gt(_0x328103),_0x1d6802);}else ea(_0x328103)&&Wn(_0x328103,_0x392fc2=>{Hn(_0x5716cc,_0x392fc2);});}function Rd(_0xfbb22d,_0x2488b0,_0x330ee0){const _0x27f398=_0x330ee0['map'](_0x9e44c=>_0x9e44c['currentWriteId']),_0x4423b6=ys(_0xfbb22d,_0x2488b0,_0x27f398);let _0x3e3f82=_0x4423b6;const _0x44e5eb=_0x4423b6['hash']();for(let _0x1207bd=0x0;_0x1207bd<_0x330ee0['length'];_0x1207bd++){const _0x5efa71=_0x330ee0[_0x1207bd];f(_0x5efa71['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5efa71['status']=0x1,_0x5efa71['retryCount']++;const _0x5770da=F(_0x2488b0,_0x5efa71['path']);_0x3e3f82=_0x3e3f82['updateChild'](_0x5770da,_0x5efa71['currentOutputSnapshotRaw']);}const _0x45f395=_0x3e3f82['val'](!0x0),_0x472a4f=_0x2488b0;_0xfbb22d['server_']['put'](_0x472a4f['toString'](),_0x45f395,_0x5cebf9=>{ut(_0xfbb22d,'transaction\x20put\x20response',{'path':_0x472a4f['toString'](),'status':_0x5cebf9});let _0x500173=[];if(_0x5cebf9==='ok'){const _0x212c2c=[];for(let _0x47d0ce=0x0;_0x47d0ce<_0x330ee0['length'];_0x47d0ce++)_0x330ee0[_0x47d0ce]['status']=0x2,_0x500173=_0x500173['concat'](pe(_0xfbb22d['serverSyncTree_'],_0x330ee0[_0x47d0ce]['currentWriteId'])),_0x330ee0[_0x47d0ce]['onComplete']&&_0x212c2c['push'](()=>_0x330ee0[_0x47d0ce]['onComplete'](null,!0x0,_0x330ee0[_0x47d0ce]['currentOutputSnapshotResolved'])),_0x330ee0[_0x47d0ce]['unwatcher']();$n(_0xfbb22d,Un(_0xfbb22d['transactionQueueTree_'],_0x2488b0)),Hn(_0xfbb22d,_0xfbb22d['transactionQueueTree_']),V(_0xfbb22d['eventQueue_'],_0x2488b0,_0x500173);for(let _0x4d0836=0x0;_0x4d0836<_0x212c2c['length'];_0x4d0836++)lt(_0x212c2c[_0x4d0836]);}else{if(_0x5cebf9==='datastale'){for(let _0x21401b=0x0;_0x21401b<_0x330ee0['length'];_0x21401b++)_0x330ee0[_0x21401b]['status']===0x3?_0x330ee0[_0x21401b]['status']=0x4:_0x330ee0[_0x21401b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x472a4f['toString']()+'\x20failed:\x20'+_0x5cebf9);for(let _0x5b009a=0x0;_0x5b009a<_0x330ee0['length'];_0x5b009a++)_0x330ee0[_0x5b009a]['status']=0x4,_0x330ee0[_0x5b009a]['abortReason']=_0x5cebf9;}st(_0xfbb22d,_0x2488b0);}},_0x44e5eb);}function st(_0x2b0f12,_0x481f97){const _0x402abb=ca(_0x2b0f12,_0x481f97),_0x53aeda=Gt(_0x402abb),_0x768818=la(_0x2b0f12,_0x402abb);return Ad(_0x2b0f12,_0x768818,_0x53aeda),_0x53aeda;}function Ad(_0x5f080c,_0x224b04,_0x5b6d15){if(_0x224b04['length']===0x0)return;const _0x49b873=[];let _0x51f314=[];const _0x1d186d=_0x224b04['filter'](_0x5cd23e=>_0x5cd23e['status']===0x0)['map'](_0x40be3a=>_0x40be3a['currentWriteId']);for(let _0x31a986=0x0;_0x31a986<_0x224b04['length'];_0x31a986++){const _0x19f7a1=_0x224b04[_0x31a986],_0x14a1d8=F(_0x5b6d15,_0x19f7a1['path']);let _0x1f00b4=!0x1,_0x2ef28f;if(f(_0x14a1d8!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x19f7a1['status']===0x4)_0x1f00b4=!0x0,_0x2ef28f=_0x19f7a1['abortReason'],_0x51f314=_0x51f314['concat'](pe(_0x5f080c['serverSyncTree_'],_0x19f7a1['currentWriteId'],!0x0));else{if(_0x19f7a1['status']===0x0){if(_0x19f7a1['retryCount']>=_d)_0x1f00b4=!0x0,_0x2ef28f='maxretry',_0x51f314=_0x51f314['concat'](pe(_0x5f080c['serverSyncTree_'],_0x19f7a1['currentWriteId'],!0x0));else{const _0x2dcec3=ys(_0x5f080c,_0x19f7a1['path'],_0x1d186d);_0x19f7a1['currentInputSnapshot']=_0x2dcec3;const _0xc3abca=_0x224b04[_0x31a986]['update'](_0x2dcec3['val']());if(_0xc3abca!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xc3abca,_0x19f7a1['path']);let _0x554a7e=N(_0xc3abca);typeof _0xc3abca=='object'&&_0xc3abca!=null&&Y(_0xc3abca,'.priority')||(_0x554a7e=_0x554a7e['updatePriority'](_0x2dcec3['getPriority']()));const _0x113d51=_0x19f7a1['currentWriteId'],_0x323317=jt(_0x5f080c),_0x213cf8=hs(_0x554a7e,_0x2dcec3,_0x323317);_0x19f7a1['currentOutputSnapshotRaw']=_0x554a7e,_0x19f7a1['currentOutputSnapshotResolved']=_0x213cf8,_0x19f7a1['currentWriteId']=Vn(_0x5f080c),_0x1d186d['splice'](_0x1d186d['indexOf'](_0x113d51),0x1),_0x51f314=_0x51f314['concat'](ss(_0x5f080c['serverSyncTree_'],_0x19f7a1['path'],_0x213cf8,_0x19f7a1['currentWriteId'],_0x19f7a1['applyLocally'])),_0x51f314=_0x51f314['concat'](pe(_0x5f080c['serverSyncTree_'],_0x113d51,!0x0));}else _0x1f00b4=!0x0,_0x2ef28f='nodata',_0x51f314=_0x51f314['concat'](pe(_0x5f080c['serverSyncTree_'],_0x19f7a1['currentWriteId'],!0x0));}}}V(_0x5f080c['eventQueue_'],_0x5b6d15,_0x51f314),_0x51f314=[],_0x1f00b4&&(_0x224b04[_0x31a986]['status']=0x2,function(_0x42e1dc){setTimeout(_0x42e1dc,Math['floor'](0x0));}(_0x224b04[_0x31a986]['unwatcher']),_0x224b04[_0x31a986]['onComplete']&&(_0x2ef28f==='nodata'?_0x49b873['push'](()=>_0x224b04[_0x31a986]['onComplete'](null,!0x1,_0x224b04[_0x31a986]['currentInputSnapshot'])):_0x49b873['push'](()=>_0x224b04[_0x31a986]['onComplete'](new Error(_0x2ef28f),!0x1,null))));}$n(_0x5f080c,_0x5f080c['transactionQueueTree_']);for(let _0x136e2f=0x0;_0x136e2f<_0x49b873['length'];_0x136e2f++)lt(_0x49b873[_0x136e2f]);Hn(_0x5f080c,_0x5f080c['transactionQueueTree_']);}function ca(_0x19ec12,_0x42a7c0){let _0x11fd42,_0x116fda=_0x19ec12['transactionQueueTree_'];for(_0x11fd42=y(_0x42a7c0);_0x11fd42!==null&&Ge(_0x116fda)===void 0x0;)_0x116fda=Un(_0x116fda,_0x11fd42),_0x42a7c0=b(_0x42a7c0),_0x11fd42=y(_0x42a7c0);return _0x116fda;}function la(_0x5a9e05,_0x206f90){const _0x1cd579=[];return ha(_0x5a9e05,_0x206f90,_0x1cd579),_0x1cd579['sort']((_0x247523,_0x1c15ce)=>_0x247523['order']-_0x1c15ce['order']),_0x1cd579;}function ha(_0x3c24d8,_0x2b9cd5,_0x2c6a44){const _0x12e046=Ge(_0x2b9cd5);if(_0x12e046){for(let _0xe4f830=0x0;_0xe4f830<_0x12e046['length'];_0xe4f830++)_0x2c6a44['push'](_0x12e046[_0xe4f830]);}Wn(_0x2b9cd5,_0xf37b38=>{ha(_0x3c24d8,_0xf37b38,_0x2c6a44);});}function $n(_0x661bfc,_0x3d275f){const _0x4590bf=Ge(_0x3d275f);if(_0x4590bf){let _0x255ef8=0x0;for(let _0x11e4eb=0x0;_0x11e4eb<_0x4590bf['length'];_0x11e4eb++)_0x4590bf[_0x11e4eb]['status']!==0x2&&(_0x4590bf[_0x255ef8]=_0x4590bf[_0x11e4eb],_0x255ef8++);_0x4590bf['length']=_0x255ef8,fs(_0x3d275f,_0x4590bf['length']>0x0?_0x4590bf:void 0x0);}Wn(_0x3d275f,_0xdc8b2b=>{$n(_0x661bfc,_0xdc8b2b);});}function vs(_0x4969fc,_0x29783e){const _0xb09349=Gt(ca(_0x4969fc,_0x29783e)),_0x3371f6=Un(_0x4969fc['transactionQueueTree_'],_0x29783e);return sd(_0x3371f6,_0x3e5e13=>{ai(_0x4969fc,_0x3e5e13);}),ai(_0x4969fc,_0x3371f6),ta(_0x3371f6,_0x9d0f9e=>{ai(_0x4969fc,_0x9d0f9e);}),_0xb09349;}function ai(_0x3dc5c6,_0xe49d06){const _0x455219=Ge(_0xe49d06);if(_0x455219){const _0x20271d=[];let _0xb0fbec=[],_0xe3cd11=-0x1;for(let _0x59f14b=0x0;_0x59f14b<_0x455219['length'];_0x59f14b++)_0x455219[_0x59f14b]['status']===0x3||(_0x455219[_0x59f14b]['status']===0x1?(f(_0xe3cd11===_0x59f14b-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0xe3cd11=_0x59f14b,_0x455219[_0x59f14b]['status']=0x3,_0x455219[_0x59f14b]['abortReason']='set'):(f(_0x455219[_0x59f14b]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x455219[_0x59f14b]['unwatcher'](),_0xb0fbec=_0xb0fbec['concat'](pe(_0x3dc5c6['serverSyncTree_'],_0x455219[_0x59f14b]['currentWriteId'],!0x0)),_0x455219[_0x59f14b]['onComplete']&&_0x20271d['push'](_0x455219[_0x59f14b]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0xe3cd11===-0x1?fs(_0xe49d06,void 0x0):_0x455219['length']=_0xe3cd11+0x1,V(_0x3dc5c6['eventQueue_'],Gt(_0xe49d06),_0xb0fbec);for(let _0x24d138=0x0;_0x24d138<_0x20271d['length'];_0x24d138++)lt(_0x20271d[_0x24d138]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x27f23b){let _0x27c50b='';const _0x5b284d=_0x27f23b['split']('/');for(let _0x57d6fc=0x0;_0x57d6fc<_0x5b284d['length'];_0x57d6fc++)if(_0x5b284d[_0x57d6fc]['length']>0x0){let _0x2dc3ee=_0x5b284d[_0x57d6fc];try{_0x2dc3ee=decodeURIComponent(_0x2dc3ee['replace'](/\+/g,'\x20'));}catch{}_0x27c50b+='/'+_0x2dc3ee;}return _0x27c50b;}function Nd(_0x263570){const _0x4127f4={};_0x263570['charAt'](0x0)==='?'&&(_0x263570=_0x263570['substring'](0x1));for(const _0x4fde82 of _0x263570['split']('&')){if(_0x4fde82['length']===0x0)continue;const _0xfe2b51=_0x4fde82['split']('=');_0xfe2b51['length']===0x2?_0x4127f4[decodeURIComponent(_0xfe2b51[0x0])]=decodeURIComponent(_0xfe2b51[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4fde82+'\x27\x20in\x20query\x20\x27'+_0x263570+'\x27');}return _0x4127f4;}const gr=function(_0x211967,_0x51c597){const _0x3c10d2=Pd(_0x211967),_0x30455c=_0x3c10d2['namespace'];_0x3c10d2['domain']==='firebase.com'&&oe(_0x3c10d2['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x30455c||_0x30455c==='undefined')&&_0x3c10d2['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3c10d2['secure']||Bl();const _0x33ada9=_0x3c10d2['scheme']==='ws'||_0x3c10d2['scheme']==='wss';return{'repoInfo':new _o(_0x3c10d2['host'],_0x3c10d2['secure'],_0x30455c,_0x33ada9,_0x51c597,'',_0x30455c!==_0x3c10d2['subdomain']),'path':new C(_0x3c10d2['pathString'])};},Pd=function(_0x227364){let _0x389866='',_0x37fab2='',_0x266ed7='',_0x21625a='',_0x347f1='',_0x4d86c6=!0x0,_0x2389e8='https',_0x2ebb4f=0x1bb;if(typeof _0x227364=='string'){let _0x2eff70=_0x227364['indexOf']('//');_0x2eff70>=0x0&&(_0x2389e8=_0x227364['substring'](0x0,_0x2eff70-0x1),_0x227364=_0x227364['substring'](_0x2eff70+0x2));let _0x39b913=_0x227364['indexOf']('/');_0x39b913===-0x1&&(_0x39b913=_0x227364['length']);let _0x4e285f=_0x227364['indexOf']('?');_0x4e285f===-0x1&&(_0x4e285f=_0x227364['length']),_0x389866=_0x227364['substring'](0x0,Math['min'](_0x39b913,_0x4e285f)),_0x39b913<_0x4e285f&&(_0x21625a=kd(_0x227364['substring'](_0x39b913,_0x4e285f)));const _0x31ef42=Nd(_0x227364['substring'](Math['min'](_0x227364['length'],_0x4e285f)));_0x2eff70=_0x389866['indexOf'](':'),_0x2eff70>=0x0?(_0x4d86c6=_0x2389e8==='https'||_0x2389e8==='wss',_0x2ebb4f=parseInt(_0x389866['substring'](_0x2eff70+0x1),0xa)):_0x2eff70=_0x389866['length'];const _0x437b1a=_0x389866['slice'](0x0,_0x2eff70);if(_0x437b1a['toLowerCase']()==='localhost')_0x37fab2='localhost';else{if(_0x437b1a['split']('.')['length']<=0x2)_0x37fab2=_0x437b1a;else{const _0x368c27=_0x389866['indexOf']('.');_0x266ed7=_0x389866['substring'](0x0,_0x368c27)['toLowerCase'](),_0x37fab2=_0x389866['substring'](_0x368c27+0x1),_0x347f1=_0x266ed7;}}'ns'in _0x31ef42&&(_0x347f1=_0x31ef42['ns']);}return{'host':_0x389866,'port':_0x2ebb4f,'domain':_0x37fab2,'subdomain':_0x266ed7,'secure':_0x4d86c6,'scheme':_0x2389e8,'pathString':_0x21625a,'namespace':_0x347f1};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x118a5b=0x0;const _0x4b1d6c=[];return function(_0x476f34){const _0x3d4f21=_0x476f34===_0x118a5b;_0x118a5b=_0x476f34;let _0xe6b794;const _0x564af4=new Array(0x8);for(_0xe6b794=0x7;_0xe6b794>=0x0;_0xe6b794--)_0x564af4[_0xe6b794]=mr['charAt'](_0x476f34%0x40),_0x476f34=Math['floor'](_0x476f34/0x40);f(_0x476f34===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3874c4=_0x564af4['join']('');if(_0x3d4f21){for(_0xe6b794=0xb;_0xe6b794>=0x0&&_0x4b1d6c[_0xe6b794]===0x3f;_0xe6b794--)_0x4b1d6c[_0xe6b794]=0x0;_0x4b1d6c[_0xe6b794]++;}else{for(_0xe6b794=0x0;_0xe6b794<0xc;_0xe6b794++)_0x4b1d6c[_0xe6b794]=Math['floor'](Math['random']()*0x40);}for(_0xe6b794=0x0;_0xe6b794<0xc;_0xe6b794++)_0x3874c4+=mr['charAt'](_0x4b1d6c[_0xe6b794]);return f(_0x3874c4['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3874c4;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x437563,_0x46f41d,_0x3f2996,_0x342604){this['eventType']=_0x437563,this['eventRegistration']=_0x46f41d,this['snapshot']=_0x3f2996,this['prevName']=_0x342604;}['getPath'](){const _0xa0646b=this['snapshot']['ref'];return this['eventType']==='value'?_0xa0646b['_path']:_0xa0646b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x42ebcc,_0x5ac431,_0x102502){this['eventRegistration']=_0x42ebcc,this['error']=_0x5ac431,this['path']=_0x102502;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x1900d9,_0x261fe3){this['snapshotCallback']=_0x1900d9,this['cancelCallback']=_0x261fe3;}['onValue'](_0x157d28,_0xc6c548){this['snapshotCallback']['call'](null,_0x157d28,_0xc6c548);}['onCancel'](_0x49d826){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x49d826);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5eca93){return this['snapshotCallback']===_0x5eca93['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5eca93['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5eca93['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xa06f29,_0x1616c3,_0x590ab9,_0x4bc97d){this['_repo']=_0xa06f29,this['_path']=_0x1616c3,this['_queryParams']=_0x590ab9,this['_orderByCalled']=_0x4bc97d;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4c69a3=nr(this['_queryParams']),_0x38c2c8=Bi(_0x4c69a3);return _0x38c2c8==='{}'?'default':_0x38c2c8;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4216a3){if(_0x4216a3=k(_0x4216a3),!(_0x4216a3 instanceof be))return!0x1;const _0x18c001=this['_repo']===_0x4216a3['_repo'],_0x688841=qi(this['_path'],_0x4216a3['_path']),_0x4e5b66=this['_queryIdentifier']===_0x4216a3['_queryIdentifier'];return _0x18c001&&_0x688841&&_0x4e5b66;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x4bcba7,_0x4c0d0f){if(_0x4bcba7['_orderByCalled']===!0x0)throw new Error(_0x4c0d0f+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3b18bf){let _0x2d115c=null,_0x4c0550=null;if(_0x3b18bf['hasStart']()&&(_0x2d115c=_0x3b18bf['getIndexStartValue']()),_0x3b18bf['hasEnd']()&&(_0x4c0550=_0x3b18bf['getIndexEndValue']()),_0x3b18bf['getIndex']()===ye){const _0x59d215='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1641b6='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3b18bf['hasStart']()){if(_0x3b18bf['getIndexStartName']()!==xe)throw new Error(_0x59d215);if(typeof _0x2d115c!='string')throw new Error(_0x1641b6);}if(_0x3b18bf['hasEnd']()){if(_0x3b18bf['getIndexEndName']()!==Ie)throw new Error(_0x59d215);if(typeof _0x4c0550!='string')throw new Error(_0x1641b6);}}else{if(_0x3b18bf['getIndex']()===R){if(_0x2d115c!=null&&!Cn(_0x2d115c)||_0x4c0550!=null&&!Cn(_0x4c0550))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3b18bf['getIndex']()instanceof Ki||_0x3b18bf['getIndex']()===Po,'unknown\x20index\x20type.'),_0x2d115c!=null&&typeof _0x2d115c=='object'||_0x4c0550!=null&&typeof _0x4c0550=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x88f720){if(_0x88f720['hasStart']()&&_0x88f720['hasEnd']()&&_0x88f720['hasLimit']()&&!_0x88f720['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x412a8e,_0x3f8770){super(_0x412a8e,_0x3f8770,new Qi(),!0x1);}get['parent'](){const _0x37c6dd=To(this['_path']);return _0x37c6dd===null?null:new Z(this['_repo'],_0x37c6dd);}get['root'](){let _0x2dc967=this;for(;_0x2dc967['parent']!==null;)_0x2dc967=_0x2dc967['parent'];return _0x2dc967;}}class rt{constructor(_0x7679c1,_0x5f32be,_0xbe827b){this['_node']=_0x7679c1,this['ref']=_0x5f32be,this['_index']=_0xbe827b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x400a5b){const _0x238a0b=new C(_0x400a5b),_0x1665b2=Lt(this['ref'],_0x400a5b);return new rt(this['_node']['getChild'](_0x238a0b),_0x1665b2,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1e4848){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x35df63,_0x580c20)=>_0x1e4848(new rt(_0x580c20,Lt(this['ref'],_0x35df63),R)));}['hasChild'](_0x2a5ae1){const _0x5f4368=new C(_0x2a5ae1);return!this['_node']['getChild'](_0x5f4368)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x67f38a,_0xb3b834){return _0x67f38a=k(_0x67f38a),_0x67f38a['_checkNotDeleted']('ref'),_0xb3b834!==void 0x0?Lt(_0x67f38a['_root'],_0xb3b834):_0x67f38a['_root'];}function Lt(_0x32645d,_0x556b9a){return _0x32645d=k(_0x32645d),y(_0x32645d['_path'])===null?ud('child','path',_0x556b9a):_s('child','path',_0x556b9a),new Z(_0x32645d['_repo'],A(_0x32645d['_path'],_0x556b9a));}function d_(_0x506ddf,_0x41ce9a){_0x506ddf=k(_0x506ddf),gs('push',_0x506ddf['_path']),qt('push',_0x41ce9a,_0x506ddf['_path'],!0x0);const _0x4d77bb=oa(_0x506ddf['_repo']),_0x5abffe=Od(_0x4d77bb),_0x29c082=Lt(_0x506ddf,_0x5abffe),_0x2b5ca3=Lt(_0x506ddf,_0x5abffe);let _0x8b033d;return _0x41ce9a!=null?_0x8b033d=Ld(_0x2b5ca3,_0x41ce9a)['then'](()=>_0x2b5ca3):_0x8b033d=Promise['resolve'](_0x2b5ca3),_0x29c082['then']=_0x8b033d['then']['bind'](_0x8b033d),_0x29c082['catch']=_0x8b033d['then']['bind'](_0x8b033d,void 0x0),_0x29c082;}function Ld(_0x50ff01,_0x2f8181){_0x50ff01=k(_0x50ff01),gs('set',_0x50ff01['_path']),qt('set',_0x2f8181,_0x50ff01['_path'],!0x1);const _0x3097d7=new Ve();return Ed(_0x50ff01['_repo'],_0x50ff01['_path'],_0x2f8181,null,_0x3097d7['wrapCallback'](()=>{})),_0x3097d7['promise'];}function f_(_0xaceedb,_0x47520f){hd('update',_0x47520f,_0xaceedb['_path']);const _0x1b3038=new Ve();return Id(_0xaceedb['_repo'],_0xaceedb['_path'],_0x47520f,_0x1b3038['wrapCallback'](()=>{})),_0x1b3038['promise'];}function p_(_0x8d8e0){_0x8d8e0=k(_0x8d8e0);const _0x4bbbc8=new ua(()=>{}),_0x18ef9c=new qn(_0x4bbbc8);return vd(_0x8d8e0['_repo'],_0x8d8e0,_0x18ef9c)['then'](_0x534ce1=>new rt(_0x534ce1,new Z(_0x8d8e0['_repo'],_0x8d8e0['_path']),_0x8d8e0['_queryParams']['getIndex']()));}class qn{constructor(_0x506716){this['callbackContext']=_0x506716;}['respondsTo'](_0x1de3d9){return _0x1de3d9==='value';}['createEvent'](_0x147cb8,_0xa69b6){const _0x410cee=_0xa69b6['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x147cb8['snapshotNode'],new Z(_0xa69b6['_repo'],_0xa69b6['_path']),_0x410cee));}['getEventRunner'](_0x584269){return _0x584269['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x584269['error']):()=>this['callbackContext']['onValue'](_0x584269['snapshot'],null);}['createCancelEvent'](_0x30ac1a,_0x8388c1){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x30ac1a,_0x8388c1):null;}['matches'](_0x47db24){return _0x47db24 instanceof qn?!_0x47db24['callbackContext']||!this['callbackContext']?!0x0:_0x47db24['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x5e3535,_0x566511,_0x43d0c9,_0x4605b2,_0x22dceb){const _0x387417=new ua(_0x43d0c9,void 0x0),_0x42bace=new qn(_0x387417);return Cd(_0x5e3535['_repo'],_0x5e3535,_0x42bace),()=>Td(_0x5e3535['_repo'],_0x5e3535,_0x42bace);}function Fd(_0x51ff0d,_0x3d7a53,_0x20f5a3,_0x319852){return xd(_0x51ff0d,'value',_0x3d7a53);}class dt{}class pa extends dt{constructor(_0x1def1d,_0x27b9db){super(),this['_value']=_0x1def1d,this['_key']=_0x27b9db,this['type']='endAt';}['_apply'](_0x58e9fb){qt('endAt',this['_value'],_0x58e9fb['_path'],!0x0);const _0x1a9b3c=Kh(_0x58e9fb['_queryParams'],this['_value'],this['_key']);if(fa(_0x1a9b3c),Gn(_0x1a9b3c),_0x58e9fb['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x58e9fb['_repo'],_0x58e9fb['_path'],_0x1a9b3c,_0x58e9fb['_orderByCalled']);}}function __(_0x22177e,_0x30695d){return new pa(_0x22177e,_0x30695d);}class _a extends dt{constructor(_0x4fcc4a,_0x5e7ecb){super(),this['_value']=_0x4fcc4a,this['_key']=_0x5e7ecb,this['type']='startAt';}['_apply'](_0x41d4b3){qt('startAt',this['_value'],_0x41d4b3['_path'],!0x0);const _0x33c31f=jh(_0x41d4b3['_queryParams'],this['_value'],this['_key']);if(fa(_0x33c31f),Gn(_0x33c31f),_0x41d4b3['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x41d4b3['_repo'],_0x41d4b3['_path'],_0x33c31f,_0x41d4b3['_orderByCalled']);}}function g_(_0x189f64=null,_0x525408){return new _a(_0x189f64,_0x525408);}class Ud extends dt{constructor(_0x1c6f17){super(),this['_limit']=_0x1c6f17,this['type']='limitToFirst';}['_apply'](_0x492b64){if(_0x492b64['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x492b64['_repo'],_0x492b64['_path'],zh(_0x492b64['_queryParams'],this['_limit']),_0x492b64['_orderByCalled']);}}function m_(_0x4217ad){if(Math['floor'](_0x4217ad)!==_0x4217ad||_0x4217ad<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x4217ad);}class Wd extends dt{constructor(_0x117ef7){super(),this['_path']=_0x117ef7,this['type']='orderByChild';}['_apply'](_0x5971cd){da(_0x5971cd,'orderByChild');const _0x4bee78=new C(this['_path']);if(v(_0x4bee78))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3b337e=new Ki(_0x4bee78),_0x432e22=Do(_0x5971cd['_queryParams'],_0x3b337e);return Gn(_0x432e22),new be(_0x5971cd['_repo'],_0x5971cd['_path'],_0x432e22,!0x0);}}function y_(_0x44c77f){if(_0x44c77f==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x44c77f==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x44c77f==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x44c77f),new Wd(_0x44c77f);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x231d6b){da(_0x231d6b,'orderByKey');const _0x535b01=Do(_0x231d6b['_queryParams'],ye);return Gn(_0x535b01),new be(_0x231d6b['_repo'],_0x231d6b['_path'],_0x535b01,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x9d8807,_0x90ec9f){super(),this['_value']=_0x9d8807,this['_key']=_0x90ec9f,this['type']='equalTo';}['_apply'](_0x3c6940){if(qt('equalTo',this['_value'],_0x3c6940['_path'],!0x1),_0x3c6940['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3c6940['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x3c6940));}}function E_(_0x203991,_0x311482){return new Vd(_0x203991,_0x311482);}function I_(_0x447758,..._0xee62c1){let _0x147aa0=k(_0x447758);for(const _0x4b9438 of _0xee62c1)_0x147aa0=_0x4b9438['_apply'](_0x147aa0);return _0x147aa0;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x32eaf9,_0x49e85e,_0x5d616b,_0xde3104){const _0x3fb93e=_0x49e85e['lastIndexOf'](':'),_0x46c820=_0x49e85e['substring'](0x0,_0x3fb93e),_0x1589d7=Wt(_0x46c820);_0x32eaf9['repoInfo_']=new _o(_0x49e85e,_0x1589d7,_0x32eaf9['repoInfo_']['namespace'],_0x32eaf9['repoInfo_']['webSocketOnly'],_0x32eaf9['repoInfo_']['nodeAdmin'],_0x32eaf9['repoInfo_']['persistenceKey'],_0x32eaf9['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5d616b),_0xde3104&&(_0x32eaf9['authTokenProvider_']=_0xde3104);}function qd(_0x92ef44,_0x59afc4,_0x57fd53,_0x54d557,_0x5b038b){let _0x3fbdde=_0x54d557||_0x92ef44['options']['databaseURL'];_0x3fbdde===void 0x0&&(_0x92ef44['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x92ef44['options']['projectId']),_0x3fbdde=_0x92ef44['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x424b95=gr(_0x3fbdde,_0x5b038b),_0x59abda=_0x424b95['repoInfo'],_0x2291f7;typeof process<'u'&&Us&&(_0x2291f7=Us[Hd]),_0x2291f7?(_0x3fbdde='http://'+_0x2291f7+'?ns='+_0x59abda['namespace'],_0x424b95=gr(_0x3fbdde,_0x5b038b),_0x59abda=_0x424b95['repoInfo']):_0x424b95['repoInfo']['secure'];const _0x363730=new Jl(_0x92ef44['name'],_0x92ef44['options'],_0x59afc4);dd('Invalid\x20Firebase\x20Database\x20URL',_0x424b95),v(_0x424b95['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x438395=jd(_0x59abda,_0x92ef44,_0x363730,new Ql(_0x92ef44,_0x57fd53));return new Kd(_0x438395,_0x92ef44);}function zd(_0x133da1,_0x392a6c){const _0x56fc29=ki[_0x392a6c];(!_0x56fc29||_0x56fc29[_0x133da1['key']]!==_0x133da1)&&oe('Database\x20'+_0x392a6c+'('+_0x133da1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x133da1),delete _0x56fc29[_0x133da1['key']];}function jd(_0x2a17e5,_0x356c8f,_0x75e094,_0x223204){let _0x4af4b9=ki[_0x356c8f['name']];_0x4af4b9||(_0x4af4b9={},ki[_0x356c8f['name']]=_0x4af4b9);let _0x383678=_0x4af4b9[_0x2a17e5['toURLString']()];return _0x383678&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x383678=new gd(_0x2a17e5,$d,_0x75e094,_0x223204),_0x4af4b9[_0x2a17e5['toURLString']()]=_0x383678,_0x383678;}class Kd{constructor(_0x20197d,_0x5294b1){this['_repoInternal']=_0x20197d,this['app']=_0x5294b1,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x330eec){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x330eec+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x2bd5cc=Qr(),_0xecb79d){const _0x411d46=Ui(_0x2bd5cc,'database')['getImmediate']({'identifier':_0xecb79d});if(!_0x411d46['_instanceStarted']){const _0x414987=ac('database');_0x414987&&Yd(_0x411d46,..._0x414987);}return _0x411d46;}function Yd(_0x3fcc73,_0x529e42,_0x2472ca,_0x7c297d={}){_0x3fcc73=k(_0x3fcc73),_0x3fcc73['_checkNotDeleted']('useEmulator');const _0x29dec9=_0x529e42+':'+_0x2472ca,_0x41c919=_0x3fcc73['_repoInternal'];if(_0x3fcc73['_instanceStarted']){if(_0x29dec9===_0x3fcc73['_repoInternal']['repoInfo_']['host']&&De(_0x7c297d,_0x41c919['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4fa89;if(_0x41c919['repoInfo_']['nodeAdmin'])_0x7c297d['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4fa89=new tn(tn['OWNER']);else{if(_0x7c297d['mockUserToken']){const _0x35e2aa=typeof _0x7c297d['mockUserToken']=='string'?_0x7c297d['mockUserToken']:cc(_0x7c297d['mockUserToken'],_0x3fcc73['app']['options']['projectId']);_0x4fa89=new tn(_0x35e2aa);}}Wt(_0x529e42)&&jr(_0x529e42),Gd(_0x41c919,_0x29dec9,_0x7c297d,_0x4fa89);}function C_(_0x5a7f0a){_0x5a7f0a=k(_0x5a7f0a),_0x5a7f0a['_checkNotDeleted']('goOffline'),aa(_0x5a7f0a['_repo']);}function T_(_0x1737dd){_0x1737dd=k(_0x1737dd),_0x1737dd['_checkNotDeleted']('goOnline'),Sd(_0x1737dd['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x57beb1){Ll(ct),et(new Me('database',(_0x172763,{instanceIdentifier:_0x4dc6ce})=>{const _0x39ab8b=_0x172763['getProvider']('app')['getImmediate'](),_0x44f8ca=_0x172763['getProvider']('auth-internal'),_0x401af6=_0x172763['getProvider']('app-check-internal');return qd(_0x39ab8b,_0x44f8ca,_0x401af6,_0x4dc6ce);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x57beb1),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x283c0f,_0x54c317){this['committed']=_0x283c0f,this['snapshot']=_0x54c317;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x22e653,_0xba0666,_0x176134){if(_0x22e653=k(_0x22e653),gs('Reference.transaction',_0x22e653['_path']),_0x22e653['key']==='.length'||_0x22e653['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x22e653['key']+'\x20is\x20a\x20read-only\x20object.';const _0x64b88c=!0x0,_0x22a16d=new Ve(),_0x773cd8=(_0x1583cb,_0x4e3c70,_0x37cba6)=>{let _0x1577e8=null;_0x1583cb?_0x22a16d['reject'](_0x1583cb):(_0x1577e8=new rt(_0x37cba6,new Z(_0x22e653['_repo'],_0x22e653['_path']),R),_0x22a16d['resolve'](new Xd(_0x4e3c70,_0x1577e8)));},_0x450bf8=Fd(_0x22e653,()=>{});return bd(_0x22e653['_repo'],_0x22e653['_path'],_0xba0666,_0x773cd8,_0x450bf8,_0x64b88c),_0x22a16d['promise'];}ie['prototype']['simpleListen']=function(_0x6f37a9,_0x4254ed){this['sendRequest']('q',{'p':_0x6f37a9},_0x4254ed);},ie['prototype']['echo']=function(_0x338e25,_0x196023){this['sendRequest']('echo',{'d':_0x338e25},_0x196023);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x53e3f1,..._0x204e2a){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x53e3f1,..._0x204e2a);}function nn(_0xd23a91,..._0x7c9a7e){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0xd23a91,..._0x7c9a7e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x445172,..._0x2ef91){throw Es(_0x445172,..._0x2ef91);}function J(_0x381ae6,..._0x42a29c){return Es(_0x381ae6,..._0x42a29c);}function ya(_0x2a551c,_0x3738e9,_0x28709a){const _0x1ac320={...Zd(),[_0x3738e9]:_0x28709a};return new Ut('auth','Firebase',_0x1ac320)['create'](_0x3738e9,{'appName':_0x2a551c['name']});}function se(_0x158efa){return ya(_0x158efa,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x19bdd2,..._0x53b55c){if(typeof _0x19bdd2!='string'){const _0x5bd2ac=_0x53b55c[0x0],_0x199bee=[..._0x53b55c['slice'](0x1)];return _0x199bee[0x0]&&(_0x199bee[0x0]['appName']=_0x19bdd2['name']),_0x19bdd2['_errorFactory']['create'](_0x5bd2ac,..._0x199bee);}return ma['create'](_0x19bdd2,..._0x53b55c);}function m(_0x399d9f,_0x5f0e9e,..._0x3aad34){if(!_0x399d9f)throw Es(_0x5f0e9e,..._0x3aad34);}function te(_0x3585f9){const _0x2ba48b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3585f9;throw nn(_0x2ba48b),new Error(_0x2ba48b);}function ae(_0x52ebf9,_0x41bf23){_0x52ebf9||te(_0x41bf23);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x5b46a2;return typeof self<'u'&&((_0x5b46a2=self['location'])==null?void 0x0:_0x5b46a2['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x20cd5c;return typeof self<'u'&&((_0x20cd5c=self['location'])==null?void 0x0:_0x20cd5c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x134ebc=navigator;return _0x134ebc['languages']&&_0x134ebc['languages'][0x0]||_0x134ebc['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x41e6b3,_0x4218f7){this['shortDelay']=_0x41e6b3,this['longDelay']=_0x4218f7,ae(_0x4218f7>_0x41e6b3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0xd451e4,_0x3e30ac){ae(_0xd451e4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2ba6cc}=_0xd451e4['emulator'];return _0x3e30ac?''+_0x2ba6cc+(_0x3e30ac['startsWith']('/')?_0x3e30ac['slice'](0x1):_0x3e30ac):_0x2ba6cc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x420ec5,_0x340581,_0x50bce6){this['fetchImpl']=_0x420ec5,_0x340581&&(this['headersImpl']=_0x340581),_0x50bce6&&(this['responseImpl']=_0x50bce6);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x4442ed,_0x10c11d){return _0x4442ed['tenantId']&&!_0x10c11d['tenantId']?{..._0x10c11d,'tenantId':_0x4442ed['tenantId']}:_0x10c11d;}async function Ae(_0x4966d1,_0xbbd91e,_0x20cd0e,_0x562ffc,_0x525181={}){return Ea(_0x4966d1,_0x525181,async()=>{let _0x274833={},_0x4772d6={};_0x562ffc&&(_0xbbd91e==='GET'?_0x4772d6=_0x562ffc:_0x274833={'body':JSON['stringify'](_0x562ffc)});const _0x4d89a8=at({..._0x4772d6,'key':_0x4966d1['config']['apiKey']})['slice'](0x1),_0x1d59d1=await _0x4966d1['_getAdditionalHeaders']();_0x1d59d1['Content-Type']='application/json',_0x4966d1['languageCode']&&(_0x1d59d1['X-Firebase-Locale']=_0x4966d1['languageCode']);const _0x4ae5cc={'method':_0xbbd91e,'headers':_0x1d59d1,..._0x274833};return lc()||(_0x4ae5cc['referrerPolicy']='strict-origin-when-cross-origin'),_0x4966d1['emulatorConfig']&&Wt(_0x4966d1['emulatorConfig']['host'])&&(_0x4ae5cc['credentials']='include'),va['fetch']()(await Ia(_0x4966d1,_0x4966d1['config']['apiHost'],_0x20cd0e,_0x4d89a8),_0x4ae5cc);});}async function Ea(_0x2f5b21,_0x7ebd05,_0xcf2136){_0x2f5b21['_canInitEmulator']=!0x1;const _0x3d3ab3={...rf,..._0x7ebd05};try{const _0x3558a2=new lf(_0x2f5b21),_0x50d382=await Promise['race']([_0xcf2136(),_0x3558a2['promise']]);_0x3558a2['clearNetworkTimeout']();const _0x400934=await _0x50d382['json']();if('needConfirmation'in _0x400934)throw en(_0x2f5b21,'account-exists-with-different-credential',_0x400934);if(_0x50d382['ok']&&!('errorMessage'in _0x400934))return _0x400934;{const _0x3f314a=_0x50d382['ok']?_0x400934['errorMessage']:_0x400934['error']['message'],[_0x3434a5,_0x390422]=_0x3f314a['split']('\x20:\x20');if(_0x3434a5==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x2f5b21,'credential-already-in-use',_0x400934);if(_0x3434a5==='EMAIL_EXISTS')throw en(_0x2f5b21,'email-already-in-use',_0x400934);if(_0x3434a5==='USER_DISABLED')throw en(_0x2f5b21,'user-disabled',_0x400934);const _0x4cbf76=_0x3d3ab3[_0x3434a5]||_0x3434a5['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x390422)throw ya(_0x2f5b21,_0x4cbf76,_0x390422);K(_0x2f5b21,_0x4cbf76);}}catch(_0x55f5ff){if(_0x55f5ff instanceof Se)throw _0x55f5ff;K(_0x2f5b21,'network-request-failed',{'message':String(_0x55f5ff)});}}async function Yt(_0x437cb6,_0x4f3e83,_0x2cd116,_0x5891bf,_0x24290c={}){const _0x4e6fa9=await Ae(_0x437cb6,_0x4f3e83,_0x2cd116,_0x5891bf,_0x24290c);return'mfaPendingCredential'in _0x4e6fa9&&K(_0x437cb6,'multi-factor-auth-required',{'_serverResponse':_0x4e6fa9}),_0x4e6fa9;}async function Ia(_0x222303,_0x1ad66d,_0x25b6b2,_0x38d3ec){const _0x35552f=''+_0x1ad66d+_0x25b6b2+'?'+_0x38d3ec,_0x26cf19=_0x222303,_0x36da48=_0x26cf19['config']['emulator']?Is(_0x222303['config'],_0x35552f):_0x222303['config']['apiScheme']+'://'+_0x35552f;return of['includes'](_0x25b6b2)&&(await _0x26cf19['_persistenceManagerAvailable'],_0x26cf19['_getPersistenceType']()==='COOKIE')?_0x26cf19['_getPersistence']()['_getFinalTarget'](_0x36da48)['toString']():_0x36da48;}function cf(_0x2f66e7){switch(_0x2f66e7){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3d86af){this['auth']=_0x3d86af,this['timer']=null,this['promise']=new Promise((_0x3b7395,_0x5f5976)=>{this['timer']=setTimeout(()=>_0x5f5976(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1df281,_0x4ebd2d,_0x260129){const _0x11174e={'appName':_0x1df281['name']};_0x260129['email']&&(_0x11174e['email']=_0x260129['email']),_0x260129['phoneNumber']&&(_0x11174e['phoneNumber']=_0x260129['phoneNumber']);const _0x248206=J(_0x1df281,_0x4ebd2d,_0x11174e);return _0x248206['customData']['_tokenResponse']=_0x260129,_0x248206;}function vr(_0x3fd7c6){return _0x3fd7c6!==void 0x0&&_0x3fd7c6['enterprise']!==void 0x0;}class hf{constructor(_0x27567e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x27567e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x27567e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x27567e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xcd6233){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x58ba10 of this['recaptchaEnforcementState'])if(_0x58ba10['provider']&&_0x58ba10['provider']===_0xcd6233)return cf(_0x58ba10['enforcementState']);return null;}['isProviderEnabled'](_0x582b32){return this['getProviderEnforcementState'](_0x582b32)==='ENFORCE'||this['getProviderEnforcementState'](_0x582b32)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x4225b2,_0x227153){return Ae(_0x4225b2,'GET','/v2/recaptchaConfig',Re(_0x4225b2,_0x227153));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x1a9f8c,_0x3bee6e){return Ae(_0x1a9f8c,'POST','/v1/accounts:delete',_0x3bee6e);}async function Sn(_0x31ca5f,_0x2c00a7){return Ae(_0x31ca5f,'POST','/v1/accounts:lookup',_0x2c00a7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x2f5a41){if(_0x2f5a41)try{const _0x5c2940=new Date(Number(_0x2f5a41));if(!isNaN(_0x5c2940['getTime']()))return _0x5c2940['toUTCString']();}catch{}}async function ff(_0x4a4f74,_0x182e61=!0x1){const _0x4c4024=k(_0x4a4f74),_0x462dcb=await _0x4c4024['getIdToken'](_0x182e61),_0x54a736=ws(_0x462dcb);m(_0x54a736&&_0x54a736['exp']&&_0x54a736['auth_time']&&_0x54a736['iat'],_0x4c4024['auth'],'internal-error');const _0x29199d=typeof _0x54a736['firebase']=='object'?_0x54a736['firebase']:void 0x0,_0x2fe6c5=_0x29199d==null?void 0x0:_0x29199d['sign_in_provider'];return{'claims':_0x54a736,'token':_0x462dcb,'authTime':St(ci(_0x54a736['auth_time'])),'issuedAtTime':St(ci(_0x54a736['iat'])),'expirationTime':St(ci(_0x54a736['exp'])),'signInProvider':_0x2fe6c5||null,'signInSecondFactor':(_0x29199d==null?void 0x0:_0x29199d['sign_in_second_factor'])||null};}function ci(_0x20c203){return Number(_0x20c203)*0x3e8;}function ws(_0x2fb99b){const [_0x320951,_0xa7b115,_0x4805b2]=_0x2fb99b['split']('.');if(_0x320951===void 0x0||_0xa7b115===void 0x0||_0x4805b2===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x37437b=cn(_0xa7b115);return _0x37437b?JSON['parse'](_0x37437b):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5af902){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5af902==null?void 0x0:_0x5af902['toString']()),null;}}function Er(_0xc2e388){const _0x3a401b=ws(_0xc2e388);return m(_0x3a401b,'internal-error'),m(typeof _0x3a401b['exp']<'u','internal-error'),m(typeof _0x3a401b['iat']<'u','internal-error'),Number(_0x3a401b['exp'])-Number(_0x3a401b['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0xa58337,_0x258fef,_0x3b2060=!0x1){if(_0x3b2060)return _0x258fef;try{return await _0x258fef;}catch(_0x28eafe){throw _0x28eafe instanceof Se&&pf(_0x28eafe)&&_0xa58337['auth']['currentUser']===_0xa58337&&await _0xa58337['auth']['signOut'](),_0x28eafe;}}function pf({code:_0x276cdd}){return _0x276cdd==='auth/user-disabled'||_0x276cdd==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3438e0){this['user']=_0x3438e0,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4cb909){if(_0x4cb909){const _0x5e5ff4=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5e5ff4;}else{this['errorBackoff']=0x7530;const _0x3ba2b9=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3ba2b9);}}['schedule'](_0x50149d=!0x1){if(!this['isRunning'])return;const _0xa3a149=this['getInterval'](_0x50149d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xa3a149);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x29bc47){(_0x29bc47==null?void 0x0:_0x29bc47['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x174b5a,_0x391996){this['createdAt']=_0x174b5a,this['lastLoginAt']=_0x391996,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x26776f){this['createdAt']=_0x26776f['createdAt'],this['lastLoginAt']=_0x26776f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x25dce5){var _0x445462;const _0x444a2d=_0x25dce5['auth'],_0x128d6b=await _0x25dce5['getIdToken'](),_0x4d9e8c=await xt(_0x25dce5,Sn(_0x444a2d,{'idToken':_0x128d6b}));m(_0x4d9e8c==null?void 0x0:_0x4d9e8c['users']['length'],_0x444a2d,'internal-error');const _0x713630=_0x4d9e8c['users'][0x0];_0x25dce5['_notifyReloadListener'](_0x713630);const _0x5d4846=(_0x445462=_0x713630['providerUserInfo'])!=null&&_0x445462['length']?wa(_0x713630['providerUserInfo']):[],_0x2d027e=mf(_0x25dce5['providerData'],_0x5d4846),_0x34ae82=_0x25dce5['isAnonymous'],_0x542dce=!(_0x25dce5['email']&&_0x713630['passwordHash'])&&!(_0x2d027e!=null&&_0x2d027e['length']),_0x2cdb0e=_0x34ae82?_0x542dce:!0x1,_0x346fb8={'uid':_0x713630['localId'],'displayName':_0x713630['displayName']||null,'photoURL':_0x713630['photoUrl']||null,'email':_0x713630['email']||null,'emailVerified':_0x713630['emailVerified']||!0x1,'phoneNumber':_0x713630['phoneNumber']||null,'tenantId':_0x713630['tenantId']||null,'providerData':_0x2d027e,'metadata':new Pi(_0x713630['createdAt'],_0x713630['lastLoginAt']),'isAnonymous':_0x2cdb0e};Object['assign'](_0x25dce5,_0x346fb8);}async function gf(_0x22c8ce){const _0x5a682e=k(_0x22c8ce);await bn(_0x5a682e),await _0x5a682e['auth']['_persistUserIfCurrent'](_0x5a682e),_0x5a682e['auth']['_notifyListenersIfCurrent'](_0x5a682e);}function mf(_0x4c50e1,_0x3e1cfc){return[..._0x4c50e1['filter'](_0x5c388a=>!_0x3e1cfc['some'](_0x4df26b=>_0x4df26b['providerId']===_0x5c388a['providerId'])),..._0x3e1cfc];}function wa(_0x29f904){return _0x29f904['map'](({providerId:_0x505b1c,..._0x5cf47d})=>({'providerId':_0x505b1c,'uid':_0x5cf47d['rawId']||'','displayName':_0x5cf47d['displayName']||null,'email':_0x5cf47d['email']||null,'phoneNumber':_0x5cf47d['phoneNumber']||null,'photoURL':_0x5cf47d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x223df8,_0x4284d9){const _0x2b771b=await Ea(_0x223df8,{},async()=>{const _0x24b09d=at({'grant_type':'refresh_token','refresh_token':_0x4284d9})['slice'](0x1),{tokenApiHost:_0x33223c,apiKey:_0x3c1d7d}=_0x223df8['config'],_0x2108c1=await Ia(_0x223df8,_0x33223c,'/v1/token','key='+_0x3c1d7d),_0x3462a8=await _0x223df8['_getAdditionalHeaders']();_0x3462a8['Content-Type']='application/x-www-form-urlencoded';const _0x34028b={'method':'POST','headers':_0x3462a8,'body':_0x24b09d};return _0x223df8['emulatorConfig']&&Wt(_0x223df8['emulatorConfig']['host'])&&(_0x34028b['credentials']='include'),va['fetch']()(_0x2108c1,_0x34028b);});return{'accessToken':_0x2b771b['access_token'],'expiresIn':_0x2b771b['expires_in'],'refreshToken':_0x2b771b['refresh_token']};}async function vf(_0x3e8026,_0xb85571){return Ae(_0x3e8026,'POST','/v2/accounts:revokeToken',Re(_0x3e8026,_0xb85571));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x16bae1){m(_0x16bae1['idToken'],'internal-error'),m(typeof _0x16bae1['idToken']<'u','internal-error'),m(typeof _0x16bae1['refreshToken']<'u','internal-error');const _0x7db654='expiresIn'in _0x16bae1&&typeof _0x16bae1['expiresIn']<'u'?Number(_0x16bae1['expiresIn']):Er(_0x16bae1['idToken']);this['updateTokensAndExpiration'](_0x16bae1['idToken'],_0x16bae1['refreshToken'],_0x7db654);}['updateFromIdToken'](_0x71ee8){m(_0x71ee8['length']!==0x0,'internal-error');const _0x1a4f9c=Er(_0x71ee8);this['updateTokensAndExpiration'](_0x71ee8,null,_0x1a4f9c);}async['getToken'](_0x3f1331,_0x30c2bf=!0x1){return!_0x30c2bf&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3f1331,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3f1331,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x40a18e,_0x23b1e0){const {accessToken:_0x13f630,refreshToken:_0x58d963,expiresIn:_0x119cc5}=await yf(_0x40a18e,_0x23b1e0);this['updateTokensAndExpiration'](_0x13f630,_0x58d963,Number(_0x119cc5));}['updateTokensAndExpiration'](_0x58e354,_0x456d33,_0x498f1d){this['refreshToken']=_0x456d33||null,this['accessToken']=_0x58e354||null,this['expirationTime']=Date['now']()+_0x498f1d*0x3e8;}static['fromJSON'](_0x541de6,_0x584380){const {refreshToken:_0x48153f,accessToken:_0x37024,expirationTime:_0x42d418}=_0x584380,_0x55b4c7=new Je();return _0x48153f&&(m(typeof _0x48153f=='string','internal-error',{'appName':_0x541de6}),_0x55b4c7['refreshToken']=_0x48153f),_0x37024&&(m(typeof _0x37024=='string','internal-error',{'appName':_0x541de6}),_0x55b4c7['accessToken']=_0x37024),_0x42d418&&(m(typeof _0x42d418=='number','internal-error',{'appName':_0x541de6}),_0x55b4c7['expirationTime']=_0x42d418),_0x55b4c7;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x16a0e6){this['accessToken']=_0x16a0e6['accessToken'],this['refreshToken']=_0x16a0e6['refreshToken'],this['expirationTime']=_0x16a0e6['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x38f37d,_0x12cbce){m(typeof _0x38f37d=='string'||typeof _0x38f37d>'u','internal-error',{'appName':_0x12cbce});}class z{constructor({uid:_0x3819f0,auth:_0x482d7e,stsTokenManager:_0x3462fc,..._0x995310}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3819f0,this['auth']=_0x482d7e,this['stsTokenManager']=_0x3462fc,this['accessToken']=_0x3462fc['accessToken'],this['displayName']=_0x995310['displayName']||null,this['email']=_0x995310['email']||null,this['emailVerified']=_0x995310['emailVerified']||!0x1,this['phoneNumber']=_0x995310['phoneNumber']||null,this['photoURL']=_0x995310['photoURL']||null,this['isAnonymous']=_0x995310['isAnonymous']||!0x1,this['tenantId']=_0x995310['tenantId']||null,this['providerData']=_0x995310['providerData']?[..._0x995310['providerData']]:[],this['metadata']=new Pi(_0x995310['createdAt']||void 0x0,_0x995310['lastLoginAt']||void 0x0);}async['getIdToken'](_0x8923a4){const _0x8bfd25=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x8923a4));return m(_0x8bfd25,this['auth'],'internal-error'),this['accessToken']!==_0x8bfd25&&(this['accessToken']=_0x8bfd25,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x8bfd25;}['getIdTokenResult'](_0x45a5bc){return ff(this,_0x45a5bc);}['reload'](){return gf(this);}['_assign'](_0x182cfa){this!==_0x182cfa&&(m(this['uid']===_0x182cfa['uid'],this['auth'],'internal-error'),this['displayName']=_0x182cfa['displayName'],this['photoURL']=_0x182cfa['photoURL'],this['email']=_0x182cfa['email'],this['emailVerified']=_0x182cfa['emailVerified'],this['phoneNumber']=_0x182cfa['phoneNumber'],this['isAnonymous']=_0x182cfa['isAnonymous'],this['tenantId']=_0x182cfa['tenantId'],this['providerData']=_0x182cfa['providerData']['map'](_0x5b0994=>({..._0x5b0994})),this['metadata']['_copy'](_0x182cfa['metadata']),this['stsTokenManager']['_assign'](_0x182cfa['stsTokenManager']));}['_clone'](_0x2c0eea){const _0x249e65=new z({...this,'auth':_0x2c0eea,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x249e65['metadata']['_copy'](this['metadata']),_0x249e65;}['_onReload'](_0x1b03a4){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1b03a4,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2563f9){this['reloadListener']?this['reloadListener'](_0x2563f9):this['reloadUserInfo']=_0x2563f9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2ab70b,_0x59966e=!0x1){let _0x5570ab=!0x1;_0x2ab70b['idToken']&&_0x2ab70b['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2ab70b),_0x5570ab=!0x0),_0x59966e&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5570ab&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1eb7a2=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1eb7a2})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1b2bf2=>({..._0x1b2bf2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4effdc,_0x5840c5){const _0x450a2c=_0x5840c5['displayName']??void 0x0,_0x36f36f=_0x5840c5['email']??void 0x0,_0x2b2dda=_0x5840c5['phoneNumber']??void 0x0,_0x341e5a=_0x5840c5['photoURL']??void 0x0,_0x31e8a6=_0x5840c5['tenantId']??void 0x0,_0x1eabe5=_0x5840c5['_redirectEventId']??void 0x0,_0x2212b9=_0x5840c5['createdAt']??void 0x0,_0x2e2681=_0x5840c5['lastLoginAt']??void 0x0,{uid:_0x2f1984,emailVerified:_0x514b4b,isAnonymous:_0x5bcb75,providerData:_0x10221f,stsTokenManager:_0x4c4575}=_0x5840c5;m(_0x2f1984&&_0x4c4575,_0x4effdc,'internal-error');const _0x24dfbb=Je['fromJSON'](this['name'],_0x4c4575);m(typeof _0x2f1984=='string',_0x4effdc,'internal-error'),ce(_0x450a2c,_0x4effdc['name']),ce(_0x36f36f,_0x4effdc['name']),m(typeof _0x514b4b=='boolean',_0x4effdc,'internal-error'),m(typeof _0x5bcb75=='boolean',_0x4effdc,'internal-error'),ce(_0x2b2dda,_0x4effdc['name']),ce(_0x341e5a,_0x4effdc['name']),ce(_0x31e8a6,_0x4effdc['name']),ce(_0x1eabe5,_0x4effdc['name']),ce(_0x2212b9,_0x4effdc['name']),ce(_0x2e2681,_0x4effdc['name']);const _0x403c18=new z({'uid':_0x2f1984,'auth':_0x4effdc,'email':_0x36f36f,'emailVerified':_0x514b4b,'displayName':_0x450a2c,'isAnonymous':_0x5bcb75,'photoURL':_0x341e5a,'phoneNumber':_0x2b2dda,'tenantId':_0x31e8a6,'stsTokenManager':_0x24dfbb,'createdAt':_0x2212b9,'lastLoginAt':_0x2e2681});return _0x10221f&&Array['isArray'](_0x10221f)&&(_0x403c18['providerData']=_0x10221f['map'](_0x546f58=>({..._0x546f58}))),_0x1eabe5&&(_0x403c18['_redirectEventId']=_0x1eabe5),_0x403c18;}static async['_fromIdTokenResponse'](_0x4cd3d2,_0x4893c9,_0x3b1f9c=!0x1){const _0x4fcc39=new Je();_0x4fcc39['updateFromServerResponse'](_0x4893c9);const _0x4fcd13=new z({'uid':_0x4893c9['localId'],'auth':_0x4cd3d2,'stsTokenManager':_0x4fcc39,'isAnonymous':_0x3b1f9c});return await bn(_0x4fcd13),_0x4fcd13;}static async['_fromGetAccountInfoResponse'](_0x22a07e,_0x51418b,_0x148026){const _0x23c1a4=_0x51418b['users'][0x0];m(_0x23c1a4['localId']!==void 0x0,'internal-error');const _0x2063e6=_0x23c1a4['providerUserInfo']!==void 0x0?wa(_0x23c1a4['providerUserInfo']):[],_0x42ac0c=!(_0x23c1a4['email']&&_0x23c1a4['passwordHash'])&&!(_0x2063e6!=null&&_0x2063e6['length']),_0x9d308e=new Je();_0x9d308e['updateFromIdToken'](_0x148026);const _0x52ce19=new z({'uid':_0x23c1a4['localId'],'auth':_0x22a07e,'stsTokenManager':_0x9d308e,'isAnonymous':_0x42ac0c}),_0xee9b27={'uid':_0x23c1a4['localId'],'displayName':_0x23c1a4['displayName']||null,'photoURL':_0x23c1a4['photoUrl']||null,'email':_0x23c1a4['email']||null,'emailVerified':_0x23c1a4['emailVerified']||!0x1,'phoneNumber':_0x23c1a4['phoneNumber']||null,'tenantId':_0x23c1a4['tenantId']||null,'providerData':_0x2063e6,'metadata':new Pi(_0x23c1a4['createdAt'],_0x23c1a4['lastLoginAt']),'isAnonymous':!(_0x23c1a4['email']&&_0x23c1a4['passwordHash'])&&!(_0x2063e6!=null&&_0x2063e6['length'])};return Object['assign'](_0x52ce19,_0xee9b27),_0x52ce19;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x2ff747){ae(_0x2ff747 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3555a6=Ir['get'](_0x2ff747);return _0x3555a6?(ae(_0x3555a6 instanceof _0x2ff747,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3555a6):(_0x3555a6=new _0x2ff747(),Ir['set'](_0x2ff747,_0x3555a6),_0x3555a6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3f1d2b,_0x2dd70e){this['storage'][_0x3f1d2b]=_0x2dd70e;}async['_get'](_0x31fd3a){const _0x582d86=this['storage'][_0x31fd3a];return _0x582d86===void 0x0?null:_0x582d86;}async['_remove'](_0x33eab0){delete this['storage'][_0x33eab0];}['_addListener'](_0x3f41d7,_0x4187da){}['_removeListener'](_0x5bb554,_0x211464){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x8305cd,_0x5b982c,_0x244019){return'firebase:'+_0x8305cd+':'+_0x5b982c+':'+_0x244019;}class Xe{constructor(_0x102382,_0x52f511,_0x450eaa){this['persistence']=_0x102382,this['auth']=_0x52f511,this['userKey']=_0x450eaa;const {config:_0x195b17,name:_0x1c8d5d}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x195b17['apiKey'],_0x1c8d5d),this['fullPersistenceKey']=sn('persistence',_0x195b17['apiKey'],_0x1c8d5d),this['boundEventHandler']=_0x52f511['_onStorageEvent']['bind'](_0x52f511),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xa0d650){return this['persistence']['_set'](this['fullUserKey'],_0xa0d650['toJSON']());}async['getCurrentUser'](){const _0x111a79=await this['persistence']['_get'](this['fullUserKey']);if(!_0x111a79)return null;if(typeof _0x111a79=='string'){const _0x15af6f=await Sn(this['auth'],{'idToken':_0x111a79})['catch'](()=>{});return _0x15af6f?z['_fromGetAccountInfoResponse'](this['auth'],_0x15af6f,_0x111a79):null;}return z['_fromJSON'](this['auth'],_0x111a79);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5133ac){if(this['persistence']===_0x5133ac)return;const _0x364ab4=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5133ac,_0x364ab4)return this['setCurrentUser'](_0x364ab4);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x10b3c4,_0x21eba9,_0x510946='authUser'){if(!_0x21eba9['length'])return new Xe(ne(wr),_0x10b3c4,_0x510946);const _0x2d3a39=(await Promise['all'](_0x21eba9['map'](async _0x5d778c=>{if(await _0x5d778c['_isAvailable']())return _0x5d778c;})))['filter'](_0x24223b=>_0x24223b);let _0xdcc36e=_0x2d3a39[0x0]||ne(wr);const _0x13faa5=sn(_0x510946,_0x10b3c4['config']['apiKey'],_0x10b3c4['name']);let _0x3d7c08=null;for(const _0x1672c6 of _0x21eba9)try{const _0x4fe35c=await _0x1672c6['_get'](_0x13faa5);if(_0x4fe35c){let _0x5e92f9;if(typeof _0x4fe35c=='string'){const _0x2ff3e0=await Sn(_0x10b3c4,{'idToken':_0x4fe35c})['catch'](()=>{});if(!_0x2ff3e0)break;_0x5e92f9=await z['_fromGetAccountInfoResponse'](_0x10b3c4,_0x2ff3e0,_0x4fe35c);}else _0x5e92f9=z['_fromJSON'](_0x10b3c4,_0x4fe35c);_0x1672c6!==_0xdcc36e&&(_0x3d7c08=_0x5e92f9),_0xdcc36e=_0x1672c6;break;}}catch{}const _0x459834=_0x2d3a39['filter'](_0x1ac208=>_0x1ac208['_shouldAllowMigration']);return!_0xdcc36e['_shouldAllowMigration']||!_0x459834['length']?new Xe(_0xdcc36e,_0x10b3c4,_0x510946):(_0xdcc36e=_0x459834[0x0],_0x3d7c08&&await _0xdcc36e['_set'](_0x13faa5,_0x3d7c08['toJSON']()),await Promise['all'](_0x21eba9['map'](async _0x3f3e91=>{if(_0x3f3e91!==_0xdcc36e)try{await _0x3f3e91['_remove'](_0x13faa5);}catch{}})),new Xe(_0xdcc36e,_0x10b3c4,_0x510946));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4de696){const _0x36a47d=_0x4de696['toLowerCase']();if(_0x36a47d['includes']('opera/')||_0x36a47d['includes']('opr/')||_0x36a47d['includes']('opios/'))return'Opera';if(Ra(_0x36a47d))return'IEMobile';if(_0x36a47d['includes']('msie')||_0x36a47d['includes']('trident/'))return'IE';if(_0x36a47d['includes']('edge/'))return'Edge';if(Ta(_0x36a47d))return'Firefox';if(_0x36a47d['includes']('silk/'))return'Silk';if(ka(_0x36a47d))return'Blackberry';if(Na(_0x36a47d))return'Webos';if(Sa(_0x36a47d))return'Safari';if((_0x36a47d['includes']('chrome/')||ba(_0x36a47d))&&!_0x36a47d['includes']('edge/'))return'Chrome';if(Aa(_0x36a47d))return'Android';{const _0x16634b=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4cbd77=_0x4de696['match'](_0x16634b);if((_0x4cbd77==null?void 0x0:_0x4cbd77['length'])===0x2)return _0x4cbd77[0x1];}return'Other';}function Ta(_0x54e026=W()){return/firefox\//i['test'](_0x54e026);}function Sa(_0x174a7a=W()){const _0x486582=_0x174a7a['toLowerCase']();return _0x486582['includes']('safari/')&&!_0x486582['includes']('chrome/')&&!_0x486582['includes']('crios/')&&!_0x486582['includes']('android');}function ba(_0x38b9df=W()){return/crios\//i['test'](_0x38b9df);}function Ra(_0x59547a=W()){return/iemobile/i['test'](_0x59547a);}function Aa(_0x4caf98=W()){return/android/i['test'](_0x4caf98);}function ka(_0x37de07=W()){return/blackberry/i['test'](_0x37de07);}function Na(_0x3202ed=W()){return/webos/i['test'](_0x3202ed);}function Cs(_0x294e51=W()){return/iphone|ipad|ipod/i['test'](_0x294e51)||/macintosh/i['test'](_0x294e51)&&/mobile/i['test'](_0x294e51);}function Ef(_0x3e2c8f=W()){var _0x30f726;return Cs(_0x3e2c8f)&&!!((_0x30f726=window['navigator'])!=null&&_0x30f726['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4c5228=W()){return Cs(_0x4c5228)||Aa(_0x4c5228)||Na(_0x4c5228)||ka(_0x4c5228)||/windows phone/i['test'](_0x4c5228)||Ra(_0x4c5228);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x40f71e,_0x4a7f68=[]){let _0x186f61;switch(_0x40f71e){case'Browser':_0x186f61=Cr(W());break;case'Worker':_0x186f61=Cr(W())+'-'+_0x40f71e;break;default:_0x186f61=_0x40f71e;}const _0xc277d0=_0x4a7f68['length']?_0x4a7f68['join'](','):'FirebaseCore-web';return _0x186f61+'/JsCore/'+ct+'/'+_0xc277d0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3d9965){this['auth']=_0x3d9965,this['queue']=[];}['pushCallback'](_0x162367,_0x6cbc34){const _0xc311ff=_0x1e23aa=>new Promise((_0x4b7b6b,_0x5d4b76)=>{try{const _0x18b0bd=_0x162367(_0x1e23aa);_0x4b7b6b(_0x18b0bd);}catch(_0x2c676e){_0x5d4b76(_0x2c676e);}});_0xc311ff['onAbort']=_0x6cbc34,this['queue']['push'](_0xc311ff);const _0x34bd12=this['queue']['length']-0x1;return()=>{this['queue'][_0x34bd12]=()=>Promise['resolve']();};}async['runMiddleware'](_0x58b4b7){if(this['auth']['currentUser']===_0x58b4b7)return;const _0x3d4820=[];try{for(const _0x44f891 of this['queue'])await _0x44f891(_0x58b4b7),_0x44f891['onAbort']&&_0x3d4820['push'](_0x44f891['onAbort']);}catch(_0x58e3a4){_0x3d4820['reverse']();for(const _0x4c8da3 of _0x3d4820)try{_0x4c8da3();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x58e3a4==null?void 0x0:_0x58e3a4['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x31ff6f,_0x3a2a01={}){return Ae(_0x31ff6f,'GET','/v2/passwordPolicy',Re(_0x31ff6f,_0x3a2a01));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x49e2d8){var _0x1fd869;const _0x23dac7=_0x49e2d8['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x23dac7['minPasswordLength']??Tf,_0x23dac7['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x23dac7['maxPasswordLength']),_0x23dac7['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x23dac7['containsLowercaseCharacter']),_0x23dac7['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x23dac7['containsUppercaseCharacter']),_0x23dac7['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x23dac7['containsNumericCharacter']),_0x23dac7['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x23dac7['containsNonAlphanumericCharacter']),this['enforcementState']=_0x49e2d8['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1fd869=_0x49e2d8['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1fd869['join'](''))??'',this['forceUpgradeOnSignin']=_0x49e2d8['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x49e2d8['schemaVersion'];}['validatePassword'](_0x2db73b){const _0x46e87d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2db73b,_0x46e87d),this['validatePasswordCharacterOptions'](_0x2db73b,_0x46e87d),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['meetsMinPasswordLength']??!0x0),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['meetsMaxPasswordLength']??!0x0),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['containsLowercaseLetter']??!0x0),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['containsUppercaseLetter']??!0x0),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['containsNumericCharacter']??!0x0),_0x46e87d['isValid']&&(_0x46e87d['isValid']=_0x46e87d['containsNonAlphanumericCharacter']??!0x0),_0x46e87d;}['validatePasswordLengthOptions'](_0x299566,_0x4ccec6){const _0x8e1e9f=this['customStrengthOptions']['minPasswordLength'],_0x372d6f=this['customStrengthOptions']['maxPasswordLength'];_0x8e1e9f&&(_0x4ccec6['meetsMinPasswordLength']=_0x299566['length']>=_0x8e1e9f),_0x372d6f&&(_0x4ccec6['meetsMaxPasswordLength']=_0x299566['length']<=_0x372d6f);}['validatePasswordCharacterOptions'](_0x218ca2,_0x57bea7){this['updatePasswordCharacterOptionsStatuses'](_0x57bea7,!0x1,!0x1,!0x1,!0x1);let _0x5e8b0e;for(let _0x56b428=0x0;_0x56b428<_0x218ca2['length'];_0x56b428++)_0x5e8b0e=_0x218ca2['charAt'](_0x56b428),this['updatePasswordCharacterOptionsStatuses'](_0x57bea7,_0x5e8b0e>='a'&&_0x5e8b0e<='z',_0x5e8b0e>='A'&&_0x5e8b0e<='Z',_0x5e8b0e>='0'&&_0x5e8b0e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5e8b0e));}['updatePasswordCharacterOptionsStatuses'](_0xe989bd,_0x460cfe,_0x4e13e4,_0x434388,_0x455a36){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xe989bd['containsLowercaseLetter']||(_0xe989bd['containsLowercaseLetter']=_0x460cfe)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xe989bd['containsUppercaseLetter']||(_0xe989bd['containsUppercaseLetter']=_0x4e13e4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xe989bd['containsNumericCharacter']||(_0xe989bd['containsNumericCharacter']=_0x434388)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xe989bd['containsNonAlphanumericCharacter']||(_0xe989bd['containsNonAlphanumericCharacter']=_0x455a36));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x276dd8,_0x1d5914,_0x18893d,_0x572722){this['app']=_0x276dd8,this['heartbeatServiceProvider']=_0x1d5914,this['appCheckServiceProvider']=_0x18893d,this['config']=_0x572722,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x276dd8['name'],this['clientVersion']=_0x572722['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4f1249=>this['_resolvePersistenceManagerAvailable']=_0x4f1249);}['_initializeWithPersistence'](_0x538cfa,_0x3da075){return _0x3da075&&(this['_popupRedirectResolver']=ne(_0x3da075)),this['_initializationPromise']=this['queue'](async()=>{var _0x337b1b,_0x570109,_0x379bd5;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x538cfa),(_0x337b1b=this['_resolvePersistenceManagerAvailable'])==null||_0x337b1b['call'](this),!this['_deleted'])){if((_0x570109=this['_popupRedirectResolver'])!=null&&_0x570109['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3da075),this['lastNotifiedUid']=((_0x379bd5=this['currentUser'])==null?void 0x0:_0x379bd5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x25b2ea=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x25b2ea)){if(this['currentUser']&&_0x25b2ea&&this['currentUser']['uid']===_0x25b2ea['uid']){this['_currentUser']['_assign'](_0x25b2ea),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x25b2ea,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5eed08){try{const _0x53ce35=await Sn(this,{'idToken':_0x5eed08}),_0x318de0=await z['_fromGetAccountInfoResponse'](this,_0x53ce35,_0x5eed08);await this['directlySetCurrentUser'](_0x318de0);}catch(_0x27c03a){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x27c03a),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x196d80){var _0x2d982e;if(H(this['app'])){const _0x2e24f7=this['app']['settings']['authIdToken'];return _0x2e24f7?new Promise(_0x5f06d8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2e24f7)['then'](_0x5f06d8,_0x5f06d8));}):this['directlySetCurrentUser'](null);}const _0x5bc312=await this['assertedPersistence']['getCurrentUser']();let _0x10734c=_0x5bc312,_0x3a5dc6=!0x1;if(_0x196d80&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x24840b=(_0x2d982e=this['redirectUser'])==null?void 0x0:_0x2d982e['_redirectEventId'],_0x45715a=_0x10734c==null?void 0x0:_0x10734c['_redirectEventId'],_0x5c0a21=await this['tryRedirectSignIn'](_0x196d80);(!_0x24840b||_0x24840b===_0x45715a)&&(_0x5c0a21!=null&&_0x5c0a21['user'])&&(_0x10734c=_0x5c0a21['user'],_0x3a5dc6=!0x0);}if(!_0x10734c)return this['directlySetCurrentUser'](null);if(!_0x10734c['_redirectEventId']){if(_0x3a5dc6)try{await this['beforeStateQueue']['runMiddleware'](_0x10734c);}catch(_0xc94a64){_0x10734c=_0x5bc312,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xc94a64));}return _0x10734c?this['reloadAndSetCurrentUserOrClear'](_0x10734c):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x10734c['_redirectEventId']?this['directlySetCurrentUser'](_0x10734c):this['reloadAndSetCurrentUserOrClear'](_0x10734c);}async['tryRedirectSignIn'](_0xbad3eb){let _0xa71b30=null;try{_0xa71b30=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xbad3eb,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xa71b30;}async['reloadAndSetCurrentUserOrClear'](_0x463e3e){try{await bn(_0x463e3e);}catch(_0x23b9cf){if((_0x23b9cf==null?void 0x0:_0x23b9cf['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x463e3e);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x13b14a){if(H(this['app']))return Promise['reject'](se(this));const _0x259deb=_0x13b14a?k(_0x13b14a):null;return _0x259deb&&m(_0x259deb['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x259deb&&_0x259deb['_clone'](this));}async['_updateCurrentUser'](_0x43c0b3,_0x16d8d9=!0x1){if(!this['_deleted'])return _0x43c0b3&&m(this['tenantId']===_0x43c0b3['tenantId'],this,'tenant-id-mismatch'),_0x16d8d9||await this['beforeStateQueue']['runMiddleware'](_0x43c0b3),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x43c0b3),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2d61af){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x2d61af));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x16dbba){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3ef99e=this['_getPasswordPolicyInternal']();return _0x3ef99e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3ef99e['validatePassword'](_0x16dbba);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x432a48=await Cf(this),_0x315b37=new Sf(_0x432a48);this['tenantId']===null?this['_projectPasswordPolicy']=_0x315b37:this['_tenantPasswordPolicies'][this['tenantId']]=_0x315b37;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x283f54){this['_errorFactory']=new Ut('auth','Firebase',_0x283f54());}['onAuthStateChanged'](_0x27d77f,_0x84fdcd,_0x3895d6){return this['registerStateListener'](this['authStateSubscription'],_0x27d77f,_0x84fdcd,_0x3895d6);}['beforeAuthStateChanged'](_0x52cf17,_0x18b0d1){return this['beforeStateQueue']['pushCallback'](_0x52cf17,_0x18b0d1);}['onIdTokenChanged'](_0x2313ff,_0x5bf4b8,_0x3c2c64){return this['registerStateListener'](this['idTokenSubscription'],_0x2313ff,_0x5bf4b8,_0x3c2c64);}['authStateReady'](){return new Promise((_0x2c79f9,_0x382da4)=>{if(this['currentUser'])_0x2c79f9();else{const _0x1425da=this['onAuthStateChanged'](()=>{_0x1425da(),_0x2c79f9();},_0x382da4);}});}async['revokeAccessToken'](_0x114d3a){if(this['currentUser']){const _0x3c598a=await this['currentUser']['getIdToken'](),_0x58eec4={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x114d3a,'idToken':_0x3c598a};this['tenantId']!=null&&(_0x58eec4['tenantId']=this['tenantId']),await vf(this,_0x58eec4);}}['toJSON'](){var _0x3a9cc6;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3a9cc6=this['_currentUser'])==null?void 0x0:_0x3a9cc6['toJSON']()};}async['_setRedirectUser'](_0x2662b6,_0x5953dd){const _0x395eb7=await this['getOrInitRedirectPersistenceManager'](_0x5953dd);return _0x2662b6===null?_0x395eb7['removeCurrentUser']():_0x395eb7['setCurrentUser'](_0x2662b6);}async['getOrInitRedirectPersistenceManager'](_0x139078){if(!this['redirectPersistenceManager']){const _0x3c3bd0=_0x139078&&ne(_0x139078)||this['_popupRedirectResolver'];m(_0x3c3bd0,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3c3bd0['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1b8d63){var _0x14330d,_0x3bd9f2;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x14330d=this['_currentUser'])==null?void 0x0:_0x14330d['_redirectEventId'])===_0x1b8d63?this['_currentUser']:((_0x3bd9f2=this['redirectUser'])==null?void 0x0:_0x3bd9f2['_redirectEventId'])===_0x1b8d63?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x380f2c){if(_0x380f2c===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x380f2c));}['_notifyListenersIfCurrent'](_0x4345bc){_0x4345bc===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x21bb7a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x252e23=((_0x21bb7a=this['currentUser'])==null?void 0x0:_0x21bb7a['uid'])??null;this['lastNotifiedUid']!==_0x252e23&&(this['lastNotifiedUid']=_0x252e23,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x42a381,_0x2e3347,_0x3c51a0,_0x37d046){if(this['_deleted'])return()=>{};const _0x352eb6=typeof _0x2e3347=='function'?_0x2e3347:_0x2e3347['next']['bind'](_0x2e3347);let _0x1b1022=!0x1;const _0x27a7b7=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x27a7b7,this,'internal-error'),_0x27a7b7['then'](()=>{_0x1b1022||_0x352eb6(this['currentUser']);}),typeof _0x2e3347=='function'){const _0x49483e=_0x42a381['addObserver'](_0x2e3347,_0x3c51a0,_0x37d046);return()=>{_0x1b1022=!0x0,_0x49483e();};}else{const _0x426147=_0x42a381['addObserver'](_0x2e3347);return()=>{_0x1b1022=!0x0,_0x426147();};}}async['directlySetCurrentUser'](_0x5f1bf0){this['currentUser']&&this['currentUser']!==_0x5f1bf0&&this['_currentUser']['_stopProactiveRefresh'](),_0x5f1bf0&&this['isProactiveRefreshEnabled']&&_0x5f1bf0['_startProactiveRefresh'](),this['currentUser']=_0x5f1bf0,_0x5f1bf0?await this['assertedPersistence']['setCurrentUser'](_0x5f1bf0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x38a16a){return this['operations']=this['operations']['then'](_0x38a16a,_0x38a16a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x100478){!_0x100478||this['frameworks']['includes'](_0x100478)||(this['frameworks']['push'](_0x100478),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x52ea2a;const _0x4b67a7={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4b67a7['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4d80b5=await((_0x52ea2a=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x52ea2a['getHeartbeatsHeader']());_0x4d80b5&&(_0x4b67a7['X-Firebase-Client']=_0x4d80b5);const _0x103727=await this['_getAppCheckToken']();return _0x103727&&(_0x4b67a7['X-Firebase-AppCheck']=_0x103727),_0x4b67a7;}async['_getAppCheckToken'](){var _0x33c7e4;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5d568a=await((_0x33c7e4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x33c7e4['getToken']());return _0x5d568a!=null&&_0x5d568a['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5d568a['error']),_0x5d568a==null?void 0x0:_0x5d568a['token'];}}function qe(_0xa2d5d){return k(_0xa2d5d);}class Tr{constructor(_0x400298){this['auth']=_0x400298,this['observer']=null,this['addObserver']=Ic(_0x203625=>this['observer']=_0x203625);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x25fe6c){zn=_0x25fe6c;}function Da(_0x3979f4){return zn['loadJS'](_0x3979f4);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x17b180){return'__'+_0x17b180+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x2dad6e){_0x2dad6e();}['execute'](_0x51ea6a,_0x1d646b){return Promise['resolve']('token');}['render'](_0x3d1bce,_0x3b1e96){return'';}}class Of{['ready'](_0x5456f0){_0x5456f0();}['execute'](_0x121561,_0x3007ad){return Promise['resolve']('token');}['render'](_0x52147d,_0x119417){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3312bf){this['type']=Df,this['auth']=qe(_0x3312bf);}async['verify'](_0x4391d1='verify',_0x5571e1=!0x1){async function _0x5c160e(_0x28481d){if(!_0x5571e1){if(_0x28481d['tenantId']==null&&_0x28481d['_agentRecaptchaConfig']!=null)return _0x28481d['_agentRecaptchaConfig']['siteKey'];if(_0x28481d['tenantId']!=null&&_0x28481d['_tenantRecaptchaConfigs'][_0x28481d['tenantId']]!==void 0x0)return _0x28481d['_tenantRecaptchaConfigs'][_0x28481d['tenantId']]['siteKey'];}return new Promise(async(_0x115d46,_0x3e4420)=>{uf(_0x28481d,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x369481=>{if(_0x369481['recaptchaKey']===void 0x0)_0x3e4420(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x62e27b=new hf(_0x369481);return _0x28481d['tenantId']==null?_0x28481d['_agentRecaptchaConfig']=_0x62e27b:_0x28481d['_tenantRecaptchaConfigs'][_0x28481d['tenantId']]=_0x62e27b,_0x115d46(_0x62e27b['siteKey']);}})['catch'](_0x1760e9=>{_0x3e4420(_0x1760e9);});});}function _0x500017(_0x561caa,_0xfe9986,_0xc0396b){const _0x4c3ac2=window['grecaptcha'];vr(_0x4c3ac2)?_0x4c3ac2['enterprise']['ready'](()=>{_0x4c3ac2['enterprise']['execute'](_0x561caa,{'action':_0x4391d1})['then'](_0x230826=>{_0xfe9986(_0x230826);})['catch'](()=>{_0xfe9986(Ma);});}):_0xc0396b(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x700fb0,_0x5f0584)=>{_0x5c160e(this['auth'])['then'](async _0x25d8c5=>{if(!_0x5571e1&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x500017(_0x25d8c5,_0x700fb0,_0x5f0584);else{if(typeof window>'u'){_0x5f0584(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5acde7=Af();_0x5acde7['length']!==0x0&&(_0x5acde7+=_0x25d8c5+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x5eb5dd;(_0x5eb5dd=le['scriptInjectionDeferred'])==null||_0x5eb5dd['resolve']();},Da(_0x5acde7)['then'](()=>{var _0x259e74;return(_0x259e74=le['scriptInjectionDeferred'])==null?void 0x0:_0x259e74['promise'];})['then'](()=>{_0x500017(_0x25d8c5,_0x700fb0,_0x5f0584);})['catch'](_0x1fc404=>{_0x5f0584(_0x1fc404);});}})['catch'](_0x1bd4cc=>{_0x5f0584(_0x1bd4cc);});});}}le['scriptInjectionDeferred']=null;async function br(_0x3f78b9,_0x3945cc,_0x301aca,_0x101552=!0x1,_0x5bf312=!0x1){const _0x55482d=new le(_0x3f78b9);let _0xd35988;if(_0x5bf312)_0xd35988=Ma;else try{_0xd35988=await _0x55482d['verify'](_0x301aca);}catch{_0xd35988=await _0x55482d['verify'](_0x301aca,!0x0);}const _0x24eed1={..._0x3945cc};if(_0x301aca==='mfaSmsEnrollment'||_0x301aca==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x24eed1){const _0x580787=_0x24eed1['phoneEnrollmentInfo']['phoneNumber'],_0x5e01a1=_0x24eed1['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x24eed1,{'phoneEnrollmentInfo':{'phoneNumber':_0x580787,'recaptchaToken':_0x5e01a1,'captchaResponse':_0xd35988,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x24eed1){const _0x38cc99=_0x24eed1['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x24eed1,{'phoneSignInInfo':{'recaptchaToken':_0x38cc99,'captchaResponse':_0xd35988,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x24eed1;}return _0x101552?Object['assign'](_0x24eed1,{'captchaResp':_0xd35988}):Object['assign'](_0x24eed1,{'captchaResponse':_0xd35988}),Object['assign'](_0x24eed1,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x24eed1,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x24eed1;}async function Oi(_0x24d802,_0x3c826f,_0x1f3914,_0xf5cb55,_0x33f123){var _0x309f9d;if((_0x309f9d=_0x24d802['_getRecaptchaConfig']())!=null&&_0x309f9d['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xff2411=await br(_0x24d802,_0x3c826f,_0x1f3914,_0x1f3914==='getOobCode');return _0xf5cb55(_0x24d802,_0xff2411);}else return _0xf5cb55(_0x24d802,_0x3c826f)['catch'](async _0xa52c0a=>{if(_0xa52c0a['code']==='auth/missing-recaptcha-token'){console['log'](_0x1f3914+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1c3ebe=await br(_0x24d802,_0x3c826f,_0x1f3914,_0x1f3914==='getOobCode');return _0xf5cb55(_0x24d802,_0x1c3ebe);}else return Promise['reject'](_0xa52c0a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x902026,_0x2ed7b0){const _0x4a99f9=Ui(_0x902026,'auth');if(_0x4a99f9['isInitialized']()){const _0x54fe4a=_0x4a99f9['getImmediate'](),_0x3b6d6c=_0x4a99f9['getOptions']();if(De(_0x3b6d6c,_0x2ed7b0??{}))return _0x54fe4a;K(_0x54fe4a,'already-initialized');}return _0x4a99f9['initialize']({'options':_0x2ed7b0});}function Lf(_0x57b46b,_0x3a4436){const _0x357a73=(_0x3a4436==null?void 0x0:_0x3a4436['persistence'])||[],_0x3b74b0=(Array['isArray'](_0x357a73)?_0x357a73:[_0x357a73])['map'](ne);_0x3a4436!=null&&_0x3a4436['errorMap']&&_0x57b46b['_updateErrorMap'](_0x3a4436['errorMap']),_0x57b46b['_initializeWithPersistence'](_0x3b74b0,_0x3a4436==null?void 0x0:_0x3a4436['popupRedirectResolver']);}function xf(_0x2f679d,_0x98d2c0,_0x4cd3bc){const _0x11d286=qe(_0x2f679d);m(/^https?:\/\//['test'](_0x98d2c0),_0x11d286,'invalid-emulator-scheme');const _0x3c4863=!0x1,_0x21139c=La(_0x98d2c0),{host:_0x559436,port:_0x86fc17}=Ff(_0x98d2c0),_0x70395f=_0x86fc17===null?'':':'+_0x86fc17,_0x45b5c0={'url':_0x21139c+'//'+_0x559436+_0x70395f+'/'},_0x2ee0d2=Object['freeze']({'host':_0x559436,'port':_0x86fc17,'protocol':_0x21139c['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3c4863})});if(!_0x11d286['_canInitEmulator']){m(_0x11d286['config']['emulator']&&_0x11d286['emulatorConfig'],_0x11d286,'emulator-config-failed'),m(De(_0x45b5c0,_0x11d286['config']['emulator'])&&De(_0x2ee0d2,_0x11d286['emulatorConfig']),_0x11d286,'emulator-config-failed');return;}_0x11d286['config']['emulator']=_0x45b5c0,_0x11d286['emulatorConfig']=_0x2ee0d2,_0x11d286['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x559436)?jr(_0x21139c+'//'+_0x559436+_0x70395f):Uf();}function La(_0x2eba27){const _0x349ee9=_0x2eba27['indexOf'](':');return _0x349ee9<0x0?'':_0x2eba27['substr'](0x0,_0x349ee9+0x1);}function Ff(_0x37e2f5){const _0x2ae932=La(_0x37e2f5),_0x50c201=/(\/\/)?([^?#/]+)/['exec'](_0x37e2f5['substr'](_0x2ae932['length']));if(!_0x50c201)return{'host':'','port':null};const _0x5ec2ab=_0x50c201[0x2]['split']('@')['pop']()||'',_0x3065a1=/^(\[[^\]]+\])(:|$)/['exec'](_0x5ec2ab);if(_0x3065a1){const _0x4b5dcf=_0x3065a1[0x1];return{'host':_0x4b5dcf,'port':Rr(_0x5ec2ab['substr'](_0x4b5dcf['length']+0x1))};}else{const [_0x496742,_0xbe0a02]=_0x5ec2ab['split'](':');return{'host':_0x496742,'port':Rr(_0xbe0a02)};}}function Rr(_0x3007dc){if(!_0x3007dc)return null;const _0x1045c5=Number(_0x3007dc);return isNaN(_0x1045c5)?null:_0x1045c5;}function Uf(){function _0x37ddcf(){const _0x513d22=document['createElement']('p'),_0x15038c=_0x513d22['style'];_0x513d22['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x15038c['position']='fixed',_0x15038c['width']='100%',_0x15038c['backgroundColor']='#ffffff',_0x15038c['border']='.1em\x20solid\x20#000000',_0x15038c['color']='#b50000',_0x15038c['bottom']='0px',_0x15038c['left']='0px',_0x15038c['margin']='0px',_0x15038c['zIndex']='10000',_0x15038c['textAlign']='center',_0x513d22['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x513d22);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x37ddcf):_0x37ddcf());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1effe0,_0x1500a9){this['providerId']=_0x1effe0,this['signInMethod']=_0x1500a9;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x4391aa){return te('not\x20implemented');}['_linkToIdToken'](_0x3fa1e5,_0xaec72a){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1c9104){return te('not\x20implemented');}}async function Wf(_0x15de92,_0x54ea56){return Ae(_0x15de92,'POST','/v1/accounts:signUp',_0x54ea56);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0xaf1352,_0x41a845){return Yt(_0xaf1352,'POST','/v1/accounts:signInWithPassword',Re(_0xaf1352,_0x41a845));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x493b3c,_0x42078a){return Yt(_0x493b3c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x493b3c,_0x42078a));}async function Hf(_0x3c59de,_0x1a3776){return Yt(_0x3c59de,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3c59de,_0x1a3776));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x157965,_0x147027,_0x87a12f,_0x579f74=null){super('password',_0x87a12f),this['_email']=_0x157965,this['_password']=_0x147027,this['_tenantId']=_0x579f74;}static['_fromEmailAndPassword'](_0x5c12dd,_0x10b3f6){return new Ft(_0x5c12dd,_0x10b3f6,'password');}static['_fromEmailAndCode'](_0x403c09,_0x278a96,_0x293bb5=null){return new Ft(_0x403c09,_0x278a96,'emailLink',_0x293bb5);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x42d962){const _0x284f27=typeof _0x42d962=='string'?JSON['parse'](_0x42d962):_0x42d962;if(_0x284f27!=null&&_0x284f27['email']&&(_0x284f27!=null&&_0x284f27['password'])){if(_0x284f27['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x284f27['email'],_0x284f27['password']);if(_0x284f27['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x284f27['email'],_0x284f27['password'],_0x284f27['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3a1593){switch(this['signInMethod']){case'password':const _0x505a05={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3a1593,_0x505a05,'signInWithPassword',Bf);case'emailLink':return Vf(_0x3a1593,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x3a1593,'internal-error');}}async['_linkToIdToken'](_0x3fbaa1,_0x292017){switch(this['signInMethod']){case'password':const _0x576390={'idToken':_0x292017,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3fbaa1,_0x576390,'signUpPassword',Wf);case'emailLink':return Hf(_0x3fbaa1,{'idToken':_0x292017,'email':this['_email'],'oobCode':this['_password']});default:K(_0x3fbaa1,'internal-error');}}['_getReauthenticationResolver'](_0x37f7cd){return this['_getIdTokenResponse'](_0x37f7cd);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x41dac0,_0x3a9750){return Yt(_0x41dac0,'POST','/v1/accounts:signInWithIdp',Re(_0x41dac0,_0x3a9750));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x942804){const _0x292dca=new We(_0x942804['providerId'],_0x942804['signInMethod']);return _0x942804['idToken']||_0x942804['accessToken']?(_0x942804['idToken']&&(_0x292dca['idToken']=_0x942804['idToken']),_0x942804['accessToken']&&(_0x292dca['accessToken']=_0x942804['accessToken']),_0x942804['nonce']&&!_0x942804['pendingToken']&&(_0x292dca['nonce']=_0x942804['nonce']),_0x942804['pendingToken']&&(_0x292dca['pendingToken']=_0x942804['pendingToken'])):_0x942804['oauthToken']&&_0x942804['oauthTokenSecret']?(_0x292dca['accessToken']=_0x942804['oauthToken'],_0x292dca['secret']=_0x942804['oauthTokenSecret']):K('argument-error'),_0x292dca;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x54bdd6){const _0x249243=typeof _0x54bdd6=='string'?JSON['parse'](_0x54bdd6):_0x54bdd6,{providerId:_0x2cceef,signInMethod:_0x5b24a1,..._0x5895ce}=_0x249243;if(!_0x2cceef||!_0x5b24a1)return null;const _0x207f65=new We(_0x2cceef,_0x5b24a1);return _0x207f65['idToken']=_0x5895ce['idToken']||void 0x0,_0x207f65['accessToken']=_0x5895ce['accessToken']||void 0x0,_0x207f65['secret']=_0x5895ce['secret'],_0x207f65['nonce']=_0x5895ce['nonce'],_0x207f65['pendingToken']=_0x5895ce['pendingToken']||null,_0x207f65;}['_getIdTokenResponse'](_0x3f5600){const _0x148a99=this['buildRequest']();return Ze(_0x3f5600,_0x148a99);}['_linkToIdToken'](_0x30bcc7,_0x58c4cc){const _0x2d0ac7=this['buildRequest']();return _0x2d0ac7['idToken']=_0x58c4cc,Ze(_0x30bcc7,_0x2d0ac7);}['_getReauthenticationResolver'](_0x1e4114){const _0x469b21=this['buildRequest']();return _0x469b21['autoCreate']=!0x1,Ze(_0x1e4114,_0x469b21);}['buildRequest'](){const _0x238319={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x238319['pendingToken']=this['pendingToken'];else{const _0xad8d2={};this['idToken']&&(_0xad8d2['id_token']=this['idToken']),this['accessToken']&&(_0xad8d2['access_token']=this['accessToken']),this['secret']&&(_0xad8d2['oauth_token_secret']=this['secret']),_0xad8d2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xad8d2['nonce']=this['nonce']),_0x238319['postBody']=at(_0xad8d2);}return _0x238319;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x324706){switch(_0x324706){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x264c0a){const _0x1185c8=yt(vt(_0x264c0a))['link'],_0x4d3df0=_0x1185c8?yt(vt(_0x1185c8))['deep_link_id']:null,_0x1bee8d=yt(vt(_0x264c0a))['deep_link_id'];return(_0x1bee8d?yt(vt(_0x1bee8d))['link']:null)||_0x1bee8d||_0x4d3df0||_0x1185c8||_0x264c0a;}class Ss{constructor(_0x273f1e){const _0x3ca0e8=yt(vt(_0x273f1e)),_0x362588=_0x3ca0e8['apiKey']??null,_0x1be55d=_0x3ca0e8['oobCode']??null,_0x1cca54=Gf(_0x3ca0e8['mode']??null);m(_0x362588&&_0x1be55d&&_0x1cca54,'argument-error'),this['apiKey']=_0x362588,this['operation']=_0x1cca54,this['code']=_0x1be55d,this['continueUrl']=_0x3ca0e8['continueUrl']??null,this['languageCode']=_0x3ca0e8['lang']??null,this['tenantId']=_0x3ca0e8['tenantId']??null;}static['parseLink'](_0x5653c6){const _0x53076f=qf(_0x5653c6);try{return new Ss(_0x53076f);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x33dac4,_0x572c9a){return Ft['_fromEmailAndPassword'](_0x33dac4,_0x572c9a);}static['credentialWithLink'](_0x4405f3,_0x4cf5c1){const _0x1e60bd=Ss['parseLink'](_0x4cf5c1);return m(_0x1e60bd,'argument-error'),Ft['_fromEmailAndCode'](_0x4405f3,_0x1e60bd['code'],_0x1e60bd['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x34eb6f){this['providerId']=_0x34eb6f,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2ec054){this['defaultLanguageCode']=_0x2ec054;}['setCustomParameters'](_0x10a52b){return this['customParameters']=_0x10a52b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x238d21){return this['scopes']['includes'](_0x238d21)||this['scopes']['push'](_0x238d21),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xfc90c9){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xfc90c9});}static['credentialFromResult'](_0x19818b){return he['credentialFromTaggedObject'](_0x19818b);}static['credentialFromError'](_0xccf698){return he['credentialFromTaggedObject'](_0xccf698['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x109a70}){if(!_0x109a70||!('oauthAccessToken'in _0x109a70)||!_0x109a70['oauthAccessToken'])return null;try{return he['credential'](_0x109a70['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5153ed,_0x4bec13){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5153ed,'accessToken':_0x4bec13});}static['credentialFromResult'](_0x459b65){return ue['credentialFromTaggedObject'](_0x459b65);}static['credentialFromError'](_0x595fbd){return ue['credentialFromTaggedObject'](_0x595fbd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x19665f}){if(!_0x19665f)return null;const {oauthIdToken:_0x25b4c8,oauthAccessToken:_0x24786e}=_0x19665f;if(!_0x25b4c8&&!_0x24786e)return null;try{return ue['credential'](_0x25b4c8,_0x24786e);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x5aadf3){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5aadf3});}static['credentialFromResult'](_0x29ae5a){return de['credentialFromTaggedObject'](_0x29ae5a);}static['credentialFromError'](_0x2c9f8f){return de['credentialFromTaggedObject'](_0x2c9f8f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1bb46d}){if(!_0x1bb46d||!('oauthAccessToken'in _0x1bb46d)||!_0x1bb46d['oauthAccessToken'])return null;try{return de['credential'](_0x1bb46d['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x25952d,_0x255484){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x25952d,'oauthTokenSecret':_0x255484});}static['credentialFromResult'](_0x329f0f){return fe['credentialFromTaggedObject'](_0x329f0f);}static['credentialFromError'](_0x36648f){return fe['credentialFromTaggedObject'](_0x36648f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59be30}){if(!_0x59be30)return null;const {oauthAccessToken:_0x568b47,oauthTokenSecret:_0x2b7f3c}=_0x59be30;if(!_0x568b47||!_0x2b7f3c)return null;try{return fe['credential'](_0x568b47,_0x2b7f3c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x75785b,_0x842df8){return Yt(_0x75785b,'POST','/v1/accounts:signUp',Re(_0x75785b,_0x842df8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x11379e){this['user']=_0x11379e['user'],this['providerId']=_0x11379e['providerId'],this['_tokenResponse']=_0x11379e['_tokenResponse'],this['operationType']=_0x11379e['operationType'];}static async['_fromIdTokenResponse'](_0x4db2ef,_0x3f8d9e,_0x233d2b,_0x44164b=!0x1){const _0x32b9db=await z['_fromIdTokenResponse'](_0x4db2ef,_0x233d2b,_0x44164b),_0x530d14=Ar(_0x233d2b);return new Be({'user':_0x32b9db,'providerId':_0x530d14,'_tokenResponse':_0x233d2b,'operationType':_0x3f8d9e});}static async['_forOperation'](_0x56cdc4,_0x4ee539,_0x3ec380){await _0x56cdc4['_updateTokensIfNecessary'](_0x3ec380,!0x0);const _0x4510de=Ar(_0x3ec380);return new Be({'user':_0x56cdc4,'providerId':_0x4510de,'_tokenResponse':_0x3ec380,'operationType':_0x4ee539});}}function Ar(_0x40c173){return _0x40c173['providerId']?_0x40c173['providerId']:'phoneNumber'in _0x40c173?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x476abe,_0x36d36a,_0x45568e,_0x2f4c5a){super(_0x36d36a['code'],_0x36d36a['message']),this['operationType']=_0x45568e,this['user']=_0x2f4c5a,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x476abe['name'],'tenantId':_0x476abe['tenantId']??void 0x0,'_serverResponse':_0x36d36a['customData']['_serverResponse'],'operationType':_0x45568e};}static['_fromErrorAndOperation'](_0x53d620,_0x5774bb,_0x37b730,_0x193eb4){return new Rn(_0x53d620,_0x5774bb,_0x37b730,_0x193eb4);}}function Fa(_0x2d61c4,_0x15365f,_0x4b626e,_0x775d7f){return(_0x15365f==='reauthenticate'?_0x4b626e['_getReauthenticationResolver'](_0x2d61c4):_0x4b626e['_getIdTokenResponse'](_0x2d61c4))['catch'](_0x40c8eb=>{throw _0x40c8eb['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x2d61c4,_0x40c8eb,_0x15365f,_0x775d7f):_0x40c8eb;});}async function jf(_0x4975ec,_0xf6e005,_0x5cec53=!0x1){const _0x3ae275=await xt(_0x4975ec,_0xf6e005['_linkToIdToken'](_0x4975ec['auth'],await _0x4975ec['getIdToken']()),_0x5cec53);return Be['_forOperation'](_0x4975ec,'link',_0x3ae275);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x15a992,_0x359d34,_0x43e8ed=!0x1){const {auth:_0x21dd3e}=_0x15a992;if(H(_0x21dd3e['app']))return Promise['reject'](se(_0x21dd3e));const _0x3d3bb9='reauthenticate';try{const _0x497994=await xt(_0x15a992,Fa(_0x21dd3e,_0x3d3bb9,_0x359d34,_0x15a992),_0x43e8ed);m(_0x497994['idToken'],_0x21dd3e,'internal-error');const _0x3f018c=ws(_0x497994['idToken']);m(_0x3f018c,_0x21dd3e,'internal-error');const {sub:_0x5af766}=_0x3f018c;return m(_0x15a992['uid']===_0x5af766,_0x21dd3e,'user-mismatch'),Be['_forOperation'](_0x15a992,_0x3d3bb9,_0x497994);}catch(_0xb6a95){throw(_0xb6a95==null?void 0x0:_0xb6a95['code'])==='auth/user-not-found'&&K(_0x21dd3e,'user-mismatch'),_0xb6a95;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x56ce32,_0x43eb4a,_0x30ec96=!0x1){if(H(_0x56ce32['app']))return Promise['reject'](se(_0x56ce32));const _0x4a4d6c='signIn',_0x51dd02=await Fa(_0x56ce32,_0x4a4d6c,_0x43eb4a),_0x4fc747=await Be['_fromIdTokenResponse'](_0x56ce32,_0x4a4d6c,_0x51dd02);return _0x30ec96||await _0x56ce32['_updateCurrentUser'](_0x4fc747['user']),_0x4fc747;}async function Yf(_0x356b25,_0x5d5a47){return Ua(qe(_0x356b25),_0x5d5a47);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2f3339){const _0x28d5a9=qe(_0x2f3339);_0x28d5a9['_getPasswordPolicyInternal']()&&await _0x28d5a9['_updatePasswordPolicy']();}async function R_(_0xd1ae4c,_0x2f5aac,_0x759cfd){if(H(_0xd1ae4c['app']))return Promise['reject'](se(_0xd1ae4c));const _0x3c73f0=qe(_0xd1ae4c),_0x2b64d4=await Oi(_0x3c73f0,{'returnSecureToken':!0x0,'email':_0x2f5aac,'password':_0x759cfd,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3dd372=>{throw _0x3dd372['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xd1ae4c),_0x3dd372;}),_0x101a85=await Be['_fromIdTokenResponse'](_0x3c73f0,'signIn',_0x2b64d4);return await _0x3c73f0['_updateCurrentUser'](_0x101a85['user']),_0x101a85;}function A_(_0x3def07,_0x7794e7,_0x353888){return H(_0x3def07['app'])?Promise['reject'](se(_0x3def07)):Yf(k(_0x3def07),ft['credential'](_0x7794e7,_0x353888))['catch'](async _0x1fed68=>{throw _0x1fed68['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3def07),_0x1fed68;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x533df7,_0x73a1b4){return k(_0x533df7)['setPersistence'](_0x73a1b4);}function Qf(_0x5a8497,_0x5bfb3d,_0x445c50,_0x439f4a){return k(_0x5a8497)['onIdTokenChanged'](_0x5bfb3d,_0x445c50,_0x439f4a);}function Jf(_0x2965a2,_0x2c7c79,_0x5ce707){return k(_0x2965a2)['beforeAuthStateChanged'](_0x2c7c79,_0x5ce707);}function N_(_0x4f5bb6,_0x44532c,_0x37d6b4,_0x49d2e1){return k(_0x4f5bb6)['onAuthStateChanged'](_0x44532c,_0x37d6b4,_0x49d2e1);}function P_(_0x2e688d){return k(_0x2e688d)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x4cfea4,_0x2356b4){this['storageRetriever']=_0x4cfea4,this['type']=_0x2356b4;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5026eb,_0x40e3ab){return this['storage']['setItem'](_0x5026eb,JSON['stringify'](_0x40e3ab)),Promise['resolve']();}['_get'](_0x1b8842){const _0xa5ce9a=this['storage']['getItem'](_0x1b8842);return Promise['resolve'](_0xa5ce9a?JSON['parse'](_0xa5ce9a):null);}['_remove'](_0x4fc330){return this['storage']['removeItem'](_0x4fc330),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2a8b43,_0x365aef)=>this['onStorageEvent'](_0x2a8b43,_0x365aef),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x59e17d){for(const _0x5788a5 of Object['keys'](this['listeners'])){const _0x2464b1=this['storage']['getItem'](_0x5788a5),_0x497521=this['localCache'][_0x5788a5];_0x2464b1!==_0x497521&&_0x59e17d(_0x5788a5,_0x497521,_0x2464b1);}}['onStorageEvent'](_0x5def22,_0xd1a891=!0x1){if(!_0x5def22['key']){this['forAllChangedKeys']((_0x4e7d8f,_0x2750ad,_0x2c5d4d)=>{this['notifyListeners'](_0x4e7d8f,_0x2c5d4d);});return;}const _0x330b37=_0x5def22['key'];_0xd1a891?this['detachListener']():this['stopPolling']();const _0x371e3f=()=>{const _0x4daeed=this['storage']['getItem'](_0x330b37);!_0xd1a891&&this['localCache'][_0x330b37]===_0x4daeed||this['notifyListeners'](_0x330b37,_0x4daeed);},_0x6b2edf=this['storage']['getItem'](_0x330b37);If()&&_0x6b2edf!==_0x5def22['newValue']&&_0x5def22['newValue']!==_0x5def22['oldValue']?setTimeout(_0x371e3f,Zf):_0x371e3f();}['notifyListeners'](_0x35d14e,_0x61878){this['localCache'][_0x35d14e]=_0x61878;const _0x21aebb=this['listeners'][_0x35d14e];if(_0x21aebb){for(const _0x1dbc30 of Array['from'](_0x21aebb))_0x1dbc30(_0x61878&&JSON['parse'](_0x61878));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3ca961,_0x1d601e,_0x3cb413)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3ca961,'oldValue':_0x1d601e,'newValue':_0x3cb413}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x210a00,_0x519d5f){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x210a00]||(this['listeners'][_0x210a00]=new Set(),this['localCache'][_0x210a00]=this['storage']['getItem'](_0x210a00)),this['listeners'][_0x210a00]['add'](_0x519d5f);}['_removeListener'](_0x42851d,_0x1d6547){this['listeners'][_0x42851d]&&(this['listeners'][_0x42851d]['delete'](_0x1d6547),this['listeners'][_0x42851d]['size']===0x0&&delete this['listeners'][_0x42851d]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1a3af0,_0x5bab58){await super['_set'](_0x1a3af0,_0x5bab58),this['localCache'][_0x1a3af0]=JSON['stringify'](_0x5bab58);}async['_get'](_0x59bda9){const _0x47ca59=await super['_get'](_0x59bda9);return this['localCache'][_0x59bda9]=JSON['stringify'](_0x47ca59),_0x47ca59;}async['_remove'](_0x24fca7){await super['_remove'](_0x24fca7),delete this['localCache'][_0x24fca7];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xb22aa,_0x59f5c4){}['_removeListener'](_0xd4b5fb,_0x40cde4){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x296a05){return Promise['all'](_0x296a05['map'](async _0x14bbc6=>{try{return{'fulfilled':!0x0,'value':await _0x14bbc6};}catch(_0x5d5bbb){return{'fulfilled':!0x1,'reason':_0x5d5bbb};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x3e9d3b){this['eventTarget']=_0x3e9d3b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5db29c){const _0x32bb5a=this['receivers']['find'](_0x5a1956=>_0x5a1956['isListeningto'](_0x5db29c));if(_0x32bb5a)return _0x32bb5a;const _0x17e5a5=new jn(_0x5db29c);return this['receivers']['push'](_0x17e5a5),_0x17e5a5;}['isListeningto'](_0x3b48f9){return this['eventTarget']===_0x3b48f9;}async['handleEvent'](_0x55ee88){const _0x53dc0c=_0x55ee88,{eventId:_0x3116da,eventType:_0xe5af1e,data:_0x5a88ad}=_0x53dc0c['data'],_0xca38c=this['handlersMap'][_0xe5af1e];if(!(_0xca38c!=null&&_0xca38c['size']))return;_0x53dc0c['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3116da,'eventType':_0xe5af1e});const _0x3253f3=Array['from'](_0xca38c)['map'](async _0x339426=>_0x339426(_0x53dc0c['origin'],_0x5a88ad)),_0x3627c7=await tp(_0x3253f3);_0x53dc0c['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3116da,'eventType':_0xe5af1e,'response':_0x3627c7});}['_subscribe'](_0x1616d9,_0x4877c5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1616d9]||(this['handlersMap'][_0x1616d9]=new Set()),this['handlersMap'][_0x1616d9]['add'](_0x4877c5);}['_unsubscribe'](_0x3b3704,_0x2aa9c0){this['handlersMap'][_0x3b3704]&&_0x2aa9c0&&this['handlersMap'][_0x3b3704]['delete'](_0x2aa9c0),(!_0x2aa9c0||this['handlersMap'][_0x3b3704]['size']===0x0)&&delete this['handlersMap'][_0x3b3704],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0xf29237='',_0x49cb12=0xa){let _0x281c3a='';for(let _0x754d39=0x0;_0x754d39<_0x49cb12;_0x754d39++)_0x281c3a+=Math['floor'](Math['random']()*0xa);return _0xf29237+_0x281c3a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x473508){this['target']=_0x473508,this['handlers']=new Set();}['removeMessageHandler'](_0x38e389){_0x38e389['messageChannel']&&(_0x38e389['messageChannel']['port1']['removeEventListener']('message',_0x38e389['onMessage']),_0x38e389['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x38e389);}async['_send'](_0x565042,_0x7760,_0x36d3a6=0x32){const _0x56a278=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x56a278)throw new Error('connection_unavailable');let _0x45a38c,_0xc55f64;return new Promise((_0x138a41,_0x1dfc87)=>{const _0x17cd17=bs('',0x14);_0x56a278['port1']['start']();const _0x17bb9a=setTimeout(()=>{_0x1dfc87(new Error('unsupported_event'));},_0x36d3a6);_0xc55f64={'messageChannel':_0x56a278,'onMessage'(_0x4b23b5){const _0x35f5cf=_0x4b23b5;if(_0x35f5cf['data']['eventId']===_0x17cd17)switch(_0x35f5cf['data']['status']){case'ack':clearTimeout(_0x17bb9a),_0x45a38c=setTimeout(()=>{_0x1dfc87(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x45a38c),_0x138a41(_0x35f5cf['data']['response']);break;default:clearTimeout(_0x17bb9a),clearTimeout(_0x45a38c),_0x1dfc87(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xc55f64),_0x56a278['port1']['addEventListener']('message',_0xc55f64['onMessage']),this['target']['postMessage']({'eventType':_0x565042,'eventId':_0x17cd17,'data':_0x7760},[_0x56a278['port2']]);})['finally'](()=>{_0xc55f64&&this['removeMessageHandler'](_0xc55f64);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x2aa53e){X()['location']['href']=_0x2aa53e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x10c2fc;return((_0x10c2fc=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x10c2fc['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5ae945){this['request']=_0x5ae945;}['toPromise'](){return new Promise((_0x4d2340,_0x26453a)=>{this['request']['addEventListener']('success',()=>{_0x4d2340(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x26453a(this['request']['error']);});});}}function Kn(_0xafc6f6,_0x162547){return _0xafc6f6['transaction']([kn],_0x162547?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x5bee12=indexedDB['deleteDatabase'](qa);return new Jt(_0x5bee12)['toPromise']();}function ja(){const _0x3ef1d9=indexedDB['open'](qa,ap);return new Promise((_0x3bbb9f,_0xeb4a67)=>{_0x3ef1d9['addEventListener']('error',()=>{_0xeb4a67(_0x3ef1d9['error']);}),_0x3ef1d9['addEventListener']('upgradeneeded',()=>{const _0x42b84d=_0x3ef1d9['result'];try{_0x42b84d['createObjectStore'](kn,{'keyPath':za});}catch(_0x2948b5){_0xeb4a67(_0x2948b5);}}),_0x3ef1d9['addEventListener']('success',async()=>{const _0x2ec4a3=_0x3ef1d9['result'];_0x2ec4a3['objectStoreNames']['contains'](kn)?_0x3bbb9f(_0x2ec4a3):(_0x2ec4a3['close'](),await cp(),_0x3bbb9f(await ja()));});});}async function kr(_0x251267,_0x5075f6,_0x1540cc){const _0x4994fb=Kn(_0x251267,!0x0)['put']({[za]:_0x5075f6,'value':_0x1540cc});return new Jt(_0x4994fb)['toPromise']();}async function lp(_0x4f4dab,_0x21542f){const _0x3ae167=Kn(_0x4f4dab,!0x1)['get'](_0x21542f),_0x19150d=await new Jt(_0x3ae167)['toPromise']();return _0x19150d===void 0x0?null:_0x19150d['value'];}function Nr(_0x52e6fe,_0x48171d){const _0x5d59f6=Kn(_0x52e6fe,!0x0)['delete'](_0x48171d);return new Jt(_0x5d59f6)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x58b5f8){let _0x76c0ee=0x0;for(;;)try{const _0x3c9318=await this['_openDb']();return await _0x58b5f8(_0x3c9318);}catch(_0x5ef3db){if(_0x76c0ee++>up)throw _0x5ef3db;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x249e93,_0x2be371)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2be371['key'])})),this['receiver']['_subscribe']('ping',async(_0x5768fa,_0x43874e)=>['keyChanged']);}async['initializeSender'](){var _0x4a7305,_0x597f72;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1763d9=await this['sender']['_send']('ping',{},0x320);_0x1763d9&&(_0x4a7305=_0x1763d9[0x0])!=null&&_0x4a7305['fulfilled']&&(_0x597f72=_0x1763d9[0x0])!=null&&_0x597f72['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x57e6eb){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x57e6eb},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3dd26c=>{await kr(_0x3dd26c,An,'1'),await Nr(_0x3dd26c,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x478465){this['pendingWrites']++;try{await _0x478465();}finally{this['pendingWrites']--;}}async['_set'](_0x5975bd,_0x505d75){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5202e5=>kr(_0x5202e5,_0x5975bd,_0x505d75)),this['localCache'][_0x5975bd]=_0x505d75,this['notifyServiceWorker'](_0x5975bd)));}async['_get'](_0x5bf304){const _0x2fe588=await this['_withRetries'](_0x3c0c3f=>lp(_0x3c0c3f,_0x5bf304));return this['localCache'][_0x5bf304]=_0x2fe588,_0x2fe588;}async['_remove'](_0x24957e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3a2a96=>Nr(_0x3a2a96,_0x24957e)),delete this['localCache'][_0x24957e],this['notifyServiceWorker'](_0x24957e)));}async['_poll'](){const _0x1afa0f=await this['_withRetries'](_0x16a82e=>{const _0x22196a=Kn(_0x16a82e,!0x1)['getAll']();return new Jt(_0x22196a)['toPromise']();});if(!_0x1afa0f)return[];if(this['pendingWrites']!==0x0)return[];const _0x4cb779=[],_0x21bec8=new Set();if(_0x1afa0f['length']!==0x0){for(const {fbase_key:_0x25cf95,value:_0x58ac01}of _0x1afa0f)_0x21bec8['add'](_0x25cf95),JSON['stringify'](this['localCache'][_0x25cf95])!==JSON['stringify'](_0x58ac01)&&(this['notifyListeners'](_0x25cf95,_0x58ac01),_0x4cb779['push'](_0x25cf95));}for(const _0x5b2737 of Object['keys'](this['localCache']))this['localCache'][_0x5b2737]&&!_0x21bec8['has'](_0x5b2737)&&(this['notifyListeners'](_0x5b2737,null),_0x4cb779['push'](_0x5b2737));return _0x4cb779;}['notifyListeners'](_0xcbdd6d,_0xe8bc7b){this['localCache'][_0xcbdd6d]=_0xe8bc7b;const _0x352d23=this['listeners'][_0xcbdd6d];if(_0x352d23){for(const _0x3afdff of Array['from'](_0x352d23))_0x3afdff(_0xe8bc7b);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x277ee3,_0x44c4d3){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x277ee3]||(this['listeners'][_0x277ee3]=new Set(),this['_get'](_0x277ee3)),this['listeners'][_0x277ee3]['add'](_0x44c4d3);}['_removeListener'](_0x5e5b47,_0xfa3cab){this['listeners'][_0x5e5b47]&&(this['listeners'][_0x5e5b47]['delete'](_0xfa3cab),this['listeners'][_0x5e5b47]['size']===0x0&&delete this['listeners'][_0x5e5b47]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x255d28,_0x342bf6){return _0x342bf6?ne(_0x342bf6):(m(_0x255d28['_popupRedirectResolver'],_0x255d28,'argument-error'),_0x255d28['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x258f51){super('custom','custom'),this['params']=_0x258f51;}['_getIdTokenResponse'](_0x5defd9){return Ze(_0x5defd9,this['_buildIdpRequest']());}['_linkToIdToken'](_0x31b01e,_0x31476a){return Ze(_0x31b01e,this['_buildIdpRequest'](_0x31476a));}['_getReauthenticationResolver'](_0x5156f4){return Ze(_0x5156f4,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x11ffa4){const _0x37f281={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x11ffa4&&(_0x37f281['idToken']=_0x11ffa4),_0x37f281;}}function pp(_0x1cdc89){return Ua(_0x1cdc89['auth'],new Rs(_0x1cdc89),_0x1cdc89['bypassAuthState']);}function _p(_0x26bb47){const {auth:_0x5b51fd,user:_0x2d532f}=_0x26bb47;return m(_0x2d532f,_0x5b51fd,'internal-error'),Kf(_0x2d532f,new Rs(_0x26bb47),_0x26bb47['bypassAuthState']);}async function gp(_0x3a132d){const {auth:_0x1eddee,user:_0x1b615f}=_0x3a132d;return m(_0x1b615f,_0x1eddee,'internal-error'),jf(_0x1b615f,new Rs(_0x3a132d),_0x3a132d['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x511aac,_0x40459a,_0x28938b,_0x2c782c,_0x162a96=!0x1){this['auth']=_0x511aac,this['resolver']=_0x28938b,this['user']=_0x2c782c,this['bypassAuthState']=_0x162a96,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x40459a)?_0x40459a:[_0x40459a];}['execute'](){return new Promise(async(_0x52fce7,_0x1bd388)=>{this['pendingPromise']={'resolve':_0x52fce7,'reject':_0x1bd388};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1d12c8){this['reject'](_0x1d12c8);}});}async['onAuthEvent'](_0x555e12){const {urlResponse:_0x2a2a8b,sessionId:_0x3342ac,postBody:_0x27a79c,tenantId:_0x3f531b,error:_0x2cf186,type:_0x11da5f}=_0x555e12;if(_0x2cf186){this['reject'](_0x2cf186);return;}const _0x387b29={'auth':this['auth'],'requestUri':_0x2a2a8b,'sessionId':_0x3342ac,'tenantId':_0x3f531b||void 0x0,'postBody':_0x27a79c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x11da5f)(_0x387b29));}catch(_0x32a6dd){this['reject'](_0x32a6dd);}}['onError'](_0x24e92d){this['reject'](_0x24e92d);}['getIdpTask'](_0x37ab99){switch(_0x37ab99){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x3a3bbd){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3a3bbd),this['unregisterAndCleanUp']();}['reject'](_0x59d5b1){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x59d5b1),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x521b5a,_0x2abeb8,_0x142fca,_0xa513f1,_0x5b4dec){super(_0x521b5a,_0x2abeb8,_0xa513f1,_0x5b4dec),this['provider']=_0x142fca,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x18c669=await this['execute']();return m(_0x18c669,this['auth'],'internal-error'),_0x18c669;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x301ee6=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x301ee6),this['authWindow']['associatedEvent']=_0x301ee6,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1a9a4d=>{this['reject'](_0x1a9a4d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x18217b=>{_0x18217b||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x53b9fc;return((_0x53b9fc=this['authWindow'])==null?void 0x0:_0x53b9fc['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xb8ba8e=()=>{var _0x457f0f,_0x504440;if((_0x504440=(_0x457f0f=this['authWindow'])==null?void 0x0:_0x457f0f['window'])!=null&&_0x504440['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xb8ba8e,mp['get']());};_0xb8ba8e();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x4f1e41,_0x544549,_0x3f55c6=!0x1){super(_0x4f1e41,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x544549,void 0x0,_0x3f55c6),this['eventId']=null;}async['execute'](){let _0x2efe36=rn['get'](this['auth']['_key']());if(!_0x2efe36){try{const _0x495134=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x2efe36=()=>Promise['resolve'](_0x495134);}catch(_0x2f9d7c){_0x2efe36=()=>Promise['reject'](_0x2f9d7c);}rn['set'](this['auth']['_key'](),_0x2efe36);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2efe36();}async['onAuthEvent'](_0x3f4f52){if(_0x3f4f52['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3f4f52);if(_0x3f4f52['type']==='unknown'){this['resolve'](null);return;}if(_0x3f4f52['eventId']){const _0x1da401=await this['auth']['_redirectUserForId'](_0x3f4f52['eventId']);if(_0x1da401)return this['user']=_0x1da401,super['onAuthEvent'](_0x3f4f52);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x2d5c34,_0x2430b5){const _0xb87fd7=Cp(_0x2430b5),_0x2cd1d5=wp(_0x2d5c34);if(!await _0x2cd1d5['_isAvailable']())return!0x1;const _0x50a1ea=await _0x2cd1d5['_get'](_0xb87fd7)==='true';return await _0x2cd1d5['_remove'](_0xb87fd7),_0x50a1ea;}function Ip(_0x54ef27,_0x4fa627){rn['set'](_0x54ef27['_key'](),_0x4fa627);}function wp(_0x2058cc){return ne(_0x2058cc['_redirectPersistence']);}function Cp(_0x34ef69){return sn(yp,_0x34ef69['config']['apiKey'],_0x34ef69['name']);}async function Tp(_0x2c8b03,_0x332df3,_0x51e66c=!0x1){if(H(_0x2c8b03['app']))return Promise['reject'](se(_0x2c8b03));const _0x9430a6=qe(_0x2c8b03),_0x1b10bd=fp(_0x9430a6,_0x332df3),_0x473342=await new vp(_0x9430a6,_0x1b10bd,_0x51e66c)['execute']();return _0x473342&&!_0x51e66c&&(delete _0x473342['user']['_redirectEventId'],await _0x9430a6['_persistUserIfCurrent'](_0x473342['user']),await _0x9430a6['_setRedirectUser'](null,_0x332df3)),_0x473342;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x452344){this['auth']=_0x452344,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4ff4be){this['consumers']['add'](_0x4ff4be),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4ff4be)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4ff4be),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4b9a41){this['consumers']['delete'](_0x4b9a41);}['onEvent'](_0x1ae3fb){if(this['hasEventBeenHandled'](_0x1ae3fb))return!0x1;let _0x5825b5=!0x1;return this['consumers']['forEach'](_0x30cbbc=>{this['isEventForConsumer'](_0x1ae3fb,_0x30cbbc)&&(_0x5825b5=!0x0,this['sendToConsumer'](_0x1ae3fb,_0x30cbbc),this['saveEventToCache'](_0x1ae3fb));}),this['hasHandledPotentialRedirect']||!Rp(_0x1ae3fb)||(this['hasHandledPotentialRedirect']=!0x0,_0x5825b5||(this['queuedRedirectEvent']=_0x1ae3fb,_0x5825b5=!0x0)),_0x5825b5;}['sendToConsumer'](_0x13530f,_0xf0f5c6){var _0x272489;if(_0x13530f['error']&&!Qa(_0x13530f)){const _0x2b57ed=((_0x272489=_0x13530f['error']['code'])==null?void 0x0:_0x272489['split']('auth/')[0x1])||'internal-error';_0xf0f5c6['onError'](J(this['auth'],_0x2b57ed));}else _0xf0f5c6['onAuthEvent'](_0x13530f);}['isEventForConsumer'](_0x3f5321,_0xe5c1f3){const _0x4ddcca=_0xe5c1f3['eventId']===null||!!_0x3f5321['eventId']&&_0x3f5321['eventId']===_0xe5c1f3['eventId'];return _0xe5c1f3['filter']['includes'](_0x3f5321['type'])&&_0x4ddcca;}['hasEventBeenHandled'](_0x2756eb){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2756eb));}['saveEventToCache'](_0x19d2b3){this['cachedEventUids']['add'](Pr(_0x19d2b3)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x536c21){return[_0x536c21['type'],_0x536c21['eventId'],_0x536c21['sessionId'],_0x536c21['tenantId']]['filter'](_0x45f213=>_0x45f213)['join']('-');}function Qa({type:_0x4bb9ff,error:_0x9ee9bc}){return _0x4bb9ff==='unknown'&&(_0x9ee9bc==null?void 0x0:_0x9ee9bc['code'])==='auth/no-auth-event';}function Rp(_0x3da24a){switch(_0x3da24a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3da24a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4679c1,_0x544b39={}){return Ae(_0x4679c1,'GET','/v1/projects',_0x544b39);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5448f0){if(_0x5448f0['config']['emulator'])return;const {authorizedDomains:_0x3959bf}=await Ap(_0x5448f0);for(const _0x556ca6 of _0x3959bf)try{if(Op(_0x556ca6))return;}catch{}K(_0x5448f0,'unauthorized-domain');}function Op(_0x5c45e6){const _0x5769cf=Ni(),{protocol:_0x4cc234,hostname:_0x1f02c8}=new URL(_0x5769cf);if(_0x5c45e6['startsWith']('chrome-extension://')){const _0x49e71b=new URL(_0x5c45e6);return _0x49e71b['hostname']===''&&_0x1f02c8===''?_0x4cc234==='chrome-extension:'&&_0x5c45e6['replace']('chrome-extension://','')===_0x5769cf['replace']('chrome-extension://',''):_0x4cc234==='chrome-extension:'&&_0x49e71b['hostname']===_0x1f02c8;}if(!Np['test'](_0x4cc234))return!0x1;if(kp['test'](_0x5c45e6))return _0x1f02c8===_0x5c45e6;const _0x37f517=_0x5c45e6['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x37f517+'|'+_0x37f517+')$','i')['test'](_0x1f02c8);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x23caf5=X()['___jsl'];if(_0x23caf5!=null&&_0x23caf5['H']){for(const _0x151d55 of Object['keys'](_0x23caf5['H']))if(_0x23caf5['H'][_0x151d55]['r']=_0x23caf5['H'][_0x151d55]['r']||[],_0x23caf5['H'][_0x151d55]['L']=_0x23caf5['H'][_0x151d55]['L']||[],_0x23caf5['H'][_0x151d55]['r']=[..._0x23caf5['H'][_0x151d55]['L']],_0x23caf5['CP']){for(let _0x51025b=0x0;_0x51025b<_0x23caf5['CP']['length'];_0x51025b++)_0x23caf5['CP'][_0x51025b]=null;}}}function Mp(_0x513393){return new Promise((_0x48ba27,_0x5d5411)=>{var _0x532691,_0x2bd67f,_0x228167;function _0x22c62d(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x48ba27(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x5d5411(J(_0x513393,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x2bd67f=(_0x532691=X()['gapi'])==null?void 0x0:_0x532691['iframes'])!=null&&_0x2bd67f['Iframe'])_0x48ba27(gapi['iframes']['getContext']());else{if((_0x228167=X()['gapi'])!=null&&_0x228167['load'])_0x22c62d();else{const _0x23126b=Nf('iframefcb');return X()[_0x23126b]=()=>{gapi['load']?_0x22c62d():_0x5d5411(J(_0x513393,'network-request-failed'));},Da(kf()+'?onload='+_0x23126b)['catch'](_0x14090f=>_0x5d5411(_0x14090f));}}})['catch'](_0x313f10=>{throw on=null,_0x313f10;});}let on=null;function Lp(_0x4d9973){return on=on||Mp(_0x4d9973),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x3f65e1){const _0x475b11=_0x3f65e1['config'];m(_0x475b11['authDomain'],_0x3f65e1,'auth-domain-config-required');const _0x24c8f2=_0x475b11['emulator']?Is(_0x475b11,Up):'https://'+_0x3f65e1['config']['authDomain']+'/'+Fp,_0x10e66b={'apiKey':_0x475b11['apiKey'],'appName':_0x3f65e1['name'],'v':ct},_0x2647de=Bp['get'](_0x3f65e1['config']['apiHost']);_0x2647de&&(_0x10e66b['eid']=_0x2647de);const _0x536de8=_0x3f65e1['_getFrameworks']();return _0x536de8['length']&&(_0x10e66b['fw']=_0x536de8['join'](',')),_0x24c8f2+'?'+at(_0x10e66b)['slice'](0x1);}async function Hp(_0x2045ee){const _0x4ebc6f=await Lp(_0x2045ee),_0xc1d2be=X()['gapi'];return m(_0xc1d2be,_0x2045ee,'internal-error'),_0x4ebc6f['open']({'where':document['body'],'url':Vp(_0x2045ee),'messageHandlersFilter':_0xc1d2be['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x7aeb43=>new Promise(async(_0x194fea,_0x1a713d)=>{await _0x7aeb43['restyle']({'setHideOnLeave':!0x1});const _0x5f4486=J(_0x2045ee,'network-request-failed'),_0x43ebbe=X()['setTimeout'](()=>{_0x1a713d(_0x5f4486);},xp['get']());function _0x3823e5(){X()['clearTimeout'](_0x43ebbe),_0x194fea(_0x7aeb43);}_0x7aeb43['ping'](_0x3823e5)['then'](_0x3823e5,()=>{_0x1a713d(_0x5f4486);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3133d6){this['window']=_0x3133d6,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x11d1ba,_0x1d1e5c,_0x257ac7,_0x4914eb=Gp,_0x1231f7=qp){const _0x26518f=Math['max']((window['screen']['availHeight']-_0x1231f7)/0x2,0x0)['toString'](),_0x2f3aba=Math['max']((window['screen']['availWidth']-_0x4914eb)/0x2,0x0)['toString']();let _0x331255='';const _0x5cecb3={...$p,'width':_0x4914eb['toString'](),'height':_0x1231f7['toString'](),'top':_0x26518f,'left':_0x2f3aba},_0x2d346d=W()['toLowerCase']();_0x257ac7&&(_0x331255=ba(_0x2d346d)?zp:_0x257ac7),Ta(_0x2d346d)&&(_0x1d1e5c=_0x1d1e5c||jp,_0x5cecb3['scrollbars']='yes');const _0xa25a2a=Object['entries'](_0x5cecb3)['reduce']((_0x2cbc46,[_0x3e307e,_0x462f18])=>''+_0x2cbc46+_0x3e307e+'='+_0x462f18+',','');if(Ef(_0x2d346d)&&_0x331255!=='_self')return Yp(_0x1d1e5c||'',_0x331255),new Dr(null);const _0x47f0a6=window['open'](_0x1d1e5c||'',_0x331255,_0xa25a2a);m(_0x47f0a6,_0x11d1ba,'popup-blocked');try{_0x47f0a6['focus']();}catch{}return new Dr(_0x47f0a6);}function Yp(_0x713895,_0xb6fbef){const _0x2fd43e=document['createElement']('a');_0x2fd43e['href']=_0x713895,_0x2fd43e['target']=_0xb6fbef;const _0x5f3361=document['createEvent']('MouseEvent');_0x5f3361['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2fd43e['dispatchEvent'](_0x5f3361);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2644ea,_0x1c0d34,_0x53ad4e,_0x25e05e,_0x3ac7ff,_0xc8539f){m(_0x2644ea['config']['authDomain'],_0x2644ea,'auth-domain-config-required'),m(_0x2644ea['config']['apiKey'],_0x2644ea,'invalid-api-key');const _0x235b40={'apiKey':_0x2644ea['config']['apiKey'],'appName':_0x2644ea['name'],'authType':_0x53ad4e,'redirectUrl':_0x25e05e,'v':ct,'eventId':_0x3ac7ff};if(_0x1c0d34 instanceof xa){_0x1c0d34['setDefaultLanguage'](_0x2644ea['languageCode']),_0x235b40['providerId']=_0x1c0d34['providerId']||'',hi(_0x1c0d34['getCustomParameters']())||(_0x235b40['customParameters']=JSON['stringify'](_0x1c0d34['getCustomParameters']()));for(const [_0x37ccdc,_0xc2bf8e]of Object['entries']({}))_0x235b40[_0x37ccdc]=_0xc2bf8e;}if(_0x1c0d34 instanceof Qt){const _0x3cd14e=_0x1c0d34['getScopes']()['filter'](_0x42924d=>_0x42924d!=='');_0x3cd14e['length']>0x0&&(_0x235b40['scopes']=_0x3cd14e['join'](','));}_0x2644ea['tenantId']&&(_0x235b40['tid']=_0x2644ea['tenantId']);const _0x228cd6=_0x235b40;for(const _0x441b85 of Object['keys'](_0x228cd6))_0x228cd6[_0x441b85]===void 0x0&&delete _0x228cd6[_0x441b85];const _0x486b23=await _0x2644ea['_getAppCheckToken'](),_0xa70229=_0x486b23?'#'+Xp+'='+encodeURIComponent(_0x486b23):'';return Zp(_0x2644ea)+'?'+at(_0x228cd6)['slice'](0x1)+_0xa70229;}function Zp({config:_0xcbeb7}){return _0xcbeb7['emulator']?Is(_0xcbeb7,Jp):'https://'+_0xcbeb7['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x263f7f,_0x591a8b,_0x1b2c8b,_0x269369){var _0x2a9d84;ae((_0x2a9d84=this['eventManagers'][_0x263f7f['_key']()])==null?void 0x0:_0x2a9d84['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1a0520=await Mr(_0x263f7f,_0x591a8b,_0x1b2c8b,Ni(),_0x269369);return Kp(_0x263f7f,_0x1a0520,bs());}async['_openRedirect'](_0x10be6b,_0x1d730a,_0x5c26a4,_0x5da704){await this['_originValidation'](_0x10be6b);const _0x245ac9=await Mr(_0x10be6b,_0x1d730a,_0x5c26a4,Ni(),_0x5da704);return ip(_0x245ac9),new Promise(()=>{});}['_initialize'](_0x1b7d57){const _0x151932=_0x1b7d57['_key']();if(this['eventManagers'][_0x151932]){const {manager:_0x5f4ee3,promise:_0x582478}=this['eventManagers'][_0x151932];return _0x5f4ee3?Promise['resolve'](_0x5f4ee3):(ae(_0x582478,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x582478);}const _0x27177f=this['initAndGetManager'](_0x1b7d57);return this['eventManagers'][_0x151932]={'promise':_0x27177f},_0x27177f['catch'](()=>{delete this['eventManagers'][_0x151932];}),_0x27177f;}async['initAndGetManager'](_0x330d0b){const _0x1c10d1=await Hp(_0x330d0b),_0x2f59c3=new bp(_0x330d0b);return _0x1c10d1['register']('authEvent',_0x2bd8af=>(m(_0x2bd8af==null?void 0x0:_0x2bd8af['authEvent'],_0x330d0b,'invalid-auth-event'),{'status':_0x2f59c3['onEvent'](_0x2bd8af['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x330d0b['_key']()]={'manager':_0x2f59c3},this['iframes'][_0x330d0b['_key']()]=_0x1c10d1,_0x2f59c3;}['_isIframeWebStorageSupported'](_0x46ac7d,_0x57e3f0){this['iframes'][_0x46ac7d['_key']()]['send'](li,{'type':li},_0x31a18f=>{var _0x4d9ac0;const _0x417963=(_0x4d9ac0=_0x31a18f==null?void 0x0:_0x31a18f[0x0])==null?void 0x0:_0x4d9ac0[li];_0x417963!==void 0x0&&_0x57e3f0(!!_0x417963),K(_0x46ac7d,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3827c9){const _0x9b385=_0x3827c9['_key']();return this['originValidationPromises'][_0x9b385]||(this['originValidationPromises'][_0x9b385]=Pp(_0x3827c9)),this['originValidationPromises'][_0x9b385];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x434109){this['auth']=_0x434109,this['internalListeners']=new Map();}['getUid'](){var _0x4769b2;return this['assertAuthConfigured'](),((_0x4769b2=this['auth']['currentUser'])==null?void 0x0:_0x4769b2['uid'])||null;}async['getToken'](_0x2792b7){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2792b7)}:null;}['addAuthTokenListener'](_0x52d026){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x52d026))return;const _0x463e08=this['auth']['onIdTokenChanged'](_0x3d6b26=>{_0x52d026((_0x3d6b26==null?void 0x0:_0x3d6b26['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x52d026,_0x463e08),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2bd569){this['assertAuthConfigured']();const _0x39145b=this['internalListeners']['get'](_0x2bd569);_0x39145b&&(this['internalListeners']['delete'](_0x2bd569),_0x39145b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x4885e6){switch(_0x4885e6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3ea0b9){et(new Me('auth',(_0x3414c0,{options:_0x2c2167})=>{const _0x436fa3=_0x3414c0['getProvider']('app')['getImmediate'](),_0x2b2701=_0x3414c0['getProvider']('heartbeat'),_0x37d6e6=_0x3414c0['getProvider']('app-check-internal'),{apiKey:_0x45f09f,authDomain:_0xcf4246}=_0x436fa3['options'];m(_0x45f09f&&!_0x45f09f['includes'](':'),'invalid-api-key',{'appName':_0x436fa3['name']});const _0x5a62fe={'apiKey':_0x45f09f,'authDomain':_0xcf4246,'clientPlatform':_0x3ea0b9,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3ea0b9)},_0x5e11f0=new bf(_0x436fa3,_0x2b2701,_0x37d6e6,_0x5a62fe);return Lf(_0x5e11f0,_0x2c2167),_0x5e11f0;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1c26b8,_0x289c0b,_0x2ad5ce)=>{_0x1c26b8['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3d3f9c=>{const _0x30f0f6=qe(_0x3d3f9c['getProvider']('auth')['getImmediate']());return(_0x37f586=>new n_(_0x37f586))(_0x30f0f6);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3ea0b9)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x323b67=>async _0x5ebaf0=>{const _0x213215=_0x5ebaf0&&await _0x5ebaf0['getIdTokenResult'](),_0x402fe9=_0x213215&&(new Date()['getTime']()-Date['parse'](_0x213215['issuedAtTime']))/0x3e8;if(_0x402fe9&&_0x402fe9>o_)return;const _0x3845ac=_0x213215==null?void 0x0:_0x213215['token'];Fr!==_0x3845ac&&(Fr=_0x3845ac,await fetch(_0x323b67,{'method':_0x3845ac?'POST':'DELETE','headers':_0x3845ac?{'Authorization':'Bearer\x20'+_0x3845ac}:{}}));};function O_(_0x258ea2=Qr()){const _0x16132e=Ui(_0x258ea2,'auth');if(_0x16132e['isInitialized']())return _0x16132e['getImmediate']();const _0x325959=Mf(_0x258ea2,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x41d4c0=Gr('authTokenSyncURL');if(_0x41d4c0&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4bff45=new URL(_0x41d4c0,location['origin']);if(location['origin']===_0x4bff45['origin']){const _0x50ab4c=a_(_0x4bff45['toString']());Jf(_0x325959,_0x50ab4c,()=>_0x50ab4c(_0x325959['currentUser'])),Qf(_0x325959,_0x681821=>_0x50ab4c(_0x681821));}}const _0x1b3429=Hr('auth');return _0x1b3429&&xf(_0x325959,'http://'+_0x1b3429),_0x325959;}function c_(){var _0x557efb;return((_0x557efb=document['getElementsByTagName']('head'))==null?void 0x0:_0x557efb[0x0])??document;}Rf({'loadJS'(_0x137cfe){return new Promise((_0x2f6a9d,_0x1d00d0)=>{const _0x3737bd=document['createElement']('script');_0x3737bd['setAttribute']('src',_0x137cfe),_0x3737bd['onload']=_0x2f6a9d,_0x3737bd['onerror']=_0x4a9ab5=>{const _0x486c29=J('internal-error');_0x486c29['customData']=_0x4a9ab5,_0x1d00d0(_0x486c29);},_0x3737bd['type']='text/javascript',_0x3737bd['charset']='UTF-8',c_()['appendChild'](_0x3737bd);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};