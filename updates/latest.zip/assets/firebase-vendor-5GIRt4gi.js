const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5c73e2,_0xc0ea3a){if(!_0x5c73e2)throw ot(_0xc0ea3a);},ot=function(_0x51cbad){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x51cbad);},Wr=function(_0x578e47){const _0x83682c=[];let _0xb905f1=0x0;for(let _0x43e43e=0x0;_0x43e43e<_0x578e47['length'];_0x43e43e++){let _0xa2686c=_0x578e47['charCodeAt'](_0x43e43e);_0xa2686c<0x80?_0x83682c[_0xb905f1++]=_0xa2686c:_0xa2686c<0x800?(_0x83682c[_0xb905f1++]=_0xa2686c>>0x6|0xc0,_0x83682c[_0xb905f1++]=_0xa2686c&0x3f|0x80):(_0xa2686c&0xfc00)===0xd800&&_0x43e43e+0x1<_0x578e47['length']&&(_0x578e47['charCodeAt'](_0x43e43e+0x1)&0xfc00)===0xdc00?(_0xa2686c=0x10000+((_0xa2686c&0x3ff)<<0xa)+(_0x578e47['charCodeAt'](++_0x43e43e)&0x3ff),_0x83682c[_0xb905f1++]=_0xa2686c>>0x12|0xf0,_0x83682c[_0xb905f1++]=_0xa2686c>>0xc&0x3f|0x80,_0x83682c[_0xb905f1++]=_0xa2686c>>0x6&0x3f|0x80,_0x83682c[_0xb905f1++]=_0xa2686c&0x3f|0x80):(_0x83682c[_0xb905f1++]=_0xa2686c>>0xc|0xe0,_0x83682c[_0xb905f1++]=_0xa2686c>>0x6&0x3f|0x80,_0x83682c[_0xb905f1++]=_0xa2686c&0x3f|0x80);}return _0x83682c;},Za=function(_0x589358){const _0x27dde0=[];let _0x233f87=0x0,_0x311009=0x0;for(;_0x233f87<_0x589358['length'];){const _0x29f1ec=_0x589358[_0x233f87++];if(_0x29f1ec<0x80)_0x27dde0[_0x311009++]=String['fromCharCode'](_0x29f1ec);else{if(_0x29f1ec>0xbf&&_0x29f1ec<0xe0){const _0x35c5f7=_0x589358[_0x233f87++];_0x27dde0[_0x311009++]=String['fromCharCode']((_0x29f1ec&0x1f)<<0x6|_0x35c5f7&0x3f);}else{if(_0x29f1ec>0xef&&_0x29f1ec<0x16d){const _0x2fc1e6=_0x589358[_0x233f87++],_0x226d75=_0x589358[_0x233f87++],_0x173281=_0x589358[_0x233f87++],_0x5c5721=((_0x29f1ec&0x7)<<0x12|(_0x2fc1e6&0x3f)<<0xc|(_0x226d75&0x3f)<<0x6|_0x173281&0x3f)-0x10000;_0x27dde0[_0x311009++]=String['fromCharCode'](0xd800+(_0x5c5721>>0xa)),_0x27dde0[_0x311009++]=String['fromCharCode'](0xdc00+(_0x5c5721&0x3ff));}else{const _0x3ead79=_0x589358[_0x233f87++],_0xa241a=_0x589358[_0x233f87++];_0x27dde0[_0x311009++]=String['fromCharCode']((_0x29f1ec&0xf)<<0xc|(_0x3ead79&0x3f)<<0x6|_0xa241a&0x3f);}}}}return _0x27dde0['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x27caf0,_0x1bab42){if(!Array['isArray'](_0x27caf0))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x91bcc8=_0x1bab42?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1e13f7=[];for(let _0x53d5fb=0x0;_0x53d5fb<_0x27caf0['length'];_0x53d5fb+=0x3){const _0x57577e=_0x27caf0[_0x53d5fb],_0x2e444f=_0x53d5fb+0x1<_0x27caf0['length'],_0x31249a=_0x2e444f?_0x27caf0[_0x53d5fb+0x1]:0x0,_0xec261b=_0x53d5fb+0x2<_0x27caf0['length'],_0x391828=_0xec261b?_0x27caf0[_0x53d5fb+0x2]:0x0,_0x44bcb4=_0x57577e>>0x2,_0x2687e5=(_0x57577e&0x3)<<0x4|_0x31249a>>0x4;let _0x1e5e65=(_0x31249a&0xf)<<0x2|_0x391828>>0x6,_0x40f143=_0x391828&0x3f;_0xec261b||(_0x40f143=0x40,_0x2e444f||(_0x1e5e65=0x40)),_0x1e13f7['push'](_0x91bcc8[_0x44bcb4],_0x91bcc8[_0x2687e5],_0x91bcc8[_0x1e5e65],_0x91bcc8[_0x40f143]);}return _0x1e13f7['join']('');},'encodeString'(_0x5cb727,_0x426632){return this['HAS_NATIVE_SUPPORT']&&!_0x426632?btoa(_0x5cb727):this['encodeByteArray'](Wr(_0x5cb727),_0x426632);},'decodeString'(_0x4ef0c0,_0x1345c6){return this['HAS_NATIVE_SUPPORT']&&!_0x1345c6?atob(_0x4ef0c0):Za(this['decodeStringToByteArray'](_0x4ef0c0,_0x1345c6));},'decodeStringToByteArray'(_0x14761f,_0x22a3c6){this['init_']();const _0x484ac2=_0x22a3c6?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x53b988=[];for(let _0x2cd06a=0x0;_0x2cd06a<_0x14761f['length'];){const _0x3430c1=_0x484ac2[_0x14761f['charAt'](_0x2cd06a++)],_0x24b315=_0x2cd06a<_0x14761f['length']?_0x484ac2[_0x14761f['charAt'](_0x2cd06a)]:0x0;++_0x2cd06a;const _0x16c0c9=_0x2cd06a<_0x14761f['length']?_0x484ac2[_0x14761f['charAt'](_0x2cd06a)]:0x40;++_0x2cd06a;const _0x46548f=_0x2cd06a<_0x14761f['length']?_0x484ac2[_0x14761f['charAt'](_0x2cd06a)]:0x40;if(++_0x2cd06a,_0x3430c1==null||_0x24b315==null||_0x16c0c9==null||_0x46548f==null)throw new ec();const _0x202b20=_0x3430c1<<0x2|_0x24b315>>0x4;if(_0x53b988['push'](_0x202b20),_0x16c0c9!==0x40){const _0x3773bf=_0x24b315<<0x4&0xf0|_0x16c0c9>>0x2;if(_0x53b988['push'](_0x3773bf),_0x46548f!==0x40){const _0x4d9df1=_0x16c0c9<<0x6&0xc0|_0x46548f;_0x53b988['push'](_0x4d9df1);}}}return _0x53b988;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1bcea6=0x0;_0x1bcea6<this['ENCODED_VALS']['length'];_0x1bcea6++)this['byteToCharMap_'][_0x1bcea6]=this['ENCODED_VALS']['charAt'](_0x1bcea6),this['charToByteMap_'][this['byteToCharMap_'][_0x1bcea6]]=_0x1bcea6,this['byteToCharMapWebSafe_'][_0x1bcea6]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1bcea6),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1bcea6]]=_0x1bcea6,_0x1bcea6>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1bcea6)]=_0x1bcea6,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1bcea6)]=_0x1bcea6);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x12bc02){const _0x1797a5=Wr(_0x12bc02);return Di['encodeByteArray'](_0x1797a5,!0x0);},an=function(_0x453223){return Br(_0x453223)['replace'](/\./g,'');},cn=function(_0x26d359){try{return Di['decodeString'](_0x26d359,!0x0);}catch(_0x374a2d){console['error']('base64Decode\x20failed:\x20',_0x374a2d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3288ed){return Vr(void 0x0,_0x3288ed);}function Vr(_0x371fb0,_0x482613){if(!(_0x482613 instanceof Object))return _0x482613;switch(_0x482613['constructor']){case Date:const _0x265bc2=_0x482613;return new Date(_0x265bc2['getTime']());case Object:_0x371fb0===void 0x0&&(_0x371fb0={});break;case Array:_0x371fb0=[];break;default:return _0x482613;}for(const _0x400b2d in _0x482613)!_0x482613['hasOwnProperty'](_0x400b2d)||!nc(_0x400b2d)||(_0x371fb0[_0x400b2d]=Vr(_0x371fb0[_0x400b2d],_0x482613[_0x400b2d]));return _0x371fb0;}function nc(_0xab35e8){return _0xab35e8!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x3556da=As['__FIREBASE_DEFAULTS__'];if(_0x3556da)return JSON['parse'](_0x3556da);},oc=()=>{if(typeof document>'u')return;let _0x5bf56b;try{_0x5bf56b=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3ee4ef=_0x5bf56b&&cn(_0x5bf56b[0x1]);return _0x3ee4ef&&JSON['parse'](_0x3ee4ef);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x16f120){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x16f120);return;}},Hr=_0x354194=>{var _0x1f94de,_0x545bb7;return(_0x545bb7=(_0x1f94de=Mi())==null?void 0x0:_0x1f94de['emulatorHosts'])==null?void 0x0:_0x545bb7[_0x354194];},ac=_0x51d12a=>{const _0xf5cf34=Hr(_0x51d12a);if(!_0xf5cf34)return;const _0x510b5e=_0xf5cf34['lastIndexOf'](':');if(_0x510b5e<=0x0||_0x510b5e+0x1===_0xf5cf34['length'])throw new Error('Invalid\x20host\x20'+_0xf5cf34+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2df414=parseInt(_0xf5cf34['substring'](_0x510b5e+0x1),0xa);return _0xf5cf34[0x0]==='['?[_0xf5cf34['substring'](0x1,_0x510b5e-0x1),_0x2df414]:[_0xf5cf34['substring'](0x0,_0x510b5e),_0x2df414];},$r=()=>{var _0x5da775;return(_0x5da775=Mi())==null?void 0x0:_0x5da775['config'];},Gr=_0x1d4cec=>{var _0x8fc57f;return(_0x8fc57f=Mi())==null?void 0x0:_0x8fc57f['_'+_0x1d4cec];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1ecd6b,_0x409542)=>{this['resolve']=_0x1ecd6b,this['reject']=_0x409542;});}['wrapCallback'](_0x5e934d){return(_0x5a6f60,_0x45be0b)=>{_0x5a6f60?this['reject'](_0x5a6f60):this['resolve'](_0x45be0b),typeof _0x5e934d=='function'&&(this['promise']['catch'](()=>{}),_0x5e934d['length']===0x1?_0x5e934d(_0x5a6f60):_0x5e934d(_0x5a6f60,_0x45be0b));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x5ddb59,_0x4cf999){if(_0x5ddb59['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x45f27f={'alg':'none','type':'JWT'},_0x5d2d5c=_0x4cf999||'demo-project',_0x588077=_0x5ddb59['iat']||0x0,_0x5dfa9f=_0x5ddb59['sub']||_0x5ddb59['user_id'];if(!_0x5dfa9f)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x41bcbe={'iss':'https://securetoken.google.com/'+_0x5d2d5c,'aud':_0x5d2d5c,'iat':_0x588077,'exp':_0x588077+0xe10,'auth_time':_0x588077,'sub':_0x5dfa9f,'user_id':_0x5dfa9f,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5ddb59};return[an(JSON['stringify'](_0x45f27f)),an(JSON['stringify'](_0x41bcbe)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x41a193=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x41a193=='object'&&_0x41a193['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x175e2d=W();return _0x175e2d['indexOf']('MSIE\x20')>=0x0||_0x175e2d['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x19eb63,_0x20583e)=>{try{let _0x1a00de=!0x0;const _0x4a7e33='validate-browser-context-for-indexeddb-analytics-module',_0x1b3e50=self['indexedDB']['open'](_0x4a7e33);_0x1b3e50['onsuccess']=()=>{_0x1b3e50['result']['close'](),_0x1a00de||self['indexedDB']['deleteDatabase'](_0x4a7e33),_0x19eb63(!0x0);},_0x1b3e50['onupgradeneeded']=()=>{_0x1a00de=!0x1;},_0x1b3e50['onerror']=()=>{var _0x326d44;_0x20583e(((_0x326d44=_0x1b3e50['error'])==null?void 0x0:_0x326d44['message'])||'');};}catch(_0x98f09c){_0x20583e(_0x98f09c);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x4ded47,_0x27b48b,_0x595efd){super(_0x27b48b),this['code']=_0x4ded47,this['customData']=_0x595efd,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x13d941,_0x57c29a,_0x2b9bb4){this['service']=_0x13d941,this['serviceName']=_0x57c29a,this['errors']=_0x2b9bb4;}['create'](_0xede649,..._0x4e8a78){const _0x1f55c8=_0x4e8a78[0x0]||{},_0x51e299=this['service']+'/'+_0xede649,_0x5a8b8a=this['errors'][_0xede649],_0xe7b726=_0x5a8b8a?gc(_0x5a8b8a,_0x1f55c8):'Error',_0x29fbf1=this['serviceName']+':\x20'+_0xe7b726+'\x20('+_0x51e299+').';return new Se(_0x51e299,_0x29fbf1,_0x1f55c8);}}function gc(_0x2a5c81,_0x246755){return _0x2a5c81['replace'](mc,(_0x49ddd9,_0x464d45)=>{const _0x139d15=_0x246755[_0x464d45];return _0x139d15!=null?String(_0x139d15):'<'+_0x464d45+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x2662c6){return JSON['parse'](_0x2662c6);}function O(_0x21f2d6){return JSON['stringify'](_0x21f2d6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x201458){let _0x2b68f6={},_0x1e1434={},_0x11965c={},_0x4f2f43='';try{const _0x489eac=_0x201458['split']('.');_0x2b68f6=bt(cn(_0x489eac[0x0])||''),_0x1e1434=bt(cn(_0x489eac[0x1])||''),_0x4f2f43=_0x489eac[0x2],_0x11965c=_0x1e1434['d']||{},delete _0x1e1434['d'];}catch{}return{'header':_0x2b68f6,'claims':_0x1e1434,'data':_0x11965c,'signature':_0x4f2f43};},yc=function(_0x3ca6cb){const _0x57ca85=zr(_0x3ca6cb),_0x4f4aef=_0x57ca85['claims'];return!!_0x4f4aef&&typeof _0x4f4aef=='object'&&_0x4f4aef['hasOwnProperty']('iat');},vc=function(_0x3be70c){const _0x178791=zr(_0x3be70c)['claims'];return typeof _0x178791=='object'&&_0x178791['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x2a6ca2,_0x5c71bc){return Object['prototype']['hasOwnProperty']['call'](_0x2a6ca2,_0x5c71bc);}function Oe(_0x227b70,_0x6d68b6){if(Object['prototype']['hasOwnProperty']['call'](_0x227b70,_0x6d68b6))return _0x227b70[_0x6d68b6];}function hi(_0x1c0193){for(const _0x312a1c in _0x1c0193)if(Object['prototype']['hasOwnProperty']['call'](_0x1c0193,_0x312a1c))return!0x1;return!0x0;}function ln(_0x121928,_0x5cce40,_0x595d21){const _0x13ba11={};for(const _0x2b560e in _0x121928)Object['prototype']['hasOwnProperty']['call'](_0x121928,_0x2b560e)&&(_0x13ba11[_0x2b560e]=_0x5cce40['call'](_0x595d21,_0x121928[_0x2b560e],_0x2b560e,_0x121928));return _0x13ba11;}function De(_0x8e5100,_0x2f761f){if(_0x8e5100===_0x2f761f)return!0x0;const _0x5cb35a=Object['keys'](_0x8e5100),_0x284897=Object['keys'](_0x2f761f);for(const _0x393ca1 of _0x5cb35a){if(!_0x284897['includes'](_0x393ca1))return!0x1;const _0x54ef16=_0x8e5100[_0x393ca1],_0x13dcf7=_0x2f761f[_0x393ca1];if(ks(_0x54ef16)&&ks(_0x13dcf7)){if(!De(_0x54ef16,_0x13dcf7))return!0x1;}else{if(_0x54ef16!==_0x13dcf7)return!0x1;}}for(const _0x497f02 of _0x284897)if(!_0x5cb35a['includes'](_0x497f02))return!0x1;return!0x0;}function ks(_0x165309){return _0x165309!==null&&typeof _0x165309=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x2aa889){const _0x407a90=[];for(const [_0x4f84d9,_0x1e13ff]of Object['entries'](_0x2aa889))Array['isArray'](_0x1e13ff)?_0x1e13ff['forEach'](_0x4fa1a4=>{_0x407a90['push'](encodeURIComponent(_0x4f84d9)+'='+encodeURIComponent(_0x4fa1a4));}):_0x407a90['push'](encodeURIComponent(_0x4f84d9)+'='+encodeURIComponent(_0x1e13ff));return _0x407a90['length']?'&'+_0x407a90['join']('&'):'';}function yt(_0x4803c8){const _0x41460f={};return _0x4803c8['replace'](/^\?/,'')['split']('&')['forEach'](_0xb93082=>{if(_0xb93082){const [_0x5587a6,_0x130c8d]=_0xb93082['split']('=');_0x41460f[decodeURIComponent(_0x5587a6)]=decodeURIComponent(_0x130c8d);}}),_0x41460f;}function vt(_0x8e6578){const _0x48940c=_0x8e6578['indexOf']('?');if(!_0x48940c)return'';const _0x570226=_0x8e6578['indexOf']('#',_0x48940c);return _0x8e6578['substring'](_0x48940c,_0x570226>0x0?_0x570226:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x12e66d=0x1;_0x12e66d<this['blockSize'];++_0x12e66d)this['pad_'][_0x12e66d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1b5f3c,_0x58b3b1){_0x58b3b1||(_0x58b3b1=0x0);const _0x351e42=this['W_'];if(typeof _0x1b5f3c=='string'){for(let _0x4c20e3=0x0;_0x4c20e3<0x10;_0x4c20e3++)_0x351e42[_0x4c20e3]=_0x1b5f3c['charCodeAt'](_0x58b3b1)<<0x18|_0x1b5f3c['charCodeAt'](_0x58b3b1+0x1)<<0x10|_0x1b5f3c['charCodeAt'](_0x58b3b1+0x2)<<0x8|_0x1b5f3c['charCodeAt'](_0x58b3b1+0x3),_0x58b3b1+=0x4;}else{for(let _0x412faa=0x0;_0x412faa<0x10;_0x412faa++)_0x351e42[_0x412faa]=_0x1b5f3c[_0x58b3b1]<<0x18|_0x1b5f3c[_0x58b3b1+0x1]<<0x10|_0x1b5f3c[_0x58b3b1+0x2]<<0x8|_0x1b5f3c[_0x58b3b1+0x3],_0x58b3b1+=0x4;}for(let _0xf291e0=0x10;_0xf291e0<0x50;_0xf291e0++){const _0x5bd711=_0x351e42[_0xf291e0-0x3]^_0x351e42[_0xf291e0-0x8]^_0x351e42[_0xf291e0-0xe]^_0x351e42[_0xf291e0-0x10];_0x351e42[_0xf291e0]=(_0x5bd711<<0x1|_0x5bd711>>>0x1f)&0xffffffff;}let _0x46e51e=this['chain_'][0x0],_0x214cc7=this['chain_'][0x1],_0x1953bd=this['chain_'][0x2],_0x4b6484=this['chain_'][0x3],_0x56f26a=this['chain_'][0x4],_0x52408c,_0x4cf80b;for(let _0x320070=0x0;_0x320070<0x50;_0x320070++){_0x320070<0x28?_0x320070<0x14?(_0x52408c=_0x4b6484^_0x214cc7&(_0x1953bd^_0x4b6484),_0x4cf80b=0x5a827999):(_0x52408c=_0x214cc7^_0x1953bd^_0x4b6484,_0x4cf80b=0x6ed9eba1):_0x320070<0x3c?(_0x52408c=_0x214cc7&_0x1953bd|_0x4b6484&(_0x214cc7|_0x1953bd),_0x4cf80b=0x8f1bbcdc):(_0x52408c=_0x214cc7^_0x1953bd^_0x4b6484,_0x4cf80b=0xca62c1d6);const _0x5cc240=(_0x46e51e<<0x5|_0x46e51e>>>0x1b)+_0x52408c+_0x56f26a+_0x4cf80b+_0x351e42[_0x320070]&0xffffffff;_0x56f26a=_0x4b6484,_0x4b6484=_0x1953bd,_0x1953bd=(_0x214cc7<<0x1e|_0x214cc7>>>0x2)&0xffffffff,_0x214cc7=_0x46e51e,_0x46e51e=_0x5cc240;}this['chain_'][0x0]=this['chain_'][0x0]+_0x46e51e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x214cc7&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1953bd&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4b6484&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x56f26a&0xffffffff;}['update'](_0x526057,_0x15f1ae){if(_0x526057==null)return;_0x15f1ae===void 0x0&&(_0x15f1ae=_0x526057['length']);const _0x3af077=_0x15f1ae-this['blockSize'];let _0x5a595f=0x0;const _0x2af5c2=this['buf_'];let _0x2862a6=this['inbuf_'];for(;_0x5a595f<_0x15f1ae;){if(_0x2862a6===0x0){for(;_0x5a595f<=_0x3af077;)this['compress_'](_0x526057,_0x5a595f),_0x5a595f+=this['blockSize'];}if(typeof _0x526057=='string'){for(;_0x5a595f<_0x15f1ae;)if(_0x2af5c2[_0x2862a6]=_0x526057['charCodeAt'](_0x5a595f),++_0x2862a6,++_0x5a595f,_0x2862a6===this['blockSize']){this['compress_'](_0x2af5c2),_0x2862a6=0x0;break;}}else{for(;_0x5a595f<_0x15f1ae;)if(_0x2af5c2[_0x2862a6]=_0x526057[_0x5a595f],++_0x2862a6,++_0x5a595f,_0x2862a6===this['blockSize']){this['compress_'](_0x2af5c2),_0x2862a6=0x0;break;}}}this['inbuf_']=_0x2862a6,this['total_']+=_0x15f1ae;}['digest'](){const _0x286b92=[];let _0x22aee6=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x13249e=this['blockSize']-0x1;_0x13249e>=0x38;_0x13249e--)this['buf_'][_0x13249e]=_0x22aee6&0xff,_0x22aee6/=0x100;this['compress_'](this['buf_']);let _0x4f8849=0x0;for(let _0x3c41f4=0x0;_0x3c41f4<0x5;_0x3c41f4++)for(let _0x3ee7bb=0x18;_0x3ee7bb>=0x0;_0x3ee7bb-=0x8)_0x286b92[_0x4f8849]=this['chain_'][_0x3c41f4]>>_0x3ee7bb&0xff,++_0x4f8849;return _0x286b92;}}function Ic(_0x3607cf,_0x19a3a1){const _0x119ba2=new wc(_0x3607cf,_0x19a3a1);return _0x119ba2['subscribe']['bind'](_0x119ba2);}class wc{constructor(_0x3fe175,_0x142f88){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x142f88,this['task']['then'](()=>{_0x3fe175(this);})['catch'](_0x2a4679=>{this['error'](_0x2a4679);});}['next'](_0x4848a3){this['forEachObserver'](_0xdacca5=>{_0xdacca5['next'](_0x4848a3);});}['error'](_0x47c146){this['forEachObserver'](_0x33df5b=>{_0x33df5b['error'](_0x47c146);}),this['close'](_0x47c146);}['complete'](){this['forEachObserver'](_0x444d93=>{_0x444d93['complete']();}),this['close']();}['subscribe'](_0x40ff7e,_0x5895db,_0x5c9ea1){let _0x205de6;if(_0x40ff7e===void 0x0&&_0x5895db===void 0x0&&_0x5c9ea1===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x40ff7e,['next','error','complete'])?_0x205de6=_0x40ff7e:_0x205de6={'next':_0x40ff7e,'error':_0x5895db,'complete':_0x5c9ea1},_0x205de6['next']===void 0x0&&(_0x205de6['next']=Qn),_0x205de6['error']===void 0x0&&(_0x205de6['error']=Qn),_0x205de6['complete']===void 0x0&&(_0x205de6['complete']=Qn);const _0xb0285d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x205de6['error'](this['finalError']):_0x205de6['complete']();}catch{}}),this['observers']['push'](_0x205de6),_0xb0285d;}['unsubscribeOne'](_0x554092){this['observers']===void 0x0||this['observers'][_0x554092]===void 0x0||(delete this['observers'][_0x554092],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x37c221){if(!this['finalized']){for(let _0x4b5134=0x0;_0x4b5134<this['observers']['length'];_0x4b5134++)this['sendOne'](_0x4b5134,_0x37c221);}}['sendOne'](_0x21bf46,_0x5e99cd){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x21bf46]!==void 0x0)try{_0x5e99cd(this['observers'][_0x21bf46]);}catch(_0x487b96){typeof console<'u'&&console['error']&&console['error'](_0x487b96);}});}['close'](_0x35e416){this['finalized']||(this['finalized']=!0x0,_0x35e416!==void 0x0&&(this['finalError']=_0x35e416),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x210bd8,_0x3fa694){if(typeof _0x210bd8!='object'||_0x210bd8===null)return!0x1;for(const _0x553ed0 of _0x3fa694)if(_0x553ed0 in _0x210bd8&&typeof _0x210bd8[_0x553ed0]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x23c309,_0x295f74){return _0x23c309+'\x20failed:\x20'+_0x295f74+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x3e7b44){const _0x284fbb=[];let _0x231210=0x0;for(let _0x4d1d20=0x0;_0x4d1d20<_0x3e7b44['length'];_0x4d1d20++){let _0x5196b3=_0x3e7b44['charCodeAt'](_0x4d1d20);if(_0x5196b3>=0xd800&&_0x5196b3<=0xdbff){const _0xadf8fb=_0x5196b3-0xd800;_0x4d1d20++,f(_0x4d1d20<_0x3e7b44['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0xefdd22=_0x3e7b44['charCodeAt'](_0x4d1d20)-0xdc00;_0x5196b3=0x10000+(_0xadf8fb<<0xa)+_0xefdd22;}_0x5196b3<0x80?_0x284fbb[_0x231210++]=_0x5196b3:_0x5196b3<0x800?(_0x284fbb[_0x231210++]=_0x5196b3>>0x6|0xc0,_0x284fbb[_0x231210++]=_0x5196b3&0x3f|0x80):_0x5196b3<0x10000?(_0x284fbb[_0x231210++]=_0x5196b3>>0xc|0xe0,_0x284fbb[_0x231210++]=_0x5196b3>>0x6&0x3f|0x80,_0x284fbb[_0x231210++]=_0x5196b3&0x3f|0x80):(_0x284fbb[_0x231210++]=_0x5196b3>>0x12|0xf0,_0x284fbb[_0x231210++]=_0x5196b3>>0xc&0x3f|0x80,_0x284fbb[_0x231210++]=_0x5196b3>>0x6&0x3f|0x80,_0x284fbb[_0x231210++]=_0x5196b3&0x3f|0x80);}return _0x284fbb;},Pn=function(_0x1bfc81){let _0x40459a=0x0;for(let _0x2a3c92=0x0;_0x2a3c92<_0x1bfc81['length'];_0x2a3c92++){const _0x3a355d=_0x1bfc81['charCodeAt'](_0x2a3c92);_0x3a355d<0x80?_0x40459a++:_0x3a355d<0x800?_0x40459a+=0x2:_0x3a355d>=0xd800&&_0x3a355d<=0xdbff?(_0x40459a+=0x4,_0x2a3c92++):_0x40459a+=0x3;}return _0x40459a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x5742b4){return _0x5742b4&&_0x5742b4['_delegate']?_0x5742b4['_delegate']:_0x5742b4;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x19a58a){try{return(_0x19a58a['startsWith']('http://')||_0x19a58a['startsWith']('https://')?new URL(_0x19a58a)['hostname']:_0x19a58a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x20b25c){return(await fetch(_0x20b25c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x393f24,_0x467970,_0x53125c){this['name']=_0x393f24,this['instanceFactory']=_0x467970,this['type']=_0x53125c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x43bfe1){return this['instantiationMode']=_0x43bfe1,this;}['setMultipleInstances'](_0x20a996){return this['multipleInstances']=_0x20a996,this;}['setServiceProps'](_0x14b13b){return this['serviceProps']=_0x14b13b,this;}['setInstanceCreatedCallback'](_0x1f1381){return this['onInstanceCreated']=_0x1f1381,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x5d82aa,_0x25fb60){this['name']=_0x5d82aa,this['container']=_0x25fb60,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x73f83c){const _0x3627ca=this['normalizeInstanceIdentifier'](_0x73f83c);if(!this['instancesDeferred']['has'](_0x3627ca)){const _0xff4182=new Ve();if(this['instancesDeferred']['set'](_0x3627ca,_0xff4182),this['isInitialized'](_0x3627ca)||this['shouldAutoInitialize']())try{const _0x20c593=this['getOrInitializeService']({'instanceIdentifier':_0x3627ca});_0x20c593&&_0xff4182['resolve'](_0x20c593);}catch{}}return this['instancesDeferred']['get'](_0x3627ca)['promise'];}['getImmediate'](_0x41a93f){const _0x4323fc=this['normalizeInstanceIdentifier'](_0x41a93f==null?void 0x0:_0x41a93f['identifier']),_0x4a423a=(_0x41a93f==null?void 0x0:_0x41a93f['optional'])??!0x1;if(this['isInitialized'](_0x4323fc)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4323fc});}catch(_0x50f6d9){if(_0x4a423a)return null;throw _0x50f6d9;}else{if(_0x4a423a)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x7a3abe){if(_0x7a3abe['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x7a3abe['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x7a3abe,!!this['shouldAutoInitialize']()){if(Rc(_0x7a3abe))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3bae65,_0x5cb6b5]of this['instancesDeferred']['entries']()){const _0x5c49b1=this['normalizeInstanceIdentifier'](_0x3bae65);try{const _0x269505=this['getOrInitializeService']({'instanceIdentifier':_0x5c49b1});_0x5cb6b5['resolve'](_0x269505);}catch{}}}}['clearInstance'](_0x46065f=ke){this['instancesDeferred']['delete'](_0x46065f),this['instancesOptions']['delete'](_0x46065f),this['instances']['delete'](_0x46065f);}async['delete'](){const _0x2c3a9a=Array['from'](this['instances']['values']());await Promise['all']([..._0x2c3a9a['filter'](_0xb050d7=>'INTERNAL'in _0xb050d7)['map'](_0x5319c7=>_0x5319c7['INTERNAL']['delete']()),..._0x2c3a9a['filter'](_0x207138=>'_delete'in _0x207138)['map'](_0x10af03=>_0x10af03['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x17deab=ke){return this['instances']['has'](_0x17deab);}['getOptions'](_0x54e387=ke){return this['instancesOptions']['get'](_0x54e387)||{};}['initialize'](_0x151516={}){const {options:_0x56506b={}}=_0x151516,_0x440249=this['normalizeInstanceIdentifier'](_0x151516['instanceIdentifier']);if(this['isInitialized'](_0x440249))throw Error(this['name']+'('+_0x440249+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1bec75=this['getOrInitializeService']({'instanceIdentifier':_0x440249,'options':_0x56506b});for(const [_0x2d1bd1,_0x52cec7]of this['instancesDeferred']['entries']()){const _0x53089a=this['normalizeInstanceIdentifier'](_0x2d1bd1);_0x440249===_0x53089a&&_0x52cec7['resolve'](_0x1bec75);}return _0x1bec75;}['onInit'](_0x529a47,_0x3701fe){const _0x441b07=this['normalizeInstanceIdentifier'](_0x3701fe),_0x4f9194=this['onInitCallbacks']['get'](_0x441b07)??new Set();_0x4f9194['add'](_0x529a47),this['onInitCallbacks']['set'](_0x441b07,_0x4f9194);const _0x438a58=this['instances']['get'](_0x441b07);return _0x438a58&&_0x529a47(_0x438a58,_0x441b07),()=>{_0x4f9194['delete'](_0x529a47);};}['invokeOnInitCallbacks'](_0x506952,_0x1d3545){const _0xb362c3=this['onInitCallbacks']['get'](_0x1d3545);if(_0xb362c3){for(const _0x84da63 of _0xb362c3)try{_0x84da63(_0x506952,_0x1d3545);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4b3b3e,options:_0x550ef4={}}){let _0x168aa0=this['instances']['get'](_0x4b3b3e);if(!_0x168aa0&&this['component']&&(_0x168aa0=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4b3b3e),'options':_0x550ef4}),this['instances']['set'](_0x4b3b3e,_0x168aa0),this['instancesOptions']['set'](_0x4b3b3e,_0x550ef4),this['invokeOnInitCallbacks'](_0x168aa0,_0x4b3b3e),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4b3b3e,_0x168aa0);}catch{}return _0x168aa0||null;}['normalizeInstanceIdentifier'](_0x1b5401=ke){return this['component']?this['component']['multipleInstances']?_0x1b5401:ke:_0x1b5401;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x53e1a9){return _0x53e1a9===ke?void 0x0:_0x53e1a9;}function Rc(_0x2d8cba){return _0x2d8cba['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x45da18){this['name']=_0x45da18,this['providers']=new Map();}['addComponent'](_0x515fd5){const _0x1e65bf=this['getProvider'](_0x515fd5['name']);if(_0x1e65bf['isComponentSet']())throw new Error('Component\x20'+_0x515fd5['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1e65bf['setComponent'](_0x515fd5);}['addOrOverwriteComponent'](_0x653078){this['getProvider'](_0x653078['name'])['isComponentSet']()&&this['providers']['delete'](_0x653078['name']),this['addComponent'](_0x653078);}['getProvider'](_0x3a7a51){if(this['providers']['has'](_0x3a7a51))return this['providers']['get'](_0x3a7a51);const _0x4f642f=new Sc(_0x3a7a51,this);return this['providers']['set'](_0x3a7a51,_0x4f642f),_0x4f642f;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1f8c14){_0x1f8c14[_0x1f8c14['DEBUG']=0x0]='DEBUG',_0x1f8c14[_0x1f8c14['VERBOSE']=0x1]='VERBOSE',_0x1f8c14[_0x1f8c14['INFO']=0x2]='INFO',_0x1f8c14[_0x1f8c14['WARN']=0x3]='WARN',_0x1f8c14[_0x1f8c14['ERROR']=0x4]='ERROR',_0x1f8c14[_0x1f8c14['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x19fd38,_0x4f9d35,..._0x5aaea0)=>{if(_0x4f9d35<_0x19fd38['logLevel'])return;const _0x1c1556=new Date()['toISOString'](),_0x54670e=Pc[_0x4f9d35];if(_0x54670e)console[_0x54670e]('['+_0x1c1556+']\x20\x20'+_0x19fd38['name']+':',..._0x5aaea0);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4f9d35+')');};class xi{constructor(_0x5dd16f){this['name']=_0x5dd16f,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x18bde2){if(!(_0x18bde2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x18bde2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x18bde2;}['setLogLevel'](_0x5c493e){this['_logLevel']=typeof _0x5c493e=='string'?kc[_0x5c493e]:_0x5c493e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4ad973){if(typeof _0x4ad973!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4ad973;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3c14fc){this['_userLogHandler']=_0x3c14fc;}['debug'](..._0x18d54b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x18d54b),this['_logHandler'](this,T['DEBUG'],..._0x18d54b);}['log'](..._0x225c37){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x225c37),this['_logHandler'](this,T['VERBOSE'],..._0x225c37);}['info'](..._0x3900bc){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3900bc),this['_logHandler'](this,T['INFO'],..._0x3900bc);}['warn'](..._0x475e5b){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x475e5b),this['_logHandler'](this,T['WARN'],..._0x475e5b);}['error'](..._0x5992ab){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5992ab),this['_logHandler'](this,T['ERROR'],..._0x5992ab);}}const Dc=(_0x4ea5ca,_0x2ce166)=>_0x2ce166['some'](_0x35fbb5=>_0x4ea5ca instanceof _0x35fbb5);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x353679){const _0x20f3af=new Promise((_0x216c9b,_0x3d48ab)=>{const _0x1fdcf3=()=>{_0x353679['removeEventListener']('success',_0x35d660),_0x353679['removeEventListener']('error',_0x392e6f);},_0x35d660=()=>{_0x216c9b(_e(_0x353679['result'])),_0x1fdcf3();},_0x392e6f=()=>{_0x3d48ab(_0x353679['error']),_0x1fdcf3();};_0x353679['addEventListener']('success',_0x35d660),_0x353679['addEventListener']('error',_0x392e6f);});return _0x20f3af['then'](_0x8e2bf=>{_0x8e2bf instanceof IDBCursor&&Kr['set'](_0x8e2bf,_0x353679);})['catch'](()=>{}),Fi['set'](_0x20f3af,_0x353679),_0x20f3af;}function Fc(_0x40c515){if(ui['has'](_0x40c515))return;const _0x405a02=new Promise((_0x48ba7e,_0x272594)=>{const _0x1cf417=()=>{_0x40c515['removeEventListener']('complete',_0x4ce067),_0x40c515['removeEventListener']('error',_0x1ee1c7),_0x40c515['removeEventListener']('abort',_0x1ee1c7);},_0x4ce067=()=>{_0x48ba7e(),_0x1cf417();},_0x1ee1c7=()=>{_0x272594(_0x40c515['error']||new DOMException('AbortError','AbortError')),_0x1cf417();};_0x40c515['addEventListener']('complete',_0x4ce067),_0x40c515['addEventListener']('error',_0x1ee1c7),_0x40c515['addEventListener']('abort',_0x1ee1c7);});ui['set'](_0x40c515,_0x405a02);}let di={'get'(_0x37aa07,_0x25b14e,_0x2d2b6d){if(_0x37aa07 instanceof IDBTransaction){if(_0x25b14e==='done')return ui['get'](_0x37aa07);if(_0x25b14e==='objectStoreNames')return _0x37aa07['objectStoreNames']||Yr['get'](_0x37aa07);if(_0x25b14e==='store')return _0x2d2b6d['objectStoreNames'][0x1]?void 0x0:_0x2d2b6d['objectStore'](_0x2d2b6d['objectStoreNames'][0x0]);}return _e(_0x37aa07[_0x25b14e]);},'set'(_0x24d139,_0x4fbf4a,_0x3c84ed){return _0x24d139[_0x4fbf4a]=_0x3c84ed,!0x0;},'has'(_0x25956b,_0x5cfbb0){return _0x25956b instanceof IDBTransaction&&(_0x5cfbb0==='done'||_0x5cfbb0==='store')?!0x0:_0x5cfbb0 in _0x25956b;}};function Uc(_0x134b1e){di=_0x134b1e(di);}function Wc(_0x206506){return _0x206506===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x6268e3,..._0x4db7b3){const _0x4648c2=_0x206506['call'](Xn(this),_0x6268e3,..._0x4db7b3);return Yr['set'](_0x4648c2,_0x6268e3['sort']?_0x6268e3['sort']():[_0x6268e3]),_e(_0x4648c2);}:Lc()['includes'](_0x206506)?function(..._0x1363ad){return _0x206506['apply'](Xn(this),_0x1363ad),_e(Kr['get'](this));}:function(..._0x560c1a){return _e(_0x206506['apply'](Xn(this),_0x560c1a));};}function Bc(_0xb92f93){return typeof _0xb92f93=='function'?Wc(_0xb92f93):(_0xb92f93 instanceof IDBTransaction&&Fc(_0xb92f93),Dc(_0xb92f93,Mc())?new Proxy(_0xb92f93,di):_0xb92f93);}function _e(_0x30caba){if(_0x30caba instanceof IDBRequest)return xc(_0x30caba);if(Jn['has'](_0x30caba))return Jn['get'](_0x30caba);const _0xa3bb51=Bc(_0x30caba);return _0xa3bb51!==_0x30caba&&(Jn['set'](_0x30caba,_0xa3bb51),Fi['set'](_0xa3bb51,_0x30caba)),_0xa3bb51;}const Xn=_0x456583=>Fi['get'](_0x456583);function Vc(_0x43d415,_0x2e2ac8,{blocked:_0x227f08,upgrade:_0x17e312,blocking:_0x1dc966,terminated:_0x291436}={}){const _0x1034f9=indexedDB['open'](_0x43d415,_0x2e2ac8),_0x584990=_e(_0x1034f9);return _0x17e312&&_0x1034f9['addEventListener']('upgradeneeded',_0x5e8ce2=>{_0x17e312(_e(_0x1034f9['result']),_0x5e8ce2['oldVersion'],_0x5e8ce2['newVersion'],_e(_0x1034f9['transaction']),_0x5e8ce2);}),_0x227f08&&_0x1034f9['addEventListener']('blocked',_0x5fd211=>_0x227f08(_0x5fd211['oldVersion'],_0x5fd211['newVersion'],_0x5fd211)),_0x584990['then'](_0x44b6b7=>{_0x291436&&_0x44b6b7['addEventListener']('close',()=>_0x291436()),_0x1dc966&&_0x44b6b7['addEventListener']('versionchange',_0x27fdf6=>_0x1dc966(_0x27fdf6['oldVersion'],_0x27fdf6['newVersion'],_0x27fdf6));})['catch'](()=>{}),_0x584990;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x2fbe38,_0x3af86d){if(!(_0x2fbe38 instanceof IDBDatabase&&!(_0x3af86d in _0x2fbe38)&&typeof _0x3af86d=='string'))return;if(Zn['get'](_0x3af86d))return Zn['get'](_0x3af86d);const _0xaffaaf=_0x3af86d['replace'](/FromIndex$/,''),_0x5e5552=_0x3af86d!==_0xaffaaf,_0xb8b7aa=$c['includes'](_0xaffaaf);if(!(_0xaffaaf in(_0x5e5552?IDBIndex:IDBObjectStore)['prototype'])||!(_0xb8b7aa||Hc['includes'](_0xaffaaf)))return;const _0x36770b=async function(_0x2f7f1d,..._0x2ee447){const _0x4cbcba=this['transaction'](_0x2f7f1d,_0xb8b7aa?'readwrite':'readonly');let _0x22a8ea=_0x4cbcba['store'];return _0x5e5552&&(_0x22a8ea=_0x22a8ea['index'](_0x2ee447['shift']())),(await Promise['all']([_0x22a8ea[_0xaffaaf](..._0x2ee447),_0xb8b7aa&&_0x4cbcba['done']]))[0x0];};return Zn['set'](_0x3af86d,_0x36770b),_0x36770b;}Uc(_0x3ec69f=>({..._0x3ec69f,'get':(_0x4f386f,_0x2f4e64,_0x8d5000)=>Os(_0x4f386f,_0x2f4e64)||_0x3ec69f['get'](_0x4f386f,_0x2f4e64,_0x8d5000),'has':(_0x8a2f63,_0x4a5ed0)=>!!Os(_0x8a2f63,_0x4a5ed0)||_0x3ec69f['has'](_0x8a2f63,_0x4a5ed0)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x5ccb55){this['container']=_0x5ccb55;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1b8a12=>{if(qc(_0x1b8a12)){const _0x225d01=_0x1b8a12['getImmediate']();return _0x225d01['library']+'/'+_0x225d01['version'];}else return null;})['filter'](_0x1def25=>_0x1def25)['join']('\x20');}}function qc(_0x565604){const _0x54cd64=_0x565604['getComponent']();return(_0x54cd64==null?void 0x0:_0x54cd64['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4ec88c,_0x9ce5d7){try{_0x4ec88c['container']['addComponent'](_0x9ce5d7);}catch(_0x59c609){re['debug']('Component\x20'+_0x9ce5d7['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4ec88c['name'],_0x59c609);}}function et(_0x857f5a){const _0x27e38c=_0x857f5a['name'];if(gi['has'](_0x27e38c))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x27e38c+'.'),!0x1;gi['set'](_0x27e38c,_0x857f5a);for(const _0x4e7411 of Le['values']())Ms(_0x4e7411,_0x857f5a);for(const _0x167e87 of _i['values']())Ms(_0x167e87,_0x857f5a);return!0x0;}function Ui(_0x5c2c3c,_0x24da4f){const _0x599310=_0x5c2c3c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x599310&&_0x599310['triggerHeartbeat'](),_0x5c2c3c['container']['getProvider'](_0x24da4f);}function H(_0x57ce2b){return _0x57ce2b==null?!0x1:_0x57ce2b['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x459104,_0x5d349d,_0x5074b2){this['_isDeleted']=!0x1,this['_options']={..._0x459104},this['_config']={..._0x5d349d},this['_name']=_0x5d349d['name'],this['_automaticDataCollectionEnabled']=_0x5d349d['automaticDataCollectionEnabled'],this['_container']=_0x5074b2,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xf55a35){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xf55a35;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x9d799){this['_isDeleted']=_0x9d799;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x368446,_0x368939={}){let _0x14c12a=_0x368446;typeof _0x368939!='object'&&(_0x368939={'name':_0x368939});const _0x104213={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x368939},_0x29df49=_0x104213['name'];if(typeof _0x29df49!='string'||!_0x29df49)throw ge['create']('bad-app-name',{'appName':String(_0x29df49)});if(_0x14c12a||(_0x14c12a=$r()),!_0x14c12a)throw ge['create']('no-options');const _0x39c630=Le['get'](_0x29df49);if(_0x39c630){if(De(_0x14c12a,_0x39c630['options'])&&De(_0x104213,_0x39c630['config']))return _0x39c630;throw ge['create']('duplicate-app',{'appName':_0x29df49});}const _0x47daea=new Ac(_0x29df49);for(const _0x5b3b48 of gi['values']())_0x47daea['addComponent'](_0x5b3b48);const _0x3d03ec=new Il(_0x14c12a,_0x104213,_0x47daea);return Le['set'](_0x29df49,_0x3d03ec),_0x3d03ec;}function Qr(_0x4693b0=pi){const _0x37eff0=Le['get'](_0x4693b0);if(!_0x37eff0&&_0x4693b0===pi&&$r())return wl();if(!_0x37eff0)throw ge['create']('no-app',{'appName':_0x4693b0});return _0x37eff0;}function l_(){return Array['from'](Le['values']());}async function h_(_0xf1b10d){let _0x186e25=!0x1;const _0x1065d1=_0xf1b10d['name'];Le['has'](_0x1065d1)?(_0x186e25=!0x0,Le['delete'](_0x1065d1)):_i['has'](_0x1065d1)&&_0xf1b10d['decRefCount']()<=0x0&&(_i['delete'](_0x1065d1),_0x186e25=!0x0),_0x186e25&&(await Promise['all'](_0xf1b10d['container']['getProviders']()['map'](_0x21f1ee=>_0x21f1ee['delete']())),_0xf1b10d['isDeleted']=!0x0);}function me(_0x3eff94,_0x3016ea,_0x3c5a77){let _0x13e302=vl[_0x3eff94]??_0x3eff94;_0x3c5a77&&(_0x13e302+='-'+_0x3c5a77);const _0x34e83d=_0x13e302['match'](/\s|\//),_0x12713c=_0x3016ea['match'](/\s|\//);if(_0x34e83d||_0x12713c){const _0x3a2240=['Unable\x20to\x20register\x20library\x20\x22'+_0x13e302+'\x22\x20with\x20version\x20\x22'+_0x3016ea+'\x22:'];_0x34e83d&&_0x3a2240['push']('library\x20name\x20\x22'+_0x13e302+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x34e83d&&_0x12713c&&_0x3a2240['push']('and'),_0x12713c&&_0x3a2240['push']('version\x20name\x20\x22'+_0x3016ea+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3a2240['join']('\x20'));return;}et(new Me(_0x13e302+'-version',()=>({'library':_0x13e302,'version':_0x3016ea}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4f1c69,_0x3e71f3)=>{switch(_0x3e71f3){case 0x0:try{_0x4f1c69['createObjectStore'](Rt);}catch(_0x4f7961){console['warn'](_0x4f7961);}}}})['catch'](_0x2957d9=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2957d9['message']});})),ei;}async function Sl(_0x4ff1ba){try{const _0x5e86dc=(await Jr())['transaction'](Rt),_0x295ed4=await _0x5e86dc['objectStore'](Rt)['get'](Xr(_0x4ff1ba));return await _0x5e86dc['done'],_0x295ed4;}catch(_0x4f6f7a){if(_0x4f6f7a instanceof Se)re['warn'](_0x4f6f7a['message']);else{const _0x2d1ea5=ge['create']('idb-get',{'originalErrorMessage':_0x4f6f7a==null?void 0x0:_0x4f6f7a['message']});re['warn'](_0x2d1ea5['message']);}}}async function Ls(_0x2fb099,_0x2e28d2){try{const _0x39ec73=(await Jr())['transaction'](Rt,'readwrite');await _0x39ec73['objectStore'](Rt)['put'](_0x2e28d2,Xr(_0x2fb099)),await _0x39ec73['done'];}catch(_0x193cf8){if(_0x193cf8 instanceof Se)re['warn'](_0x193cf8['message']);else{const _0x35d3a1=ge['create']('idb-set',{'originalErrorMessage':_0x193cf8==null?void 0x0:_0x193cf8['message']});re['warn'](_0x35d3a1['message']);}}}function Xr(_0x1d3c4b){return _0x1d3c4b['name']+'!'+_0x1d3c4b['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x5233f9){this['container']=_0x5233f9,this['_heartbeatsCache']=null;const _0x485f6d=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x485f6d),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3e6eef=>(this['_heartbeatsCache']=_0x3e6eef,_0x3e6eef));}async['triggerHeartbeat'](){var _0x2854f2,_0x4c76c6;try{const _0x1d1491=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3b8f82=xs();if(((_0x2854f2=this['_heartbeatsCache'])==null?void 0x0:_0x2854f2['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4c76c6=this['_heartbeatsCache'])==null?void 0x0:_0x4c76c6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3b8f82||this['_heartbeatsCache']['heartbeats']['some'](_0x175a8a=>_0x175a8a['date']===_0x3b8f82))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3b8f82,'agent':_0x1d1491}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x5040e0=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5040e0,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x72c43a){re['warn'](_0x72c43a);}}async['getHeartbeatsHeader'](){var _0x3f1568;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3f1568=this['_heartbeatsCache'])==null?void 0x0:_0x3f1568['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1183df=xs(),{heartbeatsToSend:_0x2a67a5,unsentEntries:_0x1a2dca}=kl(this['_heartbeatsCache']['heartbeats']),_0x1017e5=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2a67a5}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1183df,_0x1a2dca['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1a2dca,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1017e5;}catch(_0x779027){return re['warn'](_0x779027),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x116370,_0xf41143=bl){const _0x1eda2b=[];let _0x4b3f5c=_0x116370['slice']();for(const _0x8ce78b of _0x116370){const _0xa079a2=_0x1eda2b['find'](_0x4a4aa2=>_0x4a4aa2['agent']===_0x8ce78b['agent']);if(_0xa079a2){if(_0xa079a2['dates']['push'](_0x8ce78b['date']),Fs(_0x1eda2b)>_0xf41143){_0xa079a2['dates']['pop']();break;}}else{if(_0x1eda2b['push']({'agent':_0x8ce78b['agent'],'dates':[_0x8ce78b['date']]}),Fs(_0x1eda2b)>_0xf41143){_0x1eda2b['pop']();break;}}_0x4b3f5c=_0x4b3f5c['slice'](0x1);}return{'heartbeatsToSend':_0x1eda2b,'unsentEntries':_0x4b3f5c};}class Nl{constructor(_0x177326){this['app']=_0x177326,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x261096=await Sl(this['app']);return _0x261096!=null&&_0x261096['heartbeats']?_0x261096:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x510e2f){if(await this['_canUseIndexedDBPromise']){const _0x1b6e2e=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x510e2f['lastSentHeartbeatDate']??_0x1b6e2e['lastSentHeartbeatDate'],'heartbeats':_0x510e2f['heartbeats']});}else return;}async['add'](_0x159aac){if(await this['_canUseIndexedDBPromise']){const _0x8d7bb7=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x159aac['lastSentHeartbeatDate']??_0x8d7bb7['lastSentHeartbeatDate'],'heartbeats':[..._0x8d7bb7['heartbeats'],..._0x159aac['heartbeats']]});}else return;}}function Fs(_0xe51cf2){return an(JSON['stringify']({'version':0x2,'heartbeats':_0xe51cf2}))['length'];}function Pl(_0x3dced4){if(_0x3dced4['length']===0x0)return-0x1;let _0x330f5c=0x0,_0x45e72f=_0x3dced4[0x0]['date'];for(let _0x5a162c=0x1;_0x5a162c<_0x3dced4['length'];_0x5a162c++)_0x3dced4[_0x5a162c]['date']<_0x45e72f&&(_0x45e72f=_0x3dced4[_0x5a162c]['date'],_0x330f5c=_0x5a162c);return _0x330f5c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x58ea6b){et(new Me('platform-logger',_0x26d4e6=>new Gc(_0x26d4e6),'PRIVATE')),et(new Me('heartbeat',_0x35fa3f=>new Al(_0x35fa3f),'PRIVATE')),me(fi,Ds,_0x58ea6b),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x507a3f){Zr=_0x507a3f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x5daecc){this['domStorage_']=_0x5daecc,this['prefix_']='firebase:';}['set'](_0x259d3b,_0x3b0a97){_0x3b0a97==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x259d3b)):this['domStorage_']['setItem'](this['prefixedName_'](_0x259d3b),O(_0x3b0a97));}['get'](_0x1eb5b0){const _0x5c11d6=this['domStorage_']['getItem'](this['prefixedName_'](_0x1eb5b0));return _0x5c11d6==null?null:bt(_0x5c11d6);}['remove'](_0x3941e0){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3941e0));}['prefixedName_'](_0x4b6e63){return this['prefix_']+_0x4b6e63;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5d8743,_0xe88ab4){_0xe88ab4==null?delete this['cache_'][_0x5d8743]:this['cache_'][_0x5d8743]=_0xe88ab4;}['get'](_0x31c84b){return Y(this['cache_'],_0x31c84b)?this['cache_'][_0x31c84b]:null;}['remove'](_0x369026){delete this['cache_'][_0x369026];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x40053e){try{if(typeof window<'u'&&typeof window[_0x40053e]<'u'){const _0x388236=window[_0x40053e];return _0x388236['setItem']('firebase:sentinel','cache'),_0x388236['removeItem']('firebase:sentinel'),new xl(_0x388236);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x1e621d=0x1;return function(){return _0x1e621d++;};}()),no=function(_0x214ba6){const _0x185ea5=Tc(_0x214ba6),_0x5f15fd=new Ec();_0x5f15fd['update'](_0x185ea5);const _0x2741db=_0x5f15fd['digest']();return Di['encodeByteArray'](_0x2741db);},Bt=function(..._0x2eea82){let _0x458357='';for(let _0x7d076c=0x0;_0x7d076c<_0x2eea82['length'];_0x7d076c++){const _0x122d8d=_0x2eea82[_0x7d076c];Array['isArray'](_0x122d8d)||_0x122d8d&&typeof _0x122d8d=='object'&&typeof _0x122d8d['length']=='number'?_0x458357+=Bt['apply'](null,_0x122d8d):typeof _0x122d8d=='object'?_0x458357+=O(_0x122d8d):_0x458357+=_0x122d8d,_0x458357+='\x20';}return _0x458357;};let Et=null,Vs=!0x0;const Wl=function(_0x5f11d7,_0x42df47){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x177dbc){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x31c93c=Bt['apply'](null,_0x177dbc);Et(_0x31c93c);}},Vt=function(_0x5b4663){return function(..._0x43e5e4){L(_0x5b4663,..._0x43e5e4);};},mi=function(..._0x509713){const _0x552a8f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x509713);Qe['error'](_0x552a8f);},oe=function(..._0x313d17){const _0x45bed2='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x313d17);throw Qe['error'](_0x45bed2),new Error(_0x45bed2);},U=function(..._0x5e0280){const _0x96312f='FIREBASE\x20WARNING:\x20'+Bt(..._0x5e0280);Qe['warn'](_0x96312f);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x36e21c){return typeof _0x36e21c=='number'&&(_0x36e21c!==_0x36e21c||_0x36e21c===Number['POSITIVE_INFINITY']||_0x36e21c===Number['NEGATIVE_INFINITY']);},Vl=function(_0x3a2dec){if(document['readyState']==='complete')_0x3a2dec();else{let _0x1a35d7=!0x1;const _0x21c2cf=function(){if(!document['body']){setTimeout(_0x21c2cf,Math['floor'](0xa));return;}_0x1a35d7||(_0x1a35d7=!0x0,_0x3a2dec());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x21c2cf,!0x1),window['addEventListener']('load',_0x21c2cf,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x21c2cf();}),window['attachEvent']('onload',_0x21c2cf));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x466c97,_0x16a8dc){if(_0x466c97===_0x16a8dc)return 0x0;if(_0x466c97===xe||_0x16a8dc===Ie)return-0x1;if(_0x16a8dc===xe||_0x466c97===Ie)return 0x1;{const _0x236854=Hs(_0x466c97),_0x10f692=Hs(_0x16a8dc);return _0x236854!==null?_0x10f692!==null?_0x236854-_0x10f692===0x0?_0x466c97['length']-_0x16a8dc['length']:_0x236854-_0x10f692:-0x1:_0x10f692!==null?0x1:_0x466c97<_0x16a8dc?-0x1:0x1;}},Hl=function(_0x52c544,_0x1c821b){return _0x52c544===_0x1c821b?0x0:_0x52c544<_0x1c821b?-0x1:0x1;},pt=function(_0x527672,_0x94b501){if(_0x94b501&&_0x527672 in _0x94b501)return _0x94b501[_0x527672];throw new Error('Missing\x20required\x20key\x20('+_0x527672+')\x20in\x20object:\x20'+O(_0x94b501));},Bi=function(_0x506ec1){if(typeof _0x506ec1!='object'||_0x506ec1===null)return O(_0x506ec1);const _0xca45f0=[];for(const _0x582635 in _0x506ec1)_0xca45f0['push'](_0x582635);_0xca45f0['sort']();let _0x21b502='{';for(let _0x16c6e9=0x0;_0x16c6e9<_0xca45f0['length'];_0x16c6e9++)_0x16c6e9!==0x0&&(_0x21b502+=','),_0x21b502+=O(_0xca45f0[_0x16c6e9]),_0x21b502+=':',_0x21b502+=Bi(_0x506ec1[_0xca45f0[_0x16c6e9]]);return _0x21b502+='}',_0x21b502;},io=function(_0x5bce4b,_0x755661){const _0x51c392=_0x5bce4b['length'];if(_0x51c392<=_0x755661)return[_0x5bce4b];const _0x5911f2=[];for(let _0xa9101c=0x0;_0xa9101c<_0x51c392;_0xa9101c+=_0x755661)_0xa9101c+_0x755661>_0x51c392?_0x5911f2['push'](_0x5bce4b['substring'](_0xa9101c,_0x51c392)):_0x5911f2['push'](_0x5bce4b['substring'](_0xa9101c,_0xa9101c+_0x755661));return _0x5911f2;};function x(_0xb78863,_0x264256){for(const _0x233625 in _0xb78863)_0xb78863['hasOwnProperty'](_0x233625)&&_0x264256(_0x233625,_0xb78863[_0x233625]);}const so=function(_0x5cafc8){f(!Wi(_0x5cafc8),'Invalid\x20JSON\x20number');const _0x3beee3=0xb,_0x325f08=0x34,_0x13cc25=(0x1<<_0x3beee3-0x1)-0x1;let _0x21477e,_0x5939ce,_0x278840,_0x12c0c8,_0xb6fc0a;_0x5cafc8===0x0?(_0x5939ce=0x0,_0x278840=0x0,_0x21477e=0x1/_0x5cafc8===-0x1/0x0?0x1:0x0):(_0x21477e=_0x5cafc8<0x0,_0x5cafc8=Math['abs'](_0x5cafc8),_0x5cafc8>=Math['pow'](0x2,0x1-_0x13cc25)?(_0x12c0c8=Math['min'](Math['floor'](Math['log'](_0x5cafc8)/Math['LN2']),_0x13cc25),_0x5939ce=_0x12c0c8+_0x13cc25,_0x278840=Math['round'](_0x5cafc8*Math['pow'](0x2,_0x325f08-_0x12c0c8)-Math['pow'](0x2,_0x325f08))):(_0x5939ce=0x0,_0x278840=Math['round'](_0x5cafc8/Math['pow'](0x2,0x1-_0x13cc25-_0x325f08))));const _0x37b531=[];for(_0xb6fc0a=_0x325f08;_0xb6fc0a;_0xb6fc0a-=0x1)_0x37b531['push'](_0x278840%0x2?0x1:0x0),_0x278840=Math['floor'](_0x278840/0x2);for(_0xb6fc0a=_0x3beee3;_0xb6fc0a;_0xb6fc0a-=0x1)_0x37b531['push'](_0x5939ce%0x2?0x1:0x0),_0x5939ce=Math['floor'](_0x5939ce/0x2);_0x37b531['push'](_0x21477e?0x1:0x0),_0x37b531['reverse']();const _0xa399a3=_0x37b531['join']('');let _0x1b2bf0='';for(_0xb6fc0a=0x0;_0xb6fc0a<0x40;_0xb6fc0a+=0x8){let _0x2823ed=parseInt(_0xa399a3['substr'](_0xb6fc0a,0x8),0x2)['toString'](0x10);_0x2823ed['length']===0x1&&(_0x2823ed='0'+_0x2823ed),_0x1b2bf0=_0x1b2bf0+_0x2823ed;}return _0x1b2bf0['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x24c78d,_0x1ec0db){let _0x3184eb='Unknown\x20Error';_0x24c78d==='too_big'?_0x3184eb='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x24c78d==='permission_denied'?_0x3184eb='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x24c78d==='unavailable'&&(_0x3184eb='The\x20service\x20is\x20unavailable');const _0x3cf333=new Error(_0x24c78d+'\x20at\x20'+_0x1ec0db['_path']['toString']()+':\x20'+_0x3184eb);return _0x3cf333['code']=_0x24c78d['toUpperCase'](),_0x3cf333;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x3ca8b7){if(zl['test'](_0x3ca8b7)){const _0x1eae4a=Number(_0x3ca8b7);if(_0x1eae4a>=jl&&_0x1eae4a<=Kl)return _0x1eae4a;}return null;},lt=function(_0x5625db){try{_0x5625db();}catch(_0x1f44ad){setTimeout(()=>{const _0x1ad84c=_0x1f44ad['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1ad84c),_0x1f44ad;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x283e7c,_0x3d452a){const _0x1c0f4e=setTimeout(_0x283e7c,_0x3d452a);return typeof _0x1c0f4e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1c0f4e):typeof _0x1c0f4e=='object'&&_0x1c0f4e['unref']&&_0x1c0f4e['unref'](),_0x1c0f4e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x20fb1a,_0x16feb4){this['appCheckProvider']=_0x16feb4,this['appName']=_0x20fb1a['name'],H(_0x20fb1a)&&_0x20fb1a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x20fb1a['settings']['appCheckToken']),this['appCheck']=_0x16feb4==null?void 0x0:_0x16feb4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x16feb4==null||_0x16feb4['get']()['then'](_0x161095=>this['appCheck']=_0x161095);}['getToken'](_0x297bb3){if(this['serverAppAppCheckToken']){if(_0x297bb3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x297bb3):new Promise((_0x137575,_0x508dba)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x297bb3)['then'](_0x137575,_0x508dba):_0x137575(null);},0x0);});}['addTokenChangeListener'](_0x3af786){var _0xe83e32;(_0xe83e32=this['appCheckProvider'])==null||_0xe83e32['get']()['then'](_0x384a16=>_0x384a16['addTokenListener'](_0x3af786));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1b25c3,_0x17d91e,_0x41e63a){this['appName_']=_0x1b25c3,this['firebaseOptions_']=_0x17d91e,this['authProvider_']=_0x41e63a,this['auth_']=null,this['auth_']=_0x41e63a['getImmediate']({'optional':!0x0}),this['auth_']||_0x41e63a['onInit'](_0x19584e=>this['auth_']=_0x19584e);}['getToken'](_0x294187){return this['auth_']?this['auth_']['getToken'](_0x294187)['catch'](_0x1f6c85=>_0x1f6c85&&_0x1f6c85['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1f6c85)):new Promise((_0x2c4f4c,_0x372365)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x294187)['then'](_0x2c4f4c,_0x372365):_0x2c4f4c(null);},0x0);});}['addTokenChangeListener'](_0x5678b2){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5678b2):this['authProvider_']['get']()['then'](_0x2bbe87=>_0x2bbe87['addAuthTokenListener'](_0x5678b2));}['removeTokenChangeListener'](_0x4fd3b4){this['authProvider_']['get']()['then'](_0x2839ad=>_0x2839ad['removeAuthTokenListener'](_0x4fd3b4));}['notifyForInvalidToken'](){let _0x100ff3='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x100ff3+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x100ff3+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x100ff3+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x100ff3);}}class tn{constructor(_0x1fba3b){this['accessToken']=_0x1fba3b;}['getToken'](_0x3fff33){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4ad794){_0x4ad794(this['accessToken']);}['removeTokenChangeListener'](_0x457846){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x309ec8,_0xeb9eda,_0x4cf19b,_0xd594b7,_0x41dd6c=!0x1,_0x320f29='',_0x15d3b2=!0x1,_0x33c3eb=!0x1,_0x2d66f6=null){this['secure']=_0xeb9eda,this['namespace']=_0x4cf19b,this['webSocketOnly']=_0xd594b7,this['nodeAdmin']=_0x41dd6c,this['persistenceKey']=_0x320f29,this['includeNamespaceInQueryParams']=_0x15d3b2,this['isUsingEmulator']=_0x33c3eb,this['emulatorOptions']=_0x2d66f6,this['_host']=_0x309ec8['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x309ec8)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1d215a){_0x1d215a!==this['internalHost']&&(this['internalHost']=_0x1d215a,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3430af=this['toURLString']();return this['persistenceKey']&&(_0x3430af+='<'+this['persistenceKey']+'>'),_0x3430af;}['toURLString'](){const _0x339ee4=this['secure']?'https://':'http://',_0x81c5a4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x339ee4+this['host']+'/'+_0x81c5a4;}}function Xl(_0x46bdaa){return _0x46bdaa['host']!==_0x46bdaa['internalHost']||_0x46bdaa['isCustomHost']()||_0x46bdaa['includeNamespaceInQueryParams'];}function go(_0x21bd8a,_0x29ff43,_0x2fd35e){f(typeof _0x29ff43=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2fd35e=='object','typeof\x20params\x20must\x20==\x20object');let _0x574840;if(_0x29ff43===fo)_0x574840=(_0x21bd8a['secure']?'wss://':'ws://')+_0x21bd8a['internalHost']+'/.ws?';else{if(_0x29ff43===po)_0x574840=(_0x21bd8a['secure']?'https://':'http://')+_0x21bd8a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x29ff43);}Xl(_0x21bd8a)&&(_0x2fd35e['ns']=_0x21bd8a['namespace']);const _0xa73bf4=[];return x(_0x2fd35e,(_0x61cb5b,_0xb7df13)=>{_0xa73bf4['push'](_0x61cb5b+'='+_0xb7df13);}),_0x574840+_0xa73bf4['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x3ac5da,_0x256d22=0x1){Y(this['counters_'],_0x3ac5da)||(this['counters_'][_0x3ac5da]=0x0),this['counters_'][_0x3ac5da]+=_0x256d22;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5a725f){const _0x3701d3=_0x5a725f['toString']();return ti[_0x3701d3]||(ti[_0x3701d3]=new Zl()),ti[_0x3701d3];}function eh(_0x131682,_0x394ef8){const _0x14c5a2=_0x131682['toString']();return ni[_0x14c5a2]||(ni[_0x14c5a2]=_0x394ef8()),ni[_0x14c5a2];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x1e0145){this['onMessage_']=_0x1e0145,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x56314c,_0x731853){this['closeAfterResponse']=_0x56314c,this['onClose']=_0x731853,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4bd09f,_0x5b39c9){for(this['pendingResponses'][_0x4bd09f]=_0x5b39c9;this['pendingResponses'][this['currentResponseNum']];){const _0x1ea1c8=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1e09cb=0x0;_0x1e09cb<_0x1ea1c8['length'];++_0x1e09cb)_0x1ea1c8[_0x1e09cb]&&lt(()=>{this['onMessage_'](_0x1ea1c8[_0x1e09cb]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x465dc1,_0xfcdc0a,_0x9a9a68,_0xaf7a4,_0x502433,_0x2b6e43,_0x3916bb){this['connId']=_0x465dc1,this['repoInfo']=_0xfcdc0a,this['applicationId']=_0x9a9a68,this['appCheckToken']=_0xaf7a4,this['authToken']=_0x502433,this['transportSessionId']=_0x2b6e43,this['lastSessionId']=_0x3916bb,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x465dc1),this['stats_']=Hi(_0xfcdc0a),this['urlFn']=_0xcb4054=>(this['appCheckToken']&&(_0xcb4054[yi]=this['appCheckToken']),go(_0xfcdc0a,po,_0xcb4054));}['open'](_0x5a3bb6,_0x394ef7){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x394ef7,this['myPacketOrderer']=new th(_0x5a3bb6),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x4ea0fe)=>{const [_0x9fb360,_0x5334ce,_0x1ca937,_0x52726f,_0x6311f7]=_0x4ea0fe;if(this['incrementIncomingBytes_'](_0x4ea0fe),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x9fb360===$s)this['id']=_0x5334ce,this['password']=_0x1ca937;else{if(_0x9fb360===nh)_0x5334ce?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5334ce,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x9fb360);}}},(..._0x63406f)=>{const [_0x42e70e,_0x4447da]=_0x63406f;this['incrementIncomingBytes_'](_0x63406f),this['myPacketOrderer']['handleResponse'](_0x42e70e,_0x4447da);},()=>{this['onClosed_']();},this['urlFn']);const _0x2cef8d={};_0x2cef8d[$s]='t',_0x2cef8d[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2cef8d[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2cef8d[ro]=Vi,this['transportSessionId']&&(_0x2cef8d[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x2cef8d[ho]=this['lastSessionId']),this['applicationId']&&(_0x2cef8d[uo]=this['applicationId']),this['appCheckToken']&&(_0x2cef8d[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2cef8d[ao]=co);const _0x18b0dd=this['urlFn'](_0x2cef8d);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x18b0dd),this['scriptTagHolder']['addTag'](_0x18b0dd,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3038a3){const _0x520c85=O(_0x3038a3);this['bytesSent']+=_0x520c85['length'],this['stats_']['incrementCounter']('bytes_sent',_0x520c85['length']);const _0x1847cf=Br(_0x520c85),_0x3bb80e=io(_0x1847cf,hh);for(let _0x19ea42=0x0;_0x19ea42<_0x3bb80e['length'];_0x19ea42++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3bb80e['length'],_0x3bb80e[_0x19ea42]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x45c1c4,_0x4db152){this['myDisconnFrame']=document['createElement']('iframe');const _0x2f3230={};_0x2f3230[lh]='t',_0x2f3230[mo]=_0x45c1c4,_0x2f3230[yo]=_0x4db152,this['myDisconnFrame']['src']=this['urlFn'](_0x2f3230),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2ee207){const _0xa11c39=O(_0x2ee207)['length'];this['bytesReceived']+=_0xa11c39,this['stats_']['incrementCounter']('bytes_received',_0xa11c39);}}class $i{constructor(_0x92e06a,_0x5212b4,_0xdec852,_0x3798fa){this['onDisconnect']=_0xdec852,this['urlFn']=_0x3798fa,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x92e06a,window[sh+this['uniqueCallbackIdentifier']]=_0x5212b4,this['myIFrame']=$i['createIFrame_']();let _0x45577e='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x45577e='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2c2953='<html><body>'+_0x45577e+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2c2953),this['myIFrame']['doc']['close']();}catch(_0x5c938e){L('frame\x20writing\x20exception'),_0x5c938e['stack']&&L(_0x5c938e['stack']),L(_0x5c938e);}}}static['createIFrame_'](){const _0x59f5b2=document['createElement']('iframe');if(_0x59f5b2['style']['display']='none',document['body']){document['body']['appendChild'](_0x59f5b2);try{_0x59f5b2['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x553a68=document['domain'];_0x59f5b2['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x553a68+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x59f5b2['contentDocument']?_0x59f5b2['doc']=_0x59f5b2['contentDocument']:_0x59f5b2['contentWindow']?_0x59f5b2['doc']=_0x59f5b2['contentWindow']['document']:_0x59f5b2['document']&&(_0x59f5b2['doc']=_0x59f5b2['document']),_0x59f5b2;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x22024a=this['onDisconnect'];_0x22024a&&(this['onDisconnect']=null,_0x22024a());}['startLongPoll'](_0x1ccdcb,_0x3e5c91){for(this['myID']=_0x1ccdcb,this['myPW']=_0x3e5c91,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x42b8e7={};_0x42b8e7[mo]=this['myID'],_0x42b8e7[yo]=this['myPW'],_0x42b8e7[vo]=this['currentSerial'];let _0xa164d6=this['urlFn'](_0x42b8e7),_0x2f26ee='',_0x3b4a35=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2f26ee['length']<=Eo;){const _0x23ef01=this['pendingSegs']['shift']();_0x2f26ee=_0x2f26ee+'&'+oh+_0x3b4a35+'='+_0x23ef01['seg']+'&'+ah+_0x3b4a35+'='+_0x23ef01['ts']+'&'+ch+_0x3b4a35+'='+_0x23ef01['d'],_0x3b4a35++;}return _0xa164d6=_0xa164d6+_0x2f26ee,this['addLongPollTag_'](_0xa164d6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x25829f,_0x23e263,_0x32e993){this['pendingSegs']['push']({'seg':_0x25829f,'ts':_0x23e263,'d':_0x32e993}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xdb006b,_0x29e4f5){this['outstandingRequests']['add'](_0x29e4f5);const _0x671726=()=>{this['outstandingRequests']['delete'](_0x29e4f5),this['newRequest_']();},_0x31b3c5=setTimeout(_0x671726,Math['floor'](uh)),_0x40551a=()=>{clearTimeout(_0x31b3c5),_0x671726();};this['addTag'](_0xdb006b,_0x40551a);}['addTag'](_0x5ccac2,_0x163dd8){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4801d8=this['myIFrame']['doc']['createElement']('script');_0x4801d8['type']='text/javascript',_0x4801d8['async']=!0x0,_0x4801d8['src']=_0x5ccac2,_0x4801d8['onload']=_0x4801d8['onreadystatechange']=function(){const _0x6b0684=_0x4801d8['readyState'];(!_0x6b0684||_0x6b0684==='loaded'||_0x6b0684==='complete')&&(_0x4801d8['onload']=_0x4801d8['onreadystatechange']=null,_0x4801d8['parentNode']&&_0x4801d8['parentNode']['removeChild'](_0x4801d8),_0x163dd8());},_0x4801d8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5ccac2),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4801d8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x48730e,_0x240eaa,_0x1bd88d,_0x1df56a,_0x65f783,_0x31fd19,_0x1eb543){this['connId']=_0x48730e,this['applicationId']=_0x1bd88d,this['appCheckToken']=_0x1df56a,this['authToken']=_0x65f783,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x240eaa),this['connURL']=G['connectionURL_'](_0x240eaa,_0x31fd19,_0x1eb543,_0x1df56a,_0x1bd88d),this['nodeAdmin']=_0x240eaa['nodeAdmin'];}static['connectionURL_'](_0x257638,_0xf3659,_0x599d18,_0x4aeb90,_0x5ee10a){const _0x3b2db1={};return _0x3b2db1[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3b2db1[ao]=co),_0xf3659&&(_0x3b2db1[oo]=_0xf3659),_0x599d18&&(_0x3b2db1[ho]=_0x599d18),_0x4aeb90&&(_0x3b2db1[yi]=_0x4aeb90),_0x5ee10a&&(_0x3b2db1[uo]=_0x5ee10a),go(_0x257638,fo,_0x3b2db1);}['open'](_0x220ad3,_0x270f84){this['onDisconnect']=_0x270f84,this['onMessage']=_0x220ad3,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x50beff;dc(),this['mySock']=new hn(this['connURL'],[],_0x50beff);}catch(_0x34f4bb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2cd11c=_0x34f4bb['message']||_0x34f4bb['data'];_0x2cd11c&&this['log_'](_0x2cd11c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x45cb0e=>{this['handleIncomingFrame'](_0x45cb0e);},this['mySock']['onerror']=_0x2aaddb=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2f22f8=_0x2aaddb['message']||_0x2aaddb['data'];_0x2f22f8&&this['log_'](_0x2f22f8),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x206014=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x32a83a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x421a10=navigator['userAgent']['match'](_0x32a83a);_0x421a10&&_0x421a10['length']>0x1&&parseFloat(_0x421a10[0x1])<4.4&&(_0x206014=!0x0);}return!_0x206014&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1af787){if(this['frames']['push'](_0x1af787),this['frames']['length']===this['totalFrames']){const _0x59480d=this['frames']['join']('');this['frames']=null;const _0x57b372=bt(_0x59480d);this['onMessage'](_0x57b372);}}['handleNewFrameCount_'](_0x18f46e){this['totalFrames']=_0x18f46e,this['frames']=[];}['extractFrameCount_'](_0x3c1f5c){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3c1f5c['length']<=0x6){const _0x4b111c=Number(_0x3c1f5c);if(!isNaN(_0x4b111c))return this['handleNewFrameCount_'](_0x4b111c),null;}return this['handleNewFrameCount_'](0x1),_0x3c1f5c;}['handleIncomingFrame'](_0x42d5ad){if(this['mySock']===null)return;const _0x23fe53=_0x42d5ad['data'];if(this['bytesReceived']+=_0x23fe53['length'],this['stats_']['incrementCounter']('bytes_received',_0x23fe53['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x23fe53);else{const _0x18b2ba=this['extractFrameCount_'](_0x23fe53);_0x18b2ba!==null&&this['appendFrame_'](_0x18b2ba);}}['send'](_0x4adbe4){this['resetKeepAlive']();const _0x900074=O(_0x4adbe4);this['bytesSent']+=_0x900074['length'],this['stats_']['incrementCounter']('bytes_sent',_0x900074['length']);const _0x234c0d=io(_0x900074,fh);_0x234c0d['length']>0x1&&this['sendString_'](String(_0x234c0d['length']));for(let _0x301afa=0x0;_0x301afa<_0x234c0d['length'];_0x301afa++)this['sendString_'](_0x234c0d[_0x301afa]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x44a995){try{this['mySock']['send'](_0x44a995);}catch(_0x3bd704){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3bd704['message']||_0x3bd704['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x304fa0){this['initTransports_'](_0x304fa0);}['initTransports_'](_0x3c6fdc){const _0x2088d8=G&&G['isAvailable']();let _0x3ec7c2=_0x2088d8&&!G['previouslyFailed']();if(_0x3c6fdc['webSocketOnly']&&(_0x2088d8||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3ec7c2=!0x0),_0x3ec7c2)this['transports_']=[G];else{const _0xcefc9d=this['transports_']=[];for(const _0x5c6b4f of At['ALL_TRANSPORTS'])_0x5c6b4f&&_0x5c6b4f['isAvailable']()&&_0xcefc9d['push'](_0x5c6b4f);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x34813d,_0x40e0fe,_0x36710a,_0x2185a1,_0x40db08,_0x3fa7dc,_0xede848,_0x21632d,_0x626071,_0x5d7bd9){this['id']=_0x34813d,this['repoInfo_']=_0x40e0fe,this['applicationId_']=_0x36710a,this['appCheckToken_']=_0x2185a1,this['authToken_']=_0x40db08,this['onMessage_']=_0x3fa7dc,this['onReady_']=_0xede848,this['onDisconnect_']=_0x21632d,this['onKill_']=_0x626071,this['lastSessionId']=_0x5d7bd9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x40e0fe),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x382cb9=this['transportManager_']['initialTransport']();this['conn_']=new _0x382cb9(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x382cb9['responsesRequiredToBeHealthy']||0x0;const _0x5682f2=this['connReceiver_'](this['conn_']),_0x16016a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5682f2,_0x16016a);},Math['floor'](0x0));const _0xef52ca=_0x382cb9['healthyTimeout']||0x0;_0xef52ca>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xef52ca)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xff2137){return _0x5a3317=>{_0xff2137===this['conn_']?this['onConnectionLost_'](_0x5a3317):_0xff2137===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xbd3888){return _0x2e4bff=>{this['state_']!==0x2&&(_0xbd3888===this['rx_']?this['onPrimaryMessageReceived_'](_0x2e4bff):_0xbd3888===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2e4bff):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5e4aa3){const _0x55a203={'t':'d','d':_0x5e4aa3};this['sendData_'](_0x55a203);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x40c32b){if(ii in _0x40c32b){const _0x2bc643=_0x40c32b[ii];_0x2bc643===js?this['upgradeIfSecondaryHealthy_']():_0x2bc643===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2bc643===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x499f9f){const _0x3bdfb5=pt('t',_0x499f9f),_0x27a989=pt('d',_0x499f9f);if(_0x3bdfb5==='c')this['onSecondaryControl_'](_0x27a989);else{if(_0x3bdfb5==='d')this['pendingDataMessages']['push'](_0x27a989);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3bdfb5);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x24f612){const _0x413202=pt('t',_0x24f612),_0x28c618=pt('d',_0x24f612);_0x413202==='c'?this['onControl_'](_0x28c618):_0x413202==='d'&&this['onDataMessage_'](_0x28c618);}['onDataMessage_'](_0x204b6d){this['onPrimaryResponse_'](),this['onMessage_'](_0x204b6d);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x53f6e1){const _0x4987f7=pt(ii,_0x53f6e1);if(Gs in _0x53f6e1){const _0x24d1f4=_0x53f6e1[Gs];if(_0x4987f7===Ih){const _0x4ebf60={..._0x24d1f4};this['repoInfo_']['isUsingEmulator']&&(_0x4ebf60['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4ebf60);}else{if(_0x4987f7===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x31a364=0x0;_0x31a364<this['pendingDataMessages']['length'];++_0x31a364)this['onDataMessage_'](this['pendingDataMessages'][_0x31a364]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4987f7===vh?this['onConnectionShutdown_'](_0x24d1f4):_0x4987f7===qs?this['onReset_'](_0x24d1f4):_0x4987f7===Eh?mi('Server\x20Error:\x20'+_0x24d1f4):_0x4987f7===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x4987f7);}}}['onHandshake_'](_0x32ff14){const _0x2a5a1c=_0x32ff14['ts'],_0x2f7be2=_0x32ff14['v'],_0x36e158=_0x32ff14['h'];this['sessionId']=_0x32ff14['s'],this['repoInfo_']['host']=_0x36e158,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2a5a1c),Vi!==_0x2f7be2&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x42e6a4=this['transportManager_']['upgradeTransport']();_0x42e6a4&&this['startUpgrade_'](_0x42e6a4);}['startUpgrade_'](_0x1b76a7){this['secondaryConn_']=new _0x1b76a7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1b76a7['responsesRequiredToBeHealthy']||0x0;const _0x4fb6e9=this['connReceiver_'](this['secondaryConn_']),_0x4abc4c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4fb6e9,_0x4abc4c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x31cd5e){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x31cd5e),this['repoInfo_']['host']=_0x31cd5e,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x10cda2,_0x314c7e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x10cda2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x314c7e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x21a458=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x21a458||this['rx_']===_0x21a458)&&this['close']();}['onConnectionLost_'](_0xdc879b){this['conn_']=null,!_0xdc879b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x13c65f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x13c65f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4b2718){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4b2718);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x2123fb,_0x57d9aa,_0x3fb3da,_0x1c7fa0){}['merge'](_0x119391,_0x5693b2,_0x33590a,_0x420cab){}['refreshAuthToken'](_0x5a9187){}['refreshAppCheckToken'](_0x2868e4){}['onDisconnectPut'](_0x13f066,_0x1a0215,_0x3c1953){}['onDisconnectMerge'](_0x4d99e3,_0x3edff9,_0x2f76df){}['onDisconnectCancel'](_0x57d350,_0x5a9db5){}['reportStats'](_0x4e7435){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x1eff43){this['allowedEvents_']=_0x1eff43,this['listeners_']={},f(Array['isArray'](_0x1eff43)&&_0x1eff43['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x7ea472,..._0x30e8e8){if(Array['isArray'](this['listeners_'][_0x7ea472])){const _0x31eb91=[...this['listeners_'][_0x7ea472]];for(let _0x2a415b=0x0;_0x2a415b<_0x31eb91['length'];_0x2a415b++)_0x31eb91[_0x2a415b]['callback']['apply'](_0x31eb91[_0x2a415b]['context'],_0x30e8e8);}}['on'](_0x187a9d,_0x121dfb,_0x32ca25){this['validateEventType_'](_0x187a9d),this['listeners_'][_0x187a9d]=this['listeners_'][_0x187a9d]||[],this['listeners_'][_0x187a9d]['push']({'callback':_0x121dfb,'context':_0x32ca25});const _0x1f2b84=this['getInitialEvent'](_0x187a9d);_0x1f2b84&&_0x121dfb['apply'](_0x32ca25,_0x1f2b84);}['off'](_0x4b349d,_0x52a274,_0x167968){this['validateEventType_'](_0x4b349d);const _0x30e18d=this['listeners_'][_0x4b349d]||[];for(let _0x4ae20e=0x0;_0x4ae20e<_0x30e18d['length'];_0x4ae20e++)if(_0x30e18d[_0x4ae20e]['callback']===_0x52a274&&(!_0x167968||_0x167968===_0x30e18d[_0x4ae20e]['context'])){_0x30e18d['splice'](_0x4ae20e,0x1);return;}}['validateEventType_'](_0x3e9ce9){f(this['allowedEvents_']['find'](_0x2c500b=>_0x2c500b===_0x3e9ce9),'Unknown\x20event:\x20'+_0x3e9ce9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x247737){return f(_0x247737==='online','Unknown\x20event\x20type:\x20'+_0x247737),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x2abb1d,_0x457870){if(_0x457870===void 0x0){this['pieces_']=_0x2abb1d['split']('/');let _0x3a825f=0x0;for(let _0x9e32a=0x0;_0x9e32a<this['pieces_']['length'];_0x9e32a++)this['pieces_'][_0x9e32a]['length']>0x0&&(this['pieces_'][_0x3a825f]=this['pieces_'][_0x9e32a],_0x3a825f++);this['pieces_']['length']=_0x3a825f,this['pieceNum_']=0x0;}else this['pieces_']=_0x2abb1d,this['pieceNum_']=_0x457870;}['toString'](){let _0x40a3df='';for(let _0x4bfdec=this['pieceNum_'];_0x4bfdec<this['pieces_']['length'];_0x4bfdec++)this['pieces_'][_0x4bfdec]!==''&&(_0x40a3df+='/'+this['pieces_'][_0x4bfdec]);return _0x40a3df||'/';}}function w(){return new C('');}function y(_0x22fc1a){return _0x22fc1a['pieceNum_']>=_0x22fc1a['pieces_']['length']?null:_0x22fc1a['pieces_'][_0x22fc1a['pieceNum_']];}function we(_0x4c62e8){return _0x4c62e8['pieces_']['length']-_0x4c62e8['pieceNum_'];}function b(_0xaba383){let _0x27e718=_0xaba383['pieceNum_'];return _0x27e718<_0xaba383['pieces_']['length']&&_0x27e718++,new C(_0xaba383['pieces_'],_0x27e718);}function Gi(_0x351468){return _0x351468['pieceNum_']<_0x351468['pieces_']['length']?_0x351468['pieces_'][_0x351468['pieces_']['length']-0x1]:null;}function Ch(_0x186b59){let _0x4126b3='';for(let _0x1cc8fa=_0x186b59['pieceNum_'];_0x1cc8fa<_0x186b59['pieces_']['length'];_0x1cc8fa++)_0x186b59['pieces_'][_0x1cc8fa]!==''&&(_0x4126b3+='/'+encodeURIComponent(String(_0x186b59['pieces_'][_0x1cc8fa])));return _0x4126b3||'/';}function kt(_0x45d2e1,_0x4ad26b=0x0){return _0x45d2e1['pieces_']['slice'](_0x45d2e1['pieceNum_']+_0x4ad26b);}function To(_0x384d6e){if(_0x384d6e['pieceNum_']>=_0x384d6e['pieces_']['length'])return null;const _0x310a23=[];for(let _0x4348ed=_0x384d6e['pieceNum_'];_0x4348ed<_0x384d6e['pieces_']['length']-0x1;_0x4348ed++)_0x310a23['push'](_0x384d6e['pieces_'][_0x4348ed]);return new C(_0x310a23,0x0);}function A(_0x46ad23,_0x1965b0){const _0x30020b=[];for(let _0x673ca3=_0x46ad23['pieceNum_'];_0x673ca3<_0x46ad23['pieces_']['length'];_0x673ca3++)_0x30020b['push'](_0x46ad23['pieces_'][_0x673ca3]);if(_0x1965b0 instanceof C){for(let _0x296ad1=_0x1965b0['pieceNum_'];_0x296ad1<_0x1965b0['pieces_']['length'];_0x296ad1++)_0x30020b['push'](_0x1965b0['pieces_'][_0x296ad1]);}else{const _0x2198ee=_0x1965b0['split']('/');for(let _0x28770a=0x0;_0x28770a<_0x2198ee['length'];_0x28770a++)_0x2198ee[_0x28770a]['length']>0x0&&_0x30020b['push'](_0x2198ee[_0x28770a]);}return new C(_0x30020b,0x0);}function v(_0x39b0bd){return _0x39b0bd['pieceNum_']>=_0x39b0bd['pieces_']['length'];}function F(_0x2ce0e7,_0x231777){const _0x59d244=y(_0x2ce0e7),_0x538d2e=y(_0x231777);if(_0x59d244===null)return _0x231777;if(_0x59d244===_0x538d2e)return F(b(_0x2ce0e7),b(_0x231777));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x231777+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2ce0e7+')');}function Th(_0x2f27cc,_0x1b6538){const _0x5dd8e3=kt(_0x2f27cc,0x0),_0x483932=kt(_0x1b6538,0x0);for(let _0x308340=0x0;_0x308340<_0x5dd8e3['length']&&_0x308340<_0x483932['length'];_0x308340++){const _0x371af4=He(_0x5dd8e3[_0x308340],_0x483932[_0x308340]);if(_0x371af4!==0x0)return _0x371af4;}return _0x5dd8e3['length']===_0x483932['length']?0x0:_0x5dd8e3['length']<_0x483932['length']?-0x1:0x1;}function qi(_0x17ed74,_0x31773d){if(we(_0x17ed74)!==we(_0x31773d))return!0x1;for(let _0x2b394a=_0x17ed74['pieceNum_'],_0x473128=_0x31773d['pieceNum_'];_0x2b394a<=_0x17ed74['pieces_']['length'];_0x2b394a++,_0x473128++)if(_0x17ed74['pieces_'][_0x2b394a]!==_0x31773d['pieces_'][_0x473128])return!0x1;return!0x0;}function $(_0x40b7d7,_0x5bc2af){let _0xbffd95=_0x40b7d7['pieceNum_'],_0x21de81=_0x5bc2af['pieceNum_'];if(we(_0x40b7d7)>we(_0x5bc2af))return!0x1;for(;_0xbffd95<_0x40b7d7['pieces_']['length'];){if(_0x40b7d7['pieces_'][_0xbffd95]!==_0x5bc2af['pieces_'][_0x21de81])return!0x1;++_0xbffd95,++_0x21de81;}return!0x0;}class Sh{constructor(_0x9aac9b,_0x16d9e5){this['errorPrefix_']=_0x16d9e5,this['parts_']=kt(_0x9aac9b,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1c8ed1=0x0;_0x1c8ed1<this['parts_']['length'];_0x1c8ed1++)this['byteLength_']+=Pn(this['parts_'][_0x1c8ed1]);So(this);}}function bh(_0x72d75d,_0x272c73){_0x72d75d['parts_']['length']>0x0&&(_0x72d75d['byteLength_']+=0x1),_0x72d75d['parts_']['push'](_0x272c73),_0x72d75d['byteLength_']+=Pn(_0x272c73),So(_0x72d75d);}function Rh(_0x2be177){const _0x218be2=_0x2be177['parts_']['pop']();_0x2be177['byteLength_']-=Pn(_0x218be2),_0x2be177['parts_']['length']>0x0&&(_0x2be177['byteLength_']-=0x1);}function So(_0x4cd50b){if(_0x4cd50b['byteLength_']>Js)throw new Error(_0x4cd50b['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4cd50b['byteLength_']+').');if(_0x4cd50b['parts_']['length']>Qs)throw new Error(_0x4cd50b['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4cd50b));}function Ne(_0x553451){return _0x553451['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x553451['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x5ada3d,_0x496dda;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x496dda='visibilitychange',_0x5ada3d='hidden'):typeof document['mozHidden']<'u'?(_0x496dda='mozvisibilitychange',_0x5ada3d='mozHidden'):typeof document['msHidden']<'u'?(_0x496dda='msvisibilitychange',_0x5ada3d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x496dda='webkitvisibilitychange',_0x5ada3d='webkitHidden')),this['visible_']=!0x0,_0x496dda&&document['addEventListener'](_0x496dda,()=>{const _0x1d8aa0=!document[_0x5ada3d];_0x1d8aa0!==this['visible_']&&(this['visible_']=_0x1d8aa0,this['trigger']('visible',_0x1d8aa0));},!0x1);}['getInitialEvent'](_0x2851fa){return f(_0x2851fa==='visible','Unknown\x20event\x20type:\x20'+_0x2851fa),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x16b3a9,_0x4db611,_0x40458b,_0x320926,_0x3e6f8e,_0x2dc63d,_0x23c877,_0x262acb){if(super(),this['repoInfo_']=_0x16b3a9,this['applicationId_']=_0x4db611,this['onDataUpdate_']=_0x40458b,this['onConnectStatus_']=_0x320926,this['onServerInfoUpdate_']=_0x3e6f8e,this['authTokenProvider_']=_0x2dc63d,this['appCheckTokenProvider_']=_0x23c877,this['authOverride_']=_0x262acb,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x262acb)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x16b3a9['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x20dcd8,_0x116ff8,_0x3ee732){const _0xd368f4=++this['requestNumber_'],_0x475a0c={'r':_0xd368f4,'a':_0x20dcd8,'b':_0x116ff8};this['log_'](O(_0x475a0c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x475a0c),_0x3ee732&&(this['requestCBHash_'][_0xd368f4]=_0x3ee732);}['get'](_0x3cc5f5){this['initConnection_']();const _0x1083a8=new Ve(),_0x495547={'action':'g','request':{'p':_0x3cc5f5['_path']['toString'](),'q':_0x3cc5f5['_queryObject']},'onComplete':_0x268b58=>{const _0x34d4e6=_0x268b58['d'];_0x268b58['s']==='ok'?_0x1083a8['resolve'](_0x34d4e6):_0x1083a8['reject'](_0x34d4e6);}};this['outstandingGets_']['push'](_0x495547),this['outstandingGetCount_']++;const _0x44f316=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x44f316),_0x1083a8['promise'];}['listen'](_0x246fe2,_0x654eae,_0x4af95f,_0x32c2c4){this['initConnection_']();const _0x3c431c=_0x246fe2['_queryIdentifier'],_0x26bcce=_0x246fe2['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x26bcce+'\x20'+_0x3c431c),this['listens']['has'](_0x26bcce)||this['listens']['set'](_0x26bcce,new Map()),f(_0x246fe2['_queryParams']['isDefault']()||!_0x246fe2['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x26bcce)['has'](_0x3c431c),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2fc000={'onComplete':_0x32c2c4,'hashFn':_0x654eae,'query':_0x246fe2,'tag':_0x4af95f};this['listens']['get'](_0x26bcce)['set'](_0x3c431c,_0x2fc000),this['connected_']&&this['sendListen_'](_0x2fc000);}['sendGet_'](_0x519915){const _0x52b468=this['outstandingGets_'][_0x519915];this['sendRequest']('g',_0x52b468['request'],_0x9d0b1f=>{delete this['outstandingGets_'][_0x519915],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x52b468['onComplete']&&_0x52b468['onComplete'](_0x9d0b1f);});}['sendListen_'](_0x59230f){const _0xb0899d=_0x59230f['query'],_0x12b9cf=_0xb0899d['_path']['toString'](),_0x219854=_0xb0899d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x12b9cf+'\x20for\x20'+_0x219854);const _0x200c99={'p':_0x12b9cf},_0xd01af='q';_0x59230f['tag']&&(_0x200c99['q']=_0xb0899d['_queryObject'],_0x200c99['t']=_0x59230f['tag']),_0x200c99['h']=_0x59230f['hashFn'](),this['sendRequest'](_0xd01af,_0x200c99,_0xb5031a=>{const _0x347210=_0xb5031a['d'],_0x4e21be=_0xb5031a['s'];ie['warnOnListenWarnings_'](_0x347210,_0xb0899d),(this['listens']['get'](_0x12b9cf)&&this['listens']['get'](_0x12b9cf)['get'](_0x219854))===_0x59230f&&(this['log_']('listen\x20response',_0xb5031a),_0x4e21be!=='ok'&&this['removeListen_'](_0x12b9cf,_0x219854),_0x59230f['onComplete']&&_0x59230f['onComplete'](_0x4e21be,_0x347210));});}static['warnOnListenWarnings_'](_0x50a57c,_0x2b1aca){if(_0x50a57c&&typeof _0x50a57c=='object'&&Y(_0x50a57c,'w')){const _0x3742b2=Oe(_0x50a57c,'w');if(Array['isArray'](_0x3742b2)&&~_0x3742b2['indexOf']('no_index')){const _0xaab0f6='\x22.indexOn\x22:\x20\x22'+_0x2b1aca['_queryParams']['getIndex']()['toString']()+'\x22',_0x3e7363=_0x2b1aca['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0xaab0f6+'\x20at\x20'+_0x3e7363+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xad0d20){this['authToken_']=_0xad0d20,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xad0d20);}['reduceReconnectDelayIfAdminCredential_'](_0x2713a7){(_0x2713a7&&_0x2713a7['length']===0x28||vc(_0x2713a7))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4755a7){this['appCheckToken_']=_0x4755a7,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2a3b45=this['authToken_'],_0x821e24=yc(_0x2a3b45)?'auth':'gauth',_0x41c30f={'cred':_0x2a3b45};this['authOverride_']===null?_0x41c30f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x41c30f['authvar']=this['authOverride_']),this['sendRequest'](_0x821e24,_0x41c30f,_0x32be23=>{const _0x11f15d=_0x32be23['s'],_0x5a6ac9=_0x32be23['d']||'error';this['authToken_']===_0x2a3b45&&(_0x11f15d==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x11f15d,_0x5a6ac9));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x388866=>{const _0x2e1582=_0x388866['s'],_0x1658b5=_0x388866['d']||'error';_0x2e1582==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2e1582,_0x1658b5);});}['unlisten'](_0xa03672,_0x45c2fb){const _0x1d2476=_0xa03672['_path']['toString'](),_0x3e3ad2=_0xa03672['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1d2476+'\x20'+_0x3e3ad2),f(_0xa03672['_queryParams']['isDefault']()||!_0xa03672['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1d2476,_0x3e3ad2)&&this['connected_']&&this['sendUnlisten_'](_0x1d2476,_0x3e3ad2,_0xa03672['_queryObject'],_0x45c2fb);}['sendUnlisten_'](_0x492f64,_0x4a5a07,_0x23579d,_0x22ea3f){this['log_']('Unlisten\x20on\x20'+_0x492f64+'\x20for\x20'+_0x4a5a07);const _0x38e4b0={'p':_0x492f64},_0x3b4405='n';_0x22ea3f&&(_0x38e4b0['q']=_0x23579d,_0x38e4b0['t']=_0x22ea3f),this['sendRequest'](_0x3b4405,_0x38e4b0);}['onDisconnectPut'](_0x48928d,_0x5302a1,_0x128630){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x48928d,_0x5302a1,_0x128630):this['onDisconnectRequestQueue_']['push']({'pathString':_0x48928d,'action':'o','data':_0x5302a1,'onComplete':_0x128630});}['onDisconnectMerge'](_0x310ee4,_0x21fa99,_0x3067c7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x310ee4,_0x21fa99,_0x3067c7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x310ee4,'action':'om','data':_0x21fa99,'onComplete':_0x3067c7});}['onDisconnectCancel'](_0x49f04f,_0x29b92b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x49f04f,null,_0x29b92b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x49f04f,'action':'oc','data':null,'onComplete':_0x29b92b});}['sendOnDisconnect_'](_0x4b4af2,_0x1ebc67,_0x59a0ea,_0x2f704b){const _0x213bb5={'p':_0x1ebc67,'d':_0x59a0ea};this['log_']('onDisconnect\x20'+_0x4b4af2,_0x213bb5),this['sendRequest'](_0x4b4af2,_0x213bb5,_0x4da6f2=>{_0x2f704b&&setTimeout(()=>{_0x2f704b(_0x4da6f2['s'],_0x4da6f2['d']);},Math['floor'](0x0));});}['put'](_0x2346dc,_0x51b288,_0x3b8a9d,_0x478504){this['putInternal']('p',_0x2346dc,_0x51b288,_0x3b8a9d,_0x478504);}['merge'](_0x43e333,_0x5d87f2,_0x295bc5,_0x423dd3){this['putInternal']('m',_0x43e333,_0x5d87f2,_0x295bc5,_0x423dd3);}['putInternal'](_0x86b290,_0x34c442,_0x20256d,_0x376c08,_0x2d27c4){this['initConnection_']();const _0x3ee084={'p':_0x34c442,'d':_0x20256d};_0x2d27c4!==void 0x0&&(_0x3ee084['h']=_0x2d27c4),this['outstandingPuts_']['push']({'action':_0x86b290,'request':_0x3ee084,'onComplete':_0x376c08}),this['outstandingPutCount_']++;const _0x285db0=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x285db0):this['log_']('Buffering\x20put:\x20'+_0x34c442);}['sendPut_'](_0x195f43){const _0xe1b130=this['outstandingPuts_'][_0x195f43]['action'],_0x43d39d=this['outstandingPuts_'][_0x195f43]['request'],_0x38a7c0=this['outstandingPuts_'][_0x195f43]['onComplete'];this['outstandingPuts_'][_0x195f43]['queued']=this['connected_'],this['sendRequest'](_0xe1b130,_0x43d39d,_0x15b1d9=>{this['log_'](_0xe1b130+'\x20response',_0x15b1d9),delete this['outstandingPuts_'][_0x195f43],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x38a7c0&&_0x38a7c0(_0x15b1d9['s'],_0x15b1d9['d']);});}['reportStats'](_0x4f2c6c){if(this['connected_']){const _0x31e7c1={'c':_0x4f2c6c};this['log_']('reportStats',_0x31e7c1),this['sendRequest']('s',_0x31e7c1,_0x2288cb=>{if(_0x2288cb['s']!=='ok'){const _0x5addc7=_0x2288cb['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5addc7);}});}}['onDataMessage_'](_0xc0db72){if('r'in _0xc0db72){this['log_']('from\x20server:\x20'+O(_0xc0db72));const _0x28af6b=_0xc0db72['r'],_0x4b3e9a=this['requestCBHash_'][_0x28af6b];_0x4b3e9a&&(delete this['requestCBHash_'][_0x28af6b],_0x4b3e9a(_0xc0db72['b']));}else{if('error'in _0xc0db72)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xc0db72['error'];'a'in _0xc0db72&&this['onDataPush_'](_0xc0db72['a'],_0xc0db72['b']);}}['onDataPush_'](_0x5ecb85,_0x472f9a){this['log_']('handleServerMessage',_0x5ecb85,_0x472f9a),_0x5ecb85==='d'?this['onDataUpdate_'](_0x472f9a['p'],_0x472f9a['d'],!0x1,_0x472f9a['t']):_0x5ecb85==='m'?this['onDataUpdate_'](_0x472f9a['p'],_0x472f9a['d'],!0x0,_0x472f9a['t']):_0x5ecb85==='c'?this['onListenRevoked_'](_0x472f9a['p'],_0x472f9a['q']):_0x5ecb85==='ac'?this['onAuthRevoked_'](_0x472f9a['s'],_0x472f9a['d']):_0x5ecb85==='apc'?this['onAppCheckRevoked_'](_0x472f9a['s'],_0x472f9a['d']):_0x5ecb85==='sd'?this['onSecurityDebugPacket_'](_0x472f9a):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5ecb85)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1dff76,_0xf9e5a8){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1dff76),this['lastSessionId']=_0xf9e5a8,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x33724a){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x33724a));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x271f11){_0x271f11&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x271f11;}['onOnline_'](_0x2f0f1e){_0x2f0f1e?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x50321b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x21787e=Math['max'](0x0,this['reconnectDelay_']-_0x50321b);_0x21787e=Math['random']()*_0x21787e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x21787e+'ms'),this['scheduleConnect_'](_0x21787e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x18b9c9=this['onDataMessage_']['bind'](this),_0x4b4407=this['onReady_']['bind'](this),_0x17930c=this['onRealtimeDisconnect_']['bind'](this),_0x26ad5c=this['id']+':'+ie['nextConnectionId_']++,_0x1d60ad=this['lastSessionId'];let _0x565752=!0x1,_0x3346ec=null;const _0xda4890=function(){_0x3346ec?_0x3346ec['close']():(_0x565752=!0x0,_0x17930c());},_0x4656b0=function(_0x1c38e7){f(_0x3346ec,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3346ec['sendRequest'](_0x1c38e7);};this['realtime_']={'close':_0xda4890,'sendRequest':_0x4656b0};const _0xe6caa3=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1ba59d,_0xebcac0]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xe6caa3),this['appCheckTokenProvider_']['getToken'](_0xe6caa3)]);_0x565752?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1ba59d&&_0x1ba59d['accessToken'],this['appCheckToken_']=_0xebcac0&&_0xebcac0['token'],_0x3346ec=new wh(_0x26ad5c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x18b9c9,_0x4b4407,_0x17930c,_0x587959=>{U(_0x587959+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x1d60ad));}catch(_0x4149e5){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4149e5),_0x565752||(this['repoInfo_']['nodeAdmin']&&U(_0x4149e5),_0xda4890());}}}['interrupt'](_0x3fec5e){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3fec5e),this['interruptReasons_'][_0x3fec5e]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4f0cb5){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4f0cb5),delete this['interruptReasons_'][_0x4f0cb5],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5493ee){const _0x19ee76=_0x5493ee-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x19ee76});}['cancelSentTransactions_'](){for(let _0x5b7351=0x0;_0x5b7351<this['outstandingPuts_']['length'];_0x5b7351++){const _0x250f78=this['outstandingPuts_'][_0x5b7351];_0x250f78&&'h'in _0x250f78['request']&&_0x250f78['queued']&&(_0x250f78['onComplete']&&_0x250f78['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5b7351],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x297940,_0x3517f1){let _0xbf05b7;_0x3517f1?_0xbf05b7=_0x3517f1['map'](_0x3b362e=>Bi(_0x3b362e))['join']('$'):_0xbf05b7='default';const _0x4d1771=this['removeListen_'](_0x297940,_0xbf05b7);_0x4d1771&&_0x4d1771['onComplete']&&_0x4d1771['onComplete']('permission_denied');}['removeListen_'](_0x57e6fc,_0x11722d){const _0x3c3793=new C(_0x57e6fc)['toString']();let _0x2e9c40;if(this['listens']['has'](_0x3c3793)){const _0x2b3336=this['listens']['get'](_0x3c3793);_0x2e9c40=_0x2b3336['get'](_0x11722d),_0x2b3336['delete'](_0x11722d),_0x2b3336['size']===0x0&&this['listens']['delete'](_0x3c3793);}else _0x2e9c40=void 0x0;return _0x2e9c40;}['onAuthRevoked_'](_0x310a90,_0x4ac95e){L('Auth\x20token\x20revoked:\x20'+_0x310a90+'/'+_0x4ac95e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x310a90==='invalid_token'||_0x310a90==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x217b87,_0x1128ab){L('App\x20check\x20token\x20revoked:\x20'+_0x217b87+'/'+_0x1128ab),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x217b87==='invalid_token'||_0x217b87==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x7e6ac5){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x7e6ac5):'msg'in _0x7e6ac5&&console['log']('FIREBASE:\x20'+_0x7e6ac5['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xb6771e of this['listens']['values']())for(const _0x5c74cf of _0xb6771e['values']())this['sendListen_'](_0x5c74cf);for(let _0xed93cf=0x0;_0xed93cf<this['outstandingPuts_']['length'];_0xed93cf++)this['outstandingPuts_'][_0xed93cf]&&this['sendPut_'](_0xed93cf);for(;this['onDisconnectRequestQueue_']['length'];){const _0xcd6ed8=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xcd6ed8['action'],_0xcd6ed8['pathString'],_0xcd6ed8['data'],_0xcd6ed8['onComplete']);}for(let _0x5bdae8=0x0;_0x5bdae8<this['outstandingGets_']['length'];_0x5bdae8++)this['outstandingGets_'][_0x5bdae8]&&this['sendGet_'](_0x5bdae8);}['sendConnectStats_'](){const _0x531881={};let _0x4d55b8='js';_0x531881['sdk.'+_0x4d55b8+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x531881['framework.cordova']=0x1:qr()&&(_0x531881['framework.reactnative']=0x1),this['reportStats'](_0x531881);}['shouldReconnect_'](){const _0x1700a2=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x1700a2;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x12ee70,_0x2f87cd){this['name']=_0x12ee70,this['node']=_0x2f87cd;}static['Wrap'](_0x213527,_0x10b2aa){return new E(_0x213527,_0x10b2aa);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xb5112a,_0x5296dc){const _0x459a3c=new E(xe,_0xb5112a),_0x4e8a1b=new E(xe,_0x5296dc);return this['compare'](_0x459a3c,_0x4e8a1b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1e5c8a){Xt=_0x1e5c8a;}['compare'](_0x961e46,_0x3dc1ae){return He(_0x961e46['name'],_0x3dc1ae['name']);}['isDefinedOn'](_0x4cfa40){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3d5b52,_0xd1bcb){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x3fef14,_0x477e4e){return f(typeof _0x3fef14=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x3fef14,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2cbcaf,_0x5365bf,_0x1043b6,_0x1eef77,_0x4cfad4=null){this['isReverse_']=_0x1eef77,this['resultGenerator_']=_0x4cfad4,this['nodeStack_']=[];let _0x408919=0x1;for(;!_0x2cbcaf['isEmpty']();)if(_0x2cbcaf=_0x2cbcaf,_0x408919=_0x5365bf?_0x1043b6(_0x2cbcaf['key'],_0x5365bf):0x1,_0x1eef77&&(_0x408919*=-0x1),_0x408919<0x0)this['isReverse_']?_0x2cbcaf=_0x2cbcaf['left']:_0x2cbcaf=_0x2cbcaf['right'];else{if(_0x408919===0x0){this['nodeStack_']['push'](_0x2cbcaf);break;}else this['nodeStack_']['push'](_0x2cbcaf),this['isReverse_']?_0x2cbcaf=_0x2cbcaf['right']:_0x2cbcaf=_0x2cbcaf['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5c1234=this['nodeStack_']['pop'](),_0x621fa2;if(this['resultGenerator_']?_0x621fa2=this['resultGenerator_'](_0x5c1234['key'],_0x5c1234['value']):_0x621fa2={'key':_0x5c1234['key'],'value':_0x5c1234['value']},this['isReverse_']){for(_0x5c1234=_0x5c1234['left'];!_0x5c1234['isEmpty']();)this['nodeStack_']['push'](_0x5c1234),_0x5c1234=_0x5c1234['right'];}else{for(_0x5c1234=_0x5c1234['right'];!_0x5c1234['isEmpty']();)this['nodeStack_']['push'](_0x5c1234),_0x5c1234=_0x5c1234['left'];}return _0x621fa2;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xb00aba=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xb00aba['key'],_0xb00aba['value']):{'key':_0xb00aba['key'],'value':_0xb00aba['value']};}}class M{constructor(_0x265c70,_0x10ce3e,_0x43f641,_0x946034,_0x451061){this['key']=_0x265c70,this['value']=_0x10ce3e,this['color']=_0x43f641??M['RED'],this['left']=_0x946034??B['EMPTY_NODE'],this['right']=_0x451061??B['EMPTY_NODE'];}['copy'](_0x14a8f9,_0x594020,_0xb372e8,_0x17537f,_0x511328){return new M(_0x14a8f9??this['key'],_0x594020??this['value'],_0xb372e8??this['color'],_0x17537f??this['left'],_0x511328??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x17ca0a){return this['left']['inorderTraversal'](_0x17ca0a)||!!_0x17ca0a(this['key'],this['value'])||this['right']['inorderTraversal'](_0x17ca0a);}['reverseTraversal'](_0xf339fc){return this['right']['reverseTraversal'](_0xf339fc)||_0xf339fc(this['key'],this['value'])||this['left']['reverseTraversal'](_0xf339fc);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4ac868,_0x21363e,_0x3fe081){let _0x5b4640=this;const _0x24ee9e=_0x3fe081(_0x4ac868,_0x5b4640['key']);return _0x24ee9e<0x0?_0x5b4640=_0x5b4640['copy'](null,null,null,_0x5b4640['left']['insert'](_0x4ac868,_0x21363e,_0x3fe081),null):_0x24ee9e===0x0?_0x5b4640=_0x5b4640['copy'](null,_0x21363e,null,null,null):_0x5b4640=_0x5b4640['copy'](null,null,null,null,_0x5b4640['right']['insert'](_0x4ac868,_0x21363e,_0x3fe081)),_0x5b4640['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5b9e57=this;return!_0x5b9e57['left']['isRed_']()&&!_0x5b9e57['left']['left']['isRed_']()&&(_0x5b9e57=_0x5b9e57['moveRedLeft_']()),_0x5b9e57=_0x5b9e57['copy'](null,null,null,_0x5b9e57['left']['removeMin_'](),null),_0x5b9e57['fixUp_']();}['remove'](_0x5e7356,_0x36ceaf){let _0x3a9691,_0x5d6187;if(_0x3a9691=this,_0x36ceaf(_0x5e7356,_0x3a9691['key'])<0x0)!_0x3a9691['left']['isEmpty']()&&!_0x3a9691['left']['isRed_']()&&!_0x3a9691['left']['left']['isRed_']()&&(_0x3a9691=_0x3a9691['moveRedLeft_']()),_0x3a9691=_0x3a9691['copy'](null,null,null,_0x3a9691['left']['remove'](_0x5e7356,_0x36ceaf),null);else{if(_0x3a9691['left']['isRed_']()&&(_0x3a9691=_0x3a9691['rotateRight_']()),!_0x3a9691['right']['isEmpty']()&&!_0x3a9691['right']['isRed_']()&&!_0x3a9691['right']['left']['isRed_']()&&(_0x3a9691=_0x3a9691['moveRedRight_']()),_0x36ceaf(_0x5e7356,_0x3a9691['key'])===0x0){if(_0x3a9691['right']['isEmpty']())return B['EMPTY_NODE'];_0x5d6187=_0x3a9691['right']['min_'](),_0x3a9691=_0x3a9691['copy'](_0x5d6187['key'],_0x5d6187['value'],null,null,_0x3a9691['right']['removeMin_']());}_0x3a9691=_0x3a9691['copy'](null,null,null,null,_0x3a9691['right']['remove'](_0x5e7356,_0x36ceaf));}return _0x3a9691['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xd29bc9=this;return _0xd29bc9['right']['isRed_']()&&!_0xd29bc9['left']['isRed_']()&&(_0xd29bc9=_0xd29bc9['rotateLeft_']()),_0xd29bc9['left']['isRed_']()&&_0xd29bc9['left']['left']['isRed_']()&&(_0xd29bc9=_0xd29bc9['rotateRight_']()),_0xd29bc9['left']['isRed_']()&&_0xd29bc9['right']['isRed_']()&&(_0xd29bc9=_0xd29bc9['colorFlip_']()),_0xd29bc9;}['moveRedLeft_'](){let _0x6afb68=this['colorFlip_']();return _0x6afb68['right']['left']['isRed_']()&&(_0x6afb68=_0x6afb68['copy'](null,null,null,null,_0x6afb68['right']['rotateRight_']()),_0x6afb68=_0x6afb68['rotateLeft_'](),_0x6afb68=_0x6afb68['colorFlip_']()),_0x6afb68;}['moveRedRight_'](){let _0x3b7d7d=this['colorFlip_']();return _0x3b7d7d['left']['left']['isRed_']()&&(_0x3b7d7d=_0x3b7d7d['rotateRight_'](),_0x3b7d7d=_0x3b7d7d['colorFlip_']()),_0x3b7d7d;}['rotateLeft_'](){const _0x352d70=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x352d70,null);}['rotateRight_'](){const _0x554a31=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x554a31);}['colorFlip_'](){const _0x1aaae7=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x46db9c=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1aaae7,_0x46db9c);}['checkMaxDepth_'](){const _0x2f2d40=this['check_']();return Math['pow'](0x2,_0x2f2d40)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x334caa=this['left']['check_']();if(_0x334caa!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x334caa+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x28255f,_0x362595,_0x5c32ab,_0x27ec0a,_0xab813c){return this;}['insert'](_0x12d06e,_0x435145,_0x31dd1f){return new M(_0x12d06e,_0x435145,null);}['remove'](_0x2914ac,_0x47878c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3aa545){return!0x1;}['reverseTraversal'](_0x56c50c){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x24c4c0,_0x282a34=B['EMPTY_NODE']){this['comparator_']=_0x24c4c0,this['root_']=_0x282a34;}['insert'](_0x19df49,_0xe360ca){return new B(this['comparator_'],this['root_']['insert'](_0x19df49,_0xe360ca,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3d0448){return new B(this['comparator_'],this['root_']['remove'](_0x3d0448,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x312c5d){let _0x24d1bd,_0x25490c=this['root_'];for(;!_0x25490c['isEmpty']();){if(_0x24d1bd=this['comparator_'](_0x312c5d,_0x25490c['key']),_0x24d1bd===0x0)return _0x25490c['value'];_0x24d1bd<0x0?_0x25490c=_0x25490c['left']:_0x24d1bd>0x0&&(_0x25490c=_0x25490c['right']);}return null;}['getPredecessorKey'](_0x285fc2){let _0x12639a,_0x150dfd=this['root_'],_0x5818b2=null;for(;!_0x150dfd['isEmpty']();)if(_0x12639a=this['comparator_'](_0x285fc2,_0x150dfd['key']),_0x12639a===0x0){if(_0x150dfd['left']['isEmpty']())return _0x5818b2?_0x5818b2['key']:null;for(_0x150dfd=_0x150dfd['left'];!_0x150dfd['right']['isEmpty']();)_0x150dfd=_0x150dfd['right'];return _0x150dfd['key'];}else _0x12639a<0x0?_0x150dfd=_0x150dfd['left']:_0x12639a>0x0&&(_0x5818b2=_0x150dfd,_0x150dfd=_0x150dfd['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4fa13e){return this['root_']['inorderTraversal'](_0x4fa13e);}['reverseTraversal'](_0x4ac750){return this['root_']['reverseTraversal'](_0x4ac750);}['getIterator'](_0x20123d){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x20123d);}['getIteratorFrom'](_0x90a3b9,_0x4e58dc){return new Zt(this['root_'],_0x90a3b9,this['comparator_'],!0x1,_0x4e58dc);}['getReverseIteratorFrom'](_0x2fa0e3,_0x175a4c){return new Zt(this['root_'],_0x2fa0e3,this['comparator_'],!0x0,_0x175a4c);}['getReverseIterator'](_0x304481){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x304481);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x38cf20,_0x2ea4fc){return He(_0x38cf20['name'],_0x2ea4fc['name']);}function ji(_0x24f8cc,_0x47612e){return He(_0x24f8cc,_0x47612e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x126cea){vi=_0x126cea;}const Ro=function(_0x540883){return typeof _0x540883=='number'?'number:'+so(_0x540883):'string:'+_0x540883;},Ao=function(_0x642a5f){if(_0x642a5f['isLeafNode']()){const _0x1e7a62=_0x642a5f['val']();f(typeof _0x1e7a62=='string'||typeof _0x1e7a62=='number'||typeof _0x1e7a62=='object'&&Y(_0x1e7a62,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x642a5f===vi||_0x642a5f['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x642a5f===vi||_0x642a5f['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x9bd6b1){er=_0x9bd6b1;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x53b8ce,_0x2478f0=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x53b8ce,this['priorityNode_']=_0x2478f0,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x168976){return new D(this['value_'],_0x168976);}['getImmediateChild'](_0x131e3b){return _0x131e3b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0xc0d553){return v(_0xc0d553)?this:y(_0xc0d553)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x50a141,_0x141a26){return null;}['updateImmediateChild'](_0x467b13,_0x5f0136){return _0x467b13==='.priority'?this['updatePriority'](_0x5f0136):_0x5f0136['isEmpty']()&&_0x467b13!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x467b13,_0x5f0136)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x438a99,_0x30ed28){const _0x54e87f=y(_0x438a99);return _0x54e87f===null?_0x30ed28:_0x30ed28['isEmpty']()&&_0x54e87f!=='.priority'?this:(f(_0x54e87f!=='.priority'||we(_0x438a99)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x54e87f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x438a99),_0x30ed28)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3c2267,_0x8ecba5){return!0x1;}['val'](_0x316f6f){return _0x316f6f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2ede6f='';this['priorityNode_']['isEmpty']()||(_0x2ede6f+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2b204d=typeof this['value_'];_0x2ede6f+=_0x2b204d+':',_0x2b204d==='number'?_0x2ede6f+=so(this['value_']):_0x2ede6f+=this['value_'],this['lazyHash_']=no(_0x2ede6f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x113ce2){return _0x113ce2===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x113ce2 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x113ce2['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x113ce2));}['compareToLeafNode_'](_0x27fb6e){const _0x598f25=typeof _0x27fb6e['value_'],_0x268b11=typeof this['value_'],_0x399382=D['VALUE_TYPE_ORDER']['indexOf'](_0x598f25),_0x3589f5=D['VALUE_TYPE_ORDER']['indexOf'](_0x268b11);return f(_0x399382>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x598f25),f(_0x3589f5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x268b11),_0x399382===_0x3589f5?_0x268b11==='object'?0x0:this['value_']<_0x27fb6e['value_']?-0x1:this['value_']===_0x27fb6e['value_']?0x0:0x1:_0x3589f5-_0x399382;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3d034e){if(_0x3d034e===this)return!0x0;if(_0x3d034e['isLeafNode']()){const _0x20f715=_0x3d034e;return this['value_']===_0x20f715['value_']&&this['priorityNode_']['equals'](_0x20f715['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x22137){ko=_0x22137;}function xh(_0x5d376d){No=_0x5d376d;}class Fh extends On{['compare'](_0x2cf8a7,_0x15985f){const _0x32d848=_0x2cf8a7['node']['getPriority'](),_0x4312e2=_0x15985f['node']['getPriority'](),_0x4c04bf=_0x32d848['compareTo'](_0x4312e2);return _0x4c04bf===0x0?He(_0x2cf8a7['name'],_0x15985f['name']):_0x4c04bf;}['isDefinedOn'](_0x4d128b){return!_0x4d128b['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x18a890,_0x50fe87){return!_0x18a890['getPriority']()['equals'](_0x50fe87['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1425bc,_0x1e1282){const _0x2d102d=ko(_0x1425bc);return new E(_0x1e1282,new D('[PRIORITY-POST]',_0x2d102d));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x98799d){const _0x1bbf60=_0x502596=>parseInt(Math['log'](_0x502596)/Uh,0xa),_0x22cd7d=_0x598f88=>parseInt(Array(_0x598f88+0x1)['join']('1'),0x2);this['count']=_0x1bbf60(_0x98799d+0x1),this['current_']=this['count']-0x1;const _0x52f6ff=_0x22cd7d(this['count']);this['bits_']=_0x98799d+0x1&_0x52f6ff;}['nextBitIsOne'](){const _0x3b67ba=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3b67ba;}}const dn=function(_0x54067e,_0x165a88,_0x5aa40a,_0x3ccc98){_0x54067e['sort'](_0x165a88);const _0x3881ba=function(_0x33dc0b,_0x167e08){const _0x1cd028=_0x167e08-_0x33dc0b;let _0x57abfe,_0x140551;if(_0x1cd028===0x0)return null;if(_0x1cd028===0x1)return _0x57abfe=_0x54067e[_0x33dc0b],_0x140551=_0x5aa40a?_0x5aa40a(_0x57abfe):_0x57abfe,new M(_0x140551,_0x57abfe['node'],M['BLACK'],null,null);{const _0xa3637c=parseInt(_0x1cd028/0x2,0xa)+_0x33dc0b,_0x2bb908=_0x3881ba(_0x33dc0b,_0xa3637c),_0x41af5a=_0x3881ba(_0xa3637c+0x1,_0x167e08);return _0x57abfe=_0x54067e[_0xa3637c],_0x140551=_0x5aa40a?_0x5aa40a(_0x57abfe):_0x57abfe,new M(_0x140551,_0x57abfe['node'],M['BLACK'],_0x2bb908,_0x41af5a);}},_0xdfa5fc=function(_0x11a5b7){let _0x3d9c40=null,_0xc9390b=null,_0x126584=_0x54067e['length'];const _0x307c8b=function(_0x5760a4,_0x4b8ec9){const _0x425ae9=_0x126584-_0x5760a4,_0x29a109=_0x126584;_0x126584-=_0x5760a4;const _0x386a8e=_0x3881ba(_0x425ae9+0x1,_0x29a109),_0x16b15d=_0x54067e[_0x425ae9],_0x1317dc=_0x5aa40a?_0x5aa40a(_0x16b15d):_0x16b15d;_0x3c08d2(new M(_0x1317dc,_0x16b15d['node'],_0x4b8ec9,null,_0x386a8e));},_0x3c08d2=function(_0x37551e){_0x3d9c40?(_0x3d9c40['left']=_0x37551e,_0x3d9c40=_0x37551e):(_0xc9390b=_0x37551e,_0x3d9c40=_0x37551e);};for(let _0x31d782=0x0;_0x31d782<_0x11a5b7['count'];++_0x31d782){const _0x4abce6=_0x11a5b7['nextBitIsOne'](),_0x5735c1=Math['pow'](0x2,_0x11a5b7['count']-(_0x31d782+0x1));_0x4abce6?_0x307c8b(_0x5735c1,M['BLACK']):(_0x307c8b(_0x5735c1,M['BLACK']),_0x307c8b(_0x5735c1,M['RED']));}return _0xc9390b;},_0x5c0448=new Wh(_0x54067e['length']),_0x960fa9=_0xdfa5fc(_0x5c0448);return new B(_0x3ccc98||_0x165a88,_0x960fa9);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5bf341,_0x4dc2a6){this['indexes_']=_0x5bf341,this['indexSet_']=_0x4dc2a6;}['get'](_0x5ccc9f){const _0x4f8aae=Oe(this['indexes_'],_0x5ccc9f);if(!_0x4f8aae)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5ccc9f);return _0x4f8aae instanceof B?_0x4f8aae:null;}['hasIndex'](_0x417e76){return Y(this['indexSet_'],_0x417e76['toString']());}['addIndex'](_0x456dda,_0x3287fd){f(_0x456dda!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1f1206=[];let _0x45f99f=!0x1;const _0xfec5a8=_0x3287fd['getIterator'](E['Wrap']);let _0xb4a9c9=_0xfec5a8['getNext']();for(;_0xb4a9c9;)_0x45f99f=_0x45f99f||_0x456dda['isDefinedOn'](_0xb4a9c9['node']),_0x1f1206['push'](_0xb4a9c9),_0xb4a9c9=_0xfec5a8['getNext']();let _0x544f0f;_0x45f99f?_0x544f0f=dn(_0x1f1206,_0x456dda['getCompare']()):_0x544f0f=je;const _0x14b375=_0x456dda['toString'](),_0x16f819={...this['indexSet_']};_0x16f819[_0x14b375]=_0x456dda;const _0x5013d9={...this['indexes_']};return _0x5013d9[_0x14b375]=_0x544f0f,new ee(_0x5013d9,_0x16f819);}['addToIndexes'](_0x119dd7,_0x43db53){const _0x382dd0=ln(this['indexes_'],(_0x396f13,_0x36d030)=>{const _0x19c671=Oe(this['indexSet_'],_0x36d030);if(f(_0x19c671,'Missing\x20index\x20implementation\x20for\x20'+_0x36d030),_0x396f13===je){if(_0x19c671['isDefinedOn'](_0x119dd7['node'])){const _0x163b7b=[],_0x3e4ced=_0x43db53['getIterator'](E['Wrap']);let _0x112a3f=_0x3e4ced['getNext']();for(;_0x112a3f;)_0x112a3f['name']!==_0x119dd7['name']&&_0x163b7b['push'](_0x112a3f),_0x112a3f=_0x3e4ced['getNext']();return _0x163b7b['push'](_0x119dd7),dn(_0x163b7b,_0x19c671['getCompare']());}else return je;}else{const _0x9d773a=_0x43db53['get'](_0x119dd7['name']);let _0x47840d=_0x396f13;return _0x9d773a&&(_0x47840d=_0x47840d['remove'](new E(_0x119dd7['name'],_0x9d773a))),_0x47840d['insert'](_0x119dd7,_0x119dd7['node']);}});return new ee(_0x382dd0,this['indexSet_']);}['removeFromIndexes'](_0x2cf775,_0x1aa3d4){const _0xab5c8c=ln(this['indexes_'],_0x55b7b5=>{if(_0x55b7b5===je)return _0x55b7b5;{const _0x201aa=_0x1aa3d4['get'](_0x2cf775['name']);return _0x201aa?_0x55b7b5['remove'](new E(_0x2cf775['name'],_0x201aa)):_0x55b7b5;}});return new ee(_0xab5c8c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x517b8f,_0x208e2b,_0x241bf8){this['children_']=_0x517b8f,this['priorityNode_']=_0x208e2b,this['indexMap_']=_0x241bf8,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x5cdcbb){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5cdcbb,this['indexMap_']);}['getImmediateChild'](_0x48120a){if(_0x48120a==='.priority')return this['getPriority']();{const _0x1ef0b6=this['children_']['get'](_0x48120a);return _0x1ef0b6===null?gt:_0x1ef0b6;}}['getChild'](_0x4b636f){const _0x5efadf=y(_0x4b636f);return _0x5efadf===null?this:this['getImmediateChild'](_0x5efadf)['getChild'](b(_0x4b636f));}['hasChild'](_0x3e6731){return this['children_']['get'](_0x3e6731)!==null;}['updateImmediateChild'](_0x48d1cb,_0x3dc309){if(f(_0x3dc309,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x48d1cb==='.priority')return this['updatePriority'](_0x3dc309);{const _0x7e1145=new E(_0x48d1cb,_0x3dc309);let _0x3f6a1e,_0x86cec1;_0x3dc309['isEmpty']()?(_0x3f6a1e=this['children_']['remove'](_0x48d1cb),_0x86cec1=this['indexMap_']['removeFromIndexes'](_0x7e1145,this['children_'])):(_0x3f6a1e=this['children_']['insert'](_0x48d1cb,_0x3dc309),_0x86cec1=this['indexMap_']['addToIndexes'](_0x7e1145,this['children_']));const _0x2a7185=_0x3f6a1e['isEmpty']()?gt:this['priorityNode_'];return new g(_0x3f6a1e,_0x2a7185,_0x86cec1);}}['updateChild'](_0x92417c,_0x13a032){const _0x2ca7bd=y(_0x92417c);if(_0x2ca7bd===null)return _0x13a032;{f(y(_0x92417c)!=='.priority'||we(_0x92417c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1d547e=this['getImmediateChild'](_0x2ca7bd)['updateChild'](b(_0x92417c),_0x13a032);return this['updateImmediateChild'](_0x2ca7bd,_0x1d547e);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x58468e){if(this['isEmpty']())return null;const _0x3e9067={};let _0x144c9b=0x0,_0x56241c=0x0,_0x137ffa=!0x0;if(this['forEachChild'](R,(_0x5d8742,_0x46183d)=>{_0x3e9067[_0x5d8742]=_0x46183d['val'](_0x58468e),_0x144c9b++,_0x137ffa&&g['INTEGER_REGEXP_']['test'](_0x5d8742)?_0x56241c=Math['max'](_0x56241c,Number(_0x5d8742)):_0x137ffa=!0x1;}),!_0x58468e&&_0x137ffa&&_0x56241c<0x2*_0x144c9b){const _0x58802c=[];for(const _0x467a60 in _0x3e9067)_0x58802c[_0x467a60]=_0x3e9067[_0x467a60];return _0x58802c;}else return _0x58468e&&!this['getPriority']()['isEmpty']()&&(_0x3e9067['.priority']=this['getPriority']()['val']()),_0x3e9067;}['hash'](){if(this['lazyHash_']===null){let _0x2db0ca='';this['getPriority']()['isEmpty']()||(_0x2db0ca+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x550f5a,_0x3c911c)=>{const _0xeac2de=_0x3c911c['hash']();_0xeac2de!==''&&(_0x2db0ca+=':'+_0x550f5a+':'+_0xeac2de);}),this['lazyHash_']=_0x2db0ca===''?'':no(_0x2db0ca);}return this['lazyHash_'];}['getPredecessorChildName'](_0x221928,_0x1e1e8c,_0x33d01e){const _0x5420b9=this['resolveIndex_'](_0x33d01e);if(_0x5420b9){const _0x135422=_0x5420b9['getPredecessorKey'](new E(_0x221928,_0x1e1e8c));return _0x135422?_0x135422['name']:null;}else return this['children_']['getPredecessorKey'](_0x221928);}['getFirstChildName'](_0x11ce6a){const _0x33ecbf=this['resolveIndex_'](_0x11ce6a);if(_0x33ecbf){const _0x919ad6=_0x33ecbf['minKey']();return _0x919ad6&&_0x919ad6['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x446693){const _0x14f211=this['getFirstChildName'](_0x446693);return _0x14f211?new E(_0x14f211,this['children_']['get'](_0x14f211)):null;}['getLastChildName'](_0x351d2f){const _0x542229=this['resolveIndex_'](_0x351d2f);if(_0x542229){const _0x3d0692=_0x542229['maxKey']();return _0x3d0692&&_0x3d0692['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x31a915){const _0x5287ef=this['getLastChildName'](_0x31a915);return _0x5287ef?new E(_0x5287ef,this['children_']['get'](_0x5287ef)):null;}['forEachChild'](_0x57a124,_0x2c6b36){const _0x432ef8=this['resolveIndex_'](_0x57a124);return _0x432ef8?_0x432ef8['inorderTraversal'](_0x1737ee=>_0x2c6b36(_0x1737ee['name'],_0x1737ee['node'])):this['children_']['inorderTraversal'](_0x2c6b36);}['getIterator'](_0x27e062){return this['getIteratorFrom'](_0x27e062['minPost'](),_0x27e062);}['getIteratorFrom'](_0x4b1db0,_0x5a22c8){const _0x12be62=this['resolveIndex_'](_0x5a22c8);if(_0x12be62)return _0x12be62['getIteratorFrom'](_0x4b1db0,_0x483dce=>_0x483dce);{const _0x2b8cd2=this['children_']['getIteratorFrom'](_0x4b1db0['name'],E['Wrap']);let _0x41edd2=_0x2b8cd2['peek']();for(;_0x41edd2!=null&&_0x5a22c8['compare'](_0x41edd2,_0x4b1db0)<0x0;)_0x2b8cd2['getNext'](),_0x41edd2=_0x2b8cd2['peek']();return _0x2b8cd2;}}['getReverseIterator'](_0x259529){return this['getReverseIteratorFrom'](_0x259529['maxPost'](),_0x259529);}['getReverseIteratorFrom'](_0x5d824d,_0x3c63fa){const _0x33fd9e=this['resolveIndex_'](_0x3c63fa);if(_0x33fd9e)return _0x33fd9e['getReverseIteratorFrom'](_0x5d824d,_0x226306=>_0x226306);{const _0x2b9ee2=this['children_']['getReverseIteratorFrom'](_0x5d824d['name'],E['Wrap']);let _0x478b8b=_0x2b9ee2['peek']();for(;_0x478b8b!=null&&_0x3c63fa['compare'](_0x478b8b,_0x5d824d)>0x0;)_0x2b9ee2['getNext'](),_0x478b8b=_0x2b9ee2['peek']();return _0x2b9ee2;}}['compareTo'](_0x101b93){return this['isEmpty']()?_0x101b93['isEmpty']()?0x0:-0x1:_0x101b93['isLeafNode']()||_0x101b93['isEmpty']()?0x1:_0x101b93===Ht?-0x1:0x0;}['withIndex'](_0x4ba706){if(_0x4ba706===ye||this['indexMap_']['hasIndex'](_0x4ba706))return this;{const _0x39ded3=this['indexMap_']['addIndex'](_0x4ba706,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x39ded3);}}['isIndexed'](_0x24dfec){return _0x24dfec===ye||this['indexMap_']['hasIndex'](_0x24dfec);}['equals'](_0x905b99){if(_0x905b99===this)return!0x0;if(_0x905b99['isLeafNode']())return!0x1;{const _0x1e07cd=_0x905b99;if(this['getPriority']()['equals'](_0x1e07cd['getPriority']())){if(this['children_']['count']()===_0x1e07cd['children_']['count']()){const _0xd5b4ec=this['getIterator'](R),_0x345b29=_0x1e07cd['getIterator'](R);let _0x57949c=_0xd5b4ec['getNext'](),_0xbf21f5=_0x345b29['getNext']();for(;_0x57949c&&_0xbf21f5;){if(_0x57949c['name']!==_0xbf21f5['name']||!_0x57949c['node']['equals'](_0xbf21f5['node']))return!0x1;_0x57949c=_0xd5b4ec['getNext'](),_0xbf21f5=_0x345b29['getNext']();}return _0x57949c===null&&_0xbf21f5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2a2b7f){return _0x2a2b7f===ye?null:this['indexMap_']['get'](_0x2a2b7f['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x3c6416){return _0x3c6416===this?0x0:0x1;}['equals'](_0x16705f){return _0x16705f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1fda86){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x2ba821,_0x58690c=null){if(_0x2ba821===null)return g['EMPTY_NODE'];if(typeof _0x2ba821=='object'&&'.priority'in _0x2ba821&&(_0x58690c=_0x2ba821['.priority']),f(_0x58690c===null||typeof _0x58690c=='string'||typeof _0x58690c=='number'||typeof _0x58690c=='object'&&'.sv'in _0x58690c,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x58690c),typeof _0x2ba821=='object'&&'.value'in _0x2ba821&&_0x2ba821['.value']!==null&&(_0x2ba821=_0x2ba821['.value']),typeof _0x2ba821!='object'||'.sv'in _0x2ba821){const _0x5bd745=_0x2ba821;return new D(_0x5bd745,N(_0x58690c));}if(!(_0x2ba821 instanceof Array)&&Vh){const _0x175a29=[];let _0x10ed9c=!0x1;if(x(_0x2ba821,(_0x1961cb,_0x2230ec)=>{if(_0x1961cb['substring'](0x0,0x1)!=='.'){const _0x3437ac=N(_0x2230ec);_0x3437ac['isEmpty']()||(_0x10ed9c=_0x10ed9c||!_0x3437ac['getPriority']()['isEmpty'](),_0x175a29['push'](new E(_0x1961cb,_0x3437ac)));}}),_0x175a29['length']===0x0)return g['EMPTY_NODE'];const _0x19a96f=dn(_0x175a29,Dh,_0x5443b4=>_0x5443b4['name'],ji);if(_0x10ed9c){const _0x665506=dn(_0x175a29,R['getCompare']());return new g(_0x19a96f,N(_0x58690c),new ee({'.priority':_0x665506},{'.priority':R}));}else return new g(_0x19a96f,N(_0x58690c),ee['Default']);}else{let _0x392259=g['EMPTY_NODE'];return x(_0x2ba821,(_0x4ff011,_0x12e8d1)=>{if(Y(_0x2ba821,_0x4ff011)&&_0x4ff011['substring'](0x0,0x1)!=='.'){const _0x17a45c=N(_0x12e8d1);(_0x17a45c['isLeafNode']()||!_0x17a45c['isEmpty']())&&(_0x392259=_0x392259['updateImmediateChild'](_0x4ff011,_0x17a45c));}}),_0x392259['updatePriority'](N(_0x58690c));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x34794a){super(),this['indexPath_']=_0x34794a,f(!v(_0x34794a)&&y(_0x34794a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x301040){return _0x301040['getChild'](this['indexPath_']);}['isDefinedOn'](_0x47b3c8){return!_0x47b3c8['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x59d34a,_0x51870e){const _0x21b11b=this['extractChild'](_0x59d34a['node']),_0x370362=this['extractChild'](_0x51870e['node']),_0x2fe4b8=_0x21b11b['compareTo'](_0x370362);return _0x2fe4b8===0x0?He(_0x59d34a['name'],_0x51870e['name']):_0x2fe4b8;}['makePost'](_0x42fad8,_0x324188){const _0x3f67e2=N(_0x42fad8),_0x9bdf1e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3f67e2);return new E(_0x324188,_0x9bdf1e);}['maxPost'](){const _0x4ced34=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x4ced34);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x4522ab,_0x2f2fd5){const _0xd85c58=_0x4522ab['node']['compareTo'](_0x2f2fd5['node']);return _0xd85c58===0x0?He(_0x4522ab['name'],_0x2f2fd5['name']):_0xd85c58;}['isDefinedOn'](_0x4cc297){return!0x0;}['indexedValueChanged'](_0x5d0c75,_0x39b96d){return!_0x5d0c75['equals'](_0x39b96d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2a52e2,_0x15ed9a){const _0x41fab4=N(_0x2a52e2);return new E(_0x15ed9a,_0x41fab4);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x192297){return{'type':'value','snapshotNode':_0x192297};}function tt(_0x2d2439,_0x4ee4ba){return{'type':'child_added','snapshotNode':_0x4ee4ba,'childName':_0x2d2439};}function Nt(_0x16025a,_0xb08f91){return{'type':'child_removed','snapshotNode':_0xb08f91,'childName':_0x16025a};}function Pt(_0x106d68,_0x514f09,_0x196e0b){return{'type':'child_changed','snapshotNode':_0x514f09,'childName':_0x106d68,'oldSnap':_0x196e0b};}function $h(_0x3a6116,_0x2a7455){return{'type':'child_moved','snapshotNode':_0x2a7455,'childName':_0x3a6116};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x2ef19d){this['index_']=_0x2ef19d;}['updateChild'](_0x275dea,_0x1a69fb,_0x2b5266,_0x83fb9e,_0x336e85,_0x5e7ffd){f(_0x275dea['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x54fcef=_0x275dea['getImmediateChild'](_0x1a69fb);return _0x54fcef['getChild'](_0x83fb9e)['equals'](_0x2b5266['getChild'](_0x83fb9e))&&_0x54fcef['isEmpty']()===_0x2b5266['isEmpty']()||(_0x5e7ffd!=null&&(_0x2b5266['isEmpty']()?_0x275dea['hasChild'](_0x1a69fb)?_0x5e7ffd['trackChildChange'](Nt(_0x1a69fb,_0x54fcef)):f(_0x275dea['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x54fcef['isEmpty']()?_0x5e7ffd['trackChildChange'](tt(_0x1a69fb,_0x2b5266)):_0x5e7ffd['trackChildChange'](Pt(_0x1a69fb,_0x2b5266,_0x54fcef))),_0x275dea['isLeafNode']()&&_0x2b5266['isEmpty']())?_0x275dea:_0x275dea['updateImmediateChild'](_0x1a69fb,_0x2b5266)['withIndex'](this['index_']);}['updateFullNode'](_0x46f8a8,_0x590f1f,_0x3e6024){return _0x3e6024!=null&&(_0x46f8a8['isLeafNode']()||_0x46f8a8['forEachChild'](R,(_0x3fe443,_0x741952)=>{_0x590f1f['hasChild'](_0x3fe443)||_0x3e6024['trackChildChange'](Nt(_0x3fe443,_0x741952));}),_0x590f1f['isLeafNode']()||_0x590f1f['forEachChild'](R,(_0x27e621,_0xe42d62)=>{if(_0x46f8a8['hasChild'](_0x27e621)){const _0x23a245=_0x46f8a8['getImmediateChild'](_0x27e621);_0x23a245['equals'](_0xe42d62)||_0x3e6024['trackChildChange'](Pt(_0x27e621,_0xe42d62,_0x23a245));}else _0x3e6024['trackChildChange'](tt(_0x27e621,_0xe42d62));})),_0x590f1f['withIndex'](this['index_']);}['updatePriority'](_0x440b34,_0x468431){return _0x440b34['isEmpty']()?g['EMPTY_NODE']:_0x440b34['updatePriority'](_0x468431);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x1e376f){this['indexedFilter_']=new Yi(_0x1e376f['getIndex']()),this['index_']=_0x1e376f['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x1e376f),this['endPost_']=Ot['getEndPost_'](_0x1e376f),this['startIsInclusive_']=!_0x1e376f['startAfterSet_'],this['endIsInclusive_']=!_0x1e376f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5aa644){const _0x25fdd6=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5aa644)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5aa644)<0x0,_0x3c9ab1=this['endIsInclusive_']?this['index_']['compare'](_0x5aa644,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5aa644,this['getEndPost']())<0x0;return _0x25fdd6&&_0x3c9ab1;}['updateChild'](_0x22bcb8,_0x229bf6,_0x3cea11,_0x15e425,_0x5ad862,_0x2fe00d){return this['matches'](new E(_0x229bf6,_0x3cea11))||(_0x3cea11=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x22bcb8,_0x229bf6,_0x3cea11,_0x15e425,_0x5ad862,_0x2fe00d);}['updateFullNode'](_0x305246,_0x4fa930,_0x27333b){_0x4fa930['isLeafNode']()&&(_0x4fa930=g['EMPTY_NODE']);let _0x52f40d=_0x4fa930['withIndex'](this['index_']);_0x52f40d=_0x52f40d['updatePriority'](g['EMPTY_NODE']);const _0x71ef01=this;return _0x4fa930['forEachChild'](R,(_0x2027b6,_0x1749e2)=>{_0x71ef01['matches'](new E(_0x2027b6,_0x1749e2))||(_0x52f40d=_0x52f40d['updateImmediateChild'](_0x2027b6,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x305246,_0x52f40d,_0x27333b);}['updatePriority'](_0x324710,_0x1a6b54){return _0x324710;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1c179a){if(_0x1c179a['hasStart']()){const _0x2b6bae=_0x1c179a['getIndexStartName']();return _0x1c179a['getIndex']()['makePost'](_0x1c179a['getIndexStartValue'](),_0x2b6bae);}else return _0x1c179a['getIndex']()['minPost']();}static['getEndPost_'](_0x2baccb){if(_0x2baccb['hasEnd']()){const _0x4562a9=_0x2baccb['getIndexEndName']();return _0x2baccb['getIndex']()['makePost'](_0x2baccb['getIndexEndValue'](),_0x4562a9);}else return _0x2baccb['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xf7281c){this['withinDirectionalStart']=_0x31d516=>this['reverse_']?this['withinEndPost'](_0x31d516):this['withinStartPost'](_0x31d516),this['withinDirectionalEnd']=_0x4dc9c1=>this['reverse_']?this['withinStartPost'](_0x4dc9c1):this['withinEndPost'](_0x4dc9c1),this['withinStartPost']=_0x572c07=>{const _0x15cc61=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x572c07);return this['startIsInclusive_']?_0x15cc61<=0x0:_0x15cc61<0x0;},this['withinEndPost']=_0x210615=>{const _0x1fd36f=this['index_']['compare'](_0x210615,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1fd36f<=0x0:_0x1fd36f<0x0;},this['rangedFilter_']=new Ot(_0xf7281c),this['index_']=_0xf7281c['getIndex'](),this['limit_']=_0xf7281c['getLimit'](),this['reverse_']=!_0xf7281c['isViewFromLeft'](),this['startIsInclusive_']=!_0xf7281c['startAfterSet_'],this['endIsInclusive_']=!_0xf7281c['endBeforeSet_'];}['updateChild'](_0xfa6287,_0x26f873,_0x272556,_0x51656d,_0x3c2987,_0x1cac99){return this['rangedFilter_']['matches'](new E(_0x26f873,_0x272556))||(_0x272556=g['EMPTY_NODE']),_0xfa6287['getImmediateChild'](_0x26f873)['equals'](_0x272556)?_0xfa6287:_0xfa6287['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xfa6287,_0x26f873,_0x272556,_0x51656d,_0x3c2987,_0x1cac99):this['fullLimitUpdateChild_'](_0xfa6287,_0x26f873,_0x272556,_0x3c2987,_0x1cac99);}['updateFullNode'](_0x2201bf,_0x4f8a57,_0x343176){let _0x38fbe9;if(_0x4f8a57['isLeafNode']()||_0x4f8a57['isEmpty']())_0x38fbe9=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4f8a57['numChildren']()&&_0x4f8a57['isIndexed'](this['index_'])){_0x38fbe9=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x40ef5e;this['reverse_']?_0x40ef5e=_0x4f8a57['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x40ef5e=_0x4f8a57['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3f5f42=0x0;for(;_0x40ef5e['hasNext']()&&_0x3f5f42<this['limit_'];){const _0x8bd2df=_0x40ef5e['getNext']();if(this['withinDirectionalStart'](_0x8bd2df)){if(this['withinDirectionalEnd'](_0x8bd2df))_0x38fbe9=_0x38fbe9['updateImmediateChild'](_0x8bd2df['name'],_0x8bd2df['node']),_0x3f5f42++;else break;}else continue;}}else{_0x38fbe9=_0x4f8a57['withIndex'](this['index_']),_0x38fbe9=_0x38fbe9['updatePriority'](g['EMPTY_NODE']);let _0x4a9728;this['reverse_']?_0x4a9728=_0x38fbe9['getReverseIterator'](this['index_']):_0x4a9728=_0x38fbe9['getIterator'](this['index_']);let _0x1c0a1b=0x0;for(;_0x4a9728['hasNext']();){const _0x2b80e3=_0x4a9728['getNext']();_0x1c0a1b<this['limit_']&&this['withinDirectionalStart'](_0x2b80e3)&&this['withinDirectionalEnd'](_0x2b80e3)?_0x1c0a1b++:_0x38fbe9=_0x38fbe9['updateImmediateChild'](_0x2b80e3['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2201bf,_0x38fbe9,_0x343176);}['updatePriority'](_0x6ca855,_0x3a06f0){return _0x6ca855;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x57764c,_0x3eb368,_0x5cddb8,_0x4a1169,_0x5aa12a){let _0x214fd4;if(this['reverse_']){const _0x1e4404=this['index_']['getCompare']();_0x214fd4=(_0x8838fa,_0x577a5a)=>_0x1e4404(_0x577a5a,_0x8838fa);}else _0x214fd4=this['index_']['getCompare']();const _0x595531=_0x57764c;f(_0x595531['numChildren']()===this['limit_'],'');const _0x5cffed=new E(_0x3eb368,_0x5cddb8),_0x3d13f7=this['reverse_']?_0x595531['getFirstChild'](this['index_']):_0x595531['getLastChild'](this['index_']),_0x3ef343=this['rangedFilter_']['matches'](_0x5cffed);if(_0x595531['hasChild'](_0x3eb368)){const _0x5d4a22=_0x595531['getImmediateChild'](_0x3eb368);let _0x2ca32c=_0x4a1169['getChildAfterChild'](this['index_'],_0x3d13f7,this['reverse_']);for(;_0x2ca32c!=null&&(_0x2ca32c['name']===_0x3eb368||_0x595531['hasChild'](_0x2ca32c['name']));)_0x2ca32c=_0x4a1169['getChildAfterChild'](this['index_'],_0x2ca32c,this['reverse_']);const _0x21f4d5=_0x2ca32c==null?0x1:_0x214fd4(_0x2ca32c,_0x5cffed);if(_0x3ef343&&!_0x5cddb8['isEmpty']()&&_0x21f4d5>=0x0)return _0x5aa12a!=null&&_0x5aa12a['trackChildChange'](Pt(_0x3eb368,_0x5cddb8,_0x5d4a22)),_0x595531['updateImmediateChild'](_0x3eb368,_0x5cddb8);{_0x5aa12a!=null&&_0x5aa12a['trackChildChange'](Nt(_0x3eb368,_0x5d4a22));const _0xda1abd=_0x595531['updateImmediateChild'](_0x3eb368,g['EMPTY_NODE']);return _0x2ca32c!=null&&this['rangedFilter_']['matches'](_0x2ca32c)?(_0x5aa12a!=null&&_0x5aa12a['trackChildChange'](tt(_0x2ca32c['name'],_0x2ca32c['node'])),_0xda1abd['updateImmediateChild'](_0x2ca32c['name'],_0x2ca32c['node'])):_0xda1abd;}}else return _0x5cddb8['isEmpty']()?_0x57764c:_0x3ef343&&_0x214fd4(_0x3d13f7,_0x5cffed)>=0x0?(_0x5aa12a!=null&&(_0x5aa12a['trackChildChange'](Nt(_0x3d13f7['name'],_0x3d13f7['node'])),_0x5aa12a['trackChildChange'](tt(_0x3eb368,_0x5cddb8))),_0x595531['updateImmediateChild'](_0x3eb368,_0x5cddb8)['updateImmediateChild'](_0x3d13f7['name'],g['EMPTY_NODE'])):_0x57764c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1b5f25=new Qi();return _0x1b5f25['limitSet_']=this['limitSet_'],_0x1b5f25['limit_']=this['limit_'],_0x1b5f25['startSet_']=this['startSet_'],_0x1b5f25['startAfterSet_']=this['startAfterSet_'],_0x1b5f25['indexStartValue_']=this['indexStartValue_'],_0x1b5f25['startNameSet_']=this['startNameSet_'],_0x1b5f25['indexStartName_']=this['indexStartName_'],_0x1b5f25['endSet_']=this['endSet_'],_0x1b5f25['endBeforeSet_']=this['endBeforeSet_'],_0x1b5f25['indexEndValue_']=this['indexEndValue_'],_0x1b5f25['endNameSet_']=this['endNameSet_'],_0x1b5f25['indexEndName_']=this['indexEndName_'],_0x1b5f25['index_']=this['index_'],_0x1b5f25['viewFrom_']=this['viewFrom_'],_0x1b5f25;}}function qh(_0xf980c){return _0xf980c['loadsAllData']()?new Yi(_0xf980c['getIndex']()):_0xf980c['hasLimit']()?new Gh(_0xf980c):new Ot(_0xf980c);}function zh(_0x245cbb,_0x53258f){const _0x41b7df=_0x245cbb['copy']();return _0x41b7df['limitSet_']=!0x0,_0x41b7df['limit_']=_0x53258f,_0x41b7df['viewFrom_']='l',_0x41b7df;}function jh(_0x149d0f,_0x17951b,_0x1d3327){const _0x149d92=_0x149d0f['copy']();return _0x149d92['startSet_']=!0x0,_0x17951b===void 0x0&&(_0x17951b=null),_0x149d92['indexStartValue_']=_0x17951b,_0x1d3327!=null?(_0x149d92['startNameSet_']=!0x0,_0x149d92['indexStartName_']=_0x1d3327):(_0x149d92['startNameSet_']=!0x1,_0x149d92['indexStartName_']=''),_0x149d92;}function Kh(_0xaeff7f,_0x2b21ee,_0x2a6508){const _0x28e4aa=_0xaeff7f['copy']();return _0x28e4aa['endSet_']=!0x0,_0x2b21ee===void 0x0&&(_0x2b21ee=null),_0x28e4aa['indexEndValue_']=_0x2b21ee,_0x2a6508!==void 0x0?(_0x28e4aa['endNameSet_']=!0x0,_0x28e4aa['indexEndName_']=_0x2a6508):(_0x28e4aa['endNameSet_']=!0x1,_0x28e4aa['indexEndName_']=''),_0x28e4aa;}function Do(_0x28ee96,_0x4ac4a6){const _0x290da1=_0x28ee96['copy']();return _0x290da1['index_']=_0x4ac4a6,_0x290da1;}function tr(_0x5c5845){const _0x20b73b={};if(_0x5c5845['isDefault']())return _0x20b73b;let _0x4b840f;if(_0x5c5845['index_']===R?_0x4b840f='$priority':_0x5c5845['index_']===Po?_0x4b840f='$value':_0x5c5845['index_']===ye?_0x4b840f='$key':(f(_0x5c5845['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x4b840f=_0x5c5845['index_']['toString']()),_0x20b73b['orderBy']=O(_0x4b840f),_0x5c5845['startSet_']){const _0x37296b=_0x5c5845['startAfterSet_']?'startAfter':'startAt';_0x20b73b[_0x37296b]=O(_0x5c5845['indexStartValue_']),_0x5c5845['startNameSet_']&&(_0x20b73b[_0x37296b]+=','+O(_0x5c5845['indexStartName_']));}if(_0x5c5845['endSet_']){const _0x458869=_0x5c5845['endBeforeSet_']?'endBefore':'endAt';_0x20b73b[_0x458869]=O(_0x5c5845['indexEndValue_']),_0x5c5845['endNameSet_']&&(_0x20b73b[_0x458869]+=','+O(_0x5c5845['indexEndName_']));}return _0x5c5845['limitSet_']&&(_0x5c5845['isViewFromLeft']()?_0x20b73b['limitToFirst']=_0x5c5845['limit_']:_0x20b73b['limitToLast']=_0x5c5845['limit_']),_0x20b73b;}function nr(_0x3cb826){const _0x42b8db={};if(_0x3cb826['startSet_']&&(_0x42b8db['sp']=_0x3cb826['indexStartValue_'],_0x3cb826['startNameSet_']&&(_0x42b8db['sn']=_0x3cb826['indexStartName_']),_0x42b8db['sin']=!_0x3cb826['startAfterSet_']),_0x3cb826['endSet_']&&(_0x42b8db['ep']=_0x3cb826['indexEndValue_'],_0x3cb826['endNameSet_']&&(_0x42b8db['en']=_0x3cb826['indexEndName_']),_0x42b8db['ein']=!_0x3cb826['endBeforeSet_']),_0x3cb826['limitSet_']){_0x42b8db['l']=_0x3cb826['limit_'];let _0x43d05f=_0x3cb826['viewFrom_'];_0x43d05f===''&&(_0x3cb826['isViewFromLeft']()?_0x43d05f='l':_0x43d05f='r'),_0x42b8db['vf']=_0x43d05f;}return _0x3cb826['index_']!==R&&(_0x42b8db['i']=_0x3cb826['index_']['toString']()),_0x42b8db;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x5ad9db){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x41dbd5,_0x46e15b){return _0x46e15b!==void 0x0?'tag$'+_0x46e15b:(f(_0x41dbd5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x41dbd5['_path']['toString']());}constructor(_0x4d6e00,_0x26eba6,_0x531c95,_0x507c1c){super(),this['repoInfo_']=_0x4d6e00,this['onDataUpdate_']=_0x26eba6,this['authTokenProvider_']=_0x531c95,this['appCheckTokenProvider_']=_0x507c1c,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x3cd4a6,_0x401945,_0x4baefc,_0x1184ad){const _0x418ecf=_0x3cd4a6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x418ecf+'\x20'+_0x3cd4a6['_queryIdentifier']);const _0x17404d=fn['getListenId_'](_0x3cd4a6,_0x4baefc),_0x2a1756={};this['listens_'][_0x17404d]=_0x2a1756;const _0x235061=tr(_0x3cd4a6['_queryParams']);this['restRequest_'](_0x418ecf+'.json',_0x235061,(_0x46c5c3,_0x593bc6)=>{let _0x58b588=_0x593bc6;if(_0x46c5c3===0x194&&(_0x58b588=null,_0x46c5c3=null),_0x46c5c3===null&&this['onDataUpdate_'](_0x418ecf,_0x58b588,!0x1,_0x4baefc),Oe(this['listens_'],_0x17404d)===_0x2a1756){let _0xc52788;_0x46c5c3?_0x46c5c3===0x191?_0xc52788='permission_denied':_0xc52788='rest_error:'+_0x46c5c3:_0xc52788='ok',_0x1184ad(_0xc52788,null);}});}['unlisten'](_0x3f6b54,_0x3c9f52){const _0x4daf7b=fn['getListenId_'](_0x3f6b54,_0x3c9f52);delete this['listens_'][_0x4daf7b];}['get'](_0x3370f3){const _0x142456=tr(_0x3370f3['_queryParams']),_0x40f2c1=_0x3370f3['_path']['toString'](),_0x1fbc29=new Ve();return this['restRequest_'](_0x40f2c1+'.json',_0x142456,(_0x25b294,_0x307bc6)=>{let _0x1d76d7=_0x307bc6;_0x25b294===0x194&&(_0x1d76d7=null,_0x25b294=null),_0x25b294===null?(this['onDataUpdate_'](_0x40f2c1,_0x1d76d7,!0x1,null),_0x1fbc29['resolve'](_0x1d76d7)):_0x1fbc29['reject'](new Error(_0x1d76d7));}),_0x1fbc29['promise'];}['refreshAuthToken'](_0x298987){}['restRequest_'](_0x4575cc,_0x5d3555={},_0x398e7e){return _0x5d3555['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4313c3,_0x3a7048])=>{_0x4313c3&&_0x4313c3['accessToken']&&(_0x5d3555['auth']=_0x4313c3['accessToken']),_0x3a7048&&_0x3a7048['token']&&(_0x5d3555['ac']=_0x3a7048['token']);const _0x27f86e=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4575cc+'?ns='+this['repoInfo_']['namespace']+at(_0x5d3555);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x27f86e);const _0x45a860=new XMLHttpRequest();_0x45a860['onreadystatechange']=()=>{if(_0x398e7e&&_0x45a860['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x27f86e+'\x20received.\x20status:',_0x45a860['status'],'response:',_0x45a860['responseText']);let _0x1a59d4=null;if(_0x45a860['status']>=0xc8&&_0x45a860['status']<0x12c){try{_0x1a59d4=bt(_0x45a860['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x27f86e+':\x20'+_0x45a860['responseText']);}_0x398e7e(null,_0x1a59d4);}else _0x45a860['status']!==0x191&&_0x45a860['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x27f86e+'\x20Status:\x20'+_0x45a860['status']),_0x398e7e(_0x45a860['status']);_0x398e7e=null;}},_0x45a860['open']('GET',_0x27f86e,!0x0),_0x45a860['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ba0a6){return this['rootNode_']['getChild'](_0x3ba0a6);}['updateSnapshot'](_0x271c9a,_0xead9a4){this['rootNode_']=this['rootNode_']['updateChild'](_0x271c9a,_0xead9a4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x1858db,_0x3d18bc,_0x320623){if(v(_0x3d18bc))_0x1858db['value']=_0x320623,_0x1858db['children']['clear']();else{if(_0x1858db['value']!==null)_0x1858db['value']=_0x1858db['value']['updateChild'](_0x3d18bc,_0x320623);else{const _0x4179ed=y(_0x3d18bc);_0x1858db['children']['has'](_0x4179ed)||_0x1858db['children']['set'](_0x4179ed,pn());const _0xbb43d1=_0x1858db['children']['get'](_0x4179ed);_0x3d18bc=b(_0x3d18bc),Mo(_0xbb43d1,_0x3d18bc,_0x320623);}}}function Ei(_0x49a5f8,_0x2a7d7d,_0x17406b){_0x49a5f8['value']!==null?_0x17406b(_0x2a7d7d,_0x49a5f8['value']):Qh(_0x49a5f8,(_0x2f388a,_0x542349)=>{const _0x4d8d6d=new C(_0x2a7d7d['toString']()+'/'+_0x2f388a);Ei(_0x542349,_0x4d8d6d,_0x17406b);});}function Qh(_0x69fcd5,_0x168a70){_0x69fcd5['children']['forEach']((_0x39ba1c,_0x1dd20a)=>{_0x168a70(_0x1dd20a,_0x39ba1c);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x5811bb){this['collection_']=_0x5811bb,this['last_']=null;}['get'](){const _0x4fddd4=this['collection_']['get'](),_0x3d1ade={..._0x4fddd4};return this['last_']&&x(this['last_'],(_0x526dca,_0x3220a8)=>{_0x3d1ade[_0x526dca]=_0x3d1ade[_0x526dca]-_0x3220a8;}),this['last_']=_0x4fddd4,_0x3d1ade;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x46f0c7,_0x5a2cd6){this['server_']=_0x5a2cd6,this['statsToReport_']={},this['statsListener_']=new Jh(_0x46f0c7);const _0x34b70e=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x34b70e));}['reportStats_'](){const _0x257adf=this['statsListener_']['get'](),_0x59d7c8={};let _0x542542=!0x1;x(_0x257adf,(_0x432784,_0xa5892b)=>{_0xa5892b>0x0&&Y(this['statsToReport_'],_0x432784)&&(_0x59d7c8[_0x432784]=_0xa5892b,_0x542542=!0x0);}),_0x542542&&this['server_']['reportStats'](_0x59d7c8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x127281){_0x127281[_0x127281['OVERWRITE']=0x0]='OVERWRITE',_0x127281[_0x127281['MERGE']=0x1]='MERGE',_0x127281[_0x127281['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x127281[_0x127281['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x16eeb2){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x16eeb2,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x430182,_0x5dfc4f,_0x27ae0f){this['path']=_0x430182,this['affectedTree']=_0x5dfc4f,this['revert']=_0x27ae0f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5d01ee){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x144062=this['affectedTree']['subtree'](new C(_0x5d01ee));return new _n(w(),_0x144062,this['revert']);}}else return f(y(this['path'])===_0x5d01ee,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x27be80,_0x1d6684){this['source']=_0x27be80,this['path']=_0x1d6684,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x90fb66){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0xd15748,_0x142813,_0x20f9a7){this['source']=_0xd15748,this['path']=_0x142813,this['snap']=_0x20f9a7,this['type']=q['OVERWRITE'];}['operationForChild'](_0x41ac8a){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x41ac8a)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x149573,_0x183776,_0x5a5573){this['source']=_0x149573,this['path']=_0x183776,this['children']=_0x5a5573,this['type']=q['MERGE'];}['operationForChild'](_0x1c39b8){if(v(this['path'])){const _0x3cd7d4=this['children']['subtree'](new C(_0x1c39b8));return _0x3cd7d4['isEmpty']()?null:_0x3cd7d4['value']?new Fe(this['source'],w(),_0x3cd7d4['value']):new nt(this['source'],w(),_0x3cd7d4);}else return f(y(this['path'])===_0x1c39b8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x359bb6,_0x264443,_0x5d9bcd){this['node_']=_0x359bb6,this['fullyInitialized_']=_0x264443,this['filtered_']=_0x5d9bcd;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3fed3f){if(v(_0x3fed3f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x336a57=y(_0x3fed3f);return this['isCompleteForChild'](_0x336a57);}['isCompleteForChild'](_0x18fa98){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x18fa98);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x187e62){this['query_']=_0x187e62,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x2a927a,_0x580ae9,_0x3120c9,_0x1ae84b){const _0x2f7a48=[],_0x288d74=[];return _0x580ae9['forEach'](_0x1118c2=>{_0x1118c2['type']==='child_changed'&&_0x2a927a['index_']['indexedValueChanged'](_0x1118c2['oldSnap'],_0x1118c2['snapshotNode'])&&_0x288d74['push']($h(_0x1118c2['childName'],_0x1118c2['snapshotNode']));}),mt(_0x2a927a,_0x2f7a48,'child_removed',_0x580ae9,_0x1ae84b,_0x3120c9),mt(_0x2a927a,_0x2f7a48,'child_added',_0x580ae9,_0x1ae84b,_0x3120c9),mt(_0x2a927a,_0x2f7a48,'child_moved',_0x288d74,_0x1ae84b,_0x3120c9),mt(_0x2a927a,_0x2f7a48,'child_changed',_0x580ae9,_0x1ae84b,_0x3120c9),mt(_0x2a927a,_0x2f7a48,'value',_0x580ae9,_0x1ae84b,_0x3120c9),_0x2f7a48;}function mt(_0xb2bf8e,_0x435798,_0x5300eb,_0x142f60,_0x149d2d,_0xfeeb63){const _0x4c6033=_0x142f60['filter'](_0x814c0f=>_0x814c0f['type']===_0x5300eb);_0x4c6033['sort']((_0xf2cf8e,_0x9886db)=>su(_0xb2bf8e,_0xf2cf8e,_0x9886db)),_0x4c6033['forEach'](_0x5e3fb6=>{const _0x4af20f=iu(_0xb2bf8e,_0x5e3fb6,_0xfeeb63);_0x149d2d['forEach'](_0x2f26c6=>{_0x2f26c6['respondsTo'](_0x5e3fb6['type'])&&_0x435798['push'](_0x2f26c6['createEvent'](_0x4af20f,_0xb2bf8e['query_']));});});}function iu(_0x105580,_0x271d21,_0x16121b){return _0x271d21['type']==='value'||_0x271d21['type']==='child_removed'||(_0x271d21['prevName']=_0x16121b['getPredecessorChildName'](_0x271d21['childName'],_0x271d21['snapshotNode'],_0x105580['index_'])),_0x271d21;}function su(_0x5f34c2,_0x52d956,_0x59dd41){if(_0x52d956['childName']==null||_0x59dd41['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x95248a=new E(_0x52d956['childName'],_0x52d956['snapshotNode']),_0x6330e5=new E(_0x59dd41['childName'],_0x59dd41['snapshotNode']);return _0x5f34c2['index_']['compare'](_0x95248a,_0x6330e5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x14aaa3,_0x4e37b0){return{'eventCache':_0x14aaa3,'serverCache':_0x4e37b0};}function wt(_0xc78267,_0x1f4bf9,_0x212205,_0x2663d3){return Dn(new Ce(_0x1f4bf9,_0x212205,_0x2663d3),_0xc78267['serverCache']);}function Lo(_0x5878f1,_0x3a11be,_0x29f36d,_0x4f4b37){return Dn(_0x5878f1['eventCache'],new Ce(_0x3a11be,_0x29f36d,_0x4f4b37));}function gn(_0x19be11){return _0x19be11['eventCache']['isFullyInitialized']()?_0x19be11['eventCache']['getNode']():null;}function Ue(_0x5cf02d){return _0x5cf02d['serverCache']['isFullyInitialized']()?_0x5cf02d['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2106e4){let _0x241574=new S(null);return x(_0x2106e4,(_0x494409,_0x3cdcda)=>{_0x241574=_0x241574['set'](new C(_0x494409),_0x3cdcda);}),_0x241574;}constructor(_0x9b8932,_0x44573f=ru()){this['value']=_0x9b8932,this['children']=_0x44573f;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x7c3bbf,_0x1bc16d){if(this['value']!=null&&_0x1bc16d(this['value']))return{'path':w(),'value':this['value']};if(v(_0x7c3bbf))return null;{const _0x4d37d1=y(_0x7c3bbf),_0x5c607d=this['children']['get'](_0x4d37d1);if(_0x5c607d!==null){const _0x154ebc=_0x5c607d['findRootMostMatchingPathAndValue'](b(_0x7c3bbf),_0x1bc16d);return _0x154ebc!=null?{'path':A(new C(_0x4d37d1),_0x154ebc['path']),'value':_0x154ebc['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5e6413){return this['findRootMostMatchingPathAndValue'](_0x5e6413,()=>!0x0);}['subtree'](_0x2bf63a){if(v(_0x2bf63a))return this;{const _0x5b3e99=y(_0x2bf63a),_0x3dd478=this['children']['get'](_0x5b3e99);return _0x3dd478!==null?_0x3dd478['subtree'](b(_0x2bf63a)):new S(null);}}['set'](_0x4bd4db,_0x431e8a){if(v(_0x4bd4db))return new S(_0x431e8a,this['children']);{const _0x2aa2b2=y(_0x4bd4db),_0x9ba037=(this['children']['get'](_0x2aa2b2)||new S(null))['set'](b(_0x4bd4db),_0x431e8a),_0x321f01=this['children']['insert'](_0x2aa2b2,_0x9ba037);return new S(this['value'],_0x321f01);}}['remove'](_0xf7283e){if(v(_0xf7283e))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x2b3071=y(_0xf7283e),_0x2847e0=this['children']['get'](_0x2b3071);if(_0x2847e0){const _0x5df077=_0x2847e0['remove'](b(_0xf7283e));let _0x4a03f8;return _0x5df077['isEmpty']()?_0x4a03f8=this['children']['remove'](_0x2b3071):_0x4a03f8=this['children']['insert'](_0x2b3071,_0x5df077),this['value']===null&&_0x4a03f8['isEmpty']()?new S(null):new S(this['value'],_0x4a03f8);}else return this;}}['get'](_0x18fe07){if(v(_0x18fe07))return this['value'];{const _0x2c515c=y(_0x18fe07),_0x218c05=this['children']['get'](_0x2c515c);return _0x218c05?_0x218c05['get'](b(_0x18fe07)):null;}}['setTree'](_0x238052,_0x3608c2){if(v(_0x238052))return _0x3608c2;{const _0xd24c18=y(_0x238052),_0x4ec8f7=(this['children']['get'](_0xd24c18)||new S(null))['setTree'](b(_0x238052),_0x3608c2);let _0x536da6;return _0x4ec8f7['isEmpty']()?_0x536da6=this['children']['remove'](_0xd24c18):_0x536da6=this['children']['insert'](_0xd24c18,_0x4ec8f7),new S(this['value'],_0x536da6);}}['fold'](_0x53a0a1){return this['fold_'](w(),_0x53a0a1);}['fold_'](_0x4df383,_0x2a8ee3){const _0x38afe2={};return this['children']['inorderTraversal']((_0x592c4c,_0xb238a)=>{_0x38afe2[_0x592c4c]=_0xb238a['fold_'](A(_0x4df383,_0x592c4c),_0x2a8ee3);}),_0x2a8ee3(_0x4df383,this['value'],_0x38afe2);}['findOnPath'](_0x124416,_0x2ffd16){return this['findOnPath_'](_0x124416,w(),_0x2ffd16);}['findOnPath_'](_0x14d6bd,_0x24c060,_0x5a6091){const _0x2ca53c=this['value']?_0x5a6091(_0x24c060,this['value']):!0x1;if(_0x2ca53c)return _0x2ca53c;if(v(_0x14d6bd))return null;{const _0x5a73e6=y(_0x14d6bd),_0x51ea28=this['children']['get'](_0x5a73e6);return _0x51ea28?_0x51ea28['findOnPath_'](b(_0x14d6bd),A(_0x24c060,_0x5a73e6),_0x5a6091):null;}}['foreachOnPath'](_0x4ef779,_0xb0d8af){return this['foreachOnPath_'](_0x4ef779,w(),_0xb0d8af);}['foreachOnPath_'](_0x33afef,_0x461b26,_0x4c3694){if(v(_0x33afef))return this;{this['value']&&_0x4c3694(_0x461b26,this['value']);const _0x3a6ac8=y(_0x33afef),_0x55ce7a=this['children']['get'](_0x3a6ac8);return _0x55ce7a?_0x55ce7a['foreachOnPath_'](b(_0x33afef),A(_0x461b26,_0x3a6ac8),_0x4c3694):new S(null);}}['foreach'](_0x14851c){this['foreach_'](w(),_0x14851c);}['foreach_'](_0x345a3c,_0x2ff8a0){this['children']['inorderTraversal']((_0x2b17f3,_0x51d4b8)=>{_0x51d4b8['foreach_'](A(_0x345a3c,_0x2b17f3),_0x2ff8a0);}),this['value']&&_0x2ff8a0(_0x345a3c,this['value']);}['foreachChild'](_0x5d8336){this['children']['inorderTraversal']((_0x2f5177,_0x4d8ab1)=>{_0x4d8ab1['value']&&_0x5d8336(_0x2f5177,_0x4d8ab1['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x3f7c15){this['writeTree_']=_0x3f7c15;}static['empty'](){return new j(new S(null));}}function Ct(_0x30a883,_0x483c6b,_0x3e6f2a){if(v(_0x483c6b))return new j(new S(_0x3e6f2a));{const _0x5e91ec=_0x30a883['writeTree_']['findRootMostValueAndPath'](_0x483c6b);if(_0x5e91ec!=null){const _0x256ac7=_0x5e91ec['path'];let _0x198bc1=_0x5e91ec['value'];const _0x105e45=F(_0x256ac7,_0x483c6b);return _0x198bc1=_0x198bc1['updateChild'](_0x105e45,_0x3e6f2a),new j(_0x30a883['writeTree_']['set'](_0x256ac7,_0x198bc1));}else{const _0x4d27b4=new S(_0x3e6f2a),_0x2a4058=_0x30a883['writeTree_']['setTree'](_0x483c6b,_0x4d27b4);return new j(_0x2a4058);}}}function Ii(_0x248c7a,_0x485cdb,_0x129b31){let _0xf8728a=_0x248c7a;return x(_0x129b31,(_0x3a6bbe,_0x14f475)=>{_0xf8728a=Ct(_0xf8728a,A(_0x485cdb,_0x3a6bbe),_0x14f475);}),_0xf8728a;}function sr(_0x2e42df,_0x245c6b){if(v(_0x245c6b))return j['empty']();{const _0x19eacc=_0x2e42df['writeTree_']['setTree'](_0x245c6b,new S(null));return new j(_0x19eacc);}}function wi(_0x5eb3ac,_0x4f8367){return $e(_0x5eb3ac,_0x4f8367)!=null;}function $e(_0x5b15d8,_0x1f7e45){const _0x3b3d77=_0x5b15d8['writeTree_']['findRootMostValueAndPath'](_0x1f7e45);return _0x3b3d77!=null?_0x5b15d8['writeTree_']['get'](_0x3b3d77['path'])['getChild'](F(_0x3b3d77['path'],_0x1f7e45)):null;}function rr(_0x4cbc88){const _0x495609=[],_0x2eb160=_0x4cbc88['writeTree_']['value'];return _0x2eb160!=null?_0x2eb160['isLeafNode']()||_0x2eb160['forEachChild'](R,(_0x2b5254,_0x1a4d1b)=>{_0x495609['push'](new E(_0x2b5254,_0x1a4d1b));}):_0x4cbc88['writeTree_']['children']['inorderTraversal']((_0x4c4d48,_0x1a4f07)=>{_0x1a4f07['value']!=null&&_0x495609['push'](new E(_0x4c4d48,_0x1a4f07['value']));}),_0x495609;}function ve(_0xbf6cd4,_0x14f8c8){if(v(_0x14f8c8))return _0xbf6cd4;{const _0x2a82a6=$e(_0xbf6cd4,_0x14f8c8);return _0x2a82a6!=null?new j(new S(_0x2a82a6)):new j(_0xbf6cd4['writeTree_']['subtree'](_0x14f8c8));}}function Ci(_0x1d2ec2){return _0x1d2ec2['writeTree_']['isEmpty']();}function it(_0x3cd360,_0x1076d8){return xo(w(),_0x3cd360['writeTree_'],_0x1076d8);}function xo(_0x19804a,_0xbc5af3,_0x253fc3){if(_0xbc5af3['value']!=null)return _0x253fc3['updateChild'](_0x19804a,_0xbc5af3['value']);{let _0x5742f4=null;return _0xbc5af3['children']['inorderTraversal']((_0x1e4576,_0x418c23)=>{_0x1e4576==='.priority'?(f(_0x418c23['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5742f4=_0x418c23['value']):_0x253fc3=xo(A(_0x19804a,_0x1e4576),_0x418c23,_0x253fc3);}),!_0x253fc3['getChild'](_0x19804a)['isEmpty']()&&_0x5742f4!==null&&(_0x253fc3=_0x253fc3['updateChild'](A(_0x19804a,'.priority'),_0x5742f4)),_0x253fc3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x232f15,_0x2eed2b){return Bo(_0x2eed2b,_0x232f15);}function ou(_0x2b646c,_0x5600b7,_0x3285ea,_0x366641,_0x2ee554){f(_0x366641>_0x2b646c['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2ee554===void 0x0&&(_0x2ee554=!0x0),_0x2b646c['allWrites']['push']({'path':_0x5600b7,'snap':_0x3285ea,'writeId':_0x366641,'visible':_0x2ee554}),_0x2ee554&&(_0x2b646c['visibleWrites']=Ct(_0x2b646c['visibleWrites'],_0x5600b7,_0x3285ea)),_0x2b646c['lastWriteId']=_0x366641;}function au(_0x1d4f4e,_0x5bb04e,_0x2ff12e,_0x5762bb){f(_0x5762bb>_0x1d4f4e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1d4f4e['allWrites']['push']({'path':_0x5bb04e,'children':_0x2ff12e,'writeId':_0x5762bb,'visible':!0x0}),_0x1d4f4e['visibleWrites']=Ii(_0x1d4f4e['visibleWrites'],_0x5bb04e,_0x2ff12e),_0x1d4f4e['lastWriteId']=_0x5762bb;}function cu(_0x1182b2,_0x726d94){for(let _0x4cc336=0x0;_0x4cc336<_0x1182b2['allWrites']['length'];_0x4cc336++){const _0x4806a2=_0x1182b2['allWrites'][_0x4cc336];if(_0x4806a2['writeId']===_0x726d94)return _0x4806a2;}return null;}function lu(_0x2f5523,_0x16062b){const _0x3b60eb=_0x2f5523['allWrites']['findIndex'](_0x4dc123=>_0x4dc123['writeId']===_0x16062b);f(_0x3b60eb>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4db3b8=_0x2f5523['allWrites'][_0x3b60eb];_0x2f5523['allWrites']['splice'](_0x3b60eb,0x1);let _0x3c92b0=_0x4db3b8['visible'],_0x51bbad=!0x1,_0x125a7f=_0x2f5523['allWrites']['length']-0x1;for(;_0x3c92b0&&_0x125a7f>=0x0;){const _0x23d8c7=_0x2f5523['allWrites'][_0x125a7f];_0x23d8c7['visible']&&(_0x125a7f>=_0x3b60eb&&hu(_0x23d8c7,_0x4db3b8['path'])?_0x3c92b0=!0x1:$(_0x4db3b8['path'],_0x23d8c7['path'])&&(_0x51bbad=!0x0)),_0x125a7f--;}if(_0x3c92b0){if(_0x51bbad)return uu(_0x2f5523),!0x0;if(_0x4db3b8['snap'])_0x2f5523['visibleWrites']=sr(_0x2f5523['visibleWrites'],_0x4db3b8['path']);else{const _0x5e1f85=_0x4db3b8['children'];x(_0x5e1f85,_0xb2b437=>{_0x2f5523['visibleWrites']=sr(_0x2f5523['visibleWrites'],A(_0x4db3b8['path'],_0xb2b437));});}return!0x0;}else return!0x1;}function hu(_0x391a32,_0x4a15c0){if(_0x391a32['snap'])return $(_0x391a32['path'],_0x4a15c0);for(const _0x272a18 in _0x391a32['children'])if(_0x391a32['children']['hasOwnProperty'](_0x272a18)&&$(A(_0x391a32['path'],_0x272a18),_0x4a15c0))return!0x0;return!0x1;}function uu(_0x3b40e1){_0x3b40e1['visibleWrites']=Fo(_0x3b40e1['allWrites'],du,w()),_0x3b40e1['allWrites']['length']>0x0?_0x3b40e1['lastWriteId']=_0x3b40e1['allWrites'][_0x3b40e1['allWrites']['length']-0x1]['writeId']:_0x3b40e1['lastWriteId']=-0x1;}function du(_0x139b9e){return _0x139b9e['visible'];}function Fo(_0x559c76,_0x5da1cf,_0x2215c5){let _0x440209=j['empty']();for(let _0x4e9fce=0x0;_0x4e9fce<_0x559c76['length'];++_0x4e9fce){const _0x2e9ff5=_0x559c76[_0x4e9fce];if(_0x5da1cf(_0x2e9ff5)){const _0x57bc67=_0x2e9ff5['path'];let _0x4eb336;if(_0x2e9ff5['snap'])$(_0x2215c5,_0x57bc67)?(_0x4eb336=F(_0x2215c5,_0x57bc67),_0x440209=Ct(_0x440209,_0x4eb336,_0x2e9ff5['snap'])):$(_0x57bc67,_0x2215c5)&&(_0x4eb336=F(_0x57bc67,_0x2215c5),_0x440209=Ct(_0x440209,w(),_0x2e9ff5['snap']['getChild'](_0x4eb336)));else{if(_0x2e9ff5['children']){if($(_0x2215c5,_0x57bc67))_0x4eb336=F(_0x2215c5,_0x57bc67),_0x440209=Ii(_0x440209,_0x4eb336,_0x2e9ff5['children']);else{if($(_0x57bc67,_0x2215c5)){if(_0x4eb336=F(_0x57bc67,_0x2215c5),v(_0x4eb336))_0x440209=Ii(_0x440209,w(),_0x2e9ff5['children']);else{const _0xd6ffa5=Oe(_0x2e9ff5['children'],y(_0x4eb336));if(_0xd6ffa5){const _0x529e5a=_0xd6ffa5['getChild'](b(_0x4eb336));_0x440209=Ct(_0x440209,w(),_0x529e5a);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x440209;}function Uo(_0x39d1b4,_0x1cab74,_0x46783d,_0x109c24,_0x27fd45){if(!_0x109c24&&!_0x27fd45){const _0x18a5a=$e(_0x39d1b4['visibleWrites'],_0x1cab74);if(_0x18a5a!=null)return _0x18a5a;{const _0x1aabd0=ve(_0x39d1b4['visibleWrites'],_0x1cab74);if(Ci(_0x1aabd0))return _0x46783d;if(_0x46783d==null&&!wi(_0x1aabd0,w()))return null;{const _0x14a1d2=_0x46783d||g['EMPTY_NODE'];return it(_0x1aabd0,_0x14a1d2);}}}else{const _0xa15efa=ve(_0x39d1b4['visibleWrites'],_0x1cab74);if(!_0x27fd45&&Ci(_0xa15efa))return _0x46783d;if(!_0x27fd45&&_0x46783d==null&&!wi(_0xa15efa,w()))return null;{const _0x4c9a44=function(_0xa309ce){return(_0xa309ce['visible']||_0x27fd45)&&(!_0x109c24||!~_0x109c24['indexOf'](_0xa309ce['writeId']))&&($(_0xa309ce['path'],_0x1cab74)||$(_0x1cab74,_0xa309ce['path']));},_0x503905=Fo(_0x39d1b4['allWrites'],_0x4c9a44,_0x1cab74),_0xda2c95=_0x46783d||g['EMPTY_NODE'];return it(_0x503905,_0xda2c95);}}}function fu(_0x581ebe,_0x1a8e40,_0x23a2dd){let _0x33b30e=g['EMPTY_NODE'];const _0x498cc6=$e(_0x581ebe['visibleWrites'],_0x1a8e40);if(_0x498cc6)return _0x498cc6['isLeafNode']()||_0x498cc6['forEachChild'](R,(_0x2a37ff,_0x5341a6)=>{_0x33b30e=_0x33b30e['updateImmediateChild'](_0x2a37ff,_0x5341a6);}),_0x33b30e;if(_0x23a2dd){const _0x55977c=ve(_0x581ebe['visibleWrites'],_0x1a8e40);return _0x23a2dd['forEachChild'](R,(_0x2b79ec,_0x5d3b05)=>{const _0x452d48=it(ve(_0x55977c,new C(_0x2b79ec)),_0x5d3b05);_0x33b30e=_0x33b30e['updateImmediateChild'](_0x2b79ec,_0x452d48);}),rr(_0x55977c)['forEach'](_0x26f548=>{_0x33b30e=_0x33b30e['updateImmediateChild'](_0x26f548['name'],_0x26f548['node']);}),_0x33b30e;}else{const _0x1a9145=ve(_0x581ebe['visibleWrites'],_0x1a8e40);return rr(_0x1a9145)['forEach'](_0x3f6247=>{_0x33b30e=_0x33b30e['updateImmediateChild'](_0x3f6247['name'],_0x3f6247['node']);}),_0x33b30e;}}function pu(_0x402d4f,_0x2e05ba,_0x494c62,_0x122dce,_0xeff387){f(_0x122dce||_0xeff387,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1f28b9=A(_0x2e05ba,_0x494c62);if(wi(_0x402d4f['visibleWrites'],_0x1f28b9))return null;{const _0x1c8281=ve(_0x402d4f['visibleWrites'],_0x1f28b9);return Ci(_0x1c8281)?_0xeff387['getChild'](_0x494c62):it(_0x1c8281,_0xeff387['getChild'](_0x494c62));}}function _u(_0x753747,_0x4df8a5,_0x3bcd03,_0x4985ec){const _0x1aac38=A(_0x4df8a5,_0x3bcd03),_0x280043=$e(_0x753747['visibleWrites'],_0x1aac38);if(_0x280043!=null)return _0x280043;if(_0x4985ec['isCompleteForChild'](_0x3bcd03)){const _0x54248d=ve(_0x753747['visibleWrites'],_0x1aac38);return it(_0x54248d,_0x4985ec['getNode']()['getImmediateChild'](_0x3bcd03));}else return null;}function gu(_0x4ab8e4,_0x264c0f){return $e(_0x4ab8e4['visibleWrites'],_0x264c0f);}function mu(_0x5222b2,_0x28a2f4,_0x5dd14f,_0x58e780,_0x5bfba1,_0x1e2d50,_0x137850){let _0xea4194;const _0x583044=ve(_0x5222b2['visibleWrites'],_0x28a2f4),_0x57b020=$e(_0x583044,w());if(_0x57b020!=null)_0xea4194=_0x57b020;else{if(_0x5dd14f!=null)_0xea4194=it(_0x583044,_0x5dd14f);else return[];}if(_0xea4194=_0xea4194['withIndex'](_0x137850),!_0xea4194['isEmpty']()&&!_0xea4194['isLeafNode']()){const _0x48738c=[],_0x4a3479=_0x137850['getCompare'](),_0xa83f2d=_0x1e2d50?_0xea4194['getReverseIteratorFrom'](_0x58e780,_0x137850):_0xea4194['getIteratorFrom'](_0x58e780,_0x137850);let _0x191c5c=_0xa83f2d['getNext']();for(;_0x191c5c&&_0x48738c['length']<_0x5bfba1;)_0x4a3479(_0x191c5c,_0x58e780)!==0x0&&_0x48738c['push'](_0x191c5c),_0x191c5c=_0xa83f2d['getNext']();return _0x48738c;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x164b5c,_0xb45ab6,_0x33d4d2,_0x2c45ee){return Uo(_0x164b5c['writeTree'],_0x164b5c['treePath'],_0xb45ab6,_0x33d4d2,_0x2c45ee);}function es(_0x3c1273,_0x1d5e5a){return fu(_0x3c1273['writeTree'],_0x3c1273['treePath'],_0x1d5e5a);}function or(_0x44fcd4,_0x1e4a67,_0x3c8120,_0x31cfaa){return pu(_0x44fcd4['writeTree'],_0x44fcd4['treePath'],_0x1e4a67,_0x3c8120,_0x31cfaa);}function yn(_0xe0ed14,_0x2a190f){return gu(_0xe0ed14['writeTree'],A(_0xe0ed14['treePath'],_0x2a190f));}function vu(_0x57de40,_0x4f184f,_0x503c9d,_0x4fc294,_0x5779a4,_0x2bf2bc){return mu(_0x57de40['writeTree'],_0x57de40['treePath'],_0x4f184f,_0x503c9d,_0x4fc294,_0x5779a4,_0x2bf2bc);}function ts(_0x220323,_0x6f9c19,_0x417427){return _u(_0x220323['writeTree'],_0x220323['treePath'],_0x6f9c19,_0x417427);}function Wo(_0x2125bd,_0x45981b){return Bo(A(_0x2125bd['treePath'],_0x45981b),_0x2125bd['writeTree']);}function Bo(_0x1a23a1,_0x47ea1d){return{'treePath':_0x1a23a1,'writeTree':_0x47ea1d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x28edee){const _0x1b312c=_0x28edee['type'],_0x225654=_0x28edee['childName'];f(_0x1b312c==='child_added'||_0x1b312c==='child_changed'||_0x1b312c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x225654!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x38bd70=this['changeMap']['get'](_0x225654);if(_0x38bd70){const _0x2d39c6=_0x38bd70['type'];if(_0x1b312c==='child_added'&&_0x2d39c6==='child_removed')this['changeMap']['set'](_0x225654,Pt(_0x225654,_0x28edee['snapshotNode'],_0x38bd70['snapshotNode']));else{if(_0x1b312c==='child_removed'&&_0x2d39c6==='child_added')this['changeMap']['delete'](_0x225654);else{if(_0x1b312c==='child_removed'&&_0x2d39c6==='child_changed')this['changeMap']['set'](_0x225654,Nt(_0x225654,_0x38bd70['oldSnap']));else{if(_0x1b312c==='child_changed'&&_0x2d39c6==='child_added')this['changeMap']['set'](_0x225654,tt(_0x225654,_0x28edee['snapshotNode']));else{if(_0x1b312c==='child_changed'&&_0x2d39c6==='child_changed')this['changeMap']['set'](_0x225654,Pt(_0x225654,_0x28edee['snapshotNode'],_0x38bd70['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x28edee+'\x20occurred\x20after\x20'+_0x38bd70);}}}}}else this['changeMap']['set'](_0x225654,_0x28edee);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4f7d25){return null;}['getChildAfterChild'](_0xed6e8d,_0x35e14a,_0xa5d310){return null;}}const Vo=new Iu();class ns{constructor(_0x55a833,_0x2fc497,_0x2bdf97=null){this['writes_']=_0x55a833,this['viewCache_']=_0x2fc497,this['optCompleteServerCache_']=_0x2bdf97;}['getCompleteChild'](_0x46fc9b){const _0x27b337=this['viewCache_']['eventCache'];if(_0x27b337['isCompleteForChild'](_0x46fc9b))return _0x27b337['getNode']()['getImmediateChild'](_0x46fc9b);{const _0x591d63=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x46fc9b,_0x591d63);}}['getChildAfterChild'](_0x162699,_0x1d12dc,_0xdbcf27){const _0x1ecb2f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x2ae7a0=vu(this['writes_'],_0x1ecb2f,_0x1d12dc,0x1,_0xdbcf27,_0x162699);return _0x2ae7a0['length']===0x0?null:_0x2ae7a0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x5132d3){return{'filter':_0x5132d3};}function Cu(_0x28376a,_0x425ff7){f(_0x425ff7['eventCache']['getNode']()['isIndexed'](_0x28376a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x425ff7['serverCache']['getNode']()['isIndexed'](_0x28376a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x47a7bd,_0xc3f693,_0x3188f0,_0x5d4145,_0x4fa9d2){const _0xc5a8a1=new Eu();let _0x3c1cb0,_0x5c8b4c;if(_0x3188f0['type']===q['OVERWRITE']){const _0x79abf7=_0x3188f0;_0x79abf7['source']['fromUser']?_0x3c1cb0=Ti(_0x47a7bd,_0xc3f693,_0x79abf7['path'],_0x79abf7['snap'],_0x5d4145,_0x4fa9d2,_0xc5a8a1):(f(_0x79abf7['source']['fromServer'],'Unknown\x20source.'),_0x5c8b4c=_0x79abf7['source']['tagged']||_0xc3f693['serverCache']['isFiltered']()&&!v(_0x79abf7['path']),_0x3c1cb0=vn(_0x47a7bd,_0xc3f693,_0x79abf7['path'],_0x79abf7['snap'],_0x5d4145,_0x4fa9d2,_0x5c8b4c,_0xc5a8a1));}else{if(_0x3188f0['type']===q['MERGE']){const _0x67edf7=_0x3188f0;_0x67edf7['source']['fromUser']?_0x3c1cb0=bu(_0x47a7bd,_0xc3f693,_0x67edf7['path'],_0x67edf7['children'],_0x5d4145,_0x4fa9d2,_0xc5a8a1):(f(_0x67edf7['source']['fromServer'],'Unknown\x20source.'),_0x5c8b4c=_0x67edf7['source']['tagged']||_0xc3f693['serverCache']['isFiltered'](),_0x3c1cb0=Si(_0x47a7bd,_0xc3f693,_0x67edf7['path'],_0x67edf7['children'],_0x5d4145,_0x4fa9d2,_0x5c8b4c,_0xc5a8a1));}else{if(_0x3188f0['type']===q['ACK_USER_WRITE']){const _0x503eb7=_0x3188f0;_0x503eb7['revert']?_0x3c1cb0=ku(_0x47a7bd,_0xc3f693,_0x503eb7['path'],_0x5d4145,_0x4fa9d2,_0xc5a8a1):_0x3c1cb0=Ru(_0x47a7bd,_0xc3f693,_0x503eb7['path'],_0x503eb7['affectedTree'],_0x5d4145,_0x4fa9d2,_0xc5a8a1);}else{if(_0x3188f0['type']===q['LISTEN_COMPLETE'])_0x3c1cb0=Au(_0x47a7bd,_0xc3f693,_0x3188f0['path'],_0x5d4145,_0xc5a8a1);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3188f0['type']);}}}const _0x14aec6=_0xc5a8a1['getChanges']();return Su(_0xc3f693,_0x3c1cb0,_0x14aec6),{'viewCache':_0x3c1cb0,'changes':_0x14aec6};}function Su(_0x4337c7,_0x33de1a,_0x2d768c){const _0x480f9c=_0x33de1a['eventCache'];if(_0x480f9c['isFullyInitialized']()){const _0x143847=_0x480f9c['getNode']()['isLeafNode']()||_0x480f9c['getNode']()['isEmpty'](),_0x380853=gn(_0x4337c7);(_0x2d768c['length']>0x0||!_0x4337c7['eventCache']['isFullyInitialized']()||_0x143847&&!_0x480f9c['getNode']()['equals'](_0x380853)||!_0x480f9c['getNode']()['getPriority']()['equals'](_0x380853['getPriority']()))&&_0x2d768c['push'](Oo(gn(_0x33de1a)));}}function Ho(_0x1efed3,_0xaa8230,_0x11a3eb,_0x4136fd,_0x5afbd2,_0x450da7){const _0x1097da=_0xaa8230['eventCache'];if(yn(_0x4136fd,_0x11a3eb)!=null)return _0xaa8230;{let _0xd129df,_0x2d353c;if(v(_0x11a3eb)){if(f(_0xaa8230['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xaa8230['serverCache']['isFiltered']()){const _0x8eef64=Ue(_0xaa8230),_0x5c3d34=_0x8eef64 instanceof g?_0x8eef64:g['EMPTY_NODE'],_0xe4b796=es(_0x4136fd,_0x5c3d34);_0xd129df=_0x1efed3['filter']['updateFullNode'](_0xaa8230['eventCache']['getNode'](),_0xe4b796,_0x450da7);}else{const _0x5b7fac=mn(_0x4136fd,Ue(_0xaa8230));_0xd129df=_0x1efed3['filter']['updateFullNode'](_0xaa8230['eventCache']['getNode'](),_0x5b7fac,_0x450da7);}}else{const _0x3156a0=y(_0x11a3eb);if(_0x3156a0==='.priority'){f(we(_0x11a3eb)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x10ea6e=_0x1097da['getNode']();_0x2d353c=_0xaa8230['serverCache']['getNode']();const _0x36b3ae=or(_0x4136fd,_0x11a3eb,_0x10ea6e,_0x2d353c);_0x36b3ae!=null?_0xd129df=_0x1efed3['filter']['updatePriority'](_0x10ea6e,_0x36b3ae):_0xd129df=_0x1097da['getNode']();}else{const _0x501b31=b(_0x11a3eb);let _0x495b2f;if(_0x1097da['isCompleteForChild'](_0x3156a0)){_0x2d353c=_0xaa8230['serverCache']['getNode']();const _0x34771e=or(_0x4136fd,_0x11a3eb,_0x1097da['getNode'](),_0x2d353c);_0x34771e!=null?_0x495b2f=_0x1097da['getNode']()['getImmediateChild'](_0x3156a0)['updateChild'](_0x501b31,_0x34771e):_0x495b2f=_0x1097da['getNode']()['getImmediateChild'](_0x3156a0);}else _0x495b2f=ts(_0x4136fd,_0x3156a0,_0xaa8230['serverCache']);_0x495b2f!=null?_0xd129df=_0x1efed3['filter']['updateChild'](_0x1097da['getNode'](),_0x3156a0,_0x495b2f,_0x501b31,_0x5afbd2,_0x450da7):_0xd129df=_0x1097da['getNode']();}}return wt(_0xaa8230,_0xd129df,_0x1097da['isFullyInitialized']()||v(_0x11a3eb),_0x1efed3['filter']['filtersNodes']());}}function vn(_0xdf79a6,_0x3205e1,_0x2183a5,_0x2e8e6e,_0x592a2b,_0x393cac,_0x227647,_0xd23d9){const _0x227805=_0x3205e1['serverCache'];let _0x3a2afc;const _0x1c2f2e=_0x227647?_0xdf79a6['filter']:_0xdf79a6['filter']['getIndexedFilter']();if(v(_0x2183a5))_0x3a2afc=_0x1c2f2e['updateFullNode'](_0x227805['getNode'](),_0x2e8e6e,null);else{if(_0x1c2f2e['filtersNodes']()&&!_0x227805['isFiltered']()){const _0x4ee310=_0x227805['getNode']()['updateChild'](_0x2183a5,_0x2e8e6e);_0x3a2afc=_0x1c2f2e['updateFullNode'](_0x227805['getNode'](),_0x4ee310,null);}else{const _0x238af9=y(_0x2183a5);if(!_0x227805['isCompleteForPath'](_0x2183a5)&&we(_0x2183a5)>0x1)return _0x3205e1;const _0x2ba3d5=b(_0x2183a5),_0x1ede21=_0x227805['getNode']()['getImmediateChild'](_0x238af9)['updateChild'](_0x2ba3d5,_0x2e8e6e);_0x238af9==='.priority'?_0x3a2afc=_0x1c2f2e['updatePriority'](_0x227805['getNode'](),_0x1ede21):_0x3a2afc=_0x1c2f2e['updateChild'](_0x227805['getNode'](),_0x238af9,_0x1ede21,_0x2ba3d5,Vo,null);}}const _0x19061c=Lo(_0x3205e1,_0x3a2afc,_0x227805['isFullyInitialized']()||v(_0x2183a5),_0x1c2f2e['filtersNodes']()),_0x11df25=new ns(_0x592a2b,_0x19061c,_0x393cac);return Ho(_0xdf79a6,_0x19061c,_0x2183a5,_0x592a2b,_0x11df25,_0xd23d9);}function Ti(_0x15df50,_0x3df1a5,_0x1d0c62,_0x3be9ca,_0x28d26b,_0x52d5a9,_0x370d54){const _0x4d3aa5=_0x3df1a5['eventCache'];let _0x1e97b8,_0x594c5f;const _0x4258c4=new ns(_0x28d26b,_0x3df1a5,_0x52d5a9);if(v(_0x1d0c62))_0x594c5f=_0x15df50['filter']['updateFullNode'](_0x3df1a5['eventCache']['getNode'](),_0x3be9ca,_0x370d54),_0x1e97b8=wt(_0x3df1a5,_0x594c5f,!0x0,_0x15df50['filter']['filtersNodes']());else{const _0x526758=y(_0x1d0c62);if(_0x526758==='.priority')_0x594c5f=_0x15df50['filter']['updatePriority'](_0x3df1a5['eventCache']['getNode'](),_0x3be9ca),_0x1e97b8=wt(_0x3df1a5,_0x594c5f,_0x4d3aa5['isFullyInitialized'](),_0x4d3aa5['isFiltered']());else{const _0x4b6de0=b(_0x1d0c62),_0xa82914=_0x4d3aa5['getNode']()['getImmediateChild'](_0x526758);let _0x1bd84f;if(v(_0x4b6de0))_0x1bd84f=_0x3be9ca;else{const _0x5c9de1=_0x4258c4['getCompleteChild'](_0x526758);_0x5c9de1!=null?Gi(_0x4b6de0)==='.priority'&&_0x5c9de1['getChild'](To(_0x4b6de0))['isEmpty']()?_0x1bd84f=_0x5c9de1:_0x1bd84f=_0x5c9de1['updateChild'](_0x4b6de0,_0x3be9ca):_0x1bd84f=g['EMPTY_NODE'];}if(_0xa82914['equals'](_0x1bd84f))_0x1e97b8=_0x3df1a5;else{const _0x2703d8=_0x15df50['filter']['updateChild'](_0x4d3aa5['getNode'](),_0x526758,_0x1bd84f,_0x4b6de0,_0x4258c4,_0x370d54);_0x1e97b8=wt(_0x3df1a5,_0x2703d8,_0x4d3aa5['isFullyInitialized'](),_0x15df50['filter']['filtersNodes']());}}}return _0x1e97b8;}function ar(_0x1aa0fa,_0x18017d){return _0x1aa0fa['eventCache']['isCompleteForChild'](_0x18017d);}function bu(_0x250889,_0x1c909e,_0x1cda88,_0x4a40c6,_0x268cb3,_0x595d0d,_0x3eb891){let _0x37a14f=_0x1c909e;return _0x4a40c6['foreach']((_0x24fc0d,_0x34f623)=>{const _0x3c7a2a=A(_0x1cda88,_0x24fc0d);ar(_0x1c909e,y(_0x3c7a2a))&&(_0x37a14f=Ti(_0x250889,_0x37a14f,_0x3c7a2a,_0x34f623,_0x268cb3,_0x595d0d,_0x3eb891));}),_0x4a40c6['foreach']((_0x1948c8,_0x98ff5b)=>{const _0x157381=A(_0x1cda88,_0x1948c8);ar(_0x1c909e,y(_0x157381))||(_0x37a14f=Ti(_0x250889,_0x37a14f,_0x157381,_0x98ff5b,_0x268cb3,_0x595d0d,_0x3eb891));}),_0x37a14f;}function cr(_0x417693,_0xc455d7,_0x5305c2){return _0x5305c2['foreach']((_0x31002c,_0x52217b)=>{_0xc455d7=_0xc455d7['updateChild'](_0x31002c,_0x52217b);}),_0xc455d7;}function Si(_0x576c56,_0x4e7e5b,_0x2e9480,_0x2e52a8,_0x44a2ed,_0x268fb7,_0x2fcdd6,_0x410f84){if(_0x4e7e5b['serverCache']['getNode']()['isEmpty']()&&!_0x4e7e5b['serverCache']['isFullyInitialized']())return _0x4e7e5b;let _0x534d76=_0x4e7e5b,_0x337d4d;v(_0x2e9480)?_0x337d4d=_0x2e52a8:_0x337d4d=new S(null)['setTree'](_0x2e9480,_0x2e52a8);const _0x23804d=_0x4e7e5b['serverCache']['getNode']();return _0x337d4d['children']['inorderTraversal']((_0x58c3a3,_0x26f195)=>{if(_0x23804d['hasChild'](_0x58c3a3)){const _0x2ab813=_0x4e7e5b['serverCache']['getNode']()['getImmediateChild'](_0x58c3a3),_0x4f36cc=cr(_0x576c56,_0x2ab813,_0x26f195);_0x534d76=vn(_0x576c56,_0x534d76,new C(_0x58c3a3),_0x4f36cc,_0x44a2ed,_0x268fb7,_0x2fcdd6,_0x410f84);}}),_0x337d4d['children']['inorderTraversal']((_0x5f51f0,_0x260171)=>{const _0x123d2a=!_0x4e7e5b['serverCache']['isCompleteForChild'](_0x5f51f0)&&_0x260171['value']===null;if(!_0x23804d['hasChild'](_0x5f51f0)&&!_0x123d2a){const _0x3518e5=_0x4e7e5b['serverCache']['getNode']()['getImmediateChild'](_0x5f51f0),_0x3cb06b=cr(_0x576c56,_0x3518e5,_0x260171);_0x534d76=vn(_0x576c56,_0x534d76,new C(_0x5f51f0),_0x3cb06b,_0x44a2ed,_0x268fb7,_0x2fcdd6,_0x410f84);}}),_0x534d76;}function Ru(_0x5df4cf,_0x35ad0d,_0x3397f0,_0x1c7e69,_0x5089d1,_0x48645b,_0x4efc69){if(yn(_0x5089d1,_0x3397f0)!=null)return _0x35ad0d;const _0x3897e2=_0x35ad0d['serverCache']['isFiltered'](),_0x3833c8=_0x35ad0d['serverCache'];if(_0x1c7e69['value']!=null){if(v(_0x3397f0)&&_0x3833c8['isFullyInitialized']()||_0x3833c8['isCompleteForPath'](_0x3397f0))return vn(_0x5df4cf,_0x35ad0d,_0x3397f0,_0x3833c8['getNode']()['getChild'](_0x3397f0),_0x5089d1,_0x48645b,_0x3897e2,_0x4efc69);if(v(_0x3397f0)){let _0x4a89d8=new S(null);return _0x3833c8['getNode']()['forEachChild'](ye,(_0x4d75ce,_0x2b3efd)=>{_0x4a89d8=_0x4a89d8['set'](new C(_0x4d75ce),_0x2b3efd);}),Si(_0x5df4cf,_0x35ad0d,_0x3397f0,_0x4a89d8,_0x5089d1,_0x48645b,_0x3897e2,_0x4efc69);}else return _0x35ad0d;}else{let _0xdcfc91=new S(null);return _0x1c7e69['foreach']((_0x4864de,_0xbf1a78)=>{const _0x5b2ae2=A(_0x3397f0,_0x4864de);_0x3833c8['isCompleteForPath'](_0x5b2ae2)&&(_0xdcfc91=_0xdcfc91['set'](_0x4864de,_0x3833c8['getNode']()['getChild'](_0x5b2ae2)));}),Si(_0x5df4cf,_0x35ad0d,_0x3397f0,_0xdcfc91,_0x5089d1,_0x48645b,_0x3897e2,_0x4efc69);}}function Au(_0x598a59,_0x176606,_0x3de364,_0x1544d7,_0x4260b1){const _0x8d6c1c=_0x176606['serverCache'],_0xc9eab1=Lo(_0x176606,_0x8d6c1c['getNode'](),_0x8d6c1c['isFullyInitialized']()||v(_0x3de364),_0x8d6c1c['isFiltered']());return Ho(_0x598a59,_0xc9eab1,_0x3de364,_0x1544d7,Vo,_0x4260b1);}function ku(_0x4c2078,_0x4271fd,_0x4c05b6,_0x816383,_0x2ac9ec,_0x21ca5a){let _0xfdbd21;if(yn(_0x816383,_0x4c05b6)!=null)return _0x4271fd;{const _0x15b33b=new ns(_0x816383,_0x4271fd,_0x2ac9ec),_0x28ae90=_0x4271fd['eventCache']['getNode']();let _0x1e77ef;if(v(_0x4c05b6)||y(_0x4c05b6)==='.priority'){let _0x326401;if(_0x4271fd['serverCache']['isFullyInitialized']())_0x326401=mn(_0x816383,Ue(_0x4271fd));else{const _0x2970b3=_0x4271fd['serverCache']['getNode']();f(_0x2970b3 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x326401=es(_0x816383,_0x2970b3);}_0x326401=_0x326401,_0x1e77ef=_0x4c2078['filter']['updateFullNode'](_0x28ae90,_0x326401,_0x21ca5a);}else{const _0x488d0b=y(_0x4c05b6);let _0x3a358b=ts(_0x816383,_0x488d0b,_0x4271fd['serverCache']);_0x3a358b==null&&_0x4271fd['serverCache']['isCompleteForChild'](_0x488d0b)&&(_0x3a358b=_0x28ae90['getImmediateChild'](_0x488d0b)),_0x3a358b!=null?_0x1e77ef=_0x4c2078['filter']['updateChild'](_0x28ae90,_0x488d0b,_0x3a358b,b(_0x4c05b6),_0x15b33b,_0x21ca5a):_0x4271fd['eventCache']['getNode']()['hasChild'](_0x488d0b)?_0x1e77ef=_0x4c2078['filter']['updateChild'](_0x28ae90,_0x488d0b,g['EMPTY_NODE'],b(_0x4c05b6),_0x15b33b,_0x21ca5a):_0x1e77ef=_0x28ae90,_0x1e77ef['isEmpty']()&&_0x4271fd['serverCache']['isFullyInitialized']()&&(_0xfdbd21=mn(_0x816383,Ue(_0x4271fd)),_0xfdbd21['isLeafNode']()&&(_0x1e77ef=_0x4c2078['filter']['updateFullNode'](_0x1e77ef,_0xfdbd21,_0x21ca5a)));}return _0xfdbd21=_0x4271fd['serverCache']['isFullyInitialized']()||yn(_0x816383,w())!=null,wt(_0x4271fd,_0x1e77ef,_0xfdbd21,_0x4c2078['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x36c307,_0x3cdc69){this['query_']=_0x36c307,this['eventRegistrations_']=[];const _0x257c2d=this['query_']['_queryParams'],_0x34ffdc=new Yi(_0x257c2d['getIndex']()),_0x2ea2fe=qh(_0x257c2d);this['processor_']=wu(_0x2ea2fe);const _0x2ef4fc=_0x3cdc69['serverCache'],_0x605fa8=_0x3cdc69['eventCache'],_0xf88879=_0x34ffdc['updateFullNode'](g['EMPTY_NODE'],_0x2ef4fc['getNode'](),null),_0x5845a1=_0x2ea2fe['updateFullNode'](g['EMPTY_NODE'],_0x605fa8['getNode'](),null),_0x456734=new Ce(_0xf88879,_0x2ef4fc['isFullyInitialized'](),_0x34ffdc['filtersNodes']()),_0x3086f8=new Ce(_0x5845a1,_0x605fa8['isFullyInitialized'](),_0x2ea2fe['filtersNodes']());this['viewCache_']=Dn(_0x3086f8,_0x456734),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x12834f){return _0x12834f['viewCache_']['serverCache']['getNode']();}function Ou(_0x594fdc){return gn(_0x594fdc['viewCache_']);}function Du(_0x4e59ba,_0xde7b72){const _0x3f8c95=Ue(_0x4e59ba['viewCache_']);return _0x3f8c95&&(_0x4e59ba['query']['_queryParams']['loadsAllData']()||!v(_0xde7b72)&&!_0x3f8c95['getImmediateChild'](y(_0xde7b72))['isEmpty']())?_0x3f8c95['getChild'](_0xde7b72):null;}function lr(_0x370f8f){return _0x370f8f['eventRegistrations_']['length']===0x0;}function Mu(_0x45410e,_0x268a14){_0x45410e['eventRegistrations_']['push'](_0x268a14);}function hr(_0xfa3328,_0x78c58e,_0x1ab671){const _0x24641b=[];if(_0x1ab671){f(_0x78c58e==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1bb22d=_0xfa3328['query']['_path'];_0xfa3328['eventRegistrations_']['forEach'](_0x1c4945=>{const _0x101d00=_0x1c4945['createCancelEvent'](_0x1ab671,_0x1bb22d);_0x101d00&&_0x24641b['push'](_0x101d00);});}if(_0x78c58e){let _0x12332b=[];for(let _0x91d2da=0x0;_0x91d2da<_0xfa3328['eventRegistrations_']['length'];++_0x91d2da){const _0x4c5379=_0xfa3328['eventRegistrations_'][_0x91d2da];if(!_0x4c5379['matches'](_0x78c58e))_0x12332b['push'](_0x4c5379);else{if(_0x78c58e['hasAnyCallback']()){_0x12332b=_0x12332b['concat'](_0xfa3328['eventRegistrations_']['slice'](_0x91d2da+0x1));break;}}}_0xfa3328['eventRegistrations_']=_0x12332b;}else _0xfa3328['eventRegistrations_']=[];return _0x24641b;}function ur(_0x25aa71,_0x16e5e2,_0x24225b,_0x3c8529){_0x16e5e2['type']===q['MERGE']&&_0x16e5e2['source']['queryId']!==null&&(f(Ue(_0x25aa71['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x25aa71['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4cec4c=_0x25aa71['viewCache_'],_0x17d1ef=Tu(_0x25aa71['processor_'],_0x4cec4c,_0x16e5e2,_0x24225b,_0x3c8529);return Cu(_0x25aa71['processor_'],_0x17d1ef['viewCache']),f(_0x17d1ef['viewCache']['serverCache']['isFullyInitialized']()||!_0x4cec4c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x25aa71['viewCache_']=_0x17d1ef['viewCache'],$o(_0x25aa71,_0x17d1ef['changes'],_0x17d1ef['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x139ae8,_0x443659){const _0x1d8ebf=_0x139ae8['viewCache_']['eventCache'],_0x2335cf=[];return _0x1d8ebf['getNode']()['isLeafNode']()||_0x1d8ebf['getNode']()['forEachChild'](R,(_0x37a2e3,_0x445ca2)=>{_0x2335cf['push'](tt(_0x37a2e3,_0x445ca2));}),_0x1d8ebf['isFullyInitialized']()&&_0x2335cf['push'](Oo(_0x1d8ebf['getNode']())),$o(_0x139ae8,_0x2335cf,_0x1d8ebf['getNode'](),_0x443659);}function $o(_0x5ad75d,_0x413dd6,_0x4f0293,_0x13cd16){const _0x14f037=_0x13cd16?[_0x13cd16]:_0x5ad75d['eventRegistrations_'];return nu(_0x5ad75d['eventGenerator_'],_0x413dd6,_0x4f0293,_0x14f037);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x277e6d){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x277e6d;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0xe5faae){return _0xe5faae['views']['size']===0x0;}function is(_0x875200,_0x54d5e,_0x58f171,_0x413398){const _0x210d7d=_0x54d5e['source']['queryId'];if(_0x210d7d!==null){const _0xcbbf5=_0x875200['views']['get'](_0x210d7d);return f(_0xcbbf5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xcbbf5,_0x54d5e,_0x58f171,_0x413398);}else{let _0x5c992a=[];for(const _0x413869 of _0x875200['views']['values']())_0x5c992a=_0x5c992a['concat'](ur(_0x413869,_0x54d5e,_0x58f171,_0x413398));return _0x5c992a;}}function qo(_0x32f477,_0x212b9a,_0x3a1b38,_0x335d36,_0x4c8773){const _0x18ec81=_0x212b9a['_queryIdentifier'],_0x4ce2f8=_0x32f477['views']['get'](_0x18ec81);if(!_0x4ce2f8){let _0x1da534=mn(_0x3a1b38,_0x4c8773?_0x335d36:null),_0x9330f=!0x1;_0x1da534?_0x9330f=!0x0:_0x335d36 instanceof g?(_0x1da534=es(_0x3a1b38,_0x335d36),_0x9330f=!0x1):(_0x1da534=g['EMPTY_NODE'],_0x9330f=!0x1);const _0x33b464=Dn(new Ce(_0x1da534,_0x9330f,!0x1),new Ce(_0x335d36,_0x4c8773,!0x1));return new Nu(_0x212b9a,_0x33b464);}return _0x4ce2f8;}function Wu(_0x354fec,_0x53ab09,_0x25b575,_0x1b8dfd,_0x58ee6c,_0x34fe80){const _0x257df4=qo(_0x354fec,_0x53ab09,_0x1b8dfd,_0x58ee6c,_0x34fe80);return _0x354fec['views']['has'](_0x53ab09['_queryIdentifier'])||_0x354fec['views']['set'](_0x53ab09['_queryIdentifier'],_0x257df4),Mu(_0x257df4,_0x25b575),Lu(_0x257df4,_0x25b575);}function Bu(_0x2d63fd,_0x3cf945,_0x3d6cba,_0x175199){const _0x26f098=_0x3cf945['_queryIdentifier'],_0x311e81=[];let _0x1cd589=[];const _0x1e811a=Te(_0x2d63fd);if(_0x26f098==='default'){for(const [_0x15729d,_0x1d2572]of _0x2d63fd['views']['entries']())_0x1cd589=_0x1cd589['concat'](hr(_0x1d2572,_0x3d6cba,_0x175199)),lr(_0x1d2572)&&(_0x2d63fd['views']['delete'](_0x15729d),_0x1d2572['query']['_queryParams']['loadsAllData']()||_0x311e81['push'](_0x1d2572['query']));}else{const _0xac4020=_0x2d63fd['views']['get'](_0x26f098);_0xac4020&&(_0x1cd589=_0x1cd589['concat'](hr(_0xac4020,_0x3d6cba,_0x175199)),lr(_0xac4020)&&(_0x2d63fd['views']['delete'](_0x26f098),_0xac4020['query']['_queryParams']['loadsAllData']()||_0x311e81['push'](_0xac4020['query'])));}return _0x1e811a&&!Te(_0x2d63fd)&&_0x311e81['push'](new(Fu())(_0x3cf945['_repo'],_0x3cf945['_path'])),{'removed':_0x311e81,'events':_0x1cd589};}function zo(_0x5d01c5){const _0x107989=[];for(const _0xecdc01 of _0x5d01c5['views']['values']())_0xecdc01['query']['_queryParams']['loadsAllData']()||_0x107989['push'](_0xecdc01);return _0x107989;}function Ee(_0x54defa,_0x16d026){let _0x22ea1a=null;for(const _0x4862a of _0x54defa['views']['values']())_0x22ea1a=_0x22ea1a||Du(_0x4862a,_0x16d026);return _0x22ea1a;}function jo(_0x1b51b9,_0xe7d683){if(_0xe7d683['_queryParams']['loadsAllData']())return Ln(_0x1b51b9);{const _0x1087de=_0xe7d683['_queryIdentifier'];return _0x1b51b9['views']['get'](_0x1087de);}}function Ko(_0x3a0199,_0x5784c0){return jo(_0x3a0199,_0x5784c0)!=null;}function Te(_0x240a1e){return Ln(_0x240a1e)!=null;}function Ln(_0x313070){for(const _0x5dd0b6 of _0x313070['views']['values']())if(_0x5dd0b6['query']['_queryParams']['loadsAllData']())return _0x5dd0b6;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xc46b19){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xc46b19;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2ccfaf){this['listenProvider_']=_0x2ccfaf,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x45d814,_0x581df5,_0x48f909,_0x254766,_0x350c54){return ou(_0x45d814['pendingWriteTree_'],_0x581df5,_0x48f909,_0x254766,_0x350c54),_0x350c54?ht(_0x45d814,new Fe(Ji(),_0x581df5,_0x48f909)):[];}function Gu(_0x5cba46,_0x2a715d,_0x291397,_0x32b346){au(_0x5cba46['pendingWriteTree_'],_0x2a715d,_0x291397,_0x32b346);const _0x32c9d0=S['fromObject'](_0x291397);return ht(_0x5cba46,new nt(Ji(),_0x2a715d,_0x32c9d0));}function pe(_0x4b6ac9,_0x3e0bf1,_0xbda50b=!0x1){const _0x15717f=cu(_0x4b6ac9['pendingWriteTree_'],_0x3e0bf1);if(lu(_0x4b6ac9['pendingWriteTree_'],_0x3e0bf1)){let _0x4e9843=new S(null);return _0x15717f['snap']!=null?_0x4e9843=_0x4e9843['set'](w(),!0x0):x(_0x15717f['children'],_0x599e09=>{_0x4e9843=_0x4e9843['set'](new C(_0x599e09),!0x0);}),ht(_0x4b6ac9,new _n(_0x15717f['path'],_0x4e9843,_0xbda50b));}else return[];}function $t(_0x45858c,_0x5116f3,_0xffa849){return ht(_0x45858c,new Fe(Xi(),_0x5116f3,_0xffa849));}function qu(_0x2009d4,_0x27abe1,_0x585848){const _0x2dad48=S['fromObject'](_0x585848);return ht(_0x2009d4,new nt(Xi(),_0x27abe1,_0x2dad48));}function zu(_0x52a8d2,_0x1d4ea6){return ht(_0x52a8d2,new Dt(Xi(),_0x1d4ea6));}function ju(_0x12a351,_0x5979d7,_0x4b0468){const _0x2fbd85=rs(_0x12a351,_0x4b0468);if(_0x2fbd85){const _0x17214e=os(_0x2fbd85),_0x5c75d2=_0x17214e['path'],_0x1f6a12=_0x17214e['queryId'],_0x1426fd=F(_0x5c75d2,_0x5979d7),_0x3f2583=new Dt(Zi(_0x1f6a12),_0x1426fd);return as(_0x12a351,_0x5c75d2,_0x3f2583);}else return[];}function wn(_0x122db2,_0x3d05e8,_0x510db4,_0x37decb,_0x2a3b6a=!0x1){const _0x22096a=_0x3d05e8['_path'],_0x327adf=_0x122db2['syncPointTree_']['get'](_0x22096a);let _0x3b11db=[];if(_0x327adf&&(_0x3d05e8['_queryIdentifier']==='default'||Ko(_0x327adf,_0x3d05e8))){const _0x23ecae=Bu(_0x327adf,_0x3d05e8,_0x510db4,_0x37decb);Uu(_0x327adf)&&(_0x122db2['syncPointTree_']=_0x122db2['syncPointTree_']['remove'](_0x22096a));const _0x47616f=_0x23ecae['removed'];if(_0x3b11db=_0x23ecae['events'],!_0x2a3b6a){const _0x20e943=_0x47616f['findIndex'](_0x20d7b6=>_0x20d7b6['_queryParams']['loadsAllData']())!==-0x1,_0x5d4781=_0x122db2['syncPointTree_']['findOnPath'](_0x22096a,(_0x3623ca,_0x217f47)=>Te(_0x217f47));if(_0x20e943&&!_0x5d4781){const _0x18b45c=_0x122db2['syncPointTree_']['subtree'](_0x22096a);if(!_0x18b45c['isEmpty']()){const _0x421744=Qu(_0x18b45c);for(let _0x4b6f4b=0x0;_0x4b6f4b<_0x421744['length'];++_0x4b6f4b){const _0x4fea27=_0x421744[_0x4b6f4b],_0x45e088=_0x4fea27['query'],_0x4c15c6=Xo(_0x122db2,_0x4fea27);_0x122db2['listenProvider_']['startListening'](Tt(_0x45e088),Mt(_0x122db2,_0x45e088),_0x4c15c6['hashFn'],_0x4c15c6['onComplete']);}}}!_0x5d4781&&_0x47616f['length']>0x0&&!_0x37decb&&(_0x20e943?_0x122db2['listenProvider_']['stopListening'](Tt(_0x3d05e8),null):_0x47616f['forEach'](_0xabe562=>{const _0x1011d9=_0x122db2['queryToTagMap']['get'](Fn(_0xabe562));_0x122db2['listenProvider_']['stopListening'](Tt(_0xabe562),_0x1011d9);}));}Ju(_0x122db2,_0x47616f);}return _0x3b11db;}function Yo(_0x97f641,_0x1f0928,_0x6ddae8,_0x1280be){const _0x29e8b4=rs(_0x97f641,_0x1280be);if(_0x29e8b4!=null){const _0x4b20b8=os(_0x29e8b4),_0x5b872c=_0x4b20b8['path'],_0x1b9b4e=_0x4b20b8['queryId'],_0x38dc5e=F(_0x5b872c,_0x1f0928),_0x498b9c=new Fe(Zi(_0x1b9b4e),_0x38dc5e,_0x6ddae8);return as(_0x97f641,_0x5b872c,_0x498b9c);}else return[];}function Ku(_0xb802c8,_0x21123a,_0x3b8329,_0x1bf8bc){const _0x324b00=rs(_0xb802c8,_0x1bf8bc);if(_0x324b00){const _0x3bb1d4=os(_0x324b00),_0x3f3770=_0x3bb1d4['path'],_0x425fee=_0x3bb1d4['queryId'],_0x50082c=F(_0x3f3770,_0x21123a),_0x1f62d6=S['fromObject'](_0x3b8329),_0x4b1390=new nt(Zi(_0x425fee),_0x50082c,_0x1f62d6);return as(_0xb802c8,_0x3f3770,_0x4b1390);}else return[];}function bi(_0x123258,_0x21ee57,_0x150493,_0x1c6030=!0x1){const _0x17ef15=_0x21ee57['_path'];let _0x1ec23d=null,_0x46b8e7=!0x1;_0x123258['syncPointTree_']['foreachOnPath'](_0x17ef15,(_0x29c8e6,_0x2546c6)=>{const _0x20189d=F(_0x29c8e6,_0x17ef15);_0x1ec23d=_0x1ec23d||Ee(_0x2546c6,_0x20189d),_0x46b8e7=_0x46b8e7||Te(_0x2546c6);});let _0x3cb507=_0x123258['syncPointTree_']['get'](_0x17ef15);_0x3cb507?(_0x46b8e7=_0x46b8e7||Te(_0x3cb507),_0x1ec23d=_0x1ec23d||Ee(_0x3cb507,w())):(_0x3cb507=new Go(),_0x123258['syncPointTree_']=_0x123258['syncPointTree_']['set'](_0x17ef15,_0x3cb507));let _0x2392b1;_0x1ec23d!=null?_0x2392b1=!0x0:(_0x2392b1=!0x1,_0x1ec23d=g['EMPTY_NODE'],_0x123258['syncPointTree_']['subtree'](_0x17ef15)['foreachChild']((_0x443cc6,_0x5beea2)=>{const _0x352c0d=Ee(_0x5beea2,w());_0x352c0d&&(_0x1ec23d=_0x1ec23d['updateImmediateChild'](_0x443cc6,_0x352c0d));}));const _0x17cc5d=Ko(_0x3cb507,_0x21ee57);if(!_0x17cc5d&&!_0x21ee57['_queryParams']['loadsAllData']()){const _0x179f73=Fn(_0x21ee57);f(!_0x123258['queryToTagMap']['has'](_0x179f73),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x29afff=Xu();_0x123258['queryToTagMap']['set'](_0x179f73,_0x29afff),_0x123258['tagToQueryMap']['set'](_0x29afff,_0x179f73);}const _0x330a22=Mn(_0x123258['pendingWriteTree_'],_0x17ef15);let _0x30205d=Wu(_0x3cb507,_0x21ee57,_0x150493,_0x330a22,_0x1ec23d,_0x2392b1);if(!_0x17cc5d&&!_0x46b8e7&&!_0x1c6030){const _0x46c444=jo(_0x3cb507,_0x21ee57);_0x30205d=_0x30205d['concat'](Zu(_0x123258,_0x21ee57,_0x46c444));}return _0x30205d;}function xn(_0x46e7d0,_0x5a1519,_0xee6b93){const _0x3a043a=_0x46e7d0['pendingWriteTree_'],_0x4e0abb=_0x46e7d0['syncPointTree_']['findOnPath'](_0x5a1519,(_0x23029d,_0x9f93a6)=>{const _0x13559a=F(_0x23029d,_0x5a1519),_0x4db17e=Ee(_0x9f93a6,_0x13559a);if(_0x4db17e)return _0x4db17e;});return Uo(_0x3a043a,_0x5a1519,_0x4e0abb,_0xee6b93,!0x0);}function Yu(_0x3720e9,_0x347718){const _0x1136dc=_0x347718['_path'];let _0xb3a28d=null;_0x3720e9['syncPointTree_']['foreachOnPath'](_0x1136dc,(_0x4d31c4,_0x16f0c1)=>{const _0x108095=F(_0x4d31c4,_0x1136dc);_0xb3a28d=_0xb3a28d||Ee(_0x16f0c1,_0x108095);});let _0x196a9b=_0x3720e9['syncPointTree_']['get'](_0x1136dc);_0x196a9b?_0xb3a28d=_0xb3a28d||Ee(_0x196a9b,w()):(_0x196a9b=new Go(),_0x3720e9['syncPointTree_']=_0x3720e9['syncPointTree_']['set'](_0x1136dc,_0x196a9b));const _0x485c1d=_0xb3a28d!=null,_0x161aa6=_0x485c1d?new Ce(_0xb3a28d,!0x0,!0x1):null,_0x598f47=Mn(_0x3720e9['pendingWriteTree_'],_0x347718['_path']),_0x173651=qo(_0x196a9b,_0x347718,_0x598f47,_0x485c1d?_0x161aa6['getNode']():g['EMPTY_NODE'],_0x485c1d);return Ou(_0x173651);}function ht(_0x5a8213,_0x40de8c){return Qo(_0x40de8c,_0x5a8213['syncPointTree_'],null,Mn(_0x5a8213['pendingWriteTree_'],w()));}function Qo(_0x299e8f,_0x222b1f,_0x36316e,_0x4049bb){if(v(_0x299e8f['path']))return Jo(_0x299e8f,_0x222b1f,_0x36316e,_0x4049bb);{const _0x3da7e8=_0x222b1f['get'](w());_0x36316e==null&&_0x3da7e8!=null&&(_0x36316e=Ee(_0x3da7e8,w()));let _0x2228ee=[];const _0x224d97=y(_0x299e8f['path']),_0x3644ca=_0x299e8f['operationForChild'](_0x224d97),_0x140293=_0x222b1f['children']['get'](_0x224d97);if(_0x140293&&_0x3644ca){const _0x46300e=_0x36316e?_0x36316e['getImmediateChild'](_0x224d97):null,_0x719395=Wo(_0x4049bb,_0x224d97);_0x2228ee=_0x2228ee['concat'](Qo(_0x3644ca,_0x140293,_0x46300e,_0x719395));}return _0x3da7e8&&(_0x2228ee=_0x2228ee['concat'](is(_0x3da7e8,_0x299e8f,_0x4049bb,_0x36316e))),_0x2228ee;}}function Jo(_0x4f0bb9,_0x4b6a39,_0x3cc219,_0x4b79f3){const _0x4aab23=_0x4b6a39['get'](w());_0x3cc219==null&&_0x4aab23!=null&&(_0x3cc219=Ee(_0x4aab23,w()));let _0x2354f0=[];return _0x4b6a39['children']['inorderTraversal']((_0x42ee8e,_0x518ad8)=>{const _0x4a5a0f=_0x3cc219?_0x3cc219['getImmediateChild'](_0x42ee8e):null,_0x1ad75f=Wo(_0x4b79f3,_0x42ee8e),_0x29c6fe=_0x4f0bb9['operationForChild'](_0x42ee8e);_0x29c6fe&&(_0x2354f0=_0x2354f0['concat'](Jo(_0x29c6fe,_0x518ad8,_0x4a5a0f,_0x1ad75f)));}),_0x4aab23&&(_0x2354f0=_0x2354f0['concat'](is(_0x4aab23,_0x4f0bb9,_0x4b79f3,_0x3cc219))),_0x2354f0;}function Xo(_0x484e08,_0xe1b83e){const _0x505f95=_0xe1b83e['query'],_0x62caa=Mt(_0x484e08,_0x505f95);return{'hashFn':()=>(Pu(_0xe1b83e)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x208550=>{if(_0x208550==='ok')return _0x62caa?ju(_0x484e08,_0x505f95['_path'],_0x62caa):zu(_0x484e08,_0x505f95['_path']);{const _0x1446a2=ql(_0x208550,_0x505f95);return wn(_0x484e08,_0x505f95,null,_0x1446a2);}}};}function Mt(_0x22e759,_0x1a5aef){const _0x28f09f=Fn(_0x1a5aef);return _0x22e759['queryToTagMap']['get'](_0x28f09f);}function Fn(_0x55a0bd){return _0x55a0bd['_path']['toString']()+'$'+_0x55a0bd['_queryIdentifier'];}function rs(_0xcc072e,_0x36c1c1){return _0xcc072e['tagToQueryMap']['get'](_0x36c1c1);}function os(_0x21c963){const _0x1c6d41=_0x21c963['indexOf']('$');return f(_0x1c6d41!==-0x1&&_0x1c6d41<_0x21c963['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x21c963['substr'](_0x1c6d41+0x1),'path':new C(_0x21c963['substr'](0x0,_0x1c6d41))};}function as(_0x285d61,_0x52e3b2,_0x523342){const _0x222600=_0x285d61['syncPointTree_']['get'](_0x52e3b2);f(_0x222600,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1737e2=Mn(_0x285d61['pendingWriteTree_'],_0x52e3b2);return is(_0x222600,_0x523342,_0x1737e2,null);}function Qu(_0x1490f8){return _0x1490f8['fold']((_0x43d967,_0x820b69,_0x24b481)=>{if(_0x820b69&&Te(_0x820b69))return[Ln(_0x820b69)];{let _0x3341f0=[];return _0x820b69&&(_0x3341f0=zo(_0x820b69)),x(_0x24b481,(_0x511ccc,_0x583635)=>{_0x3341f0=_0x3341f0['concat'](_0x583635);}),_0x3341f0;}});}function Tt(_0x3678d9){return _0x3678d9['_queryParams']['loadsAllData']()&&!_0x3678d9['_queryParams']['isDefault']()?new(Hu())(_0x3678d9['_repo'],_0x3678d9['_path']):_0x3678d9;}function Ju(_0x2dea60,_0x3f16ad){for(let _0xa74a8f=0x0;_0xa74a8f<_0x3f16ad['length'];++_0xa74a8f){const _0x453869=_0x3f16ad[_0xa74a8f];if(!_0x453869['_queryParams']['loadsAllData']()){const _0xe24b8d=Fn(_0x453869),_0x9b909c=_0x2dea60['queryToTagMap']['get'](_0xe24b8d);_0x2dea60['queryToTagMap']['delete'](_0xe24b8d),_0x2dea60['tagToQueryMap']['delete'](_0x9b909c);}}}function Xu(){return $u++;}function Zu(_0x262e99,_0x16bd90,_0x566e6a){const _0x3c4493=_0x16bd90['_path'],_0x19597a=Mt(_0x262e99,_0x16bd90),_0x3e3747=Xo(_0x262e99,_0x566e6a),_0x15e45e=_0x262e99['listenProvider_']['startListening'](Tt(_0x16bd90),_0x19597a,_0x3e3747['hashFn'],_0x3e3747['onComplete']),_0x155e17=_0x262e99['syncPointTree_']['subtree'](_0x3c4493);if(_0x19597a)f(!Te(_0x155e17['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2e9215=_0x155e17['fold']((_0x2f436c,_0x19293a,_0x2608c5)=>{if(!v(_0x2f436c)&&_0x19293a&&Te(_0x19293a))return[Ln(_0x19293a)['query']];{let _0x229510=[];return _0x19293a&&(_0x229510=_0x229510['concat'](zo(_0x19293a)['map'](_0x452275=>_0x452275['query']))),x(_0x2608c5,(_0x5dfaf6,_0x48dbde)=>{_0x229510=_0x229510['concat'](_0x48dbde);}),_0x229510;}});for(let _0x173a4c=0x0;_0x173a4c<_0x2e9215['length'];++_0x173a4c){const _0x2f989b=_0x2e9215[_0x173a4c];_0x262e99['listenProvider_']['stopListening'](Tt(_0x2f989b),Mt(_0x262e99,_0x2f989b));}}return _0x15e45e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x3da8aa){this['node_']=_0x3da8aa;}['getImmediateChild'](_0x84518){const _0x4f159c=this['node_']['getImmediateChild'](_0x84518);return new cs(_0x4f159c);}['node'](){return this['node_'];}}class ls{constructor(_0x589d08,_0x4c4520){this['syncTree_']=_0x589d08,this['path_']=_0x4c4520;}['getImmediateChild'](_0x3ca0d2){const _0x529196=A(this['path_'],_0x3ca0d2);return new ls(this['syncTree_'],_0x529196);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x1c327){return _0x1c327=_0x1c327||{},_0x1c327['timestamp']=_0x1c327['timestamp']||new Date()['getTime'](),_0x1c327;},fr=function(_0x42224c,_0x374a31,_0xe10582){if(!_0x42224c||typeof _0x42224c!='object')return _0x42224c;if(f('.sv'in _0x42224c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x42224c['.sv']=='string')return td(_0x42224c['.sv'],_0x374a31,_0xe10582);if(typeof _0x42224c['.sv']=='object')return nd(_0x42224c['.sv'],_0x374a31);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x42224c,null,0x2));},td=function(_0xcd33f6,_0x2890f8,_0x5cf28a){switch(_0xcd33f6){case'timestamp':return _0x5cf28a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xcd33f6);}},nd=function(_0x35982a,_0x4ff286,_0x4c2b7e){_0x35982a['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x35982a,null,0x2));const _0xb9678e=_0x35982a['increment'];typeof _0xb9678e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xb9678e);const _0x365fa3=_0x4ff286['node']();if(f(_0x365fa3!==null&&typeof _0x365fa3<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x365fa3['isLeafNode']())return _0xb9678e;const _0x53208c=_0x365fa3['getValue']();return typeof _0x53208c!='number'?_0xb9678e:_0x53208c+_0xb9678e;},Zo=function(_0x5be316,_0x2b7763,_0x320b55,_0x567477){return us(_0x2b7763,new ls(_0x320b55,_0x5be316),_0x567477);},hs=function(_0x5ad9e7,_0x2df365,_0x237b35){return us(_0x5ad9e7,new cs(_0x2df365),_0x237b35);};function us(_0x5de2e4,_0x1822fd,_0x46039b){const _0x5293e2=_0x5de2e4['getPriority']()['val'](),_0x268f31=fr(_0x5293e2,_0x1822fd['getImmediateChild']('.priority'),_0x46039b);let _0x4e982b;if(_0x5de2e4['isLeafNode']()){const _0x1d4e6d=_0x5de2e4,_0x33a2a5=fr(_0x1d4e6d['getValue'](),_0x1822fd,_0x46039b);return _0x33a2a5!==_0x1d4e6d['getValue']()||_0x268f31!==_0x1d4e6d['getPriority']()['val']()?new D(_0x33a2a5,N(_0x268f31)):_0x5de2e4;}else{const _0x3ea5a9=_0x5de2e4;return _0x4e982b=_0x3ea5a9,_0x268f31!==_0x3ea5a9['getPriority']()['val']()&&(_0x4e982b=_0x4e982b['updatePriority'](new D(_0x268f31))),_0x3ea5a9['forEachChild'](R,(_0x4a4d74,_0x25747d)=>{const _0x59c07f=us(_0x25747d,_0x1822fd['getImmediateChild'](_0x4a4d74),_0x46039b);_0x59c07f!==_0x25747d&&(_0x4e982b=_0x4e982b['updateImmediateChild'](_0x4a4d74,_0x59c07f));}),_0x4e982b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x294918='',_0x3ce6ad=null,_0x4110f9={'children':{},'childCount':0x0}){this['name']=_0x294918,this['parent']=_0x3ce6ad,this['node']=_0x4110f9;}}function Un(_0x11613f,_0x499061){let _0x46dacd=_0x499061 instanceof C?_0x499061:new C(_0x499061),_0x31c811=_0x11613f,_0x108107=y(_0x46dacd);for(;_0x108107!==null;){const _0x37acdf=Oe(_0x31c811['node']['children'],_0x108107)||{'children':{},'childCount':0x0};_0x31c811=new ds(_0x108107,_0x31c811,_0x37acdf),_0x46dacd=b(_0x46dacd),_0x108107=y(_0x46dacd);}return _0x31c811;}function Ge(_0x46b304){return _0x46b304['node']['value'];}function fs(_0x5b8359,_0x56ab89){_0x5b8359['node']['value']=_0x56ab89,Ri(_0x5b8359);}function ea(_0x5b4c71){return _0x5b4c71['node']['childCount']>0x0;}function id(_0x5bc4e9){return Ge(_0x5bc4e9)===void 0x0&&!ea(_0x5bc4e9);}function Wn(_0x5deff1,_0x206a63){x(_0x5deff1['node']['children'],(_0x131e70,_0x186eca)=>{_0x206a63(new ds(_0x131e70,_0x5deff1,_0x186eca));});}function ta(_0x4efafc,_0x333663,_0x5935e0,_0x5c7088){_0x5935e0&&_0x333663(_0x4efafc),Wn(_0x4efafc,_0x58e5ea=>{ta(_0x58e5ea,_0x333663,!0x0);});}function sd(_0x29c1b8,_0x3507cc,_0x1cdb70){let _0x13821f=_0x29c1b8['parent'];for(;_0x13821f!==null;){if(_0x3507cc(_0x13821f))return!0x0;_0x13821f=_0x13821f['parent'];}return!0x1;}function Gt(_0x32121d){return new C(_0x32121d['parent']===null?_0x32121d['name']:Gt(_0x32121d['parent'])+'/'+_0x32121d['name']);}function Ri(_0x20bd10){_0x20bd10['parent']!==null&&rd(_0x20bd10['parent'],_0x20bd10['name'],_0x20bd10);}function rd(_0x381884,_0x386169,_0x17e37f){const _0xb497b1=id(_0x17e37f),_0x56839c=Y(_0x381884['node']['children'],_0x386169);_0xb497b1&&_0x56839c?(delete _0x381884['node']['children'][_0x386169],_0x381884['node']['childCount']--,Ri(_0x381884)):!_0xb497b1&&!_0x56839c&&(_0x381884['node']['children'][_0x386169]=_0x17e37f['node'],_0x381884['node']['childCount']++,Ri(_0x381884));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x22fa81){return typeof _0x22fa81=='string'&&_0x22fa81['length']!==0x0&&!od['test'](_0x22fa81);},na=function(_0x83bd0e){return typeof _0x83bd0e=='string'&&_0x83bd0e['length']!==0x0&&!ad['test'](_0x83bd0e);},cd=function(_0x36c3c0){return _0x36c3c0&&(_0x36c3c0=_0x36c3c0['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x36c3c0);},Cn=function(_0x437d84){return _0x437d84===null||typeof _0x437d84=='string'||typeof _0x437d84=='number'&&!Wi(_0x437d84)||_0x437d84&&typeof _0x437d84=='object'&&Y(_0x437d84,'.sv');},qt=function(_0x491b66,_0x1a7579,_0x5ecf9a,_0x1bb0fc){_0x1bb0fc&&_0x1a7579===void 0x0||zt(Nn(_0x491b66,'value'),_0x1a7579,_0x5ecf9a);},zt=function(_0x3ad201,_0xeb604a,_0x36ff31){const _0x4a9273=_0x36ff31 instanceof C?new Sh(_0x36ff31,_0x3ad201):_0x36ff31;if(_0xeb604a===void 0x0)throw new Error(_0x3ad201+'contains\x20undefined\x20'+Ne(_0x4a9273));if(typeof _0xeb604a=='function')throw new Error(_0x3ad201+'contains\x20a\x20function\x20'+Ne(_0x4a9273)+'\x20with\x20contents\x20=\x20'+_0xeb604a['toString']());if(Wi(_0xeb604a))throw new Error(_0x3ad201+'contains\x20'+_0xeb604a['toString']()+'\x20'+Ne(_0x4a9273));if(typeof _0xeb604a=='string'&&_0xeb604a['length']>oi/0x3&&Pn(_0xeb604a)>oi)throw new Error(_0x3ad201+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4a9273)+'\x20(\x27'+_0xeb604a['substring'](0x0,0x32)+'...\x27)');if(_0xeb604a&&typeof _0xeb604a=='object'){let _0x1f39d4=!0x1,_0x4a4cfa=!0x1;if(x(_0xeb604a,(_0x2e339d,_0x23ee89)=>{if(_0x2e339d==='.value')_0x1f39d4=!0x0;else{if(_0x2e339d!=='.priority'&&_0x2e339d!=='.sv'&&(_0x4a4cfa=!0x0,!ps(_0x2e339d)))throw new Error(_0x3ad201+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2e339d+')\x20'+Ne(_0x4a9273)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4a9273,_0x2e339d),zt(_0x3ad201,_0x23ee89,_0x4a9273),Rh(_0x4a9273);}),_0x1f39d4&&_0x4a4cfa)throw new Error(_0x3ad201+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4a9273)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x4e77a7,_0x202c69){let _0x566327,_0xe76800;for(_0x566327=0x0;_0x566327<_0x202c69['length'];_0x566327++){_0xe76800=_0x202c69[_0x566327];const _0x16fbe6=kt(_0xe76800);for(let _0x3cf864=0x0;_0x3cf864<_0x16fbe6['length'];_0x3cf864++)if(!(_0x16fbe6[_0x3cf864]==='.priority'&&_0x3cf864===_0x16fbe6['length']-0x1)){if(!ps(_0x16fbe6[_0x3cf864]))throw new Error(_0x4e77a7+'contains\x20an\x20invalid\x20key\x20('+_0x16fbe6[_0x3cf864]+')\x20in\x20path\x20'+_0xe76800['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x202c69['sort'](Th);let _0x52a7ef=null;for(_0x566327=0x0;_0x566327<_0x202c69['length'];_0x566327++){if(_0xe76800=_0x202c69[_0x566327],_0x52a7ef!==null&&$(_0x52a7ef,_0xe76800))throw new Error(_0x4e77a7+'contains\x20a\x20path\x20'+_0x52a7ef['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xe76800['toString']());_0x52a7ef=_0xe76800;}},hd=function(_0x5bdbb1,_0x51d045,_0x101905,_0xbc1699){const _0x1a1ec4=Nn(_0x5bdbb1,'values');if(!(_0x51d045&&typeof _0x51d045=='object')||Array['isArray'](_0x51d045))throw new Error(_0x1a1ec4+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x22d581=[];x(_0x51d045,(_0xdf6aa8,_0x247ca9)=>{const _0x3f8399=new C(_0xdf6aa8);if(zt(_0x1a1ec4,_0x247ca9,A(_0x101905,_0x3f8399)),Gi(_0x3f8399)==='.priority'&&!Cn(_0x247ca9))throw new Error(_0x1a1ec4+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3f8399['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x22d581['push'](_0x3f8399);}),ld(_0x1a1ec4,_0x22d581);},_s=function(_0x38db5c,_0x1a8a93,_0x29666c,_0x28a7be){if(!na(_0x29666c))throw new Error(Nn(_0x38db5c,_0x1a8a93)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x29666c+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x147b64,_0x128ffb,_0x424e80,_0x2982a2){_0x424e80&&(_0x424e80=_0x424e80['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x147b64,_0x128ffb,_0x424e80);},gs=function(_0x2edabd,_0x22b0d9){if(y(_0x22b0d9)==='.info')throw new Error(_0x2edabd+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1d5acc,_0x41fa89){const _0x58e0fc=_0x41fa89['path']['toString']();if(typeof _0x41fa89['repoInfo']['host']!='string'||_0x41fa89['repoInfo']['host']['length']===0x0||!ps(_0x41fa89['repoInfo']['namespace'])&&_0x41fa89['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x58e0fc['length']!==0x0&&!cd(_0x58e0fc))throw new Error(Nn(_0x1d5acc,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x39df73,_0x4be5f9){let _0x2fc7be=null;for(let _0x27a601=0x0;_0x27a601<_0x4be5f9['length'];_0x27a601++){const _0x75d568=_0x4be5f9[_0x27a601],_0x1953df=_0x75d568['getPath']();_0x2fc7be!==null&&!qi(_0x1953df,_0x2fc7be['path'])&&(_0x39df73['eventLists_']['push'](_0x2fc7be),_0x2fc7be=null),_0x2fc7be===null&&(_0x2fc7be={'events':[],'path':_0x1953df}),_0x2fc7be['events']['push'](_0x75d568);}_0x2fc7be&&_0x39df73['eventLists_']['push'](_0x2fc7be);}function ia(_0x2f7a06,_0x4bcd00,_0x1897a1){Bn(_0x2f7a06,_0x1897a1),sa(_0x2f7a06,_0x48ec66=>qi(_0x48ec66,_0x4bcd00));}function V(_0x480e48,_0x304e2c,_0x116c77){Bn(_0x480e48,_0x116c77),sa(_0x480e48,_0x1caeb7=>$(_0x1caeb7,_0x304e2c)||$(_0x304e2c,_0x1caeb7));}function sa(_0x53b869,_0x1e3843){_0x53b869['recursionDepth_']++;let _0x45d50d=!0x0;for(let _0x4319cd=0x0;_0x4319cd<_0x53b869['eventLists_']['length'];_0x4319cd++){const _0xe2ae76=_0x53b869['eventLists_'][_0x4319cd];if(_0xe2ae76){const _0x1b4662=_0xe2ae76['path'];_0x1e3843(_0x1b4662)?(pd(_0x53b869['eventLists_'][_0x4319cd]),_0x53b869['eventLists_'][_0x4319cd]=null):_0x45d50d=!0x1;}}_0x45d50d&&(_0x53b869['eventLists_']=[]),_0x53b869['recursionDepth_']--;}function pd(_0x12253d){for(let _0x14f27e=0x0;_0x14f27e<_0x12253d['events']['length'];_0x14f27e++){const _0x41bbcf=_0x12253d['events'][_0x14f27e];if(_0x41bbcf!==null){_0x12253d['events'][_0x14f27e]=null;const _0x150d95=_0x41bbcf['getEventRunner']();Et&&L('event:\x20'+_0x41bbcf['toString']()),lt(_0x150d95);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x14f08a,_0x548a2e,_0x55bff2,_0x115d7d){this['repoInfo_']=_0x14f08a,this['forceRestClient_']=_0x548a2e,this['authTokenProvider_']=_0x55bff2,this['appCheckProvider_']=_0x115d7d,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x564682,_0x394584,_0x4a1e32){if(_0x564682['stats_']=Hi(_0x564682['repoInfo_']),_0x564682['forceRestClient_']||Yl())_0x564682['server_']=new fn(_0x564682['repoInfo_'],(_0x4ade07,_0x8ac65b,_0xe2d9c,_0x1bbf6c)=>{pr(_0x564682,_0x4ade07,_0x8ac65b,_0xe2d9c,_0x1bbf6c);},_0x564682['authTokenProvider_'],_0x564682['appCheckProvider_']),setTimeout(()=>_r(_0x564682,!0x0),0x0);else{if(typeof _0x4a1e32<'u'&&_0x4a1e32!==null){if(typeof _0x4a1e32!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4a1e32);}catch(_0x2c803a){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2c803a);}}_0x564682['persistentConnection_']=new ie(_0x564682['repoInfo_'],_0x394584,(_0x43dac3,_0x2e28df,_0x3aaa67,_0x547925)=>{pr(_0x564682,_0x43dac3,_0x2e28df,_0x3aaa67,_0x547925);},_0x24228d=>{_r(_0x564682,_0x24228d);},_0x1cc7cd=>{yd(_0x564682,_0x1cc7cd);},_0x564682['authTokenProvider_'],_0x564682['appCheckProvider_'],_0x4a1e32),_0x564682['server_']=_0x564682['persistentConnection_'];}_0x564682['authTokenProvider_']['addTokenChangeListener'](_0x279527=>{_0x564682['server_']['refreshAuthToken'](_0x279527);}),_0x564682['appCheckProvider_']['addTokenChangeListener'](_0x3eca37=>{_0x564682['server_']['refreshAppCheckToken'](_0x3eca37['token']);}),_0x564682['statsReporter_']=eh(_0x564682['repoInfo_'],()=>new eu(_0x564682['stats_'],_0x564682['server_'])),_0x564682['infoData_']=new Yh(),_0x564682['infoSyncTree_']=new dr({'startListening':(_0x20320e,_0x365014,_0x39fb9f,_0x390f45)=>{let _0x285361=[];const _0x16de15=_0x564682['infoData_']['getNode'](_0x20320e['_path']);return _0x16de15['isEmpty']()||(_0x285361=$t(_0x564682['infoSyncTree_'],_0x20320e['_path'],_0x16de15),setTimeout(()=>{_0x390f45('ok');},0x0)),_0x285361;},'stopListening':()=>{}}),ms(_0x564682,'connected',!0x1),_0x564682['serverSyncTree_']=new dr({'startListening':(_0x35d7fb,_0x1a528a,_0x566203,_0x3f0af5)=>(_0x564682['server_']['listen'](_0x35d7fb,_0x566203,_0x1a528a,(_0x208927,_0x7f5c5c)=>{const _0x2ae0bb=_0x3f0af5(_0x208927,_0x7f5c5c);V(_0x564682['eventQueue_'],_0x35d7fb['_path'],_0x2ae0bb);}),[]),'stopListening':(_0x1de178,_0x3c6b0e)=>{_0x564682['server_']['unlisten'](_0x1de178,_0x3c6b0e);}});}function oa(_0x4e2ace){const _0x352f50=_0x4e2ace['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x352f50;}function jt(_0x26ba4b){return ed({'timestamp':oa(_0x26ba4b)});}function pr(_0x46e59c,_0x4b585e,_0xf7ca2d,_0x209b9f,_0x158f58){_0x46e59c['dataUpdateCount']++;const _0x14ef94=new C(_0x4b585e);_0xf7ca2d=_0x46e59c['interceptServerDataCallback_']?_0x46e59c['interceptServerDataCallback_'](_0x4b585e,_0xf7ca2d):_0xf7ca2d;let _0x22d004=[];if(_0x158f58){if(_0x209b9f){const _0x1a854e=ln(_0xf7ca2d,_0x3fafc4=>N(_0x3fafc4));_0x22d004=Ku(_0x46e59c['serverSyncTree_'],_0x14ef94,_0x1a854e,_0x158f58);}else{const _0x49e88e=N(_0xf7ca2d);_0x22d004=Yo(_0x46e59c['serverSyncTree_'],_0x14ef94,_0x49e88e,_0x158f58);}}else{if(_0x209b9f){const _0x33442f=ln(_0xf7ca2d,_0x4ec252=>N(_0x4ec252));_0x22d004=qu(_0x46e59c['serverSyncTree_'],_0x14ef94,_0x33442f);}else{const _0x3bf6b5=N(_0xf7ca2d);_0x22d004=$t(_0x46e59c['serverSyncTree_'],_0x14ef94,_0x3bf6b5);}}let _0x46e2a6=_0x14ef94;_0x22d004['length']>0x0&&(_0x46e2a6=st(_0x46e59c,_0x14ef94)),V(_0x46e59c['eventQueue_'],_0x46e2a6,_0x22d004);}function _r(_0x29caab,_0x579fc6){ms(_0x29caab,'connected',_0x579fc6),_0x579fc6===!0x1&&wd(_0x29caab);}function yd(_0xac2412,_0x491a4e){x(_0x491a4e,(_0x390072,_0xead9e9)=>{ms(_0xac2412,_0x390072,_0xead9e9);});}function ms(_0x1b0132,_0x6aefe5,_0x82572f){const _0x3d9349=new C('/.info/'+_0x6aefe5),_0x834d56=N(_0x82572f);_0x1b0132['infoData_']['updateSnapshot'](_0x3d9349,_0x834d56);const _0x359d58=$t(_0x1b0132['infoSyncTree_'],_0x3d9349,_0x834d56);V(_0x1b0132['eventQueue_'],_0x3d9349,_0x359d58);}function Vn(_0x3dd24b){return _0x3dd24b['nextWriteId_']++;}function vd(_0x24d059,_0x577cb8,_0x450f2c){const _0x1a33fe=Yu(_0x24d059['serverSyncTree_'],_0x577cb8);return _0x1a33fe!=null?Promise['resolve'](_0x1a33fe):_0x24d059['server_']['get'](_0x577cb8)['then'](_0x57651b=>{const _0x57214f=N(_0x57651b)['withIndex'](_0x577cb8['_queryParams']['getIndex']());bi(_0x24d059['serverSyncTree_'],_0x577cb8,_0x450f2c,!0x0);let _0x159e7d;if(_0x577cb8['_queryParams']['loadsAllData']())_0x159e7d=$t(_0x24d059['serverSyncTree_'],_0x577cb8['_path'],_0x57214f);else{const _0x3e2985=Mt(_0x24d059['serverSyncTree_'],_0x577cb8);_0x159e7d=Yo(_0x24d059['serverSyncTree_'],_0x577cb8['_path'],_0x57214f,_0x3e2985);}return V(_0x24d059['eventQueue_'],_0x577cb8['_path'],_0x159e7d),wn(_0x24d059['serverSyncTree_'],_0x577cb8,_0x450f2c,null,!0x0),_0x57214f;},_0x5183c2=>(ut(_0x24d059,'get\x20for\x20query\x20'+O(_0x577cb8)+'\x20failed:\x20'+_0x5183c2),Promise['reject'](new Error(_0x5183c2))));}function Ed(_0x4e86c8,_0x19fd29,_0x583e14,_0x36c3fb,_0x315ab5){ut(_0x4e86c8,'set',{'path':_0x19fd29['toString'](),'value':_0x583e14,'priority':_0x36c3fb});const _0x1d882a=jt(_0x4e86c8),_0xa200d4=N(_0x583e14,_0x36c3fb),_0x466651=xn(_0x4e86c8['serverSyncTree_'],_0x19fd29),_0x4c64a2=hs(_0xa200d4,_0x466651,_0x1d882a),_0x3c15e1=Vn(_0x4e86c8),_0x24353b=ss(_0x4e86c8['serverSyncTree_'],_0x19fd29,_0x4c64a2,_0x3c15e1,!0x0);Bn(_0x4e86c8['eventQueue_'],_0x24353b),_0x4e86c8['server_']['put'](_0x19fd29['toString'](),_0xa200d4['val'](!0x0),(_0x42bdfc,_0x2b72e4)=>{const _0x5aa8c7=_0x42bdfc==='ok';_0x5aa8c7||U('set\x20at\x20'+_0x19fd29+'\x20failed:\x20'+_0x42bdfc);const _0x1e4327=pe(_0x4e86c8['serverSyncTree_'],_0x3c15e1,!_0x5aa8c7);V(_0x4e86c8['eventQueue_'],_0x19fd29,_0x1e4327),Ai(_0x4e86c8,_0x315ab5,_0x42bdfc,_0x2b72e4);});const _0x288068=vs(_0x4e86c8,_0x19fd29);st(_0x4e86c8,_0x288068),V(_0x4e86c8['eventQueue_'],_0x288068,[]);}function Id(_0x66f299,_0x4cd776,_0x1b2eae,_0x26626d){ut(_0x66f299,'update',{'path':_0x4cd776['toString'](),'value':_0x1b2eae});let _0x441778=!0x0;const _0x44d769=jt(_0x66f299),_0x23d5af={};if(x(_0x1b2eae,(_0xee1d1d,_0xc4c498)=>{_0x441778=!0x1,_0x23d5af[_0xee1d1d]=Zo(A(_0x4cd776,_0xee1d1d),N(_0xc4c498),_0x66f299['serverSyncTree_'],_0x44d769);}),_0x441778)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x66f299,_0x26626d,'ok',void 0x0);else{const _0x1b47aa=Vn(_0x66f299),_0x37b70c=Gu(_0x66f299['serverSyncTree_'],_0x4cd776,_0x23d5af,_0x1b47aa);Bn(_0x66f299['eventQueue_'],_0x37b70c),_0x66f299['server_']['merge'](_0x4cd776['toString'](),_0x1b2eae,(_0x2b5c1d,_0x2871ca)=>{const _0x3972cc=_0x2b5c1d==='ok';_0x3972cc||U('update\x20at\x20'+_0x4cd776+'\x20failed:\x20'+_0x2b5c1d);const _0x264084=pe(_0x66f299['serverSyncTree_'],_0x1b47aa,!_0x3972cc),_0x555d3c=_0x264084['length']>0x0?st(_0x66f299,_0x4cd776):_0x4cd776;V(_0x66f299['eventQueue_'],_0x555d3c,_0x264084),Ai(_0x66f299,_0x26626d,_0x2b5c1d,_0x2871ca);}),x(_0x1b2eae,_0x3bd281=>{const _0xe76f76=vs(_0x66f299,A(_0x4cd776,_0x3bd281));st(_0x66f299,_0xe76f76);}),V(_0x66f299['eventQueue_'],_0x4cd776,[]);}}function wd(_0x2a3682){ut(_0x2a3682,'onDisconnectEvents');const _0x1f4ddd=jt(_0x2a3682),_0x208753=pn();Ei(_0x2a3682['onDisconnect_'],w(),(_0x5ccec9,_0x3eec51)=>{const _0x2b0265=Zo(_0x5ccec9,_0x3eec51,_0x2a3682['serverSyncTree_'],_0x1f4ddd);Mo(_0x208753,_0x5ccec9,_0x2b0265);});let _0x8f94f1=[];Ei(_0x208753,w(),(_0x43473b,_0x54aa3d)=>{_0x8f94f1=_0x8f94f1['concat']($t(_0x2a3682['serverSyncTree_'],_0x43473b,_0x54aa3d));const _0x50db6d=vs(_0x2a3682,_0x43473b);st(_0x2a3682,_0x50db6d);}),_0x2a3682['onDisconnect_']=pn(),V(_0x2a3682['eventQueue_'],w(),_0x8f94f1);}function Cd(_0x2fc655,_0x1104f9,_0x3bba9b){let _0x2c20b0;y(_0x1104f9['_path'])==='.info'?_0x2c20b0=bi(_0x2fc655['infoSyncTree_'],_0x1104f9,_0x3bba9b):_0x2c20b0=bi(_0x2fc655['serverSyncTree_'],_0x1104f9,_0x3bba9b),ia(_0x2fc655['eventQueue_'],_0x1104f9['_path'],_0x2c20b0);}function Td(_0x44a294,_0x48f9cf,_0x5ac5ed){let _0x334f7b;y(_0x48f9cf['_path'])==='.info'?_0x334f7b=wn(_0x44a294['infoSyncTree_'],_0x48f9cf,_0x5ac5ed):_0x334f7b=wn(_0x44a294['serverSyncTree_'],_0x48f9cf,_0x5ac5ed),ia(_0x44a294['eventQueue_'],_0x48f9cf['_path'],_0x334f7b);}function aa(_0x351426){_0x351426['persistentConnection_']&&_0x351426['persistentConnection_']['interrupt'](ra);}function Sd(_0x3d06a5){_0x3d06a5['persistentConnection_']&&_0x3d06a5['persistentConnection_']['resume'](ra);}function ut(_0x5ad785,..._0x3d44bb){let _0x1f8587='';_0x5ad785['persistentConnection_']&&(_0x1f8587=_0x5ad785['persistentConnection_']['id']+':'),L(_0x1f8587,..._0x3d44bb);}function Ai(_0x5cebe0,_0x264ae3,_0x2d5ce1,_0xe79756){_0x264ae3&&lt(()=>{if(_0x2d5ce1==='ok')_0x264ae3(null);else{const _0x4585bd=(_0x2d5ce1||'error')['toUpperCase']();let _0x593d6c=_0x4585bd;_0xe79756&&(_0x593d6c+=':\x20'+_0xe79756);const _0x542e29=new Error(_0x593d6c);_0x542e29['code']=_0x4585bd,_0x264ae3(_0x542e29);}});}function bd(_0x5d99d5,_0x5852e1,_0x1dede2,_0x2d18c9,_0x573a75,_0xd19e88){ut(_0x5d99d5,'transaction\x20on\x20'+_0x5852e1);const _0x18ea98={'path':_0x5852e1,'update':_0x1dede2,'onComplete':_0x2d18c9,'status':null,'order':to(),'applyLocally':_0xd19e88,'retryCount':0x0,'unwatcher':_0x573a75,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2f3b22=ys(_0x5d99d5,_0x5852e1,void 0x0);_0x18ea98['currentInputSnapshot']=_0x2f3b22;const _0xb8b449=_0x18ea98['update'](_0x2f3b22['val']());if(_0xb8b449===void 0x0)_0x18ea98['unwatcher'](),_0x18ea98['currentOutputSnapshotRaw']=null,_0x18ea98['currentOutputSnapshotResolved']=null,_0x18ea98['onComplete']&&_0x18ea98['onComplete'](null,!0x1,_0x18ea98['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0xb8b449,_0x18ea98['path']),_0x18ea98['status']=0x0;const _0x3767ab=Un(_0x5d99d5['transactionQueueTree_'],_0x5852e1),_0x16e18e=Ge(_0x3767ab)||[];_0x16e18e['push'](_0x18ea98),fs(_0x3767ab,_0x16e18e);let _0x3a4991;typeof _0xb8b449=='object'&&_0xb8b449!==null&&Y(_0xb8b449,'.priority')?(_0x3a4991=Oe(_0xb8b449,'.priority'),f(Cn(_0x3a4991),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3a4991=(xn(_0x5d99d5['serverSyncTree_'],_0x5852e1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x15c38e=jt(_0x5d99d5),_0x425521=N(_0xb8b449,_0x3a4991),_0x8e74b1=hs(_0x425521,_0x2f3b22,_0x15c38e);_0x18ea98['currentOutputSnapshotRaw']=_0x425521,_0x18ea98['currentOutputSnapshotResolved']=_0x8e74b1,_0x18ea98['currentWriteId']=Vn(_0x5d99d5);const _0x2a50ff=ss(_0x5d99d5['serverSyncTree_'],_0x5852e1,_0x8e74b1,_0x18ea98['currentWriteId'],_0x18ea98['applyLocally']);V(_0x5d99d5['eventQueue_'],_0x5852e1,_0x2a50ff),Hn(_0x5d99d5,_0x5d99d5['transactionQueueTree_']);}}function ys(_0x3e3188,_0xdcf69c,_0x46f579){return xn(_0x3e3188['serverSyncTree_'],_0xdcf69c,_0x46f579)||g['EMPTY_NODE'];}function Hn(_0x8b340c,_0x47a9e2=_0x8b340c['transactionQueueTree_']){if(_0x47a9e2||$n(_0x8b340c,_0x47a9e2),Ge(_0x47a9e2)){const _0x758fd5=la(_0x8b340c,_0x47a9e2);f(_0x758fd5['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x758fd5['every'](_0x3694ea=>_0x3694ea['status']===0x0)&&Rd(_0x8b340c,Gt(_0x47a9e2),_0x758fd5);}else ea(_0x47a9e2)&&Wn(_0x47a9e2,_0x245e90=>{Hn(_0x8b340c,_0x245e90);});}function Rd(_0x25cc6b,_0x60eefe,_0x37817c){const _0x4ad48c=_0x37817c['map'](_0x37112c=>_0x37112c['currentWriteId']),_0x1945cb=ys(_0x25cc6b,_0x60eefe,_0x4ad48c);let _0xb1a699=_0x1945cb;const _0x424180=_0x1945cb['hash']();for(let _0x280fd2=0x0;_0x280fd2<_0x37817c['length'];_0x280fd2++){const _0x388358=_0x37817c[_0x280fd2];f(_0x388358['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x388358['status']=0x1,_0x388358['retryCount']++;const _0x41d8f0=F(_0x60eefe,_0x388358['path']);_0xb1a699=_0xb1a699['updateChild'](_0x41d8f0,_0x388358['currentOutputSnapshotRaw']);}const _0x41fbe2=_0xb1a699['val'](!0x0),_0x5af4c8=_0x60eefe;_0x25cc6b['server_']['put'](_0x5af4c8['toString'](),_0x41fbe2,_0x526f63=>{ut(_0x25cc6b,'transaction\x20put\x20response',{'path':_0x5af4c8['toString'](),'status':_0x526f63});let _0x399b56=[];if(_0x526f63==='ok'){const _0x4a1d67=[];for(let _0x555859=0x0;_0x555859<_0x37817c['length'];_0x555859++)_0x37817c[_0x555859]['status']=0x2,_0x399b56=_0x399b56['concat'](pe(_0x25cc6b['serverSyncTree_'],_0x37817c[_0x555859]['currentWriteId'])),_0x37817c[_0x555859]['onComplete']&&_0x4a1d67['push'](()=>_0x37817c[_0x555859]['onComplete'](null,!0x0,_0x37817c[_0x555859]['currentOutputSnapshotResolved'])),_0x37817c[_0x555859]['unwatcher']();$n(_0x25cc6b,Un(_0x25cc6b['transactionQueueTree_'],_0x60eefe)),Hn(_0x25cc6b,_0x25cc6b['transactionQueueTree_']),V(_0x25cc6b['eventQueue_'],_0x60eefe,_0x399b56);for(let _0x36f3e6=0x0;_0x36f3e6<_0x4a1d67['length'];_0x36f3e6++)lt(_0x4a1d67[_0x36f3e6]);}else{if(_0x526f63==='datastale'){for(let _0x68a936=0x0;_0x68a936<_0x37817c['length'];_0x68a936++)_0x37817c[_0x68a936]['status']===0x3?_0x37817c[_0x68a936]['status']=0x4:_0x37817c[_0x68a936]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5af4c8['toString']()+'\x20failed:\x20'+_0x526f63);for(let _0x57c60b=0x0;_0x57c60b<_0x37817c['length'];_0x57c60b++)_0x37817c[_0x57c60b]['status']=0x4,_0x37817c[_0x57c60b]['abortReason']=_0x526f63;}st(_0x25cc6b,_0x60eefe);}},_0x424180);}function st(_0x248102,_0x2df955){const _0x3a57a5=ca(_0x248102,_0x2df955),_0x508e51=Gt(_0x3a57a5),_0x709e53=la(_0x248102,_0x3a57a5);return Ad(_0x248102,_0x709e53,_0x508e51),_0x508e51;}function Ad(_0x2dbd60,_0x3a96f1,_0x173256){if(_0x3a96f1['length']===0x0)return;const _0x5e2f71=[];let _0x5de264=[];const _0x3c050f=_0x3a96f1['filter'](_0x3f1f62=>_0x3f1f62['status']===0x0)['map'](_0x32e7c4=>_0x32e7c4['currentWriteId']);for(let _0x4c85b9=0x0;_0x4c85b9<_0x3a96f1['length'];_0x4c85b9++){const _0x5a15ab=_0x3a96f1[_0x4c85b9],_0x569717=F(_0x173256,_0x5a15ab['path']);let _0x58e990=!0x1,_0x5dbddb;if(f(_0x569717!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5a15ab['status']===0x4)_0x58e990=!0x0,_0x5dbddb=_0x5a15ab['abortReason'],_0x5de264=_0x5de264['concat'](pe(_0x2dbd60['serverSyncTree_'],_0x5a15ab['currentWriteId'],!0x0));else{if(_0x5a15ab['status']===0x0){if(_0x5a15ab['retryCount']>=_d)_0x58e990=!0x0,_0x5dbddb='maxretry',_0x5de264=_0x5de264['concat'](pe(_0x2dbd60['serverSyncTree_'],_0x5a15ab['currentWriteId'],!0x0));else{const _0x34a360=ys(_0x2dbd60,_0x5a15ab['path'],_0x3c050f);_0x5a15ab['currentInputSnapshot']=_0x34a360;const _0x18b231=_0x3a96f1[_0x4c85b9]['update'](_0x34a360['val']());if(_0x18b231!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x18b231,_0x5a15ab['path']);let _0xbf746b=N(_0x18b231);typeof _0x18b231=='object'&&_0x18b231!=null&&Y(_0x18b231,'.priority')||(_0xbf746b=_0xbf746b['updatePriority'](_0x34a360['getPriority']()));const _0x2db9bb=_0x5a15ab['currentWriteId'],_0x467d57=jt(_0x2dbd60),_0x29908b=hs(_0xbf746b,_0x34a360,_0x467d57);_0x5a15ab['currentOutputSnapshotRaw']=_0xbf746b,_0x5a15ab['currentOutputSnapshotResolved']=_0x29908b,_0x5a15ab['currentWriteId']=Vn(_0x2dbd60),_0x3c050f['splice'](_0x3c050f['indexOf'](_0x2db9bb),0x1),_0x5de264=_0x5de264['concat'](ss(_0x2dbd60['serverSyncTree_'],_0x5a15ab['path'],_0x29908b,_0x5a15ab['currentWriteId'],_0x5a15ab['applyLocally'])),_0x5de264=_0x5de264['concat'](pe(_0x2dbd60['serverSyncTree_'],_0x2db9bb,!0x0));}else _0x58e990=!0x0,_0x5dbddb='nodata',_0x5de264=_0x5de264['concat'](pe(_0x2dbd60['serverSyncTree_'],_0x5a15ab['currentWriteId'],!0x0));}}}V(_0x2dbd60['eventQueue_'],_0x173256,_0x5de264),_0x5de264=[],_0x58e990&&(_0x3a96f1[_0x4c85b9]['status']=0x2,function(_0xd29f87){setTimeout(_0xd29f87,Math['floor'](0x0));}(_0x3a96f1[_0x4c85b9]['unwatcher']),_0x3a96f1[_0x4c85b9]['onComplete']&&(_0x5dbddb==='nodata'?_0x5e2f71['push'](()=>_0x3a96f1[_0x4c85b9]['onComplete'](null,!0x1,_0x3a96f1[_0x4c85b9]['currentInputSnapshot'])):_0x5e2f71['push'](()=>_0x3a96f1[_0x4c85b9]['onComplete'](new Error(_0x5dbddb),!0x1,null))));}$n(_0x2dbd60,_0x2dbd60['transactionQueueTree_']);for(let _0x39c0b3=0x0;_0x39c0b3<_0x5e2f71['length'];_0x39c0b3++)lt(_0x5e2f71[_0x39c0b3]);Hn(_0x2dbd60,_0x2dbd60['transactionQueueTree_']);}function ca(_0x33971e,_0x54ad7f){let _0x43d8d2,_0x18207e=_0x33971e['transactionQueueTree_'];for(_0x43d8d2=y(_0x54ad7f);_0x43d8d2!==null&&Ge(_0x18207e)===void 0x0;)_0x18207e=Un(_0x18207e,_0x43d8d2),_0x54ad7f=b(_0x54ad7f),_0x43d8d2=y(_0x54ad7f);return _0x18207e;}function la(_0x3ab622,_0x1d2deb){const _0x2c37e1=[];return ha(_0x3ab622,_0x1d2deb,_0x2c37e1),_0x2c37e1['sort']((_0x464970,_0x53f337)=>_0x464970['order']-_0x53f337['order']),_0x2c37e1;}function ha(_0x95abab,_0x37f4df,_0x21a049){const _0x36fc1e=Ge(_0x37f4df);if(_0x36fc1e){for(let _0x25ee6d=0x0;_0x25ee6d<_0x36fc1e['length'];_0x25ee6d++)_0x21a049['push'](_0x36fc1e[_0x25ee6d]);}Wn(_0x37f4df,_0x74b6dc=>{ha(_0x95abab,_0x74b6dc,_0x21a049);});}function $n(_0x1f8ab7,_0x183eff){const _0x2212e4=Ge(_0x183eff);if(_0x2212e4){let _0x39fc55=0x0;for(let _0x562995=0x0;_0x562995<_0x2212e4['length'];_0x562995++)_0x2212e4[_0x562995]['status']!==0x2&&(_0x2212e4[_0x39fc55]=_0x2212e4[_0x562995],_0x39fc55++);_0x2212e4['length']=_0x39fc55,fs(_0x183eff,_0x2212e4['length']>0x0?_0x2212e4:void 0x0);}Wn(_0x183eff,_0x150231=>{$n(_0x1f8ab7,_0x150231);});}function vs(_0x533fb8,_0x13d139){const _0x5bf07a=Gt(ca(_0x533fb8,_0x13d139)),_0x436cc9=Un(_0x533fb8['transactionQueueTree_'],_0x13d139);return sd(_0x436cc9,_0x13cd14=>{ai(_0x533fb8,_0x13cd14);}),ai(_0x533fb8,_0x436cc9),ta(_0x436cc9,_0x26035a=>{ai(_0x533fb8,_0x26035a);}),_0x5bf07a;}function ai(_0x49608b,_0x431b62){const _0x28577f=Ge(_0x431b62);if(_0x28577f){const _0x29c56c=[];let _0x2d16bb=[],_0x378ca7=-0x1;for(let _0x269204=0x0;_0x269204<_0x28577f['length'];_0x269204++)_0x28577f[_0x269204]['status']===0x3||(_0x28577f[_0x269204]['status']===0x1?(f(_0x378ca7===_0x269204-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x378ca7=_0x269204,_0x28577f[_0x269204]['status']=0x3,_0x28577f[_0x269204]['abortReason']='set'):(f(_0x28577f[_0x269204]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x28577f[_0x269204]['unwatcher'](),_0x2d16bb=_0x2d16bb['concat'](pe(_0x49608b['serverSyncTree_'],_0x28577f[_0x269204]['currentWriteId'],!0x0)),_0x28577f[_0x269204]['onComplete']&&_0x29c56c['push'](_0x28577f[_0x269204]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x378ca7===-0x1?fs(_0x431b62,void 0x0):_0x28577f['length']=_0x378ca7+0x1,V(_0x49608b['eventQueue_'],Gt(_0x431b62),_0x2d16bb);for(let _0x331149=0x0;_0x331149<_0x29c56c['length'];_0x331149++)lt(_0x29c56c[_0x331149]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x19be72){let _0x403e2f='';const _0x2721bb=_0x19be72['split']('/');for(let _0x415723=0x0;_0x415723<_0x2721bb['length'];_0x415723++)if(_0x2721bb[_0x415723]['length']>0x0){let _0x58dd6c=_0x2721bb[_0x415723];try{_0x58dd6c=decodeURIComponent(_0x58dd6c['replace'](/\+/g,'\x20'));}catch{}_0x403e2f+='/'+_0x58dd6c;}return _0x403e2f;}function Nd(_0x17beb1){const _0x5ce166={};_0x17beb1['charAt'](0x0)==='?'&&(_0x17beb1=_0x17beb1['substring'](0x1));for(const _0x4f6802 of _0x17beb1['split']('&')){if(_0x4f6802['length']===0x0)continue;const _0x3c3ff5=_0x4f6802['split']('=');_0x3c3ff5['length']===0x2?_0x5ce166[decodeURIComponent(_0x3c3ff5[0x0])]=decodeURIComponent(_0x3c3ff5[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4f6802+'\x27\x20in\x20query\x20\x27'+_0x17beb1+'\x27');}return _0x5ce166;}const gr=function(_0x4bffed,_0x4f3f56){const _0x286916=Pd(_0x4bffed),_0x4a82b9=_0x286916['namespace'];_0x286916['domain']==='firebase.com'&&oe(_0x286916['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4a82b9||_0x4a82b9==='undefined')&&_0x286916['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x286916['secure']||Bl();const _0xbd5628=_0x286916['scheme']==='ws'||_0x286916['scheme']==='wss';return{'repoInfo':new _o(_0x286916['host'],_0x286916['secure'],_0x4a82b9,_0xbd5628,_0x4f3f56,'',_0x4a82b9!==_0x286916['subdomain']),'path':new C(_0x286916['pathString'])};},Pd=function(_0x361ed3){let _0x17438a='',_0x6d4258='',_0x353bc6='',_0x42b30e='',_0x2c7040='',_0x5f0c28=!0x0,_0x5b5cc2='https',_0x1b27e2=0x1bb;if(typeof _0x361ed3=='string'){let _0x5d72b2=_0x361ed3['indexOf']('//');_0x5d72b2>=0x0&&(_0x5b5cc2=_0x361ed3['substring'](0x0,_0x5d72b2-0x1),_0x361ed3=_0x361ed3['substring'](_0x5d72b2+0x2));let _0x10baaf=_0x361ed3['indexOf']('/');_0x10baaf===-0x1&&(_0x10baaf=_0x361ed3['length']);let _0x45c376=_0x361ed3['indexOf']('?');_0x45c376===-0x1&&(_0x45c376=_0x361ed3['length']),_0x17438a=_0x361ed3['substring'](0x0,Math['min'](_0x10baaf,_0x45c376)),_0x10baaf<_0x45c376&&(_0x42b30e=kd(_0x361ed3['substring'](_0x10baaf,_0x45c376)));const _0x510b0e=Nd(_0x361ed3['substring'](Math['min'](_0x361ed3['length'],_0x45c376)));_0x5d72b2=_0x17438a['indexOf'](':'),_0x5d72b2>=0x0?(_0x5f0c28=_0x5b5cc2==='https'||_0x5b5cc2==='wss',_0x1b27e2=parseInt(_0x17438a['substring'](_0x5d72b2+0x1),0xa)):_0x5d72b2=_0x17438a['length'];const _0x1c731c=_0x17438a['slice'](0x0,_0x5d72b2);if(_0x1c731c['toLowerCase']()==='localhost')_0x6d4258='localhost';else{if(_0x1c731c['split']('.')['length']<=0x2)_0x6d4258=_0x1c731c;else{const _0x42fb65=_0x17438a['indexOf']('.');_0x353bc6=_0x17438a['substring'](0x0,_0x42fb65)['toLowerCase'](),_0x6d4258=_0x17438a['substring'](_0x42fb65+0x1),_0x2c7040=_0x353bc6;}}'ns'in _0x510b0e&&(_0x2c7040=_0x510b0e['ns']);}return{'host':_0x17438a,'port':_0x1b27e2,'domain':_0x6d4258,'subdomain':_0x353bc6,'secure':_0x5f0c28,'scheme':_0x5b5cc2,'pathString':_0x42b30e,'namespace':_0x2c7040};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x220589=0x0;const _0x224fc2=[];return function(_0x15a5e1){const _0x5781c4=_0x15a5e1===_0x220589;_0x220589=_0x15a5e1;let _0x2ac6c8;const _0x2a02ca=new Array(0x8);for(_0x2ac6c8=0x7;_0x2ac6c8>=0x0;_0x2ac6c8--)_0x2a02ca[_0x2ac6c8]=mr['charAt'](_0x15a5e1%0x40),_0x15a5e1=Math['floor'](_0x15a5e1/0x40);f(_0x15a5e1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1eac0c=_0x2a02ca['join']('');if(_0x5781c4){for(_0x2ac6c8=0xb;_0x2ac6c8>=0x0&&_0x224fc2[_0x2ac6c8]===0x3f;_0x2ac6c8--)_0x224fc2[_0x2ac6c8]=0x0;_0x224fc2[_0x2ac6c8]++;}else{for(_0x2ac6c8=0x0;_0x2ac6c8<0xc;_0x2ac6c8++)_0x224fc2[_0x2ac6c8]=Math['floor'](Math['random']()*0x40);}for(_0x2ac6c8=0x0;_0x2ac6c8<0xc;_0x2ac6c8++)_0x1eac0c+=mr['charAt'](_0x224fc2[_0x2ac6c8]);return f(_0x1eac0c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1eac0c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x179fc8,_0x1a317b,_0x28f997,_0x186a2b){this['eventType']=_0x179fc8,this['eventRegistration']=_0x1a317b,this['snapshot']=_0x28f997,this['prevName']=_0x186a2b;}['getPath'](){const _0x13195a=this['snapshot']['ref'];return this['eventType']==='value'?_0x13195a['_path']:_0x13195a['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3b4e27,_0x556e54,_0x4769b6){this['eventRegistration']=_0x3b4e27,this['error']=_0x556e54,this['path']=_0x4769b6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x4cf0c6,_0x992b87){this['snapshotCallback']=_0x4cf0c6,this['cancelCallback']=_0x992b87;}['onValue'](_0x215a31,_0x387396){this['snapshotCallback']['call'](null,_0x215a31,_0x387396);}['onCancel'](_0x4495a2){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4495a2);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4c15f0){return this['snapshotCallback']===_0x4c15f0['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4c15f0['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4c15f0['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x163acf,_0x4270be,_0x4bbc89,_0x872084){this['_repo']=_0x163acf,this['_path']=_0x4270be,this['_queryParams']=_0x4bbc89,this['_orderByCalled']=_0x872084;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xee7824=nr(this['_queryParams']),_0x5bd8c8=Bi(_0xee7824);return _0x5bd8c8==='{}'?'default':_0x5bd8c8;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x2b32ca){if(_0x2b32ca=k(_0x2b32ca),!(_0x2b32ca instanceof be))return!0x1;const _0x58b31a=this['_repo']===_0x2b32ca['_repo'],_0x24f003=qi(this['_path'],_0x2b32ca['_path']),_0x5e98c9=this['_queryIdentifier']===_0x2b32ca['_queryIdentifier'];return _0x58b31a&&_0x24f003&&_0x5e98c9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x5b7234,_0x518b68){if(_0x5b7234['_orderByCalled']===!0x0)throw new Error(_0x518b68+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x57751b){let _0x5559e9=null,_0x251334=null;if(_0x57751b['hasStart']()&&(_0x5559e9=_0x57751b['getIndexStartValue']()),_0x57751b['hasEnd']()&&(_0x251334=_0x57751b['getIndexEndValue']()),_0x57751b['getIndex']()===ye){const _0x197d03='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x38e75b='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x57751b['hasStart']()){if(_0x57751b['getIndexStartName']()!==xe)throw new Error(_0x197d03);if(typeof _0x5559e9!='string')throw new Error(_0x38e75b);}if(_0x57751b['hasEnd']()){if(_0x57751b['getIndexEndName']()!==Ie)throw new Error(_0x197d03);if(typeof _0x251334!='string')throw new Error(_0x38e75b);}}else{if(_0x57751b['getIndex']()===R){if(_0x5559e9!=null&&!Cn(_0x5559e9)||_0x251334!=null&&!Cn(_0x251334))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x57751b['getIndex']()instanceof Ki||_0x57751b['getIndex']()===Po,'unknown\x20index\x20type.'),_0x5559e9!=null&&typeof _0x5559e9=='object'||_0x251334!=null&&typeof _0x251334=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x55d61b){if(_0x55d61b['hasStart']()&&_0x55d61b['hasEnd']()&&_0x55d61b['hasLimit']()&&!_0x55d61b['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x296602,_0x5b7336){super(_0x296602,_0x5b7336,new Qi(),!0x1);}get['parent'](){const _0x5041a7=To(this['_path']);return _0x5041a7===null?null:new Z(this['_repo'],_0x5041a7);}get['root'](){let _0x14a6f4=this;for(;_0x14a6f4['parent']!==null;)_0x14a6f4=_0x14a6f4['parent'];return _0x14a6f4;}}class rt{constructor(_0x2336aa,_0x470ec6,_0xd01739){this['_node']=_0x2336aa,this['ref']=_0x470ec6,this['_index']=_0xd01739;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x17b8f3){const _0x15442b=new C(_0x17b8f3),_0x56e656=Lt(this['ref'],_0x17b8f3);return new rt(this['_node']['getChild'](_0x15442b),_0x56e656,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5a5420){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x53e207,_0x7131f8)=>_0x5a5420(new rt(_0x7131f8,Lt(this['ref'],_0x53e207),R)));}['hasChild'](_0xac6a85){const _0x1f0183=new C(_0xac6a85);return!this['_node']['getChild'](_0x1f0183)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x484242,_0x1c91f3){return _0x484242=k(_0x484242),_0x484242['_checkNotDeleted']('ref'),_0x1c91f3!==void 0x0?Lt(_0x484242['_root'],_0x1c91f3):_0x484242['_root'];}function Lt(_0x1b9acf,_0x4504e2){return _0x1b9acf=k(_0x1b9acf),y(_0x1b9acf['_path'])===null?ud('child','path',_0x4504e2):_s('child','path',_0x4504e2),new Z(_0x1b9acf['_repo'],A(_0x1b9acf['_path'],_0x4504e2));}function d_(_0x5b941e,_0x455dbf){_0x5b941e=k(_0x5b941e),gs('push',_0x5b941e['_path']),qt('push',_0x455dbf,_0x5b941e['_path'],!0x0);const _0x177ff8=oa(_0x5b941e['_repo']),_0x11079d=Od(_0x177ff8),_0x5096ca=Lt(_0x5b941e,_0x11079d),_0x31963a=Lt(_0x5b941e,_0x11079d);let _0x33dc96;return _0x455dbf!=null?_0x33dc96=Ld(_0x31963a,_0x455dbf)['then'](()=>_0x31963a):_0x33dc96=Promise['resolve'](_0x31963a),_0x5096ca['then']=_0x33dc96['then']['bind'](_0x33dc96),_0x5096ca['catch']=_0x33dc96['then']['bind'](_0x33dc96,void 0x0),_0x5096ca;}function Ld(_0x292e72,_0x5f0dbe){_0x292e72=k(_0x292e72),gs('set',_0x292e72['_path']),qt('set',_0x5f0dbe,_0x292e72['_path'],!0x1);const _0xe7c761=new Ve();return Ed(_0x292e72['_repo'],_0x292e72['_path'],_0x5f0dbe,null,_0xe7c761['wrapCallback'](()=>{})),_0xe7c761['promise'];}function f_(_0x712aaf,_0x1b9816){hd('update',_0x1b9816,_0x712aaf['_path']);const _0x7edd93=new Ve();return Id(_0x712aaf['_repo'],_0x712aaf['_path'],_0x1b9816,_0x7edd93['wrapCallback'](()=>{})),_0x7edd93['promise'];}function p_(_0x29abfb){_0x29abfb=k(_0x29abfb);const _0xd7f75d=new ua(()=>{}),_0x379c97=new qn(_0xd7f75d);return vd(_0x29abfb['_repo'],_0x29abfb,_0x379c97)['then'](_0x428747=>new rt(_0x428747,new Z(_0x29abfb['_repo'],_0x29abfb['_path']),_0x29abfb['_queryParams']['getIndex']()));}class qn{constructor(_0x555491){this['callbackContext']=_0x555491;}['respondsTo'](_0x55822e){return _0x55822e==='value';}['createEvent'](_0xf61b05,_0x558b9d){const _0x2a8e37=_0x558b9d['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0xf61b05['snapshotNode'],new Z(_0x558b9d['_repo'],_0x558b9d['_path']),_0x2a8e37));}['getEventRunner'](_0x15c02d){return _0x15c02d['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x15c02d['error']):()=>this['callbackContext']['onValue'](_0x15c02d['snapshot'],null);}['createCancelEvent'](_0x294045,_0x5595a5){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x294045,_0x5595a5):null;}['matches'](_0x5ef084){return _0x5ef084 instanceof qn?!_0x5ef084['callbackContext']||!this['callbackContext']?!0x0:_0x5ef084['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x1bddfd,_0xe86ab0,_0x4a874f,_0x36b657,_0x3fe248){const _0x484852=new ua(_0x4a874f,void 0x0),_0x1da95e=new qn(_0x484852);return Cd(_0x1bddfd['_repo'],_0x1bddfd,_0x1da95e),()=>Td(_0x1bddfd['_repo'],_0x1bddfd,_0x1da95e);}function Fd(_0x47789e,_0x17d3f8,_0x57c9bb,_0x14a1fe){return xd(_0x47789e,'value',_0x17d3f8);}class dt{}class pa extends dt{constructor(_0x3449a6,_0x23ac27){super(),this['_value']=_0x3449a6,this['_key']=_0x23ac27,this['type']='endAt';}['_apply'](_0x581ccd){qt('endAt',this['_value'],_0x581ccd['_path'],!0x0);const _0x13b4cd=Kh(_0x581ccd['_queryParams'],this['_value'],this['_key']);if(fa(_0x13b4cd),Gn(_0x13b4cd),_0x581ccd['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x581ccd['_repo'],_0x581ccd['_path'],_0x13b4cd,_0x581ccd['_orderByCalled']);}}function __(_0x4190af,_0x1ebfe1){return new pa(_0x4190af,_0x1ebfe1);}class _a extends dt{constructor(_0x414854,_0xe68a1d){super(),this['_value']=_0x414854,this['_key']=_0xe68a1d,this['type']='startAt';}['_apply'](_0x119aac){qt('startAt',this['_value'],_0x119aac['_path'],!0x0);const _0x16fef7=jh(_0x119aac['_queryParams'],this['_value'],this['_key']);if(fa(_0x16fef7),Gn(_0x16fef7),_0x119aac['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x119aac['_repo'],_0x119aac['_path'],_0x16fef7,_0x119aac['_orderByCalled']);}}function g_(_0x757db7=null,_0x283fd4){return new _a(_0x757db7,_0x283fd4);}class Ud extends dt{constructor(_0x21c6df){super(),this['_limit']=_0x21c6df,this['type']='limitToFirst';}['_apply'](_0x15b339){if(_0x15b339['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x15b339['_repo'],_0x15b339['_path'],zh(_0x15b339['_queryParams'],this['_limit']),_0x15b339['_orderByCalled']);}}function m_(_0x4f7914){if(Math['floor'](_0x4f7914)!==_0x4f7914||_0x4f7914<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x4f7914);}class Wd extends dt{constructor(_0x1e155c){super(),this['_path']=_0x1e155c,this['type']='orderByChild';}['_apply'](_0x1752fa){da(_0x1752fa,'orderByChild');const _0x23f702=new C(this['_path']);if(v(_0x23f702))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3096da=new Ki(_0x23f702),_0x43e4d0=Do(_0x1752fa['_queryParams'],_0x3096da);return Gn(_0x43e4d0),new be(_0x1752fa['_repo'],_0x1752fa['_path'],_0x43e4d0,!0x0);}}function y_(_0xec8858){if(_0xec8858==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0xec8858==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0xec8858==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0xec8858),new Wd(_0xec8858);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3620e9){da(_0x3620e9,'orderByKey');const _0x401ee6=Do(_0x3620e9['_queryParams'],ye);return Gn(_0x401ee6),new be(_0x3620e9['_repo'],_0x3620e9['_path'],_0x401ee6,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x38da7f,_0x15ef69){super(),this['_value']=_0x38da7f,this['_key']=_0x15ef69,this['type']='equalTo';}['_apply'](_0x155509){if(qt('equalTo',this['_value'],_0x155509['_path'],!0x1),_0x155509['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x155509['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x155509));}}function E_(_0x317b07,_0x32b0a5){return new Vd(_0x317b07,_0x32b0a5);}function I_(_0x11493d,..._0x11fd9a){let _0x2c10b9=k(_0x11493d);for(const _0xc0925a of _0x11fd9a)_0x2c10b9=_0xc0925a['_apply'](_0x2c10b9);return _0x2c10b9;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x5df1d7,_0x194a86,_0x59cf54,_0x51a8fe){const _0x34a8d1=_0x194a86['lastIndexOf'](':'),_0x1873d0=_0x194a86['substring'](0x0,_0x34a8d1),_0x520a4b=Wt(_0x1873d0);_0x5df1d7['repoInfo_']=new _o(_0x194a86,_0x520a4b,_0x5df1d7['repoInfo_']['namespace'],_0x5df1d7['repoInfo_']['webSocketOnly'],_0x5df1d7['repoInfo_']['nodeAdmin'],_0x5df1d7['repoInfo_']['persistenceKey'],_0x5df1d7['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x59cf54),_0x51a8fe&&(_0x5df1d7['authTokenProvider_']=_0x51a8fe);}function qd(_0x484419,_0x353b92,_0x247366,_0x268f96,_0x4605af){let _0x1f0872=_0x268f96||_0x484419['options']['databaseURL'];_0x1f0872===void 0x0&&(_0x484419['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x484419['options']['projectId']),_0x1f0872=_0x484419['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2d2371=gr(_0x1f0872,_0x4605af),_0x57fa46=_0x2d2371['repoInfo'],_0x575dee;typeof process<'u'&&Us&&(_0x575dee=Us[Hd]),_0x575dee?(_0x1f0872='http://'+_0x575dee+'?ns='+_0x57fa46['namespace'],_0x2d2371=gr(_0x1f0872,_0x4605af),_0x57fa46=_0x2d2371['repoInfo']):_0x2d2371['repoInfo']['secure'];const _0x4d1ce7=new Jl(_0x484419['name'],_0x484419['options'],_0x353b92);dd('Invalid\x20Firebase\x20Database\x20URL',_0x2d2371),v(_0x2d2371['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x47004c=jd(_0x57fa46,_0x484419,_0x4d1ce7,new Ql(_0x484419,_0x247366));return new Kd(_0x47004c,_0x484419);}function zd(_0x5e738e,_0x4f8cb2){const _0x4e8d13=ki[_0x4f8cb2];(!_0x4e8d13||_0x4e8d13[_0x5e738e['key']]!==_0x5e738e)&&oe('Database\x20'+_0x4f8cb2+'('+_0x5e738e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5e738e),delete _0x4e8d13[_0x5e738e['key']];}function jd(_0x377e9c,_0xfe8edd,_0x324ad3,_0x3f31fa){let _0x5765ee=ki[_0xfe8edd['name']];_0x5765ee||(_0x5765ee={},ki[_0xfe8edd['name']]=_0x5765ee);let _0x1cc4dd=_0x5765ee[_0x377e9c['toURLString']()];return _0x1cc4dd&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1cc4dd=new gd(_0x377e9c,$d,_0x324ad3,_0x3f31fa),_0x5765ee[_0x377e9c['toURLString']()]=_0x1cc4dd,_0x1cc4dd;}class Kd{constructor(_0x5d8092,_0x211c90){this['_repoInternal']=_0x5d8092,this['app']=_0x211c90,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x25c8c2){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x25c8c2+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1de8a8=Qr(),_0xd8152){const _0x2f0c32=Ui(_0x1de8a8,'database')['getImmediate']({'identifier':_0xd8152});if(!_0x2f0c32['_instanceStarted']){const _0xe6342d=ac('database');_0xe6342d&&Yd(_0x2f0c32,..._0xe6342d);}return _0x2f0c32;}function Yd(_0x38de61,_0x547350,_0x460d61,_0x369dfd={}){_0x38de61=k(_0x38de61),_0x38de61['_checkNotDeleted']('useEmulator');const _0x84f039=_0x547350+':'+_0x460d61,_0x24c120=_0x38de61['_repoInternal'];if(_0x38de61['_instanceStarted']){if(_0x84f039===_0x38de61['_repoInternal']['repoInfo_']['host']&&De(_0x369dfd,_0x24c120['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x35de32;if(_0x24c120['repoInfo_']['nodeAdmin'])_0x369dfd['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x35de32=new tn(tn['OWNER']);else{if(_0x369dfd['mockUserToken']){const _0x366a51=typeof _0x369dfd['mockUserToken']=='string'?_0x369dfd['mockUserToken']:cc(_0x369dfd['mockUserToken'],_0x38de61['app']['options']['projectId']);_0x35de32=new tn(_0x366a51);}}Wt(_0x547350)&&jr(_0x547350),Gd(_0x24c120,_0x84f039,_0x369dfd,_0x35de32);}function C_(_0x33213c){_0x33213c=k(_0x33213c),_0x33213c['_checkNotDeleted']('goOffline'),aa(_0x33213c['_repo']);}function T_(_0x5a454d){_0x5a454d=k(_0x5a454d),_0x5a454d['_checkNotDeleted']('goOnline'),Sd(_0x5a454d['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x23a426){Ll(ct),et(new Me('database',(_0x1d4c77,{instanceIdentifier:_0x54a25f})=>{const _0x17b4df=_0x1d4c77['getProvider']('app')['getImmediate'](),_0x30ddc5=_0x1d4c77['getProvider']('auth-internal'),_0x21d8aa=_0x1d4c77['getProvider']('app-check-internal');return qd(_0x17b4df,_0x30ddc5,_0x21d8aa,_0x54a25f);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x23a426),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x22835c,_0xd63304){this['committed']=_0x22835c,this['snapshot']=_0xd63304;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x55d884,_0x48c9cd,_0x21b988){if(_0x55d884=k(_0x55d884),gs('Reference.transaction',_0x55d884['_path']),_0x55d884['key']==='.length'||_0x55d884['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x55d884['key']+'\x20is\x20a\x20read-only\x20object.';const _0x48bf51=!0x0,_0xc21ea8=new Ve(),_0x583aa5=(_0x317987,_0x38434a,_0x2871e3)=>{let _0x5d3ba1=null;_0x317987?_0xc21ea8['reject'](_0x317987):(_0x5d3ba1=new rt(_0x2871e3,new Z(_0x55d884['_repo'],_0x55d884['_path']),R),_0xc21ea8['resolve'](new Xd(_0x38434a,_0x5d3ba1)));},_0x3199d2=Fd(_0x55d884,()=>{});return bd(_0x55d884['_repo'],_0x55d884['_path'],_0x48c9cd,_0x583aa5,_0x3199d2,_0x48bf51),_0xc21ea8['promise'];}ie['prototype']['simpleListen']=function(_0x43f9a9,_0x560029){this['sendRequest']('q',{'p':_0x43f9a9},_0x560029);},ie['prototype']['echo']=function(_0x50b9b9,_0x3a93db){this['sendRequest']('echo',{'d':_0x50b9b9},_0x3a93db);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x12b1c6,..._0x121884){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x12b1c6,..._0x121884);}function nn(_0x27ed26,..._0x5b266a){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x27ed26,..._0x5b266a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x38db22,..._0x4a7273){throw Es(_0x38db22,..._0x4a7273);}function J(_0x3fd82d,..._0x479485){return Es(_0x3fd82d,..._0x479485);}function ya(_0x2bc608,_0xb3d965,_0x4cd678){const _0x3da151={...Zd(),[_0xb3d965]:_0x4cd678};return new Ut('auth','Firebase',_0x3da151)['create'](_0xb3d965,{'appName':_0x2bc608['name']});}function se(_0x545bf3){return ya(_0x545bf3,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x23662c,..._0x3e35f7){if(typeof _0x23662c!='string'){const _0x477763=_0x3e35f7[0x0],_0x21f932=[..._0x3e35f7['slice'](0x1)];return _0x21f932[0x0]&&(_0x21f932[0x0]['appName']=_0x23662c['name']),_0x23662c['_errorFactory']['create'](_0x477763,..._0x21f932);}return ma['create'](_0x23662c,..._0x3e35f7);}function m(_0x669890,_0x21d602,..._0x5c438f){if(!_0x669890)throw Es(_0x21d602,..._0x5c438f);}function te(_0x441570){const _0x42476='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x441570;throw nn(_0x42476),new Error(_0x42476);}function ae(_0x3598e2,_0x592042){_0x3598e2||te(_0x592042);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x3bf6d6;return typeof self<'u'&&((_0x3bf6d6=self['location'])==null?void 0x0:_0x3bf6d6['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0xb7182e;return typeof self<'u'&&((_0xb7182e=self['location'])==null?void 0x0:_0xb7182e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x532bfe=navigator;return _0x532bfe['languages']&&_0x532bfe['languages'][0x0]||_0x532bfe['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0xacb74e,_0x408b8b){this['shortDelay']=_0xacb74e,this['longDelay']=_0x408b8b,ae(_0x408b8b>_0xacb74e,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x5f0932,_0x36021a){ae(_0x5f0932['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x42a8cb}=_0x5f0932['emulator'];return _0x36021a?''+_0x42a8cb+(_0x36021a['startsWith']('/')?_0x36021a['slice'](0x1):_0x36021a):_0x42a8cb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x226c57,_0x2806bf,_0x6a24c4){this['fetchImpl']=_0x226c57,_0x2806bf&&(this['headersImpl']=_0x2806bf),_0x6a24c4&&(this['responseImpl']=_0x6a24c4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x420729,_0x339ece){return _0x420729['tenantId']&&!_0x339ece['tenantId']?{..._0x339ece,'tenantId':_0x420729['tenantId']}:_0x339ece;}async function Ae(_0xcfa1d4,_0x55906c,_0x3c6b76,_0x1da0f4,_0x317613={}){return Ea(_0xcfa1d4,_0x317613,async()=>{let _0x3bdc23={},_0x2e23a3={};_0x1da0f4&&(_0x55906c==='GET'?_0x2e23a3=_0x1da0f4:_0x3bdc23={'body':JSON['stringify'](_0x1da0f4)});const _0x248759=at({..._0x2e23a3,'key':_0xcfa1d4['config']['apiKey']})['slice'](0x1),_0x157871=await _0xcfa1d4['_getAdditionalHeaders']();_0x157871['Content-Type']='application/json',_0xcfa1d4['languageCode']&&(_0x157871['X-Firebase-Locale']=_0xcfa1d4['languageCode']);const _0x2a4881={'method':_0x55906c,'headers':_0x157871,..._0x3bdc23};return lc()||(_0x2a4881['referrerPolicy']='strict-origin-when-cross-origin'),_0xcfa1d4['emulatorConfig']&&Wt(_0xcfa1d4['emulatorConfig']['host'])&&(_0x2a4881['credentials']='include'),va['fetch']()(await Ia(_0xcfa1d4,_0xcfa1d4['config']['apiHost'],_0x3c6b76,_0x248759),_0x2a4881);});}async function Ea(_0xafda52,_0x3b96a5,_0xf015e7){_0xafda52['_canInitEmulator']=!0x1;const _0x51e0b5={...rf,..._0x3b96a5};try{const _0x1a7c58=new lf(_0xafda52),_0x402499=await Promise['race']([_0xf015e7(),_0x1a7c58['promise']]);_0x1a7c58['clearNetworkTimeout']();const _0x5a902a=await _0x402499['json']();if('needConfirmation'in _0x5a902a)throw en(_0xafda52,'account-exists-with-different-credential',_0x5a902a);if(_0x402499['ok']&&!('errorMessage'in _0x5a902a))return _0x5a902a;{const _0x261c78=_0x402499['ok']?_0x5a902a['errorMessage']:_0x5a902a['error']['message'],[_0x3c9e8b,_0x28fcff]=_0x261c78['split']('\x20:\x20');if(_0x3c9e8b==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0xafda52,'credential-already-in-use',_0x5a902a);if(_0x3c9e8b==='EMAIL_EXISTS')throw en(_0xafda52,'email-already-in-use',_0x5a902a);if(_0x3c9e8b==='USER_DISABLED')throw en(_0xafda52,'user-disabled',_0x5a902a);const _0x5e0851=_0x51e0b5[_0x3c9e8b]||_0x3c9e8b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x28fcff)throw ya(_0xafda52,_0x5e0851,_0x28fcff);K(_0xafda52,_0x5e0851);}}catch(_0x412536){if(_0x412536 instanceof Se)throw _0x412536;K(_0xafda52,'network-request-failed',{'message':String(_0x412536)});}}async function Yt(_0x474fd6,_0x3f4de6,_0x45676a,_0x121136,_0x5521be={}){const _0x17e9a0=await Ae(_0x474fd6,_0x3f4de6,_0x45676a,_0x121136,_0x5521be);return'mfaPendingCredential'in _0x17e9a0&&K(_0x474fd6,'multi-factor-auth-required',{'_serverResponse':_0x17e9a0}),_0x17e9a0;}async function Ia(_0x54535b,_0x2131c1,_0x3eb364,_0x33ec85){const _0x146780=''+_0x2131c1+_0x3eb364+'?'+_0x33ec85,_0x5bfc6d=_0x54535b,_0x2914c0=_0x5bfc6d['config']['emulator']?Is(_0x54535b['config'],_0x146780):_0x54535b['config']['apiScheme']+'://'+_0x146780;return of['includes'](_0x3eb364)&&(await _0x5bfc6d['_persistenceManagerAvailable'],_0x5bfc6d['_getPersistenceType']()==='COOKIE')?_0x5bfc6d['_getPersistence']()['_getFinalTarget'](_0x2914c0)['toString']():_0x2914c0;}function cf(_0x290492){switch(_0x290492){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5a65cc){this['auth']=_0x5a65cc,this['timer']=null,this['promise']=new Promise((_0xe3a827,_0x1891bd)=>{this['timer']=setTimeout(()=>_0x1891bd(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4a5a1b,_0x16cdf2,_0x29b7d7){const _0x2f0581={'appName':_0x4a5a1b['name']};_0x29b7d7['email']&&(_0x2f0581['email']=_0x29b7d7['email']),_0x29b7d7['phoneNumber']&&(_0x2f0581['phoneNumber']=_0x29b7d7['phoneNumber']);const _0x465c7c=J(_0x4a5a1b,_0x16cdf2,_0x2f0581);return _0x465c7c['customData']['_tokenResponse']=_0x29b7d7,_0x465c7c;}function vr(_0x1e4eac){return _0x1e4eac!==void 0x0&&_0x1e4eac['enterprise']!==void 0x0;}class hf{constructor(_0x164f9a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x164f9a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x164f9a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x164f9a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x49a1e1){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1886db of this['recaptchaEnforcementState'])if(_0x1886db['provider']&&_0x1886db['provider']===_0x49a1e1)return cf(_0x1886db['enforcementState']);return null;}['isProviderEnabled'](_0x453d52){return this['getProviderEnforcementState'](_0x453d52)==='ENFORCE'||this['getProviderEnforcementState'](_0x453d52)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x3f39f0,_0x11bb8b){return Ae(_0x3f39f0,'GET','/v2/recaptchaConfig',Re(_0x3f39f0,_0x11bb8b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x26ebad,_0x532766){return Ae(_0x26ebad,'POST','/v1/accounts:delete',_0x532766);}async function Sn(_0x42bccc,_0x5346f4){return Ae(_0x42bccc,'POST','/v1/accounts:lookup',_0x5346f4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x429655){if(_0x429655)try{const _0x54d98a=new Date(Number(_0x429655));if(!isNaN(_0x54d98a['getTime']()))return _0x54d98a['toUTCString']();}catch{}}async function ff(_0x4241f8,_0x4a0409=!0x1){const _0x14fe60=k(_0x4241f8),_0x293a1e=await _0x14fe60['getIdToken'](_0x4a0409),_0x33a4ae=ws(_0x293a1e);m(_0x33a4ae&&_0x33a4ae['exp']&&_0x33a4ae['auth_time']&&_0x33a4ae['iat'],_0x14fe60['auth'],'internal-error');const _0x521e62=typeof _0x33a4ae['firebase']=='object'?_0x33a4ae['firebase']:void 0x0,_0x5eeb25=_0x521e62==null?void 0x0:_0x521e62['sign_in_provider'];return{'claims':_0x33a4ae,'token':_0x293a1e,'authTime':St(ci(_0x33a4ae['auth_time'])),'issuedAtTime':St(ci(_0x33a4ae['iat'])),'expirationTime':St(ci(_0x33a4ae['exp'])),'signInProvider':_0x5eeb25||null,'signInSecondFactor':(_0x521e62==null?void 0x0:_0x521e62['sign_in_second_factor'])||null};}function ci(_0x4a1033){return Number(_0x4a1033)*0x3e8;}function ws(_0x5490a0){const [_0x44c0f6,_0x511ce8,_0x4213c8]=_0x5490a0['split']('.');if(_0x44c0f6===void 0x0||_0x511ce8===void 0x0||_0x4213c8===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0xafb99b=cn(_0x511ce8);return _0xafb99b?JSON['parse'](_0xafb99b):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x34a27c){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x34a27c==null?void 0x0:_0x34a27c['toString']()),null;}}function Er(_0x55514a){const _0x1101f4=ws(_0x55514a);return m(_0x1101f4,'internal-error'),m(typeof _0x1101f4['exp']<'u','internal-error'),m(typeof _0x1101f4['iat']<'u','internal-error'),Number(_0x1101f4['exp'])-Number(_0x1101f4['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x2bad4e,_0x4f9b74,_0xdbd655=!0x1){if(_0xdbd655)return _0x4f9b74;try{return await _0x4f9b74;}catch(_0x430563){throw _0x430563 instanceof Se&&pf(_0x430563)&&_0x2bad4e['auth']['currentUser']===_0x2bad4e&&await _0x2bad4e['auth']['signOut'](),_0x430563;}}function pf({code:_0x2c0df4}){return _0x2c0df4==='auth/user-disabled'||_0x2c0df4==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xffb82f){this['user']=_0xffb82f,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2fa1a9){if(_0x2fa1a9){const _0x63159f=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x63159f;}else{this['errorBackoff']=0x7530;const _0x4c170f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4c170f);}}['schedule'](_0x3fcafc=!0x1){if(!this['isRunning'])return;const _0x5b775c=this['getInterval'](_0x3fcafc);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5b775c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x647350){(_0x647350==null?void 0x0:_0x647350['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x263885,_0x109fe0){this['createdAt']=_0x263885,this['lastLoginAt']=_0x109fe0,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x7cac5c){this['createdAt']=_0x7cac5c['createdAt'],this['lastLoginAt']=_0x7cac5c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x44e59a){var _0x1eba7b;const _0x505caa=_0x44e59a['auth'],_0x294ee9=await _0x44e59a['getIdToken'](),_0x1c1997=await xt(_0x44e59a,Sn(_0x505caa,{'idToken':_0x294ee9}));m(_0x1c1997==null?void 0x0:_0x1c1997['users']['length'],_0x505caa,'internal-error');const _0x3c8fd9=_0x1c1997['users'][0x0];_0x44e59a['_notifyReloadListener'](_0x3c8fd9);const _0xe2e4c3=(_0x1eba7b=_0x3c8fd9['providerUserInfo'])!=null&&_0x1eba7b['length']?wa(_0x3c8fd9['providerUserInfo']):[],_0x570d32=mf(_0x44e59a['providerData'],_0xe2e4c3),_0x1ba491=_0x44e59a['isAnonymous'],_0x5a7a0a=!(_0x44e59a['email']&&_0x3c8fd9['passwordHash'])&&!(_0x570d32!=null&&_0x570d32['length']),_0x9ba440=_0x1ba491?_0x5a7a0a:!0x1,_0x3c56db={'uid':_0x3c8fd9['localId'],'displayName':_0x3c8fd9['displayName']||null,'photoURL':_0x3c8fd9['photoUrl']||null,'email':_0x3c8fd9['email']||null,'emailVerified':_0x3c8fd9['emailVerified']||!0x1,'phoneNumber':_0x3c8fd9['phoneNumber']||null,'tenantId':_0x3c8fd9['tenantId']||null,'providerData':_0x570d32,'metadata':new Pi(_0x3c8fd9['createdAt'],_0x3c8fd9['lastLoginAt']),'isAnonymous':_0x9ba440};Object['assign'](_0x44e59a,_0x3c56db);}async function gf(_0x2cd128){const _0x189337=k(_0x2cd128);await bn(_0x189337),await _0x189337['auth']['_persistUserIfCurrent'](_0x189337),_0x189337['auth']['_notifyListenersIfCurrent'](_0x189337);}function mf(_0x4e0a9a,_0x38857b){return[..._0x4e0a9a['filter'](_0x5cb090=>!_0x38857b['some'](_0x186481=>_0x186481['providerId']===_0x5cb090['providerId'])),..._0x38857b];}function wa(_0x127ee7){return _0x127ee7['map'](({providerId:_0x2dfdf6,..._0x15d56b})=>({'providerId':_0x2dfdf6,'uid':_0x15d56b['rawId']||'','displayName':_0x15d56b['displayName']||null,'email':_0x15d56b['email']||null,'phoneNumber':_0x15d56b['phoneNumber']||null,'photoURL':_0x15d56b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0xf562d7,_0x532f4a){const _0x48b82b=await Ea(_0xf562d7,{},async()=>{const _0x12f966=at({'grant_type':'refresh_token','refresh_token':_0x532f4a})['slice'](0x1),{tokenApiHost:_0x287bd1,apiKey:_0x36ad5c}=_0xf562d7['config'],_0x21de4c=await Ia(_0xf562d7,_0x287bd1,'/v1/token','key='+_0x36ad5c),_0x4c0f27=await _0xf562d7['_getAdditionalHeaders']();_0x4c0f27['Content-Type']='application/x-www-form-urlencoded';const _0x3a0f8={'method':'POST','headers':_0x4c0f27,'body':_0x12f966};return _0xf562d7['emulatorConfig']&&Wt(_0xf562d7['emulatorConfig']['host'])&&(_0x3a0f8['credentials']='include'),va['fetch']()(_0x21de4c,_0x3a0f8);});return{'accessToken':_0x48b82b['access_token'],'expiresIn':_0x48b82b['expires_in'],'refreshToken':_0x48b82b['refresh_token']};}async function vf(_0x367a5,_0x22c4a){return Ae(_0x367a5,'POST','/v2/accounts:revokeToken',Re(_0x367a5,_0x22c4a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2a916a){m(_0x2a916a['idToken'],'internal-error'),m(typeof _0x2a916a['idToken']<'u','internal-error'),m(typeof _0x2a916a['refreshToken']<'u','internal-error');const _0x2f5b44='expiresIn'in _0x2a916a&&typeof _0x2a916a['expiresIn']<'u'?Number(_0x2a916a['expiresIn']):Er(_0x2a916a['idToken']);this['updateTokensAndExpiration'](_0x2a916a['idToken'],_0x2a916a['refreshToken'],_0x2f5b44);}['updateFromIdToken'](_0x85de87){m(_0x85de87['length']!==0x0,'internal-error');const _0x66ea74=Er(_0x85de87);this['updateTokensAndExpiration'](_0x85de87,null,_0x66ea74);}async['getToken'](_0x595bec,_0xa6c336=!0x1){return!_0xa6c336&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x595bec,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x595bec,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xdb0ebb,_0x53861d){const {accessToken:_0x2f448f,refreshToken:_0x2b4c95,expiresIn:_0x2f3cd7}=await yf(_0xdb0ebb,_0x53861d);this['updateTokensAndExpiration'](_0x2f448f,_0x2b4c95,Number(_0x2f3cd7));}['updateTokensAndExpiration'](_0x31bf5a,_0x42e3ed,_0x4e4d75){this['refreshToken']=_0x42e3ed||null,this['accessToken']=_0x31bf5a||null,this['expirationTime']=Date['now']()+_0x4e4d75*0x3e8;}static['fromJSON'](_0x33fc02,_0x7ab3be){const {refreshToken:_0xfd3ea2,accessToken:_0x1088da,expirationTime:_0x474ff6}=_0x7ab3be,_0x351d27=new Je();return _0xfd3ea2&&(m(typeof _0xfd3ea2=='string','internal-error',{'appName':_0x33fc02}),_0x351d27['refreshToken']=_0xfd3ea2),_0x1088da&&(m(typeof _0x1088da=='string','internal-error',{'appName':_0x33fc02}),_0x351d27['accessToken']=_0x1088da),_0x474ff6&&(m(typeof _0x474ff6=='number','internal-error',{'appName':_0x33fc02}),_0x351d27['expirationTime']=_0x474ff6),_0x351d27;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5edd14){this['accessToken']=_0x5edd14['accessToken'],this['refreshToken']=_0x5edd14['refreshToken'],this['expirationTime']=_0x5edd14['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5a580b,_0x2e84b5){m(typeof _0x5a580b=='string'||typeof _0x5a580b>'u','internal-error',{'appName':_0x2e84b5});}class z{constructor({uid:_0x7b01ef,auth:_0x3af02f,stsTokenManager:_0x4ad2cd,..._0x1e3197}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x7b01ef,this['auth']=_0x3af02f,this['stsTokenManager']=_0x4ad2cd,this['accessToken']=_0x4ad2cd['accessToken'],this['displayName']=_0x1e3197['displayName']||null,this['email']=_0x1e3197['email']||null,this['emailVerified']=_0x1e3197['emailVerified']||!0x1,this['phoneNumber']=_0x1e3197['phoneNumber']||null,this['photoURL']=_0x1e3197['photoURL']||null,this['isAnonymous']=_0x1e3197['isAnonymous']||!0x1,this['tenantId']=_0x1e3197['tenantId']||null,this['providerData']=_0x1e3197['providerData']?[..._0x1e3197['providerData']]:[],this['metadata']=new Pi(_0x1e3197['createdAt']||void 0x0,_0x1e3197['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2ad0d2){const _0x33a15f=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2ad0d2));return m(_0x33a15f,this['auth'],'internal-error'),this['accessToken']!==_0x33a15f&&(this['accessToken']=_0x33a15f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x33a15f;}['getIdTokenResult'](_0x33e330){return ff(this,_0x33e330);}['reload'](){return gf(this);}['_assign'](_0x8d186d){this!==_0x8d186d&&(m(this['uid']===_0x8d186d['uid'],this['auth'],'internal-error'),this['displayName']=_0x8d186d['displayName'],this['photoURL']=_0x8d186d['photoURL'],this['email']=_0x8d186d['email'],this['emailVerified']=_0x8d186d['emailVerified'],this['phoneNumber']=_0x8d186d['phoneNumber'],this['isAnonymous']=_0x8d186d['isAnonymous'],this['tenantId']=_0x8d186d['tenantId'],this['providerData']=_0x8d186d['providerData']['map'](_0x41b213=>({..._0x41b213})),this['metadata']['_copy'](_0x8d186d['metadata']),this['stsTokenManager']['_assign'](_0x8d186d['stsTokenManager']));}['_clone'](_0x4b88ed){const _0x539faf=new z({...this,'auth':_0x4b88ed,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x539faf['metadata']['_copy'](this['metadata']),_0x539faf;}['_onReload'](_0x574c77){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x574c77,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x93578c){this['reloadListener']?this['reloadListener'](_0x93578c):this['reloadUserInfo']=_0x93578c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4cbe87,_0x189d29=!0x1){let _0x5bafbb=!0x1;_0x4cbe87['idToken']&&_0x4cbe87['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4cbe87),_0x5bafbb=!0x0),_0x189d29&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5bafbb&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1287c6=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1287c6})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3829ac=>({..._0x3829ac})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x27c167,_0x2ae417){const _0x16d6ce=_0x2ae417['displayName']??void 0x0,_0x108561=_0x2ae417['email']??void 0x0,_0x56c7bc=_0x2ae417['phoneNumber']??void 0x0,_0x555674=_0x2ae417['photoURL']??void 0x0,_0x2b3e65=_0x2ae417['tenantId']??void 0x0,_0x3fb6d5=_0x2ae417['_redirectEventId']??void 0x0,_0x5d1b65=_0x2ae417['createdAt']??void 0x0,_0x1b4d92=_0x2ae417['lastLoginAt']??void 0x0,{uid:_0x28fc88,emailVerified:_0x452ba1,isAnonymous:_0x2b74c0,providerData:_0x1d2f1c,stsTokenManager:_0x1c9cef}=_0x2ae417;m(_0x28fc88&&_0x1c9cef,_0x27c167,'internal-error');const _0x1d0790=Je['fromJSON'](this['name'],_0x1c9cef);m(typeof _0x28fc88=='string',_0x27c167,'internal-error'),ce(_0x16d6ce,_0x27c167['name']),ce(_0x108561,_0x27c167['name']),m(typeof _0x452ba1=='boolean',_0x27c167,'internal-error'),m(typeof _0x2b74c0=='boolean',_0x27c167,'internal-error'),ce(_0x56c7bc,_0x27c167['name']),ce(_0x555674,_0x27c167['name']),ce(_0x2b3e65,_0x27c167['name']),ce(_0x3fb6d5,_0x27c167['name']),ce(_0x5d1b65,_0x27c167['name']),ce(_0x1b4d92,_0x27c167['name']);const _0x43da9b=new z({'uid':_0x28fc88,'auth':_0x27c167,'email':_0x108561,'emailVerified':_0x452ba1,'displayName':_0x16d6ce,'isAnonymous':_0x2b74c0,'photoURL':_0x555674,'phoneNumber':_0x56c7bc,'tenantId':_0x2b3e65,'stsTokenManager':_0x1d0790,'createdAt':_0x5d1b65,'lastLoginAt':_0x1b4d92});return _0x1d2f1c&&Array['isArray'](_0x1d2f1c)&&(_0x43da9b['providerData']=_0x1d2f1c['map'](_0x5c3a33=>({..._0x5c3a33}))),_0x3fb6d5&&(_0x43da9b['_redirectEventId']=_0x3fb6d5),_0x43da9b;}static async['_fromIdTokenResponse'](_0x5c0d4c,_0x2eb710,_0x51de88=!0x1){const _0x4f6bc4=new Je();_0x4f6bc4['updateFromServerResponse'](_0x2eb710);const _0x37af2e=new z({'uid':_0x2eb710['localId'],'auth':_0x5c0d4c,'stsTokenManager':_0x4f6bc4,'isAnonymous':_0x51de88});return await bn(_0x37af2e),_0x37af2e;}static async['_fromGetAccountInfoResponse'](_0x372a9a,_0x32a891,_0x3e5e4b){const _0x45cc89=_0x32a891['users'][0x0];m(_0x45cc89['localId']!==void 0x0,'internal-error');const _0x4ad432=_0x45cc89['providerUserInfo']!==void 0x0?wa(_0x45cc89['providerUserInfo']):[],_0x4b7558=!(_0x45cc89['email']&&_0x45cc89['passwordHash'])&&!(_0x4ad432!=null&&_0x4ad432['length']),_0x36cee3=new Je();_0x36cee3['updateFromIdToken'](_0x3e5e4b);const _0xcc3fb7=new z({'uid':_0x45cc89['localId'],'auth':_0x372a9a,'stsTokenManager':_0x36cee3,'isAnonymous':_0x4b7558}),_0x1180d8={'uid':_0x45cc89['localId'],'displayName':_0x45cc89['displayName']||null,'photoURL':_0x45cc89['photoUrl']||null,'email':_0x45cc89['email']||null,'emailVerified':_0x45cc89['emailVerified']||!0x1,'phoneNumber':_0x45cc89['phoneNumber']||null,'tenantId':_0x45cc89['tenantId']||null,'providerData':_0x4ad432,'metadata':new Pi(_0x45cc89['createdAt'],_0x45cc89['lastLoginAt']),'isAnonymous':!(_0x45cc89['email']&&_0x45cc89['passwordHash'])&&!(_0x4ad432!=null&&_0x4ad432['length'])};return Object['assign'](_0xcc3fb7,_0x1180d8),_0xcc3fb7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x286912){ae(_0x286912 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x400d77=Ir['get'](_0x286912);return _0x400d77?(ae(_0x400d77 instanceof _0x286912,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x400d77):(_0x400d77=new _0x286912(),Ir['set'](_0x286912,_0x400d77),_0x400d77);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x40f645,_0x56e2da){this['storage'][_0x40f645]=_0x56e2da;}async['_get'](_0x25dff6){const _0x1f249c=this['storage'][_0x25dff6];return _0x1f249c===void 0x0?null:_0x1f249c;}async['_remove'](_0x4cbde0){delete this['storage'][_0x4cbde0];}['_addListener'](_0x1c88c9,_0x2736d0){}['_removeListener'](_0x15647e,_0x5d4b60){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3348fe,_0x5549a2,_0x1b1d33){return'firebase:'+_0x3348fe+':'+_0x5549a2+':'+_0x1b1d33;}class Xe{constructor(_0x4be6eb,_0x46aaa5,_0x2a67fb){this['persistence']=_0x4be6eb,this['auth']=_0x46aaa5,this['userKey']=_0x2a67fb;const {config:_0x3e1d92,name:_0x268eb4}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3e1d92['apiKey'],_0x268eb4),this['fullPersistenceKey']=sn('persistence',_0x3e1d92['apiKey'],_0x268eb4),this['boundEventHandler']=_0x46aaa5['_onStorageEvent']['bind'](_0x46aaa5),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x379077){return this['persistence']['_set'](this['fullUserKey'],_0x379077['toJSON']());}async['getCurrentUser'](){const _0x221a04=await this['persistence']['_get'](this['fullUserKey']);if(!_0x221a04)return null;if(typeof _0x221a04=='string'){const _0x50fadc=await Sn(this['auth'],{'idToken':_0x221a04})['catch'](()=>{});return _0x50fadc?z['_fromGetAccountInfoResponse'](this['auth'],_0x50fadc,_0x221a04):null;}return z['_fromJSON'](this['auth'],_0x221a04);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x11b84a){if(this['persistence']===_0x11b84a)return;const _0x11ef13=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x11b84a,_0x11ef13)return this['setCurrentUser'](_0x11ef13);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x467ca6,_0x35dbd5,_0x4affb0='authUser'){if(!_0x35dbd5['length'])return new Xe(ne(wr),_0x467ca6,_0x4affb0);const _0x12e475=(await Promise['all'](_0x35dbd5['map'](async _0x7a01e4=>{if(await _0x7a01e4['_isAvailable']())return _0x7a01e4;})))['filter'](_0x4192e0=>_0x4192e0);let _0x22990e=_0x12e475[0x0]||ne(wr);const _0x2897b5=sn(_0x4affb0,_0x467ca6['config']['apiKey'],_0x467ca6['name']);let _0x4e9417=null;for(const _0x4dccc9 of _0x35dbd5)try{const _0x485e64=await _0x4dccc9['_get'](_0x2897b5);if(_0x485e64){let _0x55d557;if(typeof _0x485e64=='string'){const _0x238e65=await Sn(_0x467ca6,{'idToken':_0x485e64})['catch'](()=>{});if(!_0x238e65)break;_0x55d557=await z['_fromGetAccountInfoResponse'](_0x467ca6,_0x238e65,_0x485e64);}else _0x55d557=z['_fromJSON'](_0x467ca6,_0x485e64);_0x4dccc9!==_0x22990e&&(_0x4e9417=_0x55d557),_0x22990e=_0x4dccc9;break;}}catch{}const _0x5d1e5c=_0x12e475['filter'](_0x1b03f4=>_0x1b03f4['_shouldAllowMigration']);return!_0x22990e['_shouldAllowMigration']||!_0x5d1e5c['length']?new Xe(_0x22990e,_0x467ca6,_0x4affb0):(_0x22990e=_0x5d1e5c[0x0],_0x4e9417&&await _0x22990e['_set'](_0x2897b5,_0x4e9417['toJSON']()),await Promise['all'](_0x35dbd5['map'](async _0x5785b1=>{if(_0x5785b1!==_0x22990e)try{await _0x5785b1['_remove'](_0x2897b5);}catch{}})),new Xe(_0x22990e,_0x467ca6,_0x4affb0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x10a1fc){const _0x118d16=_0x10a1fc['toLowerCase']();if(_0x118d16['includes']('opera/')||_0x118d16['includes']('opr/')||_0x118d16['includes']('opios/'))return'Opera';if(Ra(_0x118d16))return'IEMobile';if(_0x118d16['includes']('msie')||_0x118d16['includes']('trident/'))return'IE';if(_0x118d16['includes']('edge/'))return'Edge';if(Ta(_0x118d16))return'Firefox';if(_0x118d16['includes']('silk/'))return'Silk';if(ka(_0x118d16))return'Blackberry';if(Na(_0x118d16))return'Webos';if(Sa(_0x118d16))return'Safari';if((_0x118d16['includes']('chrome/')||ba(_0x118d16))&&!_0x118d16['includes']('edge/'))return'Chrome';if(Aa(_0x118d16))return'Android';{const _0x2e329f=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x94aade=_0x10a1fc['match'](_0x2e329f);if((_0x94aade==null?void 0x0:_0x94aade['length'])===0x2)return _0x94aade[0x1];}return'Other';}function Ta(_0x1cc022=W()){return/firefox\//i['test'](_0x1cc022);}function Sa(_0x55de00=W()){const _0x341045=_0x55de00['toLowerCase']();return _0x341045['includes']('safari/')&&!_0x341045['includes']('chrome/')&&!_0x341045['includes']('crios/')&&!_0x341045['includes']('android');}function ba(_0x55cd61=W()){return/crios\//i['test'](_0x55cd61);}function Ra(_0x420e66=W()){return/iemobile/i['test'](_0x420e66);}function Aa(_0x55e4e5=W()){return/android/i['test'](_0x55e4e5);}function ka(_0x460b90=W()){return/blackberry/i['test'](_0x460b90);}function Na(_0x48c2ea=W()){return/webos/i['test'](_0x48c2ea);}function Cs(_0x4db7a1=W()){return/iphone|ipad|ipod/i['test'](_0x4db7a1)||/macintosh/i['test'](_0x4db7a1)&&/mobile/i['test'](_0x4db7a1);}function Ef(_0x26e8c4=W()){var _0x1edb04;return Cs(_0x26e8c4)&&!!((_0x1edb04=window['navigator'])!=null&&_0x1edb04['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2a35c9=W()){return Cs(_0x2a35c9)||Aa(_0x2a35c9)||Na(_0x2a35c9)||ka(_0x2a35c9)||/windows phone/i['test'](_0x2a35c9)||Ra(_0x2a35c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x815c8c,_0x3cd6f0=[]){let _0x632d75;switch(_0x815c8c){case'Browser':_0x632d75=Cr(W());break;case'Worker':_0x632d75=Cr(W())+'-'+_0x815c8c;break;default:_0x632d75=_0x815c8c;}const _0x55a235=_0x3cd6f0['length']?_0x3cd6f0['join'](','):'FirebaseCore-web';return _0x632d75+'/JsCore/'+ct+'/'+_0x55a235;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x19027f){this['auth']=_0x19027f,this['queue']=[];}['pushCallback'](_0x285aac,_0x2ea5d1){const _0x533055=_0x156c3d=>new Promise((_0x4808da,_0x2ee636)=>{try{const _0x251c07=_0x285aac(_0x156c3d);_0x4808da(_0x251c07);}catch(_0x38a844){_0x2ee636(_0x38a844);}});_0x533055['onAbort']=_0x2ea5d1,this['queue']['push'](_0x533055);const _0xe912c0=this['queue']['length']-0x1;return()=>{this['queue'][_0xe912c0]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1934e7){if(this['auth']['currentUser']===_0x1934e7)return;const _0x8ce56c=[];try{for(const _0x3ed541 of this['queue'])await _0x3ed541(_0x1934e7),_0x3ed541['onAbort']&&_0x8ce56c['push'](_0x3ed541['onAbort']);}catch(_0xa7fe27){_0x8ce56c['reverse']();for(const _0xecb862 of _0x8ce56c)try{_0xecb862();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xa7fe27==null?void 0x0:_0xa7fe27['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4a3a45,_0x5781de={}){return Ae(_0x4a3a45,'GET','/v2/passwordPolicy',Re(_0x4a3a45,_0x5781de));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3dd9ca){var _0x1fceeb;const _0xd141b7=_0x3dd9ca['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xd141b7['minPasswordLength']??Tf,_0xd141b7['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xd141b7['maxPasswordLength']),_0xd141b7['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xd141b7['containsLowercaseCharacter']),_0xd141b7['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xd141b7['containsUppercaseCharacter']),_0xd141b7['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xd141b7['containsNumericCharacter']),_0xd141b7['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xd141b7['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3dd9ca['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1fceeb=_0x3dd9ca['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1fceeb['join'](''))??'',this['forceUpgradeOnSignin']=_0x3dd9ca['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3dd9ca['schemaVersion'];}['validatePassword'](_0x59e356){const _0x55b53b={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x59e356,_0x55b53b),this['validatePasswordCharacterOptions'](_0x59e356,_0x55b53b),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['meetsMinPasswordLength']??!0x0),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['meetsMaxPasswordLength']??!0x0),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['containsLowercaseLetter']??!0x0),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['containsUppercaseLetter']??!0x0),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['containsNumericCharacter']??!0x0),_0x55b53b['isValid']&&(_0x55b53b['isValid']=_0x55b53b['containsNonAlphanumericCharacter']??!0x0),_0x55b53b;}['validatePasswordLengthOptions'](_0x21a2d9,_0x42575c){const _0x3de18f=this['customStrengthOptions']['minPasswordLength'],_0x45044c=this['customStrengthOptions']['maxPasswordLength'];_0x3de18f&&(_0x42575c['meetsMinPasswordLength']=_0x21a2d9['length']>=_0x3de18f),_0x45044c&&(_0x42575c['meetsMaxPasswordLength']=_0x21a2d9['length']<=_0x45044c);}['validatePasswordCharacterOptions'](_0x414536,_0x2792ed){this['updatePasswordCharacterOptionsStatuses'](_0x2792ed,!0x1,!0x1,!0x1,!0x1);let _0x312bef;for(let _0x4692bf=0x0;_0x4692bf<_0x414536['length'];_0x4692bf++)_0x312bef=_0x414536['charAt'](_0x4692bf),this['updatePasswordCharacterOptionsStatuses'](_0x2792ed,_0x312bef>='a'&&_0x312bef<='z',_0x312bef>='A'&&_0x312bef<='Z',_0x312bef>='0'&&_0x312bef<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x312bef));}['updatePasswordCharacterOptionsStatuses'](_0x29fe03,_0x12612b,_0x992fa4,_0x413ccd,_0x57ef72){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x29fe03['containsLowercaseLetter']||(_0x29fe03['containsLowercaseLetter']=_0x12612b)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x29fe03['containsUppercaseLetter']||(_0x29fe03['containsUppercaseLetter']=_0x992fa4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x29fe03['containsNumericCharacter']||(_0x29fe03['containsNumericCharacter']=_0x413ccd)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x29fe03['containsNonAlphanumericCharacter']||(_0x29fe03['containsNonAlphanumericCharacter']=_0x57ef72));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x5c4c84,_0x5d9cde,_0x31c92b,_0x3a8322){this['app']=_0x5c4c84,this['heartbeatServiceProvider']=_0x5d9cde,this['appCheckServiceProvider']=_0x31c92b,this['config']=_0x3a8322,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5c4c84['name'],this['clientVersion']=_0x3a8322['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3a5556=>this['_resolvePersistenceManagerAvailable']=_0x3a5556);}['_initializeWithPersistence'](_0x4fd15c,_0x3f6bec){return _0x3f6bec&&(this['_popupRedirectResolver']=ne(_0x3f6bec)),this['_initializationPromise']=this['queue'](async()=>{var _0x194b37,_0x7cdf1c,_0x3204a9;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x4fd15c),(_0x194b37=this['_resolvePersistenceManagerAvailable'])==null||_0x194b37['call'](this),!this['_deleted'])){if((_0x7cdf1c=this['_popupRedirectResolver'])!=null&&_0x7cdf1c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3f6bec),this['lastNotifiedUid']=((_0x3204a9=this['currentUser'])==null?void 0x0:_0x3204a9['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xead0b2=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xead0b2)){if(this['currentUser']&&_0xead0b2&&this['currentUser']['uid']===_0xead0b2['uid']){this['_currentUser']['_assign'](_0xead0b2),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xead0b2,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1a7bb1){try{const _0x59552b=await Sn(this,{'idToken':_0x1a7bb1}),_0x3f5507=await z['_fromGetAccountInfoResponse'](this,_0x59552b,_0x1a7bb1);await this['directlySetCurrentUser'](_0x3f5507);}catch(_0x391572){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x391572),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x30ad19){var _0x3b2007;if(H(this['app'])){const _0x1a6605=this['app']['settings']['authIdToken'];return _0x1a6605?new Promise(_0xc0e2e6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1a6605)['then'](_0xc0e2e6,_0xc0e2e6));}):this['directlySetCurrentUser'](null);}const _0xedcaf6=await this['assertedPersistence']['getCurrentUser']();let _0x179397=_0xedcaf6,_0x46f7dc=!0x1;if(_0x30ad19&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1f465b=(_0x3b2007=this['redirectUser'])==null?void 0x0:_0x3b2007['_redirectEventId'],_0x56c934=_0x179397==null?void 0x0:_0x179397['_redirectEventId'],_0x4f2924=await this['tryRedirectSignIn'](_0x30ad19);(!_0x1f465b||_0x1f465b===_0x56c934)&&(_0x4f2924!=null&&_0x4f2924['user'])&&(_0x179397=_0x4f2924['user'],_0x46f7dc=!0x0);}if(!_0x179397)return this['directlySetCurrentUser'](null);if(!_0x179397['_redirectEventId']){if(_0x46f7dc)try{await this['beforeStateQueue']['runMiddleware'](_0x179397);}catch(_0x3ebe5d){_0x179397=_0xedcaf6,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3ebe5d));}return _0x179397?this['reloadAndSetCurrentUserOrClear'](_0x179397):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x179397['_redirectEventId']?this['directlySetCurrentUser'](_0x179397):this['reloadAndSetCurrentUserOrClear'](_0x179397);}async['tryRedirectSignIn'](_0x4b8c17){let _0x37fab1=null;try{_0x37fab1=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4b8c17,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x37fab1;}async['reloadAndSetCurrentUserOrClear'](_0x84f085){try{await bn(_0x84f085);}catch(_0x4cc954){if((_0x4cc954==null?void 0x0:_0x4cc954['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x84f085);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x25a756){if(H(this['app']))return Promise['reject'](se(this));const _0x1cc0ea=_0x25a756?k(_0x25a756):null;return _0x1cc0ea&&m(_0x1cc0ea['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x1cc0ea&&_0x1cc0ea['_clone'](this));}async['_updateCurrentUser'](_0x5aad05,_0x5800b3=!0x1){if(!this['_deleted'])return _0x5aad05&&m(this['tenantId']===_0x5aad05['tenantId'],this,'tenant-id-mismatch'),_0x5800b3||await this['beforeStateQueue']['runMiddleware'](_0x5aad05),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x5aad05),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2b9297){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x2b9297));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2fd92f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2acc3c=this['_getPasswordPolicyInternal']();return _0x2acc3c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2acc3c['validatePassword'](_0x2fd92f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x42902e=await Cf(this),_0x47b09c=new Sf(_0x42902e);this['tenantId']===null?this['_projectPasswordPolicy']=_0x47b09c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x47b09c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3d5638){this['_errorFactory']=new Ut('auth','Firebase',_0x3d5638());}['onAuthStateChanged'](_0x4fb742,_0x243ab1,_0x1affaf){return this['registerStateListener'](this['authStateSubscription'],_0x4fb742,_0x243ab1,_0x1affaf);}['beforeAuthStateChanged'](_0x3c87a9,_0x312b64){return this['beforeStateQueue']['pushCallback'](_0x3c87a9,_0x312b64);}['onIdTokenChanged'](_0x380074,_0x468f31,_0x5f338e){return this['registerStateListener'](this['idTokenSubscription'],_0x380074,_0x468f31,_0x5f338e);}['authStateReady'](){return new Promise((_0x3dd427,_0x2ee0aa)=>{if(this['currentUser'])_0x3dd427();else{const _0x5e82ee=this['onAuthStateChanged'](()=>{_0x5e82ee(),_0x3dd427();},_0x2ee0aa);}});}async['revokeAccessToken'](_0x407269){if(this['currentUser']){const _0x2d0a06=await this['currentUser']['getIdToken'](),_0x2481ab={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x407269,'idToken':_0x2d0a06};this['tenantId']!=null&&(_0x2481ab['tenantId']=this['tenantId']),await vf(this,_0x2481ab);}}['toJSON'](){var _0x55debb;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x55debb=this['_currentUser'])==null?void 0x0:_0x55debb['toJSON']()};}async['_setRedirectUser'](_0x45f9f3,_0x3d726e){const _0x1dc055=await this['getOrInitRedirectPersistenceManager'](_0x3d726e);return _0x45f9f3===null?_0x1dc055['removeCurrentUser']():_0x1dc055['setCurrentUser'](_0x45f9f3);}async['getOrInitRedirectPersistenceManager'](_0x588211){if(!this['redirectPersistenceManager']){const _0x6e19b6=_0x588211&&ne(_0x588211)||this['_popupRedirectResolver'];m(_0x6e19b6,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x6e19b6['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x564c2b){var _0xd37a42,_0x3ab5bc;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xd37a42=this['_currentUser'])==null?void 0x0:_0xd37a42['_redirectEventId'])===_0x564c2b?this['_currentUser']:((_0x3ab5bc=this['redirectUser'])==null?void 0x0:_0x3ab5bc['_redirectEventId'])===_0x564c2b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x34cf4b){if(_0x34cf4b===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x34cf4b));}['_notifyListenersIfCurrent'](_0x5af2ef){_0x5af2ef===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x4ab9ba;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x56b085=((_0x4ab9ba=this['currentUser'])==null?void 0x0:_0x4ab9ba['uid'])??null;this['lastNotifiedUid']!==_0x56b085&&(this['lastNotifiedUid']=_0x56b085,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xa18675,_0x534314,_0x8a9640,_0x235af8){if(this['_deleted'])return()=>{};const _0x367e12=typeof _0x534314=='function'?_0x534314:_0x534314['next']['bind'](_0x534314);let _0x587744=!0x1;const _0x58911=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x58911,this,'internal-error'),_0x58911['then'](()=>{_0x587744||_0x367e12(this['currentUser']);}),typeof _0x534314=='function'){const _0x481a59=_0xa18675['addObserver'](_0x534314,_0x8a9640,_0x235af8);return()=>{_0x587744=!0x0,_0x481a59();};}else{const _0x296017=_0xa18675['addObserver'](_0x534314);return()=>{_0x587744=!0x0,_0x296017();};}}async['directlySetCurrentUser'](_0x86277d){this['currentUser']&&this['currentUser']!==_0x86277d&&this['_currentUser']['_stopProactiveRefresh'](),_0x86277d&&this['isProactiveRefreshEnabled']&&_0x86277d['_startProactiveRefresh'](),this['currentUser']=_0x86277d,_0x86277d?await this['assertedPersistence']['setCurrentUser'](_0x86277d):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x338702){return this['operations']=this['operations']['then'](_0x338702,_0x338702),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x35e5da){!_0x35e5da||this['frameworks']['includes'](_0x35e5da)||(this['frameworks']['push'](_0x35e5da),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x50fa25;const _0x67a1ef={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x67a1ef['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xa33d52=await((_0x50fa25=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x50fa25['getHeartbeatsHeader']());_0xa33d52&&(_0x67a1ef['X-Firebase-Client']=_0xa33d52);const _0x177292=await this['_getAppCheckToken']();return _0x177292&&(_0x67a1ef['X-Firebase-AppCheck']=_0x177292),_0x67a1ef;}async['_getAppCheckToken'](){var _0x168f31;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5b53f0=await((_0x168f31=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x168f31['getToken']());return _0x5b53f0!=null&&_0x5b53f0['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5b53f0['error']),_0x5b53f0==null?void 0x0:_0x5b53f0['token'];}}function qe(_0x4d1c7a){return k(_0x4d1c7a);}class Tr{constructor(_0x2307fe){this['auth']=_0x2307fe,this['observer']=null,this['addObserver']=Ic(_0x210a92=>this['observer']=_0x210a92);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x151428){zn=_0x151428;}function Da(_0x24ae22){return zn['loadJS'](_0x24ae22);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x127277){return'__'+_0x127277+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x26e725){_0x26e725();}['execute'](_0x36f3c6,_0x2e52da){return Promise['resolve']('token');}['render'](_0x6746f6,_0x3e7d35){return'';}}class Of{['ready'](_0x35f4ef){_0x35f4ef();}['execute'](_0x13906b,_0x5eb504){return Promise['resolve']('token');}['render'](_0x1abc48,_0x5f51e0){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2f778b){this['type']=Df,this['auth']=qe(_0x2f778b);}async['verify'](_0x26f608='verify',_0xa20c57=!0x1){async function _0x2f9abb(_0x39ccc6){if(!_0xa20c57){if(_0x39ccc6['tenantId']==null&&_0x39ccc6['_agentRecaptchaConfig']!=null)return _0x39ccc6['_agentRecaptchaConfig']['siteKey'];if(_0x39ccc6['tenantId']!=null&&_0x39ccc6['_tenantRecaptchaConfigs'][_0x39ccc6['tenantId']]!==void 0x0)return _0x39ccc6['_tenantRecaptchaConfigs'][_0x39ccc6['tenantId']]['siteKey'];}return new Promise(async(_0x27faf4,_0x2f7fa2)=>{uf(_0x39ccc6,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x5f246c=>{if(_0x5f246c['recaptchaKey']===void 0x0)_0x2f7fa2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2c19a3=new hf(_0x5f246c);return _0x39ccc6['tenantId']==null?_0x39ccc6['_agentRecaptchaConfig']=_0x2c19a3:_0x39ccc6['_tenantRecaptchaConfigs'][_0x39ccc6['tenantId']]=_0x2c19a3,_0x27faf4(_0x2c19a3['siteKey']);}})['catch'](_0x5b0d94=>{_0x2f7fa2(_0x5b0d94);});});}function _0x3070e7(_0x3e45d9,_0x29c17a,_0x338749){const _0x12fc0b=window['grecaptcha'];vr(_0x12fc0b)?_0x12fc0b['enterprise']['ready'](()=>{_0x12fc0b['enterprise']['execute'](_0x3e45d9,{'action':_0x26f608})['then'](_0x522cfa=>{_0x29c17a(_0x522cfa);})['catch'](()=>{_0x29c17a(Ma);});}):_0x338749(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x212d54,_0x477f6c)=>{_0x2f9abb(this['auth'])['then'](async _0x585633=>{if(!_0xa20c57&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3070e7(_0x585633,_0x212d54,_0x477f6c);else{if(typeof window>'u'){_0x477f6c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x424715=Af();_0x424715['length']!==0x0&&(_0x424715+=_0x585633+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x52cee3;(_0x52cee3=le['scriptInjectionDeferred'])==null||_0x52cee3['resolve']();},Da(_0x424715)['then'](()=>{var _0x3fc874;return(_0x3fc874=le['scriptInjectionDeferred'])==null?void 0x0:_0x3fc874['promise'];})['then'](()=>{_0x3070e7(_0x585633,_0x212d54,_0x477f6c);})['catch'](_0x7274b1=>{_0x477f6c(_0x7274b1);});}})['catch'](_0x4649e0=>{_0x477f6c(_0x4649e0);});});}}le['scriptInjectionDeferred']=null;async function br(_0x5328d3,_0x554bd5,_0x2cabc3,_0x1a6ca7=!0x1,_0x213942=!0x1){const _0x1480e6=new le(_0x5328d3);let _0x257399;if(_0x213942)_0x257399=Ma;else try{_0x257399=await _0x1480e6['verify'](_0x2cabc3);}catch{_0x257399=await _0x1480e6['verify'](_0x2cabc3,!0x0);}const _0x52bbf3={..._0x554bd5};if(_0x2cabc3==='mfaSmsEnrollment'||_0x2cabc3==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x52bbf3){const _0x788c04=_0x52bbf3['phoneEnrollmentInfo']['phoneNumber'],_0x498712=_0x52bbf3['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x52bbf3,{'phoneEnrollmentInfo':{'phoneNumber':_0x788c04,'recaptchaToken':_0x498712,'captchaResponse':_0x257399,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x52bbf3){const _0x319b9d=_0x52bbf3['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x52bbf3,{'phoneSignInInfo':{'recaptchaToken':_0x319b9d,'captchaResponse':_0x257399,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x52bbf3;}return _0x1a6ca7?Object['assign'](_0x52bbf3,{'captchaResp':_0x257399}):Object['assign'](_0x52bbf3,{'captchaResponse':_0x257399}),Object['assign'](_0x52bbf3,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x52bbf3,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x52bbf3;}async function Oi(_0x4e2de9,_0x23b226,_0x4071ae,_0x3b95c7,_0x25107f){var _0x186393;if((_0x186393=_0x4e2de9['_getRecaptchaConfig']())!=null&&_0x186393['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x13d2a8=await br(_0x4e2de9,_0x23b226,_0x4071ae,_0x4071ae==='getOobCode');return _0x3b95c7(_0x4e2de9,_0x13d2a8);}else return _0x3b95c7(_0x4e2de9,_0x23b226)['catch'](async _0x79b45b=>{if(_0x79b45b['code']==='auth/missing-recaptcha-token'){console['log'](_0x4071ae+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x59daeb=await br(_0x4e2de9,_0x23b226,_0x4071ae,_0x4071ae==='getOobCode');return _0x3b95c7(_0x4e2de9,_0x59daeb);}else return Promise['reject'](_0x79b45b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x41ee60,_0x2ef644){const _0x27cf1e=Ui(_0x41ee60,'auth');if(_0x27cf1e['isInitialized']()){const _0x4508e4=_0x27cf1e['getImmediate'](),_0x26879f=_0x27cf1e['getOptions']();if(De(_0x26879f,_0x2ef644??{}))return _0x4508e4;K(_0x4508e4,'already-initialized');}return _0x27cf1e['initialize']({'options':_0x2ef644});}function Lf(_0x28add9,_0x4287a2){const _0x532d00=(_0x4287a2==null?void 0x0:_0x4287a2['persistence'])||[],_0x1dac4f=(Array['isArray'](_0x532d00)?_0x532d00:[_0x532d00])['map'](ne);_0x4287a2!=null&&_0x4287a2['errorMap']&&_0x28add9['_updateErrorMap'](_0x4287a2['errorMap']),_0x28add9['_initializeWithPersistence'](_0x1dac4f,_0x4287a2==null?void 0x0:_0x4287a2['popupRedirectResolver']);}function xf(_0x117f33,_0x4f0634,_0x5e4da2){const _0x256e59=qe(_0x117f33);m(/^https?:\/\//['test'](_0x4f0634),_0x256e59,'invalid-emulator-scheme');const _0x40ab96=!0x1,_0x4d3b1d=La(_0x4f0634),{host:_0x580343,port:_0x1f22c0}=Ff(_0x4f0634),_0x1698a2=_0x1f22c0===null?'':':'+_0x1f22c0,_0x1a3642={'url':_0x4d3b1d+'//'+_0x580343+_0x1698a2+'/'},_0x4651c2=Object['freeze']({'host':_0x580343,'port':_0x1f22c0,'protocol':_0x4d3b1d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x40ab96})});if(!_0x256e59['_canInitEmulator']){m(_0x256e59['config']['emulator']&&_0x256e59['emulatorConfig'],_0x256e59,'emulator-config-failed'),m(De(_0x1a3642,_0x256e59['config']['emulator'])&&De(_0x4651c2,_0x256e59['emulatorConfig']),_0x256e59,'emulator-config-failed');return;}_0x256e59['config']['emulator']=_0x1a3642,_0x256e59['emulatorConfig']=_0x4651c2,_0x256e59['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x580343)?jr(_0x4d3b1d+'//'+_0x580343+_0x1698a2):Uf();}function La(_0x3303cd){const _0x3360d2=_0x3303cd['indexOf'](':');return _0x3360d2<0x0?'':_0x3303cd['substr'](0x0,_0x3360d2+0x1);}function Ff(_0x16f1f9){const _0xe94947=La(_0x16f1f9),_0x302cd5=/(\/\/)?([^?#/]+)/['exec'](_0x16f1f9['substr'](_0xe94947['length']));if(!_0x302cd5)return{'host':'','port':null};const _0xa0eba1=_0x302cd5[0x2]['split']('@')['pop']()||'',_0x45c09d=/^(\[[^\]]+\])(:|$)/['exec'](_0xa0eba1);if(_0x45c09d){const _0x194eb7=_0x45c09d[0x1];return{'host':_0x194eb7,'port':Rr(_0xa0eba1['substr'](_0x194eb7['length']+0x1))};}else{const [_0x27d85b,_0x2d778f]=_0xa0eba1['split'](':');return{'host':_0x27d85b,'port':Rr(_0x2d778f)};}}function Rr(_0x42f391){if(!_0x42f391)return null;const _0x45cccd=Number(_0x42f391);return isNaN(_0x45cccd)?null:_0x45cccd;}function Uf(){function _0x8eaef7(){const _0x43713c=document['createElement']('p'),_0xd11318=_0x43713c['style'];_0x43713c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xd11318['position']='fixed',_0xd11318['width']='100%',_0xd11318['backgroundColor']='#ffffff',_0xd11318['border']='.1em\x20solid\x20#000000',_0xd11318['color']='#b50000',_0xd11318['bottom']='0px',_0xd11318['left']='0px',_0xd11318['margin']='0px',_0xd11318['zIndex']='10000',_0xd11318['textAlign']='center',_0x43713c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x43713c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x8eaef7):_0x8eaef7());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1680ea,_0xa26853){this['providerId']=_0x1680ea,this['signInMethod']=_0xa26853;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x36fb3e){return te('not\x20implemented');}['_linkToIdToken'](_0x102652,_0x33f101){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x223f11){return te('not\x20implemented');}}async function Wf(_0x26e437,_0xdaa302){return Ae(_0x26e437,'POST','/v1/accounts:signUp',_0xdaa302);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x24905f,_0x5db187){return Yt(_0x24905f,'POST','/v1/accounts:signInWithPassword',Re(_0x24905f,_0x5db187));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x63fd43,_0x3df3c4){return Yt(_0x63fd43,'POST','/v1/accounts:signInWithEmailLink',Re(_0x63fd43,_0x3df3c4));}async function Hf(_0x2f9bc8,_0x388ddc){return Yt(_0x2f9bc8,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2f9bc8,_0x388ddc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x526429,_0x4ad47d,_0xed4aa0,_0x47acbd=null){super('password',_0xed4aa0),this['_email']=_0x526429,this['_password']=_0x4ad47d,this['_tenantId']=_0x47acbd;}static['_fromEmailAndPassword'](_0x3ad693,_0x3c230a){return new Ft(_0x3ad693,_0x3c230a,'password');}static['_fromEmailAndCode'](_0x29f04f,_0x45f9d8,_0x52b5bf=null){return new Ft(_0x29f04f,_0x45f9d8,'emailLink',_0x52b5bf);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x336dc2){const _0x1938ea=typeof _0x336dc2=='string'?JSON['parse'](_0x336dc2):_0x336dc2;if(_0x1938ea!=null&&_0x1938ea['email']&&(_0x1938ea!=null&&_0x1938ea['password'])){if(_0x1938ea['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1938ea['email'],_0x1938ea['password']);if(_0x1938ea['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1938ea['email'],_0x1938ea['password'],_0x1938ea['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3e9b3b){switch(this['signInMethod']){case'password':const _0x149c3a={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3e9b3b,_0x149c3a,'signInWithPassword',Bf);case'emailLink':return Vf(_0x3e9b3b,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x3e9b3b,'internal-error');}}async['_linkToIdToken'](_0xd3080,_0x4a11a5){switch(this['signInMethod']){case'password':const _0x360284={'idToken':_0x4a11a5,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0xd3080,_0x360284,'signUpPassword',Wf);case'emailLink':return Hf(_0xd3080,{'idToken':_0x4a11a5,'email':this['_email'],'oobCode':this['_password']});default:K(_0xd3080,'internal-error');}}['_getReauthenticationResolver'](_0x261644){return this['_getIdTokenResponse'](_0x261644);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x1df148,_0xfd941a){return Yt(_0x1df148,'POST','/v1/accounts:signInWithIdp',Re(_0x1df148,_0xfd941a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x47a9bc){const _0x1ea327=new We(_0x47a9bc['providerId'],_0x47a9bc['signInMethod']);return _0x47a9bc['idToken']||_0x47a9bc['accessToken']?(_0x47a9bc['idToken']&&(_0x1ea327['idToken']=_0x47a9bc['idToken']),_0x47a9bc['accessToken']&&(_0x1ea327['accessToken']=_0x47a9bc['accessToken']),_0x47a9bc['nonce']&&!_0x47a9bc['pendingToken']&&(_0x1ea327['nonce']=_0x47a9bc['nonce']),_0x47a9bc['pendingToken']&&(_0x1ea327['pendingToken']=_0x47a9bc['pendingToken'])):_0x47a9bc['oauthToken']&&_0x47a9bc['oauthTokenSecret']?(_0x1ea327['accessToken']=_0x47a9bc['oauthToken'],_0x1ea327['secret']=_0x47a9bc['oauthTokenSecret']):K('argument-error'),_0x1ea327;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xac24ca){const _0x2dbd7e=typeof _0xac24ca=='string'?JSON['parse'](_0xac24ca):_0xac24ca,{providerId:_0x2e655d,signInMethod:_0x184c72,..._0x28f080}=_0x2dbd7e;if(!_0x2e655d||!_0x184c72)return null;const _0x6a70ce=new We(_0x2e655d,_0x184c72);return _0x6a70ce['idToken']=_0x28f080['idToken']||void 0x0,_0x6a70ce['accessToken']=_0x28f080['accessToken']||void 0x0,_0x6a70ce['secret']=_0x28f080['secret'],_0x6a70ce['nonce']=_0x28f080['nonce'],_0x6a70ce['pendingToken']=_0x28f080['pendingToken']||null,_0x6a70ce;}['_getIdTokenResponse'](_0x5731e4){const _0x272758=this['buildRequest']();return Ze(_0x5731e4,_0x272758);}['_linkToIdToken'](_0x4f5980,_0x263b80){const _0x6c5087=this['buildRequest']();return _0x6c5087['idToken']=_0x263b80,Ze(_0x4f5980,_0x6c5087);}['_getReauthenticationResolver'](_0x37620f){const _0x263654=this['buildRequest']();return _0x263654['autoCreate']=!0x1,Ze(_0x37620f,_0x263654);}['buildRequest'](){const _0x3b2c5c={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3b2c5c['pendingToken']=this['pendingToken'];else{const _0x8dac3d={};this['idToken']&&(_0x8dac3d['id_token']=this['idToken']),this['accessToken']&&(_0x8dac3d['access_token']=this['accessToken']),this['secret']&&(_0x8dac3d['oauth_token_secret']=this['secret']),_0x8dac3d['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x8dac3d['nonce']=this['nonce']),_0x3b2c5c['postBody']=at(_0x8dac3d);}return _0x3b2c5c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x46f445){switch(_0x46f445){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x3df89e){const _0x659a10=yt(vt(_0x3df89e))['link'],_0x338642=_0x659a10?yt(vt(_0x659a10))['deep_link_id']:null,_0x147b90=yt(vt(_0x3df89e))['deep_link_id'];return(_0x147b90?yt(vt(_0x147b90))['link']:null)||_0x147b90||_0x338642||_0x659a10||_0x3df89e;}class Ss{constructor(_0x4b105c){const _0x3ed1ca=yt(vt(_0x4b105c)),_0x2a6d5e=_0x3ed1ca['apiKey']??null,_0x49b9a9=_0x3ed1ca['oobCode']??null,_0x565905=Gf(_0x3ed1ca['mode']??null);m(_0x2a6d5e&&_0x49b9a9&&_0x565905,'argument-error'),this['apiKey']=_0x2a6d5e,this['operation']=_0x565905,this['code']=_0x49b9a9,this['continueUrl']=_0x3ed1ca['continueUrl']??null,this['languageCode']=_0x3ed1ca['lang']??null,this['tenantId']=_0x3ed1ca['tenantId']??null;}static['parseLink'](_0x199281){const _0x3958b9=qf(_0x199281);try{return new Ss(_0x3958b9);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x24629d,_0x20e35a){return Ft['_fromEmailAndPassword'](_0x24629d,_0x20e35a);}static['credentialWithLink'](_0x2b8f3d,_0x536d43){const _0x5ab068=Ss['parseLink'](_0x536d43);return m(_0x5ab068,'argument-error'),Ft['_fromEmailAndCode'](_0x2b8f3d,_0x5ab068['code'],_0x5ab068['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3d4af4){this['providerId']=_0x3d4af4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3687bc){this['defaultLanguageCode']=_0x3687bc;}['setCustomParameters'](_0x4fd880){return this['customParameters']=_0x4fd880,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x17efc0){return this['scopes']['includes'](_0x17efc0)||this['scopes']['push'](_0x17efc0),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x375d6a){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x375d6a});}static['credentialFromResult'](_0x536d90){return he['credentialFromTaggedObject'](_0x536d90);}static['credentialFromError'](_0x438c4f){return he['credentialFromTaggedObject'](_0x438c4f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x457f06}){if(!_0x457f06||!('oauthAccessToken'in _0x457f06)||!_0x457f06['oauthAccessToken'])return null;try{return he['credential'](_0x457f06['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x7f6560,_0x330c92){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x7f6560,'accessToken':_0x330c92});}static['credentialFromResult'](_0x38af3e){return ue['credentialFromTaggedObject'](_0x38af3e);}static['credentialFromError'](_0x1149df){return ue['credentialFromTaggedObject'](_0x1149df['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x12ead5}){if(!_0x12ead5)return null;const {oauthIdToken:_0x5c85c0,oauthAccessToken:_0x32c94f}=_0x12ead5;if(!_0x5c85c0&&!_0x32c94f)return null;try{return ue['credential'](_0x5c85c0,_0x32c94f);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3fcc9e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3fcc9e});}static['credentialFromResult'](_0xab4246){return de['credentialFromTaggedObject'](_0xab4246);}static['credentialFromError'](_0x5adf83){return de['credentialFromTaggedObject'](_0x5adf83['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1f6c29}){if(!_0x1f6c29||!('oauthAccessToken'in _0x1f6c29)||!_0x1f6c29['oauthAccessToken'])return null;try{return de['credential'](_0x1f6c29['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x33f162,_0x364fc9){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x33f162,'oauthTokenSecret':_0x364fc9});}static['credentialFromResult'](_0x10724e){return fe['credentialFromTaggedObject'](_0x10724e);}static['credentialFromError'](_0x48371b){return fe['credentialFromTaggedObject'](_0x48371b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x39c8e5}){if(!_0x39c8e5)return null;const {oauthAccessToken:_0x2e30ae,oauthTokenSecret:_0xdbdf99}=_0x39c8e5;if(!_0x2e30ae||!_0xdbdf99)return null;try{return fe['credential'](_0x2e30ae,_0xdbdf99);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4d981b,_0x14bd5c){return Yt(_0x4d981b,'POST','/v1/accounts:signUp',Re(_0x4d981b,_0x14bd5c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4cb7b3){this['user']=_0x4cb7b3['user'],this['providerId']=_0x4cb7b3['providerId'],this['_tokenResponse']=_0x4cb7b3['_tokenResponse'],this['operationType']=_0x4cb7b3['operationType'];}static async['_fromIdTokenResponse'](_0xd1bec4,_0xc9c65d,_0x39f6a7,_0xe9d080=!0x1){const _0x471f7d=await z['_fromIdTokenResponse'](_0xd1bec4,_0x39f6a7,_0xe9d080),_0x5309b6=Ar(_0x39f6a7);return new Be({'user':_0x471f7d,'providerId':_0x5309b6,'_tokenResponse':_0x39f6a7,'operationType':_0xc9c65d});}static async['_forOperation'](_0xc71169,_0x58134c,_0x5606ab){await _0xc71169['_updateTokensIfNecessary'](_0x5606ab,!0x0);const _0x4bf8aa=Ar(_0x5606ab);return new Be({'user':_0xc71169,'providerId':_0x4bf8aa,'_tokenResponse':_0x5606ab,'operationType':_0x58134c});}}function Ar(_0x31e0b2){return _0x31e0b2['providerId']?_0x31e0b2['providerId']:'phoneNumber'in _0x31e0b2?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xac8f7d,_0x1c8937,_0xa19050,_0x7c48e4){super(_0x1c8937['code'],_0x1c8937['message']),this['operationType']=_0xa19050,this['user']=_0x7c48e4,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xac8f7d['name'],'tenantId':_0xac8f7d['tenantId']??void 0x0,'_serverResponse':_0x1c8937['customData']['_serverResponse'],'operationType':_0xa19050};}static['_fromErrorAndOperation'](_0x31b189,_0x14e81a,_0x1f2b8b,_0x146975){return new Rn(_0x31b189,_0x14e81a,_0x1f2b8b,_0x146975);}}function Fa(_0x58afb0,_0x3a4b88,_0x43daec,_0x5a476d){return(_0x3a4b88==='reauthenticate'?_0x43daec['_getReauthenticationResolver'](_0x58afb0):_0x43daec['_getIdTokenResponse'](_0x58afb0))['catch'](_0xf2885=>{throw _0xf2885['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x58afb0,_0xf2885,_0x3a4b88,_0x5a476d):_0xf2885;});}async function jf(_0x4007c3,_0x47b384,_0x573dca=!0x1){const _0x28e7c3=await xt(_0x4007c3,_0x47b384['_linkToIdToken'](_0x4007c3['auth'],await _0x4007c3['getIdToken']()),_0x573dca);return Be['_forOperation'](_0x4007c3,'link',_0x28e7c3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1d9069,_0x49e107,_0x2c06b6=!0x1){const {auth:_0x15e3e6}=_0x1d9069;if(H(_0x15e3e6['app']))return Promise['reject'](se(_0x15e3e6));const _0x5b40bc='reauthenticate';try{const _0x25004b=await xt(_0x1d9069,Fa(_0x15e3e6,_0x5b40bc,_0x49e107,_0x1d9069),_0x2c06b6);m(_0x25004b['idToken'],_0x15e3e6,'internal-error');const _0x4cc895=ws(_0x25004b['idToken']);m(_0x4cc895,_0x15e3e6,'internal-error');const {sub:_0x3c2511}=_0x4cc895;return m(_0x1d9069['uid']===_0x3c2511,_0x15e3e6,'user-mismatch'),Be['_forOperation'](_0x1d9069,_0x5b40bc,_0x25004b);}catch(_0x444212){throw(_0x444212==null?void 0x0:_0x444212['code'])==='auth/user-not-found'&&K(_0x15e3e6,'user-mismatch'),_0x444212;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x490135,_0x4c3691,_0x5eea10=!0x1){if(H(_0x490135['app']))return Promise['reject'](se(_0x490135));const _0x19cce3='signIn',_0x53fbf6=await Fa(_0x490135,_0x19cce3,_0x4c3691),_0x1f73fb=await Be['_fromIdTokenResponse'](_0x490135,_0x19cce3,_0x53fbf6);return _0x5eea10||await _0x490135['_updateCurrentUser'](_0x1f73fb['user']),_0x1f73fb;}async function Yf(_0x27f93c,_0x2a4b3f){return Ua(qe(_0x27f93c),_0x2a4b3f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0xb4a3bf){const _0x54f731=qe(_0xb4a3bf);_0x54f731['_getPasswordPolicyInternal']()&&await _0x54f731['_updatePasswordPolicy']();}async function R_(_0x22e754,_0x4dbcc5,_0x4af480){if(H(_0x22e754['app']))return Promise['reject'](se(_0x22e754));const _0x18a077=qe(_0x22e754),_0x5e7701=await Oi(_0x18a077,{'returnSecureToken':!0x0,'email':_0x4dbcc5,'password':_0x4af480,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x17c552=>{throw _0x17c552['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x22e754),_0x17c552;}),_0x1cae0e=await Be['_fromIdTokenResponse'](_0x18a077,'signIn',_0x5e7701);return await _0x18a077['_updateCurrentUser'](_0x1cae0e['user']),_0x1cae0e;}function A_(_0x590ef3,_0x2fc01d,_0x414bff){return H(_0x590ef3['app'])?Promise['reject'](se(_0x590ef3)):Yf(k(_0x590ef3),ft['credential'](_0x2fc01d,_0x414bff))['catch'](async _0x1768f4=>{throw _0x1768f4['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x590ef3),_0x1768f4;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5f5c01,_0x4f1abd){return k(_0x5f5c01)['setPersistence'](_0x4f1abd);}function Qf(_0x52e2d6,_0x2c96be,_0x3f7f0d,_0x2f7144){return k(_0x52e2d6)['onIdTokenChanged'](_0x2c96be,_0x3f7f0d,_0x2f7144);}function Jf(_0x1210a4,_0x5aed74,_0x122dc7){return k(_0x1210a4)['beforeAuthStateChanged'](_0x5aed74,_0x122dc7);}function N_(_0x10b7f8,_0x488ee7,_0x5cbc72,_0x299884){return k(_0x10b7f8)['onAuthStateChanged'](_0x488ee7,_0x5cbc72,_0x299884);}function P_(_0x557245){return k(_0x557245)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xe66ad0,_0x3b1189){this['storageRetriever']=_0xe66ad0,this['type']=_0x3b1189;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2ac4fd,_0x5f5184){return this['storage']['setItem'](_0x2ac4fd,JSON['stringify'](_0x5f5184)),Promise['resolve']();}['_get'](_0x16d56f){const _0x9fb78c=this['storage']['getItem'](_0x16d56f);return Promise['resolve'](_0x9fb78c?JSON['parse'](_0x9fb78c):null);}['_remove'](_0x12e530){return this['storage']['removeItem'](_0x12e530),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x14787d,_0x44c160)=>this['onStorageEvent'](_0x14787d,_0x44c160),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x406284){for(const _0xebdf48 of Object['keys'](this['listeners'])){const _0x5113e6=this['storage']['getItem'](_0xebdf48),_0xe79693=this['localCache'][_0xebdf48];_0x5113e6!==_0xe79693&&_0x406284(_0xebdf48,_0xe79693,_0x5113e6);}}['onStorageEvent'](_0x16df51,_0x23eeae=!0x1){if(!_0x16df51['key']){this['forAllChangedKeys']((_0xb24e28,_0x423bd9,_0x4b9fb8)=>{this['notifyListeners'](_0xb24e28,_0x4b9fb8);});return;}const _0x19a73d=_0x16df51['key'];_0x23eeae?this['detachListener']():this['stopPolling']();const _0x319a9c=()=>{const _0x3500f9=this['storage']['getItem'](_0x19a73d);!_0x23eeae&&this['localCache'][_0x19a73d]===_0x3500f9||this['notifyListeners'](_0x19a73d,_0x3500f9);},_0x4050c3=this['storage']['getItem'](_0x19a73d);If()&&_0x4050c3!==_0x16df51['newValue']&&_0x16df51['newValue']!==_0x16df51['oldValue']?setTimeout(_0x319a9c,Zf):_0x319a9c();}['notifyListeners'](_0x5b2aab,_0x3a6b70){this['localCache'][_0x5b2aab]=_0x3a6b70;const _0x228046=this['listeners'][_0x5b2aab];if(_0x228046){for(const _0x5835b5 of Array['from'](_0x228046))_0x5835b5(_0x3a6b70&&JSON['parse'](_0x3a6b70));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x242dc7,_0x3bb40c,_0x30477a)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x242dc7,'oldValue':_0x3bb40c,'newValue':_0x30477a}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x47fcfd,_0x287aa7){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x47fcfd]||(this['listeners'][_0x47fcfd]=new Set(),this['localCache'][_0x47fcfd]=this['storage']['getItem'](_0x47fcfd)),this['listeners'][_0x47fcfd]['add'](_0x287aa7);}['_removeListener'](_0x336a44,_0x22a4cb){this['listeners'][_0x336a44]&&(this['listeners'][_0x336a44]['delete'](_0x22a4cb),this['listeners'][_0x336a44]['size']===0x0&&delete this['listeners'][_0x336a44]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x42d19f,_0x56c3ef){await super['_set'](_0x42d19f,_0x56c3ef),this['localCache'][_0x42d19f]=JSON['stringify'](_0x56c3ef);}async['_get'](_0x3314a0){const _0x31a2ca=await super['_get'](_0x3314a0);return this['localCache'][_0x3314a0]=JSON['stringify'](_0x31a2ca),_0x31a2ca;}async['_remove'](_0x2716ed){await super['_remove'](_0x2716ed),delete this['localCache'][_0x2716ed];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1c314c,_0x407a20){}['_removeListener'](_0x194e3e,_0x4192bf){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x512728){return Promise['all'](_0x512728['map'](async _0x445910=>{try{return{'fulfilled':!0x0,'value':await _0x445910};}catch(_0x559217){return{'fulfilled':!0x1,'reason':_0x559217};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x5b6f1d){this['eventTarget']=_0x5b6f1d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5e306a){const _0x19ef11=this['receivers']['find'](_0x535419=>_0x535419['isListeningto'](_0x5e306a));if(_0x19ef11)return _0x19ef11;const _0x5eae0b=new jn(_0x5e306a);return this['receivers']['push'](_0x5eae0b),_0x5eae0b;}['isListeningto'](_0x6bb7cf){return this['eventTarget']===_0x6bb7cf;}async['handleEvent'](_0x4d71e6){const _0x5c97ec=_0x4d71e6,{eventId:_0x41d455,eventType:_0x41a81c,data:_0x5e987e}=_0x5c97ec['data'],_0x101d18=this['handlersMap'][_0x41a81c];if(!(_0x101d18!=null&&_0x101d18['size']))return;_0x5c97ec['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x41d455,'eventType':_0x41a81c});const _0x3891b3=Array['from'](_0x101d18)['map'](async _0x4de365=>_0x4de365(_0x5c97ec['origin'],_0x5e987e)),_0x5f1ad6=await tp(_0x3891b3);_0x5c97ec['ports'][0x0]['postMessage']({'status':'done','eventId':_0x41d455,'eventType':_0x41a81c,'response':_0x5f1ad6});}['_subscribe'](_0x55bcd2,_0x1b91a9){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x55bcd2]||(this['handlersMap'][_0x55bcd2]=new Set()),this['handlersMap'][_0x55bcd2]['add'](_0x1b91a9);}['_unsubscribe'](_0x26638a,_0xf20715){this['handlersMap'][_0x26638a]&&_0xf20715&&this['handlersMap'][_0x26638a]['delete'](_0xf20715),(!_0xf20715||this['handlersMap'][_0x26638a]['size']===0x0)&&delete this['handlersMap'][_0x26638a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x50c47d='',_0x1f2d4d=0xa){let _0x46b831='';for(let _0x315c9d=0x0;_0x315c9d<_0x1f2d4d;_0x315c9d++)_0x46b831+=Math['floor'](Math['random']()*0xa);return _0x50c47d+_0x46b831;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x408c7f){this['target']=_0x408c7f,this['handlers']=new Set();}['removeMessageHandler'](_0x769e27){_0x769e27['messageChannel']&&(_0x769e27['messageChannel']['port1']['removeEventListener']('message',_0x769e27['onMessage']),_0x769e27['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x769e27);}async['_send'](_0xde1c08,_0x441c37,_0x397fb6=0x32){const _0xc04e1=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xc04e1)throw new Error('connection_unavailable');let _0x3488d8,_0x250c8c;return new Promise((_0x21d050,_0x104e24)=>{const _0x17d3f2=bs('',0x14);_0xc04e1['port1']['start']();const _0x146fa5=setTimeout(()=>{_0x104e24(new Error('unsupported_event'));},_0x397fb6);_0x250c8c={'messageChannel':_0xc04e1,'onMessage'(_0x4c50b5){const _0x597fac=_0x4c50b5;if(_0x597fac['data']['eventId']===_0x17d3f2)switch(_0x597fac['data']['status']){case'ack':clearTimeout(_0x146fa5),_0x3488d8=setTimeout(()=>{_0x104e24(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3488d8),_0x21d050(_0x597fac['data']['response']);break;default:clearTimeout(_0x146fa5),clearTimeout(_0x3488d8),_0x104e24(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x250c8c),_0xc04e1['port1']['addEventListener']('message',_0x250c8c['onMessage']),this['target']['postMessage']({'eventType':_0xde1c08,'eventId':_0x17d3f2,'data':_0x441c37},[_0xc04e1['port2']]);})['finally'](()=>{_0x250c8c&&this['removeMessageHandler'](_0x250c8c);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x36ac7b){X()['location']['href']=_0x36ac7b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x59a145;return((_0x59a145=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x59a145['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x4e45ba){this['request']=_0x4e45ba;}['toPromise'](){return new Promise((_0x22b4ba,_0x8373e5)=>{this['request']['addEventListener']('success',()=>{_0x22b4ba(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x8373e5(this['request']['error']);});});}}function Kn(_0x515e1d,_0x161c0f){return _0x515e1d['transaction']([kn],_0x161c0f?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x48c04b=indexedDB['deleteDatabase'](qa);return new Jt(_0x48c04b)['toPromise']();}function ja(){const _0x60fe5c=indexedDB['open'](qa,ap);return new Promise((_0x324f34,_0x3cfc84)=>{_0x60fe5c['addEventListener']('error',()=>{_0x3cfc84(_0x60fe5c['error']);}),_0x60fe5c['addEventListener']('upgradeneeded',()=>{const _0x302054=_0x60fe5c['result'];try{_0x302054['createObjectStore'](kn,{'keyPath':za});}catch(_0x193174){_0x3cfc84(_0x193174);}}),_0x60fe5c['addEventListener']('success',async()=>{const _0x5cd72d=_0x60fe5c['result'];_0x5cd72d['objectStoreNames']['contains'](kn)?_0x324f34(_0x5cd72d):(_0x5cd72d['close'](),await cp(),_0x324f34(await ja()));});});}async function kr(_0xc0ff9c,_0x5c772d,_0x1cf81b){const _0x3c2257=Kn(_0xc0ff9c,!0x0)['put']({[za]:_0x5c772d,'value':_0x1cf81b});return new Jt(_0x3c2257)['toPromise']();}async function lp(_0x2b1a24,_0x13deec){const _0x6c2dea=Kn(_0x2b1a24,!0x1)['get'](_0x13deec),_0x243729=await new Jt(_0x6c2dea)['toPromise']();return _0x243729===void 0x0?null:_0x243729['value'];}function Nr(_0x5a1d5e,_0x31347e){const _0x4251f3=Kn(_0x5a1d5e,!0x0)['delete'](_0x31347e);return new Jt(_0x4251f3)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5782c5){let _0x5bee08=0x0;for(;;)try{const _0x2ea2de=await this['_openDb']();return await _0x5782c5(_0x2ea2de);}catch(_0xedbe1f){if(_0x5bee08++>up)throw _0xedbe1f;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x28f606,_0x1dcf98)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1dcf98['key'])})),this['receiver']['_subscribe']('ping',async(_0x587757,_0x2b17a7)=>['keyChanged']);}async['initializeSender'](){var _0x2469f6,_0x362ffb;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x16c192=await this['sender']['_send']('ping',{},0x320);_0x16c192&&(_0x2469f6=_0x16c192[0x0])!=null&&_0x2469f6['fulfilled']&&(_0x362ffb=_0x16c192[0x0])!=null&&_0x362ffb['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x34979d){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x34979d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x52648e=>{await kr(_0x52648e,An,'1'),await Nr(_0x52648e,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x47eb45){this['pendingWrites']++;try{await _0x47eb45();}finally{this['pendingWrites']--;}}async['_set'](_0x1db01f,_0x100640){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x49cc16=>kr(_0x49cc16,_0x1db01f,_0x100640)),this['localCache'][_0x1db01f]=_0x100640,this['notifyServiceWorker'](_0x1db01f)));}async['_get'](_0x12421d){const _0x44b689=await this['_withRetries'](_0x26e59f=>lp(_0x26e59f,_0x12421d));return this['localCache'][_0x12421d]=_0x44b689,_0x44b689;}async['_remove'](_0x1e1aa9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1ee233=>Nr(_0x1ee233,_0x1e1aa9)),delete this['localCache'][_0x1e1aa9],this['notifyServiceWorker'](_0x1e1aa9)));}async['_poll'](){const _0x2e58ba=await this['_withRetries'](_0x2a297a=>{const _0x1035fa=Kn(_0x2a297a,!0x1)['getAll']();return new Jt(_0x1035fa)['toPromise']();});if(!_0x2e58ba)return[];if(this['pendingWrites']!==0x0)return[];const _0x3886d3=[],_0x20a93d=new Set();if(_0x2e58ba['length']!==0x0){for(const {fbase_key:_0x12f43c,value:_0x2ae219}of _0x2e58ba)_0x20a93d['add'](_0x12f43c),JSON['stringify'](this['localCache'][_0x12f43c])!==JSON['stringify'](_0x2ae219)&&(this['notifyListeners'](_0x12f43c,_0x2ae219),_0x3886d3['push'](_0x12f43c));}for(const _0xb82f67 of Object['keys'](this['localCache']))this['localCache'][_0xb82f67]&&!_0x20a93d['has'](_0xb82f67)&&(this['notifyListeners'](_0xb82f67,null),_0x3886d3['push'](_0xb82f67));return _0x3886d3;}['notifyListeners'](_0x49943b,_0x167978){this['localCache'][_0x49943b]=_0x167978;const _0x4b160f=this['listeners'][_0x49943b];if(_0x4b160f){for(const _0x3c2ad5 of Array['from'](_0x4b160f))_0x3c2ad5(_0x167978);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4bc94a,_0xe1296c){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4bc94a]||(this['listeners'][_0x4bc94a]=new Set(),this['_get'](_0x4bc94a)),this['listeners'][_0x4bc94a]['add'](_0xe1296c);}['_removeListener'](_0x1e693a,_0x268ba3){this['listeners'][_0x1e693a]&&(this['listeners'][_0x1e693a]['delete'](_0x268ba3),this['listeners'][_0x1e693a]['size']===0x0&&delete this['listeners'][_0x1e693a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51d6a4,_0x404a79){return _0x404a79?ne(_0x404a79):(m(_0x51d6a4['_popupRedirectResolver'],_0x51d6a4,'argument-error'),_0x51d6a4['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4e7c39){super('custom','custom'),this['params']=_0x4e7c39;}['_getIdTokenResponse'](_0x543dba){return Ze(_0x543dba,this['_buildIdpRequest']());}['_linkToIdToken'](_0x57a2e7,_0x16a46f){return Ze(_0x57a2e7,this['_buildIdpRequest'](_0x16a46f));}['_getReauthenticationResolver'](_0x266210){return Ze(_0x266210,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3ff04a){const _0x155167={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3ff04a&&(_0x155167['idToken']=_0x3ff04a),_0x155167;}}function pp(_0x2a36cc){return Ua(_0x2a36cc['auth'],new Rs(_0x2a36cc),_0x2a36cc['bypassAuthState']);}function _p(_0x53a6e3){const {auth:_0xd3b095,user:_0x3be800}=_0x53a6e3;return m(_0x3be800,_0xd3b095,'internal-error'),Kf(_0x3be800,new Rs(_0x53a6e3),_0x53a6e3['bypassAuthState']);}async function gp(_0x3b75c5){const {auth:_0xb4922b,user:_0x357162}=_0x3b75c5;return m(_0x357162,_0xb4922b,'internal-error'),jf(_0x357162,new Rs(_0x3b75c5),_0x3b75c5['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x9de5dd,_0x2a29dc,_0x151387,_0x576bef,_0x17f269=!0x1){this['auth']=_0x9de5dd,this['resolver']=_0x151387,this['user']=_0x576bef,this['bypassAuthState']=_0x17f269,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2a29dc)?_0x2a29dc:[_0x2a29dc];}['execute'](){return new Promise(async(_0x44d7c3,_0x3c83a9)=>{this['pendingPromise']={'resolve':_0x44d7c3,'reject':_0x3c83a9};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x641453){this['reject'](_0x641453);}});}async['onAuthEvent'](_0x14e47a){const {urlResponse:_0x229ae0,sessionId:_0x381a99,postBody:_0x5856b8,tenantId:_0xe37c65,error:_0xdf5250,type:_0x3a4940}=_0x14e47a;if(_0xdf5250){this['reject'](_0xdf5250);return;}const _0x149214={'auth':this['auth'],'requestUri':_0x229ae0,'sessionId':_0x381a99,'tenantId':_0xe37c65||void 0x0,'postBody':_0x5856b8||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3a4940)(_0x149214));}catch(_0x6a99fb){this['reject'](_0x6a99fb);}}['onError'](_0x75ff2){this['reject'](_0x75ff2);}['getIdpTask'](_0x339797){switch(_0x339797){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x5ea399){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5ea399),this['unregisterAndCleanUp']();}['reject'](_0x3ba306){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3ba306),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x2a70aa,_0x1d1bf9,_0x355b70,_0x3f9e57,_0x3e7f35){super(_0x2a70aa,_0x1d1bf9,_0x3f9e57,_0x3e7f35),this['provider']=_0x355b70,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xb4f494=await this['execute']();return m(_0xb4f494,this['auth'],'internal-error'),_0xb4f494;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x8f03e3=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x8f03e3),this['authWindow']['associatedEvent']=_0x8f03e3,this['resolver']['_originValidation'](this['auth'])['catch'](_0x11c8ca=>{this['reject'](_0x11c8ca);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0xbd8ea1=>{_0xbd8ea1||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x205308;return((_0x205308=this['authWindow'])==null?void 0x0:_0x205308['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1db1ff=()=>{var _0x561734,_0x2f4d59;if((_0x2f4d59=(_0x561734=this['authWindow'])==null?void 0x0:_0x561734['window'])!=null&&_0x2f4d59['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1db1ff,mp['get']());};_0x1db1ff();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x154f2b,_0x3c843e,_0xb2c65a=!0x1){super(_0x154f2b,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3c843e,void 0x0,_0xb2c65a),this['eventId']=null;}async['execute'](){let _0x28a97c=rn['get'](this['auth']['_key']());if(!_0x28a97c){try{const _0x488ae8=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x28a97c=()=>Promise['resolve'](_0x488ae8);}catch(_0x560717){_0x28a97c=()=>Promise['reject'](_0x560717);}rn['set'](this['auth']['_key'](),_0x28a97c);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x28a97c();}async['onAuthEvent'](_0x127f49){if(_0x127f49['type']==='signInViaRedirect')return super['onAuthEvent'](_0x127f49);if(_0x127f49['type']==='unknown'){this['resolve'](null);return;}if(_0x127f49['eventId']){const _0x2a93f6=await this['auth']['_redirectUserForId'](_0x127f49['eventId']);if(_0x2a93f6)return this['user']=_0x2a93f6,super['onAuthEvent'](_0x127f49);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x493ecf,_0x5080a3){const _0x38d034=Cp(_0x5080a3),_0x2b4d37=wp(_0x493ecf);if(!await _0x2b4d37['_isAvailable']())return!0x1;const _0x1a57db=await _0x2b4d37['_get'](_0x38d034)==='true';return await _0x2b4d37['_remove'](_0x38d034),_0x1a57db;}function Ip(_0x51db59,_0xf489dd){rn['set'](_0x51db59['_key'](),_0xf489dd);}function wp(_0x41735e){return ne(_0x41735e['_redirectPersistence']);}function Cp(_0x3aa5d1){return sn(yp,_0x3aa5d1['config']['apiKey'],_0x3aa5d1['name']);}async function Tp(_0x470b29,_0x235ce3,_0x3baf14=!0x1){if(H(_0x470b29['app']))return Promise['reject'](se(_0x470b29));const _0xc6ff42=qe(_0x470b29),_0x3e2c49=fp(_0xc6ff42,_0x235ce3),_0x555d16=await new vp(_0xc6ff42,_0x3e2c49,_0x3baf14)['execute']();return _0x555d16&&!_0x3baf14&&(delete _0x555d16['user']['_redirectEventId'],await _0xc6ff42['_persistUserIfCurrent'](_0x555d16['user']),await _0xc6ff42['_setRedirectUser'](null,_0x235ce3)),_0x555d16;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x2b0167){this['auth']=_0x2b0167,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x5ac752){this['consumers']['add'](_0x5ac752),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x5ac752)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x5ac752),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4091ab){this['consumers']['delete'](_0x4091ab);}['onEvent'](_0x558abe){if(this['hasEventBeenHandled'](_0x558abe))return!0x1;let _0x1a5d73=!0x1;return this['consumers']['forEach'](_0x551e0b=>{this['isEventForConsumer'](_0x558abe,_0x551e0b)&&(_0x1a5d73=!0x0,this['sendToConsumer'](_0x558abe,_0x551e0b),this['saveEventToCache'](_0x558abe));}),this['hasHandledPotentialRedirect']||!Rp(_0x558abe)||(this['hasHandledPotentialRedirect']=!0x0,_0x1a5d73||(this['queuedRedirectEvent']=_0x558abe,_0x1a5d73=!0x0)),_0x1a5d73;}['sendToConsumer'](_0xfc2ff8,_0x49e3fa){var _0xe67edc;if(_0xfc2ff8['error']&&!Qa(_0xfc2ff8)){const _0x203e99=((_0xe67edc=_0xfc2ff8['error']['code'])==null?void 0x0:_0xe67edc['split']('auth/')[0x1])||'internal-error';_0x49e3fa['onError'](J(this['auth'],_0x203e99));}else _0x49e3fa['onAuthEvent'](_0xfc2ff8);}['isEventForConsumer'](_0x3e3c71,_0x5c2246){const _0x424084=_0x5c2246['eventId']===null||!!_0x3e3c71['eventId']&&_0x3e3c71['eventId']===_0x5c2246['eventId'];return _0x5c2246['filter']['includes'](_0x3e3c71['type'])&&_0x424084;}['hasEventBeenHandled'](_0x96f604){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x96f604));}['saveEventToCache'](_0x263f58){this['cachedEventUids']['add'](Pr(_0x263f58)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x28642a){return[_0x28642a['type'],_0x28642a['eventId'],_0x28642a['sessionId'],_0x28642a['tenantId']]['filter'](_0x3c2c10=>_0x3c2c10)['join']('-');}function Qa({type:_0xedc61c,error:_0x29f9da}){return _0xedc61c==='unknown'&&(_0x29f9da==null?void 0x0:_0x29f9da['code'])==='auth/no-auth-event';}function Rp(_0x289ebc){switch(_0x289ebc['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x289ebc);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x31fc52,_0x36808f={}){return Ae(_0x31fc52,'GET','/v1/projects',_0x36808f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x126969){if(_0x126969['config']['emulator'])return;const {authorizedDomains:_0x48a907}=await Ap(_0x126969);for(const _0x1b6e43 of _0x48a907)try{if(Op(_0x1b6e43))return;}catch{}K(_0x126969,'unauthorized-domain');}function Op(_0x4dceb3){const _0x5f309b=Ni(),{protocol:_0x44e7af,hostname:_0x72afce}=new URL(_0x5f309b);if(_0x4dceb3['startsWith']('chrome-extension://')){const _0xf6c9e8=new URL(_0x4dceb3);return _0xf6c9e8['hostname']===''&&_0x72afce===''?_0x44e7af==='chrome-extension:'&&_0x4dceb3['replace']('chrome-extension://','')===_0x5f309b['replace']('chrome-extension://',''):_0x44e7af==='chrome-extension:'&&_0xf6c9e8['hostname']===_0x72afce;}if(!Np['test'](_0x44e7af))return!0x1;if(kp['test'](_0x4dceb3))return _0x72afce===_0x4dceb3;const _0x37e6c7=_0x4dceb3['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x37e6c7+'|'+_0x37e6c7+')$','i')['test'](_0x72afce);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x50ba2c=X()['___jsl'];if(_0x50ba2c!=null&&_0x50ba2c['H']){for(const _0x385388 of Object['keys'](_0x50ba2c['H']))if(_0x50ba2c['H'][_0x385388]['r']=_0x50ba2c['H'][_0x385388]['r']||[],_0x50ba2c['H'][_0x385388]['L']=_0x50ba2c['H'][_0x385388]['L']||[],_0x50ba2c['H'][_0x385388]['r']=[..._0x50ba2c['H'][_0x385388]['L']],_0x50ba2c['CP']){for(let _0x52b7a5=0x0;_0x52b7a5<_0x50ba2c['CP']['length'];_0x52b7a5++)_0x50ba2c['CP'][_0x52b7a5]=null;}}}function Mp(_0x1c889c){return new Promise((_0x27b081,_0x423f20)=>{var _0x2e8b42,_0xe3e9f4,_0x1eb1aa;function _0x171fa2(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x27b081(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x423f20(J(_0x1c889c,'network-request-failed'));},'timeout':Dp['get']()});}if((_0xe3e9f4=(_0x2e8b42=X()['gapi'])==null?void 0x0:_0x2e8b42['iframes'])!=null&&_0xe3e9f4['Iframe'])_0x27b081(gapi['iframes']['getContext']());else{if((_0x1eb1aa=X()['gapi'])!=null&&_0x1eb1aa['load'])_0x171fa2();else{const _0x31cfc4=Nf('iframefcb');return X()[_0x31cfc4]=()=>{gapi['load']?_0x171fa2():_0x423f20(J(_0x1c889c,'network-request-failed'));},Da(kf()+'?onload='+_0x31cfc4)['catch'](_0x14b45e=>_0x423f20(_0x14b45e));}}})['catch'](_0x22806a=>{throw on=null,_0x22806a;});}let on=null;function Lp(_0x207b10){return on=on||Mp(_0x207b10),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x20b55a){const _0x4d505c=_0x20b55a['config'];m(_0x4d505c['authDomain'],_0x20b55a,'auth-domain-config-required');const _0x435f05=_0x4d505c['emulator']?Is(_0x4d505c,Up):'https://'+_0x20b55a['config']['authDomain']+'/'+Fp,_0x227d28={'apiKey':_0x4d505c['apiKey'],'appName':_0x20b55a['name'],'v':ct},_0x269e68=Bp['get'](_0x20b55a['config']['apiHost']);_0x269e68&&(_0x227d28['eid']=_0x269e68);const _0x327554=_0x20b55a['_getFrameworks']();return _0x327554['length']&&(_0x227d28['fw']=_0x327554['join'](',')),_0x435f05+'?'+at(_0x227d28)['slice'](0x1);}async function Hp(_0x4a0a98){const _0x28575b=await Lp(_0x4a0a98),_0x53951f=X()['gapi'];return m(_0x53951f,_0x4a0a98,'internal-error'),_0x28575b['open']({'where':document['body'],'url':Vp(_0x4a0a98),'messageHandlersFilter':_0x53951f['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x13f182=>new Promise(async(_0xf63cd6,_0x194863)=>{await _0x13f182['restyle']({'setHideOnLeave':!0x1});const _0x18d6cf=J(_0x4a0a98,'network-request-failed'),_0xd47e30=X()['setTimeout'](()=>{_0x194863(_0x18d6cf);},xp['get']());function _0x89fb0e(){X()['clearTimeout'](_0xd47e30),_0xf63cd6(_0x13f182);}_0x13f182['ping'](_0x89fb0e)['then'](_0x89fb0e,()=>{_0x194863(_0x18d6cf);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x36ca79){this['window']=_0x36ca79,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x19156f,_0x161fd8,_0x3b2eb6,_0x6707fb=Gp,_0x41c696=qp){const _0x581de4=Math['max']((window['screen']['availHeight']-_0x41c696)/0x2,0x0)['toString'](),_0x2b4cd8=Math['max']((window['screen']['availWidth']-_0x6707fb)/0x2,0x0)['toString']();let _0x39168f='';const _0x2c03e7={...$p,'width':_0x6707fb['toString'](),'height':_0x41c696['toString'](),'top':_0x581de4,'left':_0x2b4cd8},_0xc232c7=W()['toLowerCase']();_0x3b2eb6&&(_0x39168f=ba(_0xc232c7)?zp:_0x3b2eb6),Ta(_0xc232c7)&&(_0x161fd8=_0x161fd8||jp,_0x2c03e7['scrollbars']='yes');const _0x3cbcc7=Object['entries'](_0x2c03e7)['reduce']((_0x5c7f34,[_0x5ae985,_0x1efcc5])=>''+_0x5c7f34+_0x5ae985+'='+_0x1efcc5+',','');if(Ef(_0xc232c7)&&_0x39168f!=='_self')return Yp(_0x161fd8||'',_0x39168f),new Dr(null);const _0x2fc270=window['open'](_0x161fd8||'',_0x39168f,_0x3cbcc7);m(_0x2fc270,_0x19156f,'popup-blocked');try{_0x2fc270['focus']();}catch{}return new Dr(_0x2fc270);}function Yp(_0x21384d,_0x50c9d9){const _0x5b7b0b=document['createElement']('a');_0x5b7b0b['href']=_0x21384d,_0x5b7b0b['target']=_0x50c9d9;const _0x5779fd=document['createEvent']('MouseEvent');_0x5779fd['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5b7b0b['dispatchEvent'](_0x5779fd);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2c0d96,_0x2a07a6,_0x4c5ea8,_0x3e0c9e,_0x168c73,_0xa9eb27){m(_0x2c0d96['config']['authDomain'],_0x2c0d96,'auth-domain-config-required'),m(_0x2c0d96['config']['apiKey'],_0x2c0d96,'invalid-api-key');const _0x2a8ce4={'apiKey':_0x2c0d96['config']['apiKey'],'appName':_0x2c0d96['name'],'authType':_0x4c5ea8,'redirectUrl':_0x3e0c9e,'v':ct,'eventId':_0x168c73};if(_0x2a07a6 instanceof xa){_0x2a07a6['setDefaultLanguage'](_0x2c0d96['languageCode']),_0x2a8ce4['providerId']=_0x2a07a6['providerId']||'',hi(_0x2a07a6['getCustomParameters']())||(_0x2a8ce4['customParameters']=JSON['stringify'](_0x2a07a6['getCustomParameters']()));for(const [_0x3bc217,_0x346502]of Object['entries']({}))_0x2a8ce4[_0x3bc217]=_0x346502;}if(_0x2a07a6 instanceof Qt){const _0x585d30=_0x2a07a6['getScopes']()['filter'](_0x220e9=>_0x220e9!=='');_0x585d30['length']>0x0&&(_0x2a8ce4['scopes']=_0x585d30['join'](','));}_0x2c0d96['tenantId']&&(_0x2a8ce4['tid']=_0x2c0d96['tenantId']);const _0x26f9e5=_0x2a8ce4;for(const _0x51383b of Object['keys'](_0x26f9e5))_0x26f9e5[_0x51383b]===void 0x0&&delete _0x26f9e5[_0x51383b];const _0x40879c=await _0x2c0d96['_getAppCheckToken'](),_0xed3db=_0x40879c?'#'+Xp+'='+encodeURIComponent(_0x40879c):'';return Zp(_0x2c0d96)+'?'+at(_0x26f9e5)['slice'](0x1)+_0xed3db;}function Zp({config:_0x279657}){return _0x279657['emulator']?Is(_0x279657,Jp):'https://'+_0x279657['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x4c8f13,_0x1feb88,_0x494da6,_0x1d5096){var _0x30a9e3;ae((_0x30a9e3=this['eventManagers'][_0x4c8f13['_key']()])==null?void 0x0:_0x30a9e3['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x6d6edf=await Mr(_0x4c8f13,_0x1feb88,_0x494da6,Ni(),_0x1d5096);return Kp(_0x4c8f13,_0x6d6edf,bs());}async['_openRedirect'](_0x424b7f,_0x3c206c,_0x2c5a4a,_0xc55ab7){await this['_originValidation'](_0x424b7f);const _0x313513=await Mr(_0x424b7f,_0x3c206c,_0x2c5a4a,Ni(),_0xc55ab7);return ip(_0x313513),new Promise(()=>{});}['_initialize'](_0x44e49b){const _0x396d68=_0x44e49b['_key']();if(this['eventManagers'][_0x396d68]){const {manager:_0x2f1a6d,promise:_0x3f9cff}=this['eventManagers'][_0x396d68];return _0x2f1a6d?Promise['resolve'](_0x2f1a6d):(ae(_0x3f9cff,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3f9cff);}const _0x1b89b7=this['initAndGetManager'](_0x44e49b);return this['eventManagers'][_0x396d68]={'promise':_0x1b89b7},_0x1b89b7['catch'](()=>{delete this['eventManagers'][_0x396d68];}),_0x1b89b7;}async['initAndGetManager'](_0x2d9f11){const _0x1ba82e=await Hp(_0x2d9f11),_0x1516ff=new bp(_0x2d9f11);return _0x1ba82e['register']('authEvent',_0x5ca085=>(m(_0x5ca085==null?void 0x0:_0x5ca085['authEvent'],_0x2d9f11,'invalid-auth-event'),{'status':_0x1516ff['onEvent'](_0x5ca085['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2d9f11['_key']()]={'manager':_0x1516ff},this['iframes'][_0x2d9f11['_key']()]=_0x1ba82e,_0x1516ff;}['_isIframeWebStorageSupported'](_0x2154c3,_0x127440){this['iframes'][_0x2154c3['_key']()]['send'](li,{'type':li},_0x2cfab7=>{var _0x418854;const _0x103f28=(_0x418854=_0x2cfab7==null?void 0x0:_0x2cfab7[0x0])==null?void 0x0:_0x418854[li];_0x103f28!==void 0x0&&_0x127440(!!_0x103f28),K(_0x2154c3,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5cb351){const _0x4925d3=_0x5cb351['_key']();return this['originValidationPromises'][_0x4925d3]||(this['originValidationPromises'][_0x4925d3]=Pp(_0x5cb351)),this['originValidationPromises'][_0x4925d3];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x3ef26a){this['auth']=_0x3ef26a,this['internalListeners']=new Map();}['getUid'](){var _0xf86f86;return this['assertAuthConfigured'](),((_0xf86f86=this['auth']['currentUser'])==null?void 0x0:_0xf86f86['uid'])||null;}async['getToken'](_0x351009){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x351009)}:null;}['addAuthTokenListener'](_0x185bde){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x185bde))return;const _0x3d67b1=this['auth']['onIdTokenChanged'](_0x344630=>{_0x185bde((_0x344630==null?void 0x0:_0x344630['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x185bde,_0x3d67b1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5d81df){this['assertAuthConfigured']();const _0x2e5af7=this['internalListeners']['get'](_0x5d81df);_0x2e5af7&&(this['internalListeners']['delete'](_0x5d81df),_0x2e5af7(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x19b8af){switch(_0x19b8af){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x28068d){et(new Me('auth',(_0x52d439,{options:_0x21f6f8})=>{const _0x3f8fc6=_0x52d439['getProvider']('app')['getImmediate'](),_0x247165=_0x52d439['getProvider']('heartbeat'),_0x2a417b=_0x52d439['getProvider']('app-check-internal'),{apiKey:_0x1ef7c8,authDomain:_0x196d46}=_0x3f8fc6['options'];m(_0x1ef7c8&&!_0x1ef7c8['includes'](':'),'invalid-api-key',{'appName':_0x3f8fc6['name']});const _0x3dbc3d={'apiKey':_0x1ef7c8,'authDomain':_0x196d46,'clientPlatform':_0x28068d,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x28068d)},_0x2835d6=new bf(_0x3f8fc6,_0x247165,_0x2a417b,_0x3dbc3d);return Lf(_0x2835d6,_0x21f6f8),_0x2835d6;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xbaf541,_0xa127b2,_0x14942d)=>{_0xbaf541['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x6b5ec=>{const _0x5a84b5=qe(_0x6b5ec['getProvider']('auth')['getImmediate']());return(_0x5e6f9f=>new n_(_0x5e6f9f))(_0x5a84b5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x28068d)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2e0e2b=>async _0x138552=>{const _0x32e020=_0x138552&&await _0x138552['getIdTokenResult'](),_0x9d9426=_0x32e020&&(new Date()['getTime']()-Date['parse'](_0x32e020['issuedAtTime']))/0x3e8;if(_0x9d9426&&_0x9d9426>o_)return;const _0x7d8c1b=_0x32e020==null?void 0x0:_0x32e020['token'];Fr!==_0x7d8c1b&&(Fr=_0x7d8c1b,await fetch(_0x2e0e2b,{'method':_0x7d8c1b?'POST':'DELETE','headers':_0x7d8c1b?{'Authorization':'Bearer\x20'+_0x7d8c1b}:{}}));};function O_(_0x505f5c=Qr()){const _0xc3b957=Ui(_0x505f5c,'auth');if(_0xc3b957['isInitialized']())return _0xc3b957['getImmediate']();const _0x1ca150=Mf(_0x505f5c,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0xe37a1b=Gr('authTokenSyncURL');if(_0xe37a1b&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x34e72c=new URL(_0xe37a1b,location['origin']);if(location['origin']===_0x34e72c['origin']){const _0x48fa80=a_(_0x34e72c['toString']());Jf(_0x1ca150,_0x48fa80,()=>_0x48fa80(_0x1ca150['currentUser'])),Qf(_0x1ca150,_0x41456a=>_0x48fa80(_0x41456a));}}const _0x13b893=Hr('auth');return _0x13b893&&xf(_0x1ca150,'http://'+_0x13b893),_0x1ca150;}function c_(){var _0x7f8e33;return((_0x7f8e33=document['getElementsByTagName']('head'))==null?void 0x0:_0x7f8e33[0x0])??document;}Rf({'loadJS'(_0x5a7b4f){return new Promise((_0x3dcbaf,_0x5793f8)=>{const _0x379827=document['createElement']('script');_0x379827['setAttribute']('src',_0x5a7b4f),_0x379827['onload']=_0x3dcbaf,_0x379827['onerror']=_0x3b124c=>{const _0x2acac3=J('internal-error');_0x2acac3['customData']=_0x3b124c,_0x5793f8(_0x2acac3);},_0x379827['type']='text/javascript',_0x379827['charset']='UTF-8',c_()['appendChild'](_0x379827);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};