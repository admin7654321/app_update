const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1db4cb,_0xcaa77a){if(!_0x1db4cb)throw ot(_0xcaa77a);},ot=function(_0x1664c4){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1664c4);},Wr=function(_0x3b4972){const _0x703569=[];let _0x3e36f=0x0;for(let _0x1e5da3=0x0;_0x1e5da3<_0x3b4972['length'];_0x1e5da3++){let _0x4a4135=_0x3b4972['charCodeAt'](_0x1e5da3);_0x4a4135<0x80?_0x703569[_0x3e36f++]=_0x4a4135:_0x4a4135<0x800?(_0x703569[_0x3e36f++]=_0x4a4135>>0x6|0xc0,_0x703569[_0x3e36f++]=_0x4a4135&0x3f|0x80):(_0x4a4135&0xfc00)===0xd800&&_0x1e5da3+0x1<_0x3b4972['length']&&(_0x3b4972['charCodeAt'](_0x1e5da3+0x1)&0xfc00)===0xdc00?(_0x4a4135=0x10000+((_0x4a4135&0x3ff)<<0xa)+(_0x3b4972['charCodeAt'](++_0x1e5da3)&0x3ff),_0x703569[_0x3e36f++]=_0x4a4135>>0x12|0xf0,_0x703569[_0x3e36f++]=_0x4a4135>>0xc&0x3f|0x80,_0x703569[_0x3e36f++]=_0x4a4135>>0x6&0x3f|0x80,_0x703569[_0x3e36f++]=_0x4a4135&0x3f|0x80):(_0x703569[_0x3e36f++]=_0x4a4135>>0xc|0xe0,_0x703569[_0x3e36f++]=_0x4a4135>>0x6&0x3f|0x80,_0x703569[_0x3e36f++]=_0x4a4135&0x3f|0x80);}return _0x703569;},Za=function(_0x39f141){const _0x1c31ea=[];let _0x258f04=0x0,_0x53d343=0x0;for(;_0x258f04<_0x39f141['length'];){const _0x45219b=_0x39f141[_0x258f04++];if(_0x45219b<0x80)_0x1c31ea[_0x53d343++]=String['fromCharCode'](_0x45219b);else{if(_0x45219b>0xbf&&_0x45219b<0xe0){const _0x95b94a=_0x39f141[_0x258f04++];_0x1c31ea[_0x53d343++]=String['fromCharCode']((_0x45219b&0x1f)<<0x6|_0x95b94a&0x3f);}else{if(_0x45219b>0xef&&_0x45219b<0x16d){const _0x1c6d0e=_0x39f141[_0x258f04++],_0x589ed6=_0x39f141[_0x258f04++],_0x58e056=_0x39f141[_0x258f04++],_0x58a845=((_0x45219b&0x7)<<0x12|(_0x1c6d0e&0x3f)<<0xc|(_0x589ed6&0x3f)<<0x6|_0x58e056&0x3f)-0x10000;_0x1c31ea[_0x53d343++]=String['fromCharCode'](0xd800+(_0x58a845>>0xa)),_0x1c31ea[_0x53d343++]=String['fromCharCode'](0xdc00+(_0x58a845&0x3ff));}else{const _0x34b255=_0x39f141[_0x258f04++],_0x4634eb=_0x39f141[_0x258f04++];_0x1c31ea[_0x53d343++]=String['fromCharCode']((_0x45219b&0xf)<<0xc|(_0x34b255&0x3f)<<0x6|_0x4634eb&0x3f);}}}}return _0x1c31ea['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2010b2,_0x281566){if(!Array['isArray'](_0x2010b2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2f23f6=_0x281566?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x20b437=[];for(let _0x1d8d93=0x0;_0x1d8d93<_0x2010b2['length'];_0x1d8d93+=0x3){const _0x13b2f1=_0x2010b2[_0x1d8d93],_0x2a9c20=_0x1d8d93+0x1<_0x2010b2['length'],_0x1048cd=_0x2a9c20?_0x2010b2[_0x1d8d93+0x1]:0x0,_0x27db9f=_0x1d8d93+0x2<_0x2010b2['length'],_0x228582=_0x27db9f?_0x2010b2[_0x1d8d93+0x2]:0x0,_0x4beb2d=_0x13b2f1>>0x2,_0x401384=(_0x13b2f1&0x3)<<0x4|_0x1048cd>>0x4;let _0x3216f9=(_0x1048cd&0xf)<<0x2|_0x228582>>0x6,_0x43d4f1=_0x228582&0x3f;_0x27db9f||(_0x43d4f1=0x40,_0x2a9c20||(_0x3216f9=0x40)),_0x20b437['push'](_0x2f23f6[_0x4beb2d],_0x2f23f6[_0x401384],_0x2f23f6[_0x3216f9],_0x2f23f6[_0x43d4f1]);}return _0x20b437['join']('');},'encodeString'(_0x3418c7,_0x147c70){return this['HAS_NATIVE_SUPPORT']&&!_0x147c70?btoa(_0x3418c7):this['encodeByteArray'](Wr(_0x3418c7),_0x147c70);},'decodeString'(_0xae7d94,_0x167d05){return this['HAS_NATIVE_SUPPORT']&&!_0x167d05?atob(_0xae7d94):Za(this['decodeStringToByteArray'](_0xae7d94,_0x167d05));},'decodeStringToByteArray'(_0x11e797,_0x51c9ee){this['init_']();const _0x4ce32c=_0x51c9ee?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4dd940=[];for(let _0xaff1c8=0x0;_0xaff1c8<_0x11e797['length'];){const _0x53d048=_0x4ce32c[_0x11e797['charAt'](_0xaff1c8++)],_0x18f54d=_0xaff1c8<_0x11e797['length']?_0x4ce32c[_0x11e797['charAt'](_0xaff1c8)]:0x0;++_0xaff1c8;const _0x4e0a37=_0xaff1c8<_0x11e797['length']?_0x4ce32c[_0x11e797['charAt'](_0xaff1c8)]:0x40;++_0xaff1c8;const _0x1a4ec2=_0xaff1c8<_0x11e797['length']?_0x4ce32c[_0x11e797['charAt'](_0xaff1c8)]:0x40;if(++_0xaff1c8,_0x53d048==null||_0x18f54d==null||_0x4e0a37==null||_0x1a4ec2==null)throw new ec();const _0x325ed4=_0x53d048<<0x2|_0x18f54d>>0x4;if(_0x4dd940['push'](_0x325ed4),_0x4e0a37!==0x40){const _0x5e56f1=_0x18f54d<<0x4&0xf0|_0x4e0a37>>0x2;if(_0x4dd940['push'](_0x5e56f1),_0x1a4ec2!==0x40){const _0x44e224=_0x4e0a37<<0x6&0xc0|_0x1a4ec2;_0x4dd940['push'](_0x44e224);}}}return _0x4dd940;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x19fbac=0x0;_0x19fbac<this['ENCODED_VALS']['length'];_0x19fbac++)this['byteToCharMap_'][_0x19fbac]=this['ENCODED_VALS']['charAt'](_0x19fbac),this['charToByteMap_'][this['byteToCharMap_'][_0x19fbac]]=_0x19fbac,this['byteToCharMapWebSafe_'][_0x19fbac]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x19fbac),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x19fbac]]=_0x19fbac,_0x19fbac>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x19fbac)]=_0x19fbac,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x19fbac)]=_0x19fbac);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x6e9af9){const _0x20af9c=Wr(_0x6e9af9);return Di['encodeByteArray'](_0x20af9c,!0x0);},an=function(_0x2c59d5){return Br(_0x2c59d5)['replace'](/\./g,'');},cn=function(_0x2e4426){try{return Di['decodeString'](_0x2e4426,!0x0);}catch(_0x2d7011){console['error']('base64Decode\x20failed:\x20',_0x2d7011);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x2a0771){return Vr(void 0x0,_0x2a0771);}function Vr(_0x466dac,_0x18e4fa){if(!(_0x18e4fa instanceof Object))return _0x18e4fa;switch(_0x18e4fa['constructor']){case Date:const _0xdb5fd=_0x18e4fa;return new Date(_0xdb5fd['getTime']());case Object:_0x466dac===void 0x0&&(_0x466dac={});break;case Array:_0x466dac=[];break;default:return _0x18e4fa;}for(const _0x444132 in _0x18e4fa)!_0x18e4fa['hasOwnProperty'](_0x444132)||!nc(_0x444132)||(_0x466dac[_0x444132]=Vr(_0x466dac[_0x444132],_0x18e4fa[_0x444132]));return _0x466dac;}function nc(_0x1fec82){return _0x1fec82!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x59ba2d=As['__FIREBASE_DEFAULTS__'];if(_0x59ba2d)return JSON['parse'](_0x59ba2d);},oc=()=>{if(typeof document>'u')return;let _0x1eaa83;try{_0x1eaa83=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x16ad45=_0x1eaa83&&cn(_0x1eaa83[0x1]);return _0x16ad45&&JSON['parse'](_0x16ad45);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x5f5c8d){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5f5c8d);return;}},Hr=_0x37352b=>{var _0x5f3e31,_0x5b4e50;return(_0x5b4e50=(_0x5f3e31=Mi())==null?void 0x0:_0x5f3e31['emulatorHosts'])==null?void 0x0:_0x5b4e50[_0x37352b];},ac=_0x391f13=>{const _0x1dfd51=Hr(_0x391f13);if(!_0x1dfd51)return;const _0x5ce417=_0x1dfd51['lastIndexOf'](':');if(_0x5ce417<=0x0||_0x5ce417+0x1===_0x1dfd51['length'])throw new Error('Invalid\x20host\x20'+_0x1dfd51+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x7d6d6=parseInt(_0x1dfd51['substring'](_0x5ce417+0x1),0xa);return _0x1dfd51[0x0]==='['?[_0x1dfd51['substring'](0x1,_0x5ce417-0x1),_0x7d6d6]:[_0x1dfd51['substring'](0x0,_0x5ce417),_0x7d6d6];},$r=()=>{var _0x353a7d;return(_0x353a7d=Mi())==null?void 0x0:_0x353a7d['config'];},Gr=_0x1431a2=>{var _0x8fecc1;return(_0x8fecc1=Mi())==null?void 0x0:_0x8fecc1['_'+_0x1431a2];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1b37c1,_0xf15b0c)=>{this['resolve']=_0x1b37c1,this['reject']=_0xf15b0c;});}['wrapCallback'](_0x145a51){return(_0x41e193,_0x4e70a9)=>{_0x41e193?this['reject'](_0x41e193):this['resolve'](_0x4e70a9),typeof _0x145a51=='function'&&(this['promise']['catch'](()=>{}),_0x145a51['length']===0x1?_0x145a51(_0x41e193):_0x145a51(_0x41e193,_0x4e70a9));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x1dfb1b,_0x3696f5){if(_0x1dfb1b['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5ee6ec={'alg':'none','type':'JWT'},_0x368cf8=_0x3696f5||'demo-project',_0x12c68f=_0x1dfb1b['iat']||0x0,_0x31fba9=_0x1dfb1b['sub']||_0x1dfb1b['user_id'];if(!_0x31fba9)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xb804db={'iss':'https://securetoken.google.com/'+_0x368cf8,'aud':_0x368cf8,'iat':_0x12c68f,'exp':_0x12c68f+0xe10,'auth_time':_0x12c68f,'sub':_0x31fba9,'user_id':_0x31fba9,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x1dfb1b};return[an(JSON['stringify'](_0x5ee6ec)),an(JSON['stringify'](_0xb804db)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x6305cb=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x6305cb=='object'&&_0x6305cb['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x188967=W();return _0x188967['indexOf']('MSIE\x20')>=0x0||_0x188967['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x47169a,_0x413fa3)=>{try{let _0x1ba237=!0x0;const _0x23b886='validate-browser-context-for-indexeddb-analytics-module',_0x3e06c3=self['indexedDB']['open'](_0x23b886);_0x3e06c3['onsuccess']=()=>{_0x3e06c3['result']['close'](),_0x1ba237||self['indexedDB']['deleteDatabase'](_0x23b886),_0x47169a(!0x0);},_0x3e06c3['onupgradeneeded']=()=>{_0x1ba237=!0x1;},_0x3e06c3['onerror']=()=>{var _0x3cf6cf;_0x413fa3(((_0x3cf6cf=_0x3e06c3['error'])==null?void 0x0:_0x3cf6cf['message'])||'');};}catch(_0x9915fc){_0x413fa3(_0x9915fc);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x5a0dae,_0x298436,_0x524926){super(_0x298436),this['code']=_0x5a0dae,this['customData']=_0x524926,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x23386a,_0x1a3409,_0x224791){this['service']=_0x23386a,this['serviceName']=_0x1a3409,this['errors']=_0x224791;}['create'](_0x35159c,..._0x9fd951){const _0x3a191d=_0x9fd951[0x0]||{},_0x36832f=this['service']+'/'+_0x35159c,_0x3d3473=this['errors'][_0x35159c],_0x25d46a=_0x3d3473?gc(_0x3d3473,_0x3a191d):'Error',_0x63d166=this['serviceName']+':\x20'+_0x25d46a+'\x20('+_0x36832f+').';return new Se(_0x36832f,_0x63d166,_0x3a191d);}}function gc(_0x5b84f3,_0xe7d112){return _0x5b84f3['replace'](mc,(_0x5cf1f7,_0x1c5460)=>{const _0x3d458d=_0xe7d112[_0x1c5460];return _0x3d458d!=null?String(_0x3d458d):'<'+_0x1c5460+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x495d1f){return JSON['parse'](_0x495d1f);}function O(_0x1af9de){return JSON['stringify'](_0x1af9de);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x195b24){let _0x2fa9c9={},_0x358544={},_0x288ce7={},_0x323e84='';try{const _0x2616b1=_0x195b24['split']('.');_0x2fa9c9=bt(cn(_0x2616b1[0x0])||''),_0x358544=bt(cn(_0x2616b1[0x1])||''),_0x323e84=_0x2616b1[0x2],_0x288ce7=_0x358544['d']||{},delete _0x358544['d'];}catch{}return{'header':_0x2fa9c9,'claims':_0x358544,'data':_0x288ce7,'signature':_0x323e84};},yc=function(_0x5f3d01){const _0x28ae52=zr(_0x5f3d01),_0x1c8ed0=_0x28ae52['claims'];return!!_0x1c8ed0&&typeof _0x1c8ed0=='object'&&_0x1c8ed0['hasOwnProperty']('iat');},vc=function(_0x25b98b){const _0xd96670=zr(_0x25b98b)['claims'];return typeof _0xd96670=='object'&&_0xd96670['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1d8230,_0x56e548){return Object['prototype']['hasOwnProperty']['call'](_0x1d8230,_0x56e548);}function Oe(_0x30ae55,_0x785e01){if(Object['prototype']['hasOwnProperty']['call'](_0x30ae55,_0x785e01))return _0x30ae55[_0x785e01];}function hi(_0x1a7abe){for(const _0x3a132e in _0x1a7abe)if(Object['prototype']['hasOwnProperty']['call'](_0x1a7abe,_0x3a132e))return!0x1;return!0x0;}function ln(_0x74be2c,_0x525d99,_0x1fa70a){const _0x1ff0e2={};for(const _0x3f0fef in _0x74be2c)Object['prototype']['hasOwnProperty']['call'](_0x74be2c,_0x3f0fef)&&(_0x1ff0e2[_0x3f0fef]=_0x525d99['call'](_0x1fa70a,_0x74be2c[_0x3f0fef],_0x3f0fef,_0x74be2c));return _0x1ff0e2;}function De(_0x47eede,_0xc7312b){if(_0x47eede===_0xc7312b)return!0x0;const _0x3be8f3=Object['keys'](_0x47eede),_0x3fe189=Object['keys'](_0xc7312b);for(const _0x53452c of _0x3be8f3){if(!_0x3fe189['includes'](_0x53452c))return!0x1;const _0x5158d8=_0x47eede[_0x53452c],_0x35f2e6=_0xc7312b[_0x53452c];if(ks(_0x5158d8)&&ks(_0x35f2e6)){if(!De(_0x5158d8,_0x35f2e6))return!0x1;}else{if(_0x5158d8!==_0x35f2e6)return!0x1;}}for(const _0x13c258 of _0x3fe189)if(!_0x3be8f3['includes'](_0x13c258))return!0x1;return!0x0;}function ks(_0x3ea56b){return _0x3ea56b!==null&&typeof _0x3ea56b=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4063e7){const _0x320c8c=[];for(const [_0x536d4,_0x5bb0ed]of Object['entries'](_0x4063e7))Array['isArray'](_0x5bb0ed)?_0x5bb0ed['forEach'](_0x1c57e9=>{_0x320c8c['push'](encodeURIComponent(_0x536d4)+'='+encodeURIComponent(_0x1c57e9));}):_0x320c8c['push'](encodeURIComponent(_0x536d4)+'='+encodeURIComponent(_0x5bb0ed));return _0x320c8c['length']?'&'+_0x320c8c['join']('&'):'';}function yt(_0x4a7f7d){const _0x52aece={};return _0x4a7f7d['replace'](/^\?/,'')['split']('&')['forEach'](_0x53f021=>{if(_0x53f021){const [_0x565bdc,_0x2d8310]=_0x53f021['split']('=');_0x52aece[decodeURIComponent(_0x565bdc)]=decodeURIComponent(_0x2d8310);}}),_0x52aece;}function vt(_0x275958){const _0x2ee1bd=_0x275958['indexOf']('?');if(!_0x2ee1bd)return'';const _0x5f1ce7=_0x275958['indexOf']('#',_0x2ee1bd);return _0x275958['substring'](_0x2ee1bd,_0x5f1ce7>0x0?_0x5f1ce7:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1f88af=0x1;_0x1f88af<this['blockSize'];++_0x1f88af)this['pad_'][_0x1f88af]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3a4554,_0x10a7ed){_0x10a7ed||(_0x10a7ed=0x0);const _0x223025=this['W_'];if(typeof _0x3a4554=='string'){for(let _0x4f1fa9=0x0;_0x4f1fa9<0x10;_0x4f1fa9++)_0x223025[_0x4f1fa9]=_0x3a4554['charCodeAt'](_0x10a7ed)<<0x18|_0x3a4554['charCodeAt'](_0x10a7ed+0x1)<<0x10|_0x3a4554['charCodeAt'](_0x10a7ed+0x2)<<0x8|_0x3a4554['charCodeAt'](_0x10a7ed+0x3),_0x10a7ed+=0x4;}else{for(let _0x408415=0x0;_0x408415<0x10;_0x408415++)_0x223025[_0x408415]=_0x3a4554[_0x10a7ed]<<0x18|_0x3a4554[_0x10a7ed+0x1]<<0x10|_0x3a4554[_0x10a7ed+0x2]<<0x8|_0x3a4554[_0x10a7ed+0x3],_0x10a7ed+=0x4;}for(let _0x3371a3=0x10;_0x3371a3<0x50;_0x3371a3++){const _0x194ac4=_0x223025[_0x3371a3-0x3]^_0x223025[_0x3371a3-0x8]^_0x223025[_0x3371a3-0xe]^_0x223025[_0x3371a3-0x10];_0x223025[_0x3371a3]=(_0x194ac4<<0x1|_0x194ac4>>>0x1f)&0xffffffff;}let _0x25dc0=this['chain_'][0x0],_0x56f538=this['chain_'][0x1],_0x2e9b6f=this['chain_'][0x2],_0x31cc84=this['chain_'][0x3],_0x5dfa93=this['chain_'][0x4],_0xe6e716,_0x4dc49f;for(let _0x247b49=0x0;_0x247b49<0x50;_0x247b49++){_0x247b49<0x28?_0x247b49<0x14?(_0xe6e716=_0x31cc84^_0x56f538&(_0x2e9b6f^_0x31cc84),_0x4dc49f=0x5a827999):(_0xe6e716=_0x56f538^_0x2e9b6f^_0x31cc84,_0x4dc49f=0x6ed9eba1):_0x247b49<0x3c?(_0xe6e716=_0x56f538&_0x2e9b6f|_0x31cc84&(_0x56f538|_0x2e9b6f),_0x4dc49f=0x8f1bbcdc):(_0xe6e716=_0x56f538^_0x2e9b6f^_0x31cc84,_0x4dc49f=0xca62c1d6);const _0x40f924=(_0x25dc0<<0x5|_0x25dc0>>>0x1b)+_0xe6e716+_0x5dfa93+_0x4dc49f+_0x223025[_0x247b49]&0xffffffff;_0x5dfa93=_0x31cc84,_0x31cc84=_0x2e9b6f,_0x2e9b6f=(_0x56f538<<0x1e|_0x56f538>>>0x2)&0xffffffff,_0x56f538=_0x25dc0,_0x25dc0=_0x40f924;}this['chain_'][0x0]=this['chain_'][0x0]+_0x25dc0&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x56f538&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2e9b6f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x31cc84&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5dfa93&0xffffffff;}['update'](_0x4ccaf8,_0x284ab6){if(_0x4ccaf8==null)return;_0x284ab6===void 0x0&&(_0x284ab6=_0x4ccaf8['length']);const _0x5da1d1=_0x284ab6-this['blockSize'];let _0x1561b0=0x0;const _0x37c1f9=this['buf_'];let _0x39aa0a=this['inbuf_'];for(;_0x1561b0<_0x284ab6;){if(_0x39aa0a===0x0){for(;_0x1561b0<=_0x5da1d1;)this['compress_'](_0x4ccaf8,_0x1561b0),_0x1561b0+=this['blockSize'];}if(typeof _0x4ccaf8=='string'){for(;_0x1561b0<_0x284ab6;)if(_0x37c1f9[_0x39aa0a]=_0x4ccaf8['charCodeAt'](_0x1561b0),++_0x39aa0a,++_0x1561b0,_0x39aa0a===this['blockSize']){this['compress_'](_0x37c1f9),_0x39aa0a=0x0;break;}}else{for(;_0x1561b0<_0x284ab6;)if(_0x37c1f9[_0x39aa0a]=_0x4ccaf8[_0x1561b0],++_0x39aa0a,++_0x1561b0,_0x39aa0a===this['blockSize']){this['compress_'](_0x37c1f9),_0x39aa0a=0x0;break;}}}this['inbuf_']=_0x39aa0a,this['total_']+=_0x284ab6;}['digest'](){const _0x5748aa=[];let _0x10409e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x206dcf=this['blockSize']-0x1;_0x206dcf>=0x38;_0x206dcf--)this['buf_'][_0x206dcf]=_0x10409e&0xff,_0x10409e/=0x100;this['compress_'](this['buf_']);let _0x2fcb3a=0x0;for(let _0x386096=0x0;_0x386096<0x5;_0x386096++)for(let _0x1a66f8=0x18;_0x1a66f8>=0x0;_0x1a66f8-=0x8)_0x5748aa[_0x2fcb3a]=this['chain_'][_0x386096]>>_0x1a66f8&0xff,++_0x2fcb3a;return _0x5748aa;}}function Ic(_0x10f83d,_0x32f288){const _0x176ef3=new wc(_0x10f83d,_0x32f288);return _0x176ef3['subscribe']['bind'](_0x176ef3);}class wc{constructor(_0x301433,_0x1d25f5){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1d25f5,this['task']['then'](()=>{_0x301433(this);})['catch'](_0x4ddd80=>{this['error'](_0x4ddd80);});}['next'](_0x1fa87b){this['forEachObserver'](_0x4353e3=>{_0x4353e3['next'](_0x1fa87b);});}['error'](_0xa8124e){this['forEachObserver'](_0x3a25f0=>{_0x3a25f0['error'](_0xa8124e);}),this['close'](_0xa8124e);}['complete'](){this['forEachObserver'](_0x19642b=>{_0x19642b['complete']();}),this['close']();}['subscribe'](_0x58bd6e,_0x5bfe10,_0x59447c){let _0x3a90ff;if(_0x58bd6e===void 0x0&&_0x5bfe10===void 0x0&&_0x59447c===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x58bd6e,['next','error','complete'])?_0x3a90ff=_0x58bd6e:_0x3a90ff={'next':_0x58bd6e,'error':_0x5bfe10,'complete':_0x59447c},_0x3a90ff['next']===void 0x0&&(_0x3a90ff['next']=Qn),_0x3a90ff['error']===void 0x0&&(_0x3a90ff['error']=Qn),_0x3a90ff['complete']===void 0x0&&(_0x3a90ff['complete']=Qn);const _0xad3ac3=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3a90ff['error'](this['finalError']):_0x3a90ff['complete']();}catch{}}),this['observers']['push'](_0x3a90ff),_0xad3ac3;}['unsubscribeOne'](_0x4d7186){this['observers']===void 0x0||this['observers'][_0x4d7186]===void 0x0||(delete this['observers'][_0x4d7186],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xbf44ef){if(!this['finalized']){for(let _0x14547c=0x0;_0x14547c<this['observers']['length'];_0x14547c++)this['sendOne'](_0x14547c,_0xbf44ef);}}['sendOne'](_0x583c7b,_0x38f567){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x583c7b]!==void 0x0)try{_0x38f567(this['observers'][_0x583c7b]);}catch(_0x23d3fa){typeof console<'u'&&console['error']&&console['error'](_0x23d3fa);}});}['close'](_0x34cad4){this['finalized']||(this['finalized']=!0x0,_0x34cad4!==void 0x0&&(this['finalError']=_0x34cad4),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x31e4a1,_0x152c81){if(typeof _0x31e4a1!='object'||_0x31e4a1===null)return!0x1;for(const _0x3e8871 of _0x152c81)if(_0x3e8871 in _0x31e4a1&&typeof _0x31e4a1[_0x3e8871]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x395d99,_0x2109b3){return _0x395d99+'\x20failed:\x20'+_0x2109b3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x3a99a2){const _0x479429=[];let _0x321fc7=0x0;for(let _0x33b540=0x0;_0x33b540<_0x3a99a2['length'];_0x33b540++){let _0x17448f=_0x3a99a2['charCodeAt'](_0x33b540);if(_0x17448f>=0xd800&&_0x17448f<=0xdbff){const _0x6acc3d=_0x17448f-0xd800;_0x33b540++,f(_0x33b540<_0x3a99a2['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3dce47=_0x3a99a2['charCodeAt'](_0x33b540)-0xdc00;_0x17448f=0x10000+(_0x6acc3d<<0xa)+_0x3dce47;}_0x17448f<0x80?_0x479429[_0x321fc7++]=_0x17448f:_0x17448f<0x800?(_0x479429[_0x321fc7++]=_0x17448f>>0x6|0xc0,_0x479429[_0x321fc7++]=_0x17448f&0x3f|0x80):_0x17448f<0x10000?(_0x479429[_0x321fc7++]=_0x17448f>>0xc|0xe0,_0x479429[_0x321fc7++]=_0x17448f>>0x6&0x3f|0x80,_0x479429[_0x321fc7++]=_0x17448f&0x3f|0x80):(_0x479429[_0x321fc7++]=_0x17448f>>0x12|0xf0,_0x479429[_0x321fc7++]=_0x17448f>>0xc&0x3f|0x80,_0x479429[_0x321fc7++]=_0x17448f>>0x6&0x3f|0x80,_0x479429[_0x321fc7++]=_0x17448f&0x3f|0x80);}return _0x479429;},Pn=function(_0x1bd23f){let _0x44cd4d=0x0;for(let _0x1f487a=0x0;_0x1f487a<_0x1bd23f['length'];_0x1f487a++){const _0xa0e09d=_0x1bd23f['charCodeAt'](_0x1f487a);_0xa0e09d<0x80?_0x44cd4d++:_0xa0e09d<0x800?_0x44cd4d+=0x2:_0xa0e09d>=0xd800&&_0xa0e09d<=0xdbff?(_0x44cd4d+=0x4,_0x1f487a++):_0x44cd4d+=0x3;}return _0x44cd4d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xea7112){return _0xea7112&&_0xea7112['_delegate']?_0xea7112['_delegate']:_0xea7112;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x4f75fe){try{return(_0x4f75fe['startsWith']('http://')||_0x4f75fe['startsWith']('https://')?new URL(_0x4f75fe)['hostname']:_0x4f75fe)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x53e9e6){return(await fetch(_0x53e9e6,{'credentials':'include'}))['ok'];}class Me{constructor(_0x537daf,_0x2f54a6,_0x4be613){this['name']=_0x537daf,this['instanceFactory']=_0x2f54a6,this['type']=_0x4be613,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x31c5c4){return this['instantiationMode']=_0x31c5c4,this;}['setMultipleInstances'](_0x630e41){return this['multipleInstances']=_0x630e41,this;}['setServiceProps'](_0x55f404){return this['serviceProps']=_0x55f404,this;}['setInstanceCreatedCallback'](_0x84d729){return this['onInstanceCreated']=_0x84d729,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x2a7d19,_0x4080e4){this['name']=_0x2a7d19,this['container']=_0x4080e4,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5e6d9b){const _0x4d1363=this['normalizeInstanceIdentifier'](_0x5e6d9b);if(!this['instancesDeferred']['has'](_0x4d1363)){const _0x49a92b=new Ve();if(this['instancesDeferred']['set'](_0x4d1363,_0x49a92b),this['isInitialized'](_0x4d1363)||this['shouldAutoInitialize']())try{const _0x2e9f5e=this['getOrInitializeService']({'instanceIdentifier':_0x4d1363});_0x2e9f5e&&_0x49a92b['resolve'](_0x2e9f5e);}catch{}}return this['instancesDeferred']['get'](_0x4d1363)['promise'];}['getImmediate'](_0x31dee0){const _0x20c3d8=this['normalizeInstanceIdentifier'](_0x31dee0==null?void 0x0:_0x31dee0['identifier']),_0x3de679=(_0x31dee0==null?void 0x0:_0x31dee0['optional'])??!0x1;if(this['isInitialized'](_0x20c3d8)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x20c3d8});}catch(_0x27dc1e){if(_0x3de679)return null;throw _0x27dc1e;}else{if(_0x3de679)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1ca014){if(_0x1ca014['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1ca014['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1ca014,!!this['shouldAutoInitialize']()){if(Rc(_0x1ca014))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0xcad41f,_0x3de4cd]of this['instancesDeferred']['entries']()){const _0x7db4be=this['normalizeInstanceIdentifier'](_0xcad41f);try{const _0x2c1af6=this['getOrInitializeService']({'instanceIdentifier':_0x7db4be});_0x3de4cd['resolve'](_0x2c1af6);}catch{}}}}['clearInstance'](_0x552d1c=ke){this['instancesDeferred']['delete'](_0x552d1c),this['instancesOptions']['delete'](_0x552d1c),this['instances']['delete'](_0x552d1c);}async['delete'](){const _0x192e10=Array['from'](this['instances']['values']());await Promise['all']([..._0x192e10['filter'](_0x3a433a=>'INTERNAL'in _0x3a433a)['map'](_0x2e3e5a=>_0x2e3e5a['INTERNAL']['delete']()),..._0x192e10['filter'](_0x4508ca=>'_delete'in _0x4508ca)['map'](_0x2a556f=>_0x2a556f['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x56450f=ke){return this['instances']['has'](_0x56450f);}['getOptions'](_0x224b9b=ke){return this['instancesOptions']['get'](_0x224b9b)||{};}['initialize'](_0x15fed1={}){const {options:_0x4b30c9={}}=_0x15fed1,_0x37c2a3=this['normalizeInstanceIdentifier'](_0x15fed1['instanceIdentifier']);if(this['isInitialized'](_0x37c2a3))throw Error(this['name']+'('+_0x37c2a3+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3e3d80=this['getOrInitializeService']({'instanceIdentifier':_0x37c2a3,'options':_0x4b30c9});for(const [_0x828909,_0x114494]of this['instancesDeferred']['entries']()){const _0x3b783b=this['normalizeInstanceIdentifier'](_0x828909);_0x37c2a3===_0x3b783b&&_0x114494['resolve'](_0x3e3d80);}return _0x3e3d80;}['onInit'](_0x36f1c1,_0x427341){const _0x76c85d=this['normalizeInstanceIdentifier'](_0x427341),_0x517baa=this['onInitCallbacks']['get'](_0x76c85d)??new Set();_0x517baa['add'](_0x36f1c1),this['onInitCallbacks']['set'](_0x76c85d,_0x517baa);const _0x38847a=this['instances']['get'](_0x76c85d);return _0x38847a&&_0x36f1c1(_0x38847a,_0x76c85d),()=>{_0x517baa['delete'](_0x36f1c1);};}['invokeOnInitCallbacks'](_0x3008c2,_0x5ae10e){const _0xb4bd3a=this['onInitCallbacks']['get'](_0x5ae10e);if(_0xb4bd3a){for(const _0x4b120d of _0xb4bd3a)try{_0x4b120d(_0x3008c2,_0x5ae10e);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x16c636,options:_0x161a82={}}){let _0x1d56c3=this['instances']['get'](_0x16c636);if(!_0x1d56c3&&this['component']&&(_0x1d56c3=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x16c636),'options':_0x161a82}),this['instances']['set'](_0x16c636,_0x1d56c3),this['instancesOptions']['set'](_0x16c636,_0x161a82),this['invokeOnInitCallbacks'](_0x1d56c3,_0x16c636),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x16c636,_0x1d56c3);}catch{}return _0x1d56c3||null;}['normalizeInstanceIdentifier'](_0x547700=ke){return this['component']?this['component']['multipleInstances']?_0x547700:ke:_0x547700;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x1fee10){return _0x1fee10===ke?void 0x0:_0x1fee10;}function Rc(_0x3479e7){return _0x3479e7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5a48d9){this['name']=_0x5a48d9,this['providers']=new Map();}['addComponent'](_0x1f9729){const _0x469356=this['getProvider'](_0x1f9729['name']);if(_0x469356['isComponentSet']())throw new Error('Component\x20'+_0x1f9729['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x469356['setComponent'](_0x1f9729);}['addOrOverwriteComponent'](_0x5e8d7e){this['getProvider'](_0x5e8d7e['name'])['isComponentSet']()&&this['providers']['delete'](_0x5e8d7e['name']),this['addComponent'](_0x5e8d7e);}['getProvider'](_0x35f509){if(this['providers']['has'](_0x35f509))return this['providers']['get'](_0x35f509);const _0xd2c18=new Sc(_0x35f509,this);return this['providers']['set'](_0x35f509,_0xd2c18),_0xd2c18;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1a0f98){_0x1a0f98[_0x1a0f98['DEBUG']=0x0]='DEBUG',_0x1a0f98[_0x1a0f98['VERBOSE']=0x1]='VERBOSE',_0x1a0f98[_0x1a0f98['INFO']=0x2]='INFO',_0x1a0f98[_0x1a0f98['WARN']=0x3]='WARN',_0x1a0f98[_0x1a0f98['ERROR']=0x4]='ERROR',_0x1a0f98[_0x1a0f98['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xfcf0ba,_0x296db,..._0x36ea26)=>{if(_0x296db<_0xfcf0ba['logLevel'])return;const _0x2b2b6e=new Date()['toISOString'](),_0x591850=Pc[_0x296db];if(_0x591850)console[_0x591850]('['+_0x2b2b6e+']\x20\x20'+_0xfcf0ba['name']+':',..._0x36ea26);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x296db+')');};class xi{constructor(_0x59b58e){this['name']=_0x59b58e,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4a8ee1){if(!(_0x4a8ee1 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4a8ee1+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4a8ee1;}['setLogLevel'](_0x242dad){this['_logLevel']=typeof _0x242dad=='string'?kc[_0x242dad]:_0x242dad;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x15bbe6){if(typeof _0x15bbe6!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x15bbe6;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3b906c){this['_userLogHandler']=_0x3b906c;}['debug'](..._0x1db241){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1db241),this['_logHandler'](this,T['DEBUG'],..._0x1db241);}['log'](..._0x5017bf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5017bf),this['_logHandler'](this,T['VERBOSE'],..._0x5017bf);}['info'](..._0x1617b1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1617b1),this['_logHandler'](this,T['INFO'],..._0x1617b1);}['warn'](..._0x4ab6d5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4ab6d5),this['_logHandler'](this,T['WARN'],..._0x4ab6d5);}['error'](..._0x42561e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x42561e),this['_logHandler'](this,T['ERROR'],..._0x42561e);}}const Dc=(_0x2a9390,_0x33cbd7)=>_0x33cbd7['some'](_0x5951a4=>_0x2a9390 instanceof _0x5951a4);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x43bda8){const _0x59cd6d=new Promise((_0x2b4f85,_0x1d3ce3)=>{const _0x297156=()=>{_0x43bda8['removeEventListener']('success',_0x376649),_0x43bda8['removeEventListener']('error',_0x22bac5);},_0x376649=()=>{_0x2b4f85(_e(_0x43bda8['result'])),_0x297156();},_0x22bac5=()=>{_0x1d3ce3(_0x43bda8['error']),_0x297156();};_0x43bda8['addEventListener']('success',_0x376649),_0x43bda8['addEventListener']('error',_0x22bac5);});return _0x59cd6d['then'](_0x160447=>{_0x160447 instanceof IDBCursor&&Kr['set'](_0x160447,_0x43bda8);})['catch'](()=>{}),Fi['set'](_0x59cd6d,_0x43bda8),_0x59cd6d;}function Fc(_0x5a1f6a){if(ui['has'](_0x5a1f6a))return;const _0x3982a8=new Promise((_0x497202,_0x430828)=>{const _0x3deb2e=()=>{_0x5a1f6a['removeEventListener']('complete',_0x27d051),_0x5a1f6a['removeEventListener']('error',_0x8b55be),_0x5a1f6a['removeEventListener']('abort',_0x8b55be);},_0x27d051=()=>{_0x497202(),_0x3deb2e();},_0x8b55be=()=>{_0x430828(_0x5a1f6a['error']||new DOMException('AbortError','AbortError')),_0x3deb2e();};_0x5a1f6a['addEventListener']('complete',_0x27d051),_0x5a1f6a['addEventListener']('error',_0x8b55be),_0x5a1f6a['addEventListener']('abort',_0x8b55be);});ui['set'](_0x5a1f6a,_0x3982a8);}let di={'get'(_0x329e1c,_0x44a69b,_0x222758){if(_0x329e1c instanceof IDBTransaction){if(_0x44a69b==='done')return ui['get'](_0x329e1c);if(_0x44a69b==='objectStoreNames')return _0x329e1c['objectStoreNames']||Yr['get'](_0x329e1c);if(_0x44a69b==='store')return _0x222758['objectStoreNames'][0x1]?void 0x0:_0x222758['objectStore'](_0x222758['objectStoreNames'][0x0]);}return _e(_0x329e1c[_0x44a69b]);},'set'(_0x38541c,_0x28098c,_0x37660d){return _0x38541c[_0x28098c]=_0x37660d,!0x0;},'has'(_0x475775,_0x80825){return _0x475775 instanceof IDBTransaction&&(_0x80825==='done'||_0x80825==='store')?!0x0:_0x80825 in _0x475775;}};function Uc(_0x3e1a74){di=_0x3e1a74(di);}function Wc(_0x1156da){return _0x1156da===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x186b6f,..._0x16bd9e){const _0x29368e=_0x1156da['call'](Xn(this),_0x186b6f,..._0x16bd9e);return Yr['set'](_0x29368e,_0x186b6f['sort']?_0x186b6f['sort']():[_0x186b6f]),_e(_0x29368e);}:Lc()['includes'](_0x1156da)?function(..._0x3b9dfd){return _0x1156da['apply'](Xn(this),_0x3b9dfd),_e(Kr['get'](this));}:function(..._0x35f936){return _e(_0x1156da['apply'](Xn(this),_0x35f936));};}function Bc(_0x29110e){return typeof _0x29110e=='function'?Wc(_0x29110e):(_0x29110e instanceof IDBTransaction&&Fc(_0x29110e),Dc(_0x29110e,Mc())?new Proxy(_0x29110e,di):_0x29110e);}function _e(_0x2845f7){if(_0x2845f7 instanceof IDBRequest)return xc(_0x2845f7);if(Jn['has'](_0x2845f7))return Jn['get'](_0x2845f7);const _0x43500d=Bc(_0x2845f7);return _0x43500d!==_0x2845f7&&(Jn['set'](_0x2845f7,_0x43500d),Fi['set'](_0x43500d,_0x2845f7)),_0x43500d;}const Xn=_0x16bcf5=>Fi['get'](_0x16bcf5);function Vc(_0x4d9865,_0x3deded,{blocked:_0x2ea8de,upgrade:_0x15b600,blocking:_0x48f44d,terminated:_0x52e4ec}={}){const _0xee4d45=indexedDB['open'](_0x4d9865,_0x3deded),_0x346916=_e(_0xee4d45);return _0x15b600&&_0xee4d45['addEventListener']('upgradeneeded',_0x191867=>{_0x15b600(_e(_0xee4d45['result']),_0x191867['oldVersion'],_0x191867['newVersion'],_e(_0xee4d45['transaction']),_0x191867);}),_0x2ea8de&&_0xee4d45['addEventListener']('blocked',_0x348288=>_0x2ea8de(_0x348288['oldVersion'],_0x348288['newVersion'],_0x348288)),_0x346916['then'](_0x3368d7=>{_0x52e4ec&&_0x3368d7['addEventListener']('close',()=>_0x52e4ec()),_0x48f44d&&_0x3368d7['addEventListener']('versionchange',_0xe77350=>_0x48f44d(_0xe77350['oldVersion'],_0xe77350['newVersion'],_0xe77350));})['catch'](()=>{}),_0x346916;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x31c60f,_0xacdea6){if(!(_0x31c60f instanceof IDBDatabase&&!(_0xacdea6 in _0x31c60f)&&typeof _0xacdea6=='string'))return;if(Zn['get'](_0xacdea6))return Zn['get'](_0xacdea6);const _0x11d01b=_0xacdea6['replace'](/FromIndex$/,''),_0x5b0c9f=_0xacdea6!==_0x11d01b,_0x301116=$c['includes'](_0x11d01b);if(!(_0x11d01b in(_0x5b0c9f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x301116||Hc['includes'](_0x11d01b)))return;const _0x2db9d3=async function(_0x3ca9f0,..._0x9dc25){const _0x804456=this['transaction'](_0x3ca9f0,_0x301116?'readwrite':'readonly');let _0x391463=_0x804456['store'];return _0x5b0c9f&&(_0x391463=_0x391463['index'](_0x9dc25['shift']())),(await Promise['all']([_0x391463[_0x11d01b](..._0x9dc25),_0x301116&&_0x804456['done']]))[0x0];};return Zn['set'](_0xacdea6,_0x2db9d3),_0x2db9d3;}Uc(_0xeecf8d=>({..._0xeecf8d,'get':(_0x175540,_0x245e69,_0x12626c)=>Os(_0x175540,_0x245e69)||_0xeecf8d['get'](_0x175540,_0x245e69,_0x12626c),'has':(_0x428ac3,_0x5b32a0)=>!!Os(_0x428ac3,_0x5b32a0)||_0xeecf8d['has'](_0x428ac3,_0x5b32a0)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x3d5fb8){this['container']=_0x3d5fb8;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x107d4d=>{if(qc(_0x107d4d)){const _0x114d9b=_0x107d4d['getImmediate']();return _0x114d9b['library']+'/'+_0x114d9b['version'];}else return null;})['filter'](_0x3d1ed9=>_0x3d1ed9)['join']('\x20');}}function qc(_0x35f7db){const _0x20c63b=_0x35f7db['getComponent']();return(_0x20c63b==null?void 0x0:_0x20c63b['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4cc76d,_0x1e8248){try{_0x4cc76d['container']['addComponent'](_0x1e8248);}catch(_0x49fb58){re['debug']('Component\x20'+_0x1e8248['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4cc76d['name'],_0x49fb58);}}function et(_0x2d76a0){const _0x435f02=_0x2d76a0['name'];if(gi['has'](_0x435f02))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x435f02+'.'),!0x1;gi['set'](_0x435f02,_0x2d76a0);for(const _0x42f1cd of Le['values']())Ms(_0x42f1cd,_0x2d76a0);for(const _0xc5f3b of _i['values']())Ms(_0xc5f3b,_0x2d76a0);return!0x0;}function Ui(_0x1710be,_0x3ba73f){const _0x4eb5b6=_0x1710be['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4eb5b6&&_0x4eb5b6['triggerHeartbeat'](),_0x1710be['container']['getProvider'](_0x3ba73f);}function H(_0x92bf01){return _0x92bf01==null?!0x1:_0x92bf01['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5d89fc,_0x1cc4c4,_0x3dcece){this['_isDeleted']=!0x1,this['_options']={..._0x5d89fc},this['_config']={..._0x1cc4c4},this['_name']=_0x1cc4c4['name'],this['_automaticDataCollectionEnabled']=_0x1cc4c4['automaticDataCollectionEnabled'],this['_container']=_0x3dcece,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x399db7){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x399db7;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x204b7b){this['_isDeleted']=_0x204b7b;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x9c8553,_0x1e198f={}){let _0x36b567=_0x9c8553;typeof _0x1e198f!='object'&&(_0x1e198f={'name':_0x1e198f});const _0xfbcb02={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1e198f},_0x5eb51b=_0xfbcb02['name'];if(typeof _0x5eb51b!='string'||!_0x5eb51b)throw ge['create']('bad-app-name',{'appName':String(_0x5eb51b)});if(_0x36b567||(_0x36b567=$r()),!_0x36b567)throw ge['create']('no-options');const _0x79faca=Le['get'](_0x5eb51b);if(_0x79faca){if(De(_0x36b567,_0x79faca['options'])&&De(_0xfbcb02,_0x79faca['config']))return _0x79faca;throw ge['create']('duplicate-app',{'appName':_0x5eb51b});}const _0x23bcb9=new Ac(_0x5eb51b);for(const _0x31c974 of gi['values']())_0x23bcb9['addComponent'](_0x31c974);const _0x23c7b3=new Il(_0x36b567,_0xfbcb02,_0x23bcb9);return Le['set'](_0x5eb51b,_0x23c7b3),_0x23c7b3;}function Qr(_0x4c85c6=pi){const _0x49670f=Le['get'](_0x4c85c6);if(!_0x49670f&&_0x4c85c6===pi&&$r())return wl();if(!_0x49670f)throw ge['create']('no-app',{'appName':_0x4c85c6});return _0x49670f;}function l_(){return Array['from'](Le['values']());}async function h_(_0x30c5ef){let _0x206b62=!0x1;const _0x178a2d=_0x30c5ef['name'];Le['has'](_0x178a2d)?(_0x206b62=!0x0,Le['delete'](_0x178a2d)):_i['has'](_0x178a2d)&&_0x30c5ef['decRefCount']()<=0x0&&(_i['delete'](_0x178a2d),_0x206b62=!0x0),_0x206b62&&(await Promise['all'](_0x30c5ef['container']['getProviders']()['map'](_0x1c8a07=>_0x1c8a07['delete']())),_0x30c5ef['isDeleted']=!0x0);}function me(_0x5dcb1f,_0x55c8c7,_0x140ccb){let _0x11b8bf=vl[_0x5dcb1f]??_0x5dcb1f;_0x140ccb&&(_0x11b8bf+='-'+_0x140ccb);const _0x471320=_0x11b8bf['match'](/\s|\//),_0x459e2b=_0x55c8c7['match'](/\s|\//);if(_0x471320||_0x459e2b){const _0x3a9c0e=['Unable\x20to\x20register\x20library\x20\x22'+_0x11b8bf+'\x22\x20with\x20version\x20\x22'+_0x55c8c7+'\x22:'];_0x471320&&_0x3a9c0e['push']('library\x20name\x20\x22'+_0x11b8bf+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x471320&&_0x459e2b&&_0x3a9c0e['push']('and'),_0x459e2b&&_0x3a9c0e['push']('version\x20name\x20\x22'+_0x55c8c7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3a9c0e['join']('\x20'));return;}et(new Me(_0x11b8bf+'-version',()=>({'library':_0x11b8bf,'version':_0x55c8c7}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3f4fd2,_0xa7b31)=>{switch(_0xa7b31){case 0x0:try{_0x3f4fd2['createObjectStore'](Rt);}catch(_0x46ca7e){console['warn'](_0x46ca7e);}}}})['catch'](_0x4d56bf=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4d56bf['message']});})),ei;}async function Sl(_0x50f915){try{const _0x362cd2=(await Jr())['transaction'](Rt),_0x4ab142=await _0x362cd2['objectStore'](Rt)['get'](Xr(_0x50f915));return await _0x362cd2['done'],_0x4ab142;}catch(_0x3696ca){if(_0x3696ca instanceof Se)re['warn'](_0x3696ca['message']);else{const _0x29df62=ge['create']('idb-get',{'originalErrorMessage':_0x3696ca==null?void 0x0:_0x3696ca['message']});re['warn'](_0x29df62['message']);}}}async function Ls(_0x2861f7,_0x5a5317){try{const _0x23909a=(await Jr())['transaction'](Rt,'readwrite');await _0x23909a['objectStore'](Rt)['put'](_0x5a5317,Xr(_0x2861f7)),await _0x23909a['done'];}catch(_0x2e85c6){if(_0x2e85c6 instanceof Se)re['warn'](_0x2e85c6['message']);else{const _0x584553=ge['create']('idb-set',{'originalErrorMessage':_0x2e85c6==null?void 0x0:_0x2e85c6['message']});re['warn'](_0x584553['message']);}}}function Xr(_0x1a9adf){return _0x1a9adf['name']+'!'+_0x1a9adf['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x225514){this['container']=_0x225514,this['_heartbeatsCache']=null;const _0x5127b9=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5127b9),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1a1cd8=>(this['_heartbeatsCache']=_0x1a1cd8,_0x1a1cd8));}async['triggerHeartbeat'](){var _0x46abdf,_0xcc6740;try{const _0x24ce1d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x400781=xs();if(((_0x46abdf=this['_heartbeatsCache'])==null?void 0x0:_0x46abdf['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xcc6740=this['_heartbeatsCache'])==null?void 0x0:_0xcc6740['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x400781||this['_heartbeatsCache']['heartbeats']['some'](_0xdab587=>_0xdab587['date']===_0x400781))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x400781,'agent':_0x24ce1d}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x2541d5=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2541d5,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x193a9a){re['warn'](_0x193a9a);}}async['getHeartbeatsHeader'](){var _0x8c55fa;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x8c55fa=this['_heartbeatsCache'])==null?void 0x0:_0x8c55fa['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x44ab92=xs(),{heartbeatsToSend:_0x301313,unsentEntries:_0x57bde6}=kl(this['_heartbeatsCache']['heartbeats']),_0x43558c=an(JSON['stringify']({'version':0x2,'heartbeats':_0x301313}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x44ab92,_0x57bde6['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x57bde6,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x43558c;}catch(_0x11d573){return re['warn'](_0x11d573),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x14241d,_0x411116=bl){const _0x97da76=[];let _0x57c134=_0x14241d['slice']();for(const _0x1707fc of _0x14241d){const _0x1236f8=_0x97da76['find'](_0x284b01=>_0x284b01['agent']===_0x1707fc['agent']);if(_0x1236f8){if(_0x1236f8['dates']['push'](_0x1707fc['date']),Fs(_0x97da76)>_0x411116){_0x1236f8['dates']['pop']();break;}}else{if(_0x97da76['push']({'agent':_0x1707fc['agent'],'dates':[_0x1707fc['date']]}),Fs(_0x97da76)>_0x411116){_0x97da76['pop']();break;}}_0x57c134=_0x57c134['slice'](0x1);}return{'heartbeatsToSend':_0x97da76,'unsentEntries':_0x57c134};}class Nl{constructor(_0x26c46f){this['app']=_0x26c46f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x524243=await Sl(this['app']);return _0x524243!=null&&_0x524243['heartbeats']?_0x524243:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4e33b8){if(await this['_canUseIndexedDBPromise']){const _0x380ad0=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4e33b8['lastSentHeartbeatDate']??_0x380ad0['lastSentHeartbeatDate'],'heartbeats':_0x4e33b8['heartbeats']});}else return;}async['add'](_0x1537b2){if(await this['_canUseIndexedDBPromise']){const _0x40efed=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1537b2['lastSentHeartbeatDate']??_0x40efed['lastSentHeartbeatDate'],'heartbeats':[..._0x40efed['heartbeats'],..._0x1537b2['heartbeats']]});}else return;}}function Fs(_0x3f7f79){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x3f7f79}))['length'];}function Pl(_0x21db0b){if(_0x21db0b['length']===0x0)return-0x1;let _0x24479b=0x0,_0x4dfafa=_0x21db0b[0x0]['date'];for(let _0x5bff70=0x1;_0x5bff70<_0x21db0b['length'];_0x5bff70++)_0x21db0b[_0x5bff70]['date']<_0x4dfafa&&(_0x4dfafa=_0x21db0b[_0x5bff70]['date'],_0x24479b=_0x5bff70);return _0x24479b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x29700c){et(new Me('platform-logger',_0x6a56a3=>new Gc(_0x6a56a3),'PRIVATE')),et(new Me('heartbeat',_0x283582=>new Al(_0x283582),'PRIVATE')),me(fi,Ds,_0x29700c),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x18c207){Zr=_0x18c207;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x11bb29){this['domStorage_']=_0x11bb29,this['prefix_']='firebase:';}['set'](_0x53725c,_0x1644e2){_0x1644e2==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x53725c)):this['domStorage_']['setItem'](this['prefixedName_'](_0x53725c),O(_0x1644e2));}['get'](_0x3076ca){const _0x1884f8=this['domStorage_']['getItem'](this['prefixedName_'](_0x3076ca));return _0x1884f8==null?null:bt(_0x1884f8);}['remove'](_0x22860e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x22860e));}['prefixedName_'](_0x4d7185){return this['prefix_']+_0x4d7185;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x32b492,_0x34c853){_0x34c853==null?delete this['cache_'][_0x32b492]:this['cache_'][_0x32b492]=_0x34c853;}['get'](_0x52a70d){return Y(this['cache_'],_0x52a70d)?this['cache_'][_0x52a70d]:null;}['remove'](_0x698f0a){delete this['cache_'][_0x698f0a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x2849f8){try{if(typeof window<'u'&&typeof window[_0x2849f8]<'u'){const _0x542200=window[_0x2849f8];return _0x542200['setItem']('firebase:sentinel','cache'),_0x542200['removeItem']('firebase:sentinel'),new xl(_0x542200);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0xd6b44d=0x1;return function(){return _0xd6b44d++;};}()),no=function(_0xeb18ee){const _0x523c5f=Tc(_0xeb18ee),_0x1a4f4b=new Ec();_0x1a4f4b['update'](_0x523c5f);const _0x53438c=_0x1a4f4b['digest']();return Di['encodeByteArray'](_0x53438c);},Bt=function(..._0x3e7178){let _0x6358b0='';for(let _0x4caf35=0x0;_0x4caf35<_0x3e7178['length'];_0x4caf35++){const _0x5ef570=_0x3e7178[_0x4caf35];Array['isArray'](_0x5ef570)||_0x5ef570&&typeof _0x5ef570=='object'&&typeof _0x5ef570['length']=='number'?_0x6358b0+=Bt['apply'](null,_0x5ef570):typeof _0x5ef570=='object'?_0x6358b0+=O(_0x5ef570):_0x6358b0+=_0x5ef570,_0x6358b0+='\x20';}return _0x6358b0;};let Et=null,Vs=!0x0;const Wl=function(_0x2f18e3,_0x515409){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x4249c3){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3be89f=Bt['apply'](null,_0x4249c3);Et(_0x3be89f);}},Vt=function(_0xd928dc){return function(..._0x464130){L(_0xd928dc,..._0x464130);};},mi=function(..._0x36f8f3){const _0x565ba4='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x36f8f3);Qe['error'](_0x565ba4);},oe=function(..._0x5548ec){const _0x33d26c='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x5548ec);throw Qe['error'](_0x33d26c),new Error(_0x33d26c);},U=function(..._0xd03241){const _0x2c6486='FIREBASE\x20WARNING:\x20'+Bt(..._0xd03241);Qe['warn'](_0x2c6486);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x34df8d){return typeof _0x34df8d=='number'&&(_0x34df8d!==_0x34df8d||_0x34df8d===Number['POSITIVE_INFINITY']||_0x34df8d===Number['NEGATIVE_INFINITY']);},Vl=function(_0x368bd8){if(document['readyState']==='complete')_0x368bd8();else{let _0x38b385=!0x1;const _0x239c35=function(){if(!document['body']){setTimeout(_0x239c35,Math['floor'](0xa));return;}_0x38b385||(_0x38b385=!0x0,_0x368bd8());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x239c35,!0x1),window['addEventListener']('load',_0x239c35,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x239c35();}),window['attachEvent']('onload',_0x239c35));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x3f2938,_0x3f7931){if(_0x3f2938===_0x3f7931)return 0x0;if(_0x3f2938===xe||_0x3f7931===Ie)return-0x1;if(_0x3f7931===xe||_0x3f2938===Ie)return 0x1;{const _0x1ea69e=Hs(_0x3f2938),_0x3de7c7=Hs(_0x3f7931);return _0x1ea69e!==null?_0x3de7c7!==null?_0x1ea69e-_0x3de7c7===0x0?_0x3f2938['length']-_0x3f7931['length']:_0x1ea69e-_0x3de7c7:-0x1:_0x3de7c7!==null?0x1:_0x3f2938<_0x3f7931?-0x1:0x1;}},Hl=function(_0x27b93e,_0x2ca92f){return _0x27b93e===_0x2ca92f?0x0:_0x27b93e<_0x2ca92f?-0x1:0x1;},pt=function(_0x399af0,_0x257ea8){if(_0x257ea8&&_0x399af0 in _0x257ea8)return _0x257ea8[_0x399af0];throw new Error('Missing\x20required\x20key\x20('+_0x399af0+')\x20in\x20object:\x20'+O(_0x257ea8));},Bi=function(_0x2e1274){if(typeof _0x2e1274!='object'||_0x2e1274===null)return O(_0x2e1274);const _0x3d398d=[];for(const _0xe654d8 in _0x2e1274)_0x3d398d['push'](_0xe654d8);_0x3d398d['sort']();let _0x122297='{';for(let _0x4bb826=0x0;_0x4bb826<_0x3d398d['length'];_0x4bb826++)_0x4bb826!==0x0&&(_0x122297+=','),_0x122297+=O(_0x3d398d[_0x4bb826]),_0x122297+=':',_0x122297+=Bi(_0x2e1274[_0x3d398d[_0x4bb826]]);return _0x122297+='}',_0x122297;},io=function(_0x3f93f5,_0x1ec36e){const _0x5d8304=_0x3f93f5['length'];if(_0x5d8304<=_0x1ec36e)return[_0x3f93f5];const _0x304ebb=[];for(let _0x48dd2b=0x0;_0x48dd2b<_0x5d8304;_0x48dd2b+=_0x1ec36e)_0x48dd2b+_0x1ec36e>_0x5d8304?_0x304ebb['push'](_0x3f93f5['substring'](_0x48dd2b,_0x5d8304)):_0x304ebb['push'](_0x3f93f5['substring'](_0x48dd2b,_0x48dd2b+_0x1ec36e));return _0x304ebb;};function x(_0x5cc45f,_0x16ab73){for(const _0x3ed6d1 in _0x5cc45f)_0x5cc45f['hasOwnProperty'](_0x3ed6d1)&&_0x16ab73(_0x3ed6d1,_0x5cc45f[_0x3ed6d1]);}const so=function(_0x37c710){f(!Wi(_0x37c710),'Invalid\x20JSON\x20number');const _0x5ae610=0xb,_0x2ba75c=0x34,_0x396ba9=(0x1<<_0x5ae610-0x1)-0x1;let _0x53d417,_0x112465,_0x170951,_0x24f52c,_0x8860bf;_0x37c710===0x0?(_0x112465=0x0,_0x170951=0x0,_0x53d417=0x1/_0x37c710===-0x1/0x0?0x1:0x0):(_0x53d417=_0x37c710<0x0,_0x37c710=Math['abs'](_0x37c710),_0x37c710>=Math['pow'](0x2,0x1-_0x396ba9)?(_0x24f52c=Math['min'](Math['floor'](Math['log'](_0x37c710)/Math['LN2']),_0x396ba9),_0x112465=_0x24f52c+_0x396ba9,_0x170951=Math['round'](_0x37c710*Math['pow'](0x2,_0x2ba75c-_0x24f52c)-Math['pow'](0x2,_0x2ba75c))):(_0x112465=0x0,_0x170951=Math['round'](_0x37c710/Math['pow'](0x2,0x1-_0x396ba9-_0x2ba75c))));const _0xcf2a3=[];for(_0x8860bf=_0x2ba75c;_0x8860bf;_0x8860bf-=0x1)_0xcf2a3['push'](_0x170951%0x2?0x1:0x0),_0x170951=Math['floor'](_0x170951/0x2);for(_0x8860bf=_0x5ae610;_0x8860bf;_0x8860bf-=0x1)_0xcf2a3['push'](_0x112465%0x2?0x1:0x0),_0x112465=Math['floor'](_0x112465/0x2);_0xcf2a3['push'](_0x53d417?0x1:0x0),_0xcf2a3['reverse']();const _0x334787=_0xcf2a3['join']('');let _0x5b3b75='';for(_0x8860bf=0x0;_0x8860bf<0x40;_0x8860bf+=0x8){let _0x2b423b=parseInt(_0x334787['substr'](_0x8860bf,0x8),0x2)['toString'](0x10);_0x2b423b['length']===0x1&&(_0x2b423b='0'+_0x2b423b),_0x5b3b75=_0x5b3b75+_0x2b423b;}return _0x5b3b75['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x182061,_0x4a4311){let _0x37520a='Unknown\x20Error';_0x182061==='too_big'?_0x37520a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x182061==='permission_denied'?_0x37520a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x182061==='unavailable'&&(_0x37520a='The\x20service\x20is\x20unavailable');const _0x4d41aa=new Error(_0x182061+'\x20at\x20'+_0x4a4311['_path']['toString']()+':\x20'+_0x37520a);return _0x4d41aa['code']=_0x182061['toUpperCase'](),_0x4d41aa;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x31733a){if(zl['test'](_0x31733a)){const _0x1ce885=Number(_0x31733a);if(_0x1ce885>=jl&&_0x1ce885<=Kl)return _0x1ce885;}return null;},lt=function(_0x3ff5be){try{_0x3ff5be();}catch(_0x569abd){setTimeout(()=>{const _0x12e85e=_0x569abd['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x12e85e),_0x569abd;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x2f60cc,_0x1a1ce3){const _0x4bbf36=setTimeout(_0x2f60cc,_0x1a1ce3);return typeof _0x4bbf36=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4bbf36):typeof _0x4bbf36=='object'&&_0x4bbf36['unref']&&_0x4bbf36['unref'](),_0x4bbf36;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x306b5f,_0x556708){this['appCheckProvider']=_0x556708,this['appName']=_0x306b5f['name'],H(_0x306b5f)&&_0x306b5f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x306b5f['settings']['appCheckToken']),this['appCheck']=_0x556708==null?void 0x0:_0x556708['getImmediate']({'optional':!0x0}),this['appCheck']||_0x556708==null||_0x556708['get']()['then'](_0x5ba5e0=>this['appCheck']=_0x5ba5e0);}['getToken'](_0xe404cb){if(this['serverAppAppCheckToken']){if(_0xe404cb)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xe404cb):new Promise((_0x47ec27,_0x3c9f40)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xe404cb)['then'](_0x47ec27,_0x3c9f40):_0x47ec27(null);},0x0);});}['addTokenChangeListener'](_0x2162e0){var _0x5cd939;(_0x5cd939=this['appCheckProvider'])==null||_0x5cd939['get']()['then'](_0x43192a=>_0x43192a['addTokenListener'](_0x2162e0));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0xa29c33,_0x58d812,_0x53f7c5){this['appName_']=_0xa29c33,this['firebaseOptions_']=_0x58d812,this['authProvider_']=_0x53f7c5,this['auth_']=null,this['auth_']=_0x53f7c5['getImmediate']({'optional':!0x0}),this['auth_']||_0x53f7c5['onInit'](_0x4adb31=>this['auth_']=_0x4adb31);}['getToken'](_0x50f9c7){return this['auth_']?this['auth_']['getToken'](_0x50f9c7)['catch'](_0x5d4316=>_0x5d4316&&_0x5d4316['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5d4316)):new Promise((_0x3333f1,_0x17ef71)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x50f9c7)['then'](_0x3333f1,_0x17ef71):_0x3333f1(null);},0x0);});}['addTokenChangeListener'](_0x2ab2ab){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2ab2ab):this['authProvider_']['get']()['then'](_0x195a7c=>_0x195a7c['addAuthTokenListener'](_0x2ab2ab));}['removeTokenChangeListener'](_0x2ed2a3){this['authProvider_']['get']()['then'](_0x1fec6b=>_0x1fec6b['removeAuthTokenListener'](_0x2ed2a3));}['notifyForInvalidToken'](){let _0x36946c='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x36946c+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x36946c+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x36946c+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x36946c);}}class tn{constructor(_0x17e223){this['accessToken']=_0x17e223;}['getToken'](_0x33c77c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xe597ca){_0xe597ca(this['accessToken']);}['removeTokenChangeListener'](_0x4e4c4b){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0xd01fd,_0x27d524,_0x140d4e,_0x24f57b,_0xfe1154=!0x1,_0x587f2b='',_0x5122e1=!0x1,_0xaf8f8e=!0x1,_0x56efc9=null){this['secure']=_0x27d524,this['namespace']=_0x140d4e,this['webSocketOnly']=_0x24f57b,this['nodeAdmin']=_0xfe1154,this['persistenceKey']=_0x587f2b,this['includeNamespaceInQueryParams']=_0x5122e1,this['isUsingEmulator']=_0xaf8f8e,this['emulatorOptions']=_0x56efc9,this['_host']=_0xd01fd['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0xd01fd)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x158ff0){_0x158ff0!==this['internalHost']&&(this['internalHost']=_0x158ff0,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x107d47=this['toURLString']();return this['persistenceKey']&&(_0x107d47+='<'+this['persistenceKey']+'>'),_0x107d47;}['toURLString'](){const _0x18a3b2=this['secure']?'https://':'http://',_0x3e44d0=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x18a3b2+this['host']+'/'+_0x3e44d0;}}function Xl(_0x45fbbd){return _0x45fbbd['host']!==_0x45fbbd['internalHost']||_0x45fbbd['isCustomHost']()||_0x45fbbd['includeNamespaceInQueryParams'];}function go(_0x378103,_0x3a5be1,_0x417385){f(typeof _0x3a5be1=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x417385=='object','typeof\x20params\x20must\x20==\x20object');let _0x41c19d;if(_0x3a5be1===fo)_0x41c19d=(_0x378103['secure']?'wss://':'ws://')+_0x378103['internalHost']+'/.ws?';else{if(_0x3a5be1===po)_0x41c19d=(_0x378103['secure']?'https://':'http://')+_0x378103['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3a5be1);}Xl(_0x378103)&&(_0x417385['ns']=_0x378103['namespace']);const _0x444b19=[];return x(_0x417385,(_0x504c0f,_0x5eb1af)=>{_0x444b19['push'](_0x504c0f+'='+_0x5eb1af);}),_0x41c19d+_0x444b19['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x2becb4,_0x599af3=0x1){Y(this['counters_'],_0x2becb4)||(this['counters_'][_0x2becb4]=0x0),this['counters_'][_0x2becb4]+=_0x599af3;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0xf1d430){const _0x56e4cc=_0xf1d430['toString']();return ti[_0x56e4cc]||(ti[_0x56e4cc]=new Zl()),ti[_0x56e4cc];}function eh(_0x2cf8dd,_0x35710f){const _0x2ce437=_0x2cf8dd['toString']();return ni[_0x2ce437]||(ni[_0x2ce437]=_0x35710f()),ni[_0x2ce437];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5a2ee9){this['onMessage_']=_0x5a2ee9,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x7e44f6,_0x2604c6){this['closeAfterResponse']=_0x7e44f6,this['onClose']=_0x2604c6,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4851f9,_0x4002df){for(this['pendingResponses'][_0x4851f9]=_0x4002df;this['pendingResponses'][this['currentResponseNum']];){const _0x172411=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x8b19c3=0x0;_0x8b19c3<_0x172411['length'];++_0x8b19c3)_0x172411[_0x8b19c3]&&lt(()=>{this['onMessage_'](_0x172411[_0x8b19c3]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x29f876,_0x13087f,_0x282112,_0x30f5a0,_0x436be8,_0x53b387,_0x574379){this['connId']=_0x29f876,this['repoInfo']=_0x13087f,this['applicationId']=_0x282112,this['appCheckToken']=_0x30f5a0,this['authToken']=_0x436be8,this['transportSessionId']=_0x53b387,this['lastSessionId']=_0x574379,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x29f876),this['stats_']=Hi(_0x13087f),this['urlFn']=_0x3bd51f=>(this['appCheckToken']&&(_0x3bd51f[yi]=this['appCheckToken']),go(_0x13087f,po,_0x3bd51f));}['open'](_0xf09646,_0x59d5c7){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x59d5c7,this['myPacketOrderer']=new th(_0xf09646),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0xb7cbac)=>{const [_0x4d94ea,_0x50596c,_0xd20d0f,_0x274202,_0x43145c]=_0xb7cbac;if(this['incrementIncomingBytes_'](_0xb7cbac),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4d94ea===$s)this['id']=_0x50596c,this['password']=_0xd20d0f;else{if(_0x4d94ea===nh)_0x50596c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x50596c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4d94ea);}}},(..._0x2ddf01)=>{const [_0xbfdab8,_0x25b9a3]=_0x2ddf01;this['incrementIncomingBytes_'](_0x2ddf01),this['myPacketOrderer']['handleResponse'](_0xbfdab8,_0x25b9a3);},()=>{this['onClosed_']();},this['urlFn']);const _0x4c1735={};_0x4c1735[$s]='t',_0x4c1735[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4c1735[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4c1735[ro]=Vi,this['transportSessionId']&&(_0x4c1735[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4c1735[ho]=this['lastSessionId']),this['applicationId']&&(_0x4c1735[uo]=this['applicationId']),this['appCheckToken']&&(_0x4c1735[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4c1735[ao]=co);const _0x2b9624=this['urlFn'](_0x4c1735);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2b9624),this['scriptTagHolder']['addTag'](_0x2b9624,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x411fcc){const _0x3c1e8a=O(_0x411fcc);this['bytesSent']+=_0x3c1e8a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3c1e8a['length']);const _0x1b3323=Br(_0x3c1e8a),_0x531361=io(_0x1b3323,hh);for(let _0x529db8=0x0;_0x529db8<_0x531361['length'];_0x529db8++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x531361['length'],_0x531361[_0x529db8]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x168108,_0x55fccc){this['myDisconnFrame']=document['createElement']('iframe');const _0x100cac={};_0x100cac[lh]='t',_0x100cac[mo]=_0x168108,_0x100cac[yo]=_0x55fccc,this['myDisconnFrame']['src']=this['urlFn'](_0x100cac),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xca9b6b){const _0x41bcf4=O(_0xca9b6b)['length'];this['bytesReceived']+=_0x41bcf4,this['stats_']['incrementCounter']('bytes_received',_0x41bcf4);}}class $i{constructor(_0x61ec07,_0x3cbf0a,_0x1281e5,_0x2e6ff8){this['onDisconnect']=_0x1281e5,this['urlFn']=_0x2e6ff8,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x61ec07,window[sh+this['uniqueCallbackIdentifier']]=_0x3cbf0a,this['myIFrame']=$i['createIFrame_']();let _0x2bf823='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2bf823='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x137000='<html><body>'+_0x2bf823+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x137000),this['myIFrame']['doc']['close']();}catch(_0xfaf99c){L('frame\x20writing\x20exception'),_0xfaf99c['stack']&&L(_0xfaf99c['stack']),L(_0xfaf99c);}}}static['createIFrame_'](){const _0x4fec67=document['createElement']('iframe');if(_0x4fec67['style']['display']='none',document['body']){document['body']['appendChild'](_0x4fec67);try{_0x4fec67['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x217390=document['domain'];_0x4fec67['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x217390+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4fec67['contentDocument']?_0x4fec67['doc']=_0x4fec67['contentDocument']:_0x4fec67['contentWindow']?_0x4fec67['doc']=_0x4fec67['contentWindow']['document']:_0x4fec67['document']&&(_0x4fec67['doc']=_0x4fec67['document']),_0x4fec67;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x50fe83=this['onDisconnect'];_0x50fe83&&(this['onDisconnect']=null,_0x50fe83());}['startLongPoll'](_0x4cc92e,_0x37fa2f){for(this['myID']=_0x4cc92e,this['myPW']=_0x37fa2f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x12f7d9={};_0x12f7d9[mo]=this['myID'],_0x12f7d9[yo]=this['myPW'],_0x12f7d9[vo]=this['currentSerial'];let _0x29c906=this['urlFn'](_0x12f7d9),_0x2f0f4a='',_0x1b74b1=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x2f0f4a['length']<=Eo;){const _0x4f2ea0=this['pendingSegs']['shift']();_0x2f0f4a=_0x2f0f4a+'&'+oh+_0x1b74b1+'='+_0x4f2ea0['seg']+'&'+ah+_0x1b74b1+'='+_0x4f2ea0['ts']+'&'+ch+_0x1b74b1+'='+_0x4f2ea0['d'],_0x1b74b1++;}return _0x29c906=_0x29c906+_0x2f0f4a,this['addLongPollTag_'](_0x29c906,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x55bc0b,_0xcec041,_0x47855e){this['pendingSegs']['push']({'seg':_0x55bc0b,'ts':_0xcec041,'d':_0x47855e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1e6eb9,_0x240523){this['outstandingRequests']['add'](_0x240523);const _0x22b0d5=()=>{this['outstandingRequests']['delete'](_0x240523),this['newRequest_']();},_0x375ede=setTimeout(_0x22b0d5,Math['floor'](uh)),_0x67ef6=()=>{clearTimeout(_0x375ede),_0x22b0d5();};this['addTag'](_0x1e6eb9,_0x67ef6);}['addTag'](_0x31801d,_0x4e44aa){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4c1872=this['myIFrame']['doc']['createElement']('script');_0x4c1872['type']='text/javascript',_0x4c1872['async']=!0x0,_0x4c1872['src']=_0x31801d,_0x4c1872['onload']=_0x4c1872['onreadystatechange']=function(){const _0x55d762=_0x4c1872['readyState'];(!_0x55d762||_0x55d762==='loaded'||_0x55d762==='complete')&&(_0x4c1872['onload']=_0x4c1872['onreadystatechange']=null,_0x4c1872['parentNode']&&_0x4c1872['parentNode']['removeChild'](_0x4c1872),_0x4e44aa());},_0x4c1872['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x31801d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4c1872);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x354a55,_0x4813d5,_0x10e787,_0x379241,_0x16c0b7,_0x4fa89a,_0x582bc8){this['connId']=_0x354a55,this['applicationId']=_0x10e787,this['appCheckToken']=_0x379241,this['authToken']=_0x16c0b7,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x4813d5),this['connURL']=G['connectionURL_'](_0x4813d5,_0x4fa89a,_0x582bc8,_0x379241,_0x10e787),this['nodeAdmin']=_0x4813d5['nodeAdmin'];}static['connectionURL_'](_0x2e12b8,_0x392f52,_0x1b4449,_0x33b0d2,_0x51f904){const _0x3cc80b={};return _0x3cc80b[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3cc80b[ao]=co),_0x392f52&&(_0x3cc80b[oo]=_0x392f52),_0x1b4449&&(_0x3cc80b[ho]=_0x1b4449),_0x33b0d2&&(_0x3cc80b[yi]=_0x33b0d2),_0x51f904&&(_0x3cc80b[uo]=_0x51f904),go(_0x2e12b8,fo,_0x3cc80b);}['open'](_0x570c5d,_0xae94e8){this['onDisconnect']=_0xae94e8,this['onMessage']=_0x570c5d,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x2ad555;dc(),this['mySock']=new hn(this['connURL'],[],_0x2ad555);}catch(_0x37c53a){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x506f9f=_0x37c53a['message']||_0x37c53a['data'];_0x506f9f&&this['log_'](_0x506f9f),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x423e50=>{this['handleIncomingFrame'](_0x423e50);},this['mySock']['onerror']=_0x40373c=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x249e1d=_0x40373c['message']||_0x40373c['data'];_0x249e1d&&this['log_'](_0x249e1d),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xc33edc=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x419881=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x512f82=navigator['userAgent']['match'](_0x419881);_0x512f82&&_0x512f82['length']>0x1&&parseFloat(_0x512f82[0x1])<4.4&&(_0xc33edc=!0x0);}return!_0xc33edc&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x37f4f2){if(this['frames']['push'](_0x37f4f2),this['frames']['length']===this['totalFrames']){const _0x528afa=this['frames']['join']('');this['frames']=null;const _0x491d48=bt(_0x528afa);this['onMessage'](_0x491d48);}}['handleNewFrameCount_'](_0x1322d2){this['totalFrames']=_0x1322d2,this['frames']=[];}['extractFrameCount_'](_0x3d6a2a){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3d6a2a['length']<=0x6){const _0x1399de=Number(_0x3d6a2a);if(!isNaN(_0x1399de))return this['handleNewFrameCount_'](_0x1399de),null;}return this['handleNewFrameCount_'](0x1),_0x3d6a2a;}['handleIncomingFrame'](_0x4a874c){if(this['mySock']===null)return;const _0x27ad86=_0x4a874c['data'];if(this['bytesReceived']+=_0x27ad86['length'],this['stats_']['incrementCounter']('bytes_received',_0x27ad86['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x27ad86);else{const _0x5d71b1=this['extractFrameCount_'](_0x27ad86);_0x5d71b1!==null&&this['appendFrame_'](_0x5d71b1);}}['send'](_0x3558ca){this['resetKeepAlive']();const _0x210987=O(_0x3558ca);this['bytesSent']+=_0x210987['length'],this['stats_']['incrementCounter']('bytes_sent',_0x210987['length']);const _0x5e7aeb=io(_0x210987,fh);_0x5e7aeb['length']>0x1&&this['sendString_'](String(_0x5e7aeb['length']));for(let _0x5adfd9=0x0;_0x5adfd9<_0x5e7aeb['length'];_0x5adfd9++)this['sendString_'](_0x5e7aeb[_0x5adfd9]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x405f12){try{this['mySock']['send'](_0x405f12);}catch(_0x6ce7e2){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x6ce7e2['message']||_0x6ce7e2['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5ecc55){this['initTransports_'](_0x5ecc55);}['initTransports_'](_0x51a3c6){const _0x1f36a6=G&&G['isAvailable']();let _0x146171=_0x1f36a6&&!G['previouslyFailed']();if(_0x51a3c6['webSocketOnly']&&(_0x1f36a6||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x146171=!0x0),_0x146171)this['transports_']=[G];else{const _0x184988=this['transports_']=[];for(const _0x21dd13 of At['ALL_TRANSPORTS'])_0x21dd13&&_0x21dd13['isAvailable']()&&_0x184988['push'](_0x21dd13);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x5f3302,_0x53b780,_0x35a046,_0x465a00,_0x26773e,_0x164127,_0x2841bf,_0x275957,_0x517a63,_0x4a884c){this['id']=_0x5f3302,this['repoInfo_']=_0x53b780,this['applicationId_']=_0x35a046,this['appCheckToken_']=_0x465a00,this['authToken_']=_0x26773e,this['onMessage_']=_0x164127,this['onReady_']=_0x2841bf,this['onDisconnect_']=_0x275957,this['onKill_']=_0x517a63,this['lastSessionId']=_0x4a884c,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x53b780),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x45b763=this['transportManager_']['initialTransport']();this['conn_']=new _0x45b763(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x45b763['responsesRequiredToBeHealthy']||0x0;const _0x30d803=this['connReceiver_'](this['conn_']),_0x207ee4=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x30d803,_0x207ee4);},Math['floor'](0x0));const _0x5f1ef3=_0x45b763['healthyTimeout']||0x0;_0x5f1ef3>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5f1ef3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x57e01a){return _0x3786c1=>{_0x57e01a===this['conn_']?this['onConnectionLost_'](_0x3786c1):_0x57e01a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x438d0a){return _0x1dfee4=>{this['state_']!==0x2&&(_0x438d0a===this['rx_']?this['onPrimaryMessageReceived_'](_0x1dfee4):_0x438d0a===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1dfee4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x319ac7){const _0x22aee2={'t':'d','d':_0x319ac7};this['sendData_'](_0x22aee2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x14a69d){if(ii in _0x14a69d){const _0x42bbed=_0x14a69d[ii];_0x42bbed===js?this['upgradeIfSecondaryHealthy_']():_0x42bbed===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x42bbed===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x21517d){const _0x3e851d=pt('t',_0x21517d),_0x5057d5=pt('d',_0x21517d);if(_0x3e851d==='c')this['onSecondaryControl_'](_0x5057d5);else{if(_0x3e851d==='d')this['pendingDataMessages']['push'](_0x5057d5);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3e851d);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x500783){const _0x3f396a=pt('t',_0x500783),_0x4160b1=pt('d',_0x500783);_0x3f396a==='c'?this['onControl_'](_0x4160b1):_0x3f396a==='d'&&this['onDataMessage_'](_0x4160b1);}['onDataMessage_'](_0x46b9c1){this['onPrimaryResponse_'](),this['onMessage_'](_0x46b9c1);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1391b3){const _0x5a7ce3=pt(ii,_0x1391b3);if(Gs in _0x1391b3){const _0x564771=_0x1391b3[Gs];if(_0x5a7ce3===Ih){const _0x2a4a5e={..._0x564771};this['repoInfo_']['isUsingEmulator']&&(_0x2a4a5e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2a4a5e);}else{if(_0x5a7ce3===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1ba395=0x0;_0x1ba395<this['pendingDataMessages']['length'];++_0x1ba395)this['onDataMessage_'](this['pendingDataMessages'][_0x1ba395]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5a7ce3===vh?this['onConnectionShutdown_'](_0x564771):_0x5a7ce3===qs?this['onReset_'](_0x564771):_0x5a7ce3===Eh?mi('Server\x20Error:\x20'+_0x564771):_0x5a7ce3===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x5a7ce3);}}}['onHandshake_'](_0xda5b39){const _0x284d41=_0xda5b39['ts'],_0x32f72c=_0xda5b39['v'],_0x5d7c01=_0xda5b39['h'];this['sessionId']=_0xda5b39['s'],this['repoInfo_']['host']=_0x5d7c01,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x284d41),Vi!==_0x32f72c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x86e675=this['transportManager_']['upgradeTransport']();_0x86e675&&this['startUpgrade_'](_0x86e675);}['startUpgrade_'](_0x1ae493){this['secondaryConn_']=new _0x1ae493(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1ae493['responsesRequiredToBeHealthy']||0x0;const _0x270313=this['connReceiver_'](this['secondaryConn_']),_0x2a31e5=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x270313,_0x2a31e5),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x924d80){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x924d80),this['repoInfo_']['host']=_0x924d80,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x53a2a3,_0x16b63e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x53a2a3,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x16b63e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5949d0=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5949d0||this['rx_']===_0x5949d0)&&this['close']();}['onConnectionLost_'](_0x2cfa24){this['conn_']=null,!_0x2cfa24&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3e36d2){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3e36d2),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x198d36){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x198d36);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x4ea477,_0x39cc00,_0x5cd260,_0x147780){}['merge'](_0x50bcca,_0x4aa745,_0x27b484,_0x93591d){}['refreshAuthToken'](_0x11b464){}['refreshAppCheckToken'](_0x53e307){}['onDisconnectPut'](_0x2e4d45,_0xd12055,_0x4f17e4){}['onDisconnectMerge'](_0x1ab245,_0x228424,_0x225443){}['onDisconnectCancel'](_0x2090d4,_0x3fc6cf){}['reportStats'](_0x145902){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2f0598){this['allowedEvents_']=_0x2f0598,this['listeners_']={},f(Array['isArray'](_0x2f0598)&&_0x2f0598['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3660c6,..._0x17096f){if(Array['isArray'](this['listeners_'][_0x3660c6])){const _0x5ed082=[...this['listeners_'][_0x3660c6]];for(let _0x44d26c=0x0;_0x44d26c<_0x5ed082['length'];_0x44d26c++)_0x5ed082[_0x44d26c]['callback']['apply'](_0x5ed082[_0x44d26c]['context'],_0x17096f);}}['on'](_0x43c80e,_0x38bcaa,_0x4e4fbf){this['validateEventType_'](_0x43c80e),this['listeners_'][_0x43c80e]=this['listeners_'][_0x43c80e]||[],this['listeners_'][_0x43c80e]['push']({'callback':_0x38bcaa,'context':_0x4e4fbf});const _0x13526e=this['getInitialEvent'](_0x43c80e);_0x13526e&&_0x38bcaa['apply'](_0x4e4fbf,_0x13526e);}['off'](_0x17f5aa,_0x484433,_0x271e0d){this['validateEventType_'](_0x17f5aa);const _0x957f9=this['listeners_'][_0x17f5aa]||[];for(let _0x29c289=0x0;_0x29c289<_0x957f9['length'];_0x29c289++)if(_0x957f9[_0x29c289]['callback']===_0x484433&&(!_0x271e0d||_0x271e0d===_0x957f9[_0x29c289]['context'])){_0x957f9['splice'](_0x29c289,0x1);return;}}['validateEventType_'](_0x26a081){f(this['allowedEvents_']['find'](_0x5ad12f=>_0x5ad12f===_0x26a081),'Unknown\x20event:\x20'+_0x26a081);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2ea0fa){return f(_0x2ea0fa==='online','Unknown\x20event\x20type:\x20'+_0x2ea0fa),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x3ae6ab,_0x3b24da){if(_0x3b24da===void 0x0){this['pieces_']=_0x3ae6ab['split']('/');let _0x35fde0=0x0;for(let _0x1b40ca=0x0;_0x1b40ca<this['pieces_']['length'];_0x1b40ca++)this['pieces_'][_0x1b40ca]['length']>0x0&&(this['pieces_'][_0x35fde0]=this['pieces_'][_0x1b40ca],_0x35fde0++);this['pieces_']['length']=_0x35fde0,this['pieceNum_']=0x0;}else this['pieces_']=_0x3ae6ab,this['pieceNum_']=_0x3b24da;}['toString'](){let _0xb211fa='';for(let _0x12ca49=this['pieceNum_'];_0x12ca49<this['pieces_']['length'];_0x12ca49++)this['pieces_'][_0x12ca49]!==''&&(_0xb211fa+='/'+this['pieces_'][_0x12ca49]);return _0xb211fa||'/';}}function w(){return new C('');}function y(_0x431b8e){return _0x431b8e['pieceNum_']>=_0x431b8e['pieces_']['length']?null:_0x431b8e['pieces_'][_0x431b8e['pieceNum_']];}function we(_0xda1fcd){return _0xda1fcd['pieces_']['length']-_0xda1fcd['pieceNum_'];}function b(_0xd004cd){let _0x3cbb25=_0xd004cd['pieceNum_'];return _0x3cbb25<_0xd004cd['pieces_']['length']&&_0x3cbb25++,new C(_0xd004cd['pieces_'],_0x3cbb25);}function Gi(_0x5e15e3){return _0x5e15e3['pieceNum_']<_0x5e15e3['pieces_']['length']?_0x5e15e3['pieces_'][_0x5e15e3['pieces_']['length']-0x1]:null;}function Ch(_0x45e41b){let _0x607d82='';for(let _0x8dcb1d=_0x45e41b['pieceNum_'];_0x8dcb1d<_0x45e41b['pieces_']['length'];_0x8dcb1d++)_0x45e41b['pieces_'][_0x8dcb1d]!==''&&(_0x607d82+='/'+encodeURIComponent(String(_0x45e41b['pieces_'][_0x8dcb1d])));return _0x607d82||'/';}function kt(_0x1b0efd,_0x33eef3=0x0){return _0x1b0efd['pieces_']['slice'](_0x1b0efd['pieceNum_']+_0x33eef3);}function To(_0x9e7bad){if(_0x9e7bad['pieceNum_']>=_0x9e7bad['pieces_']['length'])return null;const _0x4db919=[];for(let _0x2d4200=_0x9e7bad['pieceNum_'];_0x2d4200<_0x9e7bad['pieces_']['length']-0x1;_0x2d4200++)_0x4db919['push'](_0x9e7bad['pieces_'][_0x2d4200]);return new C(_0x4db919,0x0);}function A(_0x59854b,_0x2609cf){const _0x49f28e=[];for(let _0x188f05=_0x59854b['pieceNum_'];_0x188f05<_0x59854b['pieces_']['length'];_0x188f05++)_0x49f28e['push'](_0x59854b['pieces_'][_0x188f05]);if(_0x2609cf instanceof C){for(let _0x17c346=_0x2609cf['pieceNum_'];_0x17c346<_0x2609cf['pieces_']['length'];_0x17c346++)_0x49f28e['push'](_0x2609cf['pieces_'][_0x17c346]);}else{const _0x4f0f1d=_0x2609cf['split']('/');for(let _0x57cdd8=0x0;_0x57cdd8<_0x4f0f1d['length'];_0x57cdd8++)_0x4f0f1d[_0x57cdd8]['length']>0x0&&_0x49f28e['push'](_0x4f0f1d[_0x57cdd8]);}return new C(_0x49f28e,0x0);}function v(_0x12ed28){return _0x12ed28['pieceNum_']>=_0x12ed28['pieces_']['length'];}function F(_0xf2f6a9,_0xb3298e){const _0x17dfe1=y(_0xf2f6a9),_0x28fc0b=y(_0xb3298e);if(_0x17dfe1===null)return _0xb3298e;if(_0x17dfe1===_0x28fc0b)return F(b(_0xf2f6a9),b(_0xb3298e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xb3298e+')\x20is\x20not\x20within\x20outerPath\x20('+_0xf2f6a9+')');}function Th(_0x112176,_0x4c0f0a){const _0x5e813c=kt(_0x112176,0x0),_0x4f5c0a=kt(_0x4c0f0a,0x0);for(let _0x4d9294=0x0;_0x4d9294<_0x5e813c['length']&&_0x4d9294<_0x4f5c0a['length'];_0x4d9294++){const _0x36f74a=He(_0x5e813c[_0x4d9294],_0x4f5c0a[_0x4d9294]);if(_0x36f74a!==0x0)return _0x36f74a;}return _0x5e813c['length']===_0x4f5c0a['length']?0x0:_0x5e813c['length']<_0x4f5c0a['length']?-0x1:0x1;}function qi(_0x18a426,_0x591d14){if(we(_0x18a426)!==we(_0x591d14))return!0x1;for(let _0x2f6cc0=_0x18a426['pieceNum_'],_0x4d6d85=_0x591d14['pieceNum_'];_0x2f6cc0<=_0x18a426['pieces_']['length'];_0x2f6cc0++,_0x4d6d85++)if(_0x18a426['pieces_'][_0x2f6cc0]!==_0x591d14['pieces_'][_0x4d6d85])return!0x1;return!0x0;}function $(_0x54dcce,_0x54e9ca){let _0x2842d0=_0x54dcce['pieceNum_'],_0x4f4e4a=_0x54e9ca['pieceNum_'];if(we(_0x54dcce)>we(_0x54e9ca))return!0x1;for(;_0x2842d0<_0x54dcce['pieces_']['length'];){if(_0x54dcce['pieces_'][_0x2842d0]!==_0x54e9ca['pieces_'][_0x4f4e4a])return!0x1;++_0x2842d0,++_0x4f4e4a;}return!0x0;}class Sh{constructor(_0xd88070,_0x59e0ad){this['errorPrefix_']=_0x59e0ad,this['parts_']=kt(_0xd88070,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3d13ba=0x0;_0x3d13ba<this['parts_']['length'];_0x3d13ba++)this['byteLength_']+=Pn(this['parts_'][_0x3d13ba]);So(this);}}function bh(_0x33465d,_0x940dbf){_0x33465d['parts_']['length']>0x0&&(_0x33465d['byteLength_']+=0x1),_0x33465d['parts_']['push'](_0x940dbf),_0x33465d['byteLength_']+=Pn(_0x940dbf),So(_0x33465d);}function Rh(_0x1945b0){const _0x4723b9=_0x1945b0['parts_']['pop']();_0x1945b0['byteLength_']-=Pn(_0x4723b9),_0x1945b0['parts_']['length']>0x0&&(_0x1945b0['byteLength_']-=0x1);}function So(_0x5312c4){if(_0x5312c4['byteLength_']>Js)throw new Error(_0x5312c4['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x5312c4['byteLength_']+').');if(_0x5312c4['parts_']['length']>Qs)throw new Error(_0x5312c4['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x5312c4));}function Ne(_0x59a74e){return _0x59a74e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x59a74e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x4c9388,_0x4e0fc8;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4e0fc8='visibilitychange',_0x4c9388='hidden'):typeof document['mozHidden']<'u'?(_0x4e0fc8='mozvisibilitychange',_0x4c9388='mozHidden'):typeof document['msHidden']<'u'?(_0x4e0fc8='msvisibilitychange',_0x4c9388='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4e0fc8='webkitvisibilitychange',_0x4c9388='webkitHidden')),this['visible_']=!0x0,_0x4e0fc8&&document['addEventListener'](_0x4e0fc8,()=>{const _0x6d097=!document[_0x4c9388];_0x6d097!==this['visible_']&&(this['visible_']=_0x6d097,this['trigger']('visible',_0x6d097));},!0x1);}['getInitialEvent'](_0x28cbc4){return f(_0x28cbc4==='visible','Unknown\x20event\x20type:\x20'+_0x28cbc4),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5ae1a6,_0xb884ab,_0x3f271d,_0x3e26c8,_0x5ce932,_0x56b632,_0x2afc56,_0x998f2){if(super(),this['repoInfo_']=_0x5ae1a6,this['applicationId_']=_0xb884ab,this['onDataUpdate_']=_0x3f271d,this['onConnectStatus_']=_0x3e26c8,this['onServerInfoUpdate_']=_0x5ce932,this['authTokenProvider_']=_0x56b632,this['appCheckTokenProvider_']=_0x2afc56,this['authOverride_']=_0x998f2,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x998f2)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5ae1a6['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x103103,_0x38be85,_0x3d46e4){const _0x4f342b=++this['requestNumber_'],_0x4e8f8b={'r':_0x4f342b,'a':_0x103103,'b':_0x38be85};this['log_'](O(_0x4e8f8b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4e8f8b),_0x3d46e4&&(this['requestCBHash_'][_0x4f342b]=_0x3d46e4);}['get'](_0x4979f4){this['initConnection_']();const _0x3346d6=new Ve(),_0x5edac1={'action':'g','request':{'p':_0x4979f4['_path']['toString'](),'q':_0x4979f4['_queryObject']},'onComplete':_0x4e9d4b=>{const _0x58dc4f=_0x4e9d4b['d'];_0x4e9d4b['s']==='ok'?_0x3346d6['resolve'](_0x58dc4f):_0x3346d6['reject'](_0x58dc4f);}};this['outstandingGets_']['push'](_0x5edac1),this['outstandingGetCount_']++;const _0x45b993=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x45b993),_0x3346d6['promise'];}['listen'](_0x19d053,_0xf5bb5,_0x34d2b9,_0x4ea1a1){this['initConnection_']();const _0x44a2da=_0x19d053['_queryIdentifier'],_0x1f2335=_0x19d053['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f2335+'\x20'+_0x44a2da),this['listens']['has'](_0x1f2335)||this['listens']['set'](_0x1f2335,new Map()),f(_0x19d053['_queryParams']['isDefault']()||!_0x19d053['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1f2335)['has'](_0x44a2da),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x9cab49={'onComplete':_0x4ea1a1,'hashFn':_0xf5bb5,'query':_0x19d053,'tag':_0x34d2b9};this['listens']['get'](_0x1f2335)['set'](_0x44a2da,_0x9cab49),this['connected_']&&this['sendListen_'](_0x9cab49);}['sendGet_'](_0x459267){const _0x593ddd=this['outstandingGets_'][_0x459267];this['sendRequest']('g',_0x593ddd['request'],_0xa40346=>{delete this['outstandingGets_'][_0x459267],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x593ddd['onComplete']&&_0x593ddd['onComplete'](_0xa40346);});}['sendListen_'](_0x36354f){const _0x2aab87=_0x36354f['query'],_0x393c6c=_0x2aab87['_path']['toString'](),_0x476865=_0x2aab87['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x393c6c+'\x20for\x20'+_0x476865);const _0x51f2b2={'p':_0x393c6c},_0x445679='q';_0x36354f['tag']&&(_0x51f2b2['q']=_0x2aab87['_queryObject'],_0x51f2b2['t']=_0x36354f['tag']),_0x51f2b2['h']=_0x36354f['hashFn'](),this['sendRequest'](_0x445679,_0x51f2b2,_0x55faaa=>{const _0x6c489a=_0x55faaa['d'],_0x276511=_0x55faaa['s'];ie['warnOnListenWarnings_'](_0x6c489a,_0x2aab87),(this['listens']['get'](_0x393c6c)&&this['listens']['get'](_0x393c6c)['get'](_0x476865))===_0x36354f&&(this['log_']('listen\x20response',_0x55faaa),_0x276511!=='ok'&&this['removeListen_'](_0x393c6c,_0x476865),_0x36354f['onComplete']&&_0x36354f['onComplete'](_0x276511,_0x6c489a));});}static['warnOnListenWarnings_'](_0x14a006,_0x4d5353){if(_0x14a006&&typeof _0x14a006=='object'&&Y(_0x14a006,'w')){const _0x55ee93=Oe(_0x14a006,'w');if(Array['isArray'](_0x55ee93)&&~_0x55ee93['indexOf']('no_index')){const _0x1d8248='\x22.indexOn\x22:\x20\x22'+_0x4d5353['_queryParams']['getIndex']()['toString']()+'\x22',_0x91e064=_0x4d5353['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1d8248+'\x20at\x20'+_0x91e064+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xb8dd4b){this['authToken_']=_0xb8dd4b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xb8dd4b);}['reduceReconnectDelayIfAdminCredential_'](_0x3edaa1){(_0x3edaa1&&_0x3edaa1['length']===0x28||vc(_0x3edaa1))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x1956b7){this['appCheckToken_']=_0x1956b7,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xa62b7e=this['authToken_'],_0x21434a=yc(_0xa62b7e)?'auth':'gauth',_0x1a58ae={'cred':_0xa62b7e};this['authOverride_']===null?_0x1a58ae['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1a58ae['authvar']=this['authOverride_']),this['sendRequest'](_0x21434a,_0x1a58ae,_0x29e776=>{const _0xe96868=_0x29e776['s'],_0x50e603=_0x29e776['d']||'error';this['authToken_']===_0xa62b7e&&(_0xe96868==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0xe96868,_0x50e603));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2065c0=>{const _0x537fdb=_0x2065c0['s'],_0x51bd8d=_0x2065c0['d']||'error';_0x537fdb==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x537fdb,_0x51bd8d);});}['unlisten'](_0x34eba4,_0x50202f){const _0xc89bf4=_0x34eba4['_path']['toString'](),_0x107c72=_0x34eba4['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xc89bf4+'\x20'+_0x107c72),f(_0x34eba4['_queryParams']['isDefault']()||!_0x34eba4['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xc89bf4,_0x107c72)&&this['connected_']&&this['sendUnlisten_'](_0xc89bf4,_0x107c72,_0x34eba4['_queryObject'],_0x50202f);}['sendUnlisten_'](_0x1adedd,_0x3b5a81,_0x13d5cd,_0x408419){this['log_']('Unlisten\x20on\x20'+_0x1adedd+'\x20for\x20'+_0x3b5a81);const _0x2e287e={'p':_0x1adedd},_0x2372f8='n';_0x408419&&(_0x2e287e['q']=_0x13d5cd,_0x2e287e['t']=_0x408419),this['sendRequest'](_0x2372f8,_0x2e287e);}['onDisconnectPut'](_0x519f96,_0x2b9d09,_0x373695){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x519f96,_0x2b9d09,_0x373695):this['onDisconnectRequestQueue_']['push']({'pathString':_0x519f96,'action':'o','data':_0x2b9d09,'onComplete':_0x373695});}['onDisconnectMerge'](_0x4d07b6,_0x30625e,_0x50094e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4d07b6,_0x30625e,_0x50094e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4d07b6,'action':'om','data':_0x30625e,'onComplete':_0x50094e});}['onDisconnectCancel'](_0x24d1c6,_0x4dfd6e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x24d1c6,null,_0x4dfd6e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x24d1c6,'action':'oc','data':null,'onComplete':_0x4dfd6e});}['sendOnDisconnect_'](_0x5bd375,_0x5b8fa1,_0x2faef5,_0x47f640){const _0x3f8022={'p':_0x5b8fa1,'d':_0x2faef5};this['log_']('onDisconnect\x20'+_0x5bd375,_0x3f8022),this['sendRequest'](_0x5bd375,_0x3f8022,_0x2b1f9e=>{_0x47f640&&setTimeout(()=>{_0x47f640(_0x2b1f9e['s'],_0x2b1f9e['d']);},Math['floor'](0x0));});}['put'](_0x2fb6d2,_0x448155,_0x13306e,_0x5ac94d){this['putInternal']('p',_0x2fb6d2,_0x448155,_0x13306e,_0x5ac94d);}['merge'](_0x1428c1,_0x168472,_0x345136,_0x50a5d6){this['putInternal']('m',_0x1428c1,_0x168472,_0x345136,_0x50a5d6);}['putInternal'](_0x33f3e1,_0x2afad7,_0xb440a6,_0x10d31e,_0x5cadcc){this['initConnection_']();const _0x31ea66={'p':_0x2afad7,'d':_0xb440a6};_0x5cadcc!==void 0x0&&(_0x31ea66['h']=_0x5cadcc),this['outstandingPuts_']['push']({'action':_0x33f3e1,'request':_0x31ea66,'onComplete':_0x10d31e}),this['outstandingPutCount_']++;const _0x2a97a9=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2a97a9):this['log_']('Buffering\x20put:\x20'+_0x2afad7);}['sendPut_'](_0x434275){const _0x1b2bc1=this['outstandingPuts_'][_0x434275]['action'],_0x521fab=this['outstandingPuts_'][_0x434275]['request'],_0x56a0dc=this['outstandingPuts_'][_0x434275]['onComplete'];this['outstandingPuts_'][_0x434275]['queued']=this['connected_'],this['sendRequest'](_0x1b2bc1,_0x521fab,_0x33cd06=>{this['log_'](_0x1b2bc1+'\x20response',_0x33cd06),delete this['outstandingPuts_'][_0x434275],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x56a0dc&&_0x56a0dc(_0x33cd06['s'],_0x33cd06['d']);});}['reportStats'](_0x3dea75){if(this['connected_']){const _0x3b386b={'c':_0x3dea75};this['log_']('reportStats',_0x3b386b),this['sendRequest']('s',_0x3b386b,_0x1e3881=>{if(_0x1e3881['s']!=='ok'){const _0x3b41de=_0x1e3881['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3b41de);}});}}['onDataMessage_'](_0x17edcd){if('r'in _0x17edcd){this['log_']('from\x20server:\x20'+O(_0x17edcd));const _0x38abe2=_0x17edcd['r'],_0x4c5db2=this['requestCBHash_'][_0x38abe2];_0x4c5db2&&(delete this['requestCBHash_'][_0x38abe2],_0x4c5db2(_0x17edcd['b']));}else{if('error'in _0x17edcd)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x17edcd['error'];'a'in _0x17edcd&&this['onDataPush_'](_0x17edcd['a'],_0x17edcd['b']);}}['onDataPush_'](_0x5acb58,_0x2674d9){this['log_']('handleServerMessage',_0x5acb58,_0x2674d9),_0x5acb58==='d'?this['onDataUpdate_'](_0x2674d9['p'],_0x2674d9['d'],!0x1,_0x2674d9['t']):_0x5acb58==='m'?this['onDataUpdate_'](_0x2674d9['p'],_0x2674d9['d'],!0x0,_0x2674d9['t']):_0x5acb58==='c'?this['onListenRevoked_'](_0x2674d9['p'],_0x2674d9['q']):_0x5acb58==='ac'?this['onAuthRevoked_'](_0x2674d9['s'],_0x2674d9['d']):_0x5acb58==='apc'?this['onAppCheckRevoked_'](_0x2674d9['s'],_0x2674d9['d']):_0x5acb58==='sd'?this['onSecurityDebugPacket_'](_0x2674d9):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5acb58)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0xea2e6d,_0x461344){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0xea2e6d),this['lastSessionId']=_0x461344,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x241ba1){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x241ba1));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x9a4aac){_0x9a4aac&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x9a4aac;}['onOnline_'](_0x4a353b){_0x4a353b?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2663da=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2ec33b=Math['max'](0x0,this['reconnectDelay_']-_0x2663da);_0x2ec33b=Math['random']()*_0x2ec33b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2ec33b+'ms'),this['scheduleConnect_'](_0x2ec33b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x477ffe=this['onDataMessage_']['bind'](this),_0x58cc26=this['onReady_']['bind'](this),_0x46e980=this['onRealtimeDisconnect_']['bind'](this),_0xc2ab5d=this['id']+':'+ie['nextConnectionId_']++,_0x5e3b86=this['lastSessionId'];let _0x1db829=!0x1,_0x499542=null;const _0x126921=function(){_0x499542?_0x499542['close']():(_0x1db829=!0x0,_0x46e980());},_0x218243=function(_0xc172c0){f(_0x499542,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x499542['sendRequest'](_0xc172c0);};this['realtime_']={'close':_0x126921,'sendRequest':_0x218243};const _0x420b75=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x383507,_0x1ced3c]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x420b75),this['appCheckTokenProvider_']['getToken'](_0x420b75)]);_0x1db829?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x383507&&_0x383507['accessToken'],this['appCheckToken_']=_0x1ced3c&&_0x1ced3c['token'],_0x499542=new wh(_0xc2ab5d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x477ffe,_0x58cc26,_0x46e980,_0x23b5cf=>{U(_0x23b5cf+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5e3b86));}catch(_0x89777f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x89777f),_0x1db829||(this['repoInfo_']['nodeAdmin']&&U(_0x89777f),_0x126921());}}}['interrupt'](_0xf16117){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xf16117),this['interruptReasons_'][_0xf16117]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4e6bad){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4e6bad),delete this['interruptReasons_'][_0x4e6bad],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4db1b5){const _0x1a8ad9=_0x4db1b5-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1a8ad9});}['cancelSentTransactions_'](){for(let _0xb1f2c9=0x0;_0xb1f2c9<this['outstandingPuts_']['length'];_0xb1f2c9++){const _0xd62e0c=this['outstandingPuts_'][_0xb1f2c9];_0xd62e0c&&'h'in _0xd62e0c['request']&&_0xd62e0c['queued']&&(_0xd62e0c['onComplete']&&_0xd62e0c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xb1f2c9],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5e66a6,_0x3306d3){let _0x152277;_0x3306d3?_0x152277=_0x3306d3['map'](_0x384d84=>Bi(_0x384d84))['join']('$'):_0x152277='default';const _0x371ea8=this['removeListen_'](_0x5e66a6,_0x152277);_0x371ea8&&_0x371ea8['onComplete']&&_0x371ea8['onComplete']('permission_denied');}['removeListen_'](_0x5ab6ae,_0x4f1772){const _0x126489=new C(_0x5ab6ae)['toString']();let _0x21fe20;if(this['listens']['has'](_0x126489)){const _0x48183e=this['listens']['get'](_0x126489);_0x21fe20=_0x48183e['get'](_0x4f1772),_0x48183e['delete'](_0x4f1772),_0x48183e['size']===0x0&&this['listens']['delete'](_0x126489);}else _0x21fe20=void 0x0;return _0x21fe20;}['onAuthRevoked_'](_0x4c49dc,_0x4954fc){L('Auth\x20token\x20revoked:\x20'+_0x4c49dc+'/'+_0x4954fc),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4c49dc==='invalid_token'||_0x4c49dc==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x25aeae,_0x1cd455){L('App\x20check\x20token\x20revoked:\x20'+_0x25aeae+'/'+_0x1cd455),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x25aeae==='invalid_token'||_0x25aeae==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x9a2564){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x9a2564):'msg'in _0x9a2564&&console['log']('FIREBASE:\x20'+_0x9a2564['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x585885 of this['listens']['values']())for(const _0x40146c of _0x585885['values']())this['sendListen_'](_0x40146c);for(let _0x1ab81e=0x0;_0x1ab81e<this['outstandingPuts_']['length'];_0x1ab81e++)this['outstandingPuts_'][_0x1ab81e]&&this['sendPut_'](_0x1ab81e);for(;this['onDisconnectRequestQueue_']['length'];){const _0xa527cc=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xa527cc['action'],_0xa527cc['pathString'],_0xa527cc['data'],_0xa527cc['onComplete']);}for(let _0x48117b=0x0;_0x48117b<this['outstandingGets_']['length'];_0x48117b++)this['outstandingGets_'][_0x48117b]&&this['sendGet_'](_0x48117b);}['sendConnectStats_'](){const _0x43dd2f={};let _0x35e0e9='js';_0x43dd2f['sdk.'+_0x35e0e9+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x43dd2f['framework.cordova']=0x1:qr()&&(_0x43dd2f['framework.reactnative']=0x1),this['reportStats'](_0x43dd2f);}['shouldReconnect_'](){const _0x32cac5=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x32cac5;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5a2d37,_0x2afd3b){this['name']=_0x5a2d37,this['node']=_0x2afd3b;}static['Wrap'](_0x3fc9f3,_0x57ecef){return new E(_0x3fc9f3,_0x57ecef);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x21bbbd,_0x114ed5){const _0x4ffe8e=new E(xe,_0x21bbbd),_0x230678=new E(xe,_0x114ed5);return this['compare'](_0x4ffe8e,_0x230678)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x31880b){Xt=_0x31880b;}['compare'](_0x266658,_0x896d9a){return He(_0x266658['name'],_0x896d9a['name']);}['isDefinedOn'](_0x1a38e7){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x12c8fb,_0x586895){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x43bde0,_0x13ab74){return f(typeof _0x43bde0=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x43bde0,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0xace47e,_0xb1259e,_0x286ee3,_0x3a2987,_0x45e249=null){this['isReverse_']=_0x3a2987,this['resultGenerator_']=_0x45e249,this['nodeStack_']=[];let _0x4a82c2=0x1;for(;!_0xace47e['isEmpty']();)if(_0xace47e=_0xace47e,_0x4a82c2=_0xb1259e?_0x286ee3(_0xace47e['key'],_0xb1259e):0x1,_0x3a2987&&(_0x4a82c2*=-0x1),_0x4a82c2<0x0)this['isReverse_']?_0xace47e=_0xace47e['left']:_0xace47e=_0xace47e['right'];else{if(_0x4a82c2===0x0){this['nodeStack_']['push'](_0xace47e);break;}else this['nodeStack_']['push'](_0xace47e),this['isReverse_']?_0xace47e=_0xace47e['right']:_0xace47e=_0xace47e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2dbfc7=this['nodeStack_']['pop'](),_0x5eaddb;if(this['resultGenerator_']?_0x5eaddb=this['resultGenerator_'](_0x2dbfc7['key'],_0x2dbfc7['value']):_0x5eaddb={'key':_0x2dbfc7['key'],'value':_0x2dbfc7['value']},this['isReverse_']){for(_0x2dbfc7=_0x2dbfc7['left'];!_0x2dbfc7['isEmpty']();)this['nodeStack_']['push'](_0x2dbfc7),_0x2dbfc7=_0x2dbfc7['right'];}else{for(_0x2dbfc7=_0x2dbfc7['right'];!_0x2dbfc7['isEmpty']();)this['nodeStack_']['push'](_0x2dbfc7),_0x2dbfc7=_0x2dbfc7['left'];}return _0x5eaddb;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5227ee=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5227ee['key'],_0x5227ee['value']):{'key':_0x5227ee['key'],'value':_0x5227ee['value']};}}class M{constructor(_0x2506e9,_0x4c4596,_0x478682,_0x58a771,_0x38e3cc){this['key']=_0x2506e9,this['value']=_0x4c4596,this['color']=_0x478682??M['RED'],this['left']=_0x58a771??B['EMPTY_NODE'],this['right']=_0x38e3cc??B['EMPTY_NODE'];}['copy'](_0x31a24a,_0x4cdc74,_0x458c8e,_0x5b12af,_0x14732e){return new M(_0x31a24a??this['key'],_0x4cdc74??this['value'],_0x458c8e??this['color'],_0x5b12af??this['left'],_0x14732e??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x168c44){return this['left']['inorderTraversal'](_0x168c44)||!!_0x168c44(this['key'],this['value'])||this['right']['inorderTraversal'](_0x168c44);}['reverseTraversal'](_0x2ff0b6){return this['right']['reverseTraversal'](_0x2ff0b6)||_0x2ff0b6(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2ff0b6);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x597a0e,_0x3c6e9f,_0x419f2a){let _0x2603e8=this;const _0x8289d9=_0x419f2a(_0x597a0e,_0x2603e8['key']);return _0x8289d9<0x0?_0x2603e8=_0x2603e8['copy'](null,null,null,_0x2603e8['left']['insert'](_0x597a0e,_0x3c6e9f,_0x419f2a),null):_0x8289d9===0x0?_0x2603e8=_0x2603e8['copy'](null,_0x3c6e9f,null,null,null):_0x2603e8=_0x2603e8['copy'](null,null,null,null,_0x2603e8['right']['insert'](_0x597a0e,_0x3c6e9f,_0x419f2a)),_0x2603e8['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x45b315=this;return!_0x45b315['left']['isRed_']()&&!_0x45b315['left']['left']['isRed_']()&&(_0x45b315=_0x45b315['moveRedLeft_']()),_0x45b315=_0x45b315['copy'](null,null,null,_0x45b315['left']['removeMin_'](),null),_0x45b315['fixUp_']();}['remove'](_0x171d72,_0x4235b1){let _0x242c88,_0x48f0f9;if(_0x242c88=this,_0x4235b1(_0x171d72,_0x242c88['key'])<0x0)!_0x242c88['left']['isEmpty']()&&!_0x242c88['left']['isRed_']()&&!_0x242c88['left']['left']['isRed_']()&&(_0x242c88=_0x242c88['moveRedLeft_']()),_0x242c88=_0x242c88['copy'](null,null,null,_0x242c88['left']['remove'](_0x171d72,_0x4235b1),null);else{if(_0x242c88['left']['isRed_']()&&(_0x242c88=_0x242c88['rotateRight_']()),!_0x242c88['right']['isEmpty']()&&!_0x242c88['right']['isRed_']()&&!_0x242c88['right']['left']['isRed_']()&&(_0x242c88=_0x242c88['moveRedRight_']()),_0x4235b1(_0x171d72,_0x242c88['key'])===0x0){if(_0x242c88['right']['isEmpty']())return B['EMPTY_NODE'];_0x48f0f9=_0x242c88['right']['min_'](),_0x242c88=_0x242c88['copy'](_0x48f0f9['key'],_0x48f0f9['value'],null,null,_0x242c88['right']['removeMin_']());}_0x242c88=_0x242c88['copy'](null,null,null,null,_0x242c88['right']['remove'](_0x171d72,_0x4235b1));}return _0x242c88['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x47cb63=this;return _0x47cb63['right']['isRed_']()&&!_0x47cb63['left']['isRed_']()&&(_0x47cb63=_0x47cb63['rotateLeft_']()),_0x47cb63['left']['isRed_']()&&_0x47cb63['left']['left']['isRed_']()&&(_0x47cb63=_0x47cb63['rotateRight_']()),_0x47cb63['left']['isRed_']()&&_0x47cb63['right']['isRed_']()&&(_0x47cb63=_0x47cb63['colorFlip_']()),_0x47cb63;}['moveRedLeft_'](){let _0x19cdca=this['colorFlip_']();return _0x19cdca['right']['left']['isRed_']()&&(_0x19cdca=_0x19cdca['copy'](null,null,null,null,_0x19cdca['right']['rotateRight_']()),_0x19cdca=_0x19cdca['rotateLeft_'](),_0x19cdca=_0x19cdca['colorFlip_']()),_0x19cdca;}['moveRedRight_'](){let _0x1c3398=this['colorFlip_']();return _0x1c3398['left']['left']['isRed_']()&&(_0x1c3398=_0x1c3398['rotateRight_'](),_0x1c3398=_0x1c3398['colorFlip_']()),_0x1c3398;}['rotateLeft_'](){const _0x85d71f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x85d71f,null);}['rotateRight_'](){const _0x1e1a2f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1e1a2f);}['colorFlip_'](){const _0x1db004=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xbb8626=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1db004,_0xbb8626);}['checkMaxDepth_'](){const _0xe63e7d=this['check_']();return Math['pow'](0x2,_0xe63e7d)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x39d043=this['left']['check_']();if(_0x39d043!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x39d043+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x4db691,_0x481c5e,_0x578eea,_0x1fdf0c,_0x237742){return this;}['insert'](_0x156b5e,_0x5b2c44,_0x3debb4){return new M(_0x156b5e,_0x5b2c44,null);}['remove'](_0x4016f3,_0x5e9d30){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3a9b95){return!0x1;}['reverseTraversal'](_0x3a2a14){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x586b92,_0x257cb4=B['EMPTY_NODE']){this['comparator_']=_0x586b92,this['root_']=_0x257cb4;}['insert'](_0x81645,_0x15e23e){return new B(this['comparator_'],this['root_']['insert'](_0x81645,_0x15e23e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x22a51a){return new B(this['comparator_'],this['root_']['remove'](_0x22a51a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x278902){let _0xd8f79,_0x42b922=this['root_'];for(;!_0x42b922['isEmpty']();){if(_0xd8f79=this['comparator_'](_0x278902,_0x42b922['key']),_0xd8f79===0x0)return _0x42b922['value'];_0xd8f79<0x0?_0x42b922=_0x42b922['left']:_0xd8f79>0x0&&(_0x42b922=_0x42b922['right']);}return null;}['getPredecessorKey'](_0x3e976d){let _0x3a9b62,_0x58aa8a=this['root_'],_0x1968b2=null;for(;!_0x58aa8a['isEmpty']();)if(_0x3a9b62=this['comparator_'](_0x3e976d,_0x58aa8a['key']),_0x3a9b62===0x0){if(_0x58aa8a['left']['isEmpty']())return _0x1968b2?_0x1968b2['key']:null;for(_0x58aa8a=_0x58aa8a['left'];!_0x58aa8a['right']['isEmpty']();)_0x58aa8a=_0x58aa8a['right'];return _0x58aa8a['key'];}else _0x3a9b62<0x0?_0x58aa8a=_0x58aa8a['left']:_0x3a9b62>0x0&&(_0x1968b2=_0x58aa8a,_0x58aa8a=_0x58aa8a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x38e45b){return this['root_']['inorderTraversal'](_0x38e45b);}['reverseTraversal'](_0xe0dce6){return this['root_']['reverseTraversal'](_0xe0dce6);}['getIterator'](_0x157403){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x157403);}['getIteratorFrom'](_0x525bd3,_0x1fcc14){return new Zt(this['root_'],_0x525bd3,this['comparator_'],!0x1,_0x1fcc14);}['getReverseIteratorFrom'](_0x4f942a,_0x1a5713){return new Zt(this['root_'],_0x4f942a,this['comparator_'],!0x0,_0x1a5713);}['getReverseIterator'](_0x198141){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x198141);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x1c7faf,_0x258371){return He(_0x1c7faf['name'],_0x258371['name']);}function ji(_0x1fa8e8,_0x28b62a){return He(_0x1fa8e8,_0x28b62a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5612cf){vi=_0x5612cf;}const Ro=function(_0x5021f9){return typeof _0x5021f9=='number'?'number:'+so(_0x5021f9):'string:'+_0x5021f9;},Ao=function(_0x58d677){if(_0x58d677['isLeafNode']()){const _0x2a709d=_0x58d677['val']();f(typeof _0x2a709d=='string'||typeof _0x2a709d=='number'||typeof _0x2a709d=='object'&&Y(_0x2a709d,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x58d677===vi||_0x58d677['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x58d677===vi||_0x58d677['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5118c1){er=_0x5118c1;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x542ab1,_0x11ce85=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x542ab1,this['priorityNode_']=_0x11ce85,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4e9e56){return new D(this['value_'],_0x4e9e56);}['getImmediateChild'](_0x15a2cc){return _0x15a2cc==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5a74b8){return v(_0x5a74b8)?this:y(_0x5a74b8)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x125c09,_0x4fa103){return null;}['updateImmediateChild'](_0x313afa,_0x45098b){return _0x313afa==='.priority'?this['updatePriority'](_0x45098b):_0x45098b['isEmpty']()&&_0x313afa!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x313afa,_0x45098b)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1f8b87,_0x34652e){const _0x3d1c31=y(_0x1f8b87);return _0x3d1c31===null?_0x34652e:_0x34652e['isEmpty']()&&_0x3d1c31!=='.priority'?this:(f(_0x3d1c31!=='.priority'||we(_0x1f8b87)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3d1c31,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1f8b87),_0x34652e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x44d50b,_0x2537ff){return!0x1;}['val'](_0x2db4da){return _0x2db4da&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x598e51='';this['priorityNode_']['isEmpty']()||(_0x598e51+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x139c0d=typeof this['value_'];_0x598e51+=_0x139c0d+':',_0x139c0d==='number'?_0x598e51+=so(this['value_']):_0x598e51+=this['value_'],this['lazyHash_']=no(_0x598e51);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4289b8){return _0x4289b8===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4289b8 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4289b8['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4289b8));}['compareToLeafNode_'](_0x3717ac){const _0x5721bf=typeof _0x3717ac['value_'],_0xca551c=typeof this['value_'],_0x24f1a9=D['VALUE_TYPE_ORDER']['indexOf'](_0x5721bf),_0x3bd244=D['VALUE_TYPE_ORDER']['indexOf'](_0xca551c);return f(_0x24f1a9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5721bf),f(_0x3bd244>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xca551c),_0x24f1a9===_0x3bd244?_0xca551c==='object'?0x0:this['value_']<_0x3717ac['value_']?-0x1:this['value_']===_0x3717ac['value_']?0x0:0x1:_0x3bd244-_0x24f1a9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x15bfc0){if(_0x15bfc0===this)return!0x0;if(_0x15bfc0['isLeafNode']()){const _0xf5b894=_0x15bfc0;return this['value_']===_0xf5b894['value_']&&this['priorityNode_']['equals'](_0xf5b894['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x55f30d){ko=_0x55f30d;}function xh(_0x3ffa72){No=_0x3ffa72;}class Fh extends On{['compare'](_0x45f397,_0xa9a098){const _0x47450c=_0x45f397['node']['getPriority'](),_0x46b384=_0xa9a098['node']['getPriority'](),_0x1d02d8=_0x47450c['compareTo'](_0x46b384);return _0x1d02d8===0x0?He(_0x45f397['name'],_0xa9a098['name']):_0x1d02d8;}['isDefinedOn'](_0x1a97e3){return!_0x1a97e3['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x433920,_0x5890c8){return!_0x433920['getPriority']()['equals'](_0x5890c8['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2fc1f4,_0x2218af){const _0x352ba7=ko(_0x2fc1f4);return new E(_0x2218af,new D('[PRIORITY-POST]',_0x352ba7));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x27e315){const _0x41dd73=_0x5bd5f0=>parseInt(Math['log'](_0x5bd5f0)/Uh,0xa),_0x47165d=_0x1a26ff=>parseInt(Array(_0x1a26ff+0x1)['join']('1'),0x2);this['count']=_0x41dd73(_0x27e315+0x1),this['current_']=this['count']-0x1;const _0x197024=_0x47165d(this['count']);this['bits_']=_0x27e315+0x1&_0x197024;}['nextBitIsOne'](){const _0x3365c8=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3365c8;}}const dn=function(_0x310888,_0x50af75,_0xd3b6f1,_0x5ae71d){_0x310888['sort'](_0x50af75);const _0x484d00=function(_0x4d4ecb,_0x5a3bf5){const _0x18d3a9=_0x5a3bf5-_0x4d4ecb;let _0x7860fd,_0x238974;if(_0x18d3a9===0x0)return null;if(_0x18d3a9===0x1)return _0x7860fd=_0x310888[_0x4d4ecb],_0x238974=_0xd3b6f1?_0xd3b6f1(_0x7860fd):_0x7860fd,new M(_0x238974,_0x7860fd['node'],M['BLACK'],null,null);{const _0x3ca090=parseInt(_0x18d3a9/0x2,0xa)+_0x4d4ecb,_0x1d43b4=_0x484d00(_0x4d4ecb,_0x3ca090),_0x370e6f=_0x484d00(_0x3ca090+0x1,_0x5a3bf5);return _0x7860fd=_0x310888[_0x3ca090],_0x238974=_0xd3b6f1?_0xd3b6f1(_0x7860fd):_0x7860fd,new M(_0x238974,_0x7860fd['node'],M['BLACK'],_0x1d43b4,_0x370e6f);}},_0x443e73=function(_0x1ba9c6){let _0x1f4261=null,_0x28c630=null,_0x4e12cd=_0x310888['length'];const _0x1ca77a=function(_0x5cf404,_0x3ac070){const _0x4726fb=_0x4e12cd-_0x5cf404,_0x37c0c8=_0x4e12cd;_0x4e12cd-=_0x5cf404;const _0x1fc61=_0x484d00(_0x4726fb+0x1,_0x37c0c8),_0x336b42=_0x310888[_0x4726fb],_0x3e3f0c=_0xd3b6f1?_0xd3b6f1(_0x336b42):_0x336b42;_0x45e7d4(new M(_0x3e3f0c,_0x336b42['node'],_0x3ac070,null,_0x1fc61));},_0x45e7d4=function(_0x450d19){_0x1f4261?(_0x1f4261['left']=_0x450d19,_0x1f4261=_0x450d19):(_0x28c630=_0x450d19,_0x1f4261=_0x450d19);};for(let _0x20d32f=0x0;_0x20d32f<_0x1ba9c6['count'];++_0x20d32f){const _0x668b89=_0x1ba9c6['nextBitIsOne'](),_0x149c42=Math['pow'](0x2,_0x1ba9c6['count']-(_0x20d32f+0x1));_0x668b89?_0x1ca77a(_0x149c42,M['BLACK']):(_0x1ca77a(_0x149c42,M['BLACK']),_0x1ca77a(_0x149c42,M['RED']));}return _0x28c630;},_0x3cdbda=new Wh(_0x310888['length']),_0x35f2e0=_0x443e73(_0x3cdbda);return new B(_0x5ae71d||_0x50af75,_0x35f2e0);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x16ddd3,_0x59763f){this['indexes_']=_0x16ddd3,this['indexSet_']=_0x59763f;}['get'](_0xa364ac){const _0xdc0a19=Oe(this['indexes_'],_0xa364ac);if(!_0xdc0a19)throw new Error('No\x20index\x20defined\x20for\x20'+_0xa364ac);return _0xdc0a19 instanceof B?_0xdc0a19:null;}['hasIndex'](_0x549419){return Y(this['indexSet_'],_0x549419['toString']());}['addIndex'](_0x5861fc,_0x2c7fa1){f(_0x5861fc!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2d35ee=[];let _0x29fde2=!0x1;const _0x419f11=_0x2c7fa1['getIterator'](E['Wrap']);let _0x3b2f97=_0x419f11['getNext']();for(;_0x3b2f97;)_0x29fde2=_0x29fde2||_0x5861fc['isDefinedOn'](_0x3b2f97['node']),_0x2d35ee['push'](_0x3b2f97),_0x3b2f97=_0x419f11['getNext']();let _0x3881b1;_0x29fde2?_0x3881b1=dn(_0x2d35ee,_0x5861fc['getCompare']()):_0x3881b1=je;const _0x140ad9=_0x5861fc['toString'](),_0xb552af={...this['indexSet_']};_0xb552af[_0x140ad9]=_0x5861fc;const _0x22c4e4={...this['indexes_']};return _0x22c4e4[_0x140ad9]=_0x3881b1,new ee(_0x22c4e4,_0xb552af);}['addToIndexes'](_0x3f21ce,_0x6056dc){const _0x2ca635=ln(this['indexes_'],(_0x3a6a2f,_0x5ad2c3)=>{const _0x494d64=Oe(this['indexSet_'],_0x5ad2c3);if(f(_0x494d64,'Missing\x20index\x20implementation\x20for\x20'+_0x5ad2c3),_0x3a6a2f===je){if(_0x494d64['isDefinedOn'](_0x3f21ce['node'])){const _0x53de1c=[],_0x20c126=_0x6056dc['getIterator'](E['Wrap']);let _0x5cbc6f=_0x20c126['getNext']();for(;_0x5cbc6f;)_0x5cbc6f['name']!==_0x3f21ce['name']&&_0x53de1c['push'](_0x5cbc6f),_0x5cbc6f=_0x20c126['getNext']();return _0x53de1c['push'](_0x3f21ce),dn(_0x53de1c,_0x494d64['getCompare']());}else return je;}else{const _0x410808=_0x6056dc['get'](_0x3f21ce['name']);let _0x7d4884=_0x3a6a2f;return _0x410808&&(_0x7d4884=_0x7d4884['remove'](new E(_0x3f21ce['name'],_0x410808))),_0x7d4884['insert'](_0x3f21ce,_0x3f21ce['node']);}});return new ee(_0x2ca635,this['indexSet_']);}['removeFromIndexes'](_0x515ccd,_0x361cb7){const _0x38c836=ln(this['indexes_'],_0x2284ec=>{if(_0x2284ec===je)return _0x2284ec;{const _0x230250=_0x361cb7['get'](_0x515ccd['name']);return _0x230250?_0x2284ec['remove'](new E(_0x515ccd['name'],_0x230250)):_0x2284ec;}});return new ee(_0x38c836,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x157761,_0x351447,_0x2e0bbf){this['children_']=_0x157761,this['priorityNode_']=_0x351447,this['indexMap_']=_0x2e0bbf,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x143767){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x143767,this['indexMap_']);}['getImmediateChild'](_0x5a50df){if(_0x5a50df==='.priority')return this['getPriority']();{const _0x5f29da=this['children_']['get'](_0x5a50df);return _0x5f29da===null?gt:_0x5f29da;}}['getChild'](_0x192cec){const _0x1b3516=y(_0x192cec);return _0x1b3516===null?this:this['getImmediateChild'](_0x1b3516)['getChild'](b(_0x192cec));}['hasChild'](_0x1f4417){return this['children_']['get'](_0x1f4417)!==null;}['updateImmediateChild'](_0x1f2cfe,_0xeb426e){if(f(_0xeb426e,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1f2cfe==='.priority')return this['updatePriority'](_0xeb426e);{const _0x1d6c83=new E(_0x1f2cfe,_0xeb426e);let _0x3064fb,_0x266c4c;_0xeb426e['isEmpty']()?(_0x3064fb=this['children_']['remove'](_0x1f2cfe),_0x266c4c=this['indexMap_']['removeFromIndexes'](_0x1d6c83,this['children_'])):(_0x3064fb=this['children_']['insert'](_0x1f2cfe,_0xeb426e),_0x266c4c=this['indexMap_']['addToIndexes'](_0x1d6c83,this['children_']));const _0x3a27d9=_0x3064fb['isEmpty']()?gt:this['priorityNode_'];return new g(_0x3064fb,_0x3a27d9,_0x266c4c);}}['updateChild'](_0x491c5f,_0x4f8cc0){const _0x454ef7=y(_0x491c5f);if(_0x454ef7===null)return _0x4f8cc0;{f(y(_0x491c5f)!=='.priority'||we(_0x491c5f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x89d48d=this['getImmediateChild'](_0x454ef7)['updateChild'](b(_0x491c5f),_0x4f8cc0);return this['updateImmediateChild'](_0x454ef7,_0x89d48d);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x332cf9){if(this['isEmpty']())return null;const _0x36e28e={};let _0x261b4a=0x0,_0x27d818=0x0,_0xcd2e42=!0x0;if(this['forEachChild'](R,(_0x2cb587,_0x3e47fa)=>{_0x36e28e[_0x2cb587]=_0x3e47fa['val'](_0x332cf9),_0x261b4a++,_0xcd2e42&&g['INTEGER_REGEXP_']['test'](_0x2cb587)?_0x27d818=Math['max'](_0x27d818,Number(_0x2cb587)):_0xcd2e42=!0x1;}),!_0x332cf9&&_0xcd2e42&&_0x27d818<0x2*_0x261b4a){const _0x2d1e4e=[];for(const _0x69db53 in _0x36e28e)_0x2d1e4e[_0x69db53]=_0x36e28e[_0x69db53];return _0x2d1e4e;}else return _0x332cf9&&!this['getPriority']()['isEmpty']()&&(_0x36e28e['.priority']=this['getPriority']()['val']()),_0x36e28e;}['hash'](){if(this['lazyHash_']===null){let _0x57b6a2='';this['getPriority']()['isEmpty']()||(_0x57b6a2+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x175e34,_0x9ae2f7)=>{const _0xd443c=_0x9ae2f7['hash']();_0xd443c!==''&&(_0x57b6a2+=':'+_0x175e34+':'+_0xd443c);}),this['lazyHash_']=_0x57b6a2===''?'':no(_0x57b6a2);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2fd492,_0x1e49c4,_0x426f0e){const _0x302768=this['resolveIndex_'](_0x426f0e);if(_0x302768){const _0x1f6059=_0x302768['getPredecessorKey'](new E(_0x2fd492,_0x1e49c4));return _0x1f6059?_0x1f6059['name']:null;}else return this['children_']['getPredecessorKey'](_0x2fd492);}['getFirstChildName'](_0x1926b5){const _0x28da9d=this['resolveIndex_'](_0x1926b5);if(_0x28da9d){const _0x5254df=_0x28da9d['minKey']();return _0x5254df&&_0x5254df['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2a0601){const _0x4aa310=this['getFirstChildName'](_0x2a0601);return _0x4aa310?new E(_0x4aa310,this['children_']['get'](_0x4aa310)):null;}['getLastChildName'](_0x362373){const _0x482728=this['resolveIndex_'](_0x362373);if(_0x482728){const _0x5e4692=_0x482728['maxKey']();return _0x5e4692&&_0x5e4692['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2152fe){const _0x5b923e=this['getLastChildName'](_0x2152fe);return _0x5b923e?new E(_0x5b923e,this['children_']['get'](_0x5b923e)):null;}['forEachChild'](_0x54084b,_0x5b63db){const _0x292b4c=this['resolveIndex_'](_0x54084b);return _0x292b4c?_0x292b4c['inorderTraversal'](_0x595053=>_0x5b63db(_0x595053['name'],_0x595053['node'])):this['children_']['inorderTraversal'](_0x5b63db);}['getIterator'](_0x439a74){return this['getIteratorFrom'](_0x439a74['minPost'](),_0x439a74);}['getIteratorFrom'](_0xfca02,_0x30b0f8){const _0x275bbe=this['resolveIndex_'](_0x30b0f8);if(_0x275bbe)return _0x275bbe['getIteratorFrom'](_0xfca02,_0x5c2884=>_0x5c2884);{const _0x328d27=this['children_']['getIteratorFrom'](_0xfca02['name'],E['Wrap']);let _0x3d8d91=_0x328d27['peek']();for(;_0x3d8d91!=null&&_0x30b0f8['compare'](_0x3d8d91,_0xfca02)<0x0;)_0x328d27['getNext'](),_0x3d8d91=_0x328d27['peek']();return _0x328d27;}}['getReverseIterator'](_0x3bb0cc){return this['getReverseIteratorFrom'](_0x3bb0cc['maxPost'](),_0x3bb0cc);}['getReverseIteratorFrom'](_0x5dd8e2,_0x47d95f){const _0x45f358=this['resolveIndex_'](_0x47d95f);if(_0x45f358)return _0x45f358['getReverseIteratorFrom'](_0x5dd8e2,_0x5ac3a2=>_0x5ac3a2);{const _0x4dfe1f=this['children_']['getReverseIteratorFrom'](_0x5dd8e2['name'],E['Wrap']);let _0x9f1d9b=_0x4dfe1f['peek']();for(;_0x9f1d9b!=null&&_0x47d95f['compare'](_0x9f1d9b,_0x5dd8e2)>0x0;)_0x4dfe1f['getNext'](),_0x9f1d9b=_0x4dfe1f['peek']();return _0x4dfe1f;}}['compareTo'](_0x44cf70){return this['isEmpty']()?_0x44cf70['isEmpty']()?0x0:-0x1:_0x44cf70['isLeafNode']()||_0x44cf70['isEmpty']()?0x1:_0x44cf70===Ht?-0x1:0x0;}['withIndex'](_0x4d5092){if(_0x4d5092===ye||this['indexMap_']['hasIndex'](_0x4d5092))return this;{const _0x1bfd58=this['indexMap_']['addIndex'](_0x4d5092,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1bfd58);}}['isIndexed'](_0x4dfac1){return _0x4dfac1===ye||this['indexMap_']['hasIndex'](_0x4dfac1);}['equals'](_0x1789a3){if(_0x1789a3===this)return!0x0;if(_0x1789a3['isLeafNode']())return!0x1;{const _0xbcc6db=_0x1789a3;if(this['getPriority']()['equals'](_0xbcc6db['getPriority']())){if(this['children_']['count']()===_0xbcc6db['children_']['count']()){const _0x536163=this['getIterator'](R),_0x50997f=_0xbcc6db['getIterator'](R);let _0x26bb05=_0x536163['getNext'](),_0x24c865=_0x50997f['getNext']();for(;_0x26bb05&&_0x24c865;){if(_0x26bb05['name']!==_0x24c865['name']||!_0x26bb05['node']['equals'](_0x24c865['node']))return!0x1;_0x26bb05=_0x536163['getNext'](),_0x24c865=_0x50997f['getNext']();}return _0x26bb05===null&&_0x24c865===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x42f521){return _0x42f521===ye?null:this['indexMap_']['get'](_0x42f521['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x266887){return _0x266887===this?0x0:0x1;}['equals'](_0x5804a6){return _0x5804a6===this;}['getPriority'](){return this;}['getImmediateChild'](_0x183548){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x3436a2,_0x4a45b2=null){if(_0x3436a2===null)return g['EMPTY_NODE'];if(typeof _0x3436a2=='object'&&'.priority'in _0x3436a2&&(_0x4a45b2=_0x3436a2['.priority']),f(_0x4a45b2===null||typeof _0x4a45b2=='string'||typeof _0x4a45b2=='number'||typeof _0x4a45b2=='object'&&'.sv'in _0x4a45b2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4a45b2),typeof _0x3436a2=='object'&&'.value'in _0x3436a2&&_0x3436a2['.value']!==null&&(_0x3436a2=_0x3436a2['.value']),typeof _0x3436a2!='object'||'.sv'in _0x3436a2){const _0x493c93=_0x3436a2;return new D(_0x493c93,N(_0x4a45b2));}if(!(_0x3436a2 instanceof Array)&&Vh){const _0x3c194d=[];let _0x33959a=!0x1;if(x(_0x3436a2,(_0x1c514c,_0x304fd5)=>{if(_0x1c514c['substring'](0x0,0x1)!=='.'){const _0x351105=N(_0x304fd5);_0x351105['isEmpty']()||(_0x33959a=_0x33959a||!_0x351105['getPriority']()['isEmpty'](),_0x3c194d['push'](new E(_0x1c514c,_0x351105)));}}),_0x3c194d['length']===0x0)return g['EMPTY_NODE'];const _0x12dfe9=dn(_0x3c194d,Dh,_0x2ae44b=>_0x2ae44b['name'],ji);if(_0x33959a){const _0x5a2aae=dn(_0x3c194d,R['getCompare']());return new g(_0x12dfe9,N(_0x4a45b2),new ee({'.priority':_0x5a2aae},{'.priority':R}));}else return new g(_0x12dfe9,N(_0x4a45b2),ee['Default']);}else{let _0x23e6c6=g['EMPTY_NODE'];return x(_0x3436a2,(_0x39dff9,_0x571854)=>{if(Y(_0x3436a2,_0x39dff9)&&_0x39dff9['substring'](0x0,0x1)!=='.'){const _0xb29250=N(_0x571854);(_0xb29250['isLeafNode']()||!_0xb29250['isEmpty']())&&(_0x23e6c6=_0x23e6c6['updateImmediateChild'](_0x39dff9,_0xb29250));}}),_0x23e6c6['updatePriority'](N(_0x4a45b2));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x21d8a2){super(),this['indexPath_']=_0x21d8a2,f(!v(_0x21d8a2)&&y(_0x21d8a2)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x298236){return _0x298236['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2ef37d){return!_0x2ef37d['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x492e1f,_0x2fd414){const _0x434394=this['extractChild'](_0x492e1f['node']),_0xf60e91=this['extractChild'](_0x2fd414['node']),_0x6c3591=_0x434394['compareTo'](_0xf60e91);return _0x6c3591===0x0?He(_0x492e1f['name'],_0x2fd414['name']):_0x6c3591;}['makePost'](_0x238d4f,_0x46b00f){const _0x5e26fe=N(_0x238d4f),_0x57f0ab=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5e26fe);return new E(_0x46b00f,_0x57f0ab);}['maxPost'](){const _0x498b93=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x498b93);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x51a5fe,_0x4663cd){const _0x3ffa77=_0x51a5fe['node']['compareTo'](_0x4663cd['node']);return _0x3ffa77===0x0?He(_0x51a5fe['name'],_0x4663cd['name']):_0x3ffa77;}['isDefinedOn'](_0x19979a){return!0x0;}['indexedValueChanged'](_0x15a5f8,_0x211c9f){return!_0x15a5f8['equals'](_0x211c9f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x450667,_0x109e04){const _0x15d0ab=N(_0x450667);return new E(_0x109e04,_0x15d0ab);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x34d4a2){return{'type':'value','snapshotNode':_0x34d4a2};}function tt(_0x53e8de,_0x5cba1d){return{'type':'child_added','snapshotNode':_0x5cba1d,'childName':_0x53e8de};}function Nt(_0x329f40,_0x54a700){return{'type':'child_removed','snapshotNode':_0x54a700,'childName':_0x329f40};}function Pt(_0xec198c,_0x12bf3f,_0x351145){return{'type':'child_changed','snapshotNode':_0x12bf3f,'childName':_0xec198c,'oldSnap':_0x351145};}function $h(_0x4bcb00,_0x5d1541){return{'type':'child_moved','snapshotNode':_0x5d1541,'childName':_0x4bcb00};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x46e6d1){this['index_']=_0x46e6d1;}['updateChild'](_0x53afdb,_0x515bdd,_0x1d02f1,_0x56dc58,_0x24a529,_0x11075d){f(_0x53afdb['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4efadd=_0x53afdb['getImmediateChild'](_0x515bdd);return _0x4efadd['getChild'](_0x56dc58)['equals'](_0x1d02f1['getChild'](_0x56dc58))&&_0x4efadd['isEmpty']()===_0x1d02f1['isEmpty']()||(_0x11075d!=null&&(_0x1d02f1['isEmpty']()?_0x53afdb['hasChild'](_0x515bdd)?_0x11075d['trackChildChange'](Nt(_0x515bdd,_0x4efadd)):f(_0x53afdb['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4efadd['isEmpty']()?_0x11075d['trackChildChange'](tt(_0x515bdd,_0x1d02f1)):_0x11075d['trackChildChange'](Pt(_0x515bdd,_0x1d02f1,_0x4efadd))),_0x53afdb['isLeafNode']()&&_0x1d02f1['isEmpty']())?_0x53afdb:_0x53afdb['updateImmediateChild'](_0x515bdd,_0x1d02f1)['withIndex'](this['index_']);}['updateFullNode'](_0x3c6a0f,_0x487638,_0x347fe0){return _0x347fe0!=null&&(_0x3c6a0f['isLeafNode']()||_0x3c6a0f['forEachChild'](R,(_0x291984,_0x1bb7b5)=>{_0x487638['hasChild'](_0x291984)||_0x347fe0['trackChildChange'](Nt(_0x291984,_0x1bb7b5));}),_0x487638['isLeafNode']()||_0x487638['forEachChild'](R,(_0x12b163,_0x4fd621)=>{if(_0x3c6a0f['hasChild'](_0x12b163)){const _0xf34786=_0x3c6a0f['getImmediateChild'](_0x12b163);_0xf34786['equals'](_0x4fd621)||_0x347fe0['trackChildChange'](Pt(_0x12b163,_0x4fd621,_0xf34786));}else _0x347fe0['trackChildChange'](tt(_0x12b163,_0x4fd621));})),_0x487638['withIndex'](this['index_']);}['updatePriority'](_0xeb68da,_0x3463b9){return _0xeb68da['isEmpty']()?g['EMPTY_NODE']:_0xeb68da['updatePriority'](_0x3463b9);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x4ce8c7){this['indexedFilter_']=new Yi(_0x4ce8c7['getIndex']()),this['index_']=_0x4ce8c7['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x4ce8c7),this['endPost_']=Ot['getEndPost_'](_0x4ce8c7),this['startIsInclusive_']=!_0x4ce8c7['startAfterSet_'],this['endIsInclusive_']=!_0x4ce8c7['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x487d70){const _0x49621f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x487d70)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x487d70)<0x0,_0x231778=this['endIsInclusive_']?this['index_']['compare'](_0x487d70,this['getEndPost']())<=0x0:this['index_']['compare'](_0x487d70,this['getEndPost']())<0x0;return _0x49621f&&_0x231778;}['updateChild'](_0x46c628,_0x4506dd,_0x5d9eb5,_0x1cc9ab,_0x2fa925,_0x3dd492){return this['matches'](new E(_0x4506dd,_0x5d9eb5))||(_0x5d9eb5=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x46c628,_0x4506dd,_0x5d9eb5,_0x1cc9ab,_0x2fa925,_0x3dd492);}['updateFullNode'](_0x325a55,_0x2d5697,_0x1f57fe){_0x2d5697['isLeafNode']()&&(_0x2d5697=g['EMPTY_NODE']);let _0x3e7193=_0x2d5697['withIndex'](this['index_']);_0x3e7193=_0x3e7193['updatePriority'](g['EMPTY_NODE']);const _0x1c61f2=this;return _0x2d5697['forEachChild'](R,(_0x1eae0f,_0x151ebf)=>{_0x1c61f2['matches'](new E(_0x1eae0f,_0x151ebf))||(_0x3e7193=_0x3e7193['updateImmediateChild'](_0x1eae0f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x325a55,_0x3e7193,_0x1f57fe);}['updatePriority'](_0x204ab1,_0x5712c3){return _0x204ab1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x16862d){if(_0x16862d['hasStart']()){const _0x49abe3=_0x16862d['getIndexStartName']();return _0x16862d['getIndex']()['makePost'](_0x16862d['getIndexStartValue'](),_0x49abe3);}else return _0x16862d['getIndex']()['minPost']();}static['getEndPost_'](_0x1260c1){if(_0x1260c1['hasEnd']()){const _0x3e06bc=_0x1260c1['getIndexEndName']();return _0x1260c1['getIndex']()['makePost'](_0x1260c1['getIndexEndValue'](),_0x3e06bc);}else return _0x1260c1['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x1d84b0){this['withinDirectionalStart']=_0x103145=>this['reverse_']?this['withinEndPost'](_0x103145):this['withinStartPost'](_0x103145),this['withinDirectionalEnd']=_0x167253=>this['reverse_']?this['withinStartPost'](_0x167253):this['withinEndPost'](_0x167253),this['withinStartPost']=_0x312a8f=>{const _0x46eb31=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x312a8f);return this['startIsInclusive_']?_0x46eb31<=0x0:_0x46eb31<0x0;},this['withinEndPost']=_0x52191e=>{const _0x535ad7=this['index_']['compare'](_0x52191e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x535ad7<=0x0:_0x535ad7<0x0;},this['rangedFilter_']=new Ot(_0x1d84b0),this['index_']=_0x1d84b0['getIndex'](),this['limit_']=_0x1d84b0['getLimit'](),this['reverse_']=!_0x1d84b0['isViewFromLeft'](),this['startIsInclusive_']=!_0x1d84b0['startAfterSet_'],this['endIsInclusive_']=!_0x1d84b0['endBeforeSet_'];}['updateChild'](_0x1ad869,_0x9454c,_0x318a3f,_0x49c455,_0x4c6c50,_0x1ae6c3){return this['rangedFilter_']['matches'](new E(_0x9454c,_0x318a3f))||(_0x318a3f=g['EMPTY_NODE']),_0x1ad869['getImmediateChild'](_0x9454c)['equals'](_0x318a3f)?_0x1ad869:_0x1ad869['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1ad869,_0x9454c,_0x318a3f,_0x49c455,_0x4c6c50,_0x1ae6c3):this['fullLimitUpdateChild_'](_0x1ad869,_0x9454c,_0x318a3f,_0x4c6c50,_0x1ae6c3);}['updateFullNode'](_0x2aab63,_0x2e4f75,_0x30b1e9){let _0x4b065b;if(_0x2e4f75['isLeafNode']()||_0x2e4f75['isEmpty']())_0x4b065b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2e4f75['numChildren']()&&_0x2e4f75['isIndexed'](this['index_'])){_0x4b065b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x2e14b4;this['reverse_']?_0x2e14b4=_0x2e4f75['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x2e14b4=_0x2e4f75['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x358876=0x0;for(;_0x2e14b4['hasNext']()&&_0x358876<this['limit_'];){const _0x36a3c7=_0x2e14b4['getNext']();if(this['withinDirectionalStart'](_0x36a3c7)){if(this['withinDirectionalEnd'](_0x36a3c7))_0x4b065b=_0x4b065b['updateImmediateChild'](_0x36a3c7['name'],_0x36a3c7['node']),_0x358876++;else break;}else continue;}}else{_0x4b065b=_0x2e4f75['withIndex'](this['index_']),_0x4b065b=_0x4b065b['updatePriority'](g['EMPTY_NODE']);let _0x72f22;this['reverse_']?_0x72f22=_0x4b065b['getReverseIterator'](this['index_']):_0x72f22=_0x4b065b['getIterator'](this['index_']);let _0x218031=0x0;for(;_0x72f22['hasNext']();){const _0x848348=_0x72f22['getNext']();_0x218031<this['limit_']&&this['withinDirectionalStart'](_0x848348)&&this['withinDirectionalEnd'](_0x848348)?_0x218031++:_0x4b065b=_0x4b065b['updateImmediateChild'](_0x848348['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2aab63,_0x4b065b,_0x30b1e9);}['updatePriority'](_0xbea0d2,_0xa070cb){return _0xbea0d2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4c4719,_0x48896d,_0x5626f5,_0x45e89f,_0x21e74c){let _0x5d9dca;if(this['reverse_']){const _0x1fae60=this['index_']['getCompare']();_0x5d9dca=(_0x2eb6fc,_0x2e0290)=>_0x1fae60(_0x2e0290,_0x2eb6fc);}else _0x5d9dca=this['index_']['getCompare']();const _0x395dfc=_0x4c4719;f(_0x395dfc['numChildren']()===this['limit_'],'');const _0x1eb987=new E(_0x48896d,_0x5626f5),_0x2849b8=this['reverse_']?_0x395dfc['getFirstChild'](this['index_']):_0x395dfc['getLastChild'](this['index_']),_0x256b34=this['rangedFilter_']['matches'](_0x1eb987);if(_0x395dfc['hasChild'](_0x48896d)){const _0x10fad9=_0x395dfc['getImmediateChild'](_0x48896d);let _0x217b63=_0x45e89f['getChildAfterChild'](this['index_'],_0x2849b8,this['reverse_']);for(;_0x217b63!=null&&(_0x217b63['name']===_0x48896d||_0x395dfc['hasChild'](_0x217b63['name']));)_0x217b63=_0x45e89f['getChildAfterChild'](this['index_'],_0x217b63,this['reverse_']);const _0x42fce4=_0x217b63==null?0x1:_0x5d9dca(_0x217b63,_0x1eb987);if(_0x256b34&&!_0x5626f5['isEmpty']()&&_0x42fce4>=0x0)return _0x21e74c!=null&&_0x21e74c['trackChildChange'](Pt(_0x48896d,_0x5626f5,_0x10fad9)),_0x395dfc['updateImmediateChild'](_0x48896d,_0x5626f5);{_0x21e74c!=null&&_0x21e74c['trackChildChange'](Nt(_0x48896d,_0x10fad9));const _0x194c51=_0x395dfc['updateImmediateChild'](_0x48896d,g['EMPTY_NODE']);return _0x217b63!=null&&this['rangedFilter_']['matches'](_0x217b63)?(_0x21e74c!=null&&_0x21e74c['trackChildChange'](tt(_0x217b63['name'],_0x217b63['node'])),_0x194c51['updateImmediateChild'](_0x217b63['name'],_0x217b63['node'])):_0x194c51;}}else return _0x5626f5['isEmpty']()?_0x4c4719:_0x256b34&&_0x5d9dca(_0x2849b8,_0x1eb987)>=0x0?(_0x21e74c!=null&&(_0x21e74c['trackChildChange'](Nt(_0x2849b8['name'],_0x2849b8['node'])),_0x21e74c['trackChildChange'](tt(_0x48896d,_0x5626f5))),_0x395dfc['updateImmediateChild'](_0x48896d,_0x5626f5)['updateImmediateChild'](_0x2849b8['name'],g['EMPTY_NODE'])):_0x4c4719;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x339e02=new Qi();return _0x339e02['limitSet_']=this['limitSet_'],_0x339e02['limit_']=this['limit_'],_0x339e02['startSet_']=this['startSet_'],_0x339e02['startAfterSet_']=this['startAfterSet_'],_0x339e02['indexStartValue_']=this['indexStartValue_'],_0x339e02['startNameSet_']=this['startNameSet_'],_0x339e02['indexStartName_']=this['indexStartName_'],_0x339e02['endSet_']=this['endSet_'],_0x339e02['endBeforeSet_']=this['endBeforeSet_'],_0x339e02['indexEndValue_']=this['indexEndValue_'],_0x339e02['endNameSet_']=this['endNameSet_'],_0x339e02['indexEndName_']=this['indexEndName_'],_0x339e02['index_']=this['index_'],_0x339e02['viewFrom_']=this['viewFrom_'],_0x339e02;}}function qh(_0x2e14d9){return _0x2e14d9['loadsAllData']()?new Yi(_0x2e14d9['getIndex']()):_0x2e14d9['hasLimit']()?new Gh(_0x2e14d9):new Ot(_0x2e14d9);}function zh(_0x14905a,_0xb172df){const _0x1d6170=_0x14905a['copy']();return _0x1d6170['limitSet_']=!0x0,_0x1d6170['limit_']=_0xb172df,_0x1d6170['viewFrom_']='l',_0x1d6170;}function jh(_0x1f7d75,_0x247f67,_0x515a64){const _0x86b649=_0x1f7d75['copy']();return _0x86b649['startSet_']=!0x0,_0x247f67===void 0x0&&(_0x247f67=null),_0x86b649['indexStartValue_']=_0x247f67,_0x515a64!=null?(_0x86b649['startNameSet_']=!0x0,_0x86b649['indexStartName_']=_0x515a64):(_0x86b649['startNameSet_']=!0x1,_0x86b649['indexStartName_']=''),_0x86b649;}function Kh(_0x38d92b,_0x39baf8,_0x21d78c){const _0x3137b0=_0x38d92b['copy']();return _0x3137b0['endSet_']=!0x0,_0x39baf8===void 0x0&&(_0x39baf8=null),_0x3137b0['indexEndValue_']=_0x39baf8,_0x21d78c!==void 0x0?(_0x3137b0['endNameSet_']=!0x0,_0x3137b0['indexEndName_']=_0x21d78c):(_0x3137b0['endNameSet_']=!0x1,_0x3137b0['indexEndName_']=''),_0x3137b0;}function Do(_0x3a88f8,_0x4bc978){const _0x145c49=_0x3a88f8['copy']();return _0x145c49['index_']=_0x4bc978,_0x145c49;}function tr(_0xf11a33){const _0x5cfbda={};if(_0xf11a33['isDefault']())return _0x5cfbda;let _0x86c7a1;if(_0xf11a33['index_']===R?_0x86c7a1='$priority':_0xf11a33['index_']===Po?_0x86c7a1='$value':_0xf11a33['index_']===ye?_0x86c7a1='$key':(f(_0xf11a33['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x86c7a1=_0xf11a33['index_']['toString']()),_0x5cfbda['orderBy']=O(_0x86c7a1),_0xf11a33['startSet_']){const _0x4751eb=_0xf11a33['startAfterSet_']?'startAfter':'startAt';_0x5cfbda[_0x4751eb]=O(_0xf11a33['indexStartValue_']),_0xf11a33['startNameSet_']&&(_0x5cfbda[_0x4751eb]+=','+O(_0xf11a33['indexStartName_']));}if(_0xf11a33['endSet_']){const _0x2284d3=_0xf11a33['endBeforeSet_']?'endBefore':'endAt';_0x5cfbda[_0x2284d3]=O(_0xf11a33['indexEndValue_']),_0xf11a33['endNameSet_']&&(_0x5cfbda[_0x2284d3]+=','+O(_0xf11a33['indexEndName_']));}return _0xf11a33['limitSet_']&&(_0xf11a33['isViewFromLeft']()?_0x5cfbda['limitToFirst']=_0xf11a33['limit_']:_0x5cfbda['limitToLast']=_0xf11a33['limit_']),_0x5cfbda;}function nr(_0x504c5e){const _0x199255={};if(_0x504c5e['startSet_']&&(_0x199255['sp']=_0x504c5e['indexStartValue_'],_0x504c5e['startNameSet_']&&(_0x199255['sn']=_0x504c5e['indexStartName_']),_0x199255['sin']=!_0x504c5e['startAfterSet_']),_0x504c5e['endSet_']&&(_0x199255['ep']=_0x504c5e['indexEndValue_'],_0x504c5e['endNameSet_']&&(_0x199255['en']=_0x504c5e['indexEndName_']),_0x199255['ein']=!_0x504c5e['endBeforeSet_']),_0x504c5e['limitSet_']){_0x199255['l']=_0x504c5e['limit_'];let _0x515f1a=_0x504c5e['viewFrom_'];_0x515f1a===''&&(_0x504c5e['isViewFromLeft']()?_0x515f1a='l':_0x515f1a='r'),_0x199255['vf']=_0x515f1a;}return _0x504c5e['index_']!==R&&(_0x199255['i']=_0x504c5e['index_']['toString']()),_0x199255;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x337143){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3a5de7,_0x644c7c){return _0x644c7c!==void 0x0?'tag$'+_0x644c7c:(f(_0x3a5de7['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3a5de7['_path']['toString']());}constructor(_0x4a5002,_0x4ae00a,_0x5603c2,_0x501162){super(),this['repoInfo_']=_0x4a5002,this['onDataUpdate_']=_0x4ae00a,this['authTokenProvider_']=_0x5603c2,this['appCheckTokenProvider_']=_0x501162,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x465eee,_0xd0b6c4,_0x35814c,_0x360cbc){const _0xb5b2e1=_0x465eee['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xb5b2e1+'\x20'+_0x465eee['_queryIdentifier']);const _0x4a23e8=fn['getListenId_'](_0x465eee,_0x35814c),_0x3f6849={};this['listens_'][_0x4a23e8]=_0x3f6849;const _0x127489=tr(_0x465eee['_queryParams']);this['restRequest_'](_0xb5b2e1+'.json',_0x127489,(_0xc6472e,_0x12ab7a)=>{let _0x5a2c29=_0x12ab7a;if(_0xc6472e===0x194&&(_0x5a2c29=null,_0xc6472e=null),_0xc6472e===null&&this['onDataUpdate_'](_0xb5b2e1,_0x5a2c29,!0x1,_0x35814c),Oe(this['listens_'],_0x4a23e8)===_0x3f6849){let _0x175597;_0xc6472e?_0xc6472e===0x191?_0x175597='permission_denied':_0x175597='rest_error:'+_0xc6472e:_0x175597='ok',_0x360cbc(_0x175597,null);}});}['unlisten'](_0x76a8e5,_0x2ec647){const _0x51d71d=fn['getListenId_'](_0x76a8e5,_0x2ec647);delete this['listens_'][_0x51d71d];}['get'](_0x1f6190){const _0x292586=tr(_0x1f6190['_queryParams']),_0x5a4df6=_0x1f6190['_path']['toString'](),_0x1d92d7=new Ve();return this['restRequest_'](_0x5a4df6+'.json',_0x292586,(_0x34ab28,_0x1c2758)=>{let _0x323707=_0x1c2758;_0x34ab28===0x194&&(_0x323707=null,_0x34ab28=null),_0x34ab28===null?(this['onDataUpdate_'](_0x5a4df6,_0x323707,!0x1,null),_0x1d92d7['resolve'](_0x323707)):_0x1d92d7['reject'](new Error(_0x323707));}),_0x1d92d7['promise'];}['refreshAuthToken'](_0x4abdf9){}['restRequest_'](_0x5be0b7,_0x2cc393={},_0x52c1e2){return _0x2cc393['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x34f449,_0xb1c063])=>{_0x34f449&&_0x34f449['accessToken']&&(_0x2cc393['auth']=_0x34f449['accessToken']),_0xb1c063&&_0xb1c063['token']&&(_0x2cc393['ac']=_0xb1c063['token']);const _0x4983c0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5be0b7+'?ns='+this['repoInfo_']['namespace']+at(_0x2cc393);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4983c0);const _0x3f7d72=new XMLHttpRequest();_0x3f7d72['onreadystatechange']=()=>{if(_0x52c1e2&&_0x3f7d72['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4983c0+'\x20received.\x20status:',_0x3f7d72['status'],'response:',_0x3f7d72['responseText']);let _0x180cde=null;if(_0x3f7d72['status']>=0xc8&&_0x3f7d72['status']<0x12c){try{_0x180cde=bt(_0x3f7d72['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4983c0+':\x20'+_0x3f7d72['responseText']);}_0x52c1e2(null,_0x180cde);}else _0x3f7d72['status']!==0x191&&_0x3f7d72['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4983c0+'\x20Status:\x20'+_0x3f7d72['status']),_0x52c1e2(_0x3f7d72['status']);_0x52c1e2=null;}},_0x3f7d72['open']('GET',_0x4983c0,!0x0),_0x3f7d72['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x19a426){return this['rootNode_']['getChild'](_0x19a426);}['updateSnapshot'](_0x2ec729,_0x2c52dc){this['rootNode_']=this['rootNode_']['updateChild'](_0x2ec729,_0x2c52dc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x585ea6,_0x318419,_0x125248){if(v(_0x318419))_0x585ea6['value']=_0x125248,_0x585ea6['children']['clear']();else{if(_0x585ea6['value']!==null)_0x585ea6['value']=_0x585ea6['value']['updateChild'](_0x318419,_0x125248);else{const _0x2829a5=y(_0x318419);_0x585ea6['children']['has'](_0x2829a5)||_0x585ea6['children']['set'](_0x2829a5,pn());const _0x5ecaaa=_0x585ea6['children']['get'](_0x2829a5);_0x318419=b(_0x318419),Mo(_0x5ecaaa,_0x318419,_0x125248);}}}function Ei(_0x2e5b40,_0xbec7ef,_0x2d61aa){_0x2e5b40['value']!==null?_0x2d61aa(_0xbec7ef,_0x2e5b40['value']):Qh(_0x2e5b40,(_0xd19d6f,_0xc62f89)=>{const _0x3696a0=new C(_0xbec7ef['toString']()+'/'+_0xd19d6f);Ei(_0xc62f89,_0x3696a0,_0x2d61aa);});}function Qh(_0x57538a,_0x3cb738){_0x57538a['children']['forEach']((_0x542bc1,_0x51d0a4)=>{_0x3cb738(_0x51d0a4,_0x542bc1);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x17995c){this['collection_']=_0x17995c,this['last_']=null;}['get'](){const _0x2aed47=this['collection_']['get'](),_0x54232e={..._0x2aed47};return this['last_']&&x(this['last_'],(_0x3b9197,_0x22410e)=>{_0x54232e[_0x3b9197]=_0x54232e[_0x3b9197]-_0x22410e;}),this['last_']=_0x2aed47,_0x54232e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x391e5a,_0x370522){this['server_']=_0x370522,this['statsToReport_']={},this['statsListener_']=new Jh(_0x391e5a);const _0x5a8258=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x5a8258));}['reportStats_'](){const _0x591848=this['statsListener_']['get'](),_0x4ccb38={};let _0x116522=!0x1;x(_0x591848,(_0x25ac79,_0x94a3a1)=>{_0x94a3a1>0x0&&Y(this['statsToReport_'],_0x25ac79)&&(_0x4ccb38[_0x25ac79]=_0x94a3a1,_0x116522=!0x0);}),_0x116522&&this['server_']['reportStats'](_0x4ccb38),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x457cf4){_0x457cf4[_0x457cf4['OVERWRITE']=0x0]='OVERWRITE',_0x457cf4[_0x457cf4['MERGE']=0x1]='MERGE',_0x457cf4[_0x457cf4['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x457cf4[_0x457cf4['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x11da04){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x11da04,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4f8b61,_0x5271b4,_0x5603d0){this['path']=_0x4f8b61,this['affectedTree']=_0x5271b4,this['revert']=_0x5603d0,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x527d23){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x424d52=this['affectedTree']['subtree'](new C(_0x527d23));return new _n(w(),_0x424d52,this['revert']);}}else return f(y(this['path'])===_0x527d23,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x54b75a,_0x985f93){this['source']=_0x54b75a,this['path']=_0x985f93,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x518516){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x368077,_0x17d8b7,_0x31975f){this['source']=_0x368077,this['path']=_0x17d8b7,this['snap']=_0x31975f,this['type']=q['OVERWRITE'];}['operationForChild'](_0x43308e){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x43308e)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x447142,_0x2f0d7c,_0x36143e){this['source']=_0x447142,this['path']=_0x2f0d7c,this['children']=_0x36143e,this['type']=q['MERGE'];}['operationForChild'](_0x578457){if(v(this['path'])){const _0x156186=this['children']['subtree'](new C(_0x578457));return _0x156186['isEmpty']()?null:_0x156186['value']?new Fe(this['source'],w(),_0x156186['value']):new nt(this['source'],w(),_0x156186);}else return f(y(this['path'])===_0x578457,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x38fbda,_0x22e7dd,_0x525fc6){this['node_']=_0x38fbda,this['fullyInitialized_']=_0x22e7dd,this['filtered_']=_0x525fc6;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xd0ac82){if(v(_0xd0ac82))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3b9a19=y(_0xd0ac82);return this['isCompleteForChild'](_0x3b9a19);}['isCompleteForChild'](_0xe17f0e){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0xe17f0e);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x260a94){this['query_']=_0x260a94,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x361750,_0xa9374d,_0xc72b4,_0x485c21){const _0x22f151=[],_0x280fdb=[];return _0xa9374d['forEach'](_0x414a09=>{_0x414a09['type']==='child_changed'&&_0x361750['index_']['indexedValueChanged'](_0x414a09['oldSnap'],_0x414a09['snapshotNode'])&&_0x280fdb['push']($h(_0x414a09['childName'],_0x414a09['snapshotNode']));}),mt(_0x361750,_0x22f151,'child_removed',_0xa9374d,_0x485c21,_0xc72b4),mt(_0x361750,_0x22f151,'child_added',_0xa9374d,_0x485c21,_0xc72b4),mt(_0x361750,_0x22f151,'child_moved',_0x280fdb,_0x485c21,_0xc72b4),mt(_0x361750,_0x22f151,'child_changed',_0xa9374d,_0x485c21,_0xc72b4),mt(_0x361750,_0x22f151,'value',_0xa9374d,_0x485c21,_0xc72b4),_0x22f151;}function mt(_0x3225f5,_0x44f8fd,_0x411b98,_0x448fa2,_0x3b029d,_0x10e96b){const _0xcae9cc=_0x448fa2['filter'](_0x16d6d5=>_0x16d6d5['type']===_0x411b98);_0xcae9cc['sort']((_0x491a82,_0x10db9d)=>su(_0x3225f5,_0x491a82,_0x10db9d)),_0xcae9cc['forEach'](_0x7ac293=>{const _0x4d50d0=iu(_0x3225f5,_0x7ac293,_0x10e96b);_0x3b029d['forEach'](_0x3c7fa1=>{_0x3c7fa1['respondsTo'](_0x7ac293['type'])&&_0x44f8fd['push'](_0x3c7fa1['createEvent'](_0x4d50d0,_0x3225f5['query_']));});});}function iu(_0x285d20,_0x2c5211,_0x181d94){return _0x2c5211['type']==='value'||_0x2c5211['type']==='child_removed'||(_0x2c5211['prevName']=_0x181d94['getPredecessorChildName'](_0x2c5211['childName'],_0x2c5211['snapshotNode'],_0x285d20['index_'])),_0x2c5211;}function su(_0x5e43ff,_0x103c6c,_0x137429){if(_0x103c6c['childName']==null||_0x137429['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x49d2b5=new E(_0x103c6c['childName'],_0x103c6c['snapshotNode']),_0x1a30af=new E(_0x137429['childName'],_0x137429['snapshotNode']);return _0x5e43ff['index_']['compare'](_0x49d2b5,_0x1a30af);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x3ff963,_0x4fabd8){return{'eventCache':_0x3ff963,'serverCache':_0x4fabd8};}function wt(_0x5a883a,_0xd00ed1,_0x54c01a,_0x58cd21){return Dn(new Ce(_0xd00ed1,_0x54c01a,_0x58cd21),_0x5a883a['serverCache']);}function Lo(_0x5bb121,_0x6a2a46,_0x42d447,_0x8f3ea4){return Dn(_0x5bb121['eventCache'],new Ce(_0x6a2a46,_0x42d447,_0x8f3ea4));}function gn(_0x2c6192){return _0x2c6192['eventCache']['isFullyInitialized']()?_0x2c6192['eventCache']['getNode']():null;}function Ue(_0x1d11aa){return _0x1d11aa['serverCache']['isFullyInitialized']()?_0x1d11aa['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x5544cb){let _0x2b7004=new S(null);return x(_0x5544cb,(_0x93e9bc,_0x7a77c0)=>{_0x2b7004=_0x2b7004['set'](new C(_0x93e9bc),_0x7a77c0);}),_0x2b7004;}constructor(_0x236a4a,_0x4da8fe=ru()){this['value']=_0x236a4a,this['children']=_0x4da8fe;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1a2fd3,_0x58c35a){if(this['value']!=null&&_0x58c35a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1a2fd3))return null;{const _0x508e47=y(_0x1a2fd3),_0x350632=this['children']['get'](_0x508e47);if(_0x350632!==null){const _0x214738=_0x350632['findRootMostMatchingPathAndValue'](b(_0x1a2fd3),_0x58c35a);return _0x214738!=null?{'path':A(new C(_0x508e47),_0x214738['path']),'value':_0x214738['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x490a97){return this['findRootMostMatchingPathAndValue'](_0x490a97,()=>!0x0);}['subtree'](_0x46ed27){if(v(_0x46ed27))return this;{const _0x611325=y(_0x46ed27),_0x29bc96=this['children']['get'](_0x611325);return _0x29bc96!==null?_0x29bc96['subtree'](b(_0x46ed27)):new S(null);}}['set'](_0x551a4f,_0x593bc7){if(v(_0x551a4f))return new S(_0x593bc7,this['children']);{const _0xd425fe=y(_0x551a4f),_0x33f4d0=(this['children']['get'](_0xd425fe)||new S(null))['set'](b(_0x551a4f),_0x593bc7),_0x40f7a1=this['children']['insert'](_0xd425fe,_0x33f4d0);return new S(this['value'],_0x40f7a1);}}['remove'](_0x1cea43){if(v(_0x1cea43))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5a0317=y(_0x1cea43),_0x13ad39=this['children']['get'](_0x5a0317);if(_0x13ad39){const _0xdfcdf6=_0x13ad39['remove'](b(_0x1cea43));let _0x3caf16;return _0xdfcdf6['isEmpty']()?_0x3caf16=this['children']['remove'](_0x5a0317):_0x3caf16=this['children']['insert'](_0x5a0317,_0xdfcdf6),this['value']===null&&_0x3caf16['isEmpty']()?new S(null):new S(this['value'],_0x3caf16);}else return this;}}['get'](_0x4dab46){if(v(_0x4dab46))return this['value'];{const _0x174abe=y(_0x4dab46),_0x1d0e59=this['children']['get'](_0x174abe);return _0x1d0e59?_0x1d0e59['get'](b(_0x4dab46)):null;}}['setTree'](_0x1e1405,_0x59aff8){if(v(_0x1e1405))return _0x59aff8;{const _0x2e2b28=y(_0x1e1405),_0x4aefa0=(this['children']['get'](_0x2e2b28)||new S(null))['setTree'](b(_0x1e1405),_0x59aff8);let _0x487078;return _0x4aefa0['isEmpty']()?_0x487078=this['children']['remove'](_0x2e2b28):_0x487078=this['children']['insert'](_0x2e2b28,_0x4aefa0),new S(this['value'],_0x487078);}}['fold'](_0x3b3177){return this['fold_'](w(),_0x3b3177);}['fold_'](_0x3fd54c,_0x4203ac){const _0x4430ed={};return this['children']['inorderTraversal']((_0x2edf27,_0x4781f7)=>{_0x4430ed[_0x2edf27]=_0x4781f7['fold_'](A(_0x3fd54c,_0x2edf27),_0x4203ac);}),_0x4203ac(_0x3fd54c,this['value'],_0x4430ed);}['findOnPath'](_0x3eb4c1,_0x309263){return this['findOnPath_'](_0x3eb4c1,w(),_0x309263);}['findOnPath_'](_0x2ec32f,_0x9c74a1,_0x25f365){const _0x32b7af=this['value']?_0x25f365(_0x9c74a1,this['value']):!0x1;if(_0x32b7af)return _0x32b7af;if(v(_0x2ec32f))return null;{const _0x5a5b27=y(_0x2ec32f),_0x4c6523=this['children']['get'](_0x5a5b27);return _0x4c6523?_0x4c6523['findOnPath_'](b(_0x2ec32f),A(_0x9c74a1,_0x5a5b27),_0x25f365):null;}}['foreachOnPath'](_0x3aa7d4,_0x4b5a1f){return this['foreachOnPath_'](_0x3aa7d4,w(),_0x4b5a1f);}['foreachOnPath_'](_0x416cdc,_0x46ca94,_0x12fab5){if(v(_0x416cdc))return this;{this['value']&&_0x12fab5(_0x46ca94,this['value']);const _0x49dcab=y(_0x416cdc),_0x4a76ae=this['children']['get'](_0x49dcab);return _0x4a76ae?_0x4a76ae['foreachOnPath_'](b(_0x416cdc),A(_0x46ca94,_0x49dcab),_0x12fab5):new S(null);}}['foreach'](_0x5dc480){this['foreach_'](w(),_0x5dc480);}['foreach_'](_0x3be67c,_0x3ee74e){this['children']['inorderTraversal']((_0x1a2bad,_0x158992)=>{_0x158992['foreach_'](A(_0x3be67c,_0x1a2bad),_0x3ee74e);}),this['value']&&_0x3ee74e(_0x3be67c,this['value']);}['foreachChild'](_0x28287d){this['children']['inorderTraversal']((_0x4888bc,_0x5d0a28)=>{_0x5d0a28['value']&&_0x28287d(_0x4888bc,_0x5d0a28['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x56b6be){this['writeTree_']=_0x56b6be;}static['empty'](){return new j(new S(null));}}function Ct(_0x2762ae,_0x127cd8,_0x13436b){if(v(_0x127cd8))return new j(new S(_0x13436b));{const _0xcd42cb=_0x2762ae['writeTree_']['findRootMostValueAndPath'](_0x127cd8);if(_0xcd42cb!=null){const _0x4b5b8b=_0xcd42cb['path'];let _0x51506b=_0xcd42cb['value'];const _0x2950f7=F(_0x4b5b8b,_0x127cd8);return _0x51506b=_0x51506b['updateChild'](_0x2950f7,_0x13436b),new j(_0x2762ae['writeTree_']['set'](_0x4b5b8b,_0x51506b));}else{const _0x7e173f=new S(_0x13436b),_0x22ae4b=_0x2762ae['writeTree_']['setTree'](_0x127cd8,_0x7e173f);return new j(_0x22ae4b);}}}function Ii(_0x45895b,_0x7bc655,_0x28c6ec){let _0x3b982b=_0x45895b;return x(_0x28c6ec,(_0x4ec4d9,_0x15b869)=>{_0x3b982b=Ct(_0x3b982b,A(_0x7bc655,_0x4ec4d9),_0x15b869);}),_0x3b982b;}function sr(_0x44041f,_0x450e4d){if(v(_0x450e4d))return j['empty']();{const _0x5be598=_0x44041f['writeTree_']['setTree'](_0x450e4d,new S(null));return new j(_0x5be598);}}function wi(_0x535d71,_0x4d433c){return $e(_0x535d71,_0x4d433c)!=null;}function $e(_0x4de3ac,_0x2222a6){const _0x326c03=_0x4de3ac['writeTree_']['findRootMostValueAndPath'](_0x2222a6);return _0x326c03!=null?_0x4de3ac['writeTree_']['get'](_0x326c03['path'])['getChild'](F(_0x326c03['path'],_0x2222a6)):null;}function rr(_0x31a2c4){const _0x4e6f82=[],_0x162eca=_0x31a2c4['writeTree_']['value'];return _0x162eca!=null?_0x162eca['isLeafNode']()||_0x162eca['forEachChild'](R,(_0x4a7657,_0x52bc54)=>{_0x4e6f82['push'](new E(_0x4a7657,_0x52bc54));}):_0x31a2c4['writeTree_']['children']['inorderTraversal']((_0x490944,_0x1739e2)=>{_0x1739e2['value']!=null&&_0x4e6f82['push'](new E(_0x490944,_0x1739e2['value']));}),_0x4e6f82;}function ve(_0x198682,_0x532897){if(v(_0x532897))return _0x198682;{const _0x408d75=$e(_0x198682,_0x532897);return _0x408d75!=null?new j(new S(_0x408d75)):new j(_0x198682['writeTree_']['subtree'](_0x532897));}}function Ci(_0xfbcaf9){return _0xfbcaf9['writeTree_']['isEmpty']();}function it(_0xa8ecdd,_0x4bbea7){return xo(w(),_0xa8ecdd['writeTree_'],_0x4bbea7);}function xo(_0xfb6fbe,_0x12e3c2,_0xcae6da){if(_0x12e3c2['value']!=null)return _0xcae6da['updateChild'](_0xfb6fbe,_0x12e3c2['value']);{let _0x192a5a=null;return _0x12e3c2['children']['inorderTraversal']((_0x11987a,_0x5efeaf)=>{_0x11987a==='.priority'?(f(_0x5efeaf['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x192a5a=_0x5efeaf['value']):_0xcae6da=xo(A(_0xfb6fbe,_0x11987a),_0x5efeaf,_0xcae6da);}),!_0xcae6da['getChild'](_0xfb6fbe)['isEmpty']()&&_0x192a5a!==null&&(_0xcae6da=_0xcae6da['updateChild'](A(_0xfb6fbe,'.priority'),_0x192a5a)),_0xcae6da;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x313813,_0x594a5c){return Bo(_0x594a5c,_0x313813);}function ou(_0x46c37f,_0x2786b6,_0x57fc12,_0x28ecad,_0x3da42f){f(_0x28ecad>_0x46c37f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3da42f===void 0x0&&(_0x3da42f=!0x0),_0x46c37f['allWrites']['push']({'path':_0x2786b6,'snap':_0x57fc12,'writeId':_0x28ecad,'visible':_0x3da42f}),_0x3da42f&&(_0x46c37f['visibleWrites']=Ct(_0x46c37f['visibleWrites'],_0x2786b6,_0x57fc12)),_0x46c37f['lastWriteId']=_0x28ecad;}function au(_0xec8274,_0x585da7,_0x14bac6,_0x19965){f(_0x19965>_0xec8274['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xec8274['allWrites']['push']({'path':_0x585da7,'children':_0x14bac6,'writeId':_0x19965,'visible':!0x0}),_0xec8274['visibleWrites']=Ii(_0xec8274['visibleWrites'],_0x585da7,_0x14bac6),_0xec8274['lastWriteId']=_0x19965;}function cu(_0x390f94,_0xe7d669){for(let _0x45feb0=0x0;_0x45feb0<_0x390f94['allWrites']['length'];_0x45feb0++){const _0x128b8e=_0x390f94['allWrites'][_0x45feb0];if(_0x128b8e['writeId']===_0xe7d669)return _0x128b8e;}return null;}function lu(_0x48d8a1,_0x3948d4){const _0x5ae749=_0x48d8a1['allWrites']['findIndex'](_0x3d9d5e=>_0x3d9d5e['writeId']===_0x3948d4);f(_0x5ae749>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x31db87=_0x48d8a1['allWrites'][_0x5ae749];_0x48d8a1['allWrites']['splice'](_0x5ae749,0x1);let _0x15d99b=_0x31db87['visible'],_0x30f11f=!0x1,_0x2ae6a0=_0x48d8a1['allWrites']['length']-0x1;for(;_0x15d99b&&_0x2ae6a0>=0x0;){const _0x34af63=_0x48d8a1['allWrites'][_0x2ae6a0];_0x34af63['visible']&&(_0x2ae6a0>=_0x5ae749&&hu(_0x34af63,_0x31db87['path'])?_0x15d99b=!0x1:$(_0x31db87['path'],_0x34af63['path'])&&(_0x30f11f=!0x0)),_0x2ae6a0--;}if(_0x15d99b){if(_0x30f11f)return uu(_0x48d8a1),!0x0;if(_0x31db87['snap'])_0x48d8a1['visibleWrites']=sr(_0x48d8a1['visibleWrites'],_0x31db87['path']);else{const _0xe46015=_0x31db87['children'];x(_0xe46015,_0x4f96ce=>{_0x48d8a1['visibleWrites']=sr(_0x48d8a1['visibleWrites'],A(_0x31db87['path'],_0x4f96ce));});}return!0x0;}else return!0x1;}function hu(_0x2c9aa7,_0x5a3c70){if(_0x2c9aa7['snap'])return $(_0x2c9aa7['path'],_0x5a3c70);for(const _0x4752a1 in _0x2c9aa7['children'])if(_0x2c9aa7['children']['hasOwnProperty'](_0x4752a1)&&$(A(_0x2c9aa7['path'],_0x4752a1),_0x5a3c70))return!0x0;return!0x1;}function uu(_0x3d42cd){_0x3d42cd['visibleWrites']=Fo(_0x3d42cd['allWrites'],du,w()),_0x3d42cd['allWrites']['length']>0x0?_0x3d42cd['lastWriteId']=_0x3d42cd['allWrites'][_0x3d42cd['allWrites']['length']-0x1]['writeId']:_0x3d42cd['lastWriteId']=-0x1;}function du(_0x3484c2){return _0x3484c2['visible'];}function Fo(_0x2dac6a,_0x35fb01,_0x2a4e32){let _0x12c184=j['empty']();for(let _0x381d79=0x0;_0x381d79<_0x2dac6a['length'];++_0x381d79){const _0x961f46=_0x2dac6a[_0x381d79];if(_0x35fb01(_0x961f46)){const _0x27ec03=_0x961f46['path'];let _0x3aa6ec;if(_0x961f46['snap'])$(_0x2a4e32,_0x27ec03)?(_0x3aa6ec=F(_0x2a4e32,_0x27ec03),_0x12c184=Ct(_0x12c184,_0x3aa6ec,_0x961f46['snap'])):$(_0x27ec03,_0x2a4e32)&&(_0x3aa6ec=F(_0x27ec03,_0x2a4e32),_0x12c184=Ct(_0x12c184,w(),_0x961f46['snap']['getChild'](_0x3aa6ec)));else{if(_0x961f46['children']){if($(_0x2a4e32,_0x27ec03))_0x3aa6ec=F(_0x2a4e32,_0x27ec03),_0x12c184=Ii(_0x12c184,_0x3aa6ec,_0x961f46['children']);else{if($(_0x27ec03,_0x2a4e32)){if(_0x3aa6ec=F(_0x27ec03,_0x2a4e32),v(_0x3aa6ec))_0x12c184=Ii(_0x12c184,w(),_0x961f46['children']);else{const _0x23d12c=Oe(_0x961f46['children'],y(_0x3aa6ec));if(_0x23d12c){const _0x5d129f=_0x23d12c['getChild'](b(_0x3aa6ec));_0x12c184=Ct(_0x12c184,w(),_0x5d129f);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x12c184;}function Uo(_0x2a343d,_0x46f3df,_0x50c5cf,_0xe2a3ed,_0xf36ae6){if(!_0xe2a3ed&&!_0xf36ae6){const _0x50d50c=$e(_0x2a343d['visibleWrites'],_0x46f3df);if(_0x50d50c!=null)return _0x50d50c;{const _0x4257fd=ve(_0x2a343d['visibleWrites'],_0x46f3df);if(Ci(_0x4257fd))return _0x50c5cf;if(_0x50c5cf==null&&!wi(_0x4257fd,w()))return null;{const _0x45e79e=_0x50c5cf||g['EMPTY_NODE'];return it(_0x4257fd,_0x45e79e);}}}else{const _0x3b71e=ve(_0x2a343d['visibleWrites'],_0x46f3df);if(!_0xf36ae6&&Ci(_0x3b71e))return _0x50c5cf;if(!_0xf36ae6&&_0x50c5cf==null&&!wi(_0x3b71e,w()))return null;{const _0x4c2884=function(_0x2d52ad){return(_0x2d52ad['visible']||_0xf36ae6)&&(!_0xe2a3ed||!~_0xe2a3ed['indexOf'](_0x2d52ad['writeId']))&&($(_0x2d52ad['path'],_0x46f3df)||$(_0x46f3df,_0x2d52ad['path']));},_0x961282=Fo(_0x2a343d['allWrites'],_0x4c2884,_0x46f3df),_0x330876=_0x50c5cf||g['EMPTY_NODE'];return it(_0x961282,_0x330876);}}}function fu(_0x2a7f0b,_0x300b07,_0x1494d1){let _0x442325=g['EMPTY_NODE'];const _0x468292=$e(_0x2a7f0b['visibleWrites'],_0x300b07);if(_0x468292)return _0x468292['isLeafNode']()||_0x468292['forEachChild'](R,(_0x46473c,_0x4d981b)=>{_0x442325=_0x442325['updateImmediateChild'](_0x46473c,_0x4d981b);}),_0x442325;if(_0x1494d1){const _0x46ae7c=ve(_0x2a7f0b['visibleWrites'],_0x300b07);return _0x1494d1['forEachChild'](R,(_0x3a54b3,_0x412d30)=>{const _0x4ea476=it(ve(_0x46ae7c,new C(_0x3a54b3)),_0x412d30);_0x442325=_0x442325['updateImmediateChild'](_0x3a54b3,_0x4ea476);}),rr(_0x46ae7c)['forEach'](_0x22dca2=>{_0x442325=_0x442325['updateImmediateChild'](_0x22dca2['name'],_0x22dca2['node']);}),_0x442325;}else{const _0x3585bc=ve(_0x2a7f0b['visibleWrites'],_0x300b07);return rr(_0x3585bc)['forEach'](_0x1f69a1=>{_0x442325=_0x442325['updateImmediateChild'](_0x1f69a1['name'],_0x1f69a1['node']);}),_0x442325;}}function pu(_0x12e94c,_0x28aa47,_0xf835c7,_0x22983a,_0x1d44e6){f(_0x22983a||_0x1d44e6,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1d7a2a=A(_0x28aa47,_0xf835c7);if(wi(_0x12e94c['visibleWrites'],_0x1d7a2a))return null;{const _0x129dcb=ve(_0x12e94c['visibleWrites'],_0x1d7a2a);return Ci(_0x129dcb)?_0x1d44e6['getChild'](_0xf835c7):it(_0x129dcb,_0x1d44e6['getChild'](_0xf835c7));}}function _u(_0x3ff2a6,_0x5e9a75,_0x567270,_0xb45ab3){const _0x2ee935=A(_0x5e9a75,_0x567270),_0x5a0123=$e(_0x3ff2a6['visibleWrites'],_0x2ee935);if(_0x5a0123!=null)return _0x5a0123;if(_0xb45ab3['isCompleteForChild'](_0x567270)){const _0x568340=ve(_0x3ff2a6['visibleWrites'],_0x2ee935);return it(_0x568340,_0xb45ab3['getNode']()['getImmediateChild'](_0x567270));}else return null;}function gu(_0x241897,_0x126cf7){return $e(_0x241897['visibleWrites'],_0x126cf7);}function mu(_0x255230,_0x43bda5,_0x2de91f,_0xba271f,_0x361ca1,_0x4c2280,_0x2b97e4){let _0x4a5f21;const _0x325b15=ve(_0x255230['visibleWrites'],_0x43bda5),_0x20efc3=$e(_0x325b15,w());if(_0x20efc3!=null)_0x4a5f21=_0x20efc3;else{if(_0x2de91f!=null)_0x4a5f21=it(_0x325b15,_0x2de91f);else return[];}if(_0x4a5f21=_0x4a5f21['withIndex'](_0x2b97e4),!_0x4a5f21['isEmpty']()&&!_0x4a5f21['isLeafNode']()){const _0x591b22=[],_0x39ff48=_0x2b97e4['getCompare'](),_0xf96607=_0x4c2280?_0x4a5f21['getReverseIteratorFrom'](_0xba271f,_0x2b97e4):_0x4a5f21['getIteratorFrom'](_0xba271f,_0x2b97e4);let _0xa4f0a6=_0xf96607['getNext']();for(;_0xa4f0a6&&_0x591b22['length']<_0x361ca1;)_0x39ff48(_0xa4f0a6,_0xba271f)!==0x0&&_0x591b22['push'](_0xa4f0a6),_0xa4f0a6=_0xf96607['getNext']();return _0x591b22;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x17b5a7,_0x1fc1cf,_0x4b1361,_0x2ff4c7){return Uo(_0x17b5a7['writeTree'],_0x17b5a7['treePath'],_0x1fc1cf,_0x4b1361,_0x2ff4c7);}function es(_0x595828,_0x25f738){return fu(_0x595828['writeTree'],_0x595828['treePath'],_0x25f738);}function or(_0x42da6e,_0x544e31,_0x21a96e,_0xe48565){return pu(_0x42da6e['writeTree'],_0x42da6e['treePath'],_0x544e31,_0x21a96e,_0xe48565);}function yn(_0x2a35a6,_0x449360){return gu(_0x2a35a6['writeTree'],A(_0x2a35a6['treePath'],_0x449360));}function vu(_0xac638c,_0x3fdac7,_0x46628a,_0xd7fb74,_0x525fc9,_0x4aa059){return mu(_0xac638c['writeTree'],_0xac638c['treePath'],_0x3fdac7,_0x46628a,_0xd7fb74,_0x525fc9,_0x4aa059);}function ts(_0x513c11,_0x514386,_0x45cdb7){return _u(_0x513c11['writeTree'],_0x513c11['treePath'],_0x514386,_0x45cdb7);}function Wo(_0x35bf14,_0x4d112c){return Bo(A(_0x35bf14['treePath'],_0x4d112c),_0x35bf14['writeTree']);}function Bo(_0x285ea5,_0x202acb){return{'treePath':_0x285ea5,'writeTree':_0x202acb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x538df0){const _0x3d19b9=_0x538df0['type'],_0x548a67=_0x538df0['childName'];f(_0x3d19b9==='child_added'||_0x3d19b9==='child_changed'||_0x3d19b9==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x548a67!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1fb0de=this['changeMap']['get'](_0x548a67);if(_0x1fb0de){const _0x2632c2=_0x1fb0de['type'];if(_0x3d19b9==='child_added'&&_0x2632c2==='child_removed')this['changeMap']['set'](_0x548a67,Pt(_0x548a67,_0x538df0['snapshotNode'],_0x1fb0de['snapshotNode']));else{if(_0x3d19b9==='child_removed'&&_0x2632c2==='child_added')this['changeMap']['delete'](_0x548a67);else{if(_0x3d19b9==='child_removed'&&_0x2632c2==='child_changed')this['changeMap']['set'](_0x548a67,Nt(_0x548a67,_0x1fb0de['oldSnap']));else{if(_0x3d19b9==='child_changed'&&_0x2632c2==='child_added')this['changeMap']['set'](_0x548a67,tt(_0x548a67,_0x538df0['snapshotNode']));else{if(_0x3d19b9==='child_changed'&&_0x2632c2==='child_changed')this['changeMap']['set'](_0x548a67,Pt(_0x548a67,_0x538df0['snapshotNode'],_0x1fb0de['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x538df0+'\x20occurred\x20after\x20'+_0x1fb0de);}}}}}else this['changeMap']['set'](_0x548a67,_0x538df0);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x412d49){return null;}['getChildAfterChild'](_0x517389,_0xf46539,_0x5d7a34){return null;}}const Vo=new Iu();class ns{constructor(_0x43f022,_0x1e3d10,_0x1c71e0=null){this['writes_']=_0x43f022,this['viewCache_']=_0x1e3d10,this['optCompleteServerCache_']=_0x1c71e0;}['getCompleteChild'](_0x20e2ab){const _0x9f91c2=this['viewCache_']['eventCache'];if(_0x9f91c2['isCompleteForChild'](_0x20e2ab))return _0x9f91c2['getNode']()['getImmediateChild'](_0x20e2ab);{const _0x1a5229=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x20e2ab,_0x1a5229);}}['getChildAfterChild'](_0x1f69f3,_0x57231c,_0xb176dd){const _0xe76a0=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5592c3=vu(this['writes_'],_0xe76a0,_0x57231c,0x1,_0xb176dd,_0x1f69f3);return _0x5592c3['length']===0x0?null:_0x5592c3[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x485841){return{'filter':_0x485841};}function Cu(_0x24aaa8,_0xf4dede){f(_0xf4dede['eventCache']['getNode']()['isIndexed'](_0x24aaa8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xf4dede['serverCache']['getNode']()['isIndexed'](_0x24aaa8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x46ed26,_0x4c2cac,_0x26d032,_0x595601,_0x4b1472){const _0x3f890d=new Eu();let _0x2258ff,_0x5e9365;if(_0x26d032['type']===q['OVERWRITE']){const _0xd018bd=_0x26d032;_0xd018bd['source']['fromUser']?_0x2258ff=Ti(_0x46ed26,_0x4c2cac,_0xd018bd['path'],_0xd018bd['snap'],_0x595601,_0x4b1472,_0x3f890d):(f(_0xd018bd['source']['fromServer'],'Unknown\x20source.'),_0x5e9365=_0xd018bd['source']['tagged']||_0x4c2cac['serverCache']['isFiltered']()&&!v(_0xd018bd['path']),_0x2258ff=vn(_0x46ed26,_0x4c2cac,_0xd018bd['path'],_0xd018bd['snap'],_0x595601,_0x4b1472,_0x5e9365,_0x3f890d));}else{if(_0x26d032['type']===q['MERGE']){const _0x2e75c6=_0x26d032;_0x2e75c6['source']['fromUser']?_0x2258ff=bu(_0x46ed26,_0x4c2cac,_0x2e75c6['path'],_0x2e75c6['children'],_0x595601,_0x4b1472,_0x3f890d):(f(_0x2e75c6['source']['fromServer'],'Unknown\x20source.'),_0x5e9365=_0x2e75c6['source']['tagged']||_0x4c2cac['serverCache']['isFiltered'](),_0x2258ff=Si(_0x46ed26,_0x4c2cac,_0x2e75c6['path'],_0x2e75c6['children'],_0x595601,_0x4b1472,_0x5e9365,_0x3f890d));}else{if(_0x26d032['type']===q['ACK_USER_WRITE']){const _0x10b3f5=_0x26d032;_0x10b3f5['revert']?_0x2258ff=ku(_0x46ed26,_0x4c2cac,_0x10b3f5['path'],_0x595601,_0x4b1472,_0x3f890d):_0x2258ff=Ru(_0x46ed26,_0x4c2cac,_0x10b3f5['path'],_0x10b3f5['affectedTree'],_0x595601,_0x4b1472,_0x3f890d);}else{if(_0x26d032['type']===q['LISTEN_COMPLETE'])_0x2258ff=Au(_0x46ed26,_0x4c2cac,_0x26d032['path'],_0x595601,_0x3f890d);else throw ot('Unknown\x20operation\x20type:\x20'+_0x26d032['type']);}}}const _0x5baf72=_0x3f890d['getChanges']();return Su(_0x4c2cac,_0x2258ff,_0x5baf72),{'viewCache':_0x2258ff,'changes':_0x5baf72};}function Su(_0x2d53db,_0x5ae046,_0x23586b){const _0xb62d25=_0x5ae046['eventCache'];if(_0xb62d25['isFullyInitialized']()){const _0xb52d8d=_0xb62d25['getNode']()['isLeafNode']()||_0xb62d25['getNode']()['isEmpty'](),_0x2796f1=gn(_0x2d53db);(_0x23586b['length']>0x0||!_0x2d53db['eventCache']['isFullyInitialized']()||_0xb52d8d&&!_0xb62d25['getNode']()['equals'](_0x2796f1)||!_0xb62d25['getNode']()['getPriority']()['equals'](_0x2796f1['getPriority']()))&&_0x23586b['push'](Oo(gn(_0x5ae046)));}}function Ho(_0xbacb8c,_0x3e2b7f,_0x2ec540,_0x5dd637,_0x3ccdcf,_0x40b97e){const _0x51ee74=_0x3e2b7f['eventCache'];if(yn(_0x5dd637,_0x2ec540)!=null)return _0x3e2b7f;{let _0x2e597a,_0x25bffd;if(v(_0x2ec540)){if(f(_0x3e2b7f['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3e2b7f['serverCache']['isFiltered']()){const _0x39befb=Ue(_0x3e2b7f),_0x2bac8f=_0x39befb instanceof g?_0x39befb:g['EMPTY_NODE'],_0x5c9748=es(_0x5dd637,_0x2bac8f);_0x2e597a=_0xbacb8c['filter']['updateFullNode'](_0x3e2b7f['eventCache']['getNode'](),_0x5c9748,_0x40b97e);}else{const _0x1c987b=mn(_0x5dd637,Ue(_0x3e2b7f));_0x2e597a=_0xbacb8c['filter']['updateFullNode'](_0x3e2b7f['eventCache']['getNode'](),_0x1c987b,_0x40b97e);}}else{const _0x48124a=y(_0x2ec540);if(_0x48124a==='.priority'){f(we(_0x2ec540)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1e74d5=_0x51ee74['getNode']();_0x25bffd=_0x3e2b7f['serverCache']['getNode']();const _0x59cf47=or(_0x5dd637,_0x2ec540,_0x1e74d5,_0x25bffd);_0x59cf47!=null?_0x2e597a=_0xbacb8c['filter']['updatePriority'](_0x1e74d5,_0x59cf47):_0x2e597a=_0x51ee74['getNode']();}else{const _0x470d85=b(_0x2ec540);let _0x270dbe;if(_0x51ee74['isCompleteForChild'](_0x48124a)){_0x25bffd=_0x3e2b7f['serverCache']['getNode']();const _0x30a767=or(_0x5dd637,_0x2ec540,_0x51ee74['getNode'](),_0x25bffd);_0x30a767!=null?_0x270dbe=_0x51ee74['getNode']()['getImmediateChild'](_0x48124a)['updateChild'](_0x470d85,_0x30a767):_0x270dbe=_0x51ee74['getNode']()['getImmediateChild'](_0x48124a);}else _0x270dbe=ts(_0x5dd637,_0x48124a,_0x3e2b7f['serverCache']);_0x270dbe!=null?_0x2e597a=_0xbacb8c['filter']['updateChild'](_0x51ee74['getNode'](),_0x48124a,_0x270dbe,_0x470d85,_0x3ccdcf,_0x40b97e):_0x2e597a=_0x51ee74['getNode']();}}return wt(_0x3e2b7f,_0x2e597a,_0x51ee74['isFullyInitialized']()||v(_0x2ec540),_0xbacb8c['filter']['filtersNodes']());}}function vn(_0x2ba689,_0x1017eb,_0x2281e8,_0x5c6a95,_0x119552,_0x443fa6,_0x409ae1,_0x496875){const _0x429667=_0x1017eb['serverCache'];let _0x3bb102;const _0x37de54=_0x409ae1?_0x2ba689['filter']:_0x2ba689['filter']['getIndexedFilter']();if(v(_0x2281e8))_0x3bb102=_0x37de54['updateFullNode'](_0x429667['getNode'](),_0x5c6a95,null);else{if(_0x37de54['filtersNodes']()&&!_0x429667['isFiltered']()){const _0x480308=_0x429667['getNode']()['updateChild'](_0x2281e8,_0x5c6a95);_0x3bb102=_0x37de54['updateFullNode'](_0x429667['getNode'](),_0x480308,null);}else{const _0x5058a5=y(_0x2281e8);if(!_0x429667['isCompleteForPath'](_0x2281e8)&&we(_0x2281e8)>0x1)return _0x1017eb;const _0x164f27=b(_0x2281e8),_0x18798f=_0x429667['getNode']()['getImmediateChild'](_0x5058a5)['updateChild'](_0x164f27,_0x5c6a95);_0x5058a5==='.priority'?_0x3bb102=_0x37de54['updatePriority'](_0x429667['getNode'](),_0x18798f):_0x3bb102=_0x37de54['updateChild'](_0x429667['getNode'](),_0x5058a5,_0x18798f,_0x164f27,Vo,null);}}const _0x5c95f9=Lo(_0x1017eb,_0x3bb102,_0x429667['isFullyInitialized']()||v(_0x2281e8),_0x37de54['filtersNodes']()),_0x4c2d19=new ns(_0x119552,_0x5c95f9,_0x443fa6);return Ho(_0x2ba689,_0x5c95f9,_0x2281e8,_0x119552,_0x4c2d19,_0x496875);}function Ti(_0x49073c,_0x110b8d,_0x38f856,_0xe48603,_0x194cd4,_0x135dd2,_0x9b2c62){const _0x345676=_0x110b8d['eventCache'];let _0x288d88,_0x32837a;const _0x37fed1=new ns(_0x194cd4,_0x110b8d,_0x135dd2);if(v(_0x38f856))_0x32837a=_0x49073c['filter']['updateFullNode'](_0x110b8d['eventCache']['getNode'](),_0xe48603,_0x9b2c62),_0x288d88=wt(_0x110b8d,_0x32837a,!0x0,_0x49073c['filter']['filtersNodes']());else{const _0x1883b6=y(_0x38f856);if(_0x1883b6==='.priority')_0x32837a=_0x49073c['filter']['updatePriority'](_0x110b8d['eventCache']['getNode'](),_0xe48603),_0x288d88=wt(_0x110b8d,_0x32837a,_0x345676['isFullyInitialized'](),_0x345676['isFiltered']());else{const _0x29ec05=b(_0x38f856),_0x2973bf=_0x345676['getNode']()['getImmediateChild'](_0x1883b6);let _0x22a131;if(v(_0x29ec05))_0x22a131=_0xe48603;else{const _0x2bf43d=_0x37fed1['getCompleteChild'](_0x1883b6);_0x2bf43d!=null?Gi(_0x29ec05)==='.priority'&&_0x2bf43d['getChild'](To(_0x29ec05))['isEmpty']()?_0x22a131=_0x2bf43d:_0x22a131=_0x2bf43d['updateChild'](_0x29ec05,_0xe48603):_0x22a131=g['EMPTY_NODE'];}if(_0x2973bf['equals'](_0x22a131))_0x288d88=_0x110b8d;else{const _0x30dbc0=_0x49073c['filter']['updateChild'](_0x345676['getNode'](),_0x1883b6,_0x22a131,_0x29ec05,_0x37fed1,_0x9b2c62);_0x288d88=wt(_0x110b8d,_0x30dbc0,_0x345676['isFullyInitialized'](),_0x49073c['filter']['filtersNodes']());}}}return _0x288d88;}function ar(_0x1d8868,_0xd02c9a){return _0x1d8868['eventCache']['isCompleteForChild'](_0xd02c9a);}function bu(_0x496f44,_0x18b488,_0x3fa923,_0x2ffbd3,_0x37a693,_0x3aab3e,_0x3ad04f){let _0x45b6c4=_0x18b488;return _0x2ffbd3['foreach']((_0x44c8fd,_0x305a38)=>{const _0x389c64=A(_0x3fa923,_0x44c8fd);ar(_0x18b488,y(_0x389c64))&&(_0x45b6c4=Ti(_0x496f44,_0x45b6c4,_0x389c64,_0x305a38,_0x37a693,_0x3aab3e,_0x3ad04f));}),_0x2ffbd3['foreach']((_0x5b72ff,_0x8a4f10)=>{const _0x3ae15c=A(_0x3fa923,_0x5b72ff);ar(_0x18b488,y(_0x3ae15c))||(_0x45b6c4=Ti(_0x496f44,_0x45b6c4,_0x3ae15c,_0x8a4f10,_0x37a693,_0x3aab3e,_0x3ad04f));}),_0x45b6c4;}function cr(_0x139a17,_0x19755d,_0x1d5fc1){return _0x1d5fc1['foreach']((_0x891bbe,_0x40200c)=>{_0x19755d=_0x19755d['updateChild'](_0x891bbe,_0x40200c);}),_0x19755d;}function Si(_0x4c4050,_0x59e7a3,_0x2d7451,_0x1e6a33,_0x26f346,_0x40ec63,_0x2691ea,_0x18cff3){if(_0x59e7a3['serverCache']['getNode']()['isEmpty']()&&!_0x59e7a3['serverCache']['isFullyInitialized']())return _0x59e7a3;let _0x120a15=_0x59e7a3,_0x1709dc;v(_0x2d7451)?_0x1709dc=_0x1e6a33:_0x1709dc=new S(null)['setTree'](_0x2d7451,_0x1e6a33);const _0x8654b2=_0x59e7a3['serverCache']['getNode']();return _0x1709dc['children']['inorderTraversal']((_0x285025,_0xa649f9)=>{if(_0x8654b2['hasChild'](_0x285025)){const _0x278fc3=_0x59e7a3['serverCache']['getNode']()['getImmediateChild'](_0x285025),_0x2c9bee=cr(_0x4c4050,_0x278fc3,_0xa649f9);_0x120a15=vn(_0x4c4050,_0x120a15,new C(_0x285025),_0x2c9bee,_0x26f346,_0x40ec63,_0x2691ea,_0x18cff3);}}),_0x1709dc['children']['inorderTraversal']((_0x390071,_0x46c8fa)=>{const _0x545a92=!_0x59e7a3['serverCache']['isCompleteForChild'](_0x390071)&&_0x46c8fa['value']===null;if(!_0x8654b2['hasChild'](_0x390071)&&!_0x545a92){const _0x9e1025=_0x59e7a3['serverCache']['getNode']()['getImmediateChild'](_0x390071),_0x2ee727=cr(_0x4c4050,_0x9e1025,_0x46c8fa);_0x120a15=vn(_0x4c4050,_0x120a15,new C(_0x390071),_0x2ee727,_0x26f346,_0x40ec63,_0x2691ea,_0x18cff3);}}),_0x120a15;}function Ru(_0x3c9542,_0x1212db,_0x2f0dd9,_0x271ab2,_0x26193d,_0x57fec2,_0x2338ed){if(yn(_0x26193d,_0x2f0dd9)!=null)return _0x1212db;const _0x2dbca0=_0x1212db['serverCache']['isFiltered'](),_0x14f149=_0x1212db['serverCache'];if(_0x271ab2['value']!=null){if(v(_0x2f0dd9)&&_0x14f149['isFullyInitialized']()||_0x14f149['isCompleteForPath'](_0x2f0dd9))return vn(_0x3c9542,_0x1212db,_0x2f0dd9,_0x14f149['getNode']()['getChild'](_0x2f0dd9),_0x26193d,_0x57fec2,_0x2dbca0,_0x2338ed);if(v(_0x2f0dd9)){let _0x18080f=new S(null);return _0x14f149['getNode']()['forEachChild'](ye,(_0x422dc2,_0x196e6a)=>{_0x18080f=_0x18080f['set'](new C(_0x422dc2),_0x196e6a);}),Si(_0x3c9542,_0x1212db,_0x2f0dd9,_0x18080f,_0x26193d,_0x57fec2,_0x2dbca0,_0x2338ed);}else return _0x1212db;}else{let _0x13687f=new S(null);return _0x271ab2['foreach']((_0x571f4a,_0x19fe9a)=>{const _0x44f068=A(_0x2f0dd9,_0x571f4a);_0x14f149['isCompleteForPath'](_0x44f068)&&(_0x13687f=_0x13687f['set'](_0x571f4a,_0x14f149['getNode']()['getChild'](_0x44f068)));}),Si(_0x3c9542,_0x1212db,_0x2f0dd9,_0x13687f,_0x26193d,_0x57fec2,_0x2dbca0,_0x2338ed);}}function Au(_0x7048af,_0x5e055a,_0x41823b,_0x2d0b45,_0x420c97){const _0x3813b7=_0x5e055a['serverCache'],_0x58fdf1=Lo(_0x5e055a,_0x3813b7['getNode'](),_0x3813b7['isFullyInitialized']()||v(_0x41823b),_0x3813b7['isFiltered']());return Ho(_0x7048af,_0x58fdf1,_0x41823b,_0x2d0b45,Vo,_0x420c97);}function ku(_0x35671d,_0x2b1c67,_0x3fadbe,_0xa3a45f,_0xf598c0,_0x164098){let _0x234835;if(yn(_0xa3a45f,_0x3fadbe)!=null)return _0x2b1c67;{const _0x151021=new ns(_0xa3a45f,_0x2b1c67,_0xf598c0),_0x2b71ca=_0x2b1c67['eventCache']['getNode']();let _0x2eb26a;if(v(_0x3fadbe)||y(_0x3fadbe)==='.priority'){let _0x23c520;if(_0x2b1c67['serverCache']['isFullyInitialized']())_0x23c520=mn(_0xa3a45f,Ue(_0x2b1c67));else{const _0x17e482=_0x2b1c67['serverCache']['getNode']();f(_0x17e482 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x23c520=es(_0xa3a45f,_0x17e482);}_0x23c520=_0x23c520,_0x2eb26a=_0x35671d['filter']['updateFullNode'](_0x2b71ca,_0x23c520,_0x164098);}else{const _0x182889=y(_0x3fadbe);let _0x1e130b=ts(_0xa3a45f,_0x182889,_0x2b1c67['serverCache']);_0x1e130b==null&&_0x2b1c67['serverCache']['isCompleteForChild'](_0x182889)&&(_0x1e130b=_0x2b71ca['getImmediateChild'](_0x182889)),_0x1e130b!=null?_0x2eb26a=_0x35671d['filter']['updateChild'](_0x2b71ca,_0x182889,_0x1e130b,b(_0x3fadbe),_0x151021,_0x164098):_0x2b1c67['eventCache']['getNode']()['hasChild'](_0x182889)?_0x2eb26a=_0x35671d['filter']['updateChild'](_0x2b71ca,_0x182889,g['EMPTY_NODE'],b(_0x3fadbe),_0x151021,_0x164098):_0x2eb26a=_0x2b71ca,_0x2eb26a['isEmpty']()&&_0x2b1c67['serverCache']['isFullyInitialized']()&&(_0x234835=mn(_0xa3a45f,Ue(_0x2b1c67)),_0x234835['isLeafNode']()&&(_0x2eb26a=_0x35671d['filter']['updateFullNode'](_0x2eb26a,_0x234835,_0x164098)));}return _0x234835=_0x2b1c67['serverCache']['isFullyInitialized']()||yn(_0xa3a45f,w())!=null,wt(_0x2b1c67,_0x2eb26a,_0x234835,_0x35671d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3e5baf,_0x40b5f8){this['query_']=_0x3e5baf,this['eventRegistrations_']=[];const _0x571c69=this['query_']['_queryParams'],_0x56c1aa=new Yi(_0x571c69['getIndex']()),_0x8d95ab=qh(_0x571c69);this['processor_']=wu(_0x8d95ab);const _0x3ae642=_0x40b5f8['serverCache'],_0x56a539=_0x40b5f8['eventCache'],_0x249104=_0x56c1aa['updateFullNode'](g['EMPTY_NODE'],_0x3ae642['getNode'](),null),_0x15733a=_0x8d95ab['updateFullNode'](g['EMPTY_NODE'],_0x56a539['getNode'](),null),_0x33e7eb=new Ce(_0x249104,_0x3ae642['isFullyInitialized'](),_0x56c1aa['filtersNodes']()),_0x5c362b=new Ce(_0x15733a,_0x56a539['isFullyInitialized'](),_0x8d95ab['filtersNodes']());this['viewCache_']=Dn(_0x5c362b,_0x33e7eb),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x275e62){return _0x275e62['viewCache_']['serverCache']['getNode']();}function Ou(_0x37d6d2){return gn(_0x37d6d2['viewCache_']);}function Du(_0xfeb98f,_0x5e1844){const _0x35e139=Ue(_0xfeb98f['viewCache_']);return _0x35e139&&(_0xfeb98f['query']['_queryParams']['loadsAllData']()||!v(_0x5e1844)&&!_0x35e139['getImmediateChild'](y(_0x5e1844))['isEmpty']())?_0x35e139['getChild'](_0x5e1844):null;}function lr(_0x1424a4){return _0x1424a4['eventRegistrations_']['length']===0x0;}function Mu(_0x21e819,_0x502c7a){_0x21e819['eventRegistrations_']['push'](_0x502c7a);}function hr(_0x34adee,_0x163865,_0x2fd5cf){const _0xa7049d=[];if(_0x2fd5cf){f(_0x163865==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x31889f=_0x34adee['query']['_path'];_0x34adee['eventRegistrations_']['forEach'](_0x2c8277=>{const _0x1d48f0=_0x2c8277['createCancelEvent'](_0x2fd5cf,_0x31889f);_0x1d48f0&&_0xa7049d['push'](_0x1d48f0);});}if(_0x163865){let _0x5b8bbd=[];for(let _0xaf5865=0x0;_0xaf5865<_0x34adee['eventRegistrations_']['length'];++_0xaf5865){const _0x4f2f13=_0x34adee['eventRegistrations_'][_0xaf5865];if(!_0x4f2f13['matches'](_0x163865))_0x5b8bbd['push'](_0x4f2f13);else{if(_0x163865['hasAnyCallback']()){_0x5b8bbd=_0x5b8bbd['concat'](_0x34adee['eventRegistrations_']['slice'](_0xaf5865+0x1));break;}}}_0x34adee['eventRegistrations_']=_0x5b8bbd;}else _0x34adee['eventRegistrations_']=[];return _0xa7049d;}function ur(_0x32d5c4,_0x4f0ecf,_0x69a5fa,_0x260c45){_0x4f0ecf['type']===q['MERGE']&&_0x4f0ecf['source']['queryId']!==null&&(f(Ue(_0x32d5c4['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x32d5c4['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5cfdf7=_0x32d5c4['viewCache_'],_0x24abf0=Tu(_0x32d5c4['processor_'],_0x5cfdf7,_0x4f0ecf,_0x69a5fa,_0x260c45);return Cu(_0x32d5c4['processor_'],_0x24abf0['viewCache']),f(_0x24abf0['viewCache']['serverCache']['isFullyInitialized']()||!_0x5cfdf7['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x32d5c4['viewCache_']=_0x24abf0['viewCache'],$o(_0x32d5c4,_0x24abf0['changes'],_0x24abf0['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x758fbb,_0x76d547){const _0x5aced5=_0x758fbb['viewCache_']['eventCache'],_0x4239c9=[];return _0x5aced5['getNode']()['isLeafNode']()||_0x5aced5['getNode']()['forEachChild'](R,(_0x2c50d7,_0x34ff27)=>{_0x4239c9['push'](tt(_0x2c50d7,_0x34ff27));}),_0x5aced5['isFullyInitialized']()&&_0x4239c9['push'](Oo(_0x5aced5['getNode']())),$o(_0x758fbb,_0x4239c9,_0x5aced5['getNode'](),_0x76d547);}function $o(_0x4bf46b,_0x5694e1,_0xc997d6,_0x1e1adc){const _0x72ea75=_0x1e1adc?[_0x1e1adc]:_0x4bf46b['eventRegistrations_'];return nu(_0x4bf46b['eventGenerator_'],_0x5694e1,_0xc997d6,_0x72ea75);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x210f9c){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x210f9c;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x5d44bb){return _0x5d44bb['views']['size']===0x0;}function is(_0x10855c,_0x3562ef,_0x21b50a,_0x521617){const _0x445dbb=_0x3562ef['source']['queryId'];if(_0x445dbb!==null){const _0x41532a=_0x10855c['views']['get'](_0x445dbb);return f(_0x41532a!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x41532a,_0x3562ef,_0x21b50a,_0x521617);}else{let _0x505206=[];for(const _0x3cab08 of _0x10855c['views']['values']())_0x505206=_0x505206['concat'](ur(_0x3cab08,_0x3562ef,_0x21b50a,_0x521617));return _0x505206;}}function qo(_0x448b14,_0x357589,_0x100c14,_0xfd94f8,_0x1a879d){const _0x3874d5=_0x357589['_queryIdentifier'],_0x34abac=_0x448b14['views']['get'](_0x3874d5);if(!_0x34abac){let _0x3354f4=mn(_0x100c14,_0x1a879d?_0xfd94f8:null),_0x49ef06=!0x1;_0x3354f4?_0x49ef06=!0x0:_0xfd94f8 instanceof g?(_0x3354f4=es(_0x100c14,_0xfd94f8),_0x49ef06=!0x1):(_0x3354f4=g['EMPTY_NODE'],_0x49ef06=!0x1);const _0x447b29=Dn(new Ce(_0x3354f4,_0x49ef06,!0x1),new Ce(_0xfd94f8,_0x1a879d,!0x1));return new Nu(_0x357589,_0x447b29);}return _0x34abac;}function Wu(_0x56620a,_0x279fe6,_0xa0121d,_0x3f1141,_0x3fda9b,_0x261653){const _0x364414=qo(_0x56620a,_0x279fe6,_0x3f1141,_0x3fda9b,_0x261653);return _0x56620a['views']['has'](_0x279fe6['_queryIdentifier'])||_0x56620a['views']['set'](_0x279fe6['_queryIdentifier'],_0x364414),Mu(_0x364414,_0xa0121d),Lu(_0x364414,_0xa0121d);}function Bu(_0x15c926,_0x5a6a3e,_0x459d87,_0x26b972){const _0x23c2b3=_0x5a6a3e['_queryIdentifier'],_0x355e84=[];let _0x301b82=[];const _0x1deb52=Te(_0x15c926);if(_0x23c2b3==='default'){for(const [_0x5bf9d5,_0x9e999b]of _0x15c926['views']['entries']())_0x301b82=_0x301b82['concat'](hr(_0x9e999b,_0x459d87,_0x26b972)),lr(_0x9e999b)&&(_0x15c926['views']['delete'](_0x5bf9d5),_0x9e999b['query']['_queryParams']['loadsAllData']()||_0x355e84['push'](_0x9e999b['query']));}else{const _0x10b63b=_0x15c926['views']['get'](_0x23c2b3);_0x10b63b&&(_0x301b82=_0x301b82['concat'](hr(_0x10b63b,_0x459d87,_0x26b972)),lr(_0x10b63b)&&(_0x15c926['views']['delete'](_0x23c2b3),_0x10b63b['query']['_queryParams']['loadsAllData']()||_0x355e84['push'](_0x10b63b['query'])));}return _0x1deb52&&!Te(_0x15c926)&&_0x355e84['push'](new(Fu())(_0x5a6a3e['_repo'],_0x5a6a3e['_path'])),{'removed':_0x355e84,'events':_0x301b82};}function zo(_0xd148c7){const _0x2c9226=[];for(const _0x120900 of _0xd148c7['views']['values']())_0x120900['query']['_queryParams']['loadsAllData']()||_0x2c9226['push'](_0x120900);return _0x2c9226;}function Ee(_0x5b94cf,_0x219857){let _0x135347=null;for(const _0x13133c of _0x5b94cf['views']['values']())_0x135347=_0x135347||Du(_0x13133c,_0x219857);return _0x135347;}function jo(_0x292ba0,_0x15fb83){if(_0x15fb83['_queryParams']['loadsAllData']())return Ln(_0x292ba0);{const _0x54ba75=_0x15fb83['_queryIdentifier'];return _0x292ba0['views']['get'](_0x54ba75);}}function Ko(_0x31576b,_0x17c371){return jo(_0x31576b,_0x17c371)!=null;}function Te(_0x490cc2){return Ln(_0x490cc2)!=null;}function Ln(_0x36d187){for(const _0x1a556b of _0x36d187['views']['values']())if(_0x1a556b['query']['_queryParams']['loadsAllData']())return _0x1a556b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x2fb12c){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x2fb12c;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x39cce0){this['listenProvider_']=_0x39cce0,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x704d05,_0x243436,_0x451855,_0x397c5b,_0x109045){return ou(_0x704d05['pendingWriteTree_'],_0x243436,_0x451855,_0x397c5b,_0x109045),_0x109045?ht(_0x704d05,new Fe(Ji(),_0x243436,_0x451855)):[];}function Gu(_0x2d8dfe,_0x3bcc16,_0x4afd23,_0x2596a0){au(_0x2d8dfe['pendingWriteTree_'],_0x3bcc16,_0x4afd23,_0x2596a0);const _0x34e272=S['fromObject'](_0x4afd23);return ht(_0x2d8dfe,new nt(Ji(),_0x3bcc16,_0x34e272));}function pe(_0x5bff64,_0x337f07,_0x347f2c=!0x1){const _0x589def=cu(_0x5bff64['pendingWriteTree_'],_0x337f07);if(lu(_0x5bff64['pendingWriteTree_'],_0x337f07)){let _0x16ba30=new S(null);return _0x589def['snap']!=null?_0x16ba30=_0x16ba30['set'](w(),!0x0):x(_0x589def['children'],_0x5dade2=>{_0x16ba30=_0x16ba30['set'](new C(_0x5dade2),!0x0);}),ht(_0x5bff64,new _n(_0x589def['path'],_0x16ba30,_0x347f2c));}else return[];}function $t(_0xe702e4,_0x52bb65,_0x35beb4){return ht(_0xe702e4,new Fe(Xi(),_0x52bb65,_0x35beb4));}function qu(_0x18a861,_0x199388,_0x23f62){const _0x4c72f3=S['fromObject'](_0x23f62);return ht(_0x18a861,new nt(Xi(),_0x199388,_0x4c72f3));}function zu(_0x10357e,_0x17fd4f){return ht(_0x10357e,new Dt(Xi(),_0x17fd4f));}function ju(_0x191aa8,_0x57af52,_0x1f0e3d){const _0x1b35a4=rs(_0x191aa8,_0x1f0e3d);if(_0x1b35a4){const _0xc1cdd8=os(_0x1b35a4),_0x3dda09=_0xc1cdd8['path'],_0x471d8b=_0xc1cdd8['queryId'],_0x2ac57a=F(_0x3dda09,_0x57af52),_0x12329=new Dt(Zi(_0x471d8b),_0x2ac57a);return as(_0x191aa8,_0x3dda09,_0x12329);}else return[];}function wn(_0x58f321,_0x1ef9b4,_0x4c0d21,_0x1afde9,_0x55a880=!0x1){const _0x501c5c=_0x1ef9b4['_path'],_0x8e0da7=_0x58f321['syncPointTree_']['get'](_0x501c5c);let _0x2d7667=[];if(_0x8e0da7&&(_0x1ef9b4['_queryIdentifier']==='default'||Ko(_0x8e0da7,_0x1ef9b4))){const _0x3b0591=Bu(_0x8e0da7,_0x1ef9b4,_0x4c0d21,_0x1afde9);Uu(_0x8e0da7)&&(_0x58f321['syncPointTree_']=_0x58f321['syncPointTree_']['remove'](_0x501c5c));const _0x3a4ace=_0x3b0591['removed'];if(_0x2d7667=_0x3b0591['events'],!_0x55a880){const _0x334a66=_0x3a4ace['findIndex'](_0x2fce3b=>_0x2fce3b['_queryParams']['loadsAllData']())!==-0x1,_0x3a56a6=_0x58f321['syncPointTree_']['findOnPath'](_0x501c5c,(_0x546c9a,_0x1d424d)=>Te(_0x1d424d));if(_0x334a66&&!_0x3a56a6){const _0x5172e9=_0x58f321['syncPointTree_']['subtree'](_0x501c5c);if(!_0x5172e9['isEmpty']()){const _0x5232d3=Qu(_0x5172e9);for(let _0x4c0456=0x0;_0x4c0456<_0x5232d3['length'];++_0x4c0456){const _0x53a26c=_0x5232d3[_0x4c0456],_0x16bb85=_0x53a26c['query'],_0x1fbcc9=Xo(_0x58f321,_0x53a26c);_0x58f321['listenProvider_']['startListening'](Tt(_0x16bb85),Mt(_0x58f321,_0x16bb85),_0x1fbcc9['hashFn'],_0x1fbcc9['onComplete']);}}}!_0x3a56a6&&_0x3a4ace['length']>0x0&&!_0x1afde9&&(_0x334a66?_0x58f321['listenProvider_']['stopListening'](Tt(_0x1ef9b4),null):_0x3a4ace['forEach'](_0x35ece3=>{const _0x47ceea=_0x58f321['queryToTagMap']['get'](Fn(_0x35ece3));_0x58f321['listenProvider_']['stopListening'](Tt(_0x35ece3),_0x47ceea);}));}Ju(_0x58f321,_0x3a4ace);}return _0x2d7667;}function Yo(_0x39838a,_0x2bf324,_0x195136,_0x372717){const _0x5ba052=rs(_0x39838a,_0x372717);if(_0x5ba052!=null){const _0xf5aa01=os(_0x5ba052),_0x588eb5=_0xf5aa01['path'],_0x5409db=_0xf5aa01['queryId'],_0x9b236a=F(_0x588eb5,_0x2bf324),_0x4d5563=new Fe(Zi(_0x5409db),_0x9b236a,_0x195136);return as(_0x39838a,_0x588eb5,_0x4d5563);}else return[];}function Ku(_0x1cc5ff,_0x30d73d,_0x52beba,_0xbe832a){const _0x110318=rs(_0x1cc5ff,_0xbe832a);if(_0x110318){const _0x57328d=os(_0x110318),_0x4b685f=_0x57328d['path'],_0x50544e=_0x57328d['queryId'],_0x4e8e69=F(_0x4b685f,_0x30d73d),_0x2c5eeb=S['fromObject'](_0x52beba),_0x12578c=new nt(Zi(_0x50544e),_0x4e8e69,_0x2c5eeb);return as(_0x1cc5ff,_0x4b685f,_0x12578c);}else return[];}function bi(_0x210fdf,_0x5981ce,_0x270e45,_0x47f219=!0x1){const _0x4a2f10=_0x5981ce['_path'];let _0x27f0a4=null,_0x33549f=!0x1;_0x210fdf['syncPointTree_']['foreachOnPath'](_0x4a2f10,(_0x2f14a0,_0x2053b5)=>{const _0x404151=F(_0x2f14a0,_0x4a2f10);_0x27f0a4=_0x27f0a4||Ee(_0x2053b5,_0x404151),_0x33549f=_0x33549f||Te(_0x2053b5);});let _0x208f7f=_0x210fdf['syncPointTree_']['get'](_0x4a2f10);_0x208f7f?(_0x33549f=_0x33549f||Te(_0x208f7f),_0x27f0a4=_0x27f0a4||Ee(_0x208f7f,w())):(_0x208f7f=new Go(),_0x210fdf['syncPointTree_']=_0x210fdf['syncPointTree_']['set'](_0x4a2f10,_0x208f7f));let _0xf314ef;_0x27f0a4!=null?_0xf314ef=!0x0:(_0xf314ef=!0x1,_0x27f0a4=g['EMPTY_NODE'],_0x210fdf['syncPointTree_']['subtree'](_0x4a2f10)['foreachChild']((_0x2f181f,_0x5a585a)=>{const _0x59d5e6=Ee(_0x5a585a,w());_0x59d5e6&&(_0x27f0a4=_0x27f0a4['updateImmediateChild'](_0x2f181f,_0x59d5e6));}));const _0x46eb5=Ko(_0x208f7f,_0x5981ce);if(!_0x46eb5&&!_0x5981ce['_queryParams']['loadsAllData']()){const _0x5412c7=Fn(_0x5981ce);f(!_0x210fdf['queryToTagMap']['has'](_0x5412c7),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xc96698=Xu();_0x210fdf['queryToTagMap']['set'](_0x5412c7,_0xc96698),_0x210fdf['tagToQueryMap']['set'](_0xc96698,_0x5412c7);}const _0x1064f5=Mn(_0x210fdf['pendingWriteTree_'],_0x4a2f10);let _0x241611=Wu(_0x208f7f,_0x5981ce,_0x270e45,_0x1064f5,_0x27f0a4,_0xf314ef);if(!_0x46eb5&&!_0x33549f&&!_0x47f219){const _0x324f6a=jo(_0x208f7f,_0x5981ce);_0x241611=_0x241611['concat'](Zu(_0x210fdf,_0x5981ce,_0x324f6a));}return _0x241611;}function xn(_0x2a6ffe,_0x498fb4,_0x22699d){const _0x387c96=_0x2a6ffe['pendingWriteTree_'],_0x2bb7fc=_0x2a6ffe['syncPointTree_']['findOnPath'](_0x498fb4,(_0x4a4060,_0xdf6192)=>{const _0x13d92b=F(_0x4a4060,_0x498fb4),_0x59bab5=Ee(_0xdf6192,_0x13d92b);if(_0x59bab5)return _0x59bab5;});return Uo(_0x387c96,_0x498fb4,_0x2bb7fc,_0x22699d,!0x0);}function Yu(_0x18d9ff,_0x148732){const _0x28eaed=_0x148732['_path'];let _0xd62bfc=null;_0x18d9ff['syncPointTree_']['foreachOnPath'](_0x28eaed,(_0x317da2,_0x42a9c5)=>{const _0x2922b6=F(_0x317da2,_0x28eaed);_0xd62bfc=_0xd62bfc||Ee(_0x42a9c5,_0x2922b6);});let _0x2e6c4d=_0x18d9ff['syncPointTree_']['get'](_0x28eaed);_0x2e6c4d?_0xd62bfc=_0xd62bfc||Ee(_0x2e6c4d,w()):(_0x2e6c4d=new Go(),_0x18d9ff['syncPointTree_']=_0x18d9ff['syncPointTree_']['set'](_0x28eaed,_0x2e6c4d));const _0x2137f1=_0xd62bfc!=null,_0x234137=_0x2137f1?new Ce(_0xd62bfc,!0x0,!0x1):null,_0x595a99=Mn(_0x18d9ff['pendingWriteTree_'],_0x148732['_path']),_0x708557=qo(_0x2e6c4d,_0x148732,_0x595a99,_0x2137f1?_0x234137['getNode']():g['EMPTY_NODE'],_0x2137f1);return Ou(_0x708557);}function ht(_0x1c9e12,_0xb8b4da){return Qo(_0xb8b4da,_0x1c9e12['syncPointTree_'],null,Mn(_0x1c9e12['pendingWriteTree_'],w()));}function Qo(_0x3a6094,_0x549ce0,_0x306a3e,_0x8b1801){if(v(_0x3a6094['path']))return Jo(_0x3a6094,_0x549ce0,_0x306a3e,_0x8b1801);{const _0x3c1796=_0x549ce0['get'](w());_0x306a3e==null&&_0x3c1796!=null&&(_0x306a3e=Ee(_0x3c1796,w()));let _0x27854e=[];const _0x296b6e=y(_0x3a6094['path']),_0x10544f=_0x3a6094['operationForChild'](_0x296b6e),_0x31e5d6=_0x549ce0['children']['get'](_0x296b6e);if(_0x31e5d6&&_0x10544f){const _0x3115a3=_0x306a3e?_0x306a3e['getImmediateChild'](_0x296b6e):null,_0x2522e8=Wo(_0x8b1801,_0x296b6e);_0x27854e=_0x27854e['concat'](Qo(_0x10544f,_0x31e5d6,_0x3115a3,_0x2522e8));}return _0x3c1796&&(_0x27854e=_0x27854e['concat'](is(_0x3c1796,_0x3a6094,_0x8b1801,_0x306a3e))),_0x27854e;}}function Jo(_0x1050fa,_0x315a91,_0xff4552,_0xf4c3c4){const _0x3b7653=_0x315a91['get'](w());_0xff4552==null&&_0x3b7653!=null&&(_0xff4552=Ee(_0x3b7653,w()));let _0x410fd5=[];return _0x315a91['children']['inorderTraversal']((_0x51dd31,_0x22789d)=>{const _0x53cda0=_0xff4552?_0xff4552['getImmediateChild'](_0x51dd31):null,_0x311fda=Wo(_0xf4c3c4,_0x51dd31),_0x40679b=_0x1050fa['operationForChild'](_0x51dd31);_0x40679b&&(_0x410fd5=_0x410fd5['concat'](Jo(_0x40679b,_0x22789d,_0x53cda0,_0x311fda)));}),_0x3b7653&&(_0x410fd5=_0x410fd5['concat'](is(_0x3b7653,_0x1050fa,_0xf4c3c4,_0xff4552))),_0x410fd5;}function Xo(_0x33eb73,_0x4fbb03){const _0x1f1a01=_0x4fbb03['query'],_0x13ebdd=Mt(_0x33eb73,_0x1f1a01);return{'hashFn':()=>(Pu(_0x4fbb03)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x43210a=>{if(_0x43210a==='ok')return _0x13ebdd?ju(_0x33eb73,_0x1f1a01['_path'],_0x13ebdd):zu(_0x33eb73,_0x1f1a01['_path']);{const _0x191cec=ql(_0x43210a,_0x1f1a01);return wn(_0x33eb73,_0x1f1a01,null,_0x191cec);}}};}function Mt(_0x4e677b,_0x276b50){const _0x4a4a65=Fn(_0x276b50);return _0x4e677b['queryToTagMap']['get'](_0x4a4a65);}function Fn(_0x1b4d01){return _0x1b4d01['_path']['toString']()+'$'+_0x1b4d01['_queryIdentifier'];}function rs(_0x247c74,_0x1c93df){return _0x247c74['tagToQueryMap']['get'](_0x1c93df);}function os(_0x52fdc8){const _0x2b339f=_0x52fdc8['indexOf']('$');return f(_0x2b339f!==-0x1&&_0x2b339f<_0x52fdc8['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x52fdc8['substr'](_0x2b339f+0x1),'path':new C(_0x52fdc8['substr'](0x0,_0x2b339f))};}function as(_0x151106,_0x5a9d74,_0x417587){const _0x146d2a=_0x151106['syncPointTree_']['get'](_0x5a9d74);f(_0x146d2a,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4189e9=Mn(_0x151106['pendingWriteTree_'],_0x5a9d74);return is(_0x146d2a,_0x417587,_0x4189e9,null);}function Qu(_0x2bcd51){return _0x2bcd51['fold']((_0x29cb7f,_0x4b746b,_0x79187c)=>{if(_0x4b746b&&Te(_0x4b746b))return[Ln(_0x4b746b)];{let _0x18ecc2=[];return _0x4b746b&&(_0x18ecc2=zo(_0x4b746b)),x(_0x79187c,(_0x7d035,_0x4623da)=>{_0x18ecc2=_0x18ecc2['concat'](_0x4623da);}),_0x18ecc2;}});}function Tt(_0xdd5152){return _0xdd5152['_queryParams']['loadsAllData']()&&!_0xdd5152['_queryParams']['isDefault']()?new(Hu())(_0xdd5152['_repo'],_0xdd5152['_path']):_0xdd5152;}function Ju(_0x1e0acc,_0x3e8551){for(let _0x12f16f=0x0;_0x12f16f<_0x3e8551['length'];++_0x12f16f){const _0x1cff8d=_0x3e8551[_0x12f16f];if(!_0x1cff8d['_queryParams']['loadsAllData']()){const _0x2600e9=Fn(_0x1cff8d),_0x29c473=_0x1e0acc['queryToTagMap']['get'](_0x2600e9);_0x1e0acc['queryToTagMap']['delete'](_0x2600e9),_0x1e0acc['tagToQueryMap']['delete'](_0x29c473);}}}function Xu(){return $u++;}function Zu(_0x1e7693,_0x3a3ee9,_0x5103ff){const _0x17517c=_0x3a3ee9['_path'],_0x1bb473=Mt(_0x1e7693,_0x3a3ee9),_0x387d50=Xo(_0x1e7693,_0x5103ff),_0xb23dd4=_0x1e7693['listenProvider_']['startListening'](Tt(_0x3a3ee9),_0x1bb473,_0x387d50['hashFn'],_0x387d50['onComplete']),_0x1e9ded=_0x1e7693['syncPointTree_']['subtree'](_0x17517c);if(_0x1bb473)f(!Te(_0x1e9ded['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2e0432=_0x1e9ded['fold']((_0x471d66,_0x6bf6a4,_0x915dcf)=>{if(!v(_0x471d66)&&_0x6bf6a4&&Te(_0x6bf6a4))return[Ln(_0x6bf6a4)['query']];{let _0x5eee8e=[];return _0x6bf6a4&&(_0x5eee8e=_0x5eee8e['concat'](zo(_0x6bf6a4)['map'](_0xbbfdc8=>_0xbbfdc8['query']))),x(_0x915dcf,(_0x5c3990,_0x328776)=>{_0x5eee8e=_0x5eee8e['concat'](_0x328776);}),_0x5eee8e;}});for(let _0x1fb975=0x0;_0x1fb975<_0x2e0432['length'];++_0x1fb975){const _0x517455=_0x2e0432[_0x1fb975];_0x1e7693['listenProvider_']['stopListening'](Tt(_0x517455),Mt(_0x1e7693,_0x517455));}}return _0xb23dd4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x327553){this['node_']=_0x327553;}['getImmediateChild'](_0x4b3c62){const _0x427f22=this['node_']['getImmediateChild'](_0x4b3c62);return new cs(_0x427f22);}['node'](){return this['node_'];}}class ls{constructor(_0x4547f8,_0x180354){this['syncTree_']=_0x4547f8,this['path_']=_0x180354;}['getImmediateChild'](_0x21d592){const _0x126cc4=A(this['path_'],_0x21d592);return new ls(this['syncTree_'],_0x126cc4);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x1230a8){return _0x1230a8=_0x1230a8||{},_0x1230a8['timestamp']=_0x1230a8['timestamp']||new Date()['getTime'](),_0x1230a8;},fr=function(_0x3e4c2f,_0x2c5ea9,_0x34296d){if(!_0x3e4c2f||typeof _0x3e4c2f!='object')return _0x3e4c2f;if(f('.sv'in _0x3e4c2f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3e4c2f['.sv']=='string')return td(_0x3e4c2f['.sv'],_0x2c5ea9,_0x34296d);if(typeof _0x3e4c2f['.sv']=='object')return nd(_0x3e4c2f['.sv'],_0x2c5ea9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3e4c2f,null,0x2));},td=function(_0x4cc7e6,_0x2374e2,_0x57c4ca){switch(_0x4cc7e6){case'timestamp':return _0x57c4ca['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x4cc7e6);}},nd=function(_0x44cede,_0x1f4e0f,_0x58dd56){_0x44cede['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x44cede,null,0x2));const _0x2f61fe=_0x44cede['increment'];typeof _0x2f61fe!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2f61fe);const _0x55fdb0=_0x1f4e0f['node']();if(f(_0x55fdb0!==null&&typeof _0x55fdb0<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x55fdb0['isLeafNode']())return _0x2f61fe;const _0x4380e4=_0x55fdb0['getValue']();return typeof _0x4380e4!='number'?_0x2f61fe:_0x4380e4+_0x2f61fe;},Zo=function(_0x2c68a7,_0xfc6911,_0x22113e,_0x13a0c6){return us(_0xfc6911,new ls(_0x22113e,_0x2c68a7),_0x13a0c6);},hs=function(_0x36d7c4,_0x2c7f9b,_0x33cc31){return us(_0x36d7c4,new cs(_0x2c7f9b),_0x33cc31);};function us(_0x270fbb,_0x43867d,_0x52e580){const _0x51e698=_0x270fbb['getPriority']()['val'](),_0x3fcf26=fr(_0x51e698,_0x43867d['getImmediateChild']('.priority'),_0x52e580);let _0x136145;if(_0x270fbb['isLeafNode']()){const _0x3f044f=_0x270fbb,_0x1b1aba=fr(_0x3f044f['getValue'](),_0x43867d,_0x52e580);return _0x1b1aba!==_0x3f044f['getValue']()||_0x3fcf26!==_0x3f044f['getPriority']()['val']()?new D(_0x1b1aba,N(_0x3fcf26)):_0x270fbb;}else{const _0x37720f=_0x270fbb;return _0x136145=_0x37720f,_0x3fcf26!==_0x37720f['getPriority']()['val']()&&(_0x136145=_0x136145['updatePriority'](new D(_0x3fcf26))),_0x37720f['forEachChild'](R,(_0x5c0c10,_0x3a6257)=>{const _0x5e8f9c=us(_0x3a6257,_0x43867d['getImmediateChild'](_0x5c0c10),_0x52e580);_0x5e8f9c!==_0x3a6257&&(_0x136145=_0x136145['updateImmediateChild'](_0x5c0c10,_0x5e8f9c));}),_0x136145;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x2978f6='',_0x3be118=null,_0x58689b={'children':{},'childCount':0x0}){this['name']=_0x2978f6,this['parent']=_0x3be118,this['node']=_0x58689b;}}function Un(_0x1de611,_0x32124e){let _0x3fadd1=_0x32124e instanceof C?_0x32124e:new C(_0x32124e),_0x1ef989=_0x1de611,_0x3388f4=y(_0x3fadd1);for(;_0x3388f4!==null;){const _0x286c53=Oe(_0x1ef989['node']['children'],_0x3388f4)||{'children':{},'childCount':0x0};_0x1ef989=new ds(_0x3388f4,_0x1ef989,_0x286c53),_0x3fadd1=b(_0x3fadd1),_0x3388f4=y(_0x3fadd1);}return _0x1ef989;}function Ge(_0x6c31ec){return _0x6c31ec['node']['value'];}function fs(_0x3facb3,_0x1318ef){_0x3facb3['node']['value']=_0x1318ef,Ri(_0x3facb3);}function ea(_0x34b21e){return _0x34b21e['node']['childCount']>0x0;}function id(_0x172d9f){return Ge(_0x172d9f)===void 0x0&&!ea(_0x172d9f);}function Wn(_0x206b41,_0x138720){x(_0x206b41['node']['children'],(_0x207f8d,_0xa16309)=>{_0x138720(new ds(_0x207f8d,_0x206b41,_0xa16309));});}function ta(_0x2e1a81,_0x56d6e0,_0x34beea,_0x5d04e0){_0x34beea&&_0x56d6e0(_0x2e1a81),Wn(_0x2e1a81,_0x2dcc54=>{ta(_0x2dcc54,_0x56d6e0,!0x0);});}function sd(_0x56d846,_0x428da5,_0x20d44e){let _0x36b002=_0x56d846['parent'];for(;_0x36b002!==null;){if(_0x428da5(_0x36b002))return!0x0;_0x36b002=_0x36b002['parent'];}return!0x1;}function Gt(_0x2d267c){return new C(_0x2d267c['parent']===null?_0x2d267c['name']:Gt(_0x2d267c['parent'])+'/'+_0x2d267c['name']);}function Ri(_0x7099c0){_0x7099c0['parent']!==null&&rd(_0x7099c0['parent'],_0x7099c0['name'],_0x7099c0);}function rd(_0xa85b07,_0x1e5034,_0x5cae91){const _0x17ddf9=id(_0x5cae91),_0x1f52b9=Y(_0xa85b07['node']['children'],_0x1e5034);_0x17ddf9&&_0x1f52b9?(delete _0xa85b07['node']['children'][_0x1e5034],_0xa85b07['node']['childCount']--,Ri(_0xa85b07)):!_0x17ddf9&&!_0x1f52b9&&(_0xa85b07['node']['children'][_0x1e5034]=_0x5cae91['node'],_0xa85b07['node']['childCount']++,Ri(_0xa85b07));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x42a0d2){return typeof _0x42a0d2=='string'&&_0x42a0d2['length']!==0x0&&!od['test'](_0x42a0d2);},na=function(_0x351254){return typeof _0x351254=='string'&&_0x351254['length']!==0x0&&!ad['test'](_0x351254);},cd=function(_0x4915cf){return _0x4915cf&&(_0x4915cf=_0x4915cf['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x4915cf);},Cn=function(_0x564b0c){return _0x564b0c===null||typeof _0x564b0c=='string'||typeof _0x564b0c=='number'&&!Wi(_0x564b0c)||_0x564b0c&&typeof _0x564b0c=='object'&&Y(_0x564b0c,'.sv');},qt=function(_0xd826c3,_0x2104d7,_0x11ff95,_0x5b94c7){_0x5b94c7&&_0x2104d7===void 0x0||zt(Nn(_0xd826c3,'value'),_0x2104d7,_0x11ff95);},zt=function(_0x20c4a9,_0x1e804f,_0x32fd9f){const _0x1aebd5=_0x32fd9f instanceof C?new Sh(_0x32fd9f,_0x20c4a9):_0x32fd9f;if(_0x1e804f===void 0x0)throw new Error(_0x20c4a9+'contains\x20undefined\x20'+Ne(_0x1aebd5));if(typeof _0x1e804f=='function')throw new Error(_0x20c4a9+'contains\x20a\x20function\x20'+Ne(_0x1aebd5)+'\x20with\x20contents\x20=\x20'+_0x1e804f['toString']());if(Wi(_0x1e804f))throw new Error(_0x20c4a9+'contains\x20'+_0x1e804f['toString']()+'\x20'+Ne(_0x1aebd5));if(typeof _0x1e804f=='string'&&_0x1e804f['length']>oi/0x3&&Pn(_0x1e804f)>oi)throw new Error(_0x20c4a9+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x1aebd5)+'\x20(\x27'+_0x1e804f['substring'](0x0,0x32)+'...\x27)');if(_0x1e804f&&typeof _0x1e804f=='object'){let _0x41b203=!0x1,_0x243734=!0x1;if(x(_0x1e804f,(_0x47bfc9,_0x473625)=>{if(_0x47bfc9==='.value')_0x41b203=!0x0;else{if(_0x47bfc9!=='.priority'&&_0x47bfc9!=='.sv'&&(_0x243734=!0x0,!ps(_0x47bfc9)))throw new Error(_0x20c4a9+'\x20contains\x20an\x20invalid\x20key\x20('+_0x47bfc9+')\x20'+Ne(_0x1aebd5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x1aebd5,_0x47bfc9),zt(_0x20c4a9,_0x473625,_0x1aebd5),Rh(_0x1aebd5);}),_0x41b203&&_0x243734)throw new Error(_0x20c4a9+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x1aebd5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x51b492,_0x418f9c){let _0x28ea42,_0x5252ef;for(_0x28ea42=0x0;_0x28ea42<_0x418f9c['length'];_0x28ea42++){_0x5252ef=_0x418f9c[_0x28ea42];const _0x1e6104=kt(_0x5252ef);for(let _0xa3ffbb=0x0;_0xa3ffbb<_0x1e6104['length'];_0xa3ffbb++)if(!(_0x1e6104[_0xa3ffbb]==='.priority'&&_0xa3ffbb===_0x1e6104['length']-0x1)){if(!ps(_0x1e6104[_0xa3ffbb]))throw new Error(_0x51b492+'contains\x20an\x20invalid\x20key\x20('+_0x1e6104[_0xa3ffbb]+')\x20in\x20path\x20'+_0x5252ef['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x418f9c['sort'](Th);let _0x147498=null;for(_0x28ea42=0x0;_0x28ea42<_0x418f9c['length'];_0x28ea42++){if(_0x5252ef=_0x418f9c[_0x28ea42],_0x147498!==null&&$(_0x147498,_0x5252ef))throw new Error(_0x51b492+'contains\x20a\x20path\x20'+_0x147498['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5252ef['toString']());_0x147498=_0x5252ef;}},hd=function(_0x11d4c1,_0x2e524d,_0x3ccd31,_0x2a001c){const _0x585fa8=Nn(_0x11d4c1,'values');if(!(_0x2e524d&&typeof _0x2e524d=='object')||Array['isArray'](_0x2e524d))throw new Error(_0x585fa8+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5b640c=[];x(_0x2e524d,(_0x354fd3,_0x2c2a26)=>{const _0x17de01=new C(_0x354fd3);if(zt(_0x585fa8,_0x2c2a26,A(_0x3ccd31,_0x17de01)),Gi(_0x17de01)==='.priority'&&!Cn(_0x2c2a26))throw new Error(_0x585fa8+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x17de01['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5b640c['push'](_0x17de01);}),ld(_0x585fa8,_0x5b640c);},_s=function(_0x25e759,_0x2273ec,_0x18579a,_0x254886){if(!na(_0x18579a))throw new Error(Nn(_0x25e759,_0x2273ec)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x18579a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x350959,_0x52e301,_0x2b2786,_0x4439f5){_0x2b2786&&(_0x2b2786=_0x2b2786['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x350959,_0x52e301,_0x2b2786);},gs=function(_0x4cd232,_0x281c93){if(y(_0x281c93)==='.info')throw new Error(_0x4cd232+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1c1096,_0x10fa09){const _0x2b04a5=_0x10fa09['path']['toString']();if(typeof _0x10fa09['repoInfo']['host']!='string'||_0x10fa09['repoInfo']['host']['length']===0x0||!ps(_0x10fa09['repoInfo']['namespace'])&&_0x10fa09['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2b04a5['length']!==0x0&&!cd(_0x2b04a5))throw new Error(Nn(_0x1c1096,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x36d558,_0x5e0d59){let _0x5abdc8=null;for(let _0x284871=0x0;_0x284871<_0x5e0d59['length'];_0x284871++){const _0x5b1468=_0x5e0d59[_0x284871],_0x37403d=_0x5b1468['getPath']();_0x5abdc8!==null&&!qi(_0x37403d,_0x5abdc8['path'])&&(_0x36d558['eventLists_']['push'](_0x5abdc8),_0x5abdc8=null),_0x5abdc8===null&&(_0x5abdc8={'events':[],'path':_0x37403d}),_0x5abdc8['events']['push'](_0x5b1468);}_0x5abdc8&&_0x36d558['eventLists_']['push'](_0x5abdc8);}function ia(_0x1622cb,_0xb2b6f0,_0x5c5f44){Bn(_0x1622cb,_0x5c5f44),sa(_0x1622cb,_0x5e616f=>qi(_0x5e616f,_0xb2b6f0));}function V(_0x3bd380,_0x722ca7,_0x83cb4){Bn(_0x3bd380,_0x83cb4),sa(_0x3bd380,_0x43d901=>$(_0x43d901,_0x722ca7)||$(_0x722ca7,_0x43d901));}function sa(_0x57d5a5,_0x978360){_0x57d5a5['recursionDepth_']++;let _0x22513f=!0x0;for(let _0x16c35d=0x0;_0x16c35d<_0x57d5a5['eventLists_']['length'];_0x16c35d++){const _0x25ee36=_0x57d5a5['eventLists_'][_0x16c35d];if(_0x25ee36){const _0x1a0518=_0x25ee36['path'];_0x978360(_0x1a0518)?(pd(_0x57d5a5['eventLists_'][_0x16c35d]),_0x57d5a5['eventLists_'][_0x16c35d]=null):_0x22513f=!0x1;}}_0x22513f&&(_0x57d5a5['eventLists_']=[]),_0x57d5a5['recursionDepth_']--;}function pd(_0x57a7c9){for(let _0x4ae1ed=0x0;_0x4ae1ed<_0x57a7c9['events']['length'];_0x4ae1ed++){const _0x20574c=_0x57a7c9['events'][_0x4ae1ed];if(_0x20574c!==null){_0x57a7c9['events'][_0x4ae1ed]=null;const _0x43661c=_0x20574c['getEventRunner']();Et&&L('event:\x20'+_0x20574c['toString']()),lt(_0x43661c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x5cd26b,_0x34c835,_0x395e59,_0x12aae5){this['repoInfo_']=_0x5cd26b,this['forceRestClient_']=_0x34c835,this['authTokenProvider_']=_0x395e59,this['appCheckProvider_']=_0x12aae5,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x28fb02,_0x361384,_0x108f8a){if(_0x28fb02['stats_']=Hi(_0x28fb02['repoInfo_']),_0x28fb02['forceRestClient_']||Yl())_0x28fb02['server_']=new fn(_0x28fb02['repoInfo_'],(_0x3cb28a,_0x598d56,_0x8dbfa0,_0x4a03a5)=>{pr(_0x28fb02,_0x3cb28a,_0x598d56,_0x8dbfa0,_0x4a03a5);},_0x28fb02['authTokenProvider_'],_0x28fb02['appCheckProvider_']),setTimeout(()=>_r(_0x28fb02,!0x0),0x0);else{if(typeof _0x108f8a<'u'&&_0x108f8a!==null){if(typeof _0x108f8a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x108f8a);}catch(_0x3f45f6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3f45f6);}}_0x28fb02['persistentConnection_']=new ie(_0x28fb02['repoInfo_'],_0x361384,(_0x124204,_0x52f3c8,_0x41bae9,_0x24cb3d)=>{pr(_0x28fb02,_0x124204,_0x52f3c8,_0x41bae9,_0x24cb3d);},_0x455984=>{_r(_0x28fb02,_0x455984);},_0x2bdbb7=>{yd(_0x28fb02,_0x2bdbb7);},_0x28fb02['authTokenProvider_'],_0x28fb02['appCheckProvider_'],_0x108f8a),_0x28fb02['server_']=_0x28fb02['persistentConnection_'];}_0x28fb02['authTokenProvider_']['addTokenChangeListener'](_0x5b28d9=>{_0x28fb02['server_']['refreshAuthToken'](_0x5b28d9);}),_0x28fb02['appCheckProvider_']['addTokenChangeListener'](_0x1c55f2=>{_0x28fb02['server_']['refreshAppCheckToken'](_0x1c55f2['token']);}),_0x28fb02['statsReporter_']=eh(_0x28fb02['repoInfo_'],()=>new eu(_0x28fb02['stats_'],_0x28fb02['server_'])),_0x28fb02['infoData_']=new Yh(),_0x28fb02['infoSyncTree_']=new dr({'startListening':(_0x37f74f,_0x4c27b1,_0xe2aa71,_0x41a841)=>{let _0xb516bd=[];const _0x3cc862=_0x28fb02['infoData_']['getNode'](_0x37f74f['_path']);return _0x3cc862['isEmpty']()||(_0xb516bd=$t(_0x28fb02['infoSyncTree_'],_0x37f74f['_path'],_0x3cc862),setTimeout(()=>{_0x41a841('ok');},0x0)),_0xb516bd;},'stopListening':()=>{}}),ms(_0x28fb02,'connected',!0x1),_0x28fb02['serverSyncTree_']=new dr({'startListening':(_0x3d3c9f,_0x503723,_0x47416c,_0x4dd2ee)=>(_0x28fb02['server_']['listen'](_0x3d3c9f,_0x47416c,_0x503723,(_0x160899,_0x187b01)=>{const _0x1a68b6=_0x4dd2ee(_0x160899,_0x187b01);V(_0x28fb02['eventQueue_'],_0x3d3c9f['_path'],_0x1a68b6);}),[]),'stopListening':(_0x107b1e,_0x294761)=>{_0x28fb02['server_']['unlisten'](_0x107b1e,_0x294761);}});}function oa(_0x50cc88){const _0x1e1406=_0x50cc88['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1e1406;}function jt(_0x1987ca){return ed({'timestamp':oa(_0x1987ca)});}function pr(_0x5b75a3,_0x3ae9df,_0xce01bd,_0x20d519,_0x442463){_0x5b75a3['dataUpdateCount']++;const _0x2bd4d6=new C(_0x3ae9df);_0xce01bd=_0x5b75a3['interceptServerDataCallback_']?_0x5b75a3['interceptServerDataCallback_'](_0x3ae9df,_0xce01bd):_0xce01bd;let _0x2bbc34=[];if(_0x442463){if(_0x20d519){const _0x53c02d=ln(_0xce01bd,_0x5f49f7=>N(_0x5f49f7));_0x2bbc34=Ku(_0x5b75a3['serverSyncTree_'],_0x2bd4d6,_0x53c02d,_0x442463);}else{const _0x17b7cb=N(_0xce01bd);_0x2bbc34=Yo(_0x5b75a3['serverSyncTree_'],_0x2bd4d6,_0x17b7cb,_0x442463);}}else{if(_0x20d519){const _0x53561c=ln(_0xce01bd,_0x500893=>N(_0x500893));_0x2bbc34=qu(_0x5b75a3['serverSyncTree_'],_0x2bd4d6,_0x53561c);}else{const _0x3eeedd=N(_0xce01bd);_0x2bbc34=$t(_0x5b75a3['serverSyncTree_'],_0x2bd4d6,_0x3eeedd);}}let _0xf1c002=_0x2bd4d6;_0x2bbc34['length']>0x0&&(_0xf1c002=st(_0x5b75a3,_0x2bd4d6)),V(_0x5b75a3['eventQueue_'],_0xf1c002,_0x2bbc34);}function _r(_0x752e3c,_0x458786){ms(_0x752e3c,'connected',_0x458786),_0x458786===!0x1&&wd(_0x752e3c);}function yd(_0x31b299,_0x290b3a){x(_0x290b3a,(_0x8f6393,_0xa03fa)=>{ms(_0x31b299,_0x8f6393,_0xa03fa);});}function ms(_0x5da6f2,_0x2c7c96,_0x268257){const _0x40f88b=new C('/.info/'+_0x2c7c96),_0x2d211e=N(_0x268257);_0x5da6f2['infoData_']['updateSnapshot'](_0x40f88b,_0x2d211e);const _0x44e019=$t(_0x5da6f2['infoSyncTree_'],_0x40f88b,_0x2d211e);V(_0x5da6f2['eventQueue_'],_0x40f88b,_0x44e019);}function Vn(_0x531405){return _0x531405['nextWriteId_']++;}function vd(_0x33cf8d,_0x5a02e1,_0x4e86a9){const _0x2f01c5=Yu(_0x33cf8d['serverSyncTree_'],_0x5a02e1);return _0x2f01c5!=null?Promise['resolve'](_0x2f01c5):_0x33cf8d['server_']['get'](_0x5a02e1)['then'](_0x4d2993=>{const _0x4d7192=N(_0x4d2993)['withIndex'](_0x5a02e1['_queryParams']['getIndex']());bi(_0x33cf8d['serverSyncTree_'],_0x5a02e1,_0x4e86a9,!0x0);let _0x410ff9;if(_0x5a02e1['_queryParams']['loadsAllData']())_0x410ff9=$t(_0x33cf8d['serverSyncTree_'],_0x5a02e1['_path'],_0x4d7192);else{const _0x38be60=Mt(_0x33cf8d['serverSyncTree_'],_0x5a02e1);_0x410ff9=Yo(_0x33cf8d['serverSyncTree_'],_0x5a02e1['_path'],_0x4d7192,_0x38be60);}return V(_0x33cf8d['eventQueue_'],_0x5a02e1['_path'],_0x410ff9),wn(_0x33cf8d['serverSyncTree_'],_0x5a02e1,_0x4e86a9,null,!0x0),_0x4d7192;},_0xe3b177=>(ut(_0x33cf8d,'get\x20for\x20query\x20'+O(_0x5a02e1)+'\x20failed:\x20'+_0xe3b177),Promise['reject'](new Error(_0xe3b177))));}function Ed(_0x5b8fef,_0x2c8ce0,_0x179748,_0x5d04a3,_0x21d3f7){ut(_0x5b8fef,'set',{'path':_0x2c8ce0['toString'](),'value':_0x179748,'priority':_0x5d04a3});const _0x305ee1=jt(_0x5b8fef),_0x349e51=N(_0x179748,_0x5d04a3),_0x1beb9f=xn(_0x5b8fef['serverSyncTree_'],_0x2c8ce0),_0x3cebf1=hs(_0x349e51,_0x1beb9f,_0x305ee1),_0x1c20e2=Vn(_0x5b8fef),_0x4fd722=ss(_0x5b8fef['serverSyncTree_'],_0x2c8ce0,_0x3cebf1,_0x1c20e2,!0x0);Bn(_0x5b8fef['eventQueue_'],_0x4fd722),_0x5b8fef['server_']['put'](_0x2c8ce0['toString'](),_0x349e51['val'](!0x0),(_0x33ae55,_0x4dc907)=>{const _0x33caac=_0x33ae55==='ok';_0x33caac||U('set\x20at\x20'+_0x2c8ce0+'\x20failed:\x20'+_0x33ae55);const _0x436904=pe(_0x5b8fef['serverSyncTree_'],_0x1c20e2,!_0x33caac);V(_0x5b8fef['eventQueue_'],_0x2c8ce0,_0x436904),Ai(_0x5b8fef,_0x21d3f7,_0x33ae55,_0x4dc907);});const _0x185bd3=vs(_0x5b8fef,_0x2c8ce0);st(_0x5b8fef,_0x185bd3),V(_0x5b8fef['eventQueue_'],_0x185bd3,[]);}function Id(_0x408662,_0x3f887d,_0x34d760,_0x34ee9a){ut(_0x408662,'update',{'path':_0x3f887d['toString'](),'value':_0x34d760});let _0x17bc92=!0x0;const _0x244048=jt(_0x408662),_0x47d3fd={};if(x(_0x34d760,(_0x516475,_0x21dd22)=>{_0x17bc92=!0x1,_0x47d3fd[_0x516475]=Zo(A(_0x3f887d,_0x516475),N(_0x21dd22),_0x408662['serverSyncTree_'],_0x244048);}),_0x17bc92)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x408662,_0x34ee9a,'ok',void 0x0);else{const _0x5be897=Vn(_0x408662),_0x44288f=Gu(_0x408662['serverSyncTree_'],_0x3f887d,_0x47d3fd,_0x5be897);Bn(_0x408662['eventQueue_'],_0x44288f),_0x408662['server_']['merge'](_0x3f887d['toString'](),_0x34d760,(_0x30e53a,_0x5d8b50)=>{const _0x25f145=_0x30e53a==='ok';_0x25f145||U('update\x20at\x20'+_0x3f887d+'\x20failed:\x20'+_0x30e53a);const _0x49a58e=pe(_0x408662['serverSyncTree_'],_0x5be897,!_0x25f145),_0x148491=_0x49a58e['length']>0x0?st(_0x408662,_0x3f887d):_0x3f887d;V(_0x408662['eventQueue_'],_0x148491,_0x49a58e),Ai(_0x408662,_0x34ee9a,_0x30e53a,_0x5d8b50);}),x(_0x34d760,_0x3f56a7=>{const _0x383f5d=vs(_0x408662,A(_0x3f887d,_0x3f56a7));st(_0x408662,_0x383f5d);}),V(_0x408662['eventQueue_'],_0x3f887d,[]);}}function wd(_0x536ef2){ut(_0x536ef2,'onDisconnectEvents');const _0x5a7e03=jt(_0x536ef2),_0x1e3a41=pn();Ei(_0x536ef2['onDisconnect_'],w(),(_0x2b4ad3,_0x3f4dd8)=>{const _0x53e541=Zo(_0x2b4ad3,_0x3f4dd8,_0x536ef2['serverSyncTree_'],_0x5a7e03);Mo(_0x1e3a41,_0x2b4ad3,_0x53e541);});let _0x107746=[];Ei(_0x1e3a41,w(),(_0x6631f4,_0xa3e00e)=>{_0x107746=_0x107746['concat']($t(_0x536ef2['serverSyncTree_'],_0x6631f4,_0xa3e00e));const _0x42f329=vs(_0x536ef2,_0x6631f4);st(_0x536ef2,_0x42f329);}),_0x536ef2['onDisconnect_']=pn(),V(_0x536ef2['eventQueue_'],w(),_0x107746);}function Cd(_0x38c2df,_0x5adcad,_0x102fdc){let _0x4f7ea7;y(_0x5adcad['_path'])==='.info'?_0x4f7ea7=bi(_0x38c2df['infoSyncTree_'],_0x5adcad,_0x102fdc):_0x4f7ea7=bi(_0x38c2df['serverSyncTree_'],_0x5adcad,_0x102fdc),ia(_0x38c2df['eventQueue_'],_0x5adcad['_path'],_0x4f7ea7);}function Td(_0x3dac29,_0x3d87b2,_0xd26c6){let _0x5102d4;y(_0x3d87b2['_path'])==='.info'?_0x5102d4=wn(_0x3dac29['infoSyncTree_'],_0x3d87b2,_0xd26c6):_0x5102d4=wn(_0x3dac29['serverSyncTree_'],_0x3d87b2,_0xd26c6),ia(_0x3dac29['eventQueue_'],_0x3d87b2['_path'],_0x5102d4);}function aa(_0x5ca75f){_0x5ca75f['persistentConnection_']&&_0x5ca75f['persistentConnection_']['interrupt'](ra);}function Sd(_0xc702fc){_0xc702fc['persistentConnection_']&&_0xc702fc['persistentConnection_']['resume'](ra);}function ut(_0x4d9232,..._0x1d0bcd){let _0x596826='';_0x4d9232['persistentConnection_']&&(_0x596826=_0x4d9232['persistentConnection_']['id']+':'),L(_0x596826,..._0x1d0bcd);}function Ai(_0x407e2f,_0x12f5af,_0xf8fc7c,_0x5a7294){_0x12f5af&&lt(()=>{if(_0xf8fc7c==='ok')_0x12f5af(null);else{const _0x4c6e01=(_0xf8fc7c||'error')['toUpperCase']();let _0x30c8ba=_0x4c6e01;_0x5a7294&&(_0x30c8ba+=':\x20'+_0x5a7294);const _0x5d4527=new Error(_0x30c8ba);_0x5d4527['code']=_0x4c6e01,_0x12f5af(_0x5d4527);}});}function bd(_0x587199,_0x1b8a95,_0x14dd6d,_0x28a2ea,_0x1bb878,_0x2ce104){ut(_0x587199,'transaction\x20on\x20'+_0x1b8a95);const _0x161fef={'path':_0x1b8a95,'update':_0x14dd6d,'onComplete':_0x28a2ea,'status':null,'order':to(),'applyLocally':_0x2ce104,'retryCount':0x0,'unwatcher':_0x1bb878,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x34302d=ys(_0x587199,_0x1b8a95,void 0x0);_0x161fef['currentInputSnapshot']=_0x34302d;const _0x7a3536=_0x161fef['update'](_0x34302d['val']());if(_0x7a3536===void 0x0)_0x161fef['unwatcher'](),_0x161fef['currentOutputSnapshotRaw']=null,_0x161fef['currentOutputSnapshotResolved']=null,_0x161fef['onComplete']&&_0x161fef['onComplete'](null,!0x1,_0x161fef['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x7a3536,_0x161fef['path']),_0x161fef['status']=0x0;const _0x4deb8b=Un(_0x587199['transactionQueueTree_'],_0x1b8a95),_0x483f00=Ge(_0x4deb8b)||[];_0x483f00['push'](_0x161fef),fs(_0x4deb8b,_0x483f00);let _0x487dab;typeof _0x7a3536=='object'&&_0x7a3536!==null&&Y(_0x7a3536,'.priority')?(_0x487dab=Oe(_0x7a3536,'.priority'),f(Cn(_0x487dab),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x487dab=(xn(_0x587199['serverSyncTree_'],_0x1b8a95)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1221d5=jt(_0x587199),_0x131025=N(_0x7a3536,_0x487dab),_0x2e1540=hs(_0x131025,_0x34302d,_0x1221d5);_0x161fef['currentOutputSnapshotRaw']=_0x131025,_0x161fef['currentOutputSnapshotResolved']=_0x2e1540,_0x161fef['currentWriteId']=Vn(_0x587199);const _0x1063ef=ss(_0x587199['serverSyncTree_'],_0x1b8a95,_0x2e1540,_0x161fef['currentWriteId'],_0x161fef['applyLocally']);V(_0x587199['eventQueue_'],_0x1b8a95,_0x1063ef),Hn(_0x587199,_0x587199['transactionQueueTree_']);}}function ys(_0x39b26b,_0x5e9602,_0x5a8bd9){return xn(_0x39b26b['serverSyncTree_'],_0x5e9602,_0x5a8bd9)||g['EMPTY_NODE'];}function Hn(_0x5fe58,_0x4a1b3e=_0x5fe58['transactionQueueTree_']){if(_0x4a1b3e||$n(_0x5fe58,_0x4a1b3e),Ge(_0x4a1b3e)){const _0x105d49=la(_0x5fe58,_0x4a1b3e);f(_0x105d49['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x105d49['every'](_0x4375c2=>_0x4375c2['status']===0x0)&&Rd(_0x5fe58,Gt(_0x4a1b3e),_0x105d49);}else ea(_0x4a1b3e)&&Wn(_0x4a1b3e,_0xb96c2d=>{Hn(_0x5fe58,_0xb96c2d);});}function Rd(_0x54b308,_0x433cb5,_0x2044e5){const _0xcf73d7=_0x2044e5['map'](_0x196b9a=>_0x196b9a['currentWriteId']),_0xd09006=ys(_0x54b308,_0x433cb5,_0xcf73d7);let _0x37db2d=_0xd09006;const _0x208b9b=_0xd09006['hash']();for(let _0x4d033b=0x0;_0x4d033b<_0x2044e5['length'];_0x4d033b++){const _0x72cc5c=_0x2044e5[_0x4d033b];f(_0x72cc5c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x72cc5c['status']=0x1,_0x72cc5c['retryCount']++;const _0x5452b7=F(_0x433cb5,_0x72cc5c['path']);_0x37db2d=_0x37db2d['updateChild'](_0x5452b7,_0x72cc5c['currentOutputSnapshotRaw']);}const _0x2e17a7=_0x37db2d['val'](!0x0),_0x6aaf6=_0x433cb5;_0x54b308['server_']['put'](_0x6aaf6['toString'](),_0x2e17a7,_0x7f893f=>{ut(_0x54b308,'transaction\x20put\x20response',{'path':_0x6aaf6['toString'](),'status':_0x7f893f});let _0x9c95d=[];if(_0x7f893f==='ok'){const _0x4b40ec=[];for(let _0x3c89d9=0x0;_0x3c89d9<_0x2044e5['length'];_0x3c89d9++)_0x2044e5[_0x3c89d9]['status']=0x2,_0x9c95d=_0x9c95d['concat'](pe(_0x54b308['serverSyncTree_'],_0x2044e5[_0x3c89d9]['currentWriteId'])),_0x2044e5[_0x3c89d9]['onComplete']&&_0x4b40ec['push'](()=>_0x2044e5[_0x3c89d9]['onComplete'](null,!0x0,_0x2044e5[_0x3c89d9]['currentOutputSnapshotResolved'])),_0x2044e5[_0x3c89d9]['unwatcher']();$n(_0x54b308,Un(_0x54b308['transactionQueueTree_'],_0x433cb5)),Hn(_0x54b308,_0x54b308['transactionQueueTree_']),V(_0x54b308['eventQueue_'],_0x433cb5,_0x9c95d);for(let _0x353319=0x0;_0x353319<_0x4b40ec['length'];_0x353319++)lt(_0x4b40ec[_0x353319]);}else{if(_0x7f893f==='datastale'){for(let _0x4905fc=0x0;_0x4905fc<_0x2044e5['length'];_0x4905fc++)_0x2044e5[_0x4905fc]['status']===0x3?_0x2044e5[_0x4905fc]['status']=0x4:_0x2044e5[_0x4905fc]['status']=0x0;}else{U('transaction\x20at\x20'+_0x6aaf6['toString']()+'\x20failed:\x20'+_0x7f893f);for(let _0x15c8ab=0x0;_0x15c8ab<_0x2044e5['length'];_0x15c8ab++)_0x2044e5[_0x15c8ab]['status']=0x4,_0x2044e5[_0x15c8ab]['abortReason']=_0x7f893f;}st(_0x54b308,_0x433cb5);}},_0x208b9b);}function st(_0x5bb2d0,_0x21b761){const _0x2f2a5e=ca(_0x5bb2d0,_0x21b761),_0x3b329e=Gt(_0x2f2a5e),_0x42d65d=la(_0x5bb2d0,_0x2f2a5e);return Ad(_0x5bb2d0,_0x42d65d,_0x3b329e),_0x3b329e;}function Ad(_0x4bf0f8,_0x115006,_0x24e0fd){if(_0x115006['length']===0x0)return;const _0x1bc582=[];let _0x2d63b4=[];const _0x37f0fe=_0x115006['filter'](_0x5dbafa=>_0x5dbafa['status']===0x0)['map'](_0x3b7b07=>_0x3b7b07['currentWriteId']);for(let _0xda1dc9=0x0;_0xda1dc9<_0x115006['length'];_0xda1dc9++){const _0x4794ba=_0x115006[_0xda1dc9],_0x38ec38=F(_0x24e0fd,_0x4794ba['path']);let _0xb334fc=!0x1,_0x51863e;if(f(_0x38ec38!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4794ba['status']===0x4)_0xb334fc=!0x0,_0x51863e=_0x4794ba['abortReason'],_0x2d63b4=_0x2d63b4['concat'](pe(_0x4bf0f8['serverSyncTree_'],_0x4794ba['currentWriteId'],!0x0));else{if(_0x4794ba['status']===0x0){if(_0x4794ba['retryCount']>=_d)_0xb334fc=!0x0,_0x51863e='maxretry',_0x2d63b4=_0x2d63b4['concat'](pe(_0x4bf0f8['serverSyncTree_'],_0x4794ba['currentWriteId'],!0x0));else{const _0x17cf8f=ys(_0x4bf0f8,_0x4794ba['path'],_0x37f0fe);_0x4794ba['currentInputSnapshot']=_0x17cf8f;const _0x188afc=_0x115006[_0xda1dc9]['update'](_0x17cf8f['val']());if(_0x188afc!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x188afc,_0x4794ba['path']);let _0x1013ea=N(_0x188afc);typeof _0x188afc=='object'&&_0x188afc!=null&&Y(_0x188afc,'.priority')||(_0x1013ea=_0x1013ea['updatePriority'](_0x17cf8f['getPriority']()));const _0x410e31=_0x4794ba['currentWriteId'],_0x183f8a=jt(_0x4bf0f8),_0xa3777=hs(_0x1013ea,_0x17cf8f,_0x183f8a);_0x4794ba['currentOutputSnapshotRaw']=_0x1013ea,_0x4794ba['currentOutputSnapshotResolved']=_0xa3777,_0x4794ba['currentWriteId']=Vn(_0x4bf0f8),_0x37f0fe['splice'](_0x37f0fe['indexOf'](_0x410e31),0x1),_0x2d63b4=_0x2d63b4['concat'](ss(_0x4bf0f8['serverSyncTree_'],_0x4794ba['path'],_0xa3777,_0x4794ba['currentWriteId'],_0x4794ba['applyLocally'])),_0x2d63b4=_0x2d63b4['concat'](pe(_0x4bf0f8['serverSyncTree_'],_0x410e31,!0x0));}else _0xb334fc=!0x0,_0x51863e='nodata',_0x2d63b4=_0x2d63b4['concat'](pe(_0x4bf0f8['serverSyncTree_'],_0x4794ba['currentWriteId'],!0x0));}}}V(_0x4bf0f8['eventQueue_'],_0x24e0fd,_0x2d63b4),_0x2d63b4=[],_0xb334fc&&(_0x115006[_0xda1dc9]['status']=0x2,function(_0x495c19){setTimeout(_0x495c19,Math['floor'](0x0));}(_0x115006[_0xda1dc9]['unwatcher']),_0x115006[_0xda1dc9]['onComplete']&&(_0x51863e==='nodata'?_0x1bc582['push'](()=>_0x115006[_0xda1dc9]['onComplete'](null,!0x1,_0x115006[_0xda1dc9]['currentInputSnapshot'])):_0x1bc582['push'](()=>_0x115006[_0xda1dc9]['onComplete'](new Error(_0x51863e),!0x1,null))));}$n(_0x4bf0f8,_0x4bf0f8['transactionQueueTree_']);for(let _0x4a537a=0x0;_0x4a537a<_0x1bc582['length'];_0x4a537a++)lt(_0x1bc582[_0x4a537a]);Hn(_0x4bf0f8,_0x4bf0f8['transactionQueueTree_']);}function ca(_0x4eb684,_0x4e2f95){let _0x1b14fe,_0x36332f=_0x4eb684['transactionQueueTree_'];for(_0x1b14fe=y(_0x4e2f95);_0x1b14fe!==null&&Ge(_0x36332f)===void 0x0;)_0x36332f=Un(_0x36332f,_0x1b14fe),_0x4e2f95=b(_0x4e2f95),_0x1b14fe=y(_0x4e2f95);return _0x36332f;}function la(_0x249cc4,_0x10cda6){const _0x1a90ef=[];return ha(_0x249cc4,_0x10cda6,_0x1a90ef),_0x1a90ef['sort']((_0x3763bc,_0xf50bb9)=>_0x3763bc['order']-_0xf50bb9['order']),_0x1a90ef;}function ha(_0x4d330c,_0x407a1a,_0x40a684){const _0x1d3f6c=Ge(_0x407a1a);if(_0x1d3f6c){for(let _0x59239b=0x0;_0x59239b<_0x1d3f6c['length'];_0x59239b++)_0x40a684['push'](_0x1d3f6c[_0x59239b]);}Wn(_0x407a1a,_0x4f3eab=>{ha(_0x4d330c,_0x4f3eab,_0x40a684);});}function $n(_0x308033,_0x28f82e){const _0x4f84b9=Ge(_0x28f82e);if(_0x4f84b9){let _0x4f2498=0x0;for(let _0x1b5e97=0x0;_0x1b5e97<_0x4f84b9['length'];_0x1b5e97++)_0x4f84b9[_0x1b5e97]['status']!==0x2&&(_0x4f84b9[_0x4f2498]=_0x4f84b9[_0x1b5e97],_0x4f2498++);_0x4f84b9['length']=_0x4f2498,fs(_0x28f82e,_0x4f84b9['length']>0x0?_0x4f84b9:void 0x0);}Wn(_0x28f82e,_0x5c6e99=>{$n(_0x308033,_0x5c6e99);});}function vs(_0x47824e,_0x4a5d45){const _0x4006d9=Gt(ca(_0x47824e,_0x4a5d45)),_0x2af22f=Un(_0x47824e['transactionQueueTree_'],_0x4a5d45);return sd(_0x2af22f,_0x414dbe=>{ai(_0x47824e,_0x414dbe);}),ai(_0x47824e,_0x2af22f),ta(_0x2af22f,_0x524eb3=>{ai(_0x47824e,_0x524eb3);}),_0x4006d9;}function ai(_0x33bbb1,_0x3afe05){const _0x349cb5=Ge(_0x3afe05);if(_0x349cb5){const _0x4deb55=[];let _0x471cf2=[],_0x5be1a7=-0x1;for(let _0x7aedae=0x0;_0x7aedae<_0x349cb5['length'];_0x7aedae++)_0x349cb5[_0x7aedae]['status']===0x3||(_0x349cb5[_0x7aedae]['status']===0x1?(f(_0x5be1a7===_0x7aedae-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5be1a7=_0x7aedae,_0x349cb5[_0x7aedae]['status']=0x3,_0x349cb5[_0x7aedae]['abortReason']='set'):(f(_0x349cb5[_0x7aedae]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x349cb5[_0x7aedae]['unwatcher'](),_0x471cf2=_0x471cf2['concat'](pe(_0x33bbb1['serverSyncTree_'],_0x349cb5[_0x7aedae]['currentWriteId'],!0x0)),_0x349cb5[_0x7aedae]['onComplete']&&_0x4deb55['push'](_0x349cb5[_0x7aedae]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5be1a7===-0x1?fs(_0x3afe05,void 0x0):_0x349cb5['length']=_0x5be1a7+0x1,V(_0x33bbb1['eventQueue_'],Gt(_0x3afe05),_0x471cf2);for(let _0x3cac84=0x0;_0x3cac84<_0x4deb55['length'];_0x3cac84++)lt(_0x4deb55[_0x3cac84]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0xb27be7){let _0x1bfdb5='';const _0x50f05e=_0xb27be7['split']('/');for(let _0x52cd52=0x0;_0x52cd52<_0x50f05e['length'];_0x52cd52++)if(_0x50f05e[_0x52cd52]['length']>0x0){let _0x10eec8=_0x50f05e[_0x52cd52];try{_0x10eec8=decodeURIComponent(_0x10eec8['replace'](/\+/g,'\x20'));}catch{}_0x1bfdb5+='/'+_0x10eec8;}return _0x1bfdb5;}function Nd(_0x45a27e){const _0x23858f={};_0x45a27e['charAt'](0x0)==='?'&&(_0x45a27e=_0x45a27e['substring'](0x1));for(const _0x1fc211 of _0x45a27e['split']('&')){if(_0x1fc211['length']===0x0)continue;const _0x4c5660=_0x1fc211['split']('=');_0x4c5660['length']===0x2?_0x23858f[decodeURIComponent(_0x4c5660[0x0])]=decodeURIComponent(_0x4c5660[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1fc211+'\x27\x20in\x20query\x20\x27'+_0x45a27e+'\x27');}return _0x23858f;}const gr=function(_0x2aeee7,_0x32ce01){const _0x23278f=Pd(_0x2aeee7),_0x33640e=_0x23278f['namespace'];_0x23278f['domain']==='firebase.com'&&oe(_0x23278f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x33640e||_0x33640e==='undefined')&&_0x23278f['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x23278f['secure']||Bl();const _0x5bf095=_0x23278f['scheme']==='ws'||_0x23278f['scheme']==='wss';return{'repoInfo':new _o(_0x23278f['host'],_0x23278f['secure'],_0x33640e,_0x5bf095,_0x32ce01,'',_0x33640e!==_0x23278f['subdomain']),'path':new C(_0x23278f['pathString'])};},Pd=function(_0x1159f0){let _0x111153='',_0x395406='',_0x374000='',_0x25de5c='',_0x32ae1e='',_0x4bf225=!0x0,_0x23eb5a='https',_0xddf45e=0x1bb;if(typeof _0x1159f0=='string'){let _0x3683cb=_0x1159f0['indexOf']('//');_0x3683cb>=0x0&&(_0x23eb5a=_0x1159f0['substring'](0x0,_0x3683cb-0x1),_0x1159f0=_0x1159f0['substring'](_0x3683cb+0x2));let _0x37c19e=_0x1159f0['indexOf']('/');_0x37c19e===-0x1&&(_0x37c19e=_0x1159f0['length']);let _0x6459a8=_0x1159f0['indexOf']('?');_0x6459a8===-0x1&&(_0x6459a8=_0x1159f0['length']),_0x111153=_0x1159f0['substring'](0x0,Math['min'](_0x37c19e,_0x6459a8)),_0x37c19e<_0x6459a8&&(_0x25de5c=kd(_0x1159f0['substring'](_0x37c19e,_0x6459a8)));const _0x848ac7=Nd(_0x1159f0['substring'](Math['min'](_0x1159f0['length'],_0x6459a8)));_0x3683cb=_0x111153['indexOf'](':'),_0x3683cb>=0x0?(_0x4bf225=_0x23eb5a==='https'||_0x23eb5a==='wss',_0xddf45e=parseInt(_0x111153['substring'](_0x3683cb+0x1),0xa)):_0x3683cb=_0x111153['length'];const _0x446166=_0x111153['slice'](0x0,_0x3683cb);if(_0x446166['toLowerCase']()==='localhost')_0x395406='localhost';else{if(_0x446166['split']('.')['length']<=0x2)_0x395406=_0x446166;else{const _0x48cbbe=_0x111153['indexOf']('.');_0x374000=_0x111153['substring'](0x0,_0x48cbbe)['toLowerCase'](),_0x395406=_0x111153['substring'](_0x48cbbe+0x1),_0x32ae1e=_0x374000;}}'ns'in _0x848ac7&&(_0x32ae1e=_0x848ac7['ns']);}return{'host':_0x111153,'port':_0xddf45e,'domain':_0x395406,'subdomain':_0x374000,'secure':_0x4bf225,'scheme':_0x23eb5a,'pathString':_0x25de5c,'namespace':_0x32ae1e};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x381867=0x0;const _0xf7c845=[];return function(_0x490f4b){const _0x3fc5bd=_0x490f4b===_0x381867;_0x381867=_0x490f4b;let _0x546183;const _0xee4994=new Array(0x8);for(_0x546183=0x7;_0x546183>=0x0;_0x546183--)_0xee4994[_0x546183]=mr['charAt'](_0x490f4b%0x40),_0x490f4b=Math['floor'](_0x490f4b/0x40);f(_0x490f4b===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x43d74b=_0xee4994['join']('');if(_0x3fc5bd){for(_0x546183=0xb;_0x546183>=0x0&&_0xf7c845[_0x546183]===0x3f;_0x546183--)_0xf7c845[_0x546183]=0x0;_0xf7c845[_0x546183]++;}else{for(_0x546183=0x0;_0x546183<0xc;_0x546183++)_0xf7c845[_0x546183]=Math['floor'](Math['random']()*0x40);}for(_0x546183=0x0;_0x546183<0xc;_0x546183++)_0x43d74b+=mr['charAt'](_0xf7c845[_0x546183]);return f(_0x43d74b['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x43d74b;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x48b69c,_0x507b39,_0x1cf11b,_0x43d145){this['eventType']=_0x48b69c,this['eventRegistration']=_0x507b39,this['snapshot']=_0x1cf11b,this['prevName']=_0x43d145;}['getPath'](){const _0x3148b6=this['snapshot']['ref'];return this['eventType']==='value'?_0x3148b6['_path']:_0x3148b6['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x27c383,_0x511070,_0x1cabc3){this['eventRegistration']=_0x27c383,this['error']=_0x511070,this['path']=_0x1cabc3;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x5da887,_0x5938b9){this['snapshotCallback']=_0x5da887,this['cancelCallback']=_0x5938b9;}['onValue'](_0x3b66ee,_0x26e4de){this['snapshotCallback']['call'](null,_0x3b66ee,_0x26e4de);}['onCancel'](_0x7e0763){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x7e0763);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5ecdcc){return this['snapshotCallback']===_0x5ecdcc['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5ecdcc['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5ecdcc['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5e63b0,_0x1aca74,_0xe30094,_0x8e28ec){this['_repo']=_0x5e63b0,this['_path']=_0x1aca74,this['_queryParams']=_0xe30094,this['_orderByCalled']=_0x8e28ec;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xf3704a=nr(this['_queryParams']),_0xeefa78=Bi(_0xf3704a);return _0xeefa78==='{}'?'default':_0xeefa78;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x23a01b){if(_0x23a01b=k(_0x23a01b),!(_0x23a01b instanceof be))return!0x1;const _0x3c8bc1=this['_repo']===_0x23a01b['_repo'],_0x2c841b=qi(this['_path'],_0x23a01b['_path']),_0x13a1f6=this['_queryIdentifier']===_0x23a01b['_queryIdentifier'];return _0x3c8bc1&&_0x2c841b&&_0x13a1f6;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x105a3a,_0x32f9c7){if(_0x105a3a['_orderByCalled']===!0x0)throw new Error(_0x32f9c7+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x11c808){let _0x3b1a97=null,_0x3bf889=null;if(_0x11c808['hasStart']()&&(_0x3b1a97=_0x11c808['getIndexStartValue']()),_0x11c808['hasEnd']()&&(_0x3bf889=_0x11c808['getIndexEndValue']()),_0x11c808['getIndex']()===ye){const _0x534641='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x54290a='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x11c808['hasStart']()){if(_0x11c808['getIndexStartName']()!==xe)throw new Error(_0x534641);if(typeof _0x3b1a97!='string')throw new Error(_0x54290a);}if(_0x11c808['hasEnd']()){if(_0x11c808['getIndexEndName']()!==Ie)throw new Error(_0x534641);if(typeof _0x3bf889!='string')throw new Error(_0x54290a);}}else{if(_0x11c808['getIndex']()===R){if(_0x3b1a97!=null&&!Cn(_0x3b1a97)||_0x3bf889!=null&&!Cn(_0x3bf889))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x11c808['getIndex']()instanceof Ki||_0x11c808['getIndex']()===Po,'unknown\x20index\x20type.'),_0x3b1a97!=null&&typeof _0x3b1a97=='object'||_0x3bf889!=null&&typeof _0x3bf889=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x4a6583){if(_0x4a6583['hasStart']()&&_0x4a6583['hasEnd']()&&_0x4a6583['hasLimit']()&&!_0x4a6583['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x573b3a,_0x54e12e){super(_0x573b3a,_0x54e12e,new Qi(),!0x1);}get['parent'](){const _0x3a2b45=To(this['_path']);return _0x3a2b45===null?null:new Z(this['_repo'],_0x3a2b45);}get['root'](){let _0x182392=this;for(;_0x182392['parent']!==null;)_0x182392=_0x182392['parent'];return _0x182392;}}class rt{constructor(_0x7fe5c8,_0x674047,_0x57c3e9){this['_node']=_0x7fe5c8,this['ref']=_0x674047,this['_index']=_0x57c3e9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4aa69f){const _0x4e5f1f=new C(_0x4aa69f),_0xd55b0d=Lt(this['ref'],_0x4aa69f);return new rt(this['_node']['getChild'](_0x4e5f1f),_0xd55b0d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x57647a){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5a5ddf,_0x2f3225)=>_0x57647a(new rt(_0x2f3225,Lt(this['ref'],_0x5a5ddf),R)));}['hasChild'](_0x4a7e39){const _0x452769=new C(_0x4a7e39);return!this['_node']['getChild'](_0x452769)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1f5658,_0x122698){return _0x1f5658=k(_0x1f5658),_0x1f5658['_checkNotDeleted']('ref'),_0x122698!==void 0x0?Lt(_0x1f5658['_root'],_0x122698):_0x1f5658['_root'];}function Lt(_0x29be23,_0x5c7a27){return _0x29be23=k(_0x29be23),y(_0x29be23['_path'])===null?ud('child','path',_0x5c7a27):_s('child','path',_0x5c7a27),new Z(_0x29be23['_repo'],A(_0x29be23['_path'],_0x5c7a27));}function d_(_0x451a93,_0x3d605c){_0x451a93=k(_0x451a93),gs('push',_0x451a93['_path']),qt('push',_0x3d605c,_0x451a93['_path'],!0x0);const _0x4f758e=oa(_0x451a93['_repo']),_0xcf1187=Od(_0x4f758e),_0x305b2d=Lt(_0x451a93,_0xcf1187),_0x98b3d1=Lt(_0x451a93,_0xcf1187);let _0x4c884c;return _0x3d605c!=null?_0x4c884c=Ld(_0x98b3d1,_0x3d605c)['then'](()=>_0x98b3d1):_0x4c884c=Promise['resolve'](_0x98b3d1),_0x305b2d['then']=_0x4c884c['then']['bind'](_0x4c884c),_0x305b2d['catch']=_0x4c884c['then']['bind'](_0x4c884c,void 0x0),_0x305b2d;}function Ld(_0x41b3e6,_0x1ed1a2){_0x41b3e6=k(_0x41b3e6),gs('set',_0x41b3e6['_path']),qt('set',_0x1ed1a2,_0x41b3e6['_path'],!0x1);const _0x2798bb=new Ve();return Ed(_0x41b3e6['_repo'],_0x41b3e6['_path'],_0x1ed1a2,null,_0x2798bb['wrapCallback'](()=>{})),_0x2798bb['promise'];}function f_(_0x1073b9,_0x4780dc){hd('update',_0x4780dc,_0x1073b9['_path']);const _0x252202=new Ve();return Id(_0x1073b9['_repo'],_0x1073b9['_path'],_0x4780dc,_0x252202['wrapCallback'](()=>{})),_0x252202['promise'];}function p_(_0x41e5f7){_0x41e5f7=k(_0x41e5f7);const _0x5cf5df=new ua(()=>{}),_0x1ee84e=new qn(_0x5cf5df);return vd(_0x41e5f7['_repo'],_0x41e5f7,_0x1ee84e)['then'](_0x28e635=>new rt(_0x28e635,new Z(_0x41e5f7['_repo'],_0x41e5f7['_path']),_0x41e5f7['_queryParams']['getIndex']()));}class qn{constructor(_0x206fd9){this['callbackContext']=_0x206fd9;}['respondsTo'](_0x25c17d){return _0x25c17d==='value';}['createEvent'](_0x7fea78,_0x1e45e1){const _0x42f2cd=_0x1e45e1['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x7fea78['snapshotNode'],new Z(_0x1e45e1['_repo'],_0x1e45e1['_path']),_0x42f2cd));}['getEventRunner'](_0x2e1079){return _0x2e1079['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2e1079['error']):()=>this['callbackContext']['onValue'](_0x2e1079['snapshot'],null);}['createCancelEvent'](_0x502bef,_0x2406ca){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x502bef,_0x2406ca):null;}['matches'](_0x5e2ea5){return _0x5e2ea5 instanceof qn?!_0x5e2ea5['callbackContext']||!this['callbackContext']?!0x0:_0x5e2ea5['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x204484,_0x2b30ae,_0x1a9480,_0x37513b,_0x1164a1){const _0xe90813=new ua(_0x1a9480,void 0x0),_0x42b48c=new qn(_0xe90813);return Cd(_0x204484['_repo'],_0x204484,_0x42b48c),()=>Td(_0x204484['_repo'],_0x204484,_0x42b48c);}function Fd(_0x25fec1,_0x2553b9,_0x1f61e5,_0xe5091e){return xd(_0x25fec1,'value',_0x2553b9);}class dt{}class pa extends dt{constructor(_0x461a81,_0x3f163c){super(),this['_value']=_0x461a81,this['_key']=_0x3f163c,this['type']='endAt';}['_apply'](_0x2dc3d7){qt('endAt',this['_value'],_0x2dc3d7['_path'],!0x0);const _0xbfa43f=Kh(_0x2dc3d7['_queryParams'],this['_value'],this['_key']);if(fa(_0xbfa43f),Gn(_0xbfa43f),_0x2dc3d7['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2dc3d7['_repo'],_0x2dc3d7['_path'],_0xbfa43f,_0x2dc3d7['_orderByCalled']);}}function __(_0xd056a3,_0x5c0c67){return new pa(_0xd056a3,_0x5c0c67);}class _a extends dt{constructor(_0x5bc7c3,_0xf6978a){super(),this['_value']=_0x5bc7c3,this['_key']=_0xf6978a,this['type']='startAt';}['_apply'](_0x2d0ca0){qt('startAt',this['_value'],_0x2d0ca0['_path'],!0x0);const _0x530b5e=jh(_0x2d0ca0['_queryParams'],this['_value'],this['_key']);if(fa(_0x530b5e),Gn(_0x530b5e),_0x2d0ca0['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2d0ca0['_repo'],_0x2d0ca0['_path'],_0x530b5e,_0x2d0ca0['_orderByCalled']);}}function g_(_0x483f26=null,_0x227015){return new _a(_0x483f26,_0x227015);}class Ud extends dt{constructor(_0x5f0aa7){super(),this['_limit']=_0x5f0aa7,this['type']='limitToFirst';}['_apply'](_0x3fa694){if(_0x3fa694['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3fa694['_repo'],_0x3fa694['_path'],zh(_0x3fa694['_queryParams'],this['_limit']),_0x3fa694['_orderByCalled']);}}function m_(_0x20c07a){if(Math['floor'](_0x20c07a)!==_0x20c07a||_0x20c07a<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x20c07a);}class Wd extends dt{constructor(_0x727d85){super(),this['_path']=_0x727d85,this['type']='orderByChild';}['_apply'](_0x1e857e){da(_0x1e857e,'orderByChild');const _0x58d063=new C(this['_path']);if(v(_0x58d063))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x32b02f=new Ki(_0x58d063),_0x11f94a=Do(_0x1e857e['_queryParams'],_0x32b02f);return Gn(_0x11f94a),new be(_0x1e857e['_repo'],_0x1e857e['_path'],_0x11f94a,!0x0);}}function y_(_0x38ed29){if(_0x38ed29==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x38ed29==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x38ed29==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x38ed29),new Wd(_0x38ed29);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x516207){da(_0x516207,'orderByKey');const _0x574f0d=Do(_0x516207['_queryParams'],ye);return Gn(_0x574f0d),new be(_0x516207['_repo'],_0x516207['_path'],_0x574f0d,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x360cfc,_0x3ae80d){super(),this['_value']=_0x360cfc,this['_key']=_0x3ae80d,this['type']='equalTo';}['_apply'](_0x56c02a){if(qt('equalTo',this['_value'],_0x56c02a['_path'],!0x1),_0x56c02a['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x56c02a['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x56c02a));}}function E_(_0x479e51,_0x3ffa55){return new Vd(_0x479e51,_0x3ffa55);}function I_(_0x488717,..._0x4cc30a){let _0x1731d9=k(_0x488717);for(const _0x3ee574 of _0x4cc30a)_0x1731d9=_0x3ee574['_apply'](_0x1731d9);return _0x1731d9;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x14247c,_0x34f38e,_0x36e444,_0x204a2f){const _0x2e7fa3=_0x34f38e['lastIndexOf'](':'),_0xaf1137=_0x34f38e['substring'](0x0,_0x2e7fa3),_0x10aeea=Wt(_0xaf1137);_0x14247c['repoInfo_']=new _o(_0x34f38e,_0x10aeea,_0x14247c['repoInfo_']['namespace'],_0x14247c['repoInfo_']['webSocketOnly'],_0x14247c['repoInfo_']['nodeAdmin'],_0x14247c['repoInfo_']['persistenceKey'],_0x14247c['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x36e444),_0x204a2f&&(_0x14247c['authTokenProvider_']=_0x204a2f);}function qd(_0x5c9c32,_0x2886bb,_0x14c306,_0x5e3078,_0x5a89fd){let _0x2c04bf=_0x5e3078||_0x5c9c32['options']['databaseURL'];_0x2c04bf===void 0x0&&(_0x5c9c32['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5c9c32['options']['projectId']),_0x2c04bf=_0x5c9c32['options']['projectId']+'-default-rtdb.firebaseio.com');let _0xbe208b=gr(_0x2c04bf,_0x5a89fd),_0x49751e=_0xbe208b['repoInfo'],_0x54147a;typeof process<'u'&&Us&&(_0x54147a=Us[Hd]),_0x54147a?(_0x2c04bf='http://'+_0x54147a+'?ns='+_0x49751e['namespace'],_0xbe208b=gr(_0x2c04bf,_0x5a89fd),_0x49751e=_0xbe208b['repoInfo']):_0xbe208b['repoInfo']['secure'];const _0x1a5df1=new Jl(_0x5c9c32['name'],_0x5c9c32['options'],_0x2886bb);dd('Invalid\x20Firebase\x20Database\x20URL',_0xbe208b),v(_0xbe208b['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1ba193=jd(_0x49751e,_0x5c9c32,_0x1a5df1,new Ql(_0x5c9c32,_0x14c306));return new Kd(_0x1ba193,_0x5c9c32);}function zd(_0x2f4d61,_0x20b02c){const _0x5686a0=ki[_0x20b02c];(!_0x5686a0||_0x5686a0[_0x2f4d61['key']]!==_0x2f4d61)&&oe('Database\x20'+_0x20b02c+'('+_0x2f4d61['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x2f4d61),delete _0x5686a0[_0x2f4d61['key']];}function jd(_0x477aad,_0x31ea5c,_0x552ce2,_0x286de9){let _0x172c1c=ki[_0x31ea5c['name']];_0x172c1c||(_0x172c1c={},ki[_0x31ea5c['name']]=_0x172c1c);let _0x1de375=_0x172c1c[_0x477aad['toURLString']()];return _0x1de375&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1de375=new gd(_0x477aad,$d,_0x552ce2,_0x286de9),_0x172c1c[_0x477aad['toURLString']()]=_0x1de375,_0x1de375;}class Kd{constructor(_0x43d3af,_0x572c6d){this['_repoInternal']=_0x43d3af,this['app']=_0x572c6d,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x24a8c3){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x24a8c3+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x2e373d=Qr(),_0x29a688){const _0x30d98b=Ui(_0x2e373d,'database')['getImmediate']({'identifier':_0x29a688});if(!_0x30d98b['_instanceStarted']){const _0x4a538d=ac('database');_0x4a538d&&Yd(_0x30d98b,..._0x4a538d);}return _0x30d98b;}function Yd(_0x4db0d6,_0x37e624,_0x509e58,_0x5b7d07={}){_0x4db0d6=k(_0x4db0d6),_0x4db0d6['_checkNotDeleted']('useEmulator');const _0x43f305=_0x37e624+':'+_0x509e58,_0x40d22b=_0x4db0d6['_repoInternal'];if(_0x4db0d6['_instanceStarted']){if(_0x43f305===_0x4db0d6['_repoInternal']['repoInfo_']['host']&&De(_0x5b7d07,_0x40d22b['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1e08f5;if(_0x40d22b['repoInfo_']['nodeAdmin'])_0x5b7d07['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1e08f5=new tn(tn['OWNER']);else{if(_0x5b7d07['mockUserToken']){const _0x16aba0=typeof _0x5b7d07['mockUserToken']=='string'?_0x5b7d07['mockUserToken']:cc(_0x5b7d07['mockUserToken'],_0x4db0d6['app']['options']['projectId']);_0x1e08f5=new tn(_0x16aba0);}}Wt(_0x37e624)&&jr(_0x37e624),Gd(_0x40d22b,_0x43f305,_0x5b7d07,_0x1e08f5);}function C_(_0x4b103b){_0x4b103b=k(_0x4b103b),_0x4b103b['_checkNotDeleted']('goOffline'),aa(_0x4b103b['_repo']);}function T_(_0x13ff24){_0x13ff24=k(_0x13ff24),_0x13ff24['_checkNotDeleted']('goOnline'),Sd(_0x13ff24['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x11d41d){Ll(ct),et(new Me('database',(_0x3917c5,{instanceIdentifier:_0x1e74dc})=>{const _0x366ec6=_0x3917c5['getProvider']('app')['getImmediate'](),_0x10ce43=_0x3917c5['getProvider']('auth-internal'),_0x24eced=_0x3917c5['getProvider']('app-check-internal');return qd(_0x366ec6,_0x10ce43,_0x24eced,_0x1e74dc);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x11d41d),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x298163,_0x8afad3){this['committed']=_0x298163,this['snapshot']=_0x8afad3;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x42a5b6,_0x3b6f1c,_0x5a51f3){if(_0x42a5b6=k(_0x42a5b6),gs('Reference.transaction',_0x42a5b6['_path']),_0x42a5b6['key']==='.length'||_0x42a5b6['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x42a5b6['key']+'\x20is\x20a\x20read-only\x20object.';const _0x855342=!0x0,_0x49bcbc=new Ve(),_0x195bd1=(_0x20e756,_0x5e1522,_0x208ece)=>{let _0x223364=null;_0x20e756?_0x49bcbc['reject'](_0x20e756):(_0x223364=new rt(_0x208ece,new Z(_0x42a5b6['_repo'],_0x42a5b6['_path']),R),_0x49bcbc['resolve'](new Xd(_0x5e1522,_0x223364)));},_0x548fe3=Fd(_0x42a5b6,()=>{});return bd(_0x42a5b6['_repo'],_0x42a5b6['_path'],_0x3b6f1c,_0x195bd1,_0x548fe3,_0x855342),_0x49bcbc['promise'];}ie['prototype']['simpleListen']=function(_0xe41670,_0x3dec27){this['sendRequest']('q',{'p':_0xe41670},_0x3dec27);},ie['prototype']['echo']=function(_0x2fab41,_0x5599a9){this['sendRequest']('echo',{'d':_0x2fab41},_0x5599a9);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1b5564,..._0x3ce043){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1b5564,..._0x3ce043);}function nn(_0x561783,..._0x474748){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x561783,..._0x474748);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x2aa235,..._0x29d6cf){throw Es(_0x2aa235,..._0x29d6cf);}function J(_0x40b844,..._0xa9b1d7){return Es(_0x40b844,..._0xa9b1d7);}function ya(_0x40453c,_0x317842,_0x332190){const _0x3acc76={...Zd(),[_0x317842]:_0x332190};return new Ut('auth','Firebase',_0x3acc76)['create'](_0x317842,{'appName':_0x40453c['name']});}function se(_0x341098){return ya(_0x341098,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5080c9,..._0x4c5309){if(typeof _0x5080c9!='string'){const _0x6cf2ef=_0x4c5309[0x0],_0x109e5f=[..._0x4c5309['slice'](0x1)];return _0x109e5f[0x0]&&(_0x109e5f[0x0]['appName']=_0x5080c9['name']),_0x5080c9['_errorFactory']['create'](_0x6cf2ef,..._0x109e5f);}return ma['create'](_0x5080c9,..._0x4c5309);}function m(_0x5e1f77,_0x16cc62,..._0x418393){if(!_0x5e1f77)throw Es(_0x16cc62,..._0x418393);}function te(_0x32dd9d){const _0x26f59b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x32dd9d;throw nn(_0x26f59b),new Error(_0x26f59b);}function ae(_0x5eb802,_0x3ecac8){_0x5eb802||te(_0x3ecac8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x2f5aa3;return typeof self<'u'&&((_0x2f5aa3=self['location'])==null?void 0x0:_0x2f5aa3['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4907f4;return typeof self<'u'&&((_0x4907f4=self['location'])==null?void 0x0:_0x4907f4['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x53e446=navigator;return _0x53e446['languages']&&_0x53e446['languages'][0x0]||_0x53e446['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1c4e38,_0x580678){this['shortDelay']=_0x1c4e38,this['longDelay']=_0x580678,ae(_0x580678>_0x1c4e38,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0xdc62aa,_0x316d41){ae(_0xdc62aa['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x578aa7}=_0xdc62aa['emulator'];return _0x316d41?''+_0x578aa7+(_0x316d41['startsWith']('/')?_0x316d41['slice'](0x1):_0x316d41):_0x578aa7;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x2a5d30,_0x35950e,_0x4aca90){this['fetchImpl']=_0x2a5d30,_0x35950e&&(this['headersImpl']=_0x35950e),_0x4aca90&&(this['responseImpl']=_0x4aca90);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x18c447,_0x46b41e){return _0x18c447['tenantId']&&!_0x46b41e['tenantId']?{..._0x46b41e,'tenantId':_0x18c447['tenantId']}:_0x46b41e;}async function Ae(_0x364265,_0x2e876c,_0x2e917f,_0x4fdeaa,_0xf95fc2={}){return Ea(_0x364265,_0xf95fc2,async()=>{let _0x13c448={},_0x27725b={};_0x4fdeaa&&(_0x2e876c==='GET'?_0x27725b=_0x4fdeaa:_0x13c448={'body':JSON['stringify'](_0x4fdeaa)});const _0xcd85b1=at({..._0x27725b,'key':_0x364265['config']['apiKey']})['slice'](0x1),_0x3718bb=await _0x364265['_getAdditionalHeaders']();_0x3718bb['Content-Type']='application/json',_0x364265['languageCode']&&(_0x3718bb['X-Firebase-Locale']=_0x364265['languageCode']);const _0x2140d9={'method':_0x2e876c,'headers':_0x3718bb,..._0x13c448};return lc()||(_0x2140d9['referrerPolicy']='strict-origin-when-cross-origin'),_0x364265['emulatorConfig']&&Wt(_0x364265['emulatorConfig']['host'])&&(_0x2140d9['credentials']='include'),va['fetch']()(await Ia(_0x364265,_0x364265['config']['apiHost'],_0x2e917f,_0xcd85b1),_0x2140d9);});}async function Ea(_0x3b8530,_0x2bd768,_0x2787f3){_0x3b8530['_canInitEmulator']=!0x1;const _0x2a35ef={...rf,..._0x2bd768};try{const _0x419472=new lf(_0x3b8530),_0x415786=await Promise['race']([_0x2787f3(),_0x419472['promise']]);_0x419472['clearNetworkTimeout']();const _0x5ccc55=await _0x415786['json']();if('needConfirmation'in _0x5ccc55)throw en(_0x3b8530,'account-exists-with-different-credential',_0x5ccc55);if(_0x415786['ok']&&!('errorMessage'in _0x5ccc55))return _0x5ccc55;{const _0x36179e=_0x415786['ok']?_0x5ccc55['errorMessage']:_0x5ccc55['error']['message'],[_0x165ab9,_0x3262c7]=_0x36179e['split']('\x20:\x20');if(_0x165ab9==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x3b8530,'credential-already-in-use',_0x5ccc55);if(_0x165ab9==='EMAIL_EXISTS')throw en(_0x3b8530,'email-already-in-use',_0x5ccc55);if(_0x165ab9==='USER_DISABLED')throw en(_0x3b8530,'user-disabled',_0x5ccc55);const _0x511ead=_0x2a35ef[_0x165ab9]||_0x165ab9['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3262c7)throw ya(_0x3b8530,_0x511ead,_0x3262c7);K(_0x3b8530,_0x511ead);}}catch(_0xf98f1e){if(_0xf98f1e instanceof Se)throw _0xf98f1e;K(_0x3b8530,'network-request-failed',{'message':String(_0xf98f1e)});}}async function Yt(_0x229a1d,_0x126d27,_0x4aacee,_0x46569a,_0xde4ce3={}){const _0x5a1f8a=await Ae(_0x229a1d,_0x126d27,_0x4aacee,_0x46569a,_0xde4ce3);return'mfaPendingCredential'in _0x5a1f8a&&K(_0x229a1d,'multi-factor-auth-required',{'_serverResponse':_0x5a1f8a}),_0x5a1f8a;}async function Ia(_0x2a0e81,_0x441f2e,_0x1f18b8,_0x1e6232){const _0x5c9c50=''+_0x441f2e+_0x1f18b8+'?'+_0x1e6232,_0x52e3e6=_0x2a0e81,_0x160af3=_0x52e3e6['config']['emulator']?Is(_0x2a0e81['config'],_0x5c9c50):_0x2a0e81['config']['apiScheme']+'://'+_0x5c9c50;return of['includes'](_0x1f18b8)&&(await _0x52e3e6['_persistenceManagerAvailable'],_0x52e3e6['_getPersistenceType']()==='COOKIE')?_0x52e3e6['_getPersistence']()['_getFinalTarget'](_0x160af3)['toString']():_0x160af3;}function cf(_0x2272fa){switch(_0x2272fa){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4743f0){this['auth']=_0x4743f0,this['timer']=null,this['promise']=new Promise((_0x442bec,_0x5dc5ab)=>{this['timer']=setTimeout(()=>_0x5dc5ab(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4b226e,_0x30334b,_0x3a2d0f){const _0x5438fa={'appName':_0x4b226e['name']};_0x3a2d0f['email']&&(_0x5438fa['email']=_0x3a2d0f['email']),_0x3a2d0f['phoneNumber']&&(_0x5438fa['phoneNumber']=_0x3a2d0f['phoneNumber']);const _0x7154f2=J(_0x4b226e,_0x30334b,_0x5438fa);return _0x7154f2['customData']['_tokenResponse']=_0x3a2d0f,_0x7154f2;}function vr(_0x4577ad){return _0x4577ad!==void 0x0&&_0x4577ad['enterprise']!==void 0x0;}class hf{constructor(_0x3642cc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3642cc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3642cc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3642cc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4a506a){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3365aa of this['recaptchaEnforcementState'])if(_0x3365aa['provider']&&_0x3365aa['provider']===_0x4a506a)return cf(_0x3365aa['enforcementState']);return null;}['isProviderEnabled'](_0x333976){return this['getProviderEnforcementState'](_0x333976)==='ENFORCE'||this['getProviderEnforcementState'](_0x333976)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x15c1e3,_0x3f3126){return Ae(_0x15c1e3,'GET','/v2/recaptchaConfig',Re(_0x15c1e3,_0x3f3126));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x2d7380,_0x5c29f9){return Ae(_0x2d7380,'POST','/v1/accounts:delete',_0x5c29f9);}async function Sn(_0x457765,_0x1d8fc1){return Ae(_0x457765,'POST','/v1/accounts:lookup',_0x1d8fc1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x95bb9f){if(_0x95bb9f)try{const _0x539c33=new Date(Number(_0x95bb9f));if(!isNaN(_0x539c33['getTime']()))return _0x539c33['toUTCString']();}catch{}}async function ff(_0x5a5025,_0x37f12f=!0x1){const _0x2f8708=k(_0x5a5025),_0x189598=await _0x2f8708['getIdToken'](_0x37f12f),_0x3a751b=ws(_0x189598);m(_0x3a751b&&_0x3a751b['exp']&&_0x3a751b['auth_time']&&_0x3a751b['iat'],_0x2f8708['auth'],'internal-error');const _0x4bc113=typeof _0x3a751b['firebase']=='object'?_0x3a751b['firebase']:void 0x0,_0x3294b9=_0x4bc113==null?void 0x0:_0x4bc113['sign_in_provider'];return{'claims':_0x3a751b,'token':_0x189598,'authTime':St(ci(_0x3a751b['auth_time'])),'issuedAtTime':St(ci(_0x3a751b['iat'])),'expirationTime':St(ci(_0x3a751b['exp'])),'signInProvider':_0x3294b9||null,'signInSecondFactor':(_0x4bc113==null?void 0x0:_0x4bc113['sign_in_second_factor'])||null};}function ci(_0x26cd71){return Number(_0x26cd71)*0x3e8;}function ws(_0x8f7be5){const [_0x42bef5,_0x1daf7e,_0x19fc40]=_0x8f7be5['split']('.');if(_0x42bef5===void 0x0||_0x1daf7e===void 0x0||_0x19fc40===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x575871=cn(_0x1daf7e);return _0x575871?JSON['parse'](_0x575871):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5bb488){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5bb488==null?void 0x0:_0x5bb488['toString']()),null;}}function Er(_0x268824){const _0x1369f3=ws(_0x268824);return m(_0x1369f3,'internal-error'),m(typeof _0x1369f3['exp']<'u','internal-error'),m(typeof _0x1369f3['iat']<'u','internal-error'),Number(_0x1369f3['exp'])-Number(_0x1369f3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x5f63bf,_0x112c37,_0x5032d0=!0x1){if(_0x5032d0)return _0x112c37;try{return await _0x112c37;}catch(_0x3059a8){throw _0x3059a8 instanceof Se&&pf(_0x3059a8)&&_0x5f63bf['auth']['currentUser']===_0x5f63bf&&await _0x5f63bf['auth']['signOut'](),_0x3059a8;}}function pf({code:_0x438aa0}){return _0x438aa0==='auth/user-disabled'||_0x438aa0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x15bff7){this['user']=_0x15bff7,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5bb9c4){if(_0x5bb9c4){const _0x391faa=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x391faa;}else{this['errorBackoff']=0x7530;const _0x5b3004=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5b3004);}}['schedule'](_0x141dd5=!0x1){if(!this['isRunning'])return;const _0x5509e5=this['getInterval'](_0x141dd5);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5509e5);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x16cad2){(_0x16cad2==null?void 0x0:_0x16cad2['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4c743a,_0x4b8e44){this['createdAt']=_0x4c743a,this['lastLoginAt']=_0x4b8e44,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x100db2){this['createdAt']=_0x100db2['createdAt'],this['lastLoginAt']=_0x100db2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x279f48){var _0x2a1142;const _0x24d0ca=_0x279f48['auth'],_0x28c1f9=await _0x279f48['getIdToken'](),_0x5b2dc6=await xt(_0x279f48,Sn(_0x24d0ca,{'idToken':_0x28c1f9}));m(_0x5b2dc6==null?void 0x0:_0x5b2dc6['users']['length'],_0x24d0ca,'internal-error');const _0x287b3a=_0x5b2dc6['users'][0x0];_0x279f48['_notifyReloadListener'](_0x287b3a);const _0x5f54a9=(_0x2a1142=_0x287b3a['providerUserInfo'])!=null&&_0x2a1142['length']?wa(_0x287b3a['providerUserInfo']):[],_0x380031=mf(_0x279f48['providerData'],_0x5f54a9),_0x5f520=_0x279f48['isAnonymous'],_0x2b99f6=!(_0x279f48['email']&&_0x287b3a['passwordHash'])&&!(_0x380031!=null&&_0x380031['length']),_0x4cd50=_0x5f520?_0x2b99f6:!0x1,_0x3b4eaf={'uid':_0x287b3a['localId'],'displayName':_0x287b3a['displayName']||null,'photoURL':_0x287b3a['photoUrl']||null,'email':_0x287b3a['email']||null,'emailVerified':_0x287b3a['emailVerified']||!0x1,'phoneNumber':_0x287b3a['phoneNumber']||null,'tenantId':_0x287b3a['tenantId']||null,'providerData':_0x380031,'metadata':new Pi(_0x287b3a['createdAt'],_0x287b3a['lastLoginAt']),'isAnonymous':_0x4cd50};Object['assign'](_0x279f48,_0x3b4eaf);}async function gf(_0x606ff0){const _0x5c9930=k(_0x606ff0);await bn(_0x5c9930),await _0x5c9930['auth']['_persistUserIfCurrent'](_0x5c9930),_0x5c9930['auth']['_notifyListenersIfCurrent'](_0x5c9930);}function mf(_0x531b1d,_0x218006){return[..._0x531b1d['filter'](_0x1b0066=>!_0x218006['some'](_0xf53e4d=>_0xf53e4d['providerId']===_0x1b0066['providerId'])),..._0x218006];}function wa(_0x401b8d){return _0x401b8d['map'](({providerId:_0x1277a8,..._0x23e16c})=>({'providerId':_0x1277a8,'uid':_0x23e16c['rawId']||'','displayName':_0x23e16c['displayName']||null,'email':_0x23e16c['email']||null,'phoneNumber':_0x23e16c['phoneNumber']||null,'photoURL':_0x23e16c['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x28255a,_0xaa2ffc){const _0x535e9b=await Ea(_0x28255a,{},async()=>{const _0x30f760=at({'grant_type':'refresh_token','refresh_token':_0xaa2ffc})['slice'](0x1),{tokenApiHost:_0x2f3688,apiKey:_0x123944}=_0x28255a['config'],_0x4356b9=await Ia(_0x28255a,_0x2f3688,'/v1/token','key='+_0x123944),_0x3ec470=await _0x28255a['_getAdditionalHeaders']();_0x3ec470['Content-Type']='application/x-www-form-urlencoded';const _0x1f0d4f={'method':'POST','headers':_0x3ec470,'body':_0x30f760};return _0x28255a['emulatorConfig']&&Wt(_0x28255a['emulatorConfig']['host'])&&(_0x1f0d4f['credentials']='include'),va['fetch']()(_0x4356b9,_0x1f0d4f);});return{'accessToken':_0x535e9b['access_token'],'expiresIn':_0x535e9b['expires_in'],'refreshToken':_0x535e9b['refresh_token']};}async function vf(_0x4ac6df,_0x47ba5b){return Ae(_0x4ac6df,'POST','/v2/accounts:revokeToken',Re(_0x4ac6df,_0x47ba5b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x15cb95){m(_0x15cb95['idToken'],'internal-error'),m(typeof _0x15cb95['idToken']<'u','internal-error'),m(typeof _0x15cb95['refreshToken']<'u','internal-error');const _0x9486d9='expiresIn'in _0x15cb95&&typeof _0x15cb95['expiresIn']<'u'?Number(_0x15cb95['expiresIn']):Er(_0x15cb95['idToken']);this['updateTokensAndExpiration'](_0x15cb95['idToken'],_0x15cb95['refreshToken'],_0x9486d9);}['updateFromIdToken'](_0x34148f){m(_0x34148f['length']!==0x0,'internal-error');const _0x2bd9b1=Er(_0x34148f);this['updateTokensAndExpiration'](_0x34148f,null,_0x2bd9b1);}async['getToken'](_0x2bde08,_0x3fc08f=!0x1){return!_0x3fc08f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2bde08,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2bde08,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2bd8e3,_0x4371e7){const {accessToken:_0x129ff7,refreshToken:_0x516a61,expiresIn:_0x182b01}=await yf(_0x2bd8e3,_0x4371e7);this['updateTokensAndExpiration'](_0x129ff7,_0x516a61,Number(_0x182b01));}['updateTokensAndExpiration'](_0x4cd35e,_0xa29e06,_0x4f2464){this['refreshToken']=_0xa29e06||null,this['accessToken']=_0x4cd35e||null,this['expirationTime']=Date['now']()+_0x4f2464*0x3e8;}static['fromJSON'](_0x130c50,_0xe6da98){const {refreshToken:_0x5e7da2,accessToken:_0x584c96,expirationTime:_0x5a37dd}=_0xe6da98,_0xc127b4=new Je();return _0x5e7da2&&(m(typeof _0x5e7da2=='string','internal-error',{'appName':_0x130c50}),_0xc127b4['refreshToken']=_0x5e7da2),_0x584c96&&(m(typeof _0x584c96=='string','internal-error',{'appName':_0x130c50}),_0xc127b4['accessToken']=_0x584c96),_0x5a37dd&&(m(typeof _0x5a37dd=='number','internal-error',{'appName':_0x130c50}),_0xc127b4['expirationTime']=_0x5a37dd),_0xc127b4;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4213fb){this['accessToken']=_0x4213fb['accessToken'],this['refreshToken']=_0x4213fb['refreshToken'],this['expirationTime']=_0x4213fb['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x3ea867,_0x1fa541){m(typeof _0x3ea867=='string'||typeof _0x3ea867>'u','internal-error',{'appName':_0x1fa541});}class z{constructor({uid:_0x300402,auth:_0x126168,stsTokenManager:_0x44908e,..._0x389670}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x300402,this['auth']=_0x126168,this['stsTokenManager']=_0x44908e,this['accessToken']=_0x44908e['accessToken'],this['displayName']=_0x389670['displayName']||null,this['email']=_0x389670['email']||null,this['emailVerified']=_0x389670['emailVerified']||!0x1,this['phoneNumber']=_0x389670['phoneNumber']||null,this['photoURL']=_0x389670['photoURL']||null,this['isAnonymous']=_0x389670['isAnonymous']||!0x1,this['tenantId']=_0x389670['tenantId']||null,this['providerData']=_0x389670['providerData']?[..._0x389670['providerData']]:[],this['metadata']=new Pi(_0x389670['createdAt']||void 0x0,_0x389670['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4b8db1){const _0x24a8a7=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4b8db1));return m(_0x24a8a7,this['auth'],'internal-error'),this['accessToken']!==_0x24a8a7&&(this['accessToken']=_0x24a8a7,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x24a8a7;}['getIdTokenResult'](_0x4ddd09){return ff(this,_0x4ddd09);}['reload'](){return gf(this);}['_assign'](_0x3a524e){this!==_0x3a524e&&(m(this['uid']===_0x3a524e['uid'],this['auth'],'internal-error'),this['displayName']=_0x3a524e['displayName'],this['photoURL']=_0x3a524e['photoURL'],this['email']=_0x3a524e['email'],this['emailVerified']=_0x3a524e['emailVerified'],this['phoneNumber']=_0x3a524e['phoneNumber'],this['isAnonymous']=_0x3a524e['isAnonymous'],this['tenantId']=_0x3a524e['tenantId'],this['providerData']=_0x3a524e['providerData']['map'](_0x26c6a7=>({..._0x26c6a7})),this['metadata']['_copy'](_0x3a524e['metadata']),this['stsTokenManager']['_assign'](_0x3a524e['stsTokenManager']));}['_clone'](_0x5cd11e){const _0xd3b077=new z({...this,'auth':_0x5cd11e,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xd3b077['metadata']['_copy'](this['metadata']),_0xd3b077;}['_onReload'](_0x564cfe){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x564cfe,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1b305c){this['reloadListener']?this['reloadListener'](_0x1b305c):this['reloadUserInfo']=_0x1b305c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2ada08,_0x1b9f1f=!0x1){let _0x1d3a1c=!0x1;_0x2ada08['idToken']&&_0x2ada08['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2ada08),_0x1d3a1c=!0x0),_0x1b9f1f&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1d3a1c&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0xbabf91=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0xbabf91})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x39ec25=>({..._0x39ec25})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x983426,_0x113cea){const _0x2a1958=_0x113cea['displayName']??void 0x0,_0x529f9f=_0x113cea['email']??void 0x0,_0x4b7e92=_0x113cea['phoneNumber']??void 0x0,_0x25e680=_0x113cea['photoURL']??void 0x0,_0x5d1384=_0x113cea['tenantId']??void 0x0,_0x4621de=_0x113cea['_redirectEventId']??void 0x0,_0x3019b3=_0x113cea['createdAt']??void 0x0,_0x229a20=_0x113cea['lastLoginAt']??void 0x0,{uid:_0x3f2972,emailVerified:_0x4117f5,isAnonymous:_0x9680ef,providerData:_0x25545e,stsTokenManager:_0x183ce2}=_0x113cea;m(_0x3f2972&&_0x183ce2,_0x983426,'internal-error');const _0x1640b3=Je['fromJSON'](this['name'],_0x183ce2);m(typeof _0x3f2972=='string',_0x983426,'internal-error'),ce(_0x2a1958,_0x983426['name']),ce(_0x529f9f,_0x983426['name']),m(typeof _0x4117f5=='boolean',_0x983426,'internal-error'),m(typeof _0x9680ef=='boolean',_0x983426,'internal-error'),ce(_0x4b7e92,_0x983426['name']),ce(_0x25e680,_0x983426['name']),ce(_0x5d1384,_0x983426['name']),ce(_0x4621de,_0x983426['name']),ce(_0x3019b3,_0x983426['name']),ce(_0x229a20,_0x983426['name']);const _0x4c3c0a=new z({'uid':_0x3f2972,'auth':_0x983426,'email':_0x529f9f,'emailVerified':_0x4117f5,'displayName':_0x2a1958,'isAnonymous':_0x9680ef,'photoURL':_0x25e680,'phoneNumber':_0x4b7e92,'tenantId':_0x5d1384,'stsTokenManager':_0x1640b3,'createdAt':_0x3019b3,'lastLoginAt':_0x229a20});return _0x25545e&&Array['isArray'](_0x25545e)&&(_0x4c3c0a['providerData']=_0x25545e['map'](_0x5ca40c=>({..._0x5ca40c}))),_0x4621de&&(_0x4c3c0a['_redirectEventId']=_0x4621de),_0x4c3c0a;}static async['_fromIdTokenResponse'](_0x15e68a,_0x25fa11,_0x121dfe=!0x1){const _0x57f366=new Je();_0x57f366['updateFromServerResponse'](_0x25fa11);const _0x5554a8=new z({'uid':_0x25fa11['localId'],'auth':_0x15e68a,'stsTokenManager':_0x57f366,'isAnonymous':_0x121dfe});return await bn(_0x5554a8),_0x5554a8;}static async['_fromGetAccountInfoResponse'](_0x15327c,_0x18817f,_0x22577d){const _0x9ebf52=_0x18817f['users'][0x0];m(_0x9ebf52['localId']!==void 0x0,'internal-error');const _0x525c6e=_0x9ebf52['providerUserInfo']!==void 0x0?wa(_0x9ebf52['providerUserInfo']):[],_0x298fd8=!(_0x9ebf52['email']&&_0x9ebf52['passwordHash'])&&!(_0x525c6e!=null&&_0x525c6e['length']),_0x44520e=new Je();_0x44520e['updateFromIdToken'](_0x22577d);const _0x10358e=new z({'uid':_0x9ebf52['localId'],'auth':_0x15327c,'stsTokenManager':_0x44520e,'isAnonymous':_0x298fd8}),_0x66f8f4={'uid':_0x9ebf52['localId'],'displayName':_0x9ebf52['displayName']||null,'photoURL':_0x9ebf52['photoUrl']||null,'email':_0x9ebf52['email']||null,'emailVerified':_0x9ebf52['emailVerified']||!0x1,'phoneNumber':_0x9ebf52['phoneNumber']||null,'tenantId':_0x9ebf52['tenantId']||null,'providerData':_0x525c6e,'metadata':new Pi(_0x9ebf52['createdAt'],_0x9ebf52['lastLoginAt']),'isAnonymous':!(_0x9ebf52['email']&&_0x9ebf52['passwordHash'])&&!(_0x525c6e!=null&&_0x525c6e['length'])};return Object['assign'](_0x10358e,_0x66f8f4),_0x10358e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x149762){ae(_0x149762 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1ce633=Ir['get'](_0x149762);return _0x1ce633?(ae(_0x1ce633 instanceof _0x149762,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1ce633):(_0x1ce633=new _0x149762(),Ir['set'](_0x149762,_0x1ce633),_0x1ce633);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x34bc38,_0x12bfcc){this['storage'][_0x34bc38]=_0x12bfcc;}async['_get'](_0x2f137b){const _0x367238=this['storage'][_0x2f137b];return _0x367238===void 0x0?null:_0x367238;}async['_remove'](_0x4a856a){delete this['storage'][_0x4a856a];}['_addListener'](_0x45f718,_0x38912f){}['_removeListener'](_0x1b5a0b,_0x1c0635){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x5a0b0b,_0x1d0f3b,_0x5e0f8a){return'firebase:'+_0x5a0b0b+':'+_0x1d0f3b+':'+_0x5e0f8a;}class Xe{constructor(_0x5a0437,_0x5daabb,_0x13d367){this['persistence']=_0x5a0437,this['auth']=_0x5daabb,this['userKey']=_0x13d367;const {config:_0x3a1d9d,name:_0x481c07}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3a1d9d['apiKey'],_0x481c07),this['fullPersistenceKey']=sn('persistence',_0x3a1d9d['apiKey'],_0x481c07),this['boundEventHandler']=_0x5daabb['_onStorageEvent']['bind'](_0x5daabb),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x265e4f){return this['persistence']['_set'](this['fullUserKey'],_0x265e4f['toJSON']());}async['getCurrentUser'](){const _0x13d5fb=await this['persistence']['_get'](this['fullUserKey']);if(!_0x13d5fb)return null;if(typeof _0x13d5fb=='string'){const _0x20ac55=await Sn(this['auth'],{'idToken':_0x13d5fb})['catch'](()=>{});return _0x20ac55?z['_fromGetAccountInfoResponse'](this['auth'],_0x20ac55,_0x13d5fb):null;}return z['_fromJSON'](this['auth'],_0x13d5fb);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0xca1e31){if(this['persistence']===_0xca1e31)return;const _0x41fa3e=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0xca1e31,_0x41fa3e)return this['setCurrentUser'](_0x41fa3e);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xa1ac9e,_0x12696a,_0x2297b0='authUser'){if(!_0x12696a['length'])return new Xe(ne(wr),_0xa1ac9e,_0x2297b0);const _0x494ad5=(await Promise['all'](_0x12696a['map'](async _0x4f0f9e=>{if(await _0x4f0f9e['_isAvailable']())return _0x4f0f9e;})))['filter'](_0x4a455b=>_0x4a455b);let _0x2d8f0d=_0x494ad5[0x0]||ne(wr);const _0x19c8e9=sn(_0x2297b0,_0xa1ac9e['config']['apiKey'],_0xa1ac9e['name']);let _0x469ab2=null;for(const _0x83bd86 of _0x12696a)try{const _0x459f29=await _0x83bd86['_get'](_0x19c8e9);if(_0x459f29){let _0x4d1e05;if(typeof _0x459f29=='string'){const _0x2d8ec7=await Sn(_0xa1ac9e,{'idToken':_0x459f29})['catch'](()=>{});if(!_0x2d8ec7)break;_0x4d1e05=await z['_fromGetAccountInfoResponse'](_0xa1ac9e,_0x2d8ec7,_0x459f29);}else _0x4d1e05=z['_fromJSON'](_0xa1ac9e,_0x459f29);_0x83bd86!==_0x2d8f0d&&(_0x469ab2=_0x4d1e05),_0x2d8f0d=_0x83bd86;break;}}catch{}const _0x1e0f62=_0x494ad5['filter'](_0x5088a8=>_0x5088a8['_shouldAllowMigration']);return!_0x2d8f0d['_shouldAllowMigration']||!_0x1e0f62['length']?new Xe(_0x2d8f0d,_0xa1ac9e,_0x2297b0):(_0x2d8f0d=_0x1e0f62[0x0],_0x469ab2&&await _0x2d8f0d['_set'](_0x19c8e9,_0x469ab2['toJSON']()),await Promise['all'](_0x12696a['map'](async _0x3c3db2=>{if(_0x3c3db2!==_0x2d8f0d)try{await _0x3c3db2['_remove'](_0x19c8e9);}catch{}})),new Xe(_0x2d8f0d,_0xa1ac9e,_0x2297b0));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x1626d7){const _0x111324=_0x1626d7['toLowerCase']();if(_0x111324['includes']('opera/')||_0x111324['includes']('opr/')||_0x111324['includes']('opios/'))return'Opera';if(Ra(_0x111324))return'IEMobile';if(_0x111324['includes']('msie')||_0x111324['includes']('trident/'))return'IE';if(_0x111324['includes']('edge/'))return'Edge';if(Ta(_0x111324))return'Firefox';if(_0x111324['includes']('silk/'))return'Silk';if(ka(_0x111324))return'Blackberry';if(Na(_0x111324))return'Webos';if(Sa(_0x111324))return'Safari';if((_0x111324['includes']('chrome/')||ba(_0x111324))&&!_0x111324['includes']('edge/'))return'Chrome';if(Aa(_0x111324))return'Android';{const _0x16620c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x56b550=_0x1626d7['match'](_0x16620c);if((_0x56b550==null?void 0x0:_0x56b550['length'])===0x2)return _0x56b550[0x1];}return'Other';}function Ta(_0x100674=W()){return/firefox\//i['test'](_0x100674);}function Sa(_0x48b3d3=W()){const _0x12df14=_0x48b3d3['toLowerCase']();return _0x12df14['includes']('safari/')&&!_0x12df14['includes']('chrome/')&&!_0x12df14['includes']('crios/')&&!_0x12df14['includes']('android');}function ba(_0x5cb22e=W()){return/crios\//i['test'](_0x5cb22e);}function Ra(_0x3c2791=W()){return/iemobile/i['test'](_0x3c2791);}function Aa(_0x4c4f61=W()){return/android/i['test'](_0x4c4f61);}function ka(_0x2a563f=W()){return/blackberry/i['test'](_0x2a563f);}function Na(_0x42e07e=W()){return/webos/i['test'](_0x42e07e);}function Cs(_0x2d91f5=W()){return/iphone|ipad|ipod/i['test'](_0x2d91f5)||/macintosh/i['test'](_0x2d91f5)&&/mobile/i['test'](_0x2d91f5);}function Ef(_0x1d8644=W()){var _0x4b5c1a;return Cs(_0x1d8644)&&!!((_0x4b5c1a=window['navigator'])!=null&&_0x4b5c1a['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5351d4=W()){return Cs(_0x5351d4)||Aa(_0x5351d4)||Na(_0x5351d4)||ka(_0x5351d4)||/windows phone/i['test'](_0x5351d4)||Ra(_0x5351d4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x1bd472,_0x34e81c=[]){let _0x34d4f6;switch(_0x1bd472){case'Browser':_0x34d4f6=Cr(W());break;case'Worker':_0x34d4f6=Cr(W())+'-'+_0x1bd472;break;default:_0x34d4f6=_0x1bd472;}const _0x1ca30f=_0x34e81c['length']?_0x34e81c['join'](','):'FirebaseCore-web';return _0x34d4f6+'/JsCore/'+ct+'/'+_0x1ca30f;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2be64a){this['auth']=_0x2be64a,this['queue']=[];}['pushCallback'](_0x5e0b05,_0x52f0c0){const _0x2d2c9b=_0x15180f=>new Promise((_0x248c06,_0x20c552)=>{try{const _0x3c5007=_0x5e0b05(_0x15180f);_0x248c06(_0x3c5007);}catch(_0x1b3fc8){_0x20c552(_0x1b3fc8);}});_0x2d2c9b['onAbort']=_0x52f0c0,this['queue']['push'](_0x2d2c9b);const _0x3e6ec6=this['queue']['length']-0x1;return()=>{this['queue'][_0x3e6ec6]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3842bd){if(this['auth']['currentUser']===_0x3842bd)return;const _0x116704=[];try{for(const _0x4e4b76 of this['queue'])await _0x4e4b76(_0x3842bd),_0x4e4b76['onAbort']&&_0x116704['push'](_0x4e4b76['onAbort']);}catch(_0x4a706d){_0x116704['reverse']();for(const _0x918fa2 of _0x116704)try{_0x918fa2();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4a706d==null?void 0x0:_0x4a706d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x493e07,_0x2deb2e={}){return Ae(_0x493e07,'GET','/v2/passwordPolicy',Re(_0x493e07,_0x2deb2e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x40d95e){var _0x4b06a5;const _0x5d1a7b=_0x40d95e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5d1a7b['minPasswordLength']??Tf,_0x5d1a7b['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5d1a7b['maxPasswordLength']),_0x5d1a7b['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5d1a7b['containsLowercaseCharacter']),_0x5d1a7b['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5d1a7b['containsUppercaseCharacter']),_0x5d1a7b['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5d1a7b['containsNumericCharacter']),_0x5d1a7b['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5d1a7b['containsNonAlphanumericCharacter']),this['enforcementState']=_0x40d95e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4b06a5=_0x40d95e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4b06a5['join'](''))??'',this['forceUpgradeOnSignin']=_0x40d95e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x40d95e['schemaVersion'];}['validatePassword'](_0x7e0402){const _0x301d32={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x7e0402,_0x301d32),this['validatePasswordCharacterOptions'](_0x7e0402,_0x301d32),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['meetsMinPasswordLength']??!0x0),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['meetsMaxPasswordLength']??!0x0),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['containsLowercaseLetter']??!0x0),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['containsUppercaseLetter']??!0x0),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['containsNumericCharacter']??!0x0),_0x301d32['isValid']&&(_0x301d32['isValid']=_0x301d32['containsNonAlphanumericCharacter']??!0x0),_0x301d32;}['validatePasswordLengthOptions'](_0x105744,_0x18aa6f){const _0x40a25c=this['customStrengthOptions']['minPasswordLength'],_0x2c1a32=this['customStrengthOptions']['maxPasswordLength'];_0x40a25c&&(_0x18aa6f['meetsMinPasswordLength']=_0x105744['length']>=_0x40a25c),_0x2c1a32&&(_0x18aa6f['meetsMaxPasswordLength']=_0x105744['length']<=_0x2c1a32);}['validatePasswordCharacterOptions'](_0x118726,_0x3c9ced){this['updatePasswordCharacterOptionsStatuses'](_0x3c9ced,!0x1,!0x1,!0x1,!0x1);let _0x14f39e;for(let _0x41960a=0x0;_0x41960a<_0x118726['length'];_0x41960a++)_0x14f39e=_0x118726['charAt'](_0x41960a),this['updatePasswordCharacterOptionsStatuses'](_0x3c9ced,_0x14f39e>='a'&&_0x14f39e<='z',_0x14f39e>='A'&&_0x14f39e<='Z',_0x14f39e>='0'&&_0x14f39e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x14f39e));}['updatePasswordCharacterOptionsStatuses'](_0x2d5035,_0x3d33b0,_0x108b82,_0x3ddff7,_0x58a5bb){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2d5035['containsLowercaseLetter']||(_0x2d5035['containsLowercaseLetter']=_0x3d33b0)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2d5035['containsUppercaseLetter']||(_0x2d5035['containsUppercaseLetter']=_0x108b82)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2d5035['containsNumericCharacter']||(_0x2d5035['containsNumericCharacter']=_0x3ddff7)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2d5035['containsNonAlphanumericCharacter']||(_0x2d5035['containsNonAlphanumericCharacter']=_0x58a5bb));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0xbb4b14,_0x4e2180,_0x4792e2,_0x514e2e){this['app']=_0xbb4b14,this['heartbeatServiceProvider']=_0x4e2180,this['appCheckServiceProvider']=_0x4792e2,this['config']=_0x514e2e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xbb4b14['name'],this['clientVersion']=_0x514e2e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1be105=>this['_resolvePersistenceManagerAvailable']=_0x1be105);}['_initializeWithPersistence'](_0x2a7a3f,_0x1f57da){return _0x1f57da&&(this['_popupRedirectResolver']=ne(_0x1f57da)),this['_initializationPromise']=this['queue'](async()=>{var _0x4255fc,_0x325603,_0x1c9d2a;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x2a7a3f),(_0x4255fc=this['_resolvePersistenceManagerAvailable'])==null||_0x4255fc['call'](this),!this['_deleted'])){if((_0x325603=this['_popupRedirectResolver'])!=null&&_0x325603['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1f57da),this['lastNotifiedUid']=((_0x1c9d2a=this['currentUser'])==null?void 0x0:_0x1c9d2a['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x32036a=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x32036a)){if(this['currentUser']&&_0x32036a&&this['currentUser']['uid']===_0x32036a['uid']){this['_currentUser']['_assign'](_0x32036a),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x32036a,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1938a7){try{const _0x93edda=await Sn(this,{'idToken':_0x1938a7}),_0x715531=await z['_fromGetAccountInfoResponse'](this,_0x93edda,_0x1938a7);await this['directlySetCurrentUser'](_0x715531);}catch(_0x8e3a67){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x8e3a67),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1a681b){var _0x38ad23;if(H(this['app'])){const _0x2c2acc=this['app']['settings']['authIdToken'];return _0x2c2acc?new Promise(_0x49fbfe=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2c2acc)['then'](_0x49fbfe,_0x49fbfe));}):this['directlySetCurrentUser'](null);}const _0x10cf25=await this['assertedPersistence']['getCurrentUser']();let _0xac604c=_0x10cf25,_0x3ec253=!0x1;if(_0x1a681b&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3e5cc9=(_0x38ad23=this['redirectUser'])==null?void 0x0:_0x38ad23['_redirectEventId'],_0x8cde3=_0xac604c==null?void 0x0:_0xac604c['_redirectEventId'],_0x2c3f2a=await this['tryRedirectSignIn'](_0x1a681b);(!_0x3e5cc9||_0x3e5cc9===_0x8cde3)&&(_0x2c3f2a!=null&&_0x2c3f2a['user'])&&(_0xac604c=_0x2c3f2a['user'],_0x3ec253=!0x0);}if(!_0xac604c)return this['directlySetCurrentUser'](null);if(!_0xac604c['_redirectEventId']){if(_0x3ec253)try{await this['beforeStateQueue']['runMiddleware'](_0xac604c);}catch(_0x588161){_0xac604c=_0x10cf25,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x588161));}return _0xac604c?this['reloadAndSetCurrentUserOrClear'](_0xac604c):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0xac604c['_redirectEventId']?this['directlySetCurrentUser'](_0xac604c):this['reloadAndSetCurrentUserOrClear'](_0xac604c);}async['tryRedirectSignIn'](_0x693e4e){let _0x4aed72=null;try{_0x4aed72=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x693e4e,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4aed72;}async['reloadAndSetCurrentUserOrClear'](_0xe1cc00){try{await bn(_0xe1cc00);}catch(_0x4984f6){if((_0x4984f6==null?void 0x0:_0x4984f6['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0xe1cc00);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x27c4cd){if(H(this['app']))return Promise['reject'](se(this));const _0xd30b10=_0x27c4cd?k(_0x27c4cd):null;return _0xd30b10&&m(_0xd30b10['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xd30b10&&_0xd30b10['_clone'](this));}async['_updateCurrentUser'](_0x381879,_0x54ccd6=!0x1){if(!this['_deleted'])return _0x381879&&m(this['tenantId']===_0x381879['tenantId'],this,'tenant-id-mismatch'),_0x54ccd6||await this['beforeStateQueue']['runMiddleware'](_0x381879),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x381879),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2fa282){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x2fa282));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x442c5c){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4b6cfb=this['_getPasswordPolicyInternal']();return _0x4b6cfb['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4b6cfb['validatePassword'](_0x442c5c);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x489bed=await Cf(this),_0x44c0e5=new Sf(_0x489bed);this['tenantId']===null?this['_projectPasswordPolicy']=_0x44c0e5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x44c0e5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x18735a){this['_errorFactory']=new Ut('auth','Firebase',_0x18735a());}['onAuthStateChanged'](_0x28df0f,_0x2ded85,_0x2084f8){return this['registerStateListener'](this['authStateSubscription'],_0x28df0f,_0x2ded85,_0x2084f8);}['beforeAuthStateChanged'](_0x5299d6,_0x4154a9){return this['beforeStateQueue']['pushCallback'](_0x5299d6,_0x4154a9);}['onIdTokenChanged'](_0x4f1248,_0x23ac61,_0x24ad69){return this['registerStateListener'](this['idTokenSubscription'],_0x4f1248,_0x23ac61,_0x24ad69);}['authStateReady'](){return new Promise((_0x4ce075,_0x1221d2)=>{if(this['currentUser'])_0x4ce075();else{const _0x1b69bc=this['onAuthStateChanged'](()=>{_0x1b69bc(),_0x4ce075();},_0x1221d2);}});}async['revokeAccessToken'](_0x40a320){if(this['currentUser']){const _0x958b8c=await this['currentUser']['getIdToken'](),_0x51556a={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x40a320,'idToken':_0x958b8c};this['tenantId']!=null&&(_0x51556a['tenantId']=this['tenantId']),await vf(this,_0x51556a);}}['toJSON'](){var _0xae01ae;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xae01ae=this['_currentUser'])==null?void 0x0:_0xae01ae['toJSON']()};}async['_setRedirectUser'](_0x4dbf0d,_0x554c7b){const _0x46735a=await this['getOrInitRedirectPersistenceManager'](_0x554c7b);return _0x4dbf0d===null?_0x46735a['removeCurrentUser']():_0x46735a['setCurrentUser'](_0x4dbf0d);}async['getOrInitRedirectPersistenceManager'](_0x1e7752){if(!this['redirectPersistenceManager']){const _0x111755=_0x1e7752&&ne(_0x1e7752)||this['_popupRedirectResolver'];m(_0x111755,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x111755['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x57e661){var _0x52d4e8,_0x2dffef;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x52d4e8=this['_currentUser'])==null?void 0x0:_0x52d4e8['_redirectEventId'])===_0x57e661?this['_currentUser']:((_0x2dffef=this['redirectUser'])==null?void 0x0:_0x2dffef['_redirectEventId'])===_0x57e661?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x23521c){if(_0x23521c===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x23521c));}['_notifyListenersIfCurrent'](_0x301c0a){_0x301c0a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x37cab8;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x232f66=((_0x37cab8=this['currentUser'])==null?void 0x0:_0x37cab8['uid'])??null;this['lastNotifiedUid']!==_0x232f66&&(this['lastNotifiedUid']=_0x232f66,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x25463d,_0x4e3e07,_0x5475a8,_0x52a8b2){if(this['_deleted'])return()=>{};const _0x950d48=typeof _0x4e3e07=='function'?_0x4e3e07:_0x4e3e07['next']['bind'](_0x4e3e07);let _0x14d619=!0x1;const _0x3fbb1e=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3fbb1e,this,'internal-error'),_0x3fbb1e['then'](()=>{_0x14d619||_0x950d48(this['currentUser']);}),typeof _0x4e3e07=='function'){const _0x5f263c=_0x25463d['addObserver'](_0x4e3e07,_0x5475a8,_0x52a8b2);return()=>{_0x14d619=!0x0,_0x5f263c();};}else{const _0x237c2b=_0x25463d['addObserver'](_0x4e3e07);return()=>{_0x14d619=!0x0,_0x237c2b();};}}async['directlySetCurrentUser'](_0x410207){this['currentUser']&&this['currentUser']!==_0x410207&&this['_currentUser']['_stopProactiveRefresh'](),_0x410207&&this['isProactiveRefreshEnabled']&&_0x410207['_startProactiveRefresh'](),this['currentUser']=_0x410207,_0x410207?await this['assertedPersistence']['setCurrentUser'](_0x410207):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x16e41a){return this['operations']=this['operations']['then'](_0x16e41a,_0x16e41a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0xc2c079){!_0xc2c079||this['frameworks']['includes'](_0xc2c079)||(this['frameworks']['push'](_0xc2c079),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1bdfa4;const _0x23ab65={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x23ab65['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1e0cf2=await((_0x1bdfa4=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1bdfa4['getHeartbeatsHeader']());_0x1e0cf2&&(_0x23ab65['X-Firebase-Client']=_0x1e0cf2);const _0x3c632c=await this['_getAppCheckToken']();return _0x3c632c&&(_0x23ab65['X-Firebase-AppCheck']=_0x3c632c),_0x23ab65;}async['_getAppCheckToken'](){var _0x126f0f;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x30c984=await((_0x126f0f=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x126f0f['getToken']());return _0x30c984!=null&&_0x30c984['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x30c984['error']),_0x30c984==null?void 0x0:_0x30c984['token'];}}function qe(_0x15cd7d){return k(_0x15cd7d);}class Tr{constructor(_0x21eef5){this['auth']=_0x21eef5,this['observer']=null,this['addObserver']=Ic(_0xb2e252=>this['observer']=_0xb2e252);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x5836b5){zn=_0x5836b5;}function Da(_0xc99c4b){return zn['loadJS'](_0xc99c4b);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x25e2b5){return'__'+_0x25e2b5+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xd42373){_0xd42373();}['execute'](_0x53342f,_0x9ab268){return Promise['resolve']('token');}['render'](_0x440871,_0x190622){return'';}}class Of{['ready'](_0x518756){_0x518756();}['execute'](_0x1e6cb3,_0x5af17a){return Promise['resolve']('token');}['render'](_0x22d579,_0x1a233d){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x554a30){this['type']=Df,this['auth']=qe(_0x554a30);}async['verify'](_0x30dad1='verify',_0x55e87e=!0x1){async function _0x1137f5(_0x4b5c37){if(!_0x55e87e){if(_0x4b5c37['tenantId']==null&&_0x4b5c37['_agentRecaptchaConfig']!=null)return _0x4b5c37['_agentRecaptchaConfig']['siteKey'];if(_0x4b5c37['tenantId']!=null&&_0x4b5c37['_tenantRecaptchaConfigs'][_0x4b5c37['tenantId']]!==void 0x0)return _0x4b5c37['_tenantRecaptchaConfigs'][_0x4b5c37['tenantId']]['siteKey'];}return new Promise(async(_0x269667,_0x549505)=>{uf(_0x4b5c37,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1b1798=>{if(_0x1b1798['recaptchaKey']===void 0x0)_0x549505(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4b0e85=new hf(_0x1b1798);return _0x4b5c37['tenantId']==null?_0x4b5c37['_agentRecaptchaConfig']=_0x4b0e85:_0x4b5c37['_tenantRecaptchaConfigs'][_0x4b5c37['tenantId']]=_0x4b0e85,_0x269667(_0x4b0e85['siteKey']);}})['catch'](_0x38023d=>{_0x549505(_0x38023d);});});}function _0x129e3c(_0x3abb37,_0x168809,_0x21cf39){const _0x12f1f1=window['grecaptcha'];vr(_0x12f1f1)?_0x12f1f1['enterprise']['ready'](()=>{_0x12f1f1['enterprise']['execute'](_0x3abb37,{'action':_0x30dad1})['then'](_0x4f94fa=>{_0x168809(_0x4f94fa);})['catch'](()=>{_0x168809(Ma);});}):_0x21cf39(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x111cbc,_0x1abbe1)=>{_0x1137f5(this['auth'])['then'](async _0x1c1bb1=>{if(!_0x55e87e&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x129e3c(_0x1c1bb1,_0x111cbc,_0x1abbe1);else{if(typeof window>'u'){_0x1abbe1(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1a7e09=Af();_0x1a7e09['length']!==0x0&&(_0x1a7e09+=_0x1c1bb1+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x2cae6f;(_0x2cae6f=le['scriptInjectionDeferred'])==null||_0x2cae6f['resolve']();},Da(_0x1a7e09)['then'](()=>{var _0x5bca82;return(_0x5bca82=le['scriptInjectionDeferred'])==null?void 0x0:_0x5bca82['promise'];})['then'](()=>{_0x129e3c(_0x1c1bb1,_0x111cbc,_0x1abbe1);})['catch'](_0x38267b=>{_0x1abbe1(_0x38267b);});}})['catch'](_0x2cc6a4=>{_0x1abbe1(_0x2cc6a4);});});}}le['scriptInjectionDeferred']=null;async function br(_0x56a4ac,_0x12c4dd,_0x3611e2,_0x11fdbb=!0x1,_0x1d6c52=!0x1){const _0x477381=new le(_0x56a4ac);let _0x1818fc;if(_0x1d6c52)_0x1818fc=Ma;else try{_0x1818fc=await _0x477381['verify'](_0x3611e2);}catch{_0x1818fc=await _0x477381['verify'](_0x3611e2,!0x0);}const _0x27b07f={..._0x12c4dd};if(_0x3611e2==='mfaSmsEnrollment'||_0x3611e2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x27b07f){const _0x5988f6=_0x27b07f['phoneEnrollmentInfo']['phoneNumber'],_0xfa3fdd=_0x27b07f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x27b07f,{'phoneEnrollmentInfo':{'phoneNumber':_0x5988f6,'recaptchaToken':_0xfa3fdd,'captchaResponse':_0x1818fc,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x27b07f){const _0x3f96fb=_0x27b07f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x27b07f,{'phoneSignInInfo':{'recaptchaToken':_0x3f96fb,'captchaResponse':_0x1818fc,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x27b07f;}return _0x11fdbb?Object['assign'](_0x27b07f,{'captchaResp':_0x1818fc}):Object['assign'](_0x27b07f,{'captchaResponse':_0x1818fc}),Object['assign'](_0x27b07f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x27b07f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x27b07f;}async function Oi(_0x3612dc,_0x5921a2,_0x4e183c,_0x1a8632,_0x13caa8){var _0x4ff7ef;if((_0x4ff7ef=_0x3612dc['_getRecaptchaConfig']())!=null&&_0x4ff7ef['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2f6375=await br(_0x3612dc,_0x5921a2,_0x4e183c,_0x4e183c==='getOobCode');return _0x1a8632(_0x3612dc,_0x2f6375);}else return _0x1a8632(_0x3612dc,_0x5921a2)['catch'](async _0x7ff2ef=>{if(_0x7ff2ef['code']==='auth/missing-recaptcha-token'){console['log'](_0x4e183c+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3bb6e2=await br(_0x3612dc,_0x5921a2,_0x4e183c,_0x4e183c==='getOobCode');return _0x1a8632(_0x3612dc,_0x3bb6e2);}else return Promise['reject'](_0x7ff2ef);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x104133,_0xe5022f){const _0x5aaae3=Ui(_0x104133,'auth');if(_0x5aaae3['isInitialized']()){const _0x4076d6=_0x5aaae3['getImmediate'](),_0x32e23e=_0x5aaae3['getOptions']();if(De(_0x32e23e,_0xe5022f??{}))return _0x4076d6;K(_0x4076d6,'already-initialized');}return _0x5aaae3['initialize']({'options':_0xe5022f});}function Lf(_0x5ec121,_0x598e80){const _0x4ed64f=(_0x598e80==null?void 0x0:_0x598e80['persistence'])||[],_0x4d347f=(Array['isArray'](_0x4ed64f)?_0x4ed64f:[_0x4ed64f])['map'](ne);_0x598e80!=null&&_0x598e80['errorMap']&&_0x5ec121['_updateErrorMap'](_0x598e80['errorMap']),_0x5ec121['_initializeWithPersistence'](_0x4d347f,_0x598e80==null?void 0x0:_0x598e80['popupRedirectResolver']);}function xf(_0x59402,_0x24a955,_0x49e78f){const _0x18602a=qe(_0x59402);m(/^https?:\/\//['test'](_0x24a955),_0x18602a,'invalid-emulator-scheme');const _0x277b0f=!0x1,_0xa48323=La(_0x24a955),{host:_0x1715a2,port:_0x5e3540}=Ff(_0x24a955),_0x3ff948=_0x5e3540===null?'':':'+_0x5e3540,_0x286fbb={'url':_0xa48323+'//'+_0x1715a2+_0x3ff948+'/'},_0x191369=Object['freeze']({'host':_0x1715a2,'port':_0x5e3540,'protocol':_0xa48323['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x277b0f})});if(!_0x18602a['_canInitEmulator']){m(_0x18602a['config']['emulator']&&_0x18602a['emulatorConfig'],_0x18602a,'emulator-config-failed'),m(De(_0x286fbb,_0x18602a['config']['emulator'])&&De(_0x191369,_0x18602a['emulatorConfig']),_0x18602a,'emulator-config-failed');return;}_0x18602a['config']['emulator']=_0x286fbb,_0x18602a['emulatorConfig']=_0x191369,_0x18602a['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x1715a2)?jr(_0xa48323+'//'+_0x1715a2+_0x3ff948):Uf();}function La(_0x361a5d){const _0x3ba9ee=_0x361a5d['indexOf'](':');return _0x3ba9ee<0x0?'':_0x361a5d['substr'](0x0,_0x3ba9ee+0x1);}function Ff(_0x563da2){const _0x4aae93=La(_0x563da2),_0x3082e7=/(\/\/)?([^?#/]+)/['exec'](_0x563da2['substr'](_0x4aae93['length']));if(!_0x3082e7)return{'host':'','port':null};const _0x4bb40e=_0x3082e7[0x2]['split']('@')['pop']()||'',_0x1fdb94=/^(\[[^\]]+\])(:|$)/['exec'](_0x4bb40e);if(_0x1fdb94){const _0x15c424=_0x1fdb94[0x1];return{'host':_0x15c424,'port':Rr(_0x4bb40e['substr'](_0x15c424['length']+0x1))};}else{const [_0x1e5ca3,_0x39b106]=_0x4bb40e['split'](':');return{'host':_0x1e5ca3,'port':Rr(_0x39b106)};}}function Rr(_0x5d871b){if(!_0x5d871b)return null;const _0x3e3d49=Number(_0x5d871b);return isNaN(_0x3e3d49)?null:_0x3e3d49;}function Uf(){function _0xe68f2c(){const _0x477039=document['createElement']('p'),_0x48a1e1=_0x477039['style'];_0x477039['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x48a1e1['position']='fixed',_0x48a1e1['width']='100%',_0x48a1e1['backgroundColor']='#ffffff',_0x48a1e1['border']='.1em\x20solid\x20#000000',_0x48a1e1['color']='#b50000',_0x48a1e1['bottom']='0px',_0x48a1e1['left']='0px',_0x48a1e1['margin']='0px',_0x48a1e1['zIndex']='10000',_0x48a1e1['textAlign']='center',_0x477039['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x477039);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xe68f2c):_0xe68f2c());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0xc33ddb,_0x1cc05c){this['providerId']=_0xc33ddb,this['signInMethod']=_0x1cc05c;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x301ff5){return te('not\x20implemented');}['_linkToIdToken'](_0x38265d,_0xfad9eb){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x534f96){return te('not\x20implemented');}}async function Wf(_0x3e6329,_0x4c398a){return Ae(_0x3e6329,'POST','/v1/accounts:signUp',_0x4c398a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x5c8d20,_0x45ec10){return Yt(_0x5c8d20,'POST','/v1/accounts:signInWithPassword',Re(_0x5c8d20,_0x45ec10));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x5f11f3,_0x36eee6){return Yt(_0x5f11f3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5f11f3,_0x36eee6));}async function Hf(_0x58b206,_0x5d3c23){return Yt(_0x58b206,'POST','/v1/accounts:signInWithEmailLink',Re(_0x58b206,_0x5d3c23));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x28f3c7,_0x355119,_0x55222d,_0x4af31c=null){super('password',_0x55222d),this['_email']=_0x28f3c7,this['_password']=_0x355119,this['_tenantId']=_0x4af31c;}static['_fromEmailAndPassword'](_0x673568,_0x5cac62){return new Ft(_0x673568,_0x5cac62,'password');}static['_fromEmailAndCode'](_0x3f5096,_0x2868ce,_0x22ce24=null){return new Ft(_0x3f5096,_0x2868ce,'emailLink',_0x22ce24);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1ee46d){const _0x5082d1=typeof _0x1ee46d=='string'?JSON['parse'](_0x1ee46d):_0x1ee46d;if(_0x5082d1!=null&&_0x5082d1['email']&&(_0x5082d1!=null&&_0x5082d1['password'])){if(_0x5082d1['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5082d1['email'],_0x5082d1['password']);if(_0x5082d1['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5082d1['email'],_0x5082d1['password'],_0x5082d1['tenantId']);}return null;}async['_getIdTokenResponse'](_0x246331){switch(this['signInMethod']){case'password':const _0xb294b5={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x246331,_0xb294b5,'signInWithPassword',Bf);case'emailLink':return Vf(_0x246331,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x246331,'internal-error');}}async['_linkToIdToken'](_0x197c23,_0x114a29){switch(this['signInMethod']){case'password':const _0x3de716={'idToken':_0x114a29,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x197c23,_0x3de716,'signUpPassword',Wf);case'emailLink':return Hf(_0x197c23,{'idToken':_0x114a29,'email':this['_email'],'oobCode':this['_password']});default:K(_0x197c23,'internal-error');}}['_getReauthenticationResolver'](_0x1510d4){return this['_getIdTokenResponse'](_0x1510d4);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x5d16af,_0x1819ef){return Yt(_0x5d16af,'POST','/v1/accounts:signInWithIdp',Re(_0x5d16af,_0x1819ef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5bbae7){const _0x5667aa=new We(_0x5bbae7['providerId'],_0x5bbae7['signInMethod']);return _0x5bbae7['idToken']||_0x5bbae7['accessToken']?(_0x5bbae7['idToken']&&(_0x5667aa['idToken']=_0x5bbae7['idToken']),_0x5bbae7['accessToken']&&(_0x5667aa['accessToken']=_0x5bbae7['accessToken']),_0x5bbae7['nonce']&&!_0x5bbae7['pendingToken']&&(_0x5667aa['nonce']=_0x5bbae7['nonce']),_0x5bbae7['pendingToken']&&(_0x5667aa['pendingToken']=_0x5bbae7['pendingToken'])):_0x5bbae7['oauthToken']&&_0x5bbae7['oauthTokenSecret']?(_0x5667aa['accessToken']=_0x5bbae7['oauthToken'],_0x5667aa['secret']=_0x5bbae7['oauthTokenSecret']):K('argument-error'),_0x5667aa;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4f5e3d){const _0xfc26d9=typeof _0x4f5e3d=='string'?JSON['parse'](_0x4f5e3d):_0x4f5e3d,{providerId:_0x1a9129,signInMethod:_0x359870,..._0x175572}=_0xfc26d9;if(!_0x1a9129||!_0x359870)return null;const _0x52c3dc=new We(_0x1a9129,_0x359870);return _0x52c3dc['idToken']=_0x175572['idToken']||void 0x0,_0x52c3dc['accessToken']=_0x175572['accessToken']||void 0x0,_0x52c3dc['secret']=_0x175572['secret'],_0x52c3dc['nonce']=_0x175572['nonce'],_0x52c3dc['pendingToken']=_0x175572['pendingToken']||null,_0x52c3dc;}['_getIdTokenResponse'](_0x4cb413){const _0x405015=this['buildRequest']();return Ze(_0x4cb413,_0x405015);}['_linkToIdToken'](_0x9cd483,_0x2dbc00){const _0x3adbdd=this['buildRequest']();return _0x3adbdd['idToken']=_0x2dbc00,Ze(_0x9cd483,_0x3adbdd);}['_getReauthenticationResolver'](_0x64c270){const _0x217bd6=this['buildRequest']();return _0x217bd6['autoCreate']=!0x1,Ze(_0x64c270,_0x217bd6);}['buildRequest'](){const _0x494936={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x494936['pendingToken']=this['pendingToken'];else{const _0x4768aa={};this['idToken']&&(_0x4768aa['id_token']=this['idToken']),this['accessToken']&&(_0x4768aa['access_token']=this['accessToken']),this['secret']&&(_0x4768aa['oauth_token_secret']=this['secret']),_0x4768aa['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4768aa['nonce']=this['nonce']),_0x494936['postBody']=at(_0x4768aa);}return _0x494936;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x36b4f1){switch(_0x36b4f1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x54463c){const _0x1c1ec3=yt(vt(_0x54463c))['link'],_0x279b77=_0x1c1ec3?yt(vt(_0x1c1ec3))['deep_link_id']:null,_0x4c915a=yt(vt(_0x54463c))['deep_link_id'];return(_0x4c915a?yt(vt(_0x4c915a))['link']:null)||_0x4c915a||_0x279b77||_0x1c1ec3||_0x54463c;}class Ss{constructor(_0x40c889){const _0x2e1250=yt(vt(_0x40c889)),_0x53f9af=_0x2e1250['apiKey']??null,_0x364a33=_0x2e1250['oobCode']??null,_0x4fe986=Gf(_0x2e1250['mode']??null);m(_0x53f9af&&_0x364a33&&_0x4fe986,'argument-error'),this['apiKey']=_0x53f9af,this['operation']=_0x4fe986,this['code']=_0x364a33,this['continueUrl']=_0x2e1250['continueUrl']??null,this['languageCode']=_0x2e1250['lang']??null,this['tenantId']=_0x2e1250['tenantId']??null;}static['parseLink'](_0x47b56a){const _0x50e28b=qf(_0x47b56a);try{return new Ss(_0x50e28b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2e84a2,_0x35bafd){return Ft['_fromEmailAndPassword'](_0x2e84a2,_0x35bafd);}static['credentialWithLink'](_0x397a6b,_0x561c45){const _0xff4edc=Ss['parseLink'](_0x561c45);return m(_0xff4edc,'argument-error'),Ft['_fromEmailAndCode'](_0x397a6b,_0xff4edc['code'],_0xff4edc['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3c2d14){this['providerId']=_0x3c2d14,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x430d6c){this['defaultLanguageCode']=_0x430d6c;}['setCustomParameters'](_0x401ad0){return this['customParameters']=_0x401ad0,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3eae58){return this['scopes']['includes'](_0x3eae58)||this['scopes']['push'](_0x3eae58),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0xf6857){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xf6857});}static['credentialFromResult'](_0x48994e){return he['credentialFromTaggedObject'](_0x48994e);}static['credentialFromError'](_0x2294a3){return he['credentialFromTaggedObject'](_0x2294a3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5105b3}){if(!_0x5105b3||!('oauthAccessToken'in _0x5105b3)||!_0x5105b3['oauthAccessToken'])return null;try{return he['credential'](_0x5105b3['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3d8d9e,_0x580aa0){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3d8d9e,'accessToken':_0x580aa0});}static['credentialFromResult'](_0x9e3b99){return ue['credentialFromTaggedObject'](_0x9e3b99);}static['credentialFromError'](_0x3f265f){return ue['credentialFromTaggedObject'](_0x3f265f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xf29d59}){if(!_0xf29d59)return null;const {oauthIdToken:_0x5d8ca3,oauthAccessToken:_0x3aeb74}=_0xf29d59;if(!_0x5d8ca3&&!_0x3aeb74)return null;try{return ue['credential'](_0x5d8ca3,_0x3aeb74);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xa29fbe){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xa29fbe});}static['credentialFromResult'](_0x19db55){return de['credentialFromTaggedObject'](_0x19db55);}static['credentialFromError'](_0x141296){return de['credentialFromTaggedObject'](_0x141296['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4abf24}){if(!_0x4abf24||!('oauthAccessToken'in _0x4abf24)||!_0x4abf24['oauthAccessToken'])return null;try{return de['credential'](_0x4abf24['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x27ffce,_0x47b798){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x27ffce,'oauthTokenSecret':_0x47b798});}static['credentialFromResult'](_0x4d9279){return fe['credentialFromTaggedObject'](_0x4d9279);}static['credentialFromError'](_0x45f74f){return fe['credentialFromTaggedObject'](_0x45f74f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e5ebd}){if(!_0x5e5ebd)return null;const {oauthAccessToken:_0x23aef1,oauthTokenSecret:_0x39831c}=_0x5e5ebd;if(!_0x23aef1||!_0x39831c)return null;try{return fe['credential'](_0x23aef1,_0x39831c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x2d046d,_0x8e30c2){return Yt(_0x2d046d,'POST','/v1/accounts:signUp',Re(_0x2d046d,_0x8e30c2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x9fe0a){this['user']=_0x9fe0a['user'],this['providerId']=_0x9fe0a['providerId'],this['_tokenResponse']=_0x9fe0a['_tokenResponse'],this['operationType']=_0x9fe0a['operationType'];}static async['_fromIdTokenResponse'](_0x52074e,_0x59d7ff,_0x4d7629,_0x54e35a=!0x1){const _0x2c3d45=await z['_fromIdTokenResponse'](_0x52074e,_0x4d7629,_0x54e35a),_0x59603f=Ar(_0x4d7629);return new Be({'user':_0x2c3d45,'providerId':_0x59603f,'_tokenResponse':_0x4d7629,'operationType':_0x59d7ff});}static async['_forOperation'](_0x5ea896,_0x515cd5,_0x4b8ee9){await _0x5ea896['_updateTokensIfNecessary'](_0x4b8ee9,!0x0);const _0x244196=Ar(_0x4b8ee9);return new Be({'user':_0x5ea896,'providerId':_0x244196,'_tokenResponse':_0x4b8ee9,'operationType':_0x515cd5});}}function Ar(_0x35017b){return _0x35017b['providerId']?_0x35017b['providerId']:'phoneNumber'in _0x35017b?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5dc7ad,_0x355ffa,_0x434fd4,_0x476ad8){super(_0x355ffa['code'],_0x355ffa['message']),this['operationType']=_0x434fd4,this['user']=_0x476ad8,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5dc7ad['name'],'tenantId':_0x5dc7ad['tenantId']??void 0x0,'_serverResponse':_0x355ffa['customData']['_serverResponse'],'operationType':_0x434fd4};}static['_fromErrorAndOperation'](_0x1b89e8,_0x39370d,_0x2861f4,_0x3a95fd){return new Rn(_0x1b89e8,_0x39370d,_0x2861f4,_0x3a95fd);}}function Fa(_0x278171,_0x12c3e7,_0xff4acc,_0x520e47){return(_0x12c3e7==='reauthenticate'?_0xff4acc['_getReauthenticationResolver'](_0x278171):_0xff4acc['_getIdTokenResponse'](_0x278171))['catch'](_0x16d6fb=>{throw _0x16d6fb['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x278171,_0x16d6fb,_0x12c3e7,_0x520e47):_0x16d6fb;});}async function jf(_0x4fe396,_0x22e790,_0x499582=!0x1){const _0x3a9bfa=await xt(_0x4fe396,_0x22e790['_linkToIdToken'](_0x4fe396['auth'],await _0x4fe396['getIdToken']()),_0x499582);return Be['_forOperation'](_0x4fe396,'link',_0x3a9bfa);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x122e76,_0x376b18,_0x2ac635=!0x1){const {auth:_0x3808e5}=_0x122e76;if(H(_0x3808e5['app']))return Promise['reject'](se(_0x3808e5));const _0x504337='reauthenticate';try{const _0x1dd207=await xt(_0x122e76,Fa(_0x3808e5,_0x504337,_0x376b18,_0x122e76),_0x2ac635);m(_0x1dd207['idToken'],_0x3808e5,'internal-error');const _0x23a4f2=ws(_0x1dd207['idToken']);m(_0x23a4f2,_0x3808e5,'internal-error');const {sub:_0x5cbac9}=_0x23a4f2;return m(_0x122e76['uid']===_0x5cbac9,_0x3808e5,'user-mismatch'),Be['_forOperation'](_0x122e76,_0x504337,_0x1dd207);}catch(_0x938fd){throw(_0x938fd==null?void 0x0:_0x938fd['code'])==='auth/user-not-found'&&K(_0x3808e5,'user-mismatch'),_0x938fd;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4f04c2,_0x5cfea2,_0x4894c4=!0x1){if(H(_0x4f04c2['app']))return Promise['reject'](se(_0x4f04c2));const _0x21de1e='signIn',_0x1f0822=await Fa(_0x4f04c2,_0x21de1e,_0x5cfea2),_0x5645ee=await Be['_fromIdTokenResponse'](_0x4f04c2,_0x21de1e,_0x1f0822);return _0x4894c4||await _0x4f04c2['_updateCurrentUser'](_0x5645ee['user']),_0x5645ee;}async function Yf(_0x535b96,_0x23a3e7){return Ua(qe(_0x535b96),_0x23a3e7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x487c00){const _0xa2768=qe(_0x487c00);_0xa2768['_getPasswordPolicyInternal']()&&await _0xa2768['_updatePasswordPolicy']();}async function R_(_0x4676e1,_0x561c24,_0x135813){if(H(_0x4676e1['app']))return Promise['reject'](se(_0x4676e1));const _0x40ed4c=qe(_0x4676e1),_0x19ef2f=await Oi(_0x40ed4c,{'returnSecureToken':!0x0,'email':_0x561c24,'password':_0x135813,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x3fd2da=>{throw _0x3fd2da['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4676e1),_0x3fd2da;}),_0xf66669=await Be['_fromIdTokenResponse'](_0x40ed4c,'signIn',_0x19ef2f);return await _0x40ed4c['_updateCurrentUser'](_0xf66669['user']),_0xf66669;}function A_(_0x37548a,_0x31cc34,_0x3328d9){return H(_0x37548a['app'])?Promise['reject'](se(_0x37548a)):Yf(k(_0x37548a),ft['credential'](_0x31cc34,_0x3328d9))['catch'](async _0x53229e=>{throw _0x53229e['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x37548a),_0x53229e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x2195a1,_0x2bc2a4){return k(_0x2195a1)['setPersistence'](_0x2bc2a4);}function Qf(_0x2ca2b1,_0x3afe7d,_0x190644,_0x443323){return k(_0x2ca2b1)['onIdTokenChanged'](_0x3afe7d,_0x190644,_0x443323);}function Jf(_0x53bbd4,_0x209da8,_0xbc7417){return k(_0x53bbd4)['beforeAuthStateChanged'](_0x209da8,_0xbc7417);}function N_(_0x36bda0,_0x5af52f,_0x3e61f1,_0x211474){return k(_0x36bda0)['onAuthStateChanged'](_0x5af52f,_0x3e61f1,_0x211474);}function P_(_0x22ee83){return k(_0x22ee83)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x177b2c,_0x41e581){this['storageRetriever']=_0x177b2c,this['type']=_0x41e581;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x104e0e,_0x195fe8){return this['storage']['setItem'](_0x104e0e,JSON['stringify'](_0x195fe8)),Promise['resolve']();}['_get'](_0x783aed){const _0x56d8e5=this['storage']['getItem'](_0x783aed);return Promise['resolve'](_0x56d8e5?JSON['parse'](_0x56d8e5):null);}['_remove'](_0x4fa039){return this['storage']['removeItem'](_0x4fa039),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x12cdd4,_0x1390b0)=>this['onStorageEvent'](_0x12cdd4,_0x1390b0),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1720bc){for(const _0x54aac4 of Object['keys'](this['listeners'])){const _0x5ed2b7=this['storage']['getItem'](_0x54aac4),_0x315ad6=this['localCache'][_0x54aac4];_0x5ed2b7!==_0x315ad6&&_0x1720bc(_0x54aac4,_0x315ad6,_0x5ed2b7);}}['onStorageEvent'](_0x3a65b5,_0x419906=!0x1){if(!_0x3a65b5['key']){this['forAllChangedKeys']((_0x3139de,_0x37a0a6,_0x306ec)=>{this['notifyListeners'](_0x3139de,_0x306ec);});return;}const _0x5ab631=_0x3a65b5['key'];_0x419906?this['detachListener']():this['stopPolling']();const _0x45dd4e=()=>{const _0x4228b7=this['storage']['getItem'](_0x5ab631);!_0x419906&&this['localCache'][_0x5ab631]===_0x4228b7||this['notifyListeners'](_0x5ab631,_0x4228b7);},_0x598d26=this['storage']['getItem'](_0x5ab631);If()&&_0x598d26!==_0x3a65b5['newValue']&&_0x3a65b5['newValue']!==_0x3a65b5['oldValue']?setTimeout(_0x45dd4e,Zf):_0x45dd4e();}['notifyListeners'](_0x1fe602,_0x3cece2){this['localCache'][_0x1fe602]=_0x3cece2;const _0x51ae66=this['listeners'][_0x1fe602];if(_0x51ae66){for(const _0x317bf1 of Array['from'](_0x51ae66))_0x317bf1(_0x3cece2&&JSON['parse'](_0x3cece2));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5ebfbd,_0x3f51f6,_0x53bfa0)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5ebfbd,'oldValue':_0x3f51f6,'newValue':_0x53bfa0}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x22b058,_0x2c94b4){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x22b058]||(this['listeners'][_0x22b058]=new Set(),this['localCache'][_0x22b058]=this['storage']['getItem'](_0x22b058)),this['listeners'][_0x22b058]['add'](_0x2c94b4);}['_removeListener'](_0x58abcc,_0x5dce2d){this['listeners'][_0x58abcc]&&(this['listeners'][_0x58abcc]['delete'](_0x5dce2d),this['listeners'][_0x58abcc]['size']===0x0&&delete this['listeners'][_0x58abcc]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x406f0e,_0x117fb5){await super['_set'](_0x406f0e,_0x117fb5),this['localCache'][_0x406f0e]=JSON['stringify'](_0x117fb5);}async['_get'](_0x417d63){const _0x5eceb7=await super['_get'](_0x417d63);return this['localCache'][_0x417d63]=JSON['stringify'](_0x5eceb7),_0x5eceb7;}async['_remove'](_0x2f0bee){await super['_remove'](_0x2f0bee),delete this['localCache'][_0x2f0bee];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5ab39e,_0x5e7e46){}['_removeListener'](_0x3d6356,_0xca6500){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1898e5){return Promise['all'](_0x1898e5['map'](async _0x123ab8=>{try{return{'fulfilled':!0x0,'value':await _0x123ab8};}catch(_0x3b366d){return{'fulfilled':!0x1,'reason':_0x3b366d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x685d09){this['eventTarget']=_0x685d09,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xa3698c){const _0x124bcd=this['receivers']['find'](_0x531c43=>_0x531c43['isListeningto'](_0xa3698c));if(_0x124bcd)return _0x124bcd;const _0x1697cd=new jn(_0xa3698c);return this['receivers']['push'](_0x1697cd),_0x1697cd;}['isListeningto'](_0x62cfd4){return this['eventTarget']===_0x62cfd4;}async['handleEvent'](_0x2c364b){const _0x5c0173=_0x2c364b,{eventId:_0x5f3a14,eventType:_0x53967d,data:_0x4a1447}=_0x5c0173['data'],_0x13efac=this['handlersMap'][_0x53967d];if(!(_0x13efac!=null&&_0x13efac['size']))return;_0x5c0173['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5f3a14,'eventType':_0x53967d});const _0x1c0cc4=Array['from'](_0x13efac)['map'](async _0x4e7667=>_0x4e7667(_0x5c0173['origin'],_0x4a1447)),_0x588191=await tp(_0x1c0cc4);_0x5c0173['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5f3a14,'eventType':_0x53967d,'response':_0x588191});}['_subscribe'](_0x11ab5e,_0x48fea6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x11ab5e]||(this['handlersMap'][_0x11ab5e]=new Set()),this['handlersMap'][_0x11ab5e]['add'](_0x48fea6);}['_unsubscribe'](_0xdf9f5f,_0x5b2e8f){this['handlersMap'][_0xdf9f5f]&&_0x5b2e8f&&this['handlersMap'][_0xdf9f5f]['delete'](_0x5b2e8f),(!_0x5b2e8f||this['handlersMap'][_0xdf9f5f]['size']===0x0)&&delete this['handlersMap'][_0xdf9f5f],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x5b97e6='',_0x24b49e=0xa){let _0x5b7171='';for(let _0xb3c043=0x0;_0xb3c043<_0x24b49e;_0xb3c043++)_0x5b7171+=Math['floor'](Math['random']()*0xa);return _0x5b97e6+_0x5b7171;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x16255d){this['target']=_0x16255d,this['handlers']=new Set();}['removeMessageHandler'](_0xbabc84){_0xbabc84['messageChannel']&&(_0xbabc84['messageChannel']['port1']['removeEventListener']('message',_0xbabc84['onMessage']),_0xbabc84['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xbabc84);}async['_send'](_0x46387f,_0x47673f,_0x389e92=0x32){const _0x42db4c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x42db4c)throw new Error('connection_unavailable');let _0x2bc603,_0x403e96;return new Promise((_0x131685,_0xd122e0)=>{const _0x551623=bs('',0x14);_0x42db4c['port1']['start']();const _0x3d6fc1=setTimeout(()=>{_0xd122e0(new Error('unsupported_event'));},_0x389e92);_0x403e96={'messageChannel':_0x42db4c,'onMessage'(_0xf97f8d){const _0x4021a3=_0xf97f8d;if(_0x4021a3['data']['eventId']===_0x551623)switch(_0x4021a3['data']['status']){case'ack':clearTimeout(_0x3d6fc1),_0x2bc603=setTimeout(()=>{_0xd122e0(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2bc603),_0x131685(_0x4021a3['data']['response']);break;default:clearTimeout(_0x3d6fc1),clearTimeout(_0x2bc603),_0xd122e0(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x403e96),_0x42db4c['port1']['addEventListener']('message',_0x403e96['onMessage']),this['target']['postMessage']({'eventType':_0x46387f,'eventId':_0x551623,'data':_0x47673f},[_0x42db4c['port2']]);})['finally'](()=>{_0x403e96&&this['removeMessageHandler'](_0x403e96);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x55c6fa){X()['location']['href']=_0x55c6fa;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x209990;return((_0x209990=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x209990['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x38f59a){this['request']=_0x38f59a;}['toPromise'](){return new Promise((_0x31b1df,_0x4f1ea0)=>{this['request']['addEventListener']('success',()=>{_0x31b1df(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4f1ea0(this['request']['error']);});});}}function Kn(_0x279e8e,_0x2373d2){return _0x279e8e['transaction']([kn],_0x2373d2?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3dee2a=indexedDB['deleteDatabase'](qa);return new Jt(_0x3dee2a)['toPromise']();}function ja(){const _0xf88b8b=indexedDB['open'](qa,ap);return new Promise((_0x18f0af,_0x129099)=>{_0xf88b8b['addEventListener']('error',()=>{_0x129099(_0xf88b8b['error']);}),_0xf88b8b['addEventListener']('upgradeneeded',()=>{const _0xbdc07c=_0xf88b8b['result'];try{_0xbdc07c['createObjectStore'](kn,{'keyPath':za});}catch(_0x48a359){_0x129099(_0x48a359);}}),_0xf88b8b['addEventListener']('success',async()=>{const _0x5e3934=_0xf88b8b['result'];_0x5e3934['objectStoreNames']['contains'](kn)?_0x18f0af(_0x5e3934):(_0x5e3934['close'](),await cp(),_0x18f0af(await ja()));});});}async function kr(_0x5c3bb3,_0x1068d7,_0x11b4e7){const _0x520da6=Kn(_0x5c3bb3,!0x0)['put']({[za]:_0x1068d7,'value':_0x11b4e7});return new Jt(_0x520da6)['toPromise']();}async function lp(_0x2d3abf,_0x46d1d3){const _0x27186d=Kn(_0x2d3abf,!0x1)['get'](_0x46d1d3),_0x25277b=await new Jt(_0x27186d)['toPromise']();return _0x25277b===void 0x0?null:_0x25277b['value'];}function Nr(_0x174b04,_0x1d8134){const _0x125da5=Kn(_0x174b04,!0x0)['delete'](_0x1d8134);return new Jt(_0x125da5)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5b76ba){let _0x12a58a=0x0;for(;;)try{const _0x32f5bf=await this['_openDb']();return await _0x5b76ba(_0x32f5bf);}catch(_0xecb416){if(_0x12a58a++>up)throw _0xecb416;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x40a2ac,_0x13364b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x13364b['key'])})),this['receiver']['_subscribe']('ping',async(_0x171817,_0x35ee0f)=>['keyChanged']);}async['initializeSender'](){var _0x4e1521,_0xda6ace;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x2c8402=await this['sender']['_send']('ping',{},0x320);_0x2c8402&&(_0x4e1521=_0x2c8402[0x0])!=null&&_0x4e1521['fulfilled']&&(_0xda6ace=_0x2c8402[0x0])!=null&&_0xda6ace['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x27c189){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x27c189},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xa39df8=>{await kr(_0xa39df8,An,'1'),await Nr(_0xa39df8,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2c9525){this['pendingWrites']++;try{await _0x2c9525();}finally{this['pendingWrites']--;}}async['_set'](_0x2d2302,_0xbb4c09){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x363a94=>kr(_0x363a94,_0x2d2302,_0xbb4c09)),this['localCache'][_0x2d2302]=_0xbb4c09,this['notifyServiceWorker'](_0x2d2302)));}async['_get'](_0xde2b51){const _0x2ae4c4=await this['_withRetries'](_0x2ac7cc=>lp(_0x2ac7cc,_0xde2b51));return this['localCache'][_0xde2b51]=_0x2ae4c4,_0x2ae4c4;}async['_remove'](_0x1a6550){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xaa316f=>Nr(_0xaa316f,_0x1a6550)),delete this['localCache'][_0x1a6550],this['notifyServiceWorker'](_0x1a6550)));}async['_poll'](){const _0x67218c=await this['_withRetries'](_0x2ee95a=>{const _0x55e8aa=Kn(_0x2ee95a,!0x1)['getAll']();return new Jt(_0x55e8aa)['toPromise']();});if(!_0x67218c)return[];if(this['pendingWrites']!==0x0)return[];const _0x6ac835=[],_0x137667=new Set();if(_0x67218c['length']!==0x0){for(const {fbase_key:_0x333866,value:_0x175a2f}of _0x67218c)_0x137667['add'](_0x333866),JSON['stringify'](this['localCache'][_0x333866])!==JSON['stringify'](_0x175a2f)&&(this['notifyListeners'](_0x333866,_0x175a2f),_0x6ac835['push'](_0x333866));}for(const _0x4701b7 of Object['keys'](this['localCache']))this['localCache'][_0x4701b7]&&!_0x137667['has'](_0x4701b7)&&(this['notifyListeners'](_0x4701b7,null),_0x6ac835['push'](_0x4701b7));return _0x6ac835;}['notifyListeners'](_0x4a4937,_0x4cfaac){this['localCache'][_0x4a4937]=_0x4cfaac;const _0x7ffd4a=this['listeners'][_0x4a4937];if(_0x7ffd4a){for(const _0x233ac0 of Array['from'](_0x7ffd4a))_0x233ac0(_0x4cfaac);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5079c5,_0x472f30){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5079c5]||(this['listeners'][_0x5079c5]=new Set(),this['_get'](_0x5079c5)),this['listeners'][_0x5079c5]['add'](_0x472f30);}['_removeListener'](_0x1861fb,_0x155d22){this['listeners'][_0x1861fb]&&(this['listeners'][_0x1861fb]['delete'](_0x155d22),this['listeners'][_0x1861fb]['size']===0x0&&delete this['listeners'][_0x1861fb]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x248c5b,_0x46c632){return _0x46c632?ne(_0x46c632):(m(_0x248c5b['_popupRedirectResolver'],_0x248c5b,'argument-error'),_0x248c5b['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x1259e9){super('custom','custom'),this['params']=_0x1259e9;}['_getIdTokenResponse'](_0x4073f7){return Ze(_0x4073f7,this['_buildIdpRequest']());}['_linkToIdToken'](_0xf954e1,_0x557865){return Ze(_0xf954e1,this['_buildIdpRequest'](_0x557865));}['_getReauthenticationResolver'](_0x16146a){return Ze(_0x16146a,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1c1a39){const _0x2e60e5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1c1a39&&(_0x2e60e5['idToken']=_0x1c1a39),_0x2e60e5;}}function pp(_0x2b33fb){return Ua(_0x2b33fb['auth'],new Rs(_0x2b33fb),_0x2b33fb['bypassAuthState']);}function _p(_0x55bd7d){const {auth:_0x31c8ea,user:_0x5ea18b}=_0x55bd7d;return m(_0x5ea18b,_0x31c8ea,'internal-error'),Kf(_0x5ea18b,new Rs(_0x55bd7d),_0x55bd7d['bypassAuthState']);}async function gp(_0x2f5885){const {auth:_0xfc3006,user:_0x2f98eb}=_0x2f5885;return m(_0x2f98eb,_0xfc3006,'internal-error'),jf(_0x2f98eb,new Rs(_0x2f5885),_0x2f5885['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x462a1e,_0x1edf2b,_0x289ae4,_0x359d21,_0x420413=!0x1){this['auth']=_0x462a1e,this['resolver']=_0x289ae4,this['user']=_0x359d21,this['bypassAuthState']=_0x420413,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1edf2b)?_0x1edf2b:[_0x1edf2b];}['execute'](){return new Promise(async(_0x461522,_0x5d9c35)=>{this['pendingPromise']={'resolve':_0x461522,'reject':_0x5d9c35};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x7726c4){this['reject'](_0x7726c4);}});}async['onAuthEvent'](_0x4ccc55){const {urlResponse:_0x6d1054,sessionId:_0x19ba41,postBody:_0x451868,tenantId:_0x167ebb,error:_0x3c7017,type:_0x184e38}=_0x4ccc55;if(_0x3c7017){this['reject'](_0x3c7017);return;}const _0xcb3341={'auth':this['auth'],'requestUri':_0x6d1054,'sessionId':_0x19ba41,'tenantId':_0x167ebb||void 0x0,'postBody':_0x451868||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x184e38)(_0xcb3341));}catch(_0x243b2d){this['reject'](_0x243b2d);}}['onError'](_0x3d3593){this['reject'](_0x3d3593);}['getIdpTask'](_0x35602c){switch(_0x35602c){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x2a1359){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2a1359),this['unregisterAndCleanUp']();}['reject'](_0x44106f){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x44106f),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3919e4,_0x49c447,_0xde56e9,_0x4cf0a2,_0x17bd89){super(_0x3919e4,_0x49c447,_0x4cf0a2,_0x17bd89),this['provider']=_0xde56e9,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x2e0c94=await this['execute']();return m(_0x2e0c94,this['auth'],'internal-error'),_0x2e0c94;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x17584f=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x17584f),this['authWindow']['associatedEvent']=_0x17584f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x58e94c=>{this['reject'](_0x58e94c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4d843a=>{_0x4d843a||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2c8166;return((_0x2c8166=this['authWindow'])==null?void 0x0:_0x2c8166['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5302f1=()=>{var _0x302cb0,_0x12e54a;if((_0x12e54a=(_0x302cb0=this['authWindow'])==null?void 0x0:_0x302cb0['window'])!=null&&_0x12e54a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5302f1,mp['get']());};_0x5302f1();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x4f550b,_0x1badc8,_0x137ea5=!0x1){super(_0x4f550b,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1badc8,void 0x0,_0x137ea5),this['eventId']=null;}async['execute'](){let _0x200445=rn['get'](this['auth']['_key']());if(!_0x200445){try{const _0x554bd7=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x200445=()=>Promise['resolve'](_0x554bd7);}catch(_0x1ba6e1){_0x200445=()=>Promise['reject'](_0x1ba6e1);}rn['set'](this['auth']['_key'](),_0x200445);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x200445();}async['onAuthEvent'](_0x4dfe1b){if(_0x4dfe1b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4dfe1b);if(_0x4dfe1b['type']==='unknown'){this['resolve'](null);return;}if(_0x4dfe1b['eventId']){const _0xf77aae=await this['auth']['_redirectUserForId'](_0x4dfe1b['eventId']);if(_0xf77aae)return this['user']=_0xf77aae,super['onAuthEvent'](_0x4dfe1b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x4260be,_0x332744){const _0x4d8548=Cp(_0x332744),_0x9f06a1=wp(_0x4260be);if(!await _0x9f06a1['_isAvailable']())return!0x1;const _0x3ecb62=await _0x9f06a1['_get'](_0x4d8548)==='true';return await _0x9f06a1['_remove'](_0x4d8548),_0x3ecb62;}function Ip(_0x25894d,_0x78f4de){rn['set'](_0x25894d['_key'](),_0x78f4de);}function wp(_0x522ebe){return ne(_0x522ebe['_redirectPersistence']);}function Cp(_0x145e75){return sn(yp,_0x145e75['config']['apiKey'],_0x145e75['name']);}async function Tp(_0x4f10dd,_0xc23b27,_0x4138ef=!0x1){if(H(_0x4f10dd['app']))return Promise['reject'](se(_0x4f10dd));const _0x124a4d=qe(_0x4f10dd),_0x1a00b6=fp(_0x124a4d,_0xc23b27),_0x211912=await new vp(_0x124a4d,_0x1a00b6,_0x4138ef)['execute']();return _0x211912&&!_0x4138ef&&(delete _0x211912['user']['_redirectEventId'],await _0x124a4d['_persistUserIfCurrent'](_0x211912['user']),await _0x124a4d['_setRedirectUser'](null,_0xc23b27)),_0x211912;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x27643c){this['auth']=_0x27643c,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x19fc0c){this['consumers']['add'](_0x19fc0c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x19fc0c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x19fc0c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x559ed4){this['consumers']['delete'](_0x559ed4);}['onEvent'](_0x403d58){if(this['hasEventBeenHandled'](_0x403d58))return!0x1;let _0x3f668d=!0x1;return this['consumers']['forEach'](_0x55d961=>{this['isEventForConsumer'](_0x403d58,_0x55d961)&&(_0x3f668d=!0x0,this['sendToConsumer'](_0x403d58,_0x55d961),this['saveEventToCache'](_0x403d58));}),this['hasHandledPotentialRedirect']||!Rp(_0x403d58)||(this['hasHandledPotentialRedirect']=!0x0,_0x3f668d||(this['queuedRedirectEvent']=_0x403d58,_0x3f668d=!0x0)),_0x3f668d;}['sendToConsumer'](_0x4159ab,_0x358d8c){var _0x7c1d36;if(_0x4159ab['error']&&!Qa(_0x4159ab)){const _0x16e818=((_0x7c1d36=_0x4159ab['error']['code'])==null?void 0x0:_0x7c1d36['split']('auth/')[0x1])||'internal-error';_0x358d8c['onError'](J(this['auth'],_0x16e818));}else _0x358d8c['onAuthEvent'](_0x4159ab);}['isEventForConsumer'](_0x230900,_0x197399){const _0x350d3e=_0x197399['eventId']===null||!!_0x230900['eventId']&&_0x230900['eventId']===_0x197399['eventId'];return _0x197399['filter']['includes'](_0x230900['type'])&&_0x350d3e;}['hasEventBeenHandled'](_0x3fb25c){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x3fb25c));}['saveEventToCache'](_0x312271){this['cachedEventUids']['add'](Pr(_0x312271)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x4e41aa){return[_0x4e41aa['type'],_0x4e41aa['eventId'],_0x4e41aa['sessionId'],_0x4e41aa['tenantId']]['filter'](_0x30ffd7=>_0x30ffd7)['join']('-');}function Qa({type:_0x19c405,error:_0x3c0187}){return _0x19c405==='unknown'&&(_0x3c0187==null?void 0x0:_0x3c0187['code'])==='auth/no-auth-event';}function Rp(_0x3174a3){switch(_0x3174a3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3174a3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x176bbc,_0x296221={}){return Ae(_0x176bbc,'GET','/v1/projects',_0x296221);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x13004f){if(_0x13004f['config']['emulator'])return;const {authorizedDomains:_0x13ae56}=await Ap(_0x13004f);for(const _0x5b544a of _0x13ae56)try{if(Op(_0x5b544a))return;}catch{}K(_0x13004f,'unauthorized-domain');}function Op(_0x3aef10){const _0x17af88=Ni(),{protocol:_0x2898f6,hostname:_0x4eff66}=new URL(_0x17af88);if(_0x3aef10['startsWith']('chrome-extension://')){const _0x4d2512=new URL(_0x3aef10);return _0x4d2512['hostname']===''&&_0x4eff66===''?_0x2898f6==='chrome-extension:'&&_0x3aef10['replace']('chrome-extension://','')===_0x17af88['replace']('chrome-extension://',''):_0x2898f6==='chrome-extension:'&&_0x4d2512['hostname']===_0x4eff66;}if(!Np['test'](_0x2898f6))return!0x1;if(kp['test'](_0x3aef10))return _0x4eff66===_0x3aef10;const _0x2d2443=_0x3aef10['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2d2443+'|'+_0x2d2443+')$','i')['test'](_0x4eff66);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x260f9a=X()['___jsl'];if(_0x260f9a!=null&&_0x260f9a['H']){for(const _0x4a9e6f of Object['keys'](_0x260f9a['H']))if(_0x260f9a['H'][_0x4a9e6f]['r']=_0x260f9a['H'][_0x4a9e6f]['r']||[],_0x260f9a['H'][_0x4a9e6f]['L']=_0x260f9a['H'][_0x4a9e6f]['L']||[],_0x260f9a['H'][_0x4a9e6f]['r']=[..._0x260f9a['H'][_0x4a9e6f]['L']],_0x260f9a['CP']){for(let _0x41f130=0x0;_0x41f130<_0x260f9a['CP']['length'];_0x41f130++)_0x260f9a['CP'][_0x41f130]=null;}}}function Mp(_0x14847c){return new Promise((_0x57d2ae,_0x11ffbb)=>{var _0xd00757,_0x159f79,_0x5c3a0d;function _0x10dd05(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x57d2ae(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x11ffbb(J(_0x14847c,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x159f79=(_0xd00757=X()['gapi'])==null?void 0x0:_0xd00757['iframes'])!=null&&_0x159f79['Iframe'])_0x57d2ae(gapi['iframes']['getContext']());else{if((_0x5c3a0d=X()['gapi'])!=null&&_0x5c3a0d['load'])_0x10dd05();else{const _0x4cc320=Nf('iframefcb');return X()[_0x4cc320]=()=>{gapi['load']?_0x10dd05():_0x11ffbb(J(_0x14847c,'network-request-failed'));},Da(kf()+'?onload='+_0x4cc320)['catch'](_0x84c5d3=>_0x11ffbb(_0x84c5d3));}}})['catch'](_0x29974e=>{throw on=null,_0x29974e;});}let on=null;function Lp(_0x4d6608){return on=on||Mp(_0x4d6608),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x27b717){const _0xa403e7=_0x27b717['config'];m(_0xa403e7['authDomain'],_0x27b717,'auth-domain-config-required');const _0x4e7fae=_0xa403e7['emulator']?Is(_0xa403e7,Up):'https://'+_0x27b717['config']['authDomain']+'/'+Fp,_0x5b3158={'apiKey':_0xa403e7['apiKey'],'appName':_0x27b717['name'],'v':ct},_0x427dc2=Bp['get'](_0x27b717['config']['apiHost']);_0x427dc2&&(_0x5b3158['eid']=_0x427dc2);const _0x36edf7=_0x27b717['_getFrameworks']();return _0x36edf7['length']&&(_0x5b3158['fw']=_0x36edf7['join'](',')),_0x4e7fae+'?'+at(_0x5b3158)['slice'](0x1);}async function Hp(_0xb1fc92){const _0x2f6fbc=await Lp(_0xb1fc92),_0x3b2d86=X()['gapi'];return m(_0x3b2d86,_0xb1fc92,'internal-error'),_0x2f6fbc['open']({'where':document['body'],'url':Vp(_0xb1fc92),'messageHandlersFilter':_0x3b2d86['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x3f64a1=>new Promise(async(_0x4ffade,_0x1efb39)=>{await _0x3f64a1['restyle']({'setHideOnLeave':!0x1});const _0x2bc936=J(_0xb1fc92,'network-request-failed'),_0x3f8e3a=X()['setTimeout'](()=>{_0x1efb39(_0x2bc936);},xp['get']());function _0x43a1eb(){X()['clearTimeout'](_0x3f8e3a),_0x4ffade(_0x3f64a1);}_0x3f64a1['ping'](_0x43a1eb)['then'](_0x43a1eb,()=>{_0x1efb39(_0x2bc936);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xa05c70){this['window']=_0xa05c70,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x28efe7,_0x4ce54d,_0x49d9ef,_0x11f9e1=Gp,_0x480eea=qp){const _0x839a47=Math['max']((window['screen']['availHeight']-_0x480eea)/0x2,0x0)['toString'](),_0x10f56e=Math['max']((window['screen']['availWidth']-_0x11f9e1)/0x2,0x0)['toString']();let _0x242b37='';const _0x3c9085={...$p,'width':_0x11f9e1['toString'](),'height':_0x480eea['toString'](),'top':_0x839a47,'left':_0x10f56e},_0x1bff70=W()['toLowerCase']();_0x49d9ef&&(_0x242b37=ba(_0x1bff70)?zp:_0x49d9ef),Ta(_0x1bff70)&&(_0x4ce54d=_0x4ce54d||jp,_0x3c9085['scrollbars']='yes');const _0x5cd1bb=Object['entries'](_0x3c9085)['reduce']((_0x20bd2a,[_0x53e2d1,_0x2c1123])=>''+_0x20bd2a+_0x53e2d1+'='+_0x2c1123+',','');if(Ef(_0x1bff70)&&_0x242b37!=='_self')return Yp(_0x4ce54d||'',_0x242b37),new Dr(null);const _0x1f9e53=window['open'](_0x4ce54d||'',_0x242b37,_0x5cd1bb);m(_0x1f9e53,_0x28efe7,'popup-blocked');try{_0x1f9e53['focus']();}catch{}return new Dr(_0x1f9e53);}function Yp(_0x3c4246,_0x570aba){const _0xd0001=document['createElement']('a');_0xd0001['href']=_0x3c4246,_0xd0001['target']=_0x570aba;const _0x3b8e91=document['createEvent']('MouseEvent');_0x3b8e91['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xd0001['dispatchEvent'](_0x3b8e91);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x407d81,_0x1f1495,_0x51edae,_0x7fa3d8,_0x19cb73,_0x50d71f){m(_0x407d81['config']['authDomain'],_0x407d81,'auth-domain-config-required'),m(_0x407d81['config']['apiKey'],_0x407d81,'invalid-api-key');const _0xcad66d={'apiKey':_0x407d81['config']['apiKey'],'appName':_0x407d81['name'],'authType':_0x51edae,'redirectUrl':_0x7fa3d8,'v':ct,'eventId':_0x19cb73};if(_0x1f1495 instanceof xa){_0x1f1495['setDefaultLanguage'](_0x407d81['languageCode']),_0xcad66d['providerId']=_0x1f1495['providerId']||'',hi(_0x1f1495['getCustomParameters']())||(_0xcad66d['customParameters']=JSON['stringify'](_0x1f1495['getCustomParameters']()));for(const [_0x5bf0a2,_0x30a855]of Object['entries']({}))_0xcad66d[_0x5bf0a2]=_0x30a855;}if(_0x1f1495 instanceof Qt){const _0x10422e=_0x1f1495['getScopes']()['filter'](_0x499f91=>_0x499f91!=='');_0x10422e['length']>0x0&&(_0xcad66d['scopes']=_0x10422e['join'](','));}_0x407d81['tenantId']&&(_0xcad66d['tid']=_0x407d81['tenantId']);const _0x3a2cc3=_0xcad66d;for(const _0x4451c6 of Object['keys'](_0x3a2cc3))_0x3a2cc3[_0x4451c6]===void 0x0&&delete _0x3a2cc3[_0x4451c6];const _0x24e2dd=await _0x407d81['_getAppCheckToken'](),_0x9f3a94=_0x24e2dd?'#'+Xp+'='+encodeURIComponent(_0x24e2dd):'';return Zp(_0x407d81)+'?'+at(_0x3a2cc3)['slice'](0x1)+_0x9f3a94;}function Zp({config:_0x485759}){return _0x485759['emulator']?Is(_0x485759,Jp):'https://'+_0x485759['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x33a7a9,_0x18d5c4,_0x5cc760,_0x549aa8){var _0x281bdd;ae((_0x281bdd=this['eventManagers'][_0x33a7a9['_key']()])==null?void 0x0:_0x281bdd['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4aeb28=await Mr(_0x33a7a9,_0x18d5c4,_0x5cc760,Ni(),_0x549aa8);return Kp(_0x33a7a9,_0x4aeb28,bs());}async['_openRedirect'](_0x30609e,_0x2385e0,_0x355de5,_0x40feb3){await this['_originValidation'](_0x30609e);const _0x158a53=await Mr(_0x30609e,_0x2385e0,_0x355de5,Ni(),_0x40feb3);return ip(_0x158a53),new Promise(()=>{});}['_initialize'](_0x56d7fe){const _0x4e5d9b=_0x56d7fe['_key']();if(this['eventManagers'][_0x4e5d9b]){const {manager:_0x1c3e4e,promise:_0x4a367f}=this['eventManagers'][_0x4e5d9b];return _0x1c3e4e?Promise['resolve'](_0x1c3e4e):(ae(_0x4a367f,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4a367f);}const _0x5a9b6a=this['initAndGetManager'](_0x56d7fe);return this['eventManagers'][_0x4e5d9b]={'promise':_0x5a9b6a},_0x5a9b6a['catch'](()=>{delete this['eventManagers'][_0x4e5d9b];}),_0x5a9b6a;}async['initAndGetManager'](_0x24f406){const _0x13c494=await Hp(_0x24f406),_0x50de9b=new bp(_0x24f406);return _0x13c494['register']('authEvent',_0x1576af=>(m(_0x1576af==null?void 0x0:_0x1576af['authEvent'],_0x24f406,'invalid-auth-event'),{'status':_0x50de9b['onEvent'](_0x1576af['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x24f406['_key']()]={'manager':_0x50de9b},this['iframes'][_0x24f406['_key']()]=_0x13c494,_0x50de9b;}['_isIframeWebStorageSupported'](_0x249ffc,_0xa5fe0e){this['iframes'][_0x249ffc['_key']()]['send'](li,{'type':li},_0x1c1ebc=>{var _0x5e1948;const _0x771553=(_0x5e1948=_0x1c1ebc==null?void 0x0:_0x1c1ebc[0x0])==null?void 0x0:_0x5e1948[li];_0x771553!==void 0x0&&_0xa5fe0e(!!_0x771553),K(_0x249ffc,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x592f1c){const _0x3d75f5=_0x592f1c['_key']();return this['originValidationPromises'][_0x3d75f5]||(this['originValidationPromises'][_0x3d75f5]=Pp(_0x592f1c)),this['originValidationPromises'][_0x3d75f5];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x56ff40){this['auth']=_0x56ff40,this['internalListeners']=new Map();}['getUid'](){var _0x22f79a;return this['assertAuthConfigured'](),((_0x22f79a=this['auth']['currentUser'])==null?void 0x0:_0x22f79a['uid'])||null;}async['getToken'](_0x1ae799){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1ae799)}:null;}['addAuthTokenListener'](_0x4dff22){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4dff22))return;const _0x43aaaf=this['auth']['onIdTokenChanged'](_0x452bdf=>{_0x4dff22((_0x452bdf==null?void 0x0:_0x452bdf['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4dff22,_0x43aaaf),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x318848){this['assertAuthConfigured']();const _0x1f1d33=this['internalListeners']['get'](_0x318848);_0x1f1d33&&(this['internalListeners']['delete'](_0x318848),_0x1f1d33(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5d4355){switch(_0x5d4355){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x3e11e0){et(new Me('auth',(_0x57f3a6,{options:_0x4cf37c})=>{const _0x133d5b=_0x57f3a6['getProvider']('app')['getImmediate'](),_0x5f221d=_0x57f3a6['getProvider']('heartbeat'),_0x3d2072=_0x57f3a6['getProvider']('app-check-internal'),{apiKey:_0x2ca1d4,authDomain:_0xb08847}=_0x133d5b['options'];m(_0x2ca1d4&&!_0x2ca1d4['includes'](':'),'invalid-api-key',{'appName':_0x133d5b['name']});const _0x54d359={'apiKey':_0x2ca1d4,'authDomain':_0xb08847,'clientPlatform':_0x3e11e0,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x3e11e0)},_0x564a2b=new bf(_0x133d5b,_0x5f221d,_0x3d2072,_0x54d359);return Lf(_0x564a2b,_0x4cf37c),_0x564a2b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xd1a8a3,_0x3ed7fb,_0x5d7416)=>{_0xd1a8a3['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0xe51649=>{const _0x5a5a2e=qe(_0xe51649['getProvider']('auth')['getImmediate']());return(_0x57b6f2=>new n_(_0x57b6f2))(_0x5a5a2e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x3e11e0)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1cc380=>async _0x242b56=>{const _0x446097=_0x242b56&&await _0x242b56['getIdTokenResult'](),_0x493541=_0x446097&&(new Date()['getTime']()-Date['parse'](_0x446097['issuedAtTime']))/0x3e8;if(_0x493541&&_0x493541>o_)return;const _0x502e72=_0x446097==null?void 0x0:_0x446097['token'];Fr!==_0x502e72&&(Fr=_0x502e72,await fetch(_0x1cc380,{'method':_0x502e72?'POST':'DELETE','headers':_0x502e72?{'Authorization':'Bearer\x20'+_0x502e72}:{}}));};function O_(_0x1fa1be=Qr()){const _0x3631da=Ui(_0x1fa1be,'auth');if(_0x3631da['isInitialized']())return _0x3631da['getImmediate']();const _0x523057=Mf(_0x1fa1be,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x5c56ef=Gr('authTokenSyncURL');if(_0x5c56ef&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4d0ffe=new URL(_0x5c56ef,location['origin']);if(location['origin']===_0x4d0ffe['origin']){const _0x29d4c3=a_(_0x4d0ffe['toString']());Jf(_0x523057,_0x29d4c3,()=>_0x29d4c3(_0x523057['currentUser'])),Qf(_0x523057,_0xfbb535=>_0x29d4c3(_0xfbb535));}}const _0x475966=Hr('auth');return _0x475966&&xf(_0x523057,'http://'+_0x475966),_0x523057;}function c_(){var _0x4a95d7;return((_0x4a95d7=document['getElementsByTagName']('head'))==null?void 0x0:_0x4a95d7[0x0])??document;}Rf({'loadJS'(_0x3dd0b2){return new Promise((_0x58e294,_0x1c2449)=>{const _0x1663fb=document['createElement']('script');_0x1663fb['setAttribute']('src',_0x3dd0b2),_0x1663fb['onload']=_0x58e294,_0x1663fb['onerror']=_0x2b396d=>{const _0x340b76=J('internal-error');_0x340b76['customData']=_0x2b396d,_0x1c2449(_0x340b76);},_0x1663fb['type']='text/javascript',_0x1663fb['charset']='UTF-8',c_()['appendChild'](_0x1663fb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};