const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x352867,_0x2d11e5){if(!_0x352867)throw ot(_0x2d11e5);},ot=function(_0x542174){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x542174);},Wr=function(_0x487389){const _0x46b0f2=[];let _0x21ae56=0x0;for(let _0xa0ead4=0x0;_0xa0ead4<_0x487389['length'];_0xa0ead4++){let _0x131cc3=_0x487389['charCodeAt'](_0xa0ead4);_0x131cc3<0x80?_0x46b0f2[_0x21ae56++]=_0x131cc3:_0x131cc3<0x800?(_0x46b0f2[_0x21ae56++]=_0x131cc3>>0x6|0xc0,_0x46b0f2[_0x21ae56++]=_0x131cc3&0x3f|0x80):(_0x131cc3&0xfc00)===0xd800&&_0xa0ead4+0x1<_0x487389['length']&&(_0x487389['charCodeAt'](_0xa0ead4+0x1)&0xfc00)===0xdc00?(_0x131cc3=0x10000+((_0x131cc3&0x3ff)<<0xa)+(_0x487389['charCodeAt'](++_0xa0ead4)&0x3ff),_0x46b0f2[_0x21ae56++]=_0x131cc3>>0x12|0xf0,_0x46b0f2[_0x21ae56++]=_0x131cc3>>0xc&0x3f|0x80,_0x46b0f2[_0x21ae56++]=_0x131cc3>>0x6&0x3f|0x80,_0x46b0f2[_0x21ae56++]=_0x131cc3&0x3f|0x80):(_0x46b0f2[_0x21ae56++]=_0x131cc3>>0xc|0xe0,_0x46b0f2[_0x21ae56++]=_0x131cc3>>0x6&0x3f|0x80,_0x46b0f2[_0x21ae56++]=_0x131cc3&0x3f|0x80);}return _0x46b0f2;},Za=function(_0x46b8ab){const _0x113001=[];let _0x3e1700=0x0,_0x575117=0x0;for(;_0x3e1700<_0x46b8ab['length'];){const _0x12927c=_0x46b8ab[_0x3e1700++];if(_0x12927c<0x80)_0x113001[_0x575117++]=String['fromCharCode'](_0x12927c);else{if(_0x12927c>0xbf&&_0x12927c<0xe0){const _0x31abb7=_0x46b8ab[_0x3e1700++];_0x113001[_0x575117++]=String['fromCharCode']((_0x12927c&0x1f)<<0x6|_0x31abb7&0x3f);}else{if(_0x12927c>0xef&&_0x12927c<0x16d){const _0x461074=_0x46b8ab[_0x3e1700++],_0x12d3fe=_0x46b8ab[_0x3e1700++],_0x59ad45=_0x46b8ab[_0x3e1700++],_0x349abf=((_0x12927c&0x7)<<0x12|(_0x461074&0x3f)<<0xc|(_0x12d3fe&0x3f)<<0x6|_0x59ad45&0x3f)-0x10000;_0x113001[_0x575117++]=String['fromCharCode'](0xd800+(_0x349abf>>0xa)),_0x113001[_0x575117++]=String['fromCharCode'](0xdc00+(_0x349abf&0x3ff));}else{const _0x511ed0=_0x46b8ab[_0x3e1700++],_0xe70d2a=_0x46b8ab[_0x3e1700++];_0x113001[_0x575117++]=String['fromCharCode']((_0x12927c&0xf)<<0xc|(_0x511ed0&0x3f)<<0x6|_0xe70d2a&0x3f);}}}}return _0x113001['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x133d60,_0xf95d){if(!Array['isArray'](_0x133d60))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1b0615=_0xf95d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5bdf67=[];for(let _0x44cb67=0x0;_0x44cb67<_0x133d60['length'];_0x44cb67+=0x3){const _0x38013d=_0x133d60[_0x44cb67],_0x291800=_0x44cb67+0x1<_0x133d60['length'],_0xd5e687=_0x291800?_0x133d60[_0x44cb67+0x1]:0x0,_0x34d3b2=_0x44cb67+0x2<_0x133d60['length'],_0x5240a2=_0x34d3b2?_0x133d60[_0x44cb67+0x2]:0x0,_0x4f66e4=_0x38013d>>0x2,_0x4d3dba=(_0x38013d&0x3)<<0x4|_0xd5e687>>0x4;let _0x2fd586=(_0xd5e687&0xf)<<0x2|_0x5240a2>>0x6,_0x44f3ce=_0x5240a2&0x3f;_0x34d3b2||(_0x44f3ce=0x40,_0x291800||(_0x2fd586=0x40)),_0x5bdf67['push'](_0x1b0615[_0x4f66e4],_0x1b0615[_0x4d3dba],_0x1b0615[_0x2fd586],_0x1b0615[_0x44f3ce]);}return _0x5bdf67['join']('');},'encodeString'(_0xb77f35,_0x7bea9){return this['HAS_NATIVE_SUPPORT']&&!_0x7bea9?btoa(_0xb77f35):this['encodeByteArray'](Wr(_0xb77f35),_0x7bea9);},'decodeString'(_0x24044e,_0x2a7d61){return this['HAS_NATIVE_SUPPORT']&&!_0x2a7d61?atob(_0x24044e):Za(this['decodeStringToByteArray'](_0x24044e,_0x2a7d61));},'decodeStringToByteArray'(_0x94fa88,_0x252ed5){this['init_']();const _0x562fc4=_0x252ed5?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3e2fa2=[];for(let _0x6a5f9d=0x0;_0x6a5f9d<_0x94fa88['length'];){const _0x5f3c5a=_0x562fc4[_0x94fa88['charAt'](_0x6a5f9d++)],_0x31b6a3=_0x6a5f9d<_0x94fa88['length']?_0x562fc4[_0x94fa88['charAt'](_0x6a5f9d)]:0x0;++_0x6a5f9d;const _0x4b1ccd=_0x6a5f9d<_0x94fa88['length']?_0x562fc4[_0x94fa88['charAt'](_0x6a5f9d)]:0x40;++_0x6a5f9d;const _0x3c5e81=_0x6a5f9d<_0x94fa88['length']?_0x562fc4[_0x94fa88['charAt'](_0x6a5f9d)]:0x40;if(++_0x6a5f9d,_0x5f3c5a==null||_0x31b6a3==null||_0x4b1ccd==null||_0x3c5e81==null)throw new ec();const _0x2351d5=_0x5f3c5a<<0x2|_0x31b6a3>>0x4;if(_0x3e2fa2['push'](_0x2351d5),_0x4b1ccd!==0x40){const _0x19e4f9=_0x31b6a3<<0x4&0xf0|_0x4b1ccd>>0x2;if(_0x3e2fa2['push'](_0x19e4f9),_0x3c5e81!==0x40){const _0x490e04=_0x4b1ccd<<0x6&0xc0|_0x3c5e81;_0x3e2fa2['push'](_0x490e04);}}}return _0x3e2fa2;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x27c30e=0x0;_0x27c30e<this['ENCODED_VALS']['length'];_0x27c30e++)this['byteToCharMap_'][_0x27c30e]=this['ENCODED_VALS']['charAt'](_0x27c30e),this['charToByteMap_'][this['byteToCharMap_'][_0x27c30e]]=_0x27c30e,this['byteToCharMapWebSafe_'][_0x27c30e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x27c30e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x27c30e]]=_0x27c30e,_0x27c30e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x27c30e)]=_0x27c30e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x27c30e)]=_0x27c30e);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x196002){const _0x1081a2=Wr(_0x196002);return Di['encodeByteArray'](_0x1081a2,!0x0);},an=function(_0x1c7a72){return Br(_0x1c7a72)['replace'](/\./g,'');},cn=function(_0x264a5a){try{return Di['decodeString'](_0x264a5a,!0x0);}catch(_0x491798){console['error']('base64Decode\x20failed:\x20',_0x491798);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x4fcfbc){return Vr(void 0x0,_0x4fcfbc);}function Vr(_0x591906,_0x23bb13){if(!(_0x23bb13 instanceof Object))return _0x23bb13;switch(_0x23bb13['constructor']){case Date:const _0x53a3a4=_0x23bb13;return new Date(_0x53a3a4['getTime']());case Object:_0x591906===void 0x0&&(_0x591906={});break;case Array:_0x591906=[];break;default:return _0x23bb13;}for(const _0x3c9f4b in _0x23bb13)!_0x23bb13['hasOwnProperty'](_0x3c9f4b)||!nc(_0x3c9f4b)||(_0x591906[_0x3c9f4b]=Vr(_0x591906[_0x3c9f4b],_0x23bb13[_0x3c9f4b]));return _0x591906;}function nc(_0x5ba683){return _0x5ba683!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x8aab38=As['__FIREBASE_DEFAULTS__'];if(_0x8aab38)return JSON['parse'](_0x8aab38);},oc=()=>{if(typeof document>'u')return;let _0x406b6b;try{_0x406b6b=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x22fda2=_0x406b6b&&cn(_0x406b6b[0x1]);return _0x22fda2&&JSON['parse'](_0x22fda2);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4e97c5){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4e97c5);return;}},Hr=_0x38ea06=>{var _0x2d3979,_0x5d3ed5;return(_0x5d3ed5=(_0x2d3979=Mi())==null?void 0x0:_0x2d3979['emulatorHosts'])==null?void 0x0:_0x5d3ed5[_0x38ea06];},ac=_0x2d13be=>{const _0xb7b77a=Hr(_0x2d13be);if(!_0xb7b77a)return;const _0x597eb5=_0xb7b77a['lastIndexOf'](':');if(_0x597eb5<=0x0||_0x597eb5+0x1===_0xb7b77a['length'])throw new Error('Invalid\x20host\x20'+_0xb7b77a+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2fd8cc=parseInt(_0xb7b77a['substring'](_0x597eb5+0x1),0xa);return _0xb7b77a[0x0]==='['?[_0xb7b77a['substring'](0x1,_0x597eb5-0x1),_0x2fd8cc]:[_0xb7b77a['substring'](0x0,_0x597eb5),_0x2fd8cc];},$r=()=>{var _0x5f4e0e;return(_0x5f4e0e=Mi())==null?void 0x0:_0x5f4e0e['config'];},Gr=_0x2d4ab3=>{var _0x43fa99;return(_0x43fa99=Mi())==null?void 0x0:_0x43fa99['_'+_0x2d4ab3];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x352c62,_0x6f0f0b)=>{this['resolve']=_0x352c62,this['reject']=_0x6f0f0b;});}['wrapCallback'](_0x299472){return(_0x320d74,_0xa9b4d2)=>{_0x320d74?this['reject'](_0x320d74):this['resolve'](_0xa9b4d2),typeof _0x299472=='function'&&(this['promise']['catch'](()=>{}),_0x299472['length']===0x1?_0x299472(_0x320d74):_0x299472(_0x320d74,_0xa9b4d2));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x2dc4ae,_0x4f5ca9){if(_0x2dc4ae['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3a7c16={'alg':'none','type':'JWT'},_0x2d0e57=_0x4f5ca9||'demo-project',_0x1997ee=_0x2dc4ae['iat']||0x0,_0x3aa3a6=_0x2dc4ae['sub']||_0x2dc4ae['user_id'];if(!_0x3aa3a6)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x515345={'iss':'https://securetoken.google.com/'+_0x2d0e57,'aud':_0x2d0e57,'iat':_0x1997ee,'exp':_0x1997ee+0xe10,'auth_time':_0x1997ee,'sub':_0x3aa3a6,'user_id':_0x3aa3a6,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2dc4ae};return[an(JSON['stringify'](_0x3a7c16)),an(JSON['stringify'](_0x515345)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x5aed0f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5aed0f=='object'&&_0x5aed0f['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x4bda54=W();return _0x4bda54['indexOf']('MSIE\x20')>=0x0||_0x4bda54['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x19d032,_0x3c1485)=>{try{let _0x30dab6=!0x0;const _0x297ef1='validate-browser-context-for-indexeddb-analytics-module',_0x38cc79=self['indexedDB']['open'](_0x297ef1);_0x38cc79['onsuccess']=()=>{_0x38cc79['result']['close'](),_0x30dab6||self['indexedDB']['deleteDatabase'](_0x297ef1),_0x19d032(!0x0);},_0x38cc79['onupgradeneeded']=()=>{_0x30dab6=!0x1;},_0x38cc79['onerror']=()=>{var _0x428053;_0x3c1485(((_0x428053=_0x38cc79['error'])==null?void 0x0:_0x428053['message'])||'');};}catch(_0x3a4b34){_0x3c1485(_0x3a4b34);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x4f857,_0x27535b,_0x337742){super(_0x27535b),this['code']=_0x4f857,this['customData']=_0x337742,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4e9e90,_0x18bebe,_0x3484d5){this['service']=_0x4e9e90,this['serviceName']=_0x18bebe,this['errors']=_0x3484d5;}['create'](_0x4dc24a,..._0x1e4e51){const _0x47d720=_0x1e4e51[0x0]||{},_0x3363a9=this['service']+'/'+_0x4dc24a,_0x57f595=this['errors'][_0x4dc24a],_0x29657b=_0x57f595?gc(_0x57f595,_0x47d720):'Error',_0x10a802=this['serviceName']+':\x20'+_0x29657b+'\x20('+_0x3363a9+').';return new Se(_0x3363a9,_0x10a802,_0x47d720);}}function gc(_0x4cd04c,_0x4c1c97){return _0x4cd04c['replace'](mc,(_0x15b0ad,_0x49d602)=>{const _0x1c0b0d=_0x4c1c97[_0x49d602];return _0x1c0b0d!=null?String(_0x1c0b0d):'<'+_0x49d602+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4e1b8d){return JSON['parse'](_0x4e1b8d);}function O(_0x7ca5ef){return JSON['stringify'](_0x7ca5ef);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x5bbbdd){let _0x3a74c1={},_0x5d4ac5={},_0x2f2e96={},_0xfb50a9='';try{const _0x396ae4=_0x5bbbdd['split']('.');_0x3a74c1=bt(cn(_0x396ae4[0x0])||''),_0x5d4ac5=bt(cn(_0x396ae4[0x1])||''),_0xfb50a9=_0x396ae4[0x2],_0x2f2e96=_0x5d4ac5['d']||{},delete _0x5d4ac5['d'];}catch{}return{'header':_0x3a74c1,'claims':_0x5d4ac5,'data':_0x2f2e96,'signature':_0xfb50a9};},yc=function(_0x101753){const _0x2c1fd2=zr(_0x101753),_0x64d2e6=_0x2c1fd2['claims'];return!!_0x64d2e6&&typeof _0x64d2e6=='object'&&_0x64d2e6['hasOwnProperty']('iat');},vc=function(_0x2478c6){const _0x406d7b=zr(_0x2478c6)['claims'];return typeof _0x406d7b=='object'&&_0x406d7b['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x196b27,_0x3d3b5f){return Object['prototype']['hasOwnProperty']['call'](_0x196b27,_0x3d3b5f);}function Oe(_0x19228f,_0x21705e){if(Object['prototype']['hasOwnProperty']['call'](_0x19228f,_0x21705e))return _0x19228f[_0x21705e];}function hi(_0x40a01e){for(const _0x291f88 in _0x40a01e)if(Object['prototype']['hasOwnProperty']['call'](_0x40a01e,_0x291f88))return!0x1;return!0x0;}function ln(_0xef51ce,_0x4848b6,_0x31aa73){const _0x1bac58={};for(const _0x1caf8c in _0xef51ce)Object['prototype']['hasOwnProperty']['call'](_0xef51ce,_0x1caf8c)&&(_0x1bac58[_0x1caf8c]=_0x4848b6['call'](_0x31aa73,_0xef51ce[_0x1caf8c],_0x1caf8c,_0xef51ce));return _0x1bac58;}function De(_0x42bea3,_0x36f408){if(_0x42bea3===_0x36f408)return!0x0;const _0x3e21f3=Object['keys'](_0x42bea3),_0x5bd323=Object['keys'](_0x36f408);for(const _0x664830 of _0x3e21f3){if(!_0x5bd323['includes'](_0x664830))return!0x1;const _0x6bb144=_0x42bea3[_0x664830],_0x435be1=_0x36f408[_0x664830];if(ks(_0x6bb144)&&ks(_0x435be1)){if(!De(_0x6bb144,_0x435be1))return!0x1;}else{if(_0x6bb144!==_0x435be1)return!0x1;}}for(const _0x2f9d0f of _0x5bd323)if(!_0x3e21f3['includes'](_0x2f9d0f))return!0x1;return!0x0;}function ks(_0x16bdb4){return _0x16bdb4!==null&&typeof _0x16bdb4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x438f65){const _0x399831=[];for(const [_0x43d7b9,_0x15a20e]of Object['entries'](_0x438f65))Array['isArray'](_0x15a20e)?_0x15a20e['forEach'](_0x3f93ff=>{_0x399831['push'](encodeURIComponent(_0x43d7b9)+'='+encodeURIComponent(_0x3f93ff));}):_0x399831['push'](encodeURIComponent(_0x43d7b9)+'='+encodeURIComponent(_0x15a20e));return _0x399831['length']?'&'+_0x399831['join']('&'):'';}function yt(_0x40827b){const _0x1cc031={};return _0x40827b['replace'](/^\?/,'')['split']('&')['forEach'](_0x130408=>{if(_0x130408){const [_0x1dd05e,_0x262c47]=_0x130408['split']('=');_0x1cc031[decodeURIComponent(_0x1dd05e)]=decodeURIComponent(_0x262c47);}}),_0x1cc031;}function vt(_0x3f9913){const _0x5f1a64=_0x3f9913['indexOf']('?');if(!_0x5f1a64)return'';const _0x380a70=_0x3f9913['indexOf']('#',_0x5f1a64);return _0x3f9913['substring'](_0x5f1a64,_0x380a70>0x0?_0x380a70:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x366490=0x1;_0x366490<this['blockSize'];++_0x366490)this['pad_'][_0x366490]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x303f7d,_0x2eeee6){_0x2eeee6||(_0x2eeee6=0x0);const _0x47952b=this['W_'];if(typeof _0x303f7d=='string'){for(let _0x4343ee=0x0;_0x4343ee<0x10;_0x4343ee++)_0x47952b[_0x4343ee]=_0x303f7d['charCodeAt'](_0x2eeee6)<<0x18|_0x303f7d['charCodeAt'](_0x2eeee6+0x1)<<0x10|_0x303f7d['charCodeAt'](_0x2eeee6+0x2)<<0x8|_0x303f7d['charCodeAt'](_0x2eeee6+0x3),_0x2eeee6+=0x4;}else{for(let _0x5f08bd=0x0;_0x5f08bd<0x10;_0x5f08bd++)_0x47952b[_0x5f08bd]=_0x303f7d[_0x2eeee6]<<0x18|_0x303f7d[_0x2eeee6+0x1]<<0x10|_0x303f7d[_0x2eeee6+0x2]<<0x8|_0x303f7d[_0x2eeee6+0x3],_0x2eeee6+=0x4;}for(let _0x1ca0e6=0x10;_0x1ca0e6<0x50;_0x1ca0e6++){const _0x17d80f=_0x47952b[_0x1ca0e6-0x3]^_0x47952b[_0x1ca0e6-0x8]^_0x47952b[_0x1ca0e6-0xe]^_0x47952b[_0x1ca0e6-0x10];_0x47952b[_0x1ca0e6]=(_0x17d80f<<0x1|_0x17d80f>>>0x1f)&0xffffffff;}let _0x6b4824=this['chain_'][0x0],_0x4e517a=this['chain_'][0x1],_0x25119b=this['chain_'][0x2],_0x5ca679=this['chain_'][0x3],_0x2f199a=this['chain_'][0x4],_0x1ce3de,_0x312ffe;for(let _0x2c0490=0x0;_0x2c0490<0x50;_0x2c0490++){_0x2c0490<0x28?_0x2c0490<0x14?(_0x1ce3de=_0x5ca679^_0x4e517a&(_0x25119b^_0x5ca679),_0x312ffe=0x5a827999):(_0x1ce3de=_0x4e517a^_0x25119b^_0x5ca679,_0x312ffe=0x6ed9eba1):_0x2c0490<0x3c?(_0x1ce3de=_0x4e517a&_0x25119b|_0x5ca679&(_0x4e517a|_0x25119b),_0x312ffe=0x8f1bbcdc):(_0x1ce3de=_0x4e517a^_0x25119b^_0x5ca679,_0x312ffe=0xca62c1d6);const _0x34991b=(_0x6b4824<<0x5|_0x6b4824>>>0x1b)+_0x1ce3de+_0x2f199a+_0x312ffe+_0x47952b[_0x2c0490]&0xffffffff;_0x2f199a=_0x5ca679,_0x5ca679=_0x25119b,_0x25119b=(_0x4e517a<<0x1e|_0x4e517a>>>0x2)&0xffffffff,_0x4e517a=_0x6b4824,_0x6b4824=_0x34991b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x6b4824&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4e517a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x25119b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5ca679&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2f199a&0xffffffff;}['update'](_0x137aaa,_0x22e661){if(_0x137aaa==null)return;_0x22e661===void 0x0&&(_0x22e661=_0x137aaa['length']);const _0x5e5d71=_0x22e661-this['blockSize'];let _0x407601=0x0;const _0x167c26=this['buf_'];let _0x16d961=this['inbuf_'];for(;_0x407601<_0x22e661;){if(_0x16d961===0x0){for(;_0x407601<=_0x5e5d71;)this['compress_'](_0x137aaa,_0x407601),_0x407601+=this['blockSize'];}if(typeof _0x137aaa=='string'){for(;_0x407601<_0x22e661;)if(_0x167c26[_0x16d961]=_0x137aaa['charCodeAt'](_0x407601),++_0x16d961,++_0x407601,_0x16d961===this['blockSize']){this['compress_'](_0x167c26),_0x16d961=0x0;break;}}else{for(;_0x407601<_0x22e661;)if(_0x167c26[_0x16d961]=_0x137aaa[_0x407601],++_0x16d961,++_0x407601,_0x16d961===this['blockSize']){this['compress_'](_0x167c26),_0x16d961=0x0;break;}}}this['inbuf_']=_0x16d961,this['total_']+=_0x22e661;}['digest'](){const _0x123774=[];let _0x194212=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x25cbfe=this['blockSize']-0x1;_0x25cbfe>=0x38;_0x25cbfe--)this['buf_'][_0x25cbfe]=_0x194212&0xff,_0x194212/=0x100;this['compress_'](this['buf_']);let _0x32f4ac=0x0;for(let _0xa0841d=0x0;_0xa0841d<0x5;_0xa0841d++)for(let _0x39359e=0x18;_0x39359e>=0x0;_0x39359e-=0x8)_0x123774[_0x32f4ac]=this['chain_'][_0xa0841d]>>_0x39359e&0xff,++_0x32f4ac;return _0x123774;}}function Ic(_0x5973aa,_0x344f0b){const _0x6b00f9=new wc(_0x5973aa,_0x344f0b);return _0x6b00f9['subscribe']['bind'](_0x6b00f9);}class wc{constructor(_0x55a666,_0x53cb0b){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x53cb0b,this['task']['then'](()=>{_0x55a666(this);})['catch'](_0x4b8627=>{this['error'](_0x4b8627);});}['next'](_0x292a70){this['forEachObserver'](_0x4813d2=>{_0x4813d2['next'](_0x292a70);});}['error'](_0x3b13cb){this['forEachObserver'](_0x394405=>{_0x394405['error'](_0x3b13cb);}),this['close'](_0x3b13cb);}['complete'](){this['forEachObserver'](_0x41dc08=>{_0x41dc08['complete']();}),this['close']();}['subscribe'](_0x448432,_0xa07f71,_0x4a2cdb){let _0x11dc81;if(_0x448432===void 0x0&&_0xa07f71===void 0x0&&_0x4a2cdb===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x448432,['next','error','complete'])?_0x11dc81=_0x448432:_0x11dc81={'next':_0x448432,'error':_0xa07f71,'complete':_0x4a2cdb},_0x11dc81['next']===void 0x0&&(_0x11dc81['next']=Qn),_0x11dc81['error']===void 0x0&&(_0x11dc81['error']=Qn),_0x11dc81['complete']===void 0x0&&(_0x11dc81['complete']=Qn);const _0x1a60f6=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x11dc81['error'](this['finalError']):_0x11dc81['complete']();}catch{}}),this['observers']['push'](_0x11dc81),_0x1a60f6;}['unsubscribeOne'](_0x406e51){this['observers']===void 0x0||this['observers'][_0x406e51]===void 0x0||(delete this['observers'][_0x406e51],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x54e2ab){if(!this['finalized']){for(let _0x355929=0x0;_0x355929<this['observers']['length'];_0x355929++)this['sendOne'](_0x355929,_0x54e2ab);}}['sendOne'](_0x406d6d,_0x24519f){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x406d6d]!==void 0x0)try{_0x24519f(this['observers'][_0x406d6d]);}catch(_0x287c41){typeof console<'u'&&console['error']&&console['error'](_0x287c41);}});}['close'](_0x1a5716){this['finalized']||(this['finalized']=!0x0,_0x1a5716!==void 0x0&&(this['finalError']=_0x1a5716),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1f44cd,_0x1c74f3){if(typeof _0x1f44cd!='object'||_0x1f44cd===null)return!0x1;for(const _0x105328 of _0x1c74f3)if(_0x105328 in _0x1f44cd&&typeof _0x1f44cd[_0x105328]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x1d0bce,_0xd4abaa){return _0x1d0bce+'\x20failed:\x20'+_0xd4abaa+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0xf957cc){const _0x1ccfa3=[];let _0x11ec45=0x0;for(let _0x3986c5=0x0;_0x3986c5<_0xf957cc['length'];_0x3986c5++){let _0x471e60=_0xf957cc['charCodeAt'](_0x3986c5);if(_0x471e60>=0xd800&&_0x471e60<=0xdbff){const _0x3e35c6=_0x471e60-0xd800;_0x3986c5++,f(_0x3986c5<_0xf957cc['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x276f60=_0xf957cc['charCodeAt'](_0x3986c5)-0xdc00;_0x471e60=0x10000+(_0x3e35c6<<0xa)+_0x276f60;}_0x471e60<0x80?_0x1ccfa3[_0x11ec45++]=_0x471e60:_0x471e60<0x800?(_0x1ccfa3[_0x11ec45++]=_0x471e60>>0x6|0xc0,_0x1ccfa3[_0x11ec45++]=_0x471e60&0x3f|0x80):_0x471e60<0x10000?(_0x1ccfa3[_0x11ec45++]=_0x471e60>>0xc|0xe0,_0x1ccfa3[_0x11ec45++]=_0x471e60>>0x6&0x3f|0x80,_0x1ccfa3[_0x11ec45++]=_0x471e60&0x3f|0x80):(_0x1ccfa3[_0x11ec45++]=_0x471e60>>0x12|0xf0,_0x1ccfa3[_0x11ec45++]=_0x471e60>>0xc&0x3f|0x80,_0x1ccfa3[_0x11ec45++]=_0x471e60>>0x6&0x3f|0x80,_0x1ccfa3[_0x11ec45++]=_0x471e60&0x3f|0x80);}return _0x1ccfa3;},Pn=function(_0x38539c){let _0x2fc625=0x0;for(let _0x552255=0x0;_0x552255<_0x38539c['length'];_0x552255++){const _0x19429a=_0x38539c['charCodeAt'](_0x552255);_0x19429a<0x80?_0x2fc625++:_0x19429a<0x800?_0x2fc625+=0x2:_0x19429a>=0xd800&&_0x19429a<=0xdbff?(_0x2fc625+=0x4,_0x552255++):_0x2fc625+=0x3;}return _0x2fc625;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x23857d){return _0x23857d&&_0x23857d['_delegate']?_0x23857d['_delegate']:_0x23857d;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x25695e){try{return(_0x25695e['startsWith']('http://')||_0x25695e['startsWith']('https://')?new URL(_0x25695e)['hostname']:_0x25695e)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x2de5be){return(await fetch(_0x2de5be,{'credentials':'include'}))['ok'];}class Me{constructor(_0x115e63,_0x42990d,_0x2439e5){this['name']=_0x115e63,this['instanceFactory']=_0x42990d,this['type']=_0x2439e5,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4a6534){return this['instantiationMode']=_0x4a6534,this;}['setMultipleInstances'](_0x256419){return this['multipleInstances']=_0x256419,this;}['setServiceProps'](_0x2526e0){return this['serviceProps']=_0x2526e0,this;}['setInstanceCreatedCallback'](_0x5e79c4){return this['onInstanceCreated']=_0x5e79c4,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x67cd9,_0x4f3b8b){this['name']=_0x67cd9,this['container']=_0x4f3b8b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x25af6a){const _0x587219=this['normalizeInstanceIdentifier'](_0x25af6a);if(!this['instancesDeferred']['has'](_0x587219)){const _0x11c591=new Ve();if(this['instancesDeferred']['set'](_0x587219,_0x11c591),this['isInitialized'](_0x587219)||this['shouldAutoInitialize']())try{const _0x47105d=this['getOrInitializeService']({'instanceIdentifier':_0x587219});_0x47105d&&_0x11c591['resolve'](_0x47105d);}catch{}}return this['instancesDeferred']['get'](_0x587219)['promise'];}['getImmediate'](_0x2046d9){const _0x4ddb1e=this['normalizeInstanceIdentifier'](_0x2046d9==null?void 0x0:_0x2046d9['identifier']),_0x526b76=(_0x2046d9==null?void 0x0:_0x2046d9['optional'])??!0x1;if(this['isInitialized'](_0x4ddb1e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4ddb1e});}catch(_0xbe9971){if(_0x526b76)return null;throw _0xbe9971;}else{if(_0x526b76)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3802c8){if(_0x3802c8['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3802c8['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3802c8,!!this['shouldAutoInitialize']()){if(Rc(_0x3802c8))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1ae0ef,_0x16b376]of this['instancesDeferred']['entries']()){const _0x2a777f=this['normalizeInstanceIdentifier'](_0x1ae0ef);try{const _0xb96d64=this['getOrInitializeService']({'instanceIdentifier':_0x2a777f});_0x16b376['resolve'](_0xb96d64);}catch{}}}}['clearInstance'](_0x8fe2a4=ke){this['instancesDeferred']['delete'](_0x8fe2a4),this['instancesOptions']['delete'](_0x8fe2a4),this['instances']['delete'](_0x8fe2a4);}async['delete'](){const _0x28b63b=Array['from'](this['instances']['values']());await Promise['all']([..._0x28b63b['filter'](_0x360dde=>'INTERNAL'in _0x360dde)['map'](_0x33bc5b=>_0x33bc5b['INTERNAL']['delete']()),..._0x28b63b['filter'](_0x470108=>'_delete'in _0x470108)['map'](_0x1af381=>_0x1af381['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x31ecb6=ke){return this['instances']['has'](_0x31ecb6);}['getOptions'](_0x12a3e5=ke){return this['instancesOptions']['get'](_0x12a3e5)||{};}['initialize'](_0x1e6d61={}){const {options:_0x26fd00={}}=_0x1e6d61,_0x329c3c=this['normalizeInstanceIdentifier'](_0x1e6d61['instanceIdentifier']);if(this['isInitialized'](_0x329c3c))throw Error(this['name']+'('+_0x329c3c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3022fe=this['getOrInitializeService']({'instanceIdentifier':_0x329c3c,'options':_0x26fd00});for(const [_0xb8730f,_0x523248]of this['instancesDeferred']['entries']()){const _0x39a2e2=this['normalizeInstanceIdentifier'](_0xb8730f);_0x329c3c===_0x39a2e2&&_0x523248['resolve'](_0x3022fe);}return _0x3022fe;}['onInit'](_0x4e80a2,_0x39995e){const _0x1a62ab=this['normalizeInstanceIdentifier'](_0x39995e),_0x1a52a7=this['onInitCallbacks']['get'](_0x1a62ab)??new Set();_0x1a52a7['add'](_0x4e80a2),this['onInitCallbacks']['set'](_0x1a62ab,_0x1a52a7);const _0x34a0d3=this['instances']['get'](_0x1a62ab);return _0x34a0d3&&_0x4e80a2(_0x34a0d3,_0x1a62ab),()=>{_0x1a52a7['delete'](_0x4e80a2);};}['invokeOnInitCallbacks'](_0x30b94d,_0x8804e7){const _0x7de2e=this['onInitCallbacks']['get'](_0x8804e7);if(_0x7de2e){for(const _0x11791b of _0x7de2e)try{_0x11791b(_0x30b94d,_0x8804e7);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4a92ec,options:_0x780da9={}}){let _0x14db52=this['instances']['get'](_0x4a92ec);if(!_0x14db52&&this['component']&&(_0x14db52=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4a92ec),'options':_0x780da9}),this['instances']['set'](_0x4a92ec,_0x14db52),this['instancesOptions']['set'](_0x4a92ec,_0x780da9),this['invokeOnInitCallbacks'](_0x14db52,_0x4a92ec),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4a92ec,_0x14db52);}catch{}return _0x14db52||null;}['normalizeInstanceIdentifier'](_0x261417=ke){return this['component']?this['component']['multipleInstances']?_0x261417:ke:_0x261417;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2b63fe){return _0x2b63fe===ke?void 0x0:_0x2b63fe;}function Rc(_0x1511b1){return _0x1511b1['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4323b8){this['name']=_0x4323b8,this['providers']=new Map();}['addComponent'](_0x495386){const _0x5e3532=this['getProvider'](_0x495386['name']);if(_0x5e3532['isComponentSet']())throw new Error('Component\x20'+_0x495386['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5e3532['setComponent'](_0x495386);}['addOrOverwriteComponent'](_0x128c5e){this['getProvider'](_0x128c5e['name'])['isComponentSet']()&&this['providers']['delete'](_0x128c5e['name']),this['addComponent'](_0x128c5e);}['getProvider'](_0x48d2bd){if(this['providers']['has'](_0x48d2bd))return this['providers']['get'](_0x48d2bd);const _0x51d6a1=new Sc(_0x48d2bd,this);return this['providers']['set'](_0x48d2bd,_0x51d6a1),_0x51d6a1;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x72fbf0){_0x72fbf0[_0x72fbf0['DEBUG']=0x0]='DEBUG',_0x72fbf0[_0x72fbf0['VERBOSE']=0x1]='VERBOSE',_0x72fbf0[_0x72fbf0['INFO']=0x2]='INFO',_0x72fbf0[_0x72fbf0['WARN']=0x3]='WARN',_0x72fbf0[_0x72fbf0['ERROR']=0x4]='ERROR',_0x72fbf0[_0x72fbf0['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xb7979a,_0x2aba52,..._0x489784)=>{if(_0x2aba52<_0xb7979a['logLevel'])return;const _0x41bd89=new Date()['toISOString'](),_0x12181b=Pc[_0x2aba52];if(_0x12181b)console[_0x12181b]('['+_0x41bd89+']\x20\x20'+_0xb7979a['name']+':',..._0x489784);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2aba52+')');};class xi{constructor(_0x4ba1e5){this['name']=_0x4ba1e5,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x442c20){if(!(_0x442c20 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x442c20+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x442c20;}['setLogLevel'](_0x224ef9){this['_logLevel']=typeof _0x224ef9=='string'?kc[_0x224ef9]:_0x224ef9;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x438a80){if(typeof _0x438a80!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x438a80;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x23d7b3){this['_userLogHandler']=_0x23d7b3;}['debug'](..._0x58fbb7){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x58fbb7),this['_logHandler'](this,T['DEBUG'],..._0x58fbb7);}['log'](..._0x4893be){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4893be),this['_logHandler'](this,T['VERBOSE'],..._0x4893be);}['info'](..._0x3f0967){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3f0967),this['_logHandler'](this,T['INFO'],..._0x3f0967);}['warn'](..._0x45ad2c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x45ad2c),this['_logHandler'](this,T['WARN'],..._0x45ad2c);}['error'](..._0x27c06c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x27c06c),this['_logHandler'](this,T['ERROR'],..._0x27c06c);}}const Dc=(_0x18dc10,_0x85883e)=>_0x85883e['some'](_0xf0dc0=>_0x18dc10 instanceof _0xf0dc0);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x347391){const _0x850527=new Promise((_0x267fc9,_0x5d512c)=>{const _0x136b5e=()=>{_0x347391['removeEventListener']('success',_0x1d234f),_0x347391['removeEventListener']('error',_0x2a6493);},_0x1d234f=()=>{_0x267fc9(_e(_0x347391['result'])),_0x136b5e();},_0x2a6493=()=>{_0x5d512c(_0x347391['error']),_0x136b5e();};_0x347391['addEventListener']('success',_0x1d234f),_0x347391['addEventListener']('error',_0x2a6493);});return _0x850527['then'](_0x4e1cbb=>{_0x4e1cbb instanceof IDBCursor&&Kr['set'](_0x4e1cbb,_0x347391);})['catch'](()=>{}),Fi['set'](_0x850527,_0x347391),_0x850527;}function Fc(_0x3525d6){if(ui['has'](_0x3525d6))return;const _0x56e5ef=new Promise((_0x430b78,_0x471934)=>{const _0xf64726=()=>{_0x3525d6['removeEventListener']('complete',_0x50c84b),_0x3525d6['removeEventListener']('error',_0x23de70),_0x3525d6['removeEventListener']('abort',_0x23de70);},_0x50c84b=()=>{_0x430b78(),_0xf64726();},_0x23de70=()=>{_0x471934(_0x3525d6['error']||new DOMException('AbortError','AbortError')),_0xf64726();};_0x3525d6['addEventListener']('complete',_0x50c84b),_0x3525d6['addEventListener']('error',_0x23de70),_0x3525d6['addEventListener']('abort',_0x23de70);});ui['set'](_0x3525d6,_0x56e5ef);}let di={'get'(_0x49ce1b,_0x23f6be,_0x179c56){if(_0x49ce1b instanceof IDBTransaction){if(_0x23f6be==='done')return ui['get'](_0x49ce1b);if(_0x23f6be==='objectStoreNames')return _0x49ce1b['objectStoreNames']||Yr['get'](_0x49ce1b);if(_0x23f6be==='store')return _0x179c56['objectStoreNames'][0x1]?void 0x0:_0x179c56['objectStore'](_0x179c56['objectStoreNames'][0x0]);}return _e(_0x49ce1b[_0x23f6be]);},'set'(_0x4bc734,_0x56dcf4,_0x56610d){return _0x4bc734[_0x56dcf4]=_0x56610d,!0x0;},'has'(_0x372028,_0x50cf52){return _0x372028 instanceof IDBTransaction&&(_0x50cf52==='done'||_0x50cf52==='store')?!0x0:_0x50cf52 in _0x372028;}};function Uc(_0x185be8){di=_0x185be8(di);}function Wc(_0x32bd26){return _0x32bd26===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x203f47,..._0x241768){const _0x27d62f=_0x32bd26['call'](Xn(this),_0x203f47,..._0x241768);return Yr['set'](_0x27d62f,_0x203f47['sort']?_0x203f47['sort']():[_0x203f47]),_e(_0x27d62f);}:Lc()['includes'](_0x32bd26)?function(..._0x479e5b){return _0x32bd26['apply'](Xn(this),_0x479e5b),_e(Kr['get'](this));}:function(..._0x512232){return _e(_0x32bd26['apply'](Xn(this),_0x512232));};}function Bc(_0x369bf4){return typeof _0x369bf4=='function'?Wc(_0x369bf4):(_0x369bf4 instanceof IDBTransaction&&Fc(_0x369bf4),Dc(_0x369bf4,Mc())?new Proxy(_0x369bf4,di):_0x369bf4);}function _e(_0x384296){if(_0x384296 instanceof IDBRequest)return xc(_0x384296);if(Jn['has'](_0x384296))return Jn['get'](_0x384296);const _0x3284d5=Bc(_0x384296);return _0x3284d5!==_0x384296&&(Jn['set'](_0x384296,_0x3284d5),Fi['set'](_0x3284d5,_0x384296)),_0x3284d5;}const Xn=_0x3ad89f=>Fi['get'](_0x3ad89f);function Vc(_0x3c0536,_0x4ed56f,{blocked:_0x299b2c,upgrade:_0x5c4755,blocking:_0x17e1f9,terminated:_0x49074e}={}){const _0x3c851d=indexedDB['open'](_0x3c0536,_0x4ed56f),_0x5ecad9=_e(_0x3c851d);return _0x5c4755&&_0x3c851d['addEventListener']('upgradeneeded',_0x158fbd=>{_0x5c4755(_e(_0x3c851d['result']),_0x158fbd['oldVersion'],_0x158fbd['newVersion'],_e(_0x3c851d['transaction']),_0x158fbd);}),_0x299b2c&&_0x3c851d['addEventListener']('blocked',_0x2da94c=>_0x299b2c(_0x2da94c['oldVersion'],_0x2da94c['newVersion'],_0x2da94c)),_0x5ecad9['then'](_0x3cdcae=>{_0x49074e&&_0x3cdcae['addEventListener']('close',()=>_0x49074e()),_0x17e1f9&&_0x3cdcae['addEventListener']('versionchange',_0x4a7de3=>_0x17e1f9(_0x4a7de3['oldVersion'],_0x4a7de3['newVersion'],_0x4a7de3));})['catch'](()=>{}),_0x5ecad9;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x584bb2,_0x1bd21a){if(!(_0x584bb2 instanceof IDBDatabase&&!(_0x1bd21a in _0x584bb2)&&typeof _0x1bd21a=='string'))return;if(Zn['get'](_0x1bd21a))return Zn['get'](_0x1bd21a);const _0x40e9e1=_0x1bd21a['replace'](/FromIndex$/,''),_0x34edf5=_0x1bd21a!==_0x40e9e1,_0x3cf2cb=$c['includes'](_0x40e9e1);if(!(_0x40e9e1 in(_0x34edf5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3cf2cb||Hc['includes'](_0x40e9e1)))return;const _0x581d03=async function(_0x53d5e0,..._0x30b4f3){const _0x255fe8=this['transaction'](_0x53d5e0,_0x3cf2cb?'readwrite':'readonly');let _0x3cba8e=_0x255fe8['store'];return _0x34edf5&&(_0x3cba8e=_0x3cba8e['index'](_0x30b4f3['shift']())),(await Promise['all']([_0x3cba8e[_0x40e9e1](..._0x30b4f3),_0x3cf2cb&&_0x255fe8['done']]))[0x0];};return Zn['set'](_0x1bd21a,_0x581d03),_0x581d03;}Uc(_0x3456ff=>({..._0x3456ff,'get':(_0xacb60f,_0x26be39,_0x60c452)=>Os(_0xacb60f,_0x26be39)||_0x3456ff['get'](_0xacb60f,_0x26be39,_0x60c452),'has':(_0x2b8c8f,_0x1ea2ad)=>!!Os(_0x2b8c8f,_0x1ea2ad)||_0x3456ff['has'](_0x2b8c8f,_0x1ea2ad)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x56b5a5){this['container']=_0x56b5a5;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x22ec65=>{if(qc(_0x22ec65)){const _0x3ceddb=_0x22ec65['getImmediate']();return _0x3ceddb['library']+'/'+_0x3ceddb['version'];}else return null;})['filter'](_0x9c6235=>_0x9c6235)['join']('\x20');}}function qc(_0x20a693){const _0x35f457=_0x20a693['getComponent']();return(_0x35f457==null?void 0x0:_0x35f457['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x5d2079,_0x2c2a80){try{_0x5d2079['container']['addComponent'](_0x2c2a80);}catch(_0x4352bf){re['debug']('Component\x20'+_0x2c2a80['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5d2079['name'],_0x4352bf);}}function et(_0x25a633){const _0x162192=_0x25a633['name'];if(gi['has'](_0x162192))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x162192+'.'),!0x1;gi['set'](_0x162192,_0x25a633);for(const _0x15f62e of Le['values']())Ms(_0x15f62e,_0x25a633);for(const _0x57f94e of _i['values']())Ms(_0x57f94e,_0x25a633);return!0x0;}function Ui(_0x2796e1,_0xe52f17){const _0x19a5ed=_0x2796e1['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x19a5ed&&_0x19a5ed['triggerHeartbeat'](),_0x2796e1['container']['getProvider'](_0xe52f17);}function H(_0x2617d8){return _0x2617d8==null?!0x1:_0x2617d8['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x942ae2,_0x968a1b,_0x38f71c){this['_isDeleted']=!0x1,this['_options']={..._0x942ae2},this['_config']={..._0x968a1b},this['_name']=_0x968a1b['name'],this['_automaticDataCollectionEnabled']=_0x968a1b['automaticDataCollectionEnabled'],this['_container']=_0x38f71c,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xf40ff6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xf40ff6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x10895b){this['_isDeleted']=_0x10895b;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x33d45d,_0x4f5182={}){let _0x3f65fc=_0x33d45d;typeof _0x4f5182!='object'&&(_0x4f5182={'name':_0x4f5182});const _0x19bc81={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4f5182},_0x2c0014=_0x19bc81['name'];if(typeof _0x2c0014!='string'||!_0x2c0014)throw ge['create']('bad-app-name',{'appName':String(_0x2c0014)});if(_0x3f65fc||(_0x3f65fc=$r()),!_0x3f65fc)throw ge['create']('no-options');const _0x2ddd23=Le['get'](_0x2c0014);if(_0x2ddd23){if(De(_0x3f65fc,_0x2ddd23['options'])&&De(_0x19bc81,_0x2ddd23['config']))return _0x2ddd23;throw ge['create']('duplicate-app',{'appName':_0x2c0014});}const _0x2f5cc5=new Ac(_0x2c0014);for(const _0x53c0c9 of gi['values']())_0x2f5cc5['addComponent'](_0x53c0c9);const _0x643419=new Il(_0x3f65fc,_0x19bc81,_0x2f5cc5);return Le['set'](_0x2c0014,_0x643419),_0x643419;}function Qr(_0x5dae03=pi){const _0x57b8d0=Le['get'](_0x5dae03);if(!_0x57b8d0&&_0x5dae03===pi&&$r())return wl();if(!_0x57b8d0)throw ge['create']('no-app',{'appName':_0x5dae03});return _0x57b8d0;}function l_(){return Array['from'](Le['values']());}async function h_(_0x2340e7){let _0x4475c1=!0x1;const _0x3b0d5b=_0x2340e7['name'];Le['has'](_0x3b0d5b)?(_0x4475c1=!0x0,Le['delete'](_0x3b0d5b)):_i['has'](_0x3b0d5b)&&_0x2340e7['decRefCount']()<=0x0&&(_i['delete'](_0x3b0d5b),_0x4475c1=!0x0),_0x4475c1&&(await Promise['all'](_0x2340e7['container']['getProviders']()['map'](_0x2a875d=>_0x2a875d['delete']())),_0x2340e7['isDeleted']=!0x0);}function me(_0x27d186,_0x3408dd,_0xa38fa6){let _0x1ae60c=vl[_0x27d186]??_0x27d186;_0xa38fa6&&(_0x1ae60c+='-'+_0xa38fa6);const _0x2dfcda=_0x1ae60c['match'](/\s|\//),_0x47e94c=_0x3408dd['match'](/\s|\//);if(_0x2dfcda||_0x47e94c){const _0x3dedc0=['Unable\x20to\x20register\x20library\x20\x22'+_0x1ae60c+'\x22\x20with\x20version\x20\x22'+_0x3408dd+'\x22:'];_0x2dfcda&&_0x3dedc0['push']('library\x20name\x20\x22'+_0x1ae60c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2dfcda&&_0x47e94c&&_0x3dedc0['push']('and'),_0x47e94c&&_0x3dedc0['push']('version\x20name\x20\x22'+_0x3408dd+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3dedc0['join']('\x20'));return;}et(new Me(_0x1ae60c+'-version',()=>({'library':_0x1ae60c,'version':_0x3408dd}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x2a9ef0,_0xf5df0b)=>{switch(_0xf5df0b){case 0x0:try{_0x2a9ef0['createObjectStore'](Rt);}catch(_0x3d14d7){console['warn'](_0x3d14d7);}}}})['catch'](_0x165c6b=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x165c6b['message']});})),ei;}async function Sl(_0x372d53){try{const _0x450b9c=(await Jr())['transaction'](Rt),_0x4c2136=await _0x450b9c['objectStore'](Rt)['get'](Xr(_0x372d53));return await _0x450b9c['done'],_0x4c2136;}catch(_0x39c45b){if(_0x39c45b instanceof Se)re['warn'](_0x39c45b['message']);else{const _0xe6f5fb=ge['create']('idb-get',{'originalErrorMessage':_0x39c45b==null?void 0x0:_0x39c45b['message']});re['warn'](_0xe6f5fb['message']);}}}async function Ls(_0x65f70e,_0x43abb0){try{const _0x3dd0a7=(await Jr())['transaction'](Rt,'readwrite');await _0x3dd0a7['objectStore'](Rt)['put'](_0x43abb0,Xr(_0x65f70e)),await _0x3dd0a7['done'];}catch(_0x25b80a){if(_0x25b80a instanceof Se)re['warn'](_0x25b80a['message']);else{const _0x401ef9=ge['create']('idb-set',{'originalErrorMessage':_0x25b80a==null?void 0x0:_0x25b80a['message']});re['warn'](_0x401ef9['message']);}}}function Xr(_0x491740){return _0x491740['name']+'!'+_0x491740['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x26a61e){this['container']=_0x26a61e,this['_heartbeatsCache']=null;const _0x6ef31a=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x6ef31a),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4a9237=>(this['_heartbeatsCache']=_0x4a9237,_0x4a9237));}async['triggerHeartbeat'](){var _0x1fcd97,_0x46bf46;try{const _0x6032b8=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x20e207=xs();if(((_0x1fcd97=this['_heartbeatsCache'])==null?void 0x0:_0x1fcd97['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x46bf46=this['_heartbeatsCache'])==null?void 0x0:_0x46bf46['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x20e207||this['_heartbeatsCache']['heartbeats']['some'](_0x37809a=>_0x37809a['date']===_0x20e207))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x20e207,'agent':_0x6032b8}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1e6279=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1e6279,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5cd408){re['warn'](_0x5cd408);}}async['getHeartbeatsHeader'](){var _0x56627a;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x56627a=this['_heartbeatsCache'])==null?void 0x0:_0x56627a['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x353e6a=xs(),{heartbeatsToSend:_0x697e66,unsentEntries:_0x3df72c}=kl(this['_heartbeatsCache']['heartbeats']),_0x137e55=an(JSON['stringify']({'version':0x2,'heartbeats':_0x697e66}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x353e6a,_0x3df72c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3df72c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x137e55;}catch(_0x1300d0){return re['warn'](_0x1300d0),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x4c8528,_0x290b68=bl){const _0x13f7d7=[];let _0x2b6a2d=_0x4c8528['slice']();for(const _0x4cae8b of _0x4c8528){const _0x4baea1=_0x13f7d7['find'](_0x3cd7df=>_0x3cd7df['agent']===_0x4cae8b['agent']);if(_0x4baea1){if(_0x4baea1['dates']['push'](_0x4cae8b['date']),Fs(_0x13f7d7)>_0x290b68){_0x4baea1['dates']['pop']();break;}}else{if(_0x13f7d7['push']({'agent':_0x4cae8b['agent'],'dates':[_0x4cae8b['date']]}),Fs(_0x13f7d7)>_0x290b68){_0x13f7d7['pop']();break;}}_0x2b6a2d=_0x2b6a2d['slice'](0x1);}return{'heartbeatsToSend':_0x13f7d7,'unsentEntries':_0x2b6a2d};}class Nl{constructor(_0x408fe4){this['app']=_0x408fe4,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5ea5f0=await Sl(this['app']);return _0x5ea5f0!=null&&_0x5ea5f0['heartbeats']?_0x5ea5f0:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3d006a){if(await this['_canUseIndexedDBPromise']){const _0x321832=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3d006a['lastSentHeartbeatDate']??_0x321832['lastSentHeartbeatDate'],'heartbeats':_0x3d006a['heartbeats']});}else return;}async['add'](_0xaa2449){if(await this['_canUseIndexedDBPromise']){const _0x558e93=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0xaa2449['lastSentHeartbeatDate']??_0x558e93['lastSentHeartbeatDate'],'heartbeats':[..._0x558e93['heartbeats'],..._0xaa2449['heartbeats']]});}else return;}}function Fs(_0x257ce4){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x257ce4}))['length'];}function Pl(_0x2f8b89){if(_0x2f8b89['length']===0x0)return-0x1;let _0x5102cd=0x0,_0x5a6082=_0x2f8b89[0x0]['date'];for(let _0x314b32=0x1;_0x314b32<_0x2f8b89['length'];_0x314b32++)_0x2f8b89[_0x314b32]['date']<_0x5a6082&&(_0x5a6082=_0x2f8b89[_0x314b32]['date'],_0x5102cd=_0x314b32);return _0x5102cd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x424750){et(new Me('platform-logger',_0x1afd40=>new Gc(_0x1afd40),'PRIVATE')),et(new Me('heartbeat',_0x400889=>new Al(_0x400889),'PRIVATE')),me(fi,Ds,_0x424750),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x4438f3){Zr=_0x4438f3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x2bd7b8){this['domStorage_']=_0x2bd7b8,this['prefix_']='firebase:';}['set'](_0xe18819,_0x4cea49){_0x4cea49==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xe18819)):this['domStorage_']['setItem'](this['prefixedName_'](_0xe18819),O(_0x4cea49));}['get'](_0x5c620b){const _0xef1efe=this['domStorage_']['getItem'](this['prefixedName_'](_0x5c620b));return _0xef1efe==null?null:bt(_0xef1efe);}['remove'](_0x3b1271){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3b1271));}['prefixedName_'](_0x1eef6c){return this['prefix_']+_0x1eef6c;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x59dacc,_0x5750f9){_0x5750f9==null?delete this['cache_'][_0x59dacc]:this['cache_'][_0x59dacc]=_0x5750f9;}['get'](_0x31987b){return Y(this['cache_'],_0x31987b)?this['cache_'][_0x31987b]:null;}['remove'](_0x2aee25){delete this['cache_'][_0x2aee25];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x4fb6c5){try{if(typeof window<'u'&&typeof window[_0x4fb6c5]<'u'){const _0x4714ed=window[_0x4fb6c5];return _0x4714ed['setItem']('firebase:sentinel','cache'),_0x4714ed['removeItem']('firebase:sentinel'),new xl(_0x4714ed);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0xd2021e=0x1;return function(){return _0xd2021e++;};}()),no=function(_0x1123cd){const _0x436145=Tc(_0x1123cd),_0x4c277d=new Ec();_0x4c277d['update'](_0x436145);const _0x27265f=_0x4c277d['digest']();return Di['encodeByteArray'](_0x27265f);},Bt=function(..._0xad3825){let _0x599060='';for(let _0x5392d9=0x0;_0x5392d9<_0xad3825['length'];_0x5392d9++){const _0x1b1af2=_0xad3825[_0x5392d9];Array['isArray'](_0x1b1af2)||_0x1b1af2&&typeof _0x1b1af2=='object'&&typeof _0x1b1af2['length']=='number'?_0x599060+=Bt['apply'](null,_0x1b1af2):typeof _0x1b1af2=='object'?_0x599060+=O(_0x1b1af2):_0x599060+=_0x1b1af2,_0x599060+='\x20';}return _0x599060;};let Et=null,Vs=!0x0;const Wl=function(_0x1f0b48,_0x28f9c8){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x34b70c){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x205fc0=Bt['apply'](null,_0x34b70c);Et(_0x205fc0);}},Vt=function(_0x1426b0){return function(..._0x14e394){L(_0x1426b0,..._0x14e394);};},mi=function(..._0x15b762){const _0x534882='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x15b762);Qe['error'](_0x534882);},oe=function(..._0x16bc04){const _0x507062='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x16bc04);throw Qe['error'](_0x507062),new Error(_0x507062);},U=function(..._0x2d0071){const _0x4f29ca='FIREBASE\x20WARNING:\x20'+Bt(..._0x2d0071);Qe['warn'](_0x4f29ca);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0xba4dd7){return typeof _0xba4dd7=='number'&&(_0xba4dd7!==_0xba4dd7||_0xba4dd7===Number['POSITIVE_INFINITY']||_0xba4dd7===Number['NEGATIVE_INFINITY']);},Vl=function(_0x37ebf6){if(document['readyState']==='complete')_0x37ebf6();else{let _0x368bba=!0x1;const _0x2d44b6=function(){if(!document['body']){setTimeout(_0x2d44b6,Math['floor'](0xa));return;}_0x368bba||(_0x368bba=!0x0,_0x37ebf6());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2d44b6,!0x1),window['addEventListener']('load',_0x2d44b6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2d44b6();}),window['attachEvent']('onload',_0x2d44b6));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x26e118,_0x14f012){if(_0x26e118===_0x14f012)return 0x0;if(_0x26e118===xe||_0x14f012===Ie)return-0x1;if(_0x14f012===xe||_0x26e118===Ie)return 0x1;{const _0x35e8f8=Hs(_0x26e118),_0x478858=Hs(_0x14f012);return _0x35e8f8!==null?_0x478858!==null?_0x35e8f8-_0x478858===0x0?_0x26e118['length']-_0x14f012['length']:_0x35e8f8-_0x478858:-0x1:_0x478858!==null?0x1:_0x26e118<_0x14f012?-0x1:0x1;}},Hl=function(_0x297017,_0x1f7a83){return _0x297017===_0x1f7a83?0x0:_0x297017<_0x1f7a83?-0x1:0x1;},pt=function(_0x53a960,_0x5669f6){if(_0x5669f6&&_0x53a960 in _0x5669f6)return _0x5669f6[_0x53a960];throw new Error('Missing\x20required\x20key\x20('+_0x53a960+')\x20in\x20object:\x20'+O(_0x5669f6));},Bi=function(_0x25f156){if(typeof _0x25f156!='object'||_0x25f156===null)return O(_0x25f156);const _0x3f19f0=[];for(const _0x3691d5 in _0x25f156)_0x3f19f0['push'](_0x3691d5);_0x3f19f0['sort']();let _0x394798='{';for(let _0x1d2bab=0x0;_0x1d2bab<_0x3f19f0['length'];_0x1d2bab++)_0x1d2bab!==0x0&&(_0x394798+=','),_0x394798+=O(_0x3f19f0[_0x1d2bab]),_0x394798+=':',_0x394798+=Bi(_0x25f156[_0x3f19f0[_0x1d2bab]]);return _0x394798+='}',_0x394798;},io=function(_0x5ee11e,_0x4768b2){const _0x1843c4=_0x5ee11e['length'];if(_0x1843c4<=_0x4768b2)return[_0x5ee11e];const _0x904019=[];for(let _0x37617d=0x0;_0x37617d<_0x1843c4;_0x37617d+=_0x4768b2)_0x37617d+_0x4768b2>_0x1843c4?_0x904019['push'](_0x5ee11e['substring'](_0x37617d,_0x1843c4)):_0x904019['push'](_0x5ee11e['substring'](_0x37617d,_0x37617d+_0x4768b2));return _0x904019;};function x(_0x231df7,_0x596ed8){for(const _0xf8ca7b in _0x231df7)_0x231df7['hasOwnProperty'](_0xf8ca7b)&&_0x596ed8(_0xf8ca7b,_0x231df7[_0xf8ca7b]);}const so=function(_0x5f4a1c){f(!Wi(_0x5f4a1c),'Invalid\x20JSON\x20number');const _0x552d41=0xb,_0x4e0818=0x34,_0x5718e2=(0x1<<_0x552d41-0x1)-0x1;let _0x3e836e,_0xea788f,_0xea4db3,_0x4f4d82,_0x3aa4d3;_0x5f4a1c===0x0?(_0xea788f=0x0,_0xea4db3=0x0,_0x3e836e=0x1/_0x5f4a1c===-0x1/0x0?0x1:0x0):(_0x3e836e=_0x5f4a1c<0x0,_0x5f4a1c=Math['abs'](_0x5f4a1c),_0x5f4a1c>=Math['pow'](0x2,0x1-_0x5718e2)?(_0x4f4d82=Math['min'](Math['floor'](Math['log'](_0x5f4a1c)/Math['LN2']),_0x5718e2),_0xea788f=_0x4f4d82+_0x5718e2,_0xea4db3=Math['round'](_0x5f4a1c*Math['pow'](0x2,_0x4e0818-_0x4f4d82)-Math['pow'](0x2,_0x4e0818))):(_0xea788f=0x0,_0xea4db3=Math['round'](_0x5f4a1c/Math['pow'](0x2,0x1-_0x5718e2-_0x4e0818))));const _0x371b40=[];for(_0x3aa4d3=_0x4e0818;_0x3aa4d3;_0x3aa4d3-=0x1)_0x371b40['push'](_0xea4db3%0x2?0x1:0x0),_0xea4db3=Math['floor'](_0xea4db3/0x2);for(_0x3aa4d3=_0x552d41;_0x3aa4d3;_0x3aa4d3-=0x1)_0x371b40['push'](_0xea788f%0x2?0x1:0x0),_0xea788f=Math['floor'](_0xea788f/0x2);_0x371b40['push'](_0x3e836e?0x1:0x0),_0x371b40['reverse']();const _0x7465be=_0x371b40['join']('');let _0x5e12ae='';for(_0x3aa4d3=0x0;_0x3aa4d3<0x40;_0x3aa4d3+=0x8){let _0x1e68f7=parseInt(_0x7465be['substr'](_0x3aa4d3,0x8),0x2)['toString'](0x10);_0x1e68f7['length']===0x1&&(_0x1e68f7='0'+_0x1e68f7),_0x5e12ae=_0x5e12ae+_0x1e68f7;}return _0x5e12ae['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x488015,_0x3a6519){let _0x5c863a='Unknown\x20Error';_0x488015==='too_big'?_0x5c863a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x488015==='permission_denied'?_0x5c863a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x488015==='unavailable'&&(_0x5c863a='The\x20service\x20is\x20unavailable');const _0x3b1ed4=new Error(_0x488015+'\x20at\x20'+_0x3a6519['_path']['toString']()+':\x20'+_0x5c863a);return _0x3b1ed4['code']=_0x488015['toUpperCase'](),_0x3b1ed4;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x62fc36){if(zl['test'](_0x62fc36)){const _0x9cd109=Number(_0x62fc36);if(_0x9cd109>=jl&&_0x9cd109<=Kl)return _0x9cd109;}return null;},lt=function(_0x16b99c){try{_0x16b99c();}catch(_0x1c9bce){setTimeout(()=>{const _0x47ba29=_0x1c9bce['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x47ba29),_0x1c9bce;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x2f3811,_0x16cfb1){const _0x2beca6=setTimeout(_0x2f3811,_0x16cfb1);return typeof _0x2beca6=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2beca6):typeof _0x2beca6=='object'&&_0x2beca6['unref']&&_0x2beca6['unref'](),_0x2beca6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x2680ef,_0x51eb48){this['appCheckProvider']=_0x51eb48,this['appName']=_0x2680ef['name'],H(_0x2680ef)&&_0x2680ef['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2680ef['settings']['appCheckToken']),this['appCheck']=_0x51eb48==null?void 0x0:_0x51eb48['getImmediate']({'optional':!0x0}),this['appCheck']||_0x51eb48==null||_0x51eb48['get']()['then'](_0x82089f=>this['appCheck']=_0x82089f);}['getToken'](_0x2a6ebe){if(this['serverAppAppCheckToken']){if(_0x2a6ebe)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2a6ebe):new Promise((_0x1c3e6d,_0x1a9424)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2a6ebe)['then'](_0x1c3e6d,_0x1a9424):_0x1c3e6d(null);},0x0);});}['addTokenChangeListener'](_0x28df41){var _0x48579a;(_0x48579a=this['appCheckProvider'])==null||_0x48579a['get']()['then'](_0x373c50=>_0x373c50['addTokenListener'](_0x28df41));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x3bfcf3,_0x437e5c,_0x5e49eb){this['appName_']=_0x3bfcf3,this['firebaseOptions_']=_0x437e5c,this['authProvider_']=_0x5e49eb,this['auth_']=null,this['auth_']=_0x5e49eb['getImmediate']({'optional':!0x0}),this['auth_']||_0x5e49eb['onInit'](_0x491873=>this['auth_']=_0x491873);}['getToken'](_0x48261c){return this['auth_']?this['auth_']['getToken'](_0x48261c)['catch'](_0x44bbc2=>_0x44bbc2&&_0x44bbc2['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x44bbc2)):new Promise((_0x192396,_0x245d3c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x48261c)['then'](_0x192396,_0x245d3c):_0x192396(null);},0x0);});}['addTokenChangeListener'](_0x366566){this['auth_']?this['auth_']['addAuthTokenListener'](_0x366566):this['authProvider_']['get']()['then'](_0x49416b=>_0x49416b['addAuthTokenListener'](_0x366566));}['removeTokenChangeListener'](_0x512823){this['authProvider_']['get']()['then'](_0x53af83=>_0x53af83['removeAuthTokenListener'](_0x512823));}['notifyForInvalidToken'](){let _0x337693='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x337693+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x337693+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x337693+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x337693);}}class tn{constructor(_0x5220f9){this['accessToken']=_0x5220f9;}['getToken'](_0x4efaa0){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x14eec6){_0x14eec6(this['accessToken']);}['removeTokenChangeListener'](_0x5ceae0){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x574180,_0x12f202,_0x4c9cec,_0x2dcbf6,_0x53b62a=!0x1,_0x108037='',_0x408eb7=!0x1,_0x160dbf=!0x1,_0x26efee=null){this['secure']=_0x12f202,this['namespace']=_0x4c9cec,this['webSocketOnly']=_0x2dcbf6,this['nodeAdmin']=_0x53b62a,this['persistenceKey']=_0x108037,this['includeNamespaceInQueryParams']=_0x408eb7,this['isUsingEmulator']=_0x160dbf,this['emulatorOptions']=_0x26efee,this['_host']=_0x574180['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x574180)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4d9317){_0x4d9317!==this['internalHost']&&(this['internalHost']=_0x4d9317,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x108862=this['toURLString']();return this['persistenceKey']&&(_0x108862+='<'+this['persistenceKey']+'>'),_0x108862;}['toURLString'](){const _0x107cb5=this['secure']?'https://':'http://',_0x2a49b2=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x107cb5+this['host']+'/'+_0x2a49b2;}}function Xl(_0x239e64){return _0x239e64['host']!==_0x239e64['internalHost']||_0x239e64['isCustomHost']()||_0x239e64['includeNamespaceInQueryParams'];}function go(_0x304051,_0x1fc168,_0x4a693e){f(typeof _0x1fc168=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4a693e=='object','typeof\x20params\x20must\x20==\x20object');let _0x11e6f2;if(_0x1fc168===fo)_0x11e6f2=(_0x304051['secure']?'wss://':'ws://')+_0x304051['internalHost']+'/.ws?';else{if(_0x1fc168===po)_0x11e6f2=(_0x304051['secure']?'https://':'http://')+_0x304051['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1fc168);}Xl(_0x304051)&&(_0x4a693e['ns']=_0x304051['namespace']);const _0x3a180d=[];return x(_0x4a693e,(_0x3fc6f8,_0x3977ab)=>{_0x3a180d['push'](_0x3fc6f8+'='+_0x3977ab);}),_0x11e6f2+_0x3a180d['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x239e78,_0x2d7e05=0x1){Y(this['counters_'],_0x239e78)||(this['counters_'][_0x239e78]=0x0),this['counters_'][_0x239e78]+=_0x2d7e05;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x41fbaf){const _0x230231=_0x41fbaf['toString']();return ti[_0x230231]||(ti[_0x230231]=new Zl()),ti[_0x230231];}function eh(_0x512b0d,_0x33fdf9){const _0x265aa7=_0x512b0d['toString']();return ni[_0x265aa7]||(ni[_0x265aa7]=_0x33fdf9()),ni[_0x265aa7];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4f72b0){this['onMessage_']=_0x4f72b0,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x57a840,_0x45c979){this['closeAfterResponse']=_0x57a840,this['onClose']=_0x45c979,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x40b329,_0x329226){for(this['pendingResponses'][_0x40b329]=_0x329226;this['pendingResponses'][this['currentResponseNum']];){const _0x4c7ed2=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1affa0=0x0;_0x1affa0<_0x4c7ed2['length'];++_0x1affa0)_0x4c7ed2[_0x1affa0]&&lt(()=>{this['onMessage_'](_0x4c7ed2[_0x1affa0]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x344dbd,_0xf7e152,_0x442e06,_0x3fc839,_0x46c132,_0x363e29,_0x2cd025){this['connId']=_0x344dbd,this['repoInfo']=_0xf7e152,this['applicationId']=_0x442e06,this['appCheckToken']=_0x3fc839,this['authToken']=_0x46c132,this['transportSessionId']=_0x363e29,this['lastSessionId']=_0x2cd025,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x344dbd),this['stats_']=Hi(_0xf7e152),this['urlFn']=_0x13f76a=>(this['appCheckToken']&&(_0x13f76a[yi]=this['appCheckToken']),go(_0xf7e152,po,_0x13f76a));}['open'](_0x5acd6c,_0x4b4cf9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4b4cf9,this['myPacketOrderer']=new th(_0x5acd6c),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x5f0ef4)=>{const [_0x371b09,_0x487cf9,_0x591a63,_0xa1b771,_0x40d80b]=_0x5f0ef4;if(this['incrementIncomingBytes_'](_0x5f0ef4),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x371b09===$s)this['id']=_0x487cf9,this['password']=_0x591a63;else{if(_0x371b09===nh)_0x487cf9?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x487cf9,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x371b09);}}},(..._0x56c1b5)=>{const [_0x368545,_0x2a302b]=_0x56c1b5;this['incrementIncomingBytes_'](_0x56c1b5),this['myPacketOrderer']['handleResponse'](_0x368545,_0x2a302b);},()=>{this['onClosed_']();},this['urlFn']);const _0x6d7f5a={};_0x6d7f5a[$s]='t',_0x6d7f5a[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x6d7f5a[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x6d7f5a[ro]=Vi,this['transportSessionId']&&(_0x6d7f5a[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x6d7f5a[ho]=this['lastSessionId']),this['applicationId']&&(_0x6d7f5a[uo]=this['applicationId']),this['appCheckToken']&&(_0x6d7f5a[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x6d7f5a[ao]=co);const _0x5836e0=this['urlFn'](_0x6d7f5a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5836e0),this['scriptTagHolder']['addTag'](_0x5836e0,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x28f827){const _0x2bcb88=O(_0x28f827);this['bytesSent']+=_0x2bcb88['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2bcb88['length']);const _0x4bb2e0=Br(_0x2bcb88),_0x572834=io(_0x4bb2e0,hh);for(let _0x42b8e6=0x0;_0x42b8e6<_0x572834['length'];_0x42b8e6++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x572834['length'],_0x572834[_0x42b8e6]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x29902b,_0x4c139d){this['myDisconnFrame']=document['createElement']('iframe');const _0x2745ec={};_0x2745ec[lh]='t',_0x2745ec[mo]=_0x29902b,_0x2745ec[yo]=_0x4c139d,this['myDisconnFrame']['src']=this['urlFn'](_0x2745ec),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xd61494){const _0x22c1b8=O(_0xd61494)['length'];this['bytesReceived']+=_0x22c1b8,this['stats_']['incrementCounter']('bytes_received',_0x22c1b8);}}class $i{constructor(_0x38adbf,_0x18285b,_0x1cdd20,_0x26e97c){this['onDisconnect']=_0x1cdd20,this['urlFn']=_0x26e97c,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x38adbf,window[sh+this['uniqueCallbackIdentifier']]=_0x18285b,this['myIFrame']=$i['createIFrame_']();let _0x53d293='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x53d293='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2d5b56='<html><body>'+_0x53d293+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2d5b56),this['myIFrame']['doc']['close']();}catch(_0x82be53){L('frame\x20writing\x20exception'),_0x82be53['stack']&&L(_0x82be53['stack']),L(_0x82be53);}}}static['createIFrame_'](){const _0x22eeb2=document['createElement']('iframe');if(_0x22eeb2['style']['display']='none',document['body']){document['body']['appendChild'](_0x22eeb2);try{_0x22eeb2['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x22524a=document['domain'];_0x22eeb2['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x22524a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x22eeb2['contentDocument']?_0x22eeb2['doc']=_0x22eeb2['contentDocument']:_0x22eeb2['contentWindow']?_0x22eeb2['doc']=_0x22eeb2['contentWindow']['document']:_0x22eeb2['document']&&(_0x22eeb2['doc']=_0x22eeb2['document']),_0x22eeb2;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x9895c=this['onDisconnect'];_0x9895c&&(this['onDisconnect']=null,_0x9895c());}['startLongPoll'](_0x4beb18,_0x250612){for(this['myID']=_0x4beb18,this['myPW']=_0x250612,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3e030c={};_0x3e030c[mo]=this['myID'],_0x3e030c[yo]=this['myPW'],_0x3e030c[vo]=this['currentSerial'];let _0x3eb39b=this['urlFn'](_0x3e030c),_0x3e94d0='',_0x4788e3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x3e94d0['length']<=Eo;){const _0x798927=this['pendingSegs']['shift']();_0x3e94d0=_0x3e94d0+'&'+oh+_0x4788e3+'='+_0x798927['seg']+'&'+ah+_0x4788e3+'='+_0x798927['ts']+'&'+ch+_0x4788e3+'='+_0x798927['d'],_0x4788e3++;}return _0x3eb39b=_0x3eb39b+_0x3e94d0,this['addLongPollTag_'](_0x3eb39b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x48fecf,_0x4739d7,_0x3a2311){this['pendingSegs']['push']({'seg':_0x48fecf,'ts':_0x4739d7,'d':_0x3a2311}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5b74a1,_0x19a378){this['outstandingRequests']['add'](_0x19a378);const _0xeaf9f2=()=>{this['outstandingRequests']['delete'](_0x19a378),this['newRequest_']();},_0x1b5dcf=setTimeout(_0xeaf9f2,Math['floor'](uh)),_0x4a1444=()=>{clearTimeout(_0x1b5dcf),_0xeaf9f2();};this['addTag'](_0x5b74a1,_0x4a1444);}['addTag'](_0x51eca5,_0x5d5785){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5deb46=this['myIFrame']['doc']['createElement']('script');_0x5deb46['type']='text/javascript',_0x5deb46['async']=!0x0,_0x5deb46['src']=_0x51eca5,_0x5deb46['onload']=_0x5deb46['onreadystatechange']=function(){const _0x4affca=_0x5deb46['readyState'];(!_0x4affca||_0x4affca==='loaded'||_0x4affca==='complete')&&(_0x5deb46['onload']=_0x5deb46['onreadystatechange']=null,_0x5deb46['parentNode']&&_0x5deb46['parentNode']['removeChild'](_0x5deb46),_0x5d5785());},_0x5deb46['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x51eca5),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5deb46);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x3b7bba,_0x39012c,_0x5da787,_0x366104,_0x2f07ec,_0x16d208,_0x23581b){this['connId']=_0x3b7bba,this['applicationId']=_0x5da787,this['appCheckToken']=_0x366104,this['authToken']=_0x2f07ec,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x39012c),this['connURL']=G['connectionURL_'](_0x39012c,_0x16d208,_0x23581b,_0x366104,_0x5da787),this['nodeAdmin']=_0x39012c['nodeAdmin'];}static['connectionURL_'](_0x2c861a,_0x556774,_0x252f15,_0x40547e,_0x5a94cf){const _0x1dd2cf={};return _0x1dd2cf[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1dd2cf[ao]=co),_0x556774&&(_0x1dd2cf[oo]=_0x556774),_0x252f15&&(_0x1dd2cf[ho]=_0x252f15),_0x40547e&&(_0x1dd2cf[yi]=_0x40547e),_0x5a94cf&&(_0x1dd2cf[uo]=_0x5a94cf),go(_0x2c861a,fo,_0x1dd2cf);}['open'](_0x255e42,_0x330b23){this['onDisconnect']=_0x330b23,this['onMessage']=_0x255e42,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x4030dd;dc(),this['mySock']=new hn(this['connURL'],[],_0x4030dd);}catch(_0x151af6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4439b2=_0x151af6['message']||_0x151af6['data'];_0x4439b2&&this['log_'](_0x4439b2),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1771bf=>{this['handleIncomingFrame'](_0x1771bf);},this['mySock']['onerror']=_0x529fab=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x29ea1d=_0x529fab['message']||_0x529fab['data'];_0x29ea1d&&this['log_'](_0x29ea1d),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x57b2bc=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x596542=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x237e25=navigator['userAgent']['match'](_0x596542);_0x237e25&&_0x237e25['length']>0x1&&parseFloat(_0x237e25[0x1])<4.4&&(_0x57b2bc=!0x0);}return!_0x57b2bc&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0xc78568){if(this['frames']['push'](_0xc78568),this['frames']['length']===this['totalFrames']){const _0x255f5d=this['frames']['join']('');this['frames']=null;const _0x3f6447=bt(_0x255f5d);this['onMessage'](_0x3f6447);}}['handleNewFrameCount_'](_0x9b3c5c){this['totalFrames']=_0x9b3c5c,this['frames']=[];}['extractFrameCount_'](_0x114b13){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x114b13['length']<=0x6){const _0x4b0e95=Number(_0x114b13);if(!isNaN(_0x4b0e95))return this['handleNewFrameCount_'](_0x4b0e95),null;}return this['handleNewFrameCount_'](0x1),_0x114b13;}['handleIncomingFrame'](_0xca60a0){if(this['mySock']===null)return;const _0x42c014=_0xca60a0['data'];if(this['bytesReceived']+=_0x42c014['length'],this['stats_']['incrementCounter']('bytes_received',_0x42c014['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x42c014);else{const _0x3616b7=this['extractFrameCount_'](_0x42c014);_0x3616b7!==null&&this['appendFrame_'](_0x3616b7);}}['send'](_0x5365ce){this['resetKeepAlive']();const _0x4903b9=O(_0x5365ce);this['bytesSent']+=_0x4903b9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4903b9['length']);const _0x406d0c=io(_0x4903b9,fh);_0x406d0c['length']>0x1&&this['sendString_'](String(_0x406d0c['length']));for(let _0x35f7a7=0x0;_0x35f7a7<_0x406d0c['length'];_0x35f7a7++)this['sendString_'](_0x406d0c[_0x35f7a7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x56de7e){try{this['mySock']['send'](_0x56de7e);}catch(_0x3f3ab0){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3f3ab0['message']||_0x3f3ab0['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3c0194){this['initTransports_'](_0x3c0194);}['initTransports_'](_0x1ddc38){const _0x44aa07=G&&G['isAvailable']();let _0x744cc0=_0x44aa07&&!G['previouslyFailed']();if(_0x1ddc38['webSocketOnly']&&(_0x44aa07||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x744cc0=!0x0),_0x744cc0)this['transports_']=[G];else{const _0x490144=this['transports_']=[];for(const _0xf9100f of At['ALL_TRANSPORTS'])_0xf9100f&&_0xf9100f['isAvailable']()&&_0x490144['push'](_0xf9100f);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x52e027,_0x144a72,_0xe261d4,_0xaf3ac7,_0x593178,_0x45cc10,_0x19e351,_0x49845e,_0x1a498f,_0x3ab2fd){this['id']=_0x52e027,this['repoInfo_']=_0x144a72,this['applicationId_']=_0xe261d4,this['appCheckToken_']=_0xaf3ac7,this['authToken_']=_0x593178,this['onMessage_']=_0x45cc10,this['onReady_']=_0x19e351,this['onDisconnect_']=_0x49845e,this['onKill_']=_0x1a498f,this['lastSessionId']=_0x3ab2fd,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x144a72),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4f7744=this['transportManager_']['initialTransport']();this['conn_']=new _0x4f7744(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4f7744['responsesRequiredToBeHealthy']||0x0;const _0x34b041=this['connReceiver_'](this['conn_']),_0x4a95e8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x34b041,_0x4a95e8);},Math['floor'](0x0));const _0x504da5=_0x4f7744['healthyTimeout']||0x0;_0x504da5>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x504da5)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x411124){return _0x5016f9=>{_0x411124===this['conn_']?this['onConnectionLost_'](_0x5016f9):_0x411124===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xb83cf3){return _0x3d309e=>{this['state_']!==0x2&&(_0xb83cf3===this['rx_']?this['onPrimaryMessageReceived_'](_0x3d309e):_0xb83cf3===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3d309e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5f200f){const _0x432087={'t':'d','d':_0x5f200f};this['sendData_'](_0x432087);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x487452){if(ii in _0x487452){const _0x27b8a3=_0x487452[ii];_0x27b8a3===js?this['upgradeIfSecondaryHealthy_']():_0x27b8a3===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x27b8a3===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x45d3ea){const _0x4f513f=pt('t',_0x45d3ea),_0x4f52f5=pt('d',_0x45d3ea);if(_0x4f513f==='c')this['onSecondaryControl_'](_0x4f52f5);else{if(_0x4f513f==='d')this['pendingDataMessages']['push'](_0x4f52f5);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4f513f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3a7725){const _0x8cb089=pt('t',_0x3a7725),_0x4c1bae=pt('d',_0x3a7725);_0x8cb089==='c'?this['onControl_'](_0x4c1bae):_0x8cb089==='d'&&this['onDataMessage_'](_0x4c1bae);}['onDataMessage_'](_0x2cab66){this['onPrimaryResponse_'](),this['onMessage_'](_0x2cab66);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x324ce6){const _0x140d45=pt(ii,_0x324ce6);if(Gs in _0x324ce6){const _0x4a0881=_0x324ce6[Gs];if(_0x140d45===Ih){const _0x4e6dbc={..._0x4a0881};this['repoInfo_']['isUsingEmulator']&&(_0x4e6dbc['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4e6dbc);}else{if(_0x140d45===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1a4edc=0x0;_0x1a4edc<this['pendingDataMessages']['length'];++_0x1a4edc)this['onDataMessage_'](this['pendingDataMessages'][_0x1a4edc]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x140d45===vh?this['onConnectionShutdown_'](_0x4a0881):_0x140d45===qs?this['onReset_'](_0x4a0881):_0x140d45===Eh?mi('Server\x20Error:\x20'+_0x4a0881):_0x140d45===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x140d45);}}}['onHandshake_'](_0x13cba5){const _0x334adf=_0x13cba5['ts'],_0x455d31=_0x13cba5['v'],_0x1630b2=_0x13cba5['h'];this['sessionId']=_0x13cba5['s'],this['repoInfo_']['host']=_0x1630b2,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x334adf),Vi!==_0x455d31&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1b4f55=this['transportManager_']['upgradeTransport']();_0x1b4f55&&this['startUpgrade_'](_0x1b4f55);}['startUpgrade_'](_0x150ae4){this['secondaryConn_']=new _0x150ae4(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x150ae4['responsesRequiredToBeHealthy']||0x0;const _0x1d4764=this['connReceiver_'](this['secondaryConn_']),_0x57d3ad=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1d4764,_0x57d3ad),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x21f908){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x21f908),this['repoInfo_']['host']=_0x21f908,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x194f07,_0x5e73de){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x194f07,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5e73de,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x43f336=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x43f336||this['rx_']===_0x43f336)&&this['close']();}['onConnectionLost_'](_0x785c74){this['conn_']=null,!_0x785c74&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xa8167e){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xa8167e),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x52ff3d){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x52ff3d);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x1793ec,_0x32f779,_0x1ad1ab,_0x1499b9){}['merge'](_0x5111b6,_0xa2fcc3,_0x287479,_0x6c5763){}['refreshAuthToken'](_0x1a259b){}['refreshAppCheckToken'](_0x2d258d){}['onDisconnectPut'](_0x4eef08,_0xce4f09,_0x4cba29){}['onDisconnectMerge'](_0x19e765,_0x140097,_0x45cc4f){}['onDisconnectCancel'](_0x45b32f,_0x1e2f1b){}['reportStats'](_0x231706){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x276d9c){this['allowedEvents_']=_0x276d9c,this['listeners_']={},f(Array['isArray'](_0x276d9c)&&_0x276d9c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5489cc,..._0x1529ad){if(Array['isArray'](this['listeners_'][_0x5489cc])){const _0x214e6b=[...this['listeners_'][_0x5489cc]];for(let _0xb8252c=0x0;_0xb8252c<_0x214e6b['length'];_0xb8252c++)_0x214e6b[_0xb8252c]['callback']['apply'](_0x214e6b[_0xb8252c]['context'],_0x1529ad);}}['on'](_0x9ef823,_0x2996c3,_0x1d1811){this['validateEventType_'](_0x9ef823),this['listeners_'][_0x9ef823]=this['listeners_'][_0x9ef823]||[],this['listeners_'][_0x9ef823]['push']({'callback':_0x2996c3,'context':_0x1d1811});const _0x405769=this['getInitialEvent'](_0x9ef823);_0x405769&&_0x2996c3['apply'](_0x1d1811,_0x405769);}['off'](_0x25f83e,_0x13f4a2,_0x866067){this['validateEventType_'](_0x25f83e);const _0x341727=this['listeners_'][_0x25f83e]||[];for(let _0x701678=0x0;_0x701678<_0x341727['length'];_0x701678++)if(_0x341727[_0x701678]['callback']===_0x13f4a2&&(!_0x866067||_0x866067===_0x341727[_0x701678]['context'])){_0x341727['splice'](_0x701678,0x1);return;}}['validateEventType_'](_0x29ba1b){f(this['allowedEvents_']['find'](_0x5d81e2=>_0x5d81e2===_0x29ba1b),'Unknown\x20event:\x20'+_0x29ba1b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x335338){return f(_0x335338==='online','Unknown\x20event\x20type:\x20'+_0x335338),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x32b82b,_0x2dd765){if(_0x2dd765===void 0x0){this['pieces_']=_0x32b82b['split']('/');let _0x431c0f=0x0;for(let _0x2a4b78=0x0;_0x2a4b78<this['pieces_']['length'];_0x2a4b78++)this['pieces_'][_0x2a4b78]['length']>0x0&&(this['pieces_'][_0x431c0f]=this['pieces_'][_0x2a4b78],_0x431c0f++);this['pieces_']['length']=_0x431c0f,this['pieceNum_']=0x0;}else this['pieces_']=_0x32b82b,this['pieceNum_']=_0x2dd765;}['toString'](){let _0x2a6e71='';for(let _0x595aa2=this['pieceNum_'];_0x595aa2<this['pieces_']['length'];_0x595aa2++)this['pieces_'][_0x595aa2]!==''&&(_0x2a6e71+='/'+this['pieces_'][_0x595aa2]);return _0x2a6e71||'/';}}function w(){return new C('');}function y(_0x53979b){return _0x53979b['pieceNum_']>=_0x53979b['pieces_']['length']?null:_0x53979b['pieces_'][_0x53979b['pieceNum_']];}function we(_0x624bd6){return _0x624bd6['pieces_']['length']-_0x624bd6['pieceNum_'];}function b(_0x213f4e){let _0xc38c6b=_0x213f4e['pieceNum_'];return _0xc38c6b<_0x213f4e['pieces_']['length']&&_0xc38c6b++,new C(_0x213f4e['pieces_'],_0xc38c6b);}function Gi(_0x22738f){return _0x22738f['pieceNum_']<_0x22738f['pieces_']['length']?_0x22738f['pieces_'][_0x22738f['pieces_']['length']-0x1]:null;}function Ch(_0x2f9704){let _0x6e7ca4='';for(let _0x1f734a=_0x2f9704['pieceNum_'];_0x1f734a<_0x2f9704['pieces_']['length'];_0x1f734a++)_0x2f9704['pieces_'][_0x1f734a]!==''&&(_0x6e7ca4+='/'+encodeURIComponent(String(_0x2f9704['pieces_'][_0x1f734a])));return _0x6e7ca4||'/';}function kt(_0x592ba2,_0x19f63c=0x0){return _0x592ba2['pieces_']['slice'](_0x592ba2['pieceNum_']+_0x19f63c);}function To(_0x3c39c9){if(_0x3c39c9['pieceNum_']>=_0x3c39c9['pieces_']['length'])return null;const _0x5b6fdc=[];for(let _0x53a961=_0x3c39c9['pieceNum_'];_0x53a961<_0x3c39c9['pieces_']['length']-0x1;_0x53a961++)_0x5b6fdc['push'](_0x3c39c9['pieces_'][_0x53a961]);return new C(_0x5b6fdc,0x0);}function A(_0x2488ef,_0x3e8520){const _0x4e80d6=[];for(let _0xefdf6a=_0x2488ef['pieceNum_'];_0xefdf6a<_0x2488ef['pieces_']['length'];_0xefdf6a++)_0x4e80d6['push'](_0x2488ef['pieces_'][_0xefdf6a]);if(_0x3e8520 instanceof C){for(let _0x23d89a=_0x3e8520['pieceNum_'];_0x23d89a<_0x3e8520['pieces_']['length'];_0x23d89a++)_0x4e80d6['push'](_0x3e8520['pieces_'][_0x23d89a]);}else{const _0x11141b=_0x3e8520['split']('/');for(let _0xa30fdc=0x0;_0xa30fdc<_0x11141b['length'];_0xa30fdc++)_0x11141b[_0xa30fdc]['length']>0x0&&_0x4e80d6['push'](_0x11141b[_0xa30fdc]);}return new C(_0x4e80d6,0x0);}function v(_0xd48d84){return _0xd48d84['pieceNum_']>=_0xd48d84['pieces_']['length'];}function F(_0x1d6174,_0x2f5fdc){const _0x5f3cdf=y(_0x1d6174),_0x2da0d7=y(_0x2f5fdc);if(_0x5f3cdf===null)return _0x2f5fdc;if(_0x5f3cdf===_0x2da0d7)return F(b(_0x1d6174),b(_0x2f5fdc));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2f5fdc+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1d6174+')');}function Th(_0x2bca0d,_0x1ca1ce){const _0x2ec83a=kt(_0x2bca0d,0x0),_0x2fd4b1=kt(_0x1ca1ce,0x0);for(let _0x26a7bd=0x0;_0x26a7bd<_0x2ec83a['length']&&_0x26a7bd<_0x2fd4b1['length'];_0x26a7bd++){const _0x1e8c80=He(_0x2ec83a[_0x26a7bd],_0x2fd4b1[_0x26a7bd]);if(_0x1e8c80!==0x0)return _0x1e8c80;}return _0x2ec83a['length']===_0x2fd4b1['length']?0x0:_0x2ec83a['length']<_0x2fd4b1['length']?-0x1:0x1;}function qi(_0x4f6913,_0x11ef64){if(we(_0x4f6913)!==we(_0x11ef64))return!0x1;for(let _0x5b2167=_0x4f6913['pieceNum_'],_0x3feb1d=_0x11ef64['pieceNum_'];_0x5b2167<=_0x4f6913['pieces_']['length'];_0x5b2167++,_0x3feb1d++)if(_0x4f6913['pieces_'][_0x5b2167]!==_0x11ef64['pieces_'][_0x3feb1d])return!0x1;return!0x0;}function $(_0xe30f24,_0x45c446){let _0x20a520=_0xe30f24['pieceNum_'],_0x1aef01=_0x45c446['pieceNum_'];if(we(_0xe30f24)>we(_0x45c446))return!0x1;for(;_0x20a520<_0xe30f24['pieces_']['length'];){if(_0xe30f24['pieces_'][_0x20a520]!==_0x45c446['pieces_'][_0x1aef01])return!0x1;++_0x20a520,++_0x1aef01;}return!0x0;}class Sh{constructor(_0x3624d3,_0x29df2f){this['errorPrefix_']=_0x29df2f,this['parts_']=kt(_0x3624d3,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4a8f4d=0x0;_0x4a8f4d<this['parts_']['length'];_0x4a8f4d++)this['byteLength_']+=Pn(this['parts_'][_0x4a8f4d]);So(this);}}function bh(_0x9bba41,_0x535b33){_0x9bba41['parts_']['length']>0x0&&(_0x9bba41['byteLength_']+=0x1),_0x9bba41['parts_']['push'](_0x535b33),_0x9bba41['byteLength_']+=Pn(_0x535b33),So(_0x9bba41);}function Rh(_0xdc5877){const _0x2db9ac=_0xdc5877['parts_']['pop']();_0xdc5877['byteLength_']-=Pn(_0x2db9ac),_0xdc5877['parts_']['length']>0x0&&(_0xdc5877['byteLength_']-=0x1);}function So(_0x535ff9){if(_0x535ff9['byteLength_']>Js)throw new Error(_0x535ff9['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x535ff9['byteLength_']+').');if(_0x535ff9['parts_']['length']>Qs)throw new Error(_0x535ff9['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x535ff9));}function Ne(_0x3f9631){return _0x3f9631['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3f9631['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3829f5,_0x2786f0;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2786f0='visibilitychange',_0x3829f5='hidden'):typeof document['mozHidden']<'u'?(_0x2786f0='mozvisibilitychange',_0x3829f5='mozHidden'):typeof document['msHidden']<'u'?(_0x2786f0='msvisibilitychange',_0x3829f5='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2786f0='webkitvisibilitychange',_0x3829f5='webkitHidden')),this['visible_']=!0x0,_0x2786f0&&document['addEventListener'](_0x2786f0,()=>{const _0x12038d=!document[_0x3829f5];_0x12038d!==this['visible_']&&(this['visible_']=_0x12038d,this['trigger']('visible',_0x12038d));},!0x1);}['getInitialEvent'](_0x3bb561){return f(_0x3bb561==='visible','Unknown\x20event\x20type:\x20'+_0x3bb561),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x2637b2,_0x161b80,_0x2a6bca,_0x32a95d,_0xe6d4fd,_0xfe3010,_0x54413a,_0x359830){if(super(),this['repoInfo_']=_0x2637b2,this['applicationId_']=_0x161b80,this['onDataUpdate_']=_0x2a6bca,this['onConnectStatus_']=_0x32a95d,this['onServerInfoUpdate_']=_0xe6d4fd,this['authTokenProvider_']=_0xfe3010,this['appCheckTokenProvider_']=_0x54413a,this['authOverride_']=_0x359830,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x359830)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2637b2['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x434308,_0x3ec85d,_0xa9cdc3){const _0xcfc65c=++this['requestNumber_'],_0x4d0328={'r':_0xcfc65c,'a':_0x434308,'b':_0x3ec85d};this['log_'](O(_0x4d0328)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4d0328),_0xa9cdc3&&(this['requestCBHash_'][_0xcfc65c]=_0xa9cdc3);}['get'](_0x5566a4){this['initConnection_']();const _0x150ed9=new Ve(),_0x17a959={'action':'g','request':{'p':_0x5566a4['_path']['toString'](),'q':_0x5566a4['_queryObject']},'onComplete':_0x31d710=>{const _0x559e4e=_0x31d710['d'];_0x31d710['s']==='ok'?_0x150ed9['resolve'](_0x559e4e):_0x150ed9['reject'](_0x559e4e);}};this['outstandingGets_']['push'](_0x17a959),this['outstandingGetCount_']++;const _0x5f1ca0=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5f1ca0),_0x150ed9['promise'];}['listen'](_0x35a294,_0x3b3ae4,_0x3f4bd1,_0xaee4a4){this['initConnection_']();const _0x5a9001=_0x35a294['_queryIdentifier'],_0x1c3ac2=_0x35a294['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1c3ac2+'\x20'+_0x5a9001),this['listens']['has'](_0x1c3ac2)||this['listens']['set'](_0x1c3ac2,new Map()),f(_0x35a294['_queryParams']['isDefault']()||!_0x35a294['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1c3ac2)['has'](_0x5a9001),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x39ad6a={'onComplete':_0xaee4a4,'hashFn':_0x3b3ae4,'query':_0x35a294,'tag':_0x3f4bd1};this['listens']['get'](_0x1c3ac2)['set'](_0x5a9001,_0x39ad6a),this['connected_']&&this['sendListen_'](_0x39ad6a);}['sendGet_'](_0x2be92a){const _0x247770=this['outstandingGets_'][_0x2be92a];this['sendRequest']('g',_0x247770['request'],_0x2e32c3=>{delete this['outstandingGets_'][_0x2be92a],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x247770['onComplete']&&_0x247770['onComplete'](_0x2e32c3);});}['sendListen_'](_0x40a5c1){const _0x39e0b3=_0x40a5c1['query'],_0x201ca1=_0x39e0b3['_path']['toString'](),_0x100717=_0x39e0b3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x201ca1+'\x20for\x20'+_0x100717);const _0x5a6179={'p':_0x201ca1},_0x498af4='q';_0x40a5c1['tag']&&(_0x5a6179['q']=_0x39e0b3['_queryObject'],_0x5a6179['t']=_0x40a5c1['tag']),_0x5a6179['h']=_0x40a5c1['hashFn'](),this['sendRequest'](_0x498af4,_0x5a6179,_0x2c3d77=>{const _0x374b68=_0x2c3d77['d'],_0x58326d=_0x2c3d77['s'];ie['warnOnListenWarnings_'](_0x374b68,_0x39e0b3),(this['listens']['get'](_0x201ca1)&&this['listens']['get'](_0x201ca1)['get'](_0x100717))===_0x40a5c1&&(this['log_']('listen\x20response',_0x2c3d77),_0x58326d!=='ok'&&this['removeListen_'](_0x201ca1,_0x100717),_0x40a5c1['onComplete']&&_0x40a5c1['onComplete'](_0x58326d,_0x374b68));});}static['warnOnListenWarnings_'](_0x234d77,_0x2e7095){if(_0x234d77&&typeof _0x234d77=='object'&&Y(_0x234d77,'w')){const _0x27d32f=Oe(_0x234d77,'w');if(Array['isArray'](_0x27d32f)&&~_0x27d32f['indexOf']('no_index')){const _0x16bae7='\x22.indexOn\x22:\x20\x22'+_0x2e7095['_queryParams']['getIndex']()['toString']()+'\x22',_0x2dcd5b=_0x2e7095['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x16bae7+'\x20at\x20'+_0x2dcd5b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x33fd35){this['authToken_']=_0x33fd35,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x33fd35);}['reduceReconnectDelayIfAdminCredential_'](_0x11c6b5){(_0x11c6b5&&_0x11c6b5['length']===0x28||vc(_0x11c6b5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x203e7b){this['appCheckToken_']=_0x203e7b,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x27d543=this['authToken_'],_0x50397d=yc(_0x27d543)?'auth':'gauth',_0x3da0d8={'cred':_0x27d543};this['authOverride_']===null?_0x3da0d8['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3da0d8['authvar']=this['authOverride_']),this['sendRequest'](_0x50397d,_0x3da0d8,_0x35622d=>{const _0x167172=_0x35622d['s'],_0x253f2e=_0x35622d['d']||'error';this['authToken_']===_0x27d543&&(_0x167172==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x167172,_0x253f2e));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x27c40f=>{const _0x4b91fa=_0x27c40f['s'],_0x551ee6=_0x27c40f['d']||'error';_0x4b91fa==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4b91fa,_0x551ee6);});}['unlisten'](_0x28d8db,_0x40990b){const _0x13d1ed=_0x28d8db['_path']['toString'](),_0x1cedae=_0x28d8db['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x13d1ed+'\x20'+_0x1cedae),f(_0x28d8db['_queryParams']['isDefault']()||!_0x28d8db['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x13d1ed,_0x1cedae)&&this['connected_']&&this['sendUnlisten_'](_0x13d1ed,_0x1cedae,_0x28d8db['_queryObject'],_0x40990b);}['sendUnlisten_'](_0x4608de,_0x5662fd,_0xff74da,_0x1029b5){this['log_']('Unlisten\x20on\x20'+_0x4608de+'\x20for\x20'+_0x5662fd);const _0x219117={'p':_0x4608de},_0x1f7cf3='n';_0x1029b5&&(_0x219117['q']=_0xff74da,_0x219117['t']=_0x1029b5),this['sendRequest'](_0x1f7cf3,_0x219117);}['onDisconnectPut'](_0x1edae6,_0x953bfa,_0x20837a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1edae6,_0x953bfa,_0x20837a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1edae6,'action':'o','data':_0x953bfa,'onComplete':_0x20837a});}['onDisconnectMerge'](_0x165427,_0xafabb4,_0x921296){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x165427,_0xafabb4,_0x921296):this['onDisconnectRequestQueue_']['push']({'pathString':_0x165427,'action':'om','data':_0xafabb4,'onComplete':_0x921296});}['onDisconnectCancel'](_0x5c811a,_0x2ce963){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5c811a,null,_0x2ce963):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c811a,'action':'oc','data':null,'onComplete':_0x2ce963});}['sendOnDisconnect_'](_0x529bb9,_0x38cf23,_0x27a749,_0x4a785c){const _0x4f63a4={'p':_0x38cf23,'d':_0x27a749};this['log_']('onDisconnect\x20'+_0x529bb9,_0x4f63a4),this['sendRequest'](_0x529bb9,_0x4f63a4,_0x156119=>{_0x4a785c&&setTimeout(()=>{_0x4a785c(_0x156119['s'],_0x156119['d']);},Math['floor'](0x0));});}['put'](_0x4668ac,_0x5b284c,_0x1fee3f,_0x1fec07){this['putInternal']('p',_0x4668ac,_0x5b284c,_0x1fee3f,_0x1fec07);}['merge'](_0x43548f,_0x35c561,_0x36de70,_0x632b95){this['putInternal']('m',_0x43548f,_0x35c561,_0x36de70,_0x632b95);}['putInternal'](_0x1c12e9,_0x53528c,_0x297eda,_0x14e6a6,_0x293677){this['initConnection_']();const _0x106ea7={'p':_0x53528c,'d':_0x297eda};_0x293677!==void 0x0&&(_0x106ea7['h']=_0x293677),this['outstandingPuts_']['push']({'action':_0x1c12e9,'request':_0x106ea7,'onComplete':_0x14e6a6}),this['outstandingPutCount_']++;const _0x9b188b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x9b188b):this['log_']('Buffering\x20put:\x20'+_0x53528c);}['sendPut_'](_0x1dd6df){const _0x3a6d99=this['outstandingPuts_'][_0x1dd6df]['action'],_0x2e1fba=this['outstandingPuts_'][_0x1dd6df]['request'],_0x2da6bb=this['outstandingPuts_'][_0x1dd6df]['onComplete'];this['outstandingPuts_'][_0x1dd6df]['queued']=this['connected_'],this['sendRequest'](_0x3a6d99,_0x2e1fba,_0x26cfb1=>{this['log_'](_0x3a6d99+'\x20response',_0x26cfb1),delete this['outstandingPuts_'][_0x1dd6df],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2da6bb&&_0x2da6bb(_0x26cfb1['s'],_0x26cfb1['d']);});}['reportStats'](_0x4aa76c){if(this['connected_']){const _0x33dd8e={'c':_0x4aa76c};this['log_']('reportStats',_0x33dd8e),this['sendRequest']('s',_0x33dd8e,_0x3cdb57=>{if(_0x3cdb57['s']!=='ok'){const _0x3a5d9a=_0x3cdb57['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3a5d9a);}});}}['onDataMessage_'](_0x5ee12f){if('r'in _0x5ee12f){this['log_']('from\x20server:\x20'+O(_0x5ee12f));const _0x59ad89=_0x5ee12f['r'],_0x16727e=this['requestCBHash_'][_0x59ad89];_0x16727e&&(delete this['requestCBHash_'][_0x59ad89],_0x16727e(_0x5ee12f['b']));}else{if('error'in _0x5ee12f)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5ee12f['error'];'a'in _0x5ee12f&&this['onDataPush_'](_0x5ee12f['a'],_0x5ee12f['b']);}}['onDataPush_'](_0x34f657,_0x330a6d){this['log_']('handleServerMessage',_0x34f657,_0x330a6d),_0x34f657==='d'?this['onDataUpdate_'](_0x330a6d['p'],_0x330a6d['d'],!0x1,_0x330a6d['t']):_0x34f657==='m'?this['onDataUpdate_'](_0x330a6d['p'],_0x330a6d['d'],!0x0,_0x330a6d['t']):_0x34f657==='c'?this['onListenRevoked_'](_0x330a6d['p'],_0x330a6d['q']):_0x34f657==='ac'?this['onAuthRevoked_'](_0x330a6d['s'],_0x330a6d['d']):_0x34f657==='apc'?this['onAppCheckRevoked_'](_0x330a6d['s'],_0x330a6d['d']):_0x34f657==='sd'?this['onSecurityDebugPacket_'](_0x330a6d):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x34f657)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3b5611,_0x532607){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3b5611),this['lastSessionId']=_0x532607,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x270418){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x270418));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x31b42b){_0x31b42b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x31b42b;}['onOnline_'](_0x5476a6){_0x5476a6?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x42ce05=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5cd783=Math['max'](0x0,this['reconnectDelay_']-_0x42ce05);_0x5cd783=Math['random']()*_0x5cd783,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5cd783+'ms'),this['scheduleConnect_'](_0x5cd783),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5c8ad4=this['onDataMessage_']['bind'](this),_0x325c06=this['onReady_']['bind'](this),_0xd87c2d=this['onRealtimeDisconnect_']['bind'](this),_0x5f10d5=this['id']+':'+ie['nextConnectionId_']++,_0x36f97c=this['lastSessionId'];let _0xe5e039=!0x1,_0x2c913e=null;const _0x8684bc=function(){_0x2c913e?_0x2c913e['close']():(_0xe5e039=!0x0,_0xd87c2d());},_0x1bafff=function(_0x5b1bab){f(_0x2c913e,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2c913e['sendRequest'](_0x5b1bab);};this['realtime_']={'close':_0x8684bc,'sendRequest':_0x1bafff};const _0x5d5b3f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xdad7b8,_0x52f6e8]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5d5b3f),this['appCheckTokenProvider_']['getToken'](_0x5d5b3f)]);_0xe5e039?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xdad7b8&&_0xdad7b8['accessToken'],this['appCheckToken_']=_0x52f6e8&&_0x52f6e8['token'],_0x2c913e=new wh(_0x5f10d5,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5c8ad4,_0x325c06,_0xd87c2d,_0x20912e=>{U(_0x20912e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x36f97c));}catch(_0x3f5f55){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3f5f55),_0xe5e039||(this['repoInfo_']['nodeAdmin']&&U(_0x3f5f55),_0x8684bc());}}}['interrupt'](_0x352818){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x352818),this['interruptReasons_'][_0x352818]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xe90f92){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xe90f92),delete this['interruptReasons_'][_0xe90f92],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3c60c0){const _0x387a72=_0x3c60c0-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x387a72});}['cancelSentTransactions_'](){for(let _0x337ad7=0x0;_0x337ad7<this['outstandingPuts_']['length'];_0x337ad7++){const _0xf4d028=this['outstandingPuts_'][_0x337ad7];_0xf4d028&&'h'in _0xf4d028['request']&&_0xf4d028['queued']&&(_0xf4d028['onComplete']&&_0xf4d028['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x337ad7],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4eb670,_0x5e4520){let _0x2eee3e;_0x5e4520?_0x2eee3e=_0x5e4520['map'](_0x48058a=>Bi(_0x48058a))['join']('$'):_0x2eee3e='default';const _0x411b22=this['removeListen_'](_0x4eb670,_0x2eee3e);_0x411b22&&_0x411b22['onComplete']&&_0x411b22['onComplete']('permission_denied');}['removeListen_'](_0x583b6c,_0x116fe0){const _0x3f2d36=new C(_0x583b6c)['toString']();let _0xf00576;if(this['listens']['has'](_0x3f2d36)){const _0x4a32b9=this['listens']['get'](_0x3f2d36);_0xf00576=_0x4a32b9['get'](_0x116fe0),_0x4a32b9['delete'](_0x116fe0),_0x4a32b9['size']===0x0&&this['listens']['delete'](_0x3f2d36);}else _0xf00576=void 0x0;return _0xf00576;}['onAuthRevoked_'](_0x5cfe1e,_0x3bbcde){L('Auth\x20token\x20revoked:\x20'+_0x5cfe1e+'/'+_0x3bbcde),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5cfe1e==='invalid_token'||_0x5cfe1e==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x50bff3,_0x2b42eb){L('App\x20check\x20token\x20revoked:\x20'+_0x50bff3+'/'+_0x2b42eb),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x50bff3==='invalid_token'||_0x50bff3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x51fa7b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x51fa7b):'msg'in _0x51fa7b&&console['log']('FIREBASE:\x20'+_0x51fa7b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4a5113 of this['listens']['values']())for(const _0x141767 of _0x4a5113['values']())this['sendListen_'](_0x141767);for(let _0x13b52a=0x0;_0x13b52a<this['outstandingPuts_']['length'];_0x13b52a++)this['outstandingPuts_'][_0x13b52a]&&this['sendPut_'](_0x13b52a);for(;this['onDisconnectRequestQueue_']['length'];){const _0xe72178=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xe72178['action'],_0xe72178['pathString'],_0xe72178['data'],_0xe72178['onComplete']);}for(let _0x1526dd=0x0;_0x1526dd<this['outstandingGets_']['length'];_0x1526dd++)this['outstandingGets_'][_0x1526dd]&&this['sendGet_'](_0x1526dd);}['sendConnectStats_'](){const _0x14cfa5={};let _0x3cb8a4='js';_0x14cfa5['sdk.'+_0x3cb8a4+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x14cfa5['framework.cordova']=0x1:qr()&&(_0x14cfa5['framework.reactnative']=0x1),this['reportStats'](_0x14cfa5);}['shouldReconnect_'](){const _0x1253c8=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x1253c8;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x456ebc,_0x255a95){this['name']=_0x456ebc,this['node']=_0x255a95;}static['Wrap'](_0x2eac71,_0x53e815){return new E(_0x2eac71,_0x53e815);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xb85ef5,_0x2bf1d3){const _0x4bb651=new E(xe,_0xb85ef5),_0x2d26f2=new E(xe,_0x2bf1d3);return this['compare'](_0x4bb651,_0x2d26f2)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2df02b){Xt=_0x2df02b;}['compare'](_0x436f7f,_0x3f577f){return He(_0x436f7f['name'],_0x3f577f['name']);}['isDefinedOn'](_0xb29a4c){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4474b0,_0x462025){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x57c975,_0x27d9f7){return f(typeof _0x57c975=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x57c975,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x35cb26,_0x3a56e1,_0x36c81c,_0x13d887,_0x2143bf=null){this['isReverse_']=_0x13d887,this['resultGenerator_']=_0x2143bf,this['nodeStack_']=[];let _0x82d237=0x1;for(;!_0x35cb26['isEmpty']();)if(_0x35cb26=_0x35cb26,_0x82d237=_0x3a56e1?_0x36c81c(_0x35cb26['key'],_0x3a56e1):0x1,_0x13d887&&(_0x82d237*=-0x1),_0x82d237<0x0)this['isReverse_']?_0x35cb26=_0x35cb26['left']:_0x35cb26=_0x35cb26['right'];else{if(_0x82d237===0x0){this['nodeStack_']['push'](_0x35cb26);break;}else this['nodeStack_']['push'](_0x35cb26),this['isReverse_']?_0x35cb26=_0x35cb26['right']:_0x35cb26=_0x35cb26['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1d640e=this['nodeStack_']['pop'](),_0x566586;if(this['resultGenerator_']?_0x566586=this['resultGenerator_'](_0x1d640e['key'],_0x1d640e['value']):_0x566586={'key':_0x1d640e['key'],'value':_0x1d640e['value']},this['isReverse_']){for(_0x1d640e=_0x1d640e['left'];!_0x1d640e['isEmpty']();)this['nodeStack_']['push'](_0x1d640e),_0x1d640e=_0x1d640e['right'];}else{for(_0x1d640e=_0x1d640e['right'];!_0x1d640e['isEmpty']();)this['nodeStack_']['push'](_0x1d640e),_0x1d640e=_0x1d640e['left'];}return _0x566586;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2bc08e=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2bc08e['key'],_0x2bc08e['value']):{'key':_0x2bc08e['key'],'value':_0x2bc08e['value']};}}class M{constructor(_0x4f3ef7,_0x30ab31,_0x31c090,_0xd59837,_0x343546){this['key']=_0x4f3ef7,this['value']=_0x30ab31,this['color']=_0x31c090??M['RED'],this['left']=_0xd59837??B['EMPTY_NODE'],this['right']=_0x343546??B['EMPTY_NODE'];}['copy'](_0x3edd52,_0x2e9986,_0x2db0db,_0x1580ac,_0x462e68){return new M(_0x3edd52??this['key'],_0x2e9986??this['value'],_0x2db0db??this['color'],_0x1580ac??this['left'],_0x462e68??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3d49fc){return this['left']['inorderTraversal'](_0x3d49fc)||!!_0x3d49fc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3d49fc);}['reverseTraversal'](_0x11e62a){return this['right']['reverseTraversal'](_0x11e62a)||_0x11e62a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x11e62a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3b974f,_0x515605,_0x29c934){let _0x156170=this;const _0x16c4a3=_0x29c934(_0x3b974f,_0x156170['key']);return _0x16c4a3<0x0?_0x156170=_0x156170['copy'](null,null,null,_0x156170['left']['insert'](_0x3b974f,_0x515605,_0x29c934),null):_0x16c4a3===0x0?_0x156170=_0x156170['copy'](null,_0x515605,null,null,null):_0x156170=_0x156170['copy'](null,null,null,null,_0x156170['right']['insert'](_0x3b974f,_0x515605,_0x29c934)),_0x156170['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x162762=this;return!_0x162762['left']['isRed_']()&&!_0x162762['left']['left']['isRed_']()&&(_0x162762=_0x162762['moveRedLeft_']()),_0x162762=_0x162762['copy'](null,null,null,_0x162762['left']['removeMin_'](),null),_0x162762['fixUp_']();}['remove'](_0x2a7c5a,_0x58d99f){let _0x14884f,_0xbc45d9;if(_0x14884f=this,_0x58d99f(_0x2a7c5a,_0x14884f['key'])<0x0)!_0x14884f['left']['isEmpty']()&&!_0x14884f['left']['isRed_']()&&!_0x14884f['left']['left']['isRed_']()&&(_0x14884f=_0x14884f['moveRedLeft_']()),_0x14884f=_0x14884f['copy'](null,null,null,_0x14884f['left']['remove'](_0x2a7c5a,_0x58d99f),null);else{if(_0x14884f['left']['isRed_']()&&(_0x14884f=_0x14884f['rotateRight_']()),!_0x14884f['right']['isEmpty']()&&!_0x14884f['right']['isRed_']()&&!_0x14884f['right']['left']['isRed_']()&&(_0x14884f=_0x14884f['moveRedRight_']()),_0x58d99f(_0x2a7c5a,_0x14884f['key'])===0x0){if(_0x14884f['right']['isEmpty']())return B['EMPTY_NODE'];_0xbc45d9=_0x14884f['right']['min_'](),_0x14884f=_0x14884f['copy'](_0xbc45d9['key'],_0xbc45d9['value'],null,null,_0x14884f['right']['removeMin_']());}_0x14884f=_0x14884f['copy'](null,null,null,null,_0x14884f['right']['remove'](_0x2a7c5a,_0x58d99f));}return _0x14884f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5adeb4=this;return _0x5adeb4['right']['isRed_']()&&!_0x5adeb4['left']['isRed_']()&&(_0x5adeb4=_0x5adeb4['rotateLeft_']()),_0x5adeb4['left']['isRed_']()&&_0x5adeb4['left']['left']['isRed_']()&&(_0x5adeb4=_0x5adeb4['rotateRight_']()),_0x5adeb4['left']['isRed_']()&&_0x5adeb4['right']['isRed_']()&&(_0x5adeb4=_0x5adeb4['colorFlip_']()),_0x5adeb4;}['moveRedLeft_'](){let _0x598176=this['colorFlip_']();return _0x598176['right']['left']['isRed_']()&&(_0x598176=_0x598176['copy'](null,null,null,null,_0x598176['right']['rotateRight_']()),_0x598176=_0x598176['rotateLeft_'](),_0x598176=_0x598176['colorFlip_']()),_0x598176;}['moveRedRight_'](){let _0x37c6b4=this['colorFlip_']();return _0x37c6b4['left']['left']['isRed_']()&&(_0x37c6b4=_0x37c6b4['rotateRight_'](),_0x37c6b4=_0x37c6b4['colorFlip_']()),_0x37c6b4;}['rotateLeft_'](){const _0x2b6c53=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2b6c53,null);}['rotateRight_'](){const _0x4056a6=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4056a6);}['colorFlip_'](){const _0x52f2c2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x181629=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x52f2c2,_0x181629);}['checkMaxDepth_'](){const _0x51cfb4=this['check_']();return Math['pow'](0x2,_0x51cfb4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4368d7=this['left']['check_']();if(_0x4368d7!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4368d7+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x58a719,_0x310bcf,_0x5c755b,_0x3723ef,_0x1fcd67){return this;}['insert'](_0x328ae7,_0x195fea,_0x3e1196){return new M(_0x328ae7,_0x195fea,null);}['remove'](_0x285bcb,_0x2cef7e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x50c6d8){return!0x1;}['reverseTraversal'](_0xc87ad6){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x33232f,_0x2e521e=B['EMPTY_NODE']){this['comparator_']=_0x33232f,this['root_']=_0x2e521e;}['insert'](_0x2ab793,_0x58663b){return new B(this['comparator_'],this['root_']['insert'](_0x2ab793,_0x58663b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5c53a8){return new B(this['comparator_'],this['root_']['remove'](_0x5c53a8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x3918c3){let _0x1c5bb6,_0x4255e3=this['root_'];for(;!_0x4255e3['isEmpty']();){if(_0x1c5bb6=this['comparator_'](_0x3918c3,_0x4255e3['key']),_0x1c5bb6===0x0)return _0x4255e3['value'];_0x1c5bb6<0x0?_0x4255e3=_0x4255e3['left']:_0x1c5bb6>0x0&&(_0x4255e3=_0x4255e3['right']);}return null;}['getPredecessorKey'](_0x3731c2){let _0x564704,_0x3e9104=this['root_'],_0x28d672=null;for(;!_0x3e9104['isEmpty']();)if(_0x564704=this['comparator_'](_0x3731c2,_0x3e9104['key']),_0x564704===0x0){if(_0x3e9104['left']['isEmpty']())return _0x28d672?_0x28d672['key']:null;for(_0x3e9104=_0x3e9104['left'];!_0x3e9104['right']['isEmpty']();)_0x3e9104=_0x3e9104['right'];return _0x3e9104['key'];}else _0x564704<0x0?_0x3e9104=_0x3e9104['left']:_0x564704>0x0&&(_0x28d672=_0x3e9104,_0x3e9104=_0x3e9104['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xa2f9f5){return this['root_']['inorderTraversal'](_0xa2f9f5);}['reverseTraversal'](_0x351cc7){return this['root_']['reverseTraversal'](_0x351cc7);}['getIterator'](_0x13d98c){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x13d98c);}['getIteratorFrom'](_0x4d8a46,_0x5c1ab7){return new Zt(this['root_'],_0x4d8a46,this['comparator_'],!0x1,_0x5c1ab7);}['getReverseIteratorFrom'](_0x3bc116,_0x4d8b9c){return new Zt(this['root_'],_0x3bc116,this['comparator_'],!0x0,_0x4d8b9c);}['getReverseIterator'](_0xc54e10){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0xc54e10);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x23ef61,_0x5e9e22){return He(_0x23ef61['name'],_0x5e9e22['name']);}function ji(_0x239700,_0x23b148){return He(_0x239700,_0x23b148);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x2af4d3){vi=_0x2af4d3;}const Ro=function(_0x46ed8e){return typeof _0x46ed8e=='number'?'number:'+so(_0x46ed8e):'string:'+_0x46ed8e;},Ao=function(_0x49c1d0){if(_0x49c1d0['isLeafNode']()){const _0x4aa516=_0x49c1d0['val']();f(typeof _0x4aa516=='string'||typeof _0x4aa516=='number'||typeof _0x4aa516=='object'&&Y(_0x4aa516,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x49c1d0===vi||_0x49c1d0['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x49c1d0===vi||_0x49c1d0['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x2355cd){er=_0x2355cd;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2b49df,_0x353746=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2b49df,this['priorityNode_']=_0x353746,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x12eb5b){return new D(this['value_'],_0x12eb5b);}['getImmediateChild'](_0x5c11d1){return _0x5c11d1==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2dd69d){return v(_0x2dd69d)?this:y(_0x2dd69d)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x49ca1d,_0x141c52){return null;}['updateImmediateChild'](_0x13d334,_0x16f905){return _0x13d334==='.priority'?this['updatePriority'](_0x16f905):_0x16f905['isEmpty']()&&_0x13d334!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x13d334,_0x16f905)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5ce0aa,_0x44a8ad){const _0x3b84c1=y(_0x5ce0aa);return _0x3b84c1===null?_0x44a8ad:_0x44a8ad['isEmpty']()&&_0x3b84c1!=='.priority'?this:(f(_0x3b84c1!=='.priority'||we(_0x5ce0aa)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3b84c1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x5ce0aa),_0x44a8ad)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x20bad5,_0x581f49){return!0x1;}['val'](_0xf67d1b){return _0xf67d1b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x20e8d7='';this['priorityNode_']['isEmpty']()||(_0x20e8d7+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0xa5bbe=typeof this['value_'];_0x20e8d7+=_0xa5bbe+':',_0xa5bbe==='number'?_0x20e8d7+=so(this['value_']):_0x20e8d7+=this['value_'],this['lazyHash_']=no(_0x20e8d7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3b84a8){return _0x3b84a8===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3b84a8 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3b84a8['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3b84a8));}['compareToLeafNode_'](_0x40fa23){const _0x5ce079=typeof _0x40fa23['value_'],_0x553f8f=typeof this['value_'],_0x4c8b52=D['VALUE_TYPE_ORDER']['indexOf'](_0x5ce079),_0x1d00e0=D['VALUE_TYPE_ORDER']['indexOf'](_0x553f8f);return f(_0x4c8b52>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5ce079),f(_0x1d00e0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x553f8f),_0x4c8b52===_0x1d00e0?_0x553f8f==='object'?0x0:this['value_']<_0x40fa23['value_']?-0x1:this['value_']===_0x40fa23['value_']?0x0:0x1:_0x1d00e0-_0x4c8b52;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x23929e){if(_0x23929e===this)return!0x0;if(_0x23929e['isLeafNode']()){const _0x18bbda=_0x23929e;return this['value_']===_0x18bbda['value_']&&this['priorityNode_']['equals'](_0x18bbda['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x74882b){ko=_0x74882b;}function xh(_0x3ed110){No=_0x3ed110;}class Fh extends On{['compare'](_0x1b496d,_0x4e36c3){const _0x51a5bc=_0x1b496d['node']['getPriority'](),_0x1e7446=_0x4e36c3['node']['getPriority'](),_0x5126fc=_0x51a5bc['compareTo'](_0x1e7446);return _0x5126fc===0x0?He(_0x1b496d['name'],_0x4e36c3['name']):_0x5126fc;}['isDefinedOn'](_0x35ac53){return!_0x35ac53['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4a2528,_0x34b7c1){return!_0x4a2528['getPriority']()['equals'](_0x34b7c1['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x47785b,_0x361aaf){const _0x1c46d2=ko(_0x47785b);return new E(_0x361aaf,new D('[PRIORITY-POST]',_0x1c46d2));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x285151){const _0x5ab87b=_0x223c09=>parseInt(Math['log'](_0x223c09)/Uh,0xa),_0x5af210=_0x3541aa=>parseInt(Array(_0x3541aa+0x1)['join']('1'),0x2);this['count']=_0x5ab87b(_0x285151+0x1),this['current_']=this['count']-0x1;const _0xd9e06e=_0x5af210(this['count']);this['bits_']=_0x285151+0x1&_0xd9e06e;}['nextBitIsOne'](){const _0x1506c1=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1506c1;}}const dn=function(_0x595a77,_0x24ed2d,_0x48ba77,_0xd257b){_0x595a77['sort'](_0x24ed2d);const _0x3d4e5b=function(_0x4337d2,_0x3c33b8){const _0x172da4=_0x3c33b8-_0x4337d2;let _0x2956cc,_0x4133c9;if(_0x172da4===0x0)return null;if(_0x172da4===0x1)return _0x2956cc=_0x595a77[_0x4337d2],_0x4133c9=_0x48ba77?_0x48ba77(_0x2956cc):_0x2956cc,new M(_0x4133c9,_0x2956cc['node'],M['BLACK'],null,null);{const _0x474c0b=parseInt(_0x172da4/0x2,0xa)+_0x4337d2,_0x3280e9=_0x3d4e5b(_0x4337d2,_0x474c0b),_0x374956=_0x3d4e5b(_0x474c0b+0x1,_0x3c33b8);return _0x2956cc=_0x595a77[_0x474c0b],_0x4133c9=_0x48ba77?_0x48ba77(_0x2956cc):_0x2956cc,new M(_0x4133c9,_0x2956cc['node'],M['BLACK'],_0x3280e9,_0x374956);}},_0x2f8534=function(_0x594fab){let _0x1435f9=null,_0x20e76d=null,_0x26ab24=_0x595a77['length'];const _0x4ab7d0=function(_0x358e0e,_0x38907e){const _0xc5ced8=_0x26ab24-_0x358e0e,_0x529c1d=_0x26ab24;_0x26ab24-=_0x358e0e;const _0x19b5c5=_0x3d4e5b(_0xc5ced8+0x1,_0x529c1d),_0x3bcb94=_0x595a77[_0xc5ced8],_0x4a0251=_0x48ba77?_0x48ba77(_0x3bcb94):_0x3bcb94;_0x460ac4(new M(_0x4a0251,_0x3bcb94['node'],_0x38907e,null,_0x19b5c5));},_0x460ac4=function(_0x56a5f6){_0x1435f9?(_0x1435f9['left']=_0x56a5f6,_0x1435f9=_0x56a5f6):(_0x20e76d=_0x56a5f6,_0x1435f9=_0x56a5f6);};for(let _0x22bb1d=0x0;_0x22bb1d<_0x594fab['count'];++_0x22bb1d){const _0x48040f=_0x594fab['nextBitIsOne'](),_0x3d49d3=Math['pow'](0x2,_0x594fab['count']-(_0x22bb1d+0x1));_0x48040f?_0x4ab7d0(_0x3d49d3,M['BLACK']):(_0x4ab7d0(_0x3d49d3,M['BLACK']),_0x4ab7d0(_0x3d49d3,M['RED']));}return _0x20e76d;},_0x5dd460=new Wh(_0x595a77['length']),_0x3b6b9b=_0x2f8534(_0x5dd460);return new B(_0xd257b||_0x24ed2d,_0x3b6b9b);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x19e2fe,_0x34c900){this['indexes_']=_0x19e2fe,this['indexSet_']=_0x34c900;}['get'](_0x58e195){const _0x3cbb46=Oe(this['indexes_'],_0x58e195);if(!_0x3cbb46)throw new Error('No\x20index\x20defined\x20for\x20'+_0x58e195);return _0x3cbb46 instanceof B?_0x3cbb46:null;}['hasIndex'](_0x219ebf){return Y(this['indexSet_'],_0x219ebf['toString']());}['addIndex'](_0x3ff8b9,_0x4db1c5){f(_0x3ff8b9!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1c1ad6=[];let _0x512415=!0x1;const _0x4895a3=_0x4db1c5['getIterator'](E['Wrap']);let _0x1c4755=_0x4895a3['getNext']();for(;_0x1c4755;)_0x512415=_0x512415||_0x3ff8b9['isDefinedOn'](_0x1c4755['node']),_0x1c1ad6['push'](_0x1c4755),_0x1c4755=_0x4895a3['getNext']();let _0x409e5f;_0x512415?_0x409e5f=dn(_0x1c1ad6,_0x3ff8b9['getCompare']()):_0x409e5f=je;const _0x3001a1=_0x3ff8b9['toString'](),_0x1971b3={...this['indexSet_']};_0x1971b3[_0x3001a1]=_0x3ff8b9;const _0x57df24={...this['indexes_']};return _0x57df24[_0x3001a1]=_0x409e5f,new ee(_0x57df24,_0x1971b3);}['addToIndexes'](_0x2253bd,_0x443a5c){const _0x23728a=ln(this['indexes_'],(_0x50de2b,_0x5a89fd)=>{const _0x20c200=Oe(this['indexSet_'],_0x5a89fd);if(f(_0x20c200,'Missing\x20index\x20implementation\x20for\x20'+_0x5a89fd),_0x50de2b===je){if(_0x20c200['isDefinedOn'](_0x2253bd['node'])){const _0x404912=[],_0x44f945=_0x443a5c['getIterator'](E['Wrap']);let _0x414a70=_0x44f945['getNext']();for(;_0x414a70;)_0x414a70['name']!==_0x2253bd['name']&&_0x404912['push'](_0x414a70),_0x414a70=_0x44f945['getNext']();return _0x404912['push'](_0x2253bd),dn(_0x404912,_0x20c200['getCompare']());}else return je;}else{const _0x4f9f0b=_0x443a5c['get'](_0x2253bd['name']);let _0x8cefb3=_0x50de2b;return _0x4f9f0b&&(_0x8cefb3=_0x8cefb3['remove'](new E(_0x2253bd['name'],_0x4f9f0b))),_0x8cefb3['insert'](_0x2253bd,_0x2253bd['node']);}});return new ee(_0x23728a,this['indexSet_']);}['removeFromIndexes'](_0xaf1054,_0x5cd80b){const _0x197b95=ln(this['indexes_'],_0x5bcac1=>{if(_0x5bcac1===je)return _0x5bcac1;{const _0x481e07=_0x5cd80b['get'](_0xaf1054['name']);return _0x481e07?_0x5bcac1['remove'](new E(_0xaf1054['name'],_0x481e07)):_0x5bcac1;}});return new ee(_0x197b95,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x123fcf,_0x6adbed,_0x5c0e57){this['children_']=_0x123fcf,this['priorityNode_']=_0x6adbed,this['indexMap_']=_0x5c0e57,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x5bac68){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5bac68,this['indexMap_']);}['getImmediateChild'](_0x3084e3){if(_0x3084e3==='.priority')return this['getPriority']();{const _0x13cb46=this['children_']['get'](_0x3084e3);return _0x13cb46===null?gt:_0x13cb46;}}['getChild'](_0xcdc404){const _0x211d22=y(_0xcdc404);return _0x211d22===null?this:this['getImmediateChild'](_0x211d22)['getChild'](b(_0xcdc404));}['hasChild'](_0x58d6da){return this['children_']['get'](_0x58d6da)!==null;}['updateImmediateChild'](_0x89bf61,_0x5fd6c4){if(f(_0x5fd6c4,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x89bf61==='.priority')return this['updatePriority'](_0x5fd6c4);{const _0x4d0c82=new E(_0x89bf61,_0x5fd6c4);let _0x5d57cc,_0x1c4ef1;_0x5fd6c4['isEmpty']()?(_0x5d57cc=this['children_']['remove'](_0x89bf61),_0x1c4ef1=this['indexMap_']['removeFromIndexes'](_0x4d0c82,this['children_'])):(_0x5d57cc=this['children_']['insert'](_0x89bf61,_0x5fd6c4),_0x1c4ef1=this['indexMap_']['addToIndexes'](_0x4d0c82,this['children_']));const _0x9d6dcb=_0x5d57cc['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5d57cc,_0x9d6dcb,_0x1c4ef1);}}['updateChild'](_0x32b7e0,_0x3c0ecc){const _0x520491=y(_0x32b7e0);if(_0x520491===null)return _0x3c0ecc;{f(y(_0x32b7e0)!=='.priority'||we(_0x32b7e0)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x588083=this['getImmediateChild'](_0x520491)['updateChild'](b(_0x32b7e0),_0x3c0ecc);return this['updateImmediateChild'](_0x520491,_0x588083);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4558e2){if(this['isEmpty']())return null;const _0x11e2ce={};let _0x212af2=0x0,_0x13b3d8=0x0,_0xeb2515=!0x0;if(this['forEachChild'](R,(_0xf6b41e,_0x3acb67)=>{_0x11e2ce[_0xf6b41e]=_0x3acb67['val'](_0x4558e2),_0x212af2++,_0xeb2515&&g['INTEGER_REGEXP_']['test'](_0xf6b41e)?_0x13b3d8=Math['max'](_0x13b3d8,Number(_0xf6b41e)):_0xeb2515=!0x1;}),!_0x4558e2&&_0xeb2515&&_0x13b3d8<0x2*_0x212af2){const _0x24c592=[];for(const _0x518307 in _0x11e2ce)_0x24c592[_0x518307]=_0x11e2ce[_0x518307];return _0x24c592;}else return _0x4558e2&&!this['getPriority']()['isEmpty']()&&(_0x11e2ce['.priority']=this['getPriority']()['val']()),_0x11e2ce;}['hash'](){if(this['lazyHash_']===null){let _0x49dd1b='';this['getPriority']()['isEmpty']()||(_0x49dd1b+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4310be,_0x3b66b1)=>{const _0x22a1a9=_0x3b66b1['hash']();_0x22a1a9!==''&&(_0x49dd1b+=':'+_0x4310be+':'+_0x22a1a9);}),this['lazyHash_']=_0x49dd1b===''?'':no(_0x49dd1b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x65a9df,_0x9b01a7,_0x349734){const _0x338445=this['resolveIndex_'](_0x349734);if(_0x338445){const _0x4b7622=_0x338445['getPredecessorKey'](new E(_0x65a9df,_0x9b01a7));return _0x4b7622?_0x4b7622['name']:null;}else return this['children_']['getPredecessorKey'](_0x65a9df);}['getFirstChildName'](_0x415e93){const _0x1f8ed7=this['resolveIndex_'](_0x415e93);if(_0x1f8ed7){const _0x5cc685=_0x1f8ed7['minKey']();return _0x5cc685&&_0x5cc685['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x11eb7a){const _0xf73f38=this['getFirstChildName'](_0x11eb7a);return _0xf73f38?new E(_0xf73f38,this['children_']['get'](_0xf73f38)):null;}['getLastChildName'](_0x650d13){const _0x4de554=this['resolveIndex_'](_0x650d13);if(_0x4de554){const _0x902b04=_0x4de554['maxKey']();return _0x902b04&&_0x902b04['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x57653f){const _0x112144=this['getLastChildName'](_0x57653f);return _0x112144?new E(_0x112144,this['children_']['get'](_0x112144)):null;}['forEachChild'](_0x18a55b,_0x287c85){const _0x1b15a0=this['resolveIndex_'](_0x18a55b);return _0x1b15a0?_0x1b15a0['inorderTraversal'](_0x4795eb=>_0x287c85(_0x4795eb['name'],_0x4795eb['node'])):this['children_']['inorderTraversal'](_0x287c85);}['getIterator'](_0x1b7153){return this['getIteratorFrom'](_0x1b7153['minPost'](),_0x1b7153);}['getIteratorFrom'](_0x4e98c9,_0x2ed37c){const _0x39706a=this['resolveIndex_'](_0x2ed37c);if(_0x39706a)return _0x39706a['getIteratorFrom'](_0x4e98c9,_0x27c016=>_0x27c016);{const _0x5f32e7=this['children_']['getIteratorFrom'](_0x4e98c9['name'],E['Wrap']);let _0x3a17e2=_0x5f32e7['peek']();for(;_0x3a17e2!=null&&_0x2ed37c['compare'](_0x3a17e2,_0x4e98c9)<0x0;)_0x5f32e7['getNext'](),_0x3a17e2=_0x5f32e7['peek']();return _0x5f32e7;}}['getReverseIterator'](_0x404e5d){return this['getReverseIteratorFrom'](_0x404e5d['maxPost'](),_0x404e5d);}['getReverseIteratorFrom'](_0x3cf96f,_0x2a02a4){const _0x4f6198=this['resolveIndex_'](_0x2a02a4);if(_0x4f6198)return _0x4f6198['getReverseIteratorFrom'](_0x3cf96f,_0x519364=>_0x519364);{const _0x54d65e=this['children_']['getReverseIteratorFrom'](_0x3cf96f['name'],E['Wrap']);let _0x49b344=_0x54d65e['peek']();for(;_0x49b344!=null&&_0x2a02a4['compare'](_0x49b344,_0x3cf96f)>0x0;)_0x54d65e['getNext'](),_0x49b344=_0x54d65e['peek']();return _0x54d65e;}}['compareTo'](_0xbc8025){return this['isEmpty']()?_0xbc8025['isEmpty']()?0x0:-0x1:_0xbc8025['isLeafNode']()||_0xbc8025['isEmpty']()?0x1:_0xbc8025===Ht?-0x1:0x0;}['withIndex'](_0x510640){if(_0x510640===ye||this['indexMap_']['hasIndex'](_0x510640))return this;{const _0x16eb42=this['indexMap_']['addIndex'](_0x510640,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x16eb42);}}['isIndexed'](_0x31b16b){return _0x31b16b===ye||this['indexMap_']['hasIndex'](_0x31b16b);}['equals'](_0x31a077){if(_0x31a077===this)return!0x0;if(_0x31a077['isLeafNode']())return!0x1;{const _0x4ad52=_0x31a077;if(this['getPriority']()['equals'](_0x4ad52['getPriority']())){if(this['children_']['count']()===_0x4ad52['children_']['count']()){const _0x571bbd=this['getIterator'](R),_0x2c0443=_0x4ad52['getIterator'](R);let _0x2ee813=_0x571bbd['getNext'](),_0x8fed62=_0x2c0443['getNext']();for(;_0x2ee813&&_0x8fed62;){if(_0x2ee813['name']!==_0x8fed62['name']||!_0x2ee813['node']['equals'](_0x8fed62['node']))return!0x1;_0x2ee813=_0x571bbd['getNext'](),_0x8fed62=_0x2c0443['getNext']();}return _0x2ee813===null&&_0x8fed62===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x105cd5){return _0x105cd5===ye?null:this['indexMap_']['get'](_0x105cd5['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x27c756){return _0x27c756===this?0x0:0x1;}['equals'](_0x140f27){return _0x140f27===this;}['getPriority'](){return this;}['getImmediateChild'](_0x36fef2){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x26b16d,_0x49dcf1=null){if(_0x26b16d===null)return g['EMPTY_NODE'];if(typeof _0x26b16d=='object'&&'.priority'in _0x26b16d&&(_0x49dcf1=_0x26b16d['.priority']),f(_0x49dcf1===null||typeof _0x49dcf1=='string'||typeof _0x49dcf1=='number'||typeof _0x49dcf1=='object'&&'.sv'in _0x49dcf1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x49dcf1),typeof _0x26b16d=='object'&&'.value'in _0x26b16d&&_0x26b16d['.value']!==null&&(_0x26b16d=_0x26b16d['.value']),typeof _0x26b16d!='object'||'.sv'in _0x26b16d){const _0x31c105=_0x26b16d;return new D(_0x31c105,N(_0x49dcf1));}if(!(_0x26b16d instanceof Array)&&Vh){const _0x5ca7c4=[];let _0x3caf61=!0x1;if(x(_0x26b16d,(_0x320363,_0x3c6d5f)=>{if(_0x320363['substring'](0x0,0x1)!=='.'){const _0xc6a225=N(_0x3c6d5f);_0xc6a225['isEmpty']()||(_0x3caf61=_0x3caf61||!_0xc6a225['getPriority']()['isEmpty'](),_0x5ca7c4['push'](new E(_0x320363,_0xc6a225)));}}),_0x5ca7c4['length']===0x0)return g['EMPTY_NODE'];const _0x4ec545=dn(_0x5ca7c4,Dh,_0x20a2a0=>_0x20a2a0['name'],ji);if(_0x3caf61){const _0xd7bc6d=dn(_0x5ca7c4,R['getCompare']());return new g(_0x4ec545,N(_0x49dcf1),new ee({'.priority':_0xd7bc6d},{'.priority':R}));}else return new g(_0x4ec545,N(_0x49dcf1),ee['Default']);}else{let _0x2dcfa4=g['EMPTY_NODE'];return x(_0x26b16d,(_0x2f38bd,_0x50e6ba)=>{if(Y(_0x26b16d,_0x2f38bd)&&_0x2f38bd['substring'](0x0,0x1)!=='.'){const _0x11ae93=N(_0x50e6ba);(_0x11ae93['isLeafNode']()||!_0x11ae93['isEmpty']())&&(_0x2dcfa4=_0x2dcfa4['updateImmediateChild'](_0x2f38bd,_0x11ae93));}}),_0x2dcfa4['updatePriority'](N(_0x49dcf1));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x5919d8){super(),this['indexPath_']=_0x5919d8,f(!v(_0x5919d8)&&y(_0x5919d8)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x537c26){return _0x537c26['getChild'](this['indexPath_']);}['isDefinedOn'](_0x29ae94){return!_0x29ae94['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xa1bee1,_0xc08569){const _0x49e50c=this['extractChild'](_0xa1bee1['node']),_0x2d0c10=this['extractChild'](_0xc08569['node']),_0x80e243=_0x49e50c['compareTo'](_0x2d0c10);return _0x80e243===0x0?He(_0xa1bee1['name'],_0xc08569['name']):_0x80e243;}['makePost'](_0x579012,_0x71ee0a){const _0x4f4c0d=N(_0x579012),_0x5048ad=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4f4c0d);return new E(_0x71ee0a,_0x5048ad);}['maxPost'](){const _0x24356c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x24356c);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x2f3a0e,_0x32de41){const _0x25e1a3=_0x2f3a0e['node']['compareTo'](_0x32de41['node']);return _0x25e1a3===0x0?He(_0x2f3a0e['name'],_0x32de41['name']):_0x25e1a3;}['isDefinedOn'](_0x11adb0){return!0x0;}['indexedValueChanged'](_0x36a01a,_0x45c624){return!_0x36a01a['equals'](_0x45c624);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x7b2a1f,_0x1cb9a8){const _0x5bfa8b=N(_0x7b2a1f);return new E(_0x1cb9a8,_0x5bfa8b);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x326a04){return{'type':'value','snapshotNode':_0x326a04};}function tt(_0x4af72f,_0x18f073){return{'type':'child_added','snapshotNode':_0x18f073,'childName':_0x4af72f};}function Nt(_0x3639a9,_0x2dd1e4){return{'type':'child_removed','snapshotNode':_0x2dd1e4,'childName':_0x3639a9};}function Pt(_0x3b25af,_0x471e8b,_0x140051){return{'type':'child_changed','snapshotNode':_0x471e8b,'childName':_0x3b25af,'oldSnap':_0x140051};}function $h(_0x110df4,_0x225aec){return{'type':'child_moved','snapshotNode':_0x225aec,'childName':_0x110df4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x3d671b){this['index_']=_0x3d671b;}['updateChild'](_0x3e5930,_0x5a1c12,_0x3a2657,_0x10ce14,_0x5306c9,_0x27b9b1){f(_0x3e5930['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x37ee53=_0x3e5930['getImmediateChild'](_0x5a1c12);return _0x37ee53['getChild'](_0x10ce14)['equals'](_0x3a2657['getChild'](_0x10ce14))&&_0x37ee53['isEmpty']()===_0x3a2657['isEmpty']()||(_0x27b9b1!=null&&(_0x3a2657['isEmpty']()?_0x3e5930['hasChild'](_0x5a1c12)?_0x27b9b1['trackChildChange'](Nt(_0x5a1c12,_0x37ee53)):f(_0x3e5930['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x37ee53['isEmpty']()?_0x27b9b1['trackChildChange'](tt(_0x5a1c12,_0x3a2657)):_0x27b9b1['trackChildChange'](Pt(_0x5a1c12,_0x3a2657,_0x37ee53))),_0x3e5930['isLeafNode']()&&_0x3a2657['isEmpty']())?_0x3e5930:_0x3e5930['updateImmediateChild'](_0x5a1c12,_0x3a2657)['withIndex'](this['index_']);}['updateFullNode'](_0x42f09d,_0x4acb6e,_0x41faba){return _0x41faba!=null&&(_0x42f09d['isLeafNode']()||_0x42f09d['forEachChild'](R,(_0x72095d,_0x174ae1)=>{_0x4acb6e['hasChild'](_0x72095d)||_0x41faba['trackChildChange'](Nt(_0x72095d,_0x174ae1));}),_0x4acb6e['isLeafNode']()||_0x4acb6e['forEachChild'](R,(_0x794dd7,_0x33a0cf)=>{if(_0x42f09d['hasChild'](_0x794dd7)){const _0x2d3c8a=_0x42f09d['getImmediateChild'](_0x794dd7);_0x2d3c8a['equals'](_0x33a0cf)||_0x41faba['trackChildChange'](Pt(_0x794dd7,_0x33a0cf,_0x2d3c8a));}else _0x41faba['trackChildChange'](tt(_0x794dd7,_0x33a0cf));})),_0x4acb6e['withIndex'](this['index_']);}['updatePriority'](_0x16786c,_0x43b9be){return _0x16786c['isEmpty']()?g['EMPTY_NODE']:_0x16786c['updatePriority'](_0x43b9be);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x212590){this['indexedFilter_']=new Yi(_0x212590['getIndex']()),this['index_']=_0x212590['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x212590),this['endPost_']=Ot['getEndPost_'](_0x212590),this['startIsInclusive_']=!_0x212590['startAfterSet_'],this['endIsInclusive_']=!_0x212590['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2d7f3e){const _0x28ba03=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2d7f3e)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2d7f3e)<0x0,_0x52303a=this['endIsInclusive_']?this['index_']['compare'](_0x2d7f3e,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2d7f3e,this['getEndPost']())<0x0;return _0x28ba03&&_0x52303a;}['updateChild'](_0x21d64e,_0x3d50b0,_0x45bdf3,_0x1722a8,_0x12795c,_0xd5f378){return this['matches'](new E(_0x3d50b0,_0x45bdf3))||(_0x45bdf3=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x21d64e,_0x3d50b0,_0x45bdf3,_0x1722a8,_0x12795c,_0xd5f378);}['updateFullNode'](_0x181f51,_0x2fdddc,_0x26c97f){_0x2fdddc['isLeafNode']()&&(_0x2fdddc=g['EMPTY_NODE']);let _0x318c51=_0x2fdddc['withIndex'](this['index_']);_0x318c51=_0x318c51['updatePriority'](g['EMPTY_NODE']);const _0x3d71ed=this;return _0x2fdddc['forEachChild'](R,(_0x2ce901,_0x3c133d)=>{_0x3d71ed['matches'](new E(_0x2ce901,_0x3c133d))||(_0x318c51=_0x318c51['updateImmediateChild'](_0x2ce901,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x181f51,_0x318c51,_0x26c97f);}['updatePriority'](_0x4110d9,_0x2473eb){return _0x4110d9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2faec9){if(_0x2faec9['hasStart']()){const _0x4766eb=_0x2faec9['getIndexStartName']();return _0x2faec9['getIndex']()['makePost'](_0x2faec9['getIndexStartValue'](),_0x4766eb);}else return _0x2faec9['getIndex']()['minPost']();}static['getEndPost_'](_0x2f6925){if(_0x2f6925['hasEnd']()){const _0x405626=_0x2f6925['getIndexEndName']();return _0x2f6925['getIndex']()['makePost'](_0x2f6925['getIndexEndValue'](),_0x405626);}else return _0x2f6925['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x22e73a){this['withinDirectionalStart']=_0x168e35=>this['reverse_']?this['withinEndPost'](_0x168e35):this['withinStartPost'](_0x168e35),this['withinDirectionalEnd']=_0x5424b1=>this['reverse_']?this['withinStartPost'](_0x5424b1):this['withinEndPost'](_0x5424b1),this['withinStartPost']=_0x5e30c1=>{const _0x274fe0=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5e30c1);return this['startIsInclusive_']?_0x274fe0<=0x0:_0x274fe0<0x0;},this['withinEndPost']=_0x1b8654=>{const _0x5d31ab=this['index_']['compare'](_0x1b8654,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5d31ab<=0x0:_0x5d31ab<0x0;},this['rangedFilter_']=new Ot(_0x22e73a),this['index_']=_0x22e73a['getIndex'](),this['limit_']=_0x22e73a['getLimit'](),this['reverse_']=!_0x22e73a['isViewFromLeft'](),this['startIsInclusive_']=!_0x22e73a['startAfterSet_'],this['endIsInclusive_']=!_0x22e73a['endBeforeSet_'];}['updateChild'](_0x5cb611,_0x376f1f,_0x409f5c,_0x16a967,_0x32cf5f,_0x2b93be){return this['rangedFilter_']['matches'](new E(_0x376f1f,_0x409f5c))||(_0x409f5c=g['EMPTY_NODE']),_0x5cb611['getImmediateChild'](_0x376f1f)['equals'](_0x409f5c)?_0x5cb611:_0x5cb611['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5cb611,_0x376f1f,_0x409f5c,_0x16a967,_0x32cf5f,_0x2b93be):this['fullLimitUpdateChild_'](_0x5cb611,_0x376f1f,_0x409f5c,_0x32cf5f,_0x2b93be);}['updateFullNode'](_0x5c99de,_0x50aec3,_0x5d39a0){let _0x3a1b4f;if(_0x50aec3['isLeafNode']()||_0x50aec3['isEmpty']())_0x3a1b4f=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x50aec3['numChildren']()&&_0x50aec3['isIndexed'](this['index_'])){_0x3a1b4f=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x56e2f0;this['reverse_']?_0x56e2f0=_0x50aec3['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x56e2f0=_0x50aec3['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x43795a=0x0;for(;_0x56e2f0['hasNext']()&&_0x43795a<this['limit_'];){const _0x39c379=_0x56e2f0['getNext']();if(this['withinDirectionalStart'](_0x39c379)){if(this['withinDirectionalEnd'](_0x39c379))_0x3a1b4f=_0x3a1b4f['updateImmediateChild'](_0x39c379['name'],_0x39c379['node']),_0x43795a++;else break;}else continue;}}else{_0x3a1b4f=_0x50aec3['withIndex'](this['index_']),_0x3a1b4f=_0x3a1b4f['updatePriority'](g['EMPTY_NODE']);let _0x401f41;this['reverse_']?_0x401f41=_0x3a1b4f['getReverseIterator'](this['index_']):_0x401f41=_0x3a1b4f['getIterator'](this['index_']);let _0x5c910c=0x0;for(;_0x401f41['hasNext']();){const _0x1d59fe=_0x401f41['getNext']();_0x5c910c<this['limit_']&&this['withinDirectionalStart'](_0x1d59fe)&&this['withinDirectionalEnd'](_0x1d59fe)?_0x5c910c++:_0x3a1b4f=_0x3a1b4f['updateImmediateChild'](_0x1d59fe['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5c99de,_0x3a1b4f,_0x5d39a0);}['updatePriority'](_0x51b9bc,_0x4b13c9){return _0x51b9bc;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4593b1,_0x476c36,_0x26743f,_0x456a51,_0x1aae26){let _0x274fac;if(this['reverse_']){const _0xebe80d=this['index_']['getCompare']();_0x274fac=(_0xef2b3,_0x357fc5)=>_0xebe80d(_0x357fc5,_0xef2b3);}else _0x274fac=this['index_']['getCompare']();const _0x10c5d3=_0x4593b1;f(_0x10c5d3['numChildren']()===this['limit_'],'');const _0x2852e4=new E(_0x476c36,_0x26743f),_0x216b85=this['reverse_']?_0x10c5d3['getFirstChild'](this['index_']):_0x10c5d3['getLastChild'](this['index_']),_0x550bb9=this['rangedFilter_']['matches'](_0x2852e4);if(_0x10c5d3['hasChild'](_0x476c36)){const _0x5b0ced=_0x10c5d3['getImmediateChild'](_0x476c36);let _0x48eea9=_0x456a51['getChildAfterChild'](this['index_'],_0x216b85,this['reverse_']);for(;_0x48eea9!=null&&(_0x48eea9['name']===_0x476c36||_0x10c5d3['hasChild'](_0x48eea9['name']));)_0x48eea9=_0x456a51['getChildAfterChild'](this['index_'],_0x48eea9,this['reverse_']);const _0x52cbdd=_0x48eea9==null?0x1:_0x274fac(_0x48eea9,_0x2852e4);if(_0x550bb9&&!_0x26743f['isEmpty']()&&_0x52cbdd>=0x0)return _0x1aae26!=null&&_0x1aae26['trackChildChange'](Pt(_0x476c36,_0x26743f,_0x5b0ced)),_0x10c5d3['updateImmediateChild'](_0x476c36,_0x26743f);{_0x1aae26!=null&&_0x1aae26['trackChildChange'](Nt(_0x476c36,_0x5b0ced));const _0x2e3c9a=_0x10c5d3['updateImmediateChild'](_0x476c36,g['EMPTY_NODE']);return _0x48eea9!=null&&this['rangedFilter_']['matches'](_0x48eea9)?(_0x1aae26!=null&&_0x1aae26['trackChildChange'](tt(_0x48eea9['name'],_0x48eea9['node'])),_0x2e3c9a['updateImmediateChild'](_0x48eea9['name'],_0x48eea9['node'])):_0x2e3c9a;}}else return _0x26743f['isEmpty']()?_0x4593b1:_0x550bb9&&_0x274fac(_0x216b85,_0x2852e4)>=0x0?(_0x1aae26!=null&&(_0x1aae26['trackChildChange'](Nt(_0x216b85['name'],_0x216b85['node'])),_0x1aae26['trackChildChange'](tt(_0x476c36,_0x26743f))),_0x10c5d3['updateImmediateChild'](_0x476c36,_0x26743f)['updateImmediateChild'](_0x216b85['name'],g['EMPTY_NODE'])):_0x4593b1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x43d311=new Qi();return _0x43d311['limitSet_']=this['limitSet_'],_0x43d311['limit_']=this['limit_'],_0x43d311['startSet_']=this['startSet_'],_0x43d311['startAfterSet_']=this['startAfterSet_'],_0x43d311['indexStartValue_']=this['indexStartValue_'],_0x43d311['startNameSet_']=this['startNameSet_'],_0x43d311['indexStartName_']=this['indexStartName_'],_0x43d311['endSet_']=this['endSet_'],_0x43d311['endBeforeSet_']=this['endBeforeSet_'],_0x43d311['indexEndValue_']=this['indexEndValue_'],_0x43d311['endNameSet_']=this['endNameSet_'],_0x43d311['indexEndName_']=this['indexEndName_'],_0x43d311['index_']=this['index_'],_0x43d311['viewFrom_']=this['viewFrom_'],_0x43d311;}}function qh(_0x19d047){return _0x19d047['loadsAllData']()?new Yi(_0x19d047['getIndex']()):_0x19d047['hasLimit']()?new Gh(_0x19d047):new Ot(_0x19d047);}function zh(_0x45cc2b,_0x1b739f){const _0xc6cff6=_0x45cc2b['copy']();return _0xc6cff6['limitSet_']=!0x0,_0xc6cff6['limit_']=_0x1b739f,_0xc6cff6['viewFrom_']='l',_0xc6cff6;}function jh(_0x5cbdcd,_0x36781c,_0x1e05df){const _0x5a4292=_0x5cbdcd['copy']();return _0x5a4292['startSet_']=!0x0,_0x36781c===void 0x0&&(_0x36781c=null),_0x5a4292['indexStartValue_']=_0x36781c,_0x1e05df!=null?(_0x5a4292['startNameSet_']=!0x0,_0x5a4292['indexStartName_']=_0x1e05df):(_0x5a4292['startNameSet_']=!0x1,_0x5a4292['indexStartName_']=''),_0x5a4292;}function Kh(_0x2a8697,_0x50116a,_0x48d975){const _0xa0388c=_0x2a8697['copy']();return _0xa0388c['endSet_']=!0x0,_0x50116a===void 0x0&&(_0x50116a=null),_0xa0388c['indexEndValue_']=_0x50116a,_0x48d975!==void 0x0?(_0xa0388c['endNameSet_']=!0x0,_0xa0388c['indexEndName_']=_0x48d975):(_0xa0388c['endNameSet_']=!0x1,_0xa0388c['indexEndName_']=''),_0xa0388c;}function Do(_0x3856e5,_0x4740ed){const _0x13e9ad=_0x3856e5['copy']();return _0x13e9ad['index_']=_0x4740ed,_0x13e9ad;}function tr(_0x3dcfd5){const _0x5f08e1={};if(_0x3dcfd5['isDefault']())return _0x5f08e1;let _0x3aed61;if(_0x3dcfd5['index_']===R?_0x3aed61='$priority':_0x3dcfd5['index_']===Po?_0x3aed61='$value':_0x3dcfd5['index_']===ye?_0x3aed61='$key':(f(_0x3dcfd5['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x3aed61=_0x3dcfd5['index_']['toString']()),_0x5f08e1['orderBy']=O(_0x3aed61),_0x3dcfd5['startSet_']){const _0x1def31=_0x3dcfd5['startAfterSet_']?'startAfter':'startAt';_0x5f08e1[_0x1def31]=O(_0x3dcfd5['indexStartValue_']),_0x3dcfd5['startNameSet_']&&(_0x5f08e1[_0x1def31]+=','+O(_0x3dcfd5['indexStartName_']));}if(_0x3dcfd5['endSet_']){const _0x312625=_0x3dcfd5['endBeforeSet_']?'endBefore':'endAt';_0x5f08e1[_0x312625]=O(_0x3dcfd5['indexEndValue_']),_0x3dcfd5['endNameSet_']&&(_0x5f08e1[_0x312625]+=','+O(_0x3dcfd5['indexEndName_']));}return _0x3dcfd5['limitSet_']&&(_0x3dcfd5['isViewFromLeft']()?_0x5f08e1['limitToFirst']=_0x3dcfd5['limit_']:_0x5f08e1['limitToLast']=_0x3dcfd5['limit_']),_0x5f08e1;}function nr(_0x18581f){const _0x12d9a9={};if(_0x18581f['startSet_']&&(_0x12d9a9['sp']=_0x18581f['indexStartValue_'],_0x18581f['startNameSet_']&&(_0x12d9a9['sn']=_0x18581f['indexStartName_']),_0x12d9a9['sin']=!_0x18581f['startAfterSet_']),_0x18581f['endSet_']&&(_0x12d9a9['ep']=_0x18581f['indexEndValue_'],_0x18581f['endNameSet_']&&(_0x12d9a9['en']=_0x18581f['indexEndName_']),_0x12d9a9['ein']=!_0x18581f['endBeforeSet_']),_0x18581f['limitSet_']){_0x12d9a9['l']=_0x18581f['limit_'];let _0xc8b5eb=_0x18581f['viewFrom_'];_0xc8b5eb===''&&(_0x18581f['isViewFromLeft']()?_0xc8b5eb='l':_0xc8b5eb='r'),_0x12d9a9['vf']=_0xc8b5eb;}return _0x18581f['index_']!==R&&(_0x12d9a9['i']=_0x18581f['index_']['toString']()),_0x12d9a9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x302056){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x47a25a,_0x44d80a){return _0x44d80a!==void 0x0?'tag$'+_0x44d80a:(f(_0x47a25a['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x47a25a['_path']['toString']());}constructor(_0x157c0c,_0x1d845d,_0x92aef0,_0x56cea8){super(),this['repoInfo_']=_0x157c0c,this['onDataUpdate_']=_0x1d845d,this['authTokenProvider_']=_0x92aef0,this['appCheckTokenProvider_']=_0x56cea8,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0xd37fa3,_0x59dff9,_0x5c708b,_0xabca0f){const _0x5ccdc2=_0xd37fa3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5ccdc2+'\x20'+_0xd37fa3['_queryIdentifier']);const _0x47bd8f=fn['getListenId_'](_0xd37fa3,_0x5c708b),_0x48f455={};this['listens_'][_0x47bd8f]=_0x48f455;const _0x41e0bd=tr(_0xd37fa3['_queryParams']);this['restRequest_'](_0x5ccdc2+'.json',_0x41e0bd,(_0x153c16,_0x57051e)=>{let _0x1845c2=_0x57051e;if(_0x153c16===0x194&&(_0x1845c2=null,_0x153c16=null),_0x153c16===null&&this['onDataUpdate_'](_0x5ccdc2,_0x1845c2,!0x1,_0x5c708b),Oe(this['listens_'],_0x47bd8f)===_0x48f455){let _0x1e21d0;_0x153c16?_0x153c16===0x191?_0x1e21d0='permission_denied':_0x1e21d0='rest_error:'+_0x153c16:_0x1e21d0='ok',_0xabca0f(_0x1e21d0,null);}});}['unlisten'](_0x257f96,_0x3e9d57){const _0x189320=fn['getListenId_'](_0x257f96,_0x3e9d57);delete this['listens_'][_0x189320];}['get'](_0x41c391){const _0x4caf4e=tr(_0x41c391['_queryParams']),_0x493a53=_0x41c391['_path']['toString'](),_0x25c7ff=new Ve();return this['restRequest_'](_0x493a53+'.json',_0x4caf4e,(_0x57896,_0x3013f7)=>{let _0x29162b=_0x3013f7;_0x57896===0x194&&(_0x29162b=null,_0x57896=null),_0x57896===null?(this['onDataUpdate_'](_0x493a53,_0x29162b,!0x1,null),_0x25c7ff['resolve'](_0x29162b)):_0x25c7ff['reject'](new Error(_0x29162b));}),_0x25c7ff['promise'];}['refreshAuthToken'](_0x3997d6){}['restRequest_'](_0x33bd7e,_0xd665b4={},_0x73996){return _0xd665b4['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1d33ba,_0x3c82f9])=>{_0x1d33ba&&_0x1d33ba['accessToken']&&(_0xd665b4['auth']=_0x1d33ba['accessToken']),_0x3c82f9&&_0x3c82f9['token']&&(_0xd665b4['ac']=_0x3c82f9['token']);const _0x1ad397=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x33bd7e+'?ns='+this['repoInfo_']['namespace']+at(_0xd665b4);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1ad397);const _0x35fab4=new XMLHttpRequest();_0x35fab4['onreadystatechange']=()=>{if(_0x73996&&_0x35fab4['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1ad397+'\x20received.\x20status:',_0x35fab4['status'],'response:',_0x35fab4['responseText']);let _0x28cd6b=null;if(_0x35fab4['status']>=0xc8&&_0x35fab4['status']<0x12c){try{_0x28cd6b=bt(_0x35fab4['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1ad397+':\x20'+_0x35fab4['responseText']);}_0x73996(null,_0x28cd6b);}else _0x35fab4['status']!==0x191&&_0x35fab4['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1ad397+'\x20Status:\x20'+_0x35fab4['status']),_0x73996(_0x35fab4['status']);_0x73996=null;}},_0x35fab4['open']('GET',_0x1ad397,!0x0),_0x35fab4['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x85f47a){return this['rootNode_']['getChild'](_0x85f47a);}['updateSnapshot'](_0x537c04,_0x223e67){this['rootNode_']=this['rootNode_']['updateChild'](_0x537c04,_0x223e67);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x14d657,_0x1a3f55,_0x3defac){if(v(_0x1a3f55))_0x14d657['value']=_0x3defac,_0x14d657['children']['clear']();else{if(_0x14d657['value']!==null)_0x14d657['value']=_0x14d657['value']['updateChild'](_0x1a3f55,_0x3defac);else{const _0x4e9a4f=y(_0x1a3f55);_0x14d657['children']['has'](_0x4e9a4f)||_0x14d657['children']['set'](_0x4e9a4f,pn());const _0x4f2959=_0x14d657['children']['get'](_0x4e9a4f);_0x1a3f55=b(_0x1a3f55),Mo(_0x4f2959,_0x1a3f55,_0x3defac);}}}function Ei(_0xc5de6e,_0x496d35,_0x293863){_0xc5de6e['value']!==null?_0x293863(_0x496d35,_0xc5de6e['value']):Qh(_0xc5de6e,(_0x22c462,_0x8e300f)=>{const _0x52bc56=new C(_0x496d35['toString']()+'/'+_0x22c462);Ei(_0x8e300f,_0x52bc56,_0x293863);});}function Qh(_0x58b855,_0x3259cc){_0x58b855['children']['forEach']((_0x158da3,_0x4fee85)=>{_0x3259cc(_0x4fee85,_0x158da3);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x3ec051){this['collection_']=_0x3ec051,this['last_']=null;}['get'](){const _0x1f4496=this['collection_']['get'](),_0x22374d={..._0x1f4496};return this['last_']&&x(this['last_'],(_0x2edf30,_0x390d67)=>{_0x22374d[_0x2edf30]=_0x22374d[_0x2edf30]-_0x390d67;}),this['last_']=_0x1f4496,_0x22374d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0xfea7c5,_0x4f2d76){this['server_']=_0x4f2d76,this['statsToReport_']={},this['statsListener_']=new Jh(_0xfea7c5);const _0x4ff899=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x4ff899));}['reportStats_'](){const _0x477b56=this['statsListener_']['get'](),_0x2216f8={};let _0x1d045d=!0x1;x(_0x477b56,(_0x2c870d,_0x147248)=>{_0x147248>0x0&&Y(this['statsToReport_'],_0x2c870d)&&(_0x2216f8[_0x2c870d]=_0x147248,_0x1d045d=!0x0);}),_0x1d045d&&this['server_']['reportStats'](_0x2216f8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x1a96c3){_0x1a96c3[_0x1a96c3['OVERWRITE']=0x0]='OVERWRITE',_0x1a96c3[_0x1a96c3['MERGE']=0x1]='MERGE',_0x1a96c3[_0x1a96c3['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1a96c3[_0x1a96c3['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x4d001d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4d001d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x5451c3,_0x4a3381,_0x59fe80){this['path']=_0x5451c3,this['affectedTree']=_0x4a3381,this['revert']=_0x59fe80,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x424b12){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4b3799=this['affectedTree']['subtree'](new C(_0x424b12));return new _n(w(),_0x4b3799,this['revert']);}}else return f(y(this['path'])===_0x424b12,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5daa70,_0x4c1ba9){this['source']=_0x5daa70,this['path']=_0x4c1ba9,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x16909d){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x467f44,_0x246033,_0xffcd99){this['source']=_0x467f44,this['path']=_0x246033,this['snap']=_0xffcd99,this['type']=q['OVERWRITE'];}['operationForChild'](_0x591e40){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x591e40)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x3768a8,_0x3d451f,_0x2a1065){this['source']=_0x3768a8,this['path']=_0x3d451f,this['children']=_0x2a1065,this['type']=q['MERGE'];}['operationForChild'](_0x1031ab){if(v(this['path'])){const _0x233eb7=this['children']['subtree'](new C(_0x1031ab));return _0x233eb7['isEmpty']()?null:_0x233eb7['value']?new Fe(this['source'],w(),_0x233eb7['value']):new nt(this['source'],w(),_0x233eb7);}else return f(y(this['path'])===_0x1031ab,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x5562b0,_0xb971eb,_0x52651c){this['node_']=_0x5562b0,this['fullyInitialized_']=_0xb971eb,this['filtered_']=_0x52651c;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x326b62){if(v(_0x326b62))return this['isFullyInitialized']()&&!this['filtered_'];const _0x44c4aa=y(_0x326b62);return this['isCompleteForChild'](_0x44c4aa);}['isCompleteForChild'](_0x194878){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x194878);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x4eb3dc){this['query_']=_0x4eb3dc,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3ae728,_0x31d1da,_0x455f2b,_0x3894c6){const _0x5a7f44=[],_0x341e32=[];return _0x31d1da['forEach'](_0x2539f7=>{_0x2539f7['type']==='child_changed'&&_0x3ae728['index_']['indexedValueChanged'](_0x2539f7['oldSnap'],_0x2539f7['snapshotNode'])&&_0x341e32['push']($h(_0x2539f7['childName'],_0x2539f7['snapshotNode']));}),mt(_0x3ae728,_0x5a7f44,'child_removed',_0x31d1da,_0x3894c6,_0x455f2b),mt(_0x3ae728,_0x5a7f44,'child_added',_0x31d1da,_0x3894c6,_0x455f2b),mt(_0x3ae728,_0x5a7f44,'child_moved',_0x341e32,_0x3894c6,_0x455f2b),mt(_0x3ae728,_0x5a7f44,'child_changed',_0x31d1da,_0x3894c6,_0x455f2b),mt(_0x3ae728,_0x5a7f44,'value',_0x31d1da,_0x3894c6,_0x455f2b),_0x5a7f44;}function mt(_0xac9fb7,_0x49494f,_0x5b81a0,_0x2a7be5,_0x1ecd2a,_0x33187c){const _0x4ea6f2=_0x2a7be5['filter'](_0x5531aa=>_0x5531aa['type']===_0x5b81a0);_0x4ea6f2['sort']((_0x5d9ae5,_0x2e5249)=>su(_0xac9fb7,_0x5d9ae5,_0x2e5249)),_0x4ea6f2['forEach'](_0x57b6d4=>{const _0x430c46=iu(_0xac9fb7,_0x57b6d4,_0x33187c);_0x1ecd2a['forEach'](_0x4aeb40=>{_0x4aeb40['respondsTo'](_0x57b6d4['type'])&&_0x49494f['push'](_0x4aeb40['createEvent'](_0x430c46,_0xac9fb7['query_']));});});}function iu(_0x22d0a7,_0x240fc8,_0x11c120){return _0x240fc8['type']==='value'||_0x240fc8['type']==='child_removed'||(_0x240fc8['prevName']=_0x11c120['getPredecessorChildName'](_0x240fc8['childName'],_0x240fc8['snapshotNode'],_0x22d0a7['index_'])),_0x240fc8;}function su(_0x5180d6,_0x279a52,_0x31a299){if(_0x279a52['childName']==null||_0x31a299['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x8998ec=new E(_0x279a52['childName'],_0x279a52['snapshotNode']),_0x19f03b=new E(_0x31a299['childName'],_0x31a299['snapshotNode']);return _0x5180d6['index_']['compare'](_0x8998ec,_0x19f03b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x14563d,_0x59c518){return{'eventCache':_0x14563d,'serverCache':_0x59c518};}function wt(_0x5ca454,_0x107996,_0x10f1e2,_0x26ffca){return Dn(new Ce(_0x107996,_0x10f1e2,_0x26ffca),_0x5ca454['serverCache']);}function Lo(_0x3c1c5b,_0x1489fc,_0x38676e,_0x22e8ea){return Dn(_0x3c1c5b['eventCache'],new Ce(_0x1489fc,_0x38676e,_0x22e8ea));}function gn(_0xd75f84){return _0xd75f84['eventCache']['isFullyInitialized']()?_0xd75f84['eventCache']['getNode']():null;}function Ue(_0x1bb2c5){return _0x1bb2c5['serverCache']['isFullyInitialized']()?_0x1bb2c5['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x12a77c){let _0x32d0c3=new S(null);return x(_0x12a77c,(_0x32a6ce,_0x9b6f7c)=>{_0x32d0c3=_0x32d0c3['set'](new C(_0x32a6ce),_0x9b6f7c);}),_0x32d0c3;}constructor(_0x962e12,_0x1472e9=ru()){this['value']=_0x962e12,this['children']=_0x1472e9;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xd23acf,_0x4a4001){if(this['value']!=null&&_0x4a4001(this['value']))return{'path':w(),'value':this['value']};if(v(_0xd23acf))return null;{const _0x483c78=y(_0xd23acf),_0x241168=this['children']['get'](_0x483c78);if(_0x241168!==null){const _0x4a1bfa=_0x241168['findRootMostMatchingPathAndValue'](b(_0xd23acf),_0x4a4001);return _0x4a1bfa!=null?{'path':A(new C(_0x483c78),_0x4a1bfa['path']),'value':_0x4a1bfa['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4671d3){return this['findRootMostMatchingPathAndValue'](_0x4671d3,()=>!0x0);}['subtree'](_0x5be2b7){if(v(_0x5be2b7))return this;{const _0x1760d7=y(_0x5be2b7),_0x176586=this['children']['get'](_0x1760d7);return _0x176586!==null?_0x176586['subtree'](b(_0x5be2b7)):new S(null);}}['set'](_0x28949f,_0x504920){if(v(_0x28949f))return new S(_0x504920,this['children']);{const _0x47976f=y(_0x28949f),_0x1a1672=(this['children']['get'](_0x47976f)||new S(null))['set'](b(_0x28949f),_0x504920),_0x50a2ba=this['children']['insert'](_0x47976f,_0x1a1672);return new S(this['value'],_0x50a2ba);}}['remove'](_0x936ba){if(v(_0x936ba))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x520699=y(_0x936ba),_0x4e8679=this['children']['get'](_0x520699);if(_0x4e8679){const _0x47a161=_0x4e8679['remove'](b(_0x936ba));let _0x579054;return _0x47a161['isEmpty']()?_0x579054=this['children']['remove'](_0x520699):_0x579054=this['children']['insert'](_0x520699,_0x47a161),this['value']===null&&_0x579054['isEmpty']()?new S(null):new S(this['value'],_0x579054);}else return this;}}['get'](_0x4a262f){if(v(_0x4a262f))return this['value'];{const _0x467c0d=y(_0x4a262f),_0x23e758=this['children']['get'](_0x467c0d);return _0x23e758?_0x23e758['get'](b(_0x4a262f)):null;}}['setTree'](_0x27883e,_0x1343d7){if(v(_0x27883e))return _0x1343d7;{const _0x355fc1=y(_0x27883e),_0xddd3a=(this['children']['get'](_0x355fc1)||new S(null))['setTree'](b(_0x27883e),_0x1343d7);let _0x19d606;return _0xddd3a['isEmpty']()?_0x19d606=this['children']['remove'](_0x355fc1):_0x19d606=this['children']['insert'](_0x355fc1,_0xddd3a),new S(this['value'],_0x19d606);}}['fold'](_0x454385){return this['fold_'](w(),_0x454385);}['fold_'](_0x2db8a4,_0x2af477){const _0x557ebf={};return this['children']['inorderTraversal']((_0x3cc353,_0x23d380)=>{_0x557ebf[_0x3cc353]=_0x23d380['fold_'](A(_0x2db8a4,_0x3cc353),_0x2af477);}),_0x2af477(_0x2db8a4,this['value'],_0x557ebf);}['findOnPath'](_0x55ea69,_0x57c01e){return this['findOnPath_'](_0x55ea69,w(),_0x57c01e);}['findOnPath_'](_0x47dbb4,_0x3980e8,_0x5eb2f5){const _0x75bc2e=this['value']?_0x5eb2f5(_0x3980e8,this['value']):!0x1;if(_0x75bc2e)return _0x75bc2e;if(v(_0x47dbb4))return null;{const _0x183687=y(_0x47dbb4),_0x2ed71a=this['children']['get'](_0x183687);return _0x2ed71a?_0x2ed71a['findOnPath_'](b(_0x47dbb4),A(_0x3980e8,_0x183687),_0x5eb2f5):null;}}['foreachOnPath'](_0x15e275,_0x4235ac){return this['foreachOnPath_'](_0x15e275,w(),_0x4235ac);}['foreachOnPath_'](_0x517f1d,_0x3140b6,_0x477010){if(v(_0x517f1d))return this;{this['value']&&_0x477010(_0x3140b6,this['value']);const _0x2814a9=y(_0x517f1d),_0x435090=this['children']['get'](_0x2814a9);return _0x435090?_0x435090['foreachOnPath_'](b(_0x517f1d),A(_0x3140b6,_0x2814a9),_0x477010):new S(null);}}['foreach'](_0xa452f0){this['foreach_'](w(),_0xa452f0);}['foreach_'](_0x2275d6,_0x1bc78a){this['children']['inorderTraversal']((_0x1aeffd,_0x4ff557)=>{_0x4ff557['foreach_'](A(_0x2275d6,_0x1aeffd),_0x1bc78a);}),this['value']&&_0x1bc78a(_0x2275d6,this['value']);}['foreachChild'](_0x44672c){this['children']['inorderTraversal']((_0x29219c,_0xd49f65)=>{_0xd49f65['value']&&_0x44672c(_0x29219c,_0xd49f65['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x59b952){this['writeTree_']=_0x59b952;}static['empty'](){return new j(new S(null));}}function Ct(_0x4ed3f8,_0x3bcdb4,_0x5db281){if(v(_0x3bcdb4))return new j(new S(_0x5db281));{const _0x42ddcc=_0x4ed3f8['writeTree_']['findRootMostValueAndPath'](_0x3bcdb4);if(_0x42ddcc!=null){const _0x23f68b=_0x42ddcc['path'];let _0x22cf55=_0x42ddcc['value'];const _0x1cd0f6=F(_0x23f68b,_0x3bcdb4);return _0x22cf55=_0x22cf55['updateChild'](_0x1cd0f6,_0x5db281),new j(_0x4ed3f8['writeTree_']['set'](_0x23f68b,_0x22cf55));}else{const _0x325c8c=new S(_0x5db281),_0x4e3122=_0x4ed3f8['writeTree_']['setTree'](_0x3bcdb4,_0x325c8c);return new j(_0x4e3122);}}}function Ii(_0xa3f645,_0x773243,_0x4eb52e){let _0x5c459f=_0xa3f645;return x(_0x4eb52e,(_0x2ac90c,_0x116aea)=>{_0x5c459f=Ct(_0x5c459f,A(_0x773243,_0x2ac90c),_0x116aea);}),_0x5c459f;}function sr(_0x4845e3,_0x3ba3e9){if(v(_0x3ba3e9))return j['empty']();{const _0x1b3cc6=_0x4845e3['writeTree_']['setTree'](_0x3ba3e9,new S(null));return new j(_0x1b3cc6);}}function wi(_0x13f35e,_0x4c4a65){return $e(_0x13f35e,_0x4c4a65)!=null;}function $e(_0x45a877,_0x39b0cf){const _0x3debd9=_0x45a877['writeTree_']['findRootMostValueAndPath'](_0x39b0cf);return _0x3debd9!=null?_0x45a877['writeTree_']['get'](_0x3debd9['path'])['getChild'](F(_0x3debd9['path'],_0x39b0cf)):null;}function rr(_0x3c7e79){const _0x5726f8=[],_0x3ad679=_0x3c7e79['writeTree_']['value'];return _0x3ad679!=null?_0x3ad679['isLeafNode']()||_0x3ad679['forEachChild'](R,(_0x3d140d,_0x481de6)=>{_0x5726f8['push'](new E(_0x3d140d,_0x481de6));}):_0x3c7e79['writeTree_']['children']['inorderTraversal']((_0x3580b4,_0x5f0973)=>{_0x5f0973['value']!=null&&_0x5726f8['push'](new E(_0x3580b4,_0x5f0973['value']));}),_0x5726f8;}function ve(_0x5ee553,_0x1200c1){if(v(_0x1200c1))return _0x5ee553;{const _0x658a98=$e(_0x5ee553,_0x1200c1);return _0x658a98!=null?new j(new S(_0x658a98)):new j(_0x5ee553['writeTree_']['subtree'](_0x1200c1));}}function Ci(_0x5b07fc){return _0x5b07fc['writeTree_']['isEmpty']();}function it(_0x3edf40,_0x36ba14){return xo(w(),_0x3edf40['writeTree_'],_0x36ba14);}function xo(_0x94b476,_0x7d7c68,_0xfabe05){if(_0x7d7c68['value']!=null)return _0xfabe05['updateChild'](_0x94b476,_0x7d7c68['value']);{let _0x16e132=null;return _0x7d7c68['children']['inorderTraversal']((_0x16e1fb,_0x2617c1)=>{_0x16e1fb==='.priority'?(f(_0x2617c1['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x16e132=_0x2617c1['value']):_0xfabe05=xo(A(_0x94b476,_0x16e1fb),_0x2617c1,_0xfabe05);}),!_0xfabe05['getChild'](_0x94b476)['isEmpty']()&&_0x16e132!==null&&(_0xfabe05=_0xfabe05['updateChild'](A(_0x94b476,'.priority'),_0x16e132)),_0xfabe05;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1fca3e,_0x224655){return Bo(_0x224655,_0x1fca3e);}function ou(_0x4e9454,_0x3c591e,_0x240db5,_0x2ca926,_0x2e7384){f(_0x2ca926>_0x4e9454['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2e7384===void 0x0&&(_0x2e7384=!0x0),_0x4e9454['allWrites']['push']({'path':_0x3c591e,'snap':_0x240db5,'writeId':_0x2ca926,'visible':_0x2e7384}),_0x2e7384&&(_0x4e9454['visibleWrites']=Ct(_0x4e9454['visibleWrites'],_0x3c591e,_0x240db5)),_0x4e9454['lastWriteId']=_0x2ca926;}function au(_0x52895e,_0x59ae79,_0x3d1361,_0x3bb955){f(_0x3bb955>_0x52895e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x52895e['allWrites']['push']({'path':_0x59ae79,'children':_0x3d1361,'writeId':_0x3bb955,'visible':!0x0}),_0x52895e['visibleWrites']=Ii(_0x52895e['visibleWrites'],_0x59ae79,_0x3d1361),_0x52895e['lastWriteId']=_0x3bb955;}function cu(_0x2cb99d,_0x2a3feb){for(let _0x3ae2d5=0x0;_0x3ae2d5<_0x2cb99d['allWrites']['length'];_0x3ae2d5++){const _0x1cc0ed=_0x2cb99d['allWrites'][_0x3ae2d5];if(_0x1cc0ed['writeId']===_0x2a3feb)return _0x1cc0ed;}return null;}function lu(_0x1e4b3d,_0x437a5b){const _0x210697=_0x1e4b3d['allWrites']['findIndex'](_0xcb8b5=>_0xcb8b5['writeId']===_0x437a5b);f(_0x210697>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x50d0f9=_0x1e4b3d['allWrites'][_0x210697];_0x1e4b3d['allWrites']['splice'](_0x210697,0x1);let _0x15ee15=_0x50d0f9['visible'],_0x416e5c=!0x1,_0x101456=_0x1e4b3d['allWrites']['length']-0x1;for(;_0x15ee15&&_0x101456>=0x0;){const _0x7218b6=_0x1e4b3d['allWrites'][_0x101456];_0x7218b6['visible']&&(_0x101456>=_0x210697&&hu(_0x7218b6,_0x50d0f9['path'])?_0x15ee15=!0x1:$(_0x50d0f9['path'],_0x7218b6['path'])&&(_0x416e5c=!0x0)),_0x101456--;}if(_0x15ee15){if(_0x416e5c)return uu(_0x1e4b3d),!0x0;if(_0x50d0f9['snap'])_0x1e4b3d['visibleWrites']=sr(_0x1e4b3d['visibleWrites'],_0x50d0f9['path']);else{const _0x14cee2=_0x50d0f9['children'];x(_0x14cee2,_0x2f00ef=>{_0x1e4b3d['visibleWrites']=sr(_0x1e4b3d['visibleWrites'],A(_0x50d0f9['path'],_0x2f00ef));});}return!0x0;}else return!0x1;}function hu(_0x4576e9,_0x5cacc5){if(_0x4576e9['snap'])return $(_0x4576e9['path'],_0x5cacc5);for(const _0x5492e1 in _0x4576e9['children'])if(_0x4576e9['children']['hasOwnProperty'](_0x5492e1)&&$(A(_0x4576e9['path'],_0x5492e1),_0x5cacc5))return!0x0;return!0x1;}function uu(_0x288c71){_0x288c71['visibleWrites']=Fo(_0x288c71['allWrites'],du,w()),_0x288c71['allWrites']['length']>0x0?_0x288c71['lastWriteId']=_0x288c71['allWrites'][_0x288c71['allWrites']['length']-0x1]['writeId']:_0x288c71['lastWriteId']=-0x1;}function du(_0x236ef2){return _0x236ef2['visible'];}function Fo(_0x5372ac,_0x5dff7c,_0x557a83){let _0x43aed3=j['empty']();for(let _0x2494d7=0x0;_0x2494d7<_0x5372ac['length'];++_0x2494d7){const _0x2f4f45=_0x5372ac[_0x2494d7];if(_0x5dff7c(_0x2f4f45)){const _0x5c0c1c=_0x2f4f45['path'];let _0x390a69;if(_0x2f4f45['snap'])$(_0x557a83,_0x5c0c1c)?(_0x390a69=F(_0x557a83,_0x5c0c1c),_0x43aed3=Ct(_0x43aed3,_0x390a69,_0x2f4f45['snap'])):$(_0x5c0c1c,_0x557a83)&&(_0x390a69=F(_0x5c0c1c,_0x557a83),_0x43aed3=Ct(_0x43aed3,w(),_0x2f4f45['snap']['getChild'](_0x390a69)));else{if(_0x2f4f45['children']){if($(_0x557a83,_0x5c0c1c))_0x390a69=F(_0x557a83,_0x5c0c1c),_0x43aed3=Ii(_0x43aed3,_0x390a69,_0x2f4f45['children']);else{if($(_0x5c0c1c,_0x557a83)){if(_0x390a69=F(_0x5c0c1c,_0x557a83),v(_0x390a69))_0x43aed3=Ii(_0x43aed3,w(),_0x2f4f45['children']);else{const _0x1ddd4f=Oe(_0x2f4f45['children'],y(_0x390a69));if(_0x1ddd4f){const _0x2d06d3=_0x1ddd4f['getChild'](b(_0x390a69));_0x43aed3=Ct(_0x43aed3,w(),_0x2d06d3);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x43aed3;}function Uo(_0x27b3d4,_0xf5af87,_0x2dc02,_0x172942,_0x519e45){if(!_0x172942&&!_0x519e45){const _0x2ca33d=$e(_0x27b3d4['visibleWrites'],_0xf5af87);if(_0x2ca33d!=null)return _0x2ca33d;{const _0x5c7be8=ve(_0x27b3d4['visibleWrites'],_0xf5af87);if(Ci(_0x5c7be8))return _0x2dc02;if(_0x2dc02==null&&!wi(_0x5c7be8,w()))return null;{const _0x5da8eb=_0x2dc02||g['EMPTY_NODE'];return it(_0x5c7be8,_0x5da8eb);}}}else{const _0x2919f9=ve(_0x27b3d4['visibleWrites'],_0xf5af87);if(!_0x519e45&&Ci(_0x2919f9))return _0x2dc02;if(!_0x519e45&&_0x2dc02==null&&!wi(_0x2919f9,w()))return null;{const _0xdba075=function(_0x3c9f22){return(_0x3c9f22['visible']||_0x519e45)&&(!_0x172942||!~_0x172942['indexOf'](_0x3c9f22['writeId']))&&($(_0x3c9f22['path'],_0xf5af87)||$(_0xf5af87,_0x3c9f22['path']));},_0x3b45c2=Fo(_0x27b3d4['allWrites'],_0xdba075,_0xf5af87),_0x1926c4=_0x2dc02||g['EMPTY_NODE'];return it(_0x3b45c2,_0x1926c4);}}}function fu(_0x112fbe,_0x564ed0,_0x132033){let _0x17d8bc=g['EMPTY_NODE'];const _0x2d2173=$e(_0x112fbe['visibleWrites'],_0x564ed0);if(_0x2d2173)return _0x2d2173['isLeafNode']()||_0x2d2173['forEachChild'](R,(_0x7ab8b,_0x12e0d5)=>{_0x17d8bc=_0x17d8bc['updateImmediateChild'](_0x7ab8b,_0x12e0d5);}),_0x17d8bc;if(_0x132033){const _0xcbfa95=ve(_0x112fbe['visibleWrites'],_0x564ed0);return _0x132033['forEachChild'](R,(_0x3450d5,_0x275a2f)=>{const _0x3dcf4d=it(ve(_0xcbfa95,new C(_0x3450d5)),_0x275a2f);_0x17d8bc=_0x17d8bc['updateImmediateChild'](_0x3450d5,_0x3dcf4d);}),rr(_0xcbfa95)['forEach'](_0x455ae2=>{_0x17d8bc=_0x17d8bc['updateImmediateChild'](_0x455ae2['name'],_0x455ae2['node']);}),_0x17d8bc;}else{const _0x45cb91=ve(_0x112fbe['visibleWrites'],_0x564ed0);return rr(_0x45cb91)['forEach'](_0x5b482c=>{_0x17d8bc=_0x17d8bc['updateImmediateChild'](_0x5b482c['name'],_0x5b482c['node']);}),_0x17d8bc;}}function pu(_0x1b0d5b,_0x89e4f7,_0x1cba0f,_0x28672d,_0xf94d28){f(_0x28672d||_0xf94d28,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x364232=A(_0x89e4f7,_0x1cba0f);if(wi(_0x1b0d5b['visibleWrites'],_0x364232))return null;{const _0x54205c=ve(_0x1b0d5b['visibleWrites'],_0x364232);return Ci(_0x54205c)?_0xf94d28['getChild'](_0x1cba0f):it(_0x54205c,_0xf94d28['getChild'](_0x1cba0f));}}function _u(_0x24ef52,_0x457339,_0x156dcb,_0x40b315){const _0x538610=A(_0x457339,_0x156dcb),_0x223c8c=$e(_0x24ef52['visibleWrites'],_0x538610);if(_0x223c8c!=null)return _0x223c8c;if(_0x40b315['isCompleteForChild'](_0x156dcb)){const _0x117aea=ve(_0x24ef52['visibleWrites'],_0x538610);return it(_0x117aea,_0x40b315['getNode']()['getImmediateChild'](_0x156dcb));}else return null;}function gu(_0x5a020d,_0x4288b9){return $e(_0x5a020d['visibleWrites'],_0x4288b9);}function mu(_0x3c1c80,_0x2e16cb,_0x5e9008,_0x3c3a58,_0x4f9fa1,_0x55ed8c,_0xe823fd){let _0x68460a;const _0x30cc2c=ve(_0x3c1c80['visibleWrites'],_0x2e16cb),_0xb4e09c=$e(_0x30cc2c,w());if(_0xb4e09c!=null)_0x68460a=_0xb4e09c;else{if(_0x5e9008!=null)_0x68460a=it(_0x30cc2c,_0x5e9008);else return[];}if(_0x68460a=_0x68460a['withIndex'](_0xe823fd),!_0x68460a['isEmpty']()&&!_0x68460a['isLeafNode']()){const _0x2c7b48=[],_0x1ed734=_0xe823fd['getCompare'](),_0x2836cf=_0x55ed8c?_0x68460a['getReverseIteratorFrom'](_0x3c3a58,_0xe823fd):_0x68460a['getIteratorFrom'](_0x3c3a58,_0xe823fd);let _0x59cc71=_0x2836cf['getNext']();for(;_0x59cc71&&_0x2c7b48['length']<_0x4f9fa1;)_0x1ed734(_0x59cc71,_0x3c3a58)!==0x0&&_0x2c7b48['push'](_0x59cc71),_0x59cc71=_0x2836cf['getNext']();return _0x2c7b48;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1820a6,_0x26c4ed,_0x52c780,_0x4d894a){return Uo(_0x1820a6['writeTree'],_0x1820a6['treePath'],_0x26c4ed,_0x52c780,_0x4d894a);}function es(_0x3c69b6,_0x3cc356){return fu(_0x3c69b6['writeTree'],_0x3c69b6['treePath'],_0x3cc356);}function or(_0x204bc9,_0x2c9e15,_0x23d434,_0x344ef8){return pu(_0x204bc9['writeTree'],_0x204bc9['treePath'],_0x2c9e15,_0x23d434,_0x344ef8);}function yn(_0x48f23b,_0x36f051){return gu(_0x48f23b['writeTree'],A(_0x48f23b['treePath'],_0x36f051));}function vu(_0x4abffc,_0x28a6ac,_0x295042,_0x4d4d75,_0x582651,_0x36ca58){return mu(_0x4abffc['writeTree'],_0x4abffc['treePath'],_0x28a6ac,_0x295042,_0x4d4d75,_0x582651,_0x36ca58);}function ts(_0x506b58,_0x3466c0,_0x226300){return _u(_0x506b58['writeTree'],_0x506b58['treePath'],_0x3466c0,_0x226300);}function Wo(_0x51f251,_0x4e13cb){return Bo(A(_0x51f251['treePath'],_0x4e13cb),_0x51f251['writeTree']);}function Bo(_0x15b2b8,_0xf8efa){return{'treePath':_0x15b2b8,'writeTree':_0xf8efa};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x198b36){const _0x4d2d5d=_0x198b36['type'],_0x1e0f3b=_0x198b36['childName'];f(_0x4d2d5d==='child_added'||_0x4d2d5d==='child_changed'||_0x4d2d5d==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1e0f3b!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x10d3e7=this['changeMap']['get'](_0x1e0f3b);if(_0x10d3e7){const _0x57c78e=_0x10d3e7['type'];if(_0x4d2d5d==='child_added'&&_0x57c78e==='child_removed')this['changeMap']['set'](_0x1e0f3b,Pt(_0x1e0f3b,_0x198b36['snapshotNode'],_0x10d3e7['snapshotNode']));else{if(_0x4d2d5d==='child_removed'&&_0x57c78e==='child_added')this['changeMap']['delete'](_0x1e0f3b);else{if(_0x4d2d5d==='child_removed'&&_0x57c78e==='child_changed')this['changeMap']['set'](_0x1e0f3b,Nt(_0x1e0f3b,_0x10d3e7['oldSnap']));else{if(_0x4d2d5d==='child_changed'&&_0x57c78e==='child_added')this['changeMap']['set'](_0x1e0f3b,tt(_0x1e0f3b,_0x198b36['snapshotNode']));else{if(_0x4d2d5d==='child_changed'&&_0x57c78e==='child_changed')this['changeMap']['set'](_0x1e0f3b,Pt(_0x1e0f3b,_0x198b36['snapshotNode'],_0x10d3e7['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x198b36+'\x20occurred\x20after\x20'+_0x10d3e7);}}}}}else this['changeMap']['set'](_0x1e0f3b,_0x198b36);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0xf3fd9e){return null;}['getChildAfterChild'](_0x12f504,_0x4cbd8d,_0x53a9c1){return null;}}const Vo=new Iu();class ns{constructor(_0x2968cd,_0x3bdc96,_0x35c5b9=null){this['writes_']=_0x2968cd,this['viewCache_']=_0x3bdc96,this['optCompleteServerCache_']=_0x35c5b9;}['getCompleteChild'](_0x24fce9){const _0x538f14=this['viewCache_']['eventCache'];if(_0x538f14['isCompleteForChild'](_0x24fce9))return _0x538f14['getNode']()['getImmediateChild'](_0x24fce9);{const _0x29cefb=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x24fce9,_0x29cefb);}}['getChildAfterChild'](_0x1756ce,_0x4419bd,_0xbd3508){const _0xfbcfca=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x515ad2=vu(this['writes_'],_0xfbcfca,_0x4419bd,0x1,_0xbd3508,_0x1756ce);return _0x515ad2['length']===0x0?null:_0x515ad2[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3dbfed){return{'filter':_0x3dbfed};}function Cu(_0x24e032,_0x4e3a0a){f(_0x4e3a0a['eventCache']['getNode']()['isIndexed'](_0x24e032['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4e3a0a['serverCache']['getNode']()['isIndexed'](_0x24e032['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1dd95a,_0x7d2127,_0x5dc4f9,_0x1616fe,_0x46a55e){const _0x1d902f=new Eu();let _0x61d502,_0x54ad1d;if(_0x5dc4f9['type']===q['OVERWRITE']){const _0x153602=_0x5dc4f9;_0x153602['source']['fromUser']?_0x61d502=Ti(_0x1dd95a,_0x7d2127,_0x153602['path'],_0x153602['snap'],_0x1616fe,_0x46a55e,_0x1d902f):(f(_0x153602['source']['fromServer'],'Unknown\x20source.'),_0x54ad1d=_0x153602['source']['tagged']||_0x7d2127['serverCache']['isFiltered']()&&!v(_0x153602['path']),_0x61d502=vn(_0x1dd95a,_0x7d2127,_0x153602['path'],_0x153602['snap'],_0x1616fe,_0x46a55e,_0x54ad1d,_0x1d902f));}else{if(_0x5dc4f9['type']===q['MERGE']){const _0x11ee61=_0x5dc4f9;_0x11ee61['source']['fromUser']?_0x61d502=bu(_0x1dd95a,_0x7d2127,_0x11ee61['path'],_0x11ee61['children'],_0x1616fe,_0x46a55e,_0x1d902f):(f(_0x11ee61['source']['fromServer'],'Unknown\x20source.'),_0x54ad1d=_0x11ee61['source']['tagged']||_0x7d2127['serverCache']['isFiltered'](),_0x61d502=Si(_0x1dd95a,_0x7d2127,_0x11ee61['path'],_0x11ee61['children'],_0x1616fe,_0x46a55e,_0x54ad1d,_0x1d902f));}else{if(_0x5dc4f9['type']===q['ACK_USER_WRITE']){const _0x352241=_0x5dc4f9;_0x352241['revert']?_0x61d502=ku(_0x1dd95a,_0x7d2127,_0x352241['path'],_0x1616fe,_0x46a55e,_0x1d902f):_0x61d502=Ru(_0x1dd95a,_0x7d2127,_0x352241['path'],_0x352241['affectedTree'],_0x1616fe,_0x46a55e,_0x1d902f);}else{if(_0x5dc4f9['type']===q['LISTEN_COMPLETE'])_0x61d502=Au(_0x1dd95a,_0x7d2127,_0x5dc4f9['path'],_0x1616fe,_0x1d902f);else throw ot('Unknown\x20operation\x20type:\x20'+_0x5dc4f9['type']);}}}const _0x147f2e=_0x1d902f['getChanges']();return Su(_0x7d2127,_0x61d502,_0x147f2e),{'viewCache':_0x61d502,'changes':_0x147f2e};}function Su(_0x2a7a56,_0x4766d1,_0x4f341c){const _0x10c724=_0x4766d1['eventCache'];if(_0x10c724['isFullyInitialized']()){const _0x4c24a6=_0x10c724['getNode']()['isLeafNode']()||_0x10c724['getNode']()['isEmpty'](),_0x4fb68e=gn(_0x2a7a56);(_0x4f341c['length']>0x0||!_0x2a7a56['eventCache']['isFullyInitialized']()||_0x4c24a6&&!_0x10c724['getNode']()['equals'](_0x4fb68e)||!_0x10c724['getNode']()['getPriority']()['equals'](_0x4fb68e['getPriority']()))&&_0x4f341c['push'](Oo(gn(_0x4766d1)));}}function Ho(_0x25ccb4,_0x109332,_0x4b9389,_0x34fc41,_0x91cba3,_0x1e939b){const _0x3dca4e=_0x109332['eventCache'];if(yn(_0x34fc41,_0x4b9389)!=null)return _0x109332;{let _0x30d28d,_0x1f816e;if(v(_0x4b9389)){if(f(_0x109332['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x109332['serverCache']['isFiltered']()){const _0x1e7e26=Ue(_0x109332),_0x2c11d2=_0x1e7e26 instanceof g?_0x1e7e26:g['EMPTY_NODE'],_0x44ac2f=es(_0x34fc41,_0x2c11d2);_0x30d28d=_0x25ccb4['filter']['updateFullNode'](_0x109332['eventCache']['getNode'](),_0x44ac2f,_0x1e939b);}else{const _0x31ed96=mn(_0x34fc41,Ue(_0x109332));_0x30d28d=_0x25ccb4['filter']['updateFullNode'](_0x109332['eventCache']['getNode'](),_0x31ed96,_0x1e939b);}}else{const _0x513e16=y(_0x4b9389);if(_0x513e16==='.priority'){f(we(_0x4b9389)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x19ae8a=_0x3dca4e['getNode']();_0x1f816e=_0x109332['serverCache']['getNode']();const _0x2f926a=or(_0x34fc41,_0x4b9389,_0x19ae8a,_0x1f816e);_0x2f926a!=null?_0x30d28d=_0x25ccb4['filter']['updatePriority'](_0x19ae8a,_0x2f926a):_0x30d28d=_0x3dca4e['getNode']();}else{const _0x329de9=b(_0x4b9389);let _0x1e3dde;if(_0x3dca4e['isCompleteForChild'](_0x513e16)){_0x1f816e=_0x109332['serverCache']['getNode']();const _0x116f36=or(_0x34fc41,_0x4b9389,_0x3dca4e['getNode'](),_0x1f816e);_0x116f36!=null?_0x1e3dde=_0x3dca4e['getNode']()['getImmediateChild'](_0x513e16)['updateChild'](_0x329de9,_0x116f36):_0x1e3dde=_0x3dca4e['getNode']()['getImmediateChild'](_0x513e16);}else _0x1e3dde=ts(_0x34fc41,_0x513e16,_0x109332['serverCache']);_0x1e3dde!=null?_0x30d28d=_0x25ccb4['filter']['updateChild'](_0x3dca4e['getNode'](),_0x513e16,_0x1e3dde,_0x329de9,_0x91cba3,_0x1e939b):_0x30d28d=_0x3dca4e['getNode']();}}return wt(_0x109332,_0x30d28d,_0x3dca4e['isFullyInitialized']()||v(_0x4b9389),_0x25ccb4['filter']['filtersNodes']());}}function vn(_0xc7f619,_0xc72d27,_0x2e4c8d,_0x4772a2,_0xb21591,_0x4c2b5b,_0x2fde95,_0xc8a792){const _0x274908=_0xc72d27['serverCache'];let _0x2ada4f;const _0x5b067d=_0x2fde95?_0xc7f619['filter']:_0xc7f619['filter']['getIndexedFilter']();if(v(_0x2e4c8d))_0x2ada4f=_0x5b067d['updateFullNode'](_0x274908['getNode'](),_0x4772a2,null);else{if(_0x5b067d['filtersNodes']()&&!_0x274908['isFiltered']()){const _0x144696=_0x274908['getNode']()['updateChild'](_0x2e4c8d,_0x4772a2);_0x2ada4f=_0x5b067d['updateFullNode'](_0x274908['getNode'](),_0x144696,null);}else{const _0x71dca2=y(_0x2e4c8d);if(!_0x274908['isCompleteForPath'](_0x2e4c8d)&&we(_0x2e4c8d)>0x1)return _0xc72d27;const _0x3844a5=b(_0x2e4c8d),_0x27ff5a=_0x274908['getNode']()['getImmediateChild'](_0x71dca2)['updateChild'](_0x3844a5,_0x4772a2);_0x71dca2==='.priority'?_0x2ada4f=_0x5b067d['updatePriority'](_0x274908['getNode'](),_0x27ff5a):_0x2ada4f=_0x5b067d['updateChild'](_0x274908['getNode'](),_0x71dca2,_0x27ff5a,_0x3844a5,Vo,null);}}const _0x1d013e=Lo(_0xc72d27,_0x2ada4f,_0x274908['isFullyInitialized']()||v(_0x2e4c8d),_0x5b067d['filtersNodes']()),_0x55ad95=new ns(_0xb21591,_0x1d013e,_0x4c2b5b);return Ho(_0xc7f619,_0x1d013e,_0x2e4c8d,_0xb21591,_0x55ad95,_0xc8a792);}function Ti(_0x61b44,_0x1f67d1,_0x450393,_0x118e91,_0x8e0a67,_0x3c1061,_0x49c5a8){const _0x4c9a20=_0x1f67d1['eventCache'];let _0x182c98,_0x1007a;const _0x2f4f25=new ns(_0x8e0a67,_0x1f67d1,_0x3c1061);if(v(_0x450393))_0x1007a=_0x61b44['filter']['updateFullNode'](_0x1f67d1['eventCache']['getNode'](),_0x118e91,_0x49c5a8),_0x182c98=wt(_0x1f67d1,_0x1007a,!0x0,_0x61b44['filter']['filtersNodes']());else{const _0x328834=y(_0x450393);if(_0x328834==='.priority')_0x1007a=_0x61b44['filter']['updatePriority'](_0x1f67d1['eventCache']['getNode'](),_0x118e91),_0x182c98=wt(_0x1f67d1,_0x1007a,_0x4c9a20['isFullyInitialized'](),_0x4c9a20['isFiltered']());else{const _0x50e952=b(_0x450393),_0x1c1832=_0x4c9a20['getNode']()['getImmediateChild'](_0x328834);let _0x40f3a5;if(v(_0x50e952))_0x40f3a5=_0x118e91;else{const _0x1530c8=_0x2f4f25['getCompleteChild'](_0x328834);_0x1530c8!=null?Gi(_0x50e952)==='.priority'&&_0x1530c8['getChild'](To(_0x50e952))['isEmpty']()?_0x40f3a5=_0x1530c8:_0x40f3a5=_0x1530c8['updateChild'](_0x50e952,_0x118e91):_0x40f3a5=g['EMPTY_NODE'];}if(_0x1c1832['equals'](_0x40f3a5))_0x182c98=_0x1f67d1;else{const _0x5e12bf=_0x61b44['filter']['updateChild'](_0x4c9a20['getNode'](),_0x328834,_0x40f3a5,_0x50e952,_0x2f4f25,_0x49c5a8);_0x182c98=wt(_0x1f67d1,_0x5e12bf,_0x4c9a20['isFullyInitialized'](),_0x61b44['filter']['filtersNodes']());}}}return _0x182c98;}function ar(_0x313da3,_0x51b216){return _0x313da3['eventCache']['isCompleteForChild'](_0x51b216);}function bu(_0x5710d7,_0x286159,_0x509cfa,_0x3ea72c,_0xa3699a,_0x5c29aa,_0x56c426){let _0x546ba8=_0x286159;return _0x3ea72c['foreach']((_0x49cff8,_0x3852a9)=>{const _0x3e2aa4=A(_0x509cfa,_0x49cff8);ar(_0x286159,y(_0x3e2aa4))&&(_0x546ba8=Ti(_0x5710d7,_0x546ba8,_0x3e2aa4,_0x3852a9,_0xa3699a,_0x5c29aa,_0x56c426));}),_0x3ea72c['foreach']((_0x5007ee,_0xdd6922)=>{const _0x21aa69=A(_0x509cfa,_0x5007ee);ar(_0x286159,y(_0x21aa69))||(_0x546ba8=Ti(_0x5710d7,_0x546ba8,_0x21aa69,_0xdd6922,_0xa3699a,_0x5c29aa,_0x56c426));}),_0x546ba8;}function cr(_0x37bd28,_0x40f327,_0x552e7e){return _0x552e7e['foreach']((_0x38ca66,_0x3d4441)=>{_0x40f327=_0x40f327['updateChild'](_0x38ca66,_0x3d4441);}),_0x40f327;}function Si(_0x287f97,_0x1b470b,_0x535452,_0x19a447,_0x42dfc4,_0x458d68,_0x541024,_0x1e82af){if(_0x1b470b['serverCache']['getNode']()['isEmpty']()&&!_0x1b470b['serverCache']['isFullyInitialized']())return _0x1b470b;let _0xd80963=_0x1b470b,_0x175f20;v(_0x535452)?_0x175f20=_0x19a447:_0x175f20=new S(null)['setTree'](_0x535452,_0x19a447);const _0x344c9a=_0x1b470b['serverCache']['getNode']();return _0x175f20['children']['inorderTraversal']((_0x5db177,_0x179538)=>{if(_0x344c9a['hasChild'](_0x5db177)){const _0x2e8369=_0x1b470b['serverCache']['getNode']()['getImmediateChild'](_0x5db177),_0x37d4d7=cr(_0x287f97,_0x2e8369,_0x179538);_0xd80963=vn(_0x287f97,_0xd80963,new C(_0x5db177),_0x37d4d7,_0x42dfc4,_0x458d68,_0x541024,_0x1e82af);}}),_0x175f20['children']['inorderTraversal']((_0x374e28,_0x3a506d)=>{const _0x1d2b0b=!_0x1b470b['serverCache']['isCompleteForChild'](_0x374e28)&&_0x3a506d['value']===null;if(!_0x344c9a['hasChild'](_0x374e28)&&!_0x1d2b0b){const _0x2183db=_0x1b470b['serverCache']['getNode']()['getImmediateChild'](_0x374e28),_0x2f2d15=cr(_0x287f97,_0x2183db,_0x3a506d);_0xd80963=vn(_0x287f97,_0xd80963,new C(_0x374e28),_0x2f2d15,_0x42dfc4,_0x458d68,_0x541024,_0x1e82af);}}),_0xd80963;}function Ru(_0x24ab90,_0x538d89,_0x54328a,_0x49d279,_0x177a4f,_0x192ee8,_0x58029f){if(yn(_0x177a4f,_0x54328a)!=null)return _0x538d89;const _0x1c41dc=_0x538d89['serverCache']['isFiltered'](),_0x161802=_0x538d89['serverCache'];if(_0x49d279['value']!=null){if(v(_0x54328a)&&_0x161802['isFullyInitialized']()||_0x161802['isCompleteForPath'](_0x54328a))return vn(_0x24ab90,_0x538d89,_0x54328a,_0x161802['getNode']()['getChild'](_0x54328a),_0x177a4f,_0x192ee8,_0x1c41dc,_0x58029f);if(v(_0x54328a)){let _0x4fb36f=new S(null);return _0x161802['getNode']()['forEachChild'](ye,(_0x362c92,_0x5b4028)=>{_0x4fb36f=_0x4fb36f['set'](new C(_0x362c92),_0x5b4028);}),Si(_0x24ab90,_0x538d89,_0x54328a,_0x4fb36f,_0x177a4f,_0x192ee8,_0x1c41dc,_0x58029f);}else return _0x538d89;}else{let _0x2f0d2f=new S(null);return _0x49d279['foreach']((_0x5a2ae6,_0x22906c)=>{const _0x272145=A(_0x54328a,_0x5a2ae6);_0x161802['isCompleteForPath'](_0x272145)&&(_0x2f0d2f=_0x2f0d2f['set'](_0x5a2ae6,_0x161802['getNode']()['getChild'](_0x272145)));}),Si(_0x24ab90,_0x538d89,_0x54328a,_0x2f0d2f,_0x177a4f,_0x192ee8,_0x1c41dc,_0x58029f);}}function Au(_0xe55c19,_0x23847d,_0x81cbbb,_0x2aa197,_0x53812d){const _0x2d2624=_0x23847d['serverCache'],_0x555b90=Lo(_0x23847d,_0x2d2624['getNode'](),_0x2d2624['isFullyInitialized']()||v(_0x81cbbb),_0x2d2624['isFiltered']());return Ho(_0xe55c19,_0x555b90,_0x81cbbb,_0x2aa197,Vo,_0x53812d);}function ku(_0x1444f0,_0x39e260,_0x1dab1f,_0x31f2d8,_0x4a08a5,_0x2893a3){let _0x58262c;if(yn(_0x31f2d8,_0x1dab1f)!=null)return _0x39e260;{const _0x5d3ef3=new ns(_0x31f2d8,_0x39e260,_0x4a08a5),_0x708cc9=_0x39e260['eventCache']['getNode']();let _0x5b0099;if(v(_0x1dab1f)||y(_0x1dab1f)==='.priority'){let _0x1555ef;if(_0x39e260['serverCache']['isFullyInitialized']())_0x1555ef=mn(_0x31f2d8,Ue(_0x39e260));else{const _0x26984b=_0x39e260['serverCache']['getNode']();f(_0x26984b instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1555ef=es(_0x31f2d8,_0x26984b);}_0x1555ef=_0x1555ef,_0x5b0099=_0x1444f0['filter']['updateFullNode'](_0x708cc9,_0x1555ef,_0x2893a3);}else{const _0x13320a=y(_0x1dab1f);let _0x26284d=ts(_0x31f2d8,_0x13320a,_0x39e260['serverCache']);_0x26284d==null&&_0x39e260['serverCache']['isCompleteForChild'](_0x13320a)&&(_0x26284d=_0x708cc9['getImmediateChild'](_0x13320a)),_0x26284d!=null?_0x5b0099=_0x1444f0['filter']['updateChild'](_0x708cc9,_0x13320a,_0x26284d,b(_0x1dab1f),_0x5d3ef3,_0x2893a3):_0x39e260['eventCache']['getNode']()['hasChild'](_0x13320a)?_0x5b0099=_0x1444f0['filter']['updateChild'](_0x708cc9,_0x13320a,g['EMPTY_NODE'],b(_0x1dab1f),_0x5d3ef3,_0x2893a3):_0x5b0099=_0x708cc9,_0x5b0099['isEmpty']()&&_0x39e260['serverCache']['isFullyInitialized']()&&(_0x58262c=mn(_0x31f2d8,Ue(_0x39e260)),_0x58262c['isLeafNode']()&&(_0x5b0099=_0x1444f0['filter']['updateFullNode'](_0x5b0099,_0x58262c,_0x2893a3)));}return _0x58262c=_0x39e260['serverCache']['isFullyInitialized']()||yn(_0x31f2d8,w())!=null,wt(_0x39e260,_0x5b0099,_0x58262c,_0x1444f0['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x29b64f,_0xbd24fd){this['query_']=_0x29b64f,this['eventRegistrations_']=[];const _0x3583d8=this['query_']['_queryParams'],_0x5378ca=new Yi(_0x3583d8['getIndex']()),_0x564fd2=qh(_0x3583d8);this['processor_']=wu(_0x564fd2);const _0x8bcb7f=_0xbd24fd['serverCache'],_0x1addd2=_0xbd24fd['eventCache'],_0x26f5dc=_0x5378ca['updateFullNode'](g['EMPTY_NODE'],_0x8bcb7f['getNode'](),null),_0x49a260=_0x564fd2['updateFullNode'](g['EMPTY_NODE'],_0x1addd2['getNode'](),null),_0x2b97b9=new Ce(_0x26f5dc,_0x8bcb7f['isFullyInitialized'](),_0x5378ca['filtersNodes']()),_0x4da7da=new Ce(_0x49a260,_0x1addd2['isFullyInitialized'](),_0x564fd2['filtersNodes']());this['viewCache_']=Dn(_0x4da7da,_0x2b97b9),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3128e5){return _0x3128e5['viewCache_']['serverCache']['getNode']();}function Ou(_0x4324b1){return gn(_0x4324b1['viewCache_']);}function Du(_0x10f174,_0x5986fd){const _0x45779a=Ue(_0x10f174['viewCache_']);return _0x45779a&&(_0x10f174['query']['_queryParams']['loadsAllData']()||!v(_0x5986fd)&&!_0x45779a['getImmediateChild'](y(_0x5986fd))['isEmpty']())?_0x45779a['getChild'](_0x5986fd):null;}function lr(_0x5f1277){return _0x5f1277['eventRegistrations_']['length']===0x0;}function Mu(_0x14ae1c,_0x25383b){_0x14ae1c['eventRegistrations_']['push'](_0x25383b);}function hr(_0x352014,_0x2a11af,_0xe21f34){const _0x43af4d=[];if(_0xe21f34){f(_0x2a11af==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x7a5964=_0x352014['query']['_path'];_0x352014['eventRegistrations_']['forEach'](_0x32e680=>{const _0x4743b4=_0x32e680['createCancelEvent'](_0xe21f34,_0x7a5964);_0x4743b4&&_0x43af4d['push'](_0x4743b4);});}if(_0x2a11af){let _0x13bb47=[];for(let _0x4845f8=0x0;_0x4845f8<_0x352014['eventRegistrations_']['length'];++_0x4845f8){const _0x6e806=_0x352014['eventRegistrations_'][_0x4845f8];if(!_0x6e806['matches'](_0x2a11af))_0x13bb47['push'](_0x6e806);else{if(_0x2a11af['hasAnyCallback']()){_0x13bb47=_0x13bb47['concat'](_0x352014['eventRegistrations_']['slice'](_0x4845f8+0x1));break;}}}_0x352014['eventRegistrations_']=_0x13bb47;}else _0x352014['eventRegistrations_']=[];return _0x43af4d;}function ur(_0x4596bb,_0x2c6d64,_0x341a5f,_0x192d7b){_0x2c6d64['type']===q['MERGE']&&_0x2c6d64['source']['queryId']!==null&&(f(Ue(_0x4596bb['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x4596bb['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xc1b394=_0x4596bb['viewCache_'],_0x40713c=Tu(_0x4596bb['processor_'],_0xc1b394,_0x2c6d64,_0x341a5f,_0x192d7b);return Cu(_0x4596bb['processor_'],_0x40713c['viewCache']),f(_0x40713c['viewCache']['serverCache']['isFullyInitialized']()||!_0xc1b394['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4596bb['viewCache_']=_0x40713c['viewCache'],$o(_0x4596bb,_0x40713c['changes'],_0x40713c['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x2aa77b,_0x325d45){const _0x3c3558=_0x2aa77b['viewCache_']['eventCache'],_0x167a44=[];return _0x3c3558['getNode']()['isLeafNode']()||_0x3c3558['getNode']()['forEachChild'](R,(_0x84ec23,_0x38e131)=>{_0x167a44['push'](tt(_0x84ec23,_0x38e131));}),_0x3c3558['isFullyInitialized']()&&_0x167a44['push'](Oo(_0x3c3558['getNode']())),$o(_0x2aa77b,_0x167a44,_0x3c3558['getNode'](),_0x325d45);}function $o(_0x466f17,_0x590812,_0x106a4e,_0x58f8a9){const _0x4a2f9f=_0x58f8a9?[_0x58f8a9]:_0x466f17['eventRegistrations_'];return nu(_0x466f17['eventGenerator_'],_0x590812,_0x106a4e,_0x4a2f9f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x17c39a){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x17c39a;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x14552b){return _0x14552b['views']['size']===0x0;}function is(_0x4f8981,_0x1d5ee9,_0x2e4533,_0x35f03b){const _0x22d64a=_0x1d5ee9['source']['queryId'];if(_0x22d64a!==null){const _0xd43511=_0x4f8981['views']['get'](_0x22d64a);return f(_0xd43511!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xd43511,_0x1d5ee9,_0x2e4533,_0x35f03b);}else{let _0x4fbced=[];for(const _0x4a2c8c of _0x4f8981['views']['values']())_0x4fbced=_0x4fbced['concat'](ur(_0x4a2c8c,_0x1d5ee9,_0x2e4533,_0x35f03b));return _0x4fbced;}}function qo(_0xf4f486,_0x28ed4a,_0x7774d4,_0x39a79b,_0x107b4b){const _0x38fa6b=_0x28ed4a['_queryIdentifier'],_0x5c3f9f=_0xf4f486['views']['get'](_0x38fa6b);if(!_0x5c3f9f){let _0x2f6703=mn(_0x7774d4,_0x107b4b?_0x39a79b:null),_0x338334=!0x1;_0x2f6703?_0x338334=!0x0:_0x39a79b instanceof g?(_0x2f6703=es(_0x7774d4,_0x39a79b),_0x338334=!0x1):(_0x2f6703=g['EMPTY_NODE'],_0x338334=!0x1);const _0x24e635=Dn(new Ce(_0x2f6703,_0x338334,!0x1),new Ce(_0x39a79b,_0x107b4b,!0x1));return new Nu(_0x28ed4a,_0x24e635);}return _0x5c3f9f;}function Wu(_0x2e363b,_0x482f88,_0xd2bc0a,_0x1adf58,_0x4b5436,_0x25da9b){const _0x15a97d=qo(_0x2e363b,_0x482f88,_0x1adf58,_0x4b5436,_0x25da9b);return _0x2e363b['views']['has'](_0x482f88['_queryIdentifier'])||_0x2e363b['views']['set'](_0x482f88['_queryIdentifier'],_0x15a97d),Mu(_0x15a97d,_0xd2bc0a),Lu(_0x15a97d,_0xd2bc0a);}function Bu(_0x10f916,_0x5453a5,_0x37deef,_0x2659cc){const _0x526f7d=_0x5453a5['_queryIdentifier'],_0x42b17f=[];let _0x4f5887=[];const _0x4a33a=Te(_0x10f916);if(_0x526f7d==='default'){for(const [_0x30dc3a,_0x46280d]of _0x10f916['views']['entries']())_0x4f5887=_0x4f5887['concat'](hr(_0x46280d,_0x37deef,_0x2659cc)),lr(_0x46280d)&&(_0x10f916['views']['delete'](_0x30dc3a),_0x46280d['query']['_queryParams']['loadsAllData']()||_0x42b17f['push'](_0x46280d['query']));}else{const _0x436f84=_0x10f916['views']['get'](_0x526f7d);_0x436f84&&(_0x4f5887=_0x4f5887['concat'](hr(_0x436f84,_0x37deef,_0x2659cc)),lr(_0x436f84)&&(_0x10f916['views']['delete'](_0x526f7d),_0x436f84['query']['_queryParams']['loadsAllData']()||_0x42b17f['push'](_0x436f84['query'])));}return _0x4a33a&&!Te(_0x10f916)&&_0x42b17f['push'](new(Fu())(_0x5453a5['_repo'],_0x5453a5['_path'])),{'removed':_0x42b17f,'events':_0x4f5887};}function zo(_0xbbc212){const _0x16300b=[];for(const _0x1115aa of _0xbbc212['views']['values']())_0x1115aa['query']['_queryParams']['loadsAllData']()||_0x16300b['push'](_0x1115aa);return _0x16300b;}function Ee(_0x3ba219,_0xe0983b){let _0x2fd580=null;for(const _0x555434 of _0x3ba219['views']['values']())_0x2fd580=_0x2fd580||Du(_0x555434,_0xe0983b);return _0x2fd580;}function jo(_0x4cfe88,_0x1a2607){if(_0x1a2607['_queryParams']['loadsAllData']())return Ln(_0x4cfe88);{const _0x218bde=_0x1a2607['_queryIdentifier'];return _0x4cfe88['views']['get'](_0x218bde);}}function Ko(_0x223ced,_0x16cca1){return jo(_0x223ced,_0x16cca1)!=null;}function Te(_0x1652b7){return Ln(_0x1652b7)!=null;}function Ln(_0x3ebd96){for(const _0x22cc58 of _0x3ebd96['views']['values']())if(_0x22cc58['query']['_queryParams']['loadsAllData']())return _0x22cc58;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x56d1d7){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x56d1d7;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0xad8183){this['listenProvider_']=_0xad8183,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x1e2cef,_0x4ec6ec,_0x314430,_0xad11de,_0x3a0e2f){return ou(_0x1e2cef['pendingWriteTree_'],_0x4ec6ec,_0x314430,_0xad11de,_0x3a0e2f),_0x3a0e2f?ht(_0x1e2cef,new Fe(Ji(),_0x4ec6ec,_0x314430)):[];}function Gu(_0x433a27,_0x2c55bd,_0x38766e,_0x2713eb){au(_0x433a27['pendingWriteTree_'],_0x2c55bd,_0x38766e,_0x2713eb);const _0x325d0a=S['fromObject'](_0x38766e);return ht(_0x433a27,new nt(Ji(),_0x2c55bd,_0x325d0a));}function pe(_0x19b9d8,_0x2d9d82,_0x20569f=!0x1){const _0x5db703=cu(_0x19b9d8['pendingWriteTree_'],_0x2d9d82);if(lu(_0x19b9d8['pendingWriteTree_'],_0x2d9d82)){let _0x5e2c6d=new S(null);return _0x5db703['snap']!=null?_0x5e2c6d=_0x5e2c6d['set'](w(),!0x0):x(_0x5db703['children'],_0x20e344=>{_0x5e2c6d=_0x5e2c6d['set'](new C(_0x20e344),!0x0);}),ht(_0x19b9d8,new _n(_0x5db703['path'],_0x5e2c6d,_0x20569f));}else return[];}function $t(_0x3bf083,_0x2ba1cc,_0x500bf2){return ht(_0x3bf083,new Fe(Xi(),_0x2ba1cc,_0x500bf2));}function qu(_0x3531a1,_0x1f2704,_0x1da7ba){const _0x248778=S['fromObject'](_0x1da7ba);return ht(_0x3531a1,new nt(Xi(),_0x1f2704,_0x248778));}function zu(_0x2c0217,_0x3a0310){return ht(_0x2c0217,new Dt(Xi(),_0x3a0310));}function ju(_0x4390c4,_0x2e0238,_0x129079){const _0x26b578=rs(_0x4390c4,_0x129079);if(_0x26b578){const _0x31c522=os(_0x26b578),_0x4cb355=_0x31c522['path'],_0x304c7a=_0x31c522['queryId'],_0xd95c59=F(_0x4cb355,_0x2e0238),_0x338725=new Dt(Zi(_0x304c7a),_0xd95c59);return as(_0x4390c4,_0x4cb355,_0x338725);}else return[];}function wn(_0x4bd7e7,_0x1e26b3,_0x3e52fa,_0x236221,_0x28a2f4=!0x1){const _0x66bedf=_0x1e26b3['_path'],_0x4ef9c7=_0x4bd7e7['syncPointTree_']['get'](_0x66bedf);let _0x32a11a=[];if(_0x4ef9c7&&(_0x1e26b3['_queryIdentifier']==='default'||Ko(_0x4ef9c7,_0x1e26b3))){const _0x597b34=Bu(_0x4ef9c7,_0x1e26b3,_0x3e52fa,_0x236221);Uu(_0x4ef9c7)&&(_0x4bd7e7['syncPointTree_']=_0x4bd7e7['syncPointTree_']['remove'](_0x66bedf));const _0x58922c=_0x597b34['removed'];if(_0x32a11a=_0x597b34['events'],!_0x28a2f4){const _0x216a8c=_0x58922c['findIndex'](_0x26b642=>_0x26b642['_queryParams']['loadsAllData']())!==-0x1,_0x38a23a=_0x4bd7e7['syncPointTree_']['findOnPath'](_0x66bedf,(_0xa15ec0,_0x387b00)=>Te(_0x387b00));if(_0x216a8c&&!_0x38a23a){const _0x56eb81=_0x4bd7e7['syncPointTree_']['subtree'](_0x66bedf);if(!_0x56eb81['isEmpty']()){const _0x25fdaf=Qu(_0x56eb81);for(let _0x51f879=0x0;_0x51f879<_0x25fdaf['length'];++_0x51f879){const _0x564c7f=_0x25fdaf[_0x51f879],_0x15dfc8=_0x564c7f['query'],_0x4f1e7a=Xo(_0x4bd7e7,_0x564c7f);_0x4bd7e7['listenProvider_']['startListening'](Tt(_0x15dfc8),Mt(_0x4bd7e7,_0x15dfc8),_0x4f1e7a['hashFn'],_0x4f1e7a['onComplete']);}}}!_0x38a23a&&_0x58922c['length']>0x0&&!_0x236221&&(_0x216a8c?_0x4bd7e7['listenProvider_']['stopListening'](Tt(_0x1e26b3),null):_0x58922c['forEach'](_0x40189a=>{const _0x5adc61=_0x4bd7e7['queryToTagMap']['get'](Fn(_0x40189a));_0x4bd7e7['listenProvider_']['stopListening'](Tt(_0x40189a),_0x5adc61);}));}Ju(_0x4bd7e7,_0x58922c);}return _0x32a11a;}function Yo(_0x44100b,_0xc74655,_0x36cc6a,_0x393039){const _0x3ca0b7=rs(_0x44100b,_0x393039);if(_0x3ca0b7!=null){const _0x30fbe9=os(_0x3ca0b7),_0x39f5a9=_0x30fbe9['path'],_0x3a48dc=_0x30fbe9['queryId'],_0x518748=F(_0x39f5a9,_0xc74655),_0xf2d399=new Fe(Zi(_0x3a48dc),_0x518748,_0x36cc6a);return as(_0x44100b,_0x39f5a9,_0xf2d399);}else return[];}function Ku(_0x5bc995,_0x43f28f,_0x3e3b72,_0x51b435){const _0x55d806=rs(_0x5bc995,_0x51b435);if(_0x55d806){const _0x6e2a1=os(_0x55d806),_0x4eba93=_0x6e2a1['path'],_0x4649e2=_0x6e2a1['queryId'],_0x11b6b4=F(_0x4eba93,_0x43f28f),_0x2c14a2=S['fromObject'](_0x3e3b72),_0x36c4fe=new nt(Zi(_0x4649e2),_0x11b6b4,_0x2c14a2);return as(_0x5bc995,_0x4eba93,_0x36c4fe);}else return[];}function bi(_0x41c6cd,_0x924be9,_0x285e36,_0x53982=!0x1){const _0x35d0b0=_0x924be9['_path'];let _0x237c91=null,_0x41913c=!0x1;_0x41c6cd['syncPointTree_']['foreachOnPath'](_0x35d0b0,(_0x51f172,_0x3b9fda)=>{const _0x2cb5aa=F(_0x51f172,_0x35d0b0);_0x237c91=_0x237c91||Ee(_0x3b9fda,_0x2cb5aa),_0x41913c=_0x41913c||Te(_0x3b9fda);});let _0x1b42cd=_0x41c6cd['syncPointTree_']['get'](_0x35d0b0);_0x1b42cd?(_0x41913c=_0x41913c||Te(_0x1b42cd),_0x237c91=_0x237c91||Ee(_0x1b42cd,w())):(_0x1b42cd=new Go(),_0x41c6cd['syncPointTree_']=_0x41c6cd['syncPointTree_']['set'](_0x35d0b0,_0x1b42cd));let _0x19de2f;_0x237c91!=null?_0x19de2f=!0x0:(_0x19de2f=!0x1,_0x237c91=g['EMPTY_NODE'],_0x41c6cd['syncPointTree_']['subtree'](_0x35d0b0)['foreachChild']((_0x5d104a,_0x31291a)=>{const _0x425e0b=Ee(_0x31291a,w());_0x425e0b&&(_0x237c91=_0x237c91['updateImmediateChild'](_0x5d104a,_0x425e0b));}));const _0x533c99=Ko(_0x1b42cd,_0x924be9);if(!_0x533c99&&!_0x924be9['_queryParams']['loadsAllData']()){const _0x54acb6=Fn(_0x924be9);f(!_0x41c6cd['queryToTagMap']['has'](_0x54acb6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x4329c5=Xu();_0x41c6cd['queryToTagMap']['set'](_0x54acb6,_0x4329c5),_0x41c6cd['tagToQueryMap']['set'](_0x4329c5,_0x54acb6);}const _0x260523=Mn(_0x41c6cd['pendingWriteTree_'],_0x35d0b0);let _0x4c417e=Wu(_0x1b42cd,_0x924be9,_0x285e36,_0x260523,_0x237c91,_0x19de2f);if(!_0x533c99&&!_0x41913c&&!_0x53982){const _0x10930c=jo(_0x1b42cd,_0x924be9);_0x4c417e=_0x4c417e['concat'](Zu(_0x41c6cd,_0x924be9,_0x10930c));}return _0x4c417e;}function xn(_0x42661a,_0xfba2ae,_0x18b547){const _0x4f478a=_0x42661a['pendingWriteTree_'],_0x65c8da=_0x42661a['syncPointTree_']['findOnPath'](_0xfba2ae,(_0x146f8b,_0x309aed)=>{const _0x261713=F(_0x146f8b,_0xfba2ae),_0x438682=Ee(_0x309aed,_0x261713);if(_0x438682)return _0x438682;});return Uo(_0x4f478a,_0xfba2ae,_0x65c8da,_0x18b547,!0x0);}function Yu(_0x24c4c2,_0x1db98f){const _0x5b54bd=_0x1db98f['_path'];let _0x19195a=null;_0x24c4c2['syncPointTree_']['foreachOnPath'](_0x5b54bd,(_0x52500e,_0x310b19)=>{const _0x15b01d=F(_0x52500e,_0x5b54bd);_0x19195a=_0x19195a||Ee(_0x310b19,_0x15b01d);});let _0x30ae21=_0x24c4c2['syncPointTree_']['get'](_0x5b54bd);_0x30ae21?_0x19195a=_0x19195a||Ee(_0x30ae21,w()):(_0x30ae21=new Go(),_0x24c4c2['syncPointTree_']=_0x24c4c2['syncPointTree_']['set'](_0x5b54bd,_0x30ae21));const _0x5c3e4e=_0x19195a!=null,_0x2da4ca=_0x5c3e4e?new Ce(_0x19195a,!0x0,!0x1):null,_0x5d3f73=Mn(_0x24c4c2['pendingWriteTree_'],_0x1db98f['_path']),_0x18453b=qo(_0x30ae21,_0x1db98f,_0x5d3f73,_0x5c3e4e?_0x2da4ca['getNode']():g['EMPTY_NODE'],_0x5c3e4e);return Ou(_0x18453b);}function ht(_0x33be48,_0x4518b2){return Qo(_0x4518b2,_0x33be48['syncPointTree_'],null,Mn(_0x33be48['pendingWriteTree_'],w()));}function Qo(_0xaa474a,_0x198fab,_0x5302f7,_0x2c2bd4){if(v(_0xaa474a['path']))return Jo(_0xaa474a,_0x198fab,_0x5302f7,_0x2c2bd4);{const _0x133bda=_0x198fab['get'](w());_0x5302f7==null&&_0x133bda!=null&&(_0x5302f7=Ee(_0x133bda,w()));let _0x33a402=[];const _0x3250fd=y(_0xaa474a['path']),_0x363312=_0xaa474a['operationForChild'](_0x3250fd),_0x35f2cc=_0x198fab['children']['get'](_0x3250fd);if(_0x35f2cc&&_0x363312){const _0x90996b=_0x5302f7?_0x5302f7['getImmediateChild'](_0x3250fd):null,_0x310f2d=Wo(_0x2c2bd4,_0x3250fd);_0x33a402=_0x33a402['concat'](Qo(_0x363312,_0x35f2cc,_0x90996b,_0x310f2d));}return _0x133bda&&(_0x33a402=_0x33a402['concat'](is(_0x133bda,_0xaa474a,_0x2c2bd4,_0x5302f7))),_0x33a402;}}function Jo(_0x55efd7,_0x27d216,_0xbabbf2,_0x21e466){const _0x19f67a=_0x27d216['get'](w());_0xbabbf2==null&&_0x19f67a!=null&&(_0xbabbf2=Ee(_0x19f67a,w()));let _0x37a978=[];return _0x27d216['children']['inorderTraversal']((_0x402577,_0x20e4a4)=>{const _0x2a42d5=_0xbabbf2?_0xbabbf2['getImmediateChild'](_0x402577):null,_0x25dd12=Wo(_0x21e466,_0x402577),_0x24d5f9=_0x55efd7['operationForChild'](_0x402577);_0x24d5f9&&(_0x37a978=_0x37a978['concat'](Jo(_0x24d5f9,_0x20e4a4,_0x2a42d5,_0x25dd12)));}),_0x19f67a&&(_0x37a978=_0x37a978['concat'](is(_0x19f67a,_0x55efd7,_0x21e466,_0xbabbf2))),_0x37a978;}function Xo(_0x2a9082,_0x314bf3){const _0x358ef7=_0x314bf3['query'],_0x4e0a5e=Mt(_0x2a9082,_0x358ef7);return{'hashFn':()=>(Pu(_0x314bf3)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x35f2e9=>{if(_0x35f2e9==='ok')return _0x4e0a5e?ju(_0x2a9082,_0x358ef7['_path'],_0x4e0a5e):zu(_0x2a9082,_0x358ef7['_path']);{const _0x16e85b=ql(_0x35f2e9,_0x358ef7);return wn(_0x2a9082,_0x358ef7,null,_0x16e85b);}}};}function Mt(_0x2b69c9,_0x50a16c){const _0x49bab4=Fn(_0x50a16c);return _0x2b69c9['queryToTagMap']['get'](_0x49bab4);}function Fn(_0x5395fe){return _0x5395fe['_path']['toString']()+'$'+_0x5395fe['_queryIdentifier'];}function rs(_0x425044,_0x58bb5f){return _0x425044['tagToQueryMap']['get'](_0x58bb5f);}function os(_0x4607f8){const _0xdeca88=_0x4607f8['indexOf']('$');return f(_0xdeca88!==-0x1&&_0xdeca88<_0x4607f8['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4607f8['substr'](_0xdeca88+0x1),'path':new C(_0x4607f8['substr'](0x0,_0xdeca88))};}function as(_0xcb2a56,_0x5e5111,_0x5c843f){const _0xa17d44=_0xcb2a56['syncPointTree_']['get'](_0x5e5111);f(_0xa17d44,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x355c7a=Mn(_0xcb2a56['pendingWriteTree_'],_0x5e5111);return is(_0xa17d44,_0x5c843f,_0x355c7a,null);}function Qu(_0x5242ea){return _0x5242ea['fold']((_0x12ceee,_0x874e57,_0x4442b1)=>{if(_0x874e57&&Te(_0x874e57))return[Ln(_0x874e57)];{let _0xb81f28=[];return _0x874e57&&(_0xb81f28=zo(_0x874e57)),x(_0x4442b1,(_0x4c61cb,_0x458a22)=>{_0xb81f28=_0xb81f28['concat'](_0x458a22);}),_0xb81f28;}});}function Tt(_0x58d372){return _0x58d372['_queryParams']['loadsAllData']()&&!_0x58d372['_queryParams']['isDefault']()?new(Hu())(_0x58d372['_repo'],_0x58d372['_path']):_0x58d372;}function Ju(_0x2da8c9,_0x24bb98){for(let _0x2ff00d=0x0;_0x2ff00d<_0x24bb98['length'];++_0x2ff00d){const _0x59f873=_0x24bb98[_0x2ff00d];if(!_0x59f873['_queryParams']['loadsAllData']()){const _0x3356c1=Fn(_0x59f873),_0x1d7864=_0x2da8c9['queryToTagMap']['get'](_0x3356c1);_0x2da8c9['queryToTagMap']['delete'](_0x3356c1),_0x2da8c9['tagToQueryMap']['delete'](_0x1d7864);}}}function Xu(){return $u++;}function Zu(_0x23950b,_0x53a399,_0x5e18c9){const _0x5b7ab7=_0x53a399['_path'],_0x30a5e9=Mt(_0x23950b,_0x53a399),_0x5cd043=Xo(_0x23950b,_0x5e18c9),_0x20890e=_0x23950b['listenProvider_']['startListening'](Tt(_0x53a399),_0x30a5e9,_0x5cd043['hashFn'],_0x5cd043['onComplete']),_0x36c5b3=_0x23950b['syncPointTree_']['subtree'](_0x5b7ab7);if(_0x30a5e9)f(!Te(_0x36c5b3['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x280a68=_0x36c5b3['fold']((_0x3feb36,_0x56da1f,_0x5acf63)=>{if(!v(_0x3feb36)&&_0x56da1f&&Te(_0x56da1f))return[Ln(_0x56da1f)['query']];{let _0x86e112=[];return _0x56da1f&&(_0x86e112=_0x86e112['concat'](zo(_0x56da1f)['map'](_0x4e279a=>_0x4e279a['query']))),x(_0x5acf63,(_0x93974d,_0x4e2dc3)=>{_0x86e112=_0x86e112['concat'](_0x4e2dc3);}),_0x86e112;}});for(let _0x13414f=0x0;_0x13414f<_0x280a68['length'];++_0x13414f){const _0x150479=_0x280a68[_0x13414f];_0x23950b['listenProvider_']['stopListening'](Tt(_0x150479),Mt(_0x23950b,_0x150479));}}return _0x20890e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x59906e){this['node_']=_0x59906e;}['getImmediateChild'](_0x2d84fd){const _0x49fff1=this['node_']['getImmediateChild'](_0x2d84fd);return new cs(_0x49fff1);}['node'](){return this['node_'];}}class ls{constructor(_0x5d2c02,_0x5987e7){this['syncTree_']=_0x5d2c02,this['path_']=_0x5987e7;}['getImmediateChild'](_0xbb6122){const _0x180cae=A(this['path_'],_0xbb6122);return new ls(this['syncTree_'],_0x180cae);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x56618e){return _0x56618e=_0x56618e||{},_0x56618e['timestamp']=_0x56618e['timestamp']||new Date()['getTime'](),_0x56618e;},fr=function(_0x4f0553,_0x5697d4,_0xc46c19){if(!_0x4f0553||typeof _0x4f0553!='object')return _0x4f0553;if(f('.sv'in _0x4f0553,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4f0553['.sv']=='string')return td(_0x4f0553['.sv'],_0x5697d4,_0xc46c19);if(typeof _0x4f0553['.sv']=='object')return nd(_0x4f0553['.sv'],_0x5697d4);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4f0553,null,0x2));},td=function(_0x7ac0f4,_0x347aeb,_0x28f147){switch(_0x7ac0f4){case'timestamp':return _0x28f147['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x7ac0f4);}},nd=function(_0x27f1a8,_0x2b1ba1,_0x55571d){_0x27f1a8['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x27f1a8,null,0x2));const _0x57faf1=_0x27f1a8['increment'];typeof _0x57faf1!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x57faf1);const _0x11a49c=_0x2b1ba1['node']();if(f(_0x11a49c!==null&&typeof _0x11a49c<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x11a49c['isLeafNode']())return _0x57faf1;const _0x22224b=_0x11a49c['getValue']();return typeof _0x22224b!='number'?_0x57faf1:_0x22224b+_0x57faf1;},Zo=function(_0x5f3e03,_0x496d57,_0x1fdac0,_0x477d51){return us(_0x496d57,new ls(_0x1fdac0,_0x5f3e03),_0x477d51);},hs=function(_0x3d4094,_0x20c542,_0x1409ec){return us(_0x3d4094,new cs(_0x20c542),_0x1409ec);};function us(_0xb5896,_0x13b9c9,_0xc403d){const _0x4d31fa=_0xb5896['getPriority']()['val'](),_0x4e6dad=fr(_0x4d31fa,_0x13b9c9['getImmediateChild']('.priority'),_0xc403d);let _0x591911;if(_0xb5896['isLeafNode']()){const _0x3e1b8d=_0xb5896,_0x49e1b9=fr(_0x3e1b8d['getValue'](),_0x13b9c9,_0xc403d);return _0x49e1b9!==_0x3e1b8d['getValue']()||_0x4e6dad!==_0x3e1b8d['getPriority']()['val']()?new D(_0x49e1b9,N(_0x4e6dad)):_0xb5896;}else{const _0x392ea7=_0xb5896;return _0x591911=_0x392ea7,_0x4e6dad!==_0x392ea7['getPriority']()['val']()&&(_0x591911=_0x591911['updatePriority'](new D(_0x4e6dad))),_0x392ea7['forEachChild'](R,(_0x2f526a,_0x40e9ce)=>{const _0x249092=us(_0x40e9ce,_0x13b9c9['getImmediateChild'](_0x2f526a),_0xc403d);_0x249092!==_0x40e9ce&&(_0x591911=_0x591911['updateImmediateChild'](_0x2f526a,_0x249092));}),_0x591911;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x389bb4='',_0x3ec6fa=null,_0x44d477={'children':{},'childCount':0x0}){this['name']=_0x389bb4,this['parent']=_0x3ec6fa,this['node']=_0x44d477;}}function Un(_0x432e6f,_0x4d0d0a){let _0x8a4ce1=_0x4d0d0a instanceof C?_0x4d0d0a:new C(_0x4d0d0a),_0x5d959b=_0x432e6f,_0x5f2332=y(_0x8a4ce1);for(;_0x5f2332!==null;){const _0xa2c6e1=Oe(_0x5d959b['node']['children'],_0x5f2332)||{'children':{},'childCount':0x0};_0x5d959b=new ds(_0x5f2332,_0x5d959b,_0xa2c6e1),_0x8a4ce1=b(_0x8a4ce1),_0x5f2332=y(_0x8a4ce1);}return _0x5d959b;}function Ge(_0x59bd0a){return _0x59bd0a['node']['value'];}function fs(_0x5b5858,_0x49ff82){_0x5b5858['node']['value']=_0x49ff82,Ri(_0x5b5858);}function ea(_0xa9a14c){return _0xa9a14c['node']['childCount']>0x0;}function id(_0x478e74){return Ge(_0x478e74)===void 0x0&&!ea(_0x478e74);}function Wn(_0x277437,_0x20985d){x(_0x277437['node']['children'],(_0x597b90,_0x3e949a)=>{_0x20985d(new ds(_0x597b90,_0x277437,_0x3e949a));});}function ta(_0x52b1e5,_0x3c2b0e,_0x229585,_0x35d89f){_0x229585&&_0x3c2b0e(_0x52b1e5),Wn(_0x52b1e5,_0x4e6607=>{ta(_0x4e6607,_0x3c2b0e,!0x0);});}function sd(_0x53cb14,_0x1eef45,_0x3a702c){let _0x232155=_0x53cb14['parent'];for(;_0x232155!==null;){if(_0x1eef45(_0x232155))return!0x0;_0x232155=_0x232155['parent'];}return!0x1;}function Gt(_0x318ea1){return new C(_0x318ea1['parent']===null?_0x318ea1['name']:Gt(_0x318ea1['parent'])+'/'+_0x318ea1['name']);}function Ri(_0x201cc3){_0x201cc3['parent']!==null&&rd(_0x201cc3['parent'],_0x201cc3['name'],_0x201cc3);}function rd(_0x386573,_0x2e86f3,_0x3f2292){const _0x5ae253=id(_0x3f2292),_0x285b3b=Y(_0x386573['node']['children'],_0x2e86f3);_0x5ae253&&_0x285b3b?(delete _0x386573['node']['children'][_0x2e86f3],_0x386573['node']['childCount']--,Ri(_0x386573)):!_0x5ae253&&!_0x285b3b&&(_0x386573['node']['children'][_0x2e86f3]=_0x3f2292['node'],_0x386573['node']['childCount']++,Ri(_0x386573));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x124b67){return typeof _0x124b67=='string'&&_0x124b67['length']!==0x0&&!od['test'](_0x124b67);},na=function(_0x2afd66){return typeof _0x2afd66=='string'&&_0x2afd66['length']!==0x0&&!ad['test'](_0x2afd66);},cd=function(_0x1af5a6){return _0x1af5a6&&(_0x1af5a6=_0x1af5a6['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1af5a6);},Cn=function(_0x4585a1){return _0x4585a1===null||typeof _0x4585a1=='string'||typeof _0x4585a1=='number'&&!Wi(_0x4585a1)||_0x4585a1&&typeof _0x4585a1=='object'&&Y(_0x4585a1,'.sv');},qt=function(_0xe0fb6d,_0x361722,_0x157608,_0x2f8e0c){_0x2f8e0c&&_0x361722===void 0x0||zt(Nn(_0xe0fb6d,'value'),_0x361722,_0x157608);},zt=function(_0x4ab15b,_0x69b0e6,_0x177888){const _0x37d4ac=_0x177888 instanceof C?new Sh(_0x177888,_0x4ab15b):_0x177888;if(_0x69b0e6===void 0x0)throw new Error(_0x4ab15b+'contains\x20undefined\x20'+Ne(_0x37d4ac));if(typeof _0x69b0e6=='function')throw new Error(_0x4ab15b+'contains\x20a\x20function\x20'+Ne(_0x37d4ac)+'\x20with\x20contents\x20=\x20'+_0x69b0e6['toString']());if(Wi(_0x69b0e6))throw new Error(_0x4ab15b+'contains\x20'+_0x69b0e6['toString']()+'\x20'+Ne(_0x37d4ac));if(typeof _0x69b0e6=='string'&&_0x69b0e6['length']>oi/0x3&&Pn(_0x69b0e6)>oi)throw new Error(_0x4ab15b+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x37d4ac)+'\x20(\x27'+_0x69b0e6['substring'](0x0,0x32)+'...\x27)');if(_0x69b0e6&&typeof _0x69b0e6=='object'){let _0x54463a=!0x1,_0x2c4a9c=!0x1;if(x(_0x69b0e6,(_0x22ac02,_0x4e4396)=>{if(_0x22ac02==='.value')_0x54463a=!0x0;else{if(_0x22ac02!=='.priority'&&_0x22ac02!=='.sv'&&(_0x2c4a9c=!0x0,!ps(_0x22ac02)))throw new Error(_0x4ab15b+'\x20contains\x20an\x20invalid\x20key\x20('+_0x22ac02+')\x20'+Ne(_0x37d4ac)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x37d4ac,_0x22ac02),zt(_0x4ab15b,_0x4e4396,_0x37d4ac),Rh(_0x37d4ac);}),_0x54463a&&_0x2c4a9c)throw new Error(_0x4ab15b+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x37d4ac)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x177e0a,_0x44c47d){let _0x27089e,_0x4b273c;for(_0x27089e=0x0;_0x27089e<_0x44c47d['length'];_0x27089e++){_0x4b273c=_0x44c47d[_0x27089e];const _0x35b0e4=kt(_0x4b273c);for(let _0x4c134c=0x0;_0x4c134c<_0x35b0e4['length'];_0x4c134c++)if(!(_0x35b0e4[_0x4c134c]==='.priority'&&_0x4c134c===_0x35b0e4['length']-0x1)){if(!ps(_0x35b0e4[_0x4c134c]))throw new Error(_0x177e0a+'contains\x20an\x20invalid\x20key\x20('+_0x35b0e4[_0x4c134c]+')\x20in\x20path\x20'+_0x4b273c['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x44c47d['sort'](Th);let _0x213f73=null;for(_0x27089e=0x0;_0x27089e<_0x44c47d['length'];_0x27089e++){if(_0x4b273c=_0x44c47d[_0x27089e],_0x213f73!==null&&$(_0x213f73,_0x4b273c))throw new Error(_0x177e0a+'contains\x20a\x20path\x20'+_0x213f73['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4b273c['toString']());_0x213f73=_0x4b273c;}},hd=function(_0x2c8035,_0x372579,_0x3bbe98,_0x3912d3){const _0x45876f=Nn(_0x2c8035,'values');if(!(_0x372579&&typeof _0x372579=='object')||Array['isArray'](_0x372579))throw new Error(_0x45876f+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2d2bb1=[];x(_0x372579,(_0x1dd2f1,_0x6cd1e5)=>{const _0x298074=new C(_0x1dd2f1);if(zt(_0x45876f,_0x6cd1e5,A(_0x3bbe98,_0x298074)),Gi(_0x298074)==='.priority'&&!Cn(_0x6cd1e5))throw new Error(_0x45876f+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x298074['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2d2bb1['push'](_0x298074);}),ld(_0x45876f,_0x2d2bb1);},_s=function(_0x3fbdfb,_0x3337d0,_0x544a85,_0xd821d5){if(!na(_0x544a85))throw new Error(Nn(_0x3fbdfb,_0x3337d0)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x544a85+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x21b161,_0x328104,_0x3340e6,_0x4e0e96){_0x3340e6&&(_0x3340e6=_0x3340e6['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x21b161,_0x328104,_0x3340e6);},gs=function(_0x17d619,_0x5407ef){if(y(_0x5407ef)==='.info')throw new Error(_0x17d619+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x886316,_0x3a8b5c){const _0x11b03c=_0x3a8b5c['path']['toString']();if(typeof _0x3a8b5c['repoInfo']['host']!='string'||_0x3a8b5c['repoInfo']['host']['length']===0x0||!ps(_0x3a8b5c['repoInfo']['namespace'])&&_0x3a8b5c['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x11b03c['length']!==0x0&&!cd(_0x11b03c))throw new Error(Nn(_0x886316,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x1691ac,_0x48071b){let _0x2d409f=null;for(let _0x5e92bc=0x0;_0x5e92bc<_0x48071b['length'];_0x5e92bc++){const _0x2f9af7=_0x48071b[_0x5e92bc],_0x34808f=_0x2f9af7['getPath']();_0x2d409f!==null&&!qi(_0x34808f,_0x2d409f['path'])&&(_0x1691ac['eventLists_']['push'](_0x2d409f),_0x2d409f=null),_0x2d409f===null&&(_0x2d409f={'events':[],'path':_0x34808f}),_0x2d409f['events']['push'](_0x2f9af7);}_0x2d409f&&_0x1691ac['eventLists_']['push'](_0x2d409f);}function ia(_0x37f72a,_0x532c0b,_0x54d843){Bn(_0x37f72a,_0x54d843),sa(_0x37f72a,_0x15d21f=>qi(_0x15d21f,_0x532c0b));}function V(_0x447311,_0x55c9cb,_0x5537c3){Bn(_0x447311,_0x5537c3),sa(_0x447311,_0x2e63e3=>$(_0x2e63e3,_0x55c9cb)||$(_0x55c9cb,_0x2e63e3));}function sa(_0x2d3bef,_0x1405ca){_0x2d3bef['recursionDepth_']++;let _0x59703f=!0x0;for(let _0x58a2da=0x0;_0x58a2da<_0x2d3bef['eventLists_']['length'];_0x58a2da++){const _0x140425=_0x2d3bef['eventLists_'][_0x58a2da];if(_0x140425){const _0x5611dc=_0x140425['path'];_0x1405ca(_0x5611dc)?(pd(_0x2d3bef['eventLists_'][_0x58a2da]),_0x2d3bef['eventLists_'][_0x58a2da]=null):_0x59703f=!0x1;}}_0x59703f&&(_0x2d3bef['eventLists_']=[]),_0x2d3bef['recursionDepth_']--;}function pd(_0x5e6342){for(let _0x273744=0x0;_0x273744<_0x5e6342['events']['length'];_0x273744++){const _0x4b6e7e=_0x5e6342['events'][_0x273744];if(_0x4b6e7e!==null){_0x5e6342['events'][_0x273744]=null;const _0x52bdcc=_0x4b6e7e['getEventRunner']();Et&&L('event:\x20'+_0x4b6e7e['toString']()),lt(_0x52bdcc);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x3b68c6,_0x183160,_0x57dc8b,_0x402ce6){this['repoInfo_']=_0x3b68c6,this['forceRestClient_']=_0x183160,this['authTokenProvider_']=_0x57dc8b,this['appCheckProvider_']=_0x402ce6,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x2ed9af,_0x51cf5e,_0xe94dab){if(_0x2ed9af['stats_']=Hi(_0x2ed9af['repoInfo_']),_0x2ed9af['forceRestClient_']||Yl())_0x2ed9af['server_']=new fn(_0x2ed9af['repoInfo_'],(_0x38ca10,_0x114a2a,_0x5695c6,_0x44a788)=>{pr(_0x2ed9af,_0x38ca10,_0x114a2a,_0x5695c6,_0x44a788);},_0x2ed9af['authTokenProvider_'],_0x2ed9af['appCheckProvider_']),setTimeout(()=>_r(_0x2ed9af,!0x0),0x0);else{if(typeof _0xe94dab<'u'&&_0xe94dab!==null){if(typeof _0xe94dab!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xe94dab);}catch(_0x530800){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x530800);}}_0x2ed9af['persistentConnection_']=new ie(_0x2ed9af['repoInfo_'],_0x51cf5e,(_0x3b81c3,_0x407db9,_0xe5775a,_0x8dda79)=>{pr(_0x2ed9af,_0x3b81c3,_0x407db9,_0xe5775a,_0x8dda79);},_0x11efd7=>{_r(_0x2ed9af,_0x11efd7);},_0x2bb3d7=>{yd(_0x2ed9af,_0x2bb3d7);},_0x2ed9af['authTokenProvider_'],_0x2ed9af['appCheckProvider_'],_0xe94dab),_0x2ed9af['server_']=_0x2ed9af['persistentConnection_'];}_0x2ed9af['authTokenProvider_']['addTokenChangeListener'](_0x5ca288=>{_0x2ed9af['server_']['refreshAuthToken'](_0x5ca288);}),_0x2ed9af['appCheckProvider_']['addTokenChangeListener'](_0x3083d9=>{_0x2ed9af['server_']['refreshAppCheckToken'](_0x3083d9['token']);}),_0x2ed9af['statsReporter_']=eh(_0x2ed9af['repoInfo_'],()=>new eu(_0x2ed9af['stats_'],_0x2ed9af['server_'])),_0x2ed9af['infoData_']=new Yh(),_0x2ed9af['infoSyncTree_']=new dr({'startListening':(_0x11ff06,_0xfe025d,_0x539e49,_0x3bd3d6)=>{let _0x62b5a8=[];const _0x3300f3=_0x2ed9af['infoData_']['getNode'](_0x11ff06['_path']);return _0x3300f3['isEmpty']()||(_0x62b5a8=$t(_0x2ed9af['infoSyncTree_'],_0x11ff06['_path'],_0x3300f3),setTimeout(()=>{_0x3bd3d6('ok');},0x0)),_0x62b5a8;},'stopListening':()=>{}}),ms(_0x2ed9af,'connected',!0x1),_0x2ed9af['serverSyncTree_']=new dr({'startListening':(_0xcdac89,_0x9c1f84,_0x33119b,_0x32f90c)=>(_0x2ed9af['server_']['listen'](_0xcdac89,_0x33119b,_0x9c1f84,(_0x2d12c2,_0x4fc4b1)=>{const _0x45368b=_0x32f90c(_0x2d12c2,_0x4fc4b1);V(_0x2ed9af['eventQueue_'],_0xcdac89['_path'],_0x45368b);}),[]),'stopListening':(_0x356134,_0x3f45f4)=>{_0x2ed9af['server_']['unlisten'](_0x356134,_0x3f45f4);}});}function oa(_0x1a8686){const _0x317ddc=_0x1a8686['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x317ddc;}function jt(_0x5fca18){return ed({'timestamp':oa(_0x5fca18)});}function pr(_0x24433c,_0x12f84d,_0x23e83a,_0x172723,_0x2e68ca){_0x24433c['dataUpdateCount']++;const _0x4e7a04=new C(_0x12f84d);_0x23e83a=_0x24433c['interceptServerDataCallback_']?_0x24433c['interceptServerDataCallback_'](_0x12f84d,_0x23e83a):_0x23e83a;let _0x2387f4=[];if(_0x2e68ca){if(_0x172723){const _0x34930f=ln(_0x23e83a,_0x356937=>N(_0x356937));_0x2387f4=Ku(_0x24433c['serverSyncTree_'],_0x4e7a04,_0x34930f,_0x2e68ca);}else{const _0x2298b8=N(_0x23e83a);_0x2387f4=Yo(_0x24433c['serverSyncTree_'],_0x4e7a04,_0x2298b8,_0x2e68ca);}}else{if(_0x172723){const _0x5416a4=ln(_0x23e83a,_0x2b81e5=>N(_0x2b81e5));_0x2387f4=qu(_0x24433c['serverSyncTree_'],_0x4e7a04,_0x5416a4);}else{const _0x295267=N(_0x23e83a);_0x2387f4=$t(_0x24433c['serverSyncTree_'],_0x4e7a04,_0x295267);}}let _0x1c2dbb=_0x4e7a04;_0x2387f4['length']>0x0&&(_0x1c2dbb=st(_0x24433c,_0x4e7a04)),V(_0x24433c['eventQueue_'],_0x1c2dbb,_0x2387f4);}function _r(_0x22388b,_0x248d4a){ms(_0x22388b,'connected',_0x248d4a),_0x248d4a===!0x1&&wd(_0x22388b);}function yd(_0x1bb196,_0xc422d0){x(_0xc422d0,(_0x2c7e7a,_0x5270b8)=>{ms(_0x1bb196,_0x2c7e7a,_0x5270b8);});}function ms(_0x5503d5,_0x11bc9f,_0x5a474f){const _0x3c46f9=new C('/.info/'+_0x11bc9f),_0x4ac4b7=N(_0x5a474f);_0x5503d5['infoData_']['updateSnapshot'](_0x3c46f9,_0x4ac4b7);const _0x42660d=$t(_0x5503d5['infoSyncTree_'],_0x3c46f9,_0x4ac4b7);V(_0x5503d5['eventQueue_'],_0x3c46f9,_0x42660d);}function Vn(_0x142b6c){return _0x142b6c['nextWriteId_']++;}function vd(_0x23c46e,_0x1c04e0,_0x38c2a0){const _0x11b162=Yu(_0x23c46e['serverSyncTree_'],_0x1c04e0);return _0x11b162!=null?Promise['resolve'](_0x11b162):_0x23c46e['server_']['get'](_0x1c04e0)['then'](_0x3ace16=>{const _0x2b0057=N(_0x3ace16)['withIndex'](_0x1c04e0['_queryParams']['getIndex']());bi(_0x23c46e['serverSyncTree_'],_0x1c04e0,_0x38c2a0,!0x0);let _0x8338d9;if(_0x1c04e0['_queryParams']['loadsAllData']())_0x8338d9=$t(_0x23c46e['serverSyncTree_'],_0x1c04e0['_path'],_0x2b0057);else{const _0x1c88fd=Mt(_0x23c46e['serverSyncTree_'],_0x1c04e0);_0x8338d9=Yo(_0x23c46e['serverSyncTree_'],_0x1c04e0['_path'],_0x2b0057,_0x1c88fd);}return V(_0x23c46e['eventQueue_'],_0x1c04e0['_path'],_0x8338d9),wn(_0x23c46e['serverSyncTree_'],_0x1c04e0,_0x38c2a0,null,!0x0),_0x2b0057;},_0x43cf59=>(ut(_0x23c46e,'get\x20for\x20query\x20'+O(_0x1c04e0)+'\x20failed:\x20'+_0x43cf59),Promise['reject'](new Error(_0x43cf59))));}function Ed(_0x51dd08,_0x126de3,_0x14218a,_0x46cb93,_0x2fccd5){ut(_0x51dd08,'set',{'path':_0x126de3['toString'](),'value':_0x14218a,'priority':_0x46cb93});const _0x9ef3b6=jt(_0x51dd08),_0x2e9e86=N(_0x14218a,_0x46cb93),_0xb31139=xn(_0x51dd08['serverSyncTree_'],_0x126de3),_0x38a046=hs(_0x2e9e86,_0xb31139,_0x9ef3b6),_0x304041=Vn(_0x51dd08),_0x6bfef8=ss(_0x51dd08['serverSyncTree_'],_0x126de3,_0x38a046,_0x304041,!0x0);Bn(_0x51dd08['eventQueue_'],_0x6bfef8),_0x51dd08['server_']['put'](_0x126de3['toString'](),_0x2e9e86['val'](!0x0),(_0x654c95,_0x11f90f)=>{const _0x34006f=_0x654c95==='ok';_0x34006f||U('set\x20at\x20'+_0x126de3+'\x20failed:\x20'+_0x654c95);const _0x4ce33c=pe(_0x51dd08['serverSyncTree_'],_0x304041,!_0x34006f);V(_0x51dd08['eventQueue_'],_0x126de3,_0x4ce33c),Ai(_0x51dd08,_0x2fccd5,_0x654c95,_0x11f90f);});const _0x24224=vs(_0x51dd08,_0x126de3);st(_0x51dd08,_0x24224),V(_0x51dd08['eventQueue_'],_0x24224,[]);}function Id(_0x36fc40,_0x232dd3,_0x4bc167,_0xf77227){ut(_0x36fc40,'update',{'path':_0x232dd3['toString'](),'value':_0x4bc167});let _0x13e71a=!0x0;const _0x475f84=jt(_0x36fc40),_0x2e0784={};if(x(_0x4bc167,(_0x3bc347,_0x691e8a)=>{_0x13e71a=!0x1,_0x2e0784[_0x3bc347]=Zo(A(_0x232dd3,_0x3bc347),N(_0x691e8a),_0x36fc40['serverSyncTree_'],_0x475f84);}),_0x13e71a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x36fc40,_0xf77227,'ok',void 0x0);else{const _0x295bb4=Vn(_0x36fc40),_0x35238f=Gu(_0x36fc40['serverSyncTree_'],_0x232dd3,_0x2e0784,_0x295bb4);Bn(_0x36fc40['eventQueue_'],_0x35238f),_0x36fc40['server_']['merge'](_0x232dd3['toString'](),_0x4bc167,(_0x44e321,_0x55a406)=>{const _0x130f05=_0x44e321==='ok';_0x130f05||U('update\x20at\x20'+_0x232dd3+'\x20failed:\x20'+_0x44e321);const _0x3b6a21=pe(_0x36fc40['serverSyncTree_'],_0x295bb4,!_0x130f05),_0x158ef2=_0x3b6a21['length']>0x0?st(_0x36fc40,_0x232dd3):_0x232dd3;V(_0x36fc40['eventQueue_'],_0x158ef2,_0x3b6a21),Ai(_0x36fc40,_0xf77227,_0x44e321,_0x55a406);}),x(_0x4bc167,_0x58154e=>{const _0x3fec7b=vs(_0x36fc40,A(_0x232dd3,_0x58154e));st(_0x36fc40,_0x3fec7b);}),V(_0x36fc40['eventQueue_'],_0x232dd3,[]);}}function wd(_0x55777e){ut(_0x55777e,'onDisconnectEvents');const _0x9b6de4=jt(_0x55777e),_0x47b4a1=pn();Ei(_0x55777e['onDisconnect_'],w(),(_0x4d89a2,_0xf368b7)=>{const _0x4038e2=Zo(_0x4d89a2,_0xf368b7,_0x55777e['serverSyncTree_'],_0x9b6de4);Mo(_0x47b4a1,_0x4d89a2,_0x4038e2);});let _0x26fb0c=[];Ei(_0x47b4a1,w(),(_0x543542,_0x1d0785)=>{_0x26fb0c=_0x26fb0c['concat']($t(_0x55777e['serverSyncTree_'],_0x543542,_0x1d0785));const _0x2ec119=vs(_0x55777e,_0x543542);st(_0x55777e,_0x2ec119);}),_0x55777e['onDisconnect_']=pn(),V(_0x55777e['eventQueue_'],w(),_0x26fb0c);}function Cd(_0x423e76,_0x591a48,_0x48f73a){let _0x50af54;y(_0x591a48['_path'])==='.info'?_0x50af54=bi(_0x423e76['infoSyncTree_'],_0x591a48,_0x48f73a):_0x50af54=bi(_0x423e76['serverSyncTree_'],_0x591a48,_0x48f73a),ia(_0x423e76['eventQueue_'],_0x591a48['_path'],_0x50af54);}function Td(_0x5ba73f,_0x3436c1,_0x46c412){let _0x5dadc2;y(_0x3436c1['_path'])==='.info'?_0x5dadc2=wn(_0x5ba73f['infoSyncTree_'],_0x3436c1,_0x46c412):_0x5dadc2=wn(_0x5ba73f['serverSyncTree_'],_0x3436c1,_0x46c412),ia(_0x5ba73f['eventQueue_'],_0x3436c1['_path'],_0x5dadc2);}function aa(_0x13f232){_0x13f232['persistentConnection_']&&_0x13f232['persistentConnection_']['interrupt'](ra);}function Sd(_0x1360af){_0x1360af['persistentConnection_']&&_0x1360af['persistentConnection_']['resume'](ra);}function ut(_0x1fd7ae,..._0x140f77){let _0x52ad57='';_0x1fd7ae['persistentConnection_']&&(_0x52ad57=_0x1fd7ae['persistentConnection_']['id']+':'),L(_0x52ad57,..._0x140f77);}function Ai(_0x4fe0db,_0x1fe45b,_0x422c4f,_0x519115){_0x1fe45b&&lt(()=>{if(_0x422c4f==='ok')_0x1fe45b(null);else{const _0x195982=(_0x422c4f||'error')['toUpperCase']();let _0x36a19b=_0x195982;_0x519115&&(_0x36a19b+=':\x20'+_0x519115);const _0x5e6463=new Error(_0x36a19b);_0x5e6463['code']=_0x195982,_0x1fe45b(_0x5e6463);}});}function bd(_0xb3e248,_0x5401e1,_0x31820c,_0x516091,_0x22c69a,_0xb440ac){ut(_0xb3e248,'transaction\x20on\x20'+_0x5401e1);const _0x1a7da4={'path':_0x5401e1,'update':_0x31820c,'onComplete':_0x516091,'status':null,'order':to(),'applyLocally':_0xb440ac,'retryCount':0x0,'unwatcher':_0x22c69a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x411a1b=ys(_0xb3e248,_0x5401e1,void 0x0);_0x1a7da4['currentInputSnapshot']=_0x411a1b;const _0x41517e=_0x1a7da4['update'](_0x411a1b['val']());if(_0x41517e===void 0x0)_0x1a7da4['unwatcher'](),_0x1a7da4['currentOutputSnapshotRaw']=null,_0x1a7da4['currentOutputSnapshotResolved']=null,_0x1a7da4['onComplete']&&_0x1a7da4['onComplete'](null,!0x1,_0x1a7da4['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x41517e,_0x1a7da4['path']),_0x1a7da4['status']=0x0;const _0x536104=Un(_0xb3e248['transactionQueueTree_'],_0x5401e1),_0x2f1be8=Ge(_0x536104)||[];_0x2f1be8['push'](_0x1a7da4),fs(_0x536104,_0x2f1be8);let _0xc21df8;typeof _0x41517e=='object'&&_0x41517e!==null&&Y(_0x41517e,'.priority')?(_0xc21df8=Oe(_0x41517e,'.priority'),f(Cn(_0xc21df8),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xc21df8=(xn(_0xb3e248['serverSyncTree_'],_0x5401e1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4e4990=jt(_0xb3e248),_0x1f426c=N(_0x41517e,_0xc21df8),_0x78ac4e=hs(_0x1f426c,_0x411a1b,_0x4e4990);_0x1a7da4['currentOutputSnapshotRaw']=_0x1f426c,_0x1a7da4['currentOutputSnapshotResolved']=_0x78ac4e,_0x1a7da4['currentWriteId']=Vn(_0xb3e248);const _0x34c00e=ss(_0xb3e248['serverSyncTree_'],_0x5401e1,_0x78ac4e,_0x1a7da4['currentWriteId'],_0x1a7da4['applyLocally']);V(_0xb3e248['eventQueue_'],_0x5401e1,_0x34c00e),Hn(_0xb3e248,_0xb3e248['transactionQueueTree_']);}}function ys(_0x54325e,_0x42ba93,_0x26812a){return xn(_0x54325e['serverSyncTree_'],_0x42ba93,_0x26812a)||g['EMPTY_NODE'];}function Hn(_0x6fe3e6,_0x53facc=_0x6fe3e6['transactionQueueTree_']){if(_0x53facc||$n(_0x6fe3e6,_0x53facc),Ge(_0x53facc)){const _0x532e23=la(_0x6fe3e6,_0x53facc);f(_0x532e23['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x532e23['every'](_0x1854a8=>_0x1854a8['status']===0x0)&&Rd(_0x6fe3e6,Gt(_0x53facc),_0x532e23);}else ea(_0x53facc)&&Wn(_0x53facc,_0x2b32a5=>{Hn(_0x6fe3e6,_0x2b32a5);});}function Rd(_0x46a0bc,_0x58714b,_0x20795d){const _0x5806f0=_0x20795d['map'](_0x4c11b0=>_0x4c11b0['currentWriteId']),_0xf0d290=ys(_0x46a0bc,_0x58714b,_0x5806f0);let _0x10b848=_0xf0d290;const _0x3c2342=_0xf0d290['hash']();for(let _0x24f68a=0x0;_0x24f68a<_0x20795d['length'];_0x24f68a++){const _0x1c133f=_0x20795d[_0x24f68a];f(_0x1c133f['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1c133f['status']=0x1,_0x1c133f['retryCount']++;const _0x584c43=F(_0x58714b,_0x1c133f['path']);_0x10b848=_0x10b848['updateChild'](_0x584c43,_0x1c133f['currentOutputSnapshotRaw']);}const _0x3fb17c=_0x10b848['val'](!0x0),_0x3b62b3=_0x58714b;_0x46a0bc['server_']['put'](_0x3b62b3['toString'](),_0x3fb17c,_0x274d65=>{ut(_0x46a0bc,'transaction\x20put\x20response',{'path':_0x3b62b3['toString'](),'status':_0x274d65});let _0x383ab9=[];if(_0x274d65==='ok'){const _0x433d0d=[];for(let _0x5a6727=0x0;_0x5a6727<_0x20795d['length'];_0x5a6727++)_0x20795d[_0x5a6727]['status']=0x2,_0x383ab9=_0x383ab9['concat'](pe(_0x46a0bc['serverSyncTree_'],_0x20795d[_0x5a6727]['currentWriteId'])),_0x20795d[_0x5a6727]['onComplete']&&_0x433d0d['push'](()=>_0x20795d[_0x5a6727]['onComplete'](null,!0x0,_0x20795d[_0x5a6727]['currentOutputSnapshotResolved'])),_0x20795d[_0x5a6727]['unwatcher']();$n(_0x46a0bc,Un(_0x46a0bc['transactionQueueTree_'],_0x58714b)),Hn(_0x46a0bc,_0x46a0bc['transactionQueueTree_']),V(_0x46a0bc['eventQueue_'],_0x58714b,_0x383ab9);for(let _0x3549fe=0x0;_0x3549fe<_0x433d0d['length'];_0x3549fe++)lt(_0x433d0d[_0x3549fe]);}else{if(_0x274d65==='datastale'){for(let _0x3812c4=0x0;_0x3812c4<_0x20795d['length'];_0x3812c4++)_0x20795d[_0x3812c4]['status']===0x3?_0x20795d[_0x3812c4]['status']=0x4:_0x20795d[_0x3812c4]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3b62b3['toString']()+'\x20failed:\x20'+_0x274d65);for(let _0x34d278=0x0;_0x34d278<_0x20795d['length'];_0x34d278++)_0x20795d[_0x34d278]['status']=0x4,_0x20795d[_0x34d278]['abortReason']=_0x274d65;}st(_0x46a0bc,_0x58714b);}},_0x3c2342);}function st(_0xaff31,_0x524179){const _0x342fde=ca(_0xaff31,_0x524179),_0xbf618f=Gt(_0x342fde),_0x4f62e1=la(_0xaff31,_0x342fde);return Ad(_0xaff31,_0x4f62e1,_0xbf618f),_0xbf618f;}function Ad(_0x46eb51,_0x2f2133,_0x5ab0cd){if(_0x2f2133['length']===0x0)return;const _0x22982f=[];let _0x244dda=[];const _0x47799d=_0x2f2133['filter'](_0x1b1708=>_0x1b1708['status']===0x0)['map'](_0x5486fa=>_0x5486fa['currentWriteId']);for(let _0x932f49=0x0;_0x932f49<_0x2f2133['length'];_0x932f49++){const _0x9d17f1=_0x2f2133[_0x932f49],_0x1be29b=F(_0x5ab0cd,_0x9d17f1['path']);let _0x5e23c4=!0x1,_0x2041c6;if(f(_0x1be29b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x9d17f1['status']===0x4)_0x5e23c4=!0x0,_0x2041c6=_0x9d17f1['abortReason'],_0x244dda=_0x244dda['concat'](pe(_0x46eb51['serverSyncTree_'],_0x9d17f1['currentWriteId'],!0x0));else{if(_0x9d17f1['status']===0x0){if(_0x9d17f1['retryCount']>=_d)_0x5e23c4=!0x0,_0x2041c6='maxretry',_0x244dda=_0x244dda['concat'](pe(_0x46eb51['serverSyncTree_'],_0x9d17f1['currentWriteId'],!0x0));else{const _0x5e941d=ys(_0x46eb51,_0x9d17f1['path'],_0x47799d);_0x9d17f1['currentInputSnapshot']=_0x5e941d;const _0x424103=_0x2f2133[_0x932f49]['update'](_0x5e941d['val']());if(_0x424103!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x424103,_0x9d17f1['path']);let _0xd60064=N(_0x424103);typeof _0x424103=='object'&&_0x424103!=null&&Y(_0x424103,'.priority')||(_0xd60064=_0xd60064['updatePriority'](_0x5e941d['getPriority']()));const _0x1624ff=_0x9d17f1['currentWriteId'],_0x131e85=jt(_0x46eb51),_0x34ad34=hs(_0xd60064,_0x5e941d,_0x131e85);_0x9d17f1['currentOutputSnapshotRaw']=_0xd60064,_0x9d17f1['currentOutputSnapshotResolved']=_0x34ad34,_0x9d17f1['currentWriteId']=Vn(_0x46eb51),_0x47799d['splice'](_0x47799d['indexOf'](_0x1624ff),0x1),_0x244dda=_0x244dda['concat'](ss(_0x46eb51['serverSyncTree_'],_0x9d17f1['path'],_0x34ad34,_0x9d17f1['currentWriteId'],_0x9d17f1['applyLocally'])),_0x244dda=_0x244dda['concat'](pe(_0x46eb51['serverSyncTree_'],_0x1624ff,!0x0));}else _0x5e23c4=!0x0,_0x2041c6='nodata',_0x244dda=_0x244dda['concat'](pe(_0x46eb51['serverSyncTree_'],_0x9d17f1['currentWriteId'],!0x0));}}}V(_0x46eb51['eventQueue_'],_0x5ab0cd,_0x244dda),_0x244dda=[],_0x5e23c4&&(_0x2f2133[_0x932f49]['status']=0x2,function(_0x4eae4e){setTimeout(_0x4eae4e,Math['floor'](0x0));}(_0x2f2133[_0x932f49]['unwatcher']),_0x2f2133[_0x932f49]['onComplete']&&(_0x2041c6==='nodata'?_0x22982f['push'](()=>_0x2f2133[_0x932f49]['onComplete'](null,!0x1,_0x2f2133[_0x932f49]['currentInputSnapshot'])):_0x22982f['push'](()=>_0x2f2133[_0x932f49]['onComplete'](new Error(_0x2041c6),!0x1,null))));}$n(_0x46eb51,_0x46eb51['transactionQueueTree_']);for(let _0x216296=0x0;_0x216296<_0x22982f['length'];_0x216296++)lt(_0x22982f[_0x216296]);Hn(_0x46eb51,_0x46eb51['transactionQueueTree_']);}function ca(_0x5abc37,_0x5404f2){let _0x176404,_0xc1e847=_0x5abc37['transactionQueueTree_'];for(_0x176404=y(_0x5404f2);_0x176404!==null&&Ge(_0xc1e847)===void 0x0;)_0xc1e847=Un(_0xc1e847,_0x176404),_0x5404f2=b(_0x5404f2),_0x176404=y(_0x5404f2);return _0xc1e847;}function la(_0x3806a4,_0x15bc2f){const _0x1d9882=[];return ha(_0x3806a4,_0x15bc2f,_0x1d9882),_0x1d9882['sort']((_0x12a79a,_0x315dfe)=>_0x12a79a['order']-_0x315dfe['order']),_0x1d9882;}function ha(_0x406c09,_0x1200be,_0x1185a3){const _0x43ef29=Ge(_0x1200be);if(_0x43ef29){for(let _0x23dc48=0x0;_0x23dc48<_0x43ef29['length'];_0x23dc48++)_0x1185a3['push'](_0x43ef29[_0x23dc48]);}Wn(_0x1200be,_0x1a262d=>{ha(_0x406c09,_0x1a262d,_0x1185a3);});}function $n(_0x2bf5d4,_0x37440e){const _0x12c365=Ge(_0x37440e);if(_0x12c365){let _0x519aa6=0x0;for(let _0x46b3a2=0x0;_0x46b3a2<_0x12c365['length'];_0x46b3a2++)_0x12c365[_0x46b3a2]['status']!==0x2&&(_0x12c365[_0x519aa6]=_0x12c365[_0x46b3a2],_0x519aa6++);_0x12c365['length']=_0x519aa6,fs(_0x37440e,_0x12c365['length']>0x0?_0x12c365:void 0x0);}Wn(_0x37440e,_0x538f2e=>{$n(_0x2bf5d4,_0x538f2e);});}function vs(_0xb66c93,_0x2f9976){const _0x427c1e=Gt(ca(_0xb66c93,_0x2f9976)),_0xe46b7b=Un(_0xb66c93['transactionQueueTree_'],_0x2f9976);return sd(_0xe46b7b,_0x3c54bb=>{ai(_0xb66c93,_0x3c54bb);}),ai(_0xb66c93,_0xe46b7b),ta(_0xe46b7b,_0xef94f3=>{ai(_0xb66c93,_0xef94f3);}),_0x427c1e;}function ai(_0x8b6e19,_0x2a00d0){const _0x2b49b9=Ge(_0x2a00d0);if(_0x2b49b9){const _0x3128dc=[];let _0x73a9cb=[],_0x7a4897=-0x1;for(let _0x1b7614=0x0;_0x1b7614<_0x2b49b9['length'];_0x1b7614++)_0x2b49b9[_0x1b7614]['status']===0x3||(_0x2b49b9[_0x1b7614]['status']===0x1?(f(_0x7a4897===_0x1b7614-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x7a4897=_0x1b7614,_0x2b49b9[_0x1b7614]['status']=0x3,_0x2b49b9[_0x1b7614]['abortReason']='set'):(f(_0x2b49b9[_0x1b7614]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2b49b9[_0x1b7614]['unwatcher'](),_0x73a9cb=_0x73a9cb['concat'](pe(_0x8b6e19['serverSyncTree_'],_0x2b49b9[_0x1b7614]['currentWriteId'],!0x0)),_0x2b49b9[_0x1b7614]['onComplete']&&_0x3128dc['push'](_0x2b49b9[_0x1b7614]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x7a4897===-0x1?fs(_0x2a00d0,void 0x0):_0x2b49b9['length']=_0x7a4897+0x1,V(_0x8b6e19['eventQueue_'],Gt(_0x2a00d0),_0x73a9cb);for(let _0x578b9f=0x0;_0x578b9f<_0x3128dc['length'];_0x578b9f++)lt(_0x3128dc[_0x578b9f]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x52b4ff){let _0x330658='';const _0x4837bf=_0x52b4ff['split']('/');for(let _0x5d46a4=0x0;_0x5d46a4<_0x4837bf['length'];_0x5d46a4++)if(_0x4837bf[_0x5d46a4]['length']>0x0){let _0x55c961=_0x4837bf[_0x5d46a4];try{_0x55c961=decodeURIComponent(_0x55c961['replace'](/\+/g,'\x20'));}catch{}_0x330658+='/'+_0x55c961;}return _0x330658;}function Nd(_0x5e5b52){const _0x245dd1={};_0x5e5b52['charAt'](0x0)==='?'&&(_0x5e5b52=_0x5e5b52['substring'](0x1));for(const _0x5baf2a of _0x5e5b52['split']('&')){if(_0x5baf2a['length']===0x0)continue;const _0x2b3bcb=_0x5baf2a['split']('=');_0x2b3bcb['length']===0x2?_0x245dd1[decodeURIComponent(_0x2b3bcb[0x0])]=decodeURIComponent(_0x2b3bcb[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5baf2a+'\x27\x20in\x20query\x20\x27'+_0x5e5b52+'\x27');}return _0x245dd1;}const gr=function(_0x5be77e,_0x1767d7){const _0x4f86bf=Pd(_0x5be77e),_0x835915=_0x4f86bf['namespace'];_0x4f86bf['domain']==='firebase.com'&&oe(_0x4f86bf['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x835915||_0x835915==='undefined')&&_0x4f86bf['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4f86bf['secure']||Bl();const _0x11cd50=_0x4f86bf['scheme']==='ws'||_0x4f86bf['scheme']==='wss';return{'repoInfo':new _o(_0x4f86bf['host'],_0x4f86bf['secure'],_0x835915,_0x11cd50,_0x1767d7,'',_0x835915!==_0x4f86bf['subdomain']),'path':new C(_0x4f86bf['pathString'])};},Pd=function(_0x336955){let _0x1b43b4='',_0x57f9ca='',_0x272d63='',_0x4f0cd5='',_0x225153='',_0x68973c=!0x0,_0x54b586='https',_0x1c3d27=0x1bb;if(typeof _0x336955=='string'){let _0x4cabcb=_0x336955['indexOf']('//');_0x4cabcb>=0x0&&(_0x54b586=_0x336955['substring'](0x0,_0x4cabcb-0x1),_0x336955=_0x336955['substring'](_0x4cabcb+0x2));let _0x2905b5=_0x336955['indexOf']('/');_0x2905b5===-0x1&&(_0x2905b5=_0x336955['length']);let _0x2f9e69=_0x336955['indexOf']('?');_0x2f9e69===-0x1&&(_0x2f9e69=_0x336955['length']),_0x1b43b4=_0x336955['substring'](0x0,Math['min'](_0x2905b5,_0x2f9e69)),_0x2905b5<_0x2f9e69&&(_0x4f0cd5=kd(_0x336955['substring'](_0x2905b5,_0x2f9e69)));const _0x2060c1=Nd(_0x336955['substring'](Math['min'](_0x336955['length'],_0x2f9e69)));_0x4cabcb=_0x1b43b4['indexOf'](':'),_0x4cabcb>=0x0?(_0x68973c=_0x54b586==='https'||_0x54b586==='wss',_0x1c3d27=parseInt(_0x1b43b4['substring'](_0x4cabcb+0x1),0xa)):_0x4cabcb=_0x1b43b4['length'];const _0x3a8e8a=_0x1b43b4['slice'](0x0,_0x4cabcb);if(_0x3a8e8a['toLowerCase']()==='localhost')_0x57f9ca='localhost';else{if(_0x3a8e8a['split']('.')['length']<=0x2)_0x57f9ca=_0x3a8e8a;else{const _0x1554bc=_0x1b43b4['indexOf']('.');_0x272d63=_0x1b43b4['substring'](0x0,_0x1554bc)['toLowerCase'](),_0x57f9ca=_0x1b43b4['substring'](_0x1554bc+0x1),_0x225153=_0x272d63;}}'ns'in _0x2060c1&&(_0x225153=_0x2060c1['ns']);}return{'host':_0x1b43b4,'port':_0x1c3d27,'domain':_0x57f9ca,'subdomain':_0x272d63,'secure':_0x68973c,'scheme':_0x54b586,'pathString':_0x4f0cd5,'namespace':_0x225153};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x107154=0x0;const _0x696ac2=[];return function(_0x262315){const _0x57f498=_0x262315===_0x107154;_0x107154=_0x262315;let _0x2c2981;const _0xdb2dba=new Array(0x8);for(_0x2c2981=0x7;_0x2c2981>=0x0;_0x2c2981--)_0xdb2dba[_0x2c2981]=mr['charAt'](_0x262315%0x40),_0x262315=Math['floor'](_0x262315/0x40);f(_0x262315===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x37293c=_0xdb2dba['join']('');if(_0x57f498){for(_0x2c2981=0xb;_0x2c2981>=0x0&&_0x696ac2[_0x2c2981]===0x3f;_0x2c2981--)_0x696ac2[_0x2c2981]=0x0;_0x696ac2[_0x2c2981]++;}else{for(_0x2c2981=0x0;_0x2c2981<0xc;_0x2c2981++)_0x696ac2[_0x2c2981]=Math['floor'](Math['random']()*0x40);}for(_0x2c2981=0x0;_0x2c2981<0xc;_0x2c2981++)_0x37293c+=mr['charAt'](_0x696ac2[_0x2c2981]);return f(_0x37293c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x37293c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x21716f,_0x28f44d,_0x31cdf5,_0x4b4e19){this['eventType']=_0x21716f,this['eventRegistration']=_0x28f44d,this['snapshot']=_0x31cdf5,this['prevName']=_0x4b4e19;}['getPath'](){const _0x2d1589=this['snapshot']['ref'];return this['eventType']==='value'?_0x2d1589['_path']:_0x2d1589['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3f6f33,_0xd5cadd,_0x542c49){this['eventRegistration']=_0x3f6f33,this['error']=_0xd5cadd,this['path']=_0x542c49;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x5f3a78,_0x5d7545){this['snapshotCallback']=_0x5f3a78,this['cancelCallback']=_0x5d7545;}['onValue'](_0x57a2d2,_0x492bd1){this['snapshotCallback']['call'](null,_0x57a2d2,_0x492bd1);}['onCancel'](_0x39e904){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x39e904);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x577bfb){return this['snapshotCallback']===_0x577bfb['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x577bfb['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x577bfb['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5c4750,_0x2213f2,_0x46029d,_0x5e1c78){this['_repo']=_0x5c4750,this['_path']=_0x2213f2,this['_queryParams']=_0x46029d,this['_orderByCalled']=_0x5e1c78;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2b5fc9=nr(this['_queryParams']),_0x112ce2=Bi(_0x2b5fc9);return _0x112ce2==='{}'?'default':_0x112ce2;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x344557){if(_0x344557=k(_0x344557),!(_0x344557 instanceof be))return!0x1;const _0x359ba5=this['_repo']===_0x344557['_repo'],_0x5ea182=qi(this['_path'],_0x344557['_path']),_0x4aaf23=this['_queryIdentifier']===_0x344557['_queryIdentifier'];return _0x359ba5&&_0x5ea182&&_0x4aaf23;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x4b56e3,_0x1ce018){if(_0x4b56e3['_orderByCalled']===!0x0)throw new Error(_0x1ce018+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x4c08da){let _0x214d38=null,_0x226b84=null;if(_0x4c08da['hasStart']()&&(_0x214d38=_0x4c08da['getIndexStartValue']()),_0x4c08da['hasEnd']()&&(_0x226b84=_0x4c08da['getIndexEndValue']()),_0x4c08da['getIndex']()===ye){const _0x114f97='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5b9392='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4c08da['hasStart']()){if(_0x4c08da['getIndexStartName']()!==xe)throw new Error(_0x114f97);if(typeof _0x214d38!='string')throw new Error(_0x5b9392);}if(_0x4c08da['hasEnd']()){if(_0x4c08da['getIndexEndName']()!==Ie)throw new Error(_0x114f97);if(typeof _0x226b84!='string')throw new Error(_0x5b9392);}}else{if(_0x4c08da['getIndex']()===R){if(_0x214d38!=null&&!Cn(_0x214d38)||_0x226b84!=null&&!Cn(_0x226b84))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4c08da['getIndex']()instanceof Ki||_0x4c08da['getIndex']()===Po,'unknown\x20index\x20type.'),_0x214d38!=null&&typeof _0x214d38=='object'||_0x226b84!=null&&typeof _0x226b84=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x5edd0f){if(_0x5edd0f['hasStart']()&&_0x5edd0f['hasEnd']()&&_0x5edd0f['hasLimit']()&&!_0x5edd0f['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x457c75,_0x3555b2){super(_0x457c75,_0x3555b2,new Qi(),!0x1);}get['parent'](){const _0x10b312=To(this['_path']);return _0x10b312===null?null:new Z(this['_repo'],_0x10b312);}get['root'](){let _0x1c76ae=this;for(;_0x1c76ae['parent']!==null;)_0x1c76ae=_0x1c76ae['parent'];return _0x1c76ae;}}class rt{constructor(_0x4c0a7e,_0x1821af,_0x192179){this['_node']=_0x4c0a7e,this['ref']=_0x1821af,this['_index']=_0x192179;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4d8062){const _0x27212a=new C(_0x4d8062),_0x560451=Lt(this['ref'],_0x4d8062);return new rt(this['_node']['getChild'](_0x27212a),_0x560451,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x441225){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x858e27,_0x2c9844)=>_0x441225(new rt(_0x2c9844,Lt(this['ref'],_0x858e27),R)));}['hasChild'](_0x54d175){const _0x242ea8=new C(_0x54d175);return!this['_node']['getChild'](_0x242ea8)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x270e2e,_0x21e4a4){return _0x270e2e=k(_0x270e2e),_0x270e2e['_checkNotDeleted']('ref'),_0x21e4a4!==void 0x0?Lt(_0x270e2e['_root'],_0x21e4a4):_0x270e2e['_root'];}function Lt(_0x22d844,_0x32cb56){return _0x22d844=k(_0x22d844),y(_0x22d844['_path'])===null?ud('child','path',_0x32cb56):_s('child','path',_0x32cb56),new Z(_0x22d844['_repo'],A(_0x22d844['_path'],_0x32cb56));}function d_(_0x3cd3e5,_0x14908d){_0x3cd3e5=k(_0x3cd3e5),gs('push',_0x3cd3e5['_path']),qt('push',_0x14908d,_0x3cd3e5['_path'],!0x0);const _0x4d4876=oa(_0x3cd3e5['_repo']),_0x1917f5=Od(_0x4d4876),_0x45c215=Lt(_0x3cd3e5,_0x1917f5),_0x39fddf=Lt(_0x3cd3e5,_0x1917f5);let _0x27c020;return _0x14908d!=null?_0x27c020=Ld(_0x39fddf,_0x14908d)['then'](()=>_0x39fddf):_0x27c020=Promise['resolve'](_0x39fddf),_0x45c215['then']=_0x27c020['then']['bind'](_0x27c020),_0x45c215['catch']=_0x27c020['then']['bind'](_0x27c020,void 0x0),_0x45c215;}function Ld(_0x1945d4,_0x594234){_0x1945d4=k(_0x1945d4),gs('set',_0x1945d4['_path']),qt('set',_0x594234,_0x1945d4['_path'],!0x1);const _0x52004a=new Ve();return Ed(_0x1945d4['_repo'],_0x1945d4['_path'],_0x594234,null,_0x52004a['wrapCallback'](()=>{})),_0x52004a['promise'];}function f_(_0x137fd2,_0x12c1ef){hd('update',_0x12c1ef,_0x137fd2['_path']);const _0x3fa3ee=new Ve();return Id(_0x137fd2['_repo'],_0x137fd2['_path'],_0x12c1ef,_0x3fa3ee['wrapCallback'](()=>{})),_0x3fa3ee['promise'];}function p_(_0x41d102){_0x41d102=k(_0x41d102);const _0x7cd79=new ua(()=>{}),_0x21df04=new qn(_0x7cd79);return vd(_0x41d102['_repo'],_0x41d102,_0x21df04)['then'](_0x1f21ce=>new rt(_0x1f21ce,new Z(_0x41d102['_repo'],_0x41d102['_path']),_0x41d102['_queryParams']['getIndex']()));}class qn{constructor(_0x2d967){this['callbackContext']=_0x2d967;}['respondsTo'](_0x27b188){return _0x27b188==='value';}['createEvent'](_0x32962c,_0x1e3be4){const _0x3d92c0=_0x1e3be4['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x32962c['snapshotNode'],new Z(_0x1e3be4['_repo'],_0x1e3be4['_path']),_0x3d92c0));}['getEventRunner'](_0x20bd42){return _0x20bd42['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x20bd42['error']):()=>this['callbackContext']['onValue'](_0x20bd42['snapshot'],null);}['createCancelEvent'](_0x4818ba,_0x41d8fd){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x4818ba,_0x41d8fd):null;}['matches'](_0x1f9d28){return _0x1f9d28 instanceof qn?!_0x1f9d28['callbackContext']||!this['callbackContext']?!0x0:_0x1f9d28['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4da11b,_0x529780,_0x1f4c3a,_0x3476d8,_0xc7659d){const _0x5b249a=new ua(_0x1f4c3a,void 0x0),_0x37a937=new qn(_0x5b249a);return Cd(_0x4da11b['_repo'],_0x4da11b,_0x37a937),()=>Td(_0x4da11b['_repo'],_0x4da11b,_0x37a937);}function Fd(_0x43fb6e,_0x9045e6,_0x1521b2,_0x35c595){return xd(_0x43fb6e,'value',_0x9045e6);}class dt{}class pa extends dt{constructor(_0x380d08,_0x220c77){super(),this['_value']=_0x380d08,this['_key']=_0x220c77,this['type']='endAt';}['_apply'](_0x303fc1){qt('endAt',this['_value'],_0x303fc1['_path'],!0x0);const _0x58e9d3=Kh(_0x303fc1['_queryParams'],this['_value'],this['_key']);if(fa(_0x58e9d3),Gn(_0x58e9d3),_0x303fc1['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x303fc1['_repo'],_0x303fc1['_path'],_0x58e9d3,_0x303fc1['_orderByCalled']);}}function __(_0x1da655,_0xf9361){return new pa(_0x1da655,_0xf9361);}class _a extends dt{constructor(_0x53dbe2,_0x1810b5){super(),this['_value']=_0x53dbe2,this['_key']=_0x1810b5,this['type']='startAt';}['_apply'](_0x1a4a03){qt('startAt',this['_value'],_0x1a4a03['_path'],!0x0);const _0x4abdfa=jh(_0x1a4a03['_queryParams'],this['_value'],this['_key']);if(fa(_0x4abdfa),Gn(_0x4abdfa),_0x1a4a03['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x1a4a03['_repo'],_0x1a4a03['_path'],_0x4abdfa,_0x1a4a03['_orderByCalled']);}}function g_(_0x2d4fdb=null,_0x5f3ae5){return new _a(_0x2d4fdb,_0x5f3ae5);}class Ud extends dt{constructor(_0x2ed808){super(),this['_limit']=_0x2ed808,this['type']='limitToFirst';}['_apply'](_0x47d2da){if(_0x47d2da['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x47d2da['_repo'],_0x47d2da['_path'],zh(_0x47d2da['_queryParams'],this['_limit']),_0x47d2da['_orderByCalled']);}}function m_(_0x4a865d){if(Math['floor'](_0x4a865d)!==_0x4a865d||_0x4a865d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x4a865d);}class Wd extends dt{constructor(_0x5067ac){super(),this['_path']=_0x5067ac,this['type']='orderByChild';}['_apply'](_0x4f7683){da(_0x4f7683,'orderByChild');const _0x5f1b83=new C(this['_path']);if(v(_0x5f1b83))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3a8407=new Ki(_0x5f1b83),_0x402221=Do(_0x4f7683['_queryParams'],_0x3a8407);return Gn(_0x402221),new be(_0x4f7683['_repo'],_0x4f7683['_path'],_0x402221,!0x0);}}function y_(_0x399a85){if(_0x399a85==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x399a85==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x399a85==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x399a85),new Wd(_0x399a85);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x15a889){da(_0x15a889,'orderByKey');const _0x1c729e=Do(_0x15a889['_queryParams'],ye);return Gn(_0x1c729e),new be(_0x15a889['_repo'],_0x15a889['_path'],_0x1c729e,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x315acb,_0x42cb2b){super(),this['_value']=_0x315acb,this['_key']=_0x42cb2b,this['type']='equalTo';}['_apply'](_0x1a493d){if(qt('equalTo',this['_value'],_0x1a493d['_path'],!0x1),_0x1a493d['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1a493d['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x1a493d));}}function E_(_0x262843,_0x22a831){return new Vd(_0x262843,_0x22a831);}function I_(_0x18ecc8,..._0x4e8e3d){let _0xca3409=k(_0x18ecc8);for(const _0xa5c996 of _0x4e8e3d)_0xca3409=_0xa5c996['_apply'](_0xca3409);return _0xca3409;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x4b6b33,_0x419379,_0x128111,_0x4e71d9){const _0x22333a=_0x419379['lastIndexOf'](':'),_0x2ebcd8=_0x419379['substring'](0x0,_0x22333a),_0x3d711b=Wt(_0x2ebcd8);_0x4b6b33['repoInfo_']=new _o(_0x419379,_0x3d711b,_0x4b6b33['repoInfo_']['namespace'],_0x4b6b33['repoInfo_']['webSocketOnly'],_0x4b6b33['repoInfo_']['nodeAdmin'],_0x4b6b33['repoInfo_']['persistenceKey'],_0x4b6b33['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x128111),_0x4e71d9&&(_0x4b6b33['authTokenProvider_']=_0x4e71d9);}function qd(_0x13ad12,_0x46db4a,_0x307b3a,_0x1c1077,_0x1cf439){let _0x135b0f=_0x1c1077||_0x13ad12['options']['databaseURL'];_0x135b0f===void 0x0&&(_0x13ad12['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x13ad12['options']['projectId']),_0x135b0f=_0x13ad12['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x220f13=gr(_0x135b0f,_0x1cf439),_0x4c97ce=_0x220f13['repoInfo'],_0x2fa69a;typeof process<'u'&&Us&&(_0x2fa69a=Us[Hd]),_0x2fa69a?(_0x135b0f='http://'+_0x2fa69a+'?ns='+_0x4c97ce['namespace'],_0x220f13=gr(_0x135b0f,_0x1cf439),_0x4c97ce=_0x220f13['repoInfo']):_0x220f13['repoInfo']['secure'];const _0x5a52e6=new Jl(_0x13ad12['name'],_0x13ad12['options'],_0x46db4a);dd('Invalid\x20Firebase\x20Database\x20URL',_0x220f13),v(_0x220f13['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xda446a=jd(_0x4c97ce,_0x13ad12,_0x5a52e6,new Ql(_0x13ad12,_0x307b3a));return new Kd(_0xda446a,_0x13ad12);}function zd(_0x59af1b,_0xcf7ff){const _0x50c162=ki[_0xcf7ff];(!_0x50c162||_0x50c162[_0x59af1b['key']]!==_0x59af1b)&&oe('Database\x20'+_0xcf7ff+'('+_0x59af1b['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x59af1b),delete _0x50c162[_0x59af1b['key']];}function jd(_0x920144,_0x332200,_0x144125,_0x19a5c8){let _0x3704e6=ki[_0x332200['name']];_0x3704e6||(_0x3704e6={},ki[_0x332200['name']]=_0x3704e6);let _0x4ff8ec=_0x3704e6[_0x920144['toURLString']()];return _0x4ff8ec&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4ff8ec=new gd(_0x920144,$d,_0x144125,_0x19a5c8),_0x3704e6[_0x920144['toURLString']()]=_0x4ff8ec,_0x4ff8ec;}class Kd{constructor(_0x52a164,_0x4a15e4){this['_repoInternal']=_0x52a164,this['app']=_0x4a15e4,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x39e786){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x39e786+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x365214=Qr(),_0x2300b9){const _0x2aa863=Ui(_0x365214,'database')['getImmediate']({'identifier':_0x2300b9});if(!_0x2aa863['_instanceStarted']){const _0x50cbc6=ac('database');_0x50cbc6&&Yd(_0x2aa863,..._0x50cbc6);}return _0x2aa863;}function Yd(_0x8b9cb9,_0x4c18ff,_0x34cf19,_0x23a89a={}){_0x8b9cb9=k(_0x8b9cb9),_0x8b9cb9['_checkNotDeleted']('useEmulator');const _0xfd2297=_0x4c18ff+':'+_0x34cf19,_0x1395f5=_0x8b9cb9['_repoInternal'];if(_0x8b9cb9['_instanceStarted']){if(_0xfd2297===_0x8b9cb9['_repoInternal']['repoInfo_']['host']&&De(_0x23a89a,_0x1395f5['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xf3f5a0;if(_0x1395f5['repoInfo_']['nodeAdmin'])_0x23a89a['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xf3f5a0=new tn(tn['OWNER']);else{if(_0x23a89a['mockUserToken']){const _0x3d6b42=typeof _0x23a89a['mockUserToken']=='string'?_0x23a89a['mockUserToken']:cc(_0x23a89a['mockUserToken'],_0x8b9cb9['app']['options']['projectId']);_0xf3f5a0=new tn(_0x3d6b42);}}Wt(_0x4c18ff)&&jr(_0x4c18ff),Gd(_0x1395f5,_0xfd2297,_0x23a89a,_0xf3f5a0);}function C_(_0xa392e5){_0xa392e5=k(_0xa392e5),_0xa392e5['_checkNotDeleted']('goOffline'),aa(_0xa392e5['_repo']);}function T_(_0x4258ed){_0x4258ed=k(_0x4258ed),_0x4258ed['_checkNotDeleted']('goOnline'),Sd(_0x4258ed['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4ee7c0){Ll(ct),et(new Me('database',(_0x10e679,{instanceIdentifier:_0x1f07bc})=>{const _0x1d1763=_0x10e679['getProvider']('app')['getImmediate'](),_0x72e422=_0x10e679['getProvider']('auth-internal'),_0x47765b=_0x10e679['getProvider']('app-check-internal');return qd(_0x1d1763,_0x72e422,_0x47765b,_0x1f07bc);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4ee7c0),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x33af4b,_0x3b82a9){this['committed']=_0x33af4b,this['snapshot']=_0x3b82a9;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x2d8922,_0x2dbaff,_0x16958b){if(_0x2d8922=k(_0x2d8922),gs('Reference.transaction',_0x2d8922['_path']),_0x2d8922['key']==='.length'||_0x2d8922['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2d8922['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3b32da=!0x0,_0x3e92b2=new Ve(),_0x2f60e5=(_0xff6e5c,_0x33a57f,_0x29ab73)=>{let _0x21178d=null;_0xff6e5c?_0x3e92b2['reject'](_0xff6e5c):(_0x21178d=new rt(_0x29ab73,new Z(_0x2d8922['_repo'],_0x2d8922['_path']),R),_0x3e92b2['resolve'](new Xd(_0x33a57f,_0x21178d)));},_0x982c95=Fd(_0x2d8922,()=>{});return bd(_0x2d8922['_repo'],_0x2d8922['_path'],_0x2dbaff,_0x2f60e5,_0x982c95,_0x3b32da),_0x3e92b2['promise'];}ie['prototype']['simpleListen']=function(_0x3046be,_0x202d74){this['sendRequest']('q',{'p':_0x3046be},_0x202d74);},ie['prototype']['echo']=function(_0x1a6495,_0x23db48){this['sendRequest']('echo',{'d':_0x1a6495},_0x23db48);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1b616a,..._0x4b9b35){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1b616a,..._0x4b9b35);}function nn(_0x46dc78,..._0x33fdb3){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x46dc78,..._0x33fdb3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x57bf94,..._0x95b1c){throw Es(_0x57bf94,..._0x95b1c);}function J(_0x1423bb,..._0x5aad58){return Es(_0x1423bb,..._0x5aad58);}function ya(_0x50f46f,_0x260880,_0x1f868b){const _0xb6b254={...Zd(),[_0x260880]:_0x1f868b};return new Ut('auth','Firebase',_0xb6b254)['create'](_0x260880,{'appName':_0x50f46f['name']});}function se(_0x9b9458){return ya(_0x9b9458,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x54d68e,..._0x184bde){if(typeof _0x54d68e!='string'){const _0x397a75=_0x184bde[0x0],_0x390a25=[..._0x184bde['slice'](0x1)];return _0x390a25[0x0]&&(_0x390a25[0x0]['appName']=_0x54d68e['name']),_0x54d68e['_errorFactory']['create'](_0x397a75,..._0x390a25);}return ma['create'](_0x54d68e,..._0x184bde);}function m(_0x54eec4,_0xdaefd3,..._0x570671){if(!_0x54eec4)throw Es(_0xdaefd3,..._0x570671);}function te(_0x21a5f5){const _0x44acb4='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x21a5f5;throw nn(_0x44acb4),new Error(_0x44acb4);}function ae(_0x54130d,_0x2f80ca){_0x54130d||te(_0x2f80ca);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x23dac5;return typeof self<'u'&&((_0x23dac5=self['location'])==null?void 0x0:_0x23dac5['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x58056e;return typeof self<'u'&&((_0x58056e=self['location'])==null?void 0x0:_0x58056e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x15c2b6=navigator;return _0x15c2b6['languages']&&_0x15c2b6['languages'][0x0]||_0x15c2b6['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3d08d8,_0x3eb999){this['shortDelay']=_0x3d08d8,this['longDelay']=_0x3eb999,ae(_0x3eb999>_0x3d08d8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x16db17,_0x401bcc){ae(_0x16db17['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1a5f57}=_0x16db17['emulator'];return _0x401bcc?''+_0x1a5f57+(_0x401bcc['startsWith']('/')?_0x401bcc['slice'](0x1):_0x401bcc):_0x1a5f57;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x260337,_0xf51bc,_0x5778f7){this['fetchImpl']=_0x260337,_0xf51bc&&(this['headersImpl']=_0xf51bc),_0x5778f7&&(this['responseImpl']=_0x5778f7);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x15d16c,_0x376941){return _0x15d16c['tenantId']&&!_0x376941['tenantId']?{..._0x376941,'tenantId':_0x15d16c['tenantId']}:_0x376941;}async function Ae(_0x59d02c,_0x1ea4b7,_0x189b39,_0x105938,_0x1d937a={}){return Ea(_0x59d02c,_0x1d937a,async()=>{let _0x18e391={},_0x583420={};_0x105938&&(_0x1ea4b7==='GET'?_0x583420=_0x105938:_0x18e391={'body':JSON['stringify'](_0x105938)});const _0x55ff23=at({..._0x583420,'key':_0x59d02c['config']['apiKey']})['slice'](0x1),_0x403501=await _0x59d02c['_getAdditionalHeaders']();_0x403501['Content-Type']='application/json',_0x59d02c['languageCode']&&(_0x403501['X-Firebase-Locale']=_0x59d02c['languageCode']);const _0x313dfa={'method':_0x1ea4b7,'headers':_0x403501,..._0x18e391};return lc()||(_0x313dfa['referrerPolicy']='strict-origin-when-cross-origin'),_0x59d02c['emulatorConfig']&&Wt(_0x59d02c['emulatorConfig']['host'])&&(_0x313dfa['credentials']='include'),va['fetch']()(await Ia(_0x59d02c,_0x59d02c['config']['apiHost'],_0x189b39,_0x55ff23),_0x313dfa);});}async function Ea(_0x39bc9e,_0x5a85e7,_0x1ce891){_0x39bc9e['_canInitEmulator']=!0x1;const _0x5a2e04={...rf,..._0x5a85e7};try{const _0xab3e50=new lf(_0x39bc9e),_0x1c690d=await Promise['race']([_0x1ce891(),_0xab3e50['promise']]);_0xab3e50['clearNetworkTimeout']();const _0x4c487d=await _0x1c690d['json']();if('needConfirmation'in _0x4c487d)throw en(_0x39bc9e,'account-exists-with-different-credential',_0x4c487d);if(_0x1c690d['ok']&&!('errorMessage'in _0x4c487d))return _0x4c487d;{const _0x3a41a8=_0x1c690d['ok']?_0x4c487d['errorMessage']:_0x4c487d['error']['message'],[_0x565f45,_0x1df918]=_0x3a41a8['split']('\x20:\x20');if(_0x565f45==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x39bc9e,'credential-already-in-use',_0x4c487d);if(_0x565f45==='EMAIL_EXISTS')throw en(_0x39bc9e,'email-already-in-use',_0x4c487d);if(_0x565f45==='USER_DISABLED')throw en(_0x39bc9e,'user-disabled',_0x4c487d);const _0x14b51d=_0x5a2e04[_0x565f45]||_0x565f45['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1df918)throw ya(_0x39bc9e,_0x14b51d,_0x1df918);K(_0x39bc9e,_0x14b51d);}}catch(_0x535cad){if(_0x535cad instanceof Se)throw _0x535cad;K(_0x39bc9e,'network-request-failed',{'message':String(_0x535cad)});}}async function Yt(_0x2e5cc8,_0x36e972,_0x27dbe4,_0x3ac05b,_0x3f99b6={}){const _0xe14216=await Ae(_0x2e5cc8,_0x36e972,_0x27dbe4,_0x3ac05b,_0x3f99b6);return'mfaPendingCredential'in _0xe14216&&K(_0x2e5cc8,'multi-factor-auth-required',{'_serverResponse':_0xe14216}),_0xe14216;}async function Ia(_0x54cf58,_0x3a06e3,_0x5102d2,_0x51d22c){const _0x2b2981=''+_0x3a06e3+_0x5102d2+'?'+_0x51d22c,_0xb256c1=_0x54cf58,_0x105091=_0xb256c1['config']['emulator']?Is(_0x54cf58['config'],_0x2b2981):_0x54cf58['config']['apiScheme']+'://'+_0x2b2981;return of['includes'](_0x5102d2)&&(await _0xb256c1['_persistenceManagerAvailable'],_0xb256c1['_getPersistenceType']()==='COOKIE')?_0xb256c1['_getPersistence']()['_getFinalTarget'](_0x105091)['toString']():_0x105091;}function cf(_0x8114ed){switch(_0x8114ed){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5ac7c7){this['auth']=_0x5ac7c7,this['timer']=null,this['promise']=new Promise((_0x24c643,_0x567748)=>{this['timer']=setTimeout(()=>_0x567748(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4e0a14,_0x2c76f0,_0x38e7be){const _0x368919={'appName':_0x4e0a14['name']};_0x38e7be['email']&&(_0x368919['email']=_0x38e7be['email']),_0x38e7be['phoneNumber']&&(_0x368919['phoneNumber']=_0x38e7be['phoneNumber']);const _0x19155c=J(_0x4e0a14,_0x2c76f0,_0x368919);return _0x19155c['customData']['_tokenResponse']=_0x38e7be,_0x19155c;}function vr(_0x5b6fcf){return _0x5b6fcf!==void 0x0&&_0x5b6fcf['enterprise']!==void 0x0;}class hf{constructor(_0x31ae11){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x31ae11['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x31ae11['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x31ae11['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x17a801){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x32c6e2 of this['recaptchaEnforcementState'])if(_0x32c6e2['provider']&&_0x32c6e2['provider']===_0x17a801)return cf(_0x32c6e2['enforcementState']);return null;}['isProviderEnabled'](_0x10a110){return this['getProviderEnforcementState'](_0x10a110)==='ENFORCE'||this['getProviderEnforcementState'](_0x10a110)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x98899,_0x5c10af){return Ae(_0x98899,'GET','/v2/recaptchaConfig',Re(_0x98899,_0x5c10af));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x1b5f89,_0x32bde9){return Ae(_0x1b5f89,'POST','/v1/accounts:delete',_0x32bde9);}async function Sn(_0x9a30d0,_0x116269){return Ae(_0x9a30d0,'POST','/v1/accounts:lookup',_0x116269);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x591c45){if(_0x591c45)try{const _0x5f1917=new Date(Number(_0x591c45));if(!isNaN(_0x5f1917['getTime']()))return _0x5f1917['toUTCString']();}catch{}}async function ff(_0x1c79f2,_0x45dedf=!0x1){const _0x1ceea0=k(_0x1c79f2),_0x2f67b3=await _0x1ceea0['getIdToken'](_0x45dedf),_0x2524ca=ws(_0x2f67b3);m(_0x2524ca&&_0x2524ca['exp']&&_0x2524ca['auth_time']&&_0x2524ca['iat'],_0x1ceea0['auth'],'internal-error');const _0x4a74ce=typeof _0x2524ca['firebase']=='object'?_0x2524ca['firebase']:void 0x0,_0x2e0701=_0x4a74ce==null?void 0x0:_0x4a74ce['sign_in_provider'];return{'claims':_0x2524ca,'token':_0x2f67b3,'authTime':St(ci(_0x2524ca['auth_time'])),'issuedAtTime':St(ci(_0x2524ca['iat'])),'expirationTime':St(ci(_0x2524ca['exp'])),'signInProvider':_0x2e0701||null,'signInSecondFactor':(_0x4a74ce==null?void 0x0:_0x4a74ce['sign_in_second_factor'])||null};}function ci(_0x456720){return Number(_0x456720)*0x3e8;}function ws(_0x11e3dd){const [_0x1c5263,_0x445cf2,_0x123510]=_0x11e3dd['split']('.');if(_0x1c5263===void 0x0||_0x445cf2===void 0x0||_0x123510===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x324e51=cn(_0x445cf2);return _0x324e51?JSON['parse'](_0x324e51):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2cad76){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2cad76==null?void 0x0:_0x2cad76['toString']()),null;}}function Er(_0x31efd1){const _0x42fa55=ws(_0x31efd1);return m(_0x42fa55,'internal-error'),m(typeof _0x42fa55['exp']<'u','internal-error'),m(typeof _0x42fa55['iat']<'u','internal-error'),Number(_0x42fa55['exp'])-Number(_0x42fa55['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x29f113,_0x4cc25f,_0x4f6dd8=!0x1){if(_0x4f6dd8)return _0x4cc25f;try{return await _0x4cc25f;}catch(_0x2c3919){throw _0x2c3919 instanceof Se&&pf(_0x2c3919)&&_0x29f113['auth']['currentUser']===_0x29f113&&await _0x29f113['auth']['signOut'](),_0x2c3919;}}function pf({code:_0x193126}){return _0x193126==='auth/user-disabled'||_0x193126==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x4286c3){this['user']=_0x4286c3,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x567ec0){if(_0x567ec0){const _0x14ad29=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x14ad29;}else{this['errorBackoff']=0x7530;const _0x3cc9ec=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3cc9ec);}}['schedule'](_0x35c72c=!0x1){if(!this['isRunning'])return;const _0xfb3beb=this['getInterval'](_0x35c72c);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xfb3beb);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x574231){(_0x574231==null?void 0x0:_0x574231['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x58878e,_0x4f5774){this['createdAt']=_0x58878e,this['lastLoginAt']=_0x4f5774,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x10faf3){this['createdAt']=_0x10faf3['createdAt'],this['lastLoginAt']=_0x10faf3['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x37ef25){var _0x67475b;const _0x19c510=_0x37ef25['auth'],_0x58fe46=await _0x37ef25['getIdToken'](),_0x239989=await xt(_0x37ef25,Sn(_0x19c510,{'idToken':_0x58fe46}));m(_0x239989==null?void 0x0:_0x239989['users']['length'],_0x19c510,'internal-error');const _0x12d888=_0x239989['users'][0x0];_0x37ef25['_notifyReloadListener'](_0x12d888);const _0x2b4d28=(_0x67475b=_0x12d888['providerUserInfo'])!=null&&_0x67475b['length']?wa(_0x12d888['providerUserInfo']):[],_0xa9dfbd=mf(_0x37ef25['providerData'],_0x2b4d28),_0x2d41e7=_0x37ef25['isAnonymous'],_0x109627=!(_0x37ef25['email']&&_0x12d888['passwordHash'])&&!(_0xa9dfbd!=null&&_0xa9dfbd['length']),_0x55bb8f=_0x2d41e7?_0x109627:!0x1,_0x2ec535={'uid':_0x12d888['localId'],'displayName':_0x12d888['displayName']||null,'photoURL':_0x12d888['photoUrl']||null,'email':_0x12d888['email']||null,'emailVerified':_0x12d888['emailVerified']||!0x1,'phoneNumber':_0x12d888['phoneNumber']||null,'tenantId':_0x12d888['tenantId']||null,'providerData':_0xa9dfbd,'metadata':new Pi(_0x12d888['createdAt'],_0x12d888['lastLoginAt']),'isAnonymous':_0x55bb8f};Object['assign'](_0x37ef25,_0x2ec535);}async function gf(_0x2ccec9){const _0x4fbe69=k(_0x2ccec9);await bn(_0x4fbe69),await _0x4fbe69['auth']['_persistUserIfCurrent'](_0x4fbe69),_0x4fbe69['auth']['_notifyListenersIfCurrent'](_0x4fbe69);}function mf(_0x4adf70,_0xd12c1c){return[..._0x4adf70['filter'](_0xe633a6=>!_0xd12c1c['some'](_0xa9d8d7=>_0xa9d8d7['providerId']===_0xe633a6['providerId'])),..._0xd12c1c];}function wa(_0x206f60){return _0x206f60['map'](({providerId:_0x3de673,..._0x44360a})=>({'providerId':_0x3de673,'uid':_0x44360a['rawId']||'','displayName':_0x44360a['displayName']||null,'email':_0x44360a['email']||null,'phoneNumber':_0x44360a['phoneNumber']||null,'photoURL':_0x44360a['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x248b4a,_0xcbec1b){const _0x144477=await Ea(_0x248b4a,{},async()=>{const _0x398b73=at({'grant_type':'refresh_token','refresh_token':_0xcbec1b})['slice'](0x1),{tokenApiHost:_0x4e8d97,apiKey:_0x41f6c4}=_0x248b4a['config'],_0x978ee0=await Ia(_0x248b4a,_0x4e8d97,'/v1/token','key='+_0x41f6c4),_0x3e4c2f=await _0x248b4a['_getAdditionalHeaders']();_0x3e4c2f['Content-Type']='application/x-www-form-urlencoded';const _0x1a0708={'method':'POST','headers':_0x3e4c2f,'body':_0x398b73};return _0x248b4a['emulatorConfig']&&Wt(_0x248b4a['emulatorConfig']['host'])&&(_0x1a0708['credentials']='include'),va['fetch']()(_0x978ee0,_0x1a0708);});return{'accessToken':_0x144477['access_token'],'expiresIn':_0x144477['expires_in'],'refreshToken':_0x144477['refresh_token']};}async function vf(_0x56317,_0x58f09f){return Ae(_0x56317,'POST','/v2/accounts:revokeToken',Re(_0x56317,_0x58f09f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2e83ed){m(_0x2e83ed['idToken'],'internal-error'),m(typeof _0x2e83ed['idToken']<'u','internal-error'),m(typeof _0x2e83ed['refreshToken']<'u','internal-error');const _0x56882f='expiresIn'in _0x2e83ed&&typeof _0x2e83ed['expiresIn']<'u'?Number(_0x2e83ed['expiresIn']):Er(_0x2e83ed['idToken']);this['updateTokensAndExpiration'](_0x2e83ed['idToken'],_0x2e83ed['refreshToken'],_0x56882f);}['updateFromIdToken'](_0x328450){m(_0x328450['length']!==0x0,'internal-error');const _0x2b37ab=Er(_0x328450);this['updateTokensAndExpiration'](_0x328450,null,_0x2b37ab);}async['getToken'](_0x33a87e,_0x449d96=!0x1){return!_0x449d96&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x33a87e,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x33a87e,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x538e7c,_0x5e190b){const {accessToken:_0x9929ef,refreshToken:_0x45b165,expiresIn:_0x472ace}=await yf(_0x538e7c,_0x5e190b);this['updateTokensAndExpiration'](_0x9929ef,_0x45b165,Number(_0x472ace));}['updateTokensAndExpiration'](_0x48c688,_0x2a5171,_0x1b357d){this['refreshToken']=_0x2a5171||null,this['accessToken']=_0x48c688||null,this['expirationTime']=Date['now']()+_0x1b357d*0x3e8;}static['fromJSON'](_0xad20f0,_0x443950){const {refreshToken:_0x5b0147,accessToken:_0x17ccf7,expirationTime:_0x1bb83a}=_0x443950,_0x1563af=new Je();return _0x5b0147&&(m(typeof _0x5b0147=='string','internal-error',{'appName':_0xad20f0}),_0x1563af['refreshToken']=_0x5b0147),_0x17ccf7&&(m(typeof _0x17ccf7=='string','internal-error',{'appName':_0xad20f0}),_0x1563af['accessToken']=_0x17ccf7),_0x1bb83a&&(m(typeof _0x1bb83a=='number','internal-error',{'appName':_0xad20f0}),_0x1563af['expirationTime']=_0x1bb83a),_0x1563af;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x323db8){this['accessToken']=_0x323db8['accessToken'],this['refreshToken']=_0x323db8['refreshToken'],this['expirationTime']=_0x323db8['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x41886d,_0x94b420){m(typeof _0x41886d=='string'||typeof _0x41886d>'u','internal-error',{'appName':_0x94b420});}class z{constructor({uid:_0x1827af,auth:_0x4aac9c,stsTokenManager:_0x1d3f23,..._0x115244}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1827af,this['auth']=_0x4aac9c,this['stsTokenManager']=_0x1d3f23,this['accessToken']=_0x1d3f23['accessToken'],this['displayName']=_0x115244['displayName']||null,this['email']=_0x115244['email']||null,this['emailVerified']=_0x115244['emailVerified']||!0x1,this['phoneNumber']=_0x115244['phoneNumber']||null,this['photoURL']=_0x115244['photoURL']||null,this['isAnonymous']=_0x115244['isAnonymous']||!0x1,this['tenantId']=_0x115244['tenantId']||null,this['providerData']=_0x115244['providerData']?[..._0x115244['providerData']]:[],this['metadata']=new Pi(_0x115244['createdAt']||void 0x0,_0x115244['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1f30aa){const _0x456658=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1f30aa));return m(_0x456658,this['auth'],'internal-error'),this['accessToken']!==_0x456658&&(this['accessToken']=_0x456658,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x456658;}['getIdTokenResult'](_0xf6e666){return ff(this,_0xf6e666);}['reload'](){return gf(this);}['_assign'](_0x16bc0a){this!==_0x16bc0a&&(m(this['uid']===_0x16bc0a['uid'],this['auth'],'internal-error'),this['displayName']=_0x16bc0a['displayName'],this['photoURL']=_0x16bc0a['photoURL'],this['email']=_0x16bc0a['email'],this['emailVerified']=_0x16bc0a['emailVerified'],this['phoneNumber']=_0x16bc0a['phoneNumber'],this['isAnonymous']=_0x16bc0a['isAnonymous'],this['tenantId']=_0x16bc0a['tenantId'],this['providerData']=_0x16bc0a['providerData']['map'](_0x3f820a=>({..._0x3f820a})),this['metadata']['_copy'](_0x16bc0a['metadata']),this['stsTokenManager']['_assign'](_0x16bc0a['stsTokenManager']));}['_clone'](_0x4f4ce8){const _0xe04b60=new z({...this,'auth':_0x4f4ce8,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xe04b60['metadata']['_copy'](this['metadata']),_0xe04b60;}['_onReload'](_0x398c5b){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x398c5b,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3a7ba7){this['reloadListener']?this['reloadListener'](_0x3a7ba7):this['reloadUserInfo']=_0x3a7ba7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x16c7b5,_0x3f2776=!0x1){let _0x4fefb3=!0x1;_0x16c7b5['idToken']&&_0x16c7b5['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x16c7b5),_0x4fefb3=!0x0),_0x3f2776&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4fefb3&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x41c26a=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x41c26a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4b2a71=>({..._0x4b2a71})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1e8c1c,_0x4efb58){const _0x3f34cf=_0x4efb58['displayName']??void 0x0,_0x5932d8=_0x4efb58['email']??void 0x0,_0x58d907=_0x4efb58['phoneNumber']??void 0x0,_0x3ed726=_0x4efb58['photoURL']??void 0x0,_0x379e20=_0x4efb58['tenantId']??void 0x0,_0x58c8c5=_0x4efb58['_redirectEventId']??void 0x0,_0x5922fe=_0x4efb58['createdAt']??void 0x0,_0x1a29b1=_0x4efb58['lastLoginAt']??void 0x0,{uid:_0x51dcdd,emailVerified:_0xf56872,isAnonymous:_0x9de198,providerData:_0x45fa81,stsTokenManager:_0x101d85}=_0x4efb58;m(_0x51dcdd&&_0x101d85,_0x1e8c1c,'internal-error');const _0x1af1a7=Je['fromJSON'](this['name'],_0x101d85);m(typeof _0x51dcdd=='string',_0x1e8c1c,'internal-error'),ce(_0x3f34cf,_0x1e8c1c['name']),ce(_0x5932d8,_0x1e8c1c['name']),m(typeof _0xf56872=='boolean',_0x1e8c1c,'internal-error'),m(typeof _0x9de198=='boolean',_0x1e8c1c,'internal-error'),ce(_0x58d907,_0x1e8c1c['name']),ce(_0x3ed726,_0x1e8c1c['name']),ce(_0x379e20,_0x1e8c1c['name']),ce(_0x58c8c5,_0x1e8c1c['name']),ce(_0x5922fe,_0x1e8c1c['name']),ce(_0x1a29b1,_0x1e8c1c['name']);const _0x37454b=new z({'uid':_0x51dcdd,'auth':_0x1e8c1c,'email':_0x5932d8,'emailVerified':_0xf56872,'displayName':_0x3f34cf,'isAnonymous':_0x9de198,'photoURL':_0x3ed726,'phoneNumber':_0x58d907,'tenantId':_0x379e20,'stsTokenManager':_0x1af1a7,'createdAt':_0x5922fe,'lastLoginAt':_0x1a29b1});return _0x45fa81&&Array['isArray'](_0x45fa81)&&(_0x37454b['providerData']=_0x45fa81['map'](_0x33cdf4=>({..._0x33cdf4}))),_0x58c8c5&&(_0x37454b['_redirectEventId']=_0x58c8c5),_0x37454b;}static async['_fromIdTokenResponse'](_0x3bb5a3,_0x4dffaa,_0x5e42f6=!0x1){const _0x127a3f=new Je();_0x127a3f['updateFromServerResponse'](_0x4dffaa);const _0x5785c8=new z({'uid':_0x4dffaa['localId'],'auth':_0x3bb5a3,'stsTokenManager':_0x127a3f,'isAnonymous':_0x5e42f6});return await bn(_0x5785c8),_0x5785c8;}static async['_fromGetAccountInfoResponse'](_0xd7041d,_0x279ca7,_0x4ada5a){const _0x5b1fc8=_0x279ca7['users'][0x0];m(_0x5b1fc8['localId']!==void 0x0,'internal-error');const _0x2b38e9=_0x5b1fc8['providerUserInfo']!==void 0x0?wa(_0x5b1fc8['providerUserInfo']):[],_0xc21564=!(_0x5b1fc8['email']&&_0x5b1fc8['passwordHash'])&&!(_0x2b38e9!=null&&_0x2b38e9['length']),_0x4f13bc=new Je();_0x4f13bc['updateFromIdToken'](_0x4ada5a);const _0x402013=new z({'uid':_0x5b1fc8['localId'],'auth':_0xd7041d,'stsTokenManager':_0x4f13bc,'isAnonymous':_0xc21564}),_0x4bec27={'uid':_0x5b1fc8['localId'],'displayName':_0x5b1fc8['displayName']||null,'photoURL':_0x5b1fc8['photoUrl']||null,'email':_0x5b1fc8['email']||null,'emailVerified':_0x5b1fc8['emailVerified']||!0x1,'phoneNumber':_0x5b1fc8['phoneNumber']||null,'tenantId':_0x5b1fc8['tenantId']||null,'providerData':_0x2b38e9,'metadata':new Pi(_0x5b1fc8['createdAt'],_0x5b1fc8['lastLoginAt']),'isAnonymous':!(_0x5b1fc8['email']&&_0x5b1fc8['passwordHash'])&&!(_0x2b38e9!=null&&_0x2b38e9['length'])};return Object['assign'](_0x402013,_0x4bec27),_0x402013;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x4906d8){ae(_0x4906d8 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x321fd5=Ir['get'](_0x4906d8);return _0x321fd5?(ae(_0x321fd5 instanceof _0x4906d8,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x321fd5):(_0x321fd5=new _0x4906d8(),Ir['set'](_0x4906d8,_0x321fd5),_0x321fd5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2984a0,_0x1a5415){this['storage'][_0x2984a0]=_0x1a5415;}async['_get'](_0xf788ed){const _0x494344=this['storage'][_0xf788ed];return _0x494344===void 0x0?null:_0x494344;}async['_remove'](_0x28b9c9){delete this['storage'][_0x28b9c9];}['_addListener'](_0x5c125a,_0x3e9cce){}['_removeListener'](_0x3e9682,_0x33458c){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x383118,_0x25e99c,_0x49befd){return'firebase:'+_0x383118+':'+_0x25e99c+':'+_0x49befd;}class Xe{constructor(_0xaf95a8,_0x308b3e,_0x4531f2){this['persistence']=_0xaf95a8,this['auth']=_0x308b3e,this['userKey']=_0x4531f2;const {config:_0x278eab,name:_0x43ca4b}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x278eab['apiKey'],_0x43ca4b),this['fullPersistenceKey']=sn('persistence',_0x278eab['apiKey'],_0x43ca4b),this['boundEventHandler']=_0x308b3e['_onStorageEvent']['bind'](_0x308b3e),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x92e1a1){return this['persistence']['_set'](this['fullUserKey'],_0x92e1a1['toJSON']());}async['getCurrentUser'](){const _0x3903b2=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3903b2)return null;if(typeof _0x3903b2=='string'){const _0x15396f=await Sn(this['auth'],{'idToken':_0x3903b2})['catch'](()=>{});return _0x15396f?z['_fromGetAccountInfoResponse'](this['auth'],_0x15396f,_0x3903b2):null;}return z['_fromJSON'](this['auth'],_0x3903b2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x41b3db){if(this['persistence']===_0x41b3db)return;const _0x1b94f8=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x41b3db,_0x1b94f8)return this['setCurrentUser'](_0x1b94f8);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4d9c9d,_0x2b80b8,_0x35d03b='authUser'){if(!_0x2b80b8['length'])return new Xe(ne(wr),_0x4d9c9d,_0x35d03b);const _0x433bf0=(await Promise['all'](_0x2b80b8['map'](async _0x3fdf12=>{if(await _0x3fdf12['_isAvailable']())return _0x3fdf12;})))['filter'](_0x565450=>_0x565450);let _0x4ba516=_0x433bf0[0x0]||ne(wr);const _0x541e20=sn(_0x35d03b,_0x4d9c9d['config']['apiKey'],_0x4d9c9d['name']);let _0x4d5e53=null;for(const _0x145e61 of _0x2b80b8)try{const _0x1f7e4b=await _0x145e61['_get'](_0x541e20);if(_0x1f7e4b){let _0x372136;if(typeof _0x1f7e4b=='string'){const _0x522ec1=await Sn(_0x4d9c9d,{'idToken':_0x1f7e4b})['catch'](()=>{});if(!_0x522ec1)break;_0x372136=await z['_fromGetAccountInfoResponse'](_0x4d9c9d,_0x522ec1,_0x1f7e4b);}else _0x372136=z['_fromJSON'](_0x4d9c9d,_0x1f7e4b);_0x145e61!==_0x4ba516&&(_0x4d5e53=_0x372136),_0x4ba516=_0x145e61;break;}}catch{}const _0x5edf8e=_0x433bf0['filter'](_0x2fd467=>_0x2fd467['_shouldAllowMigration']);return!_0x4ba516['_shouldAllowMigration']||!_0x5edf8e['length']?new Xe(_0x4ba516,_0x4d9c9d,_0x35d03b):(_0x4ba516=_0x5edf8e[0x0],_0x4d5e53&&await _0x4ba516['_set'](_0x541e20,_0x4d5e53['toJSON']()),await Promise['all'](_0x2b80b8['map'](async _0x14ef71=>{if(_0x14ef71!==_0x4ba516)try{await _0x14ef71['_remove'](_0x541e20);}catch{}})),new Xe(_0x4ba516,_0x4d9c9d,_0x35d03b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x1f1868){const _0x1ce8c6=_0x1f1868['toLowerCase']();if(_0x1ce8c6['includes']('opera/')||_0x1ce8c6['includes']('opr/')||_0x1ce8c6['includes']('opios/'))return'Opera';if(Ra(_0x1ce8c6))return'IEMobile';if(_0x1ce8c6['includes']('msie')||_0x1ce8c6['includes']('trident/'))return'IE';if(_0x1ce8c6['includes']('edge/'))return'Edge';if(Ta(_0x1ce8c6))return'Firefox';if(_0x1ce8c6['includes']('silk/'))return'Silk';if(ka(_0x1ce8c6))return'Blackberry';if(Na(_0x1ce8c6))return'Webos';if(Sa(_0x1ce8c6))return'Safari';if((_0x1ce8c6['includes']('chrome/')||ba(_0x1ce8c6))&&!_0x1ce8c6['includes']('edge/'))return'Chrome';if(Aa(_0x1ce8c6))return'Android';{const _0x22017b=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x40c64a=_0x1f1868['match'](_0x22017b);if((_0x40c64a==null?void 0x0:_0x40c64a['length'])===0x2)return _0x40c64a[0x1];}return'Other';}function Ta(_0x105364=W()){return/firefox\//i['test'](_0x105364);}function Sa(_0x5a394c=W()){const _0x34bab1=_0x5a394c['toLowerCase']();return _0x34bab1['includes']('safari/')&&!_0x34bab1['includes']('chrome/')&&!_0x34bab1['includes']('crios/')&&!_0x34bab1['includes']('android');}function ba(_0x1ebdbf=W()){return/crios\//i['test'](_0x1ebdbf);}function Ra(_0x286616=W()){return/iemobile/i['test'](_0x286616);}function Aa(_0x3bb919=W()){return/android/i['test'](_0x3bb919);}function ka(_0x1fc926=W()){return/blackberry/i['test'](_0x1fc926);}function Na(_0x2de73b=W()){return/webos/i['test'](_0x2de73b);}function Cs(_0x2767ac=W()){return/iphone|ipad|ipod/i['test'](_0x2767ac)||/macintosh/i['test'](_0x2767ac)&&/mobile/i['test'](_0x2767ac);}function Ef(_0x3624d8=W()){var _0x1abe4e;return Cs(_0x3624d8)&&!!((_0x1abe4e=window['navigator'])!=null&&_0x1abe4e['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2e57fd=W()){return Cs(_0x2e57fd)||Aa(_0x2e57fd)||Na(_0x2e57fd)||ka(_0x2e57fd)||/windows phone/i['test'](_0x2e57fd)||Ra(_0x2e57fd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x88c611,_0x151f98=[]){let _0x2c012b;switch(_0x88c611){case'Browser':_0x2c012b=Cr(W());break;case'Worker':_0x2c012b=Cr(W())+'-'+_0x88c611;break;default:_0x2c012b=_0x88c611;}const _0x7a06e=_0x151f98['length']?_0x151f98['join'](','):'FirebaseCore-web';return _0x2c012b+'/JsCore/'+ct+'/'+_0x7a06e;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2766b6){this['auth']=_0x2766b6,this['queue']=[];}['pushCallback'](_0x116fef,_0x231bf0){const _0x4ed5ea=_0x20e447=>new Promise((_0x174f74,_0x12604e)=>{try{const _0x521357=_0x116fef(_0x20e447);_0x174f74(_0x521357);}catch(_0x136a59){_0x12604e(_0x136a59);}});_0x4ed5ea['onAbort']=_0x231bf0,this['queue']['push'](_0x4ed5ea);const _0x4b8e8c=this['queue']['length']-0x1;return()=>{this['queue'][_0x4b8e8c]=()=>Promise['resolve']();};}async['runMiddleware'](_0x37e05a){if(this['auth']['currentUser']===_0x37e05a)return;const _0x3cb810=[];try{for(const _0x5d9a4f of this['queue'])await _0x5d9a4f(_0x37e05a),_0x5d9a4f['onAbort']&&_0x3cb810['push'](_0x5d9a4f['onAbort']);}catch(_0x178455){_0x3cb810['reverse']();for(const _0x4ed226 of _0x3cb810)try{_0x4ed226();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x178455==null?void 0x0:_0x178455['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x17c808,_0xf19eee={}){return Ae(_0x17c808,'GET','/v2/passwordPolicy',Re(_0x17c808,_0xf19eee));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x30a0f1){var _0x10ae43;const _0x27c294=_0x30a0f1['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x27c294['minPasswordLength']??Tf,_0x27c294['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x27c294['maxPasswordLength']),_0x27c294['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x27c294['containsLowercaseCharacter']),_0x27c294['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x27c294['containsUppercaseCharacter']),_0x27c294['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x27c294['containsNumericCharacter']),_0x27c294['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x27c294['containsNonAlphanumericCharacter']),this['enforcementState']=_0x30a0f1['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x10ae43=_0x30a0f1['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x10ae43['join'](''))??'',this['forceUpgradeOnSignin']=_0x30a0f1['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x30a0f1['schemaVersion'];}['validatePassword'](_0x5b843d){const _0x483373={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5b843d,_0x483373),this['validatePasswordCharacterOptions'](_0x5b843d,_0x483373),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['meetsMinPasswordLength']??!0x0),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['meetsMaxPasswordLength']??!0x0),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['containsLowercaseLetter']??!0x0),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['containsUppercaseLetter']??!0x0),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['containsNumericCharacter']??!0x0),_0x483373['isValid']&&(_0x483373['isValid']=_0x483373['containsNonAlphanumericCharacter']??!0x0),_0x483373;}['validatePasswordLengthOptions'](_0x61efdc,_0x53f84d){const _0x46f5e8=this['customStrengthOptions']['minPasswordLength'],_0x5e90be=this['customStrengthOptions']['maxPasswordLength'];_0x46f5e8&&(_0x53f84d['meetsMinPasswordLength']=_0x61efdc['length']>=_0x46f5e8),_0x5e90be&&(_0x53f84d['meetsMaxPasswordLength']=_0x61efdc['length']<=_0x5e90be);}['validatePasswordCharacterOptions'](_0x2702d7,_0x4fe664){this['updatePasswordCharacterOptionsStatuses'](_0x4fe664,!0x1,!0x1,!0x1,!0x1);let _0x383bb6;for(let _0x1c11c9=0x0;_0x1c11c9<_0x2702d7['length'];_0x1c11c9++)_0x383bb6=_0x2702d7['charAt'](_0x1c11c9),this['updatePasswordCharacterOptionsStatuses'](_0x4fe664,_0x383bb6>='a'&&_0x383bb6<='z',_0x383bb6>='A'&&_0x383bb6<='Z',_0x383bb6>='0'&&_0x383bb6<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x383bb6));}['updatePasswordCharacterOptionsStatuses'](_0x7d060d,_0x234032,_0x376bd0,_0x1d097e,_0x4b37bc){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x7d060d['containsLowercaseLetter']||(_0x7d060d['containsLowercaseLetter']=_0x234032)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x7d060d['containsUppercaseLetter']||(_0x7d060d['containsUppercaseLetter']=_0x376bd0)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x7d060d['containsNumericCharacter']||(_0x7d060d['containsNumericCharacter']=_0x1d097e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x7d060d['containsNonAlphanumericCharacter']||(_0x7d060d['containsNonAlphanumericCharacter']=_0x4b37bc));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1dd49b,_0x25c1de,_0x36b254,_0x7d6204){this['app']=_0x1dd49b,this['heartbeatServiceProvider']=_0x25c1de,this['appCheckServiceProvider']=_0x36b254,this['config']=_0x7d6204,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1dd49b['name'],this['clientVersion']=_0x7d6204['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3577c9=>this['_resolvePersistenceManagerAvailable']=_0x3577c9);}['_initializeWithPersistence'](_0x239137,_0x34f8ef){return _0x34f8ef&&(this['_popupRedirectResolver']=ne(_0x34f8ef)),this['_initializationPromise']=this['queue'](async()=>{var _0x55975c,_0x329651,_0x23e5f9;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x239137),(_0x55975c=this['_resolvePersistenceManagerAvailable'])==null||_0x55975c['call'](this),!this['_deleted'])){if((_0x329651=this['_popupRedirectResolver'])!=null&&_0x329651['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x34f8ef),this['lastNotifiedUid']=((_0x23e5f9=this['currentUser'])==null?void 0x0:_0x23e5f9['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5ba47c=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5ba47c)){if(this['currentUser']&&_0x5ba47c&&this['currentUser']['uid']===_0x5ba47c['uid']){this['_currentUser']['_assign'](_0x5ba47c),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5ba47c,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x372a20){try{const _0x367bea=await Sn(this,{'idToken':_0x372a20}),_0x5f0427=await z['_fromGetAccountInfoResponse'](this,_0x367bea,_0x372a20);await this['directlySetCurrentUser'](_0x5f0427);}catch(_0x38b9f5){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x38b9f5),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x59581c){var _0x2d2e30;if(H(this['app'])){const _0x175c22=this['app']['settings']['authIdToken'];return _0x175c22?new Promise(_0x4a48be=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x175c22)['then'](_0x4a48be,_0x4a48be));}):this['directlySetCurrentUser'](null);}const _0x3a52f8=await this['assertedPersistence']['getCurrentUser']();let _0x1bb751=_0x3a52f8,_0x3a4a50=!0x1;if(_0x59581c&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xf15617=(_0x2d2e30=this['redirectUser'])==null?void 0x0:_0x2d2e30['_redirectEventId'],_0x168b0a=_0x1bb751==null?void 0x0:_0x1bb751['_redirectEventId'],_0x52e634=await this['tryRedirectSignIn'](_0x59581c);(!_0xf15617||_0xf15617===_0x168b0a)&&(_0x52e634!=null&&_0x52e634['user'])&&(_0x1bb751=_0x52e634['user'],_0x3a4a50=!0x0);}if(!_0x1bb751)return this['directlySetCurrentUser'](null);if(!_0x1bb751['_redirectEventId']){if(_0x3a4a50)try{await this['beforeStateQueue']['runMiddleware'](_0x1bb751);}catch(_0x2ed3cf){_0x1bb751=_0x3a52f8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2ed3cf));}return _0x1bb751?this['reloadAndSetCurrentUserOrClear'](_0x1bb751):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1bb751['_redirectEventId']?this['directlySetCurrentUser'](_0x1bb751):this['reloadAndSetCurrentUserOrClear'](_0x1bb751);}async['tryRedirectSignIn'](_0x689adc){let _0x16e076=null;try{_0x16e076=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x689adc,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x16e076;}async['reloadAndSetCurrentUserOrClear'](_0x1844ac){try{await bn(_0x1844ac);}catch(_0xf38f86){if((_0xf38f86==null?void 0x0:_0xf38f86['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1844ac);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1b82b3){if(H(this['app']))return Promise['reject'](se(this));const _0x283bb3=_0x1b82b3?k(_0x1b82b3):null;return _0x283bb3&&m(_0x283bb3['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x283bb3&&_0x283bb3['_clone'](this));}async['_updateCurrentUser'](_0x215b39,_0x2ddf46=!0x1){if(!this['_deleted'])return _0x215b39&&m(this['tenantId']===_0x215b39['tenantId'],this,'tenant-id-mismatch'),_0x2ddf46||await this['beforeStateQueue']['runMiddleware'](_0x215b39),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x215b39),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x372c74){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x372c74));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5aabc5){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x129826=this['_getPasswordPolicyInternal']();return _0x129826['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x129826['validatePassword'](_0x5aabc5);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x423ce8=await Cf(this),_0x1b348c=new Sf(_0x423ce8);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1b348c:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1b348c;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3e7427){this['_errorFactory']=new Ut('auth','Firebase',_0x3e7427());}['onAuthStateChanged'](_0x1335fb,_0x2c0a51,_0x11ec6e){return this['registerStateListener'](this['authStateSubscription'],_0x1335fb,_0x2c0a51,_0x11ec6e);}['beforeAuthStateChanged'](_0x4e0933,_0x3a7dd8){return this['beforeStateQueue']['pushCallback'](_0x4e0933,_0x3a7dd8);}['onIdTokenChanged'](_0x43ca6f,_0x32349b,_0xcb9904){return this['registerStateListener'](this['idTokenSubscription'],_0x43ca6f,_0x32349b,_0xcb9904);}['authStateReady'](){return new Promise((_0x351503,_0x5c7277)=>{if(this['currentUser'])_0x351503();else{const _0x789d9f=this['onAuthStateChanged'](()=>{_0x789d9f(),_0x351503();},_0x5c7277);}});}async['revokeAccessToken'](_0x51acd5){if(this['currentUser']){const _0xdb0300=await this['currentUser']['getIdToken'](),_0x57b44d={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x51acd5,'idToken':_0xdb0300};this['tenantId']!=null&&(_0x57b44d['tenantId']=this['tenantId']),await vf(this,_0x57b44d);}}['toJSON'](){var _0x19bd03;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x19bd03=this['_currentUser'])==null?void 0x0:_0x19bd03['toJSON']()};}async['_setRedirectUser'](_0x111b74,_0x199ed6){const _0x2b3f87=await this['getOrInitRedirectPersistenceManager'](_0x199ed6);return _0x111b74===null?_0x2b3f87['removeCurrentUser']():_0x2b3f87['setCurrentUser'](_0x111b74);}async['getOrInitRedirectPersistenceManager'](_0x142176){if(!this['redirectPersistenceManager']){const _0x2454ca=_0x142176&&ne(_0x142176)||this['_popupRedirectResolver'];m(_0x2454ca,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x2454ca['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x507517){var _0x4cbc6a,_0xbfe7c8;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4cbc6a=this['_currentUser'])==null?void 0x0:_0x4cbc6a['_redirectEventId'])===_0x507517?this['_currentUser']:((_0xbfe7c8=this['redirectUser'])==null?void 0x0:_0xbfe7c8['_redirectEventId'])===_0x507517?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x272467){if(_0x272467===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x272467));}['_notifyListenersIfCurrent'](_0x4fd402){_0x4fd402===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x442a90;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2c24c6=((_0x442a90=this['currentUser'])==null?void 0x0:_0x442a90['uid'])??null;this['lastNotifiedUid']!==_0x2c24c6&&(this['lastNotifiedUid']=_0x2c24c6,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4e8b5e,_0x575bda,_0xdcd00f,_0x402eae){if(this['_deleted'])return()=>{};const _0x352cf2=typeof _0x575bda=='function'?_0x575bda:_0x575bda['next']['bind'](_0x575bda);let _0xebb702=!0x1;const _0xa21eed=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xa21eed,this,'internal-error'),_0xa21eed['then'](()=>{_0xebb702||_0x352cf2(this['currentUser']);}),typeof _0x575bda=='function'){const _0x46500=_0x4e8b5e['addObserver'](_0x575bda,_0xdcd00f,_0x402eae);return()=>{_0xebb702=!0x0,_0x46500();};}else{const _0xc0ff47=_0x4e8b5e['addObserver'](_0x575bda);return()=>{_0xebb702=!0x0,_0xc0ff47();};}}async['directlySetCurrentUser'](_0x110b70){this['currentUser']&&this['currentUser']!==_0x110b70&&this['_currentUser']['_stopProactiveRefresh'](),_0x110b70&&this['isProactiveRefreshEnabled']&&_0x110b70['_startProactiveRefresh'](),this['currentUser']=_0x110b70,_0x110b70?await this['assertedPersistence']['setCurrentUser'](_0x110b70):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4b3163){return this['operations']=this['operations']['then'](_0x4b3163,_0x4b3163),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x529075){!_0x529075||this['frameworks']['includes'](_0x529075)||(this['frameworks']['push'](_0x529075),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1c72ae;const _0x57ffda={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x57ffda['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x45198d=await((_0x1c72ae=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1c72ae['getHeartbeatsHeader']());_0x45198d&&(_0x57ffda['X-Firebase-Client']=_0x45198d);const _0x3f0d3c=await this['_getAppCheckToken']();return _0x3f0d3c&&(_0x57ffda['X-Firebase-AppCheck']=_0x3f0d3c),_0x57ffda;}async['_getAppCheckToken'](){var _0x342d3c;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x49f5ad=await((_0x342d3c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x342d3c['getToken']());return _0x49f5ad!=null&&_0x49f5ad['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x49f5ad['error']),_0x49f5ad==null?void 0x0:_0x49f5ad['token'];}}function qe(_0x5dd009){return k(_0x5dd009);}class Tr{constructor(_0xea78a0){this['auth']=_0xea78a0,this['observer']=null,this['addObserver']=Ic(_0x442e85=>this['observer']=_0x442e85);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2b1d7c){zn=_0x2b1d7c;}function Da(_0x15cc41){return zn['loadJS'](_0x15cc41);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x104c99){return'__'+_0x104c99+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x20b7f5){_0x20b7f5();}['execute'](_0x39be63,_0x5139bd){return Promise['resolve']('token');}['render'](_0x3a7ec8,_0x39b15a){return'';}}class Of{['ready'](_0x3dcff1){_0x3dcff1();}['execute'](_0x1a5cee,_0x498adb){return Promise['resolve']('token');}['render'](_0x20bb43,_0x49eead){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5028f5){this['type']=Df,this['auth']=qe(_0x5028f5);}async['verify'](_0x2b23cc='verify',_0x49ba9b=!0x1){async function _0x362e48(_0x322978){if(!_0x49ba9b){if(_0x322978['tenantId']==null&&_0x322978['_agentRecaptchaConfig']!=null)return _0x322978['_agentRecaptchaConfig']['siteKey'];if(_0x322978['tenantId']!=null&&_0x322978['_tenantRecaptchaConfigs'][_0x322978['tenantId']]!==void 0x0)return _0x322978['_tenantRecaptchaConfigs'][_0x322978['tenantId']]['siteKey'];}return new Promise(async(_0x10c964,_0x102951)=>{uf(_0x322978,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x7e49aa=>{if(_0x7e49aa['recaptchaKey']===void 0x0)_0x102951(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xb94ff3=new hf(_0x7e49aa);return _0x322978['tenantId']==null?_0x322978['_agentRecaptchaConfig']=_0xb94ff3:_0x322978['_tenantRecaptchaConfigs'][_0x322978['tenantId']]=_0xb94ff3,_0x10c964(_0xb94ff3['siteKey']);}})['catch'](_0x4244a5=>{_0x102951(_0x4244a5);});});}function _0x5dad19(_0x15d959,_0x7b9342,_0x389206){const _0x547c03=window['grecaptcha'];vr(_0x547c03)?_0x547c03['enterprise']['ready'](()=>{_0x547c03['enterprise']['execute'](_0x15d959,{'action':_0x2b23cc})['then'](_0x1ee8eb=>{_0x7b9342(_0x1ee8eb);})['catch'](()=>{_0x7b9342(Ma);});}):_0x389206(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3c87fe,_0x68f6d4)=>{_0x362e48(this['auth'])['then'](async _0x2f3d99=>{if(!_0x49ba9b&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5dad19(_0x2f3d99,_0x3c87fe,_0x68f6d4);else{if(typeof window>'u'){_0x68f6d4(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xc24ccb=Af();_0xc24ccb['length']!==0x0&&(_0xc24ccb+=_0x2f3d99+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x568bd9;(_0x568bd9=le['scriptInjectionDeferred'])==null||_0x568bd9['resolve']();},Da(_0xc24ccb)['then'](()=>{var _0x2cf47d;return(_0x2cf47d=le['scriptInjectionDeferred'])==null?void 0x0:_0x2cf47d['promise'];})['then'](()=>{_0x5dad19(_0x2f3d99,_0x3c87fe,_0x68f6d4);})['catch'](_0xb250df=>{_0x68f6d4(_0xb250df);});}})['catch'](_0x5b1ff3=>{_0x68f6d4(_0x5b1ff3);});});}}le['scriptInjectionDeferred']=null;async function br(_0x554fcf,_0x11cd39,_0x142821,_0x3576cb=!0x1,_0x383e95=!0x1){const _0x178284=new le(_0x554fcf);let _0x195409;if(_0x383e95)_0x195409=Ma;else try{_0x195409=await _0x178284['verify'](_0x142821);}catch{_0x195409=await _0x178284['verify'](_0x142821,!0x0);}const _0x349235={..._0x11cd39};if(_0x142821==='mfaSmsEnrollment'||_0x142821==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x349235){const _0x542d93=_0x349235['phoneEnrollmentInfo']['phoneNumber'],_0x39ce0a=_0x349235['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x349235,{'phoneEnrollmentInfo':{'phoneNumber':_0x542d93,'recaptchaToken':_0x39ce0a,'captchaResponse':_0x195409,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x349235){const _0x127910=_0x349235['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x349235,{'phoneSignInInfo':{'recaptchaToken':_0x127910,'captchaResponse':_0x195409,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x349235;}return _0x3576cb?Object['assign'](_0x349235,{'captchaResp':_0x195409}):Object['assign'](_0x349235,{'captchaResponse':_0x195409}),Object['assign'](_0x349235,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x349235,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x349235;}async function Oi(_0x1386fe,_0x25ab83,_0x2ff4c8,_0x267e7a,_0xa7a40d){var _0x2f8379;if((_0x2f8379=_0x1386fe['_getRecaptchaConfig']())!=null&&_0x2f8379['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x48a960=await br(_0x1386fe,_0x25ab83,_0x2ff4c8,_0x2ff4c8==='getOobCode');return _0x267e7a(_0x1386fe,_0x48a960);}else return _0x267e7a(_0x1386fe,_0x25ab83)['catch'](async _0x3c4fe3=>{if(_0x3c4fe3['code']==='auth/missing-recaptcha-token'){console['log'](_0x2ff4c8+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x27567e=await br(_0x1386fe,_0x25ab83,_0x2ff4c8,_0x2ff4c8==='getOobCode');return _0x267e7a(_0x1386fe,_0x27567e);}else return Promise['reject'](_0x3c4fe3);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x4b8b3a,_0xc5343){const _0x472cb8=Ui(_0x4b8b3a,'auth');if(_0x472cb8['isInitialized']()){const _0x3b9ef7=_0x472cb8['getImmediate'](),_0x14b923=_0x472cb8['getOptions']();if(De(_0x14b923,_0xc5343??{}))return _0x3b9ef7;K(_0x3b9ef7,'already-initialized');}return _0x472cb8['initialize']({'options':_0xc5343});}function Lf(_0x22b428,_0x22225d){const _0x505dc5=(_0x22225d==null?void 0x0:_0x22225d['persistence'])||[],_0x5b7b98=(Array['isArray'](_0x505dc5)?_0x505dc5:[_0x505dc5])['map'](ne);_0x22225d!=null&&_0x22225d['errorMap']&&_0x22b428['_updateErrorMap'](_0x22225d['errorMap']),_0x22b428['_initializeWithPersistence'](_0x5b7b98,_0x22225d==null?void 0x0:_0x22225d['popupRedirectResolver']);}function xf(_0x126894,_0x4eeafb,_0x2bb48c){const _0x56af43=qe(_0x126894);m(/^https?:\/\//['test'](_0x4eeafb),_0x56af43,'invalid-emulator-scheme');const _0x5e2e91=!0x1,_0x2a7b4d=La(_0x4eeafb),{host:_0x22a7d6,port:_0x199013}=Ff(_0x4eeafb),_0x24c0c8=_0x199013===null?'':':'+_0x199013,_0x33e45b={'url':_0x2a7b4d+'//'+_0x22a7d6+_0x24c0c8+'/'},_0x2092e6=Object['freeze']({'host':_0x22a7d6,'port':_0x199013,'protocol':_0x2a7b4d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5e2e91})});if(!_0x56af43['_canInitEmulator']){m(_0x56af43['config']['emulator']&&_0x56af43['emulatorConfig'],_0x56af43,'emulator-config-failed'),m(De(_0x33e45b,_0x56af43['config']['emulator'])&&De(_0x2092e6,_0x56af43['emulatorConfig']),_0x56af43,'emulator-config-failed');return;}_0x56af43['config']['emulator']=_0x33e45b,_0x56af43['emulatorConfig']=_0x2092e6,_0x56af43['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x22a7d6)?jr(_0x2a7b4d+'//'+_0x22a7d6+_0x24c0c8):Uf();}function La(_0x462443){const _0x141b38=_0x462443['indexOf'](':');return _0x141b38<0x0?'':_0x462443['substr'](0x0,_0x141b38+0x1);}function Ff(_0x15f7a7){const _0x53e823=La(_0x15f7a7),_0x1357b0=/(\/\/)?([^?#/]+)/['exec'](_0x15f7a7['substr'](_0x53e823['length']));if(!_0x1357b0)return{'host':'','port':null};const _0x130334=_0x1357b0[0x2]['split']('@')['pop']()||'',_0x25e3c0=/^(\[[^\]]+\])(:|$)/['exec'](_0x130334);if(_0x25e3c0){const _0x155710=_0x25e3c0[0x1];return{'host':_0x155710,'port':Rr(_0x130334['substr'](_0x155710['length']+0x1))};}else{const [_0x4ec46e,_0x38bbd3]=_0x130334['split'](':');return{'host':_0x4ec46e,'port':Rr(_0x38bbd3)};}}function Rr(_0x305550){if(!_0x305550)return null;const _0x471ef4=Number(_0x305550);return isNaN(_0x471ef4)?null:_0x471ef4;}function Uf(){function _0x8b44fc(){const _0x25d21c=document['createElement']('p'),_0x32a8b7=_0x25d21c['style'];_0x25d21c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x32a8b7['position']='fixed',_0x32a8b7['width']='100%',_0x32a8b7['backgroundColor']='#ffffff',_0x32a8b7['border']='.1em\x20solid\x20#000000',_0x32a8b7['color']='#b50000',_0x32a8b7['bottom']='0px',_0x32a8b7['left']='0px',_0x32a8b7['margin']='0px',_0x32a8b7['zIndex']='10000',_0x32a8b7['textAlign']='center',_0x25d21c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x25d21c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x8b44fc):_0x8b44fc());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x373d58,_0x18313d){this['providerId']=_0x373d58,this['signInMethod']=_0x18313d;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x5067ad){return te('not\x20implemented');}['_linkToIdToken'](_0x1cb954,_0x25f8ce){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x531cc8){return te('not\x20implemented');}}async function Wf(_0x22d2f4,_0x4b6e63){return Ae(_0x22d2f4,'POST','/v1/accounts:signUp',_0x4b6e63);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x166674,_0x366d13){return Yt(_0x166674,'POST','/v1/accounts:signInWithPassword',Re(_0x166674,_0x366d13));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x37cf30,_0x4b2536){return Yt(_0x37cf30,'POST','/v1/accounts:signInWithEmailLink',Re(_0x37cf30,_0x4b2536));}async function Hf(_0x32f42c,_0x114c00){return Yt(_0x32f42c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x32f42c,_0x114c00));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xb63e8b,_0xd4f719,_0x34e86d,_0x43d612=null){super('password',_0x34e86d),this['_email']=_0xb63e8b,this['_password']=_0xd4f719,this['_tenantId']=_0x43d612;}static['_fromEmailAndPassword'](_0xa84ae1,_0x38ad72){return new Ft(_0xa84ae1,_0x38ad72,'password');}static['_fromEmailAndCode'](_0x480688,_0x2589d7,_0x1df262=null){return new Ft(_0x480688,_0x2589d7,'emailLink',_0x1df262);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xa788c7){const _0x5be140=typeof _0xa788c7=='string'?JSON['parse'](_0xa788c7):_0xa788c7;if(_0x5be140!=null&&_0x5be140['email']&&(_0x5be140!=null&&_0x5be140['password'])){if(_0x5be140['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5be140['email'],_0x5be140['password']);if(_0x5be140['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5be140['email'],_0x5be140['password'],_0x5be140['tenantId']);}return null;}async['_getIdTokenResponse'](_0x487435){switch(this['signInMethod']){case'password':const _0x1200fe={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x487435,_0x1200fe,'signInWithPassword',Bf);case'emailLink':return Vf(_0x487435,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x487435,'internal-error');}}async['_linkToIdToken'](_0x5eccd6,_0x70c595){switch(this['signInMethod']){case'password':const _0x2bfb1d={'idToken':_0x70c595,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5eccd6,_0x2bfb1d,'signUpPassword',Wf);case'emailLink':return Hf(_0x5eccd6,{'idToken':_0x70c595,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5eccd6,'internal-error');}}['_getReauthenticationResolver'](_0x84293e){return this['_getIdTokenResponse'](_0x84293e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x59eed6,_0x5f36ab){return Yt(_0x59eed6,'POST','/v1/accounts:signInWithIdp',Re(_0x59eed6,_0x5f36ab));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x470c87){const _0x30a804=new We(_0x470c87['providerId'],_0x470c87['signInMethod']);return _0x470c87['idToken']||_0x470c87['accessToken']?(_0x470c87['idToken']&&(_0x30a804['idToken']=_0x470c87['idToken']),_0x470c87['accessToken']&&(_0x30a804['accessToken']=_0x470c87['accessToken']),_0x470c87['nonce']&&!_0x470c87['pendingToken']&&(_0x30a804['nonce']=_0x470c87['nonce']),_0x470c87['pendingToken']&&(_0x30a804['pendingToken']=_0x470c87['pendingToken'])):_0x470c87['oauthToken']&&_0x470c87['oauthTokenSecret']?(_0x30a804['accessToken']=_0x470c87['oauthToken'],_0x30a804['secret']=_0x470c87['oauthTokenSecret']):K('argument-error'),_0x30a804;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x44e974){const _0x34bbf0=typeof _0x44e974=='string'?JSON['parse'](_0x44e974):_0x44e974,{providerId:_0x28e631,signInMethod:_0x3352b1,..._0x966a00}=_0x34bbf0;if(!_0x28e631||!_0x3352b1)return null;const _0x5c5252=new We(_0x28e631,_0x3352b1);return _0x5c5252['idToken']=_0x966a00['idToken']||void 0x0,_0x5c5252['accessToken']=_0x966a00['accessToken']||void 0x0,_0x5c5252['secret']=_0x966a00['secret'],_0x5c5252['nonce']=_0x966a00['nonce'],_0x5c5252['pendingToken']=_0x966a00['pendingToken']||null,_0x5c5252;}['_getIdTokenResponse'](_0x2430c7){const _0x1b001b=this['buildRequest']();return Ze(_0x2430c7,_0x1b001b);}['_linkToIdToken'](_0x986365,_0x43d279){const _0x435af8=this['buildRequest']();return _0x435af8['idToken']=_0x43d279,Ze(_0x986365,_0x435af8);}['_getReauthenticationResolver'](_0x209804){const _0x1ded82=this['buildRequest']();return _0x1ded82['autoCreate']=!0x1,Ze(_0x209804,_0x1ded82);}['buildRequest'](){const _0x336c9d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x336c9d['pendingToken']=this['pendingToken'];else{const _0x24aea9={};this['idToken']&&(_0x24aea9['id_token']=this['idToken']),this['accessToken']&&(_0x24aea9['access_token']=this['accessToken']),this['secret']&&(_0x24aea9['oauth_token_secret']=this['secret']),_0x24aea9['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x24aea9['nonce']=this['nonce']),_0x336c9d['postBody']=at(_0x24aea9);}return _0x336c9d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1c0ec2){switch(_0x1c0ec2){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x40cb6d){const _0x37aa47=yt(vt(_0x40cb6d))['link'],_0x294760=_0x37aa47?yt(vt(_0x37aa47))['deep_link_id']:null,_0x4e8d92=yt(vt(_0x40cb6d))['deep_link_id'];return(_0x4e8d92?yt(vt(_0x4e8d92))['link']:null)||_0x4e8d92||_0x294760||_0x37aa47||_0x40cb6d;}class Ss{constructor(_0x321001){const _0x520c01=yt(vt(_0x321001)),_0x31aaa3=_0x520c01['apiKey']??null,_0x401f45=_0x520c01['oobCode']??null,_0xd34d9a=Gf(_0x520c01['mode']??null);m(_0x31aaa3&&_0x401f45&&_0xd34d9a,'argument-error'),this['apiKey']=_0x31aaa3,this['operation']=_0xd34d9a,this['code']=_0x401f45,this['continueUrl']=_0x520c01['continueUrl']??null,this['languageCode']=_0x520c01['lang']??null,this['tenantId']=_0x520c01['tenantId']??null;}static['parseLink'](_0x43d8b7){const _0x427a8c=qf(_0x43d8b7);try{return new Ss(_0x427a8c);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x1cd9bc,_0x2d89f0){return Ft['_fromEmailAndPassword'](_0x1cd9bc,_0x2d89f0);}static['credentialWithLink'](_0xc377e8,_0x28b544){const _0x2a7618=Ss['parseLink'](_0x28b544);return m(_0x2a7618,'argument-error'),Ft['_fromEmailAndCode'](_0xc377e8,_0x2a7618['code'],_0x2a7618['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5e3fca){this['providerId']=_0x5e3fca,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x588b45){this['defaultLanguageCode']=_0x588b45;}['setCustomParameters'](_0x12357b){return this['customParameters']=_0x12357b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x59d478){return this['scopes']['includes'](_0x59d478)||this['scopes']['push'](_0x59d478),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x4a5d08){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4a5d08});}static['credentialFromResult'](_0x307d60){return he['credentialFromTaggedObject'](_0x307d60);}static['credentialFromError'](_0x283208){return he['credentialFromTaggedObject'](_0x283208['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x52ebc1}){if(!_0x52ebc1||!('oauthAccessToken'in _0x52ebc1)||!_0x52ebc1['oauthAccessToken'])return null;try{return he['credential'](_0x52ebc1['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xd5475f,_0x35a74e){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xd5475f,'accessToken':_0x35a74e});}static['credentialFromResult'](_0xad9cfc){return ue['credentialFromTaggedObject'](_0xad9cfc);}static['credentialFromError'](_0x11ebb4){return ue['credentialFromTaggedObject'](_0x11ebb4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4ce90f}){if(!_0x4ce90f)return null;const {oauthIdToken:_0x28f5da,oauthAccessToken:_0x9ef8a8}=_0x4ce90f;if(!_0x28f5da&&!_0x9ef8a8)return null;try{return ue['credential'](_0x28f5da,_0x9ef8a8);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x52a76b){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x52a76b});}static['credentialFromResult'](_0x1b7e27){return de['credentialFromTaggedObject'](_0x1b7e27);}static['credentialFromError'](_0x180e15){return de['credentialFromTaggedObject'](_0x180e15['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x466d82}){if(!_0x466d82||!('oauthAccessToken'in _0x466d82)||!_0x466d82['oauthAccessToken'])return null;try{return de['credential'](_0x466d82['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2c3ada,_0x5c3f66){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2c3ada,'oauthTokenSecret':_0x5c3f66});}static['credentialFromResult'](_0x2914e6){return fe['credentialFromTaggedObject'](_0x2914e6);}static['credentialFromError'](_0x12917f){return fe['credentialFromTaggedObject'](_0x12917f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x53f1be}){if(!_0x53f1be)return null;const {oauthAccessToken:_0x3da3fd,oauthTokenSecret:_0x5a24a1}=_0x53f1be;if(!_0x3da3fd||!_0x5a24a1)return null;try{return fe['credential'](_0x3da3fd,_0x5a24a1);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x51a726,_0x3f6057){return Yt(_0x51a726,'POST','/v1/accounts:signUp',Re(_0x51a726,_0x3f6057));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x56e43f){this['user']=_0x56e43f['user'],this['providerId']=_0x56e43f['providerId'],this['_tokenResponse']=_0x56e43f['_tokenResponse'],this['operationType']=_0x56e43f['operationType'];}static async['_fromIdTokenResponse'](_0x404b0a,_0xc3dbf8,_0x39ff0f,_0x449e1b=!0x1){const _0x1e085d=await z['_fromIdTokenResponse'](_0x404b0a,_0x39ff0f,_0x449e1b),_0x474fe9=Ar(_0x39ff0f);return new Be({'user':_0x1e085d,'providerId':_0x474fe9,'_tokenResponse':_0x39ff0f,'operationType':_0xc3dbf8});}static async['_forOperation'](_0x3cb1e4,_0x4414db,_0x570d57){await _0x3cb1e4['_updateTokensIfNecessary'](_0x570d57,!0x0);const _0x45f6b9=Ar(_0x570d57);return new Be({'user':_0x3cb1e4,'providerId':_0x45f6b9,'_tokenResponse':_0x570d57,'operationType':_0x4414db});}}function Ar(_0x2bf881){return _0x2bf881['providerId']?_0x2bf881['providerId']:'phoneNumber'in _0x2bf881?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5a9dab,_0x3294e2,_0x19b662,_0x4725aa){super(_0x3294e2['code'],_0x3294e2['message']),this['operationType']=_0x19b662,this['user']=_0x4725aa,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5a9dab['name'],'tenantId':_0x5a9dab['tenantId']??void 0x0,'_serverResponse':_0x3294e2['customData']['_serverResponse'],'operationType':_0x19b662};}static['_fromErrorAndOperation'](_0x1bc34c,_0x5aa891,_0x373b89,_0x2c9a8b){return new Rn(_0x1bc34c,_0x5aa891,_0x373b89,_0x2c9a8b);}}function Fa(_0x4d0384,_0x3e8154,_0x4d76a1,_0x57ea64){return(_0x3e8154==='reauthenticate'?_0x4d76a1['_getReauthenticationResolver'](_0x4d0384):_0x4d76a1['_getIdTokenResponse'](_0x4d0384))['catch'](_0x55b59d=>{throw _0x55b59d['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x4d0384,_0x55b59d,_0x3e8154,_0x57ea64):_0x55b59d;});}async function jf(_0x5ea8d9,_0x392054,_0x5ecd1b=!0x1){const _0x1675df=await xt(_0x5ea8d9,_0x392054['_linkToIdToken'](_0x5ea8d9['auth'],await _0x5ea8d9['getIdToken']()),_0x5ecd1b);return Be['_forOperation'](_0x5ea8d9,'link',_0x1675df);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x605caf,_0x1294f0,_0x4065c0=!0x1){const {auth:_0x1ae26f}=_0x605caf;if(H(_0x1ae26f['app']))return Promise['reject'](se(_0x1ae26f));const _0xae99db='reauthenticate';try{const _0x524e47=await xt(_0x605caf,Fa(_0x1ae26f,_0xae99db,_0x1294f0,_0x605caf),_0x4065c0);m(_0x524e47['idToken'],_0x1ae26f,'internal-error');const _0x38165c=ws(_0x524e47['idToken']);m(_0x38165c,_0x1ae26f,'internal-error');const {sub:_0x57bbe6}=_0x38165c;return m(_0x605caf['uid']===_0x57bbe6,_0x1ae26f,'user-mismatch'),Be['_forOperation'](_0x605caf,_0xae99db,_0x524e47);}catch(_0x141b2b){throw(_0x141b2b==null?void 0x0:_0x141b2b['code'])==='auth/user-not-found'&&K(_0x1ae26f,'user-mismatch'),_0x141b2b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x516304,_0x68b9e5,_0x4630c0=!0x1){if(H(_0x516304['app']))return Promise['reject'](se(_0x516304));const _0x59060c='signIn',_0x11f63b=await Fa(_0x516304,_0x59060c,_0x68b9e5),_0x1be960=await Be['_fromIdTokenResponse'](_0x516304,_0x59060c,_0x11f63b);return _0x4630c0||await _0x516304['_updateCurrentUser'](_0x1be960['user']),_0x1be960;}async function Yf(_0x256fd4,_0x4fd7e5){return Ua(qe(_0x256fd4),_0x4fd7e5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2319df){const _0x306541=qe(_0x2319df);_0x306541['_getPasswordPolicyInternal']()&&await _0x306541['_updatePasswordPolicy']();}async function R_(_0x1e5795,_0x263bf7,_0x293d6a){if(H(_0x1e5795['app']))return Promise['reject'](se(_0x1e5795));const _0x669498=qe(_0x1e5795),_0x51e4c3=await Oi(_0x669498,{'returnSecureToken':!0x0,'email':_0x263bf7,'password':_0x293d6a,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x43ff32=>{throw _0x43ff32['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1e5795),_0x43ff32;}),_0x3ae188=await Be['_fromIdTokenResponse'](_0x669498,'signIn',_0x51e4c3);return await _0x669498['_updateCurrentUser'](_0x3ae188['user']),_0x3ae188;}function A_(_0x1abc1c,_0x9e4290,_0x572cb6){return H(_0x1abc1c['app'])?Promise['reject'](se(_0x1abc1c)):Yf(k(_0x1abc1c),ft['credential'](_0x9e4290,_0x572cb6))['catch'](async _0x383f87=>{throw _0x383f87['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1abc1c),_0x383f87;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x578698,_0x5aeef1){return k(_0x578698)['setPersistence'](_0x5aeef1);}function Qf(_0x5465a0,_0x1f9c1e,_0x2bf3c0,_0xf60000){return k(_0x5465a0)['onIdTokenChanged'](_0x1f9c1e,_0x2bf3c0,_0xf60000);}function Jf(_0x5b254b,_0x1dfd24,_0x27ed76){return k(_0x5b254b)['beforeAuthStateChanged'](_0x1dfd24,_0x27ed76);}function N_(_0x581150,_0x1aa272,_0x2d9b46,_0x34d67f){return k(_0x581150)['onAuthStateChanged'](_0x1aa272,_0x2d9b46,_0x34d67f);}function P_(_0xf24713){return k(_0xf24713)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x4bed8e,_0xc297a1){this['storageRetriever']=_0x4bed8e,this['type']=_0xc297a1;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4f841f,_0x168476){return this['storage']['setItem'](_0x4f841f,JSON['stringify'](_0x168476)),Promise['resolve']();}['_get'](_0x5ae4a3){const _0x1640ad=this['storage']['getItem'](_0x5ae4a3);return Promise['resolve'](_0x1640ad?JSON['parse'](_0x1640ad):null);}['_remove'](_0x28ac9c){return this['storage']['removeItem'](_0x28ac9c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x53146a,_0x5d58ac)=>this['onStorageEvent'](_0x53146a,_0x5d58ac),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x25e898){for(const _0x36ea40 of Object['keys'](this['listeners'])){const _0x4265a5=this['storage']['getItem'](_0x36ea40),_0xda616=this['localCache'][_0x36ea40];_0x4265a5!==_0xda616&&_0x25e898(_0x36ea40,_0xda616,_0x4265a5);}}['onStorageEvent'](_0x200446,_0x228f0d=!0x1){if(!_0x200446['key']){this['forAllChangedKeys']((_0x459799,_0x452d8f,_0x1a4a4e)=>{this['notifyListeners'](_0x459799,_0x1a4a4e);});return;}const _0x19bcfe=_0x200446['key'];_0x228f0d?this['detachListener']():this['stopPolling']();const _0x52010e=()=>{const _0x1aa356=this['storage']['getItem'](_0x19bcfe);!_0x228f0d&&this['localCache'][_0x19bcfe]===_0x1aa356||this['notifyListeners'](_0x19bcfe,_0x1aa356);},_0x55b5f4=this['storage']['getItem'](_0x19bcfe);If()&&_0x55b5f4!==_0x200446['newValue']&&_0x200446['newValue']!==_0x200446['oldValue']?setTimeout(_0x52010e,Zf):_0x52010e();}['notifyListeners'](_0x254b3d,_0x616b41){this['localCache'][_0x254b3d]=_0x616b41;const _0x2f2f74=this['listeners'][_0x254b3d];if(_0x2f2f74){for(const _0x466b6b of Array['from'](_0x2f2f74))_0x466b6b(_0x616b41&&JSON['parse'](_0x616b41));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x11d659,_0x544516,_0x8bf8e9)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x11d659,'oldValue':_0x544516,'newValue':_0x8bf8e9}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x388382,_0x283cba){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x388382]||(this['listeners'][_0x388382]=new Set(),this['localCache'][_0x388382]=this['storage']['getItem'](_0x388382)),this['listeners'][_0x388382]['add'](_0x283cba);}['_removeListener'](_0x310837,_0x2dc607){this['listeners'][_0x310837]&&(this['listeners'][_0x310837]['delete'](_0x2dc607),this['listeners'][_0x310837]['size']===0x0&&delete this['listeners'][_0x310837]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x572313,_0xbde488){await super['_set'](_0x572313,_0xbde488),this['localCache'][_0x572313]=JSON['stringify'](_0xbde488);}async['_get'](_0x8882f5){const _0x334945=await super['_get'](_0x8882f5);return this['localCache'][_0x8882f5]=JSON['stringify'](_0x334945),_0x334945;}async['_remove'](_0x51296e){await super['_remove'](_0x51296e),delete this['localCache'][_0x51296e];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3eaa48,_0x309754){}['_removeListener'](_0x40c0f2,_0x2aee91){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4e1dc3){return Promise['all'](_0x4e1dc3['map'](async _0x11afea=>{try{return{'fulfilled':!0x0,'value':await _0x11afea};}catch(_0x1fb06a){return{'fulfilled':!0x1,'reason':_0x1fb06a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x5562a7){this['eventTarget']=_0x5562a7,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3ae7ec){const _0x1dba45=this['receivers']['find'](_0x230910=>_0x230910['isListeningto'](_0x3ae7ec));if(_0x1dba45)return _0x1dba45;const _0x2768b3=new jn(_0x3ae7ec);return this['receivers']['push'](_0x2768b3),_0x2768b3;}['isListeningto'](_0x6dfe2f){return this['eventTarget']===_0x6dfe2f;}async['handleEvent'](_0x375573){const _0x35ca81=_0x375573,{eventId:_0x3a8a85,eventType:_0x2b0f3b,data:_0x19d3be}=_0x35ca81['data'],_0x1dbdd4=this['handlersMap'][_0x2b0f3b];if(!(_0x1dbdd4!=null&&_0x1dbdd4['size']))return;_0x35ca81['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3a8a85,'eventType':_0x2b0f3b});const _0x2d150b=Array['from'](_0x1dbdd4)['map'](async _0x2a22d5=>_0x2a22d5(_0x35ca81['origin'],_0x19d3be)),_0x22bbdf=await tp(_0x2d150b);_0x35ca81['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3a8a85,'eventType':_0x2b0f3b,'response':_0x22bbdf});}['_subscribe'](_0x4f3895,_0x326c2c){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4f3895]||(this['handlersMap'][_0x4f3895]=new Set()),this['handlersMap'][_0x4f3895]['add'](_0x326c2c);}['_unsubscribe'](_0x3c72c9,_0x25101c){this['handlersMap'][_0x3c72c9]&&_0x25101c&&this['handlersMap'][_0x3c72c9]['delete'](_0x25101c),(!_0x25101c||this['handlersMap'][_0x3c72c9]['size']===0x0)&&delete this['handlersMap'][_0x3c72c9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x35afe4='',_0x4b0ad6=0xa){let _0x13939c='';for(let _0x4b103d=0x0;_0x4b103d<_0x4b0ad6;_0x4b103d++)_0x13939c+=Math['floor'](Math['random']()*0xa);return _0x35afe4+_0x13939c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x5c490e){this['target']=_0x5c490e,this['handlers']=new Set();}['removeMessageHandler'](_0x1f7051){_0x1f7051['messageChannel']&&(_0x1f7051['messageChannel']['port1']['removeEventListener']('message',_0x1f7051['onMessage']),_0x1f7051['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1f7051);}async['_send'](_0x572e4c,_0x5f5593,_0x4bbf71=0x32){const _0x25f39c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x25f39c)throw new Error('connection_unavailable');let _0x330f71,_0x5cd82c;return new Promise((_0x317d86,_0x9a8727)=>{const _0x486ee5=bs('',0x14);_0x25f39c['port1']['start']();const _0x6efdf3=setTimeout(()=>{_0x9a8727(new Error('unsupported_event'));},_0x4bbf71);_0x5cd82c={'messageChannel':_0x25f39c,'onMessage'(_0x491bc2){const _0x456607=_0x491bc2;if(_0x456607['data']['eventId']===_0x486ee5)switch(_0x456607['data']['status']){case'ack':clearTimeout(_0x6efdf3),_0x330f71=setTimeout(()=>{_0x9a8727(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x330f71),_0x317d86(_0x456607['data']['response']);break;default:clearTimeout(_0x6efdf3),clearTimeout(_0x330f71),_0x9a8727(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x5cd82c),_0x25f39c['port1']['addEventListener']('message',_0x5cd82c['onMessage']),this['target']['postMessage']({'eventType':_0x572e4c,'eventId':_0x486ee5,'data':_0x5f5593},[_0x25f39c['port2']]);})['finally'](()=>{_0x5cd82c&&this['removeMessageHandler'](_0x5cd82c);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x1cf324){X()['location']['href']=_0x1cf324;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x19081b;return((_0x19081b=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x19081b['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x2b231c){this['request']=_0x2b231c;}['toPromise'](){return new Promise((_0x398a23,_0x1c8ff4)=>{this['request']['addEventListener']('success',()=>{_0x398a23(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1c8ff4(this['request']['error']);});});}}function Kn(_0x20f445,_0x115b21){return _0x20f445['transaction']([kn],_0x115b21?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x41cee8=indexedDB['deleteDatabase'](qa);return new Jt(_0x41cee8)['toPromise']();}function ja(){const _0x5c03e2=indexedDB['open'](qa,ap);return new Promise((_0xf612c7,_0x229cb8)=>{_0x5c03e2['addEventListener']('error',()=>{_0x229cb8(_0x5c03e2['error']);}),_0x5c03e2['addEventListener']('upgradeneeded',()=>{const _0x58adda=_0x5c03e2['result'];try{_0x58adda['createObjectStore'](kn,{'keyPath':za});}catch(_0x430ac4){_0x229cb8(_0x430ac4);}}),_0x5c03e2['addEventListener']('success',async()=>{const _0x2d84cc=_0x5c03e2['result'];_0x2d84cc['objectStoreNames']['contains'](kn)?_0xf612c7(_0x2d84cc):(_0x2d84cc['close'](),await cp(),_0xf612c7(await ja()));});});}async function kr(_0x41bf6d,_0x3093b2,_0x319e65){const _0x496541=Kn(_0x41bf6d,!0x0)['put']({[za]:_0x3093b2,'value':_0x319e65});return new Jt(_0x496541)['toPromise']();}async function lp(_0x284c3a,_0x31d888){const _0x360d99=Kn(_0x284c3a,!0x1)['get'](_0x31d888),_0x50fb87=await new Jt(_0x360d99)['toPromise']();return _0x50fb87===void 0x0?null:_0x50fb87['value'];}function Nr(_0x4995a2,_0x3a539f){const _0x52f0b7=Kn(_0x4995a2,!0x0)['delete'](_0x3a539f);return new Jt(_0x52f0b7)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x22ff31){let _0x26a679=0x0;for(;;)try{const _0x2b31de=await this['_openDb']();return await _0x22ff31(_0x2b31de);}catch(_0x4ad9c5){if(_0x26a679++>up)throw _0x4ad9c5;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x8c599c,_0x1ff229)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1ff229['key'])})),this['receiver']['_subscribe']('ping',async(_0x454754,_0x5988c9)=>['keyChanged']);}async['initializeSender'](){var _0x3bafee,_0x609ea9;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0xdf793b=await this['sender']['_send']('ping',{},0x320);_0xdf793b&&(_0x3bafee=_0xdf793b[0x0])!=null&&_0x3bafee['fulfilled']&&(_0x609ea9=_0xdf793b[0x0])!=null&&_0x609ea9['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x276f6c){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x276f6c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3b40bd=>{await kr(_0x3b40bd,An,'1'),await Nr(_0x3b40bd,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3b94f2){this['pendingWrites']++;try{await _0x3b94f2();}finally{this['pendingWrites']--;}}async['_set'](_0x5f0e2b,_0x374b30){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4782db=>kr(_0x4782db,_0x5f0e2b,_0x374b30)),this['localCache'][_0x5f0e2b]=_0x374b30,this['notifyServiceWorker'](_0x5f0e2b)));}async['_get'](_0x2af79f){const _0x56507f=await this['_withRetries'](_0x462ed1=>lp(_0x462ed1,_0x2af79f));return this['localCache'][_0x2af79f]=_0x56507f,_0x56507f;}async['_remove'](_0x37a2c5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x226d77=>Nr(_0x226d77,_0x37a2c5)),delete this['localCache'][_0x37a2c5],this['notifyServiceWorker'](_0x37a2c5)));}async['_poll'](){const _0x38986e=await this['_withRetries'](_0x2025e9=>{const _0x24cdf1=Kn(_0x2025e9,!0x1)['getAll']();return new Jt(_0x24cdf1)['toPromise']();});if(!_0x38986e)return[];if(this['pendingWrites']!==0x0)return[];const _0xeff330=[],_0x75512e=new Set();if(_0x38986e['length']!==0x0){for(const {fbase_key:_0x220a49,value:_0x5df801}of _0x38986e)_0x75512e['add'](_0x220a49),JSON['stringify'](this['localCache'][_0x220a49])!==JSON['stringify'](_0x5df801)&&(this['notifyListeners'](_0x220a49,_0x5df801),_0xeff330['push'](_0x220a49));}for(const _0x17c492 of Object['keys'](this['localCache']))this['localCache'][_0x17c492]&&!_0x75512e['has'](_0x17c492)&&(this['notifyListeners'](_0x17c492,null),_0xeff330['push'](_0x17c492));return _0xeff330;}['notifyListeners'](_0x11b1e8,_0x14433d){this['localCache'][_0x11b1e8]=_0x14433d;const _0x18a3dc=this['listeners'][_0x11b1e8];if(_0x18a3dc){for(const _0x50f0e2 of Array['from'](_0x18a3dc))_0x50f0e2(_0x14433d);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xac85bc,_0xf427ff){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xac85bc]||(this['listeners'][_0xac85bc]=new Set(),this['_get'](_0xac85bc)),this['listeners'][_0xac85bc]['add'](_0xf427ff);}['_removeListener'](_0x14285e,_0x2f1793){this['listeners'][_0x14285e]&&(this['listeners'][_0x14285e]['delete'](_0x2f1793),this['listeners'][_0x14285e]['size']===0x0&&delete this['listeners'][_0x14285e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x171c92,_0x23aba5){return _0x23aba5?ne(_0x23aba5):(m(_0x171c92['_popupRedirectResolver'],_0x171c92,'argument-error'),_0x171c92['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2eb0ac){super('custom','custom'),this['params']=_0x2eb0ac;}['_getIdTokenResponse'](_0x13d9b6){return Ze(_0x13d9b6,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5774a4,_0x537d02){return Ze(_0x5774a4,this['_buildIdpRequest'](_0x537d02));}['_getReauthenticationResolver'](_0x47b7c4){return Ze(_0x47b7c4,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x12eadd){const _0x389946={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x12eadd&&(_0x389946['idToken']=_0x12eadd),_0x389946;}}function pp(_0x1a74aa){return Ua(_0x1a74aa['auth'],new Rs(_0x1a74aa),_0x1a74aa['bypassAuthState']);}function _p(_0x1dbfd1){const {auth:_0x443940,user:_0x2671bd}=_0x1dbfd1;return m(_0x2671bd,_0x443940,'internal-error'),Kf(_0x2671bd,new Rs(_0x1dbfd1),_0x1dbfd1['bypassAuthState']);}async function gp(_0x3855b0){const {auth:_0x2bec4b,user:_0x223e1a}=_0x3855b0;return m(_0x223e1a,_0x2bec4b,'internal-error'),jf(_0x223e1a,new Rs(_0x3855b0),_0x3855b0['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5072d4,_0x3c8af8,_0x32d7c4,_0x26c0d0,_0x425ca5=!0x1){this['auth']=_0x5072d4,this['resolver']=_0x32d7c4,this['user']=_0x26c0d0,this['bypassAuthState']=_0x425ca5,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3c8af8)?_0x3c8af8:[_0x3c8af8];}['execute'](){return new Promise(async(_0x107476,_0x53c0c7)=>{this['pendingPromise']={'resolve':_0x107476,'reject':_0x53c0c7};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x386f50){this['reject'](_0x386f50);}});}async['onAuthEvent'](_0x303def){const {urlResponse:_0x3b8ae2,sessionId:_0xed7bd,postBody:_0x4e5c49,tenantId:_0x57141b,error:_0xccc3bc,type:_0x150e80}=_0x303def;if(_0xccc3bc){this['reject'](_0xccc3bc);return;}const _0x6f0d9b={'auth':this['auth'],'requestUri':_0x3b8ae2,'sessionId':_0xed7bd,'tenantId':_0x57141b||void 0x0,'postBody':_0x4e5c49||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x150e80)(_0x6f0d9b));}catch(_0xafd511){this['reject'](_0xafd511);}}['onError'](_0x31892a){this['reject'](_0x31892a);}['getIdpTask'](_0x3c37f6){switch(_0x3c37f6){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0xca0ac3){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xca0ac3),this['unregisterAndCleanUp']();}['reject'](_0x4d4eb9){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4d4eb9),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1f7683,_0x433095,_0x3eb4a1,_0xb4647b,_0x2e8445){super(_0x1f7683,_0x433095,_0xb4647b,_0x2e8445),this['provider']=_0x3eb4a1,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x21bea6=await this['execute']();return m(_0x21bea6,this['auth'],'internal-error'),_0x21bea6;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4ab67e=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4ab67e),this['authWindow']['associatedEvent']=_0x4ab67e,this['resolver']['_originValidation'](this['auth'])['catch'](_0xf535ff=>{this['reject'](_0xf535ff);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x11efa9=>{_0x11efa9||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x435608;return((_0x435608=this['authWindow'])==null?void 0x0:_0x435608['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x21fb6e=()=>{var _0x47b0ad,_0x4ed87d;if((_0x4ed87d=(_0x47b0ad=this['authWindow'])==null?void 0x0:_0x47b0ad['window'])!=null&&_0x4ed87d['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x21fb6e,mp['get']());};_0x21fb6e();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x2b1536,_0xb4d8c2,_0x31b534=!0x1){super(_0x2b1536,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0xb4d8c2,void 0x0,_0x31b534),this['eventId']=null;}async['execute'](){let _0x2b372e=rn['get'](this['auth']['_key']());if(!_0x2b372e){try{const _0x3bf456=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x2b372e=()=>Promise['resolve'](_0x3bf456);}catch(_0x3b5752){_0x2b372e=()=>Promise['reject'](_0x3b5752);}rn['set'](this['auth']['_key'](),_0x2b372e);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2b372e();}async['onAuthEvent'](_0x3fad0f){if(_0x3fad0f['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3fad0f);if(_0x3fad0f['type']==='unknown'){this['resolve'](null);return;}if(_0x3fad0f['eventId']){const _0x49c1c2=await this['auth']['_redirectUserForId'](_0x3fad0f['eventId']);if(_0x49c1c2)return this['user']=_0x49c1c2,super['onAuthEvent'](_0x3fad0f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xaa1747,_0x2510f0){const _0x180bbf=Cp(_0x2510f0),_0x11e247=wp(_0xaa1747);if(!await _0x11e247['_isAvailable']())return!0x1;const _0x26097a=await _0x11e247['_get'](_0x180bbf)==='true';return await _0x11e247['_remove'](_0x180bbf),_0x26097a;}function Ip(_0x33029f,_0x202e21){rn['set'](_0x33029f['_key'](),_0x202e21);}function wp(_0x29a0b9){return ne(_0x29a0b9['_redirectPersistence']);}function Cp(_0x1d1e92){return sn(yp,_0x1d1e92['config']['apiKey'],_0x1d1e92['name']);}async function Tp(_0x448080,_0xcb689b,_0x54ebe1=!0x1){if(H(_0x448080['app']))return Promise['reject'](se(_0x448080));const _0x27e905=qe(_0x448080),_0x4c7247=fp(_0x27e905,_0xcb689b),_0xcc99e1=await new vp(_0x27e905,_0x4c7247,_0x54ebe1)['execute']();return _0xcc99e1&&!_0x54ebe1&&(delete _0xcc99e1['user']['_redirectEventId'],await _0x27e905['_persistUserIfCurrent'](_0xcc99e1['user']),await _0x27e905['_setRedirectUser'](null,_0xcb689b)),_0xcc99e1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x14dba5){this['auth']=_0x14dba5,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x47495d){this['consumers']['add'](_0x47495d),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x47495d)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x47495d),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x21a700){this['consumers']['delete'](_0x21a700);}['onEvent'](_0x49e870){if(this['hasEventBeenHandled'](_0x49e870))return!0x1;let _0x5aa80c=!0x1;return this['consumers']['forEach'](_0xf17210=>{this['isEventForConsumer'](_0x49e870,_0xf17210)&&(_0x5aa80c=!0x0,this['sendToConsumer'](_0x49e870,_0xf17210),this['saveEventToCache'](_0x49e870));}),this['hasHandledPotentialRedirect']||!Rp(_0x49e870)||(this['hasHandledPotentialRedirect']=!0x0,_0x5aa80c||(this['queuedRedirectEvent']=_0x49e870,_0x5aa80c=!0x0)),_0x5aa80c;}['sendToConsumer'](_0x965db8,_0x3792e5){var _0x4be36c;if(_0x965db8['error']&&!Qa(_0x965db8)){const _0x5a8490=((_0x4be36c=_0x965db8['error']['code'])==null?void 0x0:_0x4be36c['split']('auth/')[0x1])||'internal-error';_0x3792e5['onError'](J(this['auth'],_0x5a8490));}else _0x3792e5['onAuthEvent'](_0x965db8);}['isEventForConsumer'](_0x229a44,_0x37c8e3){const _0x161f3f=_0x37c8e3['eventId']===null||!!_0x229a44['eventId']&&_0x229a44['eventId']===_0x37c8e3['eventId'];return _0x37c8e3['filter']['includes'](_0x229a44['type'])&&_0x161f3f;}['hasEventBeenHandled'](_0x1a76a5){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x1a76a5));}['saveEventToCache'](_0x4121bd){this['cachedEventUids']['add'](Pr(_0x4121bd)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x21fb2e){return[_0x21fb2e['type'],_0x21fb2e['eventId'],_0x21fb2e['sessionId'],_0x21fb2e['tenantId']]['filter'](_0x4b434a=>_0x4b434a)['join']('-');}function Qa({type:_0x4b6c6c,error:_0x10097e}){return _0x4b6c6c==='unknown'&&(_0x10097e==null?void 0x0:_0x10097e['code'])==='auth/no-auth-event';}function Rp(_0x3a7c2e){switch(_0x3a7c2e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3a7c2e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x4aad8e,_0x1c3585={}){return Ae(_0x4aad8e,'GET','/v1/projects',_0x1c3585);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x58ea47){if(_0x58ea47['config']['emulator'])return;const {authorizedDomains:_0x17cc59}=await Ap(_0x58ea47);for(const _0x465222 of _0x17cc59)try{if(Op(_0x465222))return;}catch{}K(_0x58ea47,'unauthorized-domain');}function Op(_0x9c476b){const _0x524142=Ni(),{protocol:_0x15b1f1,hostname:_0x380355}=new URL(_0x524142);if(_0x9c476b['startsWith']('chrome-extension://')){const _0x46d419=new URL(_0x9c476b);return _0x46d419['hostname']===''&&_0x380355===''?_0x15b1f1==='chrome-extension:'&&_0x9c476b['replace']('chrome-extension://','')===_0x524142['replace']('chrome-extension://',''):_0x15b1f1==='chrome-extension:'&&_0x46d419['hostname']===_0x380355;}if(!Np['test'](_0x15b1f1))return!0x1;if(kp['test'](_0x9c476b))return _0x380355===_0x9c476b;const _0x28e5d5=_0x9c476b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x28e5d5+'|'+_0x28e5d5+')$','i')['test'](_0x380355);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x3c6b92=X()['___jsl'];if(_0x3c6b92!=null&&_0x3c6b92['H']){for(const _0x1162ce of Object['keys'](_0x3c6b92['H']))if(_0x3c6b92['H'][_0x1162ce]['r']=_0x3c6b92['H'][_0x1162ce]['r']||[],_0x3c6b92['H'][_0x1162ce]['L']=_0x3c6b92['H'][_0x1162ce]['L']||[],_0x3c6b92['H'][_0x1162ce]['r']=[..._0x3c6b92['H'][_0x1162ce]['L']],_0x3c6b92['CP']){for(let _0x26daba=0x0;_0x26daba<_0x3c6b92['CP']['length'];_0x26daba++)_0x3c6b92['CP'][_0x26daba]=null;}}}function Mp(_0x2f1ba1){return new Promise((_0xd01a4d,_0x5ddd74)=>{var _0x3d92c6,_0x5fa8d4,_0x487ec3;function _0x521c67(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xd01a4d(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x5ddd74(J(_0x2f1ba1,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5fa8d4=(_0x3d92c6=X()['gapi'])==null?void 0x0:_0x3d92c6['iframes'])!=null&&_0x5fa8d4['Iframe'])_0xd01a4d(gapi['iframes']['getContext']());else{if((_0x487ec3=X()['gapi'])!=null&&_0x487ec3['load'])_0x521c67();else{const _0x6bc204=Nf('iframefcb');return X()[_0x6bc204]=()=>{gapi['load']?_0x521c67():_0x5ddd74(J(_0x2f1ba1,'network-request-failed'));},Da(kf()+'?onload='+_0x6bc204)['catch'](_0x380497=>_0x5ddd74(_0x380497));}}})['catch'](_0x466fc1=>{throw on=null,_0x466fc1;});}let on=null;function Lp(_0x557dc6){return on=on||Mp(_0x557dc6),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x170eaa){const _0x492f16=_0x170eaa['config'];m(_0x492f16['authDomain'],_0x170eaa,'auth-domain-config-required');const _0x1bdc93=_0x492f16['emulator']?Is(_0x492f16,Up):'https://'+_0x170eaa['config']['authDomain']+'/'+Fp,_0x3a81d0={'apiKey':_0x492f16['apiKey'],'appName':_0x170eaa['name'],'v':ct},_0x5916d1=Bp['get'](_0x170eaa['config']['apiHost']);_0x5916d1&&(_0x3a81d0['eid']=_0x5916d1);const _0x2fae6d=_0x170eaa['_getFrameworks']();return _0x2fae6d['length']&&(_0x3a81d0['fw']=_0x2fae6d['join'](',')),_0x1bdc93+'?'+at(_0x3a81d0)['slice'](0x1);}async function Hp(_0x309c74){const _0xad58ec=await Lp(_0x309c74),_0xe55abb=X()['gapi'];return m(_0xe55abb,_0x309c74,'internal-error'),_0xad58ec['open']({'where':document['body'],'url':Vp(_0x309c74),'messageHandlersFilter':_0xe55abb['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x3801e3=>new Promise(async(_0x529b82,_0x66c12c)=>{await _0x3801e3['restyle']({'setHideOnLeave':!0x1});const _0x19e0ae=J(_0x309c74,'network-request-failed'),_0x4d9ab6=X()['setTimeout'](()=>{_0x66c12c(_0x19e0ae);},xp['get']());function _0x58c4de(){X()['clearTimeout'](_0x4d9ab6),_0x529b82(_0x3801e3);}_0x3801e3['ping'](_0x58c4de)['then'](_0x58c4de,()=>{_0x66c12c(_0x19e0ae);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x595d3e){this['window']=_0x595d3e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x50a153,_0x4bbf14,_0x25bf27,_0x191638=Gp,_0x4ee98c=qp){const _0x3d833a=Math['max']((window['screen']['availHeight']-_0x4ee98c)/0x2,0x0)['toString'](),_0xc1d3b=Math['max']((window['screen']['availWidth']-_0x191638)/0x2,0x0)['toString']();let _0x4dd5d0='';const _0x5d6a21={...$p,'width':_0x191638['toString'](),'height':_0x4ee98c['toString'](),'top':_0x3d833a,'left':_0xc1d3b},_0x21c246=W()['toLowerCase']();_0x25bf27&&(_0x4dd5d0=ba(_0x21c246)?zp:_0x25bf27),Ta(_0x21c246)&&(_0x4bbf14=_0x4bbf14||jp,_0x5d6a21['scrollbars']='yes');const _0x3cae4b=Object['entries'](_0x5d6a21)['reduce']((_0x4a8490,[_0x4e30f5,_0xb192a6])=>''+_0x4a8490+_0x4e30f5+'='+_0xb192a6+',','');if(Ef(_0x21c246)&&_0x4dd5d0!=='_self')return Yp(_0x4bbf14||'',_0x4dd5d0),new Dr(null);const _0x3f0131=window['open'](_0x4bbf14||'',_0x4dd5d0,_0x3cae4b);m(_0x3f0131,_0x50a153,'popup-blocked');try{_0x3f0131['focus']();}catch{}return new Dr(_0x3f0131);}function Yp(_0x525ec6,_0x2fce8f){const _0x5f518f=document['createElement']('a');_0x5f518f['href']=_0x525ec6,_0x5f518f['target']=_0x2fce8f;const _0x5e339c=document['createEvent']('MouseEvent');_0x5e339c['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5f518f['dispatchEvent'](_0x5e339c);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x4ce191,_0x5aec9e,_0x14d2df,_0x9969a1,_0xa3905c,_0x5cedb6){m(_0x4ce191['config']['authDomain'],_0x4ce191,'auth-domain-config-required'),m(_0x4ce191['config']['apiKey'],_0x4ce191,'invalid-api-key');const _0x55f7a0={'apiKey':_0x4ce191['config']['apiKey'],'appName':_0x4ce191['name'],'authType':_0x14d2df,'redirectUrl':_0x9969a1,'v':ct,'eventId':_0xa3905c};if(_0x5aec9e instanceof xa){_0x5aec9e['setDefaultLanguage'](_0x4ce191['languageCode']),_0x55f7a0['providerId']=_0x5aec9e['providerId']||'',hi(_0x5aec9e['getCustomParameters']())||(_0x55f7a0['customParameters']=JSON['stringify'](_0x5aec9e['getCustomParameters']()));for(const [_0x5ebb10,_0xcb4948]of Object['entries']({}))_0x55f7a0[_0x5ebb10]=_0xcb4948;}if(_0x5aec9e instanceof Qt){const _0x43c2fe=_0x5aec9e['getScopes']()['filter'](_0x39687a=>_0x39687a!=='');_0x43c2fe['length']>0x0&&(_0x55f7a0['scopes']=_0x43c2fe['join'](','));}_0x4ce191['tenantId']&&(_0x55f7a0['tid']=_0x4ce191['tenantId']);const _0x497610=_0x55f7a0;for(const _0x47b93f of Object['keys'](_0x497610))_0x497610[_0x47b93f]===void 0x0&&delete _0x497610[_0x47b93f];const _0x4622af=await _0x4ce191['_getAppCheckToken'](),_0x4a95e7=_0x4622af?'#'+Xp+'='+encodeURIComponent(_0x4622af):'';return Zp(_0x4ce191)+'?'+at(_0x497610)['slice'](0x1)+_0x4a95e7;}function Zp({config:_0x36b046}){return _0x36b046['emulator']?Is(_0x36b046,Jp):'https://'+_0x36b046['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x509fe9,_0x5de6dd,_0x4df1db,_0x2d5ea7){var _0x5636bd;ae((_0x5636bd=this['eventManagers'][_0x509fe9['_key']()])==null?void 0x0:_0x5636bd['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x54d3d2=await Mr(_0x509fe9,_0x5de6dd,_0x4df1db,Ni(),_0x2d5ea7);return Kp(_0x509fe9,_0x54d3d2,bs());}async['_openRedirect'](_0x3c2ed0,_0x1696fa,_0x1b0999,_0x5c88ea){await this['_originValidation'](_0x3c2ed0);const _0x65f595=await Mr(_0x3c2ed0,_0x1696fa,_0x1b0999,Ni(),_0x5c88ea);return ip(_0x65f595),new Promise(()=>{});}['_initialize'](_0x4b86e6){const _0x5e1424=_0x4b86e6['_key']();if(this['eventManagers'][_0x5e1424]){const {manager:_0x4d2f34,promise:_0x25488e}=this['eventManagers'][_0x5e1424];return _0x4d2f34?Promise['resolve'](_0x4d2f34):(ae(_0x25488e,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x25488e);}const _0x12f0ce=this['initAndGetManager'](_0x4b86e6);return this['eventManagers'][_0x5e1424]={'promise':_0x12f0ce},_0x12f0ce['catch'](()=>{delete this['eventManagers'][_0x5e1424];}),_0x12f0ce;}async['initAndGetManager'](_0x1a0d1e){const _0x1f3582=await Hp(_0x1a0d1e),_0x5264b8=new bp(_0x1a0d1e);return _0x1f3582['register']('authEvent',_0x3fec3b=>(m(_0x3fec3b==null?void 0x0:_0x3fec3b['authEvent'],_0x1a0d1e,'invalid-auth-event'),{'status':_0x5264b8['onEvent'](_0x3fec3b['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1a0d1e['_key']()]={'manager':_0x5264b8},this['iframes'][_0x1a0d1e['_key']()]=_0x1f3582,_0x5264b8;}['_isIframeWebStorageSupported'](_0x320a0b,_0x73613b){this['iframes'][_0x320a0b['_key']()]['send'](li,{'type':li},_0x41b026=>{var _0x16a943;const _0x46c6f4=(_0x16a943=_0x41b026==null?void 0x0:_0x41b026[0x0])==null?void 0x0:_0x16a943[li];_0x46c6f4!==void 0x0&&_0x73613b(!!_0x46c6f4),K(_0x320a0b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x561f02){const _0xffa996=_0x561f02['_key']();return this['originValidationPromises'][_0xffa996]||(this['originValidationPromises'][_0xffa996]=Pp(_0x561f02)),this['originValidationPromises'][_0xffa996];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x2a1084){this['auth']=_0x2a1084,this['internalListeners']=new Map();}['getUid'](){var _0x65ded4;return this['assertAuthConfigured'](),((_0x65ded4=this['auth']['currentUser'])==null?void 0x0:_0x65ded4['uid'])||null;}async['getToken'](_0x50c6af){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x50c6af)}:null;}['addAuthTokenListener'](_0xb6950b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xb6950b))return;const _0x5d0bf6=this['auth']['onIdTokenChanged'](_0x2308ae=>{_0xb6950b((_0x2308ae==null?void 0x0:_0x2308ae['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xb6950b,_0x5d0bf6),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x52efd9){this['assertAuthConfigured']();const _0x3c0ffb=this['internalListeners']['get'](_0x52efd9);_0x3c0ffb&&(this['internalListeners']['delete'](_0x52efd9),_0x3c0ffb(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x11af5f){switch(_0x11af5f){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x878d16){et(new Me('auth',(_0x234245,{options:_0x51d574})=>{const _0x9f6789=_0x234245['getProvider']('app')['getImmediate'](),_0xc68bb3=_0x234245['getProvider']('heartbeat'),_0x28ce05=_0x234245['getProvider']('app-check-internal'),{apiKey:_0x487598,authDomain:_0x1f27d8}=_0x9f6789['options'];m(_0x487598&&!_0x487598['includes'](':'),'invalid-api-key',{'appName':_0x9f6789['name']});const _0x530266={'apiKey':_0x487598,'authDomain':_0x1f27d8,'clientPlatform':_0x878d16,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x878d16)},_0x4e1f28=new bf(_0x9f6789,_0xc68bb3,_0x28ce05,_0x530266);return Lf(_0x4e1f28,_0x51d574),_0x4e1f28;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x321499,_0x45779f,_0x490179)=>{_0x321499['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x292470=>{const _0xafddc8=qe(_0x292470['getProvider']('auth')['getImmediate']());return(_0x4f26f2=>new n_(_0x4f26f2))(_0xafddc8);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x878d16)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x57cdba=>async _0x137b9c=>{const _0x274800=_0x137b9c&&await _0x137b9c['getIdTokenResult'](),_0x49db52=_0x274800&&(new Date()['getTime']()-Date['parse'](_0x274800['issuedAtTime']))/0x3e8;if(_0x49db52&&_0x49db52>o_)return;const _0x3b0a13=_0x274800==null?void 0x0:_0x274800['token'];Fr!==_0x3b0a13&&(Fr=_0x3b0a13,await fetch(_0x57cdba,{'method':_0x3b0a13?'POST':'DELETE','headers':_0x3b0a13?{'Authorization':'Bearer\x20'+_0x3b0a13}:{}}));};function O_(_0x41a514=Qr()){const _0x43b33f=Ui(_0x41a514,'auth');if(_0x43b33f['isInitialized']())return _0x43b33f['getImmediate']();const _0x4495ea=Mf(_0x41a514,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4e0641=Gr('authTokenSyncURL');if(_0x4e0641&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x31de8d=new URL(_0x4e0641,location['origin']);if(location['origin']===_0x31de8d['origin']){const _0x10adac=a_(_0x31de8d['toString']());Jf(_0x4495ea,_0x10adac,()=>_0x10adac(_0x4495ea['currentUser'])),Qf(_0x4495ea,_0x3c39d0=>_0x10adac(_0x3c39d0));}}const _0x3da2a8=Hr('auth');return _0x3da2a8&&xf(_0x4495ea,'http://'+_0x3da2a8),_0x4495ea;}function c_(){var _0xed3687;return((_0xed3687=document['getElementsByTagName']('head'))==null?void 0x0:_0xed3687[0x0])??document;}Rf({'loadJS'(_0x2c6d58){return new Promise((_0x1df9f8,_0x1696ac)=>{const _0x528e41=document['createElement']('script');_0x528e41['setAttribute']('src',_0x2c6d58),_0x528e41['onload']=_0x1df9f8,_0x528e41['onerror']=_0x4ca9bf=>{const _0x55967d=J('internal-error');_0x55967d['customData']=_0x4ca9bf,_0x1696ac(_0x55967d);},_0x528e41['type']='text/javascript',_0x528e41['charset']='UTF-8',c_()['appendChild'](_0x528e41);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};