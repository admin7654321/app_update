const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x579e0e,_0xd42502){if(!_0x579e0e)throw ot(_0xd42502);},ot=function(_0x5afecc){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5afecc);},Wr=function(_0x2bff3f){const _0x1bab8a=[];let _0x41965c=0x0;for(let _0x3261c8=0x0;_0x3261c8<_0x2bff3f['length'];_0x3261c8++){let _0x1dac58=_0x2bff3f['charCodeAt'](_0x3261c8);_0x1dac58<0x80?_0x1bab8a[_0x41965c++]=_0x1dac58:_0x1dac58<0x800?(_0x1bab8a[_0x41965c++]=_0x1dac58>>0x6|0xc0,_0x1bab8a[_0x41965c++]=_0x1dac58&0x3f|0x80):(_0x1dac58&0xfc00)===0xd800&&_0x3261c8+0x1<_0x2bff3f['length']&&(_0x2bff3f['charCodeAt'](_0x3261c8+0x1)&0xfc00)===0xdc00?(_0x1dac58=0x10000+((_0x1dac58&0x3ff)<<0xa)+(_0x2bff3f['charCodeAt'](++_0x3261c8)&0x3ff),_0x1bab8a[_0x41965c++]=_0x1dac58>>0x12|0xf0,_0x1bab8a[_0x41965c++]=_0x1dac58>>0xc&0x3f|0x80,_0x1bab8a[_0x41965c++]=_0x1dac58>>0x6&0x3f|0x80,_0x1bab8a[_0x41965c++]=_0x1dac58&0x3f|0x80):(_0x1bab8a[_0x41965c++]=_0x1dac58>>0xc|0xe0,_0x1bab8a[_0x41965c++]=_0x1dac58>>0x6&0x3f|0x80,_0x1bab8a[_0x41965c++]=_0x1dac58&0x3f|0x80);}return _0x1bab8a;},Za=function(_0x42a397){const _0x26c3ba=[];let _0x529826=0x0,_0x3f2d76=0x0;for(;_0x529826<_0x42a397['length'];){const _0x3c7714=_0x42a397[_0x529826++];if(_0x3c7714<0x80)_0x26c3ba[_0x3f2d76++]=String['fromCharCode'](_0x3c7714);else{if(_0x3c7714>0xbf&&_0x3c7714<0xe0){const _0x5040a5=_0x42a397[_0x529826++];_0x26c3ba[_0x3f2d76++]=String['fromCharCode']((_0x3c7714&0x1f)<<0x6|_0x5040a5&0x3f);}else{if(_0x3c7714>0xef&&_0x3c7714<0x16d){const _0x6451af=_0x42a397[_0x529826++],_0x5db18c=_0x42a397[_0x529826++],_0x5e91e0=_0x42a397[_0x529826++],_0x1797e1=((_0x3c7714&0x7)<<0x12|(_0x6451af&0x3f)<<0xc|(_0x5db18c&0x3f)<<0x6|_0x5e91e0&0x3f)-0x10000;_0x26c3ba[_0x3f2d76++]=String['fromCharCode'](0xd800+(_0x1797e1>>0xa)),_0x26c3ba[_0x3f2d76++]=String['fromCharCode'](0xdc00+(_0x1797e1&0x3ff));}else{const _0x9be4e3=_0x42a397[_0x529826++],_0x1a71f6=_0x42a397[_0x529826++];_0x26c3ba[_0x3f2d76++]=String['fromCharCode']((_0x3c7714&0xf)<<0xc|(_0x9be4e3&0x3f)<<0x6|_0x1a71f6&0x3f);}}}}return _0x26c3ba['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4c3182,_0x582deb){if(!Array['isArray'](_0x4c3182))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x24bfb9=_0x582deb?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x378afe=[];for(let _0x20efe4=0x0;_0x20efe4<_0x4c3182['length'];_0x20efe4+=0x3){const _0x4ad709=_0x4c3182[_0x20efe4],_0x2e6e54=_0x20efe4+0x1<_0x4c3182['length'],_0x55462d=_0x2e6e54?_0x4c3182[_0x20efe4+0x1]:0x0,_0x2fe124=_0x20efe4+0x2<_0x4c3182['length'],_0x18fe5c=_0x2fe124?_0x4c3182[_0x20efe4+0x2]:0x0,_0x18751f=_0x4ad709>>0x2,_0x3aacf3=(_0x4ad709&0x3)<<0x4|_0x55462d>>0x4;let _0x2fc25a=(_0x55462d&0xf)<<0x2|_0x18fe5c>>0x6,_0x4c4e24=_0x18fe5c&0x3f;_0x2fe124||(_0x4c4e24=0x40,_0x2e6e54||(_0x2fc25a=0x40)),_0x378afe['push'](_0x24bfb9[_0x18751f],_0x24bfb9[_0x3aacf3],_0x24bfb9[_0x2fc25a],_0x24bfb9[_0x4c4e24]);}return _0x378afe['join']('');},'encodeString'(_0x2903d8,_0x12feb3){return this['HAS_NATIVE_SUPPORT']&&!_0x12feb3?btoa(_0x2903d8):this['encodeByteArray'](Wr(_0x2903d8),_0x12feb3);},'decodeString'(_0x82c818,_0x40c551){return this['HAS_NATIVE_SUPPORT']&&!_0x40c551?atob(_0x82c818):Za(this['decodeStringToByteArray'](_0x82c818,_0x40c551));},'decodeStringToByteArray'(_0x56bd66,_0x5a8667){this['init_']();const _0x413c16=_0x5a8667?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xc8d382=[];for(let _0x5b9cf9=0x0;_0x5b9cf9<_0x56bd66['length'];){const _0x515203=_0x413c16[_0x56bd66['charAt'](_0x5b9cf9++)],_0xa99d55=_0x5b9cf9<_0x56bd66['length']?_0x413c16[_0x56bd66['charAt'](_0x5b9cf9)]:0x0;++_0x5b9cf9;const _0x1d5ec5=_0x5b9cf9<_0x56bd66['length']?_0x413c16[_0x56bd66['charAt'](_0x5b9cf9)]:0x40;++_0x5b9cf9;const _0x32a14e=_0x5b9cf9<_0x56bd66['length']?_0x413c16[_0x56bd66['charAt'](_0x5b9cf9)]:0x40;if(++_0x5b9cf9,_0x515203==null||_0xa99d55==null||_0x1d5ec5==null||_0x32a14e==null)throw new ec();const _0x584b2b=_0x515203<<0x2|_0xa99d55>>0x4;if(_0xc8d382['push'](_0x584b2b),_0x1d5ec5!==0x40){const _0x5a140b=_0xa99d55<<0x4&0xf0|_0x1d5ec5>>0x2;if(_0xc8d382['push'](_0x5a140b),_0x32a14e!==0x40){const _0x5b7a9e=_0x1d5ec5<<0x6&0xc0|_0x32a14e;_0xc8d382['push'](_0x5b7a9e);}}}return _0xc8d382;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3a6902=0x0;_0x3a6902<this['ENCODED_VALS']['length'];_0x3a6902++)this['byteToCharMap_'][_0x3a6902]=this['ENCODED_VALS']['charAt'](_0x3a6902),this['charToByteMap_'][this['byteToCharMap_'][_0x3a6902]]=_0x3a6902,this['byteToCharMapWebSafe_'][_0x3a6902]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3a6902),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3a6902]]=_0x3a6902,_0x3a6902>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3a6902)]=_0x3a6902,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3a6902)]=_0x3a6902);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x578dac){const _0x5b2537=Wr(_0x578dac);return Di['encodeByteArray'](_0x5b2537,!0x0);},an=function(_0xb3d2f){return Br(_0xb3d2f)['replace'](/\./g,'');},cn=function(_0x3515ad){try{return Di['decodeString'](_0x3515ad,!0x0);}catch(_0x1517dd){console['error']('base64Decode\x20failed:\x20',_0x1517dd);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x42baad){return Vr(void 0x0,_0x42baad);}function Vr(_0x1d0680,_0x3bcaab){if(!(_0x3bcaab instanceof Object))return _0x3bcaab;switch(_0x3bcaab['constructor']){case Date:const _0x5a9c3b=_0x3bcaab;return new Date(_0x5a9c3b['getTime']());case Object:_0x1d0680===void 0x0&&(_0x1d0680={});break;case Array:_0x1d0680=[];break;default:return _0x3bcaab;}for(const _0x775365 in _0x3bcaab)!_0x3bcaab['hasOwnProperty'](_0x775365)||!nc(_0x775365)||(_0x1d0680[_0x775365]=Vr(_0x1d0680[_0x775365],_0x3bcaab[_0x775365]));return _0x1d0680;}function nc(_0x4a4e7b){return _0x4a4e7b!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x570ea5=As['__FIREBASE_DEFAULTS__'];if(_0x570ea5)return JSON['parse'](_0x570ea5);},oc=()=>{if(typeof document>'u')return;let _0x10de49;try{_0x10de49=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4ba99c=_0x10de49&&cn(_0x10de49[0x1]);return _0x4ba99c&&JSON['parse'](_0x4ba99c);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x54ae00){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x54ae00);return;}},Hr=_0xc1f96e=>{var _0x13d820,_0x3f9fa4;return(_0x3f9fa4=(_0x13d820=Mi())==null?void 0x0:_0x13d820['emulatorHosts'])==null?void 0x0:_0x3f9fa4[_0xc1f96e];},ac=_0x17a618=>{const _0x2212ee=Hr(_0x17a618);if(!_0x2212ee)return;const _0x59ff65=_0x2212ee['lastIndexOf'](':');if(_0x59ff65<=0x0||_0x59ff65+0x1===_0x2212ee['length'])throw new Error('Invalid\x20host\x20'+_0x2212ee+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x57d7d7=parseInt(_0x2212ee['substring'](_0x59ff65+0x1),0xa);return _0x2212ee[0x0]==='['?[_0x2212ee['substring'](0x1,_0x59ff65-0x1),_0x57d7d7]:[_0x2212ee['substring'](0x0,_0x59ff65),_0x57d7d7];},$r=()=>{var _0x559c6d;return(_0x559c6d=Mi())==null?void 0x0:_0x559c6d['config'];},Gr=_0x2358f5=>{var _0x290b70;return(_0x290b70=Mi())==null?void 0x0:_0x290b70['_'+_0x2358f5];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x21c109,_0x46e50e)=>{this['resolve']=_0x21c109,this['reject']=_0x46e50e;});}['wrapCallback'](_0x436652){return(_0x4e6c37,_0x5820fd)=>{_0x4e6c37?this['reject'](_0x4e6c37):this['resolve'](_0x5820fd),typeof _0x436652=='function'&&(this['promise']['catch'](()=>{}),_0x436652['length']===0x1?_0x436652(_0x4e6c37):_0x436652(_0x4e6c37,_0x5820fd));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x438842,_0x7db34d){if(_0x438842['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x2e0339={'alg':'none','type':'JWT'},_0x2af971=_0x7db34d||'demo-project',_0x6a0a1c=_0x438842['iat']||0x0,_0x2d3157=_0x438842['sub']||_0x438842['user_id'];if(!_0x2d3157)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5416ca={'iss':'https://securetoken.google.com/'+_0x2af971,'aud':_0x2af971,'iat':_0x6a0a1c,'exp':_0x6a0a1c+0xe10,'auth_time':_0x6a0a1c,'sub':_0x2d3157,'user_id':_0x2d3157,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x438842};return[an(JSON['stringify'](_0x2e0339)),an(JSON['stringify'](_0x5416ca)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4c4629=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4c4629=='object'&&_0x4c4629['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0xaf74c2=W();return _0xaf74c2['indexOf']('MSIE\x20')>=0x0||_0xaf74c2['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4ad5e3,_0x188ae1)=>{try{let _0x1732fe=!0x0;const _0x581b48='validate-browser-context-for-indexeddb-analytics-module',_0xaeda1e=self['indexedDB']['open'](_0x581b48);_0xaeda1e['onsuccess']=()=>{_0xaeda1e['result']['close'](),_0x1732fe||self['indexedDB']['deleteDatabase'](_0x581b48),_0x4ad5e3(!0x0);},_0xaeda1e['onupgradeneeded']=()=>{_0x1732fe=!0x1;},_0xaeda1e['onerror']=()=>{var _0xd551e;_0x188ae1(((_0xd551e=_0xaeda1e['error'])==null?void 0x0:_0xd551e['message'])||'');};}catch(_0x4222e8){_0x188ae1(_0x4222e8);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x240eb5,_0x18dc56,_0x5d71ea){super(_0x18dc56),this['code']=_0x240eb5,this['customData']=_0x5d71ea,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4690ce,_0x36c730,_0x391c0a){this['service']=_0x4690ce,this['serviceName']=_0x36c730,this['errors']=_0x391c0a;}['create'](_0x461c7e,..._0x2e90ba){const _0xa75b5c=_0x2e90ba[0x0]||{},_0x11ce30=this['service']+'/'+_0x461c7e,_0x482ca0=this['errors'][_0x461c7e],_0x47dfe1=_0x482ca0?gc(_0x482ca0,_0xa75b5c):'Error',_0x28fe49=this['serviceName']+':\x20'+_0x47dfe1+'\x20('+_0x11ce30+').';return new Se(_0x11ce30,_0x28fe49,_0xa75b5c);}}function gc(_0x406d1f,_0x3b91de){return _0x406d1f['replace'](mc,(_0x39debe,_0x4125f9)=>{const _0x5da36c=_0x3b91de[_0x4125f9];return _0x5da36c!=null?String(_0x5da36c):'<'+_0x4125f9+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x236486){return JSON['parse'](_0x236486);}function O(_0x3ecd1d){return JSON['stringify'](_0x3ecd1d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x2f9788){let _0x3da17f={},_0x445697={},_0xa8daa2={},_0xce21ba='';try{const _0x4b2890=_0x2f9788['split']('.');_0x3da17f=bt(cn(_0x4b2890[0x0])||''),_0x445697=bt(cn(_0x4b2890[0x1])||''),_0xce21ba=_0x4b2890[0x2],_0xa8daa2=_0x445697['d']||{},delete _0x445697['d'];}catch{}return{'header':_0x3da17f,'claims':_0x445697,'data':_0xa8daa2,'signature':_0xce21ba};},yc=function(_0x473c0d){const _0x551006=zr(_0x473c0d),_0x16c686=_0x551006['claims'];return!!_0x16c686&&typeof _0x16c686=='object'&&_0x16c686['hasOwnProperty']('iat');},vc=function(_0x537901){const _0x193535=zr(_0x537901)['claims'];return typeof _0x193535=='object'&&_0x193535['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x20da97,_0x5e0d0b){return Object['prototype']['hasOwnProperty']['call'](_0x20da97,_0x5e0d0b);}function Oe(_0x2c463c,_0x329292){if(Object['prototype']['hasOwnProperty']['call'](_0x2c463c,_0x329292))return _0x2c463c[_0x329292];}function hi(_0x56406c){for(const _0x80c266 in _0x56406c)if(Object['prototype']['hasOwnProperty']['call'](_0x56406c,_0x80c266))return!0x1;return!0x0;}function ln(_0x5cc33c,_0x407c48,_0x1d223d){const _0x3345c2={};for(const _0x417068 in _0x5cc33c)Object['prototype']['hasOwnProperty']['call'](_0x5cc33c,_0x417068)&&(_0x3345c2[_0x417068]=_0x407c48['call'](_0x1d223d,_0x5cc33c[_0x417068],_0x417068,_0x5cc33c));return _0x3345c2;}function De(_0xf6a0a9,_0x529f59){if(_0xf6a0a9===_0x529f59)return!0x0;const _0x190ec1=Object['keys'](_0xf6a0a9),_0x49181a=Object['keys'](_0x529f59);for(const _0x3c21c3 of _0x190ec1){if(!_0x49181a['includes'](_0x3c21c3))return!0x1;const _0x53c63a=_0xf6a0a9[_0x3c21c3],_0x56ab8=_0x529f59[_0x3c21c3];if(ks(_0x53c63a)&&ks(_0x56ab8)){if(!De(_0x53c63a,_0x56ab8))return!0x1;}else{if(_0x53c63a!==_0x56ab8)return!0x1;}}for(const _0x1cffe2 of _0x49181a)if(!_0x190ec1['includes'](_0x1cffe2))return!0x1;return!0x0;}function ks(_0x2ff677){return _0x2ff677!==null&&typeof _0x2ff677=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x24a78c){const _0x4797bb=[];for(const [_0x4799fd,_0x36c669]of Object['entries'](_0x24a78c))Array['isArray'](_0x36c669)?_0x36c669['forEach'](_0x3216ff=>{_0x4797bb['push'](encodeURIComponent(_0x4799fd)+'='+encodeURIComponent(_0x3216ff));}):_0x4797bb['push'](encodeURIComponent(_0x4799fd)+'='+encodeURIComponent(_0x36c669));return _0x4797bb['length']?'&'+_0x4797bb['join']('&'):'';}function yt(_0x3db1b5){const _0x44504b={};return _0x3db1b5['replace'](/^\?/,'')['split']('&')['forEach'](_0x5951ca=>{if(_0x5951ca){const [_0x3801d3,_0x4612d4]=_0x5951ca['split']('=');_0x44504b[decodeURIComponent(_0x3801d3)]=decodeURIComponent(_0x4612d4);}}),_0x44504b;}function vt(_0x5360e2){const _0x2b1a20=_0x5360e2['indexOf']('?');if(!_0x2b1a20)return'';const _0x34418d=_0x5360e2['indexOf']('#',_0x2b1a20);return _0x5360e2['substring'](_0x2b1a20,_0x34418d>0x0?_0x34418d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3be89f=0x1;_0x3be89f<this['blockSize'];++_0x3be89f)this['pad_'][_0x3be89f]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3e6169,_0x241ec3){_0x241ec3||(_0x241ec3=0x0);const _0x1f84c8=this['W_'];if(typeof _0x3e6169=='string'){for(let _0x50f853=0x0;_0x50f853<0x10;_0x50f853++)_0x1f84c8[_0x50f853]=_0x3e6169['charCodeAt'](_0x241ec3)<<0x18|_0x3e6169['charCodeAt'](_0x241ec3+0x1)<<0x10|_0x3e6169['charCodeAt'](_0x241ec3+0x2)<<0x8|_0x3e6169['charCodeAt'](_0x241ec3+0x3),_0x241ec3+=0x4;}else{for(let _0x3df256=0x0;_0x3df256<0x10;_0x3df256++)_0x1f84c8[_0x3df256]=_0x3e6169[_0x241ec3]<<0x18|_0x3e6169[_0x241ec3+0x1]<<0x10|_0x3e6169[_0x241ec3+0x2]<<0x8|_0x3e6169[_0x241ec3+0x3],_0x241ec3+=0x4;}for(let _0x543e8f=0x10;_0x543e8f<0x50;_0x543e8f++){const _0x499102=_0x1f84c8[_0x543e8f-0x3]^_0x1f84c8[_0x543e8f-0x8]^_0x1f84c8[_0x543e8f-0xe]^_0x1f84c8[_0x543e8f-0x10];_0x1f84c8[_0x543e8f]=(_0x499102<<0x1|_0x499102>>>0x1f)&0xffffffff;}let _0x2236b9=this['chain_'][0x0],_0x360fe0=this['chain_'][0x1],_0x498538=this['chain_'][0x2],_0x35a5e2=this['chain_'][0x3],_0x34141c=this['chain_'][0x4],_0x58d7cc,_0x343491;for(let _0xfbcde7=0x0;_0xfbcde7<0x50;_0xfbcde7++){_0xfbcde7<0x28?_0xfbcde7<0x14?(_0x58d7cc=_0x35a5e2^_0x360fe0&(_0x498538^_0x35a5e2),_0x343491=0x5a827999):(_0x58d7cc=_0x360fe0^_0x498538^_0x35a5e2,_0x343491=0x6ed9eba1):_0xfbcde7<0x3c?(_0x58d7cc=_0x360fe0&_0x498538|_0x35a5e2&(_0x360fe0|_0x498538),_0x343491=0x8f1bbcdc):(_0x58d7cc=_0x360fe0^_0x498538^_0x35a5e2,_0x343491=0xca62c1d6);const _0x32d7c6=(_0x2236b9<<0x5|_0x2236b9>>>0x1b)+_0x58d7cc+_0x34141c+_0x343491+_0x1f84c8[_0xfbcde7]&0xffffffff;_0x34141c=_0x35a5e2,_0x35a5e2=_0x498538,_0x498538=(_0x360fe0<<0x1e|_0x360fe0>>>0x2)&0xffffffff,_0x360fe0=_0x2236b9,_0x2236b9=_0x32d7c6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2236b9&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x360fe0&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x498538&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x35a5e2&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x34141c&0xffffffff;}['update'](_0x1968ad,_0x1cea02){if(_0x1968ad==null)return;_0x1cea02===void 0x0&&(_0x1cea02=_0x1968ad['length']);const _0x2ed937=_0x1cea02-this['blockSize'];let _0x5f2613=0x0;const _0x20bc4d=this['buf_'];let _0x22927f=this['inbuf_'];for(;_0x5f2613<_0x1cea02;){if(_0x22927f===0x0){for(;_0x5f2613<=_0x2ed937;)this['compress_'](_0x1968ad,_0x5f2613),_0x5f2613+=this['blockSize'];}if(typeof _0x1968ad=='string'){for(;_0x5f2613<_0x1cea02;)if(_0x20bc4d[_0x22927f]=_0x1968ad['charCodeAt'](_0x5f2613),++_0x22927f,++_0x5f2613,_0x22927f===this['blockSize']){this['compress_'](_0x20bc4d),_0x22927f=0x0;break;}}else{for(;_0x5f2613<_0x1cea02;)if(_0x20bc4d[_0x22927f]=_0x1968ad[_0x5f2613],++_0x22927f,++_0x5f2613,_0x22927f===this['blockSize']){this['compress_'](_0x20bc4d),_0x22927f=0x0;break;}}}this['inbuf_']=_0x22927f,this['total_']+=_0x1cea02;}['digest'](){const _0x11f318=[];let _0x4edb3f=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x546ea7=this['blockSize']-0x1;_0x546ea7>=0x38;_0x546ea7--)this['buf_'][_0x546ea7]=_0x4edb3f&0xff,_0x4edb3f/=0x100;this['compress_'](this['buf_']);let _0x35849b=0x0;for(let _0x39969a=0x0;_0x39969a<0x5;_0x39969a++)for(let _0x2aa0e1=0x18;_0x2aa0e1>=0x0;_0x2aa0e1-=0x8)_0x11f318[_0x35849b]=this['chain_'][_0x39969a]>>_0x2aa0e1&0xff,++_0x35849b;return _0x11f318;}}function Ic(_0xa620df,_0x3b8727){const _0xd6672b=new wc(_0xa620df,_0x3b8727);return _0xd6672b['subscribe']['bind'](_0xd6672b);}class wc{constructor(_0x1ba00c,_0x5becf9){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5becf9,this['task']['then'](()=>{_0x1ba00c(this);})['catch'](_0x14f64c=>{this['error'](_0x14f64c);});}['next'](_0x3f0734){this['forEachObserver'](_0x5615c8=>{_0x5615c8['next'](_0x3f0734);});}['error'](_0x106efd){this['forEachObserver'](_0x3731c0=>{_0x3731c0['error'](_0x106efd);}),this['close'](_0x106efd);}['complete'](){this['forEachObserver'](_0x24e0ca=>{_0x24e0ca['complete']();}),this['close']();}['subscribe'](_0x519dd1,_0x4c75d7,_0x57461a){let _0x170b48;if(_0x519dd1===void 0x0&&_0x4c75d7===void 0x0&&_0x57461a===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x519dd1,['next','error','complete'])?_0x170b48=_0x519dd1:_0x170b48={'next':_0x519dd1,'error':_0x4c75d7,'complete':_0x57461a},_0x170b48['next']===void 0x0&&(_0x170b48['next']=Qn),_0x170b48['error']===void 0x0&&(_0x170b48['error']=Qn),_0x170b48['complete']===void 0x0&&(_0x170b48['complete']=Qn);const _0xbeb6ec=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x170b48['error'](this['finalError']):_0x170b48['complete']();}catch{}}),this['observers']['push'](_0x170b48),_0xbeb6ec;}['unsubscribeOne'](_0x4f46e5){this['observers']===void 0x0||this['observers'][_0x4f46e5]===void 0x0||(delete this['observers'][_0x4f46e5],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x428eac){if(!this['finalized']){for(let _0x3406ec=0x0;_0x3406ec<this['observers']['length'];_0x3406ec++)this['sendOne'](_0x3406ec,_0x428eac);}}['sendOne'](_0x42104c,_0x3bad3c){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x42104c]!==void 0x0)try{_0x3bad3c(this['observers'][_0x42104c]);}catch(_0x5294c0){typeof console<'u'&&console['error']&&console['error'](_0x5294c0);}});}['close'](_0x2fbbf0){this['finalized']||(this['finalized']=!0x0,_0x2fbbf0!==void 0x0&&(this['finalError']=_0x2fbbf0),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1140b3,_0xe75f34){if(typeof _0x1140b3!='object'||_0x1140b3===null)return!0x1;for(const _0x395d10 of _0xe75f34)if(_0x395d10 in _0x1140b3&&typeof _0x1140b3[_0x395d10]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x401373,_0x11d39e){return _0x401373+'\x20failed:\x20'+_0x11d39e+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x1f6d5d){const _0x28d01e=[];let _0x20a88f=0x0;for(let _0x59adb0=0x0;_0x59adb0<_0x1f6d5d['length'];_0x59adb0++){let _0x13872a=_0x1f6d5d['charCodeAt'](_0x59adb0);if(_0x13872a>=0xd800&&_0x13872a<=0xdbff){const _0x6a82b0=_0x13872a-0xd800;_0x59adb0++,f(_0x59adb0<_0x1f6d5d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x6c1ff5=_0x1f6d5d['charCodeAt'](_0x59adb0)-0xdc00;_0x13872a=0x10000+(_0x6a82b0<<0xa)+_0x6c1ff5;}_0x13872a<0x80?_0x28d01e[_0x20a88f++]=_0x13872a:_0x13872a<0x800?(_0x28d01e[_0x20a88f++]=_0x13872a>>0x6|0xc0,_0x28d01e[_0x20a88f++]=_0x13872a&0x3f|0x80):_0x13872a<0x10000?(_0x28d01e[_0x20a88f++]=_0x13872a>>0xc|0xe0,_0x28d01e[_0x20a88f++]=_0x13872a>>0x6&0x3f|0x80,_0x28d01e[_0x20a88f++]=_0x13872a&0x3f|0x80):(_0x28d01e[_0x20a88f++]=_0x13872a>>0x12|0xf0,_0x28d01e[_0x20a88f++]=_0x13872a>>0xc&0x3f|0x80,_0x28d01e[_0x20a88f++]=_0x13872a>>0x6&0x3f|0x80,_0x28d01e[_0x20a88f++]=_0x13872a&0x3f|0x80);}return _0x28d01e;},Pn=function(_0x35b39c){let _0x2b8744=0x0;for(let _0xd63563=0x0;_0xd63563<_0x35b39c['length'];_0xd63563++){const _0x482a0e=_0x35b39c['charCodeAt'](_0xd63563);_0x482a0e<0x80?_0x2b8744++:_0x482a0e<0x800?_0x2b8744+=0x2:_0x482a0e>=0xd800&&_0x482a0e<=0xdbff?(_0x2b8744+=0x4,_0xd63563++):_0x2b8744+=0x3;}return _0x2b8744;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4183a7){return _0x4183a7&&_0x4183a7['_delegate']?_0x4183a7['_delegate']:_0x4183a7;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x2be394){try{return(_0x2be394['startsWith']('http://')||_0x2be394['startsWith']('https://')?new URL(_0x2be394)['hostname']:_0x2be394)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x31d126){return(await fetch(_0x31d126,{'credentials':'include'}))['ok'];}class Me{constructor(_0x5ad51d,_0xa20837,_0x2c30a1){this['name']=_0x5ad51d,this['instanceFactory']=_0xa20837,this['type']=_0x2c30a1,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x21ee18){return this['instantiationMode']=_0x21ee18,this;}['setMultipleInstances'](_0x5f4e32){return this['multipleInstances']=_0x5f4e32,this;}['setServiceProps'](_0x161e6d){return this['serviceProps']=_0x161e6d,this;}['setInstanceCreatedCallback'](_0x5b3583){return this['onInstanceCreated']=_0x5b3583,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x28dc48,_0x59ea37){this['name']=_0x28dc48,this['container']=_0x59ea37,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2d80e9){const _0x73dd70=this['normalizeInstanceIdentifier'](_0x2d80e9);if(!this['instancesDeferred']['has'](_0x73dd70)){const _0x31ff5b=new Ve();if(this['instancesDeferred']['set'](_0x73dd70,_0x31ff5b),this['isInitialized'](_0x73dd70)||this['shouldAutoInitialize']())try{const _0x20f8bd=this['getOrInitializeService']({'instanceIdentifier':_0x73dd70});_0x20f8bd&&_0x31ff5b['resolve'](_0x20f8bd);}catch{}}return this['instancesDeferred']['get'](_0x73dd70)['promise'];}['getImmediate'](_0x1bf037){const _0x5c6988=this['normalizeInstanceIdentifier'](_0x1bf037==null?void 0x0:_0x1bf037['identifier']),_0x212071=(_0x1bf037==null?void 0x0:_0x1bf037['optional'])??!0x1;if(this['isInitialized'](_0x5c6988)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5c6988});}catch(_0x17256e){if(_0x212071)return null;throw _0x17256e;}else{if(_0x212071)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x18a17a){if(_0x18a17a['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x18a17a['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x18a17a,!!this['shouldAutoInitialize']()){if(Rc(_0x18a17a))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x1568fb,_0x5a4bf8]of this['instancesDeferred']['entries']()){const _0x56fc83=this['normalizeInstanceIdentifier'](_0x1568fb);try{const _0x39db07=this['getOrInitializeService']({'instanceIdentifier':_0x56fc83});_0x5a4bf8['resolve'](_0x39db07);}catch{}}}}['clearInstance'](_0x4764e9=ke){this['instancesDeferred']['delete'](_0x4764e9),this['instancesOptions']['delete'](_0x4764e9),this['instances']['delete'](_0x4764e9);}async['delete'](){const _0x4e9f14=Array['from'](this['instances']['values']());await Promise['all']([..._0x4e9f14['filter'](_0x2ab6a6=>'INTERNAL'in _0x2ab6a6)['map'](_0xeae03e=>_0xeae03e['INTERNAL']['delete']()),..._0x4e9f14['filter'](_0x117759=>'_delete'in _0x117759)['map'](_0x33f554=>_0x33f554['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x49b3a9=ke){return this['instances']['has'](_0x49b3a9);}['getOptions'](_0x14af91=ke){return this['instancesOptions']['get'](_0x14af91)||{};}['initialize'](_0x5e5d67={}){const {options:_0x4e3e87={}}=_0x5e5d67,_0x295747=this['normalizeInstanceIdentifier'](_0x5e5d67['instanceIdentifier']);if(this['isInitialized'](_0x295747))throw Error(this['name']+'('+_0x295747+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xabefd0=this['getOrInitializeService']({'instanceIdentifier':_0x295747,'options':_0x4e3e87});for(const [_0x52155b,_0x1a7668]of this['instancesDeferred']['entries']()){const _0x4fad72=this['normalizeInstanceIdentifier'](_0x52155b);_0x295747===_0x4fad72&&_0x1a7668['resolve'](_0xabefd0);}return _0xabefd0;}['onInit'](_0x2fdb62,_0x5bdc1d){const _0xaae268=this['normalizeInstanceIdentifier'](_0x5bdc1d),_0x4c2e5b=this['onInitCallbacks']['get'](_0xaae268)??new Set();_0x4c2e5b['add'](_0x2fdb62),this['onInitCallbacks']['set'](_0xaae268,_0x4c2e5b);const _0x51ec99=this['instances']['get'](_0xaae268);return _0x51ec99&&_0x2fdb62(_0x51ec99,_0xaae268),()=>{_0x4c2e5b['delete'](_0x2fdb62);};}['invokeOnInitCallbacks'](_0x339a03,_0x50ec25){const _0x496a92=this['onInitCallbacks']['get'](_0x50ec25);if(_0x496a92){for(const _0x5586d7 of _0x496a92)try{_0x5586d7(_0x339a03,_0x50ec25);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x426a05,options:_0xd9ab2a={}}){let _0x48c598=this['instances']['get'](_0x426a05);if(!_0x48c598&&this['component']&&(_0x48c598=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x426a05),'options':_0xd9ab2a}),this['instances']['set'](_0x426a05,_0x48c598),this['instancesOptions']['set'](_0x426a05,_0xd9ab2a),this['invokeOnInitCallbacks'](_0x48c598,_0x426a05),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x426a05,_0x48c598);}catch{}return _0x48c598||null;}['normalizeInstanceIdentifier'](_0x490f6f=ke){return this['component']?this['component']['multipleInstances']?_0x490f6f:ke:_0x490f6f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x192aef){return _0x192aef===ke?void 0x0:_0x192aef;}function Rc(_0x35d6a2){return _0x35d6a2['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3a348e){this['name']=_0x3a348e,this['providers']=new Map();}['addComponent'](_0x4194e9){const _0x1f9f6c=this['getProvider'](_0x4194e9['name']);if(_0x1f9f6c['isComponentSet']())throw new Error('Component\x20'+_0x4194e9['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1f9f6c['setComponent'](_0x4194e9);}['addOrOverwriteComponent'](_0x39f66b){this['getProvider'](_0x39f66b['name'])['isComponentSet']()&&this['providers']['delete'](_0x39f66b['name']),this['addComponent'](_0x39f66b);}['getProvider'](_0x1f7b3a){if(this['providers']['has'](_0x1f7b3a))return this['providers']['get'](_0x1f7b3a);const _0x4f8d75=new Sc(_0x1f7b3a,this);return this['providers']['set'](_0x1f7b3a,_0x4f8d75),_0x4f8d75;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1a761c){_0x1a761c[_0x1a761c['DEBUG']=0x0]='DEBUG',_0x1a761c[_0x1a761c['VERBOSE']=0x1]='VERBOSE',_0x1a761c[_0x1a761c['INFO']=0x2]='INFO',_0x1a761c[_0x1a761c['WARN']=0x3]='WARN',_0x1a761c[_0x1a761c['ERROR']=0x4]='ERROR',_0x1a761c[_0x1a761c['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x3d41a9,_0x534c62,..._0x59d40e)=>{if(_0x534c62<_0x3d41a9['logLevel'])return;const _0x3d61d8=new Date()['toISOString'](),_0x5fc45f=Pc[_0x534c62];if(_0x5fc45f)console[_0x5fc45f]('['+_0x3d61d8+']\x20\x20'+_0x3d41a9['name']+':',..._0x59d40e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x534c62+')');};class xi{constructor(_0x250a0f){this['name']=_0x250a0f,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x180744){if(!(_0x180744 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x180744+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x180744;}['setLogLevel'](_0xbb5291){this['_logLevel']=typeof _0xbb5291=='string'?kc[_0xbb5291]:_0xbb5291;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xc824bc){if(typeof _0xc824bc!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xc824bc;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x318103){this['_userLogHandler']=_0x318103;}['debug'](..._0x1fc56e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1fc56e),this['_logHandler'](this,T['DEBUG'],..._0x1fc56e);}['log'](..._0x149209){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x149209),this['_logHandler'](this,T['VERBOSE'],..._0x149209);}['info'](..._0x25be25){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x25be25),this['_logHandler'](this,T['INFO'],..._0x25be25);}['warn'](..._0x1c10d2){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1c10d2),this['_logHandler'](this,T['WARN'],..._0x1c10d2);}['error'](..._0x2b2633){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2b2633),this['_logHandler'](this,T['ERROR'],..._0x2b2633);}}const Dc=(_0x3c12af,_0x43e381)=>_0x43e381['some'](_0x3968e4=>_0x3c12af instanceof _0x3968e4);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x2ac125){const _0x55ce08=new Promise((_0x949cd8,_0x15a0cf)=>{const _0x425e17=()=>{_0x2ac125['removeEventListener']('success',_0x16ff85),_0x2ac125['removeEventListener']('error',_0xe9710f);},_0x16ff85=()=>{_0x949cd8(_e(_0x2ac125['result'])),_0x425e17();},_0xe9710f=()=>{_0x15a0cf(_0x2ac125['error']),_0x425e17();};_0x2ac125['addEventListener']('success',_0x16ff85),_0x2ac125['addEventListener']('error',_0xe9710f);});return _0x55ce08['then'](_0x1d58dd=>{_0x1d58dd instanceof IDBCursor&&Kr['set'](_0x1d58dd,_0x2ac125);})['catch'](()=>{}),Fi['set'](_0x55ce08,_0x2ac125),_0x55ce08;}function Fc(_0x135bf4){if(ui['has'](_0x135bf4))return;const _0x53b868=new Promise((_0x330521,_0x2c7a41)=>{const _0x31bcbb=()=>{_0x135bf4['removeEventListener']('complete',_0x2c09e8),_0x135bf4['removeEventListener']('error',_0x263b75),_0x135bf4['removeEventListener']('abort',_0x263b75);},_0x2c09e8=()=>{_0x330521(),_0x31bcbb();},_0x263b75=()=>{_0x2c7a41(_0x135bf4['error']||new DOMException('AbortError','AbortError')),_0x31bcbb();};_0x135bf4['addEventListener']('complete',_0x2c09e8),_0x135bf4['addEventListener']('error',_0x263b75),_0x135bf4['addEventListener']('abort',_0x263b75);});ui['set'](_0x135bf4,_0x53b868);}let di={'get'(_0x33dbe8,_0x5b9ef2,_0x1eb57e){if(_0x33dbe8 instanceof IDBTransaction){if(_0x5b9ef2==='done')return ui['get'](_0x33dbe8);if(_0x5b9ef2==='objectStoreNames')return _0x33dbe8['objectStoreNames']||Yr['get'](_0x33dbe8);if(_0x5b9ef2==='store')return _0x1eb57e['objectStoreNames'][0x1]?void 0x0:_0x1eb57e['objectStore'](_0x1eb57e['objectStoreNames'][0x0]);}return _e(_0x33dbe8[_0x5b9ef2]);},'set'(_0x102525,_0x16ffe7,_0x360926){return _0x102525[_0x16ffe7]=_0x360926,!0x0;},'has'(_0x15dd0c,_0x5b253e){return _0x15dd0c instanceof IDBTransaction&&(_0x5b253e==='done'||_0x5b253e==='store')?!0x0:_0x5b253e in _0x15dd0c;}};function Uc(_0x53a247){di=_0x53a247(di);}function Wc(_0x363656){return _0x363656===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4f0428,..._0x57d5f6){const _0x275215=_0x363656['call'](Xn(this),_0x4f0428,..._0x57d5f6);return Yr['set'](_0x275215,_0x4f0428['sort']?_0x4f0428['sort']():[_0x4f0428]),_e(_0x275215);}:Lc()['includes'](_0x363656)?function(..._0x321943){return _0x363656['apply'](Xn(this),_0x321943),_e(Kr['get'](this));}:function(..._0x173e25){return _e(_0x363656['apply'](Xn(this),_0x173e25));};}function Bc(_0x2c3c6d){return typeof _0x2c3c6d=='function'?Wc(_0x2c3c6d):(_0x2c3c6d instanceof IDBTransaction&&Fc(_0x2c3c6d),Dc(_0x2c3c6d,Mc())?new Proxy(_0x2c3c6d,di):_0x2c3c6d);}function _e(_0x5da24e){if(_0x5da24e instanceof IDBRequest)return xc(_0x5da24e);if(Jn['has'](_0x5da24e))return Jn['get'](_0x5da24e);const _0x551007=Bc(_0x5da24e);return _0x551007!==_0x5da24e&&(Jn['set'](_0x5da24e,_0x551007),Fi['set'](_0x551007,_0x5da24e)),_0x551007;}const Xn=_0x181552=>Fi['get'](_0x181552);function Vc(_0x360727,_0x2a9af6,{blocked:_0x5cbecb,upgrade:_0x165c4a,blocking:_0x488ff4,terminated:_0x97ebb1}={}){const _0x3735f5=indexedDB['open'](_0x360727,_0x2a9af6),_0x15933c=_e(_0x3735f5);return _0x165c4a&&_0x3735f5['addEventListener']('upgradeneeded',_0x2976ab=>{_0x165c4a(_e(_0x3735f5['result']),_0x2976ab['oldVersion'],_0x2976ab['newVersion'],_e(_0x3735f5['transaction']),_0x2976ab);}),_0x5cbecb&&_0x3735f5['addEventListener']('blocked',_0x16793a=>_0x5cbecb(_0x16793a['oldVersion'],_0x16793a['newVersion'],_0x16793a)),_0x15933c['then'](_0x175467=>{_0x97ebb1&&_0x175467['addEventListener']('close',()=>_0x97ebb1()),_0x488ff4&&_0x175467['addEventListener']('versionchange',_0x599108=>_0x488ff4(_0x599108['oldVersion'],_0x599108['newVersion'],_0x599108));})['catch'](()=>{}),_0x15933c;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x8f491d,_0x49ed1b){if(!(_0x8f491d instanceof IDBDatabase&&!(_0x49ed1b in _0x8f491d)&&typeof _0x49ed1b=='string'))return;if(Zn['get'](_0x49ed1b))return Zn['get'](_0x49ed1b);const _0x17d44a=_0x49ed1b['replace'](/FromIndex$/,''),_0x3bcc98=_0x49ed1b!==_0x17d44a,_0x20ac70=$c['includes'](_0x17d44a);if(!(_0x17d44a in(_0x3bcc98?IDBIndex:IDBObjectStore)['prototype'])||!(_0x20ac70||Hc['includes'](_0x17d44a)))return;const _0x24a7b1=async function(_0x2e8a74,..._0x624bd8){const _0x1f444e=this['transaction'](_0x2e8a74,_0x20ac70?'readwrite':'readonly');let _0x4f1cc0=_0x1f444e['store'];return _0x3bcc98&&(_0x4f1cc0=_0x4f1cc0['index'](_0x624bd8['shift']())),(await Promise['all']([_0x4f1cc0[_0x17d44a](..._0x624bd8),_0x20ac70&&_0x1f444e['done']]))[0x0];};return Zn['set'](_0x49ed1b,_0x24a7b1),_0x24a7b1;}Uc(_0x4ea430=>({..._0x4ea430,'get':(_0x450048,_0x13acee,_0x1a8acf)=>Os(_0x450048,_0x13acee)||_0x4ea430['get'](_0x450048,_0x13acee,_0x1a8acf),'has':(_0x374a8d,_0x111f9e)=>!!Os(_0x374a8d,_0x111f9e)||_0x4ea430['has'](_0x374a8d,_0x111f9e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x501e02){this['container']=_0x501e02;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x421040=>{if(qc(_0x421040)){const _0x210c3d=_0x421040['getImmediate']();return _0x210c3d['library']+'/'+_0x210c3d['version'];}else return null;})['filter'](_0x4e4df0=>_0x4e4df0)['join']('\x20');}}function qc(_0x2219ec){const _0x749ff0=_0x2219ec['getComponent']();return(_0x749ff0==null?void 0x0:_0x749ff0['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x25ad7b,_0x468d04){try{_0x25ad7b['container']['addComponent'](_0x468d04);}catch(_0x440740){re['debug']('Component\x20'+_0x468d04['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x25ad7b['name'],_0x440740);}}function et(_0x617ee9){const _0x58cd7b=_0x617ee9['name'];if(gi['has'](_0x58cd7b))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x58cd7b+'.'),!0x1;gi['set'](_0x58cd7b,_0x617ee9);for(const _0x3ed148 of Le['values']())Ms(_0x3ed148,_0x617ee9);for(const _0x59cf5a of _i['values']())Ms(_0x59cf5a,_0x617ee9);return!0x0;}function Ui(_0x1eedd9,_0x19d5cf){const _0x1a5d46=_0x1eedd9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1a5d46&&_0x1a5d46['triggerHeartbeat'](),_0x1eedd9['container']['getProvider'](_0x19d5cf);}function H(_0x4e5691){return _0x4e5691==null?!0x1:_0x4e5691['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x49a82b,_0x2586a3,_0x26efdd){this['_isDeleted']=!0x1,this['_options']={..._0x49a82b},this['_config']={..._0x2586a3},this['_name']=_0x2586a3['name'],this['_automaticDataCollectionEnabled']=_0x2586a3['automaticDataCollectionEnabled'],this['_container']=_0x26efdd,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x44afc2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x44afc2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x288e05){this['_isDeleted']=_0x288e05;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x455980,_0x45ba7e={}){let _0x344587=_0x455980;typeof _0x45ba7e!='object'&&(_0x45ba7e={'name':_0x45ba7e});const _0x433e18={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x45ba7e},_0x3e79d9=_0x433e18['name'];if(typeof _0x3e79d9!='string'||!_0x3e79d9)throw ge['create']('bad-app-name',{'appName':String(_0x3e79d9)});if(_0x344587||(_0x344587=$r()),!_0x344587)throw ge['create']('no-options');const _0x16c9b9=Le['get'](_0x3e79d9);if(_0x16c9b9){if(De(_0x344587,_0x16c9b9['options'])&&De(_0x433e18,_0x16c9b9['config']))return _0x16c9b9;throw ge['create']('duplicate-app',{'appName':_0x3e79d9});}const _0x3a2ca6=new Ac(_0x3e79d9);for(const _0x1f502e of gi['values']())_0x3a2ca6['addComponent'](_0x1f502e);const _0x18fd3d=new Il(_0x344587,_0x433e18,_0x3a2ca6);return Le['set'](_0x3e79d9,_0x18fd3d),_0x18fd3d;}function Qr(_0x16152b=pi){const _0x7c54ae=Le['get'](_0x16152b);if(!_0x7c54ae&&_0x16152b===pi&&$r())return wl();if(!_0x7c54ae)throw ge['create']('no-app',{'appName':_0x16152b});return _0x7c54ae;}function l_(){return Array['from'](Le['values']());}async function h_(_0x14ea48){let _0x5849fc=!0x1;const _0x1cae7e=_0x14ea48['name'];Le['has'](_0x1cae7e)?(_0x5849fc=!0x0,Le['delete'](_0x1cae7e)):_i['has'](_0x1cae7e)&&_0x14ea48['decRefCount']()<=0x0&&(_i['delete'](_0x1cae7e),_0x5849fc=!0x0),_0x5849fc&&(await Promise['all'](_0x14ea48['container']['getProviders']()['map'](_0x5e998a=>_0x5e998a['delete']())),_0x14ea48['isDeleted']=!0x0);}function me(_0xbd2b4f,_0x252d09,_0x28a6c0){let _0x1c7454=vl[_0xbd2b4f]??_0xbd2b4f;_0x28a6c0&&(_0x1c7454+='-'+_0x28a6c0);const _0x52f329=_0x1c7454['match'](/\s|\//),_0x526fa6=_0x252d09['match'](/\s|\//);if(_0x52f329||_0x526fa6){const _0x202040=['Unable\x20to\x20register\x20library\x20\x22'+_0x1c7454+'\x22\x20with\x20version\x20\x22'+_0x252d09+'\x22:'];_0x52f329&&_0x202040['push']('library\x20name\x20\x22'+_0x1c7454+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x52f329&&_0x526fa6&&_0x202040['push']('and'),_0x526fa6&&_0x202040['push']('version\x20name\x20\x22'+_0x252d09+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x202040['join']('\x20'));return;}et(new Me(_0x1c7454+'-version',()=>({'library':_0x1c7454,'version':_0x252d09}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x6577b3,_0x1db94e)=>{switch(_0x1db94e){case 0x0:try{_0x6577b3['createObjectStore'](Rt);}catch(_0x14aa21){console['warn'](_0x14aa21);}}}})['catch'](_0x1f6ef7=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1f6ef7['message']});})),ei;}async function Sl(_0x3754fb){try{const _0x565197=(await Jr())['transaction'](Rt),_0xc2a91b=await _0x565197['objectStore'](Rt)['get'](Xr(_0x3754fb));return await _0x565197['done'],_0xc2a91b;}catch(_0xeab96d){if(_0xeab96d instanceof Se)re['warn'](_0xeab96d['message']);else{const _0xc34d80=ge['create']('idb-get',{'originalErrorMessage':_0xeab96d==null?void 0x0:_0xeab96d['message']});re['warn'](_0xc34d80['message']);}}}async function Ls(_0x434053,_0x393684){try{const _0x5ccc22=(await Jr())['transaction'](Rt,'readwrite');await _0x5ccc22['objectStore'](Rt)['put'](_0x393684,Xr(_0x434053)),await _0x5ccc22['done'];}catch(_0xe5f701){if(_0xe5f701 instanceof Se)re['warn'](_0xe5f701['message']);else{const _0x2e5d3f=ge['create']('idb-set',{'originalErrorMessage':_0xe5f701==null?void 0x0:_0xe5f701['message']});re['warn'](_0x2e5d3f['message']);}}}function Xr(_0x97f2bb){return _0x97f2bb['name']+'!'+_0x97f2bb['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x209c2b){this['container']=_0x209c2b,this['_heartbeatsCache']=null;const _0x43a2db=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x43a2db),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x502382=>(this['_heartbeatsCache']=_0x502382,_0x502382));}async['triggerHeartbeat'](){var _0x5b808b,_0x23680b;try{const _0x535e07=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2469d8=xs();if(((_0x5b808b=this['_heartbeatsCache'])==null?void 0x0:_0x5b808b['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x23680b=this['_heartbeatsCache'])==null?void 0x0:_0x23680b['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2469d8||this['_heartbeatsCache']['heartbeats']['some'](_0x375846=>_0x375846['date']===_0x2469d8))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2469d8,'agent':_0x535e07}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0xb20e6=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0xb20e6,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3304f0){re['warn'](_0x3304f0);}}async['getHeartbeatsHeader'](){var _0x3df63b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3df63b=this['_heartbeatsCache'])==null?void 0x0:_0x3df63b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x59ccf4=xs(),{heartbeatsToSend:_0x27b6b3,unsentEntries:_0x884161}=kl(this['_heartbeatsCache']['heartbeats']),_0x5e83a7=an(JSON['stringify']({'version':0x2,'heartbeats':_0x27b6b3}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x59ccf4,_0x884161['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x884161,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5e83a7;}catch(_0x417a57){return re['warn'](_0x417a57),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x34acb4,_0x5d2cfa=bl){const _0x536399=[];let _0x33c529=_0x34acb4['slice']();for(const _0x2575f1 of _0x34acb4){const _0x44b6ee=_0x536399['find'](_0x4596e4=>_0x4596e4['agent']===_0x2575f1['agent']);if(_0x44b6ee){if(_0x44b6ee['dates']['push'](_0x2575f1['date']),Fs(_0x536399)>_0x5d2cfa){_0x44b6ee['dates']['pop']();break;}}else{if(_0x536399['push']({'agent':_0x2575f1['agent'],'dates':[_0x2575f1['date']]}),Fs(_0x536399)>_0x5d2cfa){_0x536399['pop']();break;}}_0x33c529=_0x33c529['slice'](0x1);}return{'heartbeatsToSend':_0x536399,'unsentEntries':_0x33c529};}class Nl{constructor(_0x324bb5){this['app']=_0x324bb5,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4ac871=await Sl(this['app']);return _0x4ac871!=null&&_0x4ac871['heartbeats']?_0x4ac871:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5bbfa6){if(await this['_canUseIndexedDBPromise']){const _0x193d21=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5bbfa6['lastSentHeartbeatDate']??_0x193d21['lastSentHeartbeatDate'],'heartbeats':_0x5bbfa6['heartbeats']});}else return;}async['add'](_0x12d024){if(await this['_canUseIndexedDBPromise']){const _0x12eee7=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x12d024['lastSentHeartbeatDate']??_0x12eee7['lastSentHeartbeatDate'],'heartbeats':[..._0x12eee7['heartbeats'],..._0x12d024['heartbeats']]});}else return;}}function Fs(_0x353b49){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x353b49}))['length'];}function Pl(_0x514343){if(_0x514343['length']===0x0)return-0x1;let _0xba7a89=0x0,_0x22e50a=_0x514343[0x0]['date'];for(let _0x18171d=0x1;_0x18171d<_0x514343['length'];_0x18171d++)_0x514343[_0x18171d]['date']<_0x22e50a&&(_0x22e50a=_0x514343[_0x18171d]['date'],_0xba7a89=_0x18171d);return _0xba7a89;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4810a5){et(new Me('platform-logger',_0xe29049=>new Gc(_0xe29049),'PRIVATE')),et(new Me('heartbeat',_0x83f691=>new Al(_0x83f691),'PRIVATE')),me(fi,Ds,_0x4810a5),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x5e5458){Zr=_0x5e5458;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1e4958){this['domStorage_']=_0x1e4958,this['prefix_']='firebase:';}['set'](_0x5a16c4,_0x257fbe){_0x257fbe==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5a16c4)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5a16c4),O(_0x257fbe));}['get'](_0x5e7579){const _0xa4e518=this['domStorage_']['getItem'](this['prefixedName_'](_0x5e7579));return _0xa4e518==null?null:bt(_0xa4e518);}['remove'](_0x3dd550){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3dd550));}['prefixedName_'](_0x4d4f37){return this['prefix_']+_0x4d4f37;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5c1042,_0x204657){_0x204657==null?delete this['cache_'][_0x5c1042]:this['cache_'][_0x5c1042]=_0x204657;}['get'](_0x4c0c3f){return Y(this['cache_'],_0x4c0c3f)?this['cache_'][_0x4c0c3f]:null;}['remove'](_0x3374c0){delete this['cache_'][_0x3374c0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x57654a){try{if(typeof window<'u'&&typeof window[_0x57654a]<'u'){const _0x46bbb9=window[_0x57654a];return _0x46bbb9['setItem']('firebase:sentinel','cache'),_0x46bbb9['removeItem']('firebase:sentinel'),new xl(_0x46bbb9);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x14adcd=0x1;return function(){return _0x14adcd++;};}()),no=function(_0x2910cf){const _0x1b0b2b=Tc(_0x2910cf),_0x20c68a=new Ec();_0x20c68a['update'](_0x1b0b2b);const _0x5b4d87=_0x20c68a['digest']();return Di['encodeByteArray'](_0x5b4d87);},Bt=function(..._0x3fd5b3){let _0xe6bc79='';for(let _0x46fb74=0x0;_0x46fb74<_0x3fd5b3['length'];_0x46fb74++){const _0x2a4130=_0x3fd5b3[_0x46fb74];Array['isArray'](_0x2a4130)||_0x2a4130&&typeof _0x2a4130=='object'&&typeof _0x2a4130['length']=='number'?_0xe6bc79+=Bt['apply'](null,_0x2a4130):typeof _0x2a4130=='object'?_0xe6bc79+=O(_0x2a4130):_0xe6bc79+=_0x2a4130,_0xe6bc79+='\x20';}return _0xe6bc79;};let Et=null,Vs=!0x0;const Wl=function(_0x3abec6,_0x3ba379){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1e9008){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x554808=Bt['apply'](null,_0x1e9008);Et(_0x554808);}},Vt=function(_0x22c48b){return function(..._0x51f507){L(_0x22c48b,..._0x51f507);};},mi=function(..._0x347163){const _0x4722a2='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x347163);Qe['error'](_0x4722a2);},oe=function(..._0x2f3e58){const _0x62b3d1='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x2f3e58);throw Qe['error'](_0x62b3d1),new Error(_0x62b3d1);},U=function(..._0x4ce558){const _0xc84181='FIREBASE\x20WARNING:\x20'+Bt(..._0x4ce558);Qe['warn'](_0xc84181);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x3553b1){return typeof _0x3553b1=='number'&&(_0x3553b1!==_0x3553b1||_0x3553b1===Number['POSITIVE_INFINITY']||_0x3553b1===Number['NEGATIVE_INFINITY']);},Vl=function(_0xa125b5){if(document['readyState']==='complete')_0xa125b5();else{let _0x4f76dd=!0x1;const _0x486de0=function(){if(!document['body']){setTimeout(_0x486de0,Math['floor'](0xa));return;}_0x4f76dd||(_0x4f76dd=!0x0,_0xa125b5());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x486de0,!0x1),window['addEventListener']('load',_0x486de0,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x486de0();}),window['attachEvent']('onload',_0x486de0));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4e91a4,_0x2003a6){if(_0x4e91a4===_0x2003a6)return 0x0;if(_0x4e91a4===xe||_0x2003a6===Ie)return-0x1;if(_0x2003a6===xe||_0x4e91a4===Ie)return 0x1;{const _0x2c6150=Hs(_0x4e91a4),_0x59bfe3=Hs(_0x2003a6);return _0x2c6150!==null?_0x59bfe3!==null?_0x2c6150-_0x59bfe3===0x0?_0x4e91a4['length']-_0x2003a6['length']:_0x2c6150-_0x59bfe3:-0x1:_0x59bfe3!==null?0x1:_0x4e91a4<_0x2003a6?-0x1:0x1;}},Hl=function(_0x12bed6,_0x2dd4ac){return _0x12bed6===_0x2dd4ac?0x0:_0x12bed6<_0x2dd4ac?-0x1:0x1;},pt=function(_0x4eaea8,_0x50df1b){if(_0x50df1b&&_0x4eaea8 in _0x50df1b)return _0x50df1b[_0x4eaea8];throw new Error('Missing\x20required\x20key\x20('+_0x4eaea8+')\x20in\x20object:\x20'+O(_0x50df1b));},Bi=function(_0x2a3377){if(typeof _0x2a3377!='object'||_0x2a3377===null)return O(_0x2a3377);const _0x22777b=[];for(const _0x2076b0 in _0x2a3377)_0x22777b['push'](_0x2076b0);_0x22777b['sort']();let _0x6a0ff4='{';for(let _0x122e86=0x0;_0x122e86<_0x22777b['length'];_0x122e86++)_0x122e86!==0x0&&(_0x6a0ff4+=','),_0x6a0ff4+=O(_0x22777b[_0x122e86]),_0x6a0ff4+=':',_0x6a0ff4+=Bi(_0x2a3377[_0x22777b[_0x122e86]]);return _0x6a0ff4+='}',_0x6a0ff4;},io=function(_0x28b728,_0x56ca25){const _0x461e82=_0x28b728['length'];if(_0x461e82<=_0x56ca25)return[_0x28b728];const _0x3fc21e=[];for(let _0x2cead2=0x0;_0x2cead2<_0x461e82;_0x2cead2+=_0x56ca25)_0x2cead2+_0x56ca25>_0x461e82?_0x3fc21e['push'](_0x28b728['substring'](_0x2cead2,_0x461e82)):_0x3fc21e['push'](_0x28b728['substring'](_0x2cead2,_0x2cead2+_0x56ca25));return _0x3fc21e;};function x(_0x308240,_0x388517){for(const _0x3dfd2b in _0x308240)_0x308240['hasOwnProperty'](_0x3dfd2b)&&_0x388517(_0x3dfd2b,_0x308240[_0x3dfd2b]);}const so=function(_0x1337f8){f(!Wi(_0x1337f8),'Invalid\x20JSON\x20number');const _0x45fe30=0xb,_0x25cdf9=0x34,_0x42ed6a=(0x1<<_0x45fe30-0x1)-0x1;let _0x6df8eb,_0x3c28cb,_0x90b0a2,_0x3db593,_0x278ef0;_0x1337f8===0x0?(_0x3c28cb=0x0,_0x90b0a2=0x0,_0x6df8eb=0x1/_0x1337f8===-0x1/0x0?0x1:0x0):(_0x6df8eb=_0x1337f8<0x0,_0x1337f8=Math['abs'](_0x1337f8),_0x1337f8>=Math['pow'](0x2,0x1-_0x42ed6a)?(_0x3db593=Math['min'](Math['floor'](Math['log'](_0x1337f8)/Math['LN2']),_0x42ed6a),_0x3c28cb=_0x3db593+_0x42ed6a,_0x90b0a2=Math['round'](_0x1337f8*Math['pow'](0x2,_0x25cdf9-_0x3db593)-Math['pow'](0x2,_0x25cdf9))):(_0x3c28cb=0x0,_0x90b0a2=Math['round'](_0x1337f8/Math['pow'](0x2,0x1-_0x42ed6a-_0x25cdf9))));const _0x2e4f46=[];for(_0x278ef0=_0x25cdf9;_0x278ef0;_0x278ef0-=0x1)_0x2e4f46['push'](_0x90b0a2%0x2?0x1:0x0),_0x90b0a2=Math['floor'](_0x90b0a2/0x2);for(_0x278ef0=_0x45fe30;_0x278ef0;_0x278ef0-=0x1)_0x2e4f46['push'](_0x3c28cb%0x2?0x1:0x0),_0x3c28cb=Math['floor'](_0x3c28cb/0x2);_0x2e4f46['push'](_0x6df8eb?0x1:0x0),_0x2e4f46['reverse']();const _0x338aec=_0x2e4f46['join']('');let _0x5d4ff8='';for(_0x278ef0=0x0;_0x278ef0<0x40;_0x278ef0+=0x8){let _0x393751=parseInt(_0x338aec['substr'](_0x278ef0,0x8),0x2)['toString'](0x10);_0x393751['length']===0x1&&(_0x393751='0'+_0x393751),_0x5d4ff8=_0x5d4ff8+_0x393751;}return _0x5d4ff8['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x247860,_0x4df1e5){let _0x5e8b52='Unknown\x20Error';_0x247860==='too_big'?_0x5e8b52='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x247860==='permission_denied'?_0x5e8b52='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x247860==='unavailable'&&(_0x5e8b52='The\x20service\x20is\x20unavailable');const _0x3e6be0=new Error(_0x247860+'\x20at\x20'+_0x4df1e5['_path']['toString']()+':\x20'+_0x5e8b52);return _0x3e6be0['code']=_0x247860['toUpperCase'](),_0x3e6be0;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x554d78){if(zl['test'](_0x554d78)){const _0x25d1d8=Number(_0x554d78);if(_0x25d1d8>=jl&&_0x25d1d8<=Kl)return _0x25d1d8;}return null;},lt=function(_0x14d4bd){try{_0x14d4bd();}catch(_0x552094){setTimeout(()=>{const _0xe63eec=_0x552094['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xe63eec),_0x552094;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5130fe,_0x425028){const _0x3bc4e3=setTimeout(_0x5130fe,_0x425028);return typeof _0x3bc4e3=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3bc4e3):typeof _0x3bc4e3=='object'&&_0x3bc4e3['unref']&&_0x3bc4e3['unref'](),_0x3bc4e3;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x4c25cc,_0x205983){this['appCheckProvider']=_0x205983,this['appName']=_0x4c25cc['name'],H(_0x4c25cc)&&_0x4c25cc['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4c25cc['settings']['appCheckToken']),this['appCheck']=_0x205983==null?void 0x0:_0x205983['getImmediate']({'optional':!0x0}),this['appCheck']||_0x205983==null||_0x205983['get']()['then'](_0x6ae3b5=>this['appCheck']=_0x6ae3b5);}['getToken'](_0x2efc93){if(this['serverAppAppCheckToken']){if(_0x2efc93)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2efc93):new Promise((_0xee8f3b,_0x12467d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2efc93)['then'](_0xee8f3b,_0x12467d):_0xee8f3b(null);},0x0);});}['addTokenChangeListener'](_0x2505d7){var _0x38799e;(_0x38799e=this['appCheckProvider'])==null||_0x38799e['get']()['then'](_0x4e417c=>_0x4e417c['addTokenListener'](_0x2505d7));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x56f8c8,_0x52a7e3,_0x5c52c8){this['appName_']=_0x56f8c8,this['firebaseOptions_']=_0x52a7e3,this['authProvider_']=_0x5c52c8,this['auth_']=null,this['auth_']=_0x5c52c8['getImmediate']({'optional':!0x0}),this['auth_']||_0x5c52c8['onInit'](_0x287a83=>this['auth_']=_0x287a83);}['getToken'](_0x237095){return this['auth_']?this['auth_']['getToken'](_0x237095)['catch'](_0x3f9ef9=>_0x3f9ef9&&_0x3f9ef9['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3f9ef9)):new Promise((_0x509e7f,_0x1e6b8b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x237095)['then'](_0x509e7f,_0x1e6b8b):_0x509e7f(null);},0x0);});}['addTokenChangeListener'](_0x3f9c81){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3f9c81):this['authProvider_']['get']()['then'](_0x19489d=>_0x19489d['addAuthTokenListener'](_0x3f9c81));}['removeTokenChangeListener'](_0x1f0287){this['authProvider_']['get']()['then'](_0x5548d8=>_0x5548d8['removeAuthTokenListener'](_0x1f0287));}['notifyForInvalidToken'](){let _0x269d94='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x269d94+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x269d94+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x269d94+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x269d94);}}class tn{constructor(_0x10cd5d){this['accessToken']=_0x10cd5d;}['getToken'](_0x1def34){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x35993a){_0x35993a(this['accessToken']);}['removeTokenChangeListener'](_0x239e02){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x268c7b,_0x26c916,_0x1334df,_0x172fe5,_0x3a8cc8=!0x1,_0x9d79be='',_0xe96c19=!0x1,_0x11161b=!0x1,_0x313228=null){this['secure']=_0x26c916,this['namespace']=_0x1334df,this['webSocketOnly']=_0x172fe5,this['nodeAdmin']=_0x3a8cc8,this['persistenceKey']=_0x9d79be,this['includeNamespaceInQueryParams']=_0xe96c19,this['isUsingEmulator']=_0x11161b,this['emulatorOptions']=_0x313228,this['_host']=_0x268c7b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x268c7b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2b0ca2){_0x2b0ca2!==this['internalHost']&&(this['internalHost']=_0x2b0ca2,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x416f99=this['toURLString']();return this['persistenceKey']&&(_0x416f99+='<'+this['persistenceKey']+'>'),_0x416f99;}['toURLString'](){const _0x2ddcd0=this['secure']?'https://':'http://',_0x34fbf4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2ddcd0+this['host']+'/'+_0x34fbf4;}}function Xl(_0x181e89){return _0x181e89['host']!==_0x181e89['internalHost']||_0x181e89['isCustomHost']()||_0x181e89['includeNamespaceInQueryParams'];}function go(_0x2e49fd,_0x2721b2,_0x3000eb){f(typeof _0x2721b2=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3000eb=='object','typeof\x20params\x20must\x20==\x20object');let _0x238a38;if(_0x2721b2===fo)_0x238a38=(_0x2e49fd['secure']?'wss://':'ws://')+_0x2e49fd['internalHost']+'/.ws?';else{if(_0x2721b2===po)_0x238a38=(_0x2e49fd['secure']?'https://':'http://')+_0x2e49fd['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2721b2);}Xl(_0x2e49fd)&&(_0x3000eb['ns']=_0x2e49fd['namespace']);const _0x16a278=[];return x(_0x3000eb,(_0x476695,_0x4aea2e)=>{_0x16a278['push'](_0x476695+'='+_0x4aea2e);}),_0x238a38+_0x16a278['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x453d07,_0x196b21=0x1){Y(this['counters_'],_0x453d07)||(this['counters_'][_0x453d07]=0x0),this['counters_'][_0x453d07]+=_0x196b21;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x3ef39d){const _0x39aa0c=_0x3ef39d['toString']();return ti[_0x39aa0c]||(ti[_0x39aa0c]=new Zl()),ti[_0x39aa0c];}function eh(_0x1b89fe,_0x10c03e){const _0x565c3a=_0x1b89fe['toString']();return ni[_0x565c3a]||(ni[_0x565c3a]=_0x10c03e()),ni[_0x565c3a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x147677){this['onMessage_']=_0x147677,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x578b58,_0x2c915f){this['closeAfterResponse']=_0x578b58,this['onClose']=_0x2c915f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5d4126,_0x556dd4){for(this['pendingResponses'][_0x5d4126]=_0x556dd4;this['pendingResponses'][this['currentResponseNum']];){const _0x163546=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x56368a=0x0;_0x56368a<_0x163546['length'];++_0x56368a)_0x163546[_0x56368a]&&lt(()=>{this['onMessage_'](_0x163546[_0x56368a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2db088,_0x35ed4b,_0x3714bf,_0x3a8f24,_0x45bfd6,_0x1a45c4,_0x491809){this['connId']=_0x2db088,this['repoInfo']=_0x35ed4b,this['applicationId']=_0x3714bf,this['appCheckToken']=_0x3a8f24,this['authToken']=_0x45bfd6,this['transportSessionId']=_0x1a45c4,this['lastSessionId']=_0x491809,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2db088),this['stats_']=Hi(_0x35ed4b),this['urlFn']=_0x1087db=>(this['appCheckToken']&&(_0x1087db[yi]=this['appCheckToken']),go(_0x35ed4b,po,_0x1087db));}['open'](_0x4456aa,_0x3ce663){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3ce663,this['myPacketOrderer']=new th(_0x4456aa),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x6ed632)=>{const [_0x2472f5,_0x329d31,_0xfa30e0,_0xbf984a,_0x4a41]=_0x6ed632;if(this['incrementIncomingBytes_'](_0x6ed632),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2472f5===$s)this['id']=_0x329d31,this['password']=_0xfa30e0;else{if(_0x2472f5===nh)_0x329d31?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x329d31,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2472f5);}}},(..._0x3421b0)=>{const [_0x355b9a,_0x345fb7]=_0x3421b0;this['incrementIncomingBytes_'](_0x3421b0),this['myPacketOrderer']['handleResponse'](_0x355b9a,_0x345fb7);},()=>{this['onClosed_']();},this['urlFn']);const _0x18b957={};_0x18b957[$s]='t',_0x18b957[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x18b957[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x18b957[ro]=Vi,this['transportSessionId']&&(_0x18b957[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x18b957[ho]=this['lastSessionId']),this['applicationId']&&(_0x18b957[uo]=this['applicationId']),this['appCheckToken']&&(_0x18b957[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x18b957[ao]=co);const _0x172081=this['urlFn'](_0x18b957);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x172081),this['scriptTagHolder']['addTag'](_0x172081,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x38d012){const _0x266075=O(_0x38d012);this['bytesSent']+=_0x266075['length'],this['stats_']['incrementCounter']('bytes_sent',_0x266075['length']);const _0x15ed9f=Br(_0x266075),_0x243bbb=io(_0x15ed9f,hh);for(let _0x5905ac=0x0;_0x5905ac<_0x243bbb['length'];_0x5905ac++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x243bbb['length'],_0x243bbb[_0x5905ac]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x738403,_0x40232f){this['myDisconnFrame']=document['createElement']('iframe');const _0x2c2d72={};_0x2c2d72[lh]='t',_0x2c2d72[mo]=_0x738403,_0x2c2d72[yo]=_0x40232f,this['myDisconnFrame']['src']=this['urlFn'](_0x2c2d72),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x563d3d){const _0x11cbb0=O(_0x563d3d)['length'];this['bytesReceived']+=_0x11cbb0,this['stats_']['incrementCounter']('bytes_received',_0x11cbb0);}}class $i{constructor(_0x424a8b,_0x12b306,_0x3c9a5d,_0x4c088d){this['onDisconnect']=_0x3c9a5d,this['urlFn']=_0x4c088d,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x424a8b,window[sh+this['uniqueCallbackIdentifier']]=_0x12b306,this['myIFrame']=$i['createIFrame_']();let _0x58b041='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x58b041='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1a5cc8='<html><body>'+_0x58b041+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1a5cc8),this['myIFrame']['doc']['close']();}catch(_0x3854ea){L('frame\x20writing\x20exception'),_0x3854ea['stack']&&L(_0x3854ea['stack']),L(_0x3854ea);}}}static['createIFrame_'](){const _0x2380c7=document['createElement']('iframe');if(_0x2380c7['style']['display']='none',document['body']){document['body']['appendChild'](_0x2380c7);try{_0x2380c7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4c3048=document['domain'];_0x2380c7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4c3048+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2380c7['contentDocument']?_0x2380c7['doc']=_0x2380c7['contentDocument']:_0x2380c7['contentWindow']?_0x2380c7['doc']=_0x2380c7['contentWindow']['document']:_0x2380c7['document']&&(_0x2380c7['doc']=_0x2380c7['document']),_0x2380c7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x35e8e6=this['onDisconnect'];_0x35e8e6&&(this['onDisconnect']=null,_0x35e8e6());}['startLongPoll'](_0x3e82e3,_0x3dd3f2){for(this['myID']=_0x3e82e3,this['myPW']=_0x3dd3f2,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x100425={};_0x100425[mo]=this['myID'],_0x100425[yo]=this['myPW'],_0x100425[vo]=this['currentSerial'];let _0x1510d4=this['urlFn'](_0x100425),_0x16b2ea='',_0x11f140=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x16b2ea['length']<=Eo;){const _0x2f270f=this['pendingSegs']['shift']();_0x16b2ea=_0x16b2ea+'&'+oh+_0x11f140+'='+_0x2f270f['seg']+'&'+ah+_0x11f140+'='+_0x2f270f['ts']+'&'+ch+_0x11f140+'='+_0x2f270f['d'],_0x11f140++;}return _0x1510d4=_0x1510d4+_0x16b2ea,this['addLongPollTag_'](_0x1510d4,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xe24cd6,_0x21a771,_0x28459d){this['pendingSegs']['push']({'seg':_0xe24cd6,'ts':_0x21a771,'d':_0x28459d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xab9136,_0x1c7f5c){this['outstandingRequests']['add'](_0x1c7f5c);const _0x5c2654=()=>{this['outstandingRequests']['delete'](_0x1c7f5c),this['newRequest_']();},_0x23487e=setTimeout(_0x5c2654,Math['floor'](uh)),_0xeac53=()=>{clearTimeout(_0x23487e),_0x5c2654();};this['addTag'](_0xab9136,_0xeac53);}['addTag'](_0x37a6d1,_0x4ee119){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5b8270=this['myIFrame']['doc']['createElement']('script');_0x5b8270['type']='text/javascript',_0x5b8270['async']=!0x0,_0x5b8270['src']=_0x37a6d1,_0x5b8270['onload']=_0x5b8270['onreadystatechange']=function(){const _0x2aebe6=_0x5b8270['readyState'];(!_0x2aebe6||_0x2aebe6==='loaded'||_0x2aebe6==='complete')&&(_0x5b8270['onload']=_0x5b8270['onreadystatechange']=null,_0x5b8270['parentNode']&&_0x5b8270['parentNode']['removeChild'](_0x5b8270),_0x4ee119());},_0x5b8270['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x37a6d1),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5b8270);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1dc352,_0x357c06,_0x4a42c6,_0x1900e9,_0x2643bc,_0x306b82,_0x4f8322){this['connId']=_0x1dc352,this['applicationId']=_0x4a42c6,this['appCheckToken']=_0x1900e9,this['authToken']=_0x2643bc,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x357c06),this['connURL']=G['connectionURL_'](_0x357c06,_0x306b82,_0x4f8322,_0x1900e9,_0x4a42c6),this['nodeAdmin']=_0x357c06['nodeAdmin'];}static['connectionURL_'](_0x24302b,_0x184720,_0x20cc7f,_0x4103a3,_0x488138){const _0xc0b0cf={};return _0xc0b0cf[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xc0b0cf[ao]=co),_0x184720&&(_0xc0b0cf[oo]=_0x184720),_0x20cc7f&&(_0xc0b0cf[ho]=_0x20cc7f),_0x4103a3&&(_0xc0b0cf[yi]=_0x4103a3),_0x488138&&(_0xc0b0cf[uo]=_0x488138),go(_0x24302b,fo,_0xc0b0cf);}['open'](_0x12725b,_0x530aa4){this['onDisconnect']=_0x530aa4,this['onMessage']=_0x12725b,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x378c99;dc(),this['mySock']=new hn(this['connURL'],[],_0x378c99);}catch(_0x21d9e6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3f35e1=_0x21d9e6['message']||_0x21d9e6['data'];_0x3f35e1&&this['log_'](_0x3f35e1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3caec9=>{this['handleIncomingFrame'](_0x3caec9);},this['mySock']['onerror']=_0x3f668e=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xa92504=_0x3f668e['message']||_0x3f668e['data'];_0xa92504&&this['log_'](_0xa92504),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xe5517f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3afe04=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4eb044=navigator['userAgent']['match'](_0x3afe04);_0x4eb044&&_0x4eb044['length']>0x1&&parseFloat(_0x4eb044[0x1])<4.4&&(_0xe5517f=!0x0);}return!_0xe5517f&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5359ca){if(this['frames']['push'](_0x5359ca),this['frames']['length']===this['totalFrames']){const _0x18bf5f=this['frames']['join']('');this['frames']=null;const _0x119ca8=bt(_0x18bf5f);this['onMessage'](_0x119ca8);}}['handleNewFrameCount_'](_0x51bb7f){this['totalFrames']=_0x51bb7f,this['frames']=[];}['extractFrameCount_'](_0x3e5c8c){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3e5c8c['length']<=0x6){const _0x3cfcbd=Number(_0x3e5c8c);if(!isNaN(_0x3cfcbd))return this['handleNewFrameCount_'](_0x3cfcbd),null;}return this['handleNewFrameCount_'](0x1),_0x3e5c8c;}['handleIncomingFrame'](_0x4e8d21){if(this['mySock']===null)return;const _0x264540=_0x4e8d21['data'];if(this['bytesReceived']+=_0x264540['length'],this['stats_']['incrementCounter']('bytes_received',_0x264540['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x264540);else{const _0x4d7a52=this['extractFrameCount_'](_0x264540);_0x4d7a52!==null&&this['appendFrame_'](_0x4d7a52);}}['send'](_0x1052b3){this['resetKeepAlive']();const _0x72dfbe=O(_0x1052b3);this['bytesSent']+=_0x72dfbe['length'],this['stats_']['incrementCounter']('bytes_sent',_0x72dfbe['length']);const _0x1babbd=io(_0x72dfbe,fh);_0x1babbd['length']>0x1&&this['sendString_'](String(_0x1babbd['length']));for(let _0x1eed60=0x0;_0x1eed60<_0x1babbd['length'];_0x1eed60++)this['sendString_'](_0x1babbd[_0x1eed60]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x470e99){try{this['mySock']['send'](_0x470e99);}catch(_0x233329){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x233329['message']||_0x233329['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4ddc43){this['initTransports_'](_0x4ddc43);}['initTransports_'](_0x2c2e05){const _0x3c9b93=G&&G['isAvailable']();let _0x1c7a7a=_0x3c9b93&&!G['previouslyFailed']();if(_0x2c2e05['webSocketOnly']&&(_0x3c9b93||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1c7a7a=!0x0),_0x1c7a7a)this['transports_']=[G];else{const _0xb0df9a=this['transports_']=[];for(const _0xaa9fd3 of At['ALL_TRANSPORTS'])_0xaa9fd3&&_0xaa9fd3['isAvailable']()&&_0xb0df9a['push'](_0xaa9fd3);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x30c882,_0x55a5e2,_0x17a580,_0x582216,_0x3763c6,_0x3882bd,_0x28c02a,_0x36ca80,_0x12a761,_0x607587){this['id']=_0x30c882,this['repoInfo_']=_0x55a5e2,this['applicationId_']=_0x17a580,this['appCheckToken_']=_0x582216,this['authToken_']=_0x3763c6,this['onMessage_']=_0x3882bd,this['onReady_']=_0x28c02a,this['onDisconnect_']=_0x36ca80,this['onKill_']=_0x12a761,this['lastSessionId']=_0x607587,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x55a5e2),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x460a1d=this['transportManager_']['initialTransport']();this['conn_']=new _0x460a1d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x460a1d['responsesRequiredToBeHealthy']||0x0;const _0x2ca14e=this['connReceiver_'](this['conn_']),_0x2bdf62=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2ca14e,_0x2bdf62);},Math['floor'](0x0));const _0x2d8996=_0x460a1d['healthyTimeout']||0x0;_0x2d8996>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2d8996)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3f91d1){return _0x34af07=>{_0x3f91d1===this['conn_']?this['onConnectionLost_'](_0x34af07):_0x3f91d1===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x43e700){return _0x5615f2=>{this['state_']!==0x2&&(_0x43e700===this['rx_']?this['onPrimaryMessageReceived_'](_0x5615f2):_0x43e700===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5615f2):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5ae251){const _0x5475b2={'t':'d','d':_0x5ae251};this['sendData_'](_0x5475b2);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x27a935){if(ii in _0x27a935){const _0x5d8b36=_0x27a935[ii];_0x5d8b36===js?this['upgradeIfSecondaryHealthy_']():_0x5d8b36===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5d8b36===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4dc6ec){const _0x488745=pt('t',_0x4dc6ec),_0x1ad566=pt('d',_0x4dc6ec);if(_0x488745==='c')this['onSecondaryControl_'](_0x1ad566);else{if(_0x488745==='d')this['pendingDataMessages']['push'](_0x1ad566);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x488745);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x16bfa0){const _0x5e7406=pt('t',_0x16bfa0),_0x47dbd5=pt('d',_0x16bfa0);_0x5e7406==='c'?this['onControl_'](_0x47dbd5):_0x5e7406==='d'&&this['onDataMessage_'](_0x47dbd5);}['onDataMessage_'](_0x2b2e77){this['onPrimaryResponse_'](),this['onMessage_'](_0x2b2e77);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x26e04e){const _0x1c448e=pt(ii,_0x26e04e);if(Gs in _0x26e04e){const _0x5aaa99=_0x26e04e[Gs];if(_0x1c448e===Ih){const _0x5ae2e7={..._0x5aaa99};this['repoInfo_']['isUsingEmulator']&&(_0x5ae2e7['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5ae2e7);}else{if(_0x1c448e===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3924fd=0x0;_0x3924fd<this['pendingDataMessages']['length'];++_0x3924fd)this['onDataMessage_'](this['pendingDataMessages'][_0x3924fd]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1c448e===vh?this['onConnectionShutdown_'](_0x5aaa99):_0x1c448e===qs?this['onReset_'](_0x5aaa99):_0x1c448e===Eh?mi('Server\x20Error:\x20'+_0x5aaa99):_0x1c448e===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x1c448e);}}}['onHandshake_'](_0x4290a5){const _0x3177c5=_0x4290a5['ts'],_0x551a16=_0x4290a5['v'],_0x78913a=_0x4290a5['h'];this['sessionId']=_0x4290a5['s'],this['repoInfo_']['host']=_0x78913a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3177c5),Vi!==_0x551a16&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x17744a=this['transportManager_']['upgradeTransport']();_0x17744a&&this['startUpgrade_'](_0x17744a);}['startUpgrade_'](_0x1d11ec){this['secondaryConn_']=new _0x1d11ec(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1d11ec['responsesRequiredToBeHealthy']||0x0;const _0x361932=this['connReceiver_'](this['secondaryConn_']),_0x14f5cd=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x361932,_0x14f5cd),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2fac89){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2fac89),this['repoInfo_']['host']=_0x2fac89,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0xa764c9,_0x374d52){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0xa764c9,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x374d52,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xc92151=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xc92151||this['rx_']===_0xc92151)&&this['close']();}['onConnectionLost_'](_0x2c9820){this['conn_']=null,!_0x2c9820&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x32037e){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x32037e),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x117e3c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x117e3c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x25333a,_0x58ca61,_0x2571de,_0x3d3fd9){}['merge'](_0x33b8cc,_0x409b69,_0x579382,_0x149a73){}['refreshAuthToken'](_0x328d7a){}['refreshAppCheckToken'](_0x260a92){}['onDisconnectPut'](_0x125ca6,_0x1600be,_0x25ee64){}['onDisconnectMerge'](_0x3f58ba,_0x496625,_0x517f9d){}['onDisconnectCancel'](_0x46bd82,_0x6e5d47){}['reportStats'](_0x1c874){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x54ba7d){this['allowedEvents_']=_0x54ba7d,this['listeners_']={},f(Array['isArray'](_0x54ba7d)&&_0x54ba7d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x34dd77,..._0xec0d04){if(Array['isArray'](this['listeners_'][_0x34dd77])){const _0x15d325=[...this['listeners_'][_0x34dd77]];for(let _0xcf7e11=0x0;_0xcf7e11<_0x15d325['length'];_0xcf7e11++)_0x15d325[_0xcf7e11]['callback']['apply'](_0x15d325[_0xcf7e11]['context'],_0xec0d04);}}['on'](_0x45cd2f,_0x5a5cca,_0x142cf3){this['validateEventType_'](_0x45cd2f),this['listeners_'][_0x45cd2f]=this['listeners_'][_0x45cd2f]||[],this['listeners_'][_0x45cd2f]['push']({'callback':_0x5a5cca,'context':_0x142cf3});const _0x3ad515=this['getInitialEvent'](_0x45cd2f);_0x3ad515&&_0x5a5cca['apply'](_0x142cf3,_0x3ad515);}['off'](_0x507ea5,_0x593642,_0x3f1937){this['validateEventType_'](_0x507ea5);const _0x12a0e3=this['listeners_'][_0x507ea5]||[];for(let _0x263765=0x0;_0x263765<_0x12a0e3['length'];_0x263765++)if(_0x12a0e3[_0x263765]['callback']===_0x593642&&(!_0x3f1937||_0x3f1937===_0x12a0e3[_0x263765]['context'])){_0x12a0e3['splice'](_0x263765,0x1);return;}}['validateEventType_'](_0x8a17bf){f(this['allowedEvents_']['find'](_0x5a9e77=>_0x5a9e77===_0x8a17bf),'Unknown\x20event:\x20'+_0x8a17bf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5ea969){return f(_0x5ea969==='online','Unknown\x20event\x20type:\x20'+_0x5ea969),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x42681d,_0x28c7ce){if(_0x28c7ce===void 0x0){this['pieces_']=_0x42681d['split']('/');let _0x3269e3=0x0;for(let _0x4512a5=0x0;_0x4512a5<this['pieces_']['length'];_0x4512a5++)this['pieces_'][_0x4512a5]['length']>0x0&&(this['pieces_'][_0x3269e3]=this['pieces_'][_0x4512a5],_0x3269e3++);this['pieces_']['length']=_0x3269e3,this['pieceNum_']=0x0;}else this['pieces_']=_0x42681d,this['pieceNum_']=_0x28c7ce;}['toString'](){let _0x29fd77='';for(let _0x24cd86=this['pieceNum_'];_0x24cd86<this['pieces_']['length'];_0x24cd86++)this['pieces_'][_0x24cd86]!==''&&(_0x29fd77+='/'+this['pieces_'][_0x24cd86]);return _0x29fd77||'/';}}function w(){return new C('');}function y(_0x5f2443){return _0x5f2443['pieceNum_']>=_0x5f2443['pieces_']['length']?null:_0x5f2443['pieces_'][_0x5f2443['pieceNum_']];}function we(_0x2009de){return _0x2009de['pieces_']['length']-_0x2009de['pieceNum_'];}function b(_0x2fa428){let _0x14ff92=_0x2fa428['pieceNum_'];return _0x14ff92<_0x2fa428['pieces_']['length']&&_0x14ff92++,new C(_0x2fa428['pieces_'],_0x14ff92);}function Gi(_0x531930){return _0x531930['pieceNum_']<_0x531930['pieces_']['length']?_0x531930['pieces_'][_0x531930['pieces_']['length']-0x1]:null;}function Ch(_0x34567e){let _0x3c42c1='';for(let _0x2b1209=_0x34567e['pieceNum_'];_0x2b1209<_0x34567e['pieces_']['length'];_0x2b1209++)_0x34567e['pieces_'][_0x2b1209]!==''&&(_0x3c42c1+='/'+encodeURIComponent(String(_0x34567e['pieces_'][_0x2b1209])));return _0x3c42c1||'/';}function kt(_0x2ad429,_0x1ff6a1=0x0){return _0x2ad429['pieces_']['slice'](_0x2ad429['pieceNum_']+_0x1ff6a1);}function To(_0x27c9a9){if(_0x27c9a9['pieceNum_']>=_0x27c9a9['pieces_']['length'])return null;const _0x3bcd88=[];for(let _0x16b75a=_0x27c9a9['pieceNum_'];_0x16b75a<_0x27c9a9['pieces_']['length']-0x1;_0x16b75a++)_0x3bcd88['push'](_0x27c9a9['pieces_'][_0x16b75a]);return new C(_0x3bcd88,0x0);}function A(_0x25ceac,_0x460614){const _0x4cfb4a=[];for(let _0x2b8924=_0x25ceac['pieceNum_'];_0x2b8924<_0x25ceac['pieces_']['length'];_0x2b8924++)_0x4cfb4a['push'](_0x25ceac['pieces_'][_0x2b8924]);if(_0x460614 instanceof C){for(let _0x2a22af=_0x460614['pieceNum_'];_0x2a22af<_0x460614['pieces_']['length'];_0x2a22af++)_0x4cfb4a['push'](_0x460614['pieces_'][_0x2a22af]);}else{const _0x3ecb96=_0x460614['split']('/');for(let _0xb287f7=0x0;_0xb287f7<_0x3ecb96['length'];_0xb287f7++)_0x3ecb96[_0xb287f7]['length']>0x0&&_0x4cfb4a['push'](_0x3ecb96[_0xb287f7]);}return new C(_0x4cfb4a,0x0);}function v(_0x578d2a){return _0x578d2a['pieceNum_']>=_0x578d2a['pieces_']['length'];}function F(_0x25b9b3,_0x415c0f){const _0x294d35=y(_0x25b9b3),_0x4f3672=y(_0x415c0f);if(_0x294d35===null)return _0x415c0f;if(_0x294d35===_0x4f3672)return F(b(_0x25b9b3),b(_0x415c0f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x415c0f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x25b9b3+')');}function Th(_0x4d2297,_0x4109af){const _0x4b5772=kt(_0x4d2297,0x0),_0x1dced0=kt(_0x4109af,0x0);for(let _0x4651af=0x0;_0x4651af<_0x4b5772['length']&&_0x4651af<_0x1dced0['length'];_0x4651af++){const _0x54baaa=He(_0x4b5772[_0x4651af],_0x1dced0[_0x4651af]);if(_0x54baaa!==0x0)return _0x54baaa;}return _0x4b5772['length']===_0x1dced0['length']?0x0:_0x4b5772['length']<_0x1dced0['length']?-0x1:0x1;}function qi(_0x139ea9,_0x4d66a7){if(we(_0x139ea9)!==we(_0x4d66a7))return!0x1;for(let _0x5942ed=_0x139ea9['pieceNum_'],_0x18b15f=_0x4d66a7['pieceNum_'];_0x5942ed<=_0x139ea9['pieces_']['length'];_0x5942ed++,_0x18b15f++)if(_0x139ea9['pieces_'][_0x5942ed]!==_0x4d66a7['pieces_'][_0x18b15f])return!0x1;return!0x0;}function $(_0x17d87c,_0x22c5e8){let _0x30ec53=_0x17d87c['pieceNum_'],_0x27583f=_0x22c5e8['pieceNum_'];if(we(_0x17d87c)>we(_0x22c5e8))return!0x1;for(;_0x30ec53<_0x17d87c['pieces_']['length'];){if(_0x17d87c['pieces_'][_0x30ec53]!==_0x22c5e8['pieces_'][_0x27583f])return!0x1;++_0x30ec53,++_0x27583f;}return!0x0;}class Sh{constructor(_0x12e893,_0x42fcef){this['errorPrefix_']=_0x42fcef,this['parts_']=kt(_0x12e893,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x574e9e=0x0;_0x574e9e<this['parts_']['length'];_0x574e9e++)this['byteLength_']+=Pn(this['parts_'][_0x574e9e]);So(this);}}function bh(_0x6a18e2,_0x311a48){_0x6a18e2['parts_']['length']>0x0&&(_0x6a18e2['byteLength_']+=0x1),_0x6a18e2['parts_']['push'](_0x311a48),_0x6a18e2['byteLength_']+=Pn(_0x311a48),So(_0x6a18e2);}function Rh(_0xcfd6fb){const _0x312e01=_0xcfd6fb['parts_']['pop']();_0xcfd6fb['byteLength_']-=Pn(_0x312e01),_0xcfd6fb['parts_']['length']>0x0&&(_0xcfd6fb['byteLength_']-=0x1);}function So(_0x628500){if(_0x628500['byteLength_']>Js)throw new Error(_0x628500['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x628500['byteLength_']+').');if(_0x628500['parts_']['length']>Qs)throw new Error(_0x628500['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x628500));}function Ne(_0x223eb7){return _0x223eb7['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x223eb7['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0xba5b0c,_0xcdfd9;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xcdfd9='visibilitychange',_0xba5b0c='hidden'):typeof document['mozHidden']<'u'?(_0xcdfd9='mozvisibilitychange',_0xba5b0c='mozHidden'):typeof document['msHidden']<'u'?(_0xcdfd9='msvisibilitychange',_0xba5b0c='msHidden'):typeof document['webkitHidden']<'u'&&(_0xcdfd9='webkitvisibilitychange',_0xba5b0c='webkitHidden')),this['visible_']=!0x0,_0xcdfd9&&document['addEventListener'](_0xcdfd9,()=>{const _0x155b35=!document[_0xba5b0c];_0x155b35!==this['visible_']&&(this['visible_']=_0x155b35,this['trigger']('visible',_0x155b35));},!0x1);}['getInitialEvent'](_0xc83980){return f(_0xc83980==='visible','Unknown\x20event\x20type:\x20'+_0xc83980),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x574e44,_0x23ffc8,_0x53a798,_0x92c9ea,_0x4cea7f,_0x4b87ad,_0x4a146c,_0xbbd0fc){if(super(),this['repoInfo_']=_0x574e44,this['applicationId_']=_0x23ffc8,this['onDataUpdate_']=_0x53a798,this['onConnectStatus_']=_0x92c9ea,this['onServerInfoUpdate_']=_0x4cea7f,this['authTokenProvider_']=_0x4b87ad,this['appCheckTokenProvider_']=_0x4a146c,this['authOverride_']=_0xbbd0fc,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xbbd0fc)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x574e44['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x416426,_0x2b5390,_0x25cc29){const _0x3e8605=++this['requestNumber_'],_0x2484c9={'r':_0x3e8605,'a':_0x416426,'b':_0x2b5390};this['log_'](O(_0x2484c9)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2484c9),_0x25cc29&&(this['requestCBHash_'][_0x3e8605]=_0x25cc29);}['get'](_0x1f9204){this['initConnection_']();const _0x48a685=new Ve(),_0x37bb64={'action':'g','request':{'p':_0x1f9204['_path']['toString'](),'q':_0x1f9204['_queryObject']},'onComplete':_0x31e2a7=>{const _0x1d9b24=_0x31e2a7['d'];_0x31e2a7['s']==='ok'?_0x48a685['resolve'](_0x1d9b24):_0x48a685['reject'](_0x1d9b24);}};this['outstandingGets_']['push'](_0x37bb64),this['outstandingGetCount_']++;const _0x59b811=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x59b811),_0x48a685['promise'];}['listen'](_0x5cde17,_0x12afac,_0x1a290c,_0x18ac3f){this['initConnection_']();const _0x124990=_0x5cde17['_queryIdentifier'],_0x10dd6e=_0x5cde17['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x10dd6e+'\x20'+_0x124990),this['listens']['has'](_0x10dd6e)||this['listens']['set'](_0x10dd6e,new Map()),f(_0x5cde17['_queryParams']['isDefault']()||!_0x5cde17['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x10dd6e)['has'](_0x124990),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x209a8e={'onComplete':_0x18ac3f,'hashFn':_0x12afac,'query':_0x5cde17,'tag':_0x1a290c};this['listens']['get'](_0x10dd6e)['set'](_0x124990,_0x209a8e),this['connected_']&&this['sendListen_'](_0x209a8e);}['sendGet_'](_0x4d9a88){const _0x35f3a3=this['outstandingGets_'][_0x4d9a88];this['sendRequest']('g',_0x35f3a3['request'],_0x126849=>{delete this['outstandingGets_'][_0x4d9a88],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x35f3a3['onComplete']&&_0x35f3a3['onComplete'](_0x126849);});}['sendListen_'](_0x38fa0f){const _0x24f366=_0x38fa0f['query'],_0x268597=_0x24f366['_path']['toString'](),_0x2280ff=_0x24f366['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x268597+'\x20for\x20'+_0x2280ff);const _0x3d5195={'p':_0x268597},_0x20b726='q';_0x38fa0f['tag']&&(_0x3d5195['q']=_0x24f366['_queryObject'],_0x3d5195['t']=_0x38fa0f['tag']),_0x3d5195['h']=_0x38fa0f['hashFn'](),this['sendRequest'](_0x20b726,_0x3d5195,_0x298e07=>{const _0x3a7e6a=_0x298e07['d'],_0x209418=_0x298e07['s'];ie['warnOnListenWarnings_'](_0x3a7e6a,_0x24f366),(this['listens']['get'](_0x268597)&&this['listens']['get'](_0x268597)['get'](_0x2280ff))===_0x38fa0f&&(this['log_']('listen\x20response',_0x298e07),_0x209418!=='ok'&&this['removeListen_'](_0x268597,_0x2280ff),_0x38fa0f['onComplete']&&_0x38fa0f['onComplete'](_0x209418,_0x3a7e6a));});}static['warnOnListenWarnings_'](_0x392646,_0x5d4798){if(_0x392646&&typeof _0x392646=='object'&&Y(_0x392646,'w')){const _0x44811f=Oe(_0x392646,'w');if(Array['isArray'](_0x44811f)&&~_0x44811f['indexOf']('no_index')){const _0x34d367='\x22.indexOn\x22:\x20\x22'+_0x5d4798['_queryParams']['getIndex']()['toString']()+'\x22',_0x2c2747=_0x5d4798['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x34d367+'\x20at\x20'+_0x2c2747+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x217351){this['authToken_']=_0x217351,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x217351);}['reduceReconnectDelayIfAdminCredential_'](_0x4e2b16){(_0x4e2b16&&_0x4e2b16['length']===0x28||vc(_0x4e2b16))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x3ba93a){this['appCheckToken_']=_0x3ba93a,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x160494=this['authToken_'],_0x2ead82=yc(_0x160494)?'auth':'gauth',_0x49a312={'cred':_0x160494};this['authOverride_']===null?_0x49a312['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x49a312['authvar']=this['authOverride_']),this['sendRequest'](_0x2ead82,_0x49a312,_0x1fdf8e=>{const _0x2963a5=_0x1fdf8e['s'],_0x553f19=_0x1fdf8e['d']||'error';this['authToken_']===_0x160494&&(_0x2963a5==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2963a5,_0x553f19));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5c03f3=>{const _0x28c6b8=_0x5c03f3['s'],_0x49f130=_0x5c03f3['d']||'error';_0x28c6b8==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x28c6b8,_0x49f130);});}['unlisten'](_0x1fbf6c,_0x1e931d){const _0x3482ce=_0x1fbf6c['_path']['toString'](),_0x7ce3d6=_0x1fbf6c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3482ce+'\x20'+_0x7ce3d6),f(_0x1fbf6c['_queryParams']['isDefault']()||!_0x1fbf6c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3482ce,_0x7ce3d6)&&this['connected_']&&this['sendUnlisten_'](_0x3482ce,_0x7ce3d6,_0x1fbf6c['_queryObject'],_0x1e931d);}['sendUnlisten_'](_0x20219c,_0x4cd301,_0xeb05d0,_0x54f3bb){this['log_']('Unlisten\x20on\x20'+_0x20219c+'\x20for\x20'+_0x4cd301);const _0x1dc8cc={'p':_0x20219c},_0xf2d43d='n';_0x54f3bb&&(_0x1dc8cc['q']=_0xeb05d0,_0x1dc8cc['t']=_0x54f3bb),this['sendRequest'](_0xf2d43d,_0x1dc8cc);}['onDisconnectPut'](_0x4c1333,_0x1d3ac4,_0x1299ce){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4c1333,_0x1d3ac4,_0x1299ce):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4c1333,'action':'o','data':_0x1d3ac4,'onComplete':_0x1299ce});}['onDisconnectMerge'](_0x20a0bc,_0x826a60,_0x2d2ffc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x20a0bc,_0x826a60,_0x2d2ffc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x20a0bc,'action':'om','data':_0x826a60,'onComplete':_0x2d2ffc});}['onDisconnectCancel'](_0xe07f4a,_0x4b3327){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xe07f4a,null,_0x4b3327):this['onDisconnectRequestQueue_']['push']({'pathString':_0xe07f4a,'action':'oc','data':null,'onComplete':_0x4b3327});}['sendOnDisconnect_'](_0x1a91aa,_0x46fdb4,_0x5549b8,_0x2d03d8){const _0x126c9a={'p':_0x46fdb4,'d':_0x5549b8};this['log_']('onDisconnect\x20'+_0x1a91aa,_0x126c9a),this['sendRequest'](_0x1a91aa,_0x126c9a,_0x49f4b2=>{_0x2d03d8&&setTimeout(()=>{_0x2d03d8(_0x49f4b2['s'],_0x49f4b2['d']);},Math['floor'](0x0));});}['put'](_0xedc92d,_0x470b92,_0x205570,_0x5e8c00){this['putInternal']('p',_0xedc92d,_0x470b92,_0x205570,_0x5e8c00);}['merge'](_0x5d8958,_0x3f0ce2,_0x1cbf79,_0x281bfb){this['putInternal']('m',_0x5d8958,_0x3f0ce2,_0x1cbf79,_0x281bfb);}['putInternal'](_0x5cffdc,_0x37515e,_0x58258c,_0x590956,_0x955f54){this['initConnection_']();const _0x2f03f8={'p':_0x37515e,'d':_0x58258c};_0x955f54!==void 0x0&&(_0x2f03f8['h']=_0x955f54),this['outstandingPuts_']['push']({'action':_0x5cffdc,'request':_0x2f03f8,'onComplete':_0x590956}),this['outstandingPutCount_']++;const _0x45e2b7=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x45e2b7):this['log_']('Buffering\x20put:\x20'+_0x37515e);}['sendPut_'](_0x5b7f51){const _0x28568f=this['outstandingPuts_'][_0x5b7f51]['action'],_0x5386d9=this['outstandingPuts_'][_0x5b7f51]['request'],_0x37923e=this['outstandingPuts_'][_0x5b7f51]['onComplete'];this['outstandingPuts_'][_0x5b7f51]['queued']=this['connected_'],this['sendRequest'](_0x28568f,_0x5386d9,_0x1fa9f9=>{this['log_'](_0x28568f+'\x20response',_0x1fa9f9),delete this['outstandingPuts_'][_0x5b7f51],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x37923e&&_0x37923e(_0x1fa9f9['s'],_0x1fa9f9['d']);});}['reportStats'](_0x537aee){if(this['connected_']){const _0x496ee8={'c':_0x537aee};this['log_']('reportStats',_0x496ee8),this['sendRequest']('s',_0x496ee8,_0x14d2f3=>{if(_0x14d2f3['s']!=='ok'){const _0x279ea5=_0x14d2f3['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x279ea5);}});}}['onDataMessage_'](_0x1fb978){if('r'in _0x1fb978){this['log_']('from\x20server:\x20'+O(_0x1fb978));const _0x79132=_0x1fb978['r'],_0x328ce3=this['requestCBHash_'][_0x79132];_0x328ce3&&(delete this['requestCBHash_'][_0x79132],_0x328ce3(_0x1fb978['b']));}else{if('error'in _0x1fb978)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1fb978['error'];'a'in _0x1fb978&&this['onDataPush_'](_0x1fb978['a'],_0x1fb978['b']);}}['onDataPush_'](_0x10f7de,_0x333999){this['log_']('handleServerMessage',_0x10f7de,_0x333999),_0x10f7de==='d'?this['onDataUpdate_'](_0x333999['p'],_0x333999['d'],!0x1,_0x333999['t']):_0x10f7de==='m'?this['onDataUpdate_'](_0x333999['p'],_0x333999['d'],!0x0,_0x333999['t']):_0x10f7de==='c'?this['onListenRevoked_'](_0x333999['p'],_0x333999['q']):_0x10f7de==='ac'?this['onAuthRevoked_'](_0x333999['s'],_0x333999['d']):_0x10f7de==='apc'?this['onAppCheckRevoked_'](_0x333999['s'],_0x333999['d']):_0x10f7de==='sd'?this['onSecurityDebugPacket_'](_0x333999):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x10f7de)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3518d0,_0x483638){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3518d0),this['lastSessionId']=_0x483638,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x344a49){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x344a49));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x27b1c6){_0x27b1c6&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x27b1c6;}['onOnline_'](_0x42597c){_0x42597c?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3603b2=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x31dd6c=Math['max'](0x0,this['reconnectDelay_']-_0x3603b2);_0x31dd6c=Math['random']()*_0x31dd6c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x31dd6c+'ms'),this['scheduleConnect_'](_0x31dd6c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x40b2dc=this['onDataMessage_']['bind'](this),_0x22f079=this['onReady_']['bind'](this),_0x1e878d=this['onRealtimeDisconnect_']['bind'](this),_0x18ac12=this['id']+':'+ie['nextConnectionId_']++,_0x5ed46f=this['lastSessionId'];let _0x47a5c6=!0x1,_0x14dc59=null;const _0x2585fe=function(){_0x14dc59?_0x14dc59['close']():(_0x47a5c6=!0x0,_0x1e878d());},_0x1888bd=function(_0x52be97){f(_0x14dc59,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x14dc59['sendRequest'](_0x52be97);};this['realtime_']={'close':_0x2585fe,'sendRequest':_0x1888bd};const _0x38a06f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5c7a02,_0x40ff2b]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x38a06f),this['appCheckTokenProvider_']['getToken'](_0x38a06f)]);_0x47a5c6?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5c7a02&&_0x5c7a02['accessToken'],this['appCheckToken_']=_0x40ff2b&&_0x40ff2b['token'],_0x14dc59=new wh(_0x18ac12,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x40b2dc,_0x22f079,_0x1e878d,_0x1b001b=>{U(_0x1b001b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5ed46f));}catch(_0x4b477f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4b477f),_0x47a5c6||(this['repoInfo_']['nodeAdmin']&&U(_0x4b477f),_0x2585fe());}}}['interrupt'](_0x3a9dab){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3a9dab),this['interruptReasons_'][_0x3a9dab]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x34adb0){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x34adb0),delete this['interruptReasons_'][_0x34adb0],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4c3e92){const _0x1ad095=_0x4c3e92-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1ad095});}['cancelSentTransactions_'](){for(let _0xa8d509=0x0;_0xa8d509<this['outstandingPuts_']['length'];_0xa8d509++){const _0x4509e9=this['outstandingPuts_'][_0xa8d509];_0x4509e9&&'h'in _0x4509e9['request']&&_0x4509e9['queued']&&(_0x4509e9['onComplete']&&_0x4509e9['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xa8d509],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x31a990,_0x21e979){let _0xcf1a70;_0x21e979?_0xcf1a70=_0x21e979['map'](_0x47afb5=>Bi(_0x47afb5))['join']('$'):_0xcf1a70='default';const _0x1983ab=this['removeListen_'](_0x31a990,_0xcf1a70);_0x1983ab&&_0x1983ab['onComplete']&&_0x1983ab['onComplete']('permission_denied');}['removeListen_'](_0x456a51,_0x13fc7e){const _0x5694c8=new C(_0x456a51)['toString']();let _0x3e1f11;if(this['listens']['has'](_0x5694c8)){const _0x4b27e8=this['listens']['get'](_0x5694c8);_0x3e1f11=_0x4b27e8['get'](_0x13fc7e),_0x4b27e8['delete'](_0x13fc7e),_0x4b27e8['size']===0x0&&this['listens']['delete'](_0x5694c8);}else _0x3e1f11=void 0x0;return _0x3e1f11;}['onAuthRevoked_'](_0x5e926e,_0x507607){L('Auth\x20token\x20revoked:\x20'+_0x5e926e+'/'+_0x507607),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5e926e==='invalid_token'||_0x5e926e==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x191da5,_0x4870e9){L('App\x20check\x20token\x20revoked:\x20'+_0x191da5+'/'+_0x4870e9),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x191da5==='invalid_token'||_0x191da5==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x77d71a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x77d71a):'msg'in _0x77d71a&&console['log']('FIREBASE:\x20'+_0x77d71a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3eba2a of this['listens']['values']())for(const _0x3fdf20 of _0x3eba2a['values']())this['sendListen_'](_0x3fdf20);for(let _0xae67ec=0x0;_0xae67ec<this['outstandingPuts_']['length'];_0xae67ec++)this['outstandingPuts_'][_0xae67ec]&&this['sendPut_'](_0xae67ec);for(;this['onDisconnectRequestQueue_']['length'];){const _0x143e97=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x143e97['action'],_0x143e97['pathString'],_0x143e97['data'],_0x143e97['onComplete']);}for(let _0x59072a=0x0;_0x59072a<this['outstandingGets_']['length'];_0x59072a++)this['outstandingGets_'][_0x59072a]&&this['sendGet_'](_0x59072a);}['sendConnectStats_'](){const _0x48d1fa={};let _0x458945='js';_0x48d1fa['sdk.'+_0x458945+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x48d1fa['framework.cordova']=0x1:qr()&&(_0x48d1fa['framework.reactnative']=0x1),this['reportStats'](_0x48d1fa);}['shouldReconnect_'](){const _0x297db9=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x297db9;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4e0bf2,_0xd9b273){this['name']=_0x4e0bf2,this['node']=_0xd9b273;}static['Wrap'](_0x2901eb,_0xd9759d){return new E(_0x2901eb,_0xd9759d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x105114,_0x25b406){const _0xe4b29f=new E(xe,_0x105114),_0xf94ba6=new E(xe,_0x25b406);return this['compare'](_0xe4b29f,_0xf94ba6)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1088a2){Xt=_0x1088a2;}['compare'](_0x33228f,_0x3600ea){return He(_0x33228f['name'],_0x3600ea['name']);}['isDefinedOn'](_0x5672ec){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x254311,_0x480987){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x13af0c,_0x43ba65){return f(typeof _0x13af0c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x13af0c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3377f8,_0xa44346,_0x2913b5,_0x27912c,_0x488a37=null){this['isReverse_']=_0x27912c,this['resultGenerator_']=_0x488a37,this['nodeStack_']=[];let _0x33b6a1=0x1;for(;!_0x3377f8['isEmpty']();)if(_0x3377f8=_0x3377f8,_0x33b6a1=_0xa44346?_0x2913b5(_0x3377f8['key'],_0xa44346):0x1,_0x27912c&&(_0x33b6a1*=-0x1),_0x33b6a1<0x0)this['isReverse_']?_0x3377f8=_0x3377f8['left']:_0x3377f8=_0x3377f8['right'];else{if(_0x33b6a1===0x0){this['nodeStack_']['push'](_0x3377f8);break;}else this['nodeStack_']['push'](_0x3377f8),this['isReverse_']?_0x3377f8=_0x3377f8['right']:_0x3377f8=_0x3377f8['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x25ebbb=this['nodeStack_']['pop'](),_0x4b66fe;if(this['resultGenerator_']?_0x4b66fe=this['resultGenerator_'](_0x25ebbb['key'],_0x25ebbb['value']):_0x4b66fe={'key':_0x25ebbb['key'],'value':_0x25ebbb['value']},this['isReverse_']){for(_0x25ebbb=_0x25ebbb['left'];!_0x25ebbb['isEmpty']();)this['nodeStack_']['push'](_0x25ebbb),_0x25ebbb=_0x25ebbb['right'];}else{for(_0x25ebbb=_0x25ebbb['right'];!_0x25ebbb['isEmpty']();)this['nodeStack_']['push'](_0x25ebbb),_0x25ebbb=_0x25ebbb['left'];}return _0x4b66fe;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x337509=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x337509['key'],_0x337509['value']):{'key':_0x337509['key'],'value':_0x337509['value']};}}class M{constructor(_0x4b2948,_0x230ea,_0x6ef7ad,_0x3993b7,_0x484ade){this['key']=_0x4b2948,this['value']=_0x230ea,this['color']=_0x6ef7ad??M['RED'],this['left']=_0x3993b7??B['EMPTY_NODE'],this['right']=_0x484ade??B['EMPTY_NODE'];}['copy'](_0x2837c3,_0x396fff,_0x159d32,_0x369483,_0x523fc4){return new M(_0x2837c3??this['key'],_0x396fff??this['value'],_0x159d32??this['color'],_0x369483??this['left'],_0x523fc4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x29d870){return this['left']['inorderTraversal'](_0x29d870)||!!_0x29d870(this['key'],this['value'])||this['right']['inorderTraversal'](_0x29d870);}['reverseTraversal'](_0x8e099c){return this['right']['reverseTraversal'](_0x8e099c)||_0x8e099c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x8e099c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x435312,_0x176ce2,_0x202b23){let _0x240631=this;const _0x50ab60=_0x202b23(_0x435312,_0x240631['key']);return _0x50ab60<0x0?_0x240631=_0x240631['copy'](null,null,null,_0x240631['left']['insert'](_0x435312,_0x176ce2,_0x202b23),null):_0x50ab60===0x0?_0x240631=_0x240631['copy'](null,_0x176ce2,null,null,null):_0x240631=_0x240631['copy'](null,null,null,null,_0x240631['right']['insert'](_0x435312,_0x176ce2,_0x202b23)),_0x240631['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x171665=this;return!_0x171665['left']['isRed_']()&&!_0x171665['left']['left']['isRed_']()&&(_0x171665=_0x171665['moveRedLeft_']()),_0x171665=_0x171665['copy'](null,null,null,_0x171665['left']['removeMin_'](),null),_0x171665['fixUp_']();}['remove'](_0x3dd200,_0x6676aa){let _0x23c0ff,_0x32656a;if(_0x23c0ff=this,_0x6676aa(_0x3dd200,_0x23c0ff['key'])<0x0)!_0x23c0ff['left']['isEmpty']()&&!_0x23c0ff['left']['isRed_']()&&!_0x23c0ff['left']['left']['isRed_']()&&(_0x23c0ff=_0x23c0ff['moveRedLeft_']()),_0x23c0ff=_0x23c0ff['copy'](null,null,null,_0x23c0ff['left']['remove'](_0x3dd200,_0x6676aa),null);else{if(_0x23c0ff['left']['isRed_']()&&(_0x23c0ff=_0x23c0ff['rotateRight_']()),!_0x23c0ff['right']['isEmpty']()&&!_0x23c0ff['right']['isRed_']()&&!_0x23c0ff['right']['left']['isRed_']()&&(_0x23c0ff=_0x23c0ff['moveRedRight_']()),_0x6676aa(_0x3dd200,_0x23c0ff['key'])===0x0){if(_0x23c0ff['right']['isEmpty']())return B['EMPTY_NODE'];_0x32656a=_0x23c0ff['right']['min_'](),_0x23c0ff=_0x23c0ff['copy'](_0x32656a['key'],_0x32656a['value'],null,null,_0x23c0ff['right']['removeMin_']());}_0x23c0ff=_0x23c0ff['copy'](null,null,null,null,_0x23c0ff['right']['remove'](_0x3dd200,_0x6676aa));}return _0x23c0ff['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x535d05=this;return _0x535d05['right']['isRed_']()&&!_0x535d05['left']['isRed_']()&&(_0x535d05=_0x535d05['rotateLeft_']()),_0x535d05['left']['isRed_']()&&_0x535d05['left']['left']['isRed_']()&&(_0x535d05=_0x535d05['rotateRight_']()),_0x535d05['left']['isRed_']()&&_0x535d05['right']['isRed_']()&&(_0x535d05=_0x535d05['colorFlip_']()),_0x535d05;}['moveRedLeft_'](){let _0x1482d9=this['colorFlip_']();return _0x1482d9['right']['left']['isRed_']()&&(_0x1482d9=_0x1482d9['copy'](null,null,null,null,_0x1482d9['right']['rotateRight_']()),_0x1482d9=_0x1482d9['rotateLeft_'](),_0x1482d9=_0x1482d9['colorFlip_']()),_0x1482d9;}['moveRedRight_'](){let _0x4ccf37=this['colorFlip_']();return _0x4ccf37['left']['left']['isRed_']()&&(_0x4ccf37=_0x4ccf37['rotateRight_'](),_0x4ccf37=_0x4ccf37['colorFlip_']()),_0x4ccf37;}['rotateLeft_'](){const _0x2971ef=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2971ef,null);}['rotateRight_'](){const _0x3b9887=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3b9887);}['colorFlip_'](){const _0x3c357d=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x47a4b5=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3c357d,_0x47a4b5);}['checkMaxDepth_'](){const _0x38edc4=this['check_']();return Math['pow'](0x2,_0x38edc4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x5b37b0=this['left']['check_']();if(_0x5b37b0!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x5b37b0+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x736b6b,_0x1daad7,_0x537eb8,_0x40bbfc,_0xf38e3){return this;}['insert'](_0x3c55e5,_0x132f42,_0x24847f){return new M(_0x3c55e5,_0x132f42,null);}['remove'](_0x59cba4,_0x27a25c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0xe91d49){return!0x1;}['reverseTraversal'](_0x355120){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x6ecaeb,_0x1641fd=B['EMPTY_NODE']){this['comparator_']=_0x6ecaeb,this['root_']=_0x1641fd;}['insert'](_0x21e8c8,_0x2a3cbb){return new B(this['comparator_'],this['root_']['insert'](_0x21e8c8,_0x2a3cbb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x424141){return new B(this['comparator_'],this['root_']['remove'](_0x424141,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x39e2d7){let _0x7812f,_0x408965=this['root_'];for(;!_0x408965['isEmpty']();){if(_0x7812f=this['comparator_'](_0x39e2d7,_0x408965['key']),_0x7812f===0x0)return _0x408965['value'];_0x7812f<0x0?_0x408965=_0x408965['left']:_0x7812f>0x0&&(_0x408965=_0x408965['right']);}return null;}['getPredecessorKey'](_0x2ad869){let _0x1949a5,_0x3d4a57=this['root_'],_0x29fd3b=null;for(;!_0x3d4a57['isEmpty']();)if(_0x1949a5=this['comparator_'](_0x2ad869,_0x3d4a57['key']),_0x1949a5===0x0){if(_0x3d4a57['left']['isEmpty']())return _0x29fd3b?_0x29fd3b['key']:null;for(_0x3d4a57=_0x3d4a57['left'];!_0x3d4a57['right']['isEmpty']();)_0x3d4a57=_0x3d4a57['right'];return _0x3d4a57['key'];}else _0x1949a5<0x0?_0x3d4a57=_0x3d4a57['left']:_0x1949a5>0x0&&(_0x29fd3b=_0x3d4a57,_0x3d4a57=_0x3d4a57['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1025f0){return this['root_']['inorderTraversal'](_0x1025f0);}['reverseTraversal'](_0x52b305){return this['root_']['reverseTraversal'](_0x52b305);}['getIterator'](_0x1dee57){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x1dee57);}['getIteratorFrom'](_0x285dab,_0x4780e9){return new Zt(this['root_'],_0x285dab,this['comparator_'],!0x1,_0x4780e9);}['getReverseIteratorFrom'](_0x4202da,_0x5b23b4){return new Zt(this['root_'],_0x4202da,this['comparator_'],!0x0,_0x5b23b4);}['getReverseIterator'](_0x4c2a90){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x4c2a90);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x1ef9a5,_0x4e60af){return He(_0x1ef9a5['name'],_0x4e60af['name']);}function ji(_0x105981,_0x225a44){return He(_0x105981,_0x225a44);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x4b6f6b){vi=_0x4b6f6b;}const Ro=function(_0x53c71a){return typeof _0x53c71a=='number'?'number:'+so(_0x53c71a):'string:'+_0x53c71a;},Ao=function(_0x5a3dac){if(_0x5a3dac['isLeafNode']()){const _0x2b9337=_0x5a3dac['val']();f(typeof _0x2b9337=='string'||typeof _0x2b9337=='number'||typeof _0x2b9337=='object'&&Y(_0x2b9337,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5a3dac===vi||_0x5a3dac['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5a3dac===vi||_0x5a3dac['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x4e19ee){er=_0x4e19ee;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2a9b93,_0x39172b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2a9b93,this['priorityNode_']=_0x39172b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x25ca5f){return new D(this['value_'],_0x25ca5f);}['getImmediateChild'](_0x140a47){return _0x140a47==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2f976e){return v(_0x2f976e)?this:y(_0x2f976e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1d1b01,_0x492ee4){return null;}['updateImmediateChild'](_0x10ca00,_0x3e4fab){return _0x10ca00==='.priority'?this['updatePriority'](_0x3e4fab):_0x3e4fab['isEmpty']()&&_0x10ca00!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x10ca00,_0x3e4fab)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4249f1,_0x26391c){const _0x53fe3b=y(_0x4249f1);return _0x53fe3b===null?_0x26391c:_0x26391c['isEmpty']()&&_0x53fe3b!=='.priority'?this:(f(_0x53fe3b!=='.priority'||we(_0x4249f1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x53fe3b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4249f1),_0x26391c)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2c88c9,_0x5b672e){return!0x1;}['val'](_0x2220e9){return _0x2220e9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4f900b='';this['priorityNode_']['isEmpty']()||(_0x4f900b+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x17578d=typeof this['value_'];_0x4f900b+=_0x17578d+':',_0x17578d==='number'?_0x4f900b+=so(this['value_']):_0x4f900b+=this['value_'],this['lazyHash_']=no(_0x4f900b);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x495249){return _0x495249===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x495249 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x495249['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x495249));}['compareToLeafNode_'](_0x3b14a2){const _0x48a875=typeof _0x3b14a2['value_'],_0x31c3f1=typeof this['value_'],_0x2e7d2a=D['VALUE_TYPE_ORDER']['indexOf'](_0x48a875),_0x3306d7=D['VALUE_TYPE_ORDER']['indexOf'](_0x31c3f1);return f(_0x2e7d2a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x48a875),f(_0x3306d7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x31c3f1),_0x2e7d2a===_0x3306d7?_0x31c3f1==='object'?0x0:this['value_']<_0x3b14a2['value_']?-0x1:this['value_']===_0x3b14a2['value_']?0x0:0x1:_0x3306d7-_0x2e7d2a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x173b5c){if(_0x173b5c===this)return!0x0;if(_0x173b5c['isLeafNode']()){const _0x2a6ada=_0x173b5c;return this['value_']===_0x2a6ada['value_']&&this['priorityNode_']['equals'](_0x2a6ada['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x58d4d2){ko=_0x58d4d2;}function xh(_0x12977c){No=_0x12977c;}class Fh extends On{['compare'](_0x27edda,_0x4a60d6){const _0x4f0b1b=_0x27edda['node']['getPriority'](),_0x3dec63=_0x4a60d6['node']['getPriority'](),_0x5c661b=_0x4f0b1b['compareTo'](_0x3dec63);return _0x5c661b===0x0?He(_0x27edda['name'],_0x4a60d6['name']):_0x5c661b;}['isDefinedOn'](_0x31edd5){return!_0x31edd5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5a0b84,_0x373352){return!_0x5a0b84['getPriority']()['equals'](_0x373352['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x382074,_0x58307f){const _0x1aae2b=ko(_0x382074);return new E(_0x58307f,new D('[PRIORITY-POST]',_0x1aae2b));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x5c284d){const _0x55ddf4=_0x2471ec=>parseInt(Math['log'](_0x2471ec)/Uh,0xa),_0x23da29=_0x5b8802=>parseInt(Array(_0x5b8802+0x1)['join']('1'),0x2);this['count']=_0x55ddf4(_0x5c284d+0x1),this['current_']=this['count']-0x1;const _0x1602fd=_0x23da29(this['count']);this['bits_']=_0x5c284d+0x1&_0x1602fd;}['nextBitIsOne'](){const _0x523837=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x523837;}}const dn=function(_0x2f75a9,_0xb1737,_0x38edc3,_0x44d0e2){_0x2f75a9['sort'](_0xb1737);const _0x7a695d=function(_0x132291,_0x3698f3){const _0xcc0116=_0x3698f3-_0x132291;let _0x59f49f,_0xa6f964;if(_0xcc0116===0x0)return null;if(_0xcc0116===0x1)return _0x59f49f=_0x2f75a9[_0x132291],_0xa6f964=_0x38edc3?_0x38edc3(_0x59f49f):_0x59f49f,new M(_0xa6f964,_0x59f49f['node'],M['BLACK'],null,null);{const _0x3edcaa=parseInt(_0xcc0116/0x2,0xa)+_0x132291,_0x1263c0=_0x7a695d(_0x132291,_0x3edcaa),_0x56d043=_0x7a695d(_0x3edcaa+0x1,_0x3698f3);return _0x59f49f=_0x2f75a9[_0x3edcaa],_0xa6f964=_0x38edc3?_0x38edc3(_0x59f49f):_0x59f49f,new M(_0xa6f964,_0x59f49f['node'],M['BLACK'],_0x1263c0,_0x56d043);}},_0x5e0ff5=function(_0x7288b0){let _0x43179f=null,_0xa8c7b9=null,_0x1f3e5b=_0x2f75a9['length'];const _0x418524=function(_0x28ac33,_0x38e8f7){const _0x3679e6=_0x1f3e5b-_0x28ac33,_0x480e05=_0x1f3e5b;_0x1f3e5b-=_0x28ac33;const _0x5c0c6e=_0x7a695d(_0x3679e6+0x1,_0x480e05),_0xbdfa14=_0x2f75a9[_0x3679e6],_0x43996a=_0x38edc3?_0x38edc3(_0xbdfa14):_0xbdfa14;_0x373c04(new M(_0x43996a,_0xbdfa14['node'],_0x38e8f7,null,_0x5c0c6e));},_0x373c04=function(_0x1b8271){_0x43179f?(_0x43179f['left']=_0x1b8271,_0x43179f=_0x1b8271):(_0xa8c7b9=_0x1b8271,_0x43179f=_0x1b8271);};for(let _0x19a9c5=0x0;_0x19a9c5<_0x7288b0['count'];++_0x19a9c5){const _0x3cf7f5=_0x7288b0['nextBitIsOne'](),_0x5ba632=Math['pow'](0x2,_0x7288b0['count']-(_0x19a9c5+0x1));_0x3cf7f5?_0x418524(_0x5ba632,M['BLACK']):(_0x418524(_0x5ba632,M['BLACK']),_0x418524(_0x5ba632,M['RED']));}return _0xa8c7b9;},_0x10d034=new Wh(_0x2f75a9['length']),_0x2b0b63=_0x5e0ff5(_0x10d034);return new B(_0x44d0e2||_0xb1737,_0x2b0b63);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x445305,_0x21d30e){this['indexes_']=_0x445305,this['indexSet_']=_0x21d30e;}['get'](_0x26858c){const _0x3bae00=Oe(this['indexes_'],_0x26858c);if(!_0x3bae00)throw new Error('No\x20index\x20defined\x20for\x20'+_0x26858c);return _0x3bae00 instanceof B?_0x3bae00:null;}['hasIndex'](_0x4ad935){return Y(this['indexSet_'],_0x4ad935['toString']());}['addIndex'](_0x496b5d,_0x23f43f){f(_0x496b5d!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x40bbcc=[];let _0x175b99=!0x1;const _0x146dea=_0x23f43f['getIterator'](E['Wrap']);let _0x2a36bb=_0x146dea['getNext']();for(;_0x2a36bb;)_0x175b99=_0x175b99||_0x496b5d['isDefinedOn'](_0x2a36bb['node']),_0x40bbcc['push'](_0x2a36bb),_0x2a36bb=_0x146dea['getNext']();let _0x40de53;_0x175b99?_0x40de53=dn(_0x40bbcc,_0x496b5d['getCompare']()):_0x40de53=je;const _0x180059=_0x496b5d['toString'](),_0x14849f={...this['indexSet_']};_0x14849f[_0x180059]=_0x496b5d;const _0x4c737d={...this['indexes_']};return _0x4c737d[_0x180059]=_0x40de53,new ee(_0x4c737d,_0x14849f);}['addToIndexes'](_0x28b67e,_0x255ae4){const _0x310524=ln(this['indexes_'],(_0x483890,_0x56fbfd)=>{const _0x4a6461=Oe(this['indexSet_'],_0x56fbfd);if(f(_0x4a6461,'Missing\x20index\x20implementation\x20for\x20'+_0x56fbfd),_0x483890===je){if(_0x4a6461['isDefinedOn'](_0x28b67e['node'])){const _0x49250d=[],_0xfadbb=_0x255ae4['getIterator'](E['Wrap']);let _0x3635ff=_0xfadbb['getNext']();for(;_0x3635ff;)_0x3635ff['name']!==_0x28b67e['name']&&_0x49250d['push'](_0x3635ff),_0x3635ff=_0xfadbb['getNext']();return _0x49250d['push'](_0x28b67e),dn(_0x49250d,_0x4a6461['getCompare']());}else return je;}else{const _0xa4d307=_0x255ae4['get'](_0x28b67e['name']);let _0x551e67=_0x483890;return _0xa4d307&&(_0x551e67=_0x551e67['remove'](new E(_0x28b67e['name'],_0xa4d307))),_0x551e67['insert'](_0x28b67e,_0x28b67e['node']);}});return new ee(_0x310524,this['indexSet_']);}['removeFromIndexes'](_0x33f896,_0x5222c){const _0x159d79=ln(this['indexes_'],_0x4b7c55=>{if(_0x4b7c55===je)return _0x4b7c55;{const _0x542dbe=_0x5222c['get'](_0x33f896['name']);return _0x542dbe?_0x4b7c55['remove'](new E(_0x33f896['name'],_0x542dbe)):_0x4b7c55;}});return new ee(_0x159d79,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x22077c,_0x3f73d9,_0x4ae332){this['children_']=_0x22077c,this['priorityNode_']=_0x3f73d9,this['indexMap_']=_0x4ae332,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1e7c8c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1e7c8c,this['indexMap_']);}['getImmediateChild'](_0x4880cc){if(_0x4880cc==='.priority')return this['getPriority']();{const _0x1439f9=this['children_']['get'](_0x4880cc);return _0x1439f9===null?gt:_0x1439f9;}}['getChild'](_0x215f16){const _0x5884d5=y(_0x215f16);return _0x5884d5===null?this:this['getImmediateChild'](_0x5884d5)['getChild'](b(_0x215f16));}['hasChild'](_0x35464b){return this['children_']['get'](_0x35464b)!==null;}['updateImmediateChild'](_0x2a0acd,_0x3f8f3c){if(f(_0x3f8f3c,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2a0acd==='.priority')return this['updatePriority'](_0x3f8f3c);{const _0x547f59=new E(_0x2a0acd,_0x3f8f3c);let _0x2cf49b,_0x4a5f56;_0x3f8f3c['isEmpty']()?(_0x2cf49b=this['children_']['remove'](_0x2a0acd),_0x4a5f56=this['indexMap_']['removeFromIndexes'](_0x547f59,this['children_'])):(_0x2cf49b=this['children_']['insert'](_0x2a0acd,_0x3f8f3c),_0x4a5f56=this['indexMap_']['addToIndexes'](_0x547f59,this['children_']));const _0x2aeec1=_0x2cf49b['isEmpty']()?gt:this['priorityNode_'];return new g(_0x2cf49b,_0x2aeec1,_0x4a5f56);}}['updateChild'](_0x1b66e5,_0x18bdec){const _0x531655=y(_0x1b66e5);if(_0x531655===null)return _0x18bdec;{f(y(_0x1b66e5)!=='.priority'||we(_0x1b66e5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x50b77e=this['getImmediateChild'](_0x531655)['updateChild'](b(_0x1b66e5),_0x18bdec);return this['updateImmediateChild'](_0x531655,_0x50b77e);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2e1d92){if(this['isEmpty']())return null;const _0x378814={};let _0x27f752=0x0,_0x3a1c99=0x0,_0x439ec0=!0x0;if(this['forEachChild'](R,(_0xc3ce4,_0x2206ed)=>{_0x378814[_0xc3ce4]=_0x2206ed['val'](_0x2e1d92),_0x27f752++,_0x439ec0&&g['INTEGER_REGEXP_']['test'](_0xc3ce4)?_0x3a1c99=Math['max'](_0x3a1c99,Number(_0xc3ce4)):_0x439ec0=!0x1;}),!_0x2e1d92&&_0x439ec0&&_0x3a1c99<0x2*_0x27f752){const _0x9b293d=[];for(const _0x5b15a9 in _0x378814)_0x9b293d[_0x5b15a9]=_0x378814[_0x5b15a9];return _0x9b293d;}else return _0x2e1d92&&!this['getPriority']()['isEmpty']()&&(_0x378814['.priority']=this['getPriority']()['val']()),_0x378814;}['hash'](){if(this['lazyHash_']===null){let _0x5edb43='';this['getPriority']()['isEmpty']()||(_0x5edb43+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1e6a12,_0x4e07a8)=>{const _0x14b916=_0x4e07a8['hash']();_0x14b916!==''&&(_0x5edb43+=':'+_0x1e6a12+':'+_0x14b916);}),this['lazyHash_']=_0x5edb43===''?'':no(_0x5edb43);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4ad24b,_0x5b6ef5,_0x589114){const _0x1082c1=this['resolveIndex_'](_0x589114);if(_0x1082c1){const _0x2b5603=_0x1082c1['getPredecessorKey'](new E(_0x4ad24b,_0x5b6ef5));return _0x2b5603?_0x2b5603['name']:null;}else return this['children_']['getPredecessorKey'](_0x4ad24b);}['getFirstChildName'](_0x4f893d){const _0x5a52c8=this['resolveIndex_'](_0x4f893d);if(_0x5a52c8){const _0x4116c4=_0x5a52c8['minKey']();return _0x4116c4&&_0x4116c4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x44b0fd){const _0x401bef=this['getFirstChildName'](_0x44b0fd);return _0x401bef?new E(_0x401bef,this['children_']['get'](_0x401bef)):null;}['getLastChildName'](_0x5cec27){const _0x5eeece=this['resolveIndex_'](_0x5cec27);if(_0x5eeece){const _0xb04dbe=_0x5eeece['maxKey']();return _0xb04dbe&&_0xb04dbe['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5e0391){const _0x1b0763=this['getLastChildName'](_0x5e0391);return _0x1b0763?new E(_0x1b0763,this['children_']['get'](_0x1b0763)):null;}['forEachChild'](_0xecc66,_0x231d3f){const _0xf21d08=this['resolveIndex_'](_0xecc66);return _0xf21d08?_0xf21d08['inorderTraversal'](_0x14ede1=>_0x231d3f(_0x14ede1['name'],_0x14ede1['node'])):this['children_']['inorderTraversal'](_0x231d3f);}['getIterator'](_0x48cedf){return this['getIteratorFrom'](_0x48cedf['minPost'](),_0x48cedf);}['getIteratorFrom'](_0x2954b2,_0x4884b3){const _0x24e847=this['resolveIndex_'](_0x4884b3);if(_0x24e847)return _0x24e847['getIteratorFrom'](_0x2954b2,_0x5f1718=>_0x5f1718);{const _0x4eb3b9=this['children_']['getIteratorFrom'](_0x2954b2['name'],E['Wrap']);let _0x3b9659=_0x4eb3b9['peek']();for(;_0x3b9659!=null&&_0x4884b3['compare'](_0x3b9659,_0x2954b2)<0x0;)_0x4eb3b9['getNext'](),_0x3b9659=_0x4eb3b9['peek']();return _0x4eb3b9;}}['getReverseIterator'](_0x4f350a){return this['getReverseIteratorFrom'](_0x4f350a['maxPost'](),_0x4f350a);}['getReverseIteratorFrom'](_0x37166a,_0x36636e){const _0x4163c0=this['resolveIndex_'](_0x36636e);if(_0x4163c0)return _0x4163c0['getReverseIteratorFrom'](_0x37166a,_0x4f709a=>_0x4f709a);{const _0x469348=this['children_']['getReverseIteratorFrom'](_0x37166a['name'],E['Wrap']);let _0x17dc1a=_0x469348['peek']();for(;_0x17dc1a!=null&&_0x36636e['compare'](_0x17dc1a,_0x37166a)>0x0;)_0x469348['getNext'](),_0x17dc1a=_0x469348['peek']();return _0x469348;}}['compareTo'](_0x2fb1aa){return this['isEmpty']()?_0x2fb1aa['isEmpty']()?0x0:-0x1:_0x2fb1aa['isLeafNode']()||_0x2fb1aa['isEmpty']()?0x1:_0x2fb1aa===Ht?-0x1:0x0;}['withIndex'](_0x352942){if(_0x352942===ye||this['indexMap_']['hasIndex'](_0x352942))return this;{const _0x1e68bf=this['indexMap_']['addIndex'](_0x352942,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1e68bf);}}['isIndexed'](_0x2f0dbe){return _0x2f0dbe===ye||this['indexMap_']['hasIndex'](_0x2f0dbe);}['equals'](_0x422843){if(_0x422843===this)return!0x0;if(_0x422843['isLeafNode']())return!0x1;{const _0x3143b8=_0x422843;if(this['getPriority']()['equals'](_0x3143b8['getPriority']())){if(this['children_']['count']()===_0x3143b8['children_']['count']()){const _0x13b433=this['getIterator'](R),_0x3695f5=_0x3143b8['getIterator'](R);let _0x535885=_0x13b433['getNext'](),_0x66f6c1=_0x3695f5['getNext']();for(;_0x535885&&_0x66f6c1;){if(_0x535885['name']!==_0x66f6c1['name']||!_0x535885['node']['equals'](_0x66f6c1['node']))return!0x1;_0x535885=_0x13b433['getNext'](),_0x66f6c1=_0x3695f5['getNext']();}return _0x535885===null&&_0x66f6c1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4b1640){return _0x4b1640===ye?null:this['indexMap_']['get'](_0x4b1640['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0xd5eb7c){return _0xd5eb7c===this?0x0:0x1;}['equals'](_0x4f4f00){return _0x4f4f00===this;}['getPriority'](){return this;}['getImmediateChild'](_0x21bd72){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x1eb5c4,_0x231a43=null){if(_0x1eb5c4===null)return g['EMPTY_NODE'];if(typeof _0x1eb5c4=='object'&&'.priority'in _0x1eb5c4&&(_0x231a43=_0x1eb5c4['.priority']),f(_0x231a43===null||typeof _0x231a43=='string'||typeof _0x231a43=='number'||typeof _0x231a43=='object'&&'.sv'in _0x231a43,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x231a43),typeof _0x1eb5c4=='object'&&'.value'in _0x1eb5c4&&_0x1eb5c4['.value']!==null&&(_0x1eb5c4=_0x1eb5c4['.value']),typeof _0x1eb5c4!='object'||'.sv'in _0x1eb5c4){const _0x2e7538=_0x1eb5c4;return new D(_0x2e7538,N(_0x231a43));}if(!(_0x1eb5c4 instanceof Array)&&Vh){const _0x339986=[];let _0x204bbc=!0x1;if(x(_0x1eb5c4,(_0x53cc02,_0x4699dd)=>{if(_0x53cc02['substring'](0x0,0x1)!=='.'){const _0x41915c=N(_0x4699dd);_0x41915c['isEmpty']()||(_0x204bbc=_0x204bbc||!_0x41915c['getPriority']()['isEmpty'](),_0x339986['push'](new E(_0x53cc02,_0x41915c)));}}),_0x339986['length']===0x0)return g['EMPTY_NODE'];const _0xf07919=dn(_0x339986,Dh,_0x443271=>_0x443271['name'],ji);if(_0x204bbc){const _0x42a492=dn(_0x339986,R['getCompare']());return new g(_0xf07919,N(_0x231a43),new ee({'.priority':_0x42a492},{'.priority':R}));}else return new g(_0xf07919,N(_0x231a43),ee['Default']);}else{let _0x4bc1b8=g['EMPTY_NODE'];return x(_0x1eb5c4,(_0x7e7c17,_0x2f7c80)=>{if(Y(_0x1eb5c4,_0x7e7c17)&&_0x7e7c17['substring'](0x0,0x1)!=='.'){const _0x2bb276=N(_0x2f7c80);(_0x2bb276['isLeafNode']()||!_0x2bb276['isEmpty']())&&(_0x4bc1b8=_0x4bc1b8['updateImmediateChild'](_0x7e7c17,_0x2bb276));}}),_0x4bc1b8['updatePriority'](N(_0x231a43));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x54f8b3){super(),this['indexPath_']=_0x54f8b3,f(!v(_0x54f8b3)&&y(_0x54f8b3)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1cf224){return _0x1cf224['getChild'](this['indexPath_']);}['isDefinedOn'](_0xcf21e4){return!_0xcf21e4['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2dac11,_0x2db8ca){const _0x227181=this['extractChild'](_0x2dac11['node']),_0x969f51=this['extractChild'](_0x2db8ca['node']),_0x26d772=_0x227181['compareTo'](_0x969f51);return _0x26d772===0x0?He(_0x2dac11['name'],_0x2db8ca['name']):_0x26d772;}['makePost'](_0x26c1e6,_0x149ca9){const _0xb988a2=N(_0x26c1e6),_0x4d96c5=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xb988a2);return new E(_0x149ca9,_0x4d96c5);}['maxPost'](){const _0x58abd2=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x58abd2);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0xbfb423,_0x30998a){const _0x591f63=_0xbfb423['node']['compareTo'](_0x30998a['node']);return _0x591f63===0x0?He(_0xbfb423['name'],_0x30998a['name']):_0x591f63;}['isDefinedOn'](_0x368f6e){return!0x0;}['indexedValueChanged'](_0x4ab823,_0x2205d8){return!_0x4ab823['equals'](_0x2205d8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xb28b02,_0x38159c){const _0xad1a03=N(_0xb28b02);return new E(_0x38159c,_0xad1a03);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x35752a){return{'type':'value','snapshotNode':_0x35752a};}function tt(_0x16bece,_0x1a30b0){return{'type':'child_added','snapshotNode':_0x1a30b0,'childName':_0x16bece};}function Nt(_0x41716e,_0xdd867f){return{'type':'child_removed','snapshotNode':_0xdd867f,'childName':_0x41716e};}function Pt(_0x230c0e,_0x16b57e,_0x374fe5){return{'type':'child_changed','snapshotNode':_0x16b57e,'childName':_0x230c0e,'oldSnap':_0x374fe5};}function $h(_0xd2ab9e,_0x4bacce){return{'type':'child_moved','snapshotNode':_0x4bacce,'childName':_0xd2ab9e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x547a72){this['index_']=_0x547a72;}['updateChild'](_0x38eb82,_0x3d26d5,_0x190027,_0x155663,_0x4f5c50,_0x4ecc07){f(_0x38eb82['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3b8f57=_0x38eb82['getImmediateChild'](_0x3d26d5);return _0x3b8f57['getChild'](_0x155663)['equals'](_0x190027['getChild'](_0x155663))&&_0x3b8f57['isEmpty']()===_0x190027['isEmpty']()||(_0x4ecc07!=null&&(_0x190027['isEmpty']()?_0x38eb82['hasChild'](_0x3d26d5)?_0x4ecc07['trackChildChange'](Nt(_0x3d26d5,_0x3b8f57)):f(_0x38eb82['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3b8f57['isEmpty']()?_0x4ecc07['trackChildChange'](tt(_0x3d26d5,_0x190027)):_0x4ecc07['trackChildChange'](Pt(_0x3d26d5,_0x190027,_0x3b8f57))),_0x38eb82['isLeafNode']()&&_0x190027['isEmpty']())?_0x38eb82:_0x38eb82['updateImmediateChild'](_0x3d26d5,_0x190027)['withIndex'](this['index_']);}['updateFullNode'](_0x3dec6a,_0x3c3673,_0x5b16ac){return _0x5b16ac!=null&&(_0x3dec6a['isLeafNode']()||_0x3dec6a['forEachChild'](R,(_0x529479,_0x2752dc)=>{_0x3c3673['hasChild'](_0x529479)||_0x5b16ac['trackChildChange'](Nt(_0x529479,_0x2752dc));}),_0x3c3673['isLeafNode']()||_0x3c3673['forEachChild'](R,(_0x20702c,_0x33c5ae)=>{if(_0x3dec6a['hasChild'](_0x20702c)){const _0x1f5107=_0x3dec6a['getImmediateChild'](_0x20702c);_0x1f5107['equals'](_0x33c5ae)||_0x5b16ac['trackChildChange'](Pt(_0x20702c,_0x33c5ae,_0x1f5107));}else _0x5b16ac['trackChildChange'](tt(_0x20702c,_0x33c5ae));})),_0x3c3673['withIndex'](this['index_']);}['updatePriority'](_0x44be3b,_0x20ab1c){return _0x44be3b['isEmpty']()?g['EMPTY_NODE']:_0x44be3b['updatePriority'](_0x20ab1c);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x1a328d){this['indexedFilter_']=new Yi(_0x1a328d['getIndex']()),this['index_']=_0x1a328d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x1a328d),this['endPost_']=Ot['getEndPost_'](_0x1a328d),this['startIsInclusive_']=!_0x1a328d['startAfterSet_'],this['endIsInclusive_']=!_0x1a328d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5b0fd9){const _0x57ab5b=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5b0fd9)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5b0fd9)<0x0,_0xce187d=this['endIsInclusive_']?this['index_']['compare'](_0x5b0fd9,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5b0fd9,this['getEndPost']())<0x0;return _0x57ab5b&&_0xce187d;}['updateChild'](_0x4cb91d,_0x4503e4,_0xd1c1da,_0x559289,_0x389cc3,_0x3d8bd3){return this['matches'](new E(_0x4503e4,_0xd1c1da))||(_0xd1c1da=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4cb91d,_0x4503e4,_0xd1c1da,_0x559289,_0x389cc3,_0x3d8bd3);}['updateFullNode'](_0x1fd84d,_0x341762,_0xf1765f){_0x341762['isLeafNode']()&&(_0x341762=g['EMPTY_NODE']);let _0x232bf5=_0x341762['withIndex'](this['index_']);_0x232bf5=_0x232bf5['updatePriority'](g['EMPTY_NODE']);const _0x4ddefd=this;return _0x341762['forEachChild'](R,(_0x43df7a,_0x9a0d28)=>{_0x4ddefd['matches'](new E(_0x43df7a,_0x9a0d28))||(_0x232bf5=_0x232bf5['updateImmediateChild'](_0x43df7a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1fd84d,_0x232bf5,_0xf1765f);}['updatePriority'](_0x55b3b6,_0x3a6b1c){return _0x55b3b6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x482467){if(_0x482467['hasStart']()){const _0x34bd46=_0x482467['getIndexStartName']();return _0x482467['getIndex']()['makePost'](_0x482467['getIndexStartValue'](),_0x34bd46);}else return _0x482467['getIndex']()['minPost']();}static['getEndPost_'](_0x580e75){if(_0x580e75['hasEnd']()){const _0x44f34c=_0x580e75['getIndexEndName']();return _0x580e75['getIndex']()['makePost'](_0x580e75['getIndexEndValue'](),_0x44f34c);}else return _0x580e75['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x29cc6d){this['withinDirectionalStart']=_0x358641=>this['reverse_']?this['withinEndPost'](_0x358641):this['withinStartPost'](_0x358641),this['withinDirectionalEnd']=_0x1c5927=>this['reverse_']?this['withinStartPost'](_0x1c5927):this['withinEndPost'](_0x1c5927),this['withinStartPost']=_0x41932a=>{const _0xbf81eb=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x41932a);return this['startIsInclusive_']?_0xbf81eb<=0x0:_0xbf81eb<0x0;},this['withinEndPost']=_0x7e8187=>{const _0x598c54=this['index_']['compare'](_0x7e8187,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x598c54<=0x0:_0x598c54<0x0;},this['rangedFilter_']=new Ot(_0x29cc6d),this['index_']=_0x29cc6d['getIndex'](),this['limit_']=_0x29cc6d['getLimit'](),this['reverse_']=!_0x29cc6d['isViewFromLeft'](),this['startIsInclusive_']=!_0x29cc6d['startAfterSet_'],this['endIsInclusive_']=!_0x29cc6d['endBeforeSet_'];}['updateChild'](_0x4c818a,_0x303044,_0x525b75,_0x37d1ff,_0x1ba141,_0xe7c92f){return this['rangedFilter_']['matches'](new E(_0x303044,_0x525b75))||(_0x525b75=g['EMPTY_NODE']),_0x4c818a['getImmediateChild'](_0x303044)['equals'](_0x525b75)?_0x4c818a:_0x4c818a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4c818a,_0x303044,_0x525b75,_0x37d1ff,_0x1ba141,_0xe7c92f):this['fullLimitUpdateChild_'](_0x4c818a,_0x303044,_0x525b75,_0x1ba141,_0xe7c92f);}['updateFullNode'](_0x5be456,_0x1a5b33,_0x4ebb6e){let _0x2f710d;if(_0x1a5b33['isLeafNode']()||_0x1a5b33['isEmpty']())_0x2f710d=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1a5b33['numChildren']()&&_0x1a5b33['isIndexed'](this['index_'])){_0x2f710d=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3b18f4;this['reverse_']?_0x3b18f4=_0x1a5b33['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3b18f4=_0x1a5b33['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x296a52=0x0;for(;_0x3b18f4['hasNext']()&&_0x296a52<this['limit_'];){const _0x2a7cac=_0x3b18f4['getNext']();if(this['withinDirectionalStart'](_0x2a7cac)){if(this['withinDirectionalEnd'](_0x2a7cac))_0x2f710d=_0x2f710d['updateImmediateChild'](_0x2a7cac['name'],_0x2a7cac['node']),_0x296a52++;else break;}else continue;}}else{_0x2f710d=_0x1a5b33['withIndex'](this['index_']),_0x2f710d=_0x2f710d['updatePriority'](g['EMPTY_NODE']);let _0x324a3c;this['reverse_']?_0x324a3c=_0x2f710d['getReverseIterator'](this['index_']):_0x324a3c=_0x2f710d['getIterator'](this['index_']);let _0x39f047=0x0;for(;_0x324a3c['hasNext']();){const _0x2a92c1=_0x324a3c['getNext']();_0x39f047<this['limit_']&&this['withinDirectionalStart'](_0x2a92c1)&&this['withinDirectionalEnd'](_0x2a92c1)?_0x39f047++:_0x2f710d=_0x2f710d['updateImmediateChild'](_0x2a92c1['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5be456,_0x2f710d,_0x4ebb6e);}['updatePriority'](_0x37199e,_0x2bcb8a){return _0x37199e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x59cea7,_0x4b8306,_0x6f4913,_0x24109f,_0x429d0d){let _0x2088d6;if(this['reverse_']){const _0x322ed3=this['index_']['getCompare']();_0x2088d6=(_0xe6935e,_0x1c0be3)=>_0x322ed3(_0x1c0be3,_0xe6935e);}else _0x2088d6=this['index_']['getCompare']();const _0x5d321d=_0x59cea7;f(_0x5d321d['numChildren']()===this['limit_'],'');const _0x45134e=new E(_0x4b8306,_0x6f4913),_0x14b7d6=this['reverse_']?_0x5d321d['getFirstChild'](this['index_']):_0x5d321d['getLastChild'](this['index_']),_0x540d7a=this['rangedFilter_']['matches'](_0x45134e);if(_0x5d321d['hasChild'](_0x4b8306)){const _0x424fe2=_0x5d321d['getImmediateChild'](_0x4b8306);let _0x5d3e2b=_0x24109f['getChildAfterChild'](this['index_'],_0x14b7d6,this['reverse_']);for(;_0x5d3e2b!=null&&(_0x5d3e2b['name']===_0x4b8306||_0x5d321d['hasChild'](_0x5d3e2b['name']));)_0x5d3e2b=_0x24109f['getChildAfterChild'](this['index_'],_0x5d3e2b,this['reverse_']);const _0x1f7674=_0x5d3e2b==null?0x1:_0x2088d6(_0x5d3e2b,_0x45134e);if(_0x540d7a&&!_0x6f4913['isEmpty']()&&_0x1f7674>=0x0)return _0x429d0d!=null&&_0x429d0d['trackChildChange'](Pt(_0x4b8306,_0x6f4913,_0x424fe2)),_0x5d321d['updateImmediateChild'](_0x4b8306,_0x6f4913);{_0x429d0d!=null&&_0x429d0d['trackChildChange'](Nt(_0x4b8306,_0x424fe2));const _0x3ba93e=_0x5d321d['updateImmediateChild'](_0x4b8306,g['EMPTY_NODE']);return _0x5d3e2b!=null&&this['rangedFilter_']['matches'](_0x5d3e2b)?(_0x429d0d!=null&&_0x429d0d['trackChildChange'](tt(_0x5d3e2b['name'],_0x5d3e2b['node'])),_0x3ba93e['updateImmediateChild'](_0x5d3e2b['name'],_0x5d3e2b['node'])):_0x3ba93e;}}else return _0x6f4913['isEmpty']()?_0x59cea7:_0x540d7a&&_0x2088d6(_0x14b7d6,_0x45134e)>=0x0?(_0x429d0d!=null&&(_0x429d0d['trackChildChange'](Nt(_0x14b7d6['name'],_0x14b7d6['node'])),_0x429d0d['trackChildChange'](tt(_0x4b8306,_0x6f4913))),_0x5d321d['updateImmediateChild'](_0x4b8306,_0x6f4913)['updateImmediateChild'](_0x14b7d6['name'],g['EMPTY_NODE'])):_0x59cea7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1fe3d4=new Qi();return _0x1fe3d4['limitSet_']=this['limitSet_'],_0x1fe3d4['limit_']=this['limit_'],_0x1fe3d4['startSet_']=this['startSet_'],_0x1fe3d4['startAfterSet_']=this['startAfterSet_'],_0x1fe3d4['indexStartValue_']=this['indexStartValue_'],_0x1fe3d4['startNameSet_']=this['startNameSet_'],_0x1fe3d4['indexStartName_']=this['indexStartName_'],_0x1fe3d4['endSet_']=this['endSet_'],_0x1fe3d4['endBeforeSet_']=this['endBeforeSet_'],_0x1fe3d4['indexEndValue_']=this['indexEndValue_'],_0x1fe3d4['endNameSet_']=this['endNameSet_'],_0x1fe3d4['indexEndName_']=this['indexEndName_'],_0x1fe3d4['index_']=this['index_'],_0x1fe3d4['viewFrom_']=this['viewFrom_'],_0x1fe3d4;}}function qh(_0x4cac24){return _0x4cac24['loadsAllData']()?new Yi(_0x4cac24['getIndex']()):_0x4cac24['hasLimit']()?new Gh(_0x4cac24):new Ot(_0x4cac24);}function zh(_0x569740,_0x51b2d9){const _0x26c4d1=_0x569740['copy']();return _0x26c4d1['limitSet_']=!0x0,_0x26c4d1['limit_']=_0x51b2d9,_0x26c4d1['viewFrom_']='l',_0x26c4d1;}function jh(_0x17c32a,_0x55627c,_0x1d4220){const _0xed7567=_0x17c32a['copy']();return _0xed7567['startSet_']=!0x0,_0x55627c===void 0x0&&(_0x55627c=null),_0xed7567['indexStartValue_']=_0x55627c,_0x1d4220!=null?(_0xed7567['startNameSet_']=!0x0,_0xed7567['indexStartName_']=_0x1d4220):(_0xed7567['startNameSet_']=!0x1,_0xed7567['indexStartName_']=''),_0xed7567;}function Kh(_0xcbcd80,_0x2cc3f9,_0x54ed82){const _0x2750cb=_0xcbcd80['copy']();return _0x2750cb['endSet_']=!0x0,_0x2cc3f9===void 0x0&&(_0x2cc3f9=null),_0x2750cb['indexEndValue_']=_0x2cc3f9,_0x54ed82!==void 0x0?(_0x2750cb['endNameSet_']=!0x0,_0x2750cb['indexEndName_']=_0x54ed82):(_0x2750cb['endNameSet_']=!0x1,_0x2750cb['indexEndName_']=''),_0x2750cb;}function Do(_0x59b281,_0x5a7c6c){const _0x5b51de=_0x59b281['copy']();return _0x5b51de['index_']=_0x5a7c6c,_0x5b51de;}function tr(_0x225307){const _0x103629={};if(_0x225307['isDefault']())return _0x103629;let _0x58c44a;if(_0x225307['index_']===R?_0x58c44a='$priority':_0x225307['index_']===Po?_0x58c44a='$value':_0x225307['index_']===ye?_0x58c44a='$key':(f(_0x225307['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x58c44a=_0x225307['index_']['toString']()),_0x103629['orderBy']=O(_0x58c44a),_0x225307['startSet_']){const _0x26ee34=_0x225307['startAfterSet_']?'startAfter':'startAt';_0x103629[_0x26ee34]=O(_0x225307['indexStartValue_']),_0x225307['startNameSet_']&&(_0x103629[_0x26ee34]+=','+O(_0x225307['indexStartName_']));}if(_0x225307['endSet_']){const _0x3a7f41=_0x225307['endBeforeSet_']?'endBefore':'endAt';_0x103629[_0x3a7f41]=O(_0x225307['indexEndValue_']),_0x225307['endNameSet_']&&(_0x103629[_0x3a7f41]+=','+O(_0x225307['indexEndName_']));}return _0x225307['limitSet_']&&(_0x225307['isViewFromLeft']()?_0x103629['limitToFirst']=_0x225307['limit_']:_0x103629['limitToLast']=_0x225307['limit_']),_0x103629;}function nr(_0x5bf8ac){const _0x2e4eb6={};if(_0x5bf8ac['startSet_']&&(_0x2e4eb6['sp']=_0x5bf8ac['indexStartValue_'],_0x5bf8ac['startNameSet_']&&(_0x2e4eb6['sn']=_0x5bf8ac['indexStartName_']),_0x2e4eb6['sin']=!_0x5bf8ac['startAfterSet_']),_0x5bf8ac['endSet_']&&(_0x2e4eb6['ep']=_0x5bf8ac['indexEndValue_'],_0x5bf8ac['endNameSet_']&&(_0x2e4eb6['en']=_0x5bf8ac['indexEndName_']),_0x2e4eb6['ein']=!_0x5bf8ac['endBeforeSet_']),_0x5bf8ac['limitSet_']){_0x2e4eb6['l']=_0x5bf8ac['limit_'];let _0xf50b23=_0x5bf8ac['viewFrom_'];_0xf50b23===''&&(_0x5bf8ac['isViewFromLeft']()?_0xf50b23='l':_0xf50b23='r'),_0x2e4eb6['vf']=_0xf50b23;}return _0x5bf8ac['index_']!==R&&(_0x2e4eb6['i']=_0x5bf8ac['index_']['toString']()),_0x2e4eb6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x3fd309){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2fa03a,_0x4b6965){return _0x4b6965!==void 0x0?'tag$'+_0x4b6965:(f(_0x2fa03a['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2fa03a['_path']['toString']());}constructor(_0x591394,_0x198a56,_0x3454a9,_0x5b8c25){super(),this['repoInfo_']=_0x591394,this['onDataUpdate_']=_0x198a56,this['authTokenProvider_']=_0x3454a9,this['appCheckTokenProvider_']=_0x5b8c25,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x411acd,_0x171013,_0x114880,_0xf9ce13){const _0x5089bc=_0x411acd['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5089bc+'\x20'+_0x411acd['_queryIdentifier']);const _0x1414ae=fn['getListenId_'](_0x411acd,_0x114880),_0x41760e={};this['listens_'][_0x1414ae]=_0x41760e;const _0x4a0d53=tr(_0x411acd['_queryParams']);this['restRequest_'](_0x5089bc+'.json',_0x4a0d53,(_0x4af255,_0x29305b)=>{let _0x25ae1a=_0x29305b;if(_0x4af255===0x194&&(_0x25ae1a=null,_0x4af255=null),_0x4af255===null&&this['onDataUpdate_'](_0x5089bc,_0x25ae1a,!0x1,_0x114880),Oe(this['listens_'],_0x1414ae)===_0x41760e){let _0x44da86;_0x4af255?_0x4af255===0x191?_0x44da86='permission_denied':_0x44da86='rest_error:'+_0x4af255:_0x44da86='ok',_0xf9ce13(_0x44da86,null);}});}['unlisten'](_0x5f46c6,_0x2f206a){const _0x21b0b0=fn['getListenId_'](_0x5f46c6,_0x2f206a);delete this['listens_'][_0x21b0b0];}['get'](_0x4246f8){const _0x342080=tr(_0x4246f8['_queryParams']),_0x19d791=_0x4246f8['_path']['toString'](),_0x40a2d1=new Ve();return this['restRequest_'](_0x19d791+'.json',_0x342080,(_0x59c19,_0x53d01f)=>{let _0x4b391d=_0x53d01f;_0x59c19===0x194&&(_0x4b391d=null,_0x59c19=null),_0x59c19===null?(this['onDataUpdate_'](_0x19d791,_0x4b391d,!0x1,null),_0x40a2d1['resolve'](_0x4b391d)):_0x40a2d1['reject'](new Error(_0x4b391d));}),_0x40a2d1['promise'];}['refreshAuthToken'](_0x51eb90){}['restRequest_'](_0x45256a,_0xd2a9c8={},_0x1eaad2){return _0xd2a9c8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x557212,_0x26be1a])=>{_0x557212&&_0x557212['accessToken']&&(_0xd2a9c8['auth']=_0x557212['accessToken']),_0x26be1a&&_0x26be1a['token']&&(_0xd2a9c8['ac']=_0x26be1a['token']);const _0x233b47=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x45256a+'?ns='+this['repoInfo_']['namespace']+at(_0xd2a9c8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x233b47);const _0x1acac9=new XMLHttpRequest();_0x1acac9['onreadystatechange']=()=>{if(_0x1eaad2&&_0x1acac9['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x233b47+'\x20received.\x20status:',_0x1acac9['status'],'response:',_0x1acac9['responseText']);let _0x237f75=null;if(_0x1acac9['status']>=0xc8&&_0x1acac9['status']<0x12c){try{_0x237f75=bt(_0x1acac9['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x233b47+':\x20'+_0x1acac9['responseText']);}_0x1eaad2(null,_0x237f75);}else _0x1acac9['status']!==0x191&&_0x1acac9['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x233b47+'\x20Status:\x20'+_0x1acac9['status']),_0x1eaad2(_0x1acac9['status']);_0x1eaad2=null;}},_0x1acac9['open']('GET',_0x233b47,!0x0),_0x1acac9['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2dff5c){return this['rootNode_']['getChild'](_0x2dff5c);}['updateSnapshot'](_0x363595,_0x21fee0){this['rootNode_']=this['rootNode_']['updateChild'](_0x363595,_0x21fee0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x3316c3,_0x37852a,_0x572c72){if(v(_0x37852a))_0x3316c3['value']=_0x572c72,_0x3316c3['children']['clear']();else{if(_0x3316c3['value']!==null)_0x3316c3['value']=_0x3316c3['value']['updateChild'](_0x37852a,_0x572c72);else{const _0x56ab4c=y(_0x37852a);_0x3316c3['children']['has'](_0x56ab4c)||_0x3316c3['children']['set'](_0x56ab4c,pn());const _0x1fe89e=_0x3316c3['children']['get'](_0x56ab4c);_0x37852a=b(_0x37852a),Mo(_0x1fe89e,_0x37852a,_0x572c72);}}}function Ei(_0x44aaa6,_0x474b71,_0x356f71){_0x44aaa6['value']!==null?_0x356f71(_0x474b71,_0x44aaa6['value']):Qh(_0x44aaa6,(_0x440459,_0xe475a4)=>{const _0x4d0c96=new C(_0x474b71['toString']()+'/'+_0x440459);Ei(_0xe475a4,_0x4d0c96,_0x356f71);});}function Qh(_0x38a0e9,_0x32b1e9){_0x38a0e9['children']['forEach']((_0x268b2c,_0x1ab0d2)=>{_0x32b1e9(_0x1ab0d2,_0x268b2c);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x10710c){this['collection_']=_0x10710c,this['last_']=null;}['get'](){const _0x2b04db=this['collection_']['get'](),_0x2308b7={..._0x2b04db};return this['last_']&&x(this['last_'],(_0x56c8ce,_0x3b5bb2)=>{_0x2308b7[_0x56c8ce]=_0x2308b7[_0x56c8ce]-_0x3b5bb2;}),this['last_']=_0x2b04db,_0x2308b7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x1250dd,_0x1d6444){this['server_']=_0x1d6444,this['statsToReport_']={},this['statsListener_']=new Jh(_0x1250dd);const _0x59de33=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x59de33));}['reportStats_'](){const _0x56630b=this['statsListener_']['get'](),_0x5812a4={};let _0x38c413=!0x1;x(_0x56630b,(_0x22cb19,_0x373255)=>{_0x373255>0x0&&Y(this['statsToReport_'],_0x22cb19)&&(_0x5812a4[_0x22cb19]=_0x373255,_0x38c413=!0x0);}),_0x38c413&&this['server_']['reportStats'](_0x5812a4),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x56e6bd){_0x56e6bd[_0x56e6bd['OVERWRITE']=0x0]='OVERWRITE',_0x56e6bd[_0x56e6bd['MERGE']=0x1]='MERGE',_0x56e6bd[_0x56e6bd['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x56e6bd[_0x56e6bd['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x5a2dfc){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5a2dfc,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3850f7,_0x501209,_0x3cfb43){this['path']=_0x3850f7,this['affectedTree']=_0x501209,this['revert']=_0x3cfb43,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x53235b){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x51a9bf=this['affectedTree']['subtree'](new C(_0x53235b));return new _n(w(),_0x51a9bf,this['revert']);}}else return f(y(this['path'])===_0x53235b,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x597f42,_0x33af66){this['source']=_0x597f42,this['path']=_0x33af66,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0xe5a9ce){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x21e967,_0xb5dedb,_0x3d9742){this['source']=_0x21e967,this['path']=_0xb5dedb,this['snap']=_0x3d9742,this['type']=q['OVERWRITE'];}['operationForChild'](_0x5e3647){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x5e3647)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x31b7bc,_0x332971,_0x3aace7){this['source']=_0x31b7bc,this['path']=_0x332971,this['children']=_0x3aace7,this['type']=q['MERGE'];}['operationForChild'](_0x4efa42){if(v(this['path'])){const _0x2549c7=this['children']['subtree'](new C(_0x4efa42));return _0x2549c7['isEmpty']()?null:_0x2549c7['value']?new Fe(this['source'],w(),_0x2549c7['value']):new nt(this['source'],w(),_0x2549c7);}else return f(y(this['path'])===_0x4efa42,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x56b1ae,_0x3d7274,_0x261eb7){this['node_']=_0x56b1ae,this['fullyInitialized_']=_0x3d7274,this['filtered_']=_0x261eb7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x44fe48){if(v(_0x44fe48))return this['isFullyInitialized']()&&!this['filtered_'];const _0x2eefda=y(_0x44fe48);return this['isCompleteForChild'](_0x2eefda);}['isCompleteForChild'](_0x2d8246){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2d8246);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x400174){this['query_']=_0x400174,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x350b5f,_0x1c23fb,_0x119cc7,_0xf6e0e1){const _0x4c2970=[],_0x258b60=[];return _0x1c23fb['forEach'](_0xa94fb0=>{_0xa94fb0['type']==='child_changed'&&_0x350b5f['index_']['indexedValueChanged'](_0xa94fb0['oldSnap'],_0xa94fb0['snapshotNode'])&&_0x258b60['push']($h(_0xa94fb0['childName'],_0xa94fb0['snapshotNode']));}),mt(_0x350b5f,_0x4c2970,'child_removed',_0x1c23fb,_0xf6e0e1,_0x119cc7),mt(_0x350b5f,_0x4c2970,'child_added',_0x1c23fb,_0xf6e0e1,_0x119cc7),mt(_0x350b5f,_0x4c2970,'child_moved',_0x258b60,_0xf6e0e1,_0x119cc7),mt(_0x350b5f,_0x4c2970,'child_changed',_0x1c23fb,_0xf6e0e1,_0x119cc7),mt(_0x350b5f,_0x4c2970,'value',_0x1c23fb,_0xf6e0e1,_0x119cc7),_0x4c2970;}function mt(_0x5cb5a3,_0x152875,_0x58553e,_0x30e6e7,_0xeb7a31,_0x3f0b5d){const _0x38a179=_0x30e6e7['filter'](_0x3c1728=>_0x3c1728['type']===_0x58553e);_0x38a179['sort']((_0x5ccc24,_0x375947)=>su(_0x5cb5a3,_0x5ccc24,_0x375947)),_0x38a179['forEach'](_0xf6cedf=>{const _0x12194b=iu(_0x5cb5a3,_0xf6cedf,_0x3f0b5d);_0xeb7a31['forEach'](_0x5f09e9=>{_0x5f09e9['respondsTo'](_0xf6cedf['type'])&&_0x152875['push'](_0x5f09e9['createEvent'](_0x12194b,_0x5cb5a3['query_']));});});}function iu(_0x4bf1b8,_0x97205c,_0x4e14eb){return _0x97205c['type']==='value'||_0x97205c['type']==='child_removed'||(_0x97205c['prevName']=_0x4e14eb['getPredecessorChildName'](_0x97205c['childName'],_0x97205c['snapshotNode'],_0x4bf1b8['index_'])),_0x97205c;}function su(_0x4b4912,_0x1c49f0,_0xc135f4){if(_0x1c49f0['childName']==null||_0xc135f4['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x35c72d=new E(_0x1c49f0['childName'],_0x1c49f0['snapshotNode']),_0x26ad6a=new E(_0xc135f4['childName'],_0xc135f4['snapshotNode']);return _0x4b4912['index_']['compare'](_0x35c72d,_0x26ad6a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x8b4733,_0x708c4e){return{'eventCache':_0x8b4733,'serverCache':_0x708c4e};}function wt(_0x1247d4,_0x22cccb,_0x5d2ab2,_0x1f78c8){return Dn(new Ce(_0x22cccb,_0x5d2ab2,_0x1f78c8),_0x1247d4['serverCache']);}function Lo(_0x2edf65,_0x2d408e,_0x2737ee,_0xdc05a6){return Dn(_0x2edf65['eventCache'],new Ce(_0x2d408e,_0x2737ee,_0xdc05a6));}function gn(_0x1dbce7){return _0x1dbce7['eventCache']['isFullyInitialized']()?_0x1dbce7['eventCache']['getNode']():null;}function Ue(_0x5ac54b){return _0x5ac54b['serverCache']['isFullyInitialized']()?_0x5ac54b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2f595b){let _0x2fa24b=new S(null);return x(_0x2f595b,(_0x2a489a,_0x2562b5)=>{_0x2fa24b=_0x2fa24b['set'](new C(_0x2a489a),_0x2562b5);}),_0x2fa24b;}constructor(_0x2f5c34,_0x1dbb50=ru()){this['value']=_0x2f5c34,this['children']=_0x1dbb50;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2b990a,_0x1c9c5c){if(this['value']!=null&&_0x1c9c5c(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2b990a))return null;{const _0x237ce1=y(_0x2b990a),_0x553455=this['children']['get'](_0x237ce1);if(_0x553455!==null){const _0x1c9bf6=_0x553455['findRootMostMatchingPathAndValue'](b(_0x2b990a),_0x1c9c5c);return _0x1c9bf6!=null?{'path':A(new C(_0x237ce1),_0x1c9bf6['path']),'value':_0x1c9bf6['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x328535){return this['findRootMostMatchingPathAndValue'](_0x328535,()=>!0x0);}['subtree'](_0x48c372){if(v(_0x48c372))return this;{const _0x465b2c=y(_0x48c372),_0x376a01=this['children']['get'](_0x465b2c);return _0x376a01!==null?_0x376a01['subtree'](b(_0x48c372)):new S(null);}}['set'](_0x5726de,_0x54e3fa){if(v(_0x5726de))return new S(_0x54e3fa,this['children']);{const _0x3fb06c=y(_0x5726de),_0x2798b2=(this['children']['get'](_0x3fb06c)||new S(null))['set'](b(_0x5726de),_0x54e3fa),_0x5b04f4=this['children']['insert'](_0x3fb06c,_0x2798b2);return new S(this['value'],_0x5b04f4);}}['remove'](_0x29a19f){if(v(_0x29a19f))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3853ad=y(_0x29a19f),_0xfdcfc3=this['children']['get'](_0x3853ad);if(_0xfdcfc3){const _0x97eeaa=_0xfdcfc3['remove'](b(_0x29a19f));let _0x892fcc;return _0x97eeaa['isEmpty']()?_0x892fcc=this['children']['remove'](_0x3853ad):_0x892fcc=this['children']['insert'](_0x3853ad,_0x97eeaa),this['value']===null&&_0x892fcc['isEmpty']()?new S(null):new S(this['value'],_0x892fcc);}else return this;}}['get'](_0x4ed9b5){if(v(_0x4ed9b5))return this['value'];{const _0x2c28c3=y(_0x4ed9b5),_0x17f3b6=this['children']['get'](_0x2c28c3);return _0x17f3b6?_0x17f3b6['get'](b(_0x4ed9b5)):null;}}['setTree'](_0x11c89c,_0x281a76){if(v(_0x11c89c))return _0x281a76;{const _0x464007=y(_0x11c89c),_0x327e58=(this['children']['get'](_0x464007)||new S(null))['setTree'](b(_0x11c89c),_0x281a76);let _0x50e9c5;return _0x327e58['isEmpty']()?_0x50e9c5=this['children']['remove'](_0x464007):_0x50e9c5=this['children']['insert'](_0x464007,_0x327e58),new S(this['value'],_0x50e9c5);}}['fold'](_0x58f6b5){return this['fold_'](w(),_0x58f6b5);}['fold_'](_0x2fb96f,_0x27406b){const _0x452b5d={};return this['children']['inorderTraversal']((_0x12bf07,_0x375d76)=>{_0x452b5d[_0x12bf07]=_0x375d76['fold_'](A(_0x2fb96f,_0x12bf07),_0x27406b);}),_0x27406b(_0x2fb96f,this['value'],_0x452b5d);}['findOnPath'](_0xd42e80,_0x328b53){return this['findOnPath_'](_0xd42e80,w(),_0x328b53);}['findOnPath_'](_0x215fff,_0x6e465d,_0x55f426){const _0x46dfa6=this['value']?_0x55f426(_0x6e465d,this['value']):!0x1;if(_0x46dfa6)return _0x46dfa6;if(v(_0x215fff))return null;{const _0x141ddd=y(_0x215fff),_0x479b7f=this['children']['get'](_0x141ddd);return _0x479b7f?_0x479b7f['findOnPath_'](b(_0x215fff),A(_0x6e465d,_0x141ddd),_0x55f426):null;}}['foreachOnPath'](_0x474f15,_0x1d017a){return this['foreachOnPath_'](_0x474f15,w(),_0x1d017a);}['foreachOnPath_'](_0x2c43dd,_0x50c31a,_0x234d52){if(v(_0x2c43dd))return this;{this['value']&&_0x234d52(_0x50c31a,this['value']);const _0x4520ec=y(_0x2c43dd),_0x39463b=this['children']['get'](_0x4520ec);return _0x39463b?_0x39463b['foreachOnPath_'](b(_0x2c43dd),A(_0x50c31a,_0x4520ec),_0x234d52):new S(null);}}['foreach'](_0x2ac10d){this['foreach_'](w(),_0x2ac10d);}['foreach_'](_0x3a3b3f,_0x1d66a){this['children']['inorderTraversal']((_0x2c43c0,_0xfc0b4d)=>{_0xfc0b4d['foreach_'](A(_0x3a3b3f,_0x2c43c0),_0x1d66a);}),this['value']&&_0x1d66a(_0x3a3b3f,this['value']);}['foreachChild'](_0x41cc69){this['children']['inorderTraversal']((_0x421a7e,_0x399a47)=>{_0x399a47['value']&&_0x41cc69(_0x421a7e,_0x399a47['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x41bccd){this['writeTree_']=_0x41bccd;}static['empty'](){return new j(new S(null));}}function Ct(_0x43815f,_0x55364f,_0x3ceace){if(v(_0x55364f))return new j(new S(_0x3ceace));{const _0xcf56cb=_0x43815f['writeTree_']['findRootMostValueAndPath'](_0x55364f);if(_0xcf56cb!=null){const _0x122bbe=_0xcf56cb['path'];let _0x27a246=_0xcf56cb['value'];const _0x1c289d=F(_0x122bbe,_0x55364f);return _0x27a246=_0x27a246['updateChild'](_0x1c289d,_0x3ceace),new j(_0x43815f['writeTree_']['set'](_0x122bbe,_0x27a246));}else{const _0x3e4293=new S(_0x3ceace),_0x599648=_0x43815f['writeTree_']['setTree'](_0x55364f,_0x3e4293);return new j(_0x599648);}}}function Ii(_0x99cc30,_0x54025e,_0x543d02){let _0x3ea764=_0x99cc30;return x(_0x543d02,(_0x32eb35,_0xa532a1)=>{_0x3ea764=Ct(_0x3ea764,A(_0x54025e,_0x32eb35),_0xa532a1);}),_0x3ea764;}function sr(_0x9f1da4,_0x5a1b2c){if(v(_0x5a1b2c))return j['empty']();{const _0x30e24d=_0x9f1da4['writeTree_']['setTree'](_0x5a1b2c,new S(null));return new j(_0x30e24d);}}function wi(_0xbfc04b,_0x1121f8){return $e(_0xbfc04b,_0x1121f8)!=null;}function $e(_0x238b16,_0x22ed7f){const _0x172b31=_0x238b16['writeTree_']['findRootMostValueAndPath'](_0x22ed7f);return _0x172b31!=null?_0x238b16['writeTree_']['get'](_0x172b31['path'])['getChild'](F(_0x172b31['path'],_0x22ed7f)):null;}function rr(_0x4131c4){const _0x28797e=[],_0x174318=_0x4131c4['writeTree_']['value'];return _0x174318!=null?_0x174318['isLeafNode']()||_0x174318['forEachChild'](R,(_0x426719,_0x311d90)=>{_0x28797e['push'](new E(_0x426719,_0x311d90));}):_0x4131c4['writeTree_']['children']['inorderTraversal']((_0x468d50,_0x5e1102)=>{_0x5e1102['value']!=null&&_0x28797e['push'](new E(_0x468d50,_0x5e1102['value']));}),_0x28797e;}function ve(_0x4f5650,_0x1388ab){if(v(_0x1388ab))return _0x4f5650;{const _0x32bda6=$e(_0x4f5650,_0x1388ab);return _0x32bda6!=null?new j(new S(_0x32bda6)):new j(_0x4f5650['writeTree_']['subtree'](_0x1388ab));}}function Ci(_0x3f26dc){return _0x3f26dc['writeTree_']['isEmpty']();}function it(_0xac95ca,_0x3c126a){return xo(w(),_0xac95ca['writeTree_'],_0x3c126a);}function xo(_0x4b0f3a,_0x10c7af,_0x2657b3){if(_0x10c7af['value']!=null)return _0x2657b3['updateChild'](_0x4b0f3a,_0x10c7af['value']);{let _0x4ac36f=null;return _0x10c7af['children']['inorderTraversal']((_0x3d0f9e,_0x4bc83b)=>{_0x3d0f9e==='.priority'?(f(_0x4bc83b['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4ac36f=_0x4bc83b['value']):_0x2657b3=xo(A(_0x4b0f3a,_0x3d0f9e),_0x4bc83b,_0x2657b3);}),!_0x2657b3['getChild'](_0x4b0f3a)['isEmpty']()&&_0x4ac36f!==null&&(_0x2657b3=_0x2657b3['updateChild'](A(_0x4b0f3a,'.priority'),_0x4ac36f)),_0x2657b3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x18da87,_0x3c0601){return Bo(_0x3c0601,_0x18da87);}function ou(_0xaea1ca,_0x32a2a3,_0x5dd93f,_0x1f2e94,_0x19b6bc){f(_0x1f2e94>_0xaea1ca['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x19b6bc===void 0x0&&(_0x19b6bc=!0x0),_0xaea1ca['allWrites']['push']({'path':_0x32a2a3,'snap':_0x5dd93f,'writeId':_0x1f2e94,'visible':_0x19b6bc}),_0x19b6bc&&(_0xaea1ca['visibleWrites']=Ct(_0xaea1ca['visibleWrites'],_0x32a2a3,_0x5dd93f)),_0xaea1ca['lastWriteId']=_0x1f2e94;}function au(_0x29a3ca,_0x47a1bb,_0x93439c,_0x980c76){f(_0x980c76>_0x29a3ca['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x29a3ca['allWrites']['push']({'path':_0x47a1bb,'children':_0x93439c,'writeId':_0x980c76,'visible':!0x0}),_0x29a3ca['visibleWrites']=Ii(_0x29a3ca['visibleWrites'],_0x47a1bb,_0x93439c),_0x29a3ca['lastWriteId']=_0x980c76;}function cu(_0x5ebeaa,_0x389460){for(let _0x35ba71=0x0;_0x35ba71<_0x5ebeaa['allWrites']['length'];_0x35ba71++){const _0x5414c8=_0x5ebeaa['allWrites'][_0x35ba71];if(_0x5414c8['writeId']===_0x389460)return _0x5414c8;}return null;}function lu(_0x3e1362,_0x27124f){const _0x30dfb1=_0x3e1362['allWrites']['findIndex'](_0x5b9da7=>_0x5b9da7['writeId']===_0x27124f);f(_0x30dfb1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x118954=_0x3e1362['allWrites'][_0x30dfb1];_0x3e1362['allWrites']['splice'](_0x30dfb1,0x1);let _0x1b3a0f=_0x118954['visible'],_0x3ea2a5=!0x1,_0x48e96=_0x3e1362['allWrites']['length']-0x1;for(;_0x1b3a0f&&_0x48e96>=0x0;){const _0x5eed00=_0x3e1362['allWrites'][_0x48e96];_0x5eed00['visible']&&(_0x48e96>=_0x30dfb1&&hu(_0x5eed00,_0x118954['path'])?_0x1b3a0f=!0x1:$(_0x118954['path'],_0x5eed00['path'])&&(_0x3ea2a5=!0x0)),_0x48e96--;}if(_0x1b3a0f){if(_0x3ea2a5)return uu(_0x3e1362),!0x0;if(_0x118954['snap'])_0x3e1362['visibleWrites']=sr(_0x3e1362['visibleWrites'],_0x118954['path']);else{const _0x5adba0=_0x118954['children'];x(_0x5adba0,_0x494869=>{_0x3e1362['visibleWrites']=sr(_0x3e1362['visibleWrites'],A(_0x118954['path'],_0x494869));});}return!0x0;}else return!0x1;}function hu(_0x5857cc,_0x4483b1){if(_0x5857cc['snap'])return $(_0x5857cc['path'],_0x4483b1);for(const _0x41d93a in _0x5857cc['children'])if(_0x5857cc['children']['hasOwnProperty'](_0x41d93a)&&$(A(_0x5857cc['path'],_0x41d93a),_0x4483b1))return!0x0;return!0x1;}function uu(_0xfa1309){_0xfa1309['visibleWrites']=Fo(_0xfa1309['allWrites'],du,w()),_0xfa1309['allWrites']['length']>0x0?_0xfa1309['lastWriteId']=_0xfa1309['allWrites'][_0xfa1309['allWrites']['length']-0x1]['writeId']:_0xfa1309['lastWriteId']=-0x1;}function du(_0x5b165f){return _0x5b165f['visible'];}function Fo(_0x5b92e7,_0x3b1cbc,_0x56864d){let _0x356d9c=j['empty']();for(let _0x2142b5=0x0;_0x2142b5<_0x5b92e7['length'];++_0x2142b5){const _0x1f07a2=_0x5b92e7[_0x2142b5];if(_0x3b1cbc(_0x1f07a2)){const _0xc4e71a=_0x1f07a2['path'];let _0x3577fe;if(_0x1f07a2['snap'])$(_0x56864d,_0xc4e71a)?(_0x3577fe=F(_0x56864d,_0xc4e71a),_0x356d9c=Ct(_0x356d9c,_0x3577fe,_0x1f07a2['snap'])):$(_0xc4e71a,_0x56864d)&&(_0x3577fe=F(_0xc4e71a,_0x56864d),_0x356d9c=Ct(_0x356d9c,w(),_0x1f07a2['snap']['getChild'](_0x3577fe)));else{if(_0x1f07a2['children']){if($(_0x56864d,_0xc4e71a))_0x3577fe=F(_0x56864d,_0xc4e71a),_0x356d9c=Ii(_0x356d9c,_0x3577fe,_0x1f07a2['children']);else{if($(_0xc4e71a,_0x56864d)){if(_0x3577fe=F(_0xc4e71a,_0x56864d),v(_0x3577fe))_0x356d9c=Ii(_0x356d9c,w(),_0x1f07a2['children']);else{const _0x325585=Oe(_0x1f07a2['children'],y(_0x3577fe));if(_0x325585){const _0x4177a6=_0x325585['getChild'](b(_0x3577fe));_0x356d9c=Ct(_0x356d9c,w(),_0x4177a6);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x356d9c;}function Uo(_0x2833ba,_0x283f13,_0x3e2c6a,_0x25fd5e,_0x50ac8e){if(!_0x25fd5e&&!_0x50ac8e){const _0x2f71f2=$e(_0x2833ba['visibleWrites'],_0x283f13);if(_0x2f71f2!=null)return _0x2f71f2;{const _0x2f41c0=ve(_0x2833ba['visibleWrites'],_0x283f13);if(Ci(_0x2f41c0))return _0x3e2c6a;if(_0x3e2c6a==null&&!wi(_0x2f41c0,w()))return null;{const _0x319a68=_0x3e2c6a||g['EMPTY_NODE'];return it(_0x2f41c0,_0x319a68);}}}else{const _0x1aab47=ve(_0x2833ba['visibleWrites'],_0x283f13);if(!_0x50ac8e&&Ci(_0x1aab47))return _0x3e2c6a;if(!_0x50ac8e&&_0x3e2c6a==null&&!wi(_0x1aab47,w()))return null;{const _0x3ef765=function(_0x3af2bf){return(_0x3af2bf['visible']||_0x50ac8e)&&(!_0x25fd5e||!~_0x25fd5e['indexOf'](_0x3af2bf['writeId']))&&($(_0x3af2bf['path'],_0x283f13)||$(_0x283f13,_0x3af2bf['path']));},_0x55b5e3=Fo(_0x2833ba['allWrites'],_0x3ef765,_0x283f13),_0x350500=_0x3e2c6a||g['EMPTY_NODE'];return it(_0x55b5e3,_0x350500);}}}function fu(_0x18faeb,_0x3d2f09,_0x537ec8){let _0xd0dc7a=g['EMPTY_NODE'];const _0xc9f034=$e(_0x18faeb['visibleWrites'],_0x3d2f09);if(_0xc9f034)return _0xc9f034['isLeafNode']()||_0xc9f034['forEachChild'](R,(_0x38bd83,_0x174983)=>{_0xd0dc7a=_0xd0dc7a['updateImmediateChild'](_0x38bd83,_0x174983);}),_0xd0dc7a;if(_0x537ec8){const _0x180f00=ve(_0x18faeb['visibleWrites'],_0x3d2f09);return _0x537ec8['forEachChild'](R,(_0x220b40,_0xf40279)=>{const _0x2f2b30=it(ve(_0x180f00,new C(_0x220b40)),_0xf40279);_0xd0dc7a=_0xd0dc7a['updateImmediateChild'](_0x220b40,_0x2f2b30);}),rr(_0x180f00)['forEach'](_0x4afd9f=>{_0xd0dc7a=_0xd0dc7a['updateImmediateChild'](_0x4afd9f['name'],_0x4afd9f['node']);}),_0xd0dc7a;}else{const _0x525f98=ve(_0x18faeb['visibleWrites'],_0x3d2f09);return rr(_0x525f98)['forEach'](_0x33761d=>{_0xd0dc7a=_0xd0dc7a['updateImmediateChild'](_0x33761d['name'],_0x33761d['node']);}),_0xd0dc7a;}}function pu(_0x4c9e69,_0x3803ab,_0x5895c0,_0x1bf8a3,_0x10afcc){f(_0x1bf8a3||_0x10afcc,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x57f273=A(_0x3803ab,_0x5895c0);if(wi(_0x4c9e69['visibleWrites'],_0x57f273))return null;{const _0x47d917=ve(_0x4c9e69['visibleWrites'],_0x57f273);return Ci(_0x47d917)?_0x10afcc['getChild'](_0x5895c0):it(_0x47d917,_0x10afcc['getChild'](_0x5895c0));}}function _u(_0x242811,_0x1ed64c,_0x2f6520,_0x5118f9){const _0x4a5121=A(_0x1ed64c,_0x2f6520),_0x10feef=$e(_0x242811['visibleWrites'],_0x4a5121);if(_0x10feef!=null)return _0x10feef;if(_0x5118f9['isCompleteForChild'](_0x2f6520)){const _0x33b54c=ve(_0x242811['visibleWrites'],_0x4a5121);return it(_0x33b54c,_0x5118f9['getNode']()['getImmediateChild'](_0x2f6520));}else return null;}function gu(_0x52887d,_0x4b4781){return $e(_0x52887d['visibleWrites'],_0x4b4781);}function mu(_0x2c1cd0,_0x126bf8,_0x557f96,_0x7e3c3a,_0x56c9db,_0x587445,_0xa7f016){let _0x4f4c33;const _0x2e2ccd=ve(_0x2c1cd0['visibleWrites'],_0x126bf8),_0x3b6465=$e(_0x2e2ccd,w());if(_0x3b6465!=null)_0x4f4c33=_0x3b6465;else{if(_0x557f96!=null)_0x4f4c33=it(_0x2e2ccd,_0x557f96);else return[];}if(_0x4f4c33=_0x4f4c33['withIndex'](_0xa7f016),!_0x4f4c33['isEmpty']()&&!_0x4f4c33['isLeafNode']()){const _0x25f779=[],_0x20f0e3=_0xa7f016['getCompare'](),_0x2ba063=_0x587445?_0x4f4c33['getReverseIteratorFrom'](_0x7e3c3a,_0xa7f016):_0x4f4c33['getIteratorFrom'](_0x7e3c3a,_0xa7f016);let _0x4a9dc3=_0x2ba063['getNext']();for(;_0x4a9dc3&&_0x25f779['length']<_0x56c9db;)_0x20f0e3(_0x4a9dc3,_0x7e3c3a)!==0x0&&_0x25f779['push'](_0x4a9dc3),_0x4a9dc3=_0x2ba063['getNext']();return _0x25f779;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x380d1b,_0xfa5c6d,_0x2a2064,_0x131bf0){return Uo(_0x380d1b['writeTree'],_0x380d1b['treePath'],_0xfa5c6d,_0x2a2064,_0x131bf0);}function es(_0x2714c6,_0x3b8450){return fu(_0x2714c6['writeTree'],_0x2714c6['treePath'],_0x3b8450);}function or(_0x4bb358,_0x7fc85a,_0x536ca0,_0x53ca6b){return pu(_0x4bb358['writeTree'],_0x4bb358['treePath'],_0x7fc85a,_0x536ca0,_0x53ca6b);}function yn(_0x22afd3,_0x3509fe){return gu(_0x22afd3['writeTree'],A(_0x22afd3['treePath'],_0x3509fe));}function vu(_0x35fd93,_0xafb694,_0x1d0d09,_0x208178,_0x104afd,_0x37cd3e){return mu(_0x35fd93['writeTree'],_0x35fd93['treePath'],_0xafb694,_0x1d0d09,_0x208178,_0x104afd,_0x37cd3e);}function ts(_0x29333c,_0x2034f4,_0x984519){return _u(_0x29333c['writeTree'],_0x29333c['treePath'],_0x2034f4,_0x984519);}function Wo(_0x4e189a,_0x22632e){return Bo(A(_0x4e189a['treePath'],_0x22632e),_0x4e189a['writeTree']);}function Bo(_0x543cda,_0x21fece){return{'treePath':_0x543cda,'writeTree':_0x21fece};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3d5245){const _0x291e0f=_0x3d5245['type'],_0x5aed57=_0x3d5245['childName'];f(_0x291e0f==='child_added'||_0x291e0f==='child_changed'||_0x291e0f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5aed57!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x14553b=this['changeMap']['get'](_0x5aed57);if(_0x14553b){const _0x251ad8=_0x14553b['type'];if(_0x291e0f==='child_added'&&_0x251ad8==='child_removed')this['changeMap']['set'](_0x5aed57,Pt(_0x5aed57,_0x3d5245['snapshotNode'],_0x14553b['snapshotNode']));else{if(_0x291e0f==='child_removed'&&_0x251ad8==='child_added')this['changeMap']['delete'](_0x5aed57);else{if(_0x291e0f==='child_removed'&&_0x251ad8==='child_changed')this['changeMap']['set'](_0x5aed57,Nt(_0x5aed57,_0x14553b['oldSnap']));else{if(_0x291e0f==='child_changed'&&_0x251ad8==='child_added')this['changeMap']['set'](_0x5aed57,tt(_0x5aed57,_0x3d5245['snapshotNode']));else{if(_0x291e0f==='child_changed'&&_0x251ad8==='child_changed')this['changeMap']['set'](_0x5aed57,Pt(_0x5aed57,_0x3d5245['snapshotNode'],_0x14553b['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3d5245+'\x20occurred\x20after\x20'+_0x14553b);}}}}}else this['changeMap']['set'](_0x5aed57,_0x3d5245);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0xa5e107){return null;}['getChildAfterChild'](_0x4baaa3,_0x498633,_0x498f61){return null;}}const Vo=new Iu();class ns{constructor(_0x2658ac,_0x1ad865,_0x211b63=null){this['writes_']=_0x2658ac,this['viewCache_']=_0x1ad865,this['optCompleteServerCache_']=_0x211b63;}['getCompleteChild'](_0x4bc003){const _0xd2f748=this['viewCache_']['eventCache'];if(_0xd2f748['isCompleteForChild'](_0x4bc003))return _0xd2f748['getNode']()['getImmediateChild'](_0x4bc003);{const _0x4bbee5=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x4bc003,_0x4bbee5);}}['getChildAfterChild'](_0x4b7a13,_0x4538ba,_0xfd5a38){const _0x3242a4=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x32da91=vu(this['writes_'],_0x3242a4,_0x4538ba,0x1,_0xfd5a38,_0x4b7a13);return _0x32da91['length']===0x0?null:_0x32da91[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x4e27fd){return{'filter':_0x4e27fd};}function Cu(_0x2c3a6c,_0x39c254){f(_0x39c254['eventCache']['getNode']()['isIndexed'](_0x2c3a6c['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x39c254['serverCache']['getNode']()['isIndexed'](_0x2c3a6c['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1f3727,_0x70a5c0,_0x185ef9,_0x3a67b5,_0x322bab){const _0x208237=new Eu();let _0x498d88,_0x37796d;if(_0x185ef9['type']===q['OVERWRITE']){const _0x342bc9=_0x185ef9;_0x342bc9['source']['fromUser']?_0x498d88=Ti(_0x1f3727,_0x70a5c0,_0x342bc9['path'],_0x342bc9['snap'],_0x3a67b5,_0x322bab,_0x208237):(f(_0x342bc9['source']['fromServer'],'Unknown\x20source.'),_0x37796d=_0x342bc9['source']['tagged']||_0x70a5c0['serverCache']['isFiltered']()&&!v(_0x342bc9['path']),_0x498d88=vn(_0x1f3727,_0x70a5c0,_0x342bc9['path'],_0x342bc9['snap'],_0x3a67b5,_0x322bab,_0x37796d,_0x208237));}else{if(_0x185ef9['type']===q['MERGE']){const _0x1670d2=_0x185ef9;_0x1670d2['source']['fromUser']?_0x498d88=bu(_0x1f3727,_0x70a5c0,_0x1670d2['path'],_0x1670d2['children'],_0x3a67b5,_0x322bab,_0x208237):(f(_0x1670d2['source']['fromServer'],'Unknown\x20source.'),_0x37796d=_0x1670d2['source']['tagged']||_0x70a5c0['serverCache']['isFiltered'](),_0x498d88=Si(_0x1f3727,_0x70a5c0,_0x1670d2['path'],_0x1670d2['children'],_0x3a67b5,_0x322bab,_0x37796d,_0x208237));}else{if(_0x185ef9['type']===q['ACK_USER_WRITE']){const _0x229e91=_0x185ef9;_0x229e91['revert']?_0x498d88=ku(_0x1f3727,_0x70a5c0,_0x229e91['path'],_0x3a67b5,_0x322bab,_0x208237):_0x498d88=Ru(_0x1f3727,_0x70a5c0,_0x229e91['path'],_0x229e91['affectedTree'],_0x3a67b5,_0x322bab,_0x208237);}else{if(_0x185ef9['type']===q['LISTEN_COMPLETE'])_0x498d88=Au(_0x1f3727,_0x70a5c0,_0x185ef9['path'],_0x3a67b5,_0x208237);else throw ot('Unknown\x20operation\x20type:\x20'+_0x185ef9['type']);}}}const _0x366da1=_0x208237['getChanges']();return Su(_0x70a5c0,_0x498d88,_0x366da1),{'viewCache':_0x498d88,'changes':_0x366da1};}function Su(_0x2b476c,_0x5875d7,_0x302072){const _0x3e6728=_0x5875d7['eventCache'];if(_0x3e6728['isFullyInitialized']()){const _0x5051d5=_0x3e6728['getNode']()['isLeafNode']()||_0x3e6728['getNode']()['isEmpty'](),_0x49e43d=gn(_0x2b476c);(_0x302072['length']>0x0||!_0x2b476c['eventCache']['isFullyInitialized']()||_0x5051d5&&!_0x3e6728['getNode']()['equals'](_0x49e43d)||!_0x3e6728['getNode']()['getPriority']()['equals'](_0x49e43d['getPriority']()))&&_0x302072['push'](Oo(gn(_0x5875d7)));}}function Ho(_0x300b9d,_0x2b5af0,_0x5a24ed,_0x2d0c44,_0x13272a,_0x3a04d1){const _0x188d4f=_0x2b5af0['eventCache'];if(yn(_0x2d0c44,_0x5a24ed)!=null)return _0x2b5af0;{let _0x4b6734,_0x5b618c;if(v(_0x5a24ed)){if(f(_0x2b5af0['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2b5af0['serverCache']['isFiltered']()){const _0x2c4f0b=Ue(_0x2b5af0),_0x228c12=_0x2c4f0b instanceof g?_0x2c4f0b:g['EMPTY_NODE'],_0x17d100=es(_0x2d0c44,_0x228c12);_0x4b6734=_0x300b9d['filter']['updateFullNode'](_0x2b5af0['eventCache']['getNode'](),_0x17d100,_0x3a04d1);}else{const _0x3284cc=mn(_0x2d0c44,Ue(_0x2b5af0));_0x4b6734=_0x300b9d['filter']['updateFullNode'](_0x2b5af0['eventCache']['getNode'](),_0x3284cc,_0x3a04d1);}}else{const _0x5d7d2f=y(_0x5a24ed);if(_0x5d7d2f==='.priority'){f(we(_0x5a24ed)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x45c41e=_0x188d4f['getNode']();_0x5b618c=_0x2b5af0['serverCache']['getNode']();const _0x230ad6=or(_0x2d0c44,_0x5a24ed,_0x45c41e,_0x5b618c);_0x230ad6!=null?_0x4b6734=_0x300b9d['filter']['updatePriority'](_0x45c41e,_0x230ad6):_0x4b6734=_0x188d4f['getNode']();}else{const _0x4805f4=b(_0x5a24ed);let _0x1ad0db;if(_0x188d4f['isCompleteForChild'](_0x5d7d2f)){_0x5b618c=_0x2b5af0['serverCache']['getNode']();const _0x20ffa5=or(_0x2d0c44,_0x5a24ed,_0x188d4f['getNode'](),_0x5b618c);_0x20ffa5!=null?_0x1ad0db=_0x188d4f['getNode']()['getImmediateChild'](_0x5d7d2f)['updateChild'](_0x4805f4,_0x20ffa5):_0x1ad0db=_0x188d4f['getNode']()['getImmediateChild'](_0x5d7d2f);}else _0x1ad0db=ts(_0x2d0c44,_0x5d7d2f,_0x2b5af0['serverCache']);_0x1ad0db!=null?_0x4b6734=_0x300b9d['filter']['updateChild'](_0x188d4f['getNode'](),_0x5d7d2f,_0x1ad0db,_0x4805f4,_0x13272a,_0x3a04d1):_0x4b6734=_0x188d4f['getNode']();}}return wt(_0x2b5af0,_0x4b6734,_0x188d4f['isFullyInitialized']()||v(_0x5a24ed),_0x300b9d['filter']['filtersNodes']());}}function vn(_0x17e70f,_0x4743cb,_0xf89f02,_0x215cac,_0x2c4192,_0x5e2211,_0x1c3a94,_0x4d3b9b){const _0x5a8883=_0x4743cb['serverCache'];let _0x13fbe8;const _0x59b4b6=_0x1c3a94?_0x17e70f['filter']:_0x17e70f['filter']['getIndexedFilter']();if(v(_0xf89f02))_0x13fbe8=_0x59b4b6['updateFullNode'](_0x5a8883['getNode'](),_0x215cac,null);else{if(_0x59b4b6['filtersNodes']()&&!_0x5a8883['isFiltered']()){const _0xad4395=_0x5a8883['getNode']()['updateChild'](_0xf89f02,_0x215cac);_0x13fbe8=_0x59b4b6['updateFullNode'](_0x5a8883['getNode'](),_0xad4395,null);}else{const _0x13e04b=y(_0xf89f02);if(!_0x5a8883['isCompleteForPath'](_0xf89f02)&&we(_0xf89f02)>0x1)return _0x4743cb;const _0x3a9bbc=b(_0xf89f02),_0x3fb24b=_0x5a8883['getNode']()['getImmediateChild'](_0x13e04b)['updateChild'](_0x3a9bbc,_0x215cac);_0x13e04b==='.priority'?_0x13fbe8=_0x59b4b6['updatePriority'](_0x5a8883['getNode'](),_0x3fb24b):_0x13fbe8=_0x59b4b6['updateChild'](_0x5a8883['getNode'](),_0x13e04b,_0x3fb24b,_0x3a9bbc,Vo,null);}}const _0x376712=Lo(_0x4743cb,_0x13fbe8,_0x5a8883['isFullyInitialized']()||v(_0xf89f02),_0x59b4b6['filtersNodes']()),_0x24043b=new ns(_0x2c4192,_0x376712,_0x5e2211);return Ho(_0x17e70f,_0x376712,_0xf89f02,_0x2c4192,_0x24043b,_0x4d3b9b);}function Ti(_0x55867c,_0x180954,_0xd02313,_0x22b572,_0x512047,_0x1983a3,_0x20d77f){const _0x112a2e=_0x180954['eventCache'];let _0x1eef23,_0x637401;const _0x5d4f85=new ns(_0x512047,_0x180954,_0x1983a3);if(v(_0xd02313))_0x637401=_0x55867c['filter']['updateFullNode'](_0x180954['eventCache']['getNode'](),_0x22b572,_0x20d77f),_0x1eef23=wt(_0x180954,_0x637401,!0x0,_0x55867c['filter']['filtersNodes']());else{const _0x19fe82=y(_0xd02313);if(_0x19fe82==='.priority')_0x637401=_0x55867c['filter']['updatePriority'](_0x180954['eventCache']['getNode'](),_0x22b572),_0x1eef23=wt(_0x180954,_0x637401,_0x112a2e['isFullyInitialized'](),_0x112a2e['isFiltered']());else{const _0x42f6a0=b(_0xd02313),_0x13f36d=_0x112a2e['getNode']()['getImmediateChild'](_0x19fe82);let _0x997319;if(v(_0x42f6a0))_0x997319=_0x22b572;else{const _0x9c87f9=_0x5d4f85['getCompleteChild'](_0x19fe82);_0x9c87f9!=null?Gi(_0x42f6a0)==='.priority'&&_0x9c87f9['getChild'](To(_0x42f6a0))['isEmpty']()?_0x997319=_0x9c87f9:_0x997319=_0x9c87f9['updateChild'](_0x42f6a0,_0x22b572):_0x997319=g['EMPTY_NODE'];}if(_0x13f36d['equals'](_0x997319))_0x1eef23=_0x180954;else{const _0x20d91a=_0x55867c['filter']['updateChild'](_0x112a2e['getNode'](),_0x19fe82,_0x997319,_0x42f6a0,_0x5d4f85,_0x20d77f);_0x1eef23=wt(_0x180954,_0x20d91a,_0x112a2e['isFullyInitialized'](),_0x55867c['filter']['filtersNodes']());}}}return _0x1eef23;}function ar(_0x264d2a,_0x4fa7b5){return _0x264d2a['eventCache']['isCompleteForChild'](_0x4fa7b5);}function bu(_0x5a23ba,_0x445aa6,_0x9b5ec1,_0xebf7e0,_0x1a5816,_0x5ccb73,_0x3ecd17){let _0x5b0dd6=_0x445aa6;return _0xebf7e0['foreach']((_0x4f4b85,_0x492b85)=>{const _0x8f26a7=A(_0x9b5ec1,_0x4f4b85);ar(_0x445aa6,y(_0x8f26a7))&&(_0x5b0dd6=Ti(_0x5a23ba,_0x5b0dd6,_0x8f26a7,_0x492b85,_0x1a5816,_0x5ccb73,_0x3ecd17));}),_0xebf7e0['foreach']((_0x5a63ac,_0x45d55d)=>{const _0x54a6c6=A(_0x9b5ec1,_0x5a63ac);ar(_0x445aa6,y(_0x54a6c6))||(_0x5b0dd6=Ti(_0x5a23ba,_0x5b0dd6,_0x54a6c6,_0x45d55d,_0x1a5816,_0x5ccb73,_0x3ecd17));}),_0x5b0dd6;}function cr(_0x3566cd,_0x374a76,_0x550566){return _0x550566['foreach']((_0x380b61,_0x40fdef)=>{_0x374a76=_0x374a76['updateChild'](_0x380b61,_0x40fdef);}),_0x374a76;}function Si(_0x5629d8,_0x57795e,_0x9d0d99,_0x57dbcc,_0x44d546,_0x1a279a,_0x4e70ab,_0x41330a){if(_0x57795e['serverCache']['getNode']()['isEmpty']()&&!_0x57795e['serverCache']['isFullyInitialized']())return _0x57795e;let _0x512aef=_0x57795e,_0x39d8ee;v(_0x9d0d99)?_0x39d8ee=_0x57dbcc:_0x39d8ee=new S(null)['setTree'](_0x9d0d99,_0x57dbcc);const _0xd10ab5=_0x57795e['serverCache']['getNode']();return _0x39d8ee['children']['inorderTraversal']((_0x33e01f,_0x54dd21)=>{if(_0xd10ab5['hasChild'](_0x33e01f)){const _0x14865b=_0x57795e['serverCache']['getNode']()['getImmediateChild'](_0x33e01f),_0x1f13a5=cr(_0x5629d8,_0x14865b,_0x54dd21);_0x512aef=vn(_0x5629d8,_0x512aef,new C(_0x33e01f),_0x1f13a5,_0x44d546,_0x1a279a,_0x4e70ab,_0x41330a);}}),_0x39d8ee['children']['inorderTraversal']((_0x5d1622,_0x128167)=>{const _0x2bdae8=!_0x57795e['serverCache']['isCompleteForChild'](_0x5d1622)&&_0x128167['value']===null;if(!_0xd10ab5['hasChild'](_0x5d1622)&&!_0x2bdae8){const _0x54c38d=_0x57795e['serverCache']['getNode']()['getImmediateChild'](_0x5d1622),_0xd6b030=cr(_0x5629d8,_0x54c38d,_0x128167);_0x512aef=vn(_0x5629d8,_0x512aef,new C(_0x5d1622),_0xd6b030,_0x44d546,_0x1a279a,_0x4e70ab,_0x41330a);}}),_0x512aef;}function Ru(_0x43fa46,_0x2790a9,_0x39c470,_0x3b842a,_0x2eb91e,_0x570e46,_0x2d9343){if(yn(_0x2eb91e,_0x39c470)!=null)return _0x2790a9;const _0xc05fc9=_0x2790a9['serverCache']['isFiltered'](),_0x123a74=_0x2790a9['serverCache'];if(_0x3b842a['value']!=null){if(v(_0x39c470)&&_0x123a74['isFullyInitialized']()||_0x123a74['isCompleteForPath'](_0x39c470))return vn(_0x43fa46,_0x2790a9,_0x39c470,_0x123a74['getNode']()['getChild'](_0x39c470),_0x2eb91e,_0x570e46,_0xc05fc9,_0x2d9343);if(v(_0x39c470)){let _0x257d6c=new S(null);return _0x123a74['getNode']()['forEachChild'](ye,(_0x27e8c0,_0x3515e4)=>{_0x257d6c=_0x257d6c['set'](new C(_0x27e8c0),_0x3515e4);}),Si(_0x43fa46,_0x2790a9,_0x39c470,_0x257d6c,_0x2eb91e,_0x570e46,_0xc05fc9,_0x2d9343);}else return _0x2790a9;}else{let _0x46151b=new S(null);return _0x3b842a['foreach']((_0x260370,_0x38591f)=>{const _0x1e39fa=A(_0x39c470,_0x260370);_0x123a74['isCompleteForPath'](_0x1e39fa)&&(_0x46151b=_0x46151b['set'](_0x260370,_0x123a74['getNode']()['getChild'](_0x1e39fa)));}),Si(_0x43fa46,_0x2790a9,_0x39c470,_0x46151b,_0x2eb91e,_0x570e46,_0xc05fc9,_0x2d9343);}}function Au(_0x5eb70b,_0x16b1b6,_0x5e9b4e,_0x25b009,_0x3f7b6c){const _0x152481=_0x16b1b6['serverCache'],_0x259ade=Lo(_0x16b1b6,_0x152481['getNode'](),_0x152481['isFullyInitialized']()||v(_0x5e9b4e),_0x152481['isFiltered']());return Ho(_0x5eb70b,_0x259ade,_0x5e9b4e,_0x25b009,Vo,_0x3f7b6c);}function ku(_0x5569c7,_0x281ee9,_0x1be128,_0x4c9a4f,_0x5c1e64,_0x3dbf08){let _0x192008;if(yn(_0x4c9a4f,_0x1be128)!=null)return _0x281ee9;{const _0x1ea26f=new ns(_0x4c9a4f,_0x281ee9,_0x5c1e64),_0x3f30ff=_0x281ee9['eventCache']['getNode']();let _0x4862ce;if(v(_0x1be128)||y(_0x1be128)==='.priority'){let _0x3c9f9a;if(_0x281ee9['serverCache']['isFullyInitialized']())_0x3c9f9a=mn(_0x4c9a4f,Ue(_0x281ee9));else{const _0xafe908=_0x281ee9['serverCache']['getNode']();f(_0xafe908 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3c9f9a=es(_0x4c9a4f,_0xafe908);}_0x3c9f9a=_0x3c9f9a,_0x4862ce=_0x5569c7['filter']['updateFullNode'](_0x3f30ff,_0x3c9f9a,_0x3dbf08);}else{const _0x45773c=y(_0x1be128);let _0x20ba91=ts(_0x4c9a4f,_0x45773c,_0x281ee9['serverCache']);_0x20ba91==null&&_0x281ee9['serverCache']['isCompleteForChild'](_0x45773c)&&(_0x20ba91=_0x3f30ff['getImmediateChild'](_0x45773c)),_0x20ba91!=null?_0x4862ce=_0x5569c7['filter']['updateChild'](_0x3f30ff,_0x45773c,_0x20ba91,b(_0x1be128),_0x1ea26f,_0x3dbf08):_0x281ee9['eventCache']['getNode']()['hasChild'](_0x45773c)?_0x4862ce=_0x5569c7['filter']['updateChild'](_0x3f30ff,_0x45773c,g['EMPTY_NODE'],b(_0x1be128),_0x1ea26f,_0x3dbf08):_0x4862ce=_0x3f30ff,_0x4862ce['isEmpty']()&&_0x281ee9['serverCache']['isFullyInitialized']()&&(_0x192008=mn(_0x4c9a4f,Ue(_0x281ee9)),_0x192008['isLeafNode']()&&(_0x4862ce=_0x5569c7['filter']['updateFullNode'](_0x4862ce,_0x192008,_0x3dbf08)));}return _0x192008=_0x281ee9['serverCache']['isFullyInitialized']()||yn(_0x4c9a4f,w())!=null,wt(_0x281ee9,_0x4862ce,_0x192008,_0x5569c7['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0xcfc9e8,_0x7014c0){this['query_']=_0xcfc9e8,this['eventRegistrations_']=[];const _0x150048=this['query_']['_queryParams'],_0x1b2200=new Yi(_0x150048['getIndex']()),_0x3220de=qh(_0x150048);this['processor_']=wu(_0x3220de);const _0x43f97f=_0x7014c0['serverCache'],_0x42ed70=_0x7014c0['eventCache'],_0x1779f1=_0x1b2200['updateFullNode'](g['EMPTY_NODE'],_0x43f97f['getNode'](),null),_0x53a1cb=_0x3220de['updateFullNode'](g['EMPTY_NODE'],_0x42ed70['getNode'](),null),_0x39686f=new Ce(_0x1779f1,_0x43f97f['isFullyInitialized'](),_0x1b2200['filtersNodes']()),_0x423a1b=new Ce(_0x53a1cb,_0x42ed70['isFullyInitialized'](),_0x3220de['filtersNodes']());this['viewCache_']=Dn(_0x423a1b,_0x39686f),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3aa4d5){return _0x3aa4d5['viewCache_']['serverCache']['getNode']();}function Ou(_0x52447c){return gn(_0x52447c['viewCache_']);}function Du(_0x3c7b0e,_0x4a34dc){const _0x4483fb=Ue(_0x3c7b0e['viewCache_']);return _0x4483fb&&(_0x3c7b0e['query']['_queryParams']['loadsAllData']()||!v(_0x4a34dc)&&!_0x4483fb['getImmediateChild'](y(_0x4a34dc))['isEmpty']())?_0x4483fb['getChild'](_0x4a34dc):null;}function lr(_0x467e91){return _0x467e91['eventRegistrations_']['length']===0x0;}function Mu(_0x3ed701,_0x49b3c9){_0x3ed701['eventRegistrations_']['push'](_0x49b3c9);}function hr(_0x485843,_0x30fec2,_0x99a8f5){const _0x2a1cf3=[];if(_0x99a8f5){f(_0x30fec2==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x945f0e=_0x485843['query']['_path'];_0x485843['eventRegistrations_']['forEach'](_0x54088c=>{const _0x1ddeb6=_0x54088c['createCancelEvent'](_0x99a8f5,_0x945f0e);_0x1ddeb6&&_0x2a1cf3['push'](_0x1ddeb6);});}if(_0x30fec2){let _0x3fe8a2=[];for(let _0x5ca161=0x0;_0x5ca161<_0x485843['eventRegistrations_']['length'];++_0x5ca161){const _0x288854=_0x485843['eventRegistrations_'][_0x5ca161];if(!_0x288854['matches'](_0x30fec2))_0x3fe8a2['push'](_0x288854);else{if(_0x30fec2['hasAnyCallback']()){_0x3fe8a2=_0x3fe8a2['concat'](_0x485843['eventRegistrations_']['slice'](_0x5ca161+0x1));break;}}}_0x485843['eventRegistrations_']=_0x3fe8a2;}else _0x485843['eventRegistrations_']=[];return _0x2a1cf3;}function ur(_0x204c39,_0x171832,_0x5c6dfb,_0x246fc8){_0x171832['type']===q['MERGE']&&_0x171832['source']['queryId']!==null&&(f(Ue(_0x204c39['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x204c39['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x43abc5=_0x204c39['viewCache_'],_0x35cc26=Tu(_0x204c39['processor_'],_0x43abc5,_0x171832,_0x5c6dfb,_0x246fc8);return Cu(_0x204c39['processor_'],_0x35cc26['viewCache']),f(_0x35cc26['viewCache']['serverCache']['isFullyInitialized']()||!_0x43abc5['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x204c39['viewCache_']=_0x35cc26['viewCache'],$o(_0x204c39,_0x35cc26['changes'],_0x35cc26['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x46a57c,_0x399500){const _0x2bdf3e=_0x46a57c['viewCache_']['eventCache'],_0x2f6f2c=[];return _0x2bdf3e['getNode']()['isLeafNode']()||_0x2bdf3e['getNode']()['forEachChild'](R,(_0x22be44,_0x310d64)=>{_0x2f6f2c['push'](tt(_0x22be44,_0x310d64));}),_0x2bdf3e['isFullyInitialized']()&&_0x2f6f2c['push'](Oo(_0x2bdf3e['getNode']())),$o(_0x46a57c,_0x2f6f2c,_0x2bdf3e['getNode'](),_0x399500);}function $o(_0x50f17b,_0x1f5da3,_0x56b4ae,_0x5734f3){const _0x28bd6a=_0x5734f3?[_0x5734f3]:_0x50f17b['eventRegistrations_'];return nu(_0x50f17b['eventGenerator_'],_0x1f5da3,_0x56b4ae,_0x28bd6a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x42be4b){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x42be4b;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x3e1e7a){return _0x3e1e7a['views']['size']===0x0;}function is(_0x294af0,_0x2e59b4,_0x10f233,_0x132c44){const _0x57c78d=_0x2e59b4['source']['queryId'];if(_0x57c78d!==null){const _0x5aa949=_0x294af0['views']['get'](_0x57c78d);return f(_0x5aa949!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x5aa949,_0x2e59b4,_0x10f233,_0x132c44);}else{let _0xcf1d90=[];for(const _0x3634ba of _0x294af0['views']['values']())_0xcf1d90=_0xcf1d90['concat'](ur(_0x3634ba,_0x2e59b4,_0x10f233,_0x132c44));return _0xcf1d90;}}function qo(_0x28b11c,_0x1e28e2,_0x27139d,_0x3e4ed8,_0x4404e0){const _0xfee1bd=_0x1e28e2['_queryIdentifier'],_0x552554=_0x28b11c['views']['get'](_0xfee1bd);if(!_0x552554){let _0x1c204e=mn(_0x27139d,_0x4404e0?_0x3e4ed8:null),_0x2182f2=!0x1;_0x1c204e?_0x2182f2=!0x0:_0x3e4ed8 instanceof g?(_0x1c204e=es(_0x27139d,_0x3e4ed8),_0x2182f2=!0x1):(_0x1c204e=g['EMPTY_NODE'],_0x2182f2=!0x1);const _0x45c51c=Dn(new Ce(_0x1c204e,_0x2182f2,!0x1),new Ce(_0x3e4ed8,_0x4404e0,!0x1));return new Nu(_0x1e28e2,_0x45c51c);}return _0x552554;}function Wu(_0x15a2cf,_0x161a4e,_0x3602c0,_0x391cf8,_0x39aa20,_0x54a75f){const _0x6ac198=qo(_0x15a2cf,_0x161a4e,_0x391cf8,_0x39aa20,_0x54a75f);return _0x15a2cf['views']['has'](_0x161a4e['_queryIdentifier'])||_0x15a2cf['views']['set'](_0x161a4e['_queryIdentifier'],_0x6ac198),Mu(_0x6ac198,_0x3602c0),Lu(_0x6ac198,_0x3602c0);}function Bu(_0x24301c,_0x361df0,_0x45d7c2,_0x164588){const _0x5c618c=_0x361df0['_queryIdentifier'],_0x3dd957=[];let _0x336f0b=[];const _0x436373=Te(_0x24301c);if(_0x5c618c==='default'){for(const [_0x4b696e,_0x3141f6]of _0x24301c['views']['entries']())_0x336f0b=_0x336f0b['concat'](hr(_0x3141f6,_0x45d7c2,_0x164588)),lr(_0x3141f6)&&(_0x24301c['views']['delete'](_0x4b696e),_0x3141f6['query']['_queryParams']['loadsAllData']()||_0x3dd957['push'](_0x3141f6['query']));}else{const _0x5130c8=_0x24301c['views']['get'](_0x5c618c);_0x5130c8&&(_0x336f0b=_0x336f0b['concat'](hr(_0x5130c8,_0x45d7c2,_0x164588)),lr(_0x5130c8)&&(_0x24301c['views']['delete'](_0x5c618c),_0x5130c8['query']['_queryParams']['loadsAllData']()||_0x3dd957['push'](_0x5130c8['query'])));}return _0x436373&&!Te(_0x24301c)&&_0x3dd957['push'](new(Fu())(_0x361df0['_repo'],_0x361df0['_path'])),{'removed':_0x3dd957,'events':_0x336f0b};}function zo(_0x56a198){const _0x117349=[];for(const _0x2c1129 of _0x56a198['views']['values']())_0x2c1129['query']['_queryParams']['loadsAllData']()||_0x117349['push'](_0x2c1129);return _0x117349;}function Ee(_0x499853,_0x3a9ab0){let _0x6f7efe=null;for(const _0x56b36f of _0x499853['views']['values']())_0x6f7efe=_0x6f7efe||Du(_0x56b36f,_0x3a9ab0);return _0x6f7efe;}function jo(_0x4f4c9a,_0x1a9d69){if(_0x1a9d69['_queryParams']['loadsAllData']())return Ln(_0x4f4c9a);{const _0x1343b4=_0x1a9d69['_queryIdentifier'];return _0x4f4c9a['views']['get'](_0x1343b4);}}function Ko(_0x39e875,_0x2afe2e){return jo(_0x39e875,_0x2afe2e)!=null;}function Te(_0x3edcee){return Ln(_0x3edcee)!=null;}function Ln(_0x5eec2b){for(const _0x3f5af3 of _0x5eec2b['views']['values']())if(_0x3f5af3['query']['_queryParams']['loadsAllData']())return _0x3f5af3;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x3ea15b){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3ea15b;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x4ef0cf){this['listenProvider_']=_0x4ef0cf,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2a5ccc,_0x412a1e,_0x3a3e7d,_0x37f7b9,_0x3031c2){return ou(_0x2a5ccc['pendingWriteTree_'],_0x412a1e,_0x3a3e7d,_0x37f7b9,_0x3031c2),_0x3031c2?ht(_0x2a5ccc,new Fe(Ji(),_0x412a1e,_0x3a3e7d)):[];}function Gu(_0xc9f65b,_0x445daa,_0x29dfeb,_0x124089){au(_0xc9f65b['pendingWriteTree_'],_0x445daa,_0x29dfeb,_0x124089);const _0x2993d8=S['fromObject'](_0x29dfeb);return ht(_0xc9f65b,new nt(Ji(),_0x445daa,_0x2993d8));}function pe(_0x1e57b2,_0x46b004,_0x4f2bfe=!0x1){const _0x1f0440=cu(_0x1e57b2['pendingWriteTree_'],_0x46b004);if(lu(_0x1e57b2['pendingWriteTree_'],_0x46b004)){let _0x2143ee=new S(null);return _0x1f0440['snap']!=null?_0x2143ee=_0x2143ee['set'](w(),!0x0):x(_0x1f0440['children'],_0x103a27=>{_0x2143ee=_0x2143ee['set'](new C(_0x103a27),!0x0);}),ht(_0x1e57b2,new _n(_0x1f0440['path'],_0x2143ee,_0x4f2bfe));}else return[];}function $t(_0x1c52cb,_0x31db55,_0x3da834){return ht(_0x1c52cb,new Fe(Xi(),_0x31db55,_0x3da834));}function qu(_0x428f2f,_0x1b5d3b,_0xa7a45d){const _0xb7a4=S['fromObject'](_0xa7a45d);return ht(_0x428f2f,new nt(Xi(),_0x1b5d3b,_0xb7a4));}function zu(_0x21cae8,_0x3ee6ae){return ht(_0x21cae8,new Dt(Xi(),_0x3ee6ae));}function ju(_0x5090c9,_0x2a8918,_0x223ee3){const _0x3e8c23=rs(_0x5090c9,_0x223ee3);if(_0x3e8c23){const _0x21519e=os(_0x3e8c23),_0x4a1725=_0x21519e['path'],_0x271939=_0x21519e['queryId'],_0x397a9c=F(_0x4a1725,_0x2a8918),_0x2edead=new Dt(Zi(_0x271939),_0x397a9c);return as(_0x5090c9,_0x4a1725,_0x2edead);}else return[];}function wn(_0x39e91f,_0x5045b6,_0x390bed,_0x4c702f,_0x55a9f8=!0x1){const _0x5a8853=_0x5045b6['_path'],_0x178cae=_0x39e91f['syncPointTree_']['get'](_0x5a8853);let _0x9b3eb0=[];if(_0x178cae&&(_0x5045b6['_queryIdentifier']==='default'||Ko(_0x178cae,_0x5045b6))){const _0x10aa39=Bu(_0x178cae,_0x5045b6,_0x390bed,_0x4c702f);Uu(_0x178cae)&&(_0x39e91f['syncPointTree_']=_0x39e91f['syncPointTree_']['remove'](_0x5a8853));const _0x38d80a=_0x10aa39['removed'];if(_0x9b3eb0=_0x10aa39['events'],!_0x55a9f8){const _0x14267f=_0x38d80a['findIndex'](_0x51d541=>_0x51d541['_queryParams']['loadsAllData']())!==-0x1,_0x229825=_0x39e91f['syncPointTree_']['findOnPath'](_0x5a8853,(_0x23bd95,_0x5492f0)=>Te(_0x5492f0));if(_0x14267f&&!_0x229825){const _0x218977=_0x39e91f['syncPointTree_']['subtree'](_0x5a8853);if(!_0x218977['isEmpty']()){const _0x30b359=Qu(_0x218977);for(let _0x1f97f1=0x0;_0x1f97f1<_0x30b359['length'];++_0x1f97f1){const _0x4c7a32=_0x30b359[_0x1f97f1],_0x501ff3=_0x4c7a32['query'],_0xa66a37=Xo(_0x39e91f,_0x4c7a32);_0x39e91f['listenProvider_']['startListening'](Tt(_0x501ff3),Mt(_0x39e91f,_0x501ff3),_0xa66a37['hashFn'],_0xa66a37['onComplete']);}}}!_0x229825&&_0x38d80a['length']>0x0&&!_0x4c702f&&(_0x14267f?_0x39e91f['listenProvider_']['stopListening'](Tt(_0x5045b6),null):_0x38d80a['forEach'](_0x4b687c=>{const _0x2ae4dc=_0x39e91f['queryToTagMap']['get'](Fn(_0x4b687c));_0x39e91f['listenProvider_']['stopListening'](Tt(_0x4b687c),_0x2ae4dc);}));}Ju(_0x39e91f,_0x38d80a);}return _0x9b3eb0;}function Yo(_0x12fa25,_0x429ab5,_0xf530d8,_0xe30e22){const _0x377bbb=rs(_0x12fa25,_0xe30e22);if(_0x377bbb!=null){const _0x2bbef8=os(_0x377bbb),_0xa29943=_0x2bbef8['path'],_0x2b309a=_0x2bbef8['queryId'],_0x321d22=F(_0xa29943,_0x429ab5),_0x4944ab=new Fe(Zi(_0x2b309a),_0x321d22,_0xf530d8);return as(_0x12fa25,_0xa29943,_0x4944ab);}else return[];}function Ku(_0x5edc01,_0x103fbc,_0x5e86e4,_0x1893fc){const _0x28866b=rs(_0x5edc01,_0x1893fc);if(_0x28866b){const _0x59013d=os(_0x28866b),_0x3e5142=_0x59013d['path'],_0x4ea5bf=_0x59013d['queryId'],_0x10e528=F(_0x3e5142,_0x103fbc),_0x5f71f3=S['fromObject'](_0x5e86e4),_0x2a3451=new nt(Zi(_0x4ea5bf),_0x10e528,_0x5f71f3);return as(_0x5edc01,_0x3e5142,_0x2a3451);}else return[];}function bi(_0x4c3d0d,_0xf8fa07,_0x48cafe,_0x141387=!0x1){const _0x2f0407=_0xf8fa07['_path'];let _0x130f40=null,_0x2471ac=!0x1;_0x4c3d0d['syncPointTree_']['foreachOnPath'](_0x2f0407,(_0x299927,_0x2ca405)=>{const _0x2e517f=F(_0x299927,_0x2f0407);_0x130f40=_0x130f40||Ee(_0x2ca405,_0x2e517f),_0x2471ac=_0x2471ac||Te(_0x2ca405);});let _0x5ec04a=_0x4c3d0d['syncPointTree_']['get'](_0x2f0407);_0x5ec04a?(_0x2471ac=_0x2471ac||Te(_0x5ec04a),_0x130f40=_0x130f40||Ee(_0x5ec04a,w())):(_0x5ec04a=new Go(),_0x4c3d0d['syncPointTree_']=_0x4c3d0d['syncPointTree_']['set'](_0x2f0407,_0x5ec04a));let _0x3ff594;_0x130f40!=null?_0x3ff594=!0x0:(_0x3ff594=!0x1,_0x130f40=g['EMPTY_NODE'],_0x4c3d0d['syncPointTree_']['subtree'](_0x2f0407)['foreachChild']((_0x3032b7,_0x309dfb)=>{const _0x2bceba=Ee(_0x309dfb,w());_0x2bceba&&(_0x130f40=_0x130f40['updateImmediateChild'](_0x3032b7,_0x2bceba));}));const _0x39a516=Ko(_0x5ec04a,_0xf8fa07);if(!_0x39a516&&!_0xf8fa07['_queryParams']['loadsAllData']()){const _0x418805=Fn(_0xf8fa07);f(!_0x4c3d0d['queryToTagMap']['has'](_0x418805),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x19f86a=Xu();_0x4c3d0d['queryToTagMap']['set'](_0x418805,_0x19f86a),_0x4c3d0d['tagToQueryMap']['set'](_0x19f86a,_0x418805);}const _0x114bb3=Mn(_0x4c3d0d['pendingWriteTree_'],_0x2f0407);let _0x42f741=Wu(_0x5ec04a,_0xf8fa07,_0x48cafe,_0x114bb3,_0x130f40,_0x3ff594);if(!_0x39a516&&!_0x2471ac&&!_0x141387){const _0x414f8b=jo(_0x5ec04a,_0xf8fa07);_0x42f741=_0x42f741['concat'](Zu(_0x4c3d0d,_0xf8fa07,_0x414f8b));}return _0x42f741;}function xn(_0x53355e,_0x143222,_0x2fcaf2){const _0x26deac=_0x53355e['pendingWriteTree_'],_0x2f0e23=_0x53355e['syncPointTree_']['findOnPath'](_0x143222,(_0x59b77f,_0x588aae)=>{const _0x1c59a0=F(_0x59b77f,_0x143222),_0x58c04e=Ee(_0x588aae,_0x1c59a0);if(_0x58c04e)return _0x58c04e;});return Uo(_0x26deac,_0x143222,_0x2f0e23,_0x2fcaf2,!0x0);}function Yu(_0x52afa9,_0x1b1354){const _0x4b898a=_0x1b1354['_path'];let _0x9efde1=null;_0x52afa9['syncPointTree_']['foreachOnPath'](_0x4b898a,(_0x2b1bcf,_0x2ca5a7)=>{const _0x4db32f=F(_0x2b1bcf,_0x4b898a);_0x9efde1=_0x9efde1||Ee(_0x2ca5a7,_0x4db32f);});let _0x17a764=_0x52afa9['syncPointTree_']['get'](_0x4b898a);_0x17a764?_0x9efde1=_0x9efde1||Ee(_0x17a764,w()):(_0x17a764=new Go(),_0x52afa9['syncPointTree_']=_0x52afa9['syncPointTree_']['set'](_0x4b898a,_0x17a764));const _0x78740c=_0x9efde1!=null,_0x515d0e=_0x78740c?new Ce(_0x9efde1,!0x0,!0x1):null,_0x908e79=Mn(_0x52afa9['pendingWriteTree_'],_0x1b1354['_path']),_0x3a2191=qo(_0x17a764,_0x1b1354,_0x908e79,_0x78740c?_0x515d0e['getNode']():g['EMPTY_NODE'],_0x78740c);return Ou(_0x3a2191);}function ht(_0x226859,_0x26a2ed){return Qo(_0x26a2ed,_0x226859['syncPointTree_'],null,Mn(_0x226859['pendingWriteTree_'],w()));}function Qo(_0x5c76f2,_0x3f4ec9,_0x4c2f35,_0x3d98e8){if(v(_0x5c76f2['path']))return Jo(_0x5c76f2,_0x3f4ec9,_0x4c2f35,_0x3d98e8);{const _0x14df1e=_0x3f4ec9['get'](w());_0x4c2f35==null&&_0x14df1e!=null&&(_0x4c2f35=Ee(_0x14df1e,w()));let _0x2356f8=[];const _0x3523f1=y(_0x5c76f2['path']),_0x4c5bcf=_0x5c76f2['operationForChild'](_0x3523f1),_0x14070d=_0x3f4ec9['children']['get'](_0x3523f1);if(_0x14070d&&_0x4c5bcf){const _0x5938b9=_0x4c2f35?_0x4c2f35['getImmediateChild'](_0x3523f1):null,_0x1f5729=Wo(_0x3d98e8,_0x3523f1);_0x2356f8=_0x2356f8['concat'](Qo(_0x4c5bcf,_0x14070d,_0x5938b9,_0x1f5729));}return _0x14df1e&&(_0x2356f8=_0x2356f8['concat'](is(_0x14df1e,_0x5c76f2,_0x3d98e8,_0x4c2f35))),_0x2356f8;}}function Jo(_0x343832,_0x1352a7,_0x2dff8a,_0x5ec060){const _0x3745b0=_0x1352a7['get'](w());_0x2dff8a==null&&_0x3745b0!=null&&(_0x2dff8a=Ee(_0x3745b0,w()));let _0x3aa63a=[];return _0x1352a7['children']['inorderTraversal']((_0x239d63,_0x369aa2)=>{const _0x459afc=_0x2dff8a?_0x2dff8a['getImmediateChild'](_0x239d63):null,_0x927f3=Wo(_0x5ec060,_0x239d63),_0x58701a=_0x343832['operationForChild'](_0x239d63);_0x58701a&&(_0x3aa63a=_0x3aa63a['concat'](Jo(_0x58701a,_0x369aa2,_0x459afc,_0x927f3)));}),_0x3745b0&&(_0x3aa63a=_0x3aa63a['concat'](is(_0x3745b0,_0x343832,_0x5ec060,_0x2dff8a))),_0x3aa63a;}function Xo(_0x11a6e6,_0x53cb68){const _0x449f05=_0x53cb68['query'],_0x18de88=Mt(_0x11a6e6,_0x449f05);return{'hashFn':()=>(Pu(_0x53cb68)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x209488=>{if(_0x209488==='ok')return _0x18de88?ju(_0x11a6e6,_0x449f05['_path'],_0x18de88):zu(_0x11a6e6,_0x449f05['_path']);{const _0x502195=ql(_0x209488,_0x449f05);return wn(_0x11a6e6,_0x449f05,null,_0x502195);}}};}function Mt(_0x4c39bb,_0x14e2b2){const _0x2ac265=Fn(_0x14e2b2);return _0x4c39bb['queryToTagMap']['get'](_0x2ac265);}function Fn(_0x10f03d){return _0x10f03d['_path']['toString']()+'$'+_0x10f03d['_queryIdentifier'];}function rs(_0x473faa,_0x187156){return _0x473faa['tagToQueryMap']['get'](_0x187156);}function os(_0x269e8a){const _0x26ac15=_0x269e8a['indexOf']('$');return f(_0x26ac15!==-0x1&&_0x26ac15<_0x269e8a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x269e8a['substr'](_0x26ac15+0x1),'path':new C(_0x269e8a['substr'](0x0,_0x26ac15))};}function as(_0x221d3d,_0x34cc76,_0x163cee){const _0x1ac83e=_0x221d3d['syncPointTree_']['get'](_0x34cc76);f(_0x1ac83e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x85074a=Mn(_0x221d3d['pendingWriteTree_'],_0x34cc76);return is(_0x1ac83e,_0x163cee,_0x85074a,null);}function Qu(_0x475ba1){return _0x475ba1['fold']((_0x1b9bb9,_0x224f30,_0x15ff2a)=>{if(_0x224f30&&Te(_0x224f30))return[Ln(_0x224f30)];{let _0x15acc8=[];return _0x224f30&&(_0x15acc8=zo(_0x224f30)),x(_0x15ff2a,(_0x4e837d,_0x1b9bb8)=>{_0x15acc8=_0x15acc8['concat'](_0x1b9bb8);}),_0x15acc8;}});}function Tt(_0x36a7ee){return _0x36a7ee['_queryParams']['loadsAllData']()&&!_0x36a7ee['_queryParams']['isDefault']()?new(Hu())(_0x36a7ee['_repo'],_0x36a7ee['_path']):_0x36a7ee;}function Ju(_0x1d8b0c,_0x48ebdb){for(let _0x36cb91=0x0;_0x36cb91<_0x48ebdb['length'];++_0x36cb91){const _0x404fef=_0x48ebdb[_0x36cb91];if(!_0x404fef['_queryParams']['loadsAllData']()){const _0x499143=Fn(_0x404fef),_0x44c693=_0x1d8b0c['queryToTagMap']['get'](_0x499143);_0x1d8b0c['queryToTagMap']['delete'](_0x499143),_0x1d8b0c['tagToQueryMap']['delete'](_0x44c693);}}}function Xu(){return $u++;}function Zu(_0x1707a2,_0x362025,_0x34d7fb){const _0x30da66=_0x362025['_path'],_0x2c9b70=Mt(_0x1707a2,_0x362025),_0x2bc6d5=Xo(_0x1707a2,_0x34d7fb),_0x2f1cd0=_0x1707a2['listenProvider_']['startListening'](Tt(_0x362025),_0x2c9b70,_0x2bc6d5['hashFn'],_0x2bc6d5['onComplete']),_0xda88ae=_0x1707a2['syncPointTree_']['subtree'](_0x30da66);if(_0x2c9b70)f(!Te(_0xda88ae['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xa6f60c=_0xda88ae['fold']((_0x283a49,_0x5d973d,_0x4b95d8)=>{if(!v(_0x283a49)&&_0x5d973d&&Te(_0x5d973d))return[Ln(_0x5d973d)['query']];{let _0x42b046=[];return _0x5d973d&&(_0x42b046=_0x42b046['concat'](zo(_0x5d973d)['map'](_0x274803=>_0x274803['query']))),x(_0x4b95d8,(_0x4bdd97,_0x1afeb8)=>{_0x42b046=_0x42b046['concat'](_0x1afeb8);}),_0x42b046;}});for(let _0x5a017e=0x0;_0x5a017e<_0xa6f60c['length'];++_0x5a017e){const _0x5c5301=_0xa6f60c[_0x5a017e];_0x1707a2['listenProvider_']['stopListening'](Tt(_0x5c5301),Mt(_0x1707a2,_0x5c5301));}}return _0x2f1cd0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x540320){this['node_']=_0x540320;}['getImmediateChild'](_0x5f59a4){const _0x535c78=this['node_']['getImmediateChild'](_0x5f59a4);return new cs(_0x535c78);}['node'](){return this['node_'];}}class ls{constructor(_0x570599,_0x357546){this['syncTree_']=_0x570599,this['path_']=_0x357546;}['getImmediateChild'](_0x5a88c9){const _0x48439c=A(this['path_'],_0x5a88c9);return new ls(this['syncTree_'],_0x48439c);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x3d1905){return _0x3d1905=_0x3d1905||{},_0x3d1905['timestamp']=_0x3d1905['timestamp']||new Date()['getTime'](),_0x3d1905;},fr=function(_0x55d0f6,_0x1e1cbe,_0x2b9916){if(!_0x55d0f6||typeof _0x55d0f6!='object')return _0x55d0f6;if(f('.sv'in _0x55d0f6,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x55d0f6['.sv']=='string')return td(_0x55d0f6['.sv'],_0x1e1cbe,_0x2b9916);if(typeof _0x55d0f6['.sv']=='object')return nd(_0x55d0f6['.sv'],_0x1e1cbe);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x55d0f6,null,0x2));},td=function(_0x237fc7,_0x7d355a,_0x347aca){switch(_0x237fc7){case'timestamp':return _0x347aca['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x237fc7);}},nd=function(_0x1665ea,_0x226557,_0xfdc423){_0x1665ea['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1665ea,null,0x2));const _0x3097c6=_0x1665ea['increment'];typeof _0x3097c6!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3097c6);const _0x5ba311=_0x226557['node']();if(f(_0x5ba311!==null&&typeof _0x5ba311<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5ba311['isLeafNode']())return _0x3097c6;const _0x132dbb=_0x5ba311['getValue']();return typeof _0x132dbb!='number'?_0x3097c6:_0x132dbb+_0x3097c6;},Zo=function(_0x2ec3e4,_0x1a23e8,_0x217bb2,_0x507f61){return us(_0x1a23e8,new ls(_0x217bb2,_0x2ec3e4),_0x507f61);},hs=function(_0x2742ec,_0x215924,_0x42609c){return us(_0x2742ec,new cs(_0x215924),_0x42609c);};function us(_0x2abf81,_0x2fd520,_0x5b66aa){const _0x298c02=_0x2abf81['getPriority']()['val'](),_0x25b50b=fr(_0x298c02,_0x2fd520['getImmediateChild']('.priority'),_0x5b66aa);let _0x32daaa;if(_0x2abf81['isLeafNode']()){const _0x4eb338=_0x2abf81,_0x2aabd1=fr(_0x4eb338['getValue'](),_0x2fd520,_0x5b66aa);return _0x2aabd1!==_0x4eb338['getValue']()||_0x25b50b!==_0x4eb338['getPriority']()['val']()?new D(_0x2aabd1,N(_0x25b50b)):_0x2abf81;}else{const _0x4d5179=_0x2abf81;return _0x32daaa=_0x4d5179,_0x25b50b!==_0x4d5179['getPriority']()['val']()&&(_0x32daaa=_0x32daaa['updatePriority'](new D(_0x25b50b))),_0x4d5179['forEachChild'](R,(_0x3edb4b,_0x30d5c4)=>{const _0x290363=us(_0x30d5c4,_0x2fd520['getImmediateChild'](_0x3edb4b),_0x5b66aa);_0x290363!==_0x30d5c4&&(_0x32daaa=_0x32daaa['updateImmediateChild'](_0x3edb4b,_0x290363));}),_0x32daaa;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4723fb='',_0x460b76=null,_0x267d98={'children':{},'childCount':0x0}){this['name']=_0x4723fb,this['parent']=_0x460b76,this['node']=_0x267d98;}}function Un(_0xe47a4d,_0x49619c){let _0x2167f5=_0x49619c instanceof C?_0x49619c:new C(_0x49619c),_0x436846=_0xe47a4d,_0xcf74fc=y(_0x2167f5);for(;_0xcf74fc!==null;){const _0x532913=Oe(_0x436846['node']['children'],_0xcf74fc)||{'children':{},'childCount':0x0};_0x436846=new ds(_0xcf74fc,_0x436846,_0x532913),_0x2167f5=b(_0x2167f5),_0xcf74fc=y(_0x2167f5);}return _0x436846;}function Ge(_0x4db868){return _0x4db868['node']['value'];}function fs(_0x342cf5,_0x403e65){_0x342cf5['node']['value']=_0x403e65,Ri(_0x342cf5);}function ea(_0x4f73fd){return _0x4f73fd['node']['childCount']>0x0;}function id(_0x2c961e){return Ge(_0x2c961e)===void 0x0&&!ea(_0x2c961e);}function Wn(_0x51dbfd,_0x5a47e4){x(_0x51dbfd['node']['children'],(_0x497040,_0x426ec4)=>{_0x5a47e4(new ds(_0x497040,_0x51dbfd,_0x426ec4));});}function ta(_0x4e5060,_0x2eb37a,_0x3b9b54,_0x5e5544){_0x3b9b54&&_0x2eb37a(_0x4e5060),Wn(_0x4e5060,_0xa6fe48=>{ta(_0xa6fe48,_0x2eb37a,!0x0);});}function sd(_0x2ade90,_0x4804b6,_0x32cbc0){let _0x14806a=_0x2ade90['parent'];for(;_0x14806a!==null;){if(_0x4804b6(_0x14806a))return!0x0;_0x14806a=_0x14806a['parent'];}return!0x1;}function Gt(_0x5b7a80){return new C(_0x5b7a80['parent']===null?_0x5b7a80['name']:Gt(_0x5b7a80['parent'])+'/'+_0x5b7a80['name']);}function Ri(_0x3c6e8c){_0x3c6e8c['parent']!==null&&rd(_0x3c6e8c['parent'],_0x3c6e8c['name'],_0x3c6e8c);}function rd(_0x3d6b94,_0x4b3bc5,_0x30afac){const _0x351ccf=id(_0x30afac),_0x2f4d2b=Y(_0x3d6b94['node']['children'],_0x4b3bc5);_0x351ccf&&_0x2f4d2b?(delete _0x3d6b94['node']['children'][_0x4b3bc5],_0x3d6b94['node']['childCount']--,Ri(_0x3d6b94)):!_0x351ccf&&!_0x2f4d2b&&(_0x3d6b94['node']['children'][_0x4b3bc5]=_0x30afac['node'],_0x3d6b94['node']['childCount']++,Ri(_0x3d6b94));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x3ba5a4){return typeof _0x3ba5a4=='string'&&_0x3ba5a4['length']!==0x0&&!od['test'](_0x3ba5a4);},na=function(_0xa60e21){return typeof _0xa60e21=='string'&&_0xa60e21['length']!==0x0&&!ad['test'](_0xa60e21);},cd=function(_0x5bd576){return _0x5bd576&&(_0x5bd576=_0x5bd576['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x5bd576);},Cn=function(_0x1ba8f9){return _0x1ba8f9===null||typeof _0x1ba8f9=='string'||typeof _0x1ba8f9=='number'&&!Wi(_0x1ba8f9)||_0x1ba8f9&&typeof _0x1ba8f9=='object'&&Y(_0x1ba8f9,'.sv');},qt=function(_0xbd9f1a,_0x223a53,_0x3ac8d8,_0x2e052b){_0x2e052b&&_0x223a53===void 0x0||zt(Nn(_0xbd9f1a,'value'),_0x223a53,_0x3ac8d8);},zt=function(_0xacc73d,_0x165781,_0x2ea89d){const _0x5b45c3=_0x2ea89d instanceof C?new Sh(_0x2ea89d,_0xacc73d):_0x2ea89d;if(_0x165781===void 0x0)throw new Error(_0xacc73d+'contains\x20undefined\x20'+Ne(_0x5b45c3));if(typeof _0x165781=='function')throw new Error(_0xacc73d+'contains\x20a\x20function\x20'+Ne(_0x5b45c3)+'\x20with\x20contents\x20=\x20'+_0x165781['toString']());if(Wi(_0x165781))throw new Error(_0xacc73d+'contains\x20'+_0x165781['toString']()+'\x20'+Ne(_0x5b45c3));if(typeof _0x165781=='string'&&_0x165781['length']>oi/0x3&&Pn(_0x165781)>oi)throw new Error(_0xacc73d+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x5b45c3)+'\x20(\x27'+_0x165781['substring'](0x0,0x32)+'...\x27)');if(_0x165781&&typeof _0x165781=='object'){let _0x5e00f9=!0x1,_0x2617ae=!0x1;if(x(_0x165781,(_0x2b8cc3,_0x39749c)=>{if(_0x2b8cc3==='.value')_0x5e00f9=!0x0;else{if(_0x2b8cc3!=='.priority'&&_0x2b8cc3!=='.sv'&&(_0x2617ae=!0x0,!ps(_0x2b8cc3)))throw new Error(_0xacc73d+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2b8cc3+')\x20'+Ne(_0x5b45c3)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x5b45c3,_0x2b8cc3),zt(_0xacc73d,_0x39749c,_0x5b45c3),Rh(_0x5b45c3);}),_0x5e00f9&&_0x2617ae)throw new Error(_0xacc73d+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x5b45c3)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x32195b,_0x1b88c6){let _0x1ddf9a,_0x1bc381;for(_0x1ddf9a=0x0;_0x1ddf9a<_0x1b88c6['length'];_0x1ddf9a++){_0x1bc381=_0x1b88c6[_0x1ddf9a];const _0x230bc0=kt(_0x1bc381);for(let _0x2acc91=0x0;_0x2acc91<_0x230bc0['length'];_0x2acc91++)if(!(_0x230bc0[_0x2acc91]==='.priority'&&_0x2acc91===_0x230bc0['length']-0x1)){if(!ps(_0x230bc0[_0x2acc91]))throw new Error(_0x32195b+'contains\x20an\x20invalid\x20key\x20('+_0x230bc0[_0x2acc91]+')\x20in\x20path\x20'+_0x1bc381['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1b88c6['sort'](Th);let _0x9964b1=null;for(_0x1ddf9a=0x0;_0x1ddf9a<_0x1b88c6['length'];_0x1ddf9a++){if(_0x1bc381=_0x1b88c6[_0x1ddf9a],_0x9964b1!==null&&$(_0x9964b1,_0x1bc381))throw new Error(_0x32195b+'contains\x20a\x20path\x20'+_0x9964b1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1bc381['toString']());_0x9964b1=_0x1bc381;}},hd=function(_0x368401,_0x17ce9d,_0x552c2e,_0x14a0b1){const _0x2b12ac=Nn(_0x368401,'values');if(!(_0x17ce9d&&typeof _0x17ce9d=='object')||Array['isArray'](_0x17ce9d))throw new Error(_0x2b12ac+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3aaabc=[];x(_0x17ce9d,(_0x2cdd8c,_0x39e453)=>{const _0x548dfb=new C(_0x2cdd8c);if(zt(_0x2b12ac,_0x39e453,A(_0x552c2e,_0x548dfb)),Gi(_0x548dfb)==='.priority'&&!Cn(_0x39e453))throw new Error(_0x2b12ac+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x548dfb['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3aaabc['push'](_0x548dfb);}),ld(_0x2b12ac,_0x3aaabc);},_s=function(_0x451f74,_0x3ab6cc,_0x24ffd0,_0x5c32e1){if(!na(_0x24ffd0))throw new Error(Nn(_0x451f74,_0x3ab6cc)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x24ffd0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0xbd1b1a,_0x45af4c,_0x390d13,_0x35ddd5){_0x390d13&&(_0x390d13=_0x390d13['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0xbd1b1a,_0x45af4c,_0x390d13);},gs=function(_0x3e938e,_0x2681c6){if(y(_0x2681c6)==='.info')throw new Error(_0x3e938e+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x408754,_0x586ca9){const _0x20032c=_0x586ca9['path']['toString']();if(typeof _0x586ca9['repoInfo']['host']!='string'||_0x586ca9['repoInfo']['host']['length']===0x0||!ps(_0x586ca9['repoInfo']['namespace'])&&_0x586ca9['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x20032c['length']!==0x0&&!cd(_0x20032c))throw new Error(Nn(_0x408754,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x1ba5d8,_0x38acbe){let _0x1a7391=null;for(let _0x401d34=0x0;_0x401d34<_0x38acbe['length'];_0x401d34++){const _0x3dc31d=_0x38acbe[_0x401d34],_0x5e248c=_0x3dc31d['getPath']();_0x1a7391!==null&&!qi(_0x5e248c,_0x1a7391['path'])&&(_0x1ba5d8['eventLists_']['push'](_0x1a7391),_0x1a7391=null),_0x1a7391===null&&(_0x1a7391={'events':[],'path':_0x5e248c}),_0x1a7391['events']['push'](_0x3dc31d);}_0x1a7391&&_0x1ba5d8['eventLists_']['push'](_0x1a7391);}function ia(_0x1b17a5,_0x5f20f5,_0x48b373){Bn(_0x1b17a5,_0x48b373),sa(_0x1b17a5,_0x2ed473=>qi(_0x2ed473,_0x5f20f5));}function V(_0x6021f6,_0xb17c4f,_0x31938d){Bn(_0x6021f6,_0x31938d),sa(_0x6021f6,_0xeae6e=>$(_0xeae6e,_0xb17c4f)||$(_0xb17c4f,_0xeae6e));}function sa(_0x32f34d,_0x191695){_0x32f34d['recursionDepth_']++;let _0x8c5ecb=!0x0;for(let _0x5f4dca=0x0;_0x5f4dca<_0x32f34d['eventLists_']['length'];_0x5f4dca++){const _0x460320=_0x32f34d['eventLists_'][_0x5f4dca];if(_0x460320){const _0x241d73=_0x460320['path'];_0x191695(_0x241d73)?(pd(_0x32f34d['eventLists_'][_0x5f4dca]),_0x32f34d['eventLists_'][_0x5f4dca]=null):_0x8c5ecb=!0x1;}}_0x8c5ecb&&(_0x32f34d['eventLists_']=[]),_0x32f34d['recursionDepth_']--;}function pd(_0x9f617){for(let _0x467c73=0x0;_0x467c73<_0x9f617['events']['length'];_0x467c73++){const _0x4de642=_0x9f617['events'][_0x467c73];if(_0x4de642!==null){_0x9f617['events'][_0x467c73]=null;const _0x2dbc44=_0x4de642['getEventRunner']();Et&&L('event:\x20'+_0x4de642['toString']()),lt(_0x2dbc44);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x514d29,_0x24880f,_0xcf2e65,_0x3346ae){this['repoInfo_']=_0x514d29,this['forceRestClient_']=_0x24880f,this['authTokenProvider_']=_0xcf2e65,this['appCheckProvider_']=_0x3346ae,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x17d015,_0x506dba,_0x4e2fa8){if(_0x17d015['stats_']=Hi(_0x17d015['repoInfo_']),_0x17d015['forceRestClient_']||Yl())_0x17d015['server_']=new fn(_0x17d015['repoInfo_'],(_0x648f42,_0x111c52,_0x3f7394,_0x3a7c02)=>{pr(_0x17d015,_0x648f42,_0x111c52,_0x3f7394,_0x3a7c02);},_0x17d015['authTokenProvider_'],_0x17d015['appCheckProvider_']),setTimeout(()=>_r(_0x17d015,!0x0),0x0);else{if(typeof _0x4e2fa8<'u'&&_0x4e2fa8!==null){if(typeof _0x4e2fa8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4e2fa8);}catch(_0x62e3f5){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x62e3f5);}}_0x17d015['persistentConnection_']=new ie(_0x17d015['repoInfo_'],_0x506dba,(_0x529474,_0x47c756,_0x5802af,_0x3ea0b9)=>{pr(_0x17d015,_0x529474,_0x47c756,_0x5802af,_0x3ea0b9);},_0x195a53=>{_r(_0x17d015,_0x195a53);},_0x2fd398=>{yd(_0x17d015,_0x2fd398);},_0x17d015['authTokenProvider_'],_0x17d015['appCheckProvider_'],_0x4e2fa8),_0x17d015['server_']=_0x17d015['persistentConnection_'];}_0x17d015['authTokenProvider_']['addTokenChangeListener'](_0x5dd747=>{_0x17d015['server_']['refreshAuthToken'](_0x5dd747);}),_0x17d015['appCheckProvider_']['addTokenChangeListener'](_0x313805=>{_0x17d015['server_']['refreshAppCheckToken'](_0x313805['token']);}),_0x17d015['statsReporter_']=eh(_0x17d015['repoInfo_'],()=>new eu(_0x17d015['stats_'],_0x17d015['server_'])),_0x17d015['infoData_']=new Yh(),_0x17d015['infoSyncTree_']=new dr({'startListening':(_0x2cb27f,_0x5a0a3a,_0x21d5c7,_0x1120a0)=>{let _0x111f4d=[];const _0x93b2b2=_0x17d015['infoData_']['getNode'](_0x2cb27f['_path']);return _0x93b2b2['isEmpty']()||(_0x111f4d=$t(_0x17d015['infoSyncTree_'],_0x2cb27f['_path'],_0x93b2b2),setTimeout(()=>{_0x1120a0('ok');},0x0)),_0x111f4d;},'stopListening':()=>{}}),ms(_0x17d015,'connected',!0x1),_0x17d015['serverSyncTree_']=new dr({'startListening':(_0x5034d3,_0x1082a1,_0x2ce8ab,_0x386358)=>(_0x17d015['server_']['listen'](_0x5034d3,_0x2ce8ab,_0x1082a1,(_0x253e21,_0x162852)=>{const _0x23882a=_0x386358(_0x253e21,_0x162852);V(_0x17d015['eventQueue_'],_0x5034d3['_path'],_0x23882a);}),[]),'stopListening':(_0x12b9e9,_0x2688ad)=>{_0x17d015['server_']['unlisten'](_0x12b9e9,_0x2688ad);}});}function oa(_0x12051e){const _0x16c2d2=_0x12051e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x16c2d2;}function jt(_0x423da4){return ed({'timestamp':oa(_0x423da4)});}function pr(_0x47bc1b,_0x405d56,_0x5152cc,_0xf485cb,_0x32f818){_0x47bc1b['dataUpdateCount']++;const _0x2b708b=new C(_0x405d56);_0x5152cc=_0x47bc1b['interceptServerDataCallback_']?_0x47bc1b['interceptServerDataCallback_'](_0x405d56,_0x5152cc):_0x5152cc;let _0x463b8c=[];if(_0x32f818){if(_0xf485cb){const _0x213906=ln(_0x5152cc,_0xd4ff61=>N(_0xd4ff61));_0x463b8c=Ku(_0x47bc1b['serverSyncTree_'],_0x2b708b,_0x213906,_0x32f818);}else{const _0x27ff79=N(_0x5152cc);_0x463b8c=Yo(_0x47bc1b['serverSyncTree_'],_0x2b708b,_0x27ff79,_0x32f818);}}else{if(_0xf485cb){const _0xa1dd45=ln(_0x5152cc,_0x3e34e6=>N(_0x3e34e6));_0x463b8c=qu(_0x47bc1b['serverSyncTree_'],_0x2b708b,_0xa1dd45);}else{const _0x9a15dd=N(_0x5152cc);_0x463b8c=$t(_0x47bc1b['serverSyncTree_'],_0x2b708b,_0x9a15dd);}}let _0x1e04ce=_0x2b708b;_0x463b8c['length']>0x0&&(_0x1e04ce=st(_0x47bc1b,_0x2b708b)),V(_0x47bc1b['eventQueue_'],_0x1e04ce,_0x463b8c);}function _r(_0x2746b9,_0xf1e893){ms(_0x2746b9,'connected',_0xf1e893),_0xf1e893===!0x1&&wd(_0x2746b9);}function yd(_0x1791f0,_0x2e09ad){x(_0x2e09ad,(_0x113923,_0x59319e)=>{ms(_0x1791f0,_0x113923,_0x59319e);});}function ms(_0x2afb7a,_0x59b622,_0x449635){const _0x190244=new C('/.info/'+_0x59b622),_0xa32fa6=N(_0x449635);_0x2afb7a['infoData_']['updateSnapshot'](_0x190244,_0xa32fa6);const _0x4efa9e=$t(_0x2afb7a['infoSyncTree_'],_0x190244,_0xa32fa6);V(_0x2afb7a['eventQueue_'],_0x190244,_0x4efa9e);}function Vn(_0x48da11){return _0x48da11['nextWriteId_']++;}function vd(_0x134f39,_0x1da7a8,_0x52d749){const _0xd55bcf=Yu(_0x134f39['serverSyncTree_'],_0x1da7a8);return _0xd55bcf!=null?Promise['resolve'](_0xd55bcf):_0x134f39['server_']['get'](_0x1da7a8)['then'](_0x3f02a3=>{const _0x5d00e8=N(_0x3f02a3)['withIndex'](_0x1da7a8['_queryParams']['getIndex']());bi(_0x134f39['serverSyncTree_'],_0x1da7a8,_0x52d749,!0x0);let _0x4bd85a;if(_0x1da7a8['_queryParams']['loadsAllData']())_0x4bd85a=$t(_0x134f39['serverSyncTree_'],_0x1da7a8['_path'],_0x5d00e8);else{const _0x91dafe=Mt(_0x134f39['serverSyncTree_'],_0x1da7a8);_0x4bd85a=Yo(_0x134f39['serverSyncTree_'],_0x1da7a8['_path'],_0x5d00e8,_0x91dafe);}return V(_0x134f39['eventQueue_'],_0x1da7a8['_path'],_0x4bd85a),wn(_0x134f39['serverSyncTree_'],_0x1da7a8,_0x52d749,null,!0x0),_0x5d00e8;},_0x1cd423=>(ut(_0x134f39,'get\x20for\x20query\x20'+O(_0x1da7a8)+'\x20failed:\x20'+_0x1cd423),Promise['reject'](new Error(_0x1cd423))));}function Ed(_0x171804,_0x4755a5,_0x44ae82,_0x575656,_0x48dc7b){ut(_0x171804,'set',{'path':_0x4755a5['toString'](),'value':_0x44ae82,'priority':_0x575656});const _0x1f8eac=jt(_0x171804),_0x217386=N(_0x44ae82,_0x575656),_0x11174e=xn(_0x171804['serverSyncTree_'],_0x4755a5),_0x390aeb=hs(_0x217386,_0x11174e,_0x1f8eac),_0x3c1fba=Vn(_0x171804),_0x58dba4=ss(_0x171804['serverSyncTree_'],_0x4755a5,_0x390aeb,_0x3c1fba,!0x0);Bn(_0x171804['eventQueue_'],_0x58dba4),_0x171804['server_']['put'](_0x4755a5['toString'](),_0x217386['val'](!0x0),(_0x46274c,_0x3848b5)=>{const _0x208853=_0x46274c==='ok';_0x208853||U('set\x20at\x20'+_0x4755a5+'\x20failed:\x20'+_0x46274c);const _0x331d68=pe(_0x171804['serverSyncTree_'],_0x3c1fba,!_0x208853);V(_0x171804['eventQueue_'],_0x4755a5,_0x331d68),Ai(_0x171804,_0x48dc7b,_0x46274c,_0x3848b5);});const _0x47ea8c=vs(_0x171804,_0x4755a5);st(_0x171804,_0x47ea8c),V(_0x171804['eventQueue_'],_0x47ea8c,[]);}function Id(_0x39351c,_0x17da33,_0x10f2e6,_0x4d0890){ut(_0x39351c,'update',{'path':_0x17da33['toString'](),'value':_0x10f2e6});let _0x2a0875=!0x0;const _0x41e559=jt(_0x39351c),_0x344a60={};if(x(_0x10f2e6,(_0x19ccbe,_0x55c3bd)=>{_0x2a0875=!0x1,_0x344a60[_0x19ccbe]=Zo(A(_0x17da33,_0x19ccbe),N(_0x55c3bd),_0x39351c['serverSyncTree_'],_0x41e559);}),_0x2a0875)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x39351c,_0x4d0890,'ok',void 0x0);else{const _0x645889=Vn(_0x39351c),_0x1b2c8b=Gu(_0x39351c['serverSyncTree_'],_0x17da33,_0x344a60,_0x645889);Bn(_0x39351c['eventQueue_'],_0x1b2c8b),_0x39351c['server_']['merge'](_0x17da33['toString'](),_0x10f2e6,(_0x4e68b4,_0x494344)=>{const _0x275e68=_0x4e68b4==='ok';_0x275e68||U('update\x20at\x20'+_0x17da33+'\x20failed:\x20'+_0x4e68b4);const _0xbc3821=pe(_0x39351c['serverSyncTree_'],_0x645889,!_0x275e68),_0x3db58c=_0xbc3821['length']>0x0?st(_0x39351c,_0x17da33):_0x17da33;V(_0x39351c['eventQueue_'],_0x3db58c,_0xbc3821),Ai(_0x39351c,_0x4d0890,_0x4e68b4,_0x494344);}),x(_0x10f2e6,_0x8c48e3=>{const _0x226ec0=vs(_0x39351c,A(_0x17da33,_0x8c48e3));st(_0x39351c,_0x226ec0);}),V(_0x39351c['eventQueue_'],_0x17da33,[]);}}function wd(_0x30dd45){ut(_0x30dd45,'onDisconnectEvents');const _0x340ba3=jt(_0x30dd45),_0x2858fc=pn();Ei(_0x30dd45['onDisconnect_'],w(),(_0x588266,_0x96d5a4)=>{const _0x1cae1e=Zo(_0x588266,_0x96d5a4,_0x30dd45['serverSyncTree_'],_0x340ba3);Mo(_0x2858fc,_0x588266,_0x1cae1e);});let _0x57b4e4=[];Ei(_0x2858fc,w(),(_0x15fc2d,_0x90206c)=>{_0x57b4e4=_0x57b4e4['concat']($t(_0x30dd45['serverSyncTree_'],_0x15fc2d,_0x90206c));const _0x5c9849=vs(_0x30dd45,_0x15fc2d);st(_0x30dd45,_0x5c9849);}),_0x30dd45['onDisconnect_']=pn(),V(_0x30dd45['eventQueue_'],w(),_0x57b4e4);}function Cd(_0x46173b,_0x67439c,_0x504486){let _0x1a7a64;y(_0x67439c['_path'])==='.info'?_0x1a7a64=bi(_0x46173b['infoSyncTree_'],_0x67439c,_0x504486):_0x1a7a64=bi(_0x46173b['serverSyncTree_'],_0x67439c,_0x504486),ia(_0x46173b['eventQueue_'],_0x67439c['_path'],_0x1a7a64);}function Td(_0x147088,_0x2e8c96,_0x5df9a5){let _0x149902;y(_0x2e8c96['_path'])==='.info'?_0x149902=wn(_0x147088['infoSyncTree_'],_0x2e8c96,_0x5df9a5):_0x149902=wn(_0x147088['serverSyncTree_'],_0x2e8c96,_0x5df9a5),ia(_0x147088['eventQueue_'],_0x2e8c96['_path'],_0x149902);}function aa(_0x2616ab){_0x2616ab['persistentConnection_']&&_0x2616ab['persistentConnection_']['interrupt'](ra);}function Sd(_0x10334e){_0x10334e['persistentConnection_']&&_0x10334e['persistentConnection_']['resume'](ra);}function ut(_0x15ce42,..._0x294778){let _0x2dd423='';_0x15ce42['persistentConnection_']&&(_0x2dd423=_0x15ce42['persistentConnection_']['id']+':'),L(_0x2dd423,..._0x294778);}function Ai(_0x1ef8ec,_0x318ae9,_0x1199ed,_0x308740){_0x318ae9&&lt(()=>{if(_0x1199ed==='ok')_0x318ae9(null);else{const _0x45ccdb=(_0x1199ed||'error')['toUpperCase']();let _0x1a7c48=_0x45ccdb;_0x308740&&(_0x1a7c48+=':\x20'+_0x308740);const _0x1a19d2=new Error(_0x1a7c48);_0x1a19d2['code']=_0x45ccdb,_0x318ae9(_0x1a19d2);}});}function bd(_0x5c32f5,_0xbcf8d5,_0x16fdc3,_0x146454,_0x4c1401,_0x365892){ut(_0x5c32f5,'transaction\x20on\x20'+_0xbcf8d5);const _0x487155={'path':_0xbcf8d5,'update':_0x16fdc3,'onComplete':_0x146454,'status':null,'order':to(),'applyLocally':_0x365892,'retryCount':0x0,'unwatcher':_0x4c1401,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x434b34=ys(_0x5c32f5,_0xbcf8d5,void 0x0);_0x487155['currentInputSnapshot']=_0x434b34;const _0x34027f=_0x487155['update'](_0x434b34['val']());if(_0x34027f===void 0x0)_0x487155['unwatcher'](),_0x487155['currentOutputSnapshotRaw']=null,_0x487155['currentOutputSnapshotResolved']=null,_0x487155['onComplete']&&_0x487155['onComplete'](null,!0x1,_0x487155['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x34027f,_0x487155['path']),_0x487155['status']=0x0;const _0x363b25=Un(_0x5c32f5['transactionQueueTree_'],_0xbcf8d5),_0x54cd3a=Ge(_0x363b25)||[];_0x54cd3a['push'](_0x487155),fs(_0x363b25,_0x54cd3a);let _0x2e38cb;typeof _0x34027f=='object'&&_0x34027f!==null&&Y(_0x34027f,'.priority')?(_0x2e38cb=Oe(_0x34027f,'.priority'),f(Cn(_0x2e38cb),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2e38cb=(xn(_0x5c32f5['serverSyncTree_'],_0xbcf8d5)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3dc8c5=jt(_0x5c32f5),_0x1118de=N(_0x34027f,_0x2e38cb),_0x181d3e=hs(_0x1118de,_0x434b34,_0x3dc8c5);_0x487155['currentOutputSnapshotRaw']=_0x1118de,_0x487155['currentOutputSnapshotResolved']=_0x181d3e,_0x487155['currentWriteId']=Vn(_0x5c32f5);const _0x2df6a7=ss(_0x5c32f5['serverSyncTree_'],_0xbcf8d5,_0x181d3e,_0x487155['currentWriteId'],_0x487155['applyLocally']);V(_0x5c32f5['eventQueue_'],_0xbcf8d5,_0x2df6a7),Hn(_0x5c32f5,_0x5c32f5['transactionQueueTree_']);}}function ys(_0x2ae025,_0x2a5499,_0x36d39f){return xn(_0x2ae025['serverSyncTree_'],_0x2a5499,_0x36d39f)||g['EMPTY_NODE'];}function Hn(_0x311760,_0xa8a1df=_0x311760['transactionQueueTree_']){if(_0xa8a1df||$n(_0x311760,_0xa8a1df),Ge(_0xa8a1df)){const _0x4d146d=la(_0x311760,_0xa8a1df);f(_0x4d146d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4d146d['every'](_0x235d9c=>_0x235d9c['status']===0x0)&&Rd(_0x311760,Gt(_0xa8a1df),_0x4d146d);}else ea(_0xa8a1df)&&Wn(_0xa8a1df,_0x4d5ec8=>{Hn(_0x311760,_0x4d5ec8);});}function Rd(_0x395872,_0x1ab9c0,_0x296e2c){const _0x23f5f7=_0x296e2c['map'](_0x27f784=>_0x27f784['currentWriteId']),_0xdf258e=ys(_0x395872,_0x1ab9c0,_0x23f5f7);let _0xdf4f3=_0xdf258e;const _0x5bad3d=_0xdf258e['hash']();for(let _0x362081=0x0;_0x362081<_0x296e2c['length'];_0x362081++){const _0x389842=_0x296e2c[_0x362081];f(_0x389842['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x389842['status']=0x1,_0x389842['retryCount']++;const _0x44395a=F(_0x1ab9c0,_0x389842['path']);_0xdf4f3=_0xdf4f3['updateChild'](_0x44395a,_0x389842['currentOutputSnapshotRaw']);}const _0x169c24=_0xdf4f3['val'](!0x0),_0x33c3cc=_0x1ab9c0;_0x395872['server_']['put'](_0x33c3cc['toString'](),_0x169c24,_0x52278e=>{ut(_0x395872,'transaction\x20put\x20response',{'path':_0x33c3cc['toString'](),'status':_0x52278e});let _0x3472a3=[];if(_0x52278e==='ok'){const _0x55d217=[];for(let _0x4c72fe=0x0;_0x4c72fe<_0x296e2c['length'];_0x4c72fe++)_0x296e2c[_0x4c72fe]['status']=0x2,_0x3472a3=_0x3472a3['concat'](pe(_0x395872['serverSyncTree_'],_0x296e2c[_0x4c72fe]['currentWriteId'])),_0x296e2c[_0x4c72fe]['onComplete']&&_0x55d217['push'](()=>_0x296e2c[_0x4c72fe]['onComplete'](null,!0x0,_0x296e2c[_0x4c72fe]['currentOutputSnapshotResolved'])),_0x296e2c[_0x4c72fe]['unwatcher']();$n(_0x395872,Un(_0x395872['transactionQueueTree_'],_0x1ab9c0)),Hn(_0x395872,_0x395872['transactionQueueTree_']),V(_0x395872['eventQueue_'],_0x1ab9c0,_0x3472a3);for(let _0x4bd669=0x0;_0x4bd669<_0x55d217['length'];_0x4bd669++)lt(_0x55d217[_0x4bd669]);}else{if(_0x52278e==='datastale'){for(let _0x2b3e81=0x0;_0x2b3e81<_0x296e2c['length'];_0x2b3e81++)_0x296e2c[_0x2b3e81]['status']===0x3?_0x296e2c[_0x2b3e81]['status']=0x4:_0x296e2c[_0x2b3e81]['status']=0x0;}else{U('transaction\x20at\x20'+_0x33c3cc['toString']()+'\x20failed:\x20'+_0x52278e);for(let _0x595448=0x0;_0x595448<_0x296e2c['length'];_0x595448++)_0x296e2c[_0x595448]['status']=0x4,_0x296e2c[_0x595448]['abortReason']=_0x52278e;}st(_0x395872,_0x1ab9c0);}},_0x5bad3d);}function st(_0x51d301,_0x24fe76){const _0x36fe73=ca(_0x51d301,_0x24fe76),_0x3193b2=Gt(_0x36fe73),_0x13a6fb=la(_0x51d301,_0x36fe73);return Ad(_0x51d301,_0x13a6fb,_0x3193b2),_0x3193b2;}function Ad(_0x2cd391,_0x10e05f,_0x3b07f9){if(_0x10e05f['length']===0x0)return;const _0xcd8b15=[];let _0x304cde=[];const _0x42f730=_0x10e05f['filter'](_0x140395=>_0x140395['status']===0x0)['map'](_0x4333a7=>_0x4333a7['currentWriteId']);for(let _0x7367e5=0x0;_0x7367e5<_0x10e05f['length'];_0x7367e5++){const _0xc9e413=_0x10e05f[_0x7367e5],_0x2c6794=F(_0x3b07f9,_0xc9e413['path']);let _0x4b6673=!0x1,_0x35a8f5;if(f(_0x2c6794!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xc9e413['status']===0x4)_0x4b6673=!0x0,_0x35a8f5=_0xc9e413['abortReason'],_0x304cde=_0x304cde['concat'](pe(_0x2cd391['serverSyncTree_'],_0xc9e413['currentWriteId'],!0x0));else{if(_0xc9e413['status']===0x0){if(_0xc9e413['retryCount']>=_d)_0x4b6673=!0x0,_0x35a8f5='maxretry',_0x304cde=_0x304cde['concat'](pe(_0x2cd391['serverSyncTree_'],_0xc9e413['currentWriteId'],!0x0));else{const _0x131266=ys(_0x2cd391,_0xc9e413['path'],_0x42f730);_0xc9e413['currentInputSnapshot']=_0x131266;const _0x1423e0=_0x10e05f[_0x7367e5]['update'](_0x131266['val']());if(_0x1423e0!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1423e0,_0xc9e413['path']);let _0x2be24b=N(_0x1423e0);typeof _0x1423e0=='object'&&_0x1423e0!=null&&Y(_0x1423e0,'.priority')||(_0x2be24b=_0x2be24b['updatePriority'](_0x131266['getPriority']()));const _0x1b9569=_0xc9e413['currentWriteId'],_0x2aff79=jt(_0x2cd391),_0x1e1af0=hs(_0x2be24b,_0x131266,_0x2aff79);_0xc9e413['currentOutputSnapshotRaw']=_0x2be24b,_0xc9e413['currentOutputSnapshotResolved']=_0x1e1af0,_0xc9e413['currentWriteId']=Vn(_0x2cd391),_0x42f730['splice'](_0x42f730['indexOf'](_0x1b9569),0x1),_0x304cde=_0x304cde['concat'](ss(_0x2cd391['serverSyncTree_'],_0xc9e413['path'],_0x1e1af0,_0xc9e413['currentWriteId'],_0xc9e413['applyLocally'])),_0x304cde=_0x304cde['concat'](pe(_0x2cd391['serverSyncTree_'],_0x1b9569,!0x0));}else _0x4b6673=!0x0,_0x35a8f5='nodata',_0x304cde=_0x304cde['concat'](pe(_0x2cd391['serverSyncTree_'],_0xc9e413['currentWriteId'],!0x0));}}}V(_0x2cd391['eventQueue_'],_0x3b07f9,_0x304cde),_0x304cde=[],_0x4b6673&&(_0x10e05f[_0x7367e5]['status']=0x2,function(_0x481603){setTimeout(_0x481603,Math['floor'](0x0));}(_0x10e05f[_0x7367e5]['unwatcher']),_0x10e05f[_0x7367e5]['onComplete']&&(_0x35a8f5==='nodata'?_0xcd8b15['push'](()=>_0x10e05f[_0x7367e5]['onComplete'](null,!0x1,_0x10e05f[_0x7367e5]['currentInputSnapshot'])):_0xcd8b15['push'](()=>_0x10e05f[_0x7367e5]['onComplete'](new Error(_0x35a8f5),!0x1,null))));}$n(_0x2cd391,_0x2cd391['transactionQueueTree_']);for(let _0x1a3c66=0x0;_0x1a3c66<_0xcd8b15['length'];_0x1a3c66++)lt(_0xcd8b15[_0x1a3c66]);Hn(_0x2cd391,_0x2cd391['transactionQueueTree_']);}function ca(_0x44e528,_0x293dd7){let _0x438991,_0x3f8eb7=_0x44e528['transactionQueueTree_'];for(_0x438991=y(_0x293dd7);_0x438991!==null&&Ge(_0x3f8eb7)===void 0x0;)_0x3f8eb7=Un(_0x3f8eb7,_0x438991),_0x293dd7=b(_0x293dd7),_0x438991=y(_0x293dd7);return _0x3f8eb7;}function la(_0x735616,_0x59f937){const _0x4fe684=[];return ha(_0x735616,_0x59f937,_0x4fe684),_0x4fe684['sort']((_0x378db9,_0x2dfdaa)=>_0x378db9['order']-_0x2dfdaa['order']),_0x4fe684;}function ha(_0x2edf75,_0x11f56c,_0x1be6e7){const _0x35abcf=Ge(_0x11f56c);if(_0x35abcf){for(let _0x3f6241=0x0;_0x3f6241<_0x35abcf['length'];_0x3f6241++)_0x1be6e7['push'](_0x35abcf[_0x3f6241]);}Wn(_0x11f56c,_0x12b117=>{ha(_0x2edf75,_0x12b117,_0x1be6e7);});}function $n(_0x4c66e3,_0x1bff0e){const _0x4505e9=Ge(_0x1bff0e);if(_0x4505e9){let _0x30676f=0x0;for(let _0xbdbfa2=0x0;_0xbdbfa2<_0x4505e9['length'];_0xbdbfa2++)_0x4505e9[_0xbdbfa2]['status']!==0x2&&(_0x4505e9[_0x30676f]=_0x4505e9[_0xbdbfa2],_0x30676f++);_0x4505e9['length']=_0x30676f,fs(_0x1bff0e,_0x4505e9['length']>0x0?_0x4505e9:void 0x0);}Wn(_0x1bff0e,_0x5cd4f=>{$n(_0x4c66e3,_0x5cd4f);});}function vs(_0xbe787c,_0x7d8a0a){const _0x49ea72=Gt(ca(_0xbe787c,_0x7d8a0a)),_0x55c531=Un(_0xbe787c['transactionQueueTree_'],_0x7d8a0a);return sd(_0x55c531,_0x1de487=>{ai(_0xbe787c,_0x1de487);}),ai(_0xbe787c,_0x55c531),ta(_0x55c531,_0x127d05=>{ai(_0xbe787c,_0x127d05);}),_0x49ea72;}function ai(_0x29bd05,_0xd0e01f){const _0x5d2053=Ge(_0xd0e01f);if(_0x5d2053){const _0x153c14=[];let _0x706634=[],_0x27c1ad=-0x1;for(let _0x18bd17=0x0;_0x18bd17<_0x5d2053['length'];_0x18bd17++)_0x5d2053[_0x18bd17]['status']===0x3||(_0x5d2053[_0x18bd17]['status']===0x1?(f(_0x27c1ad===_0x18bd17-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x27c1ad=_0x18bd17,_0x5d2053[_0x18bd17]['status']=0x3,_0x5d2053[_0x18bd17]['abortReason']='set'):(f(_0x5d2053[_0x18bd17]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5d2053[_0x18bd17]['unwatcher'](),_0x706634=_0x706634['concat'](pe(_0x29bd05['serverSyncTree_'],_0x5d2053[_0x18bd17]['currentWriteId'],!0x0)),_0x5d2053[_0x18bd17]['onComplete']&&_0x153c14['push'](_0x5d2053[_0x18bd17]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x27c1ad===-0x1?fs(_0xd0e01f,void 0x0):_0x5d2053['length']=_0x27c1ad+0x1,V(_0x29bd05['eventQueue_'],Gt(_0xd0e01f),_0x706634);for(let _0x578eba=0x0;_0x578eba<_0x153c14['length'];_0x578eba++)lt(_0x153c14[_0x578eba]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x3639d8){let _0x4fe111='';const _0x31da6c=_0x3639d8['split']('/');for(let _0xe920a3=0x0;_0xe920a3<_0x31da6c['length'];_0xe920a3++)if(_0x31da6c[_0xe920a3]['length']>0x0){let _0x5b86dc=_0x31da6c[_0xe920a3];try{_0x5b86dc=decodeURIComponent(_0x5b86dc['replace'](/\+/g,'\x20'));}catch{}_0x4fe111+='/'+_0x5b86dc;}return _0x4fe111;}function Nd(_0x49dc40){const _0x72cffe={};_0x49dc40['charAt'](0x0)==='?'&&(_0x49dc40=_0x49dc40['substring'](0x1));for(const _0x135f4a of _0x49dc40['split']('&')){if(_0x135f4a['length']===0x0)continue;const _0x312e25=_0x135f4a['split']('=');_0x312e25['length']===0x2?_0x72cffe[decodeURIComponent(_0x312e25[0x0])]=decodeURIComponent(_0x312e25[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x135f4a+'\x27\x20in\x20query\x20\x27'+_0x49dc40+'\x27');}return _0x72cffe;}const gr=function(_0x377be,_0x3bc661){const _0x492af5=Pd(_0x377be),_0x289b8d=_0x492af5['namespace'];_0x492af5['domain']==='firebase.com'&&oe(_0x492af5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x289b8d||_0x289b8d==='undefined')&&_0x492af5['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x492af5['secure']||Bl();const _0x1c65de=_0x492af5['scheme']==='ws'||_0x492af5['scheme']==='wss';return{'repoInfo':new _o(_0x492af5['host'],_0x492af5['secure'],_0x289b8d,_0x1c65de,_0x3bc661,'',_0x289b8d!==_0x492af5['subdomain']),'path':new C(_0x492af5['pathString'])};},Pd=function(_0x3e905e){let _0x51693b='',_0x5a4a31='',_0x2b45cb='',_0x4cfe03='',_0x2dc83d='',_0x22fd83=!0x0,_0x3812de='https',_0x1a50cb=0x1bb;if(typeof _0x3e905e=='string'){let _0x1539c0=_0x3e905e['indexOf']('//');_0x1539c0>=0x0&&(_0x3812de=_0x3e905e['substring'](0x0,_0x1539c0-0x1),_0x3e905e=_0x3e905e['substring'](_0x1539c0+0x2));let _0x23200e=_0x3e905e['indexOf']('/');_0x23200e===-0x1&&(_0x23200e=_0x3e905e['length']);let _0x52505c=_0x3e905e['indexOf']('?');_0x52505c===-0x1&&(_0x52505c=_0x3e905e['length']),_0x51693b=_0x3e905e['substring'](0x0,Math['min'](_0x23200e,_0x52505c)),_0x23200e<_0x52505c&&(_0x4cfe03=kd(_0x3e905e['substring'](_0x23200e,_0x52505c)));const _0x343e86=Nd(_0x3e905e['substring'](Math['min'](_0x3e905e['length'],_0x52505c)));_0x1539c0=_0x51693b['indexOf'](':'),_0x1539c0>=0x0?(_0x22fd83=_0x3812de==='https'||_0x3812de==='wss',_0x1a50cb=parseInt(_0x51693b['substring'](_0x1539c0+0x1),0xa)):_0x1539c0=_0x51693b['length'];const _0x25354e=_0x51693b['slice'](0x0,_0x1539c0);if(_0x25354e['toLowerCase']()==='localhost')_0x5a4a31='localhost';else{if(_0x25354e['split']('.')['length']<=0x2)_0x5a4a31=_0x25354e;else{const _0x2740eb=_0x51693b['indexOf']('.');_0x2b45cb=_0x51693b['substring'](0x0,_0x2740eb)['toLowerCase'](),_0x5a4a31=_0x51693b['substring'](_0x2740eb+0x1),_0x2dc83d=_0x2b45cb;}}'ns'in _0x343e86&&(_0x2dc83d=_0x343e86['ns']);}return{'host':_0x51693b,'port':_0x1a50cb,'domain':_0x5a4a31,'subdomain':_0x2b45cb,'secure':_0x22fd83,'scheme':_0x3812de,'pathString':_0x4cfe03,'namespace':_0x2dc83d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x18ece8=0x0;const _0x47b48d=[];return function(_0x584aa0){const _0x3464a9=_0x584aa0===_0x18ece8;_0x18ece8=_0x584aa0;let _0xee4fca;const _0x2fa7c9=new Array(0x8);for(_0xee4fca=0x7;_0xee4fca>=0x0;_0xee4fca--)_0x2fa7c9[_0xee4fca]=mr['charAt'](_0x584aa0%0x40),_0x584aa0=Math['floor'](_0x584aa0/0x40);f(_0x584aa0===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x18a2d5=_0x2fa7c9['join']('');if(_0x3464a9){for(_0xee4fca=0xb;_0xee4fca>=0x0&&_0x47b48d[_0xee4fca]===0x3f;_0xee4fca--)_0x47b48d[_0xee4fca]=0x0;_0x47b48d[_0xee4fca]++;}else{for(_0xee4fca=0x0;_0xee4fca<0xc;_0xee4fca++)_0x47b48d[_0xee4fca]=Math['floor'](Math['random']()*0x40);}for(_0xee4fca=0x0;_0xee4fca<0xc;_0xee4fca++)_0x18a2d5+=mr['charAt'](_0x47b48d[_0xee4fca]);return f(_0x18a2d5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x18a2d5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x34a43f,_0x45ecfc,_0x565398,_0x347de8){this['eventType']=_0x34a43f,this['eventRegistration']=_0x45ecfc,this['snapshot']=_0x565398,this['prevName']=_0x347de8;}['getPath'](){const _0x5342db=this['snapshot']['ref'];return this['eventType']==='value'?_0x5342db['_path']:_0x5342db['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1705af,_0x118599,_0x10284f){this['eventRegistration']=_0x1705af,this['error']=_0x118599,this['path']=_0x10284f;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x37aef9,_0x5806d5){this['snapshotCallback']=_0x37aef9,this['cancelCallback']=_0x5806d5;}['onValue'](_0x4928c2,_0x183a78){this['snapshotCallback']['call'](null,_0x4928c2,_0x183a78);}['onCancel'](_0x2dda6d){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2dda6d);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x912830){return this['snapshotCallback']===_0x912830['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x912830['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x912830['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3c29d8,_0x4390d8,_0x46227b,_0x21fa1e){this['_repo']=_0x3c29d8,this['_path']=_0x4390d8,this['_queryParams']=_0x46227b,this['_orderByCalled']=_0x21fa1e;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xec629e=nr(this['_queryParams']),_0x1b3b27=Bi(_0xec629e);return _0x1b3b27==='{}'?'default':_0x1b3b27;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4af98d){if(_0x4af98d=k(_0x4af98d),!(_0x4af98d instanceof be))return!0x1;const _0x44eeda=this['_repo']===_0x4af98d['_repo'],_0x5d0558=qi(this['_path'],_0x4af98d['_path']),_0xc980a1=this['_queryIdentifier']===_0x4af98d['_queryIdentifier'];return _0x44eeda&&_0x5d0558&&_0xc980a1;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x395a6e,_0x359193){if(_0x395a6e['_orderByCalled']===!0x0)throw new Error(_0x359193+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x1b2afa){let _0x4f0136=null,_0x57924b=null;if(_0x1b2afa['hasStart']()&&(_0x4f0136=_0x1b2afa['getIndexStartValue']()),_0x1b2afa['hasEnd']()&&(_0x57924b=_0x1b2afa['getIndexEndValue']()),_0x1b2afa['getIndex']()===ye){const _0x2dbcd7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x55e08f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1b2afa['hasStart']()){if(_0x1b2afa['getIndexStartName']()!==xe)throw new Error(_0x2dbcd7);if(typeof _0x4f0136!='string')throw new Error(_0x55e08f);}if(_0x1b2afa['hasEnd']()){if(_0x1b2afa['getIndexEndName']()!==Ie)throw new Error(_0x2dbcd7);if(typeof _0x57924b!='string')throw new Error(_0x55e08f);}}else{if(_0x1b2afa['getIndex']()===R){if(_0x4f0136!=null&&!Cn(_0x4f0136)||_0x57924b!=null&&!Cn(_0x57924b))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1b2afa['getIndex']()instanceof Ki||_0x1b2afa['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4f0136!=null&&typeof _0x4f0136=='object'||_0x57924b!=null&&typeof _0x57924b=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2f0cdf){if(_0x2f0cdf['hasStart']()&&_0x2f0cdf['hasEnd']()&&_0x2f0cdf['hasLimit']()&&!_0x2f0cdf['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x1e0118,_0x44458c){super(_0x1e0118,_0x44458c,new Qi(),!0x1);}get['parent'](){const _0x3edb61=To(this['_path']);return _0x3edb61===null?null:new Z(this['_repo'],_0x3edb61);}get['root'](){let _0x1c558e=this;for(;_0x1c558e['parent']!==null;)_0x1c558e=_0x1c558e['parent'];return _0x1c558e;}}class rt{constructor(_0xff8397,_0x5c1df8,_0x97c12c){this['_node']=_0xff8397,this['ref']=_0x5c1df8,this['_index']=_0x97c12c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2579af){const _0x170b63=new C(_0x2579af),_0x5ac793=Lt(this['ref'],_0x2579af);return new rt(this['_node']['getChild'](_0x170b63),_0x5ac793,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2d3c7d){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4b293c,_0x18858e)=>_0x2d3c7d(new rt(_0x18858e,Lt(this['ref'],_0x4b293c),R)));}['hasChild'](_0x4b7cac){const _0x198049=new C(_0x4b7cac);return!this['_node']['getChild'](_0x198049)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x58199c,_0x29e748){return _0x58199c=k(_0x58199c),_0x58199c['_checkNotDeleted']('ref'),_0x29e748!==void 0x0?Lt(_0x58199c['_root'],_0x29e748):_0x58199c['_root'];}function Lt(_0x1e28fb,_0x27e133){return _0x1e28fb=k(_0x1e28fb),y(_0x1e28fb['_path'])===null?ud('child','path',_0x27e133):_s('child','path',_0x27e133),new Z(_0x1e28fb['_repo'],A(_0x1e28fb['_path'],_0x27e133));}function d_(_0x40b639,_0x2aa588){_0x40b639=k(_0x40b639),gs('push',_0x40b639['_path']),qt('push',_0x2aa588,_0x40b639['_path'],!0x0);const _0x2a0e92=oa(_0x40b639['_repo']),_0x3e2f4e=Od(_0x2a0e92),_0x101597=Lt(_0x40b639,_0x3e2f4e),_0x39ec51=Lt(_0x40b639,_0x3e2f4e);let _0xfd94d;return _0x2aa588!=null?_0xfd94d=Ld(_0x39ec51,_0x2aa588)['then'](()=>_0x39ec51):_0xfd94d=Promise['resolve'](_0x39ec51),_0x101597['then']=_0xfd94d['then']['bind'](_0xfd94d),_0x101597['catch']=_0xfd94d['then']['bind'](_0xfd94d,void 0x0),_0x101597;}function Ld(_0x1509d7,_0x419768){_0x1509d7=k(_0x1509d7),gs('set',_0x1509d7['_path']),qt('set',_0x419768,_0x1509d7['_path'],!0x1);const _0x56fe76=new Ve();return Ed(_0x1509d7['_repo'],_0x1509d7['_path'],_0x419768,null,_0x56fe76['wrapCallback'](()=>{})),_0x56fe76['promise'];}function f_(_0x25b0ac,_0x2a8b32){hd('update',_0x2a8b32,_0x25b0ac['_path']);const _0x152093=new Ve();return Id(_0x25b0ac['_repo'],_0x25b0ac['_path'],_0x2a8b32,_0x152093['wrapCallback'](()=>{})),_0x152093['promise'];}function p_(_0x2c5746){_0x2c5746=k(_0x2c5746);const _0x1d23e5=new ua(()=>{}),_0x4027d5=new qn(_0x1d23e5);return vd(_0x2c5746['_repo'],_0x2c5746,_0x4027d5)['then'](_0x259c2c=>new rt(_0x259c2c,new Z(_0x2c5746['_repo'],_0x2c5746['_path']),_0x2c5746['_queryParams']['getIndex']()));}class qn{constructor(_0x225750){this['callbackContext']=_0x225750;}['respondsTo'](_0x181733){return _0x181733==='value';}['createEvent'](_0x425d93,_0x21cedc){const _0x4243f7=_0x21cedc['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x425d93['snapshotNode'],new Z(_0x21cedc['_repo'],_0x21cedc['_path']),_0x4243f7));}['getEventRunner'](_0x157c4d){return _0x157c4d['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x157c4d['error']):()=>this['callbackContext']['onValue'](_0x157c4d['snapshot'],null);}['createCancelEvent'](_0x173bb5,_0x366bc1){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x173bb5,_0x366bc1):null;}['matches'](_0x47a495){return _0x47a495 instanceof qn?!_0x47a495['callbackContext']||!this['callbackContext']?!0x0:_0x47a495['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x25658c,_0x341e20,_0x3f2e33,_0x536603,_0x56b026){const _0x3b9bee=new ua(_0x3f2e33,void 0x0),_0x5a0302=new qn(_0x3b9bee);return Cd(_0x25658c['_repo'],_0x25658c,_0x5a0302),()=>Td(_0x25658c['_repo'],_0x25658c,_0x5a0302);}function Fd(_0x92f276,_0x1a9f6e,_0x3c347c,_0x3ec351){return xd(_0x92f276,'value',_0x1a9f6e);}class dt{}class pa extends dt{constructor(_0x49278c,_0x1e096b){super(),this['_value']=_0x49278c,this['_key']=_0x1e096b,this['type']='endAt';}['_apply'](_0x46d921){qt('endAt',this['_value'],_0x46d921['_path'],!0x0);const _0x287a80=Kh(_0x46d921['_queryParams'],this['_value'],this['_key']);if(fa(_0x287a80),Gn(_0x287a80),_0x46d921['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x46d921['_repo'],_0x46d921['_path'],_0x287a80,_0x46d921['_orderByCalled']);}}function __(_0x5ebb1a,_0x2d92d2){return new pa(_0x5ebb1a,_0x2d92d2);}class _a extends dt{constructor(_0x42ae84,_0x4dfb7f){super(),this['_value']=_0x42ae84,this['_key']=_0x4dfb7f,this['type']='startAt';}['_apply'](_0xc5b5f5){qt('startAt',this['_value'],_0xc5b5f5['_path'],!0x0);const _0x1ff0fe=jh(_0xc5b5f5['_queryParams'],this['_value'],this['_key']);if(fa(_0x1ff0fe),Gn(_0x1ff0fe),_0xc5b5f5['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0xc5b5f5['_repo'],_0xc5b5f5['_path'],_0x1ff0fe,_0xc5b5f5['_orderByCalled']);}}function g_(_0x35b8a4=null,_0x5e927e){return new _a(_0x35b8a4,_0x5e927e);}class Ud extends dt{constructor(_0x5da364){super(),this['_limit']=_0x5da364,this['type']='limitToFirst';}['_apply'](_0x51e837){if(_0x51e837['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x51e837['_repo'],_0x51e837['_path'],zh(_0x51e837['_queryParams'],this['_limit']),_0x51e837['_orderByCalled']);}}function m_(_0x20d140){if(Math['floor'](_0x20d140)!==_0x20d140||_0x20d140<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x20d140);}class Wd extends dt{constructor(_0x2c470a){super(),this['_path']=_0x2c470a,this['type']='orderByChild';}['_apply'](_0x42abca){da(_0x42abca,'orderByChild');const _0x5db984=new C(this['_path']);if(v(_0x5db984))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x981182=new Ki(_0x5db984),_0x279868=Do(_0x42abca['_queryParams'],_0x981182);return Gn(_0x279868),new be(_0x42abca['_repo'],_0x42abca['_path'],_0x279868,!0x0);}}function y_(_0x1154dd){if(_0x1154dd==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1154dd==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1154dd==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x1154dd),new Wd(_0x1154dd);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x9bc80c){da(_0x9bc80c,'orderByKey');const _0x596065=Do(_0x9bc80c['_queryParams'],ye);return Gn(_0x596065),new be(_0x9bc80c['_repo'],_0x9bc80c['_path'],_0x596065,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x2118ac,_0x157a95){super(),this['_value']=_0x2118ac,this['_key']=_0x157a95,this['type']='equalTo';}['_apply'](_0x2339a2){if(qt('equalTo',this['_value'],_0x2339a2['_path'],!0x1),_0x2339a2['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2339a2['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2339a2));}}function E_(_0x44985b,_0x2ce400){return new Vd(_0x44985b,_0x2ce400);}function I_(_0x181b28,..._0x6d20dd){let _0x28b123=k(_0x181b28);for(const _0x5bd544 of _0x6d20dd)_0x28b123=_0x5bd544['_apply'](_0x28b123);return _0x28b123;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x4ebff4,_0x2c9a2f,_0x40d46e,_0xe7ddfa){const _0x1375d2=_0x2c9a2f['lastIndexOf'](':'),_0x643d29=_0x2c9a2f['substring'](0x0,_0x1375d2),_0x3cf146=Wt(_0x643d29);_0x4ebff4['repoInfo_']=new _o(_0x2c9a2f,_0x3cf146,_0x4ebff4['repoInfo_']['namespace'],_0x4ebff4['repoInfo_']['webSocketOnly'],_0x4ebff4['repoInfo_']['nodeAdmin'],_0x4ebff4['repoInfo_']['persistenceKey'],_0x4ebff4['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x40d46e),_0xe7ddfa&&(_0x4ebff4['authTokenProvider_']=_0xe7ddfa);}function qd(_0x4ee9df,_0x5908ac,_0x425db9,_0x247103,_0x5832c9){let _0x1aea1c=_0x247103||_0x4ee9df['options']['databaseURL'];_0x1aea1c===void 0x0&&(_0x4ee9df['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4ee9df['options']['projectId']),_0x1aea1c=_0x4ee9df['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3f5810=gr(_0x1aea1c,_0x5832c9),_0x252fb9=_0x3f5810['repoInfo'],_0x57ceb6;typeof process<'u'&&Us&&(_0x57ceb6=Us[Hd]),_0x57ceb6?(_0x1aea1c='http://'+_0x57ceb6+'?ns='+_0x252fb9['namespace'],_0x3f5810=gr(_0x1aea1c,_0x5832c9),_0x252fb9=_0x3f5810['repoInfo']):_0x3f5810['repoInfo']['secure'];const _0x3dea23=new Jl(_0x4ee9df['name'],_0x4ee9df['options'],_0x5908ac);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3f5810),v(_0x3f5810['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xcd7ee8=jd(_0x252fb9,_0x4ee9df,_0x3dea23,new Ql(_0x4ee9df,_0x425db9));return new Kd(_0xcd7ee8,_0x4ee9df);}function zd(_0x298529,_0x352002){const _0x4d0f94=ki[_0x352002];(!_0x4d0f94||_0x4d0f94[_0x298529['key']]!==_0x298529)&&oe('Database\x20'+_0x352002+'('+_0x298529['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x298529),delete _0x4d0f94[_0x298529['key']];}function jd(_0x30c97e,_0x34dd4d,_0x396380,_0x3d4b33){let _0x14199d=ki[_0x34dd4d['name']];_0x14199d||(_0x14199d={},ki[_0x34dd4d['name']]=_0x14199d);let _0xd1a492=_0x14199d[_0x30c97e['toURLString']()];return _0xd1a492&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0xd1a492=new gd(_0x30c97e,$d,_0x396380,_0x3d4b33),_0x14199d[_0x30c97e['toURLString']()]=_0xd1a492,_0xd1a492;}class Kd{constructor(_0x191c13,_0x3ad2ed){this['_repoInternal']=_0x191c13,this['app']=_0x3ad2ed,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1d5752){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1d5752+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x27ace0=Qr(),_0x5e703f){const _0x4993c1=Ui(_0x27ace0,'database')['getImmediate']({'identifier':_0x5e703f});if(!_0x4993c1['_instanceStarted']){const _0x2068bf=ac('database');_0x2068bf&&Yd(_0x4993c1,..._0x2068bf);}return _0x4993c1;}function Yd(_0x4ce19,_0x40f7c9,_0x94f78,_0x9cce08={}){_0x4ce19=k(_0x4ce19),_0x4ce19['_checkNotDeleted']('useEmulator');const _0x5e7241=_0x40f7c9+':'+_0x94f78,_0x5e95c4=_0x4ce19['_repoInternal'];if(_0x4ce19['_instanceStarted']){if(_0x5e7241===_0x4ce19['_repoInternal']['repoInfo_']['host']&&De(_0x9cce08,_0x5e95c4['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3b9641;if(_0x5e95c4['repoInfo_']['nodeAdmin'])_0x9cce08['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3b9641=new tn(tn['OWNER']);else{if(_0x9cce08['mockUserToken']){const _0x1c47ad=typeof _0x9cce08['mockUserToken']=='string'?_0x9cce08['mockUserToken']:cc(_0x9cce08['mockUserToken'],_0x4ce19['app']['options']['projectId']);_0x3b9641=new tn(_0x1c47ad);}}Wt(_0x40f7c9)&&jr(_0x40f7c9),Gd(_0x5e95c4,_0x5e7241,_0x9cce08,_0x3b9641);}function C_(_0x489207){_0x489207=k(_0x489207),_0x489207['_checkNotDeleted']('goOffline'),aa(_0x489207['_repo']);}function T_(_0x1e86be){_0x1e86be=k(_0x1e86be),_0x1e86be['_checkNotDeleted']('goOnline'),Sd(_0x1e86be['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x502aa1){Ll(ct),et(new Me('database',(_0x283c0f,{instanceIdentifier:_0x10ea2e})=>{const _0x110a08=_0x283c0f['getProvider']('app')['getImmediate'](),_0x949580=_0x283c0f['getProvider']('auth-internal'),_0x5de203=_0x283c0f['getProvider']('app-check-internal');return qd(_0x110a08,_0x949580,_0x5de203,_0x10ea2e);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x502aa1),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x4ff4cc,_0x22b0fa){this['committed']=_0x4ff4cc,this['snapshot']=_0x22b0fa;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3b61c2,_0x514c38,_0x2f7496){if(_0x3b61c2=k(_0x3b61c2),gs('Reference.transaction',_0x3b61c2['_path']),_0x3b61c2['key']==='.length'||_0x3b61c2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3b61c2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x10e42d=!0x0,_0xa5ac06=new Ve(),_0x4db320=(_0x2cd2fa,_0x2462cc,_0x542048)=>{let _0x17c475=null;_0x2cd2fa?_0xa5ac06['reject'](_0x2cd2fa):(_0x17c475=new rt(_0x542048,new Z(_0x3b61c2['_repo'],_0x3b61c2['_path']),R),_0xa5ac06['resolve'](new Xd(_0x2462cc,_0x17c475)));},_0x4e301c=Fd(_0x3b61c2,()=>{});return bd(_0x3b61c2['_repo'],_0x3b61c2['_path'],_0x514c38,_0x4db320,_0x4e301c,_0x10e42d),_0xa5ac06['promise'];}ie['prototype']['simpleListen']=function(_0x37bee9,_0x5a9816){this['sendRequest']('q',{'p':_0x37bee9},_0x5a9816);},ie['prototype']['echo']=function(_0x5afdfa,_0x3d4026){this['sendRequest']('echo',{'d':_0x5afdfa},_0x3d4026);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x1a0e56,..._0x33c12e){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x1a0e56,..._0x33c12e);}function nn(_0x2eb860,..._0x39be39){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2eb860,..._0x39be39);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x1d8b06,..._0x59c9fb){throw Es(_0x1d8b06,..._0x59c9fb);}function J(_0x374958,..._0x11bf02){return Es(_0x374958,..._0x11bf02);}function ya(_0x1573f1,_0x4b32c0,_0x5e692c){const _0x328b2f={...Zd(),[_0x4b32c0]:_0x5e692c};return new Ut('auth','Firebase',_0x328b2f)['create'](_0x4b32c0,{'appName':_0x1573f1['name']});}function se(_0xa8ad30){return ya(_0xa8ad30,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x36b085,..._0x2da250){if(typeof _0x36b085!='string'){const _0xb09fb8=_0x2da250[0x0],_0xc2f3b9=[..._0x2da250['slice'](0x1)];return _0xc2f3b9[0x0]&&(_0xc2f3b9[0x0]['appName']=_0x36b085['name']),_0x36b085['_errorFactory']['create'](_0xb09fb8,..._0xc2f3b9);}return ma['create'](_0x36b085,..._0x2da250);}function m(_0x4d9aa3,_0x4a8f90,..._0x4ce1da){if(!_0x4d9aa3)throw Es(_0x4a8f90,..._0x4ce1da);}function te(_0x3a9f44){const _0x258c2c='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3a9f44;throw nn(_0x258c2c),new Error(_0x258c2c);}function ae(_0x9e8b79,_0x2126e7){_0x9e8b79||te(_0x2126e7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x37ba39;return typeof self<'u'&&((_0x37ba39=self['location'])==null?void 0x0:_0x37ba39['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x5bc995;return typeof self<'u'&&((_0x5bc995=self['location'])==null?void 0x0:_0x5bc995['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x5a35de=navigator;return _0x5a35de['languages']&&_0x5a35de['languages'][0x0]||_0x5a35de['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x2770b0,_0x353a6d){this['shortDelay']=_0x2770b0,this['longDelay']=_0x353a6d,ae(_0x353a6d>_0x2770b0,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x5512ca,_0xda847f){ae(_0x5512ca['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5455e1}=_0x5512ca['emulator'];return _0xda847f?''+_0x5455e1+(_0xda847f['startsWith']('/')?_0xda847f['slice'](0x1):_0xda847f):_0x5455e1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x236691,_0x3d16a1,_0x52235c){this['fetchImpl']=_0x236691,_0x3d16a1&&(this['headersImpl']=_0x3d16a1),_0x52235c&&(this['responseImpl']=_0x52235c);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0xc3c2b5,_0x5a3e31){return _0xc3c2b5['tenantId']&&!_0x5a3e31['tenantId']?{..._0x5a3e31,'tenantId':_0xc3c2b5['tenantId']}:_0x5a3e31;}async function Ae(_0x565ff2,_0x35b76f,_0x10db9a,_0x2ebe66,_0x273edc={}){return Ea(_0x565ff2,_0x273edc,async()=>{let _0x14f24f={},_0x4c0c3c={};_0x2ebe66&&(_0x35b76f==='GET'?_0x4c0c3c=_0x2ebe66:_0x14f24f={'body':JSON['stringify'](_0x2ebe66)});const _0x1fe7e3=at({..._0x4c0c3c,'key':_0x565ff2['config']['apiKey']})['slice'](0x1),_0x2f35de=await _0x565ff2['_getAdditionalHeaders']();_0x2f35de['Content-Type']='application/json',_0x565ff2['languageCode']&&(_0x2f35de['X-Firebase-Locale']=_0x565ff2['languageCode']);const _0x2299e1={'method':_0x35b76f,'headers':_0x2f35de,..._0x14f24f};return lc()||(_0x2299e1['referrerPolicy']='strict-origin-when-cross-origin'),_0x565ff2['emulatorConfig']&&Wt(_0x565ff2['emulatorConfig']['host'])&&(_0x2299e1['credentials']='include'),va['fetch']()(await Ia(_0x565ff2,_0x565ff2['config']['apiHost'],_0x10db9a,_0x1fe7e3),_0x2299e1);});}async function Ea(_0x132bab,_0x2e14bd,_0xa7fa00){_0x132bab['_canInitEmulator']=!0x1;const _0x4526e9={...rf,..._0x2e14bd};try{const _0x588a29=new lf(_0x132bab),_0x2bc736=await Promise['race']([_0xa7fa00(),_0x588a29['promise']]);_0x588a29['clearNetworkTimeout']();const _0x124da0=await _0x2bc736['json']();if('needConfirmation'in _0x124da0)throw en(_0x132bab,'account-exists-with-different-credential',_0x124da0);if(_0x2bc736['ok']&&!('errorMessage'in _0x124da0))return _0x124da0;{const _0x49c9b8=_0x2bc736['ok']?_0x124da0['errorMessage']:_0x124da0['error']['message'],[_0xf7dd48,_0x7f0882]=_0x49c9b8['split']('\x20:\x20');if(_0xf7dd48==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x132bab,'credential-already-in-use',_0x124da0);if(_0xf7dd48==='EMAIL_EXISTS')throw en(_0x132bab,'email-already-in-use',_0x124da0);if(_0xf7dd48==='USER_DISABLED')throw en(_0x132bab,'user-disabled',_0x124da0);const _0x4f644b=_0x4526e9[_0xf7dd48]||_0xf7dd48['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x7f0882)throw ya(_0x132bab,_0x4f644b,_0x7f0882);K(_0x132bab,_0x4f644b);}}catch(_0x16c6db){if(_0x16c6db instanceof Se)throw _0x16c6db;K(_0x132bab,'network-request-failed',{'message':String(_0x16c6db)});}}async function Yt(_0x30fc53,_0x385cfa,_0x6d4dec,_0x3c54ff,_0x73d01f={}){const _0x5b74c2=await Ae(_0x30fc53,_0x385cfa,_0x6d4dec,_0x3c54ff,_0x73d01f);return'mfaPendingCredential'in _0x5b74c2&&K(_0x30fc53,'multi-factor-auth-required',{'_serverResponse':_0x5b74c2}),_0x5b74c2;}async function Ia(_0x27bdf4,_0xd803c1,_0x47d258,_0x76598a){const _0x71fdf4=''+_0xd803c1+_0x47d258+'?'+_0x76598a,_0x5489f8=_0x27bdf4,_0x2dc874=_0x5489f8['config']['emulator']?Is(_0x27bdf4['config'],_0x71fdf4):_0x27bdf4['config']['apiScheme']+'://'+_0x71fdf4;return of['includes'](_0x47d258)&&(await _0x5489f8['_persistenceManagerAvailable'],_0x5489f8['_getPersistenceType']()==='COOKIE')?_0x5489f8['_getPersistence']()['_getFinalTarget'](_0x2dc874)['toString']():_0x2dc874;}function cf(_0x3ae1c3){switch(_0x3ae1c3){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5a3cc9){this['auth']=_0x5a3cc9,this['timer']=null,this['promise']=new Promise((_0x40d1e4,_0x4a62d7)=>{this['timer']=setTimeout(()=>_0x4a62d7(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x485182,_0x333534,_0x464f2b){const _0x214c09={'appName':_0x485182['name']};_0x464f2b['email']&&(_0x214c09['email']=_0x464f2b['email']),_0x464f2b['phoneNumber']&&(_0x214c09['phoneNumber']=_0x464f2b['phoneNumber']);const _0x1b30e7=J(_0x485182,_0x333534,_0x214c09);return _0x1b30e7['customData']['_tokenResponse']=_0x464f2b,_0x1b30e7;}function vr(_0x370918){return _0x370918!==void 0x0&&_0x370918['enterprise']!==void 0x0;}class hf{constructor(_0x764717){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x764717['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x764717['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x764717['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x43cafd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1fc0b2 of this['recaptchaEnforcementState'])if(_0x1fc0b2['provider']&&_0x1fc0b2['provider']===_0x43cafd)return cf(_0x1fc0b2['enforcementState']);return null;}['isProviderEnabled'](_0x5a2203){return this['getProviderEnforcementState'](_0x5a2203)==='ENFORCE'||this['getProviderEnforcementState'](_0x5a2203)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x2fd0af,_0x238d83){return Ae(_0x2fd0af,'GET','/v2/recaptchaConfig',Re(_0x2fd0af,_0x238d83));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x5f2098,_0x474b61){return Ae(_0x5f2098,'POST','/v1/accounts:delete',_0x474b61);}async function Sn(_0x56bc92,_0x29bbc8){return Ae(_0x56bc92,'POST','/v1/accounts:lookup',_0x29bbc8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x3769df){if(_0x3769df)try{const _0xd4fcfb=new Date(Number(_0x3769df));if(!isNaN(_0xd4fcfb['getTime']()))return _0xd4fcfb['toUTCString']();}catch{}}async function ff(_0x8f3021,_0x5b436d=!0x1){const _0x3718da=k(_0x8f3021),_0x40b4dc=await _0x3718da['getIdToken'](_0x5b436d),_0x3bf33e=ws(_0x40b4dc);m(_0x3bf33e&&_0x3bf33e['exp']&&_0x3bf33e['auth_time']&&_0x3bf33e['iat'],_0x3718da['auth'],'internal-error');const _0x34222e=typeof _0x3bf33e['firebase']=='object'?_0x3bf33e['firebase']:void 0x0,_0xa0db14=_0x34222e==null?void 0x0:_0x34222e['sign_in_provider'];return{'claims':_0x3bf33e,'token':_0x40b4dc,'authTime':St(ci(_0x3bf33e['auth_time'])),'issuedAtTime':St(ci(_0x3bf33e['iat'])),'expirationTime':St(ci(_0x3bf33e['exp'])),'signInProvider':_0xa0db14||null,'signInSecondFactor':(_0x34222e==null?void 0x0:_0x34222e['sign_in_second_factor'])||null};}function ci(_0x84924b){return Number(_0x84924b)*0x3e8;}function ws(_0x4f0180){const [_0x4571a7,_0x242767,_0xc4524b]=_0x4f0180['split']('.');if(_0x4571a7===void 0x0||_0x242767===void 0x0||_0xc4524b===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3d9895=cn(_0x242767);return _0x3d9895?JSON['parse'](_0x3d9895):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3d98ec){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3d98ec==null?void 0x0:_0x3d98ec['toString']()),null;}}function Er(_0x47fe5a){const _0x525ee5=ws(_0x47fe5a);return m(_0x525ee5,'internal-error'),m(typeof _0x525ee5['exp']<'u','internal-error'),m(typeof _0x525ee5['iat']<'u','internal-error'),Number(_0x525ee5['exp'])-Number(_0x525ee5['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x4ab0a,_0x1863dd,_0x90715=!0x1){if(_0x90715)return _0x1863dd;try{return await _0x1863dd;}catch(_0x575701){throw _0x575701 instanceof Se&&pf(_0x575701)&&_0x4ab0a['auth']['currentUser']===_0x4ab0a&&await _0x4ab0a['auth']['signOut'](),_0x575701;}}function pf({code:_0x52c47a}){return _0x52c47a==='auth/user-disabled'||_0x52c47a==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x233577){this['user']=_0x233577,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2742ef){if(_0x2742ef){const _0x28e181=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x28e181;}else{this['errorBackoff']=0x7530;const _0x21500d=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x21500d);}}['schedule'](_0x58cb54=!0x1){if(!this['isRunning'])return;const _0x264bca=this['getInterval'](_0x58cb54);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x264bca);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2fa104){(_0x2fa104==null?void 0x0:_0x2fa104['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4d42c3,_0x54cfc6){this['createdAt']=_0x4d42c3,this['lastLoginAt']=_0x54cfc6,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x3a40ac){this['createdAt']=_0x3a40ac['createdAt'],this['lastLoginAt']=_0x3a40ac['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x4c2ee0){var _0x462e27;const _0x188518=_0x4c2ee0['auth'],_0x5fc539=await _0x4c2ee0['getIdToken'](),_0x222205=await xt(_0x4c2ee0,Sn(_0x188518,{'idToken':_0x5fc539}));m(_0x222205==null?void 0x0:_0x222205['users']['length'],_0x188518,'internal-error');const _0x5c861d=_0x222205['users'][0x0];_0x4c2ee0['_notifyReloadListener'](_0x5c861d);const _0x30f68b=(_0x462e27=_0x5c861d['providerUserInfo'])!=null&&_0x462e27['length']?wa(_0x5c861d['providerUserInfo']):[],_0x54f888=mf(_0x4c2ee0['providerData'],_0x30f68b),_0x44b29f=_0x4c2ee0['isAnonymous'],_0x41fe12=!(_0x4c2ee0['email']&&_0x5c861d['passwordHash'])&&!(_0x54f888!=null&&_0x54f888['length']),_0x8a2234=_0x44b29f?_0x41fe12:!0x1,_0x3683f3={'uid':_0x5c861d['localId'],'displayName':_0x5c861d['displayName']||null,'photoURL':_0x5c861d['photoUrl']||null,'email':_0x5c861d['email']||null,'emailVerified':_0x5c861d['emailVerified']||!0x1,'phoneNumber':_0x5c861d['phoneNumber']||null,'tenantId':_0x5c861d['tenantId']||null,'providerData':_0x54f888,'metadata':new Pi(_0x5c861d['createdAt'],_0x5c861d['lastLoginAt']),'isAnonymous':_0x8a2234};Object['assign'](_0x4c2ee0,_0x3683f3);}async function gf(_0x24c296){const _0x4c102f=k(_0x24c296);await bn(_0x4c102f),await _0x4c102f['auth']['_persistUserIfCurrent'](_0x4c102f),_0x4c102f['auth']['_notifyListenersIfCurrent'](_0x4c102f);}function mf(_0x3e5930,_0x1dacc6){return[..._0x3e5930['filter'](_0x3d201c=>!_0x1dacc6['some'](_0xdf7be4=>_0xdf7be4['providerId']===_0x3d201c['providerId'])),..._0x1dacc6];}function wa(_0x1a322b){return _0x1a322b['map'](({providerId:_0x30692e,..._0x17c8ed})=>({'providerId':_0x30692e,'uid':_0x17c8ed['rawId']||'','displayName':_0x17c8ed['displayName']||null,'email':_0x17c8ed['email']||null,'phoneNumber':_0x17c8ed['phoneNumber']||null,'photoURL':_0x17c8ed['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x409316,_0x2e6913){const _0x5c1488=await Ea(_0x409316,{},async()=>{const _0x1d5e97=at({'grant_type':'refresh_token','refresh_token':_0x2e6913})['slice'](0x1),{tokenApiHost:_0x7b90ee,apiKey:_0x1b367f}=_0x409316['config'],_0x1c3420=await Ia(_0x409316,_0x7b90ee,'/v1/token','key='+_0x1b367f),_0x2033c3=await _0x409316['_getAdditionalHeaders']();_0x2033c3['Content-Type']='application/x-www-form-urlencoded';const _0x298ef3={'method':'POST','headers':_0x2033c3,'body':_0x1d5e97};return _0x409316['emulatorConfig']&&Wt(_0x409316['emulatorConfig']['host'])&&(_0x298ef3['credentials']='include'),va['fetch']()(_0x1c3420,_0x298ef3);});return{'accessToken':_0x5c1488['access_token'],'expiresIn':_0x5c1488['expires_in'],'refreshToken':_0x5c1488['refresh_token']};}async function vf(_0x4d5d2c,_0x4cc09b){return Ae(_0x4d5d2c,'POST','/v2/accounts:revokeToken',Re(_0x4d5d2c,_0x4cc09b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x47b2ab){m(_0x47b2ab['idToken'],'internal-error'),m(typeof _0x47b2ab['idToken']<'u','internal-error'),m(typeof _0x47b2ab['refreshToken']<'u','internal-error');const _0x443d3f='expiresIn'in _0x47b2ab&&typeof _0x47b2ab['expiresIn']<'u'?Number(_0x47b2ab['expiresIn']):Er(_0x47b2ab['idToken']);this['updateTokensAndExpiration'](_0x47b2ab['idToken'],_0x47b2ab['refreshToken'],_0x443d3f);}['updateFromIdToken'](_0x342286){m(_0x342286['length']!==0x0,'internal-error');const _0x41e4c9=Er(_0x342286);this['updateTokensAndExpiration'](_0x342286,null,_0x41e4c9);}async['getToken'](_0x5886a5,_0x523b3d=!0x1){return!_0x523b3d&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5886a5,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5886a5,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3df383,_0x5477bd){const {accessToken:_0x22caa6,refreshToken:_0x3a5c20,expiresIn:_0x528270}=await yf(_0x3df383,_0x5477bd);this['updateTokensAndExpiration'](_0x22caa6,_0x3a5c20,Number(_0x528270));}['updateTokensAndExpiration'](_0x5a0fc9,_0x19cd16,_0x4139bf){this['refreshToken']=_0x19cd16||null,this['accessToken']=_0x5a0fc9||null,this['expirationTime']=Date['now']()+_0x4139bf*0x3e8;}static['fromJSON'](_0x1c3d5f,_0x968bbd){const {refreshToken:_0x6f089,accessToken:_0x25de30,expirationTime:_0x2252d1}=_0x968bbd,_0x5f3e64=new Je();return _0x6f089&&(m(typeof _0x6f089=='string','internal-error',{'appName':_0x1c3d5f}),_0x5f3e64['refreshToken']=_0x6f089),_0x25de30&&(m(typeof _0x25de30=='string','internal-error',{'appName':_0x1c3d5f}),_0x5f3e64['accessToken']=_0x25de30),_0x2252d1&&(m(typeof _0x2252d1=='number','internal-error',{'appName':_0x1c3d5f}),_0x5f3e64['expirationTime']=_0x2252d1),_0x5f3e64;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4603c7){this['accessToken']=_0x4603c7['accessToken'],this['refreshToken']=_0x4603c7['refreshToken'],this['expirationTime']=_0x4603c7['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x21eb51,_0x3d96fc){m(typeof _0x21eb51=='string'||typeof _0x21eb51>'u','internal-error',{'appName':_0x3d96fc});}class z{constructor({uid:_0x31e105,auth:_0x259d03,stsTokenManager:_0x362039,..._0x3f2c8d}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x31e105,this['auth']=_0x259d03,this['stsTokenManager']=_0x362039,this['accessToken']=_0x362039['accessToken'],this['displayName']=_0x3f2c8d['displayName']||null,this['email']=_0x3f2c8d['email']||null,this['emailVerified']=_0x3f2c8d['emailVerified']||!0x1,this['phoneNumber']=_0x3f2c8d['phoneNumber']||null,this['photoURL']=_0x3f2c8d['photoURL']||null,this['isAnonymous']=_0x3f2c8d['isAnonymous']||!0x1,this['tenantId']=_0x3f2c8d['tenantId']||null,this['providerData']=_0x3f2c8d['providerData']?[..._0x3f2c8d['providerData']]:[],this['metadata']=new Pi(_0x3f2c8d['createdAt']||void 0x0,_0x3f2c8d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3f28c1){const _0x14d81c=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x3f28c1));return m(_0x14d81c,this['auth'],'internal-error'),this['accessToken']!==_0x14d81c&&(this['accessToken']=_0x14d81c,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x14d81c;}['getIdTokenResult'](_0x8fd98c){return ff(this,_0x8fd98c);}['reload'](){return gf(this);}['_assign'](_0x83fcba){this!==_0x83fcba&&(m(this['uid']===_0x83fcba['uid'],this['auth'],'internal-error'),this['displayName']=_0x83fcba['displayName'],this['photoURL']=_0x83fcba['photoURL'],this['email']=_0x83fcba['email'],this['emailVerified']=_0x83fcba['emailVerified'],this['phoneNumber']=_0x83fcba['phoneNumber'],this['isAnonymous']=_0x83fcba['isAnonymous'],this['tenantId']=_0x83fcba['tenantId'],this['providerData']=_0x83fcba['providerData']['map'](_0x58495b=>({..._0x58495b})),this['metadata']['_copy'](_0x83fcba['metadata']),this['stsTokenManager']['_assign'](_0x83fcba['stsTokenManager']));}['_clone'](_0x327e19){const _0x456217=new z({...this,'auth':_0x327e19,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x456217['metadata']['_copy'](this['metadata']),_0x456217;}['_onReload'](_0x1849b0){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1849b0,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x48c0d9){this['reloadListener']?this['reloadListener'](_0x48c0d9):this['reloadUserInfo']=_0x48c0d9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2daa18,_0x2b1b2d=!0x1){let _0x48a785=!0x1;_0x2daa18['idToken']&&_0x2daa18['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2daa18),_0x48a785=!0x0),_0x2b1b2d&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x48a785&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x7c386e=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x7c386e})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1ae71c=>({..._0x1ae71c})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x732806,_0x3c7ef0){const _0xf59e22=_0x3c7ef0['displayName']??void 0x0,_0x564660=_0x3c7ef0['email']??void 0x0,_0x12d017=_0x3c7ef0['phoneNumber']??void 0x0,_0x39eaf1=_0x3c7ef0['photoURL']??void 0x0,_0x137279=_0x3c7ef0['tenantId']??void 0x0,_0x5dae9a=_0x3c7ef0['_redirectEventId']??void 0x0,_0xa2d77d=_0x3c7ef0['createdAt']??void 0x0,_0x9cd4e5=_0x3c7ef0['lastLoginAt']??void 0x0,{uid:_0xe0f068,emailVerified:_0x3bd518,isAnonymous:_0xbe6313,providerData:_0x379510,stsTokenManager:_0xf944be}=_0x3c7ef0;m(_0xe0f068&&_0xf944be,_0x732806,'internal-error');const _0x29d41f=Je['fromJSON'](this['name'],_0xf944be);m(typeof _0xe0f068=='string',_0x732806,'internal-error'),ce(_0xf59e22,_0x732806['name']),ce(_0x564660,_0x732806['name']),m(typeof _0x3bd518=='boolean',_0x732806,'internal-error'),m(typeof _0xbe6313=='boolean',_0x732806,'internal-error'),ce(_0x12d017,_0x732806['name']),ce(_0x39eaf1,_0x732806['name']),ce(_0x137279,_0x732806['name']),ce(_0x5dae9a,_0x732806['name']),ce(_0xa2d77d,_0x732806['name']),ce(_0x9cd4e5,_0x732806['name']);const _0x49b1e5=new z({'uid':_0xe0f068,'auth':_0x732806,'email':_0x564660,'emailVerified':_0x3bd518,'displayName':_0xf59e22,'isAnonymous':_0xbe6313,'photoURL':_0x39eaf1,'phoneNumber':_0x12d017,'tenantId':_0x137279,'stsTokenManager':_0x29d41f,'createdAt':_0xa2d77d,'lastLoginAt':_0x9cd4e5});return _0x379510&&Array['isArray'](_0x379510)&&(_0x49b1e5['providerData']=_0x379510['map'](_0x488e96=>({..._0x488e96}))),_0x5dae9a&&(_0x49b1e5['_redirectEventId']=_0x5dae9a),_0x49b1e5;}static async['_fromIdTokenResponse'](_0x5e5d95,_0x308307,_0x92dfe8=!0x1){const _0x54e0f4=new Je();_0x54e0f4['updateFromServerResponse'](_0x308307);const _0x37af00=new z({'uid':_0x308307['localId'],'auth':_0x5e5d95,'stsTokenManager':_0x54e0f4,'isAnonymous':_0x92dfe8});return await bn(_0x37af00),_0x37af00;}static async['_fromGetAccountInfoResponse'](_0x30f20a,_0x6658df,_0xacb681){const _0xc83887=_0x6658df['users'][0x0];m(_0xc83887['localId']!==void 0x0,'internal-error');const _0x253de6=_0xc83887['providerUserInfo']!==void 0x0?wa(_0xc83887['providerUserInfo']):[],_0x4e0402=!(_0xc83887['email']&&_0xc83887['passwordHash'])&&!(_0x253de6!=null&&_0x253de6['length']),_0xdecec2=new Je();_0xdecec2['updateFromIdToken'](_0xacb681);const _0x3a5829=new z({'uid':_0xc83887['localId'],'auth':_0x30f20a,'stsTokenManager':_0xdecec2,'isAnonymous':_0x4e0402}),_0x525c62={'uid':_0xc83887['localId'],'displayName':_0xc83887['displayName']||null,'photoURL':_0xc83887['photoUrl']||null,'email':_0xc83887['email']||null,'emailVerified':_0xc83887['emailVerified']||!0x1,'phoneNumber':_0xc83887['phoneNumber']||null,'tenantId':_0xc83887['tenantId']||null,'providerData':_0x253de6,'metadata':new Pi(_0xc83887['createdAt'],_0xc83887['lastLoginAt']),'isAnonymous':!(_0xc83887['email']&&_0xc83887['passwordHash'])&&!(_0x253de6!=null&&_0x253de6['length'])};return Object['assign'](_0x3a5829,_0x525c62),_0x3a5829;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x13f793){ae(_0x13f793 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x242328=Ir['get'](_0x13f793);return _0x242328?(ae(_0x242328 instanceof _0x13f793,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x242328):(_0x242328=new _0x13f793(),Ir['set'](_0x13f793,_0x242328),_0x242328);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x54d365,_0x4a1b3d){this['storage'][_0x54d365]=_0x4a1b3d;}async['_get'](_0x3dccc7){const _0x37b77e=this['storage'][_0x3dccc7];return _0x37b77e===void 0x0?null:_0x37b77e;}async['_remove'](_0xe8168d){delete this['storage'][_0xe8168d];}['_addListener'](_0x1c8f28,_0x29efb2){}['_removeListener'](_0x37d547,_0x24837b){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x2803a4,_0x4dfec7,_0x40e644){return'firebase:'+_0x2803a4+':'+_0x4dfec7+':'+_0x40e644;}class Xe{constructor(_0xbf97fa,_0x1b6209,_0x324ffe){this['persistence']=_0xbf97fa,this['auth']=_0x1b6209,this['userKey']=_0x324ffe;const {config:_0x7d7a8e,name:_0x1800a5}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x7d7a8e['apiKey'],_0x1800a5),this['fullPersistenceKey']=sn('persistence',_0x7d7a8e['apiKey'],_0x1800a5),this['boundEventHandler']=_0x1b6209['_onStorageEvent']['bind'](_0x1b6209),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xa2683b){return this['persistence']['_set'](this['fullUserKey'],_0xa2683b['toJSON']());}async['getCurrentUser'](){const _0x391a8=await this['persistence']['_get'](this['fullUserKey']);if(!_0x391a8)return null;if(typeof _0x391a8=='string'){const _0x4d6571=await Sn(this['auth'],{'idToken':_0x391a8})['catch'](()=>{});return _0x4d6571?z['_fromGetAccountInfoResponse'](this['auth'],_0x4d6571,_0x391a8):null;}return z['_fromJSON'](this['auth'],_0x391a8);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x19a001){if(this['persistence']===_0x19a001)return;const _0x45e747=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x19a001,_0x45e747)return this['setCurrentUser'](_0x45e747);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x331678,_0x3ab99f,_0x2bfaab='authUser'){if(!_0x3ab99f['length'])return new Xe(ne(wr),_0x331678,_0x2bfaab);const _0x4980da=(await Promise['all'](_0x3ab99f['map'](async _0x5bc705=>{if(await _0x5bc705['_isAvailable']())return _0x5bc705;})))['filter'](_0xfc1720=>_0xfc1720);let _0x1f6286=_0x4980da[0x0]||ne(wr);const _0x39712f=sn(_0x2bfaab,_0x331678['config']['apiKey'],_0x331678['name']);let _0x302117=null;for(const _0x1d6c3d of _0x3ab99f)try{const _0x4374a4=await _0x1d6c3d['_get'](_0x39712f);if(_0x4374a4){let _0x5d740e;if(typeof _0x4374a4=='string'){const _0xa2314=await Sn(_0x331678,{'idToken':_0x4374a4})['catch'](()=>{});if(!_0xa2314)break;_0x5d740e=await z['_fromGetAccountInfoResponse'](_0x331678,_0xa2314,_0x4374a4);}else _0x5d740e=z['_fromJSON'](_0x331678,_0x4374a4);_0x1d6c3d!==_0x1f6286&&(_0x302117=_0x5d740e),_0x1f6286=_0x1d6c3d;break;}}catch{}const _0x1e40fe=_0x4980da['filter'](_0x1ea8ef=>_0x1ea8ef['_shouldAllowMigration']);return!_0x1f6286['_shouldAllowMigration']||!_0x1e40fe['length']?new Xe(_0x1f6286,_0x331678,_0x2bfaab):(_0x1f6286=_0x1e40fe[0x0],_0x302117&&await _0x1f6286['_set'](_0x39712f,_0x302117['toJSON']()),await Promise['all'](_0x3ab99f['map'](async _0x3d6de5=>{if(_0x3d6de5!==_0x1f6286)try{await _0x3d6de5['_remove'](_0x39712f);}catch{}})),new Xe(_0x1f6286,_0x331678,_0x2bfaab));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x3b54eb){const _0x1901c3=_0x3b54eb['toLowerCase']();if(_0x1901c3['includes']('opera/')||_0x1901c3['includes']('opr/')||_0x1901c3['includes']('opios/'))return'Opera';if(Ra(_0x1901c3))return'IEMobile';if(_0x1901c3['includes']('msie')||_0x1901c3['includes']('trident/'))return'IE';if(_0x1901c3['includes']('edge/'))return'Edge';if(Ta(_0x1901c3))return'Firefox';if(_0x1901c3['includes']('silk/'))return'Silk';if(ka(_0x1901c3))return'Blackberry';if(Na(_0x1901c3))return'Webos';if(Sa(_0x1901c3))return'Safari';if((_0x1901c3['includes']('chrome/')||ba(_0x1901c3))&&!_0x1901c3['includes']('edge/'))return'Chrome';if(Aa(_0x1901c3))return'Android';{const _0x53bf9d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5d65a4=_0x3b54eb['match'](_0x53bf9d);if((_0x5d65a4==null?void 0x0:_0x5d65a4['length'])===0x2)return _0x5d65a4[0x1];}return'Other';}function Ta(_0x3d858c=W()){return/firefox\//i['test'](_0x3d858c);}function Sa(_0x4dc426=W()){const _0x5d2363=_0x4dc426['toLowerCase']();return _0x5d2363['includes']('safari/')&&!_0x5d2363['includes']('chrome/')&&!_0x5d2363['includes']('crios/')&&!_0x5d2363['includes']('android');}function ba(_0x75a71a=W()){return/crios\//i['test'](_0x75a71a);}function Ra(_0x2f9ae4=W()){return/iemobile/i['test'](_0x2f9ae4);}function Aa(_0x5a3202=W()){return/android/i['test'](_0x5a3202);}function ka(_0x195a15=W()){return/blackberry/i['test'](_0x195a15);}function Na(_0x9d9b53=W()){return/webos/i['test'](_0x9d9b53);}function Cs(_0xbc91df=W()){return/iphone|ipad|ipod/i['test'](_0xbc91df)||/macintosh/i['test'](_0xbc91df)&&/mobile/i['test'](_0xbc91df);}function Ef(_0x54b3eb=W()){var _0x255616;return Cs(_0x54b3eb)&&!!((_0x255616=window['navigator'])!=null&&_0x255616['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x4b356b=W()){return Cs(_0x4b356b)||Aa(_0x4b356b)||Na(_0x4b356b)||ka(_0x4b356b)||/windows phone/i['test'](_0x4b356b)||Ra(_0x4b356b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x9cb020,_0x216a3f=[]){let _0x23c9cb;switch(_0x9cb020){case'Browser':_0x23c9cb=Cr(W());break;case'Worker':_0x23c9cb=Cr(W())+'-'+_0x9cb020;break;default:_0x23c9cb=_0x9cb020;}const _0x45baeb=_0x216a3f['length']?_0x216a3f['join'](','):'FirebaseCore-web';return _0x23c9cb+'/JsCore/'+ct+'/'+_0x45baeb;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x40aa08){this['auth']=_0x40aa08,this['queue']=[];}['pushCallback'](_0x3245c3,_0x1c4094){const _0x10510b=_0x4b96f2=>new Promise((_0x2fbade,_0x41339e)=>{try{const _0x154c5e=_0x3245c3(_0x4b96f2);_0x2fbade(_0x154c5e);}catch(_0x35eded){_0x41339e(_0x35eded);}});_0x10510b['onAbort']=_0x1c4094,this['queue']['push'](_0x10510b);const _0x2ae250=this['queue']['length']-0x1;return()=>{this['queue'][_0x2ae250]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1a2c78){if(this['auth']['currentUser']===_0x1a2c78)return;const _0xac427a=[];try{for(const _0x76d3cf of this['queue'])await _0x76d3cf(_0x1a2c78),_0x76d3cf['onAbort']&&_0xac427a['push'](_0x76d3cf['onAbort']);}catch(_0xf207d2){_0xac427a['reverse']();for(const _0x40200f of _0xac427a)try{_0x40200f();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xf207d2==null?void 0x0:_0xf207d2['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x12e1c9,_0x3aaac0={}){return Ae(_0x12e1c9,'GET','/v2/passwordPolicy',Re(_0x12e1c9,_0x3aaac0));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x1b3c08){var _0x4c8772;const _0xa28675=_0x1b3c08['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xa28675['minPasswordLength']??Tf,_0xa28675['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xa28675['maxPasswordLength']),_0xa28675['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xa28675['containsLowercaseCharacter']),_0xa28675['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xa28675['containsUppercaseCharacter']),_0xa28675['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xa28675['containsNumericCharacter']),_0xa28675['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xa28675['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1b3c08['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4c8772=_0x1b3c08['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4c8772['join'](''))??'',this['forceUpgradeOnSignin']=_0x1b3c08['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1b3c08['schemaVersion'];}['validatePassword'](_0x15fbf9){const _0x4e9771={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x15fbf9,_0x4e9771),this['validatePasswordCharacterOptions'](_0x15fbf9,_0x4e9771),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['meetsMinPasswordLength']??!0x0),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['meetsMaxPasswordLength']??!0x0),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['containsLowercaseLetter']??!0x0),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['containsUppercaseLetter']??!0x0),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['containsNumericCharacter']??!0x0),_0x4e9771['isValid']&&(_0x4e9771['isValid']=_0x4e9771['containsNonAlphanumericCharacter']??!0x0),_0x4e9771;}['validatePasswordLengthOptions'](_0x55b1a8,_0x471c1a){const _0x448c63=this['customStrengthOptions']['minPasswordLength'],_0x315d81=this['customStrengthOptions']['maxPasswordLength'];_0x448c63&&(_0x471c1a['meetsMinPasswordLength']=_0x55b1a8['length']>=_0x448c63),_0x315d81&&(_0x471c1a['meetsMaxPasswordLength']=_0x55b1a8['length']<=_0x315d81);}['validatePasswordCharacterOptions'](_0x3c9023,_0x2fd353){this['updatePasswordCharacterOptionsStatuses'](_0x2fd353,!0x1,!0x1,!0x1,!0x1);let _0x15b7df;for(let _0x30d765=0x0;_0x30d765<_0x3c9023['length'];_0x30d765++)_0x15b7df=_0x3c9023['charAt'](_0x30d765),this['updatePasswordCharacterOptionsStatuses'](_0x2fd353,_0x15b7df>='a'&&_0x15b7df<='z',_0x15b7df>='A'&&_0x15b7df<='Z',_0x15b7df>='0'&&_0x15b7df<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x15b7df));}['updatePasswordCharacterOptionsStatuses'](_0xa774ae,_0x59b5f5,_0x2e0c3d,_0x1f32a5,_0x3987f8){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xa774ae['containsLowercaseLetter']||(_0xa774ae['containsLowercaseLetter']=_0x59b5f5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xa774ae['containsUppercaseLetter']||(_0xa774ae['containsUppercaseLetter']=_0x2e0c3d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xa774ae['containsNumericCharacter']||(_0xa774ae['containsNumericCharacter']=_0x1f32a5)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xa774ae['containsNonAlphanumericCharacter']||(_0xa774ae['containsNonAlphanumericCharacter']=_0x3987f8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x29fc25,_0x485ea2,_0x5d7517,_0x5450f7){this['app']=_0x29fc25,this['heartbeatServiceProvider']=_0x485ea2,this['appCheckServiceProvider']=_0x5d7517,this['config']=_0x5450f7,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x29fc25['name'],this['clientVersion']=_0x5450f7['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4642f3=>this['_resolvePersistenceManagerAvailable']=_0x4642f3);}['_initializeWithPersistence'](_0x285400,_0x357c8d){return _0x357c8d&&(this['_popupRedirectResolver']=ne(_0x357c8d)),this['_initializationPromise']=this['queue'](async()=>{var _0x5a09bf,_0xa095b5,_0x2b7224;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x285400),(_0x5a09bf=this['_resolvePersistenceManagerAvailable'])==null||_0x5a09bf['call'](this),!this['_deleted'])){if((_0xa095b5=this['_popupRedirectResolver'])!=null&&_0xa095b5['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x357c8d),this['lastNotifiedUid']=((_0x2b7224=this['currentUser'])==null?void 0x0:_0x2b7224['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x26984d=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x26984d)){if(this['currentUser']&&_0x26984d&&this['currentUser']['uid']===_0x26984d['uid']){this['_currentUser']['_assign'](_0x26984d),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x26984d,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2918bc){try{const _0x5ee62c=await Sn(this,{'idToken':_0x2918bc}),_0x463cf1=await z['_fromGetAccountInfoResponse'](this,_0x5ee62c,_0x2918bc);await this['directlySetCurrentUser'](_0x463cf1);}catch(_0x374478){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x374478),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1a5e52){var _0x4b5795;if(H(this['app'])){const _0x52ff34=this['app']['settings']['authIdToken'];return _0x52ff34?new Promise(_0x497c7f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x52ff34)['then'](_0x497c7f,_0x497c7f));}):this['directlySetCurrentUser'](null);}const _0x552363=await this['assertedPersistence']['getCurrentUser']();let _0x5e1007=_0x552363,_0x28efca=!0x1;if(_0x1a5e52&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2baf21=(_0x4b5795=this['redirectUser'])==null?void 0x0:_0x4b5795['_redirectEventId'],_0x3cc1a5=_0x5e1007==null?void 0x0:_0x5e1007['_redirectEventId'],_0x53f56d=await this['tryRedirectSignIn'](_0x1a5e52);(!_0x2baf21||_0x2baf21===_0x3cc1a5)&&(_0x53f56d!=null&&_0x53f56d['user'])&&(_0x5e1007=_0x53f56d['user'],_0x28efca=!0x0);}if(!_0x5e1007)return this['directlySetCurrentUser'](null);if(!_0x5e1007['_redirectEventId']){if(_0x28efca)try{await this['beforeStateQueue']['runMiddleware'](_0x5e1007);}catch(_0xab4859){_0x5e1007=_0x552363,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xab4859));}return _0x5e1007?this['reloadAndSetCurrentUserOrClear'](_0x5e1007):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5e1007['_redirectEventId']?this['directlySetCurrentUser'](_0x5e1007):this['reloadAndSetCurrentUserOrClear'](_0x5e1007);}async['tryRedirectSignIn'](_0x69bb92){let _0x2f2beb=null;try{_0x2f2beb=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x69bb92,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2f2beb;}async['reloadAndSetCurrentUserOrClear'](_0x25db6e){try{await bn(_0x25db6e);}catch(_0x34a8c9){if((_0x34a8c9==null?void 0x0:_0x34a8c9['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x25db6e);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2d051e){if(H(this['app']))return Promise['reject'](se(this));const _0x2a5096=_0x2d051e?k(_0x2d051e):null;return _0x2a5096&&m(_0x2a5096['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2a5096&&_0x2a5096['_clone'](this));}async['_updateCurrentUser'](_0x54fd8c,_0x4c948e=!0x1){if(!this['_deleted'])return _0x54fd8c&&m(this['tenantId']===_0x54fd8c['tenantId'],this,'tenant-id-mismatch'),_0x4c948e||await this['beforeStateQueue']['runMiddleware'](_0x54fd8c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x54fd8c),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x473161){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x473161));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x45838d){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x42b597=this['_getPasswordPolicyInternal']();return _0x42b597['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x42b597['validatePassword'](_0x45838d);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x347c27=await Cf(this),_0x151691=new Sf(_0x347c27);this['tenantId']===null?this['_projectPasswordPolicy']=_0x151691:this['_tenantPasswordPolicies'][this['tenantId']]=_0x151691;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2f4b53){this['_errorFactory']=new Ut('auth','Firebase',_0x2f4b53());}['onAuthStateChanged'](_0x1f2476,_0x3523ff,_0x18e1be){return this['registerStateListener'](this['authStateSubscription'],_0x1f2476,_0x3523ff,_0x18e1be);}['beforeAuthStateChanged'](_0x5b59ff,_0x30b139){return this['beforeStateQueue']['pushCallback'](_0x5b59ff,_0x30b139);}['onIdTokenChanged'](_0x594e12,_0x30c9d9,_0x5a79bb){return this['registerStateListener'](this['idTokenSubscription'],_0x594e12,_0x30c9d9,_0x5a79bb);}['authStateReady'](){return new Promise((_0x38de30,_0x464212)=>{if(this['currentUser'])_0x38de30();else{const _0x5547a8=this['onAuthStateChanged'](()=>{_0x5547a8(),_0x38de30();},_0x464212);}});}async['revokeAccessToken'](_0x13cfa9){if(this['currentUser']){const _0x2b90a2=await this['currentUser']['getIdToken'](),_0x3f78c7={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x13cfa9,'idToken':_0x2b90a2};this['tenantId']!=null&&(_0x3f78c7['tenantId']=this['tenantId']),await vf(this,_0x3f78c7);}}['toJSON'](){var _0x3c97ee;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3c97ee=this['_currentUser'])==null?void 0x0:_0x3c97ee['toJSON']()};}async['_setRedirectUser'](_0x27cf43,_0x3c7a69){const _0x203ee6=await this['getOrInitRedirectPersistenceManager'](_0x3c7a69);return _0x27cf43===null?_0x203ee6['removeCurrentUser']():_0x203ee6['setCurrentUser'](_0x27cf43);}async['getOrInitRedirectPersistenceManager'](_0x50a020){if(!this['redirectPersistenceManager']){const _0x345ecb=_0x50a020&&ne(_0x50a020)||this['_popupRedirectResolver'];m(_0x345ecb,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x345ecb['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x207d53){var _0xa7c73a,_0x71fbd6;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0xa7c73a=this['_currentUser'])==null?void 0x0:_0xa7c73a['_redirectEventId'])===_0x207d53?this['_currentUser']:((_0x71fbd6=this['redirectUser'])==null?void 0x0:_0x71fbd6['_redirectEventId'])===_0x207d53?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x36739f){if(_0x36739f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x36739f));}['_notifyListenersIfCurrent'](_0x1eb351){_0x1eb351===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xf11466;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4cec67=((_0xf11466=this['currentUser'])==null?void 0x0:_0xf11466['uid'])??null;this['lastNotifiedUid']!==_0x4cec67&&(this['lastNotifiedUid']=_0x4cec67,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4858d0,_0x1af23a,_0x58543a,_0x1c224f){if(this['_deleted'])return()=>{};const _0xe6dd56=typeof _0x1af23a=='function'?_0x1af23a:_0x1af23a['next']['bind'](_0x1af23a);let _0x4fe8e3=!0x1;const _0x1e0df3=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1e0df3,this,'internal-error'),_0x1e0df3['then'](()=>{_0x4fe8e3||_0xe6dd56(this['currentUser']);}),typeof _0x1af23a=='function'){const _0x46e82e=_0x4858d0['addObserver'](_0x1af23a,_0x58543a,_0x1c224f);return()=>{_0x4fe8e3=!0x0,_0x46e82e();};}else{const _0x49bd4f=_0x4858d0['addObserver'](_0x1af23a);return()=>{_0x4fe8e3=!0x0,_0x49bd4f();};}}async['directlySetCurrentUser'](_0x9d880f){this['currentUser']&&this['currentUser']!==_0x9d880f&&this['_currentUser']['_stopProactiveRefresh'](),_0x9d880f&&this['isProactiveRefreshEnabled']&&_0x9d880f['_startProactiveRefresh'](),this['currentUser']=_0x9d880f,_0x9d880f?await this['assertedPersistence']['setCurrentUser'](_0x9d880f):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5a5188){return this['operations']=this['operations']['then'](_0x5a5188,_0x5a5188),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x28465a){!_0x28465a||this['frameworks']['includes'](_0x28465a)||(this['frameworks']['push'](_0x28465a),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x40f28d;const _0x9e8d34={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x9e8d34['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x577eab=await((_0x40f28d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x40f28d['getHeartbeatsHeader']());_0x577eab&&(_0x9e8d34['X-Firebase-Client']=_0x577eab);const _0x16e3e8=await this['_getAppCheckToken']();return _0x16e3e8&&(_0x9e8d34['X-Firebase-AppCheck']=_0x16e3e8),_0x9e8d34;}async['_getAppCheckToken'](){var _0x5b53dd;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2df18e=await((_0x5b53dd=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5b53dd['getToken']());return _0x2df18e!=null&&_0x2df18e['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2df18e['error']),_0x2df18e==null?void 0x0:_0x2df18e['token'];}}function qe(_0x58e616){return k(_0x58e616);}class Tr{constructor(_0x439df6){this['auth']=_0x439df6,this['observer']=null,this['addObserver']=Ic(_0x4d6d3d=>this['observer']=_0x4d6d3d);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0xf949d8){zn=_0xf949d8;}function Da(_0x5adc47){return zn['loadJS'](_0x5adc47);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4c2e13){return'__'+_0x4c2e13+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x5375f3){_0x5375f3();}['execute'](_0x437611,_0xd7b8c7){return Promise['resolve']('token');}['render'](_0x557a98,_0x15f6c7){return'';}}class Of{['ready'](_0x3dbeaf){_0x3dbeaf();}['execute'](_0x1a8623,_0x1dec8a){return Promise['resolve']('token');}['render'](_0x14b50d,_0x3ebd28){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x1b39ff){this['type']=Df,this['auth']=qe(_0x1b39ff);}async['verify'](_0x285657='verify',_0x4c434a=!0x1){async function _0x43ea93(_0x36faff){if(!_0x4c434a){if(_0x36faff['tenantId']==null&&_0x36faff['_agentRecaptchaConfig']!=null)return _0x36faff['_agentRecaptchaConfig']['siteKey'];if(_0x36faff['tenantId']!=null&&_0x36faff['_tenantRecaptchaConfigs'][_0x36faff['tenantId']]!==void 0x0)return _0x36faff['_tenantRecaptchaConfigs'][_0x36faff['tenantId']]['siteKey'];}return new Promise(async(_0x8786f2,_0x3a1f21)=>{uf(_0x36faff,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x25bb43=>{if(_0x25bb43['recaptchaKey']===void 0x0)_0x3a1f21(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2f2af6=new hf(_0x25bb43);return _0x36faff['tenantId']==null?_0x36faff['_agentRecaptchaConfig']=_0x2f2af6:_0x36faff['_tenantRecaptchaConfigs'][_0x36faff['tenantId']]=_0x2f2af6,_0x8786f2(_0x2f2af6['siteKey']);}})['catch'](_0x2f3e8c=>{_0x3a1f21(_0x2f3e8c);});});}function _0x54f82b(_0x2351c5,_0x231570,_0x4c5077){const _0x2cac52=window['grecaptcha'];vr(_0x2cac52)?_0x2cac52['enterprise']['ready'](()=>{_0x2cac52['enterprise']['execute'](_0x2351c5,{'action':_0x285657})['then'](_0x580577=>{_0x231570(_0x580577);})['catch'](()=>{_0x231570(Ma);});}):_0x4c5077(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x9f5261,_0x274ce0)=>{_0x43ea93(this['auth'])['then'](async _0x20fbdc=>{if(!_0x4c434a&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x54f82b(_0x20fbdc,_0x9f5261,_0x274ce0);else{if(typeof window>'u'){_0x274ce0(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x4ba877=Af();_0x4ba877['length']!==0x0&&(_0x4ba877+=_0x20fbdc+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x4b5282;(_0x4b5282=le['scriptInjectionDeferred'])==null||_0x4b5282['resolve']();},Da(_0x4ba877)['then'](()=>{var _0x21ab05;return(_0x21ab05=le['scriptInjectionDeferred'])==null?void 0x0:_0x21ab05['promise'];})['then'](()=>{_0x54f82b(_0x20fbdc,_0x9f5261,_0x274ce0);})['catch'](_0x21b2ac=>{_0x274ce0(_0x21b2ac);});}})['catch'](_0x2ddedc=>{_0x274ce0(_0x2ddedc);});});}}le['scriptInjectionDeferred']=null;async function br(_0x683c8e,_0x5dfd48,_0x1b6379,_0x183e18=!0x1,_0x937162=!0x1){const _0x59ff1d=new le(_0x683c8e);let _0x6ca18b;if(_0x937162)_0x6ca18b=Ma;else try{_0x6ca18b=await _0x59ff1d['verify'](_0x1b6379);}catch{_0x6ca18b=await _0x59ff1d['verify'](_0x1b6379,!0x0);}const _0x7da387={..._0x5dfd48};if(_0x1b6379==='mfaSmsEnrollment'||_0x1b6379==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x7da387){const _0x5c1805=_0x7da387['phoneEnrollmentInfo']['phoneNumber'],_0xc092e5=_0x7da387['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x7da387,{'phoneEnrollmentInfo':{'phoneNumber':_0x5c1805,'recaptchaToken':_0xc092e5,'captchaResponse':_0x6ca18b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x7da387){const _0x29b75b=_0x7da387['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x7da387,{'phoneSignInInfo':{'recaptchaToken':_0x29b75b,'captchaResponse':_0x6ca18b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x7da387;}return _0x183e18?Object['assign'](_0x7da387,{'captchaResp':_0x6ca18b}):Object['assign'](_0x7da387,{'captchaResponse':_0x6ca18b}),Object['assign'](_0x7da387,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x7da387,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x7da387;}async function Oi(_0x31bde4,_0x8cb0b9,_0x5b2ec9,_0x23d689,_0x5d68fe){var _0x1128fd;if((_0x1128fd=_0x31bde4['_getRecaptchaConfig']())!=null&&_0x1128fd['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1c52b8=await br(_0x31bde4,_0x8cb0b9,_0x5b2ec9,_0x5b2ec9==='getOobCode');return _0x23d689(_0x31bde4,_0x1c52b8);}else return _0x23d689(_0x31bde4,_0x8cb0b9)['catch'](async _0x1a5ece=>{if(_0x1a5ece['code']==='auth/missing-recaptcha-token'){console['log'](_0x5b2ec9+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4c3467=await br(_0x31bde4,_0x8cb0b9,_0x5b2ec9,_0x5b2ec9==='getOobCode');return _0x23d689(_0x31bde4,_0x4c3467);}else return Promise['reject'](_0x1a5ece);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x47bbcb,_0x6a7c31){const _0x47cc7a=Ui(_0x47bbcb,'auth');if(_0x47cc7a['isInitialized']()){const _0x19e7ec=_0x47cc7a['getImmediate'](),_0x3a81ef=_0x47cc7a['getOptions']();if(De(_0x3a81ef,_0x6a7c31??{}))return _0x19e7ec;K(_0x19e7ec,'already-initialized');}return _0x47cc7a['initialize']({'options':_0x6a7c31});}function Lf(_0xb5cdcf,_0x448a25){const _0x1208fb=(_0x448a25==null?void 0x0:_0x448a25['persistence'])||[],_0x328224=(Array['isArray'](_0x1208fb)?_0x1208fb:[_0x1208fb])['map'](ne);_0x448a25!=null&&_0x448a25['errorMap']&&_0xb5cdcf['_updateErrorMap'](_0x448a25['errorMap']),_0xb5cdcf['_initializeWithPersistence'](_0x328224,_0x448a25==null?void 0x0:_0x448a25['popupRedirectResolver']);}function xf(_0x52144c,_0x24fd0e,_0x326347){const _0x5d1841=qe(_0x52144c);m(/^https?:\/\//['test'](_0x24fd0e),_0x5d1841,'invalid-emulator-scheme');const _0x1c3d68=!0x1,_0x47855c=La(_0x24fd0e),{host:_0x3cd9d9,port:_0x13d4ba}=Ff(_0x24fd0e),_0x3c696f=_0x13d4ba===null?'':':'+_0x13d4ba,_0x3a6c68={'url':_0x47855c+'//'+_0x3cd9d9+_0x3c696f+'/'},_0x176fcb=Object['freeze']({'host':_0x3cd9d9,'port':_0x13d4ba,'protocol':_0x47855c['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1c3d68})});if(!_0x5d1841['_canInitEmulator']){m(_0x5d1841['config']['emulator']&&_0x5d1841['emulatorConfig'],_0x5d1841,'emulator-config-failed'),m(De(_0x3a6c68,_0x5d1841['config']['emulator'])&&De(_0x176fcb,_0x5d1841['emulatorConfig']),_0x5d1841,'emulator-config-failed');return;}_0x5d1841['config']['emulator']=_0x3a6c68,_0x5d1841['emulatorConfig']=_0x176fcb,_0x5d1841['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3cd9d9)?jr(_0x47855c+'//'+_0x3cd9d9+_0x3c696f):Uf();}function La(_0x4f3389){const _0x23c728=_0x4f3389['indexOf'](':');return _0x23c728<0x0?'':_0x4f3389['substr'](0x0,_0x23c728+0x1);}function Ff(_0x18b3b7){const _0x5c44bb=La(_0x18b3b7),_0x1eb567=/(\/\/)?([^?#/]+)/['exec'](_0x18b3b7['substr'](_0x5c44bb['length']));if(!_0x1eb567)return{'host':'','port':null};const _0x7c26ed=_0x1eb567[0x2]['split']('@')['pop']()||'',_0x478730=/^(\[[^\]]+\])(:|$)/['exec'](_0x7c26ed);if(_0x478730){const _0x4cd9c8=_0x478730[0x1];return{'host':_0x4cd9c8,'port':Rr(_0x7c26ed['substr'](_0x4cd9c8['length']+0x1))};}else{const [_0x458d7e,_0xb93ad9]=_0x7c26ed['split'](':');return{'host':_0x458d7e,'port':Rr(_0xb93ad9)};}}function Rr(_0x5a0d03){if(!_0x5a0d03)return null;const _0x24db0c=Number(_0x5a0d03);return isNaN(_0x24db0c)?null:_0x24db0c;}function Uf(){function _0x2631a2(){const _0x777a18=document['createElement']('p'),_0x30415e=_0x777a18['style'];_0x777a18['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x30415e['position']='fixed',_0x30415e['width']='100%',_0x30415e['backgroundColor']='#ffffff',_0x30415e['border']='.1em\x20solid\x20#000000',_0x30415e['color']='#b50000',_0x30415e['bottom']='0px',_0x30415e['left']='0px',_0x30415e['margin']='0px',_0x30415e['zIndex']='10000',_0x30415e['textAlign']='center',_0x777a18['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x777a18);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2631a2):_0x2631a2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x3115d9,_0x119ad3){this['providerId']=_0x3115d9,this['signInMethod']=_0x119ad3;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x5b41e2){return te('not\x20implemented');}['_linkToIdToken'](_0x579523,_0xdcfabc){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x374584){return te('not\x20implemented');}}async function Wf(_0xe8bd4b,_0x23f3c0){return Ae(_0xe8bd4b,'POST','/v1/accounts:signUp',_0x23f3c0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x24540e,_0xd528f5){return Yt(_0x24540e,'POST','/v1/accounts:signInWithPassword',Re(_0x24540e,_0xd528f5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x5e00a7,_0x50497d){return Yt(_0x5e00a7,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5e00a7,_0x50497d));}async function Hf(_0x32f9a0,_0x232b61){return Yt(_0x32f9a0,'POST','/v1/accounts:signInWithEmailLink',Re(_0x32f9a0,_0x232b61));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xdb01a8,_0x49ddc2,_0x21fe95,_0x59ccb9=null){super('password',_0x21fe95),this['_email']=_0xdb01a8,this['_password']=_0x49ddc2,this['_tenantId']=_0x59ccb9;}static['_fromEmailAndPassword'](_0x44e2e0,_0x6a93a4){return new Ft(_0x44e2e0,_0x6a93a4,'password');}static['_fromEmailAndCode'](_0x393f96,_0x4290ff,_0x15d35b=null){return new Ft(_0x393f96,_0x4290ff,'emailLink',_0x15d35b);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5219e0){const _0xaffc=typeof _0x5219e0=='string'?JSON['parse'](_0x5219e0):_0x5219e0;if(_0xaffc!=null&&_0xaffc['email']&&(_0xaffc!=null&&_0xaffc['password'])){if(_0xaffc['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xaffc['email'],_0xaffc['password']);if(_0xaffc['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xaffc['email'],_0xaffc['password'],_0xaffc['tenantId']);}return null;}async['_getIdTokenResponse'](_0x224c90){switch(this['signInMethod']){case'password':const _0x1344d7={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x224c90,_0x1344d7,'signInWithPassword',Bf);case'emailLink':return Vf(_0x224c90,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x224c90,'internal-error');}}async['_linkToIdToken'](_0x4669a9,_0x29e63d){switch(this['signInMethod']){case'password':const _0x13bc98={'idToken':_0x29e63d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4669a9,_0x13bc98,'signUpPassword',Wf);case'emailLink':return Hf(_0x4669a9,{'idToken':_0x29e63d,'email':this['_email'],'oobCode':this['_password']});default:K(_0x4669a9,'internal-error');}}['_getReauthenticationResolver'](_0x544cbe){return this['_getIdTokenResponse'](_0x544cbe);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x392992,_0x2e66aa){return Yt(_0x392992,'POST','/v1/accounts:signInWithIdp',Re(_0x392992,_0x2e66aa));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x28d261){const _0x4a8a0a=new We(_0x28d261['providerId'],_0x28d261['signInMethod']);return _0x28d261['idToken']||_0x28d261['accessToken']?(_0x28d261['idToken']&&(_0x4a8a0a['idToken']=_0x28d261['idToken']),_0x28d261['accessToken']&&(_0x4a8a0a['accessToken']=_0x28d261['accessToken']),_0x28d261['nonce']&&!_0x28d261['pendingToken']&&(_0x4a8a0a['nonce']=_0x28d261['nonce']),_0x28d261['pendingToken']&&(_0x4a8a0a['pendingToken']=_0x28d261['pendingToken'])):_0x28d261['oauthToken']&&_0x28d261['oauthTokenSecret']?(_0x4a8a0a['accessToken']=_0x28d261['oauthToken'],_0x4a8a0a['secret']=_0x28d261['oauthTokenSecret']):K('argument-error'),_0x4a8a0a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3bed5a){const _0x473f70=typeof _0x3bed5a=='string'?JSON['parse'](_0x3bed5a):_0x3bed5a,{providerId:_0x11d4c6,signInMethod:_0x38e905,..._0x3a3f9c}=_0x473f70;if(!_0x11d4c6||!_0x38e905)return null;const _0x33b4be=new We(_0x11d4c6,_0x38e905);return _0x33b4be['idToken']=_0x3a3f9c['idToken']||void 0x0,_0x33b4be['accessToken']=_0x3a3f9c['accessToken']||void 0x0,_0x33b4be['secret']=_0x3a3f9c['secret'],_0x33b4be['nonce']=_0x3a3f9c['nonce'],_0x33b4be['pendingToken']=_0x3a3f9c['pendingToken']||null,_0x33b4be;}['_getIdTokenResponse'](_0x28e25f){const _0x6bec77=this['buildRequest']();return Ze(_0x28e25f,_0x6bec77);}['_linkToIdToken'](_0x27efb9,_0x2d8366){const _0x527023=this['buildRequest']();return _0x527023['idToken']=_0x2d8366,Ze(_0x27efb9,_0x527023);}['_getReauthenticationResolver'](_0x384995){const _0x3974b7=this['buildRequest']();return _0x3974b7['autoCreate']=!0x1,Ze(_0x384995,_0x3974b7);}['buildRequest'](){const _0x456fa8={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x456fa8['pendingToken']=this['pendingToken'];else{const _0xe22eef={};this['idToken']&&(_0xe22eef['id_token']=this['idToken']),this['accessToken']&&(_0xe22eef['access_token']=this['accessToken']),this['secret']&&(_0xe22eef['oauth_token_secret']=this['secret']),_0xe22eef['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xe22eef['nonce']=this['nonce']),_0x456fa8['postBody']=at(_0xe22eef);}return _0x456fa8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x98bf29){switch(_0x98bf29){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x409b26){const _0xddef61=yt(vt(_0x409b26))['link'],_0x912b2a=_0xddef61?yt(vt(_0xddef61))['deep_link_id']:null,_0x394fd1=yt(vt(_0x409b26))['deep_link_id'];return(_0x394fd1?yt(vt(_0x394fd1))['link']:null)||_0x394fd1||_0x912b2a||_0xddef61||_0x409b26;}class Ss{constructor(_0x159a3d){const _0x5280bf=yt(vt(_0x159a3d)),_0x3a155d=_0x5280bf['apiKey']??null,_0xba5bf1=_0x5280bf['oobCode']??null,_0x552b0f=Gf(_0x5280bf['mode']??null);m(_0x3a155d&&_0xba5bf1&&_0x552b0f,'argument-error'),this['apiKey']=_0x3a155d,this['operation']=_0x552b0f,this['code']=_0xba5bf1,this['continueUrl']=_0x5280bf['continueUrl']??null,this['languageCode']=_0x5280bf['lang']??null,this['tenantId']=_0x5280bf['tenantId']??null;}static['parseLink'](_0x5785c2){const _0x313cd3=qf(_0x5785c2);try{return new Ss(_0x313cd3);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2a0376,_0x4e85d2){return Ft['_fromEmailAndPassword'](_0x2a0376,_0x4e85d2);}static['credentialWithLink'](_0x3a4569,_0x1d130d){const _0x11a434=Ss['parseLink'](_0x1d130d);return m(_0x11a434,'argument-error'),Ft['_fromEmailAndCode'](_0x3a4569,_0x11a434['code'],_0x11a434['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x32dc7e){this['providerId']=_0x32dc7e,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x14ae45){this['defaultLanguageCode']=_0x14ae45;}['setCustomParameters'](_0x4fbf00){return this['customParameters']=_0x4fbf00,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4042f3){return this['scopes']['includes'](_0x4042f3)||this['scopes']['push'](_0x4042f3),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x1b4f0e){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1b4f0e});}static['credentialFromResult'](_0x5cf4cf){return he['credentialFromTaggedObject'](_0x5cf4cf);}static['credentialFromError'](_0x4becda){return he['credentialFromTaggedObject'](_0x4becda['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x46b286}){if(!_0x46b286||!('oauthAccessToken'in _0x46b286)||!_0x46b286['oauthAccessToken'])return null;try{return he['credential'](_0x46b286['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3051c5,_0xc4fbcb){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3051c5,'accessToken':_0xc4fbcb});}static['credentialFromResult'](_0x1e3f8b){return ue['credentialFromTaggedObject'](_0x1e3f8b);}static['credentialFromError'](_0x2d44dd){return ue['credentialFromTaggedObject'](_0x2d44dd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x36b723}){if(!_0x36b723)return null;const {oauthIdToken:_0x262881,oauthAccessToken:_0x52eace}=_0x36b723;if(!_0x262881&&!_0x52eace)return null;try{return ue['credential'](_0x262881,_0x52eace);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x22c6cf){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x22c6cf});}static['credentialFromResult'](_0x603488){return de['credentialFromTaggedObject'](_0x603488);}static['credentialFromError'](_0x2d55b0){return de['credentialFromTaggedObject'](_0x2d55b0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c80d3}){if(!_0x2c80d3||!('oauthAccessToken'in _0x2c80d3)||!_0x2c80d3['oauthAccessToken'])return null;try{return de['credential'](_0x2c80d3['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x310cec,_0x305162){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x310cec,'oauthTokenSecret':_0x305162});}static['credentialFromResult'](_0x39cb34){return fe['credentialFromTaggedObject'](_0x39cb34);}static['credentialFromError'](_0x498181){return fe['credentialFromTaggedObject'](_0x498181['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x13f05f}){if(!_0x13f05f)return null;const {oauthAccessToken:_0x2a86aa,oauthTokenSecret:_0x6994b}=_0x13f05f;if(!_0x2a86aa||!_0x6994b)return null;try{return fe['credential'](_0x2a86aa,_0x6994b);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x36af7a,_0x97c15c){return Yt(_0x36af7a,'POST','/v1/accounts:signUp',Re(_0x36af7a,_0x97c15c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4806cc){this['user']=_0x4806cc['user'],this['providerId']=_0x4806cc['providerId'],this['_tokenResponse']=_0x4806cc['_tokenResponse'],this['operationType']=_0x4806cc['operationType'];}static async['_fromIdTokenResponse'](_0x2392d5,_0x57f2ef,_0x4045a8,_0x90f96a=!0x1){const _0x56f64a=await z['_fromIdTokenResponse'](_0x2392d5,_0x4045a8,_0x90f96a),_0x326d99=Ar(_0x4045a8);return new Be({'user':_0x56f64a,'providerId':_0x326d99,'_tokenResponse':_0x4045a8,'operationType':_0x57f2ef});}static async['_forOperation'](_0x33c504,_0x2d3d25,_0x16875c){await _0x33c504['_updateTokensIfNecessary'](_0x16875c,!0x0);const _0x116024=Ar(_0x16875c);return new Be({'user':_0x33c504,'providerId':_0x116024,'_tokenResponse':_0x16875c,'operationType':_0x2d3d25});}}function Ar(_0x1b3755){return _0x1b3755['providerId']?_0x1b3755['providerId']:'phoneNumber'in _0x1b3755?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x4a1870,_0x2a84ba,_0x23d084,_0x57b258){super(_0x2a84ba['code'],_0x2a84ba['message']),this['operationType']=_0x23d084,this['user']=_0x57b258,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x4a1870['name'],'tenantId':_0x4a1870['tenantId']??void 0x0,'_serverResponse':_0x2a84ba['customData']['_serverResponse'],'operationType':_0x23d084};}static['_fromErrorAndOperation'](_0x17a61a,_0x74e9bd,_0x4eca9b,_0x4c73fc){return new Rn(_0x17a61a,_0x74e9bd,_0x4eca9b,_0x4c73fc);}}function Fa(_0x3bf312,_0x70f5da,_0x2b364d,_0x9d7110){return(_0x70f5da==='reauthenticate'?_0x2b364d['_getReauthenticationResolver'](_0x3bf312):_0x2b364d['_getIdTokenResponse'](_0x3bf312))['catch'](_0xe14e36=>{throw _0xe14e36['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x3bf312,_0xe14e36,_0x70f5da,_0x9d7110):_0xe14e36;});}async function jf(_0xd53313,_0x34a08d,_0x22ad33=!0x1){const _0x5ad8dc=await xt(_0xd53313,_0x34a08d['_linkToIdToken'](_0xd53313['auth'],await _0xd53313['getIdToken']()),_0x22ad33);return Be['_forOperation'](_0xd53313,'link',_0x5ad8dc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3d610e,_0x2de7c2,_0xaf0ac8=!0x1){const {auth:_0x58a4f7}=_0x3d610e;if(H(_0x58a4f7['app']))return Promise['reject'](se(_0x58a4f7));const _0x1b5f9e='reauthenticate';try{const _0x3fe679=await xt(_0x3d610e,Fa(_0x58a4f7,_0x1b5f9e,_0x2de7c2,_0x3d610e),_0xaf0ac8);m(_0x3fe679['idToken'],_0x58a4f7,'internal-error');const _0x441abf=ws(_0x3fe679['idToken']);m(_0x441abf,_0x58a4f7,'internal-error');const {sub:_0xa2b87a}=_0x441abf;return m(_0x3d610e['uid']===_0xa2b87a,_0x58a4f7,'user-mismatch'),Be['_forOperation'](_0x3d610e,_0x1b5f9e,_0x3fe679);}catch(_0x43ab89){throw(_0x43ab89==null?void 0x0:_0x43ab89['code'])==='auth/user-not-found'&&K(_0x58a4f7,'user-mismatch'),_0x43ab89;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0xc33b4c,_0x59f7d7,_0xa235cf=!0x1){if(H(_0xc33b4c['app']))return Promise['reject'](se(_0xc33b4c));const _0x50607e='signIn',_0x43b171=await Fa(_0xc33b4c,_0x50607e,_0x59f7d7),_0x510d3f=await Be['_fromIdTokenResponse'](_0xc33b4c,_0x50607e,_0x43b171);return _0xa235cf||await _0xc33b4c['_updateCurrentUser'](_0x510d3f['user']),_0x510d3f;}async function Yf(_0x5751c0,_0x2bc667){return Ua(qe(_0x5751c0),_0x2bc667);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1a7910){const _0x3b1e9e=qe(_0x1a7910);_0x3b1e9e['_getPasswordPolicyInternal']()&&await _0x3b1e9e['_updatePasswordPolicy']();}async function R_(_0x1173c5,_0x19479f,_0x290714){if(H(_0x1173c5['app']))return Promise['reject'](se(_0x1173c5));const _0x22a877=qe(_0x1173c5),_0x2eee27=await Oi(_0x22a877,{'returnSecureToken':!0x0,'email':_0x19479f,'password':_0x290714,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x15ebb3=>{throw _0x15ebb3['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1173c5),_0x15ebb3;}),_0x4cba68=await Be['_fromIdTokenResponse'](_0x22a877,'signIn',_0x2eee27);return await _0x22a877['_updateCurrentUser'](_0x4cba68['user']),_0x4cba68;}function A_(_0x4e6df0,_0x1fee8d,_0x1e8126){return H(_0x4e6df0['app'])?Promise['reject'](se(_0x4e6df0)):Yf(k(_0x4e6df0),ft['credential'](_0x1fee8d,_0x1e8126))['catch'](async _0x56e19c=>{throw _0x56e19c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4e6df0),_0x56e19c;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x75ccfc,_0x25d8ff){return k(_0x75ccfc)['setPersistence'](_0x25d8ff);}function Qf(_0x563303,_0x232c9b,_0x4e1bb8,_0x52afdd){return k(_0x563303)['onIdTokenChanged'](_0x232c9b,_0x4e1bb8,_0x52afdd);}function Jf(_0x136ba7,_0x3796e1,_0x5b41f8){return k(_0x136ba7)['beforeAuthStateChanged'](_0x3796e1,_0x5b41f8);}function N_(_0x923906,_0x4616b6,_0x4259dc,_0x1bc7b0){return k(_0x923906)['onAuthStateChanged'](_0x4616b6,_0x4259dc,_0x1bc7b0);}function P_(_0x485173){return k(_0x485173)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x18a4a8,_0xe18407){this['storageRetriever']=_0x18a4a8,this['type']=_0xe18407;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x32e98c,_0x2dc007){return this['storage']['setItem'](_0x32e98c,JSON['stringify'](_0x2dc007)),Promise['resolve']();}['_get'](_0x50dd7e){const _0x529b22=this['storage']['getItem'](_0x50dd7e);return Promise['resolve'](_0x529b22?JSON['parse'](_0x529b22):null);}['_remove'](_0x39aa88){return this['storage']['removeItem'](_0x39aa88),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4e694b,_0x6bcc91)=>this['onStorageEvent'](_0x4e694b,_0x6bcc91),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x18c286){for(const _0x5d5827 of Object['keys'](this['listeners'])){const _0xe61d16=this['storage']['getItem'](_0x5d5827),_0x34f5a9=this['localCache'][_0x5d5827];_0xe61d16!==_0x34f5a9&&_0x18c286(_0x5d5827,_0x34f5a9,_0xe61d16);}}['onStorageEvent'](_0x11e6d0,_0x1436f8=!0x1){if(!_0x11e6d0['key']){this['forAllChangedKeys']((_0x3c0400,_0x12ad4a,_0x24f130)=>{this['notifyListeners'](_0x3c0400,_0x24f130);});return;}const _0xf3bc46=_0x11e6d0['key'];_0x1436f8?this['detachListener']():this['stopPolling']();const _0x47e49d=()=>{const _0x1e8bcf=this['storage']['getItem'](_0xf3bc46);!_0x1436f8&&this['localCache'][_0xf3bc46]===_0x1e8bcf||this['notifyListeners'](_0xf3bc46,_0x1e8bcf);},_0x3e9b3d=this['storage']['getItem'](_0xf3bc46);If()&&_0x3e9b3d!==_0x11e6d0['newValue']&&_0x11e6d0['newValue']!==_0x11e6d0['oldValue']?setTimeout(_0x47e49d,Zf):_0x47e49d();}['notifyListeners'](_0x54adc1,_0x2ef02e){this['localCache'][_0x54adc1]=_0x2ef02e;const _0x31a721=this['listeners'][_0x54adc1];if(_0x31a721){for(const _0x268567 of Array['from'](_0x31a721))_0x268567(_0x2ef02e&&JSON['parse'](_0x2ef02e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x19768d,_0x27e1e8,_0x10aace)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x19768d,'oldValue':_0x27e1e8,'newValue':_0x10aace}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x43b449,_0x1b3b17){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x43b449]||(this['listeners'][_0x43b449]=new Set(),this['localCache'][_0x43b449]=this['storage']['getItem'](_0x43b449)),this['listeners'][_0x43b449]['add'](_0x1b3b17);}['_removeListener'](_0x450173,_0x18aa30){this['listeners'][_0x450173]&&(this['listeners'][_0x450173]['delete'](_0x18aa30),this['listeners'][_0x450173]['size']===0x0&&delete this['listeners'][_0x450173]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4bdf79,_0x3ede59){await super['_set'](_0x4bdf79,_0x3ede59),this['localCache'][_0x4bdf79]=JSON['stringify'](_0x3ede59);}async['_get'](_0x5b58bb){const _0x52284d=await super['_get'](_0x5b58bb);return this['localCache'][_0x5b58bb]=JSON['stringify'](_0x52284d),_0x52284d;}async['_remove'](_0x512a54){await super['_remove'](_0x512a54),delete this['localCache'][_0x512a54];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3247b8,_0x577073){}['_removeListener'](_0x37f191,_0x1628c7){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x1bad8d){return Promise['all'](_0x1bad8d['map'](async _0x238c80=>{try{return{'fulfilled':!0x0,'value':await _0x238c80};}catch(_0x2aeae3){return{'fulfilled':!0x1,'reason':_0x2aeae3};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x250d4a){this['eventTarget']=_0x250d4a,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x529dbf){const _0x5a61cf=this['receivers']['find'](_0x134315=>_0x134315['isListeningto'](_0x529dbf));if(_0x5a61cf)return _0x5a61cf;const _0x2f011a=new jn(_0x529dbf);return this['receivers']['push'](_0x2f011a),_0x2f011a;}['isListeningto'](_0x5ee1e8){return this['eventTarget']===_0x5ee1e8;}async['handleEvent'](_0x40be09){const _0x5a72cd=_0x40be09,{eventId:_0x1f6599,eventType:_0x17f69e,data:_0x453422}=_0x5a72cd['data'],_0x5556bb=this['handlersMap'][_0x17f69e];if(!(_0x5556bb!=null&&_0x5556bb['size']))return;_0x5a72cd['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1f6599,'eventType':_0x17f69e});const _0x92798f=Array['from'](_0x5556bb)['map'](async _0x5bef63=>_0x5bef63(_0x5a72cd['origin'],_0x453422)),_0x27b108=await tp(_0x92798f);_0x5a72cd['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1f6599,'eventType':_0x17f69e,'response':_0x27b108});}['_subscribe'](_0x571da4,_0x28d6f3){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x571da4]||(this['handlersMap'][_0x571da4]=new Set()),this['handlersMap'][_0x571da4]['add'](_0x28d6f3);}['_unsubscribe'](_0x1d09ab,_0x604b6a){this['handlersMap'][_0x1d09ab]&&_0x604b6a&&this['handlersMap'][_0x1d09ab]['delete'](_0x604b6a),(!_0x604b6a||this['handlersMap'][_0x1d09ab]['size']===0x0)&&delete this['handlersMap'][_0x1d09ab],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x1868d5='',_0x9d73ee=0xa){let _0x52ea19='';for(let _0x2f4586=0x0;_0x2f4586<_0x9d73ee;_0x2f4586++)_0x52ea19+=Math['floor'](Math['random']()*0xa);return _0x1868d5+_0x52ea19;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x441da8){this['target']=_0x441da8,this['handlers']=new Set();}['removeMessageHandler'](_0x5b5ee7){_0x5b5ee7['messageChannel']&&(_0x5b5ee7['messageChannel']['port1']['removeEventListener']('message',_0x5b5ee7['onMessage']),_0x5b5ee7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5b5ee7);}async['_send'](_0x2fc90a,_0x3b83e3,_0x107366=0x32){const _0xf718ba=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xf718ba)throw new Error('connection_unavailable');let _0x51f514,_0x6e0a82;return new Promise((_0x17b849,_0x8abdb2)=>{const _0x10aa2e=bs('',0x14);_0xf718ba['port1']['start']();const _0x268b37=setTimeout(()=>{_0x8abdb2(new Error('unsupported_event'));},_0x107366);_0x6e0a82={'messageChannel':_0xf718ba,'onMessage'(_0x2f6458){const _0x285b0c=_0x2f6458;if(_0x285b0c['data']['eventId']===_0x10aa2e)switch(_0x285b0c['data']['status']){case'ack':clearTimeout(_0x268b37),_0x51f514=setTimeout(()=>{_0x8abdb2(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x51f514),_0x17b849(_0x285b0c['data']['response']);break;default:clearTimeout(_0x268b37),clearTimeout(_0x51f514),_0x8abdb2(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x6e0a82),_0xf718ba['port1']['addEventListener']('message',_0x6e0a82['onMessage']),this['target']['postMessage']({'eventType':_0x2fc90a,'eventId':_0x10aa2e,'data':_0x3b83e3},[_0xf718ba['port2']]);})['finally'](()=>{_0x6e0a82&&this['removeMessageHandler'](_0x6e0a82);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x34fc86){X()['location']['href']=_0x34fc86;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x424f6e;return((_0x424f6e=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x424f6e['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x19c0d6){this['request']=_0x19c0d6;}['toPromise'](){return new Promise((_0x532339,_0x21ea4d)=>{this['request']['addEventListener']('success',()=>{_0x532339(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x21ea4d(this['request']['error']);});});}}function Kn(_0x389505,_0x250286){return _0x389505['transaction']([kn],_0x250286?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x480e09=indexedDB['deleteDatabase'](qa);return new Jt(_0x480e09)['toPromise']();}function ja(){const _0x536ccd=indexedDB['open'](qa,ap);return new Promise((_0x8ba9ee,_0x575e97)=>{_0x536ccd['addEventListener']('error',()=>{_0x575e97(_0x536ccd['error']);}),_0x536ccd['addEventListener']('upgradeneeded',()=>{const _0x435075=_0x536ccd['result'];try{_0x435075['createObjectStore'](kn,{'keyPath':za});}catch(_0x3d278f){_0x575e97(_0x3d278f);}}),_0x536ccd['addEventListener']('success',async()=>{const _0x18ff3b=_0x536ccd['result'];_0x18ff3b['objectStoreNames']['contains'](kn)?_0x8ba9ee(_0x18ff3b):(_0x18ff3b['close'](),await cp(),_0x8ba9ee(await ja()));});});}async function kr(_0x2519af,_0x3c5744,_0x473a44){const _0x4e97a8=Kn(_0x2519af,!0x0)['put']({[za]:_0x3c5744,'value':_0x473a44});return new Jt(_0x4e97a8)['toPromise']();}async function lp(_0x17b02f,_0x485dd6){const _0x46fed4=Kn(_0x17b02f,!0x1)['get'](_0x485dd6),_0x5ef4c8=await new Jt(_0x46fed4)['toPromise']();return _0x5ef4c8===void 0x0?null:_0x5ef4c8['value'];}function Nr(_0x59fc78,_0x4c5b4e){const _0x32d4c3=Kn(_0x59fc78,!0x0)['delete'](_0x4c5b4e);return new Jt(_0x32d4c3)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x54371d){let _0x5a1b83=0x0;for(;;)try{const _0x26c1fb=await this['_openDb']();return await _0x54371d(_0x26c1fb);}catch(_0x18e1cb){if(_0x5a1b83++>up)throw _0x18e1cb;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1d406b,_0xa5b6ce)=>({'keyProcessed':(await this['_poll']())['includes'](_0xa5b6ce['key'])})),this['receiver']['_subscribe']('ping',async(_0xbfe63f,_0x12c696)=>['keyChanged']);}async['initializeSender'](){var _0x2796e0,_0x49a2f3;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1a1d31=await this['sender']['_send']('ping',{},0x320);_0x1a1d31&&(_0x2796e0=_0x1a1d31[0x0])!=null&&_0x2796e0['fulfilled']&&(_0x49a2f3=_0x1a1d31[0x0])!=null&&_0x49a2f3['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1d87b3){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1d87b3},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2c0b51=>{await kr(_0x2c0b51,An,'1'),await Nr(_0x2c0b51,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4eea83){this['pendingWrites']++;try{await _0x4eea83();}finally{this['pendingWrites']--;}}async['_set'](_0x23a9b6,_0x5bbe2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x213ad2=>kr(_0x213ad2,_0x23a9b6,_0x5bbe2)),this['localCache'][_0x23a9b6]=_0x5bbe2,this['notifyServiceWorker'](_0x23a9b6)));}async['_get'](_0x46d535){const _0xcf97=await this['_withRetries'](_0x364e68=>lp(_0x364e68,_0x46d535));return this['localCache'][_0x46d535]=_0xcf97,_0xcf97;}async['_remove'](_0x25912b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x38cbfd=>Nr(_0x38cbfd,_0x25912b)),delete this['localCache'][_0x25912b],this['notifyServiceWorker'](_0x25912b)));}async['_poll'](){const _0x14bba6=await this['_withRetries'](_0x4cf6de=>{const _0x58b99e=Kn(_0x4cf6de,!0x1)['getAll']();return new Jt(_0x58b99e)['toPromise']();});if(!_0x14bba6)return[];if(this['pendingWrites']!==0x0)return[];const _0x2cdca7=[],_0x4eacaa=new Set();if(_0x14bba6['length']!==0x0){for(const {fbase_key:_0xbfbf46,value:_0x35f1fe}of _0x14bba6)_0x4eacaa['add'](_0xbfbf46),JSON['stringify'](this['localCache'][_0xbfbf46])!==JSON['stringify'](_0x35f1fe)&&(this['notifyListeners'](_0xbfbf46,_0x35f1fe),_0x2cdca7['push'](_0xbfbf46));}for(const _0x2e427e of Object['keys'](this['localCache']))this['localCache'][_0x2e427e]&&!_0x4eacaa['has'](_0x2e427e)&&(this['notifyListeners'](_0x2e427e,null),_0x2cdca7['push'](_0x2e427e));return _0x2cdca7;}['notifyListeners'](_0x5bc1c3,_0x3b32e5){this['localCache'][_0x5bc1c3]=_0x3b32e5;const _0x4be94d=this['listeners'][_0x5bc1c3];if(_0x4be94d){for(const _0x634ed1 of Array['from'](_0x4be94d))_0x634ed1(_0x3b32e5);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1f392d,_0x460d3d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1f392d]||(this['listeners'][_0x1f392d]=new Set(),this['_get'](_0x1f392d)),this['listeners'][_0x1f392d]['add'](_0x460d3d);}['_removeListener'](_0xe2a9c1,_0x787582){this['listeners'][_0xe2a9c1]&&(this['listeners'][_0xe2a9c1]['delete'](_0x787582),this['listeners'][_0xe2a9c1]['size']===0x0&&delete this['listeners'][_0xe2a9c1]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x51c865,_0xe2561e){return _0xe2561e?ne(_0xe2561e):(m(_0x51c865['_popupRedirectResolver'],_0x51c865,'argument-error'),_0x51c865['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2f84c6){super('custom','custom'),this['params']=_0x2f84c6;}['_getIdTokenResponse'](_0x35b3fc){return Ze(_0x35b3fc,this['_buildIdpRequest']());}['_linkToIdToken'](_0x164c8e,_0x348abf){return Ze(_0x164c8e,this['_buildIdpRequest'](_0x348abf));}['_getReauthenticationResolver'](_0xa1d4fa){return Ze(_0xa1d4fa,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1268ab){const _0xac5251={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1268ab&&(_0xac5251['idToken']=_0x1268ab),_0xac5251;}}function pp(_0x19ea35){return Ua(_0x19ea35['auth'],new Rs(_0x19ea35),_0x19ea35['bypassAuthState']);}function _p(_0x5a816e){const {auth:_0xd799d3,user:_0x5ae4d0}=_0x5a816e;return m(_0x5ae4d0,_0xd799d3,'internal-error'),Kf(_0x5ae4d0,new Rs(_0x5a816e),_0x5a816e['bypassAuthState']);}async function gp(_0x2565c0){const {auth:_0x3108b7,user:_0xd9feaf}=_0x2565c0;return m(_0xd9feaf,_0x3108b7,'internal-error'),jf(_0xd9feaf,new Rs(_0x2565c0),_0x2565c0['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x33970f,_0x2e9c2b,_0x352147,_0x59145c,_0x479876=!0x1){this['auth']=_0x33970f,this['resolver']=_0x352147,this['user']=_0x59145c,this['bypassAuthState']=_0x479876,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2e9c2b)?_0x2e9c2b:[_0x2e9c2b];}['execute'](){return new Promise(async(_0x387cbc,_0x87555)=>{this['pendingPromise']={'resolve':_0x387cbc,'reject':_0x87555};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4da53d){this['reject'](_0x4da53d);}});}async['onAuthEvent'](_0x41bc66){const {urlResponse:_0x367b4b,sessionId:_0x382545,postBody:_0x246dd7,tenantId:_0x289427,error:_0x4bcc15,type:_0x11ca28}=_0x41bc66;if(_0x4bcc15){this['reject'](_0x4bcc15);return;}const _0x35b670={'auth':this['auth'],'requestUri':_0x367b4b,'sessionId':_0x382545,'tenantId':_0x289427||void 0x0,'postBody':_0x246dd7||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x11ca28)(_0x35b670));}catch(_0x5aac55){this['reject'](_0x5aac55);}}['onError'](_0x50b055){this['reject'](_0x50b055);}['getIdpTask'](_0x5def02){switch(_0x5def02){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x37ccf5){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x37ccf5),this['unregisterAndCleanUp']();}['reject'](_0x15779b){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x15779b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x522d59,_0x564abc,_0x1cb986,_0x43960c,_0x15189b){super(_0x522d59,_0x564abc,_0x43960c,_0x15189b),this['provider']=_0x1cb986,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x343b57=await this['execute']();return m(_0x343b57,this['auth'],'internal-error'),_0x343b57;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x137772=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x137772),this['authWindow']['associatedEvent']=_0x137772,this['resolver']['_originValidation'](this['auth'])['catch'](_0xc731c0=>{this['reject'](_0xc731c0);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x18d8ec=>{_0x18d8ec||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x34a55d;return((_0x34a55d=this['authWindow'])==null?void 0x0:_0x34a55d['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x187e7e=()=>{var _0x127fd0,_0x531056;if((_0x531056=(_0x127fd0=this['authWindow'])==null?void 0x0:_0x127fd0['window'])!=null&&_0x531056['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x187e7e,mp['get']());};_0x187e7e();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x6c5c8f,_0x6d7181,_0x24d3c7=!0x1){super(_0x6c5c8f,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x6d7181,void 0x0,_0x24d3c7),this['eventId']=null;}async['execute'](){let _0x566fef=rn['get'](this['auth']['_key']());if(!_0x566fef){try{const _0xe04683=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x566fef=()=>Promise['resolve'](_0xe04683);}catch(_0x370c30){_0x566fef=()=>Promise['reject'](_0x370c30);}rn['set'](this['auth']['_key'](),_0x566fef);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x566fef();}async['onAuthEvent'](_0x517b72){if(_0x517b72['type']==='signInViaRedirect')return super['onAuthEvent'](_0x517b72);if(_0x517b72['type']==='unknown'){this['resolve'](null);return;}if(_0x517b72['eventId']){const _0x382bcb=await this['auth']['_redirectUserForId'](_0x517b72['eventId']);if(_0x382bcb)return this['user']=_0x382bcb,super['onAuthEvent'](_0x517b72);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x4cd5b7,_0x26c208){const _0x4eb4a5=Cp(_0x26c208),_0x31703d=wp(_0x4cd5b7);if(!await _0x31703d['_isAvailable']())return!0x1;const _0x358c31=await _0x31703d['_get'](_0x4eb4a5)==='true';return await _0x31703d['_remove'](_0x4eb4a5),_0x358c31;}function Ip(_0x144b9d,_0x12d07e){rn['set'](_0x144b9d['_key'](),_0x12d07e);}function wp(_0xc7c21){return ne(_0xc7c21['_redirectPersistence']);}function Cp(_0x42ac6e){return sn(yp,_0x42ac6e['config']['apiKey'],_0x42ac6e['name']);}async function Tp(_0x46d886,_0x34b693,_0x2b527e=!0x1){if(H(_0x46d886['app']))return Promise['reject'](se(_0x46d886));const _0xa8e7cb=qe(_0x46d886),_0xc12429=fp(_0xa8e7cb,_0x34b693),_0x4d1b6f=await new vp(_0xa8e7cb,_0xc12429,_0x2b527e)['execute']();return _0x4d1b6f&&!_0x2b527e&&(delete _0x4d1b6f['user']['_redirectEventId'],await _0xa8e7cb['_persistUserIfCurrent'](_0x4d1b6f['user']),await _0xa8e7cb['_setRedirectUser'](null,_0x34b693)),_0x4d1b6f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4ee571){this['auth']=_0x4ee571,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1a0a09){this['consumers']['add'](_0x1a0a09),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1a0a09)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1a0a09),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x59d43d){this['consumers']['delete'](_0x59d43d);}['onEvent'](_0x3b42cd){if(this['hasEventBeenHandled'](_0x3b42cd))return!0x1;let _0x5507a5=!0x1;return this['consumers']['forEach'](_0x2d569b=>{this['isEventForConsumer'](_0x3b42cd,_0x2d569b)&&(_0x5507a5=!0x0,this['sendToConsumer'](_0x3b42cd,_0x2d569b),this['saveEventToCache'](_0x3b42cd));}),this['hasHandledPotentialRedirect']||!Rp(_0x3b42cd)||(this['hasHandledPotentialRedirect']=!0x0,_0x5507a5||(this['queuedRedirectEvent']=_0x3b42cd,_0x5507a5=!0x0)),_0x5507a5;}['sendToConsumer'](_0x321e33,_0x1270bd){var _0x20032a;if(_0x321e33['error']&&!Qa(_0x321e33)){const _0x10aec4=((_0x20032a=_0x321e33['error']['code'])==null?void 0x0:_0x20032a['split']('auth/')[0x1])||'internal-error';_0x1270bd['onError'](J(this['auth'],_0x10aec4));}else _0x1270bd['onAuthEvent'](_0x321e33);}['isEventForConsumer'](_0x11c50f,_0x20f5e8){const _0x4d94c7=_0x20f5e8['eventId']===null||!!_0x11c50f['eventId']&&_0x11c50f['eventId']===_0x20f5e8['eventId'];return _0x20f5e8['filter']['includes'](_0x11c50f['type'])&&_0x4d94c7;}['hasEventBeenHandled'](_0x5c6a70){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x5c6a70));}['saveEventToCache'](_0x59db50){this['cachedEventUids']['add'](Pr(_0x59db50)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x22d7ef){return[_0x22d7ef['type'],_0x22d7ef['eventId'],_0x22d7ef['sessionId'],_0x22d7ef['tenantId']]['filter'](_0x4ea897=>_0x4ea897)['join']('-');}function Qa({type:_0xf8ccf4,error:_0xe0ba16}){return _0xf8ccf4==='unknown'&&(_0xe0ba16==null?void 0x0:_0xe0ba16['code'])==='auth/no-auth-event';}function Rp(_0x25bfc){switch(_0x25bfc['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x25bfc);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x1c36d5,_0x4c2252={}){return Ae(_0x1c36d5,'GET','/v1/projects',_0x4c2252);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5c8ab4){if(_0x5c8ab4['config']['emulator'])return;const {authorizedDomains:_0x1bf634}=await Ap(_0x5c8ab4);for(const _0x3de804 of _0x1bf634)try{if(Op(_0x3de804))return;}catch{}K(_0x5c8ab4,'unauthorized-domain');}function Op(_0x55cd45){const _0x1c29fc=Ni(),{protocol:_0x5ac230,hostname:_0x3e741d}=new URL(_0x1c29fc);if(_0x55cd45['startsWith']('chrome-extension://')){const _0x337b4f=new URL(_0x55cd45);return _0x337b4f['hostname']===''&&_0x3e741d===''?_0x5ac230==='chrome-extension:'&&_0x55cd45['replace']('chrome-extension://','')===_0x1c29fc['replace']('chrome-extension://',''):_0x5ac230==='chrome-extension:'&&_0x337b4f['hostname']===_0x3e741d;}if(!Np['test'](_0x5ac230))return!0x1;if(kp['test'](_0x55cd45))return _0x3e741d===_0x55cd45;const _0x1664c3=_0x55cd45['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1664c3+'|'+_0x1664c3+')$','i')['test'](_0x3e741d);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x1ff5bf=X()['___jsl'];if(_0x1ff5bf!=null&&_0x1ff5bf['H']){for(const _0x426a68 of Object['keys'](_0x1ff5bf['H']))if(_0x1ff5bf['H'][_0x426a68]['r']=_0x1ff5bf['H'][_0x426a68]['r']||[],_0x1ff5bf['H'][_0x426a68]['L']=_0x1ff5bf['H'][_0x426a68]['L']||[],_0x1ff5bf['H'][_0x426a68]['r']=[..._0x1ff5bf['H'][_0x426a68]['L']],_0x1ff5bf['CP']){for(let _0x5e5cd3=0x0;_0x5e5cd3<_0x1ff5bf['CP']['length'];_0x5e5cd3++)_0x1ff5bf['CP'][_0x5e5cd3]=null;}}}function Mp(_0x2b20bc){return new Promise((_0x527592,_0x19a87e)=>{var _0x207aeb,_0x55dc34,_0x30bfcd;function _0x578228(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x527592(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x19a87e(J(_0x2b20bc,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x55dc34=(_0x207aeb=X()['gapi'])==null?void 0x0:_0x207aeb['iframes'])!=null&&_0x55dc34['Iframe'])_0x527592(gapi['iframes']['getContext']());else{if((_0x30bfcd=X()['gapi'])!=null&&_0x30bfcd['load'])_0x578228();else{const _0x4ec5d8=Nf('iframefcb');return X()[_0x4ec5d8]=()=>{gapi['load']?_0x578228():_0x19a87e(J(_0x2b20bc,'network-request-failed'));},Da(kf()+'?onload='+_0x4ec5d8)['catch'](_0x28d554=>_0x19a87e(_0x28d554));}}})['catch'](_0x566b6a=>{throw on=null,_0x566b6a;});}let on=null;function Lp(_0x273a8b){return on=on||Mp(_0x273a8b),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x494d5c){const _0xf54569=_0x494d5c['config'];m(_0xf54569['authDomain'],_0x494d5c,'auth-domain-config-required');const _0x2a23bb=_0xf54569['emulator']?Is(_0xf54569,Up):'https://'+_0x494d5c['config']['authDomain']+'/'+Fp,_0x5ad139={'apiKey':_0xf54569['apiKey'],'appName':_0x494d5c['name'],'v':ct},_0xb59c2e=Bp['get'](_0x494d5c['config']['apiHost']);_0xb59c2e&&(_0x5ad139['eid']=_0xb59c2e);const _0x2c914c=_0x494d5c['_getFrameworks']();return _0x2c914c['length']&&(_0x5ad139['fw']=_0x2c914c['join'](',')),_0x2a23bb+'?'+at(_0x5ad139)['slice'](0x1);}async function Hp(_0x5d34d3){const _0x4b88a7=await Lp(_0x5d34d3),_0x3500e6=X()['gapi'];return m(_0x3500e6,_0x5d34d3,'internal-error'),_0x4b88a7['open']({'where':document['body'],'url':Vp(_0x5d34d3),'messageHandlersFilter':_0x3500e6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x208635=>new Promise(async(_0x4287be,_0x1f19f8)=>{await _0x208635['restyle']({'setHideOnLeave':!0x1});const _0x412d05=J(_0x5d34d3,'network-request-failed'),_0x5bcd25=X()['setTimeout'](()=>{_0x1f19f8(_0x412d05);},xp['get']());function _0x32967f(){X()['clearTimeout'](_0x5bcd25),_0x4287be(_0x208635);}_0x208635['ping'](_0x32967f)['then'](_0x32967f,()=>{_0x1f19f8(_0x412d05);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3927cf){this['window']=_0x3927cf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x48620a,_0x2ddf46,_0x1deb1e,_0xac3eff=Gp,_0x3b74a3=qp){const _0x596a2a=Math['max']((window['screen']['availHeight']-_0x3b74a3)/0x2,0x0)['toString'](),_0x32ad09=Math['max']((window['screen']['availWidth']-_0xac3eff)/0x2,0x0)['toString']();let _0x55de8f='';const _0xc63387={...$p,'width':_0xac3eff['toString'](),'height':_0x3b74a3['toString'](),'top':_0x596a2a,'left':_0x32ad09},_0x469855=W()['toLowerCase']();_0x1deb1e&&(_0x55de8f=ba(_0x469855)?zp:_0x1deb1e),Ta(_0x469855)&&(_0x2ddf46=_0x2ddf46||jp,_0xc63387['scrollbars']='yes');const _0x1d97ac=Object['entries'](_0xc63387)['reduce']((_0x2c66b2,[_0x5ed4c6,_0xba007])=>''+_0x2c66b2+_0x5ed4c6+'='+_0xba007+',','');if(Ef(_0x469855)&&_0x55de8f!=='_self')return Yp(_0x2ddf46||'',_0x55de8f),new Dr(null);const _0xfcb085=window['open'](_0x2ddf46||'',_0x55de8f,_0x1d97ac);m(_0xfcb085,_0x48620a,'popup-blocked');try{_0xfcb085['focus']();}catch{}return new Dr(_0xfcb085);}function Yp(_0x1aaa52,_0x113dbd){const _0x264015=document['createElement']('a');_0x264015['href']=_0x1aaa52,_0x264015['target']=_0x113dbd;const _0x811458=document['createEvent']('MouseEvent');_0x811458['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x264015['dispatchEvent'](_0x811458);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x3b231f,_0x662af9,_0x339908,_0x523de9,_0xa3ccfe,_0x4297a7){m(_0x3b231f['config']['authDomain'],_0x3b231f,'auth-domain-config-required'),m(_0x3b231f['config']['apiKey'],_0x3b231f,'invalid-api-key');const _0x5d3bad={'apiKey':_0x3b231f['config']['apiKey'],'appName':_0x3b231f['name'],'authType':_0x339908,'redirectUrl':_0x523de9,'v':ct,'eventId':_0xa3ccfe};if(_0x662af9 instanceof xa){_0x662af9['setDefaultLanguage'](_0x3b231f['languageCode']),_0x5d3bad['providerId']=_0x662af9['providerId']||'',hi(_0x662af9['getCustomParameters']())||(_0x5d3bad['customParameters']=JSON['stringify'](_0x662af9['getCustomParameters']()));for(const [_0x28947a,_0xf8aef0]of Object['entries']({}))_0x5d3bad[_0x28947a]=_0xf8aef0;}if(_0x662af9 instanceof Qt){const _0x5f3284=_0x662af9['getScopes']()['filter'](_0x16fa6d=>_0x16fa6d!=='');_0x5f3284['length']>0x0&&(_0x5d3bad['scopes']=_0x5f3284['join'](','));}_0x3b231f['tenantId']&&(_0x5d3bad['tid']=_0x3b231f['tenantId']);const _0x124a0f=_0x5d3bad;for(const _0x4d0655 of Object['keys'](_0x124a0f))_0x124a0f[_0x4d0655]===void 0x0&&delete _0x124a0f[_0x4d0655];const _0x49621b=await _0x3b231f['_getAppCheckToken'](),_0x671c6f=_0x49621b?'#'+Xp+'='+encodeURIComponent(_0x49621b):'';return Zp(_0x3b231f)+'?'+at(_0x124a0f)['slice'](0x1)+_0x671c6f;}function Zp({config:_0x4832e2}){return _0x4832e2['emulator']?Is(_0x4832e2,Jp):'https://'+_0x4832e2['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0xbbec55,_0x145086,_0x1581b0,_0x3958ba){var _0x357f73;ae((_0x357f73=this['eventManagers'][_0xbbec55['_key']()])==null?void 0x0:_0x357f73['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x470937=await Mr(_0xbbec55,_0x145086,_0x1581b0,Ni(),_0x3958ba);return Kp(_0xbbec55,_0x470937,bs());}async['_openRedirect'](_0x285b47,_0x48440e,_0x22e9f3,_0x877d1f){await this['_originValidation'](_0x285b47);const _0x34db7b=await Mr(_0x285b47,_0x48440e,_0x22e9f3,Ni(),_0x877d1f);return ip(_0x34db7b),new Promise(()=>{});}['_initialize'](_0x4f205b){const _0x172eab=_0x4f205b['_key']();if(this['eventManagers'][_0x172eab]){const {manager:_0x358e37,promise:_0x58366d}=this['eventManagers'][_0x172eab];return _0x358e37?Promise['resolve'](_0x358e37):(ae(_0x58366d,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x58366d);}const _0x588397=this['initAndGetManager'](_0x4f205b);return this['eventManagers'][_0x172eab]={'promise':_0x588397},_0x588397['catch'](()=>{delete this['eventManagers'][_0x172eab];}),_0x588397;}async['initAndGetManager'](_0x34d716){const _0x17d474=await Hp(_0x34d716),_0x14db36=new bp(_0x34d716);return _0x17d474['register']('authEvent',_0x4deda1=>(m(_0x4deda1==null?void 0x0:_0x4deda1['authEvent'],_0x34d716,'invalid-auth-event'),{'status':_0x14db36['onEvent'](_0x4deda1['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x34d716['_key']()]={'manager':_0x14db36},this['iframes'][_0x34d716['_key']()]=_0x17d474,_0x14db36;}['_isIframeWebStorageSupported'](_0x322c31,_0x45882c){this['iframes'][_0x322c31['_key']()]['send'](li,{'type':li},_0x3019c6=>{var _0x262b0c;const _0x81ca14=(_0x262b0c=_0x3019c6==null?void 0x0:_0x3019c6[0x0])==null?void 0x0:_0x262b0c[li];_0x81ca14!==void 0x0&&_0x45882c(!!_0x81ca14),K(_0x322c31,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x530091){const _0x4459ee=_0x530091['_key']();return this['originValidationPromises'][_0x4459ee]||(this['originValidationPromises'][_0x4459ee]=Pp(_0x530091)),this['originValidationPromises'][_0x4459ee];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x513cd5){this['auth']=_0x513cd5,this['internalListeners']=new Map();}['getUid'](){var _0x16980d;return this['assertAuthConfigured'](),((_0x16980d=this['auth']['currentUser'])==null?void 0x0:_0x16980d['uid'])||null;}async['getToken'](_0x1a9adb){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1a9adb)}:null;}['addAuthTokenListener'](_0x3a41d1){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3a41d1))return;const _0x1601ed=this['auth']['onIdTokenChanged'](_0x866cb8=>{_0x3a41d1((_0x866cb8==null?void 0x0:_0x866cb8['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3a41d1,_0x1601ed),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2c0106){this['assertAuthConfigured']();const _0x2b3fd2=this['internalListeners']['get'](_0x2c0106);_0x2b3fd2&&(this['internalListeners']['delete'](_0x2c0106),_0x2b3fd2(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x1c626e){switch(_0x1c626e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x47c518){et(new Me('auth',(_0xbe88b8,{options:_0x5daef5})=>{const _0x11a8f6=_0xbe88b8['getProvider']('app')['getImmediate'](),_0x33a10e=_0xbe88b8['getProvider']('heartbeat'),_0x502504=_0xbe88b8['getProvider']('app-check-internal'),{apiKey:_0x2b1fd6,authDomain:_0x15e6bd}=_0x11a8f6['options'];m(_0x2b1fd6&&!_0x2b1fd6['includes'](':'),'invalid-api-key',{'appName':_0x11a8f6['name']});const _0x3aa7a4={'apiKey':_0x2b1fd6,'authDomain':_0x15e6bd,'clientPlatform':_0x47c518,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x47c518)},_0x1e1324=new bf(_0x11a8f6,_0x33a10e,_0x502504,_0x3aa7a4);return Lf(_0x1e1324,_0x5daef5),_0x1e1324;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x31053e,_0x58474,_0x4cbb94)=>{_0x31053e['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x49bdb9=>{const _0x5f2308=qe(_0x49bdb9['getProvider']('auth')['getImmediate']());return(_0x558743=>new n_(_0x558743))(_0x5f2308);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x47c518)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x4cdf6d=>async _0x4f4560=>{const _0x8012dc=_0x4f4560&&await _0x4f4560['getIdTokenResult'](),_0x13196e=_0x8012dc&&(new Date()['getTime']()-Date['parse'](_0x8012dc['issuedAtTime']))/0x3e8;if(_0x13196e&&_0x13196e>o_)return;const _0x5138bb=_0x8012dc==null?void 0x0:_0x8012dc['token'];Fr!==_0x5138bb&&(Fr=_0x5138bb,await fetch(_0x4cdf6d,{'method':_0x5138bb?'POST':'DELETE','headers':_0x5138bb?{'Authorization':'Bearer\x20'+_0x5138bb}:{}}));};function O_(_0x440b70=Qr()){const _0x2840cd=Ui(_0x440b70,'auth');if(_0x2840cd['isInitialized']())return _0x2840cd['getImmediate']();const _0x2989f4=Mf(_0x440b70,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2d6535=Gr('authTokenSyncURL');if(_0x2d6535&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x467343=new URL(_0x2d6535,location['origin']);if(location['origin']===_0x467343['origin']){const _0xe984ca=a_(_0x467343['toString']());Jf(_0x2989f4,_0xe984ca,()=>_0xe984ca(_0x2989f4['currentUser'])),Qf(_0x2989f4,_0x15a02e=>_0xe984ca(_0x15a02e));}}const _0x279bbe=Hr('auth');return _0x279bbe&&xf(_0x2989f4,'http://'+_0x279bbe),_0x2989f4;}function c_(){var _0x4f71b6;return((_0x4f71b6=document['getElementsByTagName']('head'))==null?void 0x0:_0x4f71b6[0x0])??document;}Rf({'loadJS'(_0x349085){return new Promise((_0x46e20b,_0x4b19be)=>{const _0xb1997d=document['createElement']('script');_0xb1997d['setAttribute']('src',_0x349085),_0xb1997d['onload']=_0x46e20b,_0xb1997d['onerror']=_0x396db8=>{const _0x257642=J('internal-error');_0x257642['customData']=_0x396db8,_0x4b19be(_0x257642);},_0xb1997d['type']='text/javascript',_0xb1997d['charset']='UTF-8',c_()['appendChild'](_0xb1997d);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};