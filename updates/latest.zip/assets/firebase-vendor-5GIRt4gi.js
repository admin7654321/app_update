const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1bea36,_0x18fd98){if(!_0x1bea36)throw ot(_0x18fd98);},ot=function(_0x36b9da){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x36b9da);},Wr=function(_0x11b28a){const _0x3c9737=[];let _0x495dcb=0x0;for(let _0x51e404=0x0;_0x51e404<_0x11b28a['length'];_0x51e404++){let _0x9617d8=_0x11b28a['charCodeAt'](_0x51e404);_0x9617d8<0x80?_0x3c9737[_0x495dcb++]=_0x9617d8:_0x9617d8<0x800?(_0x3c9737[_0x495dcb++]=_0x9617d8>>0x6|0xc0,_0x3c9737[_0x495dcb++]=_0x9617d8&0x3f|0x80):(_0x9617d8&0xfc00)===0xd800&&_0x51e404+0x1<_0x11b28a['length']&&(_0x11b28a['charCodeAt'](_0x51e404+0x1)&0xfc00)===0xdc00?(_0x9617d8=0x10000+((_0x9617d8&0x3ff)<<0xa)+(_0x11b28a['charCodeAt'](++_0x51e404)&0x3ff),_0x3c9737[_0x495dcb++]=_0x9617d8>>0x12|0xf0,_0x3c9737[_0x495dcb++]=_0x9617d8>>0xc&0x3f|0x80,_0x3c9737[_0x495dcb++]=_0x9617d8>>0x6&0x3f|0x80,_0x3c9737[_0x495dcb++]=_0x9617d8&0x3f|0x80):(_0x3c9737[_0x495dcb++]=_0x9617d8>>0xc|0xe0,_0x3c9737[_0x495dcb++]=_0x9617d8>>0x6&0x3f|0x80,_0x3c9737[_0x495dcb++]=_0x9617d8&0x3f|0x80);}return _0x3c9737;},Za=function(_0xc5493d){const _0x5230e9=[];let _0x17ea57=0x0,_0x51581f=0x0;for(;_0x17ea57<_0xc5493d['length'];){const _0x400e51=_0xc5493d[_0x17ea57++];if(_0x400e51<0x80)_0x5230e9[_0x51581f++]=String['fromCharCode'](_0x400e51);else{if(_0x400e51>0xbf&&_0x400e51<0xe0){const _0x496530=_0xc5493d[_0x17ea57++];_0x5230e9[_0x51581f++]=String['fromCharCode']((_0x400e51&0x1f)<<0x6|_0x496530&0x3f);}else{if(_0x400e51>0xef&&_0x400e51<0x16d){const _0x284088=_0xc5493d[_0x17ea57++],_0x2eeea3=_0xc5493d[_0x17ea57++],_0x5f1c31=_0xc5493d[_0x17ea57++],_0x4a7e5a=((_0x400e51&0x7)<<0x12|(_0x284088&0x3f)<<0xc|(_0x2eeea3&0x3f)<<0x6|_0x5f1c31&0x3f)-0x10000;_0x5230e9[_0x51581f++]=String['fromCharCode'](0xd800+(_0x4a7e5a>>0xa)),_0x5230e9[_0x51581f++]=String['fromCharCode'](0xdc00+(_0x4a7e5a&0x3ff));}else{const _0x15e2a6=_0xc5493d[_0x17ea57++],_0x213f79=_0xc5493d[_0x17ea57++];_0x5230e9[_0x51581f++]=String['fromCharCode']((_0x400e51&0xf)<<0xc|(_0x15e2a6&0x3f)<<0x6|_0x213f79&0x3f);}}}}return _0x5230e9['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x535f01,_0x22edef){if(!Array['isArray'](_0x535f01))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xb517b=_0x22edef?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2f2dfb=[];for(let _0x451316=0x0;_0x451316<_0x535f01['length'];_0x451316+=0x3){const _0x5f14c0=_0x535f01[_0x451316],_0x2c9d27=_0x451316+0x1<_0x535f01['length'],_0x107faf=_0x2c9d27?_0x535f01[_0x451316+0x1]:0x0,_0x25ac35=_0x451316+0x2<_0x535f01['length'],_0x360819=_0x25ac35?_0x535f01[_0x451316+0x2]:0x0,_0x3e761f=_0x5f14c0>>0x2,_0x22ecd5=(_0x5f14c0&0x3)<<0x4|_0x107faf>>0x4;let _0x34c418=(_0x107faf&0xf)<<0x2|_0x360819>>0x6,_0x354bdc=_0x360819&0x3f;_0x25ac35||(_0x354bdc=0x40,_0x2c9d27||(_0x34c418=0x40)),_0x2f2dfb['push'](_0xb517b[_0x3e761f],_0xb517b[_0x22ecd5],_0xb517b[_0x34c418],_0xb517b[_0x354bdc]);}return _0x2f2dfb['join']('');},'encodeString'(_0x26c4fb,_0x5883cf){return this['HAS_NATIVE_SUPPORT']&&!_0x5883cf?btoa(_0x26c4fb):this['encodeByteArray'](Wr(_0x26c4fb),_0x5883cf);},'decodeString'(_0x12c15c,_0x1c9410){return this['HAS_NATIVE_SUPPORT']&&!_0x1c9410?atob(_0x12c15c):Za(this['decodeStringToByteArray'](_0x12c15c,_0x1c9410));},'decodeStringToByteArray'(_0x58897c,_0x1298b9){this['init_']();const _0x4ae89c=_0x1298b9?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x247ce2=[];for(let _0x43426a=0x0;_0x43426a<_0x58897c['length'];){const _0x24489d=_0x4ae89c[_0x58897c['charAt'](_0x43426a++)],_0x28c476=_0x43426a<_0x58897c['length']?_0x4ae89c[_0x58897c['charAt'](_0x43426a)]:0x0;++_0x43426a;const _0x5a1c0a=_0x43426a<_0x58897c['length']?_0x4ae89c[_0x58897c['charAt'](_0x43426a)]:0x40;++_0x43426a;const _0x88a768=_0x43426a<_0x58897c['length']?_0x4ae89c[_0x58897c['charAt'](_0x43426a)]:0x40;if(++_0x43426a,_0x24489d==null||_0x28c476==null||_0x5a1c0a==null||_0x88a768==null)throw new ec();const _0x32b39a=_0x24489d<<0x2|_0x28c476>>0x4;if(_0x247ce2['push'](_0x32b39a),_0x5a1c0a!==0x40){const _0x325645=_0x28c476<<0x4&0xf0|_0x5a1c0a>>0x2;if(_0x247ce2['push'](_0x325645),_0x88a768!==0x40){const _0x4c7bc8=_0x5a1c0a<<0x6&0xc0|_0x88a768;_0x247ce2['push'](_0x4c7bc8);}}}return _0x247ce2;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3cfd9f=0x0;_0x3cfd9f<this['ENCODED_VALS']['length'];_0x3cfd9f++)this['byteToCharMap_'][_0x3cfd9f]=this['ENCODED_VALS']['charAt'](_0x3cfd9f),this['charToByteMap_'][this['byteToCharMap_'][_0x3cfd9f]]=_0x3cfd9f,this['byteToCharMapWebSafe_'][_0x3cfd9f]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3cfd9f),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3cfd9f]]=_0x3cfd9f,_0x3cfd9f>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3cfd9f)]=_0x3cfd9f,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3cfd9f)]=_0x3cfd9f);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x5c5ddb){const _0x13d6ea=Wr(_0x5c5ddb);return Di['encodeByteArray'](_0x13d6ea,!0x0);},an=function(_0x2a6777){return Br(_0x2a6777)['replace'](/\./g,'');},cn=function(_0x5886ca){try{return Di['decodeString'](_0x5886ca,!0x0);}catch(_0xd550b5){console['error']('base64Decode\x20failed:\x20',_0xd550b5);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x40edf2){return Vr(void 0x0,_0x40edf2);}function Vr(_0x233719,_0x568d0a){if(!(_0x568d0a instanceof Object))return _0x568d0a;switch(_0x568d0a['constructor']){case Date:const _0x482a13=_0x568d0a;return new Date(_0x482a13['getTime']());case Object:_0x233719===void 0x0&&(_0x233719={});break;case Array:_0x233719=[];break;default:return _0x568d0a;}for(const _0x5dff79 in _0x568d0a)!_0x568d0a['hasOwnProperty'](_0x5dff79)||!nc(_0x5dff79)||(_0x233719[_0x5dff79]=Vr(_0x233719[_0x5dff79],_0x568d0a[_0x5dff79]));return _0x233719;}function nc(_0x4acdbf){return _0x4acdbf!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x2f4419=As['__FIREBASE_DEFAULTS__'];if(_0x2f4419)return JSON['parse'](_0x2f4419);},oc=()=>{if(typeof document>'u')return;let _0x3c2726;try{_0x3c2726=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3e9f1f=_0x3c2726&&cn(_0x3c2726[0x1]);return _0x3e9f1f&&JSON['parse'](_0x3e9f1f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4df33c){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4df33c);return;}},Hr=_0x1b9289=>{var _0x24b366,_0x1f8169;return(_0x1f8169=(_0x24b366=Mi())==null?void 0x0:_0x24b366['emulatorHosts'])==null?void 0x0:_0x1f8169[_0x1b9289];},ac=_0x347292=>{const _0x1a6c93=Hr(_0x347292);if(!_0x1a6c93)return;const _0x37200d=_0x1a6c93['lastIndexOf'](':');if(_0x37200d<=0x0||_0x37200d+0x1===_0x1a6c93['length'])throw new Error('Invalid\x20host\x20'+_0x1a6c93+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4b3df8=parseInt(_0x1a6c93['substring'](_0x37200d+0x1),0xa);return _0x1a6c93[0x0]==='['?[_0x1a6c93['substring'](0x1,_0x37200d-0x1),_0x4b3df8]:[_0x1a6c93['substring'](0x0,_0x37200d),_0x4b3df8];},$r=()=>{var _0x181bab;return(_0x181bab=Mi())==null?void 0x0:_0x181bab['config'];},Gr=_0x325723=>{var _0x58df3f;return(_0x58df3f=Mi())==null?void 0x0:_0x58df3f['_'+_0x325723];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x378acd,_0x27927b)=>{this['resolve']=_0x378acd,this['reject']=_0x27927b;});}['wrapCallback'](_0x5bd798){return(_0x331e24,_0x4cdd1e)=>{_0x331e24?this['reject'](_0x331e24):this['resolve'](_0x4cdd1e),typeof _0x5bd798=='function'&&(this['promise']['catch'](()=>{}),_0x5bd798['length']===0x1?_0x5bd798(_0x331e24):_0x5bd798(_0x331e24,_0x4cdd1e));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x336ec7,_0x281e9a){if(_0x336ec7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1c1664={'alg':'none','type':'JWT'},_0x881f4=_0x281e9a||'demo-project',_0x5eea77=_0x336ec7['iat']||0x0,_0xa2b5af=_0x336ec7['sub']||_0x336ec7['user_id'];if(!_0xa2b5af)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1341ce={'iss':'https://securetoken.google.com/'+_0x881f4,'aud':_0x881f4,'iat':_0x5eea77,'exp':_0x5eea77+0xe10,'auth_time':_0x5eea77,'sub':_0xa2b5af,'user_id':_0xa2b5af,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x336ec7};return[an(JSON['stringify'](_0x1c1664)),an(JSON['stringify'](_0x1341ce)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x36dbf5=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x36dbf5=='object'&&_0x36dbf5['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x26bf8c=W();return _0x26bf8c['indexOf']('MSIE\x20')>=0x0||_0x26bf8c['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x1b4a49,_0x2bedf9)=>{try{let _0x2c6464=!0x0;const _0x4a0b6b='validate-browser-context-for-indexeddb-analytics-module',_0x3fb416=self['indexedDB']['open'](_0x4a0b6b);_0x3fb416['onsuccess']=()=>{_0x3fb416['result']['close'](),_0x2c6464||self['indexedDB']['deleteDatabase'](_0x4a0b6b),_0x1b4a49(!0x0);},_0x3fb416['onupgradeneeded']=()=>{_0x2c6464=!0x1;},_0x3fb416['onerror']=()=>{var _0x1f7ede;_0x2bedf9(((_0x1f7ede=_0x3fb416['error'])==null?void 0x0:_0x1f7ede['message'])||'');};}catch(_0x5bd7da){_0x2bedf9(_0x5bd7da);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x4107a7,_0x1f3ace,_0x27f6f5){super(_0x1f3ace),this['code']=_0x4107a7,this['customData']=_0x27f6f5,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x1a3b2f,_0xcd48d1,_0x31e134){this['service']=_0x1a3b2f,this['serviceName']=_0xcd48d1,this['errors']=_0x31e134;}['create'](_0x1c3116,..._0x5c05df){const _0x122580=_0x5c05df[0x0]||{},_0x47b7e2=this['service']+'/'+_0x1c3116,_0x5e7fa8=this['errors'][_0x1c3116],_0x52632c=_0x5e7fa8?gc(_0x5e7fa8,_0x122580):'Error',_0x292676=this['serviceName']+':\x20'+_0x52632c+'\x20('+_0x47b7e2+').';return new Se(_0x47b7e2,_0x292676,_0x122580);}}function gc(_0x4be73e,_0x7f339c){return _0x4be73e['replace'](mc,(_0x5344e5,_0x28e03c)=>{const _0x1139e8=_0x7f339c[_0x28e03c];return _0x1139e8!=null?String(_0x1139e8):'<'+_0x28e03c+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x2202c6){return JSON['parse'](_0x2202c6);}function O(_0x27aa29){return JSON['stringify'](_0x27aa29);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x41db9a){let _0x1a99bd={},_0x39a986={},_0x37c561={},_0x4591bc='';try{const _0x26d68f=_0x41db9a['split']('.');_0x1a99bd=bt(cn(_0x26d68f[0x0])||''),_0x39a986=bt(cn(_0x26d68f[0x1])||''),_0x4591bc=_0x26d68f[0x2],_0x37c561=_0x39a986['d']||{},delete _0x39a986['d'];}catch{}return{'header':_0x1a99bd,'claims':_0x39a986,'data':_0x37c561,'signature':_0x4591bc};},yc=function(_0x2f726a){const _0x15a76f=zr(_0x2f726a),_0x574e2b=_0x15a76f['claims'];return!!_0x574e2b&&typeof _0x574e2b=='object'&&_0x574e2b['hasOwnProperty']('iat');},vc=function(_0x10d1c5){const _0x238f0b=zr(_0x10d1c5)['claims'];return typeof _0x238f0b=='object'&&_0x238f0b['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x575783,_0x4c1303){return Object['prototype']['hasOwnProperty']['call'](_0x575783,_0x4c1303);}function Oe(_0x278d20,_0xe6156e){if(Object['prototype']['hasOwnProperty']['call'](_0x278d20,_0xe6156e))return _0x278d20[_0xe6156e];}function hi(_0x1087d2){for(const _0x370737 in _0x1087d2)if(Object['prototype']['hasOwnProperty']['call'](_0x1087d2,_0x370737))return!0x1;return!0x0;}function ln(_0x235d8d,_0x18e328,_0x3d1c05){const _0x28e1fe={};for(const _0x117767 in _0x235d8d)Object['prototype']['hasOwnProperty']['call'](_0x235d8d,_0x117767)&&(_0x28e1fe[_0x117767]=_0x18e328['call'](_0x3d1c05,_0x235d8d[_0x117767],_0x117767,_0x235d8d));return _0x28e1fe;}function De(_0x5bea15,_0x5bcf74){if(_0x5bea15===_0x5bcf74)return!0x0;const _0x1a689a=Object['keys'](_0x5bea15),_0xb37564=Object['keys'](_0x5bcf74);for(const _0xcd7445 of _0x1a689a){if(!_0xb37564['includes'](_0xcd7445))return!0x1;const _0x49b0ff=_0x5bea15[_0xcd7445],_0x541ca0=_0x5bcf74[_0xcd7445];if(ks(_0x49b0ff)&&ks(_0x541ca0)){if(!De(_0x49b0ff,_0x541ca0))return!0x1;}else{if(_0x49b0ff!==_0x541ca0)return!0x1;}}for(const _0x436595 of _0xb37564)if(!_0x1a689a['includes'](_0x436595))return!0x1;return!0x0;}function ks(_0x23ff46){return _0x23ff46!==null&&typeof _0x23ff46=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x53a960){const _0x28b45b=[];for(const [_0x29b1b1,_0x30a169]of Object['entries'](_0x53a960))Array['isArray'](_0x30a169)?_0x30a169['forEach'](_0x3add17=>{_0x28b45b['push'](encodeURIComponent(_0x29b1b1)+'='+encodeURIComponent(_0x3add17));}):_0x28b45b['push'](encodeURIComponent(_0x29b1b1)+'='+encodeURIComponent(_0x30a169));return _0x28b45b['length']?'&'+_0x28b45b['join']('&'):'';}function yt(_0x55db13){const _0x1bebd6={};return _0x55db13['replace'](/^\?/,'')['split']('&')['forEach'](_0x5b886c=>{if(_0x5b886c){const [_0x4e8493,_0x2c3c3e]=_0x5b886c['split']('=');_0x1bebd6[decodeURIComponent(_0x4e8493)]=decodeURIComponent(_0x2c3c3e);}}),_0x1bebd6;}function vt(_0x2b2ca7){const _0x3589fb=_0x2b2ca7['indexOf']('?');if(!_0x3589fb)return'';const _0x3a5b37=_0x2b2ca7['indexOf']('#',_0x3589fb);return _0x2b2ca7['substring'](_0x3589fb,_0x3a5b37>0x0?_0x3a5b37:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xe4f987=0x1;_0xe4f987<this['blockSize'];++_0xe4f987)this['pad_'][_0xe4f987]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5dfbce,_0x48b4bf){_0x48b4bf||(_0x48b4bf=0x0);const _0x37ae77=this['W_'];if(typeof _0x5dfbce=='string'){for(let _0x316c8c=0x0;_0x316c8c<0x10;_0x316c8c++)_0x37ae77[_0x316c8c]=_0x5dfbce['charCodeAt'](_0x48b4bf)<<0x18|_0x5dfbce['charCodeAt'](_0x48b4bf+0x1)<<0x10|_0x5dfbce['charCodeAt'](_0x48b4bf+0x2)<<0x8|_0x5dfbce['charCodeAt'](_0x48b4bf+0x3),_0x48b4bf+=0x4;}else{for(let _0x4f2389=0x0;_0x4f2389<0x10;_0x4f2389++)_0x37ae77[_0x4f2389]=_0x5dfbce[_0x48b4bf]<<0x18|_0x5dfbce[_0x48b4bf+0x1]<<0x10|_0x5dfbce[_0x48b4bf+0x2]<<0x8|_0x5dfbce[_0x48b4bf+0x3],_0x48b4bf+=0x4;}for(let _0x1f5c2f=0x10;_0x1f5c2f<0x50;_0x1f5c2f++){const _0x5c2226=_0x37ae77[_0x1f5c2f-0x3]^_0x37ae77[_0x1f5c2f-0x8]^_0x37ae77[_0x1f5c2f-0xe]^_0x37ae77[_0x1f5c2f-0x10];_0x37ae77[_0x1f5c2f]=(_0x5c2226<<0x1|_0x5c2226>>>0x1f)&0xffffffff;}let _0x3fe09b=this['chain_'][0x0],_0x45aa69=this['chain_'][0x1],_0x829fa8=this['chain_'][0x2],_0x419e04=this['chain_'][0x3],_0x6980e7=this['chain_'][0x4],_0x19f7db,_0x5cce05;for(let _0x3e0fe2=0x0;_0x3e0fe2<0x50;_0x3e0fe2++){_0x3e0fe2<0x28?_0x3e0fe2<0x14?(_0x19f7db=_0x419e04^_0x45aa69&(_0x829fa8^_0x419e04),_0x5cce05=0x5a827999):(_0x19f7db=_0x45aa69^_0x829fa8^_0x419e04,_0x5cce05=0x6ed9eba1):_0x3e0fe2<0x3c?(_0x19f7db=_0x45aa69&_0x829fa8|_0x419e04&(_0x45aa69|_0x829fa8),_0x5cce05=0x8f1bbcdc):(_0x19f7db=_0x45aa69^_0x829fa8^_0x419e04,_0x5cce05=0xca62c1d6);const _0x38b152=(_0x3fe09b<<0x5|_0x3fe09b>>>0x1b)+_0x19f7db+_0x6980e7+_0x5cce05+_0x37ae77[_0x3e0fe2]&0xffffffff;_0x6980e7=_0x419e04,_0x419e04=_0x829fa8,_0x829fa8=(_0x45aa69<<0x1e|_0x45aa69>>>0x2)&0xffffffff,_0x45aa69=_0x3fe09b,_0x3fe09b=_0x38b152;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3fe09b&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x45aa69&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x829fa8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x419e04&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x6980e7&0xffffffff;}['update'](_0x2fe029,_0x1fdb93){if(_0x2fe029==null)return;_0x1fdb93===void 0x0&&(_0x1fdb93=_0x2fe029['length']);const _0x53540b=_0x1fdb93-this['blockSize'];let _0x4fc413=0x0;const _0x26523d=this['buf_'];let _0x7f24cc=this['inbuf_'];for(;_0x4fc413<_0x1fdb93;){if(_0x7f24cc===0x0){for(;_0x4fc413<=_0x53540b;)this['compress_'](_0x2fe029,_0x4fc413),_0x4fc413+=this['blockSize'];}if(typeof _0x2fe029=='string'){for(;_0x4fc413<_0x1fdb93;)if(_0x26523d[_0x7f24cc]=_0x2fe029['charCodeAt'](_0x4fc413),++_0x7f24cc,++_0x4fc413,_0x7f24cc===this['blockSize']){this['compress_'](_0x26523d),_0x7f24cc=0x0;break;}}else{for(;_0x4fc413<_0x1fdb93;)if(_0x26523d[_0x7f24cc]=_0x2fe029[_0x4fc413],++_0x7f24cc,++_0x4fc413,_0x7f24cc===this['blockSize']){this['compress_'](_0x26523d),_0x7f24cc=0x0;break;}}}this['inbuf_']=_0x7f24cc,this['total_']+=_0x1fdb93;}['digest'](){const _0x334609=[];let _0x1d44a6=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x49668e=this['blockSize']-0x1;_0x49668e>=0x38;_0x49668e--)this['buf_'][_0x49668e]=_0x1d44a6&0xff,_0x1d44a6/=0x100;this['compress_'](this['buf_']);let _0x51f3cd=0x0;for(let _0xfa839d=0x0;_0xfa839d<0x5;_0xfa839d++)for(let _0xf29cab=0x18;_0xf29cab>=0x0;_0xf29cab-=0x8)_0x334609[_0x51f3cd]=this['chain_'][_0xfa839d]>>_0xf29cab&0xff,++_0x51f3cd;return _0x334609;}}function Ic(_0x388e12,_0xb23d82){const _0x39650=new wc(_0x388e12,_0xb23d82);return _0x39650['subscribe']['bind'](_0x39650);}class wc{constructor(_0x51fc98,_0x3746d7){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3746d7,this['task']['then'](()=>{_0x51fc98(this);})['catch'](_0x14eb38=>{this['error'](_0x14eb38);});}['next'](_0x31b05e){this['forEachObserver'](_0xa045c=>{_0xa045c['next'](_0x31b05e);});}['error'](_0x283b92){this['forEachObserver'](_0x2b7761=>{_0x2b7761['error'](_0x283b92);}),this['close'](_0x283b92);}['complete'](){this['forEachObserver'](_0x323e36=>{_0x323e36['complete']();}),this['close']();}['subscribe'](_0x1d251b,_0x407607,_0x57af7a){let _0x395fc7;if(_0x1d251b===void 0x0&&_0x407607===void 0x0&&_0x57af7a===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x1d251b,['next','error','complete'])?_0x395fc7=_0x1d251b:_0x395fc7={'next':_0x1d251b,'error':_0x407607,'complete':_0x57af7a},_0x395fc7['next']===void 0x0&&(_0x395fc7['next']=Qn),_0x395fc7['error']===void 0x0&&(_0x395fc7['error']=Qn),_0x395fc7['complete']===void 0x0&&(_0x395fc7['complete']=Qn);const _0x1dc8c3=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x395fc7['error'](this['finalError']):_0x395fc7['complete']();}catch{}}),this['observers']['push'](_0x395fc7),_0x1dc8c3;}['unsubscribeOne'](_0x1d94a5){this['observers']===void 0x0||this['observers'][_0x1d94a5]===void 0x0||(delete this['observers'][_0x1d94a5],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xfce51b){if(!this['finalized']){for(let _0x3cd5aa=0x0;_0x3cd5aa<this['observers']['length'];_0x3cd5aa++)this['sendOne'](_0x3cd5aa,_0xfce51b);}}['sendOne'](_0x4237e5,_0x25c3d8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4237e5]!==void 0x0)try{_0x25c3d8(this['observers'][_0x4237e5]);}catch(_0x48ecfb){typeof console<'u'&&console['error']&&console['error'](_0x48ecfb);}});}['close'](_0x5b337e){this['finalized']||(this['finalized']=!0x0,_0x5b337e!==void 0x0&&(this['finalError']=_0x5b337e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x40173a,_0x375dfc){if(typeof _0x40173a!='object'||_0x40173a===null)return!0x1;for(const _0x1ccb1d of _0x375dfc)if(_0x1ccb1d in _0x40173a&&typeof _0x40173a[_0x1ccb1d]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x4df1eb,_0x1b5ab2){return _0x4df1eb+'\x20failed:\x20'+_0x1b5ab2+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x160a78){const _0x1b0bd9=[];let _0x1a3c69=0x0;for(let _0x2f6944=0x0;_0x2f6944<_0x160a78['length'];_0x2f6944++){let _0x289c92=_0x160a78['charCodeAt'](_0x2f6944);if(_0x289c92>=0xd800&&_0x289c92<=0xdbff){const _0x587245=_0x289c92-0xd800;_0x2f6944++,f(_0x2f6944<_0x160a78['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x133179=_0x160a78['charCodeAt'](_0x2f6944)-0xdc00;_0x289c92=0x10000+(_0x587245<<0xa)+_0x133179;}_0x289c92<0x80?_0x1b0bd9[_0x1a3c69++]=_0x289c92:_0x289c92<0x800?(_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0x6|0xc0,_0x1b0bd9[_0x1a3c69++]=_0x289c92&0x3f|0x80):_0x289c92<0x10000?(_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0xc|0xe0,_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0x6&0x3f|0x80,_0x1b0bd9[_0x1a3c69++]=_0x289c92&0x3f|0x80):(_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0x12|0xf0,_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0xc&0x3f|0x80,_0x1b0bd9[_0x1a3c69++]=_0x289c92>>0x6&0x3f|0x80,_0x1b0bd9[_0x1a3c69++]=_0x289c92&0x3f|0x80);}return _0x1b0bd9;},Pn=function(_0x4f3b09){let _0x6ac508=0x0;for(let _0x234859=0x0;_0x234859<_0x4f3b09['length'];_0x234859++){const _0x130a8b=_0x4f3b09['charCodeAt'](_0x234859);_0x130a8b<0x80?_0x6ac508++:_0x130a8b<0x800?_0x6ac508+=0x2:_0x130a8b>=0xd800&&_0x130a8b<=0xdbff?(_0x6ac508+=0x4,_0x234859++):_0x6ac508+=0x3;}return _0x6ac508;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xc9ddc0){return _0xc9ddc0&&_0xc9ddc0['_delegate']?_0xc9ddc0['_delegate']:_0xc9ddc0;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x30f367){try{return(_0x30f367['startsWith']('http://')||_0x30f367['startsWith']('https://')?new URL(_0x30f367)['hostname']:_0x30f367)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x26fd93){return(await fetch(_0x26fd93,{'credentials':'include'}))['ok'];}class Me{constructor(_0x5e66e7,_0x10f24f,_0x1ea2d2){this['name']=_0x5e66e7,this['instanceFactory']=_0x10f24f,this['type']=_0x1ea2d2,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x45dfe9){return this['instantiationMode']=_0x45dfe9,this;}['setMultipleInstances'](_0x4ed143){return this['multipleInstances']=_0x4ed143,this;}['setServiceProps'](_0x156298){return this['serviceProps']=_0x156298,this;}['setInstanceCreatedCallback'](_0x2fbf59){return this['onInstanceCreated']=_0x2fbf59,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x952f26,_0xc4872c){this['name']=_0x952f26,this['container']=_0xc4872c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x568fc6){const _0xccbe6c=this['normalizeInstanceIdentifier'](_0x568fc6);if(!this['instancesDeferred']['has'](_0xccbe6c)){const _0xaa53ee=new Ve();if(this['instancesDeferred']['set'](_0xccbe6c,_0xaa53ee),this['isInitialized'](_0xccbe6c)||this['shouldAutoInitialize']())try{const _0x3381c2=this['getOrInitializeService']({'instanceIdentifier':_0xccbe6c});_0x3381c2&&_0xaa53ee['resolve'](_0x3381c2);}catch{}}return this['instancesDeferred']['get'](_0xccbe6c)['promise'];}['getImmediate'](_0x4b283b){const _0xbfdee5=this['normalizeInstanceIdentifier'](_0x4b283b==null?void 0x0:_0x4b283b['identifier']),_0x26cb0f=(_0x4b283b==null?void 0x0:_0x4b283b['optional'])??!0x1;if(this['isInitialized'](_0xbfdee5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xbfdee5});}catch(_0x1f6856){if(_0x26cb0f)return null;throw _0x1f6856;}else{if(_0x26cb0f)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2c7d58){if(_0x2c7d58['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2c7d58['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2c7d58,!!this['shouldAutoInitialize']()){if(Rc(_0x2c7d58))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x19786b,_0x1585b3]of this['instancesDeferred']['entries']()){const _0xe19ed5=this['normalizeInstanceIdentifier'](_0x19786b);try{const _0x438076=this['getOrInitializeService']({'instanceIdentifier':_0xe19ed5});_0x1585b3['resolve'](_0x438076);}catch{}}}}['clearInstance'](_0x4ef20e=ke){this['instancesDeferred']['delete'](_0x4ef20e),this['instancesOptions']['delete'](_0x4ef20e),this['instances']['delete'](_0x4ef20e);}async['delete'](){const _0x291fa0=Array['from'](this['instances']['values']());await Promise['all']([..._0x291fa0['filter'](_0x154d68=>'INTERNAL'in _0x154d68)['map'](_0x5185e0=>_0x5185e0['INTERNAL']['delete']()),..._0x291fa0['filter'](_0x4bf62b=>'_delete'in _0x4bf62b)['map'](_0x2c5c8a=>_0x2c5c8a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3dcde4=ke){return this['instances']['has'](_0x3dcde4);}['getOptions'](_0x564ff2=ke){return this['instancesOptions']['get'](_0x564ff2)||{};}['initialize'](_0x44f690={}){const {options:_0x5f5d88={}}=_0x44f690,_0x4103aa=this['normalizeInstanceIdentifier'](_0x44f690['instanceIdentifier']);if(this['isInitialized'](_0x4103aa))throw Error(this['name']+'('+_0x4103aa+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x109b3a=this['getOrInitializeService']({'instanceIdentifier':_0x4103aa,'options':_0x5f5d88});for(const [_0x146a0c,_0x123b3d]of this['instancesDeferred']['entries']()){const _0x336dcb=this['normalizeInstanceIdentifier'](_0x146a0c);_0x4103aa===_0x336dcb&&_0x123b3d['resolve'](_0x109b3a);}return _0x109b3a;}['onInit'](_0x34bd6c,_0x202853){const _0x145cdb=this['normalizeInstanceIdentifier'](_0x202853),_0x42632f=this['onInitCallbacks']['get'](_0x145cdb)??new Set();_0x42632f['add'](_0x34bd6c),this['onInitCallbacks']['set'](_0x145cdb,_0x42632f);const _0x55232d=this['instances']['get'](_0x145cdb);return _0x55232d&&_0x34bd6c(_0x55232d,_0x145cdb),()=>{_0x42632f['delete'](_0x34bd6c);};}['invokeOnInitCallbacks'](_0x567c3b,_0xc766d3){const _0x1049b5=this['onInitCallbacks']['get'](_0xc766d3);if(_0x1049b5){for(const _0x176d4b of _0x1049b5)try{_0x176d4b(_0x567c3b,_0xc766d3);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x19426a,options:_0xa25745={}}){let _0x5a3363=this['instances']['get'](_0x19426a);if(!_0x5a3363&&this['component']&&(_0x5a3363=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x19426a),'options':_0xa25745}),this['instances']['set'](_0x19426a,_0x5a3363),this['instancesOptions']['set'](_0x19426a,_0xa25745),this['invokeOnInitCallbacks'](_0x5a3363,_0x19426a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x19426a,_0x5a3363);}catch{}return _0x5a3363||null;}['normalizeInstanceIdentifier'](_0x4559f3=ke){return this['component']?this['component']['multipleInstances']?_0x4559f3:ke:_0x4559f3;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x52b177){return _0x52b177===ke?void 0x0:_0x52b177;}function Rc(_0x1b6e7a){return _0x1b6e7a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x19f2e3){this['name']=_0x19f2e3,this['providers']=new Map();}['addComponent'](_0x1b7225){const _0x3a3408=this['getProvider'](_0x1b7225['name']);if(_0x3a3408['isComponentSet']())throw new Error('Component\x20'+_0x1b7225['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3a3408['setComponent'](_0x1b7225);}['addOrOverwriteComponent'](_0x35a464){this['getProvider'](_0x35a464['name'])['isComponentSet']()&&this['providers']['delete'](_0x35a464['name']),this['addComponent'](_0x35a464);}['getProvider'](_0x3387bc){if(this['providers']['has'](_0x3387bc))return this['providers']['get'](_0x3387bc);const _0x12e2cd=new Sc(_0x3387bc,this);return this['providers']['set'](_0x3387bc,_0x12e2cd),_0x12e2cd;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5821bd){_0x5821bd[_0x5821bd['DEBUG']=0x0]='DEBUG',_0x5821bd[_0x5821bd['VERBOSE']=0x1]='VERBOSE',_0x5821bd[_0x5821bd['INFO']=0x2]='INFO',_0x5821bd[_0x5821bd['WARN']=0x3]='WARN',_0x5821bd[_0x5821bd['ERROR']=0x4]='ERROR',_0x5821bd[_0x5821bd['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2ba28a,_0x50dac6,..._0x2851e5)=>{if(_0x50dac6<_0x2ba28a['logLevel'])return;const _0x4d74df=new Date()['toISOString'](),_0x16f7ab=Pc[_0x50dac6];if(_0x16f7ab)console[_0x16f7ab]('['+_0x4d74df+']\x20\x20'+_0x2ba28a['name']+':',..._0x2851e5);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x50dac6+')');};class xi{constructor(_0x4153c4){this['name']=_0x4153c4,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x32c5f2){if(!(_0x32c5f2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x32c5f2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x32c5f2;}['setLogLevel'](_0x142292){this['_logLevel']=typeof _0x142292=='string'?kc[_0x142292]:_0x142292;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x179d07){if(typeof _0x179d07!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x179d07;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x280191){this['_userLogHandler']=_0x280191;}['debug'](..._0x4fcecf){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4fcecf),this['_logHandler'](this,T['DEBUG'],..._0x4fcecf);}['log'](..._0x434bd1){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x434bd1),this['_logHandler'](this,T['VERBOSE'],..._0x434bd1);}['info'](..._0x2d8e9a){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x2d8e9a),this['_logHandler'](this,T['INFO'],..._0x2d8e9a);}['warn'](..._0x28f49f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x28f49f),this['_logHandler'](this,T['WARN'],..._0x28f49f);}['error'](..._0x49f27b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x49f27b),this['_logHandler'](this,T['ERROR'],..._0x49f27b);}}const Dc=(_0x21fe30,_0x42e72d)=>_0x42e72d['some'](_0x5e1957=>_0x21fe30 instanceof _0x5e1957);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x439bb8){const _0x5275dc=new Promise((_0x1d8c68,_0x3abcdc)=>{const _0x521914=()=>{_0x439bb8['removeEventListener']('success',_0x55f96c),_0x439bb8['removeEventListener']('error',_0x529e24);},_0x55f96c=()=>{_0x1d8c68(_e(_0x439bb8['result'])),_0x521914();},_0x529e24=()=>{_0x3abcdc(_0x439bb8['error']),_0x521914();};_0x439bb8['addEventListener']('success',_0x55f96c),_0x439bb8['addEventListener']('error',_0x529e24);});return _0x5275dc['then'](_0x5cbe6d=>{_0x5cbe6d instanceof IDBCursor&&Kr['set'](_0x5cbe6d,_0x439bb8);})['catch'](()=>{}),Fi['set'](_0x5275dc,_0x439bb8),_0x5275dc;}function Fc(_0x2dae21){if(ui['has'](_0x2dae21))return;const _0x510b7b=new Promise((_0x27517b,_0x4810ba)=>{const _0x21496c=()=>{_0x2dae21['removeEventListener']('complete',_0x3a5aa9),_0x2dae21['removeEventListener']('error',_0x5173f0),_0x2dae21['removeEventListener']('abort',_0x5173f0);},_0x3a5aa9=()=>{_0x27517b(),_0x21496c();},_0x5173f0=()=>{_0x4810ba(_0x2dae21['error']||new DOMException('AbortError','AbortError')),_0x21496c();};_0x2dae21['addEventListener']('complete',_0x3a5aa9),_0x2dae21['addEventListener']('error',_0x5173f0),_0x2dae21['addEventListener']('abort',_0x5173f0);});ui['set'](_0x2dae21,_0x510b7b);}let di={'get'(_0x5e775e,_0x1c6eb8,_0x20617d){if(_0x5e775e instanceof IDBTransaction){if(_0x1c6eb8==='done')return ui['get'](_0x5e775e);if(_0x1c6eb8==='objectStoreNames')return _0x5e775e['objectStoreNames']||Yr['get'](_0x5e775e);if(_0x1c6eb8==='store')return _0x20617d['objectStoreNames'][0x1]?void 0x0:_0x20617d['objectStore'](_0x20617d['objectStoreNames'][0x0]);}return _e(_0x5e775e[_0x1c6eb8]);},'set'(_0x2714b9,_0x4db3d3,_0x4b727a){return _0x2714b9[_0x4db3d3]=_0x4b727a,!0x0;},'has'(_0x590109,_0x432643){return _0x590109 instanceof IDBTransaction&&(_0x432643==='done'||_0x432643==='store')?!0x0:_0x432643 in _0x590109;}};function Uc(_0x43c0b0){di=_0x43c0b0(di);}function Wc(_0x5db45a){return _0x5db45a===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x291abb,..._0x3b9607){const _0x58e6fd=_0x5db45a['call'](Xn(this),_0x291abb,..._0x3b9607);return Yr['set'](_0x58e6fd,_0x291abb['sort']?_0x291abb['sort']():[_0x291abb]),_e(_0x58e6fd);}:Lc()['includes'](_0x5db45a)?function(..._0x3ab6cb){return _0x5db45a['apply'](Xn(this),_0x3ab6cb),_e(Kr['get'](this));}:function(..._0x143d31){return _e(_0x5db45a['apply'](Xn(this),_0x143d31));};}function Bc(_0x14bd8c){return typeof _0x14bd8c=='function'?Wc(_0x14bd8c):(_0x14bd8c instanceof IDBTransaction&&Fc(_0x14bd8c),Dc(_0x14bd8c,Mc())?new Proxy(_0x14bd8c,di):_0x14bd8c);}function _e(_0x45d86e){if(_0x45d86e instanceof IDBRequest)return xc(_0x45d86e);if(Jn['has'](_0x45d86e))return Jn['get'](_0x45d86e);const _0x278b6b=Bc(_0x45d86e);return _0x278b6b!==_0x45d86e&&(Jn['set'](_0x45d86e,_0x278b6b),Fi['set'](_0x278b6b,_0x45d86e)),_0x278b6b;}const Xn=_0x543fbc=>Fi['get'](_0x543fbc);function Vc(_0x46ba4f,_0x3b5835,{blocked:_0x424968,upgrade:_0x5a5df6,blocking:_0xf52a0e,terminated:_0x4abc64}={}){const _0x834902=indexedDB['open'](_0x46ba4f,_0x3b5835),_0xd26ea2=_e(_0x834902);return _0x5a5df6&&_0x834902['addEventListener']('upgradeneeded',_0x32cba2=>{_0x5a5df6(_e(_0x834902['result']),_0x32cba2['oldVersion'],_0x32cba2['newVersion'],_e(_0x834902['transaction']),_0x32cba2);}),_0x424968&&_0x834902['addEventListener']('blocked',_0x1b3b34=>_0x424968(_0x1b3b34['oldVersion'],_0x1b3b34['newVersion'],_0x1b3b34)),_0xd26ea2['then'](_0xef5ade=>{_0x4abc64&&_0xef5ade['addEventListener']('close',()=>_0x4abc64()),_0xf52a0e&&_0xef5ade['addEventListener']('versionchange',_0x4127d8=>_0xf52a0e(_0x4127d8['oldVersion'],_0x4127d8['newVersion'],_0x4127d8));})['catch'](()=>{}),_0xd26ea2;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x9d3cf2,_0x4e7423){if(!(_0x9d3cf2 instanceof IDBDatabase&&!(_0x4e7423 in _0x9d3cf2)&&typeof _0x4e7423=='string'))return;if(Zn['get'](_0x4e7423))return Zn['get'](_0x4e7423);const _0x36b681=_0x4e7423['replace'](/FromIndex$/,''),_0x412f5d=_0x4e7423!==_0x36b681,_0x3b231e=$c['includes'](_0x36b681);if(!(_0x36b681 in(_0x412f5d?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3b231e||Hc['includes'](_0x36b681)))return;const _0x5ce4b0=async function(_0x159d5e,..._0x54c2fe){const _0x526256=this['transaction'](_0x159d5e,_0x3b231e?'readwrite':'readonly');let _0x23cdba=_0x526256['store'];return _0x412f5d&&(_0x23cdba=_0x23cdba['index'](_0x54c2fe['shift']())),(await Promise['all']([_0x23cdba[_0x36b681](..._0x54c2fe),_0x3b231e&&_0x526256['done']]))[0x0];};return Zn['set'](_0x4e7423,_0x5ce4b0),_0x5ce4b0;}Uc(_0x14decb=>({..._0x14decb,'get':(_0x15a7a7,_0x1a76c4,_0x5ad598)=>Os(_0x15a7a7,_0x1a76c4)||_0x14decb['get'](_0x15a7a7,_0x1a76c4,_0x5ad598),'has':(_0x43fe33,_0x247771)=>!!Os(_0x43fe33,_0x247771)||_0x14decb['has'](_0x43fe33,_0x247771)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x57b861){this['container']=_0x57b861;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5c435a=>{if(qc(_0x5c435a)){const _0x28c324=_0x5c435a['getImmediate']();return _0x28c324['library']+'/'+_0x28c324['version'];}else return null;})['filter'](_0x5e2a61=>_0x5e2a61)['join']('\x20');}}function qc(_0x22debd){const _0x59b9d7=_0x22debd['getComponent']();return(_0x59b9d7==null?void 0x0:_0x59b9d7['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4f6dd0,_0x42579f){try{_0x4f6dd0['container']['addComponent'](_0x42579f);}catch(_0x453bec){re['debug']('Component\x20'+_0x42579f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4f6dd0['name'],_0x453bec);}}function et(_0x2cb270){const _0x26eac9=_0x2cb270['name'];if(gi['has'](_0x26eac9))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x26eac9+'.'),!0x1;gi['set'](_0x26eac9,_0x2cb270);for(const _0x1ec536 of Le['values']())Ms(_0x1ec536,_0x2cb270);for(const _0x2f13cb of _i['values']())Ms(_0x2f13cb,_0x2cb270);return!0x0;}function Ui(_0x154001,_0x241c3f){const _0x4573e2=_0x154001['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4573e2&&_0x4573e2['triggerHeartbeat'](),_0x154001['container']['getProvider'](_0x241c3f);}function H(_0x4c2fb2){return _0x4c2fb2==null?!0x1:_0x4c2fb2['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x25095c,_0x70e09e,_0x1ed95a){this['_isDeleted']=!0x1,this['_options']={..._0x25095c},this['_config']={..._0x70e09e},this['_name']=_0x70e09e['name'],this['_automaticDataCollectionEnabled']=_0x70e09e['automaticDataCollectionEnabled'],this['_container']=_0x1ed95a,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5a7ddf){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5a7ddf;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x14243e){this['_isDeleted']=_0x14243e;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5ea616,_0x1ad548={}){let _0x2f19f8=_0x5ea616;typeof _0x1ad548!='object'&&(_0x1ad548={'name':_0x1ad548});const _0x20eb69={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1ad548},_0x701fbf=_0x20eb69['name'];if(typeof _0x701fbf!='string'||!_0x701fbf)throw ge['create']('bad-app-name',{'appName':String(_0x701fbf)});if(_0x2f19f8||(_0x2f19f8=$r()),!_0x2f19f8)throw ge['create']('no-options');const _0x50f604=Le['get'](_0x701fbf);if(_0x50f604){if(De(_0x2f19f8,_0x50f604['options'])&&De(_0x20eb69,_0x50f604['config']))return _0x50f604;throw ge['create']('duplicate-app',{'appName':_0x701fbf});}const _0x3a11ee=new Ac(_0x701fbf);for(const _0x126aed of gi['values']())_0x3a11ee['addComponent'](_0x126aed);const _0x53518c=new Il(_0x2f19f8,_0x20eb69,_0x3a11ee);return Le['set'](_0x701fbf,_0x53518c),_0x53518c;}function Qr(_0x2c5ce8=pi){const _0x152acc=Le['get'](_0x2c5ce8);if(!_0x152acc&&_0x2c5ce8===pi&&$r())return wl();if(!_0x152acc)throw ge['create']('no-app',{'appName':_0x2c5ce8});return _0x152acc;}function l_(){return Array['from'](Le['values']());}async function h_(_0x1fdb12){let _0x12ecb0=!0x1;const _0x5381f4=_0x1fdb12['name'];Le['has'](_0x5381f4)?(_0x12ecb0=!0x0,Le['delete'](_0x5381f4)):_i['has'](_0x5381f4)&&_0x1fdb12['decRefCount']()<=0x0&&(_i['delete'](_0x5381f4),_0x12ecb0=!0x0),_0x12ecb0&&(await Promise['all'](_0x1fdb12['container']['getProviders']()['map'](_0x14047b=>_0x14047b['delete']())),_0x1fdb12['isDeleted']=!0x0);}function me(_0x275ecb,_0x4ecf18,_0x5c2b92){let _0x47d75f=vl[_0x275ecb]??_0x275ecb;_0x5c2b92&&(_0x47d75f+='-'+_0x5c2b92);const _0x9e2425=_0x47d75f['match'](/\s|\//),_0x1d94dd=_0x4ecf18['match'](/\s|\//);if(_0x9e2425||_0x1d94dd){const _0x336dd1=['Unable\x20to\x20register\x20library\x20\x22'+_0x47d75f+'\x22\x20with\x20version\x20\x22'+_0x4ecf18+'\x22:'];_0x9e2425&&_0x336dd1['push']('library\x20name\x20\x22'+_0x47d75f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x9e2425&&_0x1d94dd&&_0x336dd1['push']('and'),_0x1d94dd&&_0x336dd1['push']('version\x20name\x20\x22'+_0x4ecf18+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x336dd1['join']('\x20'));return;}et(new Me(_0x47d75f+'-version',()=>({'library':_0x47d75f,'version':_0x4ecf18}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x5587cb,_0x55d5a7)=>{switch(_0x55d5a7){case 0x0:try{_0x5587cb['createObjectStore'](Rt);}catch(_0x29c75c){console['warn'](_0x29c75c);}}}})['catch'](_0x1df2ac=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1df2ac['message']});})),ei;}async function Sl(_0x339778){try{const _0x49c95d=(await Jr())['transaction'](Rt),_0x3d2df6=await _0x49c95d['objectStore'](Rt)['get'](Xr(_0x339778));return await _0x49c95d['done'],_0x3d2df6;}catch(_0x4498c0){if(_0x4498c0 instanceof Se)re['warn'](_0x4498c0['message']);else{const _0x37dfa6=ge['create']('idb-get',{'originalErrorMessage':_0x4498c0==null?void 0x0:_0x4498c0['message']});re['warn'](_0x37dfa6['message']);}}}async function Ls(_0x115346,_0x54783f){try{const _0x447d73=(await Jr())['transaction'](Rt,'readwrite');await _0x447d73['objectStore'](Rt)['put'](_0x54783f,Xr(_0x115346)),await _0x447d73['done'];}catch(_0x353d1c){if(_0x353d1c instanceof Se)re['warn'](_0x353d1c['message']);else{const _0x55138d=ge['create']('idb-set',{'originalErrorMessage':_0x353d1c==null?void 0x0:_0x353d1c['message']});re['warn'](_0x55138d['message']);}}}function Xr(_0x140aaf){return _0x140aaf['name']+'!'+_0x140aaf['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2e2c28){this['container']=_0x2e2c28,this['_heartbeatsCache']=null;const _0x7974ae=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x7974ae),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1d1374=>(this['_heartbeatsCache']=_0x1d1374,_0x1d1374));}async['triggerHeartbeat'](){var _0x116eda,_0x262915;try{const _0x22d2b5=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5e3ec7=xs();if(((_0x116eda=this['_heartbeatsCache'])==null?void 0x0:_0x116eda['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x262915=this['_heartbeatsCache'])==null?void 0x0:_0x262915['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5e3ec7||this['_heartbeatsCache']['heartbeats']['some'](_0x381a62=>_0x381a62['date']===_0x5e3ec7))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5e3ec7,'agent':_0x22d2b5}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1a50ad=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1a50ad,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1027be){re['warn'](_0x1027be);}}async['getHeartbeatsHeader'](){var _0x5e47bb;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5e47bb=this['_heartbeatsCache'])==null?void 0x0:_0x5e47bb['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x433702=xs(),{heartbeatsToSend:_0x1e29b0,unsentEntries:_0x33441a}=kl(this['_heartbeatsCache']['heartbeats']),_0xbc0354=an(JSON['stringify']({'version':0x2,'heartbeats':_0x1e29b0}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x433702,_0x33441a['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x33441a,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xbc0354;}catch(_0x41afe4){return re['warn'](_0x41afe4),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x429463,_0x2b9de9=bl){const _0x5348c9=[];let _0x4c4e99=_0x429463['slice']();for(const _0x339d69 of _0x429463){const _0x170659=_0x5348c9['find'](_0x3196d2=>_0x3196d2['agent']===_0x339d69['agent']);if(_0x170659){if(_0x170659['dates']['push'](_0x339d69['date']),Fs(_0x5348c9)>_0x2b9de9){_0x170659['dates']['pop']();break;}}else{if(_0x5348c9['push']({'agent':_0x339d69['agent'],'dates':[_0x339d69['date']]}),Fs(_0x5348c9)>_0x2b9de9){_0x5348c9['pop']();break;}}_0x4c4e99=_0x4c4e99['slice'](0x1);}return{'heartbeatsToSend':_0x5348c9,'unsentEntries':_0x4c4e99};}class Nl{constructor(_0x6d281f){this['app']=_0x6d281f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xa93603=await Sl(this['app']);return _0xa93603!=null&&_0xa93603['heartbeats']?_0xa93603:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3d6c07){if(await this['_canUseIndexedDBPromise']){const _0x39423d=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3d6c07['lastSentHeartbeatDate']??_0x39423d['lastSentHeartbeatDate'],'heartbeats':_0x3d6c07['heartbeats']});}else return;}async['add'](_0x1c36ed){if(await this['_canUseIndexedDBPromise']){const _0x481573=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1c36ed['lastSentHeartbeatDate']??_0x481573['lastSentHeartbeatDate'],'heartbeats':[..._0x481573['heartbeats'],..._0x1c36ed['heartbeats']]});}else return;}}function Fs(_0x2821f8){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x2821f8}))['length'];}function Pl(_0x17a9c2){if(_0x17a9c2['length']===0x0)return-0x1;let _0xb1603c=0x0,_0x38a811=_0x17a9c2[0x0]['date'];for(let _0x69525d=0x1;_0x69525d<_0x17a9c2['length'];_0x69525d++)_0x17a9c2[_0x69525d]['date']<_0x38a811&&(_0x38a811=_0x17a9c2[_0x69525d]['date'],_0xb1603c=_0x69525d);return _0xb1603c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x465db9){et(new Me('platform-logger',_0x431caf=>new Gc(_0x431caf),'PRIVATE')),et(new Me('heartbeat',_0x31d6ed=>new Al(_0x31d6ed),'PRIVATE')),me(fi,Ds,_0x465db9),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x4f5b3a){Zr=_0x4f5b3a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x5e4029){this['domStorage_']=_0x5e4029,this['prefix_']='firebase:';}['set'](_0x13fd5c,_0x4d3c05){_0x4d3c05==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x13fd5c)):this['domStorage_']['setItem'](this['prefixedName_'](_0x13fd5c),O(_0x4d3c05));}['get'](_0x120fb1){const _0x149d19=this['domStorage_']['getItem'](this['prefixedName_'](_0x120fb1));return _0x149d19==null?null:bt(_0x149d19);}['remove'](_0x247dd1){this['domStorage_']['removeItem'](this['prefixedName_'](_0x247dd1));}['prefixedName_'](_0x4e058a){return this['prefix_']+_0x4e058a;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1f1ead,_0x303009){_0x303009==null?delete this['cache_'][_0x1f1ead]:this['cache_'][_0x1f1ead]=_0x303009;}['get'](_0x250008){return Y(this['cache_'],_0x250008)?this['cache_'][_0x250008]:null;}['remove'](_0x2501ab){delete this['cache_'][_0x2501ab];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x325b99){try{if(typeof window<'u'&&typeof window[_0x325b99]<'u'){const _0xd9b79d=window[_0x325b99];return _0xd9b79d['setItem']('firebase:sentinel','cache'),_0xd9b79d['removeItem']('firebase:sentinel'),new xl(_0xd9b79d);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x491f38=0x1;return function(){return _0x491f38++;};}()),no=function(_0x352b1b){const _0x3ec610=Tc(_0x352b1b),_0xf7b000=new Ec();_0xf7b000['update'](_0x3ec610);const _0x46fc72=_0xf7b000['digest']();return Di['encodeByteArray'](_0x46fc72);},Bt=function(..._0x2c9327){let _0x243c10='';for(let _0x5ce8c4=0x0;_0x5ce8c4<_0x2c9327['length'];_0x5ce8c4++){const _0x5ce241=_0x2c9327[_0x5ce8c4];Array['isArray'](_0x5ce241)||_0x5ce241&&typeof _0x5ce241=='object'&&typeof _0x5ce241['length']=='number'?_0x243c10+=Bt['apply'](null,_0x5ce241):typeof _0x5ce241=='object'?_0x243c10+=O(_0x5ce241):_0x243c10+=_0x5ce241,_0x243c10+='\x20';}return _0x243c10;};let Et=null,Vs=!0x0;const Wl=function(_0x3d033a,_0x55e8d9){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x15044b){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0xeebb80=Bt['apply'](null,_0x15044b);Et(_0xeebb80);}},Vt=function(_0x31a399){return function(..._0x323dc7){L(_0x31a399,..._0x323dc7);};},mi=function(..._0x35bee2){const _0x51c36c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x35bee2);Qe['error'](_0x51c36c);},oe=function(..._0x467861){const _0x4d7b0a='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x467861);throw Qe['error'](_0x4d7b0a),new Error(_0x4d7b0a);},U=function(..._0x2267e7){const _0x40c28a='FIREBASE\x20WARNING:\x20'+Bt(..._0x2267e7);Qe['warn'](_0x40c28a);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x481f6b){return typeof _0x481f6b=='number'&&(_0x481f6b!==_0x481f6b||_0x481f6b===Number['POSITIVE_INFINITY']||_0x481f6b===Number['NEGATIVE_INFINITY']);},Vl=function(_0x4f3533){if(document['readyState']==='complete')_0x4f3533();else{let _0xcd8ad9=!0x1;const _0x4fe6e8=function(){if(!document['body']){setTimeout(_0x4fe6e8,Math['floor'](0xa));return;}_0xcd8ad9||(_0xcd8ad9=!0x0,_0x4f3533());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4fe6e8,!0x1),window['addEventListener']('load',_0x4fe6e8,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4fe6e8();}),window['attachEvent']('onload',_0x4fe6e8));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x52bdbf,_0x78c009){if(_0x52bdbf===_0x78c009)return 0x0;if(_0x52bdbf===xe||_0x78c009===Ie)return-0x1;if(_0x78c009===xe||_0x52bdbf===Ie)return 0x1;{const _0x335199=Hs(_0x52bdbf),_0xc1623c=Hs(_0x78c009);return _0x335199!==null?_0xc1623c!==null?_0x335199-_0xc1623c===0x0?_0x52bdbf['length']-_0x78c009['length']:_0x335199-_0xc1623c:-0x1:_0xc1623c!==null?0x1:_0x52bdbf<_0x78c009?-0x1:0x1;}},Hl=function(_0x392be6,_0x51e6c8){return _0x392be6===_0x51e6c8?0x0:_0x392be6<_0x51e6c8?-0x1:0x1;},pt=function(_0x1e173c,_0x2b2dc9){if(_0x2b2dc9&&_0x1e173c in _0x2b2dc9)return _0x2b2dc9[_0x1e173c];throw new Error('Missing\x20required\x20key\x20('+_0x1e173c+')\x20in\x20object:\x20'+O(_0x2b2dc9));},Bi=function(_0x459d36){if(typeof _0x459d36!='object'||_0x459d36===null)return O(_0x459d36);const _0x34ca58=[];for(const _0x19fa0c in _0x459d36)_0x34ca58['push'](_0x19fa0c);_0x34ca58['sort']();let _0x5a934c='{';for(let _0x40dcf8=0x0;_0x40dcf8<_0x34ca58['length'];_0x40dcf8++)_0x40dcf8!==0x0&&(_0x5a934c+=','),_0x5a934c+=O(_0x34ca58[_0x40dcf8]),_0x5a934c+=':',_0x5a934c+=Bi(_0x459d36[_0x34ca58[_0x40dcf8]]);return _0x5a934c+='}',_0x5a934c;},io=function(_0x4b4d0a,_0x292ca3){const _0x36f2f3=_0x4b4d0a['length'];if(_0x36f2f3<=_0x292ca3)return[_0x4b4d0a];const _0x8ffc55=[];for(let _0x11660b=0x0;_0x11660b<_0x36f2f3;_0x11660b+=_0x292ca3)_0x11660b+_0x292ca3>_0x36f2f3?_0x8ffc55['push'](_0x4b4d0a['substring'](_0x11660b,_0x36f2f3)):_0x8ffc55['push'](_0x4b4d0a['substring'](_0x11660b,_0x11660b+_0x292ca3));return _0x8ffc55;};function x(_0x4176c9,_0x59dc63){for(const _0x213b49 in _0x4176c9)_0x4176c9['hasOwnProperty'](_0x213b49)&&_0x59dc63(_0x213b49,_0x4176c9[_0x213b49]);}const so=function(_0x462d6c){f(!Wi(_0x462d6c),'Invalid\x20JSON\x20number');const _0x4063ba=0xb,_0x3741b6=0x34,_0x3c5703=(0x1<<_0x4063ba-0x1)-0x1;let _0x4201d5,_0x3e91cd,_0x43c6cf,_0x5476f2,_0xe31877;_0x462d6c===0x0?(_0x3e91cd=0x0,_0x43c6cf=0x0,_0x4201d5=0x1/_0x462d6c===-0x1/0x0?0x1:0x0):(_0x4201d5=_0x462d6c<0x0,_0x462d6c=Math['abs'](_0x462d6c),_0x462d6c>=Math['pow'](0x2,0x1-_0x3c5703)?(_0x5476f2=Math['min'](Math['floor'](Math['log'](_0x462d6c)/Math['LN2']),_0x3c5703),_0x3e91cd=_0x5476f2+_0x3c5703,_0x43c6cf=Math['round'](_0x462d6c*Math['pow'](0x2,_0x3741b6-_0x5476f2)-Math['pow'](0x2,_0x3741b6))):(_0x3e91cd=0x0,_0x43c6cf=Math['round'](_0x462d6c/Math['pow'](0x2,0x1-_0x3c5703-_0x3741b6))));const _0x21c7c6=[];for(_0xe31877=_0x3741b6;_0xe31877;_0xe31877-=0x1)_0x21c7c6['push'](_0x43c6cf%0x2?0x1:0x0),_0x43c6cf=Math['floor'](_0x43c6cf/0x2);for(_0xe31877=_0x4063ba;_0xe31877;_0xe31877-=0x1)_0x21c7c6['push'](_0x3e91cd%0x2?0x1:0x0),_0x3e91cd=Math['floor'](_0x3e91cd/0x2);_0x21c7c6['push'](_0x4201d5?0x1:0x0),_0x21c7c6['reverse']();const _0x18b0bd=_0x21c7c6['join']('');let _0x360333='';for(_0xe31877=0x0;_0xe31877<0x40;_0xe31877+=0x8){let _0x2469df=parseInt(_0x18b0bd['substr'](_0xe31877,0x8),0x2)['toString'](0x10);_0x2469df['length']===0x1&&(_0x2469df='0'+_0x2469df),_0x360333=_0x360333+_0x2469df;}return _0x360333['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x3d087c,_0x951b7e){let _0x1c6846='Unknown\x20Error';_0x3d087c==='too_big'?_0x1c6846='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3d087c==='permission_denied'?_0x1c6846='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3d087c==='unavailable'&&(_0x1c6846='The\x20service\x20is\x20unavailable');const _0x2ccc61=new Error(_0x3d087c+'\x20at\x20'+_0x951b7e['_path']['toString']()+':\x20'+_0x1c6846);return _0x2ccc61['code']=_0x3d087c['toUpperCase'](),_0x2ccc61;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x24f4ac){if(zl['test'](_0x24f4ac)){const _0x9fb6bf=Number(_0x24f4ac);if(_0x9fb6bf>=jl&&_0x9fb6bf<=Kl)return _0x9fb6bf;}return null;},lt=function(_0x34a8c7){try{_0x34a8c7();}catch(_0x297c1a){setTimeout(()=>{const _0x431703=_0x297c1a['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x431703),_0x297c1a;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x26ebb5,_0x3a3f67){const _0xf7b695=setTimeout(_0x26ebb5,_0x3a3f67);return typeof _0xf7b695=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xf7b695):typeof _0xf7b695=='object'&&_0xf7b695['unref']&&_0xf7b695['unref'](),_0xf7b695;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x2f5933,_0x392423){this['appCheckProvider']=_0x392423,this['appName']=_0x2f5933['name'],H(_0x2f5933)&&_0x2f5933['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2f5933['settings']['appCheckToken']),this['appCheck']=_0x392423==null?void 0x0:_0x392423['getImmediate']({'optional':!0x0}),this['appCheck']||_0x392423==null||_0x392423['get']()['then'](_0x263b0c=>this['appCheck']=_0x263b0c);}['getToken'](_0x5a2880){if(this['serverAppAppCheckToken']){if(_0x5a2880)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5a2880):new Promise((_0x11394e,_0x1edc84)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5a2880)['then'](_0x11394e,_0x1edc84):_0x11394e(null);},0x0);});}['addTokenChangeListener'](_0x180cee){var _0xb5266f;(_0xb5266f=this['appCheckProvider'])==null||_0xb5266f['get']()['then'](_0x3ec583=>_0x3ec583['addTokenListener'](_0x180cee));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x277051,_0x3b7563,_0x59f067){this['appName_']=_0x277051,this['firebaseOptions_']=_0x3b7563,this['authProvider_']=_0x59f067,this['auth_']=null,this['auth_']=_0x59f067['getImmediate']({'optional':!0x0}),this['auth_']||_0x59f067['onInit'](_0x6537b2=>this['auth_']=_0x6537b2);}['getToken'](_0x155cc0){return this['auth_']?this['auth_']['getToken'](_0x155cc0)['catch'](_0x243b41=>_0x243b41&&_0x243b41['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x243b41)):new Promise((_0x59844e,_0x54e71b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x155cc0)['then'](_0x59844e,_0x54e71b):_0x59844e(null);},0x0);});}['addTokenChangeListener'](_0x182d9e){this['auth_']?this['auth_']['addAuthTokenListener'](_0x182d9e):this['authProvider_']['get']()['then'](_0x96ba52=>_0x96ba52['addAuthTokenListener'](_0x182d9e));}['removeTokenChangeListener'](_0x55431a){this['authProvider_']['get']()['then'](_0x505ee3=>_0x505ee3['removeAuthTokenListener'](_0x55431a));}['notifyForInvalidToken'](){let _0x2996e8='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2996e8+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2996e8+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2996e8+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2996e8);}}class tn{constructor(_0xfe45c){this['accessToken']=_0xfe45c;}['getToken'](_0x213176){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x453f2f){_0x453f2f(this['accessToken']);}['removeTokenChangeListener'](_0x2208dd){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x44021,_0x1309a2,_0x7b1db1,_0x40a2e2,_0x26f547=!0x1,_0x43ad51='',_0x45a907=!0x1,_0x355113=!0x1,_0x2292a9=null){this['secure']=_0x1309a2,this['namespace']=_0x7b1db1,this['webSocketOnly']=_0x40a2e2,this['nodeAdmin']=_0x26f547,this['persistenceKey']=_0x43ad51,this['includeNamespaceInQueryParams']=_0x45a907,this['isUsingEmulator']=_0x355113,this['emulatorOptions']=_0x2292a9,this['_host']=_0x44021['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x44021)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2f8622){_0x2f8622!==this['internalHost']&&(this['internalHost']=_0x2f8622,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x14f179=this['toURLString']();return this['persistenceKey']&&(_0x14f179+='<'+this['persistenceKey']+'>'),_0x14f179;}['toURLString'](){const _0x165266=this['secure']?'https://':'http://',_0x21ecb2=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x165266+this['host']+'/'+_0x21ecb2;}}function Xl(_0x144051){return _0x144051['host']!==_0x144051['internalHost']||_0x144051['isCustomHost']()||_0x144051['includeNamespaceInQueryParams'];}function go(_0x2cfa47,_0x298d6d,_0x7f54ac){f(typeof _0x298d6d=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x7f54ac=='object','typeof\x20params\x20must\x20==\x20object');let _0x37f438;if(_0x298d6d===fo)_0x37f438=(_0x2cfa47['secure']?'wss://':'ws://')+_0x2cfa47['internalHost']+'/.ws?';else{if(_0x298d6d===po)_0x37f438=(_0x2cfa47['secure']?'https://':'http://')+_0x2cfa47['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x298d6d);}Xl(_0x2cfa47)&&(_0x7f54ac['ns']=_0x2cfa47['namespace']);const _0x12046b=[];return x(_0x7f54ac,(_0x3abeef,_0x277bca)=>{_0x12046b['push'](_0x3abeef+'='+_0x277bca);}),_0x37f438+_0x12046b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x18179e,_0x320af8=0x1){Y(this['counters_'],_0x18179e)||(this['counters_'][_0x18179e]=0x0),this['counters_'][_0x18179e]+=_0x320af8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x21742c){const _0x3484fb=_0x21742c['toString']();return ti[_0x3484fb]||(ti[_0x3484fb]=new Zl()),ti[_0x3484fb];}function eh(_0x390936,_0x44eaf2){const _0x477a5b=_0x390936['toString']();return ni[_0x477a5b]||(ni[_0x477a5b]=_0x44eaf2()),ni[_0x477a5b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x56bc79){this['onMessage_']=_0x56bc79,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x18b5f5,_0x468a9f){this['closeAfterResponse']=_0x18b5f5,this['onClose']=_0x468a9f,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x42e780,_0x5f2dc8){for(this['pendingResponses'][_0x42e780]=_0x5f2dc8;this['pendingResponses'][this['currentResponseNum']];){const _0x21e664=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x132699=0x0;_0x132699<_0x21e664['length'];++_0x132699)_0x21e664[_0x132699]&&lt(()=>{this['onMessage_'](_0x21e664[_0x132699]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x38df02,_0x5d116d,_0x578496,_0x413863,_0x3ec35a,_0x35495a,_0x4aa866){this['connId']=_0x38df02,this['repoInfo']=_0x5d116d,this['applicationId']=_0x578496,this['appCheckToken']=_0x413863,this['authToken']=_0x3ec35a,this['transportSessionId']=_0x35495a,this['lastSessionId']=_0x4aa866,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x38df02),this['stats_']=Hi(_0x5d116d),this['urlFn']=_0x33a3ae=>(this['appCheckToken']&&(_0x33a3ae[yi]=this['appCheckToken']),go(_0x5d116d,po,_0x33a3ae));}['open'](_0x173a97,_0x438a02){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x438a02,this['myPacketOrderer']=new th(_0x173a97),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x43f742)=>{const [_0x49e177,_0x43ea90,_0x8e0be3,_0x3a8bcd,_0x659b35]=_0x43f742;if(this['incrementIncomingBytes_'](_0x43f742),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x49e177===$s)this['id']=_0x43ea90,this['password']=_0x8e0be3;else{if(_0x49e177===nh)_0x43ea90?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x43ea90,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x49e177);}}},(..._0x2899ad)=>{const [_0x1b46a0,_0x568e20]=_0x2899ad;this['incrementIncomingBytes_'](_0x2899ad),this['myPacketOrderer']['handleResponse'](_0x1b46a0,_0x568e20);},()=>{this['onClosed_']();},this['urlFn']);const _0xc7d9e0={};_0xc7d9e0[$s]='t',_0xc7d9e0[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xc7d9e0[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xc7d9e0[ro]=Vi,this['transportSessionId']&&(_0xc7d9e0[oo]=this['transportSessionId']),this['lastSessionId']&&(_0xc7d9e0[ho]=this['lastSessionId']),this['applicationId']&&(_0xc7d9e0[uo]=this['applicationId']),this['appCheckToken']&&(_0xc7d9e0[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xc7d9e0[ao]=co);const _0x55a70b=this['urlFn'](_0xc7d9e0);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x55a70b),this['scriptTagHolder']['addTag'](_0x55a70b,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x19c71c){const _0x322c4e=O(_0x19c71c);this['bytesSent']+=_0x322c4e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x322c4e['length']);const _0x128a49=Br(_0x322c4e),_0x244d3b=io(_0x128a49,hh);for(let _0x4c75fa=0x0;_0x4c75fa<_0x244d3b['length'];_0x4c75fa++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x244d3b['length'],_0x244d3b[_0x4c75fa]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5d2907,_0x456319){this['myDisconnFrame']=document['createElement']('iframe');const _0x310734={};_0x310734[lh]='t',_0x310734[mo]=_0x5d2907,_0x310734[yo]=_0x456319,this['myDisconnFrame']['src']=this['urlFn'](_0x310734),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5e561f){const _0x1212ca=O(_0x5e561f)['length'];this['bytesReceived']+=_0x1212ca,this['stats_']['incrementCounter']('bytes_received',_0x1212ca);}}class $i{constructor(_0x93f2ca,_0x2fa019,_0x5c4a46,_0x425e71){this['onDisconnect']=_0x5c4a46,this['urlFn']=_0x425e71,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x93f2ca,window[sh+this['uniqueCallbackIdentifier']]=_0x2fa019,this['myIFrame']=$i['createIFrame_']();let _0x46399d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x46399d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x353a84='<html><body>'+_0x46399d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x353a84),this['myIFrame']['doc']['close']();}catch(_0x2e33d7){L('frame\x20writing\x20exception'),_0x2e33d7['stack']&&L(_0x2e33d7['stack']),L(_0x2e33d7);}}}static['createIFrame_'](){const _0x2a87c0=document['createElement']('iframe');if(_0x2a87c0['style']['display']='none',document['body']){document['body']['appendChild'](_0x2a87c0);try{_0x2a87c0['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4411b4=document['domain'];_0x2a87c0['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4411b4+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2a87c0['contentDocument']?_0x2a87c0['doc']=_0x2a87c0['contentDocument']:_0x2a87c0['contentWindow']?_0x2a87c0['doc']=_0x2a87c0['contentWindow']['document']:_0x2a87c0['document']&&(_0x2a87c0['doc']=_0x2a87c0['document']),_0x2a87c0;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x43b609=this['onDisconnect'];_0x43b609&&(this['onDisconnect']=null,_0x43b609());}['startLongPoll'](_0x16de02,_0x1a5412){for(this['myID']=_0x16de02,this['myPW']=_0x1a5412,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x227a17={};_0x227a17[mo]=this['myID'],_0x227a17[yo]=this['myPW'],_0x227a17[vo]=this['currentSerial'];let _0xcc3138=this['urlFn'](_0x227a17),_0x4eff96='',_0x2b9c9d=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x4eff96['length']<=Eo;){const _0x41e868=this['pendingSegs']['shift']();_0x4eff96=_0x4eff96+'&'+oh+_0x2b9c9d+'='+_0x41e868['seg']+'&'+ah+_0x2b9c9d+'='+_0x41e868['ts']+'&'+ch+_0x2b9c9d+'='+_0x41e868['d'],_0x2b9c9d++;}return _0xcc3138=_0xcc3138+_0x4eff96,this['addLongPollTag_'](_0xcc3138,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x57112c,_0x36a4f6,_0x3b7593){this['pendingSegs']['push']({'seg':_0x57112c,'ts':_0x36a4f6,'d':_0x3b7593}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1fc879,_0xc8971f){this['outstandingRequests']['add'](_0xc8971f);const _0x3772eb=()=>{this['outstandingRequests']['delete'](_0xc8971f),this['newRequest_']();},_0x2b51bd=setTimeout(_0x3772eb,Math['floor'](uh)),_0x40f350=()=>{clearTimeout(_0x2b51bd),_0x3772eb();};this['addTag'](_0x1fc879,_0x40f350);}['addTag'](_0x53e17f,_0xc0d01f){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x39ba71=this['myIFrame']['doc']['createElement']('script');_0x39ba71['type']='text/javascript',_0x39ba71['async']=!0x0,_0x39ba71['src']=_0x53e17f,_0x39ba71['onload']=_0x39ba71['onreadystatechange']=function(){const _0x3d1a8c=_0x39ba71['readyState'];(!_0x3d1a8c||_0x3d1a8c==='loaded'||_0x3d1a8c==='complete')&&(_0x39ba71['onload']=_0x39ba71['onreadystatechange']=null,_0x39ba71['parentNode']&&_0x39ba71['parentNode']['removeChild'](_0x39ba71),_0xc0d01f());},_0x39ba71['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x53e17f),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x39ba71);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x469604,_0x1257b9,_0x27ee76,_0x5cd96d,_0x52cf53,_0x1befcf,_0x2dd089){this['connId']=_0x469604,this['applicationId']=_0x27ee76,this['appCheckToken']=_0x5cd96d,this['authToken']=_0x52cf53,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x1257b9),this['connURL']=G['connectionURL_'](_0x1257b9,_0x1befcf,_0x2dd089,_0x5cd96d,_0x27ee76),this['nodeAdmin']=_0x1257b9['nodeAdmin'];}static['connectionURL_'](_0x32d1eb,_0x37fe51,_0x46e7e7,_0x453310,_0x1d07cb){const _0x5622eb={};return _0x5622eb[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5622eb[ao]=co),_0x37fe51&&(_0x5622eb[oo]=_0x37fe51),_0x46e7e7&&(_0x5622eb[ho]=_0x46e7e7),_0x453310&&(_0x5622eb[yi]=_0x453310),_0x1d07cb&&(_0x5622eb[uo]=_0x1d07cb),go(_0x32d1eb,fo,_0x5622eb);}['open'](_0x21d527,_0x4afc37){this['onDisconnect']=_0x4afc37,this['onMessage']=_0x21d527,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x10919a;dc(),this['mySock']=new hn(this['connURL'],[],_0x10919a);}catch(_0x3fa255){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2d0943=_0x3fa255['message']||_0x3fa255['data'];_0x2d0943&&this['log_'](_0x2d0943),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1167c1=>{this['handleIncomingFrame'](_0x1167c1);},this['mySock']['onerror']=_0x7f3cee=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5539ab=_0x7f3cee['message']||_0x7f3cee['data'];_0x5539ab&&this['log_'](_0x5539ab),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x31c248=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x107383=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5168c3=navigator['userAgent']['match'](_0x107383);_0x5168c3&&_0x5168c3['length']>0x1&&parseFloat(_0x5168c3[0x1])<4.4&&(_0x31c248=!0x0);}return!_0x31c248&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x53bfd2){if(this['frames']['push'](_0x53bfd2),this['frames']['length']===this['totalFrames']){const _0x5b6406=this['frames']['join']('');this['frames']=null;const _0x2d924c=bt(_0x5b6406);this['onMessage'](_0x2d924c);}}['handleNewFrameCount_'](_0x27b4a4){this['totalFrames']=_0x27b4a4,this['frames']=[];}['extractFrameCount_'](_0x2ad054){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2ad054['length']<=0x6){const _0x5217a4=Number(_0x2ad054);if(!isNaN(_0x5217a4))return this['handleNewFrameCount_'](_0x5217a4),null;}return this['handleNewFrameCount_'](0x1),_0x2ad054;}['handleIncomingFrame'](_0xa6b3a8){if(this['mySock']===null)return;const _0x98e694=_0xa6b3a8['data'];if(this['bytesReceived']+=_0x98e694['length'],this['stats_']['incrementCounter']('bytes_received',_0x98e694['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x98e694);else{const _0x4435de=this['extractFrameCount_'](_0x98e694);_0x4435de!==null&&this['appendFrame_'](_0x4435de);}}['send'](_0xc6b282){this['resetKeepAlive']();const _0x230454=O(_0xc6b282);this['bytesSent']+=_0x230454['length'],this['stats_']['incrementCounter']('bytes_sent',_0x230454['length']);const _0x13f9bf=io(_0x230454,fh);_0x13f9bf['length']>0x1&&this['sendString_'](String(_0x13f9bf['length']));for(let _0x43c947=0x0;_0x43c947<_0x13f9bf['length'];_0x43c947++)this['sendString_'](_0x13f9bf[_0x43c947]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3caabd){try{this['mySock']['send'](_0x3caabd);}catch(_0x40d533){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x40d533['message']||_0x40d533['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5808f2){this['initTransports_'](_0x5808f2);}['initTransports_'](_0x5b1110){const _0x3d44f6=G&&G['isAvailable']();let _0x3a9035=_0x3d44f6&&!G['previouslyFailed']();if(_0x5b1110['webSocketOnly']&&(_0x3d44f6||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3a9035=!0x0),_0x3a9035)this['transports_']=[G];else{const _0x573796=this['transports_']=[];for(const _0x5cefca of At['ALL_TRANSPORTS'])_0x5cefca&&_0x5cefca['isAvailable']()&&_0x573796['push'](_0x5cefca);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x319802,_0x10dc59,_0x2ea5b5,_0x2ead14,_0x154d1d,_0x171939,_0x34cdde,_0x157fc3,_0x12000c,_0x221521){this['id']=_0x319802,this['repoInfo_']=_0x10dc59,this['applicationId_']=_0x2ea5b5,this['appCheckToken_']=_0x2ead14,this['authToken_']=_0x154d1d,this['onMessage_']=_0x171939,this['onReady_']=_0x34cdde,this['onDisconnect_']=_0x157fc3,this['onKill_']=_0x12000c,this['lastSessionId']=_0x221521,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x10dc59),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x41bf00=this['transportManager_']['initialTransport']();this['conn_']=new _0x41bf00(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x41bf00['responsesRequiredToBeHealthy']||0x0;const _0x5489fe=this['connReceiver_'](this['conn_']),_0x4b1c53=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5489fe,_0x4b1c53);},Math['floor'](0x0));const _0x508525=_0x41bf00['healthyTimeout']||0x0;_0x508525>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x508525)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x387ea8){return _0x1c61df=>{_0x387ea8===this['conn_']?this['onConnectionLost_'](_0x1c61df):_0x387ea8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xcb42a){return _0x326876=>{this['state_']!==0x2&&(_0xcb42a===this['rx_']?this['onPrimaryMessageReceived_'](_0x326876):_0xcb42a===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x326876):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5e1f08){const _0x598e5b={'t':'d','d':_0x5e1f08};this['sendData_'](_0x598e5b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1937cc){if(ii in _0x1937cc){const _0x572483=_0x1937cc[ii];_0x572483===js?this['upgradeIfSecondaryHealthy_']():_0x572483===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x572483===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4412b8){const _0x4f67a4=pt('t',_0x4412b8),_0x455891=pt('d',_0x4412b8);if(_0x4f67a4==='c')this['onSecondaryControl_'](_0x455891);else{if(_0x4f67a4==='d')this['pendingDataMessages']['push'](_0x455891);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4f67a4);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x517f80){const _0x9744e5=pt('t',_0x517f80),_0x141379=pt('d',_0x517f80);_0x9744e5==='c'?this['onControl_'](_0x141379):_0x9744e5==='d'&&this['onDataMessage_'](_0x141379);}['onDataMessage_'](_0x4f15f0){this['onPrimaryResponse_'](),this['onMessage_'](_0x4f15f0);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x55a747){const _0x5c8808=pt(ii,_0x55a747);if(Gs in _0x55a747){const _0x47575d=_0x55a747[Gs];if(_0x5c8808===Ih){const _0x124411={..._0x47575d};this['repoInfo_']['isUsingEmulator']&&(_0x124411['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x124411);}else{if(_0x5c8808===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x54ad56=0x0;_0x54ad56<this['pendingDataMessages']['length'];++_0x54ad56)this['onDataMessage_'](this['pendingDataMessages'][_0x54ad56]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5c8808===vh?this['onConnectionShutdown_'](_0x47575d):_0x5c8808===qs?this['onReset_'](_0x47575d):_0x5c8808===Eh?mi('Server\x20Error:\x20'+_0x47575d):_0x5c8808===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x5c8808);}}}['onHandshake_'](_0x372598){const _0x2dc8dd=_0x372598['ts'],_0x448b51=_0x372598['v'],_0x1f7b97=_0x372598['h'];this['sessionId']=_0x372598['s'],this['repoInfo_']['host']=_0x1f7b97,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2dc8dd),Vi!==_0x448b51&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x3e62fb=this['transportManager_']['upgradeTransport']();_0x3e62fb&&this['startUpgrade_'](_0x3e62fb);}['startUpgrade_'](_0x430495){this['secondaryConn_']=new _0x430495(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x430495['responsesRequiredToBeHealthy']||0x0;const _0x2e2c09=this['connReceiver_'](this['secondaryConn_']),_0x4612fe=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2e2c09,_0x4612fe),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x270b9d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x270b9d),this['repoInfo_']['host']=_0x270b9d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1432bd,_0x4e0a6d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1432bd,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4e0a6d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x23ae20=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x23ae20||this['rx_']===_0x23ae20)&&this['close']();}['onConnectionLost_'](_0x54a00b){this['conn_']=null,!_0x54a00b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x535278){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x535278),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x539aee){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x539aee);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x3961a3,_0x10e904,_0x4980e0,_0x3af646){}['merge'](_0x3efe90,_0x4383c6,_0x53fba8,_0x27fddd){}['refreshAuthToken'](_0x158694){}['refreshAppCheckToken'](_0x3b3d70){}['onDisconnectPut'](_0x2876b4,_0x3c1e49,_0x95d6a9){}['onDisconnectMerge'](_0x325269,_0x2765ca,_0x2427e2){}['onDisconnectCancel'](_0x2b5b1e,_0x4a72c9){}['reportStats'](_0x32cecc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x4c304e){this['allowedEvents_']=_0x4c304e,this['listeners_']={},f(Array['isArray'](_0x4c304e)&&_0x4c304e['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x52721a,..._0x57a40e){if(Array['isArray'](this['listeners_'][_0x52721a])){const _0x4e8e85=[...this['listeners_'][_0x52721a]];for(let _0x82815d=0x0;_0x82815d<_0x4e8e85['length'];_0x82815d++)_0x4e8e85[_0x82815d]['callback']['apply'](_0x4e8e85[_0x82815d]['context'],_0x57a40e);}}['on'](_0x2d2a6c,_0x2a2f14,_0x55d688){this['validateEventType_'](_0x2d2a6c),this['listeners_'][_0x2d2a6c]=this['listeners_'][_0x2d2a6c]||[],this['listeners_'][_0x2d2a6c]['push']({'callback':_0x2a2f14,'context':_0x55d688});const _0x4c3ec4=this['getInitialEvent'](_0x2d2a6c);_0x4c3ec4&&_0x2a2f14['apply'](_0x55d688,_0x4c3ec4);}['off'](_0x58c460,_0x36922d,_0x5a4f14){this['validateEventType_'](_0x58c460);const _0x29e502=this['listeners_'][_0x58c460]||[];for(let _0x272448=0x0;_0x272448<_0x29e502['length'];_0x272448++)if(_0x29e502[_0x272448]['callback']===_0x36922d&&(!_0x5a4f14||_0x5a4f14===_0x29e502[_0x272448]['context'])){_0x29e502['splice'](_0x272448,0x1);return;}}['validateEventType_'](_0x24a0ea){f(this['allowedEvents_']['find'](_0x435430=>_0x435430===_0x24a0ea),'Unknown\x20event:\x20'+_0x24a0ea);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x34ef84){return f(_0x34ef84==='online','Unknown\x20event\x20type:\x20'+_0x34ef84),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x25bdd8,_0x485e5c){if(_0x485e5c===void 0x0){this['pieces_']=_0x25bdd8['split']('/');let _0x46fdf6=0x0;for(let _0x577b5b=0x0;_0x577b5b<this['pieces_']['length'];_0x577b5b++)this['pieces_'][_0x577b5b]['length']>0x0&&(this['pieces_'][_0x46fdf6]=this['pieces_'][_0x577b5b],_0x46fdf6++);this['pieces_']['length']=_0x46fdf6,this['pieceNum_']=0x0;}else this['pieces_']=_0x25bdd8,this['pieceNum_']=_0x485e5c;}['toString'](){let _0x124471='';for(let _0x162f04=this['pieceNum_'];_0x162f04<this['pieces_']['length'];_0x162f04++)this['pieces_'][_0x162f04]!==''&&(_0x124471+='/'+this['pieces_'][_0x162f04]);return _0x124471||'/';}}function w(){return new C('');}function y(_0x3bad72){return _0x3bad72['pieceNum_']>=_0x3bad72['pieces_']['length']?null:_0x3bad72['pieces_'][_0x3bad72['pieceNum_']];}function we(_0x555eb5){return _0x555eb5['pieces_']['length']-_0x555eb5['pieceNum_'];}function b(_0x2b8c0e){let _0xb82bd1=_0x2b8c0e['pieceNum_'];return _0xb82bd1<_0x2b8c0e['pieces_']['length']&&_0xb82bd1++,new C(_0x2b8c0e['pieces_'],_0xb82bd1);}function Gi(_0x13cdb4){return _0x13cdb4['pieceNum_']<_0x13cdb4['pieces_']['length']?_0x13cdb4['pieces_'][_0x13cdb4['pieces_']['length']-0x1]:null;}function Ch(_0xadcf75){let _0x27e5c1='';for(let _0x4150e2=_0xadcf75['pieceNum_'];_0x4150e2<_0xadcf75['pieces_']['length'];_0x4150e2++)_0xadcf75['pieces_'][_0x4150e2]!==''&&(_0x27e5c1+='/'+encodeURIComponent(String(_0xadcf75['pieces_'][_0x4150e2])));return _0x27e5c1||'/';}function kt(_0x57a7c7,_0x531c0d=0x0){return _0x57a7c7['pieces_']['slice'](_0x57a7c7['pieceNum_']+_0x531c0d);}function To(_0x51b546){if(_0x51b546['pieceNum_']>=_0x51b546['pieces_']['length'])return null;const _0x3a5408=[];for(let _0x55700a=_0x51b546['pieceNum_'];_0x55700a<_0x51b546['pieces_']['length']-0x1;_0x55700a++)_0x3a5408['push'](_0x51b546['pieces_'][_0x55700a]);return new C(_0x3a5408,0x0);}function A(_0x4e9ff7,_0x24f184){const _0x2bdb21=[];for(let _0x292a0c=_0x4e9ff7['pieceNum_'];_0x292a0c<_0x4e9ff7['pieces_']['length'];_0x292a0c++)_0x2bdb21['push'](_0x4e9ff7['pieces_'][_0x292a0c]);if(_0x24f184 instanceof C){for(let _0x3be5ab=_0x24f184['pieceNum_'];_0x3be5ab<_0x24f184['pieces_']['length'];_0x3be5ab++)_0x2bdb21['push'](_0x24f184['pieces_'][_0x3be5ab]);}else{const _0x46cd4b=_0x24f184['split']('/');for(let _0x48481b=0x0;_0x48481b<_0x46cd4b['length'];_0x48481b++)_0x46cd4b[_0x48481b]['length']>0x0&&_0x2bdb21['push'](_0x46cd4b[_0x48481b]);}return new C(_0x2bdb21,0x0);}function v(_0x33f94f){return _0x33f94f['pieceNum_']>=_0x33f94f['pieces_']['length'];}function F(_0x365d10,_0xd2a707){const _0x54d8ef=y(_0x365d10),_0xa40863=y(_0xd2a707);if(_0x54d8ef===null)return _0xd2a707;if(_0x54d8ef===_0xa40863)return F(b(_0x365d10),b(_0xd2a707));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xd2a707+')\x20is\x20not\x20within\x20outerPath\x20('+_0x365d10+')');}function Th(_0x1f3cf8,_0x91d3a){const _0x5cf8fc=kt(_0x1f3cf8,0x0),_0x43088c=kt(_0x91d3a,0x0);for(let _0x431d87=0x0;_0x431d87<_0x5cf8fc['length']&&_0x431d87<_0x43088c['length'];_0x431d87++){const _0x1e7f27=He(_0x5cf8fc[_0x431d87],_0x43088c[_0x431d87]);if(_0x1e7f27!==0x0)return _0x1e7f27;}return _0x5cf8fc['length']===_0x43088c['length']?0x0:_0x5cf8fc['length']<_0x43088c['length']?-0x1:0x1;}function qi(_0x4b011c,_0x42cf2d){if(we(_0x4b011c)!==we(_0x42cf2d))return!0x1;for(let _0x3603d6=_0x4b011c['pieceNum_'],_0x1e2b95=_0x42cf2d['pieceNum_'];_0x3603d6<=_0x4b011c['pieces_']['length'];_0x3603d6++,_0x1e2b95++)if(_0x4b011c['pieces_'][_0x3603d6]!==_0x42cf2d['pieces_'][_0x1e2b95])return!0x1;return!0x0;}function $(_0x4d1f7a,_0x45eaee){let _0x15fb17=_0x4d1f7a['pieceNum_'],_0x46f230=_0x45eaee['pieceNum_'];if(we(_0x4d1f7a)>we(_0x45eaee))return!0x1;for(;_0x15fb17<_0x4d1f7a['pieces_']['length'];){if(_0x4d1f7a['pieces_'][_0x15fb17]!==_0x45eaee['pieces_'][_0x46f230])return!0x1;++_0x15fb17,++_0x46f230;}return!0x0;}class Sh{constructor(_0x27cc26,_0x393077){this['errorPrefix_']=_0x393077,this['parts_']=kt(_0x27cc26,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x27ae33=0x0;_0x27ae33<this['parts_']['length'];_0x27ae33++)this['byteLength_']+=Pn(this['parts_'][_0x27ae33]);So(this);}}function bh(_0x11b672,_0x135ec9){_0x11b672['parts_']['length']>0x0&&(_0x11b672['byteLength_']+=0x1),_0x11b672['parts_']['push'](_0x135ec9),_0x11b672['byteLength_']+=Pn(_0x135ec9),So(_0x11b672);}function Rh(_0x192a5a){const _0xed184e=_0x192a5a['parts_']['pop']();_0x192a5a['byteLength_']-=Pn(_0xed184e),_0x192a5a['parts_']['length']>0x0&&(_0x192a5a['byteLength_']-=0x1);}function So(_0x5f59c2){if(_0x5f59c2['byteLength_']>Js)throw new Error(_0x5f59c2['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x5f59c2['byteLength_']+').');if(_0x5f59c2['parts_']['length']>Qs)throw new Error(_0x5f59c2['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x5f59c2));}function Ne(_0x10072b){return _0x10072b['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x10072b['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x23c821,_0x2c0ac1;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2c0ac1='visibilitychange',_0x23c821='hidden'):typeof document['mozHidden']<'u'?(_0x2c0ac1='mozvisibilitychange',_0x23c821='mozHidden'):typeof document['msHidden']<'u'?(_0x2c0ac1='msvisibilitychange',_0x23c821='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2c0ac1='webkitvisibilitychange',_0x23c821='webkitHidden')),this['visible_']=!0x0,_0x2c0ac1&&document['addEventListener'](_0x2c0ac1,()=>{const _0x172dbc=!document[_0x23c821];_0x172dbc!==this['visible_']&&(this['visible_']=_0x172dbc,this['trigger']('visible',_0x172dbc));},!0x1);}['getInitialEvent'](_0x566c1f){return f(_0x566c1f==='visible','Unknown\x20event\x20type:\x20'+_0x566c1f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x47569e,_0x27e0e1,_0x51f3b5,_0x14b5b9,_0x3f5dfd,_0x21563c,_0x2a7f04,_0x5097f4){if(super(),this['repoInfo_']=_0x47569e,this['applicationId_']=_0x27e0e1,this['onDataUpdate_']=_0x51f3b5,this['onConnectStatus_']=_0x14b5b9,this['onServerInfoUpdate_']=_0x3f5dfd,this['authTokenProvider_']=_0x21563c,this['appCheckTokenProvider_']=_0x2a7f04,this['authOverride_']=_0x5097f4,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5097f4)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x47569e['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x554f88,_0x167a7e,_0x416f6c){const _0x2cd4b5=++this['requestNumber_'],_0x34fe04={'r':_0x2cd4b5,'a':_0x554f88,'b':_0x167a7e};this['log_'](O(_0x34fe04)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x34fe04),_0x416f6c&&(this['requestCBHash_'][_0x2cd4b5]=_0x416f6c);}['get'](_0x30aed4){this['initConnection_']();const _0x41f9b8=new Ve(),_0x2e3045={'action':'g','request':{'p':_0x30aed4['_path']['toString'](),'q':_0x30aed4['_queryObject']},'onComplete':_0x4fd784=>{const _0x204e90=_0x4fd784['d'];_0x4fd784['s']==='ok'?_0x41f9b8['resolve'](_0x204e90):_0x41f9b8['reject'](_0x204e90);}};this['outstandingGets_']['push'](_0x2e3045),this['outstandingGetCount_']++;const _0x386d07=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x386d07),_0x41f9b8['promise'];}['listen'](_0x5bd2e1,_0x40862f,_0x589095,_0x37643d){this['initConnection_']();const _0x6e6f8a=_0x5bd2e1['_queryIdentifier'],_0x4b01d7=_0x5bd2e1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4b01d7+'\x20'+_0x6e6f8a),this['listens']['has'](_0x4b01d7)||this['listens']['set'](_0x4b01d7,new Map()),f(_0x5bd2e1['_queryParams']['isDefault']()||!_0x5bd2e1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4b01d7)['has'](_0x6e6f8a),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x52afc9={'onComplete':_0x37643d,'hashFn':_0x40862f,'query':_0x5bd2e1,'tag':_0x589095};this['listens']['get'](_0x4b01d7)['set'](_0x6e6f8a,_0x52afc9),this['connected_']&&this['sendListen_'](_0x52afc9);}['sendGet_'](_0x471b46){const _0x455b84=this['outstandingGets_'][_0x471b46];this['sendRequest']('g',_0x455b84['request'],_0x1704ef=>{delete this['outstandingGets_'][_0x471b46],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x455b84['onComplete']&&_0x455b84['onComplete'](_0x1704ef);});}['sendListen_'](_0x6ecb45){const _0x54fd34=_0x6ecb45['query'],_0x3adf15=_0x54fd34['_path']['toString'](),_0x4ad00a=_0x54fd34['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x3adf15+'\x20for\x20'+_0x4ad00a);const _0x127883={'p':_0x3adf15},_0x5790a1='q';_0x6ecb45['tag']&&(_0x127883['q']=_0x54fd34['_queryObject'],_0x127883['t']=_0x6ecb45['tag']),_0x127883['h']=_0x6ecb45['hashFn'](),this['sendRequest'](_0x5790a1,_0x127883,_0x2beb7f=>{const _0x44a6f8=_0x2beb7f['d'],_0x276fd3=_0x2beb7f['s'];ie['warnOnListenWarnings_'](_0x44a6f8,_0x54fd34),(this['listens']['get'](_0x3adf15)&&this['listens']['get'](_0x3adf15)['get'](_0x4ad00a))===_0x6ecb45&&(this['log_']('listen\x20response',_0x2beb7f),_0x276fd3!=='ok'&&this['removeListen_'](_0x3adf15,_0x4ad00a),_0x6ecb45['onComplete']&&_0x6ecb45['onComplete'](_0x276fd3,_0x44a6f8));});}static['warnOnListenWarnings_'](_0x140ff0,_0x355e2a){if(_0x140ff0&&typeof _0x140ff0=='object'&&Y(_0x140ff0,'w')){const _0x33679a=Oe(_0x140ff0,'w');if(Array['isArray'](_0x33679a)&&~_0x33679a['indexOf']('no_index')){const _0x4241b2='\x22.indexOn\x22:\x20\x22'+_0x355e2a['_queryParams']['getIndex']()['toString']()+'\x22',_0x52abd1=_0x355e2a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4241b2+'\x20at\x20'+_0x52abd1+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x114775){this['authToken_']=_0x114775,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x114775);}['reduceReconnectDelayIfAdminCredential_'](_0x3693d3){(_0x3693d3&&_0x3693d3['length']===0x28||vc(_0x3693d3))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x7b9d58){this['appCheckToken_']=_0x7b9d58,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xf33a4a=this['authToken_'],_0x4ea635=yc(_0xf33a4a)?'auth':'gauth',_0x4816fd={'cred':_0xf33a4a};this['authOverride_']===null?_0x4816fd['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4816fd['authvar']=this['authOverride_']),this['sendRequest'](_0x4ea635,_0x4816fd,_0x32c747=>{const _0x58c0af=_0x32c747['s'],_0x58cd2e=_0x32c747['d']||'error';this['authToken_']===_0xf33a4a&&(_0x58c0af==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x58c0af,_0x58cd2e));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x168830=>{const _0x519c55=_0x168830['s'],_0x3fb27d=_0x168830['d']||'error';_0x519c55==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x519c55,_0x3fb27d);});}['unlisten'](_0x44a8c9,_0x28dac3){const _0x5d8b48=_0x44a8c9['_path']['toString'](),_0x49f43f=_0x44a8c9['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5d8b48+'\x20'+_0x49f43f),f(_0x44a8c9['_queryParams']['isDefault']()||!_0x44a8c9['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5d8b48,_0x49f43f)&&this['connected_']&&this['sendUnlisten_'](_0x5d8b48,_0x49f43f,_0x44a8c9['_queryObject'],_0x28dac3);}['sendUnlisten_'](_0x672b5d,_0x495e9d,_0x102492,_0x4b6022){this['log_']('Unlisten\x20on\x20'+_0x672b5d+'\x20for\x20'+_0x495e9d);const _0x2b9252={'p':_0x672b5d},_0xe73acb='n';_0x4b6022&&(_0x2b9252['q']=_0x102492,_0x2b9252['t']=_0x4b6022),this['sendRequest'](_0xe73acb,_0x2b9252);}['onDisconnectPut'](_0x135d44,_0x3a2c01,_0x492dc3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x135d44,_0x3a2c01,_0x492dc3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x135d44,'action':'o','data':_0x3a2c01,'onComplete':_0x492dc3});}['onDisconnectMerge'](_0x508eeb,_0x465a0f,_0xd1b139){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x508eeb,_0x465a0f,_0xd1b139):this['onDisconnectRequestQueue_']['push']({'pathString':_0x508eeb,'action':'om','data':_0x465a0f,'onComplete':_0xd1b139});}['onDisconnectCancel'](_0x3a8a32,_0x24a51a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3a8a32,null,_0x24a51a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3a8a32,'action':'oc','data':null,'onComplete':_0x24a51a});}['sendOnDisconnect_'](_0xc4705a,_0x210051,_0x40c73e,_0x37413a){const _0xf4b5a2={'p':_0x210051,'d':_0x40c73e};this['log_']('onDisconnect\x20'+_0xc4705a,_0xf4b5a2),this['sendRequest'](_0xc4705a,_0xf4b5a2,_0x159454=>{_0x37413a&&setTimeout(()=>{_0x37413a(_0x159454['s'],_0x159454['d']);},Math['floor'](0x0));});}['put'](_0x5bc90e,_0x198846,_0x49ddd7,_0x42bf20){this['putInternal']('p',_0x5bc90e,_0x198846,_0x49ddd7,_0x42bf20);}['merge'](_0x355965,_0xad7971,_0x4c3a57,_0x2d573a){this['putInternal']('m',_0x355965,_0xad7971,_0x4c3a57,_0x2d573a);}['putInternal'](_0x3e1f2b,_0x21a042,_0x131cf5,_0x30d4b2,_0x4afa26){this['initConnection_']();const _0x1be4f0={'p':_0x21a042,'d':_0x131cf5};_0x4afa26!==void 0x0&&(_0x1be4f0['h']=_0x4afa26),this['outstandingPuts_']['push']({'action':_0x3e1f2b,'request':_0x1be4f0,'onComplete':_0x30d4b2}),this['outstandingPutCount_']++;const _0x45d3f7=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x45d3f7):this['log_']('Buffering\x20put:\x20'+_0x21a042);}['sendPut_'](_0x42abb5){const _0x597c10=this['outstandingPuts_'][_0x42abb5]['action'],_0x4a7456=this['outstandingPuts_'][_0x42abb5]['request'],_0x479aef=this['outstandingPuts_'][_0x42abb5]['onComplete'];this['outstandingPuts_'][_0x42abb5]['queued']=this['connected_'],this['sendRequest'](_0x597c10,_0x4a7456,_0x37af53=>{this['log_'](_0x597c10+'\x20response',_0x37af53),delete this['outstandingPuts_'][_0x42abb5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x479aef&&_0x479aef(_0x37af53['s'],_0x37af53['d']);});}['reportStats'](_0x1d3c23){if(this['connected_']){const _0x1d961a={'c':_0x1d3c23};this['log_']('reportStats',_0x1d961a),this['sendRequest']('s',_0x1d961a,_0x3349ed=>{if(_0x3349ed['s']!=='ok'){const _0xf1dc0f=_0x3349ed['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xf1dc0f);}});}}['onDataMessage_'](_0x12eea0){if('r'in _0x12eea0){this['log_']('from\x20server:\x20'+O(_0x12eea0));const _0x22e684=_0x12eea0['r'],_0x524f96=this['requestCBHash_'][_0x22e684];_0x524f96&&(delete this['requestCBHash_'][_0x22e684],_0x524f96(_0x12eea0['b']));}else{if('error'in _0x12eea0)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x12eea0['error'];'a'in _0x12eea0&&this['onDataPush_'](_0x12eea0['a'],_0x12eea0['b']);}}['onDataPush_'](_0x4f9943,_0x692e6b){this['log_']('handleServerMessage',_0x4f9943,_0x692e6b),_0x4f9943==='d'?this['onDataUpdate_'](_0x692e6b['p'],_0x692e6b['d'],!0x1,_0x692e6b['t']):_0x4f9943==='m'?this['onDataUpdate_'](_0x692e6b['p'],_0x692e6b['d'],!0x0,_0x692e6b['t']):_0x4f9943==='c'?this['onListenRevoked_'](_0x692e6b['p'],_0x692e6b['q']):_0x4f9943==='ac'?this['onAuthRevoked_'](_0x692e6b['s'],_0x692e6b['d']):_0x4f9943==='apc'?this['onAppCheckRevoked_'](_0x692e6b['s'],_0x692e6b['d']):_0x4f9943==='sd'?this['onSecurityDebugPacket_'](_0x692e6b):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4f9943)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2ddf04,_0xcc73e1){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2ddf04),this['lastSessionId']=_0xcc73e1,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3cb6bb){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3cb6bb));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4445e6){_0x4445e6&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4445e6;}['onOnline_'](_0x4e5170){_0x4e5170?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x24ee92=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x354533=Math['max'](0x0,this['reconnectDelay_']-_0x24ee92);_0x354533=Math['random']()*_0x354533,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x354533+'ms'),this['scheduleConnect_'](_0x354533),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x8c481=this['onDataMessage_']['bind'](this),_0x2bfa41=this['onReady_']['bind'](this),_0x3d83b0=this['onRealtimeDisconnect_']['bind'](this),_0x4356c6=this['id']+':'+ie['nextConnectionId_']++,_0x57b79f=this['lastSessionId'];let _0x3ecc40=!0x1,_0x75ac10=null;const _0x6c11b1=function(){_0x75ac10?_0x75ac10['close']():(_0x3ecc40=!0x0,_0x3d83b0());},_0x1fed12=function(_0x4a2b37){f(_0x75ac10,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x75ac10['sendRequest'](_0x4a2b37);};this['realtime_']={'close':_0x6c11b1,'sendRequest':_0x1fed12};const _0x4d7768=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x338091,_0x4f9c85]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4d7768),this['appCheckTokenProvider_']['getToken'](_0x4d7768)]);_0x3ecc40?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x338091&&_0x338091['accessToken'],this['appCheckToken_']=_0x4f9c85&&_0x4f9c85['token'],_0x75ac10=new wh(_0x4356c6,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x8c481,_0x2bfa41,_0x3d83b0,_0x513962=>{U(_0x513962+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x57b79f));}catch(_0x2d1e41){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2d1e41),_0x3ecc40||(this['repoInfo_']['nodeAdmin']&&U(_0x2d1e41),_0x6c11b1());}}}['interrupt'](_0xa95af9){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xa95af9),this['interruptReasons_'][_0xa95af9]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4fee6a){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4fee6a),delete this['interruptReasons_'][_0x4fee6a],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x23f556){const _0x459d8d=_0x23f556-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x459d8d});}['cancelSentTransactions_'](){for(let _0x1692eb=0x0;_0x1692eb<this['outstandingPuts_']['length'];_0x1692eb++){const _0x12423a=this['outstandingPuts_'][_0x1692eb];_0x12423a&&'h'in _0x12423a['request']&&_0x12423a['queued']&&(_0x12423a['onComplete']&&_0x12423a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1692eb],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xaf5342,_0x3f01d6){let _0x482f7a;_0x3f01d6?_0x482f7a=_0x3f01d6['map'](_0x5d7791=>Bi(_0x5d7791))['join']('$'):_0x482f7a='default';const _0x39a379=this['removeListen_'](_0xaf5342,_0x482f7a);_0x39a379&&_0x39a379['onComplete']&&_0x39a379['onComplete']('permission_denied');}['removeListen_'](_0x22566c,_0x3e89dd){const _0x505f79=new C(_0x22566c)['toString']();let _0x2de9ae;if(this['listens']['has'](_0x505f79)){const _0x3c28d2=this['listens']['get'](_0x505f79);_0x2de9ae=_0x3c28d2['get'](_0x3e89dd),_0x3c28d2['delete'](_0x3e89dd),_0x3c28d2['size']===0x0&&this['listens']['delete'](_0x505f79);}else _0x2de9ae=void 0x0;return _0x2de9ae;}['onAuthRevoked_'](_0x23409d,_0x2296c8){L('Auth\x20token\x20revoked:\x20'+_0x23409d+'/'+_0x2296c8),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x23409d==='invalid_token'||_0x23409d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xbf1950,_0x3b9689){L('App\x20check\x20token\x20revoked:\x20'+_0xbf1950+'/'+_0x3b9689),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xbf1950==='invalid_token'||_0xbf1950==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2e2dcf){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2e2dcf):'msg'in _0x2e2dcf&&console['log']('FIREBASE:\x20'+_0x2e2dcf['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x49a0fb of this['listens']['values']())for(const _0x5f51c4 of _0x49a0fb['values']())this['sendListen_'](_0x5f51c4);for(let _0x576e9f=0x0;_0x576e9f<this['outstandingPuts_']['length'];_0x576e9f++)this['outstandingPuts_'][_0x576e9f]&&this['sendPut_'](_0x576e9f);for(;this['onDisconnectRequestQueue_']['length'];){const _0x394463=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x394463['action'],_0x394463['pathString'],_0x394463['data'],_0x394463['onComplete']);}for(let _0x574925=0x0;_0x574925<this['outstandingGets_']['length'];_0x574925++)this['outstandingGets_'][_0x574925]&&this['sendGet_'](_0x574925);}['sendConnectStats_'](){const _0x51d1a0={};let _0xa0529c='js';_0x51d1a0['sdk.'+_0xa0529c+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x51d1a0['framework.cordova']=0x1:qr()&&(_0x51d1a0['framework.reactnative']=0x1),this['reportStats'](_0x51d1a0);}['shouldReconnect_'](){const _0x59c94b=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x59c94b;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x35f06e,_0x28e1fa){this['name']=_0x35f06e,this['node']=_0x28e1fa;}static['Wrap'](_0x2ecb38,_0xe867b4){return new E(_0x2ecb38,_0xe867b4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1f1df7,_0x512587){const _0x95c827=new E(xe,_0x1f1df7),_0x468e14=new E(xe,_0x512587);return this['compare'](_0x95c827,_0x468e14)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x4392b2){Xt=_0x4392b2;}['compare'](_0x41805c,_0x2bacbe){return He(_0x41805c['name'],_0x2bacbe['name']);}['isDefinedOn'](_0x6d4755){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x325028,_0x564400){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x595bbb,_0x2a3947){return f(typeof _0x595bbb=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x595bbb,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4790a6,_0x5ba8ef,_0x4feeed,_0x1f0c56,_0x53a038=null){this['isReverse_']=_0x1f0c56,this['resultGenerator_']=_0x53a038,this['nodeStack_']=[];let _0x490249=0x1;for(;!_0x4790a6['isEmpty']();)if(_0x4790a6=_0x4790a6,_0x490249=_0x5ba8ef?_0x4feeed(_0x4790a6['key'],_0x5ba8ef):0x1,_0x1f0c56&&(_0x490249*=-0x1),_0x490249<0x0)this['isReverse_']?_0x4790a6=_0x4790a6['left']:_0x4790a6=_0x4790a6['right'];else{if(_0x490249===0x0){this['nodeStack_']['push'](_0x4790a6);break;}else this['nodeStack_']['push'](_0x4790a6),this['isReverse_']?_0x4790a6=_0x4790a6['right']:_0x4790a6=_0x4790a6['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5ee075=this['nodeStack_']['pop'](),_0x107a23;if(this['resultGenerator_']?_0x107a23=this['resultGenerator_'](_0x5ee075['key'],_0x5ee075['value']):_0x107a23={'key':_0x5ee075['key'],'value':_0x5ee075['value']},this['isReverse_']){for(_0x5ee075=_0x5ee075['left'];!_0x5ee075['isEmpty']();)this['nodeStack_']['push'](_0x5ee075),_0x5ee075=_0x5ee075['right'];}else{for(_0x5ee075=_0x5ee075['right'];!_0x5ee075['isEmpty']();)this['nodeStack_']['push'](_0x5ee075),_0x5ee075=_0x5ee075['left'];}return _0x107a23;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x47eaed=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x47eaed['key'],_0x47eaed['value']):{'key':_0x47eaed['key'],'value':_0x47eaed['value']};}}class M{constructor(_0x2a79cc,_0x58235b,_0x5e71ec,_0x14a09b,_0x24154f){this['key']=_0x2a79cc,this['value']=_0x58235b,this['color']=_0x5e71ec??M['RED'],this['left']=_0x14a09b??B['EMPTY_NODE'],this['right']=_0x24154f??B['EMPTY_NODE'];}['copy'](_0x191e62,_0x287aaa,_0x7198ac,_0x15c1e0,_0x53672d){return new M(_0x191e62??this['key'],_0x287aaa??this['value'],_0x7198ac??this['color'],_0x15c1e0??this['left'],_0x53672d??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x493181){return this['left']['inorderTraversal'](_0x493181)||!!_0x493181(this['key'],this['value'])||this['right']['inorderTraversal'](_0x493181);}['reverseTraversal'](_0x452f96){return this['right']['reverseTraversal'](_0x452f96)||_0x452f96(this['key'],this['value'])||this['left']['reverseTraversal'](_0x452f96);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x288791,_0x1cf30e,_0x134cec){let _0x2b188e=this;const _0x7dfaa6=_0x134cec(_0x288791,_0x2b188e['key']);return _0x7dfaa6<0x0?_0x2b188e=_0x2b188e['copy'](null,null,null,_0x2b188e['left']['insert'](_0x288791,_0x1cf30e,_0x134cec),null):_0x7dfaa6===0x0?_0x2b188e=_0x2b188e['copy'](null,_0x1cf30e,null,null,null):_0x2b188e=_0x2b188e['copy'](null,null,null,null,_0x2b188e['right']['insert'](_0x288791,_0x1cf30e,_0x134cec)),_0x2b188e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1c51fb=this;return!_0x1c51fb['left']['isRed_']()&&!_0x1c51fb['left']['left']['isRed_']()&&(_0x1c51fb=_0x1c51fb['moveRedLeft_']()),_0x1c51fb=_0x1c51fb['copy'](null,null,null,_0x1c51fb['left']['removeMin_'](),null),_0x1c51fb['fixUp_']();}['remove'](_0x297600,_0x48f0da){let _0x3bad54,_0x8d0505;if(_0x3bad54=this,_0x48f0da(_0x297600,_0x3bad54['key'])<0x0)!_0x3bad54['left']['isEmpty']()&&!_0x3bad54['left']['isRed_']()&&!_0x3bad54['left']['left']['isRed_']()&&(_0x3bad54=_0x3bad54['moveRedLeft_']()),_0x3bad54=_0x3bad54['copy'](null,null,null,_0x3bad54['left']['remove'](_0x297600,_0x48f0da),null);else{if(_0x3bad54['left']['isRed_']()&&(_0x3bad54=_0x3bad54['rotateRight_']()),!_0x3bad54['right']['isEmpty']()&&!_0x3bad54['right']['isRed_']()&&!_0x3bad54['right']['left']['isRed_']()&&(_0x3bad54=_0x3bad54['moveRedRight_']()),_0x48f0da(_0x297600,_0x3bad54['key'])===0x0){if(_0x3bad54['right']['isEmpty']())return B['EMPTY_NODE'];_0x8d0505=_0x3bad54['right']['min_'](),_0x3bad54=_0x3bad54['copy'](_0x8d0505['key'],_0x8d0505['value'],null,null,_0x3bad54['right']['removeMin_']());}_0x3bad54=_0x3bad54['copy'](null,null,null,null,_0x3bad54['right']['remove'](_0x297600,_0x48f0da));}return _0x3bad54['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x528c49=this;return _0x528c49['right']['isRed_']()&&!_0x528c49['left']['isRed_']()&&(_0x528c49=_0x528c49['rotateLeft_']()),_0x528c49['left']['isRed_']()&&_0x528c49['left']['left']['isRed_']()&&(_0x528c49=_0x528c49['rotateRight_']()),_0x528c49['left']['isRed_']()&&_0x528c49['right']['isRed_']()&&(_0x528c49=_0x528c49['colorFlip_']()),_0x528c49;}['moveRedLeft_'](){let _0x5b9195=this['colorFlip_']();return _0x5b9195['right']['left']['isRed_']()&&(_0x5b9195=_0x5b9195['copy'](null,null,null,null,_0x5b9195['right']['rotateRight_']()),_0x5b9195=_0x5b9195['rotateLeft_'](),_0x5b9195=_0x5b9195['colorFlip_']()),_0x5b9195;}['moveRedRight_'](){let _0x2d85aa=this['colorFlip_']();return _0x2d85aa['left']['left']['isRed_']()&&(_0x2d85aa=_0x2d85aa['rotateRight_'](),_0x2d85aa=_0x2d85aa['colorFlip_']()),_0x2d85aa;}['rotateLeft_'](){const _0x42fbf3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x42fbf3,null);}['rotateRight_'](){const _0x1e4a65=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1e4a65);}['colorFlip_'](){const _0x548cad=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3af574=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x548cad,_0x3af574);}['checkMaxDepth_'](){const _0x1283be=this['check_']();return Math['pow'](0x2,_0x1283be)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x130951=this['left']['check_']();if(_0x130951!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x130951+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x44f00a,_0x5c7171,_0x101017,_0x84e78f,_0x435376){return this;}['insert'](_0xcefb7,_0x1b89ec,_0x4be05b){return new M(_0xcefb7,_0x1b89ec,null);}['remove'](_0x3c37c6,_0x3077ff){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5b7a62){return!0x1;}['reverseTraversal'](_0x53311f){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2a7687,_0x1fa9e3=B['EMPTY_NODE']){this['comparator_']=_0x2a7687,this['root_']=_0x1fa9e3;}['insert'](_0x4c041a,_0x5d64b3){return new B(this['comparator_'],this['root_']['insert'](_0x4c041a,_0x5d64b3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x30b5e3){return new B(this['comparator_'],this['root_']['remove'](_0x30b5e3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x151c73){let _0x4965f9,_0x544d84=this['root_'];for(;!_0x544d84['isEmpty']();){if(_0x4965f9=this['comparator_'](_0x151c73,_0x544d84['key']),_0x4965f9===0x0)return _0x544d84['value'];_0x4965f9<0x0?_0x544d84=_0x544d84['left']:_0x4965f9>0x0&&(_0x544d84=_0x544d84['right']);}return null;}['getPredecessorKey'](_0x4808f4){let _0x2d37d6,_0x218ad6=this['root_'],_0x33f7b6=null;for(;!_0x218ad6['isEmpty']();)if(_0x2d37d6=this['comparator_'](_0x4808f4,_0x218ad6['key']),_0x2d37d6===0x0){if(_0x218ad6['left']['isEmpty']())return _0x33f7b6?_0x33f7b6['key']:null;for(_0x218ad6=_0x218ad6['left'];!_0x218ad6['right']['isEmpty']();)_0x218ad6=_0x218ad6['right'];return _0x218ad6['key'];}else _0x2d37d6<0x0?_0x218ad6=_0x218ad6['left']:_0x2d37d6>0x0&&(_0x33f7b6=_0x218ad6,_0x218ad6=_0x218ad6['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1a2ba7){return this['root_']['inorderTraversal'](_0x1a2ba7);}['reverseTraversal'](_0x4f94fe){return this['root_']['reverseTraversal'](_0x4f94fe);}['getIterator'](_0x14d23b){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x14d23b);}['getIteratorFrom'](_0x21cb4d,_0x419f18){return new Zt(this['root_'],_0x21cb4d,this['comparator_'],!0x1,_0x419f18);}['getReverseIteratorFrom'](_0x364203,_0x1ff461){return new Zt(this['root_'],_0x364203,this['comparator_'],!0x0,_0x1ff461);}['getReverseIterator'](_0x4731a2){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x4731a2);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x1ffa2a,_0x5aef56){return He(_0x1ffa2a['name'],_0x5aef56['name']);}function ji(_0x2f4b2a,_0x27425d){return He(_0x2f4b2a,_0x27425d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x19d3aa){vi=_0x19d3aa;}const Ro=function(_0x2550cf){return typeof _0x2550cf=='number'?'number:'+so(_0x2550cf):'string:'+_0x2550cf;},Ao=function(_0x4d7931){if(_0x4d7931['isLeafNode']()){const _0x507a52=_0x4d7931['val']();f(typeof _0x507a52=='string'||typeof _0x507a52=='number'||typeof _0x507a52=='object'&&Y(_0x507a52,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4d7931===vi||_0x4d7931['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4d7931===vi||_0x4d7931['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3e73c5){er=_0x3e73c5;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x3b2e62,_0x52af7d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3b2e62,this['priorityNode_']=_0x52af7d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1e7e83){return new D(this['value_'],_0x1e7e83);}['getImmediateChild'](_0xd2d66b){return _0xd2d66b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5509d2){return v(_0x5509d2)?this:y(_0x5509d2)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x905afa,_0x1b4a09){return null;}['updateImmediateChild'](_0x32ad11,_0x3d7700){return _0x32ad11==='.priority'?this['updatePriority'](_0x3d7700):_0x3d7700['isEmpty']()&&_0x32ad11!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x32ad11,_0x3d7700)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x165975,_0xb605fb){const _0x2306c9=y(_0x165975);return _0x2306c9===null?_0xb605fb:_0xb605fb['isEmpty']()&&_0x2306c9!=='.priority'?this:(f(_0x2306c9!=='.priority'||we(_0x165975)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2306c9,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x165975),_0xb605fb)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x58e82b,_0x23fc64){return!0x1;}['val'](_0x213f44){return _0x213f44&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x155f4c='';this['priorityNode_']['isEmpty']()||(_0x155f4c+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x327f9f=typeof this['value_'];_0x155f4c+=_0x327f9f+':',_0x327f9f==='number'?_0x155f4c+=so(this['value_']):_0x155f4c+=this['value_'],this['lazyHash_']=no(_0x155f4c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3fe263){return _0x3fe263===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3fe263 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3fe263['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3fe263));}['compareToLeafNode_'](_0x20811e){const _0x1c505a=typeof _0x20811e['value_'],_0x5dbaae=typeof this['value_'],_0x1188ac=D['VALUE_TYPE_ORDER']['indexOf'](_0x1c505a),_0x3382e1=D['VALUE_TYPE_ORDER']['indexOf'](_0x5dbaae);return f(_0x1188ac>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1c505a),f(_0x3382e1>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5dbaae),_0x1188ac===_0x3382e1?_0x5dbaae==='object'?0x0:this['value_']<_0x20811e['value_']?-0x1:this['value_']===_0x20811e['value_']?0x0:0x1:_0x3382e1-_0x1188ac;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2c7893){if(_0x2c7893===this)return!0x0;if(_0x2c7893['isLeafNode']()){const _0x5188ae=_0x2c7893;return this['value_']===_0x5188ae['value_']&&this['priorityNode_']['equals'](_0x5188ae['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3432b2){ko=_0x3432b2;}function xh(_0x93a8aa){No=_0x93a8aa;}class Fh extends On{['compare'](_0x214598,_0x3360bc){const _0x2d0f86=_0x214598['node']['getPriority'](),_0x17b1af=_0x3360bc['node']['getPriority'](),_0x240145=_0x2d0f86['compareTo'](_0x17b1af);return _0x240145===0x0?He(_0x214598['name'],_0x3360bc['name']):_0x240145;}['isDefinedOn'](_0x3508e4){return!_0x3508e4['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x33494a,_0x30df61){return!_0x33494a['getPriority']()['equals'](_0x30df61['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x3196ad,_0x25de80){const _0x28471a=ko(_0x3196ad);return new E(_0x25de80,new D('[PRIORITY-POST]',_0x28471a));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x3174b8){const _0x214021=_0x15a218=>parseInt(Math['log'](_0x15a218)/Uh,0xa),_0x37d4e2=_0x28ca33=>parseInt(Array(_0x28ca33+0x1)['join']('1'),0x2);this['count']=_0x214021(_0x3174b8+0x1),this['current_']=this['count']-0x1;const _0x4789c1=_0x37d4e2(this['count']);this['bits_']=_0x3174b8+0x1&_0x4789c1;}['nextBitIsOne'](){const _0x594c57=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x594c57;}}const dn=function(_0x35a6fe,_0x220e2a,_0x25891c,_0x40d6b4){_0x35a6fe['sort'](_0x220e2a);const _0x5e4601=function(_0x102d40,_0x5eb726){const _0x593753=_0x5eb726-_0x102d40;let _0x146519,_0x4ee4d0;if(_0x593753===0x0)return null;if(_0x593753===0x1)return _0x146519=_0x35a6fe[_0x102d40],_0x4ee4d0=_0x25891c?_0x25891c(_0x146519):_0x146519,new M(_0x4ee4d0,_0x146519['node'],M['BLACK'],null,null);{const _0x1a2e23=parseInt(_0x593753/0x2,0xa)+_0x102d40,_0x121c46=_0x5e4601(_0x102d40,_0x1a2e23),_0x5140a4=_0x5e4601(_0x1a2e23+0x1,_0x5eb726);return _0x146519=_0x35a6fe[_0x1a2e23],_0x4ee4d0=_0x25891c?_0x25891c(_0x146519):_0x146519,new M(_0x4ee4d0,_0x146519['node'],M['BLACK'],_0x121c46,_0x5140a4);}},_0x2ab716=function(_0x3713f6){let _0x222404=null,_0x3ce189=null,_0x2b831e=_0x35a6fe['length'];const _0x3db072=function(_0x2ace45,_0x45eadf){const _0x55d67f=_0x2b831e-_0x2ace45,_0x40634f=_0x2b831e;_0x2b831e-=_0x2ace45;const _0x4bd5ce=_0x5e4601(_0x55d67f+0x1,_0x40634f),_0x26770e=_0x35a6fe[_0x55d67f],_0x5865b7=_0x25891c?_0x25891c(_0x26770e):_0x26770e;_0x523ed0(new M(_0x5865b7,_0x26770e['node'],_0x45eadf,null,_0x4bd5ce));},_0x523ed0=function(_0x19d977){_0x222404?(_0x222404['left']=_0x19d977,_0x222404=_0x19d977):(_0x3ce189=_0x19d977,_0x222404=_0x19d977);};for(let _0x2aa790=0x0;_0x2aa790<_0x3713f6['count'];++_0x2aa790){const _0x4c73d0=_0x3713f6['nextBitIsOne'](),_0x462545=Math['pow'](0x2,_0x3713f6['count']-(_0x2aa790+0x1));_0x4c73d0?_0x3db072(_0x462545,M['BLACK']):(_0x3db072(_0x462545,M['BLACK']),_0x3db072(_0x462545,M['RED']));}return _0x3ce189;},_0xab6844=new Wh(_0x35a6fe['length']),_0x475a45=_0x2ab716(_0xab6844);return new B(_0x40d6b4||_0x220e2a,_0x475a45);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x32498f,_0x4f2a72){this['indexes_']=_0x32498f,this['indexSet_']=_0x4f2a72;}['get'](_0x4a7d6d){const _0x5b4f4f=Oe(this['indexes_'],_0x4a7d6d);if(!_0x5b4f4f)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4a7d6d);return _0x5b4f4f instanceof B?_0x5b4f4f:null;}['hasIndex'](_0x570cf8){return Y(this['indexSet_'],_0x570cf8['toString']());}['addIndex'](_0x53ddf6,_0x3ff56b){f(_0x53ddf6!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4fe3cc=[];let _0x46ea87=!0x1;const _0x2a5e07=_0x3ff56b['getIterator'](E['Wrap']);let _0x3c53d1=_0x2a5e07['getNext']();for(;_0x3c53d1;)_0x46ea87=_0x46ea87||_0x53ddf6['isDefinedOn'](_0x3c53d1['node']),_0x4fe3cc['push'](_0x3c53d1),_0x3c53d1=_0x2a5e07['getNext']();let _0x35e990;_0x46ea87?_0x35e990=dn(_0x4fe3cc,_0x53ddf6['getCompare']()):_0x35e990=je;const _0x4c2d56=_0x53ddf6['toString'](),_0x2cce50={...this['indexSet_']};_0x2cce50[_0x4c2d56]=_0x53ddf6;const _0x229371={...this['indexes_']};return _0x229371[_0x4c2d56]=_0x35e990,new ee(_0x229371,_0x2cce50);}['addToIndexes'](_0x52a1ef,_0xc74cd0){const _0xabe69f=ln(this['indexes_'],(_0x27c1a5,_0xb9e44e)=>{const _0x379438=Oe(this['indexSet_'],_0xb9e44e);if(f(_0x379438,'Missing\x20index\x20implementation\x20for\x20'+_0xb9e44e),_0x27c1a5===je){if(_0x379438['isDefinedOn'](_0x52a1ef['node'])){const _0x2daf0b=[],_0x5a08a7=_0xc74cd0['getIterator'](E['Wrap']);let _0x4cae37=_0x5a08a7['getNext']();for(;_0x4cae37;)_0x4cae37['name']!==_0x52a1ef['name']&&_0x2daf0b['push'](_0x4cae37),_0x4cae37=_0x5a08a7['getNext']();return _0x2daf0b['push'](_0x52a1ef),dn(_0x2daf0b,_0x379438['getCompare']());}else return je;}else{const _0x83aa40=_0xc74cd0['get'](_0x52a1ef['name']);let _0x50fd26=_0x27c1a5;return _0x83aa40&&(_0x50fd26=_0x50fd26['remove'](new E(_0x52a1ef['name'],_0x83aa40))),_0x50fd26['insert'](_0x52a1ef,_0x52a1ef['node']);}});return new ee(_0xabe69f,this['indexSet_']);}['removeFromIndexes'](_0x421f20,_0x479d2f){const _0x3d58a8=ln(this['indexes_'],_0x497b7b=>{if(_0x497b7b===je)return _0x497b7b;{const _0x2be6c6=_0x479d2f['get'](_0x421f20['name']);return _0x2be6c6?_0x497b7b['remove'](new E(_0x421f20['name'],_0x2be6c6)):_0x497b7b;}});return new ee(_0x3d58a8,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x441308,_0x48f895,_0x3755fe){this['children_']=_0x441308,this['priorityNode_']=_0x48f895,this['indexMap_']=_0x3755fe,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1341b0){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1341b0,this['indexMap_']);}['getImmediateChild'](_0x64a666){if(_0x64a666==='.priority')return this['getPriority']();{const _0x28fedf=this['children_']['get'](_0x64a666);return _0x28fedf===null?gt:_0x28fedf;}}['getChild'](_0x189234){const _0x4da61d=y(_0x189234);return _0x4da61d===null?this:this['getImmediateChild'](_0x4da61d)['getChild'](b(_0x189234));}['hasChild'](_0x242093){return this['children_']['get'](_0x242093)!==null;}['updateImmediateChild'](_0x4a1e37,_0x224c61){if(f(_0x224c61,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4a1e37==='.priority')return this['updatePriority'](_0x224c61);{const _0x1fb2aa=new E(_0x4a1e37,_0x224c61);let _0x50d4e3,_0x4fa9ec;_0x224c61['isEmpty']()?(_0x50d4e3=this['children_']['remove'](_0x4a1e37),_0x4fa9ec=this['indexMap_']['removeFromIndexes'](_0x1fb2aa,this['children_'])):(_0x50d4e3=this['children_']['insert'](_0x4a1e37,_0x224c61),_0x4fa9ec=this['indexMap_']['addToIndexes'](_0x1fb2aa,this['children_']));const _0x41087e=_0x50d4e3['isEmpty']()?gt:this['priorityNode_'];return new g(_0x50d4e3,_0x41087e,_0x4fa9ec);}}['updateChild'](_0x2b9084,_0x120866){const _0x592462=y(_0x2b9084);if(_0x592462===null)return _0x120866;{f(y(_0x2b9084)!=='.priority'||we(_0x2b9084)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x471118=this['getImmediateChild'](_0x592462)['updateChild'](b(_0x2b9084),_0x120866);return this['updateImmediateChild'](_0x592462,_0x471118);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3614a5){if(this['isEmpty']())return null;const _0x47c04c={};let _0x401592=0x0,_0x32a9d5=0x0,_0x5495c0=!0x0;if(this['forEachChild'](R,(_0x12bb16,_0x19f1df)=>{_0x47c04c[_0x12bb16]=_0x19f1df['val'](_0x3614a5),_0x401592++,_0x5495c0&&g['INTEGER_REGEXP_']['test'](_0x12bb16)?_0x32a9d5=Math['max'](_0x32a9d5,Number(_0x12bb16)):_0x5495c0=!0x1;}),!_0x3614a5&&_0x5495c0&&_0x32a9d5<0x2*_0x401592){const _0x4f6d0e=[];for(const _0x106bdc in _0x47c04c)_0x4f6d0e[_0x106bdc]=_0x47c04c[_0x106bdc];return _0x4f6d0e;}else return _0x3614a5&&!this['getPriority']()['isEmpty']()&&(_0x47c04c['.priority']=this['getPriority']()['val']()),_0x47c04c;}['hash'](){if(this['lazyHash_']===null){let _0x5b4f2b='';this['getPriority']()['isEmpty']()||(_0x5b4f2b+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2783a7,_0xbf0079)=>{const _0x37587d=_0xbf0079['hash']();_0x37587d!==''&&(_0x5b4f2b+=':'+_0x2783a7+':'+_0x37587d);}),this['lazyHash_']=_0x5b4f2b===''?'':no(_0x5b4f2b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1a509f,_0x918685,_0x1a03dd){const _0x3b4228=this['resolveIndex_'](_0x1a03dd);if(_0x3b4228){const _0x10198a=_0x3b4228['getPredecessorKey'](new E(_0x1a509f,_0x918685));return _0x10198a?_0x10198a['name']:null;}else return this['children_']['getPredecessorKey'](_0x1a509f);}['getFirstChildName'](_0x1e620a){const _0x51f726=this['resolveIndex_'](_0x1e620a);if(_0x51f726){const _0x29faf4=_0x51f726['minKey']();return _0x29faf4&&_0x29faf4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4ae666){const _0x5a507e=this['getFirstChildName'](_0x4ae666);return _0x5a507e?new E(_0x5a507e,this['children_']['get'](_0x5a507e)):null;}['getLastChildName'](_0x366fce){const _0x4d2c3a=this['resolveIndex_'](_0x366fce);if(_0x4d2c3a){const _0x5af6f1=_0x4d2c3a['maxKey']();return _0x5af6f1&&_0x5af6f1['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x19bb72){const _0x41edad=this['getLastChildName'](_0x19bb72);return _0x41edad?new E(_0x41edad,this['children_']['get'](_0x41edad)):null;}['forEachChild'](_0x3e1e58,_0x318a6d){const _0x4ccb60=this['resolveIndex_'](_0x3e1e58);return _0x4ccb60?_0x4ccb60['inorderTraversal'](_0x250d23=>_0x318a6d(_0x250d23['name'],_0x250d23['node'])):this['children_']['inorderTraversal'](_0x318a6d);}['getIterator'](_0x59100b){return this['getIteratorFrom'](_0x59100b['minPost'](),_0x59100b);}['getIteratorFrom'](_0x548425,_0x975aa3){const _0x3b2f32=this['resolveIndex_'](_0x975aa3);if(_0x3b2f32)return _0x3b2f32['getIteratorFrom'](_0x548425,_0x3e54c1=>_0x3e54c1);{const _0x42e59a=this['children_']['getIteratorFrom'](_0x548425['name'],E['Wrap']);let _0x3d3d01=_0x42e59a['peek']();for(;_0x3d3d01!=null&&_0x975aa3['compare'](_0x3d3d01,_0x548425)<0x0;)_0x42e59a['getNext'](),_0x3d3d01=_0x42e59a['peek']();return _0x42e59a;}}['getReverseIterator'](_0x331f39){return this['getReverseIteratorFrom'](_0x331f39['maxPost'](),_0x331f39);}['getReverseIteratorFrom'](_0x101e9d,_0x3ec4ba){const _0xf3cf29=this['resolveIndex_'](_0x3ec4ba);if(_0xf3cf29)return _0xf3cf29['getReverseIteratorFrom'](_0x101e9d,_0x25bed5=>_0x25bed5);{const _0x4d9483=this['children_']['getReverseIteratorFrom'](_0x101e9d['name'],E['Wrap']);let _0x10f79a=_0x4d9483['peek']();for(;_0x10f79a!=null&&_0x3ec4ba['compare'](_0x10f79a,_0x101e9d)>0x0;)_0x4d9483['getNext'](),_0x10f79a=_0x4d9483['peek']();return _0x4d9483;}}['compareTo'](_0x20d6f5){return this['isEmpty']()?_0x20d6f5['isEmpty']()?0x0:-0x1:_0x20d6f5['isLeafNode']()||_0x20d6f5['isEmpty']()?0x1:_0x20d6f5===Ht?-0x1:0x0;}['withIndex'](_0x5998ba){if(_0x5998ba===ye||this['indexMap_']['hasIndex'](_0x5998ba))return this;{const _0x16cc28=this['indexMap_']['addIndex'](_0x5998ba,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x16cc28);}}['isIndexed'](_0x4b2884){return _0x4b2884===ye||this['indexMap_']['hasIndex'](_0x4b2884);}['equals'](_0x3e40cb){if(_0x3e40cb===this)return!0x0;if(_0x3e40cb['isLeafNode']())return!0x1;{const _0x1854d4=_0x3e40cb;if(this['getPriority']()['equals'](_0x1854d4['getPriority']())){if(this['children_']['count']()===_0x1854d4['children_']['count']()){const _0x1f7fcb=this['getIterator'](R),_0x456d97=_0x1854d4['getIterator'](R);let _0x3cedad=_0x1f7fcb['getNext'](),_0x11d933=_0x456d97['getNext']();for(;_0x3cedad&&_0x11d933;){if(_0x3cedad['name']!==_0x11d933['name']||!_0x3cedad['node']['equals'](_0x11d933['node']))return!0x1;_0x3cedad=_0x1f7fcb['getNext'](),_0x11d933=_0x456d97['getNext']();}return _0x3cedad===null&&_0x11d933===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x58ead4){return _0x58ead4===ye?null:this['indexMap_']['get'](_0x58ead4['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x381c38){return _0x381c38===this?0x0:0x1;}['equals'](_0x376a45){return _0x376a45===this;}['getPriority'](){return this;}['getImmediateChild'](_0x482739){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x46901e,_0x14847f=null){if(_0x46901e===null)return g['EMPTY_NODE'];if(typeof _0x46901e=='object'&&'.priority'in _0x46901e&&(_0x14847f=_0x46901e['.priority']),f(_0x14847f===null||typeof _0x14847f=='string'||typeof _0x14847f=='number'||typeof _0x14847f=='object'&&'.sv'in _0x14847f,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x14847f),typeof _0x46901e=='object'&&'.value'in _0x46901e&&_0x46901e['.value']!==null&&(_0x46901e=_0x46901e['.value']),typeof _0x46901e!='object'||'.sv'in _0x46901e){const _0x3b086c=_0x46901e;return new D(_0x3b086c,N(_0x14847f));}if(!(_0x46901e instanceof Array)&&Vh){const _0x585029=[];let _0x2753a6=!0x1;if(x(_0x46901e,(_0x67c296,_0x428b75)=>{if(_0x67c296['substring'](0x0,0x1)!=='.'){const _0x57bf5c=N(_0x428b75);_0x57bf5c['isEmpty']()||(_0x2753a6=_0x2753a6||!_0x57bf5c['getPriority']()['isEmpty'](),_0x585029['push'](new E(_0x67c296,_0x57bf5c)));}}),_0x585029['length']===0x0)return g['EMPTY_NODE'];const _0x4f95d1=dn(_0x585029,Dh,_0x48d278=>_0x48d278['name'],ji);if(_0x2753a6){const _0x4b2f12=dn(_0x585029,R['getCompare']());return new g(_0x4f95d1,N(_0x14847f),new ee({'.priority':_0x4b2f12},{'.priority':R}));}else return new g(_0x4f95d1,N(_0x14847f),ee['Default']);}else{let _0x3356e9=g['EMPTY_NODE'];return x(_0x46901e,(_0x25a330,_0x20cc25)=>{if(Y(_0x46901e,_0x25a330)&&_0x25a330['substring'](0x0,0x1)!=='.'){const _0x2bd364=N(_0x20cc25);(_0x2bd364['isLeafNode']()||!_0x2bd364['isEmpty']())&&(_0x3356e9=_0x3356e9['updateImmediateChild'](_0x25a330,_0x2bd364));}}),_0x3356e9['updatePriority'](N(_0x14847f));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x306fab){super(),this['indexPath_']=_0x306fab,f(!v(_0x306fab)&&y(_0x306fab)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x523d89){return _0x523d89['getChild'](this['indexPath_']);}['isDefinedOn'](_0xf76162){return!_0xf76162['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4f853b,_0x5db3fc){const _0x209741=this['extractChild'](_0x4f853b['node']),_0x2b7ffc=this['extractChild'](_0x5db3fc['node']),_0x53ca5a=_0x209741['compareTo'](_0x2b7ffc);return _0x53ca5a===0x0?He(_0x4f853b['name'],_0x5db3fc['name']):_0x53ca5a;}['makePost'](_0x5bc08b,_0x2f0a0b){const _0x45e49d=N(_0x5bc08b),_0x590322=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x45e49d);return new E(_0x2f0a0b,_0x590322);}['maxPost'](){const _0x3b04c1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x3b04c1);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x4396ff,_0x8a6a71){const _0x221ce9=_0x4396ff['node']['compareTo'](_0x8a6a71['node']);return _0x221ce9===0x0?He(_0x4396ff['name'],_0x8a6a71['name']):_0x221ce9;}['isDefinedOn'](_0x334df4){return!0x0;}['indexedValueChanged'](_0x42f3d1,_0x581afc){return!_0x42f3d1['equals'](_0x581afc);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3d2665,_0x2a6bd2){const _0x47a3b3=N(_0x3d2665);return new E(_0x2a6bd2,_0x47a3b3);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x2a6053){return{'type':'value','snapshotNode':_0x2a6053};}function tt(_0x6fc58,_0x28f468){return{'type':'child_added','snapshotNode':_0x28f468,'childName':_0x6fc58};}function Nt(_0x4aae92,_0x43c022){return{'type':'child_removed','snapshotNode':_0x43c022,'childName':_0x4aae92};}function Pt(_0x187b54,_0x3dda74,_0x363b12){return{'type':'child_changed','snapshotNode':_0x3dda74,'childName':_0x187b54,'oldSnap':_0x363b12};}function $h(_0x224046,_0x3ad895){return{'type':'child_moved','snapshotNode':_0x3ad895,'childName':_0x224046};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x5bca31){this['index_']=_0x5bca31;}['updateChild'](_0x206d28,_0x22af85,_0x5cf282,_0x4db31f,_0x5e8a7f,_0x6ab746){f(_0x206d28['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xf67540=_0x206d28['getImmediateChild'](_0x22af85);return _0xf67540['getChild'](_0x4db31f)['equals'](_0x5cf282['getChild'](_0x4db31f))&&_0xf67540['isEmpty']()===_0x5cf282['isEmpty']()||(_0x6ab746!=null&&(_0x5cf282['isEmpty']()?_0x206d28['hasChild'](_0x22af85)?_0x6ab746['trackChildChange'](Nt(_0x22af85,_0xf67540)):f(_0x206d28['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xf67540['isEmpty']()?_0x6ab746['trackChildChange'](tt(_0x22af85,_0x5cf282)):_0x6ab746['trackChildChange'](Pt(_0x22af85,_0x5cf282,_0xf67540))),_0x206d28['isLeafNode']()&&_0x5cf282['isEmpty']())?_0x206d28:_0x206d28['updateImmediateChild'](_0x22af85,_0x5cf282)['withIndex'](this['index_']);}['updateFullNode'](_0x1b255e,_0x83c00,_0x51aa0d){return _0x51aa0d!=null&&(_0x1b255e['isLeafNode']()||_0x1b255e['forEachChild'](R,(_0x317a89,_0x51beb4)=>{_0x83c00['hasChild'](_0x317a89)||_0x51aa0d['trackChildChange'](Nt(_0x317a89,_0x51beb4));}),_0x83c00['isLeafNode']()||_0x83c00['forEachChild'](R,(_0x299e61,_0x1c5825)=>{if(_0x1b255e['hasChild'](_0x299e61)){const _0xc009c6=_0x1b255e['getImmediateChild'](_0x299e61);_0xc009c6['equals'](_0x1c5825)||_0x51aa0d['trackChildChange'](Pt(_0x299e61,_0x1c5825,_0xc009c6));}else _0x51aa0d['trackChildChange'](tt(_0x299e61,_0x1c5825));})),_0x83c00['withIndex'](this['index_']);}['updatePriority'](_0x194656,_0x3e0407){return _0x194656['isEmpty']()?g['EMPTY_NODE']:_0x194656['updatePriority'](_0x3e0407);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x5f2f24){this['indexedFilter_']=new Yi(_0x5f2f24['getIndex']()),this['index_']=_0x5f2f24['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x5f2f24),this['endPost_']=Ot['getEndPost_'](_0x5f2f24),this['startIsInclusive_']=!_0x5f2f24['startAfterSet_'],this['endIsInclusive_']=!_0x5f2f24['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xe12648){const _0x36d9a6=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xe12648)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xe12648)<0x0,_0x30284b=this['endIsInclusive_']?this['index_']['compare'](_0xe12648,this['getEndPost']())<=0x0:this['index_']['compare'](_0xe12648,this['getEndPost']())<0x0;return _0x36d9a6&&_0x30284b;}['updateChild'](_0x363e77,_0x51bb8f,_0x4af3b9,_0x1cd533,_0x2ffb04,_0x192bff){return this['matches'](new E(_0x51bb8f,_0x4af3b9))||(_0x4af3b9=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x363e77,_0x51bb8f,_0x4af3b9,_0x1cd533,_0x2ffb04,_0x192bff);}['updateFullNode'](_0x448717,_0x475c7e,_0x2d3e13){_0x475c7e['isLeafNode']()&&(_0x475c7e=g['EMPTY_NODE']);let _0x21b9e2=_0x475c7e['withIndex'](this['index_']);_0x21b9e2=_0x21b9e2['updatePriority'](g['EMPTY_NODE']);const _0x58c3da=this;return _0x475c7e['forEachChild'](R,(_0x496138,_0x52b0e8)=>{_0x58c3da['matches'](new E(_0x496138,_0x52b0e8))||(_0x21b9e2=_0x21b9e2['updateImmediateChild'](_0x496138,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x448717,_0x21b9e2,_0x2d3e13);}['updatePriority'](_0x51f5de,_0x18f77e){return _0x51f5de;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x467d91){if(_0x467d91['hasStart']()){const _0x52b59d=_0x467d91['getIndexStartName']();return _0x467d91['getIndex']()['makePost'](_0x467d91['getIndexStartValue'](),_0x52b59d);}else return _0x467d91['getIndex']()['minPost']();}static['getEndPost_'](_0x365dd7){if(_0x365dd7['hasEnd']()){const _0x247a3d=_0x365dd7['getIndexEndName']();return _0x365dd7['getIndex']()['makePost'](_0x365dd7['getIndexEndValue'](),_0x247a3d);}else return _0x365dd7['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x2d65e2){this['withinDirectionalStart']=_0x5be5a7=>this['reverse_']?this['withinEndPost'](_0x5be5a7):this['withinStartPost'](_0x5be5a7),this['withinDirectionalEnd']=_0x5a4569=>this['reverse_']?this['withinStartPost'](_0x5a4569):this['withinEndPost'](_0x5a4569),this['withinStartPost']=_0x43cb50=>{const _0xefcfb6=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x43cb50);return this['startIsInclusive_']?_0xefcfb6<=0x0:_0xefcfb6<0x0;},this['withinEndPost']=_0xeca85a=>{const _0x54c6e7=this['index_']['compare'](_0xeca85a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x54c6e7<=0x0:_0x54c6e7<0x0;},this['rangedFilter_']=new Ot(_0x2d65e2),this['index_']=_0x2d65e2['getIndex'](),this['limit_']=_0x2d65e2['getLimit'](),this['reverse_']=!_0x2d65e2['isViewFromLeft'](),this['startIsInclusive_']=!_0x2d65e2['startAfterSet_'],this['endIsInclusive_']=!_0x2d65e2['endBeforeSet_'];}['updateChild'](_0x2763bf,_0x3b4cfa,_0x3cc2b8,_0x3158cb,_0x63d64e,_0x4586dd){return this['rangedFilter_']['matches'](new E(_0x3b4cfa,_0x3cc2b8))||(_0x3cc2b8=g['EMPTY_NODE']),_0x2763bf['getImmediateChild'](_0x3b4cfa)['equals'](_0x3cc2b8)?_0x2763bf:_0x2763bf['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2763bf,_0x3b4cfa,_0x3cc2b8,_0x3158cb,_0x63d64e,_0x4586dd):this['fullLimitUpdateChild_'](_0x2763bf,_0x3b4cfa,_0x3cc2b8,_0x63d64e,_0x4586dd);}['updateFullNode'](_0x1a5892,_0xb4ac2e,_0x51ffbf){let _0x14950c;if(_0xb4ac2e['isLeafNode']()||_0xb4ac2e['isEmpty']())_0x14950c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xb4ac2e['numChildren']()&&_0xb4ac2e['isIndexed'](this['index_'])){_0x14950c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x45eb3a;this['reverse_']?_0x45eb3a=_0xb4ac2e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x45eb3a=_0xb4ac2e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xc9a29d=0x0;for(;_0x45eb3a['hasNext']()&&_0xc9a29d<this['limit_'];){const _0x5f1555=_0x45eb3a['getNext']();if(this['withinDirectionalStart'](_0x5f1555)){if(this['withinDirectionalEnd'](_0x5f1555))_0x14950c=_0x14950c['updateImmediateChild'](_0x5f1555['name'],_0x5f1555['node']),_0xc9a29d++;else break;}else continue;}}else{_0x14950c=_0xb4ac2e['withIndex'](this['index_']),_0x14950c=_0x14950c['updatePriority'](g['EMPTY_NODE']);let _0x5e1cd1;this['reverse_']?_0x5e1cd1=_0x14950c['getReverseIterator'](this['index_']):_0x5e1cd1=_0x14950c['getIterator'](this['index_']);let _0x187e5b=0x0;for(;_0x5e1cd1['hasNext']();){const _0x8d7ac9=_0x5e1cd1['getNext']();_0x187e5b<this['limit_']&&this['withinDirectionalStart'](_0x8d7ac9)&&this['withinDirectionalEnd'](_0x8d7ac9)?_0x187e5b++:_0x14950c=_0x14950c['updateImmediateChild'](_0x8d7ac9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1a5892,_0x14950c,_0x51ffbf);}['updatePriority'](_0x37e136,_0x105611){return _0x37e136;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x15ffb9,_0x21ecbd,_0x302f5b,_0x1cd5a4,_0x34797a){let _0x5550b2;if(this['reverse_']){const _0x1bbfc6=this['index_']['getCompare']();_0x5550b2=(_0x2fdc9c,_0x457fda)=>_0x1bbfc6(_0x457fda,_0x2fdc9c);}else _0x5550b2=this['index_']['getCompare']();const _0xde689e=_0x15ffb9;f(_0xde689e['numChildren']()===this['limit_'],'');const _0x450fba=new E(_0x21ecbd,_0x302f5b),_0x37d693=this['reverse_']?_0xde689e['getFirstChild'](this['index_']):_0xde689e['getLastChild'](this['index_']),_0x406bf2=this['rangedFilter_']['matches'](_0x450fba);if(_0xde689e['hasChild'](_0x21ecbd)){const _0x16628a=_0xde689e['getImmediateChild'](_0x21ecbd);let _0xf7b3ba=_0x1cd5a4['getChildAfterChild'](this['index_'],_0x37d693,this['reverse_']);for(;_0xf7b3ba!=null&&(_0xf7b3ba['name']===_0x21ecbd||_0xde689e['hasChild'](_0xf7b3ba['name']));)_0xf7b3ba=_0x1cd5a4['getChildAfterChild'](this['index_'],_0xf7b3ba,this['reverse_']);const _0xc7ddbb=_0xf7b3ba==null?0x1:_0x5550b2(_0xf7b3ba,_0x450fba);if(_0x406bf2&&!_0x302f5b['isEmpty']()&&_0xc7ddbb>=0x0)return _0x34797a!=null&&_0x34797a['trackChildChange'](Pt(_0x21ecbd,_0x302f5b,_0x16628a)),_0xde689e['updateImmediateChild'](_0x21ecbd,_0x302f5b);{_0x34797a!=null&&_0x34797a['trackChildChange'](Nt(_0x21ecbd,_0x16628a));const _0x2b4d29=_0xde689e['updateImmediateChild'](_0x21ecbd,g['EMPTY_NODE']);return _0xf7b3ba!=null&&this['rangedFilter_']['matches'](_0xf7b3ba)?(_0x34797a!=null&&_0x34797a['trackChildChange'](tt(_0xf7b3ba['name'],_0xf7b3ba['node'])),_0x2b4d29['updateImmediateChild'](_0xf7b3ba['name'],_0xf7b3ba['node'])):_0x2b4d29;}}else return _0x302f5b['isEmpty']()?_0x15ffb9:_0x406bf2&&_0x5550b2(_0x37d693,_0x450fba)>=0x0?(_0x34797a!=null&&(_0x34797a['trackChildChange'](Nt(_0x37d693['name'],_0x37d693['node'])),_0x34797a['trackChildChange'](tt(_0x21ecbd,_0x302f5b))),_0xde689e['updateImmediateChild'](_0x21ecbd,_0x302f5b)['updateImmediateChild'](_0x37d693['name'],g['EMPTY_NODE'])):_0x15ffb9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x18921f=new Qi();return _0x18921f['limitSet_']=this['limitSet_'],_0x18921f['limit_']=this['limit_'],_0x18921f['startSet_']=this['startSet_'],_0x18921f['startAfterSet_']=this['startAfterSet_'],_0x18921f['indexStartValue_']=this['indexStartValue_'],_0x18921f['startNameSet_']=this['startNameSet_'],_0x18921f['indexStartName_']=this['indexStartName_'],_0x18921f['endSet_']=this['endSet_'],_0x18921f['endBeforeSet_']=this['endBeforeSet_'],_0x18921f['indexEndValue_']=this['indexEndValue_'],_0x18921f['endNameSet_']=this['endNameSet_'],_0x18921f['indexEndName_']=this['indexEndName_'],_0x18921f['index_']=this['index_'],_0x18921f['viewFrom_']=this['viewFrom_'],_0x18921f;}}function qh(_0x5cf7b4){return _0x5cf7b4['loadsAllData']()?new Yi(_0x5cf7b4['getIndex']()):_0x5cf7b4['hasLimit']()?new Gh(_0x5cf7b4):new Ot(_0x5cf7b4);}function zh(_0x196b8c,_0x297327){const _0x3ecf41=_0x196b8c['copy']();return _0x3ecf41['limitSet_']=!0x0,_0x3ecf41['limit_']=_0x297327,_0x3ecf41['viewFrom_']='l',_0x3ecf41;}function jh(_0x47d821,_0x198fd6,_0x5cadff){const _0x52aab9=_0x47d821['copy']();return _0x52aab9['startSet_']=!0x0,_0x198fd6===void 0x0&&(_0x198fd6=null),_0x52aab9['indexStartValue_']=_0x198fd6,_0x5cadff!=null?(_0x52aab9['startNameSet_']=!0x0,_0x52aab9['indexStartName_']=_0x5cadff):(_0x52aab9['startNameSet_']=!0x1,_0x52aab9['indexStartName_']=''),_0x52aab9;}function Kh(_0xaaeb77,_0xe9ace3,_0x483086){const _0x32723e=_0xaaeb77['copy']();return _0x32723e['endSet_']=!0x0,_0xe9ace3===void 0x0&&(_0xe9ace3=null),_0x32723e['indexEndValue_']=_0xe9ace3,_0x483086!==void 0x0?(_0x32723e['endNameSet_']=!0x0,_0x32723e['indexEndName_']=_0x483086):(_0x32723e['endNameSet_']=!0x1,_0x32723e['indexEndName_']=''),_0x32723e;}function Do(_0x2dca05,_0x195e92){const _0x1a644e=_0x2dca05['copy']();return _0x1a644e['index_']=_0x195e92,_0x1a644e;}function tr(_0x18e713){const _0x4f2ff3={};if(_0x18e713['isDefault']())return _0x4f2ff3;let _0xc6e6be;if(_0x18e713['index_']===R?_0xc6e6be='$priority':_0x18e713['index_']===Po?_0xc6e6be='$value':_0x18e713['index_']===ye?_0xc6e6be='$key':(f(_0x18e713['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0xc6e6be=_0x18e713['index_']['toString']()),_0x4f2ff3['orderBy']=O(_0xc6e6be),_0x18e713['startSet_']){const _0x4296e9=_0x18e713['startAfterSet_']?'startAfter':'startAt';_0x4f2ff3[_0x4296e9]=O(_0x18e713['indexStartValue_']),_0x18e713['startNameSet_']&&(_0x4f2ff3[_0x4296e9]+=','+O(_0x18e713['indexStartName_']));}if(_0x18e713['endSet_']){const _0x55af87=_0x18e713['endBeforeSet_']?'endBefore':'endAt';_0x4f2ff3[_0x55af87]=O(_0x18e713['indexEndValue_']),_0x18e713['endNameSet_']&&(_0x4f2ff3[_0x55af87]+=','+O(_0x18e713['indexEndName_']));}return _0x18e713['limitSet_']&&(_0x18e713['isViewFromLeft']()?_0x4f2ff3['limitToFirst']=_0x18e713['limit_']:_0x4f2ff3['limitToLast']=_0x18e713['limit_']),_0x4f2ff3;}function nr(_0xcb164c){const _0x4cee70={};if(_0xcb164c['startSet_']&&(_0x4cee70['sp']=_0xcb164c['indexStartValue_'],_0xcb164c['startNameSet_']&&(_0x4cee70['sn']=_0xcb164c['indexStartName_']),_0x4cee70['sin']=!_0xcb164c['startAfterSet_']),_0xcb164c['endSet_']&&(_0x4cee70['ep']=_0xcb164c['indexEndValue_'],_0xcb164c['endNameSet_']&&(_0x4cee70['en']=_0xcb164c['indexEndName_']),_0x4cee70['ein']=!_0xcb164c['endBeforeSet_']),_0xcb164c['limitSet_']){_0x4cee70['l']=_0xcb164c['limit_'];let _0x29be28=_0xcb164c['viewFrom_'];_0x29be28===''&&(_0xcb164c['isViewFromLeft']()?_0x29be28='l':_0x29be28='r'),_0x4cee70['vf']=_0x29be28;}return _0xcb164c['index_']!==R&&(_0x4cee70['i']=_0xcb164c['index_']['toString']()),_0x4cee70;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x2abaeb){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x226373,_0x4c2226){return _0x4c2226!==void 0x0?'tag$'+_0x4c2226:(f(_0x226373['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x226373['_path']['toString']());}constructor(_0x3aa92b,_0x355110,_0x3de09b,_0x2f1cf5){super(),this['repoInfo_']=_0x3aa92b,this['onDataUpdate_']=_0x355110,this['authTokenProvider_']=_0x3de09b,this['appCheckTokenProvider_']=_0x2f1cf5,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x5ec2b5,_0x1aee51,_0x49046e,_0x1ef8ad){const _0x5779bb=_0x5ec2b5['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5779bb+'\x20'+_0x5ec2b5['_queryIdentifier']);const _0x5dfbb6=fn['getListenId_'](_0x5ec2b5,_0x49046e),_0x3809c1={};this['listens_'][_0x5dfbb6]=_0x3809c1;const _0x2e5a16=tr(_0x5ec2b5['_queryParams']);this['restRequest_'](_0x5779bb+'.json',_0x2e5a16,(_0x126f8e,_0x408e36)=>{let _0x418cda=_0x408e36;if(_0x126f8e===0x194&&(_0x418cda=null,_0x126f8e=null),_0x126f8e===null&&this['onDataUpdate_'](_0x5779bb,_0x418cda,!0x1,_0x49046e),Oe(this['listens_'],_0x5dfbb6)===_0x3809c1){let _0x5281bd;_0x126f8e?_0x126f8e===0x191?_0x5281bd='permission_denied':_0x5281bd='rest_error:'+_0x126f8e:_0x5281bd='ok',_0x1ef8ad(_0x5281bd,null);}});}['unlisten'](_0x341689,_0x449b02){const _0x4df8ac=fn['getListenId_'](_0x341689,_0x449b02);delete this['listens_'][_0x4df8ac];}['get'](_0xd2bcc5){const _0x319dec=tr(_0xd2bcc5['_queryParams']),_0x532dba=_0xd2bcc5['_path']['toString'](),_0x487e85=new Ve();return this['restRequest_'](_0x532dba+'.json',_0x319dec,(_0x4419f3,_0xd38a53)=>{let _0x446e5f=_0xd38a53;_0x4419f3===0x194&&(_0x446e5f=null,_0x4419f3=null),_0x4419f3===null?(this['onDataUpdate_'](_0x532dba,_0x446e5f,!0x1,null),_0x487e85['resolve'](_0x446e5f)):_0x487e85['reject'](new Error(_0x446e5f));}),_0x487e85['promise'];}['refreshAuthToken'](_0x5cd04f){}['restRequest_'](_0x3ccdbb,_0x172abd={},_0x4fd2f7){return _0x172abd['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x92b73f,_0x475585])=>{_0x92b73f&&_0x92b73f['accessToken']&&(_0x172abd['auth']=_0x92b73f['accessToken']),_0x475585&&_0x475585['token']&&(_0x172abd['ac']=_0x475585['token']);const _0x57508a=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3ccdbb+'?ns='+this['repoInfo_']['namespace']+at(_0x172abd);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x57508a);const _0x1cf649=new XMLHttpRequest();_0x1cf649['onreadystatechange']=()=>{if(_0x4fd2f7&&_0x1cf649['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x57508a+'\x20received.\x20status:',_0x1cf649['status'],'response:',_0x1cf649['responseText']);let _0x6fdd25=null;if(_0x1cf649['status']>=0xc8&&_0x1cf649['status']<0x12c){try{_0x6fdd25=bt(_0x1cf649['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x57508a+':\x20'+_0x1cf649['responseText']);}_0x4fd2f7(null,_0x6fdd25);}else _0x1cf649['status']!==0x191&&_0x1cf649['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x57508a+'\x20Status:\x20'+_0x1cf649['status']),_0x4fd2f7(_0x1cf649['status']);_0x4fd2f7=null;}},_0x1cf649['open']('GET',_0x57508a,!0x0),_0x1cf649['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x532124){return this['rootNode_']['getChild'](_0x532124);}['updateSnapshot'](_0x3e4d9b,_0x12ff06){this['rootNode_']=this['rootNode_']['updateChild'](_0x3e4d9b,_0x12ff06);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x2c0fc4,_0x423a8c,_0x5ea7f9){if(v(_0x423a8c))_0x2c0fc4['value']=_0x5ea7f9,_0x2c0fc4['children']['clear']();else{if(_0x2c0fc4['value']!==null)_0x2c0fc4['value']=_0x2c0fc4['value']['updateChild'](_0x423a8c,_0x5ea7f9);else{const _0x2cafc6=y(_0x423a8c);_0x2c0fc4['children']['has'](_0x2cafc6)||_0x2c0fc4['children']['set'](_0x2cafc6,pn());const _0x3209cf=_0x2c0fc4['children']['get'](_0x2cafc6);_0x423a8c=b(_0x423a8c),Mo(_0x3209cf,_0x423a8c,_0x5ea7f9);}}}function Ei(_0x3c503d,_0x5ad851,_0xd8555f){_0x3c503d['value']!==null?_0xd8555f(_0x5ad851,_0x3c503d['value']):Qh(_0x3c503d,(_0x50c619,_0x32e4d5)=>{const _0x1896f2=new C(_0x5ad851['toString']()+'/'+_0x50c619);Ei(_0x32e4d5,_0x1896f2,_0xd8555f);});}function Qh(_0x3bd085,_0x2cd1eb){_0x3bd085['children']['forEach']((_0x1459a4,_0x161c83)=>{_0x2cd1eb(_0x161c83,_0x1459a4);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x171c3e){this['collection_']=_0x171c3e,this['last_']=null;}['get'](){const _0x42f18b=this['collection_']['get'](),_0x18bd11={..._0x42f18b};return this['last_']&&x(this['last_'],(_0x48d413,_0x44061d)=>{_0x18bd11[_0x48d413]=_0x18bd11[_0x48d413]-_0x44061d;}),this['last_']=_0x42f18b,_0x18bd11;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x2b7c5d,_0x29fe5f){this['server_']=_0x29fe5f,this['statsToReport_']={},this['statsListener_']=new Jh(_0x2b7c5d);const _0x493a4d=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x493a4d));}['reportStats_'](){const _0x5846da=this['statsListener_']['get'](),_0x2b24e8={};let _0x58f977=!0x1;x(_0x5846da,(_0x2961b4,_0x38878e)=>{_0x38878e>0x0&&Y(this['statsToReport_'],_0x2961b4)&&(_0x2b24e8[_0x2961b4]=_0x38878e,_0x58f977=!0x0);}),_0x58f977&&this['server_']['reportStats'](_0x2b24e8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x15d328){_0x15d328[_0x15d328['OVERWRITE']=0x0]='OVERWRITE',_0x15d328[_0x15d328['MERGE']=0x1]='MERGE',_0x15d328[_0x15d328['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x15d328[_0x15d328['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x95dbee){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x95dbee,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0xb603ab,_0x4074db,_0x24012a){this['path']=_0xb603ab,this['affectedTree']=_0x4074db,this['revert']=_0x24012a,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x8d2a26){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4f60d2=this['affectedTree']['subtree'](new C(_0x8d2a26));return new _n(w(),_0x4f60d2,this['revert']);}}else return f(y(this['path'])===_0x8d2a26,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x3494ea,_0x310677){this['source']=_0x3494ea,this['path']=_0x310677,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0xc8190c){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x1a0ad9,_0x585304,_0x1a5eb2){this['source']=_0x1a0ad9,this['path']=_0x585304,this['snap']=_0x1a5eb2,this['type']=q['OVERWRITE'];}['operationForChild'](_0x122c79){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x122c79)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x37188c,_0x23d069,_0x5efd59){this['source']=_0x37188c,this['path']=_0x23d069,this['children']=_0x5efd59,this['type']=q['MERGE'];}['operationForChild'](_0x45d3d8){if(v(this['path'])){const _0x4c0863=this['children']['subtree'](new C(_0x45d3d8));return _0x4c0863['isEmpty']()?null:_0x4c0863['value']?new Fe(this['source'],w(),_0x4c0863['value']):new nt(this['source'],w(),_0x4c0863);}else return f(y(this['path'])===_0x45d3d8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x96fec7,_0x432317,_0x5423d1){this['node_']=_0x96fec7,this['fullyInitialized_']=_0x432317,this['filtered_']=_0x5423d1;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x241afc){if(v(_0x241afc))return this['isFullyInitialized']()&&!this['filtered_'];const _0x57f0e9=y(_0x241afc);return this['isCompleteForChild'](_0x57f0e9);}['isCompleteForChild'](_0x5953ca){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5953ca);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x18d248){this['query_']=_0x18d248,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x21a779,_0x321462,_0x525948,_0x468c05){const _0x5184e2=[],_0x4c7e14=[];return _0x321462['forEach'](_0x21b894=>{_0x21b894['type']==='child_changed'&&_0x21a779['index_']['indexedValueChanged'](_0x21b894['oldSnap'],_0x21b894['snapshotNode'])&&_0x4c7e14['push']($h(_0x21b894['childName'],_0x21b894['snapshotNode']));}),mt(_0x21a779,_0x5184e2,'child_removed',_0x321462,_0x468c05,_0x525948),mt(_0x21a779,_0x5184e2,'child_added',_0x321462,_0x468c05,_0x525948),mt(_0x21a779,_0x5184e2,'child_moved',_0x4c7e14,_0x468c05,_0x525948),mt(_0x21a779,_0x5184e2,'child_changed',_0x321462,_0x468c05,_0x525948),mt(_0x21a779,_0x5184e2,'value',_0x321462,_0x468c05,_0x525948),_0x5184e2;}function mt(_0xdf2551,_0x4ee492,_0x514870,_0x444ab6,_0x52c4de,_0x397ebb){const _0x5b2507=_0x444ab6['filter'](_0x2a7e8a=>_0x2a7e8a['type']===_0x514870);_0x5b2507['sort']((_0x49e24e,_0x45433d)=>su(_0xdf2551,_0x49e24e,_0x45433d)),_0x5b2507['forEach'](_0x430982=>{const _0x5c819f=iu(_0xdf2551,_0x430982,_0x397ebb);_0x52c4de['forEach'](_0x35a2d0=>{_0x35a2d0['respondsTo'](_0x430982['type'])&&_0x4ee492['push'](_0x35a2d0['createEvent'](_0x5c819f,_0xdf2551['query_']));});});}function iu(_0x2d697e,_0x3a3e82,_0x4a04e7){return _0x3a3e82['type']==='value'||_0x3a3e82['type']==='child_removed'||(_0x3a3e82['prevName']=_0x4a04e7['getPredecessorChildName'](_0x3a3e82['childName'],_0x3a3e82['snapshotNode'],_0x2d697e['index_'])),_0x3a3e82;}function su(_0x537d3e,_0x12b36a,_0x355907){if(_0x12b36a['childName']==null||_0x355907['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0xae1036=new E(_0x12b36a['childName'],_0x12b36a['snapshotNode']),_0x4871ee=new E(_0x355907['childName'],_0x355907['snapshotNode']);return _0x537d3e['index_']['compare'](_0xae1036,_0x4871ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x1d0057,_0x4159ea){return{'eventCache':_0x1d0057,'serverCache':_0x4159ea};}function wt(_0xcf83b9,_0x31cf83,_0x30b8e,_0x1e6b82){return Dn(new Ce(_0x31cf83,_0x30b8e,_0x1e6b82),_0xcf83b9['serverCache']);}function Lo(_0x372c55,_0x135796,_0x11eefb,_0x202b5a){return Dn(_0x372c55['eventCache'],new Ce(_0x135796,_0x11eefb,_0x202b5a));}function gn(_0x8ec40f){return _0x8ec40f['eventCache']['isFullyInitialized']()?_0x8ec40f['eventCache']['getNode']():null;}function Ue(_0x4c8bad){return _0x4c8bad['serverCache']['isFullyInitialized']()?_0x4c8bad['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x5075c3){let _0x3e9dd5=new S(null);return x(_0x5075c3,(_0x2d2cfb,_0x118b25)=>{_0x3e9dd5=_0x3e9dd5['set'](new C(_0x2d2cfb),_0x118b25);}),_0x3e9dd5;}constructor(_0x1294a7,_0x6da2=ru()){this['value']=_0x1294a7,this['children']=_0x6da2;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x51c78a,_0x53624d){if(this['value']!=null&&_0x53624d(this['value']))return{'path':w(),'value':this['value']};if(v(_0x51c78a))return null;{const _0x476d7f=y(_0x51c78a),_0xb38869=this['children']['get'](_0x476d7f);if(_0xb38869!==null){const _0x23de4f=_0xb38869['findRootMostMatchingPathAndValue'](b(_0x51c78a),_0x53624d);return _0x23de4f!=null?{'path':A(new C(_0x476d7f),_0x23de4f['path']),'value':_0x23de4f['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x4689b3){return this['findRootMostMatchingPathAndValue'](_0x4689b3,()=>!0x0);}['subtree'](_0x5875cc){if(v(_0x5875cc))return this;{const _0x18877e=y(_0x5875cc),_0x17c602=this['children']['get'](_0x18877e);return _0x17c602!==null?_0x17c602['subtree'](b(_0x5875cc)):new S(null);}}['set'](_0x5c7cf6,_0x468f35){if(v(_0x5c7cf6))return new S(_0x468f35,this['children']);{const _0x48b6aa=y(_0x5c7cf6),_0x2ef5a4=(this['children']['get'](_0x48b6aa)||new S(null))['set'](b(_0x5c7cf6),_0x468f35),_0x449b9c=this['children']['insert'](_0x48b6aa,_0x2ef5a4);return new S(this['value'],_0x449b9c);}}['remove'](_0x4d2114){if(v(_0x4d2114))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x36ffa2=y(_0x4d2114),_0x1211fe=this['children']['get'](_0x36ffa2);if(_0x1211fe){const _0x523882=_0x1211fe['remove'](b(_0x4d2114));let _0x1fd1a5;return _0x523882['isEmpty']()?_0x1fd1a5=this['children']['remove'](_0x36ffa2):_0x1fd1a5=this['children']['insert'](_0x36ffa2,_0x523882),this['value']===null&&_0x1fd1a5['isEmpty']()?new S(null):new S(this['value'],_0x1fd1a5);}else return this;}}['get'](_0x5c6ad1){if(v(_0x5c6ad1))return this['value'];{const _0x209965=y(_0x5c6ad1),_0x3a6c60=this['children']['get'](_0x209965);return _0x3a6c60?_0x3a6c60['get'](b(_0x5c6ad1)):null;}}['setTree'](_0x4c1a06,_0x49fa7c){if(v(_0x4c1a06))return _0x49fa7c;{const _0xae5b2e=y(_0x4c1a06),_0x2a8065=(this['children']['get'](_0xae5b2e)||new S(null))['setTree'](b(_0x4c1a06),_0x49fa7c);let _0x15b99f;return _0x2a8065['isEmpty']()?_0x15b99f=this['children']['remove'](_0xae5b2e):_0x15b99f=this['children']['insert'](_0xae5b2e,_0x2a8065),new S(this['value'],_0x15b99f);}}['fold'](_0x413995){return this['fold_'](w(),_0x413995);}['fold_'](_0x599bbb,_0x47fb17){const _0xb2a513={};return this['children']['inorderTraversal']((_0x10d342,_0xc2a59b)=>{_0xb2a513[_0x10d342]=_0xc2a59b['fold_'](A(_0x599bbb,_0x10d342),_0x47fb17);}),_0x47fb17(_0x599bbb,this['value'],_0xb2a513);}['findOnPath'](_0xe1a385,_0x4accc1){return this['findOnPath_'](_0xe1a385,w(),_0x4accc1);}['findOnPath_'](_0x466f0d,_0x389d20,_0x3813f0){const _0x4cac28=this['value']?_0x3813f0(_0x389d20,this['value']):!0x1;if(_0x4cac28)return _0x4cac28;if(v(_0x466f0d))return null;{const _0x56c5ac=y(_0x466f0d),_0x94fdc=this['children']['get'](_0x56c5ac);return _0x94fdc?_0x94fdc['findOnPath_'](b(_0x466f0d),A(_0x389d20,_0x56c5ac),_0x3813f0):null;}}['foreachOnPath'](_0x4434e0,_0x4f3979){return this['foreachOnPath_'](_0x4434e0,w(),_0x4f3979);}['foreachOnPath_'](_0x3a5738,_0x28ef67,_0xd516ae){if(v(_0x3a5738))return this;{this['value']&&_0xd516ae(_0x28ef67,this['value']);const _0x2f61f7=y(_0x3a5738),_0x406bfa=this['children']['get'](_0x2f61f7);return _0x406bfa?_0x406bfa['foreachOnPath_'](b(_0x3a5738),A(_0x28ef67,_0x2f61f7),_0xd516ae):new S(null);}}['foreach'](_0x1dfb6b){this['foreach_'](w(),_0x1dfb6b);}['foreach_'](_0x17d043,_0x29ae63){this['children']['inorderTraversal']((_0x15546e,_0x22eaf2)=>{_0x22eaf2['foreach_'](A(_0x17d043,_0x15546e),_0x29ae63);}),this['value']&&_0x29ae63(_0x17d043,this['value']);}['foreachChild'](_0x3df4ed){this['children']['inorderTraversal']((_0x2f9b70,_0x2d6dea)=>{_0x2d6dea['value']&&_0x3df4ed(_0x2f9b70,_0x2d6dea['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2e6b3b){this['writeTree_']=_0x2e6b3b;}static['empty'](){return new j(new S(null));}}function Ct(_0x1b4a70,_0x3cd973,_0x29fd15){if(v(_0x3cd973))return new j(new S(_0x29fd15));{const _0x5856d7=_0x1b4a70['writeTree_']['findRootMostValueAndPath'](_0x3cd973);if(_0x5856d7!=null){const _0x40c918=_0x5856d7['path'];let _0x1c63f4=_0x5856d7['value'];const _0x5381d2=F(_0x40c918,_0x3cd973);return _0x1c63f4=_0x1c63f4['updateChild'](_0x5381d2,_0x29fd15),new j(_0x1b4a70['writeTree_']['set'](_0x40c918,_0x1c63f4));}else{const _0x211255=new S(_0x29fd15),_0x1efb98=_0x1b4a70['writeTree_']['setTree'](_0x3cd973,_0x211255);return new j(_0x1efb98);}}}function Ii(_0xc9a4e0,_0xb0d9ff,_0x550017){let _0x501989=_0xc9a4e0;return x(_0x550017,(_0x390eed,_0x13c693)=>{_0x501989=Ct(_0x501989,A(_0xb0d9ff,_0x390eed),_0x13c693);}),_0x501989;}function sr(_0x38eda4,_0x259396){if(v(_0x259396))return j['empty']();{const _0x48b45e=_0x38eda4['writeTree_']['setTree'](_0x259396,new S(null));return new j(_0x48b45e);}}function wi(_0x1fde28,_0x44e82f){return $e(_0x1fde28,_0x44e82f)!=null;}function $e(_0x4fb8ff,_0x1e1fec){const _0x27256f=_0x4fb8ff['writeTree_']['findRootMostValueAndPath'](_0x1e1fec);return _0x27256f!=null?_0x4fb8ff['writeTree_']['get'](_0x27256f['path'])['getChild'](F(_0x27256f['path'],_0x1e1fec)):null;}function rr(_0x5794e1){const _0x1f55fa=[],_0x4db323=_0x5794e1['writeTree_']['value'];return _0x4db323!=null?_0x4db323['isLeafNode']()||_0x4db323['forEachChild'](R,(_0x4223c8,_0x5c5fe3)=>{_0x1f55fa['push'](new E(_0x4223c8,_0x5c5fe3));}):_0x5794e1['writeTree_']['children']['inorderTraversal']((_0x565a37,_0x59685e)=>{_0x59685e['value']!=null&&_0x1f55fa['push'](new E(_0x565a37,_0x59685e['value']));}),_0x1f55fa;}function ve(_0x4b7ad9,_0x487d25){if(v(_0x487d25))return _0x4b7ad9;{const _0x56ff1e=$e(_0x4b7ad9,_0x487d25);return _0x56ff1e!=null?new j(new S(_0x56ff1e)):new j(_0x4b7ad9['writeTree_']['subtree'](_0x487d25));}}function Ci(_0x27faf3){return _0x27faf3['writeTree_']['isEmpty']();}function it(_0x2d6d86,_0x1f4e8a){return xo(w(),_0x2d6d86['writeTree_'],_0x1f4e8a);}function xo(_0x37daaf,_0x3a360d,_0x5f5887){if(_0x3a360d['value']!=null)return _0x5f5887['updateChild'](_0x37daaf,_0x3a360d['value']);{let _0x281fd1=null;return _0x3a360d['children']['inorderTraversal']((_0x58388c,_0x186f6f)=>{_0x58388c==='.priority'?(f(_0x186f6f['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x281fd1=_0x186f6f['value']):_0x5f5887=xo(A(_0x37daaf,_0x58388c),_0x186f6f,_0x5f5887);}),!_0x5f5887['getChild'](_0x37daaf)['isEmpty']()&&_0x281fd1!==null&&(_0x5f5887=_0x5f5887['updateChild'](A(_0x37daaf,'.priority'),_0x281fd1)),_0x5f5887;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x52be2b,_0x2aec8b){return Bo(_0x2aec8b,_0x52be2b);}function ou(_0x2720ac,_0x294544,_0x1a42eb,_0x21007f,_0x42f2bb){f(_0x21007f>_0x2720ac['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x42f2bb===void 0x0&&(_0x42f2bb=!0x0),_0x2720ac['allWrites']['push']({'path':_0x294544,'snap':_0x1a42eb,'writeId':_0x21007f,'visible':_0x42f2bb}),_0x42f2bb&&(_0x2720ac['visibleWrites']=Ct(_0x2720ac['visibleWrites'],_0x294544,_0x1a42eb)),_0x2720ac['lastWriteId']=_0x21007f;}function au(_0x3b6651,_0x4b96fb,_0x4075bf,_0x74c98e){f(_0x74c98e>_0x3b6651['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3b6651['allWrites']['push']({'path':_0x4b96fb,'children':_0x4075bf,'writeId':_0x74c98e,'visible':!0x0}),_0x3b6651['visibleWrites']=Ii(_0x3b6651['visibleWrites'],_0x4b96fb,_0x4075bf),_0x3b6651['lastWriteId']=_0x74c98e;}function cu(_0x4c6ea3,_0x29ec5d){for(let _0x22339f=0x0;_0x22339f<_0x4c6ea3['allWrites']['length'];_0x22339f++){const _0x4e1560=_0x4c6ea3['allWrites'][_0x22339f];if(_0x4e1560['writeId']===_0x29ec5d)return _0x4e1560;}return null;}function lu(_0x368ab7,_0x367524){const _0x46baea=_0x368ab7['allWrites']['findIndex'](_0xcf9ebe=>_0xcf9ebe['writeId']===_0x367524);f(_0x46baea>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x2f8e2e=_0x368ab7['allWrites'][_0x46baea];_0x368ab7['allWrites']['splice'](_0x46baea,0x1);let _0x1e9d50=_0x2f8e2e['visible'],_0x39f5f1=!0x1,_0x5a22b0=_0x368ab7['allWrites']['length']-0x1;for(;_0x1e9d50&&_0x5a22b0>=0x0;){const _0x4c7d4b=_0x368ab7['allWrites'][_0x5a22b0];_0x4c7d4b['visible']&&(_0x5a22b0>=_0x46baea&&hu(_0x4c7d4b,_0x2f8e2e['path'])?_0x1e9d50=!0x1:$(_0x2f8e2e['path'],_0x4c7d4b['path'])&&(_0x39f5f1=!0x0)),_0x5a22b0--;}if(_0x1e9d50){if(_0x39f5f1)return uu(_0x368ab7),!0x0;if(_0x2f8e2e['snap'])_0x368ab7['visibleWrites']=sr(_0x368ab7['visibleWrites'],_0x2f8e2e['path']);else{const _0x1abea0=_0x2f8e2e['children'];x(_0x1abea0,_0x7f8936=>{_0x368ab7['visibleWrites']=sr(_0x368ab7['visibleWrites'],A(_0x2f8e2e['path'],_0x7f8936));});}return!0x0;}else return!0x1;}function hu(_0x203b62,_0x24e747){if(_0x203b62['snap'])return $(_0x203b62['path'],_0x24e747);for(const _0x558a75 in _0x203b62['children'])if(_0x203b62['children']['hasOwnProperty'](_0x558a75)&&$(A(_0x203b62['path'],_0x558a75),_0x24e747))return!0x0;return!0x1;}function uu(_0x411230){_0x411230['visibleWrites']=Fo(_0x411230['allWrites'],du,w()),_0x411230['allWrites']['length']>0x0?_0x411230['lastWriteId']=_0x411230['allWrites'][_0x411230['allWrites']['length']-0x1]['writeId']:_0x411230['lastWriteId']=-0x1;}function du(_0x2ced89){return _0x2ced89['visible'];}function Fo(_0xad929e,_0x299c20,_0x58edd3){let _0x1b96b4=j['empty']();for(let _0x503b39=0x0;_0x503b39<_0xad929e['length'];++_0x503b39){const _0x3db04d=_0xad929e[_0x503b39];if(_0x299c20(_0x3db04d)){const _0x476d14=_0x3db04d['path'];let _0x4da86f;if(_0x3db04d['snap'])$(_0x58edd3,_0x476d14)?(_0x4da86f=F(_0x58edd3,_0x476d14),_0x1b96b4=Ct(_0x1b96b4,_0x4da86f,_0x3db04d['snap'])):$(_0x476d14,_0x58edd3)&&(_0x4da86f=F(_0x476d14,_0x58edd3),_0x1b96b4=Ct(_0x1b96b4,w(),_0x3db04d['snap']['getChild'](_0x4da86f)));else{if(_0x3db04d['children']){if($(_0x58edd3,_0x476d14))_0x4da86f=F(_0x58edd3,_0x476d14),_0x1b96b4=Ii(_0x1b96b4,_0x4da86f,_0x3db04d['children']);else{if($(_0x476d14,_0x58edd3)){if(_0x4da86f=F(_0x476d14,_0x58edd3),v(_0x4da86f))_0x1b96b4=Ii(_0x1b96b4,w(),_0x3db04d['children']);else{const _0x37328a=Oe(_0x3db04d['children'],y(_0x4da86f));if(_0x37328a){const _0x52ce8f=_0x37328a['getChild'](b(_0x4da86f));_0x1b96b4=Ct(_0x1b96b4,w(),_0x52ce8f);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1b96b4;}function Uo(_0x18d6f7,_0x35870d,_0x3a8870,_0x442117,_0x54e4a2){if(!_0x442117&&!_0x54e4a2){const _0x57caaf=$e(_0x18d6f7['visibleWrites'],_0x35870d);if(_0x57caaf!=null)return _0x57caaf;{const _0x2d9e07=ve(_0x18d6f7['visibleWrites'],_0x35870d);if(Ci(_0x2d9e07))return _0x3a8870;if(_0x3a8870==null&&!wi(_0x2d9e07,w()))return null;{const _0x49eab5=_0x3a8870||g['EMPTY_NODE'];return it(_0x2d9e07,_0x49eab5);}}}else{const _0x27644b=ve(_0x18d6f7['visibleWrites'],_0x35870d);if(!_0x54e4a2&&Ci(_0x27644b))return _0x3a8870;if(!_0x54e4a2&&_0x3a8870==null&&!wi(_0x27644b,w()))return null;{const _0x342bc5=function(_0x218681){return(_0x218681['visible']||_0x54e4a2)&&(!_0x442117||!~_0x442117['indexOf'](_0x218681['writeId']))&&($(_0x218681['path'],_0x35870d)||$(_0x35870d,_0x218681['path']));},_0x266bfc=Fo(_0x18d6f7['allWrites'],_0x342bc5,_0x35870d),_0x39ad6a=_0x3a8870||g['EMPTY_NODE'];return it(_0x266bfc,_0x39ad6a);}}}function fu(_0xace97c,_0x17b9dc,_0x17f276){let _0x41567b=g['EMPTY_NODE'];const _0x38ca06=$e(_0xace97c['visibleWrites'],_0x17b9dc);if(_0x38ca06)return _0x38ca06['isLeafNode']()||_0x38ca06['forEachChild'](R,(_0x3b75d4,_0x1656ff)=>{_0x41567b=_0x41567b['updateImmediateChild'](_0x3b75d4,_0x1656ff);}),_0x41567b;if(_0x17f276){const _0x2e3fbe=ve(_0xace97c['visibleWrites'],_0x17b9dc);return _0x17f276['forEachChild'](R,(_0x260254,_0x12ea45)=>{const _0x34435a=it(ve(_0x2e3fbe,new C(_0x260254)),_0x12ea45);_0x41567b=_0x41567b['updateImmediateChild'](_0x260254,_0x34435a);}),rr(_0x2e3fbe)['forEach'](_0x234da9=>{_0x41567b=_0x41567b['updateImmediateChild'](_0x234da9['name'],_0x234da9['node']);}),_0x41567b;}else{const _0x236eb4=ve(_0xace97c['visibleWrites'],_0x17b9dc);return rr(_0x236eb4)['forEach'](_0x379add=>{_0x41567b=_0x41567b['updateImmediateChild'](_0x379add['name'],_0x379add['node']);}),_0x41567b;}}function pu(_0x73617d,_0x448dbe,_0x1a95ef,_0x44cc5a,_0x46779d){f(_0x44cc5a||_0x46779d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x549aae=A(_0x448dbe,_0x1a95ef);if(wi(_0x73617d['visibleWrites'],_0x549aae))return null;{const _0x32af99=ve(_0x73617d['visibleWrites'],_0x549aae);return Ci(_0x32af99)?_0x46779d['getChild'](_0x1a95ef):it(_0x32af99,_0x46779d['getChild'](_0x1a95ef));}}function _u(_0x35f655,_0x3be9c2,_0x4318ca,_0x4ca56d){const _0x13ac66=A(_0x3be9c2,_0x4318ca),_0x3ad820=$e(_0x35f655['visibleWrites'],_0x13ac66);if(_0x3ad820!=null)return _0x3ad820;if(_0x4ca56d['isCompleteForChild'](_0x4318ca)){const _0x2b1a6a=ve(_0x35f655['visibleWrites'],_0x13ac66);return it(_0x2b1a6a,_0x4ca56d['getNode']()['getImmediateChild'](_0x4318ca));}else return null;}function gu(_0x441dfc,_0x2e8239){return $e(_0x441dfc['visibleWrites'],_0x2e8239);}function mu(_0x39e696,_0x3a7d22,_0xa59874,_0x2208a9,_0x2c7381,_0x1e6727,_0x2aaa20){let _0x132c86;const _0x4e218b=ve(_0x39e696['visibleWrites'],_0x3a7d22),_0x29897c=$e(_0x4e218b,w());if(_0x29897c!=null)_0x132c86=_0x29897c;else{if(_0xa59874!=null)_0x132c86=it(_0x4e218b,_0xa59874);else return[];}if(_0x132c86=_0x132c86['withIndex'](_0x2aaa20),!_0x132c86['isEmpty']()&&!_0x132c86['isLeafNode']()){const _0x4533da=[],_0x10fc99=_0x2aaa20['getCompare'](),_0x492540=_0x1e6727?_0x132c86['getReverseIteratorFrom'](_0x2208a9,_0x2aaa20):_0x132c86['getIteratorFrom'](_0x2208a9,_0x2aaa20);let _0x41c90f=_0x492540['getNext']();for(;_0x41c90f&&_0x4533da['length']<_0x2c7381;)_0x10fc99(_0x41c90f,_0x2208a9)!==0x0&&_0x4533da['push'](_0x41c90f),_0x41c90f=_0x492540['getNext']();return _0x4533da;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x355f6c,_0x5b38c4,_0x409395,_0x371052){return Uo(_0x355f6c['writeTree'],_0x355f6c['treePath'],_0x5b38c4,_0x409395,_0x371052);}function es(_0x11831b,_0x5f19ee){return fu(_0x11831b['writeTree'],_0x11831b['treePath'],_0x5f19ee);}function or(_0x23cc25,_0x2676be,_0x5c69d6,_0x3cc4d0){return pu(_0x23cc25['writeTree'],_0x23cc25['treePath'],_0x2676be,_0x5c69d6,_0x3cc4d0);}function yn(_0x570a1b,_0xf8075c){return gu(_0x570a1b['writeTree'],A(_0x570a1b['treePath'],_0xf8075c));}function vu(_0x1252bb,_0x4d13f3,_0x3bfc56,_0x282b25,_0x198527,_0x2375eb){return mu(_0x1252bb['writeTree'],_0x1252bb['treePath'],_0x4d13f3,_0x3bfc56,_0x282b25,_0x198527,_0x2375eb);}function ts(_0x458957,_0x2512a6,_0x142f38){return _u(_0x458957['writeTree'],_0x458957['treePath'],_0x2512a6,_0x142f38);}function Wo(_0x29150b,_0x2dee46){return Bo(A(_0x29150b['treePath'],_0x2dee46),_0x29150b['writeTree']);}function Bo(_0x1fdeae,_0x2bf419){return{'treePath':_0x1fdeae,'writeTree':_0x2bf419};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x295940){const _0x511373=_0x295940['type'],_0x66aacc=_0x295940['childName'];f(_0x511373==='child_added'||_0x511373==='child_changed'||_0x511373==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x66aacc!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4d2cad=this['changeMap']['get'](_0x66aacc);if(_0x4d2cad){const _0x90c424=_0x4d2cad['type'];if(_0x511373==='child_added'&&_0x90c424==='child_removed')this['changeMap']['set'](_0x66aacc,Pt(_0x66aacc,_0x295940['snapshotNode'],_0x4d2cad['snapshotNode']));else{if(_0x511373==='child_removed'&&_0x90c424==='child_added')this['changeMap']['delete'](_0x66aacc);else{if(_0x511373==='child_removed'&&_0x90c424==='child_changed')this['changeMap']['set'](_0x66aacc,Nt(_0x66aacc,_0x4d2cad['oldSnap']));else{if(_0x511373==='child_changed'&&_0x90c424==='child_added')this['changeMap']['set'](_0x66aacc,tt(_0x66aacc,_0x295940['snapshotNode']));else{if(_0x511373==='child_changed'&&_0x90c424==='child_changed')this['changeMap']['set'](_0x66aacc,Pt(_0x66aacc,_0x295940['snapshotNode'],_0x4d2cad['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x295940+'\x20occurred\x20after\x20'+_0x4d2cad);}}}}}else this['changeMap']['set'](_0x66aacc,_0x295940);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x12ff1a){return null;}['getChildAfterChild'](_0x43a1cb,_0x4cc97b,_0xbb2766){return null;}}const Vo=new Iu();class ns{constructor(_0x38c893,_0x5764fc,_0x4b89a3=null){this['writes_']=_0x38c893,this['viewCache_']=_0x5764fc,this['optCompleteServerCache_']=_0x4b89a3;}['getCompleteChild'](_0x57f2e5){const _0x2b2c39=this['viewCache_']['eventCache'];if(_0x2b2c39['isCompleteForChild'](_0x57f2e5))return _0x2b2c39['getNode']()['getImmediateChild'](_0x57f2e5);{const _0x3be95e=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x57f2e5,_0x3be95e);}}['getChildAfterChild'](_0x3bf20f,_0x513f38,_0x5a1b49){const _0x2f7f42=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x454d81=vu(this['writes_'],_0x2f7f42,_0x513f38,0x1,_0x5a1b49,_0x3bf20f);return _0x454d81['length']===0x0?null:_0x454d81[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0xeac902){return{'filter':_0xeac902};}function Cu(_0x1f629c,_0x1c36a1){f(_0x1c36a1['eventCache']['getNode']()['isIndexed'](_0x1f629c['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1c36a1['serverCache']['getNode']()['isIndexed'](_0x1f629c['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1716e7,_0x537307,_0x17475f,_0x28280f,_0x4f407a){const _0x3f8d7f=new Eu();let _0x47d9f5,_0x53f2b4;if(_0x17475f['type']===q['OVERWRITE']){const _0x43f063=_0x17475f;_0x43f063['source']['fromUser']?_0x47d9f5=Ti(_0x1716e7,_0x537307,_0x43f063['path'],_0x43f063['snap'],_0x28280f,_0x4f407a,_0x3f8d7f):(f(_0x43f063['source']['fromServer'],'Unknown\x20source.'),_0x53f2b4=_0x43f063['source']['tagged']||_0x537307['serverCache']['isFiltered']()&&!v(_0x43f063['path']),_0x47d9f5=vn(_0x1716e7,_0x537307,_0x43f063['path'],_0x43f063['snap'],_0x28280f,_0x4f407a,_0x53f2b4,_0x3f8d7f));}else{if(_0x17475f['type']===q['MERGE']){const _0x2f64d8=_0x17475f;_0x2f64d8['source']['fromUser']?_0x47d9f5=bu(_0x1716e7,_0x537307,_0x2f64d8['path'],_0x2f64d8['children'],_0x28280f,_0x4f407a,_0x3f8d7f):(f(_0x2f64d8['source']['fromServer'],'Unknown\x20source.'),_0x53f2b4=_0x2f64d8['source']['tagged']||_0x537307['serverCache']['isFiltered'](),_0x47d9f5=Si(_0x1716e7,_0x537307,_0x2f64d8['path'],_0x2f64d8['children'],_0x28280f,_0x4f407a,_0x53f2b4,_0x3f8d7f));}else{if(_0x17475f['type']===q['ACK_USER_WRITE']){const _0x15074e=_0x17475f;_0x15074e['revert']?_0x47d9f5=ku(_0x1716e7,_0x537307,_0x15074e['path'],_0x28280f,_0x4f407a,_0x3f8d7f):_0x47d9f5=Ru(_0x1716e7,_0x537307,_0x15074e['path'],_0x15074e['affectedTree'],_0x28280f,_0x4f407a,_0x3f8d7f);}else{if(_0x17475f['type']===q['LISTEN_COMPLETE'])_0x47d9f5=Au(_0x1716e7,_0x537307,_0x17475f['path'],_0x28280f,_0x3f8d7f);else throw ot('Unknown\x20operation\x20type:\x20'+_0x17475f['type']);}}}const _0x4000db=_0x3f8d7f['getChanges']();return Su(_0x537307,_0x47d9f5,_0x4000db),{'viewCache':_0x47d9f5,'changes':_0x4000db};}function Su(_0x30530c,_0x3b5df1,_0x5a0b50){const _0x241064=_0x3b5df1['eventCache'];if(_0x241064['isFullyInitialized']()){const _0x43f0cf=_0x241064['getNode']()['isLeafNode']()||_0x241064['getNode']()['isEmpty'](),_0x4ed40a=gn(_0x30530c);(_0x5a0b50['length']>0x0||!_0x30530c['eventCache']['isFullyInitialized']()||_0x43f0cf&&!_0x241064['getNode']()['equals'](_0x4ed40a)||!_0x241064['getNode']()['getPriority']()['equals'](_0x4ed40a['getPriority']()))&&_0x5a0b50['push'](Oo(gn(_0x3b5df1)));}}function Ho(_0x197293,_0x22ab05,_0x4fc7da,_0x1f06d0,_0x1033b9,_0x4adf63){const _0x5e876f=_0x22ab05['eventCache'];if(yn(_0x1f06d0,_0x4fc7da)!=null)return _0x22ab05;{let _0x5159ca,_0x47da4c;if(v(_0x4fc7da)){if(f(_0x22ab05['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x22ab05['serverCache']['isFiltered']()){const _0x4c96c3=Ue(_0x22ab05),_0x4af52d=_0x4c96c3 instanceof g?_0x4c96c3:g['EMPTY_NODE'],_0xe28e66=es(_0x1f06d0,_0x4af52d);_0x5159ca=_0x197293['filter']['updateFullNode'](_0x22ab05['eventCache']['getNode'](),_0xe28e66,_0x4adf63);}else{const _0xf5988a=mn(_0x1f06d0,Ue(_0x22ab05));_0x5159ca=_0x197293['filter']['updateFullNode'](_0x22ab05['eventCache']['getNode'](),_0xf5988a,_0x4adf63);}}else{const _0x2b97b7=y(_0x4fc7da);if(_0x2b97b7==='.priority'){f(we(_0x4fc7da)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x532141=_0x5e876f['getNode']();_0x47da4c=_0x22ab05['serverCache']['getNode']();const _0x49be40=or(_0x1f06d0,_0x4fc7da,_0x532141,_0x47da4c);_0x49be40!=null?_0x5159ca=_0x197293['filter']['updatePriority'](_0x532141,_0x49be40):_0x5159ca=_0x5e876f['getNode']();}else{const _0x1ae8cb=b(_0x4fc7da);let _0x2b83a1;if(_0x5e876f['isCompleteForChild'](_0x2b97b7)){_0x47da4c=_0x22ab05['serverCache']['getNode']();const _0x47cbab=or(_0x1f06d0,_0x4fc7da,_0x5e876f['getNode'](),_0x47da4c);_0x47cbab!=null?_0x2b83a1=_0x5e876f['getNode']()['getImmediateChild'](_0x2b97b7)['updateChild'](_0x1ae8cb,_0x47cbab):_0x2b83a1=_0x5e876f['getNode']()['getImmediateChild'](_0x2b97b7);}else _0x2b83a1=ts(_0x1f06d0,_0x2b97b7,_0x22ab05['serverCache']);_0x2b83a1!=null?_0x5159ca=_0x197293['filter']['updateChild'](_0x5e876f['getNode'](),_0x2b97b7,_0x2b83a1,_0x1ae8cb,_0x1033b9,_0x4adf63):_0x5159ca=_0x5e876f['getNode']();}}return wt(_0x22ab05,_0x5159ca,_0x5e876f['isFullyInitialized']()||v(_0x4fc7da),_0x197293['filter']['filtersNodes']());}}function vn(_0x4a1cb7,_0x9692a6,_0x5d5276,_0x275301,_0x3416ea,_0x6a4f27,_0x54dd11,_0x2d6e62){const _0x4d72a2=_0x9692a6['serverCache'];let _0x289732;const _0x36be50=_0x54dd11?_0x4a1cb7['filter']:_0x4a1cb7['filter']['getIndexedFilter']();if(v(_0x5d5276))_0x289732=_0x36be50['updateFullNode'](_0x4d72a2['getNode'](),_0x275301,null);else{if(_0x36be50['filtersNodes']()&&!_0x4d72a2['isFiltered']()){const _0x184325=_0x4d72a2['getNode']()['updateChild'](_0x5d5276,_0x275301);_0x289732=_0x36be50['updateFullNode'](_0x4d72a2['getNode'](),_0x184325,null);}else{const _0x1122ce=y(_0x5d5276);if(!_0x4d72a2['isCompleteForPath'](_0x5d5276)&&we(_0x5d5276)>0x1)return _0x9692a6;const _0xc43a7b=b(_0x5d5276),_0x3f0947=_0x4d72a2['getNode']()['getImmediateChild'](_0x1122ce)['updateChild'](_0xc43a7b,_0x275301);_0x1122ce==='.priority'?_0x289732=_0x36be50['updatePriority'](_0x4d72a2['getNode'](),_0x3f0947):_0x289732=_0x36be50['updateChild'](_0x4d72a2['getNode'](),_0x1122ce,_0x3f0947,_0xc43a7b,Vo,null);}}const _0x1f6c1d=Lo(_0x9692a6,_0x289732,_0x4d72a2['isFullyInitialized']()||v(_0x5d5276),_0x36be50['filtersNodes']()),_0x1a8340=new ns(_0x3416ea,_0x1f6c1d,_0x6a4f27);return Ho(_0x4a1cb7,_0x1f6c1d,_0x5d5276,_0x3416ea,_0x1a8340,_0x2d6e62);}function Ti(_0xfd8458,_0x39ef64,_0x43fea6,_0x5ae334,_0x4a0213,_0x179563,_0x5e30d3){const _0x463f3d=_0x39ef64['eventCache'];let _0x42b37a,_0x25856f;const _0x4dc74f=new ns(_0x4a0213,_0x39ef64,_0x179563);if(v(_0x43fea6))_0x25856f=_0xfd8458['filter']['updateFullNode'](_0x39ef64['eventCache']['getNode'](),_0x5ae334,_0x5e30d3),_0x42b37a=wt(_0x39ef64,_0x25856f,!0x0,_0xfd8458['filter']['filtersNodes']());else{const _0xfe9370=y(_0x43fea6);if(_0xfe9370==='.priority')_0x25856f=_0xfd8458['filter']['updatePriority'](_0x39ef64['eventCache']['getNode'](),_0x5ae334),_0x42b37a=wt(_0x39ef64,_0x25856f,_0x463f3d['isFullyInitialized'](),_0x463f3d['isFiltered']());else{const _0xfd2e54=b(_0x43fea6),_0x1ec2f2=_0x463f3d['getNode']()['getImmediateChild'](_0xfe9370);let _0x376197;if(v(_0xfd2e54))_0x376197=_0x5ae334;else{const _0x39d0db=_0x4dc74f['getCompleteChild'](_0xfe9370);_0x39d0db!=null?Gi(_0xfd2e54)==='.priority'&&_0x39d0db['getChild'](To(_0xfd2e54))['isEmpty']()?_0x376197=_0x39d0db:_0x376197=_0x39d0db['updateChild'](_0xfd2e54,_0x5ae334):_0x376197=g['EMPTY_NODE'];}if(_0x1ec2f2['equals'](_0x376197))_0x42b37a=_0x39ef64;else{const _0x433b83=_0xfd8458['filter']['updateChild'](_0x463f3d['getNode'](),_0xfe9370,_0x376197,_0xfd2e54,_0x4dc74f,_0x5e30d3);_0x42b37a=wt(_0x39ef64,_0x433b83,_0x463f3d['isFullyInitialized'](),_0xfd8458['filter']['filtersNodes']());}}}return _0x42b37a;}function ar(_0x7ab5f3,_0x42df9d){return _0x7ab5f3['eventCache']['isCompleteForChild'](_0x42df9d);}function bu(_0x4fc962,_0x471dcf,_0x5e705c,_0x3afe55,_0x58609e,_0x4e08a4,_0x2246be){let _0x30e6f8=_0x471dcf;return _0x3afe55['foreach']((_0x1519a5,_0x1f5fc8)=>{const _0x1bee59=A(_0x5e705c,_0x1519a5);ar(_0x471dcf,y(_0x1bee59))&&(_0x30e6f8=Ti(_0x4fc962,_0x30e6f8,_0x1bee59,_0x1f5fc8,_0x58609e,_0x4e08a4,_0x2246be));}),_0x3afe55['foreach']((_0x2f57ec,_0x10ada4)=>{const _0x1e95b6=A(_0x5e705c,_0x2f57ec);ar(_0x471dcf,y(_0x1e95b6))||(_0x30e6f8=Ti(_0x4fc962,_0x30e6f8,_0x1e95b6,_0x10ada4,_0x58609e,_0x4e08a4,_0x2246be));}),_0x30e6f8;}function cr(_0x2f3c6e,_0x35dcf0,_0x518ea4){return _0x518ea4['foreach']((_0x3639b9,_0x51780)=>{_0x35dcf0=_0x35dcf0['updateChild'](_0x3639b9,_0x51780);}),_0x35dcf0;}function Si(_0x22b020,_0x49c29b,_0xc04a45,_0x45e7cb,_0xadd1f5,_0x3f7bb7,_0x1781ba,_0x40f9cb){if(_0x49c29b['serverCache']['getNode']()['isEmpty']()&&!_0x49c29b['serverCache']['isFullyInitialized']())return _0x49c29b;let _0x147327=_0x49c29b,_0x1b9f6f;v(_0xc04a45)?_0x1b9f6f=_0x45e7cb:_0x1b9f6f=new S(null)['setTree'](_0xc04a45,_0x45e7cb);const _0x10501a=_0x49c29b['serverCache']['getNode']();return _0x1b9f6f['children']['inorderTraversal']((_0x241724,_0x5463b5)=>{if(_0x10501a['hasChild'](_0x241724)){const _0x29169c=_0x49c29b['serverCache']['getNode']()['getImmediateChild'](_0x241724),_0x44520f=cr(_0x22b020,_0x29169c,_0x5463b5);_0x147327=vn(_0x22b020,_0x147327,new C(_0x241724),_0x44520f,_0xadd1f5,_0x3f7bb7,_0x1781ba,_0x40f9cb);}}),_0x1b9f6f['children']['inorderTraversal']((_0x385a53,_0x2e1376)=>{const _0x4f6242=!_0x49c29b['serverCache']['isCompleteForChild'](_0x385a53)&&_0x2e1376['value']===null;if(!_0x10501a['hasChild'](_0x385a53)&&!_0x4f6242){const _0x4dc1be=_0x49c29b['serverCache']['getNode']()['getImmediateChild'](_0x385a53),_0x3dc3fc=cr(_0x22b020,_0x4dc1be,_0x2e1376);_0x147327=vn(_0x22b020,_0x147327,new C(_0x385a53),_0x3dc3fc,_0xadd1f5,_0x3f7bb7,_0x1781ba,_0x40f9cb);}}),_0x147327;}function Ru(_0x1ca02e,_0x4d02fe,_0x2cbb52,_0xa28d10,_0xd03ac4,_0x256128,_0x441e37){if(yn(_0xd03ac4,_0x2cbb52)!=null)return _0x4d02fe;const _0x4bd46a=_0x4d02fe['serverCache']['isFiltered'](),_0x5b1c2d=_0x4d02fe['serverCache'];if(_0xa28d10['value']!=null){if(v(_0x2cbb52)&&_0x5b1c2d['isFullyInitialized']()||_0x5b1c2d['isCompleteForPath'](_0x2cbb52))return vn(_0x1ca02e,_0x4d02fe,_0x2cbb52,_0x5b1c2d['getNode']()['getChild'](_0x2cbb52),_0xd03ac4,_0x256128,_0x4bd46a,_0x441e37);if(v(_0x2cbb52)){let _0x5ebe86=new S(null);return _0x5b1c2d['getNode']()['forEachChild'](ye,(_0x1c1355,_0x35d154)=>{_0x5ebe86=_0x5ebe86['set'](new C(_0x1c1355),_0x35d154);}),Si(_0x1ca02e,_0x4d02fe,_0x2cbb52,_0x5ebe86,_0xd03ac4,_0x256128,_0x4bd46a,_0x441e37);}else return _0x4d02fe;}else{let _0x4f0c80=new S(null);return _0xa28d10['foreach']((_0x1307db,_0x2c4468)=>{const _0xc10c1b=A(_0x2cbb52,_0x1307db);_0x5b1c2d['isCompleteForPath'](_0xc10c1b)&&(_0x4f0c80=_0x4f0c80['set'](_0x1307db,_0x5b1c2d['getNode']()['getChild'](_0xc10c1b)));}),Si(_0x1ca02e,_0x4d02fe,_0x2cbb52,_0x4f0c80,_0xd03ac4,_0x256128,_0x4bd46a,_0x441e37);}}function Au(_0x8873eb,_0x4b3fe6,_0x396aac,_0x5c72ce,_0x2c32c2){const _0x4ad259=_0x4b3fe6['serverCache'],_0xd64288=Lo(_0x4b3fe6,_0x4ad259['getNode'](),_0x4ad259['isFullyInitialized']()||v(_0x396aac),_0x4ad259['isFiltered']());return Ho(_0x8873eb,_0xd64288,_0x396aac,_0x5c72ce,Vo,_0x2c32c2);}function ku(_0x21874c,_0x3848c5,_0xf59f62,_0x3a006b,_0x4976e8,_0x4a5d42){let _0x49c309;if(yn(_0x3a006b,_0xf59f62)!=null)return _0x3848c5;{const _0x1ce9c6=new ns(_0x3a006b,_0x3848c5,_0x4976e8),_0x2e5531=_0x3848c5['eventCache']['getNode']();let _0xde06b4;if(v(_0xf59f62)||y(_0xf59f62)==='.priority'){let _0x2dc2e8;if(_0x3848c5['serverCache']['isFullyInitialized']())_0x2dc2e8=mn(_0x3a006b,Ue(_0x3848c5));else{const _0x488d48=_0x3848c5['serverCache']['getNode']();f(_0x488d48 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2dc2e8=es(_0x3a006b,_0x488d48);}_0x2dc2e8=_0x2dc2e8,_0xde06b4=_0x21874c['filter']['updateFullNode'](_0x2e5531,_0x2dc2e8,_0x4a5d42);}else{const _0x3edaa9=y(_0xf59f62);let _0x53ba19=ts(_0x3a006b,_0x3edaa9,_0x3848c5['serverCache']);_0x53ba19==null&&_0x3848c5['serverCache']['isCompleteForChild'](_0x3edaa9)&&(_0x53ba19=_0x2e5531['getImmediateChild'](_0x3edaa9)),_0x53ba19!=null?_0xde06b4=_0x21874c['filter']['updateChild'](_0x2e5531,_0x3edaa9,_0x53ba19,b(_0xf59f62),_0x1ce9c6,_0x4a5d42):_0x3848c5['eventCache']['getNode']()['hasChild'](_0x3edaa9)?_0xde06b4=_0x21874c['filter']['updateChild'](_0x2e5531,_0x3edaa9,g['EMPTY_NODE'],b(_0xf59f62),_0x1ce9c6,_0x4a5d42):_0xde06b4=_0x2e5531,_0xde06b4['isEmpty']()&&_0x3848c5['serverCache']['isFullyInitialized']()&&(_0x49c309=mn(_0x3a006b,Ue(_0x3848c5)),_0x49c309['isLeafNode']()&&(_0xde06b4=_0x21874c['filter']['updateFullNode'](_0xde06b4,_0x49c309,_0x4a5d42)));}return _0x49c309=_0x3848c5['serverCache']['isFullyInitialized']()||yn(_0x3a006b,w())!=null,wt(_0x3848c5,_0xde06b4,_0x49c309,_0x21874c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3ba626,_0x7ecc0d){this['query_']=_0x3ba626,this['eventRegistrations_']=[];const _0x1e5161=this['query_']['_queryParams'],_0x373d34=new Yi(_0x1e5161['getIndex']()),_0x3a3159=qh(_0x1e5161);this['processor_']=wu(_0x3a3159);const _0x23a0c7=_0x7ecc0d['serverCache'],_0x2012c7=_0x7ecc0d['eventCache'],_0x48720c=_0x373d34['updateFullNode'](g['EMPTY_NODE'],_0x23a0c7['getNode'](),null),_0x229983=_0x3a3159['updateFullNode'](g['EMPTY_NODE'],_0x2012c7['getNode'](),null),_0x1120d1=new Ce(_0x48720c,_0x23a0c7['isFullyInitialized'](),_0x373d34['filtersNodes']()),_0x16761d=new Ce(_0x229983,_0x2012c7['isFullyInitialized'](),_0x3a3159['filtersNodes']());this['viewCache_']=Dn(_0x16761d,_0x1120d1),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x416435){return _0x416435['viewCache_']['serverCache']['getNode']();}function Ou(_0x40e1c1){return gn(_0x40e1c1['viewCache_']);}function Du(_0x473b1c,_0x21ab83){const _0x3a923a=Ue(_0x473b1c['viewCache_']);return _0x3a923a&&(_0x473b1c['query']['_queryParams']['loadsAllData']()||!v(_0x21ab83)&&!_0x3a923a['getImmediateChild'](y(_0x21ab83))['isEmpty']())?_0x3a923a['getChild'](_0x21ab83):null;}function lr(_0x27f996){return _0x27f996['eventRegistrations_']['length']===0x0;}function Mu(_0x290737,_0x3e1c6a){_0x290737['eventRegistrations_']['push'](_0x3e1c6a);}function hr(_0x25f825,_0x5c6af7,_0xfd443e){const _0x10aa0c=[];if(_0xfd443e){f(_0x5c6af7==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5cc88e=_0x25f825['query']['_path'];_0x25f825['eventRegistrations_']['forEach'](_0x3ca9ac=>{const _0x1a6bd1=_0x3ca9ac['createCancelEvent'](_0xfd443e,_0x5cc88e);_0x1a6bd1&&_0x10aa0c['push'](_0x1a6bd1);});}if(_0x5c6af7){let _0x4a0f24=[];for(let _0x15ac89=0x0;_0x15ac89<_0x25f825['eventRegistrations_']['length'];++_0x15ac89){const _0x351f97=_0x25f825['eventRegistrations_'][_0x15ac89];if(!_0x351f97['matches'](_0x5c6af7))_0x4a0f24['push'](_0x351f97);else{if(_0x5c6af7['hasAnyCallback']()){_0x4a0f24=_0x4a0f24['concat'](_0x25f825['eventRegistrations_']['slice'](_0x15ac89+0x1));break;}}}_0x25f825['eventRegistrations_']=_0x4a0f24;}else _0x25f825['eventRegistrations_']=[];return _0x10aa0c;}function ur(_0x1b24f0,_0x346c45,_0x2a9d50,_0x4e61d6){_0x346c45['type']===q['MERGE']&&_0x346c45['source']['queryId']!==null&&(f(Ue(_0x1b24f0['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x1b24f0['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3c6415=_0x1b24f0['viewCache_'],_0x276184=Tu(_0x1b24f0['processor_'],_0x3c6415,_0x346c45,_0x2a9d50,_0x4e61d6);return Cu(_0x1b24f0['processor_'],_0x276184['viewCache']),f(_0x276184['viewCache']['serverCache']['isFullyInitialized']()||!_0x3c6415['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1b24f0['viewCache_']=_0x276184['viewCache'],$o(_0x1b24f0,_0x276184['changes'],_0x276184['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x395eb1,_0x389b91){const _0x4e8ee9=_0x395eb1['viewCache_']['eventCache'],_0x306ebb=[];return _0x4e8ee9['getNode']()['isLeafNode']()||_0x4e8ee9['getNode']()['forEachChild'](R,(_0x416a5e,_0x73d77c)=>{_0x306ebb['push'](tt(_0x416a5e,_0x73d77c));}),_0x4e8ee9['isFullyInitialized']()&&_0x306ebb['push'](Oo(_0x4e8ee9['getNode']())),$o(_0x395eb1,_0x306ebb,_0x4e8ee9['getNode'](),_0x389b91);}function $o(_0x16d754,_0x4e266b,_0x51ac1f,_0x32b7e3){const _0x451c1c=_0x32b7e3?[_0x32b7e3]:_0x16d754['eventRegistrations_'];return nu(_0x16d754['eventGenerator_'],_0x4e266b,_0x51ac1f,_0x451c1c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x259bd1){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x259bd1;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x49960e){return _0x49960e['views']['size']===0x0;}function is(_0xbce0dc,_0x2e9ec9,_0x6d4109,_0x1e8523){const _0x36c1bf=_0x2e9ec9['source']['queryId'];if(_0x36c1bf!==null){const _0x1e729c=_0xbce0dc['views']['get'](_0x36c1bf);return f(_0x1e729c!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x1e729c,_0x2e9ec9,_0x6d4109,_0x1e8523);}else{let _0x5485b4=[];for(const _0x135ed1 of _0xbce0dc['views']['values']())_0x5485b4=_0x5485b4['concat'](ur(_0x135ed1,_0x2e9ec9,_0x6d4109,_0x1e8523));return _0x5485b4;}}function qo(_0x5542d6,_0x4661fe,_0x376f07,_0xcac240,_0x307327){const _0x4ead65=_0x4661fe['_queryIdentifier'],_0x3b104e=_0x5542d6['views']['get'](_0x4ead65);if(!_0x3b104e){let _0x359288=mn(_0x376f07,_0x307327?_0xcac240:null),_0x5f221e=!0x1;_0x359288?_0x5f221e=!0x0:_0xcac240 instanceof g?(_0x359288=es(_0x376f07,_0xcac240),_0x5f221e=!0x1):(_0x359288=g['EMPTY_NODE'],_0x5f221e=!0x1);const _0xe60e92=Dn(new Ce(_0x359288,_0x5f221e,!0x1),new Ce(_0xcac240,_0x307327,!0x1));return new Nu(_0x4661fe,_0xe60e92);}return _0x3b104e;}function Wu(_0x1ec2e0,_0x19af33,_0x5826c5,_0x10c31c,_0x3cb3e7,_0x15c7fe){const _0x14d087=qo(_0x1ec2e0,_0x19af33,_0x10c31c,_0x3cb3e7,_0x15c7fe);return _0x1ec2e0['views']['has'](_0x19af33['_queryIdentifier'])||_0x1ec2e0['views']['set'](_0x19af33['_queryIdentifier'],_0x14d087),Mu(_0x14d087,_0x5826c5),Lu(_0x14d087,_0x5826c5);}function Bu(_0x5d7ad9,_0x2c3926,_0x33b912,_0x5b9cb2){const _0xb33110=_0x2c3926['_queryIdentifier'],_0x12adfd=[];let _0x35dc4d=[];const _0x1101d2=Te(_0x5d7ad9);if(_0xb33110==='default'){for(const [_0x55452c,_0x3a992c]of _0x5d7ad9['views']['entries']())_0x35dc4d=_0x35dc4d['concat'](hr(_0x3a992c,_0x33b912,_0x5b9cb2)),lr(_0x3a992c)&&(_0x5d7ad9['views']['delete'](_0x55452c),_0x3a992c['query']['_queryParams']['loadsAllData']()||_0x12adfd['push'](_0x3a992c['query']));}else{const _0x945879=_0x5d7ad9['views']['get'](_0xb33110);_0x945879&&(_0x35dc4d=_0x35dc4d['concat'](hr(_0x945879,_0x33b912,_0x5b9cb2)),lr(_0x945879)&&(_0x5d7ad9['views']['delete'](_0xb33110),_0x945879['query']['_queryParams']['loadsAllData']()||_0x12adfd['push'](_0x945879['query'])));}return _0x1101d2&&!Te(_0x5d7ad9)&&_0x12adfd['push'](new(Fu())(_0x2c3926['_repo'],_0x2c3926['_path'])),{'removed':_0x12adfd,'events':_0x35dc4d};}function zo(_0x32b777){const _0x59ad42=[];for(const _0xf62cac of _0x32b777['views']['values']())_0xf62cac['query']['_queryParams']['loadsAllData']()||_0x59ad42['push'](_0xf62cac);return _0x59ad42;}function Ee(_0x34cafc,_0x3a4483){let _0x4a036c=null;for(const _0x5e31d7 of _0x34cafc['views']['values']())_0x4a036c=_0x4a036c||Du(_0x5e31d7,_0x3a4483);return _0x4a036c;}function jo(_0x375258,_0x4d8aa2){if(_0x4d8aa2['_queryParams']['loadsAllData']())return Ln(_0x375258);{const _0x338b8a=_0x4d8aa2['_queryIdentifier'];return _0x375258['views']['get'](_0x338b8a);}}function Ko(_0x28956f,_0x374c09){return jo(_0x28956f,_0x374c09)!=null;}function Te(_0xffd09b){return Ln(_0xffd09b)!=null;}function Ln(_0x40cc5c){for(const _0x34aae6 of _0x40cc5c['views']['values']())if(_0x34aae6['query']['_queryParams']['loadsAllData']())return _0x34aae6;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1db317){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1db317;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x37a382){this['listenProvider_']=_0x37a382,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x36273c,_0x26f206,_0x3d52cc,_0x31f974,_0x5d1abc){return ou(_0x36273c['pendingWriteTree_'],_0x26f206,_0x3d52cc,_0x31f974,_0x5d1abc),_0x5d1abc?ht(_0x36273c,new Fe(Ji(),_0x26f206,_0x3d52cc)):[];}function Gu(_0x4abc10,_0x4e934c,_0x276042,_0x23d467){au(_0x4abc10['pendingWriteTree_'],_0x4e934c,_0x276042,_0x23d467);const _0x251a78=S['fromObject'](_0x276042);return ht(_0x4abc10,new nt(Ji(),_0x4e934c,_0x251a78));}function pe(_0x30c954,_0x526e78,_0x154d65=!0x1){const _0x40abc1=cu(_0x30c954['pendingWriteTree_'],_0x526e78);if(lu(_0x30c954['pendingWriteTree_'],_0x526e78)){let _0x3686b8=new S(null);return _0x40abc1['snap']!=null?_0x3686b8=_0x3686b8['set'](w(),!0x0):x(_0x40abc1['children'],_0x38d589=>{_0x3686b8=_0x3686b8['set'](new C(_0x38d589),!0x0);}),ht(_0x30c954,new _n(_0x40abc1['path'],_0x3686b8,_0x154d65));}else return[];}function $t(_0x3b5f64,_0x5edf57,_0x269a17){return ht(_0x3b5f64,new Fe(Xi(),_0x5edf57,_0x269a17));}function qu(_0x251bf3,_0x4e92e9,_0x12c5e8){const _0x3833b0=S['fromObject'](_0x12c5e8);return ht(_0x251bf3,new nt(Xi(),_0x4e92e9,_0x3833b0));}function zu(_0x8a5475,_0x468978){return ht(_0x8a5475,new Dt(Xi(),_0x468978));}function ju(_0x376271,_0x501070,_0x4e43ed){const _0x2df29a=rs(_0x376271,_0x4e43ed);if(_0x2df29a){const _0x39bfa3=os(_0x2df29a),_0x30e61b=_0x39bfa3['path'],_0x2db763=_0x39bfa3['queryId'],_0xd7c1d1=F(_0x30e61b,_0x501070),_0x2611ab=new Dt(Zi(_0x2db763),_0xd7c1d1);return as(_0x376271,_0x30e61b,_0x2611ab);}else return[];}function wn(_0x13ace3,_0x4c3542,_0x59882e,_0x2181e8,_0xb4a0c5=!0x1){const _0x44df5b=_0x4c3542['_path'],_0x36374c=_0x13ace3['syncPointTree_']['get'](_0x44df5b);let _0x3b1d09=[];if(_0x36374c&&(_0x4c3542['_queryIdentifier']==='default'||Ko(_0x36374c,_0x4c3542))){const _0x3657d4=Bu(_0x36374c,_0x4c3542,_0x59882e,_0x2181e8);Uu(_0x36374c)&&(_0x13ace3['syncPointTree_']=_0x13ace3['syncPointTree_']['remove'](_0x44df5b));const _0x3801c4=_0x3657d4['removed'];if(_0x3b1d09=_0x3657d4['events'],!_0xb4a0c5){const _0x500461=_0x3801c4['findIndex'](_0x286fb0=>_0x286fb0['_queryParams']['loadsAllData']())!==-0x1,_0x228861=_0x13ace3['syncPointTree_']['findOnPath'](_0x44df5b,(_0x50c7a1,_0x17c0cc)=>Te(_0x17c0cc));if(_0x500461&&!_0x228861){const _0x29656a=_0x13ace3['syncPointTree_']['subtree'](_0x44df5b);if(!_0x29656a['isEmpty']()){const _0x13aa3a=Qu(_0x29656a);for(let _0x6cb16b=0x0;_0x6cb16b<_0x13aa3a['length'];++_0x6cb16b){const _0x4397da=_0x13aa3a[_0x6cb16b],_0x312d9f=_0x4397da['query'],_0x526a4d=Xo(_0x13ace3,_0x4397da);_0x13ace3['listenProvider_']['startListening'](Tt(_0x312d9f),Mt(_0x13ace3,_0x312d9f),_0x526a4d['hashFn'],_0x526a4d['onComplete']);}}}!_0x228861&&_0x3801c4['length']>0x0&&!_0x2181e8&&(_0x500461?_0x13ace3['listenProvider_']['stopListening'](Tt(_0x4c3542),null):_0x3801c4['forEach'](_0x1e3970=>{const _0x599db8=_0x13ace3['queryToTagMap']['get'](Fn(_0x1e3970));_0x13ace3['listenProvider_']['stopListening'](Tt(_0x1e3970),_0x599db8);}));}Ju(_0x13ace3,_0x3801c4);}return _0x3b1d09;}function Yo(_0x33522d,_0x1082ee,_0x3a2ab9,_0x10e1ff){const _0x3ff5a2=rs(_0x33522d,_0x10e1ff);if(_0x3ff5a2!=null){const _0xd52c52=os(_0x3ff5a2),_0x9a78d8=_0xd52c52['path'],_0xdcaf53=_0xd52c52['queryId'],_0x456bba=F(_0x9a78d8,_0x1082ee),_0x5c3444=new Fe(Zi(_0xdcaf53),_0x456bba,_0x3a2ab9);return as(_0x33522d,_0x9a78d8,_0x5c3444);}else return[];}function Ku(_0x1c5a68,_0x48a751,_0x3fb41b,_0x19385d){const _0x38268d=rs(_0x1c5a68,_0x19385d);if(_0x38268d){const _0x54439a=os(_0x38268d),_0x167dfc=_0x54439a['path'],_0x48262f=_0x54439a['queryId'],_0x12656e=F(_0x167dfc,_0x48a751),_0x387690=S['fromObject'](_0x3fb41b),_0x91b756=new nt(Zi(_0x48262f),_0x12656e,_0x387690);return as(_0x1c5a68,_0x167dfc,_0x91b756);}else return[];}function bi(_0x18304a,_0x20b906,_0x2fe048,_0x142ee3=!0x1){const _0x4b963e=_0x20b906['_path'];let _0xc8f10=null,_0x14f13a=!0x1;_0x18304a['syncPointTree_']['foreachOnPath'](_0x4b963e,(_0x470292,_0x55cf7c)=>{const _0xc86d32=F(_0x470292,_0x4b963e);_0xc8f10=_0xc8f10||Ee(_0x55cf7c,_0xc86d32),_0x14f13a=_0x14f13a||Te(_0x55cf7c);});let _0x397970=_0x18304a['syncPointTree_']['get'](_0x4b963e);_0x397970?(_0x14f13a=_0x14f13a||Te(_0x397970),_0xc8f10=_0xc8f10||Ee(_0x397970,w())):(_0x397970=new Go(),_0x18304a['syncPointTree_']=_0x18304a['syncPointTree_']['set'](_0x4b963e,_0x397970));let _0x2ba2cb;_0xc8f10!=null?_0x2ba2cb=!0x0:(_0x2ba2cb=!0x1,_0xc8f10=g['EMPTY_NODE'],_0x18304a['syncPointTree_']['subtree'](_0x4b963e)['foreachChild']((_0x20068a,_0x49de33)=>{const _0x2ad297=Ee(_0x49de33,w());_0x2ad297&&(_0xc8f10=_0xc8f10['updateImmediateChild'](_0x20068a,_0x2ad297));}));const _0x4c71c2=Ko(_0x397970,_0x20b906);if(!_0x4c71c2&&!_0x20b906['_queryParams']['loadsAllData']()){const _0x1ce14a=Fn(_0x20b906);f(!_0x18304a['queryToTagMap']['has'](_0x1ce14a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5e469e=Xu();_0x18304a['queryToTagMap']['set'](_0x1ce14a,_0x5e469e),_0x18304a['tagToQueryMap']['set'](_0x5e469e,_0x1ce14a);}const _0x35a637=Mn(_0x18304a['pendingWriteTree_'],_0x4b963e);let _0x36000f=Wu(_0x397970,_0x20b906,_0x2fe048,_0x35a637,_0xc8f10,_0x2ba2cb);if(!_0x4c71c2&&!_0x14f13a&&!_0x142ee3){const _0x564f27=jo(_0x397970,_0x20b906);_0x36000f=_0x36000f['concat'](Zu(_0x18304a,_0x20b906,_0x564f27));}return _0x36000f;}function xn(_0x1ef878,_0x232af9,_0x2ebab5){const _0x33327b=_0x1ef878['pendingWriteTree_'],_0xf8dddf=_0x1ef878['syncPointTree_']['findOnPath'](_0x232af9,(_0x2c0cfd,_0x494b36)=>{const _0x4484fc=F(_0x2c0cfd,_0x232af9),_0x58b746=Ee(_0x494b36,_0x4484fc);if(_0x58b746)return _0x58b746;});return Uo(_0x33327b,_0x232af9,_0xf8dddf,_0x2ebab5,!0x0);}function Yu(_0x5843b9,_0x2c7670){const _0x59b5b2=_0x2c7670['_path'];let _0x2bf834=null;_0x5843b9['syncPointTree_']['foreachOnPath'](_0x59b5b2,(_0x48cd64,_0x3e6a29)=>{const _0x2b2829=F(_0x48cd64,_0x59b5b2);_0x2bf834=_0x2bf834||Ee(_0x3e6a29,_0x2b2829);});let _0x3fef23=_0x5843b9['syncPointTree_']['get'](_0x59b5b2);_0x3fef23?_0x2bf834=_0x2bf834||Ee(_0x3fef23,w()):(_0x3fef23=new Go(),_0x5843b9['syncPointTree_']=_0x5843b9['syncPointTree_']['set'](_0x59b5b2,_0x3fef23));const _0x3817cd=_0x2bf834!=null,_0x366bfb=_0x3817cd?new Ce(_0x2bf834,!0x0,!0x1):null,_0xbc7558=Mn(_0x5843b9['pendingWriteTree_'],_0x2c7670['_path']),_0x5d4722=qo(_0x3fef23,_0x2c7670,_0xbc7558,_0x3817cd?_0x366bfb['getNode']():g['EMPTY_NODE'],_0x3817cd);return Ou(_0x5d4722);}function ht(_0x19f9e2,_0x151cb5){return Qo(_0x151cb5,_0x19f9e2['syncPointTree_'],null,Mn(_0x19f9e2['pendingWriteTree_'],w()));}function Qo(_0x289e7,_0x5018e4,_0x312506,_0x41cb3a){if(v(_0x289e7['path']))return Jo(_0x289e7,_0x5018e4,_0x312506,_0x41cb3a);{const _0x168d85=_0x5018e4['get'](w());_0x312506==null&&_0x168d85!=null&&(_0x312506=Ee(_0x168d85,w()));let _0x5836ab=[];const _0x2e3d3b=y(_0x289e7['path']),_0x28576c=_0x289e7['operationForChild'](_0x2e3d3b),_0x481932=_0x5018e4['children']['get'](_0x2e3d3b);if(_0x481932&&_0x28576c){const _0x3d1068=_0x312506?_0x312506['getImmediateChild'](_0x2e3d3b):null,_0x589ce7=Wo(_0x41cb3a,_0x2e3d3b);_0x5836ab=_0x5836ab['concat'](Qo(_0x28576c,_0x481932,_0x3d1068,_0x589ce7));}return _0x168d85&&(_0x5836ab=_0x5836ab['concat'](is(_0x168d85,_0x289e7,_0x41cb3a,_0x312506))),_0x5836ab;}}function Jo(_0x2e2c42,_0x47f00e,_0x2cb7a5,_0x5ba4c6){const _0x3f75fa=_0x47f00e['get'](w());_0x2cb7a5==null&&_0x3f75fa!=null&&(_0x2cb7a5=Ee(_0x3f75fa,w()));let _0x3e6830=[];return _0x47f00e['children']['inorderTraversal']((_0x38c5f1,_0x344d07)=>{const _0xaaf293=_0x2cb7a5?_0x2cb7a5['getImmediateChild'](_0x38c5f1):null,_0x41e17c=Wo(_0x5ba4c6,_0x38c5f1),_0x5c361f=_0x2e2c42['operationForChild'](_0x38c5f1);_0x5c361f&&(_0x3e6830=_0x3e6830['concat'](Jo(_0x5c361f,_0x344d07,_0xaaf293,_0x41e17c)));}),_0x3f75fa&&(_0x3e6830=_0x3e6830['concat'](is(_0x3f75fa,_0x2e2c42,_0x5ba4c6,_0x2cb7a5))),_0x3e6830;}function Xo(_0x31cafa,_0x3a669d){const _0x465e53=_0x3a669d['query'],_0x349b76=Mt(_0x31cafa,_0x465e53);return{'hashFn':()=>(Pu(_0x3a669d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3305c0=>{if(_0x3305c0==='ok')return _0x349b76?ju(_0x31cafa,_0x465e53['_path'],_0x349b76):zu(_0x31cafa,_0x465e53['_path']);{const _0x5dd062=ql(_0x3305c0,_0x465e53);return wn(_0x31cafa,_0x465e53,null,_0x5dd062);}}};}function Mt(_0x3789f0,_0x45b723){const _0x7bf7bf=Fn(_0x45b723);return _0x3789f0['queryToTagMap']['get'](_0x7bf7bf);}function Fn(_0x35c20d){return _0x35c20d['_path']['toString']()+'$'+_0x35c20d['_queryIdentifier'];}function rs(_0x468c63,_0xd5e6c8){return _0x468c63['tagToQueryMap']['get'](_0xd5e6c8);}function os(_0x76ba57){const _0x5a43d=_0x76ba57['indexOf']('$');return f(_0x5a43d!==-0x1&&_0x5a43d<_0x76ba57['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x76ba57['substr'](_0x5a43d+0x1),'path':new C(_0x76ba57['substr'](0x0,_0x5a43d))};}function as(_0x588db0,_0xe8a3ba,_0xc9c9bc){const _0x550f66=_0x588db0['syncPointTree_']['get'](_0xe8a3ba);f(_0x550f66,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x35ee3c=Mn(_0x588db0['pendingWriteTree_'],_0xe8a3ba);return is(_0x550f66,_0xc9c9bc,_0x35ee3c,null);}function Qu(_0x1cb13d){return _0x1cb13d['fold']((_0xd65676,_0x73cffb,_0x42b6c7)=>{if(_0x73cffb&&Te(_0x73cffb))return[Ln(_0x73cffb)];{let _0x2b7091=[];return _0x73cffb&&(_0x2b7091=zo(_0x73cffb)),x(_0x42b6c7,(_0x2ca1ce,_0xda4b9a)=>{_0x2b7091=_0x2b7091['concat'](_0xda4b9a);}),_0x2b7091;}});}function Tt(_0x169197){return _0x169197['_queryParams']['loadsAllData']()&&!_0x169197['_queryParams']['isDefault']()?new(Hu())(_0x169197['_repo'],_0x169197['_path']):_0x169197;}function Ju(_0x46cca7,_0xff842d){for(let _0x9af047=0x0;_0x9af047<_0xff842d['length'];++_0x9af047){const _0x44e603=_0xff842d[_0x9af047];if(!_0x44e603['_queryParams']['loadsAllData']()){const _0xb950ed=Fn(_0x44e603),_0x36a285=_0x46cca7['queryToTagMap']['get'](_0xb950ed);_0x46cca7['queryToTagMap']['delete'](_0xb950ed),_0x46cca7['tagToQueryMap']['delete'](_0x36a285);}}}function Xu(){return $u++;}function Zu(_0xf19b81,_0x13a3e9,_0x3e9259){const _0x56f7ea=_0x13a3e9['_path'],_0x2dd682=Mt(_0xf19b81,_0x13a3e9),_0x47ecf2=Xo(_0xf19b81,_0x3e9259),_0x30d3e4=_0xf19b81['listenProvider_']['startListening'](Tt(_0x13a3e9),_0x2dd682,_0x47ecf2['hashFn'],_0x47ecf2['onComplete']),_0x11fcd7=_0xf19b81['syncPointTree_']['subtree'](_0x56f7ea);if(_0x2dd682)f(!Te(_0x11fcd7['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x32ef18=_0x11fcd7['fold']((_0x2727b5,_0x58792c,_0x20595c)=>{if(!v(_0x2727b5)&&_0x58792c&&Te(_0x58792c))return[Ln(_0x58792c)['query']];{let _0x299a57=[];return _0x58792c&&(_0x299a57=_0x299a57['concat'](zo(_0x58792c)['map'](_0x383cae=>_0x383cae['query']))),x(_0x20595c,(_0x34690e,_0x5a5458)=>{_0x299a57=_0x299a57['concat'](_0x5a5458);}),_0x299a57;}});for(let _0x4dcef3=0x0;_0x4dcef3<_0x32ef18['length'];++_0x4dcef3){const _0x46857e=_0x32ef18[_0x4dcef3];_0xf19b81['listenProvider_']['stopListening'](Tt(_0x46857e),Mt(_0xf19b81,_0x46857e));}}return _0x30d3e4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x575e31){this['node_']=_0x575e31;}['getImmediateChild'](_0x2fd0e3){const _0x826143=this['node_']['getImmediateChild'](_0x2fd0e3);return new cs(_0x826143);}['node'](){return this['node_'];}}class ls{constructor(_0x314152,_0x1178b7){this['syncTree_']=_0x314152,this['path_']=_0x1178b7;}['getImmediateChild'](_0x1108e1){const _0x31964e=A(this['path_'],_0x1108e1);return new ls(this['syncTree_'],_0x31964e);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x577d41){return _0x577d41=_0x577d41||{},_0x577d41['timestamp']=_0x577d41['timestamp']||new Date()['getTime'](),_0x577d41;},fr=function(_0x47b802,_0x27f5d7,_0x578a1d){if(!_0x47b802||typeof _0x47b802!='object')return _0x47b802;if(f('.sv'in _0x47b802,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x47b802['.sv']=='string')return td(_0x47b802['.sv'],_0x27f5d7,_0x578a1d);if(typeof _0x47b802['.sv']=='object')return nd(_0x47b802['.sv'],_0x27f5d7);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x47b802,null,0x2));},td=function(_0x3d7baf,_0x2040b2,_0x327bdf){switch(_0x3d7baf){case'timestamp':return _0x327bdf['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3d7baf);}},nd=function(_0x912b27,_0x362e2c,_0x41482d){_0x912b27['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x912b27,null,0x2));const _0x2283ee=_0x912b27['increment'];typeof _0x2283ee!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2283ee);const _0x5443fb=_0x362e2c['node']();if(f(_0x5443fb!==null&&typeof _0x5443fb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5443fb['isLeafNode']())return _0x2283ee;const _0x26b369=_0x5443fb['getValue']();return typeof _0x26b369!='number'?_0x2283ee:_0x26b369+_0x2283ee;},Zo=function(_0x5e2c55,_0x442f5f,_0x150b66,_0x521b72){return us(_0x442f5f,new ls(_0x150b66,_0x5e2c55),_0x521b72);},hs=function(_0x2b62f2,_0x233f3c,_0x36b94e){return us(_0x2b62f2,new cs(_0x233f3c),_0x36b94e);};function us(_0x56dca8,_0x32b315,_0x309fd0){const _0x1d64ba=_0x56dca8['getPriority']()['val'](),_0x27954c=fr(_0x1d64ba,_0x32b315['getImmediateChild']('.priority'),_0x309fd0);let _0x3f0ff3;if(_0x56dca8['isLeafNode']()){const _0x484c86=_0x56dca8,_0x3f0fe2=fr(_0x484c86['getValue'](),_0x32b315,_0x309fd0);return _0x3f0fe2!==_0x484c86['getValue']()||_0x27954c!==_0x484c86['getPriority']()['val']()?new D(_0x3f0fe2,N(_0x27954c)):_0x56dca8;}else{const _0x3990e8=_0x56dca8;return _0x3f0ff3=_0x3990e8,_0x27954c!==_0x3990e8['getPriority']()['val']()&&(_0x3f0ff3=_0x3f0ff3['updatePriority'](new D(_0x27954c))),_0x3990e8['forEachChild'](R,(_0x10c91b,_0x46a040)=>{const _0x58a38e=us(_0x46a040,_0x32b315['getImmediateChild'](_0x10c91b),_0x309fd0);_0x58a38e!==_0x46a040&&(_0x3f0ff3=_0x3f0ff3['updateImmediateChild'](_0x10c91b,_0x58a38e));}),_0x3f0ff3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x2072d8='',_0x1f31bd=null,_0x50d070={'children':{},'childCount':0x0}){this['name']=_0x2072d8,this['parent']=_0x1f31bd,this['node']=_0x50d070;}}function Un(_0x660a07,_0x296285){let _0x4428cc=_0x296285 instanceof C?_0x296285:new C(_0x296285),_0x595263=_0x660a07,_0x383d89=y(_0x4428cc);for(;_0x383d89!==null;){const _0x4bc7b5=Oe(_0x595263['node']['children'],_0x383d89)||{'children':{},'childCount':0x0};_0x595263=new ds(_0x383d89,_0x595263,_0x4bc7b5),_0x4428cc=b(_0x4428cc),_0x383d89=y(_0x4428cc);}return _0x595263;}function Ge(_0x27228d){return _0x27228d['node']['value'];}function fs(_0x49458d,_0xce986a){_0x49458d['node']['value']=_0xce986a,Ri(_0x49458d);}function ea(_0x13e7b9){return _0x13e7b9['node']['childCount']>0x0;}function id(_0x57cd67){return Ge(_0x57cd67)===void 0x0&&!ea(_0x57cd67);}function Wn(_0x2e062c,_0x403c56){x(_0x2e062c['node']['children'],(_0x32bebf,_0x442879)=>{_0x403c56(new ds(_0x32bebf,_0x2e062c,_0x442879));});}function ta(_0x3fc651,_0x28fccd,_0x557063,_0x3824f0){_0x557063&&_0x28fccd(_0x3fc651),Wn(_0x3fc651,_0xbc6b86=>{ta(_0xbc6b86,_0x28fccd,!0x0);});}function sd(_0x4114db,_0x33b14e,_0x1984f8){let _0x3d6a60=_0x4114db['parent'];for(;_0x3d6a60!==null;){if(_0x33b14e(_0x3d6a60))return!0x0;_0x3d6a60=_0x3d6a60['parent'];}return!0x1;}function Gt(_0x425141){return new C(_0x425141['parent']===null?_0x425141['name']:Gt(_0x425141['parent'])+'/'+_0x425141['name']);}function Ri(_0x217cd7){_0x217cd7['parent']!==null&&rd(_0x217cd7['parent'],_0x217cd7['name'],_0x217cd7);}function rd(_0x655349,_0x452ba5,_0x16bfe0){const _0x1d600d=id(_0x16bfe0),_0x29a092=Y(_0x655349['node']['children'],_0x452ba5);_0x1d600d&&_0x29a092?(delete _0x655349['node']['children'][_0x452ba5],_0x655349['node']['childCount']--,Ri(_0x655349)):!_0x1d600d&&!_0x29a092&&(_0x655349['node']['children'][_0x452ba5]=_0x16bfe0['node'],_0x655349['node']['childCount']++,Ri(_0x655349));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x5f8a73){return typeof _0x5f8a73=='string'&&_0x5f8a73['length']!==0x0&&!od['test'](_0x5f8a73);},na=function(_0x3cec02){return typeof _0x3cec02=='string'&&_0x3cec02['length']!==0x0&&!ad['test'](_0x3cec02);},cd=function(_0x1142fa){return _0x1142fa&&(_0x1142fa=_0x1142fa['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x1142fa);},Cn=function(_0x5ce674){return _0x5ce674===null||typeof _0x5ce674=='string'||typeof _0x5ce674=='number'&&!Wi(_0x5ce674)||_0x5ce674&&typeof _0x5ce674=='object'&&Y(_0x5ce674,'.sv');},qt=function(_0x48adf7,_0x434180,_0xe3b84,_0x89ada7){_0x89ada7&&_0x434180===void 0x0||zt(Nn(_0x48adf7,'value'),_0x434180,_0xe3b84);},zt=function(_0x5aae00,_0x4d43e2,_0x39948b){const _0x2b0682=_0x39948b instanceof C?new Sh(_0x39948b,_0x5aae00):_0x39948b;if(_0x4d43e2===void 0x0)throw new Error(_0x5aae00+'contains\x20undefined\x20'+Ne(_0x2b0682));if(typeof _0x4d43e2=='function')throw new Error(_0x5aae00+'contains\x20a\x20function\x20'+Ne(_0x2b0682)+'\x20with\x20contents\x20=\x20'+_0x4d43e2['toString']());if(Wi(_0x4d43e2))throw new Error(_0x5aae00+'contains\x20'+_0x4d43e2['toString']()+'\x20'+Ne(_0x2b0682));if(typeof _0x4d43e2=='string'&&_0x4d43e2['length']>oi/0x3&&Pn(_0x4d43e2)>oi)throw new Error(_0x5aae00+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x2b0682)+'\x20(\x27'+_0x4d43e2['substring'](0x0,0x32)+'...\x27)');if(_0x4d43e2&&typeof _0x4d43e2=='object'){let _0x4b59c1=!0x1,_0xc19a42=!0x1;if(x(_0x4d43e2,(_0x3ce516,_0x242262)=>{if(_0x3ce516==='.value')_0x4b59c1=!0x0;else{if(_0x3ce516!=='.priority'&&_0x3ce516!=='.sv'&&(_0xc19a42=!0x0,!ps(_0x3ce516)))throw new Error(_0x5aae00+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3ce516+')\x20'+Ne(_0x2b0682)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x2b0682,_0x3ce516),zt(_0x5aae00,_0x242262,_0x2b0682),Rh(_0x2b0682);}),_0x4b59c1&&_0xc19a42)throw new Error(_0x5aae00+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2b0682)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x4332b2,_0x130922){let _0x31ba36,_0x15fae8;for(_0x31ba36=0x0;_0x31ba36<_0x130922['length'];_0x31ba36++){_0x15fae8=_0x130922[_0x31ba36];const _0x377e6f=kt(_0x15fae8);for(let _0x5bf224=0x0;_0x5bf224<_0x377e6f['length'];_0x5bf224++)if(!(_0x377e6f[_0x5bf224]==='.priority'&&_0x5bf224===_0x377e6f['length']-0x1)){if(!ps(_0x377e6f[_0x5bf224]))throw new Error(_0x4332b2+'contains\x20an\x20invalid\x20key\x20('+_0x377e6f[_0x5bf224]+')\x20in\x20path\x20'+_0x15fae8['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x130922['sort'](Th);let _0x2107fb=null;for(_0x31ba36=0x0;_0x31ba36<_0x130922['length'];_0x31ba36++){if(_0x15fae8=_0x130922[_0x31ba36],_0x2107fb!==null&&$(_0x2107fb,_0x15fae8))throw new Error(_0x4332b2+'contains\x20a\x20path\x20'+_0x2107fb['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x15fae8['toString']());_0x2107fb=_0x15fae8;}},hd=function(_0x1feb9e,_0x879bba,_0x581eec,_0x2f27c5){const _0x4e2df8=Nn(_0x1feb9e,'values');if(!(_0x879bba&&typeof _0x879bba=='object')||Array['isArray'](_0x879bba))throw new Error(_0x4e2df8+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2d66a1=[];x(_0x879bba,(_0x4a6ef5,_0x56996e)=>{const _0x3aaaab=new C(_0x4a6ef5);if(zt(_0x4e2df8,_0x56996e,A(_0x581eec,_0x3aaaab)),Gi(_0x3aaaab)==='.priority'&&!Cn(_0x56996e))throw new Error(_0x4e2df8+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3aaaab['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2d66a1['push'](_0x3aaaab);}),ld(_0x4e2df8,_0x2d66a1);},_s=function(_0x1770a4,_0x37d14e,_0x21944e,_0x326d34){if(!na(_0x21944e))throw new Error(Nn(_0x1770a4,_0x37d14e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x21944e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x9ace62,_0x46de9b,_0x557a31,_0x42f341){_0x557a31&&(_0x557a31=_0x557a31['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x9ace62,_0x46de9b,_0x557a31);},gs=function(_0x1ac073,_0x3ab21f){if(y(_0x3ab21f)==='.info')throw new Error(_0x1ac073+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1c16d0,_0x78805f){const _0x507eab=_0x78805f['path']['toString']();if(typeof _0x78805f['repoInfo']['host']!='string'||_0x78805f['repoInfo']['host']['length']===0x0||!ps(_0x78805f['repoInfo']['namespace'])&&_0x78805f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x507eab['length']!==0x0&&!cd(_0x507eab))throw new Error(Nn(_0x1c16d0,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x215a1e,_0x1b4e8c){let _0x88260d=null;for(let _0x153453=0x0;_0x153453<_0x1b4e8c['length'];_0x153453++){const _0x2319b8=_0x1b4e8c[_0x153453],_0x305a46=_0x2319b8['getPath']();_0x88260d!==null&&!qi(_0x305a46,_0x88260d['path'])&&(_0x215a1e['eventLists_']['push'](_0x88260d),_0x88260d=null),_0x88260d===null&&(_0x88260d={'events':[],'path':_0x305a46}),_0x88260d['events']['push'](_0x2319b8);}_0x88260d&&_0x215a1e['eventLists_']['push'](_0x88260d);}function ia(_0x525223,_0x847c05,_0x34eedf){Bn(_0x525223,_0x34eedf),sa(_0x525223,_0x2f44a7=>qi(_0x2f44a7,_0x847c05));}function V(_0x154804,_0x557f5e,_0x5cbdac){Bn(_0x154804,_0x5cbdac),sa(_0x154804,_0x36dc2c=>$(_0x36dc2c,_0x557f5e)||$(_0x557f5e,_0x36dc2c));}function sa(_0x386623,_0x4ec614){_0x386623['recursionDepth_']++;let _0x166d31=!0x0;for(let _0x35438a=0x0;_0x35438a<_0x386623['eventLists_']['length'];_0x35438a++){const _0x218561=_0x386623['eventLists_'][_0x35438a];if(_0x218561){const _0xc42d6f=_0x218561['path'];_0x4ec614(_0xc42d6f)?(pd(_0x386623['eventLists_'][_0x35438a]),_0x386623['eventLists_'][_0x35438a]=null):_0x166d31=!0x1;}}_0x166d31&&(_0x386623['eventLists_']=[]),_0x386623['recursionDepth_']--;}function pd(_0x319838){for(let _0x34345c=0x0;_0x34345c<_0x319838['events']['length'];_0x34345c++){const _0x198706=_0x319838['events'][_0x34345c];if(_0x198706!==null){_0x319838['events'][_0x34345c]=null;const _0x44cddb=_0x198706['getEventRunner']();Et&&L('event:\x20'+_0x198706['toString']()),lt(_0x44cddb);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x239b10,_0x2eea9c,_0x2b14c2,_0x4060b0){this['repoInfo_']=_0x239b10,this['forceRestClient_']=_0x2eea9c,this['authTokenProvider_']=_0x2b14c2,this['appCheckProvider_']=_0x4060b0,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x1e67d9,_0x42cef7,_0xab623f){if(_0x1e67d9['stats_']=Hi(_0x1e67d9['repoInfo_']),_0x1e67d9['forceRestClient_']||Yl())_0x1e67d9['server_']=new fn(_0x1e67d9['repoInfo_'],(_0x59f92f,_0x3226e,_0x255a96,_0x220617)=>{pr(_0x1e67d9,_0x59f92f,_0x3226e,_0x255a96,_0x220617);},_0x1e67d9['authTokenProvider_'],_0x1e67d9['appCheckProvider_']),setTimeout(()=>_r(_0x1e67d9,!0x0),0x0);else{if(typeof _0xab623f<'u'&&_0xab623f!==null){if(typeof _0xab623f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xab623f);}catch(_0x4c81c4){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4c81c4);}}_0x1e67d9['persistentConnection_']=new ie(_0x1e67d9['repoInfo_'],_0x42cef7,(_0x49327d,_0x4d307b,_0x323186,_0x19c64b)=>{pr(_0x1e67d9,_0x49327d,_0x4d307b,_0x323186,_0x19c64b);},_0x3b70c8=>{_r(_0x1e67d9,_0x3b70c8);},_0x13c57a=>{yd(_0x1e67d9,_0x13c57a);},_0x1e67d9['authTokenProvider_'],_0x1e67d9['appCheckProvider_'],_0xab623f),_0x1e67d9['server_']=_0x1e67d9['persistentConnection_'];}_0x1e67d9['authTokenProvider_']['addTokenChangeListener'](_0x41190d=>{_0x1e67d9['server_']['refreshAuthToken'](_0x41190d);}),_0x1e67d9['appCheckProvider_']['addTokenChangeListener'](_0x2618b9=>{_0x1e67d9['server_']['refreshAppCheckToken'](_0x2618b9['token']);}),_0x1e67d9['statsReporter_']=eh(_0x1e67d9['repoInfo_'],()=>new eu(_0x1e67d9['stats_'],_0x1e67d9['server_'])),_0x1e67d9['infoData_']=new Yh(),_0x1e67d9['infoSyncTree_']=new dr({'startListening':(_0x2e6e74,_0x46bbdc,_0x501deb,_0x5ba3d3)=>{let _0x3d91bd=[];const _0x45acf0=_0x1e67d9['infoData_']['getNode'](_0x2e6e74['_path']);return _0x45acf0['isEmpty']()||(_0x3d91bd=$t(_0x1e67d9['infoSyncTree_'],_0x2e6e74['_path'],_0x45acf0),setTimeout(()=>{_0x5ba3d3('ok');},0x0)),_0x3d91bd;},'stopListening':()=>{}}),ms(_0x1e67d9,'connected',!0x1),_0x1e67d9['serverSyncTree_']=new dr({'startListening':(_0x5510fd,_0x235767,_0x55c52e,_0x5b527e)=>(_0x1e67d9['server_']['listen'](_0x5510fd,_0x55c52e,_0x235767,(_0x5b7e16,_0x246907)=>{const _0x204b67=_0x5b527e(_0x5b7e16,_0x246907);V(_0x1e67d9['eventQueue_'],_0x5510fd['_path'],_0x204b67);}),[]),'stopListening':(_0x5f396c,_0x7ea170)=>{_0x1e67d9['server_']['unlisten'](_0x5f396c,_0x7ea170);}});}function oa(_0x256c69){const _0x5aaed0=_0x256c69['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5aaed0;}function jt(_0x2c4345){return ed({'timestamp':oa(_0x2c4345)});}function pr(_0x2f5a7a,_0x394911,_0x11f0d3,_0x2d27a0,_0x1eb852){_0x2f5a7a['dataUpdateCount']++;const _0x17fed0=new C(_0x394911);_0x11f0d3=_0x2f5a7a['interceptServerDataCallback_']?_0x2f5a7a['interceptServerDataCallback_'](_0x394911,_0x11f0d3):_0x11f0d3;let _0x125198=[];if(_0x1eb852){if(_0x2d27a0){const _0x4b3e43=ln(_0x11f0d3,_0x38730d=>N(_0x38730d));_0x125198=Ku(_0x2f5a7a['serverSyncTree_'],_0x17fed0,_0x4b3e43,_0x1eb852);}else{const _0x325dfb=N(_0x11f0d3);_0x125198=Yo(_0x2f5a7a['serverSyncTree_'],_0x17fed0,_0x325dfb,_0x1eb852);}}else{if(_0x2d27a0){const _0xd15a80=ln(_0x11f0d3,_0x2b5e27=>N(_0x2b5e27));_0x125198=qu(_0x2f5a7a['serverSyncTree_'],_0x17fed0,_0xd15a80);}else{const _0x495d58=N(_0x11f0d3);_0x125198=$t(_0x2f5a7a['serverSyncTree_'],_0x17fed0,_0x495d58);}}let _0x1699bd=_0x17fed0;_0x125198['length']>0x0&&(_0x1699bd=st(_0x2f5a7a,_0x17fed0)),V(_0x2f5a7a['eventQueue_'],_0x1699bd,_0x125198);}function _r(_0x44fb36,_0x3dc9c9){ms(_0x44fb36,'connected',_0x3dc9c9),_0x3dc9c9===!0x1&&wd(_0x44fb36);}function yd(_0xa1e281,_0x52f0a3){x(_0x52f0a3,(_0x29b3e8,_0xa27e5e)=>{ms(_0xa1e281,_0x29b3e8,_0xa27e5e);});}function ms(_0x429433,_0x12c90b,_0x59ab35){const _0xc895e8=new C('/.info/'+_0x12c90b),_0x21bbac=N(_0x59ab35);_0x429433['infoData_']['updateSnapshot'](_0xc895e8,_0x21bbac);const _0xb2684f=$t(_0x429433['infoSyncTree_'],_0xc895e8,_0x21bbac);V(_0x429433['eventQueue_'],_0xc895e8,_0xb2684f);}function Vn(_0x2b09fd){return _0x2b09fd['nextWriteId_']++;}function vd(_0x38f739,_0x465c62,_0x3682db){const _0x4029f6=Yu(_0x38f739['serverSyncTree_'],_0x465c62);return _0x4029f6!=null?Promise['resolve'](_0x4029f6):_0x38f739['server_']['get'](_0x465c62)['then'](_0x4ec44c=>{const _0x293319=N(_0x4ec44c)['withIndex'](_0x465c62['_queryParams']['getIndex']());bi(_0x38f739['serverSyncTree_'],_0x465c62,_0x3682db,!0x0);let _0x51f71f;if(_0x465c62['_queryParams']['loadsAllData']())_0x51f71f=$t(_0x38f739['serverSyncTree_'],_0x465c62['_path'],_0x293319);else{const _0x4aefb7=Mt(_0x38f739['serverSyncTree_'],_0x465c62);_0x51f71f=Yo(_0x38f739['serverSyncTree_'],_0x465c62['_path'],_0x293319,_0x4aefb7);}return V(_0x38f739['eventQueue_'],_0x465c62['_path'],_0x51f71f),wn(_0x38f739['serverSyncTree_'],_0x465c62,_0x3682db,null,!0x0),_0x293319;},_0x59d0f8=>(ut(_0x38f739,'get\x20for\x20query\x20'+O(_0x465c62)+'\x20failed:\x20'+_0x59d0f8),Promise['reject'](new Error(_0x59d0f8))));}function Ed(_0x2ea858,_0x4e9944,_0x2027a2,_0x1407c4,_0x3524bf){ut(_0x2ea858,'set',{'path':_0x4e9944['toString'](),'value':_0x2027a2,'priority':_0x1407c4});const _0x307264=jt(_0x2ea858),_0x4e62c1=N(_0x2027a2,_0x1407c4),_0x47c857=xn(_0x2ea858['serverSyncTree_'],_0x4e9944),_0x4d6fc4=hs(_0x4e62c1,_0x47c857,_0x307264),_0x5be26b=Vn(_0x2ea858),_0x1d23bf=ss(_0x2ea858['serverSyncTree_'],_0x4e9944,_0x4d6fc4,_0x5be26b,!0x0);Bn(_0x2ea858['eventQueue_'],_0x1d23bf),_0x2ea858['server_']['put'](_0x4e9944['toString'](),_0x4e62c1['val'](!0x0),(_0x4c993b,_0x47ba52)=>{const _0x4a5e18=_0x4c993b==='ok';_0x4a5e18||U('set\x20at\x20'+_0x4e9944+'\x20failed:\x20'+_0x4c993b);const _0x55645f=pe(_0x2ea858['serverSyncTree_'],_0x5be26b,!_0x4a5e18);V(_0x2ea858['eventQueue_'],_0x4e9944,_0x55645f),Ai(_0x2ea858,_0x3524bf,_0x4c993b,_0x47ba52);});const _0x597959=vs(_0x2ea858,_0x4e9944);st(_0x2ea858,_0x597959),V(_0x2ea858['eventQueue_'],_0x597959,[]);}function Id(_0x121b91,_0x3640b0,_0x6f2616,_0x471eef){ut(_0x121b91,'update',{'path':_0x3640b0['toString'](),'value':_0x6f2616});let _0x59d2b1=!0x0;const _0x379b30=jt(_0x121b91),_0x5bc187={};if(x(_0x6f2616,(_0xac5016,_0x3eda86)=>{_0x59d2b1=!0x1,_0x5bc187[_0xac5016]=Zo(A(_0x3640b0,_0xac5016),N(_0x3eda86),_0x121b91['serverSyncTree_'],_0x379b30);}),_0x59d2b1)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x121b91,_0x471eef,'ok',void 0x0);else{const _0x18277a=Vn(_0x121b91),_0x287467=Gu(_0x121b91['serverSyncTree_'],_0x3640b0,_0x5bc187,_0x18277a);Bn(_0x121b91['eventQueue_'],_0x287467),_0x121b91['server_']['merge'](_0x3640b0['toString'](),_0x6f2616,(_0x1b0e90,_0x10f428)=>{const _0x3f2dbe=_0x1b0e90==='ok';_0x3f2dbe||U('update\x20at\x20'+_0x3640b0+'\x20failed:\x20'+_0x1b0e90);const _0x4f070c=pe(_0x121b91['serverSyncTree_'],_0x18277a,!_0x3f2dbe),_0x41f5a3=_0x4f070c['length']>0x0?st(_0x121b91,_0x3640b0):_0x3640b0;V(_0x121b91['eventQueue_'],_0x41f5a3,_0x4f070c),Ai(_0x121b91,_0x471eef,_0x1b0e90,_0x10f428);}),x(_0x6f2616,_0x1b7edb=>{const _0x31e339=vs(_0x121b91,A(_0x3640b0,_0x1b7edb));st(_0x121b91,_0x31e339);}),V(_0x121b91['eventQueue_'],_0x3640b0,[]);}}function wd(_0x4278ac){ut(_0x4278ac,'onDisconnectEvents');const _0x4ebaa8=jt(_0x4278ac),_0xa5060e=pn();Ei(_0x4278ac['onDisconnect_'],w(),(_0x58463a,_0x17a818)=>{const _0x3a835c=Zo(_0x58463a,_0x17a818,_0x4278ac['serverSyncTree_'],_0x4ebaa8);Mo(_0xa5060e,_0x58463a,_0x3a835c);});let _0x2f9411=[];Ei(_0xa5060e,w(),(_0xe3fbc0,_0x306206)=>{_0x2f9411=_0x2f9411['concat']($t(_0x4278ac['serverSyncTree_'],_0xe3fbc0,_0x306206));const _0x291649=vs(_0x4278ac,_0xe3fbc0);st(_0x4278ac,_0x291649);}),_0x4278ac['onDisconnect_']=pn(),V(_0x4278ac['eventQueue_'],w(),_0x2f9411);}function Cd(_0x241723,_0x3d20a1,_0x1d27c1){let _0x3d9bd3;y(_0x3d20a1['_path'])==='.info'?_0x3d9bd3=bi(_0x241723['infoSyncTree_'],_0x3d20a1,_0x1d27c1):_0x3d9bd3=bi(_0x241723['serverSyncTree_'],_0x3d20a1,_0x1d27c1),ia(_0x241723['eventQueue_'],_0x3d20a1['_path'],_0x3d9bd3);}function Td(_0x1bf4a2,_0xfef1e6,_0x3ae24d){let _0x47c625;y(_0xfef1e6['_path'])==='.info'?_0x47c625=wn(_0x1bf4a2['infoSyncTree_'],_0xfef1e6,_0x3ae24d):_0x47c625=wn(_0x1bf4a2['serverSyncTree_'],_0xfef1e6,_0x3ae24d),ia(_0x1bf4a2['eventQueue_'],_0xfef1e6['_path'],_0x47c625);}function aa(_0x36a1c1){_0x36a1c1['persistentConnection_']&&_0x36a1c1['persistentConnection_']['interrupt'](ra);}function Sd(_0x226552){_0x226552['persistentConnection_']&&_0x226552['persistentConnection_']['resume'](ra);}function ut(_0x50937f,..._0x5644b5){let _0x1d8183='';_0x50937f['persistentConnection_']&&(_0x1d8183=_0x50937f['persistentConnection_']['id']+':'),L(_0x1d8183,..._0x5644b5);}function Ai(_0x4064d9,_0x3e560c,_0x4f1e15,_0x28358c){_0x3e560c&&lt(()=>{if(_0x4f1e15==='ok')_0x3e560c(null);else{const _0x2ba06e=(_0x4f1e15||'error')['toUpperCase']();let _0x9a13e3=_0x2ba06e;_0x28358c&&(_0x9a13e3+=':\x20'+_0x28358c);const _0xc81edc=new Error(_0x9a13e3);_0xc81edc['code']=_0x2ba06e,_0x3e560c(_0xc81edc);}});}function bd(_0x437329,_0x14b94f,_0x1ddd68,_0x4ab5e4,_0x27e340,_0x2e8c66){ut(_0x437329,'transaction\x20on\x20'+_0x14b94f);const _0x2686ba={'path':_0x14b94f,'update':_0x1ddd68,'onComplete':_0x4ab5e4,'status':null,'order':to(),'applyLocally':_0x2e8c66,'retryCount':0x0,'unwatcher':_0x27e340,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x210af1=ys(_0x437329,_0x14b94f,void 0x0);_0x2686ba['currentInputSnapshot']=_0x210af1;const _0xa1f683=_0x2686ba['update'](_0x210af1['val']());if(_0xa1f683===void 0x0)_0x2686ba['unwatcher'](),_0x2686ba['currentOutputSnapshotRaw']=null,_0x2686ba['currentOutputSnapshotResolved']=null,_0x2686ba['onComplete']&&_0x2686ba['onComplete'](null,!0x1,_0x2686ba['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0xa1f683,_0x2686ba['path']),_0x2686ba['status']=0x0;const _0x19b816=Un(_0x437329['transactionQueueTree_'],_0x14b94f),_0x4f968c=Ge(_0x19b816)||[];_0x4f968c['push'](_0x2686ba),fs(_0x19b816,_0x4f968c);let _0x29f4b5;typeof _0xa1f683=='object'&&_0xa1f683!==null&&Y(_0xa1f683,'.priority')?(_0x29f4b5=Oe(_0xa1f683,'.priority'),f(Cn(_0x29f4b5),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x29f4b5=(xn(_0x437329['serverSyncTree_'],_0x14b94f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x213046=jt(_0x437329),_0x3ac582=N(_0xa1f683,_0x29f4b5),_0x513743=hs(_0x3ac582,_0x210af1,_0x213046);_0x2686ba['currentOutputSnapshotRaw']=_0x3ac582,_0x2686ba['currentOutputSnapshotResolved']=_0x513743,_0x2686ba['currentWriteId']=Vn(_0x437329);const _0x5efae4=ss(_0x437329['serverSyncTree_'],_0x14b94f,_0x513743,_0x2686ba['currentWriteId'],_0x2686ba['applyLocally']);V(_0x437329['eventQueue_'],_0x14b94f,_0x5efae4),Hn(_0x437329,_0x437329['transactionQueueTree_']);}}function ys(_0x6d336d,_0x53ff4e,_0x21ebed){return xn(_0x6d336d['serverSyncTree_'],_0x53ff4e,_0x21ebed)||g['EMPTY_NODE'];}function Hn(_0x3ee844,_0x42a938=_0x3ee844['transactionQueueTree_']){if(_0x42a938||$n(_0x3ee844,_0x42a938),Ge(_0x42a938)){const _0x4ee908=la(_0x3ee844,_0x42a938);f(_0x4ee908['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4ee908['every'](_0x2d636d=>_0x2d636d['status']===0x0)&&Rd(_0x3ee844,Gt(_0x42a938),_0x4ee908);}else ea(_0x42a938)&&Wn(_0x42a938,_0x3d9ebb=>{Hn(_0x3ee844,_0x3d9ebb);});}function Rd(_0x283b22,_0x1d08a8,_0x42265c){const _0x5b8e69=_0x42265c['map'](_0x5c604a=>_0x5c604a['currentWriteId']),_0x228f5e=ys(_0x283b22,_0x1d08a8,_0x5b8e69);let _0x5929d3=_0x228f5e;const _0x56c3dc=_0x228f5e['hash']();for(let _0x566b49=0x0;_0x566b49<_0x42265c['length'];_0x566b49++){const _0x2eefa3=_0x42265c[_0x566b49];f(_0x2eefa3['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2eefa3['status']=0x1,_0x2eefa3['retryCount']++;const _0xdeaa5b=F(_0x1d08a8,_0x2eefa3['path']);_0x5929d3=_0x5929d3['updateChild'](_0xdeaa5b,_0x2eefa3['currentOutputSnapshotRaw']);}const _0x38aded=_0x5929d3['val'](!0x0),_0x2e58a2=_0x1d08a8;_0x283b22['server_']['put'](_0x2e58a2['toString'](),_0x38aded,_0x2c993d=>{ut(_0x283b22,'transaction\x20put\x20response',{'path':_0x2e58a2['toString'](),'status':_0x2c993d});let _0x2ef37d=[];if(_0x2c993d==='ok'){const _0x1c8ebc=[];for(let _0x2889e7=0x0;_0x2889e7<_0x42265c['length'];_0x2889e7++)_0x42265c[_0x2889e7]['status']=0x2,_0x2ef37d=_0x2ef37d['concat'](pe(_0x283b22['serverSyncTree_'],_0x42265c[_0x2889e7]['currentWriteId'])),_0x42265c[_0x2889e7]['onComplete']&&_0x1c8ebc['push'](()=>_0x42265c[_0x2889e7]['onComplete'](null,!0x0,_0x42265c[_0x2889e7]['currentOutputSnapshotResolved'])),_0x42265c[_0x2889e7]['unwatcher']();$n(_0x283b22,Un(_0x283b22['transactionQueueTree_'],_0x1d08a8)),Hn(_0x283b22,_0x283b22['transactionQueueTree_']),V(_0x283b22['eventQueue_'],_0x1d08a8,_0x2ef37d);for(let _0x693836=0x0;_0x693836<_0x1c8ebc['length'];_0x693836++)lt(_0x1c8ebc[_0x693836]);}else{if(_0x2c993d==='datastale'){for(let _0x3be05a=0x0;_0x3be05a<_0x42265c['length'];_0x3be05a++)_0x42265c[_0x3be05a]['status']===0x3?_0x42265c[_0x3be05a]['status']=0x4:_0x42265c[_0x3be05a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2e58a2['toString']()+'\x20failed:\x20'+_0x2c993d);for(let _0x3bddbd=0x0;_0x3bddbd<_0x42265c['length'];_0x3bddbd++)_0x42265c[_0x3bddbd]['status']=0x4,_0x42265c[_0x3bddbd]['abortReason']=_0x2c993d;}st(_0x283b22,_0x1d08a8);}},_0x56c3dc);}function st(_0x327042,_0x5117f8){const _0x566dd6=ca(_0x327042,_0x5117f8),_0x30a524=Gt(_0x566dd6),_0x5c796c=la(_0x327042,_0x566dd6);return Ad(_0x327042,_0x5c796c,_0x30a524),_0x30a524;}function Ad(_0x18d56f,_0x489500,_0x17962e){if(_0x489500['length']===0x0)return;const _0x284043=[];let _0x32d669=[];const _0x49bf63=_0x489500['filter'](_0x213178=>_0x213178['status']===0x0)['map'](_0x53beda=>_0x53beda['currentWriteId']);for(let _0xa887c5=0x0;_0xa887c5<_0x489500['length'];_0xa887c5++){const _0x28a9c4=_0x489500[_0xa887c5],_0x204c9f=F(_0x17962e,_0x28a9c4['path']);let _0x453473=!0x1,_0x4c25be;if(f(_0x204c9f!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x28a9c4['status']===0x4)_0x453473=!0x0,_0x4c25be=_0x28a9c4['abortReason'],_0x32d669=_0x32d669['concat'](pe(_0x18d56f['serverSyncTree_'],_0x28a9c4['currentWriteId'],!0x0));else{if(_0x28a9c4['status']===0x0){if(_0x28a9c4['retryCount']>=_d)_0x453473=!0x0,_0x4c25be='maxretry',_0x32d669=_0x32d669['concat'](pe(_0x18d56f['serverSyncTree_'],_0x28a9c4['currentWriteId'],!0x0));else{const _0x48c40d=ys(_0x18d56f,_0x28a9c4['path'],_0x49bf63);_0x28a9c4['currentInputSnapshot']=_0x48c40d;const _0x1d071e=_0x489500[_0xa887c5]['update'](_0x48c40d['val']());if(_0x1d071e!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1d071e,_0x28a9c4['path']);let _0x484f9c=N(_0x1d071e);typeof _0x1d071e=='object'&&_0x1d071e!=null&&Y(_0x1d071e,'.priority')||(_0x484f9c=_0x484f9c['updatePriority'](_0x48c40d['getPriority']()));const _0x58d1d9=_0x28a9c4['currentWriteId'],_0x31b5dc=jt(_0x18d56f),_0x1304c8=hs(_0x484f9c,_0x48c40d,_0x31b5dc);_0x28a9c4['currentOutputSnapshotRaw']=_0x484f9c,_0x28a9c4['currentOutputSnapshotResolved']=_0x1304c8,_0x28a9c4['currentWriteId']=Vn(_0x18d56f),_0x49bf63['splice'](_0x49bf63['indexOf'](_0x58d1d9),0x1),_0x32d669=_0x32d669['concat'](ss(_0x18d56f['serverSyncTree_'],_0x28a9c4['path'],_0x1304c8,_0x28a9c4['currentWriteId'],_0x28a9c4['applyLocally'])),_0x32d669=_0x32d669['concat'](pe(_0x18d56f['serverSyncTree_'],_0x58d1d9,!0x0));}else _0x453473=!0x0,_0x4c25be='nodata',_0x32d669=_0x32d669['concat'](pe(_0x18d56f['serverSyncTree_'],_0x28a9c4['currentWriteId'],!0x0));}}}V(_0x18d56f['eventQueue_'],_0x17962e,_0x32d669),_0x32d669=[],_0x453473&&(_0x489500[_0xa887c5]['status']=0x2,function(_0x196594){setTimeout(_0x196594,Math['floor'](0x0));}(_0x489500[_0xa887c5]['unwatcher']),_0x489500[_0xa887c5]['onComplete']&&(_0x4c25be==='nodata'?_0x284043['push'](()=>_0x489500[_0xa887c5]['onComplete'](null,!0x1,_0x489500[_0xa887c5]['currentInputSnapshot'])):_0x284043['push'](()=>_0x489500[_0xa887c5]['onComplete'](new Error(_0x4c25be),!0x1,null))));}$n(_0x18d56f,_0x18d56f['transactionQueueTree_']);for(let _0x5083be=0x0;_0x5083be<_0x284043['length'];_0x5083be++)lt(_0x284043[_0x5083be]);Hn(_0x18d56f,_0x18d56f['transactionQueueTree_']);}function ca(_0x2f50fe,_0x606df6){let _0x544065,_0x4eb1ea=_0x2f50fe['transactionQueueTree_'];for(_0x544065=y(_0x606df6);_0x544065!==null&&Ge(_0x4eb1ea)===void 0x0;)_0x4eb1ea=Un(_0x4eb1ea,_0x544065),_0x606df6=b(_0x606df6),_0x544065=y(_0x606df6);return _0x4eb1ea;}function la(_0x1bc534,_0x59f076){const _0x3a8e15=[];return ha(_0x1bc534,_0x59f076,_0x3a8e15),_0x3a8e15['sort']((_0x2b7753,_0x5b9000)=>_0x2b7753['order']-_0x5b9000['order']),_0x3a8e15;}function ha(_0x36f10e,_0x1f3182,_0x435be8){const _0x585097=Ge(_0x1f3182);if(_0x585097){for(let _0x3429fa=0x0;_0x3429fa<_0x585097['length'];_0x3429fa++)_0x435be8['push'](_0x585097[_0x3429fa]);}Wn(_0x1f3182,_0x406b89=>{ha(_0x36f10e,_0x406b89,_0x435be8);});}function $n(_0x1b3971,_0x541cd1){const _0x5b3b6d=Ge(_0x541cd1);if(_0x5b3b6d){let _0xceb5f=0x0;for(let _0x54f8e9=0x0;_0x54f8e9<_0x5b3b6d['length'];_0x54f8e9++)_0x5b3b6d[_0x54f8e9]['status']!==0x2&&(_0x5b3b6d[_0xceb5f]=_0x5b3b6d[_0x54f8e9],_0xceb5f++);_0x5b3b6d['length']=_0xceb5f,fs(_0x541cd1,_0x5b3b6d['length']>0x0?_0x5b3b6d:void 0x0);}Wn(_0x541cd1,_0x12a3a2=>{$n(_0x1b3971,_0x12a3a2);});}function vs(_0x8fd5ff,_0x46927a){const _0x1914ac=Gt(ca(_0x8fd5ff,_0x46927a)),_0x584678=Un(_0x8fd5ff['transactionQueueTree_'],_0x46927a);return sd(_0x584678,_0x4573d7=>{ai(_0x8fd5ff,_0x4573d7);}),ai(_0x8fd5ff,_0x584678),ta(_0x584678,_0x76042b=>{ai(_0x8fd5ff,_0x76042b);}),_0x1914ac;}function ai(_0x1524bc,_0x3dc792){const _0x305b73=Ge(_0x3dc792);if(_0x305b73){const _0x319c9e=[];let _0x3a39e8=[],_0x43375c=-0x1;for(let _0xb8d2=0x0;_0xb8d2<_0x305b73['length'];_0xb8d2++)_0x305b73[_0xb8d2]['status']===0x3||(_0x305b73[_0xb8d2]['status']===0x1?(f(_0x43375c===_0xb8d2-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x43375c=_0xb8d2,_0x305b73[_0xb8d2]['status']=0x3,_0x305b73[_0xb8d2]['abortReason']='set'):(f(_0x305b73[_0xb8d2]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x305b73[_0xb8d2]['unwatcher'](),_0x3a39e8=_0x3a39e8['concat'](pe(_0x1524bc['serverSyncTree_'],_0x305b73[_0xb8d2]['currentWriteId'],!0x0)),_0x305b73[_0xb8d2]['onComplete']&&_0x319c9e['push'](_0x305b73[_0xb8d2]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x43375c===-0x1?fs(_0x3dc792,void 0x0):_0x305b73['length']=_0x43375c+0x1,V(_0x1524bc['eventQueue_'],Gt(_0x3dc792),_0x3a39e8);for(let _0x64b0e8=0x0;_0x64b0e8<_0x319c9e['length'];_0x64b0e8++)lt(_0x319c9e[_0x64b0e8]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x147ba3){let _0x24ffe1='';const _0x2dd4b1=_0x147ba3['split']('/');for(let _0x3621dc=0x0;_0x3621dc<_0x2dd4b1['length'];_0x3621dc++)if(_0x2dd4b1[_0x3621dc]['length']>0x0){let _0x8782b0=_0x2dd4b1[_0x3621dc];try{_0x8782b0=decodeURIComponent(_0x8782b0['replace'](/\+/g,'\x20'));}catch{}_0x24ffe1+='/'+_0x8782b0;}return _0x24ffe1;}function Nd(_0x348d95){const _0x2aa13f={};_0x348d95['charAt'](0x0)==='?'&&(_0x348d95=_0x348d95['substring'](0x1));for(const _0x29283b of _0x348d95['split']('&')){if(_0x29283b['length']===0x0)continue;const _0x3fcd61=_0x29283b['split']('=');_0x3fcd61['length']===0x2?_0x2aa13f[decodeURIComponent(_0x3fcd61[0x0])]=decodeURIComponent(_0x3fcd61[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x29283b+'\x27\x20in\x20query\x20\x27'+_0x348d95+'\x27');}return _0x2aa13f;}const gr=function(_0x1a5882,_0x104862){const _0x4173d4=Pd(_0x1a5882),_0x22dd67=_0x4173d4['namespace'];_0x4173d4['domain']==='firebase.com'&&oe(_0x4173d4['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x22dd67||_0x22dd67==='undefined')&&_0x4173d4['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4173d4['secure']||Bl();const _0x484727=_0x4173d4['scheme']==='ws'||_0x4173d4['scheme']==='wss';return{'repoInfo':new _o(_0x4173d4['host'],_0x4173d4['secure'],_0x22dd67,_0x484727,_0x104862,'',_0x22dd67!==_0x4173d4['subdomain']),'path':new C(_0x4173d4['pathString'])};},Pd=function(_0x584f89){let _0x2a2c13='',_0x3ab677='',_0x165b6d='',_0x45a55f='',_0x42b1f4='',_0x3a079f=!0x0,_0x405a35='https',_0x634f53=0x1bb;if(typeof _0x584f89=='string'){let _0x3792ca=_0x584f89['indexOf']('//');_0x3792ca>=0x0&&(_0x405a35=_0x584f89['substring'](0x0,_0x3792ca-0x1),_0x584f89=_0x584f89['substring'](_0x3792ca+0x2));let _0x757619=_0x584f89['indexOf']('/');_0x757619===-0x1&&(_0x757619=_0x584f89['length']);let _0x426bc5=_0x584f89['indexOf']('?');_0x426bc5===-0x1&&(_0x426bc5=_0x584f89['length']),_0x2a2c13=_0x584f89['substring'](0x0,Math['min'](_0x757619,_0x426bc5)),_0x757619<_0x426bc5&&(_0x45a55f=kd(_0x584f89['substring'](_0x757619,_0x426bc5)));const _0x4d8f5f=Nd(_0x584f89['substring'](Math['min'](_0x584f89['length'],_0x426bc5)));_0x3792ca=_0x2a2c13['indexOf'](':'),_0x3792ca>=0x0?(_0x3a079f=_0x405a35==='https'||_0x405a35==='wss',_0x634f53=parseInt(_0x2a2c13['substring'](_0x3792ca+0x1),0xa)):_0x3792ca=_0x2a2c13['length'];const _0xc4ba77=_0x2a2c13['slice'](0x0,_0x3792ca);if(_0xc4ba77['toLowerCase']()==='localhost')_0x3ab677='localhost';else{if(_0xc4ba77['split']('.')['length']<=0x2)_0x3ab677=_0xc4ba77;else{const _0x5c774f=_0x2a2c13['indexOf']('.');_0x165b6d=_0x2a2c13['substring'](0x0,_0x5c774f)['toLowerCase'](),_0x3ab677=_0x2a2c13['substring'](_0x5c774f+0x1),_0x42b1f4=_0x165b6d;}}'ns'in _0x4d8f5f&&(_0x42b1f4=_0x4d8f5f['ns']);}return{'host':_0x2a2c13,'port':_0x634f53,'domain':_0x3ab677,'subdomain':_0x165b6d,'secure':_0x3a079f,'scheme':_0x405a35,'pathString':_0x45a55f,'namespace':_0x42b1f4};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x3972c9=0x0;const _0x156ef6=[];return function(_0x401d2d){const _0xf3a9f0=_0x401d2d===_0x3972c9;_0x3972c9=_0x401d2d;let _0x4d0ec0;const _0x1270fd=new Array(0x8);for(_0x4d0ec0=0x7;_0x4d0ec0>=0x0;_0x4d0ec0--)_0x1270fd[_0x4d0ec0]=mr['charAt'](_0x401d2d%0x40),_0x401d2d=Math['floor'](_0x401d2d/0x40);f(_0x401d2d===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3acc27=_0x1270fd['join']('');if(_0xf3a9f0){for(_0x4d0ec0=0xb;_0x4d0ec0>=0x0&&_0x156ef6[_0x4d0ec0]===0x3f;_0x4d0ec0--)_0x156ef6[_0x4d0ec0]=0x0;_0x156ef6[_0x4d0ec0]++;}else{for(_0x4d0ec0=0x0;_0x4d0ec0<0xc;_0x4d0ec0++)_0x156ef6[_0x4d0ec0]=Math['floor'](Math['random']()*0x40);}for(_0x4d0ec0=0x0;_0x4d0ec0<0xc;_0x4d0ec0++)_0x3acc27+=mr['charAt'](_0x156ef6[_0x4d0ec0]);return f(_0x3acc27['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3acc27;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x11104c,_0x4b56da,_0x59da92,_0x2bbccd){this['eventType']=_0x11104c,this['eventRegistration']=_0x4b56da,this['snapshot']=_0x59da92,this['prevName']=_0x2bbccd;}['getPath'](){const _0x15f5f4=this['snapshot']['ref'];return this['eventType']==='value'?_0x15f5f4['_path']:_0x15f5f4['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x51fbb7,_0x30a627,_0x3891a3){this['eventRegistration']=_0x51fbb7,this['error']=_0x30a627,this['path']=_0x3891a3;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x172052,_0x10e361){this['snapshotCallback']=_0x172052,this['cancelCallback']=_0x10e361;}['onValue'](_0x56fe3b,_0x52e3bc){this['snapshotCallback']['call'](null,_0x56fe3b,_0x52e3bc);}['onCancel'](_0x297015){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x297015);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xa546b1){return this['snapshotCallback']===_0xa546b1['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xa546b1['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xa546b1['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x24172f,_0x1dc386,_0x44b995,_0x57a7ff){this['_repo']=_0x24172f,this['_path']=_0x1dc386,this['_queryParams']=_0x44b995,this['_orderByCalled']=_0x57a7ff;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xab2c85=nr(this['_queryParams']),_0x1f55fc=Bi(_0xab2c85);return _0x1f55fc==='{}'?'default':_0x1f55fc;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x77a3f2){if(_0x77a3f2=k(_0x77a3f2),!(_0x77a3f2 instanceof be))return!0x1;const _0x55df4e=this['_repo']===_0x77a3f2['_repo'],_0x43d4be=qi(this['_path'],_0x77a3f2['_path']),_0x1cedeb=this['_queryIdentifier']===_0x77a3f2['_queryIdentifier'];return _0x55df4e&&_0x43d4be&&_0x1cedeb;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x4e7364,_0x4899b0){if(_0x4e7364['_orderByCalled']===!0x0)throw new Error(_0x4899b0+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x46ef65){let _0x8853e5=null,_0x185cd8=null;if(_0x46ef65['hasStart']()&&(_0x8853e5=_0x46ef65['getIndexStartValue']()),_0x46ef65['hasEnd']()&&(_0x185cd8=_0x46ef65['getIndexEndValue']()),_0x46ef65['getIndex']()===ye){const _0x5c4462='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x24eaf3='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x46ef65['hasStart']()){if(_0x46ef65['getIndexStartName']()!==xe)throw new Error(_0x5c4462);if(typeof _0x8853e5!='string')throw new Error(_0x24eaf3);}if(_0x46ef65['hasEnd']()){if(_0x46ef65['getIndexEndName']()!==Ie)throw new Error(_0x5c4462);if(typeof _0x185cd8!='string')throw new Error(_0x24eaf3);}}else{if(_0x46ef65['getIndex']()===R){if(_0x8853e5!=null&&!Cn(_0x8853e5)||_0x185cd8!=null&&!Cn(_0x185cd8))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x46ef65['getIndex']()instanceof Ki||_0x46ef65['getIndex']()===Po,'unknown\x20index\x20type.'),_0x8853e5!=null&&typeof _0x8853e5=='object'||_0x185cd8!=null&&typeof _0x185cd8=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x47aa1e){if(_0x47aa1e['hasStart']()&&_0x47aa1e['hasEnd']()&&_0x47aa1e['hasLimit']()&&!_0x47aa1e['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2c76c7,_0x3b8fc4){super(_0x2c76c7,_0x3b8fc4,new Qi(),!0x1);}get['parent'](){const _0x5d2150=To(this['_path']);return _0x5d2150===null?null:new Z(this['_repo'],_0x5d2150);}get['root'](){let _0x40dd02=this;for(;_0x40dd02['parent']!==null;)_0x40dd02=_0x40dd02['parent'];return _0x40dd02;}}class rt{constructor(_0x1fba23,_0x38c2b4,_0x28da3f){this['_node']=_0x1fba23,this['ref']=_0x38c2b4,this['_index']=_0x28da3f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xc19313){const _0x5e95f7=new C(_0xc19313),_0x1dc399=Lt(this['ref'],_0xc19313);return new rt(this['_node']['getChild'](_0x5e95f7),_0x1dc399,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1eb1c0){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x43c6bd,_0x3b154a)=>_0x1eb1c0(new rt(_0x3b154a,Lt(this['ref'],_0x43c6bd),R)));}['hasChild'](_0x115ff2){const _0x587bb7=new C(_0x115ff2);return!this['_node']['getChild'](_0x587bb7)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x1f0f95,_0x369395){return _0x1f0f95=k(_0x1f0f95),_0x1f0f95['_checkNotDeleted']('ref'),_0x369395!==void 0x0?Lt(_0x1f0f95['_root'],_0x369395):_0x1f0f95['_root'];}function Lt(_0x877942,_0x5d2043){return _0x877942=k(_0x877942),y(_0x877942['_path'])===null?ud('child','path',_0x5d2043):_s('child','path',_0x5d2043),new Z(_0x877942['_repo'],A(_0x877942['_path'],_0x5d2043));}function d_(_0x1e25a2,_0x376396){_0x1e25a2=k(_0x1e25a2),gs('push',_0x1e25a2['_path']),qt('push',_0x376396,_0x1e25a2['_path'],!0x0);const _0x2f4a0d=oa(_0x1e25a2['_repo']),_0x580f17=Od(_0x2f4a0d),_0x2c5ff0=Lt(_0x1e25a2,_0x580f17),_0x5b2dbc=Lt(_0x1e25a2,_0x580f17);let _0x4b745e;return _0x376396!=null?_0x4b745e=Ld(_0x5b2dbc,_0x376396)['then'](()=>_0x5b2dbc):_0x4b745e=Promise['resolve'](_0x5b2dbc),_0x2c5ff0['then']=_0x4b745e['then']['bind'](_0x4b745e),_0x2c5ff0['catch']=_0x4b745e['then']['bind'](_0x4b745e,void 0x0),_0x2c5ff0;}function Ld(_0x174f8b,_0x53b63d){_0x174f8b=k(_0x174f8b),gs('set',_0x174f8b['_path']),qt('set',_0x53b63d,_0x174f8b['_path'],!0x1);const _0x310fc1=new Ve();return Ed(_0x174f8b['_repo'],_0x174f8b['_path'],_0x53b63d,null,_0x310fc1['wrapCallback'](()=>{})),_0x310fc1['promise'];}function f_(_0x947c54,_0x58168d){hd('update',_0x58168d,_0x947c54['_path']);const _0x344b51=new Ve();return Id(_0x947c54['_repo'],_0x947c54['_path'],_0x58168d,_0x344b51['wrapCallback'](()=>{})),_0x344b51['promise'];}function p_(_0x31b438){_0x31b438=k(_0x31b438);const _0x3e114b=new ua(()=>{}),_0x138e2f=new qn(_0x3e114b);return vd(_0x31b438['_repo'],_0x31b438,_0x138e2f)['then'](_0x1efb28=>new rt(_0x1efb28,new Z(_0x31b438['_repo'],_0x31b438['_path']),_0x31b438['_queryParams']['getIndex']()));}class qn{constructor(_0x2efa7f){this['callbackContext']=_0x2efa7f;}['respondsTo'](_0x372f38){return _0x372f38==='value';}['createEvent'](_0x382e1f,_0x4ae5fd){const _0x2205e0=_0x4ae5fd['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x382e1f['snapshotNode'],new Z(_0x4ae5fd['_repo'],_0x4ae5fd['_path']),_0x2205e0));}['getEventRunner'](_0xc78b7b){return _0xc78b7b['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xc78b7b['error']):()=>this['callbackContext']['onValue'](_0xc78b7b['snapshot'],null);}['createCancelEvent'](_0xb2c841,_0x4c46d7){return this['callbackContext']['hasCancelCallback']?new Md(this,_0xb2c841,_0x4c46d7):null;}['matches'](_0x203989){return _0x203989 instanceof qn?!_0x203989['callbackContext']||!this['callbackContext']?!0x0:_0x203989['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x46fe06,_0x5949b7,_0xb42f7b,_0x13c370,_0x25fb47){const _0x5b252b=new ua(_0xb42f7b,void 0x0),_0x2b6dca=new qn(_0x5b252b);return Cd(_0x46fe06['_repo'],_0x46fe06,_0x2b6dca),()=>Td(_0x46fe06['_repo'],_0x46fe06,_0x2b6dca);}function Fd(_0x1437a1,_0x289ce0,_0x24e83a,_0x37cf33){return xd(_0x1437a1,'value',_0x289ce0);}class dt{}class pa extends dt{constructor(_0x2950ab,_0x4e6a55){super(),this['_value']=_0x2950ab,this['_key']=_0x4e6a55,this['type']='endAt';}['_apply'](_0x5668b1){qt('endAt',this['_value'],_0x5668b1['_path'],!0x0);const _0x42c576=Kh(_0x5668b1['_queryParams'],this['_value'],this['_key']);if(fa(_0x42c576),Gn(_0x42c576),_0x5668b1['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x5668b1['_repo'],_0x5668b1['_path'],_0x42c576,_0x5668b1['_orderByCalled']);}}function __(_0x3062df,_0x2f3a7a){return new pa(_0x3062df,_0x2f3a7a);}class _a extends dt{constructor(_0x2ac579,_0x945791){super(),this['_value']=_0x2ac579,this['_key']=_0x945791,this['type']='startAt';}['_apply'](_0x63aae0){qt('startAt',this['_value'],_0x63aae0['_path'],!0x0);const _0x3bc96f=jh(_0x63aae0['_queryParams'],this['_value'],this['_key']);if(fa(_0x3bc96f),Gn(_0x3bc96f),_0x63aae0['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x63aae0['_repo'],_0x63aae0['_path'],_0x3bc96f,_0x63aae0['_orderByCalled']);}}function g_(_0x4a5bab=null,_0x1d7204){return new _a(_0x4a5bab,_0x1d7204);}class Ud extends dt{constructor(_0x14ce2e){super(),this['_limit']=_0x14ce2e,this['type']='limitToFirst';}['_apply'](_0x4c1112){if(_0x4c1112['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x4c1112['_repo'],_0x4c1112['_path'],zh(_0x4c1112['_queryParams'],this['_limit']),_0x4c1112['_orderByCalled']);}}function m_(_0x4b93b4){if(Math['floor'](_0x4b93b4)!==_0x4b93b4||_0x4b93b4<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x4b93b4);}class Wd extends dt{constructor(_0x165ad7){super(),this['_path']=_0x165ad7,this['type']='orderByChild';}['_apply'](_0x5706b2){da(_0x5706b2,'orderByChild');const _0x3f02f3=new C(this['_path']);if(v(_0x3f02f3))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2d0368=new Ki(_0x3f02f3),_0x1986c1=Do(_0x5706b2['_queryParams'],_0x2d0368);return Gn(_0x1986c1),new be(_0x5706b2['_repo'],_0x5706b2['_path'],_0x1986c1,!0x0);}}function y_(_0x5554c5){if(_0x5554c5==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5554c5==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5554c5==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x5554c5),new Wd(_0x5554c5);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x48fb43){da(_0x48fb43,'orderByKey');const _0x22908b=Do(_0x48fb43['_queryParams'],ye);return Gn(_0x22908b),new be(_0x48fb43['_repo'],_0x48fb43['_path'],_0x22908b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x12152f,_0x30ddcf){super(),this['_value']=_0x12152f,this['_key']=_0x30ddcf,this['type']='equalTo';}['_apply'](_0x4ec3c8){if(qt('equalTo',this['_value'],_0x4ec3c8['_path'],!0x1),_0x4ec3c8['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4ec3c8['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x4ec3c8));}}function E_(_0x2f1e79,_0x269428){return new Vd(_0x2f1e79,_0x269428);}function I_(_0x41418a,..._0x169bee){let _0x1b11e2=k(_0x41418a);for(const _0x2817ea of _0x169bee)_0x1b11e2=_0x2817ea['_apply'](_0x1b11e2);return _0x1b11e2;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x21d0af,_0x259589,_0x295823,_0x32f84e){const _0xa1a415=_0x259589['lastIndexOf'](':'),_0x54f906=_0x259589['substring'](0x0,_0xa1a415),_0x5a4903=Wt(_0x54f906);_0x21d0af['repoInfo_']=new _o(_0x259589,_0x5a4903,_0x21d0af['repoInfo_']['namespace'],_0x21d0af['repoInfo_']['webSocketOnly'],_0x21d0af['repoInfo_']['nodeAdmin'],_0x21d0af['repoInfo_']['persistenceKey'],_0x21d0af['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x295823),_0x32f84e&&(_0x21d0af['authTokenProvider_']=_0x32f84e);}function qd(_0x17659e,_0x4b37e0,_0x57f284,_0x6593fe,_0xafedf8){let _0x2960b8=_0x6593fe||_0x17659e['options']['databaseURL'];_0x2960b8===void 0x0&&(_0x17659e['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x17659e['options']['projectId']),_0x2960b8=_0x17659e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x21d8a6=gr(_0x2960b8,_0xafedf8),_0x252c6b=_0x21d8a6['repoInfo'],_0x1e0277;typeof process<'u'&&Us&&(_0x1e0277=Us[Hd]),_0x1e0277?(_0x2960b8='http://'+_0x1e0277+'?ns='+_0x252c6b['namespace'],_0x21d8a6=gr(_0x2960b8,_0xafedf8),_0x252c6b=_0x21d8a6['repoInfo']):_0x21d8a6['repoInfo']['secure'];const _0x3e54ae=new Jl(_0x17659e['name'],_0x17659e['options'],_0x4b37e0);dd('Invalid\x20Firebase\x20Database\x20URL',_0x21d8a6),v(_0x21d8a6['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x26bcfe=jd(_0x252c6b,_0x17659e,_0x3e54ae,new Ql(_0x17659e,_0x57f284));return new Kd(_0x26bcfe,_0x17659e);}function zd(_0x2b339c,_0x212f51){const _0x121aea=ki[_0x212f51];(!_0x121aea||_0x121aea[_0x2b339c['key']]!==_0x2b339c)&&oe('Database\x20'+_0x212f51+'('+_0x2b339c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x2b339c),delete _0x121aea[_0x2b339c['key']];}function jd(_0x135a60,_0x282d95,_0x4fa88f,_0x535a18){let _0x12eb73=ki[_0x282d95['name']];_0x12eb73||(_0x12eb73={},ki[_0x282d95['name']]=_0x12eb73);let _0x4b470a=_0x12eb73[_0x135a60['toURLString']()];return _0x4b470a&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4b470a=new gd(_0x135a60,$d,_0x4fa88f,_0x535a18),_0x12eb73[_0x135a60['toURLString']()]=_0x4b470a,_0x4b470a;}class Kd{constructor(_0x33a2b4,_0x33ff40){this['_repoInternal']=_0x33a2b4,this['app']=_0x33ff40,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x152b71){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x152b71+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x3d05ba=Qr(),_0x50ebdd){const _0xe83b93=Ui(_0x3d05ba,'database')['getImmediate']({'identifier':_0x50ebdd});if(!_0xe83b93['_instanceStarted']){const _0x52cfea=ac('database');_0x52cfea&&Yd(_0xe83b93,..._0x52cfea);}return _0xe83b93;}function Yd(_0x2b1dc8,_0x51cf16,_0x512694,_0x2932ff={}){_0x2b1dc8=k(_0x2b1dc8),_0x2b1dc8['_checkNotDeleted']('useEmulator');const _0x456473=_0x51cf16+':'+_0x512694,_0x4356a9=_0x2b1dc8['_repoInternal'];if(_0x2b1dc8['_instanceStarted']){if(_0x456473===_0x2b1dc8['_repoInternal']['repoInfo_']['host']&&De(_0x2932ff,_0x4356a9['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x47649f;if(_0x4356a9['repoInfo_']['nodeAdmin'])_0x2932ff['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x47649f=new tn(tn['OWNER']);else{if(_0x2932ff['mockUserToken']){const _0xf121e7=typeof _0x2932ff['mockUserToken']=='string'?_0x2932ff['mockUserToken']:cc(_0x2932ff['mockUserToken'],_0x2b1dc8['app']['options']['projectId']);_0x47649f=new tn(_0xf121e7);}}Wt(_0x51cf16)&&jr(_0x51cf16),Gd(_0x4356a9,_0x456473,_0x2932ff,_0x47649f);}function C_(_0x1b4469){_0x1b4469=k(_0x1b4469),_0x1b4469['_checkNotDeleted']('goOffline'),aa(_0x1b4469['_repo']);}function T_(_0x565f52){_0x565f52=k(_0x565f52),_0x565f52['_checkNotDeleted']('goOnline'),Sd(_0x565f52['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x357502){Ll(ct),et(new Me('database',(_0x9ddef4,{instanceIdentifier:_0x3fafc0})=>{const _0x9a4332=_0x9ddef4['getProvider']('app')['getImmediate'](),_0x1497fb=_0x9ddef4['getProvider']('auth-internal'),_0x5d4d4c=_0x9ddef4['getProvider']('app-check-internal');return qd(_0x9a4332,_0x1497fb,_0x5d4d4c,_0x3fafc0);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x357502),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1b29d5,_0x52e4fa){this['committed']=_0x1b29d5,this['snapshot']=_0x52e4fa;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3483d0,_0x36826e,_0x2a005e){if(_0x3483d0=k(_0x3483d0),gs('Reference.transaction',_0x3483d0['_path']),_0x3483d0['key']==='.length'||_0x3483d0['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3483d0['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1e5ae6=!0x0,_0x37791f=new Ve(),_0x34ccf2=(_0x3e0fcc,_0x4822a9,_0x5b043b)=>{let _0x56cf74=null;_0x3e0fcc?_0x37791f['reject'](_0x3e0fcc):(_0x56cf74=new rt(_0x5b043b,new Z(_0x3483d0['_repo'],_0x3483d0['_path']),R),_0x37791f['resolve'](new Xd(_0x4822a9,_0x56cf74)));},_0x19a737=Fd(_0x3483d0,()=>{});return bd(_0x3483d0['_repo'],_0x3483d0['_path'],_0x36826e,_0x34ccf2,_0x19a737,_0x1e5ae6),_0x37791f['promise'];}ie['prototype']['simpleListen']=function(_0x4af45b,_0x55abf1){this['sendRequest']('q',{'p':_0x4af45b},_0x55abf1);},ie['prototype']['echo']=function(_0x35ef0b,_0x3124a5){this['sendRequest']('echo',{'d':_0x35ef0b},_0x3124a5);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0xbe6d89,..._0x57c955){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0xbe6d89,..._0x57c955);}function nn(_0x20927f,..._0x1653cd){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x20927f,..._0x1653cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x401a6e,..._0x1d3af2){throw Es(_0x401a6e,..._0x1d3af2);}function J(_0x45ff54,..._0x5248b1){return Es(_0x45ff54,..._0x5248b1);}function ya(_0x454c38,_0xda6d7f,_0x5dc49c){const _0x3aaa77={...Zd(),[_0xda6d7f]:_0x5dc49c};return new Ut('auth','Firebase',_0x3aaa77)['create'](_0xda6d7f,{'appName':_0x454c38['name']});}function se(_0x4b84ec){return ya(_0x4b84ec,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x69dcef,..._0x523b3b){if(typeof _0x69dcef!='string'){const _0x26e1ed=_0x523b3b[0x0],_0xf6ba3d=[..._0x523b3b['slice'](0x1)];return _0xf6ba3d[0x0]&&(_0xf6ba3d[0x0]['appName']=_0x69dcef['name']),_0x69dcef['_errorFactory']['create'](_0x26e1ed,..._0xf6ba3d);}return ma['create'](_0x69dcef,..._0x523b3b);}function m(_0x3a2687,_0x11415f,..._0x1905f9){if(!_0x3a2687)throw Es(_0x11415f,..._0x1905f9);}function te(_0x7a79d0){const _0x3fac32='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x7a79d0;throw nn(_0x3fac32),new Error(_0x3fac32);}function ae(_0x3742a8,_0x45f792){_0x3742a8||te(_0x45f792);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0xb488bf;return typeof self<'u'&&((_0xb488bf=self['location'])==null?void 0x0:_0xb488bf['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1a0122;return typeof self<'u'&&((_0x1a0122=self['location'])==null?void 0x0:_0x1a0122['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x1d6fb4=navigator;return _0x1d6fb4['languages']&&_0x1d6fb4['languages'][0x0]||_0x1d6fb4['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x392ceb,_0xee7259){this['shortDelay']=_0x392ceb,this['longDelay']=_0xee7259,ae(_0xee7259>_0x392ceb,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x4bb427,_0x4a43cd){ae(_0x4bb427['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x45db8e}=_0x4bb427['emulator'];return _0x4a43cd?''+_0x45db8e+(_0x4a43cd['startsWith']('/')?_0x4a43cd['slice'](0x1):_0x4a43cd):_0x45db8e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x46793b,_0x10286e,_0x20b0ca){this['fetchImpl']=_0x46793b,_0x10286e&&(this['headersImpl']=_0x10286e),_0x20b0ca&&(this['responseImpl']=_0x20b0ca);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x189113,_0xc86737){return _0x189113['tenantId']&&!_0xc86737['tenantId']?{..._0xc86737,'tenantId':_0x189113['tenantId']}:_0xc86737;}async function Ae(_0x4913d5,_0xbc29af,_0x526d7f,_0x50c182,_0x4b7e8f={}){return Ea(_0x4913d5,_0x4b7e8f,async()=>{let _0x24a6dd={},_0xa57d6f={};_0x50c182&&(_0xbc29af==='GET'?_0xa57d6f=_0x50c182:_0x24a6dd={'body':JSON['stringify'](_0x50c182)});const _0x5a5853=at({..._0xa57d6f,'key':_0x4913d5['config']['apiKey']})['slice'](0x1),_0x30e56e=await _0x4913d5['_getAdditionalHeaders']();_0x30e56e['Content-Type']='application/json',_0x4913d5['languageCode']&&(_0x30e56e['X-Firebase-Locale']=_0x4913d5['languageCode']);const _0x1cdf52={'method':_0xbc29af,'headers':_0x30e56e,..._0x24a6dd};return lc()||(_0x1cdf52['referrerPolicy']='strict-origin-when-cross-origin'),_0x4913d5['emulatorConfig']&&Wt(_0x4913d5['emulatorConfig']['host'])&&(_0x1cdf52['credentials']='include'),va['fetch']()(await Ia(_0x4913d5,_0x4913d5['config']['apiHost'],_0x526d7f,_0x5a5853),_0x1cdf52);});}async function Ea(_0x45e0c2,_0x131b54,_0x41989d){_0x45e0c2['_canInitEmulator']=!0x1;const _0x489e78={...rf,..._0x131b54};try{const _0x21eb2d=new lf(_0x45e0c2),_0x4b1a82=await Promise['race']([_0x41989d(),_0x21eb2d['promise']]);_0x21eb2d['clearNetworkTimeout']();const _0x3ac1de=await _0x4b1a82['json']();if('needConfirmation'in _0x3ac1de)throw en(_0x45e0c2,'account-exists-with-different-credential',_0x3ac1de);if(_0x4b1a82['ok']&&!('errorMessage'in _0x3ac1de))return _0x3ac1de;{const _0x10b96c=_0x4b1a82['ok']?_0x3ac1de['errorMessage']:_0x3ac1de['error']['message'],[_0x6c1eb8,_0x5f0474]=_0x10b96c['split']('\x20:\x20');if(_0x6c1eb8==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x45e0c2,'credential-already-in-use',_0x3ac1de);if(_0x6c1eb8==='EMAIL_EXISTS')throw en(_0x45e0c2,'email-already-in-use',_0x3ac1de);if(_0x6c1eb8==='USER_DISABLED')throw en(_0x45e0c2,'user-disabled',_0x3ac1de);const _0x4decd3=_0x489e78[_0x6c1eb8]||_0x6c1eb8['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5f0474)throw ya(_0x45e0c2,_0x4decd3,_0x5f0474);K(_0x45e0c2,_0x4decd3);}}catch(_0x22c793){if(_0x22c793 instanceof Se)throw _0x22c793;K(_0x45e0c2,'network-request-failed',{'message':String(_0x22c793)});}}async function Yt(_0x3f5239,_0x4b2df4,_0x52dba1,_0x41302e,_0x2ffe13={}){const _0x39f491=await Ae(_0x3f5239,_0x4b2df4,_0x52dba1,_0x41302e,_0x2ffe13);return'mfaPendingCredential'in _0x39f491&&K(_0x3f5239,'multi-factor-auth-required',{'_serverResponse':_0x39f491}),_0x39f491;}async function Ia(_0x3f7f33,_0x28b50c,_0x2d9e42,_0x2cb21f){const _0x27809e=''+_0x28b50c+_0x2d9e42+'?'+_0x2cb21f,_0x12832a=_0x3f7f33,_0x498c74=_0x12832a['config']['emulator']?Is(_0x3f7f33['config'],_0x27809e):_0x3f7f33['config']['apiScheme']+'://'+_0x27809e;return of['includes'](_0x2d9e42)&&(await _0x12832a['_persistenceManagerAvailable'],_0x12832a['_getPersistenceType']()==='COOKIE')?_0x12832a['_getPersistence']()['_getFinalTarget'](_0x498c74)['toString']():_0x498c74;}function cf(_0x340309){switch(_0x340309){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1cc746){this['auth']=_0x1cc746,this['timer']=null,this['promise']=new Promise((_0x209632,_0x3cadec)=>{this['timer']=setTimeout(()=>_0x3cadec(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x50a5f8,_0x3f7135,_0x2691be){const _0x1642ee={'appName':_0x50a5f8['name']};_0x2691be['email']&&(_0x1642ee['email']=_0x2691be['email']),_0x2691be['phoneNumber']&&(_0x1642ee['phoneNumber']=_0x2691be['phoneNumber']);const _0x2cf8fe=J(_0x50a5f8,_0x3f7135,_0x1642ee);return _0x2cf8fe['customData']['_tokenResponse']=_0x2691be,_0x2cf8fe;}function vr(_0x3e4035){return _0x3e4035!==void 0x0&&_0x3e4035['enterprise']!==void 0x0;}class hf{constructor(_0x4f568e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4f568e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4f568e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4f568e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x69d977){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x4eddf4 of this['recaptchaEnforcementState'])if(_0x4eddf4['provider']&&_0x4eddf4['provider']===_0x69d977)return cf(_0x4eddf4['enforcementState']);return null;}['isProviderEnabled'](_0x3f4a31){return this['getProviderEnforcementState'](_0x3f4a31)==='ENFORCE'||this['getProviderEnforcementState'](_0x3f4a31)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0xac7b6c,_0x403a20){return Ae(_0xac7b6c,'GET','/v2/recaptchaConfig',Re(_0xac7b6c,_0x403a20));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x16c1fd,_0x55b34b){return Ae(_0x16c1fd,'POST','/v1/accounts:delete',_0x55b34b);}async function Sn(_0x870a01,_0x23b3dc){return Ae(_0x870a01,'POST','/v1/accounts:lookup',_0x23b3dc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x198cb9){if(_0x198cb9)try{const _0x2d0b60=new Date(Number(_0x198cb9));if(!isNaN(_0x2d0b60['getTime']()))return _0x2d0b60['toUTCString']();}catch{}}async function ff(_0x3338b0,_0x1392cf=!0x1){const _0x312ca7=k(_0x3338b0),_0xbe2e9d=await _0x312ca7['getIdToken'](_0x1392cf),_0x4cb9a7=ws(_0xbe2e9d);m(_0x4cb9a7&&_0x4cb9a7['exp']&&_0x4cb9a7['auth_time']&&_0x4cb9a7['iat'],_0x312ca7['auth'],'internal-error');const _0x33b106=typeof _0x4cb9a7['firebase']=='object'?_0x4cb9a7['firebase']:void 0x0,_0x1967a9=_0x33b106==null?void 0x0:_0x33b106['sign_in_provider'];return{'claims':_0x4cb9a7,'token':_0xbe2e9d,'authTime':St(ci(_0x4cb9a7['auth_time'])),'issuedAtTime':St(ci(_0x4cb9a7['iat'])),'expirationTime':St(ci(_0x4cb9a7['exp'])),'signInProvider':_0x1967a9||null,'signInSecondFactor':(_0x33b106==null?void 0x0:_0x33b106['sign_in_second_factor'])||null};}function ci(_0x307df7){return Number(_0x307df7)*0x3e8;}function ws(_0x2379db){const [_0x19fc85,_0x4cc9cb,_0x34073c]=_0x2379db['split']('.');if(_0x19fc85===void 0x0||_0x4cc9cb===void 0x0||_0x34073c===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4321ea=cn(_0x4cc9cb);return _0x4321ea?JSON['parse'](_0x4321ea):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5c0a00){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5c0a00==null?void 0x0:_0x5c0a00['toString']()),null;}}function Er(_0x157d71){const _0x10027f=ws(_0x157d71);return m(_0x10027f,'internal-error'),m(typeof _0x10027f['exp']<'u','internal-error'),m(typeof _0x10027f['iat']<'u','internal-error'),Number(_0x10027f['exp'])-Number(_0x10027f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x5af786,_0x1b3613,_0x15f4e5=!0x1){if(_0x15f4e5)return _0x1b3613;try{return await _0x1b3613;}catch(_0x8653bc){throw _0x8653bc instanceof Se&&pf(_0x8653bc)&&_0x5af786['auth']['currentUser']===_0x5af786&&await _0x5af786['auth']['signOut'](),_0x8653bc;}}function pf({code:_0xd0de8}){return _0xd0de8==='auth/user-disabled'||_0xd0de8==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xae1e87){this['user']=_0xae1e87,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x8d2628){if(_0x8d2628){const _0x536ad5=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x536ad5;}else{this['errorBackoff']=0x7530;const _0x56d064=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x56d064);}}['schedule'](_0x208a3a=!0x1){if(!this['isRunning'])return;const _0x3afb68=this['getInterval'](_0x208a3a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3afb68);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x234226){(_0x234226==null?void 0x0:_0x234226['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5d86d6,_0x1a5f11){this['createdAt']=_0x5d86d6,this['lastLoginAt']=_0x1a5f11,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x1bdf1c){this['createdAt']=_0x1bdf1c['createdAt'],this['lastLoginAt']=_0x1bdf1c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x48edbf){var _0x298eec;const _0x5498c3=_0x48edbf['auth'],_0x17dab7=await _0x48edbf['getIdToken'](),_0x1d0359=await xt(_0x48edbf,Sn(_0x5498c3,{'idToken':_0x17dab7}));m(_0x1d0359==null?void 0x0:_0x1d0359['users']['length'],_0x5498c3,'internal-error');const _0x178c89=_0x1d0359['users'][0x0];_0x48edbf['_notifyReloadListener'](_0x178c89);const _0x1523b2=(_0x298eec=_0x178c89['providerUserInfo'])!=null&&_0x298eec['length']?wa(_0x178c89['providerUserInfo']):[],_0x399940=mf(_0x48edbf['providerData'],_0x1523b2),_0x1dada4=_0x48edbf['isAnonymous'],_0x59622c=!(_0x48edbf['email']&&_0x178c89['passwordHash'])&&!(_0x399940!=null&&_0x399940['length']),_0x1363c7=_0x1dada4?_0x59622c:!0x1,_0x5e77ac={'uid':_0x178c89['localId'],'displayName':_0x178c89['displayName']||null,'photoURL':_0x178c89['photoUrl']||null,'email':_0x178c89['email']||null,'emailVerified':_0x178c89['emailVerified']||!0x1,'phoneNumber':_0x178c89['phoneNumber']||null,'tenantId':_0x178c89['tenantId']||null,'providerData':_0x399940,'metadata':new Pi(_0x178c89['createdAt'],_0x178c89['lastLoginAt']),'isAnonymous':_0x1363c7};Object['assign'](_0x48edbf,_0x5e77ac);}async function gf(_0x549c34){const _0x1f937c=k(_0x549c34);await bn(_0x1f937c),await _0x1f937c['auth']['_persistUserIfCurrent'](_0x1f937c),_0x1f937c['auth']['_notifyListenersIfCurrent'](_0x1f937c);}function mf(_0x4c2438,_0x1a396b){return[..._0x4c2438['filter'](_0xf86e8f=>!_0x1a396b['some'](_0x304769=>_0x304769['providerId']===_0xf86e8f['providerId'])),..._0x1a396b];}function wa(_0x7980e0){return _0x7980e0['map'](({providerId:_0x420e65,..._0x4e3e43})=>({'providerId':_0x420e65,'uid':_0x4e3e43['rawId']||'','displayName':_0x4e3e43['displayName']||null,'email':_0x4e3e43['email']||null,'phoneNumber':_0x4e3e43['phoneNumber']||null,'photoURL':_0x4e3e43['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x303c6c,_0xac19a1){const _0x91db7b=await Ea(_0x303c6c,{},async()=>{const _0x2a009c=at({'grant_type':'refresh_token','refresh_token':_0xac19a1})['slice'](0x1),{tokenApiHost:_0x187384,apiKey:_0x2a037d}=_0x303c6c['config'],_0x2f829a=await Ia(_0x303c6c,_0x187384,'/v1/token','key='+_0x2a037d),_0x31aa0b=await _0x303c6c['_getAdditionalHeaders']();_0x31aa0b['Content-Type']='application/x-www-form-urlencoded';const _0x3264e8={'method':'POST','headers':_0x31aa0b,'body':_0x2a009c};return _0x303c6c['emulatorConfig']&&Wt(_0x303c6c['emulatorConfig']['host'])&&(_0x3264e8['credentials']='include'),va['fetch']()(_0x2f829a,_0x3264e8);});return{'accessToken':_0x91db7b['access_token'],'expiresIn':_0x91db7b['expires_in'],'refreshToken':_0x91db7b['refresh_token']};}async function vf(_0x25a0d5,_0x42d73b){return Ae(_0x25a0d5,'POST','/v2/accounts:revokeToken',Re(_0x25a0d5,_0x42d73b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x474710){m(_0x474710['idToken'],'internal-error'),m(typeof _0x474710['idToken']<'u','internal-error'),m(typeof _0x474710['refreshToken']<'u','internal-error');const _0xd52624='expiresIn'in _0x474710&&typeof _0x474710['expiresIn']<'u'?Number(_0x474710['expiresIn']):Er(_0x474710['idToken']);this['updateTokensAndExpiration'](_0x474710['idToken'],_0x474710['refreshToken'],_0xd52624);}['updateFromIdToken'](_0x32b700){m(_0x32b700['length']!==0x0,'internal-error');const _0x57b917=Er(_0x32b700);this['updateTokensAndExpiration'](_0x32b700,null,_0x57b917);}async['getToken'](_0x42f399,_0x4045b5=!0x1){return!_0x4045b5&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x42f399,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x42f399,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x12540e,_0x47f2df){const {accessToken:_0x3f9b34,refreshToken:_0x5a7eba,expiresIn:_0x175aa8}=await yf(_0x12540e,_0x47f2df);this['updateTokensAndExpiration'](_0x3f9b34,_0x5a7eba,Number(_0x175aa8));}['updateTokensAndExpiration'](_0x2291aa,_0x2b97c6,_0xa4f624){this['refreshToken']=_0x2b97c6||null,this['accessToken']=_0x2291aa||null,this['expirationTime']=Date['now']()+_0xa4f624*0x3e8;}static['fromJSON'](_0x1d7ff0,_0x3a3bdd){const {refreshToken:_0x460a02,accessToken:_0xe8a66d,expirationTime:_0x3d4836}=_0x3a3bdd,_0x500c63=new Je();return _0x460a02&&(m(typeof _0x460a02=='string','internal-error',{'appName':_0x1d7ff0}),_0x500c63['refreshToken']=_0x460a02),_0xe8a66d&&(m(typeof _0xe8a66d=='string','internal-error',{'appName':_0x1d7ff0}),_0x500c63['accessToken']=_0xe8a66d),_0x3d4836&&(m(typeof _0x3d4836=='number','internal-error',{'appName':_0x1d7ff0}),_0x500c63['expirationTime']=_0x3d4836),_0x500c63;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4be164){this['accessToken']=_0x4be164['accessToken'],this['refreshToken']=_0x4be164['refreshToken'],this['expirationTime']=_0x4be164['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x4c1cf6,_0x5e47ef){m(typeof _0x4c1cf6=='string'||typeof _0x4c1cf6>'u','internal-error',{'appName':_0x5e47ef});}class z{constructor({uid:_0x22a19d,auth:_0x349029,stsTokenManager:_0x4ee95c,..._0x5bd7dc}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x22a19d,this['auth']=_0x349029,this['stsTokenManager']=_0x4ee95c,this['accessToken']=_0x4ee95c['accessToken'],this['displayName']=_0x5bd7dc['displayName']||null,this['email']=_0x5bd7dc['email']||null,this['emailVerified']=_0x5bd7dc['emailVerified']||!0x1,this['phoneNumber']=_0x5bd7dc['phoneNumber']||null,this['photoURL']=_0x5bd7dc['photoURL']||null,this['isAnonymous']=_0x5bd7dc['isAnonymous']||!0x1,this['tenantId']=_0x5bd7dc['tenantId']||null,this['providerData']=_0x5bd7dc['providerData']?[..._0x5bd7dc['providerData']]:[],this['metadata']=new Pi(_0x5bd7dc['createdAt']||void 0x0,_0x5bd7dc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x58d721){const _0x27539b=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x58d721));return m(_0x27539b,this['auth'],'internal-error'),this['accessToken']!==_0x27539b&&(this['accessToken']=_0x27539b,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x27539b;}['getIdTokenResult'](_0x3a15fe){return ff(this,_0x3a15fe);}['reload'](){return gf(this);}['_assign'](_0x367cc2){this!==_0x367cc2&&(m(this['uid']===_0x367cc2['uid'],this['auth'],'internal-error'),this['displayName']=_0x367cc2['displayName'],this['photoURL']=_0x367cc2['photoURL'],this['email']=_0x367cc2['email'],this['emailVerified']=_0x367cc2['emailVerified'],this['phoneNumber']=_0x367cc2['phoneNumber'],this['isAnonymous']=_0x367cc2['isAnonymous'],this['tenantId']=_0x367cc2['tenantId'],this['providerData']=_0x367cc2['providerData']['map'](_0x7d8b98=>({..._0x7d8b98})),this['metadata']['_copy'](_0x367cc2['metadata']),this['stsTokenManager']['_assign'](_0x367cc2['stsTokenManager']));}['_clone'](_0x4b3457){const _0x4de8e5=new z({...this,'auth':_0x4b3457,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4de8e5['metadata']['_copy'](this['metadata']),_0x4de8e5;}['_onReload'](_0x445777){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x445777,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2184b3){this['reloadListener']?this['reloadListener'](_0x2184b3):this['reloadUserInfo']=_0x2184b3;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x255ad4,_0x1cde4e=!0x1){let _0x8f9660=!0x1;_0x255ad4['idToken']&&_0x255ad4['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x255ad4),_0x8f9660=!0x0),_0x1cde4e&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x8f9660&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x56a8fc=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x56a8fc})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x195cb2=>({..._0x195cb2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x404759,_0x2c9914){const _0x3829b6=_0x2c9914['displayName']??void 0x0,_0x3771bd=_0x2c9914['email']??void 0x0,_0x301112=_0x2c9914['phoneNumber']??void 0x0,_0x1e2ac4=_0x2c9914['photoURL']??void 0x0,_0x2a48c1=_0x2c9914['tenantId']??void 0x0,_0x3f9eda=_0x2c9914['_redirectEventId']??void 0x0,_0x3330e7=_0x2c9914['createdAt']??void 0x0,_0x2fdbb2=_0x2c9914['lastLoginAt']??void 0x0,{uid:_0x4dc021,emailVerified:_0x3ac7bf,isAnonymous:_0x364795,providerData:_0x2eb872,stsTokenManager:_0x59e31d}=_0x2c9914;m(_0x4dc021&&_0x59e31d,_0x404759,'internal-error');const _0x2402cb=Je['fromJSON'](this['name'],_0x59e31d);m(typeof _0x4dc021=='string',_0x404759,'internal-error'),ce(_0x3829b6,_0x404759['name']),ce(_0x3771bd,_0x404759['name']),m(typeof _0x3ac7bf=='boolean',_0x404759,'internal-error'),m(typeof _0x364795=='boolean',_0x404759,'internal-error'),ce(_0x301112,_0x404759['name']),ce(_0x1e2ac4,_0x404759['name']),ce(_0x2a48c1,_0x404759['name']),ce(_0x3f9eda,_0x404759['name']),ce(_0x3330e7,_0x404759['name']),ce(_0x2fdbb2,_0x404759['name']);const _0x2a07e7=new z({'uid':_0x4dc021,'auth':_0x404759,'email':_0x3771bd,'emailVerified':_0x3ac7bf,'displayName':_0x3829b6,'isAnonymous':_0x364795,'photoURL':_0x1e2ac4,'phoneNumber':_0x301112,'tenantId':_0x2a48c1,'stsTokenManager':_0x2402cb,'createdAt':_0x3330e7,'lastLoginAt':_0x2fdbb2});return _0x2eb872&&Array['isArray'](_0x2eb872)&&(_0x2a07e7['providerData']=_0x2eb872['map'](_0x4ab9f0=>({..._0x4ab9f0}))),_0x3f9eda&&(_0x2a07e7['_redirectEventId']=_0x3f9eda),_0x2a07e7;}static async['_fromIdTokenResponse'](_0x39431b,_0x59aa44,_0x34455a=!0x1){const _0x3537e4=new Je();_0x3537e4['updateFromServerResponse'](_0x59aa44);const _0x1583d5=new z({'uid':_0x59aa44['localId'],'auth':_0x39431b,'stsTokenManager':_0x3537e4,'isAnonymous':_0x34455a});return await bn(_0x1583d5),_0x1583d5;}static async['_fromGetAccountInfoResponse'](_0x311135,_0x2cf26a,_0x2037f3){const _0xe7eafc=_0x2cf26a['users'][0x0];m(_0xe7eafc['localId']!==void 0x0,'internal-error');const _0x518417=_0xe7eafc['providerUserInfo']!==void 0x0?wa(_0xe7eafc['providerUserInfo']):[],_0x31cc91=!(_0xe7eafc['email']&&_0xe7eafc['passwordHash'])&&!(_0x518417!=null&&_0x518417['length']),_0x6629d8=new Je();_0x6629d8['updateFromIdToken'](_0x2037f3);const _0x131961=new z({'uid':_0xe7eafc['localId'],'auth':_0x311135,'stsTokenManager':_0x6629d8,'isAnonymous':_0x31cc91}),_0x4489f2={'uid':_0xe7eafc['localId'],'displayName':_0xe7eafc['displayName']||null,'photoURL':_0xe7eafc['photoUrl']||null,'email':_0xe7eafc['email']||null,'emailVerified':_0xe7eafc['emailVerified']||!0x1,'phoneNumber':_0xe7eafc['phoneNumber']||null,'tenantId':_0xe7eafc['tenantId']||null,'providerData':_0x518417,'metadata':new Pi(_0xe7eafc['createdAt'],_0xe7eafc['lastLoginAt']),'isAnonymous':!(_0xe7eafc['email']&&_0xe7eafc['passwordHash'])&&!(_0x518417!=null&&_0x518417['length'])};return Object['assign'](_0x131961,_0x4489f2),_0x131961;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x20d2d8){ae(_0x20d2d8 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1e6900=Ir['get'](_0x20d2d8);return _0x1e6900?(ae(_0x1e6900 instanceof _0x20d2d8,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1e6900):(_0x1e6900=new _0x20d2d8(),Ir['set'](_0x20d2d8,_0x1e6900),_0x1e6900);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x332e45,_0x12d6a5){this['storage'][_0x332e45]=_0x12d6a5;}async['_get'](_0x1a849d){const _0x36c06b=this['storage'][_0x1a849d];return _0x36c06b===void 0x0?null:_0x36c06b;}async['_remove'](_0x3ee9d1){delete this['storage'][_0x3ee9d1];}['_addListener'](_0x4886dc,_0x498da6){}['_removeListener'](_0x3ceb3e,_0x29388f){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x1ed44a,_0x7ab11b,_0x2db9dd){return'firebase:'+_0x1ed44a+':'+_0x7ab11b+':'+_0x2db9dd;}class Xe{constructor(_0x3ccfcd,_0xd64b7a,_0x68c905){this['persistence']=_0x3ccfcd,this['auth']=_0xd64b7a,this['userKey']=_0x68c905;const {config:_0x19b206,name:_0xcf9555}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x19b206['apiKey'],_0xcf9555),this['fullPersistenceKey']=sn('persistence',_0x19b206['apiKey'],_0xcf9555),this['boundEventHandler']=_0xd64b7a['_onStorageEvent']['bind'](_0xd64b7a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2d90ba){return this['persistence']['_set'](this['fullUserKey'],_0x2d90ba['toJSON']());}async['getCurrentUser'](){const _0x3164d5=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3164d5)return null;if(typeof _0x3164d5=='string'){const _0x1c521a=await Sn(this['auth'],{'idToken':_0x3164d5})['catch'](()=>{});return _0x1c521a?z['_fromGetAccountInfoResponse'](this['auth'],_0x1c521a,_0x3164d5):null;}return z['_fromJSON'](this['auth'],_0x3164d5);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x24f991){if(this['persistence']===_0x24f991)return;const _0x3e26d6=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x24f991,_0x3e26d6)return this['setCurrentUser'](_0x3e26d6);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x40f77a,_0x3ad31a,_0x18e692='authUser'){if(!_0x3ad31a['length'])return new Xe(ne(wr),_0x40f77a,_0x18e692);const _0x15c6e6=(await Promise['all'](_0x3ad31a['map'](async _0x332a03=>{if(await _0x332a03['_isAvailable']())return _0x332a03;})))['filter'](_0x1dee73=>_0x1dee73);let _0x42eb89=_0x15c6e6[0x0]||ne(wr);const _0x371458=sn(_0x18e692,_0x40f77a['config']['apiKey'],_0x40f77a['name']);let _0x2400b9=null;for(const _0x29e154 of _0x3ad31a)try{const _0x34c127=await _0x29e154['_get'](_0x371458);if(_0x34c127){let _0x12c7a0;if(typeof _0x34c127=='string'){const _0x55c432=await Sn(_0x40f77a,{'idToken':_0x34c127})['catch'](()=>{});if(!_0x55c432)break;_0x12c7a0=await z['_fromGetAccountInfoResponse'](_0x40f77a,_0x55c432,_0x34c127);}else _0x12c7a0=z['_fromJSON'](_0x40f77a,_0x34c127);_0x29e154!==_0x42eb89&&(_0x2400b9=_0x12c7a0),_0x42eb89=_0x29e154;break;}}catch{}const _0x5c5379=_0x15c6e6['filter'](_0x36a87d=>_0x36a87d['_shouldAllowMigration']);return!_0x42eb89['_shouldAllowMigration']||!_0x5c5379['length']?new Xe(_0x42eb89,_0x40f77a,_0x18e692):(_0x42eb89=_0x5c5379[0x0],_0x2400b9&&await _0x42eb89['_set'](_0x371458,_0x2400b9['toJSON']()),await Promise['all'](_0x3ad31a['map'](async _0x30c07b=>{if(_0x30c07b!==_0x42eb89)try{await _0x30c07b['_remove'](_0x371458);}catch{}})),new Xe(_0x42eb89,_0x40f77a,_0x18e692));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x787ba4){const _0x44746c=_0x787ba4['toLowerCase']();if(_0x44746c['includes']('opera/')||_0x44746c['includes']('opr/')||_0x44746c['includes']('opios/'))return'Opera';if(Ra(_0x44746c))return'IEMobile';if(_0x44746c['includes']('msie')||_0x44746c['includes']('trident/'))return'IE';if(_0x44746c['includes']('edge/'))return'Edge';if(Ta(_0x44746c))return'Firefox';if(_0x44746c['includes']('silk/'))return'Silk';if(ka(_0x44746c))return'Blackberry';if(Na(_0x44746c))return'Webos';if(Sa(_0x44746c))return'Safari';if((_0x44746c['includes']('chrome/')||ba(_0x44746c))&&!_0x44746c['includes']('edge/'))return'Chrome';if(Aa(_0x44746c))return'Android';{const _0x5adab8=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x360419=_0x787ba4['match'](_0x5adab8);if((_0x360419==null?void 0x0:_0x360419['length'])===0x2)return _0x360419[0x1];}return'Other';}function Ta(_0x44ba05=W()){return/firefox\//i['test'](_0x44ba05);}function Sa(_0x1f62a3=W()){const _0x5ef082=_0x1f62a3['toLowerCase']();return _0x5ef082['includes']('safari/')&&!_0x5ef082['includes']('chrome/')&&!_0x5ef082['includes']('crios/')&&!_0x5ef082['includes']('android');}function ba(_0x55164c=W()){return/crios\//i['test'](_0x55164c);}function Ra(_0x1407ff=W()){return/iemobile/i['test'](_0x1407ff);}function Aa(_0xd02d11=W()){return/android/i['test'](_0xd02d11);}function ka(_0xf34eba=W()){return/blackberry/i['test'](_0xf34eba);}function Na(_0x5151ba=W()){return/webos/i['test'](_0x5151ba);}function Cs(_0x55043b=W()){return/iphone|ipad|ipod/i['test'](_0x55043b)||/macintosh/i['test'](_0x55043b)&&/mobile/i['test'](_0x55043b);}function Ef(_0x15ee40=W()){var _0x268c7c;return Cs(_0x15ee40)&&!!((_0x268c7c=window['navigator'])!=null&&_0x268c7c['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0xcdcc1b=W()){return Cs(_0xcdcc1b)||Aa(_0xcdcc1b)||Na(_0xcdcc1b)||ka(_0xcdcc1b)||/windows phone/i['test'](_0xcdcc1b)||Ra(_0xcdcc1b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x33e640,_0x1ac3ca=[]){let _0x323ef7;switch(_0x33e640){case'Browser':_0x323ef7=Cr(W());break;case'Worker':_0x323ef7=Cr(W())+'-'+_0x33e640;break;default:_0x323ef7=_0x33e640;}const _0x4390e5=_0x1ac3ca['length']?_0x1ac3ca['join'](','):'FirebaseCore-web';return _0x323ef7+'/JsCore/'+ct+'/'+_0x4390e5;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x416129){this['auth']=_0x416129,this['queue']=[];}['pushCallback'](_0x2a8de1,_0x33d994){const _0x169f6f=_0x25efcd=>new Promise((_0xfda7f9,_0x16133e)=>{try{const _0x176120=_0x2a8de1(_0x25efcd);_0xfda7f9(_0x176120);}catch(_0x34ed90){_0x16133e(_0x34ed90);}});_0x169f6f['onAbort']=_0x33d994,this['queue']['push'](_0x169f6f);const _0xa11a6c=this['queue']['length']-0x1;return()=>{this['queue'][_0xa11a6c]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2fe175){if(this['auth']['currentUser']===_0x2fe175)return;const _0x40c01d=[];try{for(const _0x2848af of this['queue'])await _0x2848af(_0x2fe175),_0x2848af['onAbort']&&_0x40c01d['push'](_0x2848af['onAbort']);}catch(_0x937d55){_0x40c01d['reverse']();for(const _0x7c5c68 of _0x40c01d)try{_0x7c5c68();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x937d55==null?void 0x0:_0x937d55['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x361c51,_0x4558fa={}){return Ae(_0x361c51,'GET','/v2/passwordPolicy',Re(_0x361c51,_0x4558fa));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x39352b){var _0x57f790;const _0x3fd9ce=_0x39352b['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3fd9ce['minPasswordLength']??Tf,_0x3fd9ce['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3fd9ce['maxPasswordLength']),_0x3fd9ce['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3fd9ce['containsLowercaseCharacter']),_0x3fd9ce['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3fd9ce['containsUppercaseCharacter']),_0x3fd9ce['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3fd9ce['containsNumericCharacter']),_0x3fd9ce['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3fd9ce['containsNonAlphanumericCharacter']),this['enforcementState']=_0x39352b['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x57f790=_0x39352b['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x57f790['join'](''))??'',this['forceUpgradeOnSignin']=_0x39352b['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x39352b['schemaVersion'];}['validatePassword'](_0xdeb320){const _0x2af9c1={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0xdeb320,_0x2af9c1),this['validatePasswordCharacterOptions'](_0xdeb320,_0x2af9c1),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['meetsMinPasswordLength']??!0x0),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['meetsMaxPasswordLength']??!0x0),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['containsLowercaseLetter']??!0x0),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['containsUppercaseLetter']??!0x0),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['containsNumericCharacter']??!0x0),_0x2af9c1['isValid']&&(_0x2af9c1['isValid']=_0x2af9c1['containsNonAlphanumericCharacter']??!0x0),_0x2af9c1;}['validatePasswordLengthOptions'](_0x52bc0b,_0x1f38d0){const _0x470347=this['customStrengthOptions']['minPasswordLength'],_0x4021ce=this['customStrengthOptions']['maxPasswordLength'];_0x470347&&(_0x1f38d0['meetsMinPasswordLength']=_0x52bc0b['length']>=_0x470347),_0x4021ce&&(_0x1f38d0['meetsMaxPasswordLength']=_0x52bc0b['length']<=_0x4021ce);}['validatePasswordCharacterOptions'](_0x17c753,_0x9ddf0a){this['updatePasswordCharacterOptionsStatuses'](_0x9ddf0a,!0x1,!0x1,!0x1,!0x1);let _0x28d95c;for(let _0x511dce=0x0;_0x511dce<_0x17c753['length'];_0x511dce++)_0x28d95c=_0x17c753['charAt'](_0x511dce),this['updatePasswordCharacterOptionsStatuses'](_0x9ddf0a,_0x28d95c>='a'&&_0x28d95c<='z',_0x28d95c>='A'&&_0x28d95c<='Z',_0x28d95c>='0'&&_0x28d95c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x28d95c));}['updatePasswordCharacterOptionsStatuses'](_0x4d1a5b,_0x37f4af,_0x1fb34d,_0x3daa9a,_0x5ee454){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4d1a5b['containsLowercaseLetter']||(_0x4d1a5b['containsLowercaseLetter']=_0x37f4af)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4d1a5b['containsUppercaseLetter']||(_0x4d1a5b['containsUppercaseLetter']=_0x1fb34d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4d1a5b['containsNumericCharacter']||(_0x4d1a5b['containsNumericCharacter']=_0x3daa9a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4d1a5b['containsNonAlphanumericCharacter']||(_0x4d1a5b['containsNonAlphanumericCharacter']=_0x5ee454));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x3d9065,_0x26cd00,_0x6b4d09,_0x2065cc){this['app']=_0x3d9065,this['heartbeatServiceProvider']=_0x26cd00,this['appCheckServiceProvider']=_0x6b4d09,this['config']=_0x2065cc,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3d9065['name'],this['clientVersion']=_0x2065cc['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x263368=>this['_resolvePersistenceManagerAvailable']=_0x263368);}['_initializeWithPersistence'](_0x54ed69,_0x45179e){return _0x45179e&&(this['_popupRedirectResolver']=ne(_0x45179e)),this['_initializationPromise']=this['queue'](async()=>{var _0x9ee3bf,_0x10e5dd,_0x4db8e7;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x54ed69),(_0x9ee3bf=this['_resolvePersistenceManagerAvailable'])==null||_0x9ee3bf['call'](this),!this['_deleted'])){if((_0x10e5dd=this['_popupRedirectResolver'])!=null&&_0x10e5dd['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x45179e),this['lastNotifiedUid']=((_0x4db8e7=this['currentUser'])==null?void 0x0:_0x4db8e7['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x39ff11=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x39ff11)){if(this['currentUser']&&_0x39ff11&&this['currentUser']['uid']===_0x39ff11['uid']){this['_currentUser']['_assign'](_0x39ff11),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x39ff11,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x46c2a2){try{const _0x277fc3=await Sn(this,{'idToken':_0x46c2a2}),_0x28a76c=await z['_fromGetAccountInfoResponse'](this,_0x277fc3,_0x46c2a2);await this['directlySetCurrentUser'](_0x28a76c);}catch(_0x4f0811){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4f0811),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x582f95){var _0x4b9c2f;if(H(this['app'])){const _0x9b115b=this['app']['settings']['authIdToken'];return _0x9b115b?new Promise(_0x4b0dbe=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x9b115b)['then'](_0x4b0dbe,_0x4b0dbe));}):this['directlySetCurrentUser'](null);}const _0x4a6fa5=await this['assertedPersistence']['getCurrentUser']();let _0x4f30d2=_0x4a6fa5,_0x22bfe1=!0x1;if(_0x582f95&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x30940f=(_0x4b9c2f=this['redirectUser'])==null?void 0x0:_0x4b9c2f['_redirectEventId'],_0x2444f5=_0x4f30d2==null?void 0x0:_0x4f30d2['_redirectEventId'],_0x5b48b9=await this['tryRedirectSignIn'](_0x582f95);(!_0x30940f||_0x30940f===_0x2444f5)&&(_0x5b48b9!=null&&_0x5b48b9['user'])&&(_0x4f30d2=_0x5b48b9['user'],_0x22bfe1=!0x0);}if(!_0x4f30d2)return this['directlySetCurrentUser'](null);if(!_0x4f30d2['_redirectEventId']){if(_0x22bfe1)try{await this['beforeStateQueue']['runMiddleware'](_0x4f30d2);}catch(_0x48af53){_0x4f30d2=_0x4a6fa5,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x48af53));}return _0x4f30d2?this['reloadAndSetCurrentUserOrClear'](_0x4f30d2):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4f30d2['_redirectEventId']?this['directlySetCurrentUser'](_0x4f30d2):this['reloadAndSetCurrentUserOrClear'](_0x4f30d2);}async['tryRedirectSignIn'](_0x5ca27f){let _0x59064a=null;try{_0x59064a=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5ca27f,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x59064a;}async['reloadAndSetCurrentUserOrClear'](_0x23d8d7){try{await bn(_0x23d8d7);}catch(_0x359cd0){if((_0x359cd0==null?void 0x0:_0x359cd0['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x23d8d7);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x4511c8){if(H(this['app']))return Promise['reject'](se(this));const _0x209758=_0x4511c8?k(_0x4511c8):null;return _0x209758&&m(_0x209758['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x209758&&_0x209758['_clone'](this));}async['_updateCurrentUser'](_0x5aecce,_0x257a8c=!0x1){if(!this['_deleted'])return _0x5aecce&&m(this['tenantId']===_0x5aecce['tenantId'],this,'tenant-id-mismatch'),_0x257a8c||await this['beforeStateQueue']['runMiddleware'](_0x5aecce),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x5aecce),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4ffc18){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x4ffc18));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1084f2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x34a482=this['_getPasswordPolicyInternal']();return _0x34a482['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x34a482['validatePassword'](_0x1084f2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5a5f0f=await Cf(this),_0x17099b=new Sf(_0x5a5f0f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x17099b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x17099b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x441816){this['_errorFactory']=new Ut('auth','Firebase',_0x441816());}['onAuthStateChanged'](_0x164b3d,_0x210dbe,_0x5dcb2c){return this['registerStateListener'](this['authStateSubscription'],_0x164b3d,_0x210dbe,_0x5dcb2c);}['beforeAuthStateChanged'](_0x13ef61,_0x4f9392){return this['beforeStateQueue']['pushCallback'](_0x13ef61,_0x4f9392);}['onIdTokenChanged'](_0x58a875,_0x2c6420,_0x23d6ef){return this['registerStateListener'](this['idTokenSubscription'],_0x58a875,_0x2c6420,_0x23d6ef);}['authStateReady'](){return new Promise((_0x5a31a4,_0x1ecc0c)=>{if(this['currentUser'])_0x5a31a4();else{const _0xd20407=this['onAuthStateChanged'](()=>{_0xd20407(),_0x5a31a4();},_0x1ecc0c);}});}async['revokeAccessToken'](_0x4764d3){if(this['currentUser']){const _0x4c834b=await this['currentUser']['getIdToken'](),_0x1ca3f4={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4764d3,'idToken':_0x4c834b};this['tenantId']!=null&&(_0x1ca3f4['tenantId']=this['tenantId']),await vf(this,_0x1ca3f4);}}['toJSON'](){var _0x22f915;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x22f915=this['_currentUser'])==null?void 0x0:_0x22f915['toJSON']()};}async['_setRedirectUser'](_0x29023d,_0x3df9dc){const _0x63a211=await this['getOrInitRedirectPersistenceManager'](_0x3df9dc);return _0x29023d===null?_0x63a211['removeCurrentUser']():_0x63a211['setCurrentUser'](_0x29023d);}async['getOrInitRedirectPersistenceManager'](_0x256642){if(!this['redirectPersistenceManager']){const _0x7110fd=_0x256642&&ne(_0x256642)||this['_popupRedirectResolver'];m(_0x7110fd,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x7110fd['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x258c5b){var _0x423212,_0x5ed10f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x423212=this['_currentUser'])==null?void 0x0:_0x423212['_redirectEventId'])===_0x258c5b?this['_currentUser']:((_0x5ed10f=this['redirectUser'])==null?void 0x0:_0x5ed10f['_redirectEventId'])===_0x258c5b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3eb4eb){if(_0x3eb4eb===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3eb4eb));}['_notifyListenersIfCurrent'](_0xb9f24){_0xb9f24===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x469d75;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x38112c=((_0x469d75=this['currentUser'])==null?void 0x0:_0x469d75['uid'])??null;this['lastNotifiedUid']!==_0x38112c&&(this['lastNotifiedUid']=_0x38112c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4f4aa2,_0x21d427,_0x39eeb3,_0x224d2d){if(this['_deleted'])return()=>{};const _0xabf880=typeof _0x21d427=='function'?_0x21d427:_0x21d427['next']['bind'](_0x21d427);let _0xbaa6da=!0x1;const _0x4b4afe=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4b4afe,this,'internal-error'),_0x4b4afe['then'](()=>{_0xbaa6da||_0xabf880(this['currentUser']);}),typeof _0x21d427=='function'){const _0x58d64c=_0x4f4aa2['addObserver'](_0x21d427,_0x39eeb3,_0x224d2d);return()=>{_0xbaa6da=!0x0,_0x58d64c();};}else{const _0x2ce339=_0x4f4aa2['addObserver'](_0x21d427);return()=>{_0xbaa6da=!0x0,_0x2ce339();};}}async['directlySetCurrentUser'](_0x5cad51){this['currentUser']&&this['currentUser']!==_0x5cad51&&this['_currentUser']['_stopProactiveRefresh'](),_0x5cad51&&this['isProactiveRefreshEnabled']&&_0x5cad51['_startProactiveRefresh'](),this['currentUser']=_0x5cad51,_0x5cad51?await this['assertedPersistence']['setCurrentUser'](_0x5cad51):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1a3d53){return this['operations']=this['operations']['then'](_0x1a3d53,_0x1a3d53),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5b6abf){!_0x5b6abf||this['frameworks']['includes'](_0x5b6abf)||(this['frameworks']['push'](_0x5b6abf),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x3b1abd;const _0x4465bb={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4465bb['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x6cdc18=await((_0x3b1abd=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3b1abd['getHeartbeatsHeader']());_0x6cdc18&&(_0x4465bb['X-Firebase-Client']=_0x6cdc18);const _0x4b9c49=await this['_getAppCheckToken']();return _0x4b9c49&&(_0x4465bb['X-Firebase-AppCheck']=_0x4b9c49),_0x4465bb;}async['_getAppCheckToken'](){var _0x3ff4e9;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1e8e19=await((_0x3ff4e9=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3ff4e9['getToken']());return _0x1e8e19!=null&&_0x1e8e19['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1e8e19['error']),_0x1e8e19==null?void 0x0:_0x1e8e19['token'];}}function qe(_0x7d545e){return k(_0x7d545e);}class Tr{constructor(_0x47f1f7){this['auth']=_0x47f1f7,this['observer']=null,this['addObserver']=Ic(_0x2f6bed=>this['observer']=_0x2f6bed);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x146448){zn=_0x146448;}function Da(_0x5ce746){return zn['loadJS'](_0x5ce746);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x425900){return'__'+_0x425900+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x9d0f94){_0x9d0f94();}['execute'](_0xb671ec,_0xbe676a){return Promise['resolve']('token');}['render'](_0x157ce3,_0xd19c03){return'';}}class Of{['ready'](_0x366304){_0x366304();}['execute'](_0x46eee9,_0x397c7d){return Promise['resolve']('token');}['render'](_0x19b9b6,_0x311cf7){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4fca4c){this['type']=Df,this['auth']=qe(_0x4fca4c);}async['verify'](_0x3a1bc2='verify',_0x5ea617=!0x1){async function _0x1d0661(_0x2547b7){if(!_0x5ea617){if(_0x2547b7['tenantId']==null&&_0x2547b7['_agentRecaptchaConfig']!=null)return _0x2547b7['_agentRecaptchaConfig']['siteKey'];if(_0x2547b7['tenantId']!=null&&_0x2547b7['_tenantRecaptchaConfigs'][_0x2547b7['tenantId']]!==void 0x0)return _0x2547b7['_tenantRecaptchaConfigs'][_0x2547b7['tenantId']]['siteKey'];}return new Promise(async(_0x47bffc,_0x1a3128)=>{uf(_0x2547b7,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4912e3=>{if(_0x4912e3['recaptchaKey']===void 0x0)_0x1a3128(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4df436=new hf(_0x4912e3);return _0x2547b7['tenantId']==null?_0x2547b7['_agentRecaptchaConfig']=_0x4df436:_0x2547b7['_tenantRecaptchaConfigs'][_0x2547b7['tenantId']]=_0x4df436,_0x47bffc(_0x4df436['siteKey']);}})['catch'](_0xe5fcaf=>{_0x1a3128(_0xe5fcaf);});});}function _0x117acf(_0x19690b,_0x28967f,_0x685190){const _0x2fbcfa=window['grecaptcha'];vr(_0x2fbcfa)?_0x2fbcfa['enterprise']['ready'](()=>{_0x2fbcfa['enterprise']['execute'](_0x19690b,{'action':_0x3a1bc2})['then'](_0x3bcada=>{_0x28967f(_0x3bcada);})['catch'](()=>{_0x28967f(Ma);});}):_0x685190(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x6fbcb7,_0x4fd23e)=>{_0x1d0661(this['auth'])['then'](async _0x2fb67f=>{if(!_0x5ea617&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x117acf(_0x2fb67f,_0x6fbcb7,_0x4fd23e);else{if(typeof window>'u'){_0x4fd23e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x33abf0=Af();_0x33abf0['length']!==0x0&&(_0x33abf0+=_0x2fb67f+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x3c6604;(_0x3c6604=le['scriptInjectionDeferred'])==null||_0x3c6604['resolve']();},Da(_0x33abf0)['then'](()=>{var _0x3750d1;return(_0x3750d1=le['scriptInjectionDeferred'])==null?void 0x0:_0x3750d1['promise'];})['then'](()=>{_0x117acf(_0x2fb67f,_0x6fbcb7,_0x4fd23e);})['catch'](_0x4e9ab7=>{_0x4fd23e(_0x4e9ab7);});}})['catch'](_0x1c99a5=>{_0x4fd23e(_0x1c99a5);});});}}le['scriptInjectionDeferred']=null;async function br(_0x147497,_0x328b56,_0x17d4f2,_0x387a09=!0x1,_0x20839b=!0x1){const _0x45d4df=new le(_0x147497);let _0xccbe28;if(_0x20839b)_0xccbe28=Ma;else try{_0xccbe28=await _0x45d4df['verify'](_0x17d4f2);}catch{_0xccbe28=await _0x45d4df['verify'](_0x17d4f2,!0x0);}const _0x1cb79b={..._0x328b56};if(_0x17d4f2==='mfaSmsEnrollment'||_0x17d4f2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1cb79b){const _0x18793a=_0x1cb79b['phoneEnrollmentInfo']['phoneNumber'],_0x350342=_0x1cb79b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1cb79b,{'phoneEnrollmentInfo':{'phoneNumber':_0x18793a,'recaptchaToken':_0x350342,'captchaResponse':_0xccbe28,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1cb79b){const _0x5ac3a9=_0x1cb79b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1cb79b,{'phoneSignInInfo':{'recaptchaToken':_0x5ac3a9,'captchaResponse':_0xccbe28,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1cb79b;}return _0x387a09?Object['assign'](_0x1cb79b,{'captchaResp':_0xccbe28}):Object['assign'](_0x1cb79b,{'captchaResponse':_0xccbe28}),Object['assign'](_0x1cb79b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1cb79b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1cb79b;}async function Oi(_0x2b38f9,_0x1279ad,_0x3b0e2d,_0x4b23c1,_0x373015){var _0x3e9e75;if((_0x3e9e75=_0x2b38f9['_getRecaptchaConfig']())!=null&&_0x3e9e75['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x338abb=await br(_0x2b38f9,_0x1279ad,_0x3b0e2d,_0x3b0e2d==='getOobCode');return _0x4b23c1(_0x2b38f9,_0x338abb);}else return _0x4b23c1(_0x2b38f9,_0x1279ad)['catch'](async _0x114b8d=>{if(_0x114b8d['code']==='auth/missing-recaptcha-token'){console['log'](_0x3b0e2d+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x22c7d0=await br(_0x2b38f9,_0x1279ad,_0x3b0e2d,_0x3b0e2d==='getOobCode');return _0x4b23c1(_0x2b38f9,_0x22c7d0);}else return Promise['reject'](_0x114b8d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x24c8d9,_0x339322){const _0x551800=Ui(_0x24c8d9,'auth');if(_0x551800['isInitialized']()){const _0x3a8ca6=_0x551800['getImmediate'](),_0x29c994=_0x551800['getOptions']();if(De(_0x29c994,_0x339322??{}))return _0x3a8ca6;K(_0x3a8ca6,'already-initialized');}return _0x551800['initialize']({'options':_0x339322});}function Lf(_0x54331e,_0x5f1431){const _0x4296e0=(_0x5f1431==null?void 0x0:_0x5f1431['persistence'])||[],_0x3a47f8=(Array['isArray'](_0x4296e0)?_0x4296e0:[_0x4296e0])['map'](ne);_0x5f1431!=null&&_0x5f1431['errorMap']&&_0x54331e['_updateErrorMap'](_0x5f1431['errorMap']),_0x54331e['_initializeWithPersistence'](_0x3a47f8,_0x5f1431==null?void 0x0:_0x5f1431['popupRedirectResolver']);}function xf(_0x1db45f,_0x2e85db,_0x18a777){const _0x4b7a79=qe(_0x1db45f);m(/^https?:\/\//['test'](_0x2e85db),_0x4b7a79,'invalid-emulator-scheme');const _0x2bac99=!0x1,_0x4b5a44=La(_0x2e85db),{host:_0x68ef24,port:_0x4a9645}=Ff(_0x2e85db),_0x3d5e82=_0x4a9645===null?'':':'+_0x4a9645,_0x40ec37={'url':_0x4b5a44+'//'+_0x68ef24+_0x3d5e82+'/'},_0x58a23c=Object['freeze']({'host':_0x68ef24,'port':_0x4a9645,'protocol':_0x4b5a44['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2bac99})});if(!_0x4b7a79['_canInitEmulator']){m(_0x4b7a79['config']['emulator']&&_0x4b7a79['emulatorConfig'],_0x4b7a79,'emulator-config-failed'),m(De(_0x40ec37,_0x4b7a79['config']['emulator'])&&De(_0x58a23c,_0x4b7a79['emulatorConfig']),_0x4b7a79,'emulator-config-failed');return;}_0x4b7a79['config']['emulator']=_0x40ec37,_0x4b7a79['emulatorConfig']=_0x58a23c,_0x4b7a79['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x68ef24)?jr(_0x4b5a44+'//'+_0x68ef24+_0x3d5e82):Uf();}function La(_0x5945f2){const _0x551163=_0x5945f2['indexOf'](':');return _0x551163<0x0?'':_0x5945f2['substr'](0x0,_0x551163+0x1);}function Ff(_0x28219c){const _0x2c9a77=La(_0x28219c),_0x52bb5a=/(\/\/)?([^?#/]+)/['exec'](_0x28219c['substr'](_0x2c9a77['length']));if(!_0x52bb5a)return{'host':'','port':null};const _0x311293=_0x52bb5a[0x2]['split']('@')['pop']()||'',_0x4753a9=/^(\[[^\]]+\])(:|$)/['exec'](_0x311293);if(_0x4753a9){const _0x2f7eea=_0x4753a9[0x1];return{'host':_0x2f7eea,'port':Rr(_0x311293['substr'](_0x2f7eea['length']+0x1))};}else{const [_0x415d80,_0x22b367]=_0x311293['split'](':');return{'host':_0x415d80,'port':Rr(_0x22b367)};}}function Rr(_0x398413){if(!_0x398413)return null;const _0x5a10f3=Number(_0x398413);return isNaN(_0x5a10f3)?null:_0x5a10f3;}function Uf(){function _0x1c1501(){const _0x256496=document['createElement']('p'),_0x2b6c38=_0x256496['style'];_0x256496['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2b6c38['position']='fixed',_0x2b6c38['width']='100%',_0x2b6c38['backgroundColor']='#ffffff',_0x2b6c38['border']='.1em\x20solid\x20#000000',_0x2b6c38['color']='#b50000',_0x2b6c38['bottom']='0px',_0x2b6c38['left']='0px',_0x2b6c38['margin']='0px',_0x2b6c38['zIndex']='10000',_0x2b6c38['textAlign']='center',_0x256496['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x256496);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1c1501):_0x1c1501());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x3aa8ab,_0x4a7253){this['providerId']=_0x3aa8ab,this['signInMethod']=_0x4a7253;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x34df3e){return te('not\x20implemented');}['_linkToIdToken'](_0x1ddb9f,_0x4e5c33){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x26d202){return te('not\x20implemented');}}async function Wf(_0x18946e,_0xafc516){return Ae(_0x18946e,'POST','/v1/accounts:signUp',_0xafc516);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x205ac2,_0x54dc73){return Yt(_0x205ac2,'POST','/v1/accounts:signInWithPassword',Re(_0x205ac2,_0x54dc73));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x243530,_0x3f069c){return Yt(_0x243530,'POST','/v1/accounts:signInWithEmailLink',Re(_0x243530,_0x3f069c));}async function Hf(_0x3d2302,_0xef34d1){return Yt(_0x3d2302,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3d2302,_0xef34d1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x5bb82a,_0x15bcab,_0xd097fc,_0x25de4=null){super('password',_0xd097fc),this['_email']=_0x5bb82a,this['_password']=_0x15bcab,this['_tenantId']=_0x25de4;}static['_fromEmailAndPassword'](_0x51435a,_0x1ed65b){return new Ft(_0x51435a,_0x1ed65b,'password');}static['_fromEmailAndCode'](_0xf37a48,_0xfc8d7e,_0x386b73=null){return new Ft(_0xf37a48,_0xfc8d7e,'emailLink',_0x386b73);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x589de7){const _0x56dfa1=typeof _0x589de7=='string'?JSON['parse'](_0x589de7):_0x589de7;if(_0x56dfa1!=null&&_0x56dfa1['email']&&(_0x56dfa1!=null&&_0x56dfa1['password'])){if(_0x56dfa1['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x56dfa1['email'],_0x56dfa1['password']);if(_0x56dfa1['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x56dfa1['email'],_0x56dfa1['password'],_0x56dfa1['tenantId']);}return null;}async['_getIdTokenResponse'](_0x288f61){switch(this['signInMethod']){case'password':const _0x4affb6={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x288f61,_0x4affb6,'signInWithPassword',Bf);case'emailLink':return Vf(_0x288f61,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x288f61,'internal-error');}}async['_linkToIdToken'](_0x5da99f,_0x5a23c5){switch(this['signInMethod']){case'password':const _0x280c30={'idToken':_0x5a23c5,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5da99f,_0x280c30,'signUpPassword',Wf);case'emailLink':return Hf(_0x5da99f,{'idToken':_0x5a23c5,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5da99f,'internal-error');}}['_getReauthenticationResolver'](_0xe05159){return this['_getIdTokenResponse'](_0xe05159);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3ff31d,_0x1c8947){return Yt(_0x3ff31d,'POST','/v1/accounts:signInWithIdp',Re(_0x3ff31d,_0x1c8947));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3e6da0){const _0x52a794=new We(_0x3e6da0['providerId'],_0x3e6da0['signInMethod']);return _0x3e6da0['idToken']||_0x3e6da0['accessToken']?(_0x3e6da0['idToken']&&(_0x52a794['idToken']=_0x3e6da0['idToken']),_0x3e6da0['accessToken']&&(_0x52a794['accessToken']=_0x3e6da0['accessToken']),_0x3e6da0['nonce']&&!_0x3e6da0['pendingToken']&&(_0x52a794['nonce']=_0x3e6da0['nonce']),_0x3e6da0['pendingToken']&&(_0x52a794['pendingToken']=_0x3e6da0['pendingToken'])):_0x3e6da0['oauthToken']&&_0x3e6da0['oauthTokenSecret']?(_0x52a794['accessToken']=_0x3e6da0['oauthToken'],_0x52a794['secret']=_0x3e6da0['oauthTokenSecret']):K('argument-error'),_0x52a794;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x115263){const _0x40a2a0=typeof _0x115263=='string'?JSON['parse'](_0x115263):_0x115263,{providerId:_0x69fb6e,signInMethod:_0x5434ed,..._0x2e6d80}=_0x40a2a0;if(!_0x69fb6e||!_0x5434ed)return null;const _0x2f1b62=new We(_0x69fb6e,_0x5434ed);return _0x2f1b62['idToken']=_0x2e6d80['idToken']||void 0x0,_0x2f1b62['accessToken']=_0x2e6d80['accessToken']||void 0x0,_0x2f1b62['secret']=_0x2e6d80['secret'],_0x2f1b62['nonce']=_0x2e6d80['nonce'],_0x2f1b62['pendingToken']=_0x2e6d80['pendingToken']||null,_0x2f1b62;}['_getIdTokenResponse'](_0xaf1878){const _0x374ca4=this['buildRequest']();return Ze(_0xaf1878,_0x374ca4);}['_linkToIdToken'](_0x43ac19,_0x210db5){const _0x385c03=this['buildRequest']();return _0x385c03['idToken']=_0x210db5,Ze(_0x43ac19,_0x385c03);}['_getReauthenticationResolver'](_0x272e64){const _0x5dbe07=this['buildRequest']();return _0x5dbe07['autoCreate']=!0x1,Ze(_0x272e64,_0x5dbe07);}['buildRequest'](){const _0x8ff01={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x8ff01['pendingToken']=this['pendingToken'];else{const _0x48712e={};this['idToken']&&(_0x48712e['id_token']=this['idToken']),this['accessToken']&&(_0x48712e['access_token']=this['accessToken']),this['secret']&&(_0x48712e['oauth_token_secret']=this['secret']),_0x48712e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x48712e['nonce']=this['nonce']),_0x8ff01['postBody']=at(_0x48712e);}return _0x8ff01;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x4da3c4){switch(_0x4da3c4){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0xc045bc){const _0x12c73e=yt(vt(_0xc045bc))['link'],_0x5b900b=_0x12c73e?yt(vt(_0x12c73e))['deep_link_id']:null,_0x248b0e=yt(vt(_0xc045bc))['deep_link_id'];return(_0x248b0e?yt(vt(_0x248b0e))['link']:null)||_0x248b0e||_0x5b900b||_0x12c73e||_0xc045bc;}class Ss{constructor(_0x376b1c){const _0x360d78=yt(vt(_0x376b1c)),_0x8d09fd=_0x360d78['apiKey']??null,_0x351cc6=_0x360d78['oobCode']??null,_0x47108a=Gf(_0x360d78['mode']??null);m(_0x8d09fd&&_0x351cc6&&_0x47108a,'argument-error'),this['apiKey']=_0x8d09fd,this['operation']=_0x47108a,this['code']=_0x351cc6,this['continueUrl']=_0x360d78['continueUrl']??null,this['languageCode']=_0x360d78['lang']??null,this['tenantId']=_0x360d78['tenantId']??null;}static['parseLink'](_0x1682d4){const _0x303574=qf(_0x1682d4);try{return new Ss(_0x303574);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x3438f7,_0x22cf84){return Ft['_fromEmailAndPassword'](_0x3438f7,_0x22cf84);}static['credentialWithLink'](_0x218c94,_0x873e56){const _0x435714=Ss['parseLink'](_0x873e56);return m(_0x435714,'argument-error'),Ft['_fromEmailAndCode'](_0x218c94,_0x435714['code'],_0x435714['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x4f1ae9){this['providerId']=_0x4f1ae9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5ad7b6){this['defaultLanguageCode']=_0x5ad7b6;}['setCustomParameters'](_0x224af1){return this['customParameters']=_0x224af1,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xcbd945){return this['scopes']['includes'](_0xcbd945)||this['scopes']['push'](_0xcbd945),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3c218e){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3c218e});}static['credentialFromResult'](_0x1fa579){return he['credentialFromTaggedObject'](_0x1fa579);}static['credentialFromError'](_0x1a5a77){return he['credentialFromTaggedObject'](_0x1a5a77['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x41aa42}){if(!_0x41aa42||!('oauthAccessToken'in _0x41aa42)||!_0x41aa42['oauthAccessToken'])return null;try{return he['credential'](_0x41aa42['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3421a4,_0x6427be){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3421a4,'accessToken':_0x6427be});}static['credentialFromResult'](_0x4d4761){return ue['credentialFromTaggedObject'](_0x4d4761);}static['credentialFromError'](_0x170998){return ue['credentialFromTaggedObject'](_0x170998['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4c53d8}){if(!_0x4c53d8)return null;const {oauthIdToken:_0x160a64,oauthAccessToken:_0x4e35fb}=_0x4c53d8;if(!_0x160a64&&!_0x4e35fb)return null;try{return ue['credential'](_0x160a64,_0x4e35fb);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x36c824){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x36c824});}static['credentialFromResult'](_0x424dfc){return de['credentialFromTaggedObject'](_0x424dfc);}static['credentialFromError'](_0x829f38){return de['credentialFromTaggedObject'](_0x829f38['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x244463}){if(!_0x244463||!('oauthAccessToken'in _0x244463)||!_0x244463['oauthAccessToken'])return null;try{return de['credential'](_0x244463['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4a2820,_0x214ed4){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4a2820,'oauthTokenSecret':_0x214ed4});}static['credentialFromResult'](_0x24e86a){return fe['credentialFromTaggedObject'](_0x24e86a);}static['credentialFromError'](_0x3a1659){return fe['credentialFromTaggedObject'](_0x3a1659['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x48094d}){if(!_0x48094d)return null;const {oauthAccessToken:_0x3b1461,oauthTokenSecret:_0x2d903c}=_0x48094d;if(!_0x3b1461||!_0x2d903c)return null;try{return fe['credential'](_0x3b1461,_0x2d903c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x4598a9,_0x4bd4ca){return Yt(_0x4598a9,'POST','/v1/accounts:signUp',Re(_0x4598a9,_0x4bd4ca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x4ccbb8){this['user']=_0x4ccbb8['user'],this['providerId']=_0x4ccbb8['providerId'],this['_tokenResponse']=_0x4ccbb8['_tokenResponse'],this['operationType']=_0x4ccbb8['operationType'];}static async['_fromIdTokenResponse'](_0x3bedbc,_0x3fbdc6,_0x34f9ba,_0x319ae3=!0x1){const _0x1858c1=await z['_fromIdTokenResponse'](_0x3bedbc,_0x34f9ba,_0x319ae3),_0x2c966d=Ar(_0x34f9ba);return new Be({'user':_0x1858c1,'providerId':_0x2c966d,'_tokenResponse':_0x34f9ba,'operationType':_0x3fbdc6});}static async['_forOperation'](_0x4bfd3c,_0x455fc6,_0x21f625){await _0x4bfd3c['_updateTokensIfNecessary'](_0x21f625,!0x0);const _0xbbee74=Ar(_0x21f625);return new Be({'user':_0x4bfd3c,'providerId':_0xbbee74,'_tokenResponse':_0x21f625,'operationType':_0x455fc6});}}function Ar(_0xb5cbef){return _0xb5cbef['providerId']?_0xb5cbef['providerId']:'phoneNumber'in _0xb5cbef?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x1f3276,_0x170edd,_0x8418ca,_0x471267){super(_0x170edd['code'],_0x170edd['message']),this['operationType']=_0x8418ca,this['user']=_0x471267,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x1f3276['name'],'tenantId':_0x1f3276['tenantId']??void 0x0,'_serverResponse':_0x170edd['customData']['_serverResponse'],'operationType':_0x8418ca};}static['_fromErrorAndOperation'](_0x1d21cd,_0x343aa7,_0x239114,_0x592d60){return new Rn(_0x1d21cd,_0x343aa7,_0x239114,_0x592d60);}}function Fa(_0x23355e,_0x52cb28,_0x487eab,_0x4b7bb9){return(_0x52cb28==='reauthenticate'?_0x487eab['_getReauthenticationResolver'](_0x23355e):_0x487eab['_getIdTokenResponse'](_0x23355e))['catch'](_0x299c32=>{throw _0x299c32['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x23355e,_0x299c32,_0x52cb28,_0x4b7bb9):_0x299c32;});}async function jf(_0x7a34b6,_0x5340a7,_0x9c8057=!0x1){const _0x593440=await xt(_0x7a34b6,_0x5340a7['_linkToIdToken'](_0x7a34b6['auth'],await _0x7a34b6['getIdToken']()),_0x9c8057);return Be['_forOperation'](_0x7a34b6,'link',_0x593440);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2bcc97,_0x40ca6a,_0x490a19=!0x1){const {auth:_0x2a6473}=_0x2bcc97;if(H(_0x2a6473['app']))return Promise['reject'](se(_0x2a6473));const _0xb45125='reauthenticate';try{const _0x430a3d=await xt(_0x2bcc97,Fa(_0x2a6473,_0xb45125,_0x40ca6a,_0x2bcc97),_0x490a19);m(_0x430a3d['idToken'],_0x2a6473,'internal-error');const _0x160065=ws(_0x430a3d['idToken']);m(_0x160065,_0x2a6473,'internal-error');const {sub:_0x5448ca}=_0x160065;return m(_0x2bcc97['uid']===_0x5448ca,_0x2a6473,'user-mismatch'),Be['_forOperation'](_0x2bcc97,_0xb45125,_0x430a3d);}catch(_0x3e1c2b){throw(_0x3e1c2b==null?void 0x0:_0x3e1c2b['code'])==='auth/user-not-found'&&K(_0x2a6473,'user-mismatch'),_0x3e1c2b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x5c8053,_0x457337,_0x1d0c18=!0x1){if(H(_0x5c8053['app']))return Promise['reject'](se(_0x5c8053));const _0xa6a741='signIn',_0x5cfe62=await Fa(_0x5c8053,_0xa6a741,_0x457337),_0x5eb573=await Be['_fromIdTokenResponse'](_0x5c8053,_0xa6a741,_0x5cfe62);return _0x1d0c18||await _0x5c8053['_updateCurrentUser'](_0x5eb573['user']),_0x5eb573;}async function Yf(_0x4945e8,_0x28d746){return Ua(qe(_0x4945e8),_0x28d746);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x1e31e2){const _0x49140c=qe(_0x1e31e2);_0x49140c['_getPasswordPolicyInternal']()&&await _0x49140c['_updatePasswordPolicy']();}async function R_(_0x3a96fb,_0x117f5e,_0x1ddd0a){if(H(_0x3a96fb['app']))return Promise['reject'](se(_0x3a96fb));const _0x1c0cfe=qe(_0x3a96fb),_0x6c263b=await Oi(_0x1c0cfe,{'returnSecureToken':!0x0,'email':_0x117f5e,'password':_0x1ddd0a,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x5b07f1=>{throw _0x5b07f1['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x3a96fb),_0x5b07f1;}),_0x389cb7=await Be['_fromIdTokenResponse'](_0x1c0cfe,'signIn',_0x6c263b);return await _0x1c0cfe['_updateCurrentUser'](_0x389cb7['user']),_0x389cb7;}function A_(_0x22bf2a,_0x3f5266,_0x1ae9a6){return H(_0x22bf2a['app'])?Promise['reject'](se(_0x22bf2a)):Yf(k(_0x22bf2a),ft['credential'](_0x3f5266,_0x1ae9a6))['catch'](async _0x45e161=>{throw _0x45e161['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x22bf2a),_0x45e161;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x3794d0,_0x2d6c6f){return k(_0x3794d0)['setPersistence'](_0x2d6c6f);}function Qf(_0x460918,_0x16a521,_0x5177b1,_0x2f8a22){return k(_0x460918)['onIdTokenChanged'](_0x16a521,_0x5177b1,_0x2f8a22);}function Jf(_0x2995fc,_0x5a67b0,_0x55e235){return k(_0x2995fc)['beforeAuthStateChanged'](_0x5a67b0,_0x55e235);}function N_(_0x2e7af5,_0x60c2b1,_0x27d6fb,_0x41ea27){return k(_0x2e7af5)['onAuthStateChanged'](_0x60c2b1,_0x27d6fb,_0x41ea27);}function P_(_0x2daa22){return k(_0x2daa22)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x4face4,_0x5db170){this['storageRetriever']=_0x4face4,this['type']=_0x5db170;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3bcd17,_0x4f9514){return this['storage']['setItem'](_0x3bcd17,JSON['stringify'](_0x4f9514)),Promise['resolve']();}['_get'](_0x30c567){const _0x59b3ab=this['storage']['getItem'](_0x30c567);return Promise['resolve'](_0x59b3ab?JSON['parse'](_0x59b3ab):null);}['_remove'](_0x78e5d1){return this['storage']['removeItem'](_0x78e5d1),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x286885,_0x50ec42)=>this['onStorageEvent'](_0x286885,_0x50ec42),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5a6ed7){for(const _0x455838 of Object['keys'](this['listeners'])){const _0x11611d=this['storage']['getItem'](_0x455838),_0x9ded09=this['localCache'][_0x455838];_0x11611d!==_0x9ded09&&_0x5a6ed7(_0x455838,_0x9ded09,_0x11611d);}}['onStorageEvent'](_0x4b33b6,_0x52641a=!0x1){if(!_0x4b33b6['key']){this['forAllChangedKeys']((_0x581c0e,_0x16ddd3,_0xed1b1a)=>{this['notifyListeners'](_0x581c0e,_0xed1b1a);});return;}const _0x2a8dab=_0x4b33b6['key'];_0x52641a?this['detachListener']():this['stopPolling']();const _0x1e1606=()=>{const _0x3200ce=this['storage']['getItem'](_0x2a8dab);!_0x52641a&&this['localCache'][_0x2a8dab]===_0x3200ce||this['notifyListeners'](_0x2a8dab,_0x3200ce);},_0x323562=this['storage']['getItem'](_0x2a8dab);If()&&_0x323562!==_0x4b33b6['newValue']&&_0x4b33b6['newValue']!==_0x4b33b6['oldValue']?setTimeout(_0x1e1606,Zf):_0x1e1606();}['notifyListeners'](_0x11f5f4,_0x3a3000){this['localCache'][_0x11f5f4]=_0x3a3000;const _0x2a740b=this['listeners'][_0x11f5f4];if(_0x2a740b){for(const _0x115db1 of Array['from'](_0x2a740b))_0x115db1(_0x3a3000&&JSON['parse'](_0x3a3000));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3db073,_0x3554c4,_0x2b60d1)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3db073,'oldValue':_0x3554c4,'newValue':_0x2b60d1}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x59768e,_0x10c4a4){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x59768e]||(this['listeners'][_0x59768e]=new Set(),this['localCache'][_0x59768e]=this['storage']['getItem'](_0x59768e)),this['listeners'][_0x59768e]['add'](_0x10c4a4);}['_removeListener'](_0xfc9e5,_0x509439){this['listeners'][_0xfc9e5]&&(this['listeners'][_0xfc9e5]['delete'](_0x509439),this['listeners'][_0xfc9e5]['size']===0x0&&delete this['listeners'][_0xfc9e5]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4e70dc,_0x1581f4){await super['_set'](_0x4e70dc,_0x1581f4),this['localCache'][_0x4e70dc]=JSON['stringify'](_0x1581f4);}async['_get'](_0x36f28f){const _0x4886f4=await super['_get'](_0x36f28f);return this['localCache'][_0x36f28f]=JSON['stringify'](_0x4886f4),_0x4886f4;}async['_remove'](_0x1a89e4){await super['_remove'](_0x1a89e4),delete this['localCache'][_0x1a89e4];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x512c2f,_0x7c25df){}['_removeListener'](_0x5a7886,_0x233b88){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x15132a){return Promise['all'](_0x15132a['map'](async _0x52f44f=>{try{return{'fulfilled':!0x0,'value':await _0x52f44f};}catch(_0x211cb6){return{'fulfilled':!0x1,'reason':_0x211cb6};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x2d30e5){this['eventTarget']=_0x2d30e5,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x236efc){const _0x46626b=this['receivers']['find'](_0x300103=>_0x300103['isListeningto'](_0x236efc));if(_0x46626b)return _0x46626b;const _0x14c937=new jn(_0x236efc);return this['receivers']['push'](_0x14c937),_0x14c937;}['isListeningto'](_0x577f60){return this['eventTarget']===_0x577f60;}async['handleEvent'](_0x48ab25){const _0x3ddfb0=_0x48ab25,{eventId:_0x59c0df,eventType:_0x75d53f,data:_0x21adaf}=_0x3ddfb0['data'],_0x2c3bc4=this['handlersMap'][_0x75d53f];if(!(_0x2c3bc4!=null&&_0x2c3bc4['size']))return;_0x3ddfb0['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x59c0df,'eventType':_0x75d53f});const _0x49c3af=Array['from'](_0x2c3bc4)['map'](async _0x1da26f=>_0x1da26f(_0x3ddfb0['origin'],_0x21adaf)),_0x3f5bea=await tp(_0x49c3af);_0x3ddfb0['ports'][0x0]['postMessage']({'status':'done','eventId':_0x59c0df,'eventType':_0x75d53f,'response':_0x3f5bea});}['_subscribe'](_0x2e4283,_0x4317b5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2e4283]||(this['handlersMap'][_0x2e4283]=new Set()),this['handlersMap'][_0x2e4283]['add'](_0x4317b5);}['_unsubscribe'](_0x17a6a6,_0x5cd5af){this['handlersMap'][_0x17a6a6]&&_0x5cd5af&&this['handlersMap'][_0x17a6a6]['delete'](_0x5cd5af),(!_0x5cd5af||this['handlersMap'][_0x17a6a6]['size']===0x0)&&delete this['handlersMap'][_0x17a6a6],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x737b67='',_0x10bda0=0xa){let _0x37364b='';for(let _0x32e38c=0x0;_0x32e38c<_0x10bda0;_0x32e38c++)_0x37364b+=Math['floor'](Math['random']()*0xa);return _0x737b67+_0x37364b;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x54505f){this['target']=_0x54505f,this['handlers']=new Set();}['removeMessageHandler'](_0x3697a1){_0x3697a1['messageChannel']&&(_0x3697a1['messageChannel']['port1']['removeEventListener']('message',_0x3697a1['onMessage']),_0x3697a1['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3697a1);}async['_send'](_0x64d75e,_0x2fc4ad,_0x3f07b7=0x32){const _0x4e2fb9=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4e2fb9)throw new Error('connection_unavailable');let _0xbdc3f2,_0x2dbb03;return new Promise((_0x266da1,_0x299fd3)=>{const _0x2e5240=bs('',0x14);_0x4e2fb9['port1']['start']();const _0x3a7b00=setTimeout(()=>{_0x299fd3(new Error('unsupported_event'));},_0x3f07b7);_0x2dbb03={'messageChannel':_0x4e2fb9,'onMessage'(_0x8e7626){const _0x290a62=_0x8e7626;if(_0x290a62['data']['eventId']===_0x2e5240)switch(_0x290a62['data']['status']){case'ack':clearTimeout(_0x3a7b00),_0xbdc3f2=setTimeout(()=>{_0x299fd3(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xbdc3f2),_0x266da1(_0x290a62['data']['response']);break;default:clearTimeout(_0x3a7b00),clearTimeout(_0xbdc3f2),_0x299fd3(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2dbb03),_0x4e2fb9['port1']['addEventListener']('message',_0x2dbb03['onMessage']),this['target']['postMessage']({'eventType':_0x64d75e,'eventId':_0x2e5240,'data':_0x2fc4ad},[_0x4e2fb9['port2']]);})['finally'](()=>{_0x2dbb03&&this['removeMessageHandler'](_0x2dbb03);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0xd3fac8){X()['location']['href']=_0xd3fac8;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x1549a3;return((_0x1549a3=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1549a3['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3c5a0a){this['request']=_0x3c5a0a;}['toPromise'](){return new Promise((_0x321512,_0x35ae40)=>{this['request']['addEventListener']('success',()=>{_0x321512(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x35ae40(this['request']['error']);});});}}function Kn(_0x1e7344,_0x2c5d2a){return _0x1e7344['transaction']([kn],_0x2c5d2a?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x4406c3=indexedDB['deleteDatabase'](qa);return new Jt(_0x4406c3)['toPromise']();}function ja(){const _0x23a527=indexedDB['open'](qa,ap);return new Promise((_0x2f6314,_0x2f862a)=>{_0x23a527['addEventListener']('error',()=>{_0x2f862a(_0x23a527['error']);}),_0x23a527['addEventListener']('upgradeneeded',()=>{const _0x42e70f=_0x23a527['result'];try{_0x42e70f['createObjectStore'](kn,{'keyPath':za});}catch(_0x1f1809){_0x2f862a(_0x1f1809);}}),_0x23a527['addEventListener']('success',async()=>{const _0x201665=_0x23a527['result'];_0x201665['objectStoreNames']['contains'](kn)?_0x2f6314(_0x201665):(_0x201665['close'](),await cp(),_0x2f6314(await ja()));});});}async function kr(_0x5d6b1b,_0x3939d5,_0x4a582d){const _0x64ffaf=Kn(_0x5d6b1b,!0x0)['put']({[za]:_0x3939d5,'value':_0x4a582d});return new Jt(_0x64ffaf)['toPromise']();}async function lp(_0x3c2f7c,_0x3e464d){const _0x5f028f=Kn(_0x3c2f7c,!0x1)['get'](_0x3e464d),_0x5b8ccd=await new Jt(_0x5f028f)['toPromise']();return _0x5b8ccd===void 0x0?null:_0x5b8ccd['value'];}function Nr(_0x406ea0,_0x5622a7){const _0x5d6bf5=Kn(_0x406ea0,!0x0)['delete'](_0x5622a7);return new Jt(_0x5d6bf5)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0xeb126d){let _0x38ccdb=0x0;for(;;)try{const _0x10bbc5=await this['_openDb']();return await _0xeb126d(_0x10bbc5);}catch(_0x3cb417){if(_0x38ccdb++>up)throw _0x3cb417;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3583d1,_0x5b1116)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5b1116['key'])})),this['receiver']['_subscribe']('ping',async(_0x2bb725,_0xcf9189)=>['keyChanged']);}async['initializeSender'](){var _0x57707f,_0x5e4a73;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x50f270=await this['sender']['_send']('ping',{},0x320);_0x50f270&&(_0x57707f=_0x50f270[0x0])!=null&&_0x57707f['fulfilled']&&(_0x5e4a73=_0x50f270[0x0])!=null&&_0x5e4a73['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xd864c5){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xd864c5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x413aef=>{await kr(_0x413aef,An,'1'),await Nr(_0x413aef,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4a79a6){this['pendingWrites']++;try{await _0x4a79a6();}finally{this['pendingWrites']--;}}async['_set'](_0x47d476,_0xf5789){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x23a838=>kr(_0x23a838,_0x47d476,_0xf5789)),this['localCache'][_0x47d476]=_0xf5789,this['notifyServiceWorker'](_0x47d476)));}async['_get'](_0x41c613){const _0x3c4e7b=await this['_withRetries'](_0x69f5e6=>lp(_0x69f5e6,_0x41c613));return this['localCache'][_0x41c613]=_0x3c4e7b,_0x3c4e7b;}async['_remove'](_0x38487f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xf04f66=>Nr(_0xf04f66,_0x38487f)),delete this['localCache'][_0x38487f],this['notifyServiceWorker'](_0x38487f)));}async['_poll'](){const _0x49ffd2=await this['_withRetries'](_0xfcf243=>{const _0x39befe=Kn(_0xfcf243,!0x1)['getAll']();return new Jt(_0x39befe)['toPromise']();});if(!_0x49ffd2)return[];if(this['pendingWrites']!==0x0)return[];const _0x2f14ac=[],_0xa60512=new Set();if(_0x49ffd2['length']!==0x0){for(const {fbase_key:_0x25a603,value:_0x33994a}of _0x49ffd2)_0xa60512['add'](_0x25a603),JSON['stringify'](this['localCache'][_0x25a603])!==JSON['stringify'](_0x33994a)&&(this['notifyListeners'](_0x25a603,_0x33994a),_0x2f14ac['push'](_0x25a603));}for(const _0x281ff3 of Object['keys'](this['localCache']))this['localCache'][_0x281ff3]&&!_0xa60512['has'](_0x281ff3)&&(this['notifyListeners'](_0x281ff3,null),_0x2f14ac['push'](_0x281ff3));return _0x2f14ac;}['notifyListeners'](_0x1335ff,_0x3b1c84){this['localCache'][_0x1335ff]=_0x3b1c84;const _0x2afae7=this['listeners'][_0x1335ff];if(_0x2afae7){for(const _0x28f792 of Array['from'](_0x2afae7))_0x28f792(_0x3b1c84);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x56e421,_0x3ee287){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x56e421]||(this['listeners'][_0x56e421]=new Set(),this['_get'](_0x56e421)),this['listeners'][_0x56e421]['add'](_0x3ee287);}['_removeListener'](_0xbdb2bb,_0x20fdff){this['listeners'][_0xbdb2bb]&&(this['listeners'][_0xbdb2bb]['delete'](_0x20fdff),this['listeners'][_0xbdb2bb]['size']===0x0&&delete this['listeners'][_0xbdb2bb]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x9e2f6,_0xc1acb7){return _0xc1acb7?ne(_0xc1acb7):(m(_0x9e2f6['_popupRedirectResolver'],_0x9e2f6,'argument-error'),_0x9e2f6['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x39bc9b){super('custom','custom'),this['params']=_0x39bc9b;}['_getIdTokenResponse'](_0x1bddea){return Ze(_0x1bddea,this['_buildIdpRequest']());}['_linkToIdToken'](_0x414ecb,_0x4067f5){return Ze(_0x414ecb,this['_buildIdpRequest'](_0x4067f5));}['_getReauthenticationResolver'](_0x452a2b){return Ze(_0x452a2b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x22a063){const _0x4529f2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x22a063&&(_0x4529f2['idToken']=_0x22a063),_0x4529f2;}}function pp(_0x2b97a3){return Ua(_0x2b97a3['auth'],new Rs(_0x2b97a3),_0x2b97a3['bypassAuthState']);}function _p(_0x147ff6){const {auth:_0x2149ed,user:_0x5393b9}=_0x147ff6;return m(_0x5393b9,_0x2149ed,'internal-error'),Kf(_0x5393b9,new Rs(_0x147ff6),_0x147ff6['bypassAuthState']);}async function gp(_0x269742){const {auth:_0x151f23,user:_0xc80f2a}=_0x269742;return m(_0xc80f2a,_0x151f23,'internal-error'),jf(_0xc80f2a,new Rs(_0x269742),_0x269742['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x270c31,_0x449627,_0x8f9571,_0x1a45a3,_0x37a014=!0x1){this['auth']=_0x270c31,this['resolver']=_0x8f9571,this['user']=_0x1a45a3,this['bypassAuthState']=_0x37a014,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x449627)?_0x449627:[_0x449627];}['execute'](){return new Promise(async(_0x208228,_0x256d3d)=>{this['pendingPromise']={'resolve':_0x208228,'reject':_0x256d3d};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x42a3ad){this['reject'](_0x42a3ad);}});}async['onAuthEvent'](_0x5ad805){const {urlResponse:_0x1a0a83,sessionId:_0x592e95,postBody:_0x350716,tenantId:_0x513ae9,error:_0xfe0952,type:_0x2fc22c}=_0x5ad805;if(_0xfe0952){this['reject'](_0xfe0952);return;}const _0x3947c4={'auth':this['auth'],'requestUri':_0x1a0a83,'sessionId':_0x592e95,'tenantId':_0x513ae9||void 0x0,'postBody':_0x350716||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2fc22c)(_0x3947c4));}catch(_0x1c99c9){this['reject'](_0x1c99c9);}}['onError'](_0x406584){this['reject'](_0x406584);}['getIdpTask'](_0x135f26){switch(_0x135f26){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x587a70){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x587a70),this['unregisterAndCleanUp']();}['reject'](_0xa6534e){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xa6534e),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x35e3cf,_0x3abd58,_0x1cea3f,_0x10730f,_0x584c72){super(_0x35e3cf,_0x3abd58,_0x10730f,_0x584c72),this['provider']=_0x1cea3f,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x4fc51b=await this['execute']();return m(_0x4fc51b,this['auth'],'internal-error'),_0x4fc51b;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2b3b3c=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2b3b3c),this['authWindow']['associatedEvent']=_0x2b3b3c,this['resolver']['_originValidation'](this['auth'])['catch'](_0x41ebda=>{this['reject'](_0x41ebda);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1d6ad2=>{_0x1d6ad2||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2ba618;return((_0x2ba618=this['authWindow'])==null?void 0x0:_0x2ba618['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x17e020=()=>{var _0x1b59b7,_0x2baee5;if((_0x2baee5=(_0x1b59b7=this['authWindow'])==null?void 0x0:_0x1b59b7['window'])!=null&&_0x2baee5['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x17e020,mp['get']());};_0x17e020();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0xfec424,_0x4a9473,_0x21a72e=!0x1){super(_0xfec424,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4a9473,void 0x0,_0x21a72e),this['eventId']=null;}async['execute'](){let _0x3fe7ad=rn['get'](this['auth']['_key']());if(!_0x3fe7ad){try{const _0x4306a1=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3fe7ad=()=>Promise['resolve'](_0x4306a1);}catch(_0x24371d){_0x3fe7ad=()=>Promise['reject'](_0x24371d);}rn['set'](this['auth']['_key'](),_0x3fe7ad);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3fe7ad();}async['onAuthEvent'](_0x1c179b){if(_0x1c179b['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1c179b);if(_0x1c179b['type']==='unknown'){this['resolve'](null);return;}if(_0x1c179b['eventId']){const _0x481d52=await this['auth']['_redirectUserForId'](_0x1c179b['eventId']);if(_0x481d52)return this['user']=_0x481d52,super['onAuthEvent'](_0x1c179b);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x4d65e5,_0x2259bf){const _0x34f4ba=Cp(_0x2259bf),_0x4fd8e1=wp(_0x4d65e5);if(!await _0x4fd8e1['_isAvailable']())return!0x1;const _0xc82a13=await _0x4fd8e1['_get'](_0x34f4ba)==='true';return await _0x4fd8e1['_remove'](_0x34f4ba),_0xc82a13;}function Ip(_0x1e7e06,_0x246098){rn['set'](_0x1e7e06['_key'](),_0x246098);}function wp(_0x193c5f){return ne(_0x193c5f['_redirectPersistence']);}function Cp(_0x2436db){return sn(yp,_0x2436db['config']['apiKey'],_0x2436db['name']);}async function Tp(_0x12b759,_0x2d5c2c,_0x3fc5fe=!0x1){if(H(_0x12b759['app']))return Promise['reject'](se(_0x12b759));const _0x398a9e=qe(_0x12b759),_0x432217=fp(_0x398a9e,_0x2d5c2c),_0x3351e0=await new vp(_0x398a9e,_0x432217,_0x3fc5fe)['execute']();return _0x3351e0&&!_0x3fc5fe&&(delete _0x3351e0['user']['_redirectEventId'],await _0x398a9e['_persistUserIfCurrent'](_0x3351e0['user']),await _0x398a9e['_setRedirectUser'](null,_0x2d5c2c)),_0x3351e0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x123fbd){this['auth']=_0x123fbd,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x291e29){this['consumers']['add'](_0x291e29),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x291e29)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x291e29),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2b6cf8){this['consumers']['delete'](_0x2b6cf8);}['onEvent'](_0x179a03){if(this['hasEventBeenHandled'](_0x179a03))return!0x1;let _0xd8a61=!0x1;return this['consumers']['forEach'](_0x3658bb=>{this['isEventForConsumer'](_0x179a03,_0x3658bb)&&(_0xd8a61=!0x0,this['sendToConsumer'](_0x179a03,_0x3658bb),this['saveEventToCache'](_0x179a03));}),this['hasHandledPotentialRedirect']||!Rp(_0x179a03)||(this['hasHandledPotentialRedirect']=!0x0,_0xd8a61||(this['queuedRedirectEvent']=_0x179a03,_0xd8a61=!0x0)),_0xd8a61;}['sendToConsumer'](_0x16ab28,_0x3fbfe4){var _0x1bdb87;if(_0x16ab28['error']&&!Qa(_0x16ab28)){const _0x4e6d81=((_0x1bdb87=_0x16ab28['error']['code'])==null?void 0x0:_0x1bdb87['split']('auth/')[0x1])||'internal-error';_0x3fbfe4['onError'](J(this['auth'],_0x4e6d81));}else _0x3fbfe4['onAuthEvent'](_0x16ab28);}['isEventForConsumer'](_0x816894,_0x122512){const _0x2f7646=_0x122512['eventId']===null||!!_0x816894['eventId']&&_0x816894['eventId']===_0x122512['eventId'];return _0x122512['filter']['includes'](_0x816894['type'])&&_0x2f7646;}['hasEventBeenHandled'](_0xe0bc07){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0xe0bc07));}['saveEventToCache'](_0x33add0){this['cachedEventUids']['add'](Pr(_0x33add0)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x59bd17){return[_0x59bd17['type'],_0x59bd17['eventId'],_0x59bd17['sessionId'],_0x59bd17['tenantId']]['filter'](_0x225f3a=>_0x225f3a)['join']('-');}function Qa({type:_0x919b39,error:_0x3eb502}){return _0x919b39==='unknown'&&(_0x3eb502==null?void 0x0:_0x3eb502['code'])==='auth/no-auth-event';}function Rp(_0x4a527a){switch(_0x4a527a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4a527a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x9867d9,_0x4eac6a={}){return Ae(_0x9867d9,'GET','/v1/projects',_0x4eac6a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x51876d){if(_0x51876d['config']['emulator'])return;const {authorizedDomains:_0x10be3c}=await Ap(_0x51876d);for(const _0x3d796a of _0x10be3c)try{if(Op(_0x3d796a))return;}catch{}K(_0x51876d,'unauthorized-domain');}function Op(_0x539a58){const _0xfb1e42=Ni(),{protocol:_0x5ab030,hostname:_0x2a7a6f}=new URL(_0xfb1e42);if(_0x539a58['startsWith']('chrome-extension://')){const _0x389eac=new URL(_0x539a58);return _0x389eac['hostname']===''&&_0x2a7a6f===''?_0x5ab030==='chrome-extension:'&&_0x539a58['replace']('chrome-extension://','')===_0xfb1e42['replace']('chrome-extension://',''):_0x5ab030==='chrome-extension:'&&_0x389eac['hostname']===_0x2a7a6f;}if(!Np['test'](_0x5ab030))return!0x1;if(kp['test'](_0x539a58))return _0x2a7a6f===_0x539a58;const _0x46e62d=_0x539a58['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x46e62d+'|'+_0x46e62d+')$','i')['test'](_0x2a7a6f);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x20d65b=X()['___jsl'];if(_0x20d65b!=null&&_0x20d65b['H']){for(const _0x229dca of Object['keys'](_0x20d65b['H']))if(_0x20d65b['H'][_0x229dca]['r']=_0x20d65b['H'][_0x229dca]['r']||[],_0x20d65b['H'][_0x229dca]['L']=_0x20d65b['H'][_0x229dca]['L']||[],_0x20d65b['H'][_0x229dca]['r']=[..._0x20d65b['H'][_0x229dca]['L']],_0x20d65b['CP']){for(let _0x539fa5=0x0;_0x539fa5<_0x20d65b['CP']['length'];_0x539fa5++)_0x20d65b['CP'][_0x539fa5]=null;}}}function Mp(_0x154ab5){return new Promise((_0xfe9798,_0x19560d)=>{var _0x3cb9f2,_0x49c6d2,_0x32e43d;function _0x3e1af8(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0xfe9798(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x19560d(J(_0x154ab5,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x49c6d2=(_0x3cb9f2=X()['gapi'])==null?void 0x0:_0x3cb9f2['iframes'])!=null&&_0x49c6d2['Iframe'])_0xfe9798(gapi['iframes']['getContext']());else{if((_0x32e43d=X()['gapi'])!=null&&_0x32e43d['load'])_0x3e1af8();else{const _0x696a58=Nf('iframefcb');return X()[_0x696a58]=()=>{gapi['load']?_0x3e1af8():_0x19560d(J(_0x154ab5,'network-request-failed'));},Da(kf()+'?onload='+_0x696a58)['catch'](_0xe2ba64=>_0x19560d(_0xe2ba64));}}})['catch'](_0x108df7=>{throw on=null,_0x108df7;});}let on=null;function Lp(_0x808fae){return on=on||Mp(_0x808fae),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x1796e8){const _0x4d7823=_0x1796e8['config'];m(_0x4d7823['authDomain'],_0x1796e8,'auth-domain-config-required');const _0x3e15ec=_0x4d7823['emulator']?Is(_0x4d7823,Up):'https://'+_0x1796e8['config']['authDomain']+'/'+Fp,_0x5557dc={'apiKey':_0x4d7823['apiKey'],'appName':_0x1796e8['name'],'v':ct},_0x4a94f1=Bp['get'](_0x1796e8['config']['apiHost']);_0x4a94f1&&(_0x5557dc['eid']=_0x4a94f1);const _0x58077a=_0x1796e8['_getFrameworks']();return _0x58077a['length']&&(_0x5557dc['fw']=_0x58077a['join'](',')),_0x3e15ec+'?'+at(_0x5557dc)['slice'](0x1);}async function Hp(_0x5adcec){const _0x5dcf0c=await Lp(_0x5adcec),_0x2ba2d0=X()['gapi'];return m(_0x2ba2d0,_0x5adcec,'internal-error'),_0x5dcf0c['open']({'where':document['body'],'url':Vp(_0x5adcec),'messageHandlersFilter':_0x2ba2d0['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0xd4e298=>new Promise(async(_0x2749df,_0x8c86e6)=>{await _0xd4e298['restyle']({'setHideOnLeave':!0x1});const _0x49bb0c=J(_0x5adcec,'network-request-failed'),_0x51ba40=X()['setTimeout'](()=>{_0x8c86e6(_0x49bb0c);},xp['get']());function _0x1f0dc3(){X()['clearTimeout'](_0x51ba40),_0x2749df(_0xd4e298);}_0xd4e298['ping'](_0x1f0dc3)['then'](_0x1f0dc3,()=>{_0x8c86e6(_0x49bb0c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xb6a86d){this['window']=_0xb6a86d,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x547259,_0x3cf041,_0x5a9046,_0x35e245=Gp,_0x185ef5=qp){const _0x379fe3=Math['max']((window['screen']['availHeight']-_0x185ef5)/0x2,0x0)['toString'](),_0x1d89a8=Math['max']((window['screen']['availWidth']-_0x35e245)/0x2,0x0)['toString']();let _0x5c44f9='';const _0xa64b9b={...$p,'width':_0x35e245['toString'](),'height':_0x185ef5['toString'](),'top':_0x379fe3,'left':_0x1d89a8},_0x53d527=W()['toLowerCase']();_0x5a9046&&(_0x5c44f9=ba(_0x53d527)?zp:_0x5a9046),Ta(_0x53d527)&&(_0x3cf041=_0x3cf041||jp,_0xa64b9b['scrollbars']='yes');const _0x296dbb=Object['entries'](_0xa64b9b)['reduce']((_0x356c4b,[_0x56f711,_0x1b4455])=>''+_0x356c4b+_0x56f711+'='+_0x1b4455+',','');if(Ef(_0x53d527)&&_0x5c44f9!=='_self')return Yp(_0x3cf041||'',_0x5c44f9),new Dr(null);const _0x5cd92f=window['open'](_0x3cf041||'',_0x5c44f9,_0x296dbb);m(_0x5cd92f,_0x547259,'popup-blocked');try{_0x5cd92f['focus']();}catch{}return new Dr(_0x5cd92f);}function Yp(_0x527ad1,_0x2e08f4){const _0x1792e8=document['createElement']('a');_0x1792e8['href']=_0x527ad1,_0x1792e8['target']=_0x2e08f4;const _0x30b635=document['createEvent']('MouseEvent');_0x30b635['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1792e8['dispatchEvent'](_0x30b635);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x3417b4,_0x2a02b2,_0xc7246a,_0x28973c,_0x2a0b21,_0x18f7b1){m(_0x3417b4['config']['authDomain'],_0x3417b4,'auth-domain-config-required'),m(_0x3417b4['config']['apiKey'],_0x3417b4,'invalid-api-key');const _0x3d587c={'apiKey':_0x3417b4['config']['apiKey'],'appName':_0x3417b4['name'],'authType':_0xc7246a,'redirectUrl':_0x28973c,'v':ct,'eventId':_0x2a0b21};if(_0x2a02b2 instanceof xa){_0x2a02b2['setDefaultLanguage'](_0x3417b4['languageCode']),_0x3d587c['providerId']=_0x2a02b2['providerId']||'',hi(_0x2a02b2['getCustomParameters']())||(_0x3d587c['customParameters']=JSON['stringify'](_0x2a02b2['getCustomParameters']()));for(const [_0xcc6256,_0x2ae804]of Object['entries']({}))_0x3d587c[_0xcc6256]=_0x2ae804;}if(_0x2a02b2 instanceof Qt){const _0x2f6d71=_0x2a02b2['getScopes']()['filter'](_0x212e29=>_0x212e29!=='');_0x2f6d71['length']>0x0&&(_0x3d587c['scopes']=_0x2f6d71['join'](','));}_0x3417b4['tenantId']&&(_0x3d587c['tid']=_0x3417b4['tenantId']);const _0x2dcf6f=_0x3d587c;for(const _0x5bf7df of Object['keys'](_0x2dcf6f))_0x2dcf6f[_0x5bf7df]===void 0x0&&delete _0x2dcf6f[_0x5bf7df];const _0x1ba4ec=await _0x3417b4['_getAppCheckToken'](),_0x34d12b=_0x1ba4ec?'#'+Xp+'='+encodeURIComponent(_0x1ba4ec):'';return Zp(_0x3417b4)+'?'+at(_0x2dcf6f)['slice'](0x1)+_0x34d12b;}function Zp({config:_0x5aae2b}){return _0x5aae2b['emulator']?Is(_0x5aae2b,Jp):'https://'+_0x5aae2b['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x114789,_0x36ac7b,_0x4185fd,_0x2ada89){var _0x2c1b9f;ae((_0x2c1b9f=this['eventManagers'][_0x114789['_key']()])==null?void 0x0:_0x2c1b9f['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xb070fa=await Mr(_0x114789,_0x36ac7b,_0x4185fd,Ni(),_0x2ada89);return Kp(_0x114789,_0xb070fa,bs());}async['_openRedirect'](_0x53db0d,_0x50b5ed,_0x393f86,_0x562911){await this['_originValidation'](_0x53db0d);const _0x4eca31=await Mr(_0x53db0d,_0x50b5ed,_0x393f86,Ni(),_0x562911);return ip(_0x4eca31),new Promise(()=>{});}['_initialize'](_0x3c65bb){const _0x46744f=_0x3c65bb['_key']();if(this['eventManagers'][_0x46744f]){const {manager:_0x55833c,promise:_0x2d2d43}=this['eventManagers'][_0x46744f];return _0x55833c?Promise['resolve'](_0x55833c):(ae(_0x2d2d43,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2d2d43);}const _0x4cda5e=this['initAndGetManager'](_0x3c65bb);return this['eventManagers'][_0x46744f]={'promise':_0x4cda5e},_0x4cda5e['catch'](()=>{delete this['eventManagers'][_0x46744f];}),_0x4cda5e;}async['initAndGetManager'](_0x1587f3){const _0x759986=await Hp(_0x1587f3),_0x1be190=new bp(_0x1587f3);return _0x759986['register']('authEvent',_0x125f98=>(m(_0x125f98==null?void 0x0:_0x125f98['authEvent'],_0x1587f3,'invalid-auth-event'),{'status':_0x1be190['onEvent'](_0x125f98['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1587f3['_key']()]={'manager':_0x1be190},this['iframes'][_0x1587f3['_key']()]=_0x759986,_0x1be190;}['_isIframeWebStorageSupported'](_0x2eb9f5,_0x5d0a81){this['iframes'][_0x2eb9f5['_key']()]['send'](li,{'type':li},_0x3d206c=>{var _0x1042c4;const _0x55fd61=(_0x1042c4=_0x3d206c==null?void 0x0:_0x3d206c[0x0])==null?void 0x0:_0x1042c4[li];_0x55fd61!==void 0x0&&_0x5d0a81(!!_0x55fd61),K(_0x2eb9f5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x364a54){const _0x422eba=_0x364a54['_key']();return this['originValidationPromises'][_0x422eba]||(this['originValidationPromises'][_0x422eba]=Pp(_0x364a54)),this['originValidationPromises'][_0x422eba];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0xc4f4a){this['auth']=_0xc4f4a,this['internalListeners']=new Map();}['getUid'](){var _0x20d508;return this['assertAuthConfigured'](),((_0x20d508=this['auth']['currentUser'])==null?void 0x0:_0x20d508['uid'])||null;}async['getToken'](_0x711022){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x711022)}:null;}['addAuthTokenListener'](_0x272d5c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x272d5c))return;const _0x5dbfe8=this['auth']['onIdTokenChanged'](_0x4b9d54=>{_0x272d5c((_0x4b9d54==null?void 0x0:_0x4b9d54['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x272d5c,_0x5dbfe8),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x101871){this['assertAuthConfigured']();const _0x487b2b=this['internalListeners']['get'](_0x101871);_0x487b2b&&(this['internalListeners']['delete'](_0x101871),_0x487b2b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x15a3b5){switch(_0x15a3b5){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x335705){et(new Me('auth',(_0x2bed2b,{options:_0xf9fd34})=>{const _0xfc141e=_0x2bed2b['getProvider']('app')['getImmediate'](),_0x4a3218=_0x2bed2b['getProvider']('heartbeat'),_0x4ab195=_0x2bed2b['getProvider']('app-check-internal'),{apiKey:_0x28daed,authDomain:_0x1854b8}=_0xfc141e['options'];m(_0x28daed&&!_0x28daed['includes'](':'),'invalid-api-key',{'appName':_0xfc141e['name']});const _0x301237={'apiKey':_0x28daed,'authDomain':_0x1854b8,'clientPlatform':_0x335705,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x335705)},_0x244987=new bf(_0xfc141e,_0x4a3218,_0x4ab195,_0x301237);return Lf(_0x244987,_0xf9fd34),_0x244987;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1cd5f8,_0x2bf045,_0x154ec0)=>{_0x1cd5f8['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x4b5d59=>{const _0xbd95b5=qe(_0x4b5d59['getProvider']('auth')['getImmediate']());return(_0x5494a5=>new n_(_0x5494a5))(_0xbd95b5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x335705)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0xd91380=>async _0x2055dd=>{const _0x1b6851=_0x2055dd&&await _0x2055dd['getIdTokenResult'](),_0x51b25b=_0x1b6851&&(new Date()['getTime']()-Date['parse'](_0x1b6851['issuedAtTime']))/0x3e8;if(_0x51b25b&&_0x51b25b>o_)return;const _0x5cba41=_0x1b6851==null?void 0x0:_0x1b6851['token'];Fr!==_0x5cba41&&(Fr=_0x5cba41,await fetch(_0xd91380,{'method':_0x5cba41?'POST':'DELETE','headers':_0x5cba41?{'Authorization':'Bearer\x20'+_0x5cba41}:{}}));};function O_(_0x16de9b=Qr()){const _0x4bd27e=Ui(_0x16de9b,'auth');if(_0x4bd27e['isInitialized']())return _0x4bd27e['getImmediate']();const _0x1228fd=Mf(_0x16de9b,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x54237d=Gr('authTokenSyncURL');if(_0x54237d&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4cfb2f=new URL(_0x54237d,location['origin']);if(location['origin']===_0x4cfb2f['origin']){const _0x418978=a_(_0x4cfb2f['toString']());Jf(_0x1228fd,_0x418978,()=>_0x418978(_0x1228fd['currentUser'])),Qf(_0x1228fd,_0x10a2ae=>_0x418978(_0x10a2ae));}}const _0x51713f=Hr('auth');return _0x51713f&&xf(_0x1228fd,'http://'+_0x51713f),_0x1228fd;}function c_(){var _0x761d51;return((_0x761d51=document['getElementsByTagName']('head'))==null?void 0x0:_0x761d51[0x0])??document;}Rf({'loadJS'(_0x11442c){return new Promise((_0x153f9f,_0x24afd8)=>{const _0x17f2cc=document['createElement']('script');_0x17f2cc['setAttribute']('src',_0x11442c),_0x17f2cc['onload']=_0x153f9f,_0x17f2cc['onerror']=_0x44e522=>{const _0x21a290=J('internal-error');_0x21a290['customData']=_0x44e522,_0x24afd8(_0x21a290);},_0x17f2cc['type']='text/javascript',_0x17f2cc['charset']='UTF-8',c_()['appendChild'](_0x17f2cc);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};