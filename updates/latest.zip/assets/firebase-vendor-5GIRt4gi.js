const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2e92c0,_0x22a412){if(!_0x2e92c0)throw ot(_0x22a412);},ot=function(_0x20dba9){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x20dba9);},Wr=function(_0x5385de){const _0x1c2bec=[];let _0x3dc133=0x0;for(let _0x3caf39=0x0;_0x3caf39<_0x5385de['length'];_0x3caf39++){let _0x1bdab3=_0x5385de['charCodeAt'](_0x3caf39);_0x1bdab3<0x80?_0x1c2bec[_0x3dc133++]=_0x1bdab3:_0x1bdab3<0x800?(_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0x6|0xc0,_0x1c2bec[_0x3dc133++]=_0x1bdab3&0x3f|0x80):(_0x1bdab3&0xfc00)===0xd800&&_0x3caf39+0x1<_0x5385de['length']&&(_0x5385de['charCodeAt'](_0x3caf39+0x1)&0xfc00)===0xdc00?(_0x1bdab3=0x10000+((_0x1bdab3&0x3ff)<<0xa)+(_0x5385de['charCodeAt'](++_0x3caf39)&0x3ff),_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0x12|0xf0,_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0xc&0x3f|0x80,_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0x6&0x3f|0x80,_0x1c2bec[_0x3dc133++]=_0x1bdab3&0x3f|0x80):(_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0xc|0xe0,_0x1c2bec[_0x3dc133++]=_0x1bdab3>>0x6&0x3f|0x80,_0x1c2bec[_0x3dc133++]=_0x1bdab3&0x3f|0x80);}return _0x1c2bec;},Za=function(_0x2849b5){const _0x1eb0ca=[];let _0x511b63=0x0,_0x578426=0x0;for(;_0x511b63<_0x2849b5['length'];){const _0x2f4368=_0x2849b5[_0x511b63++];if(_0x2f4368<0x80)_0x1eb0ca[_0x578426++]=String['fromCharCode'](_0x2f4368);else{if(_0x2f4368>0xbf&&_0x2f4368<0xe0){const _0x1ce921=_0x2849b5[_0x511b63++];_0x1eb0ca[_0x578426++]=String['fromCharCode']((_0x2f4368&0x1f)<<0x6|_0x1ce921&0x3f);}else{if(_0x2f4368>0xef&&_0x2f4368<0x16d){const _0x11f6b0=_0x2849b5[_0x511b63++],_0x58f645=_0x2849b5[_0x511b63++],_0x24d717=_0x2849b5[_0x511b63++],_0x40c0d4=((_0x2f4368&0x7)<<0x12|(_0x11f6b0&0x3f)<<0xc|(_0x58f645&0x3f)<<0x6|_0x24d717&0x3f)-0x10000;_0x1eb0ca[_0x578426++]=String['fromCharCode'](0xd800+(_0x40c0d4>>0xa)),_0x1eb0ca[_0x578426++]=String['fromCharCode'](0xdc00+(_0x40c0d4&0x3ff));}else{const _0x31b0f9=_0x2849b5[_0x511b63++],_0x20a474=_0x2849b5[_0x511b63++];_0x1eb0ca[_0x578426++]=String['fromCharCode']((_0x2f4368&0xf)<<0xc|(_0x31b0f9&0x3f)<<0x6|_0x20a474&0x3f);}}}}return _0x1eb0ca['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x57da98,_0x2dd3bd){if(!Array['isArray'](_0x57da98))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3ef5fd=_0x2dd3bd?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x356830=[];for(let _0x51aeb6=0x0;_0x51aeb6<_0x57da98['length'];_0x51aeb6+=0x3){const _0x3460fd=_0x57da98[_0x51aeb6],_0x2c8bbe=_0x51aeb6+0x1<_0x57da98['length'],_0xf83517=_0x2c8bbe?_0x57da98[_0x51aeb6+0x1]:0x0,_0x369dc4=_0x51aeb6+0x2<_0x57da98['length'],_0x193bc4=_0x369dc4?_0x57da98[_0x51aeb6+0x2]:0x0,_0x3cd7e4=_0x3460fd>>0x2,_0x467e84=(_0x3460fd&0x3)<<0x4|_0xf83517>>0x4;let _0x119855=(_0xf83517&0xf)<<0x2|_0x193bc4>>0x6,_0x474d25=_0x193bc4&0x3f;_0x369dc4||(_0x474d25=0x40,_0x2c8bbe||(_0x119855=0x40)),_0x356830['push'](_0x3ef5fd[_0x3cd7e4],_0x3ef5fd[_0x467e84],_0x3ef5fd[_0x119855],_0x3ef5fd[_0x474d25]);}return _0x356830['join']('');},'encodeString'(_0x56c9d4,_0x48de94){return this['HAS_NATIVE_SUPPORT']&&!_0x48de94?btoa(_0x56c9d4):this['encodeByteArray'](Wr(_0x56c9d4),_0x48de94);},'decodeString'(_0x4043ed,_0x237768){return this['HAS_NATIVE_SUPPORT']&&!_0x237768?atob(_0x4043ed):Za(this['decodeStringToByteArray'](_0x4043ed,_0x237768));},'decodeStringToByteArray'(_0x5363d3,_0x1276b4){this['init_']();const _0x3caeef=_0x1276b4?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x31828d=[];for(let _0x19515f=0x0;_0x19515f<_0x5363d3['length'];){const _0x1ec54f=_0x3caeef[_0x5363d3['charAt'](_0x19515f++)],_0x18c9d9=_0x19515f<_0x5363d3['length']?_0x3caeef[_0x5363d3['charAt'](_0x19515f)]:0x0;++_0x19515f;const _0x33436e=_0x19515f<_0x5363d3['length']?_0x3caeef[_0x5363d3['charAt'](_0x19515f)]:0x40;++_0x19515f;const _0x35e96b=_0x19515f<_0x5363d3['length']?_0x3caeef[_0x5363d3['charAt'](_0x19515f)]:0x40;if(++_0x19515f,_0x1ec54f==null||_0x18c9d9==null||_0x33436e==null||_0x35e96b==null)throw new ec();const _0x554e30=_0x1ec54f<<0x2|_0x18c9d9>>0x4;if(_0x31828d['push'](_0x554e30),_0x33436e!==0x40){const _0x29f3c0=_0x18c9d9<<0x4&0xf0|_0x33436e>>0x2;if(_0x31828d['push'](_0x29f3c0),_0x35e96b!==0x40){const _0x437fb9=_0x33436e<<0x6&0xc0|_0x35e96b;_0x31828d['push'](_0x437fb9);}}}return _0x31828d;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x339b37=0x0;_0x339b37<this['ENCODED_VALS']['length'];_0x339b37++)this['byteToCharMap_'][_0x339b37]=this['ENCODED_VALS']['charAt'](_0x339b37),this['charToByteMap_'][this['byteToCharMap_'][_0x339b37]]=_0x339b37,this['byteToCharMapWebSafe_'][_0x339b37]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x339b37),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x339b37]]=_0x339b37,_0x339b37>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x339b37)]=_0x339b37,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x339b37)]=_0x339b37);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x3ff683){const _0x674614=Wr(_0x3ff683);return Di['encodeByteArray'](_0x674614,!0x0);},an=function(_0x3a9ed7){return Br(_0x3a9ed7)['replace'](/\./g,'');},cn=function(_0x391183){try{return Di['decodeString'](_0x391183,!0x0);}catch(_0x347d97){console['error']('base64Decode\x20failed:\x20',_0x347d97);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3326af){return Vr(void 0x0,_0x3326af);}function Vr(_0x28f5ba,_0x683c30){if(!(_0x683c30 instanceof Object))return _0x683c30;switch(_0x683c30['constructor']){case Date:const _0x5b7aec=_0x683c30;return new Date(_0x5b7aec['getTime']());case Object:_0x28f5ba===void 0x0&&(_0x28f5ba={});break;case Array:_0x28f5ba=[];break;default:return _0x683c30;}for(const _0x53f074 in _0x683c30)!_0x683c30['hasOwnProperty'](_0x53f074)||!nc(_0x53f074)||(_0x28f5ba[_0x53f074]=Vr(_0x28f5ba[_0x53f074],_0x683c30[_0x53f074]));return _0x28f5ba;}function nc(_0x17b2dc){return _0x17b2dc!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x4a699c=As['__FIREBASE_DEFAULTS__'];if(_0x4a699c)return JSON['parse'](_0x4a699c);},oc=()=>{if(typeof document>'u')return;let _0x136e9d;try{_0x136e9d=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x35dada=_0x136e9d&&cn(_0x136e9d[0x1]);return _0x35dada&&JSON['parse'](_0x35dada);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x5dc0ea){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5dc0ea);return;}},Hr=_0x535478=>{var _0x4720f4,_0x2de5e7;return(_0x2de5e7=(_0x4720f4=Mi())==null?void 0x0:_0x4720f4['emulatorHosts'])==null?void 0x0:_0x2de5e7[_0x535478];},ac=_0x295f52=>{const _0x5c427c=Hr(_0x295f52);if(!_0x5c427c)return;const _0x590a22=_0x5c427c['lastIndexOf'](':');if(_0x590a22<=0x0||_0x590a22+0x1===_0x5c427c['length'])throw new Error('Invalid\x20host\x20'+_0x5c427c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x54c253=parseInt(_0x5c427c['substring'](_0x590a22+0x1),0xa);return _0x5c427c[0x0]==='['?[_0x5c427c['substring'](0x1,_0x590a22-0x1),_0x54c253]:[_0x5c427c['substring'](0x0,_0x590a22),_0x54c253];},$r=()=>{var _0x381f79;return(_0x381f79=Mi())==null?void 0x0:_0x381f79['config'];},Gr=_0x51b088=>{var _0x1a3446;return(_0x1a3446=Mi())==null?void 0x0:_0x1a3446['_'+_0x51b088];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x23d86d,_0x563d37)=>{this['resolve']=_0x23d86d,this['reject']=_0x563d37;});}['wrapCallback'](_0x3858b3){return(_0x5f3cf7,_0x20af81)=>{_0x5f3cf7?this['reject'](_0x5f3cf7):this['resolve'](_0x20af81),typeof _0x3858b3=='function'&&(this['promise']['catch'](()=>{}),_0x3858b3['length']===0x1?_0x3858b3(_0x5f3cf7):_0x3858b3(_0x5f3cf7,_0x20af81));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3b353f,_0x4aee2f){if(_0x3b353f['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x33be16={'alg':'none','type':'JWT'},_0x425514=_0x4aee2f||'demo-project',_0x37856e=_0x3b353f['iat']||0x0,_0x54c032=_0x3b353f['sub']||_0x3b353f['user_id'];if(!_0x54c032)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3eae1c={'iss':'https://securetoken.google.com/'+_0x425514,'aud':_0x425514,'iat':_0x37856e,'exp':_0x37856e+0xe10,'auth_time':_0x37856e,'sub':_0x54c032,'user_id':_0x54c032,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3b353f};return[an(JSON['stringify'](_0x33be16)),an(JSON['stringify'](_0x3eae1c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x2eeeaa=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2eeeaa=='object'&&_0x2eeeaa['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x32b6ca=W();return _0x32b6ca['indexOf']('MSIE\x20')>=0x0||_0x32b6ca['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x41103a,_0x42a059)=>{try{let _0x5b71b7=!0x0;const _0x52aa01='validate-browser-context-for-indexeddb-analytics-module',_0x460abe=self['indexedDB']['open'](_0x52aa01);_0x460abe['onsuccess']=()=>{_0x460abe['result']['close'](),_0x5b71b7||self['indexedDB']['deleteDatabase'](_0x52aa01),_0x41103a(!0x0);},_0x460abe['onupgradeneeded']=()=>{_0x5b71b7=!0x1;},_0x460abe['onerror']=()=>{var _0x5dbfd7;_0x42a059(((_0x5dbfd7=_0x460abe['error'])==null?void 0x0:_0x5dbfd7['message'])||'');};}catch(_0x439276){_0x42a059(_0x439276);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x3ccb17,_0x1f522b,_0x159df5){super(_0x1f522b),this['code']=_0x3ccb17,this['customData']=_0x159df5,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x6687b7,_0x2f8086,_0x181dc0){this['service']=_0x6687b7,this['serviceName']=_0x2f8086,this['errors']=_0x181dc0;}['create'](_0x4a7743,..._0x37d654){const _0x164fc7=_0x37d654[0x0]||{},_0x22109c=this['service']+'/'+_0x4a7743,_0x428032=this['errors'][_0x4a7743],_0x2c29dc=_0x428032?gc(_0x428032,_0x164fc7):'Error',_0x531eba=this['serviceName']+':\x20'+_0x2c29dc+'\x20('+_0x22109c+').';return new Se(_0x22109c,_0x531eba,_0x164fc7);}}function gc(_0x1ba206,_0x49c46a){return _0x1ba206['replace'](mc,(_0x5c7013,_0x520196)=>{const _0xab0620=_0x49c46a[_0x520196];return _0xab0620!=null?String(_0xab0620):'<'+_0x520196+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x1d4288){return JSON['parse'](_0x1d4288);}function O(_0x51acb1){return JSON['stringify'](_0x51acb1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x305b65){let _0x21e7c8={},_0x18d8ee={},_0x256af0={},_0x1c6dec='';try{const _0x4d6667=_0x305b65['split']('.');_0x21e7c8=bt(cn(_0x4d6667[0x0])||''),_0x18d8ee=bt(cn(_0x4d6667[0x1])||''),_0x1c6dec=_0x4d6667[0x2],_0x256af0=_0x18d8ee['d']||{},delete _0x18d8ee['d'];}catch{}return{'header':_0x21e7c8,'claims':_0x18d8ee,'data':_0x256af0,'signature':_0x1c6dec};},yc=function(_0x24bf9d){const _0x494202=zr(_0x24bf9d),_0x56434c=_0x494202['claims'];return!!_0x56434c&&typeof _0x56434c=='object'&&_0x56434c['hasOwnProperty']('iat');},vc=function(_0x2b655f){const _0xca3ed7=zr(_0x2b655f)['claims'];return typeof _0xca3ed7=='object'&&_0xca3ed7['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x42ed5e,_0x3e0cd2){return Object['prototype']['hasOwnProperty']['call'](_0x42ed5e,_0x3e0cd2);}function Oe(_0x39ff2f,_0x4b19ec){if(Object['prototype']['hasOwnProperty']['call'](_0x39ff2f,_0x4b19ec))return _0x39ff2f[_0x4b19ec];}function hi(_0x5ce01e){for(const _0x4be4d4 in _0x5ce01e)if(Object['prototype']['hasOwnProperty']['call'](_0x5ce01e,_0x4be4d4))return!0x1;return!0x0;}function ln(_0x4429ba,_0x219eb3,_0x994c84){const _0x2f11b5={};for(const _0x24fc2b in _0x4429ba)Object['prototype']['hasOwnProperty']['call'](_0x4429ba,_0x24fc2b)&&(_0x2f11b5[_0x24fc2b]=_0x219eb3['call'](_0x994c84,_0x4429ba[_0x24fc2b],_0x24fc2b,_0x4429ba));return _0x2f11b5;}function De(_0x544b48,_0x17a514){if(_0x544b48===_0x17a514)return!0x0;const _0xffb77e=Object['keys'](_0x544b48),_0x341f86=Object['keys'](_0x17a514);for(const _0xa5fa3a of _0xffb77e){if(!_0x341f86['includes'](_0xa5fa3a))return!0x1;const _0x119377=_0x544b48[_0xa5fa3a],_0x17e0e5=_0x17a514[_0xa5fa3a];if(ks(_0x119377)&&ks(_0x17e0e5)){if(!De(_0x119377,_0x17e0e5))return!0x1;}else{if(_0x119377!==_0x17e0e5)return!0x1;}}for(const _0x1f088e of _0x341f86)if(!_0xffb77e['includes'](_0x1f088e))return!0x1;return!0x0;}function ks(_0x509ebd){return _0x509ebd!==null&&typeof _0x509ebd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x25d30f){const _0x25631a=[];for(const [_0xde606b,_0xfb5426]of Object['entries'](_0x25d30f))Array['isArray'](_0xfb5426)?_0xfb5426['forEach'](_0x1597a6=>{_0x25631a['push'](encodeURIComponent(_0xde606b)+'='+encodeURIComponent(_0x1597a6));}):_0x25631a['push'](encodeURIComponent(_0xde606b)+'='+encodeURIComponent(_0xfb5426));return _0x25631a['length']?'&'+_0x25631a['join']('&'):'';}function yt(_0x59d10f){const _0x454b8c={};return _0x59d10f['replace'](/^\?/,'')['split']('&')['forEach'](_0x21c417=>{if(_0x21c417){const [_0x577564,_0x440757]=_0x21c417['split']('=');_0x454b8c[decodeURIComponent(_0x577564)]=decodeURIComponent(_0x440757);}}),_0x454b8c;}function vt(_0x3e0646){const _0x588314=_0x3e0646['indexOf']('?');if(!_0x588314)return'';const _0x13f62c=_0x3e0646['indexOf']('#',_0x588314);return _0x3e0646['substring'](_0x588314,_0x13f62c>0x0?_0x13f62c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2a0ac6=0x1;_0x2a0ac6<this['blockSize'];++_0x2a0ac6)this['pad_'][_0x2a0ac6]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1391d2,_0x3d1ae2){_0x3d1ae2||(_0x3d1ae2=0x0);const _0x1215fa=this['W_'];if(typeof _0x1391d2=='string'){for(let _0x565367=0x0;_0x565367<0x10;_0x565367++)_0x1215fa[_0x565367]=_0x1391d2['charCodeAt'](_0x3d1ae2)<<0x18|_0x1391d2['charCodeAt'](_0x3d1ae2+0x1)<<0x10|_0x1391d2['charCodeAt'](_0x3d1ae2+0x2)<<0x8|_0x1391d2['charCodeAt'](_0x3d1ae2+0x3),_0x3d1ae2+=0x4;}else{for(let _0x316691=0x0;_0x316691<0x10;_0x316691++)_0x1215fa[_0x316691]=_0x1391d2[_0x3d1ae2]<<0x18|_0x1391d2[_0x3d1ae2+0x1]<<0x10|_0x1391d2[_0x3d1ae2+0x2]<<0x8|_0x1391d2[_0x3d1ae2+0x3],_0x3d1ae2+=0x4;}for(let _0x71be49=0x10;_0x71be49<0x50;_0x71be49++){const _0x5d4760=_0x1215fa[_0x71be49-0x3]^_0x1215fa[_0x71be49-0x8]^_0x1215fa[_0x71be49-0xe]^_0x1215fa[_0x71be49-0x10];_0x1215fa[_0x71be49]=(_0x5d4760<<0x1|_0x5d4760>>>0x1f)&0xffffffff;}let _0x28c367=this['chain_'][0x0],_0x5784d6=this['chain_'][0x1],_0x4696f3=this['chain_'][0x2],_0x418382=this['chain_'][0x3],_0x5cb0e0=this['chain_'][0x4],_0x1dd0a0,_0x41d922;for(let _0x5021cf=0x0;_0x5021cf<0x50;_0x5021cf++){_0x5021cf<0x28?_0x5021cf<0x14?(_0x1dd0a0=_0x418382^_0x5784d6&(_0x4696f3^_0x418382),_0x41d922=0x5a827999):(_0x1dd0a0=_0x5784d6^_0x4696f3^_0x418382,_0x41d922=0x6ed9eba1):_0x5021cf<0x3c?(_0x1dd0a0=_0x5784d6&_0x4696f3|_0x418382&(_0x5784d6|_0x4696f3),_0x41d922=0x8f1bbcdc):(_0x1dd0a0=_0x5784d6^_0x4696f3^_0x418382,_0x41d922=0xca62c1d6);const _0x3c2336=(_0x28c367<<0x5|_0x28c367>>>0x1b)+_0x1dd0a0+_0x5cb0e0+_0x41d922+_0x1215fa[_0x5021cf]&0xffffffff;_0x5cb0e0=_0x418382,_0x418382=_0x4696f3,_0x4696f3=(_0x5784d6<<0x1e|_0x5784d6>>>0x2)&0xffffffff,_0x5784d6=_0x28c367,_0x28c367=_0x3c2336;}this['chain_'][0x0]=this['chain_'][0x0]+_0x28c367&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5784d6&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4696f3&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x418382&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5cb0e0&0xffffffff;}['update'](_0x347752,_0x6fec8a){if(_0x347752==null)return;_0x6fec8a===void 0x0&&(_0x6fec8a=_0x347752['length']);const _0x44641c=_0x6fec8a-this['blockSize'];let _0x4211a4=0x0;const _0x271a28=this['buf_'];let _0x17ea4d=this['inbuf_'];for(;_0x4211a4<_0x6fec8a;){if(_0x17ea4d===0x0){for(;_0x4211a4<=_0x44641c;)this['compress_'](_0x347752,_0x4211a4),_0x4211a4+=this['blockSize'];}if(typeof _0x347752=='string'){for(;_0x4211a4<_0x6fec8a;)if(_0x271a28[_0x17ea4d]=_0x347752['charCodeAt'](_0x4211a4),++_0x17ea4d,++_0x4211a4,_0x17ea4d===this['blockSize']){this['compress_'](_0x271a28),_0x17ea4d=0x0;break;}}else{for(;_0x4211a4<_0x6fec8a;)if(_0x271a28[_0x17ea4d]=_0x347752[_0x4211a4],++_0x17ea4d,++_0x4211a4,_0x17ea4d===this['blockSize']){this['compress_'](_0x271a28),_0x17ea4d=0x0;break;}}}this['inbuf_']=_0x17ea4d,this['total_']+=_0x6fec8a;}['digest'](){const _0x5bc1b1=[];let _0x3693aa=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x39cd7c=this['blockSize']-0x1;_0x39cd7c>=0x38;_0x39cd7c--)this['buf_'][_0x39cd7c]=_0x3693aa&0xff,_0x3693aa/=0x100;this['compress_'](this['buf_']);let _0x1cd2f2=0x0;for(let _0x56d587=0x0;_0x56d587<0x5;_0x56d587++)for(let _0x21e114=0x18;_0x21e114>=0x0;_0x21e114-=0x8)_0x5bc1b1[_0x1cd2f2]=this['chain_'][_0x56d587]>>_0x21e114&0xff,++_0x1cd2f2;return _0x5bc1b1;}}function Ic(_0x5cb8f5,_0x3e690e){const _0x5dd124=new wc(_0x5cb8f5,_0x3e690e);return _0x5dd124['subscribe']['bind'](_0x5dd124);}class wc{constructor(_0x5f345f,_0x43703f){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x43703f,this['task']['then'](()=>{_0x5f345f(this);})['catch'](_0x1cf09f=>{this['error'](_0x1cf09f);});}['next'](_0x3e60c1){this['forEachObserver'](_0x1785a8=>{_0x1785a8['next'](_0x3e60c1);});}['error'](_0x306098){this['forEachObserver'](_0x28eb25=>{_0x28eb25['error'](_0x306098);}),this['close'](_0x306098);}['complete'](){this['forEachObserver'](_0x482b22=>{_0x482b22['complete']();}),this['close']();}['subscribe'](_0x1ec8e5,_0x2acf31,_0x5aec18){let _0x55e67c;if(_0x1ec8e5===void 0x0&&_0x2acf31===void 0x0&&_0x5aec18===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x1ec8e5,['next','error','complete'])?_0x55e67c=_0x1ec8e5:_0x55e67c={'next':_0x1ec8e5,'error':_0x2acf31,'complete':_0x5aec18},_0x55e67c['next']===void 0x0&&(_0x55e67c['next']=Qn),_0x55e67c['error']===void 0x0&&(_0x55e67c['error']=Qn),_0x55e67c['complete']===void 0x0&&(_0x55e67c['complete']=Qn);const _0x415c60=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x55e67c['error'](this['finalError']):_0x55e67c['complete']();}catch{}}),this['observers']['push'](_0x55e67c),_0x415c60;}['unsubscribeOne'](_0x2bf4ed){this['observers']===void 0x0||this['observers'][_0x2bf4ed]===void 0x0||(delete this['observers'][_0x2bf4ed],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3ce341){if(!this['finalized']){for(let _0x97f818=0x0;_0x97f818<this['observers']['length'];_0x97f818++)this['sendOne'](_0x97f818,_0x3ce341);}}['sendOne'](_0x30f1c7,_0xc07bd9){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x30f1c7]!==void 0x0)try{_0xc07bd9(this['observers'][_0x30f1c7]);}catch(_0x32a562){typeof console<'u'&&console['error']&&console['error'](_0x32a562);}});}['close'](_0x594221){this['finalized']||(this['finalized']=!0x0,_0x594221!==void 0x0&&(this['finalError']=_0x594221),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x2a20dd,_0x18a6c8){if(typeof _0x2a20dd!='object'||_0x2a20dd===null)return!0x1;for(const _0x309e7d of _0x18a6c8)if(_0x309e7d in _0x2a20dd&&typeof _0x2a20dd[_0x309e7d]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x205679,_0xb551fc){return _0x205679+'\x20failed:\x20'+_0xb551fc+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x52ba72){const _0x4e838a=[];let _0x3edf01=0x0;for(let _0x3380b9=0x0;_0x3380b9<_0x52ba72['length'];_0x3380b9++){let _0x35f038=_0x52ba72['charCodeAt'](_0x3380b9);if(_0x35f038>=0xd800&&_0x35f038<=0xdbff){const _0x15b500=_0x35f038-0xd800;_0x3380b9++,f(_0x3380b9<_0x52ba72['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1ae5b8=_0x52ba72['charCodeAt'](_0x3380b9)-0xdc00;_0x35f038=0x10000+(_0x15b500<<0xa)+_0x1ae5b8;}_0x35f038<0x80?_0x4e838a[_0x3edf01++]=_0x35f038:_0x35f038<0x800?(_0x4e838a[_0x3edf01++]=_0x35f038>>0x6|0xc0,_0x4e838a[_0x3edf01++]=_0x35f038&0x3f|0x80):_0x35f038<0x10000?(_0x4e838a[_0x3edf01++]=_0x35f038>>0xc|0xe0,_0x4e838a[_0x3edf01++]=_0x35f038>>0x6&0x3f|0x80,_0x4e838a[_0x3edf01++]=_0x35f038&0x3f|0x80):(_0x4e838a[_0x3edf01++]=_0x35f038>>0x12|0xf0,_0x4e838a[_0x3edf01++]=_0x35f038>>0xc&0x3f|0x80,_0x4e838a[_0x3edf01++]=_0x35f038>>0x6&0x3f|0x80,_0x4e838a[_0x3edf01++]=_0x35f038&0x3f|0x80);}return _0x4e838a;},Pn=function(_0x4447bf){let _0x1d6c2a=0x0;for(let _0x1dc270=0x0;_0x1dc270<_0x4447bf['length'];_0x1dc270++){const _0x1838c0=_0x4447bf['charCodeAt'](_0x1dc270);_0x1838c0<0x80?_0x1d6c2a++:_0x1838c0<0x800?_0x1d6c2a+=0x2:_0x1838c0>=0xd800&&_0x1838c0<=0xdbff?(_0x1d6c2a+=0x4,_0x1dc270++):_0x1d6c2a+=0x3;}return _0x1d6c2a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4a290f){return _0x4a290f&&_0x4a290f['_delegate']?_0x4a290f['_delegate']:_0x4a290f;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x1e908a){try{return(_0x1e908a['startsWith']('http://')||_0x1e908a['startsWith']('https://')?new URL(_0x1e908a)['hostname']:_0x1e908a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x2ed09c){return(await fetch(_0x2ed09c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x2c6aa2,_0x3ad4e8,_0x53b57d){this['name']=_0x2c6aa2,this['instanceFactory']=_0x3ad4e8,this['type']=_0x53b57d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1612f3){return this['instantiationMode']=_0x1612f3,this;}['setMultipleInstances'](_0x2dba5a){return this['multipleInstances']=_0x2dba5a,this;}['setServiceProps'](_0xf223d2){return this['serviceProps']=_0xf223d2,this;}['setInstanceCreatedCallback'](_0x1c771a){return this['onInstanceCreated']=_0x1c771a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4fa5d1,_0x31f0da){this['name']=_0x4fa5d1,this['container']=_0x31f0da,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2bf468){const _0x333a6c=this['normalizeInstanceIdentifier'](_0x2bf468);if(!this['instancesDeferred']['has'](_0x333a6c)){const _0x3e9f6d=new Ve();if(this['instancesDeferred']['set'](_0x333a6c,_0x3e9f6d),this['isInitialized'](_0x333a6c)||this['shouldAutoInitialize']())try{const _0x430953=this['getOrInitializeService']({'instanceIdentifier':_0x333a6c});_0x430953&&_0x3e9f6d['resolve'](_0x430953);}catch{}}return this['instancesDeferred']['get'](_0x333a6c)['promise'];}['getImmediate'](_0x31853b){const _0x19e9e9=this['normalizeInstanceIdentifier'](_0x31853b==null?void 0x0:_0x31853b['identifier']),_0x57b641=(_0x31853b==null?void 0x0:_0x31853b['optional'])??!0x1;if(this['isInitialized'](_0x19e9e9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x19e9e9});}catch(_0x5a35b4){if(_0x57b641)return null;throw _0x5a35b4;}else{if(_0x57b641)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1a4d88){if(_0x1a4d88['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1a4d88['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1a4d88,!!this['shouldAutoInitialize']()){if(Rc(_0x1a4d88))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x322093,_0x54e5b9]of this['instancesDeferred']['entries']()){const _0x54581d=this['normalizeInstanceIdentifier'](_0x322093);try{const _0x25a148=this['getOrInitializeService']({'instanceIdentifier':_0x54581d});_0x54e5b9['resolve'](_0x25a148);}catch{}}}}['clearInstance'](_0x37e740=ke){this['instancesDeferred']['delete'](_0x37e740),this['instancesOptions']['delete'](_0x37e740),this['instances']['delete'](_0x37e740);}async['delete'](){const _0x4e03b5=Array['from'](this['instances']['values']());await Promise['all']([..._0x4e03b5['filter'](_0x14c56e=>'INTERNAL'in _0x14c56e)['map'](_0xa066d4=>_0xa066d4['INTERNAL']['delete']()),..._0x4e03b5['filter'](_0x2128a3=>'_delete'in _0x2128a3)['map'](_0x15cd8d=>_0x15cd8d['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x15bb31=ke){return this['instances']['has'](_0x15bb31);}['getOptions'](_0x50aa71=ke){return this['instancesOptions']['get'](_0x50aa71)||{};}['initialize'](_0x43d7c4={}){const {options:_0x37fda9={}}=_0x43d7c4,_0x214508=this['normalizeInstanceIdentifier'](_0x43d7c4['instanceIdentifier']);if(this['isInitialized'](_0x214508))throw Error(this['name']+'('+_0x214508+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4cbf4b=this['getOrInitializeService']({'instanceIdentifier':_0x214508,'options':_0x37fda9});for(const [_0xf94f09,_0x20649f]of this['instancesDeferred']['entries']()){const _0x4f994c=this['normalizeInstanceIdentifier'](_0xf94f09);_0x214508===_0x4f994c&&_0x20649f['resolve'](_0x4cbf4b);}return _0x4cbf4b;}['onInit'](_0x25c45b,_0x4b0f38){const _0x4dd05a=this['normalizeInstanceIdentifier'](_0x4b0f38),_0x514178=this['onInitCallbacks']['get'](_0x4dd05a)??new Set();_0x514178['add'](_0x25c45b),this['onInitCallbacks']['set'](_0x4dd05a,_0x514178);const _0x205e7c=this['instances']['get'](_0x4dd05a);return _0x205e7c&&_0x25c45b(_0x205e7c,_0x4dd05a),()=>{_0x514178['delete'](_0x25c45b);};}['invokeOnInitCallbacks'](_0x406e41,_0x336ca9){const _0x12d0c6=this['onInitCallbacks']['get'](_0x336ca9);if(_0x12d0c6){for(const _0x2f759e of _0x12d0c6)try{_0x2f759e(_0x406e41,_0x336ca9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xee5303,options:_0x232f9d={}}){let _0x4febd3=this['instances']['get'](_0xee5303);if(!_0x4febd3&&this['component']&&(_0x4febd3=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xee5303),'options':_0x232f9d}),this['instances']['set'](_0xee5303,_0x4febd3),this['instancesOptions']['set'](_0xee5303,_0x232f9d),this['invokeOnInitCallbacks'](_0x4febd3,_0xee5303),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xee5303,_0x4febd3);}catch{}return _0x4febd3||null;}['normalizeInstanceIdentifier'](_0x1cc4fa=ke){return this['component']?this['component']['multipleInstances']?_0x1cc4fa:ke:_0x1cc4fa;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x165310){return _0x165310===ke?void 0x0:_0x165310;}function Rc(_0x4f0629){return _0x4f0629['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x19d9ed){this['name']=_0x19d9ed,this['providers']=new Map();}['addComponent'](_0x2b036e){const _0x6728ec=this['getProvider'](_0x2b036e['name']);if(_0x6728ec['isComponentSet']())throw new Error('Component\x20'+_0x2b036e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x6728ec['setComponent'](_0x2b036e);}['addOrOverwriteComponent'](_0x4e7416){this['getProvider'](_0x4e7416['name'])['isComponentSet']()&&this['providers']['delete'](_0x4e7416['name']),this['addComponent'](_0x4e7416);}['getProvider'](_0x4974bf){if(this['providers']['has'](_0x4974bf))return this['providers']['get'](_0x4974bf);const _0x5acfad=new Sc(_0x4974bf,this);return this['providers']['set'](_0x4974bf,_0x5acfad),_0x5acfad;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x10e997){_0x10e997[_0x10e997['DEBUG']=0x0]='DEBUG',_0x10e997[_0x10e997['VERBOSE']=0x1]='VERBOSE',_0x10e997[_0x10e997['INFO']=0x2]='INFO',_0x10e997[_0x10e997['WARN']=0x3]='WARN',_0x10e997[_0x10e997['ERROR']=0x4]='ERROR',_0x10e997[_0x10e997['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x327045,_0x36f898,..._0x225a03)=>{if(_0x36f898<_0x327045['logLevel'])return;const _0x55b500=new Date()['toISOString'](),_0x235c69=Pc[_0x36f898];if(_0x235c69)console[_0x235c69]('['+_0x55b500+']\x20\x20'+_0x327045['name']+':',..._0x225a03);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x36f898+')');};class xi{constructor(_0x540240){this['name']=_0x540240,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x39a925){if(!(_0x39a925 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x39a925+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x39a925;}['setLogLevel'](_0x3f2334){this['_logLevel']=typeof _0x3f2334=='string'?kc[_0x3f2334]:_0x3f2334;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x90c20d){if(typeof _0x90c20d!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x90c20d;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x6522b7){this['_userLogHandler']=_0x6522b7;}['debug'](..._0x5137aa){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5137aa),this['_logHandler'](this,T['DEBUG'],..._0x5137aa);}['log'](..._0x55862a){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x55862a),this['_logHandler'](this,T['VERBOSE'],..._0x55862a);}['info'](..._0x34912c){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x34912c),this['_logHandler'](this,T['INFO'],..._0x34912c);}['warn'](..._0x1adabd){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1adabd),this['_logHandler'](this,T['WARN'],..._0x1adabd);}['error'](..._0x33d1ee){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x33d1ee),this['_logHandler'](this,T['ERROR'],..._0x33d1ee);}}const Dc=(_0x43cca1,_0x35375e)=>_0x35375e['some'](_0x2a027b=>_0x43cca1 instanceof _0x2a027b);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0xf5a235){const _0x58379f=new Promise((_0x4b5be4,_0xc780d2)=>{const _0x2a3ff4=()=>{_0xf5a235['removeEventListener']('success',_0x4b1807),_0xf5a235['removeEventListener']('error',_0x7105af);},_0x4b1807=()=>{_0x4b5be4(_e(_0xf5a235['result'])),_0x2a3ff4();},_0x7105af=()=>{_0xc780d2(_0xf5a235['error']),_0x2a3ff4();};_0xf5a235['addEventListener']('success',_0x4b1807),_0xf5a235['addEventListener']('error',_0x7105af);});return _0x58379f['then'](_0x5ca7ea=>{_0x5ca7ea instanceof IDBCursor&&Kr['set'](_0x5ca7ea,_0xf5a235);})['catch'](()=>{}),Fi['set'](_0x58379f,_0xf5a235),_0x58379f;}function Fc(_0x198f21){if(ui['has'](_0x198f21))return;const _0x166cf7=new Promise((_0x14baa8,_0xbf602e)=>{const _0x4b47ba=()=>{_0x198f21['removeEventListener']('complete',_0x553eb3),_0x198f21['removeEventListener']('error',_0x3d1f00),_0x198f21['removeEventListener']('abort',_0x3d1f00);},_0x553eb3=()=>{_0x14baa8(),_0x4b47ba();},_0x3d1f00=()=>{_0xbf602e(_0x198f21['error']||new DOMException('AbortError','AbortError')),_0x4b47ba();};_0x198f21['addEventListener']('complete',_0x553eb3),_0x198f21['addEventListener']('error',_0x3d1f00),_0x198f21['addEventListener']('abort',_0x3d1f00);});ui['set'](_0x198f21,_0x166cf7);}let di={'get'(_0x56fd14,_0x3b73e5,_0x5a6a3c){if(_0x56fd14 instanceof IDBTransaction){if(_0x3b73e5==='done')return ui['get'](_0x56fd14);if(_0x3b73e5==='objectStoreNames')return _0x56fd14['objectStoreNames']||Yr['get'](_0x56fd14);if(_0x3b73e5==='store')return _0x5a6a3c['objectStoreNames'][0x1]?void 0x0:_0x5a6a3c['objectStore'](_0x5a6a3c['objectStoreNames'][0x0]);}return _e(_0x56fd14[_0x3b73e5]);},'set'(_0x58ac9a,_0x3c6057,_0x14ad8b){return _0x58ac9a[_0x3c6057]=_0x14ad8b,!0x0;},'has'(_0x3c0471,_0x4b1bfd){return _0x3c0471 instanceof IDBTransaction&&(_0x4b1bfd==='done'||_0x4b1bfd==='store')?!0x0:_0x4b1bfd in _0x3c0471;}};function Uc(_0x3e3a92){di=_0x3e3a92(di);}function Wc(_0x50b1ad){return _0x50b1ad===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4ca5b5,..._0xd37c04){const _0x472f30=_0x50b1ad['call'](Xn(this),_0x4ca5b5,..._0xd37c04);return Yr['set'](_0x472f30,_0x4ca5b5['sort']?_0x4ca5b5['sort']():[_0x4ca5b5]),_e(_0x472f30);}:Lc()['includes'](_0x50b1ad)?function(..._0x2d64f7){return _0x50b1ad['apply'](Xn(this),_0x2d64f7),_e(Kr['get'](this));}:function(..._0x12489c){return _e(_0x50b1ad['apply'](Xn(this),_0x12489c));};}function Bc(_0x39f4a9){return typeof _0x39f4a9=='function'?Wc(_0x39f4a9):(_0x39f4a9 instanceof IDBTransaction&&Fc(_0x39f4a9),Dc(_0x39f4a9,Mc())?new Proxy(_0x39f4a9,di):_0x39f4a9);}function _e(_0x4fa4dd){if(_0x4fa4dd instanceof IDBRequest)return xc(_0x4fa4dd);if(Jn['has'](_0x4fa4dd))return Jn['get'](_0x4fa4dd);const _0x409137=Bc(_0x4fa4dd);return _0x409137!==_0x4fa4dd&&(Jn['set'](_0x4fa4dd,_0x409137),Fi['set'](_0x409137,_0x4fa4dd)),_0x409137;}const Xn=_0x30c703=>Fi['get'](_0x30c703);function Vc(_0xc607b4,_0x171d70,{blocked:_0x299f1d,upgrade:_0x3fea4a,blocking:_0x498ddd,terminated:_0x1b88da}={}){const _0x59fb0e=indexedDB['open'](_0xc607b4,_0x171d70),_0xeede96=_e(_0x59fb0e);return _0x3fea4a&&_0x59fb0e['addEventListener']('upgradeneeded',_0x33dca2=>{_0x3fea4a(_e(_0x59fb0e['result']),_0x33dca2['oldVersion'],_0x33dca2['newVersion'],_e(_0x59fb0e['transaction']),_0x33dca2);}),_0x299f1d&&_0x59fb0e['addEventListener']('blocked',_0xa09ca3=>_0x299f1d(_0xa09ca3['oldVersion'],_0xa09ca3['newVersion'],_0xa09ca3)),_0xeede96['then'](_0x53eeae=>{_0x1b88da&&_0x53eeae['addEventListener']('close',()=>_0x1b88da()),_0x498ddd&&_0x53eeae['addEventListener']('versionchange',_0x4755a9=>_0x498ddd(_0x4755a9['oldVersion'],_0x4755a9['newVersion'],_0x4755a9));})['catch'](()=>{}),_0xeede96;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1c29da,_0x47a9ea){if(!(_0x1c29da instanceof IDBDatabase&&!(_0x47a9ea in _0x1c29da)&&typeof _0x47a9ea=='string'))return;if(Zn['get'](_0x47a9ea))return Zn['get'](_0x47a9ea);const _0x2638d1=_0x47a9ea['replace'](/FromIndex$/,''),_0x46977f=_0x47a9ea!==_0x2638d1,_0x48f3e4=$c['includes'](_0x2638d1);if(!(_0x2638d1 in(_0x46977f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x48f3e4||Hc['includes'](_0x2638d1)))return;const _0xc0d55a=async function(_0x2aad5a,..._0x1afab9){const _0xdf0db1=this['transaction'](_0x2aad5a,_0x48f3e4?'readwrite':'readonly');let _0x63f0ed=_0xdf0db1['store'];return _0x46977f&&(_0x63f0ed=_0x63f0ed['index'](_0x1afab9['shift']())),(await Promise['all']([_0x63f0ed[_0x2638d1](..._0x1afab9),_0x48f3e4&&_0xdf0db1['done']]))[0x0];};return Zn['set'](_0x47a9ea,_0xc0d55a),_0xc0d55a;}Uc(_0x4a00f6=>({..._0x4a00f6,'get':(_0x1c9099,_0x42d464,_0x40dd46)=>Os(_0x1c9099,_0x42d464)||_0x4a00f6['get'](_0x1c9099,_0x42d464,_0x40dd46),'has':(_0x164b8b,_0x1589ce)=>!!Os(_0x164b8b,_0x1589ce)||_0x4a00f6['has'](_0x164b8b,_0x1589ce)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x10d284){this['container']=_0x10d284;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x179cdc=>{if(qc(_0x179cdc)){const _0x200cdc=_0x179cdc['getImmediate']();return _0x200cdc['library']+'/'+_0x200cdc['version'];}else return null;})['filter'](_0x59f146=>_0x59f146)['join']('\x20');}}function qc(_0x27c2c9){const _0x4cd7a5=_0x27c2c9['getComponent']();return(_0x4cd7a5==null?void 0x0:_0x4cd7a5['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x594e7b,_0x483efb){try{_0x594e7b['container']['addComponent'](_0x483efb);}catch(_0x16557b){re['debug']('Component\x20'+_0x483efb['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x594e7b['name'],_0x16557b);}}function et(_0x110d90){const _0x35918e=_0x110d90['name'];if(gi['has'](_0x35918e))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x35918e+'.'),!0x1;gi['set'](_0x35918e,_0x110d90);for(const _0x4ee3c0 of Le['values']())Ms(_0x4ee3c0,_0x110d90);for(const _0x42d341 of _i['values']())Ms(_0x42d341,_0x110d90);return!0x0;}function Ui(_0x35ec17,_0x129cdb){const _0x3bcf31=_0x35ec17['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3bcf31&&_0x3bcf31['triggerHeartbeat'](),_0x35ec17['container']['getProvider'](_0x129cdb);}function H(_0x1fba22){return _0x1fba22==null?!0x1:_0x1fba22['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x85cd27,_0x3b391c,_0x522530){this['_isDeleted']=!0x1,this['_options']={..._0x85cd27},this['_config']={..._0x3b391c},this['_name']=_0x3b391c['name'],this['_automaticDataCollectionEnabled']=_0x3b391c['automaticDataCollectionEnabled'],this['_container']=_0x522530,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5a50c1){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5a50c1;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x104c69){this['_isDeleted']=_0x104c69;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4d3dce,_0x4a3b55={}){let _0x628a26=_0x4d3dce;typeof _0x4a3b55!='object'&&(_0x4a3b55={'name':_0x4a3b55});const _0x283ca2={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4a3b55},_0x2a6c09=_0x283ca2['name'];if(typeof _0x2a6c09!='string'||!_0x2a6c09)throw ge['create']('bad-app-name',{'appName':String(_0x2a6c09)});if(_0x628a26||(_0x628a26=$r()),!_0x628a26)throw ge['create']('no-options');const _0x469a82=Le['get'](_0x2a6c09);if(_0x469a82){if(De(_0x628a26,_0x469a82['options'])&&De(_0x283ca2,_0x469a82['config']))return _0x469a82;throw ge['create']('duplicate-app',{'appName':_0x2a6c09});}const _0x1bb39c=new Ac(_0x2a6c09);for(const _0xad8497 of gi['values']())_0x1bb39c['addComponent'](_0xad8497);const _0xc3f03c=new Il(_0x628a26,_0x283ca2,_0x1bb39c);return Le['set'](_0x2a6c09,_0xc3f03c),_0xc3f03c;}function Qr(_0x4d06fe=pi){const _0x2c49c8=Le['get'](_0x4d06fe);if(!_0x2c49c8&&_0x4d06fe===pi&&$r())return wl();if(!_0x2c49c8)throw ge['create']('no-app',{'appName':_0x4d06fe});return _0x2c49c8;}function l_(){return Array['from'](Le['values']());}async function h_(_0x300b34){let _0x462322=!0x1;const _0x2da1a2=_0x300b34['name'];Le['has'](_0x2da1a2)?(_0x462322=!0x0,Le['delete'](_0x2da1a2)):_i['has'](_0x2da1a2)&&_0x300b34['decRefCount']()<=0x0&&(_i['delete'](_0x2da1a2),_0x462322=!0x0),_0x462322&&(await Promise['all'](_0x300b34['container']['getProviders']()['map'](_0x52f1ce=>_0x52f1ce['delete']())),_0x300b34['isDeleted']=!0x0);}function me(_0x51789f,_0x59b760,_0x53ca7c){let _0x3d1e1d=vl[_0x51789f]??_0x51789f;_0x53ca7c&&(_0x3d1e1d+='-'+_0x53ca7c);const _0x19fd60=_0x3d1e1d['match'](/\s|\//),_0x1343c7=_0x59b760['match'](/\s|\//);if(_0x19fd60||_0x1343c7){const _0x1e7071=['Unable\x20to\x20register\x20library\x20\x22'+_0x3d1e1d+'\x22\x20with\x20version\x20\x22'+_0x59b760+'\x22:'];_0x19fd60&&_0x1e7071['push']('library\x20name\x20\x22'+_0x3d1e1d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x19fd60&&_0x1343c7&&_0x1e7071['push']('and'),_0x1343c7&&_0x1e7071['push']('version\x20name\x20\x22'+_0x59b760+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x1e7071['join']('\x20'));return;}et(new Me(_0x3d1e1d+'-version',()=>({'library':_0x3d1e1d,'version':_0x59b760}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x52262a,_0x2e940d)=>{switch(_0x2e940d){case 0x0:try{_0x52262a['createObjectStore'](Rt);}catch(_0x5e16ad){console['warn'](_0x5e16ad);}}}})['catch'](_0x7abca4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x7abca4['message']});})),ei;}async function Sl(_0xa2d3b9){try{const _0x4759d8=(await Jr())['transaction'](Rt),_0x551411=await _0x4759d8['objectStore'](Rt)['get'](Xr(_0xa2d3b9));return await _0x4759d8['done'],_0x551411;}catch(_0x22439b){if(_0x22439b instanceof Se)re['warn'](_0x22439b['message']);else{const _0x43461b=ge['create']('idb-get',{'originalErrorMessage':_0x22439b==null?void 0x0:_0x22439b['message']});re['warn'](_0x43461b['message']);}}}async function Ls(_0x1a58d6,_0x58eb1f){try{const _0x27e131=(await Jr())['transaction'](Rt,'readwrite');await _0x27e131['objectStore'](Rt)['put'](_0x58eb1f,Xr(_0x1a58d6)),await _0x27e131['done'];}catch(_0x28ae1a){if(_0x28ae1a instanceof Se)re['warn'](_0x28ae1a['message']);else{const _0x4e499b=ge['create']('idb-set',{'originalErrorMessage':_0x28ae1a==null?void 0x0:_0x28ae1a['message']});re['warn'](_0x4e499b['message']);}}}function Xr(_0x409052){return _0x409052['name']+'!'+_0x409052['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0xe4e91b){this['container']=_0xe4e91b,this['_heartbeatsCache']=null;const _0x32c133=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x32c133),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x7534e7=>(this['_heartbeatsCache']=_0x7534e7,_0x7534e7));}async['triggerHeartbeat'](){var _0x442184,_0x5a3c00;try{const _0x1e24e7=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5e2317=xs();if(((_0x442184=this['_heartbeatsCache'])==null?void 0x0:_0x442184['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5a3c00=this['_heartbeatsCache'])==null?void 0x0:_0x5a3c00['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5e2317||this['_heartbeatsCache']['heartbeats']['some'](_0x295dd5=>_0x295dd5['date']===_0x5e2317))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5e2317,'agent':_0x1e24e7}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1061a5=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1061a5,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5a041a){re['warn'](_0x5a041a);}}async['getHeartbeatsHeader'](){var _0x2a6668;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x2a6668=this['_heartbeatsCache'])==null?void 0x0:_0x2a6668['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x375360=xs(),{heartbeatsToSend:_0xfcc9f1,unsentEntries:_0x4cbe36}=kl(this['_heartbeatsCache']['heartbeats']),_0x1e7a27=an(JSON['stringify']({'version':0x2,'heartbeats':_0xfcc9f1}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x375360,_0x4cbe36['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4cbe36,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1e7a27;}catch(_0x55e37f){return re['warn'](_0x55e37f),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x18162a,_0x52e7cd=bl){const _0x2750e0=[];let _0x4108a3=_0x18162a['slice']();for(const _0x3b5bf6 of _0x18162a){const _0x5a67f0=_0x2750e0['find'](_0x532517=>_0x532517['agent']===_0x3b5bf6['agent']);if(_0x5a67f0){if(_0x5a67f0['dates']['push'](_0x3b5bf6['date']),Fs(_0x2750e0)>_0x52e7cd){_0x5a67f0['dates']['pop']();break;}}else{if(_0x2750e0['push']({'agent':_0x3b5bf6['agent'],'dates':[_0x3b5bf6['date']]}),Fs(_0x2750e0)>_0x52e7cd){_0x2750e0['pop']();break;}}_0x4108a3=_0x4108a3['slice'](0x1);}return{'heartbeatsToSend':_0x2750e0,'unsentEntries':_0x4108a3};}class Nl{constructor(_0x57726c){this['app']=_0x57726c,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x521a5b=await Sl(this['app']);return _0x521a5b!=null&&_0x521a5b['heartbeats']?_0x521a5b:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x406f27){if(await this['_canUseIndexedDBPromise']){const _0x41c52b=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x406f27['lastSentHeartbeatDate']??_0x41c52b['lastSentHeartbeatDate'],'heartbeats':_0x406f27['heartbeats']});}else return;}async['add'](_0x2b9fa6){if(await this['_canUseIndexedDBPromise']){const _0x504e23=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x2b9fa6['lastSentHeartbeatDate']??_0x504e23['lastSentHeartbeatDate'],'heartbeats':[..._0x504e23['heartbeats'],..._0x2b9fa6['heartbeats']]});}else return;}}function Fs(_0x40804c){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x40804c}))['length'];}function Pl(_0x40fe6c){if(_0x40fe6c['length']===0x0)return-0x1;let _0x2c0a35=0x0,_0x1b7fd0=_0x40fe6c[0x0]['date'];for(let _0x413241=0x1;_0x413241<_0x40fe6c['length'];_0x413241++)_0x40fe6c[_0x413241]['date']<_0x1b7fd0&&(_0x1b7fd0=_0x40fe6c[_0x413241]['date'],_0x2c0a35=_0x413241);return _0x2c0a35;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x36f7d8){et(new Me('platform-logger',_0x8b157e=>new Gc(_0x8b157e),'PRIVATE')),et(new Me('heartbeat',_0x4e6ddf=>new Al(_0x4e6ddf),'PRIVATE')),me(fi,Ds,_0x36f7d8),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x58dc41){Zr=_0x58dc41;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x35cc4f){this['domStorage_']=_0x35cc4f,this['prefix_']='firebase:';}['set'](_0x4331c8,_0x5805ba){_0x5805ba==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4331c8)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4331c8),O(_0x5805ba));}['get'](_0x29eacf){const _0x537b40=this['domStorage_']['getItem'](this['prefixedName_'](_0x29eacf));return _0x537b40==null?null:bt(_0x537b40);}['remove'](_0x408fd9){this['domStorage_']['removeItem'](this['prefixedName_'](_0x408fd9));}['prefixedName_'](_0x4c42cb){return this['prefix_']+_0x4c42cb;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x470c90,_0x4c1588){_0x4c1588==null?delete this['cache_'][_0x470c90]:this['cache_'][_0x470c90]=_0x4c1588;}['get'](_0x5f1753){return Y(this['cache_'],_0x5f1753)?this['cache_'][_0x5f1753]:null;}['remove'](_0x1332b6){delete this['cache_'][_0x1332b6];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x13d1f9){try{if(typeof window<'u'&&typeof window[_0x13d1f9]<'u'){const _0xd97d11=window[_0x13d1f9];return _0xd97d11['setItem']('firebase:sentinel','cache'),_0xd97d11['removeItem']('firebase:sentinel'),new xl(_0xd97d11);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x3d760f=0x1;return function(){return _0x3d760f++;};}()),no=function(_0x5a7b6b){const _0x3310d0=Tc(_0x5a7b6b),_0x4f5c2f=new Ec();_0x4f5c2f['update'](_0x3310d0);const _0x38d44b=_0x4f5c2f['digest']();return Di['encodeByteArray'](_0x38d44b);},Bt=function(..._0x2e9d19){let _0x15218c='';for(let _0x146391=0x0;_0x146391<_0x2e9d19['length'];_0x146391++){const _0x556892=_0x2e9d19[_0x146391];Array['isArray'](_0x556892)||_0x556892&&typeof _0x556892=='object'&&typeof _0x556892['length']=='number'?_0x15218c+=Bt['apply'](null,_0x556892):typeof _0x556892=='object'?_0x15218c+=O(_0x556892):_0x15218c+=_0x556892,_0x15218c+='\x20';}return _0x15218c;};let Et=null,Vs=!0x0;const Wl=function(_0xa0d93b,_0x59679e){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0xf41f75){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x1e284a=Bt['apply'](null,_0xf41f75);Et(_0x1e284a);}},Vt=function(_0x4b18bd){return function(..._0x76e51b){L(_0x4b18bd,..._0x76e51b);};},mi=function(..._0x1a5985){const _0x7fb7dc='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x1a5985);Qe['error'](_0x7fb7dc);},oe=function(..._0xd979fc){const _0x14be97='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0xd979fc);throw Qe['error'](_0x14be97),new Error(_0x14be97);},U=function(..._0x305c2d){const _0x231845='FIREBASE\x20WARNING:\x20'+Bt(..._0x305c2d);Qe['warn'](_0x231845);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x129ba9){return typeof _0x129ba9=='number'&&(_0x129ba9!==_0x129ba9||_0x129ba9===Number['POSITIVE_INFINITY']||_0x129ba9===Number['NEGATIVE_INFINITY']);},Vl=function(_0x5de612){if(document['readyState']==='complete')_0x5de612();else{let _0x2ac48d=!0x1;const _0x39c61a=function(){if(!document['body']){setTimeout(_0x39c61a,Math['floor'](0xa));return;}_0x2ac48d||(_0x2ac48d=!0x0,_0x5de612());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x39c61a,!0x1),window['addEventListener']('load',_0x39c61a,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x39c61a();}),window['attachEvent']('onload',_0x39c61a));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x449132,_0x1eb97a){if(_0x449132===_0x1eb97a)return 0x0;if(_0x449132===xe||_0x1eb97a===Ie)return-0x1;if(_0x1eb97a===xe||_0x449132===Ie)return 0x1;{const _0x78b7ec=Hs(_0x449132),_0x2a7b75=Hs(_0x1eb97a);return _0x78b7ec!==null?_0x2a7b75!==null?_0x78b7ec-_0x2a7b75===0x0?_0x449132['length']-_0x1eb97a['length']:_0x78b7ec-_0x2a7b75:-0x1:_0x2a7b75!==null?0x1:_0x449132<_0x1eb97a?-0x1:0x1;}},Hl=function(_0x474421,_0x213320){return _0x474421===_0x213320?0x0:_0x474421<_0x213320?-0x1:0x1;},pt=function(_0x239682,_0x203fd6){if(_0x203fd6&&_0x239682 in _0x203fd6)return _0x203fd6[_0x239682];throw new Error('Missing\x20required\x20key\x20('+_0x239682+')\x20in\x20object:\x20'+O(_0x203fd6));},Bi=function(_0x4f30ac){if(typeof _0x4f30ac!='object'||_0x4f30ac===null)return O(_0x4f30ac);const _0x262a38=[];for(const _0x13023e in _0x4f30ac)_0x262a38['push'](_0x13023e);_0x262a38['sort']();let _0x48ee7f='{';for(let _0x552b37=0x0;_0x552b37<_0x262a38['length'];_0x552b37++)_0x552b37!==0x0&&(_0x48ee7f+=','),_0x48ee7f+=O(_0x262a38[_0x552b37]),_0x48ee7f+=':',_0x48ee7f+=Bi(_0x4f30ac[_0x262a38[_0x552b37]]);return _0x48ee7f+='}',_0x48ee7f;},io=function(_0xaa1255,_0x538adb){const _0x40a9f8=_0xaa1255['length'];if(_0x40a9f8<=_0x538adb)return[_0xaa1255];const _0xbda7af=[];for(let _0x1166a5=0x0;_0x1166a5<_0x40a9f8;_0x1166a5+=_0x538adb)_0x1166a5+_0x538adb>_0x40a9f8?_0xbda7af['push'](_0xaa1255['substring'](_0x1166a5,_0x40a9f8)):_0xbda7af['push'](_0xaa1255['substring'](_0x1166a5,_0x1166a5+_0x538adb));return _0xbda7af;};function x(_0x3beec3,_0x4f629a){for(const _0x3b50c7 in _0x3beec3)_0x3beec3['hasOwnProperty'](_0x3b50c7)&&_0x4f629a(_0x3b50c7,_0x3beec3[_0x3b50c7]);}const so=function(_0x22f05c){f(!Wi(_0x22f05c),'Invalid\x20JSON\x20number');const _0x4bf773=0xb,_0x333c67=0x34,_0x2bf355=(0x1<<_0x4bf773-0x1)-0x1;let _0x3a090d,_0x10c8fb,_0x2aef7c,_0x52a5e1,_0x12a0a4;_0x22f05c===0x0?(_0x10c8fb=0x0,_0x2aef7c=0x0,_0x3a090d=0x1/_0x22f05c===-0x1/0x0?0x1:0x0):(_0x3a090d=_0x22f05c<0x0,_0x22f05c=Math['abs'](_0x22f05c),_0x22f05c>=Math['pow'](0x2,0x1-_0x2bf355)?(_0x52a5e1=Math['min'](Math['floor'](Math['log'](_0x22f05c)/Math['LN2']),_0x2bf355),_0x10c8fb=_0x52a5e1+_0x2bf355,_0x2aef7c=Math['round'](_0x22f05c*Math['pow'](0x2,_0x333c67-_0x52a5e1)-Math['pow'](0x2,_0x333c67))):(_0x10c8fb=0x0,_0x2aef7c=Math['round'](_0x22f05c/Math['pow'](0x2,0x1-_0x2bf355-_0x333c67))));const _0x302d4f=[];for(_0x12a0a4=_0x333c67;_0x12a0a4;_0x12a0a4-=0x1)_0x302d4f['push'](_0x2aef7c%0x2?0x1:0x0),_0x2aef7c=Math['floor'](_0x2aef7c/0x2);for(_0x12a0a4=_0x4bf773;_0x12a0a4;_0x12a0a4-=0x1)_0x302d4f['push'](_0x10c8fb%0x2?0x1:0x0),_0x10c8fb=Math['floor'](_0x10c8fb/0x2);_0x302d4f['push'](_0x3a090d?0x1:0x0),_0x302d4f['reverse']();const _0x384202=_0x302d4f['join']('');let _0x5be098='';for(_0x12a0a4=0x0;_0x12a0a4<0x40;_0x12a0a4+=0x8){let _0x475fc7=parseInt(_0x384202['substr'](_0x12a0a4,0x8),0x2)['toString'](0x10);_0x475fc7['length']===0x1&&(_0x475fc7='0'+_0x475fc7),_0x5be098=_0x5be098+_0x475fc7;}return _0x5be098['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x4e7c3b,_0x435ad1){let _0x4caf68='Unknown\x20Error';_0x4e7c3b==='too_big'?_0x4caf68='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4e7c3b==='permission_denied'?_0x4caf68='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4e7c3b==='unavailable'&&(_0x4caf68='The\x20service\x20is\x20unavailable');const _0x415b4f=new Error(_0x4e7c3b+'\x20at\x20'+_0x435ad1['_path']['toString']()+':\x20'+_0x4caf68);return _0x415b4f['code']=_0x4e7c3b['toUpperCase'](),_0x415b4f;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x34d771){if(zl['test'](_0x34d771)){const _0x38839f=Number(_0x34d771);if(_0x38839f>=jl&&_0x38839f<=Kl)return _0x38839f;}return null;},lt=function(_0x1d914c){try{_0x1d914c();}catch(_0x132dee){setTimeout(()=>{const _0x430ea1=_0x132dee['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x430ea1),_0x132dee;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x532c6e,_0x102d43){const _0x58ec93=setTimeout(_0x532c6e,_0x102d43);return typeof _0x58ec93=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x58ec93):typeof _0x58ec93=='object'&&_0x58ec93['unref']&&_0x58ec93['unref'](),_0x58ec93;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x32269a,_0x35fd23){this['appCheckProvider']=_0x35fd23,this['appName']=_0x32269a['name'],H(_0x32269a)&&_0x32269a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x32269a['settings']['appCheckToken']),this['appCheck']=_0x35fd23==null?void 0x0:_0x35fd23['getImmediate']({'optional':!0x0}),this['appCheck']||_0x35fd23==null||_0x35fd23['get']()['then'](_0x53190b=>this['appCheck']=_0x53190b);}['getToken'](_0x59a1b8){if(this['serverAppAppCheckToken']){if(_0x59a1b8)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x59a1b8):new Promise((_0x481782,_0x7b49c1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x59a1b8)['then'](_0x481782,_0x7b49c1):_0x481782(null);},0x0);});}['addTokenChangeListener'](_0x4b3e91){var _0x2682e0;(_0x2682e0=this['appCheckProvider'])==null||_0x2682e0['get']()['then'](_0x5d37d5=>_0x5d37d5['addTokenListener'](_0x4b3e91));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x44ecb5,_0x3332f1,_0x1a56a5){this['appName_']=_0x44ecb5,this['firebaseOptions_']=_0x3332f1,this['authProvider_']=_0x1a56a5,this['auth_']=null,this['auth_']=_0x1a56a5['getImmediate']({'optional':!0x0}),this['auth_']||_0x1a56a5['onInit'](_0x4a88b6=>this['auth_']=_0x4a88b6);}['getToken'](_0x23c0ea){return this['auth_']?this['auth_']['getToken'](_0x23c0ea)['catch'](_0xbf9db5=>_0xbf9db5&&_0xbf9db5['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xbf9db5)):new Promise((_0x2f409c,_0x3df0db)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x23c0ea)['then'](_0x2f409c,_0x3df0db):_0x2f409c(null);},0x0);});}['addTokenChangeListener'](_0x393e29){this['auth_']?this['auth_']['addAuthTokenListener'](_0x393e29):this['authProvider_']['get']()['then'](_0x381092=>_0x381092['addAuthTokenListener'](_0x393e29));}['removeTokenChangeListener'](_0x41cdf6){this['authProvider_']['get']()['then'](_0x164080=>_0x164080['removeAuthTokenListener'](_0x41cdf6));}['notifyForInvalidToken'](){let _0x3fffd9='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3fffd9+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3fffd9+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3fffd9+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3fffd9);}}class tn{constructor(_0x60aa8c){this['accessToken']=_0x60aa8c;}['getToken'](_0x2e485b){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1f1588){_0x1f1588(this['accessToken']);}['removeTokenChangeListener'](_0x5e397c){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1eb094,_0x4b6d1a,_0x508d56,_0x585a41,_0x1163c8=!0x1,_0x3c5d1c='',_0x58b3a6=!0x1,_0x42f16a=!0x1,_0x248723=null){this['secure']=_0x4b6d1a,this['namespace']=_0x508d56,this['webSocketOnly']=_0x585a41,this['nodeAdmin']=_0x1163c8,this['persistenceKey']=_0x3c5d1c,this['includeNamespaceInQueryParams']=_0x58b3a6,this['isUsingEmulator']=_0x42f16a,this['emulatorOptions']=_0x248723,this['_host']=_0x1eb094['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1eb094)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3ff7a3){_0x3ff7a3!==this['internalHost']&&(this['internalHost']=_0x3ff7a3,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5f4175=this['toURLString']();return this['persistenceKey']&&(_0x5f4175+='<'+this['persistenceKey']+'>'),_0x5f4175;}['toURLString'](){const _0x392078=this['secure']?'https://':'http://',_0x1aacf7=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x392078+this['host']+'/'+_0x1aacf7;}}function Xl(_0x4fa49e){return _0x4fa49e['host']!==_0x4fa49e['internalHost']||_0x4fa49e['isCustomHost']()||_0x4fa49e['includeNamespaceInQueryParams'];}function go(_0x394846,_0x10045b,_0x212126){f(typeof _0x10045b=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x212126=='object','typeof\x20params\x20must\x20==\x20object');let _0x3ac982;if(_0x10045b===fo)_0x3ac982=(_0x394846['secure']?'wss://':'ws://')+_0x394846['internalHost']+'/.ws?';else{if(_0x10045b===po)_0x3ac982=(_0x394846['secure']?'https://':'http://')+_0x394846['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x10045b);}Xl(_0x394846)&&(_0x212126['ns']=_0x394846['namespace']);const _0x459740=[];return x(_0x212126,(_0x359c09,_0x170885)=>{_0x459740['push'](_0x359c09+'='+_0x170885);}),_0x3ac982+_0x459740['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0xddaf1c,_0x2c5b1a=0x1){Y(this['counters_'],_0xddaf1c)||(this['counters_'][_0xddaf1c]=0x0),this['counters_'][_0xddaf1c]+=_0x2c5b1a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x3dff3c){const _0x57e8a4=_0x3dff3c['toString']();return ti[_0x57e8a4]||(ti[_0x57e8a4]=new Zl()),ti[_0x57e8a4];}function eh(_0x9765fb,_0xce33){const _0x31ef15=_0x9765fb['toString']();return ni[_0x31ef15]||(ni[_0x31ef15]=_0xce33()),ni[_0x31ef15];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x3d26a7){this['onMessage_']=_0x3d26a7,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2a6224,_0xdc5553){this['closeAfterResponse']=_0x2a6224,this['onClose']=_0xdc5553,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5232bb,_0x331fa9){for(this['pendingResponses'][_0x5232bb]=_0x331fa9;this['pendingResponses'][this['currentResponseNum']];){const _0x333c32=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x236be1=0x0;_0x236be1<_0x333c32['length'];++_0x236be1)_0x333c32[_0x236be1]&&lt(()=>{this['onMessage_'](_0x333c32[_0x236be1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1b8438,_0xec39a0,_0x2956d2,_0x34dfa1,_0x273836,_0x118ff1,_0x2276db){this['connId']=_0x1b8438,this['repoInfo']=_0xec39a0,this['applicationId']=_0x2956d2,this['appCheckToken']=_0x34dfa1,this['authToken']=_0x273836,this['transportSessionId']=_0x118ff1,this['lastSessionId']=_0x2276db,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1b8438),this['stats_']=Hi(_0xec39a0),this['urlFn']=_0x6da772=>(this['appCheckToken']&&(_0x6da772[yi]=this['appCheckToken']),go(_0xec39a0,po,_0x6da772));}['open'](_0x5ca49e,_0xd1cb6){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xd1cb6,this['myPacketOrderer']=new th(_0x5ca49e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x988c57)=>{const [_0x3c9511,_0x5af1d9,_0x42dcae,_0x21bd83,_0x579c8d]=_0x988c57;if(this['incrementIncomingBytes_'](_0x988c57),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3c9511===$s)this['id']=_0x5af1d9,this['password']=_0x42dcae;else{if(_0x3c9511===nh)_0x5af1d9?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5af1d9,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3c9511);}}},(..._0x1ac592)=>{const [_0x565f60,_0x2b9423]=_0x1ac592;this['incrementIncomingBytes_'](_0x1ac592),this['myPacketOrderer']['handleResponse'](_0x565f60,_0x2b9423);},()=>{this['onClosed_']();},this['urlFn']);const _0xe54fed={};_0xe54fed[$s]='t',_0xe54fed[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xe54fed[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xe54fed[ro]=Vi,this['transportSessionId']&&(_0xe54fed[oo]=this['transportSessionId']),this['lastSessionId']&&(_0xe54fed[ho]=this['lastSessionId']),this['applicationId']&&(_0xe54fed[uo]=this['applicationId']),this['appCheckToken']&&(_0xe54fed[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xe54fed[ao]=co);const _0x48a796=this['urlFn'](_0xe54fed);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x48a796),this['scriptTagHolder']['addTag'](_0x48a796,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x52ddee){const _0x12a242=O(_0x52ddee);this['bytesSent']+=_0x12a242['length'],this['stats_']['incrementCounter']('bytes_sent',_0x12a242['length']);const _0x1227cc=Br(_0x12a242),_0x21f757=io(_0x1227cc,hh);for(let _0x2364c4=0x0;_0x2364c4<_0x21f757['length'];_0x2364c4++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x21f757['length'],_0x21f757[_0x2364c4]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x16cadf,_0x5d115b){this['myDisconnFrame']=document['createElement']('iframe');const _0x465ea4={};_0x465ea4[lh]='t',_0x465ea4[mo]=_0x16cadf,_0x465ea4[yo]=_0x5d115b,this['myDisconnFrame']['src']=this['urlFn'](_0x465ea4),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x95043a){const _0x181a25=O(_0x95043a)['length'];this['bytesReceived']+=_0x181a25,this['stats_']['incrementCounter']('bytes_received',_0x181a25);}}class $i{constructor(_0x5482cc,_0x13f701,_0x1b5ae5,_0x3384e7){this['onDisconnect']=_0x1b5ae5,this['urlFn']=_0x3384e7,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x5482cc,window[sh+this['uniqueCallbackIdentifier']]=_0x13f701,this['myIFrame']=$i['createIFrame_']();let _0x3f1ed9='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3f1ed9='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4af14b='<html><body>'+_0x3f1ed9+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4af14b),this['myIFrame']['doc']['close']();}catch(_0x2b934f){L('frame\x20writing\x20exception'),_0x2b934f['stack']&&L(_0x2b934f['stack']),L(_0x2b934f);}}}static['createIFrame_'](){const _0xcafcb9=document['createElement']('iframe');if(_0xcafcb9['style']['display']='none',document['body']){document['body']['appendChild'](_0xcafcb9);try{_0xcafcb9['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x56bc1a=document['domain'];_0xcafcb9['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x56bc1a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xcafcb9['contentDocument']?_0xcafcb9['doc']=_0xcafcb9['contentDocument']:_0xcafcb9['contentWindow']?_0xcafcb9['doc']=_0xcafcb9['contentWindow']['document']:_0xcafcb9['document']&&(_0xcafcb9['doc']=_0xcafcb9['document']),_0xcafcb9;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4b207b=this['onDisconnect'];_0x4b207b&&(this['onDisconnect']=null,_0x4b207b());}['startLongPoll'](_0x405b59,_0x4da933){for(this['myID']=_0x405b59,this['myPW']=_0x4da933,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5de653={};_0x5de653[mo]=this['myID'],_0x5de653[yo]=this['myPW'],_0x5de653[vo]=this['currentSerial'];let _0x44e10d=this['urlFn'](_0x5de653),_0x578280='',_0xc21a01=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x578280['length']<=Eo;){const _0xe7f391=this['pendingSegs']['shift']();_0x578280=_0x578280+'&'+oh+_0xc21a01+'='+_0xe7f391['seg']+'&'+ah+_0xc21a01+'='+_0xe7f391['ts']+'&'+ch+_0xc21a01+'='+_0xe7f391['d'],_0xc21a01++;}return _0x44e10d=_0x44e10d+_0x578280,this['addLongPollTag_'](_0x44e10d,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x51a8aa,_0x2bd792,_0x255431){this['pendingSegs']['push']({'seg':_0x51a8aa,'ts':_0x2bd792,'d':_0x255431}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1cc2e6,_0x5b9691){this['outstandingRequests']['add'](_0x5b9691);const _0x220a4a=()=>{this['outstandingRequests']['delete'](_0x5b9691),this['newRequest_']();},_0x587537=setTimeout(_0x220a4a,Math['floor'](uh)),_0x2e1107=()=>{clearTimeout(_0x587537),_0x220a4a();};this['addTag'](_0x1cc2e6,_0x2e1107);}['addTag'](_0xb335f9,_0x1ea782){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x335ee4=this['myIFrame']['doc']['createElement']('script');_0x335ee4['type']='text/javascript',_0x335ee4['async']=!0x0,_0x335ee4['src']=_0xb335f9,_0x335ee4['onload']=_0x335ee4['onreadystatechange']=function(){const _0x23adee=_0x335ee4['readyState'];(!_0x23adee||_0x23adee==='loaded'||_0x23adee==='complete')&&(_0x335ee4['onload']=_0x335ee4['onreadystatechange']=null,_0x335ee4['parentNode']&&_0x335ee4['parentNode']['removeChild'](_0x335ee4),_0x1ea782());},_0x335ee4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xb335f9),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x335ee4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x212f28,_0x9dffdd,_0x259096,_0x3ef52d,_0x5cab7a,_0x3aeca0,_0x399c21){this['connId']=_0x212f28,this['applicationId']=_0x259096,this['appCheckToken']=_0x3ef52d,this['authToken']=_0x5cab7a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x9dffdd),this['connURL']=G['connectionURL_'](_0x9dffdd,_0x3aeca0,_0x399c21,_0x3ef52d,_0x259096),this['nodeAdmin']=_0x9dffdd['nodeAdmin'];}static['connectionURL_'](_0x248b39,_0x3be127,_0x4d6a54,_0x2a8add,_0x7ff579){const _0x4be985={};return _0x4be985[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4be985[ao]=co),_0x3be127&&(_0x4be985[oo]=_0x3be127),_0x4d6a54&&(_0x4be985[ho]=_0x4d6a54),_0x2a8add&&(_0x4be985[yi]=_0x2a8add),_0x7ff579&&(_0x4be985[uo]=_0x7ff579),go(_0x248b39,fo,_0x4be985);}['open'](_0x2eacfd,_0x3622c0){this['onDisconnect']=_0x3622c0,this['onMessage']=_0x2eacfd,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x52d345;dc(),this['mySock']=new hn(this['connURL'],[],_0x52d345);}catch(_0x25f4bb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xb6dd7=_0x25f4bb['message']||_0x25f4bb['data'];_0xb6dd7&&this['log_'](_0xb6dd7),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xc72cf8=>{this['handleIncomingFrame'](_0xc72cf8);},this['mySock']['onerror']=_0xa9daa6=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x53dddc=_0xa9daa6['message']||_0xa9daa6['data'];_0x53dddc&&this['log_'](_0x53dddc),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x342d54=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x33fe27=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4ae43b=navigator['userAgent']['match'](_0x33fe27);_0x4ae43b&&_0x4ae43b['length']>0x1&&parseFloat(_0x4ae43b[0x1])<4.4&&(_0x342d54=!0x0);}return!_0x342d54&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x22eb73){if(this['frames']['push'](_0x22eb73),this['frames']['length']===this['totalFrames']){const _0x9ecc00=this['frames']['join']('');this['frames']=null;const _0x29f065=bt(_0x9ecc00);this['onMessage'](_0x29f065);}}['handleNewFrameCount_'](_0xb7c377){this['totalFrames']=_0xb7c377,this['frames']=[];}['extractFrameCount_'](_0x1dbe3e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1dbe3e['length']<=0x6){const _0xd1698d=Number(_0x1dbe3e);if(!isNaN(_0xd1698d))return this['handleNewFrameCount_'](_0xd1698d),null;}return this['handleNewFrameCount_'](0x1),_0x1dbe3e;}['handleIncomingFrame'](_0x228212){if(this['mySock']===null)return;const _0x4b0e14=_0x228212['data'];if(this['bytesReceived']+=_0x4b0e14['length'],this['stats_']['incrementCounter']('bytes_received',_0x4b0e14['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4b0e14);else{const _0x11951e=this['extractFrameCount_'](_0x4b0e14);_0x11951e!==null&&this['appendFrame_'](_0x11951e);}}['send'](_0x13b9b7){this['resetKeepAlive']();const _0x574f21=O(_0x13b9b7);this['bytesSent']+=_0x574f21['length'],this['stats_']['incrementCounter']('bytes_sent',_0x574f21['length']);const _0x25df0e=io(_0x574f21,fh);_0x25df0e['length']>0x1&&this['sendString_'](String(_0x25df0e['length']));for(let _0xdfc905=0x0;_0xdfc905<_0x25df0e['length'];_0xdfc905++)this['sendString_'](_0x25df0e[_0xdfc905]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x20a246){try{this['mySock']['send'](_0x20a246);}catch(_0x5ecc75){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5ecc75['message']||_0x5ecc75['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x28db96){this['initTransports_'](_0x28db96);}['initTransports_'](_0x1062ed){const _0x1f12c3=G&&G['isAvailable']();let _0x19e6d7=_0x1f12c3&&!G['previouslyFailed']();if(_0x1062ed['webSocketOnly']&&(_0x1f12c3||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x19e6d7=!0x0),_0x19e6d7)this['transports_']=[G];else{const _0x3fbd2f=this['transports_']=[];for(const _0x242e0f of At['ALL_TRANSPORTS'])_0x242e0f&&_0x242e0f['isAvailable']()&&_0x3fbd2f['push'](_0x242e0f);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0xab2b54,_0x51efae,_0x4c2765,_0x421c33,_0x34f3b0,_0x5decfe,_0x30e0e1,_0x5bfb68,_0x4ddc5f,_0x355a91){this['id']=_0xab2b54,this['repoInfo_']=_0x51efae,this['applicationId_']=_0x4c2765,this['appCheckToken_']=_0x421c33,this['authToken_']=_0x34f3b0,this['onMessage_']=_0x5decfe,this['onReady_']=_0x30e0e1,this['onDisconnect_']=_0x5bfb68,this['onKill_']=_0x4ddc5f,this['lastSessionId']=_0x355a91,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x51efae),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x53cc37=this['transportManager_']['initialTransport']();this['conn_']=new _0x53cc37(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x53cc37['responsesRequiredToBeHealthy']||0x0;const _0x100043=this['connReceiver_'](this['conn_']),_0x459d74=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x100043,_0x459d74);},Math['floor'](0x0));const _0x3f3b94=_0x53cc37['healthyTimeout']||0x0;_0x3f3b94>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3f3b94)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1e9802){return _0x32c3ce=>{_0x1e9802===this['conn_']?this['onConnectionLost_'](_0x32c3ce):_0x1e9802===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3e11aa){return _0x472568=>{this['state_']!==0x2&&(_0x3e11aa===this['rx_']?this['onPrimaryMessageReceived_'](_0x472568):_0x3e11aa===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x472568):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4a8d55){const _0x26e399={'t':'d','d':_0x4a8d55};this['sendData_'](_0x26e399);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5f581f){if(ii in _0x5f581f){const _0x3688fc=_0x5f581f[ii];_0x3688fc===js?this['upgradeIfSecondaryHealthy_']():_0x3688fc===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3688fc===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x21d0bd){const _0x4a3d31=pt('t',_0x21d0bd),_0x2d2a6f=pt('d',_0x21d0bd);if(_0x4a3d31==='c')this['onSecondaryControl_'](_0x2d2a6f);else{if(_0x4a3d31==='d')this['pendingDataMessages']['push'](_0x2d2a6f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4a3d31);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1c095a){const _0x5afcad=pt('t',_0x1c095a),_0x111d35=pt('d',_0x1c095a);_0x5afcad==='c'?this['onControl_'](_0x111d35):_0x5afcad==='d'&&this['onDataMessage_'](_0x111d35);}['onDataMessage_'](_0xd15d7c){this['onPrimaryResponse_'](),this['onMessage_'](_0xd15d7c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4017cb){const _0x53dafb=pt(ii,_0x4017cb);if(Gs in _0x4017cb){const _0xb52200=_0x4017cb[Gs];if(_0x53dafb===Ih){const _0x4a0e55={..._0xb52200};this['repoInfo_']['isUsingEmulator']&&(_0x4a0e55['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4a0e55);}else{if(_0x53dafb===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2f93fa=0x0;_0x2f93fa<this['pendingDataMessages']['length'];++_0x2f93fa)this['onDataMessage_'](this['pendingDataMessages'][_0x2f93fa]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x53dafb===vh?this['onConnectionShutdown_'](_0xb52200):_0x53dafb===qs?this['onReset_'](_0xb52200):_0x53dafb===Eh?mi('Server\x20Error:\x20'+_0xb52200):_0x53dafb===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x53dafb);}}}['onHandshake_'](_0x12daa4){const _0xc6b96d=_0x12daa4['ts'],_0x423d3f=_0x12daa4['v'],_0x486668=_0x12daa4['h'];this['sessionId']=_0x12daa4['s'],this['repoInfo_']['host']=_0x486668,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xc6b96d),Vi!==_0x423d3f&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x228b05=this['transportManager_']['upgradeTransport']();_0x228b05&&this['startUpgrade_'](_0x228b05);}['startUpgrade_'](_0x3f7706){this['secondaryConn_']=new _0x3f7706(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3f7706['responsesRequiredToBeHealthy']||0x0;const _0x16b3fc=this['connReceiver_'](this['secondaryConn_']),_0x5b8424=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x16b3fc,_0x5b8424),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xdbb1d7){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xdbb1d7),this['repoInfo_']['host']=_0xdbb1d7,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x24bb9d,_0x3b30aa){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x24bb9d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3b30aa,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x322b4e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x322b4e||this['rx_']===_0x322b4e)&&this['close']();}['onConnectionLost_'](_0x4a36c1){this['conn_']=null,!_0x4a36c1&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x1ac36d){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x1ac36d),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1de43e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1de43e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x56e426,_0x458fc2,_0x5d9b35,_0x5008da){}['merge'](_0x3ab650,_0x88a48e,_0x4389e2,_0x371f31){}['refreshAuthToken'](_0x43cc43){}['refreshAppCheckToken'](_0x26369d){}['onDisconnectPut'](_0xb6f014,_0xdb25ab,_0x4172c6){}['onDisconnectMerge'](_0x5125c8,_0x4e38c8,_0x1221ba){}['onDisconnectCancel'](_0x18798c,_0x5364f3){}['reportStats'](_0x15ef44){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x2ce8d0){this['allowedEvents_']=_0x2ce8d0,this['listeners_']={},f(Array['isArray'](_0x2ce8d0)&&_0x2ce8d0['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x149b93,..._0x4bbeb3){if(Array['isArray'](this['listeners_'][_0x149b93])){const _0x1db64e=[...this['listeners_'][_0x149b93]];for(let _0x1721eb=0x0;_0x1721eb<_0x1db64e['length'];_0x1721eb++)_0x1db64e[_0x1721eb]['callback']['apply'](_0x1db64e[_0x1721eb]['context'],_0x4bbeb3);}}['on'](_0x1e1cfb,_0x4e84ac,_0x4f5933){this['validateEventType_'](_0x1e1cfb),this['listeners_'][_0x1e1cfb]=this['listeners_'][_0x1e1cfb]||[],this['listeners_'][_0x1e1cfb]['push']({'callback':_0x4e84ac,'context':_0x4f5933});const _0x582ffe=this['getInitialEvent'](_0x1e1cfb);_0x582ffe&&_0x4e84ac['apply'](_0x4f5933,_0x582ffe);}['off'](_0x24a8ef,_0x2d5d26,_0x1c51b1){this['validateEventType_'](_0x24a8ef);const _0x4d3114=this['listeners_'][_0x24a8ef]||[];for(let _0x35c46f=0x0;_0x35c46f<_0x4d3114['length'];_0x35c46f++)if(_0x4d3114[_0x35c46f]['callback']===_0x2d5d26&&(!_0x1c51b1||_0x1c51b1===_0x4d3114[_0x35c46f]['context'])){_0x4d3114['splice'](_0x35c46f,0x1);return;}}['validateEventType_'](_0x431d6c){f(this['allowedEvents_']['find'](_0x168e56=>_0x168e56===_0x431d6c),'Unknown\x20event:\x20'+_0x431d6c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x14ea91){return f(_0x14ea91==='online','Unknown\x20event\x20type:\x20'+_0x14ea91),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x866beb,_0x92f7d6){if(_0x92f7d6===void 0x0){this['pieces_']=_0x866beb['split']('/');let _0x15bb9e=0x0;for(let _0x2253ee=0x0;_0x2253ee<this['pieces_']['length'];_0x2253ee++)this['pieces_'][_0x2253ee]['length']>0x0&&(this['pieces_'][_0x15bb9e]=this['pieces_'][_0x2253ee],_0x15bb9e++);this['pieces_']['length']=_0x15bb9e,this['pieceNum_']=0x0;}else this['pieces_']=_0x866beb,this['pieceNum_']=_0x92f7d6;}['toString'](){let _0x7bc91f='';for(let _0x23e70d=this['pieceNum_'];_0x23e70d<this['pieces_']['length'];_0x23e70d++)this['pieces_'][_0x23e70d]!==''&&(_0x7bc91f+='/'+this['pieces_'][_0x23e70d]);return _0x7bc91f||'/';}}function w(){return new C('');}function y(_0x1c159c){return _0x1c159c['pieceNum_']>=_0x1c159c['pieces_']['length']?null:_0x1c159c['pieces_'][_0x1c159c['pieceNum_']];}function we(_0x1cee92){return _0x1cee92['pieces_']['length']-_0x1cee92['pieceNum_'];}function b(_0x1141a8){let _0x34a4e9=_0x1141a8['pieceNum_'];return _0x34a4e9<_0x1141a8['pieces_']['length']&&_0x34a4e9++,new C(_0x1141a8['pieces_'],_0x34a4e9);}function Gi(_0x5827f9){return _0x5827f9['pieceNum_']<_0x5827f9['pieces_']['length']?_0x5827f9['pieces_'][_0x5827f9['pieces_']['length']-0x1]:null;}function Ch(_0x4b3e15){let _0x58c162='';for(let _0x34ae74=_0x4b3e15['pieceNum_'];_0x34ae74<_0x4b3e15['pieces_']['length'];_0x34ae74++)_0x4b3e15['pieces_'][_0x34ae74]!==''&&(_0x58c162+='/'+encodeURIComponent(String(_0x4b3e15['pieces_'][_0x34ae74])));return _0x58c162||'/';}function kt(_0x597e0f,_0x425c1c=0x0){return _0x597e0f['pieces_']['slice'](_0x597e0f['pieceNum_']+_0x425c1c);}function To(_0x21bff8){if(_0x21bff8['pieceNum_']>=_0x21bff8['pieces_']['length'])return null;const _0x2cc9ab=[];for(let _0x2e53e5=_0x21bff8['pieceNum_'];_0x2e53e5<_0x21bff8['pieces_']['length']-0x1;_0x2e53e5++)_0x2cc9ab['push'](_0x21bff8['pieces_'][_0x2e53e5]);return new C(_0x2cc9ab,0x0);}function A(_0x24821b,_0x5ce58c){const _0x3b06e1=[];for(let _0x57d477=_0x24821b['pieceNum_'];_0x57d477<_0x24821b['pieces_']['length'];_0x57d477++)_0x3b06e1['push'](_0x24821b['pieces_'][_0x57d477]);if(_0x5ce58c instanceof C){for(let _0x1e1e93=_0x5ce58c['pieceNum_'];_0x1e1e93<_0x5ce58c['pieces_']['length'];_0x1e1e93++)_0x3b06e1['push'](_0x5ce58c['pieces_'][_0x1e1e93]);}else{const _0x21c675=_0x5ce58c['split']('/');for(let _0x29e671=0x0;_0x29e671<_0x21c675['length'];_0x29e671++)_0x21c675[_0x29e671]['length']>0x0&&_0x3b06e1['push'](_0x21c675[_0x29e671]);}return new C(_0x3b06e1,0x0);}function v(_0x766804){return _0x766804['pieceNum_']>=_0x766804['pieces_']['length'];}function F(_0x28a69b,_0x5f5697){const _0x19aec0=y(_0x28a69b),_0x3729a0=y(_0x5f5697);if(_0x19aec0===null)return _0x5f5697;if(_0x19aec0===_0x3729a0)return F(b(_0x28a69b),b(_0x5f5697));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5f5697+')\x20is\x20not\x20within\x20outerPath\x20('+_0x28a69b+')');}function Th(_0x1af379,_0x5aa2e6){const _0x22849e=kt(_0x1af379,0x0),_0x11e5bd=kt(_0x5aa2e6,0x0);for(let _0x36996e=0x0;_0x36996e<_0x22849e['length']&&_0x36996e<_0x11e5bd['length'];_0x36996e++){const _0x50ff3d=He(_0x22849e[_0x36996e],_0x11e5bd[_0x36996e]);if(_0x50ff3d!==0x0)return _0x50ff3d;}return _0x22849e['length']===_0x11e5bd['length']?0x0:_0x22849e['length']<_0x11e5bd['length']?-0x1:0x1;}function qi(_0x109f3a,_0x5a2f79){if(we(_0x109f3a)!==we(_0x5a2f79))return!0x1;for(let _0x53d4be=_0x109f3a['pieceNum_'],_0x24cf9d=_0x5a2f79['pieceNum_'];_0x53d4be<=_0x109f3a['pieces_']['length'];_0x53d4be++,_0x24cf9d++)if(_0x109f3a['pieces_'][_0x53d4be]!==_0x5a2f79['pieces_'][_0x24cf9d])return!0x1;return!0x0;}function $(_0x16d383,_0x322bf2){let _0x1cc8d9=_0x16d383['pieceNum_'],_0x2f034a=_0x322bf2['pieceNum_'];if(we(_0x16d383)>we(_0x322bf2))return!0x1;for(;_0x1cc8d9<_0x16d383['pieces_']['length'];){if(_0x16d383['pieces_'][_0x1cc8d9]!==_0x322bf2['pieces_'][_0x2f034a])return!0x1;++_0x1cc8d9,++_0x2f034a;}return!0x0;}class Sh{constructor(_0x21d395,_0x58e38d){this['errorPrefix_']=_0x58e38d,this['parts_']=kt(_0x21d395,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x41ce08=0x0;_0x41ce08<this['parts_']['length'];_0x41ce08++)this['byteLength_']+=Pn(this['parts_'][_0x41ce08]);So(this);}}function bh(_0x53718b,_0x3c2133){_0x53718b['parts_']['length']>0x0&&(_0x53718b['byteLength_']+=0x1),_0x53718b['parts_']['push'](_0x3c2133),_0x53718b['byteLength_']+=Pn(_0x3c2133),So(_0x53718b);}function Rh(_0x417e22){const _0x45263c=_0x417e22['parts_']['pop']();_0x417e22['byteLength_']-=Pn(_0x45263c),_0x417e22['parts_']['length']>0x0&&(_0x417e22['byteLength_']-=0x1);}function So(_0x254575){if(_0x254575['byteLength_']>Js)throw new Error(_0x254575['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x254575['byteLength_']+').');if(_0x254575['parts_']['length']>Qs)throw new Error(_0x254575['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x254575));}function Ne(_0x19c291){return _0x19c291['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x19c291['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x547650,_0x29454e;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x29454e='visibilitychange',_0x547650='hidden'):typeof document['mozHidden']<'u'?(_0x29454e='mozvisibilitychange',_0x547650='mozHidden'):typeof document['msHidden']<'u'?(_0x29454e='msvisibilitychange',_0x547650='msHidden'):typeof document['webkitHidden']<'u'&&(_0x29454e='webkitvisibilitychange',_0x547650='webkitHidden')),this['visible_']=!0x0,_0x29454e&&document['addEventListener'](_0x29454e,()=>{const _0x1240ce=!document[_0x547650];_0x1240ce!==this['visible_']&&(this['visible_']=_0x1240ce,this['trigger']('visible',_0x1240ce));},!0x1);}['getInitialEvent'](_0x411562){return f(_0x411562==='visible','Unknown\x20event\x20type:\x20'+_0x411562),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x5779b5,_0x278ccd,_0x406917,_0x3d5ce1,_0x5774ab,_0x5c9ca2,_0x178777,_0x42c1e9){if(super(),this['repoInfo_']=_0x5779b5,this['applicationId_']=_0x278ccd,this['onDataUpdate_']=_0x406917,this['onConnectStatus_']=_0x3d5ce1,this['onServerInfoUpdate_']=_0x5774ab,this['authTokenProvider_']=_0x5c9ca2,this['appCheckTokenProvider_']=_0x178777,this['authOverride_']=_0x42c1e9,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x42c1e9)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5779b5['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4e20a7,_0xcecdfa,_0x2a61ba){const _0x1cf239=++this['requestNumber_'],_0x2633c2={'r':_0x1cf239,'a':_0x4e20a7,'b':_0xcecdfa};this['log_'](O(_0x2633c2)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2633c2),_0x2a61ba&&(this['requestCBHash_'][_0x1cf239]=_0x2a61ba);}['get'](_0x39a3ae){this['initConnection_']();const _0x2e822c=new Ve(),_0x33f164={'action':'g','request':{'p':_0x39a3ae['_path']['toString'](),'q':_0x39a3ae['_queryObject']},'onComplete':_0x41f994=>{const _0x10e0e8=_0x41f994['d'];_0x41f994['s']==='ok'?_0x2e822c['resolve'](_0x10e0e8):_0x2e822c['reject'](_0x10e0e8);}};this['outstandingGets_']['push'](_0x33f164),this['outstandingGetCount_']++;const _0x5308b9=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5308b9),_0x2e822c['promise'];}['listen'](_0x516ff3,_0x142550,_0x52f31f,_0x54daac){this['initConnection_']();const _0x5ee5b8=_0x516ff3['_queryIdentifier'],_0x4a681e=_0x516ff3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4a681e+'\x20'+_0x5ee5b8),this['listens']['has'](_0x4a681e)||this['listens']['set'](_0x4a681e,new Map()),f(_0x516ff3['_queryParams']['isDefault']()||!_0x516ff3['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4a681e)['has'](_0x5ee5b8),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x16085a={'onComplete':_0x54daac,'hashFn':_0x142550,'query':_0x516ff3,'tag':_0x52f31f};this['listens']['get'](_0x4a681e)['set'](_0x5ee5b8,_0x16085a),this['connected_']&&this['sendListen_'](_0x16085a);}['sendGet_'](_0x591afa){const _0x5c84e3=this['outstandingGets_'][_0x591afa];this['sendRequest']('g',_0x5c84e3['request'],_0x4e9ef5=>{delete this['outstandingGets_'][_0x591afa],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5c84e3['onComplete']&&_0x5c84e3['onComplete'](_0x4e9ef5);});}['sendListen_'](_0x4df32c){const _0x442814=_0x4df32c['query'],_0x134214=_0x442814['_path']['toString'](),_0x46181a=_0x442814['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x134214+'\x20for\x20'+_0x46181a);const _0x4da06f={'p':_0x134214},_0x48c435='q';_0x4df32c['tag']&&(_0x4da06f['q']=_0x442814['_queryObject'],_0x4da06f['t']=_0x4df32c['tag']),_0x4da06f['h']=_0x4df32c['hashFn'](),this['sendRequest'](_0x48c435,_0x4da06f,_0x11fd61=>{const _0x496165=_0x11fd61['d'],_0x5111f5=_0x11fd61['s'];ie['warnOnListenWarnings_'](_0x496165,_0x442814),(this['listens']['get'](_0x134214)&&this['listens']['get'](_0x134214)['get'](_0x46181a))===_0x4df32c&&(this['log_']('listen\x20response',_0x11fd61),_0x5111f5!=='ok'&&this['removeListen_'](_0x134214,_0x46181a),_0x4df32c['onComplete']&&_0x4df32c['onComplete'](_0x5111f5,_0x496165));});}static['warnOnListenWarnings_'](_0x19d354,_0x486c23){if(_0x19d354&&typeof _0x19d354=='object'&&Y(_0x19d354,'w')){const _0x3e16cc=Oe(_0x19d354,'w');if(Array['isArray'](_0x3e16cc)&&~_0x3e16cc['indexOf']('no_index')){const _0x2e5381='\x22.indexOn\x22:\x20\x22'+_0x486c23['_queryParams']['getIndex']()['toString']()+'\x22',_0x5d8bbd=_0x486c23['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2e5381+'\x20at\x20'+_0x5d8bbd+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4a8b40){this['authToken_']=_0x4a8b40,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4a8b40);}['reduceReconnectDelayIfAdminCredential_'](_0x24891f){(_0x24891f&&_0x24891f['length']===0x28||vc(_0x24891f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x18d734){this['appCheckToken_']=_0x18d734,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1ee7c8=this['authToken_'],_0x6955d1=yc(_0x1ee7c8)?'auth':'gauth',_0x396b39={'cred':_0x1ee7c8};this['authOverride_']===null?_0x396b39['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x396b39['authvar']=this['authOverride_']),this['sendRequest'](_0x6955d1,_0x396b39,_0x2aa937=>{const _0x11d3c8=_0x2aa937['s'],_0x3b6ee8=_0x2aa937['d']||'error';this['authToken_']===_0x1ee7c8&&(_0x11d3c8==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x11d3c8,_0x3b6ee8));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x47d129=>{const _0x191f9e=_0x47d129['s'],_0x400a3f=_0x47d129['d']||'error';_0x191f9e==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x191f9e,_0x400a3f);});}['unlisten'](_0x14947d,_0x1ae0de){const _0x28e1d4=_0x14947d['_path']['toString'](),_0x5aa6d9=_0x14947d['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x28e1d4+'\x20'+_0x5aa6d9),f(_0x14947d['_queryParams']['isDefault']()||!_0x14947d['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x28e1d4,_0x5aa6d9)&&this['connected_']&&this['sendUnlisten_'](_0x28e1d4,_0x5aa6d9,_0x14947d['_queryObject'],_0x1ae0de);}['sendUnlisten_'](_0x378190,_0x4890d2,_0x471c59,_0x124a73){this['log_']('Unlisten\x20on\x20'+_0x378190+'\x20for\x20'+_0x4890d2);const _0x57f0d5={'p':_0x378190},_0x5e4977='n';_0x124a73&&(_0x57f0d5['q']=_0x471c59,_0x57f0d5['t']=_0x124a73),this['sendRequest'](_0x5e4977,_0x57f0d5);}['onDisconnectPut'](_0x153fb2,_0x216c80,_0x195acc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x153fb2,_0x216c80,_0x195acc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x153fb2,'action':'o','data':_0x216c80,'onComplete':_0x195acc});}['onDisconnectMerge'](_0x54dfa7,_0x3981e5,_0xc1d91){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x54dfa7,_0x3981e5,_0xc1d91):this['onDisconnectRequestQueue_']['push']({'pathString':_0x54dfa7,'action':'om','data':_0x3981e5,'onComplete':_0xc1d91});}['onDisconnectCancel'](_0x1752f8,_0x2a30a5){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1752f8,null,_0x2a30a5):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1752f8,'action':'oc','data':null,'onComplete':_0x2a30a5});}['sendOnDisconnect_'](_0x155190,_0x18c037,_0x5d379c,_0x493f51){const _0x574be7={'p':_0x18c037,'d':_0x5d379c};this['log_']('onDisconnect\x20'+_0x155190,_0x574be7),this['sendRequest'](_0x155190,_0x574be7,_0x549680=>{_0x493f51&&setTimeout(()=>{_0x493f51(_0x549680['s'],_0x549680['d']);},Math['floor'](0x0));});}['put'](_0x76741f,_0xe9feda,_0x4d5a4a,_0x5e5c53){this['putInternal']('p',_0x76741f,_0xe9feda,_0x4d5a4a,_0x5e5c53);}['merge'](_0x38bdb1,_0xff4867,_0x5475e1,_0x3d32f8){this['putInternal']('m',_0x38bdb1,_0xff4867,_0x5475e1,_0x3d32f8);}['putInternal'](_0x7d3439,_0x3ec531,_0x4ede3f,_0x42d1ba,_0x4219d7){this['initConnection_']();const _0x46bd1c={'p':_0x3ec531,'d':_0x4ede3f};_0x4219d7!==void 0x0&&(_0x46bd1c['h']=_0x4219d7),this['outstandingPuts_']['push']({'action':_0x7d3439,'request':_0x46bd1c,'onComplete':_0x42d1ba}),this['outstandingPutCount_']++;const _0xce5503=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xce5503):this['log_']('Buffering\x20put:\x20'+_0x3ec531);}['sendPut_'](_0x1000f5){const _0x1d0602=this['outstandingPuts_'][_0x1000f5]['action'],_0x1edf5b=this['outstandingPuts_'][_0x1000f5]['request'],_0x51d8d6=this['outstandingPuts_'][_0x1000f5]['onComplete'];this['outstandingPuts_'][_0x1000f5]['queued']=this['connected_'],this['sendRequest'](_0x1d0602,_0x1edf5b,_0x25a7e3=>{this['log_'](_0x1d0602+'\x20response',_0x25a7e3),delete this['outstandingPuts_'][_0x1000f5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x51d8d6&&_0x51d8d6(_0x25a7e3['s'],_0x25a7e3['d']);});}['reportStats'](_0x22b640){if(this['connected_']){const _0x1a12d1={'c':_0x22b640};this['log_']('reportStats',_0x1a12d1),this['sendRequest']('s',_0x1a12d1,_0x28d222=>{if(_0x28d222['s']!=='ok'){const _0x4b8a17=_0x28d222['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x4b8a17);}});}}['onDataMessage_'](_0x30a50c){if('r'in _0x30a50c){this['log_']('from\x20server:\x20'+O(_0x30a50c));const _0x49494e=_0x30a50c['r'],_0x59f4c3=this['requestCBHash_'][_0x49494e];_0x59f4c3&&(delete this['requestCBHash_'][_0x49494e],_0x59f4c3(_0x30a50c['b']));}else{if('error'in _0x30a50c)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x30a50c['error'];'a'in _0x30a50c&&this['onDataPush_'](_0x30a50c['a'],_0x30a50c['b']);}}['onDataPush_'](_0x55e31d,_0x315b06){this['log_']('handleServerMessage',_0x55e31d,_0x315b06),_0x55e31d==='d'?this['onDataUpdate_'](_0x315b06['p'],_0x315b06['d'],!0x1,_0x315b06['t']):_0x55e31d==='m'?this['onDataUpdate_'](_0x315b06['p'],_0x315b06['d'],!0x0,_0x315b06['t']):_0x55e31d==='c'?this['onListenRevoked_'](_0x315b06['p'],_0x315b06['q']):_0x55e31d==='ac'?this['onAuthRevoked_'](_0x315b06['s'],_0x315b06['d']):_0x55e31d==='apc'?this['onAppCheckRevoked_'](_0x315b06['s'],_0x315b06['d']):_0x55e31d==='sd'?this['onSecurityDebugPacket_'](_0x315b06):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x55e31d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4f0c85,_0x251d36){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4f0c85),this['lastSessionId']=_0x251d36,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x114909){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x114909));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x55b270){_0x55b270&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x55b270;}['onOnline_'](_0x2bb958){_0x2bb958?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3826cf=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xde11d8=Math['max'](0x0,this['reconnectDelay_']-_0x3826cf);_0xde11d8=Math['random']()*_0xde11d8,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xde11d8+'ms'),this['scheduleConnect_'](_0xde11d8),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x435567=this['onDataMessage_']['bind'](this),_0x99ee6c=this['onReady_']['bind'](this),_0xd7c5c1=this['onRealtimeDisconnect_']['bind'](this),_0x2f4781=this['id']+':'+ie['nextConnectionId_']++,_0x5635ed=this['lastSessionId'];let _0x50f337=!0x1,_0x28a43b=null;const _0x2dc964=function(){_0x28a43b?_0x28a43b['close']():(_0x50f337=!0x0,_0xd7c5c1());},_0x332b38=function(_0x1f3407){f(_0x28a43b,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x28a43b['sendRequest'](_0x1f3407);};this['realtime_']={'close':_0x2dc964,'sendRequest':_0x332b38};const _0x135b78=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x40afc1,_0xc49f81]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x135b78),this['appCheckTokenProvider_']['getToken'](_0x135b78)]);_0x50f337?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x40afc1&&_0x40afc1['accessToken'],this['appCheckToken_']=_0xc49f81&&_0xc49f81['token'],_0x28a43b=new wh(_0x2f4781,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x435567,_0x99ee6c,_0xd7c5c1,_0xac9f5c=>{U(_0xac9f5c+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5635ed));}catch(_0x596ca5){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x596ca5),_0x50f337||(this['repoInfo_']['nodeAdmin']&&U(_0x596ca5),_0x2dc964());}}}['interrupt'](_0x377b75){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x377b75),this['interruptReasons_'][_0x377b75]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x460b76){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x460b76),delete this['interruptReasons_'][_0x460b76],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3a2202){const _0x1c485c=_0x3a2202-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1c485c});}['cancelSentTransactions_'](){for(let _0xa23a24=0x0;_0xa23a24<this['outstandingPuts_']['length'];_0xa23a24++){const _0xcab9df=this['outstandingPuts_'][_0xa23a24];_0xcab9df&&'h'in _0xcab9df['request']&&_0xcab9df['queued']&&(_0xcab9df['onComplete']&&_0xcab9df['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xa23a24],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4cd981,_0x5d1fd8){let _0x979f3b;_0x5d1fd8?_0x979f3b=_0x5d1fd8['map'](_0x4411fc=>Bi(_0x4411fc))['join']('$'):_0x979f3b='default';const _0x2872b1=this['removeListen_'](_0x4cd981,_0x979f3b);_0x2872b1&&_0x2872b1['onComplete']&&_0x2872b1['onComplete']('permission_denied');}['removeListen_'](_0x2675c4,_0x3bf63a){const _0x1126fb=new C(_0x2675c4)['toString']();let _0x3f045f;if(this['listens']['has'](_0x1126fb)){const _0x5455c0=this['listens']['get'](_0x1126fb);_0x3f045f=_0x5455c0['get'](_0x3bf63a),_0x5455c0['delete'](_0x3bf63a),_0x5455c0['size']===0x0&&this['listens']['delete'](_0x1126fb);}else _0x3f045f=void 0x0;return _0x3f045f;}['onAuthRevoked_'](_0x50a4b2,_0x8c5c25){L('Auth\x20token\x20revoked:\x20'+_0x50a4b2+'/'+_0x8c5c25),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x50a4b2==='invalid_token'||_0x50a4b2==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1534e6,_0x26fa8a){L('App\x20check\x20token\x20revoked:\x20'+_0x1534e6+'/'+_0x26fa8a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1534e6==='invalid_token'||_0x1534e6==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x536773){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x536773):'msg'in _0x536773&&console['log']('FIREBASE:\x20'+_0x536773['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4cc404 of this['listens']['values']())for(const _0x469784 of _0x4cc404['values']())this['sendListen_'](_0x469784);for(let _0x266840=0x0;_0x266840<this['outstandingPuts_']['length'];_0x266840++)this['outstandingPuts_'][_0x266840]&&this['sendPut_'](_0x266840);for(;this['onDisconnectRequestQueue_']['length'];){const _0x36c049=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x36c049['action'],_0x36c049['pathString'],_0x36c049['data'],_0x36c049['onComplete']);}for(let _0x2579b1=0x0;_0x2579b1<this['outstandingGets_']['length'];_0x2579b1++)this['outstandingGets_'][_0x2579b1]&&this['sendGet_'](_0x2579b1);}['sendConnectStats_'](){const _0x5ffce9={};let _0x5aa3a1='js';_0x5ffce9['sdk.'+_0x5aa3a1+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x5ffce9['framework.cordova']=0x1:qr()&&(_0x5ffce9['framework.reactnative']=0x1),this['reportStats'](_0x5ffce9);}['shouldReconnect_'](){const _0x53d632=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x53d632;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x19f5d7,_0x57b96c){this['name']=_0x19f5d7,this['node']=_0x57b96c;}static['Wrap'](_0x1b5818,_0x2cd8d8){return new E(_0x1b5818,_0x2cd8d8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5d2af0,_0x1c9983){const _0x4a6afa=new E(xe,_0x5d2af0),_0x23e6c1=new E(xe,_0x1c9983);return this['compare'](_0x4a6afa,_0x23e6c1)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x2692b3){Xt=_0x2692b3;}['compare'](_0x1b8a7c,_0x25db3c){return He(_0x1b8a7c['name'],_0x25db3c['name']);}['isDefinedOn'](_0x479fec){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4b0436,_0x21000a){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x30b97a,_0x5f5c98){return f(typeof _0x30b97a=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x30b97a,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x57dea1,_0x34cfda,_0x3db74e,_0x392cb9,_0x179d3c=null){this['isReverse_']=_0x392cb9,this['resultGenerator_']=_0x179d3c,this['nodeStack_']=[];let _0x58c08e=0x1;for(;!_0x57dea1['isEmpty']();)if(_0x57dea1=_0x57dea1,_0x58c08e=_0x34cfda?_0x3db74e(_0x57dea1['key'],_0x34cfda):0x1,_0x392cb9&&(_0x58c08e*=-0x1),_0x58c08e<0x0)this['isReverse_']?_0x57dea1=_0x57dea1['left']:_0x57dea1=_0x57dea1['right'];else{if(_0x58c08e===0x0){this['nodeStack_']['push'](_0x57dea1);break;}else this['nodeStack_']['push'](_0x57dea1),this['isReverse_']?_0x57dea1=_0x57dea1['right']:_0x57dea1=_0x57dea1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xb55468=this['nodeStack_']['pop'](),_0x33bcde;if(this['resultGenerator_']?_0x33bcde=this['resultGenerator_'](_0xb55468['key'],_0xb55468['value']):_0x33bcde={'key':_0xb55468['key'],'value':_0xb55468['value']},this['isReverse_']){for(_0xb55468=_0xb55468['left'];!_0xb55468['isEmpty']();)this['nodeStack_']['push'](_0xb55468),_0xb55468=_0xb55468['right'];}else{for(_0xb55468=_0xb55468['right'];!_0xb55468['isEmpty']();)this['nodeStack_']['push'](_0xb55468),_0xb55468=_0xb55468['left'];}return _0x33bcde;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1f27e4=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1f27e4['key'],_0x1f27e4['value']):{'key':_0x1f27e4['key'],'value':_0x1f27e4['value']};}}class M{constructor(_0x48153f,_0x570cd5,_0x522520,_0xda6b62,_0x3f85d7){this['key']=_0x48153f,this['value']=_0x570cd5,this['color']=_0x522520??M['RED'],this['left']=_0xda6b62??B['EMPTY_NODE'],this['right']=_0x3f85d7??B['EMPTY_NODE'];}['copy'](_0x165ee6,_0x3eabfe,_0x33a026,_0x578cb3,_0x5d7d6a){return new M(_0x165ee6??this['key'],_0x3eabfe??this['value'],_0x33a026??this['color'],_0x578cb3??this['left'],_0x5d7d6a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5cae52){return this['left']['inorderTraversal'](_0x5cae52)||!!_0x5cae52(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5cae52);}['reverseTraversal'](_0x3c5d77){return this['right']['reverseTraversal'](_0x3c5d77)||_0x3c5d77(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3c5d77);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x964c6,_0xc14800,_0x5719c4){let _0x4eca6e=this;const _0x4e7775=_0x5719c4(_0x964c6,_0x4eca6e['key']);return _0x4e7775<0x0?_0x4eca6e=_0x4eca6e['copy'](null,null,null,_0x4eca6e['left']['insert'](_0x964c6,_0xc14800,_0x5719c4),null):_0x4e7775===0x0?_0x4eca6e=_0x4eca6e['copy'](null,_0xc14800,null,null,null):_0x4eca6e=_0x4eca6e['copy'](null,null,null,null,_0x4eca6e['right']['insert'](_0x964c6,_0xc14800,_0x5719c4)),_0x4eca6e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4d7af8=this;return!_0x4d7af8['left']['isRed_']()&&!_0x4d7af8['left']['left']['isRed_']()&&(_0x4d7af8=_0x4d7af8['moveRedLeft_']()),_0x4d7af8=_0x4d7af8['copy'](null,null,null,_0x4d7af8['left']['removeMin_'](),null),_0x4d7af8['fixUp_']();}['remove'](_0x41c49b,_0x256ca0){let _0x42be98,_0x1d2e86;if(_0x42be98=this,_0x256ca0(_0x41c49b,_0x42be98['key'])<0x0)!_0x42be98['left']['isEmpty']()&&!_0x42be98['left']['isRed_']()&&!_0x42be98['left']['left']['isRed_']()&&(_0x42be98=_0x42be98['moveRedLeft_']()),_0x42be98=_0x42be98['copy'](null,null,null,_0x42be98['left']['remove'](_0x41c49b,_0x256ca0),null);else{if(_0x42be98['left']['isRed_']()&&(_0x42be98=_0x42be98['rotateRight_']()),!_0x42be98['right']['isEmpty']()&&!_0x42be98['right']['isRed_']()&&!_0x42be98['right']['left']['isRed_']()&&(_0x42be98=_0x42be98['moveRedRight_']()),_0x256ca0(_0x41c49b,_0x42be98['key'])===0x0){if(_0x42be98['right']['isEmpty']())return B['EMPTY_NODE'];_0x1d2e86=_0x42be98['right']['min_'](),_0x42be98=_0x42be98['copy'](_0x1d2e86['key'],_0x1d2e86['value'],null,null,_0x42be98['right']['removeMin_']());}_0x42be98=_0x42be98['copy'](null,null,null,null,_0x42be98['right']['remove'](_0x41c49b,_0x256ca0));}return _0x42be98['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1b93f3=this;return _0x1b93f3['right']['isRed_']()&&!_0x1b93f3['left']['isRed_']()&&(_0x1b93f3=_0x1b93f3['rotateLeft_']()),_0x1b93f3['left']['isRed_']()&&_0x1b93f3['left']['left']['isRed_']()&&(_0x1b93f3=_0x1b93f3['rotateRight_']()),_0x1b93f3['left']['isRed_']()&&_0x1b93f3['right']['isRed_']()&&(_0x1b93f3=_0x1b93f3['colorFlip_']()),_0x1b93f3;}['moveRedLeft_'](){let _0x4e8bf8=this['colorFlip_']();return _0x4e8bf8['right']['left']['isRed_']()&&(_0x4e8bf8=_0x4e8bf8['copy'](null,null,null,null,_0x4e8bf8['right']['rotateRight_']()),_0x4e8bf8=_0x4e8bf8['rotateLeft_'](),_0x4e8bf8=_0x4e8bf8['colorFlip_']()),_0x4e8bf8;}['moveRedRight_'](){let _0x59ee9b=this['colorFlip_']();return _0x59ee9b['left']['left']['isRed_']()&&(_0x59ee9b=_0x59ee9b['rotateRight_'](),_0x59ee9b=_0x59ee9b['colorFlip_']()),_0x59ee9b;}['rotateLeft_'](){const _0x3b92e3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3b92e3,null);}['rotateRight_'](){const _0x35a2c0=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x35a2c0);}['colorFlip_'](){const _0x752309=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x341377=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x752309,_0x341377);}['checkMaxDepth_'](){const _0x30129d=this['check_']();return Math['pow'](0x2,_0x30129d)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x232ec4=this['left']['check_']();if(_0x232ec4!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x232ec4+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x56415c,_0x37b387,_0x109e25,_0x4d66b2,_0x1013d3){return this;}['insert'](_0x449ef2,_0x43e468,_0xbe4bd8){return new M(_0x449ef2,_0x43e468,null);}['remove'](_0x1763bc,_0x23daeb){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2293b1){return!0x1;}['reverseTraversal'](_0x433538){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x287e31,_0xcf03bf=B['EMPTY_NODE']){this['comparator_']=_0x287e31,this['root_']=_0xcf03bf;}['insert'](_0x4f90e1,_0x1cc506){return new B(this['comparator_'],this['root_']['insert'](_0x4f90e1,_0x1cc506,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4f9e4c){return new B(this['comparator_'],this['root_']['remove'](_0x4f9e4c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x503b99){let _0x2d8bc5,_0x463328=this['root_'];for(;!_0x463328['isEmpty']();){if(_0x2d8bc5=this['comparator_'](_0x503b99,_0x463328['key']),_0x2d8bc5===0x0)return _0x463328['value'];_0x2d8bc5<0x0?_0x463328=_0x463328['left']:_0x2d8bc5>0x0&&(_0x463328=_0x463328['right']);}return null;}['getPredecessorKey'](_0x4d8f03){let _0x4d5f0e,_0xa9f03a=this['root_'],_0x40ba25=null;for(;!_0xa9f03a['isEmpty']();)if(_0x4d5f0e=this['comparator_'](_0x4d8f03,_0xa9f03a['key']),_0x4d5f0e===0x0){if(_0xa9f03a['left']['isEmpty']())return _0x40ba25?_0x40ba25['key']:null;for(_0xa9f03a=_0xa9f03a['left'];!_0xa9f03a['right']['isEmpty']();)_0xa9f03a=_0xa9f03a['right'];return _0xa9f03a['key'];}else _0x4d5f0e<0x0?_0xa9f03a=_0xa9f03a['left']:_0x4d5f0e>0x0&&(_0x40ba25=_0xa9f03a,_0xa9f03a=_0xa9f03a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x47f0e0){return this['root_']['inorderTraversal'](_0x47f0e0);}['reverseTraversal'](_0x511c70){return this['root_']['reverseTraversal'](_0x511c70);}['getIterator'](_0x57dabe){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x57dabe);}['getIteratorFrom'](_0x1ec157,_0x805c85){return new Zt(this['root_'],_0x1ec157,this['comparator_'],!0x1,_0x805c85);}['getReverseIteratorFrom'](_0x33e415,_0x4a0ce8){return new Zt(this['root_'],_0x33e415,this['comparator_'],!0x0,_0x4a0ce8);}['getReverseIterator'](_0x5257cc){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x5257cc);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x367231,_0x36fd5f){return He(_0x367231['name'],_0x36fd5f['name']);}function ji(_0x2578b6,_0x519017){return He(_0x2578b6,_0x519017);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5e02a4){vi=_0x5e02a4;}const Ro=function(_0x53e156){return typeof _0x53e156=='number'?'number:'+so(_0x53e156):'string:'+_0x53e156;},Ao=function(_0x3e8b61){if(_0x3e8b61['isLeafNode']()){const _0x931a8a=_0x3e8b61['val']();f(typeof _0x931a8a=='string'||typeof _0x931a8a=='number'||typeof _0x931a8a=='object'&&Y(_0x931a8a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3e8b61===vi||_0x3e8b61['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3e8b61===vi||_0x3e8b61['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3bd173){er=_0x3bd173;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2ead49,_0x40bda3=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2ead49,this['priorityNode_']=_0x40bda3,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1bcb1c){return new D(this['value_'],_0x1bcb1c);}['getImmediateChild'](_0x24bdf2){return _0x24bdf2==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5a717b){return v(_0x5a717b)?this:y(_0x5a717b)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4d523c,_0x5b1be5){return null;}['updateImmediateChild'](_0x3fc4b0,_0xfd0aeb){return _0x3fc4b0==='.priority'?this['updatePriority'](_0xfd0aeb):_0xfd0aeb['isEmpty']()&&_0x3fc4b0!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x3fc4b0,_0xfd0aeb)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x25589a,_0xaaeb19){const _0x199c61=y(_0x25589a);return _0x199c61===null?_0xaaeb19:_0xaaeb19['isEmpty']()&&_0x199c61!=='.priority'?this:(f(_0x199c61!=='.priority'||we(_0x25589a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x199c61,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x25589a),_0xaaeb19)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x357e65,_0x47f757){return!0x1;}['val'](_0x360b44){return _0x360b44&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1d0a18='';this['priorityNode_']['isEmpty']()||(_0x1d0a18+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x36d3e1=typeof this['value_'];_0x1d0a18+=_0x36d3e1+':',_0x36d3e1==='number'?_0x1d0a18+=so(this['value_']):_0x1d0a18+=this['value_'],this['lazyHash_']=no(_0x1d0a18);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2e61e1){return _0x2e61e1===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2e61e1 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2e61e1['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2e61e1));}['compareToLeafNode_'](_0x44622a){const _0x5ec545=typeof _0x44622a['value_'],_0x1bff5e=typeof this['value_'],_0x348440=D['VALUE_TYPE_ORDER']['indexOf'](_0x5ec545),_0x10441f=D['VALUE_TYPE_ORDER']['indexOf'](_0x1bff5e);return f(_0x348440>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5ec545),f(_0x10441f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1bff5e),_0x348440===_0x10441f?_0x1bff5e==='object'?0x0:this['value_']<_0x44622a['value_']?-0x1:this['value_']===_0x44622a['value_']?0x0:0x1:_0x10441f-_0x348440;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4f546e){if(_0x4f546e===this)return!0x0;if(_0x4f546e['isLeafNode']()){const _0x49dfe4=_0x4f546e;return this['value_']===_0x49dfe4['value_']&&this['priorityNode_']['equals'](_0x49dfe4['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x41a97c){ko=_0x41a97c;}function xh(_0x31fa64){No=_0x31fa64;}class Fh extends On{['compare'](_0x9098b0,_0x3aef9a){const _0x2d8732=_0x9098b0['node']['getPriority'](),_0x465d19=_0x3aef9a['node']['getPriority'](),_0x4608a1=_0x2d8732['compareTo'](_0x465d19);return _0x4608a1===0x0?He(_0x9098b0['name'],_0x3aef9a['name']):_0x4608a1;}['isDefinedOn'](_0x340409){return!_0x340409['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3a38ef,_0x56ff1d){return!_0x3a38ef['getPriority']()['equals'](_0x56ff1d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x21730b,_0x32ac95){const _0x340b04=ko(_0x21730b);return new E(_0x32ac95,new D('[PRIORITY-POST]',_0x340b04));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x538f3b){const _0x40919c=_0x16890c=>parseInt(Math['log'](_0x16890c)/Uh,0xa),_0x5ef8b9=_0x246b8d=>parseInt(Array(_0x246b8d+0x1)['join']('1'),0x2);this['count']=_0x40919c(_0x538f3b+0x1),this['current_']=this['count']-0x1;const _0x436b22=_0x5ef8b9(this['count']);this['bits_']=_0x538f3b+0x1&_0x436b22;}['nextBitIsOne'](){const _0x8f18fa=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x8f18fa;}}const dn=function(_0x5bce1e,_0x4fa0c0,_0xf639f3,_0x5db772){_0x5bce1e['sort'](_0x4fa0c0);const _0x1d3344=function(_0x258d7b,_0x960c71){const _0x45ee66=_0x960c71-_0x258d7b;let _0x204e82,_0x483d77;if(_0x45ee66===0x0)return null;if(_0x45ee66===0x1)return _0x204e82=_0x5bce1e[_0x258d7b],_0x483d77=_0xf639f3?_0xf639f3(_0x204e82):_0x204e82,new M(_0x483d77,_0x204e82['node'],M['BLACK'],null,null);{const _0x53e119=parseInt(_0x45ee66/0x2,0xa)+_0x258d7b,_0x93aa18=_0x1d3344(_0x258d7b,_0x53e119),_0x247410=_0x1d3344(_0x53e119+0x1,_0x960c71);return _0x204e82=_0x5bce1e[_0x53e119],_0x483d77=_0xf639f3?_0xf639f3(_0x204e82):_0x204e82,new M(_0x483d77,_0x204e82['node'],M['BLACK'],_0x93aa18,_0x247410);}},_0x4b1b15=function(_0x3353f5){let _0x1aa73c=null,_0x495154=null,_0x5d6d5a=_0x5bce1e['length'];const _0x15b41d=function(_0x28eb27,_0x422cb2){const _0x2420cd=_0x5d6d5a-_0x28eb27,_0x3c7dd7=_0x5d6d5a;_0x5d6d5a-=_0x28eb27;const _0x336288=_0x1d3344(_0x2420cd+0x1,_0x3c7dd7),_0x595197=_0x5bce1e[_0x2420cd],_0x5b2be5=_0xf639f3?_0xf639f3(_0x595197):_0x595197;_0x797283(new M(_0x5b2be5,_0x595197['node'],_0x422cb2,null,_0x336288));},_0x797283=function(_0x3c80ff){_0x1aa73c?(_0x1aa73c['left']=_0x3c80ff,_0x1aa73c=_0x3c80ff):(_0x495154=_0x3c80ff,_0x1aa73c=_0x3c80ff);};for(let _0x1c667b=0x0;_0x1c667b<_0x3353f5['count'];++_0x1c667b){const _0x99e77e=_0x3353f5['nextBitIsOne'](),_0x86b058=Math['pow'](0x2,_0x3353f5['count']-(_0x1c667b+0x1));_0x99e77e?_0x15b41d(_0x86b058,M['BLACK']):(_0x15b41d(_0x86b058,M['BLACK']),_0x15b41d(_0x86b058,M['RED']));}return _0x495154;},_0x32c400=new Wh(_0x5bce1e['length']),_0x3638ed=_0x4b1b15(_0x32c400);return new B(_0x5db772||_0x4fa0c0,_0x3638ed);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5ad047,_0x2a0523){this['indexes_']=_0x5ad047,this['indexSet_']=_0x2a0523;}['get'](_0x482d0a){const _0x2376ab=Oe(this['indexes_'],_0x482d0a);if(!_0x2376ab)throw new Error('No\x20index\x20defined\x20for\x20'+_0x482d0a);return _0x2376ab instanceof B?_0x2376ab:null;}['hasIndex'](_0x4d5f7c){return Y(this['indexSet_'],_0x4d5f7c['toString']());}['addIndex'](_0x265990,_0x299720){f(_0x265990!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xd59cd3=[];let _0x2e8ac6=!0x1;const _0x359ad1=_0x299720['getIterator'](E['Wrap']);let _0x18e56e=_0x359ad1['getNext']();for(;_0x18e56e;)_0x2e8ac6=_0x2e8ac6||_0x265990['isDefinedOn'](_0x18e56e['node']),_0xd59cd3['push'](_0x18e56e),_0x18e56e=_0x359ad1['getNext']();let _0x3d544e;_0x2e8ac6?_0x3d544e=dn(_0xd59cd3,_0x265990['getCompare']()):_0x3d544e=je;const _0x5642d0=_0x265990['toString'](),_0x2cf0e6={...this['indexSet_']};_0x2cf0e6[_0x5642d0]=_0x265990;const _0x40b25e={...this['indexes_']};return _0x40b25e[_0x5642d0]=_0x3d544e,new ee(_0x40b25e,_0x2cf0e6);}['addToIndexes'](_0xf5f049,_0x246401){const _0x4bc24f=ln(this['indexes_'],(_0x5780fe,_0x902983)=>{const _0x5598a4=Oe(this['indexSet_'],_0x902983);if(f(_0x5598a4,'Missing\x20index\x20implementation\x20for\x20'+_0x902983),_0x5780fe===je){if(_0x5598a4['isDefinedOn'](_0xf5f049['node'])){const _0x4deb29=[],_0x38b67f=_0x246401['getIterator'](E['Wrap']);let _0x3513d0=_0x38b67f['getNext']();for(;_0x3513d0;)_0x3513d0['name']!==_0xf5f049['name']&&_0x4deb29['push'](_0x3513d0),_0x3513d0=_0x38b67f['getNext']();return _0x4deb29['push'](_0xf5f049),dn(_0x4deb29,_0x5598a4['getCompare']());}else return je;}else{const _0x4387b0=_0x246401['get'](_0xf5f049['name']);let _0x405b77=_0x5780fe;return _0x4387b0&&(_0x405b77=_0x405b77['remove'](new E(_0xf5f049['name'],_0x4387b0))),_0x405b77['insert'](_0xf5f049,_0xf5f049['node']);}});return new ee(_0x4bc24f,this['indexSet_']);}['removeFromIndexes'](_0x5327e4,_0x5763c9){const _0x3aec1d=ln(this['indexes_'],_0x593a45=>{if(_0x593a45===je)return _0x593a45;{const _0x231965=_0x5763c9['get'](_0x5327e4['name']);return _0x231965?_0x593a45['remove'](new E(_0x5327e4['name'],_0x231965)):_0x593a45;}});return new ee(_0x3aec1d,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x3107f0,_0x1a34e7,_0x1a2a55){this['children_']=_0x3107f0,this['priorityNode_']=_0x1a34e7,this['indexMap_']=_0x1a2a55,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x52e08b){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x52e08b,this['indexMap_']);}['getImmediateChild'](_0x38b38b){if(_0x38b38b==='.priority')return this['getPriority']();{const _0x467576=this['children_']['get'](_0x38b38b);return _0x467576===null?gt:_0x467576;}}['getChild'](_0xcaeeae){const _0x4add55=y(_0xcaeeae);return _0x4add55===null?this:this['getImmediateChild'](_0x4add55)['getChild'](b(_0xcaeeae));}['hasChild'](_0xe2077d){return this['children_']['get'](_0xe2077d)!==null;}['updateImmediateChild'](_0x5e60cd,_0x520af5){if(f(_0x520af5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5e60cd==='.priority')return this['updatePriority'](_0x520af5);{const _0x20cf1d=new E(_0x5e60cd,_0x520af5);let _0x52ce79,_0x2a51a3;_0x520af5['isEmpty']()?(_0x52ce79=this['children_']['remove'](_0x5e60cd),_0x2a51a3=this['indexMap_']['removeFromIndexes'](_0x20cf1d,this['children_'])):(_0x52ce79=this['children_']['insert'](_0x5e60cd,_0x520af5),_0x2a51a3=this['indexMap_']['addToIndexes'](_0x20cf1d,this['children_']));const _0x4ef6f8=_0x52ce79['isEmpty']()?gt:this['priorityNode_'];return new g(_0x52ce79,_0x4ef6f8,_0x2a51a3);}}['updateChild'](_0x8b607d,_0x3fc5db){const _0x1443e4=y(_0x8b607d);if(_0x1443e4===null)return _0x3fc5db;{f(y(_0x8b607d)!=='.priority'||we(_0x8b607d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x3e9c33=this['getImmediateChild'](_0x1443e4)['updateChild'](b(_0x8b607d),_0x3fc5db);return this['updateImmediateChild'](_0x1443e4,_0x3e9c33);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x53e1bc){if(this['isEmpty']())return null;const _0x30bc94={};let _0x3eb890=0x0,_0x21a34e=0x0,_0x4c4b1e=!0x0;if(this['forEachChild'](R,(_0x142fd9,_0x2f31aa)=>{_0x30bc94[_0x142fd9]=_0x2f31aa['val'](_0x53e1bc),_0x3eb890++,_0x4c4b1e&&g['INTEGER_REGEXP_']['test'](_0x142fd9)?_0x21a34e=Math['max'](_0x21a34e,Number(_0x142fd9)):_0x4c4b1e=!0x1;}),!_0x53e1bc&&_0x4c4b1e&&_0x21a34e<0x2*_0x3eb890){const _0x24a498=[];for(const _0x1bd0e4 in _0x30bc94)_0x24a498[_0x1bd0e4]=_0x30bc94[_0x1bd0e4];return _0x24a498;}else return _0x53e1bc&&!this['getPriority']()['isEmpty']()&&(_0x30bc94['.priority']=this['getPriority']()['val']()),_0x30bc94;}['hash'](){if(this['lazyHash_']===null){let _0x26c28b='';this['getPriority']()['isEmpty']()||(_0x26c28b+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x192d24,_0x2747af)=>{const _0x2d5c12=_0x2747af['hash']();_0x2d5c12!==''&&(_0x26c28b+=':'+_0x192d24+':'+_0x2d5c12);}),this['lazyHash_']=_0x26c28b===''?'':no(_0x26c28b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x497f02,_0x93998d,_0xdc3e0a){const _0xe7624a=this['resolveIndex_'](_0xdc3e0a);if(_0xe7624a){const _0x5197cc=_0xe7624a['getPredecessorKey'](new E(_0x497f02,_0x93998d));return _0x5197cc?_0x5197cc['name']:null;}else return this['children_']['getPredecessorKey'](_0x497f02);}['getFirstChildName'](_0x42712c){const _0x58fef0=this['resolveIndex_'](_0x42712c);if(_0x58fef0){const _0xdc6320=_0x58fef0['minKey']();return _0xdc6320&&_0xdc6320['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x599a76){const _0x155897=this['getFirstChildName'](_0x599a76);return _0x155897?new E(_0x155897,this['children_']['get'](_0x155897)):null;}['getLastChildName'](_0x3240e6){const _0x43e1cf=this['resolveIndex_'](_0x3240e6);if(_0x43e1cf){const _0x1b2970=_0x43e1cf['maxKey']();return _0x1b2970&&_0x1b2970['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1ea510){const _0x56db8e=this['getLastChildName'](_0x1ea510);return _0x56db8e?new E(_0x56db8e,this['children_']['get'](_0x56db8e)):null;}['forEachChild'](_0x49c425,_0x2afc0d){const _0x299667=this['resolveIndex_'](_0x49c425);return _0x299667?_0x299667['inorderTraversal'](_0x8a77e5=>_0x2afc0d(_0x8a77e5['name'],_0x8a77e5['node'])):this['children_']['inorderTraversal'](_0x2afc0d);}['getIterator'](_0x202c42){return this['getIteratorFrom'](_0x202c42['minPost'](),_0x202c42);}['getIteratorFrom'](_0x3754cf,_0x2b74fb){const _0x46ee22=this['resolveIndex_'](_0x2b74fb);if(_0x46ee22)return _0x46ee22['getIteratorFrom'](_0x3754cf,_0x4f6878=>_0x4f6878);{const _0x3aa523=this['children_']['getIteratorFrom'](_0x3754cf['name'],E['Wrap']);let _0x56646d=_0x3aa523['peek']();for(;_0x56646d!=null&&_0x2b74fb['compare'](_0x56646d,_0x3754cf)<0x0;)_0x3aa523['getNext'](),_0x56646d=_0x3aa523['peek']();return _0x3aa523;}}['getReverseIterator'](_0x20d22e){return this['getReverseIteratorFrom'](_0x20d22e['maxPost'](),_0x20d22e);}['getReverseIteratorFrom'](_0x251af,_0x2a1771){const _0x18bc43=this['resolveIndex_'](_0x2a1771);if(_0x18bc43)return _0x18bc43['getReverseIteratorFrom'](_0x251af,_0x4fd184=>_0x4fd184);{const _0x4dd312=this['children_']['getReverseIteratorFrom'](_0x251af['name'],E['Wrap']);let _0x573565=_0x4dd312['peek']();for(;_0x573565!=null&&_0x2a1771['compare'](_0x573565,_0x251af)>0x0;)_0x4dd312['getNext'](),_0x573565=_0x4dd312['peek']();return _0x4dd312;}}['compareTo'](_0x4a2b28){return this['isEmpty']()?_0x4a2b28['isEmpty']()?0x0:-0x1:_0x4a2b28['isLeafNode']()||_0x4a2b28['isEmpty']()?0x1:_0x4a2b28===Ht?-0x1:0x0;}['withIndex'](_0x172e8c){if(_0x172e8c===ye||this['indexMap_']['hasIndex'](_0x172e8c))return this;{const _0x4a93e4=this['indexMap_']['addIndex'](_0x172e8c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4a93e4);}}['isIndexed'](_0x2ae667){return _0x2ae667===ye||this['indexMap_']['hasIndex'](_0x2ae667);}['equals'](_0x4a37b6){if(_0x4a37b6===this)return!0x0;if(_0x4a37b6['isLeafNode']())return!0x1;{const _0x57b45c=_0x4a37b6;if(this['getPriority']()['equals'](_0x57b45c['getPriority']())){if(this['children_']['count']()===_0x57b45c['children_']['count']()){const _0x18cfcb=this['getIterator'](R),_0xbc558e=_0x57b45c['getIterator'](R);let _0x4e1e72=_0x18cfcb['getNext'](),_0x6e5091=_0xbc558e['getNext']();for(;_0x4e1e72&&_0x6e5091;){if(_0x4e1e72['name']!==_0x6e5091['name']||!_0x4e1e72['node']['equals'](_0x6e5091['node']))return!0x1;_0x4e1e72=_0x18cfcb['getNext'](),_0x6e5091=_0xbc558e['getNext']();}return _0x4e1e72===null&&_0x6e5091===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xffbb2b){return _0xffbb2b===ye?null:this['indexMap_']['get'](_0xffbb2b['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x436cf9){return _0x436cf9===this?0x0:0x1;}['equals'](_0xfdfced){return _0xfdfced===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4ac521){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x19b459,_0x49e0ad=null){if(_0x19b459===null)return g['EMPTY_NODE'];if(typeof _0x19b459=='object'&&'.priority'in _0x19b459&&(_0x49e0ad=_0x19b459['.priority']),f(_0x49e0ad===null||typeof _0x49e0ad=='string'||typeof _0x49e0ad=='number'||typeof _0x49e0ad=='object'&&'.sv'in _0x49e0ad,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x49e0ad),typeof _0x19b459=='object'&&'.value'in _0x19b459&&_0x19b459['.value']!==null&&(_0x19b459=_0x19b459['.value']),typeof _0x19b459!='object'||'.sv'in _0x19b459){const _0x410de0=_0x19b459;return new D(_0x410de0,N(_0x49e0ad));}if(!(_0x19b459 instanceof Array)&&Vh){const _0x9efa15=[];let _0x4f17a1=!0x1;if(x(_0x19b459,(_0x4e8e0f,_0x19d026)=>{if(_0x4e8e0f['substring'](0x0,0x1)!=='.'){const _0x2d46f0=N(_0x19d026);_0x2d46f0['isEmpty']()||(_0x4f17a1=_0x4f17a1||!_0x2d46f0['getPriority']()['isEmpty'](),_0x9efa15['push'](new E(_0x4e8e0f,_0x2d46f0)));}}),_0x9efa15['length']===0x0)return g['EMPTY_NODE'];const _0x2b8b8d=dn(_0x9efa15,Dh,_0x4c8e87=>_0x4c8e87['name'],ji);if(_0x4f17a1){const _0x273a17=dn(_0x9efa15,R['getCompare']());return new g(_0x2b8b8d,N(_0x49e0ad),new ee({'.priority':_0x273a17},{'.priority':R}));}else return new g(_0x2b8b8d,N(_0x49e0ad),ee['Default']);}else{let _0x190f93=g['EMPTY_NODE'];return x(_0x19b459,(_0x40e278,_0x378a51)=>{if(Y(_0x19b459,_0x40e278)&&_0x40e278['substring'](0x0,0x1)!=='.'){const _0x41e98b=N(_0x378a51);(_0x41e98b['isLeafNode']()||!_0x41e98b['isEmpty']())&&(_0x190f93=_0x190f93['updateImmediateChild'](_0x40e278,_0x41e98b));}}),_0x190f93['updatePriority'](N(_0x49e0ad));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x51bf56){super(),this['indexPath_']=_0x51bf56,f(!v(_0x51bf56)&&y(_0x51bf56)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x122ce6){return _0x122ce6['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3b9855){return!_0x3b9855['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4cbd01,_0x2c3e30){const _0x56bacf=this['extractChild'](_0x4cbd01['node']),_0x5718a0=this['extractChild'](_0x2c3e30['node']),_0x302bcc=_0x56bacf['compareTo'](_0x5718a0);return _0x302bcc===0x0?He(_0x4cbd01['name'],_0x2c3e30['name']):_0x302bcc;}['makePost'](_0x376163,_0x598452){const _0x10a34c=N(_0x376163),_0x421d79=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x10a34c);return new E(_0x598452,_0x421d79);}['maxPost'](){const _0x205ae3=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x205ae3);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x11c26d,_0x483032){const _0x269fac=_0x11c26d['node']['compareTo'](_0x483032['node']);return _0x269fac===0x0?He(_0x11c26d['name'],_0x483032['name']):_0x269fac;}['isDefinedOn'](_0x1f4abe){return!0x0;}['indexedValueChanged'](_0x58342a,_0x13ae5f){return!_0x58342a['equals'](_0x13ae5f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x11922e,_0x1a5a73){const _0x596f1c=N(_0x11922e);return new E(_0x1a5a73,_0x596f1c);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x1e80d9){return{'type':'value','snapshotNode':_0x1e80d9};}function tt(_0x429e36,_0x2d2779){return{'type':'child_added','snapshotNode':_0x2d2779,'childName':_0x429e36};}function Nt(_0xc89792,_0x2c7e5f){return{'type':'child_removed','snapshotNode':_0x2c7e5f,'childName':_0xc89792};}function Pt(_0x2436d5,_0x21bc8b,_0x752ebb){return{'type':'child_changed','snapshotNode':_0x21bc8b,'childName':_0x2436d5,'oldSnap':_0x752ebb};}function $h(_0xd0f3d3,_0xfcab74){return{'type':'child_moved','snapshotNode':_0xfcab74,'childName':_0xd0f3d3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x5b8868){this['index_']=_0x5b8868;}['updateChild'](_0x441f24,_0x46eba7,_0x867d10,_0x3d7d4e,_0x93525b,_0x6adc77){f(_0x441f24['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3ff6f9=_0x441f24['getImmediateChild'](_0x46eba7);return _0x3ff6f9['getChild'](_0x3d7d4e)['equals'](_0x867d10['getChild'](_0x3d7d4e))&&_0x3ff6f9['isEmpty']()===_0x867d10['isEmpty']()||(_0x6adc77!=null&&(_0x867d10['isEmpty']()?_0x441f24['hasChild'](_0x46eba7)?_0x6adc77['trackChildChange'](Nt(_0x46eba7,_0x3ff6f9)):f(_0x441f24['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3ff6f9['isEmpty']()?_0x6adc77['trackChildChange'](tt(_0x46eba7,_0x867d10)):_0x6adc77['trackChildChange'](Pt(_0x46eba7,_0x867d10,_0x3ff6f9))),_0x441f24['isLeafNode']()&&_0x867d10['isEmpty']())?_0x441f24:_0x441f24['updateImmediateChild'](_0x46eba7,_0x867d10)['withIndex'](this['index_']);}['updateFullNode'](_0x535edf,_0x466708,_0x51385d){return _0x51385d!=null&&(_0x535edf['isLeafNode']()||_0x535edf['forEachChild'](R,(_0x322a94,_0x10286c)=>{_0x466708['hasChild'](_0x322a94)||_0x51385d['trackChildChange'](Nt(_0x322a94,_0x10286c));}),_0x466708['isLeafNode']()||_0x466708['forEachChild'](R,(_0x1fc686,_0x25f875)=>{if(_0x535edf['hasChild'](_0x1fc686)){const _0x5598d4=_0x535edf['getImmediateChild'](_0x1fc686);_0x5598d4['equals'](_0x25f875)||_0x51385d['trackChildChange'](Pt(_0x1fc686,_0x25f875,_0x5598d4));}else _0x51385d['trackChildChange'](tt(_0x1fc686,_0x25f875));})),_0x466708['withIndex'](this['index_']);}['updatePriority'](_0x58a726,_0x493163){return _0x58a726['isEmpty']()?g['EMPTY_NODE']:_0x58a726['updatePriority'](_0x493163);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2e8f0b){this['indexedFilter_']=new Yi(_0x2e8f0b['getIndex']()),this['index_']=_0x2e8f0b['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2e8f0b),this['endPost_']=Ot['getEndPost_'](_0x2e8f0b),this['startIsInclusive_']=!_0x2e8f0b['startAfterSet_'],this['endIsInclusive_']=!_0x2e8f0b['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4f1085){const _0x3ce9e5=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4f1085)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4f1085)<0x0,_0x21129f=this['endIsInclusive_']?this['index_']['compare'](_0x4f1085,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4f1085,this['getEndPost']())<0x0;return _0x3ce9e5&&_0x21129f;}['updateChild'](_0x1e7cd7,_0x521d60,_0x56e92d,_0xbcec78,_0x6eab8b,_0x1fc50e){return this['matches'](new E(_0x521d60,_0x56e92d))||(_0x56e92d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1e7cd7,_0x521d60,_0x56e92d,_0xbcec78,_0x6eab8b,_0x1fc50e);}['updateFullNode'](_0x3ddd48,_0x1454f5,_0x27a6f5){_0x1454f5['isLeafNode']()&&(_0x1454f5=g['EMPTY_NODE']);let _0x2439a9=_0x1454f5['withIndex'](this['index_']);_0x2439a9=_0x2439a9['updatePriority'](g['EMPTY_NODE']);const _0x16afaf=this;return _0x1454f5['forEachChild'](R,(_0x5bea0c,_0x5e268c)=>{_0x16afaf['matches'](new E(_0x5bea0c,_0x5e268c))||(_0x2439a9=_0x2439a9['updateImmediateChild'](_0x5bea0c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3ddd48,_0x2439a9,_0x27a6f5);}['updatePriority'](_0x2965a2,_0x2fabf3){return _0x2965a2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3c936c){if(_0x3c936c['hasStart']()){const _0x4dd983=_0x3c936c['getIndexStartName']();return _0x3c936c['getIndex']()['makePost'](_0x3c936c['getIndexStartValue'](),_0x4dd983);}else return _0x3c936c['getIndex']()['minPost']();}static['getEndPost_'](_0x3dfcaa){if(_0x3dfcaa['hasEnd']()){const _0x5b184b=_0x3dfcaa['getIndexEndName']();return _0x3dfcaa['getIndex']()['makePost'](_0x3dfcaa['getIndexEndValue'](),_0x5b184b);}else return _0x3dfcaa['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x5efecc){this['withinDirectionalStart']=_0x31c76d=>this['reverse_']?this['withinEndPost'](_0x31c76d):this['withinStartPost'](_0x31c76d),this['withinDirectionalEnd']=_0x16e70d=>this['reverse_']?this['withinStartPost'](_0x16e70d):this['withinEndPost'](_0x16e70d),this['withinStartPost']=_0x4c8102=>{const _0x291cf6=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4c8102);return this['startIsInclusive_']?_0x291cf6<=0x0:_0x291cf6<0x0;},this['withinEndPost']=_0x29869a=>{const _0x3703ab=this['index_']['compare'](_0x29869a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3703ab<=0x0:_0x3703ab<0x0;},this['rangedFilter_']=new Ot(_0x5efecc),this['index_']=_0x5efecc['getIndex'](),this['limit_']=_0x5efecc['getLimit'](),this['reverse_']=!_0x5efecc['isViewFromLeft'](),this['startIsInclusive_']=!_0x5efecc['startAfterSet_'],this['endIsInclusive_']=!_0x5efecc['endBeforeSet_'];}['updateChild'](_0x547173,_0x355733,_0x5e3648,_0x38cda7,_0x13937b,_0x7361d1){return this['rangedFilter_']['matches'](new E(_0x355733,_0x5e3648))||(_0x5e3648=g['EMPTY_NODE']),_0x547173['getImmediateChild'](_0x355733)['equals'](_0x5e3648)?_0x547173:_0x547173['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x547173,_0x355733,_0x5e3648,_0x38cda7,_0x13937b,_0x7361d1):this['fullLimitUpdateChild_'](_0x547173,_0x355733,_0x5e3648,_0x13937b,_0x7361d1);}['updateFullNode'](_0xde5a67,_0x8d9fa,_0x33bd56){let _0x48197b;if(_0x8d9fa['isLeafNode']()||_0x8d9fa['isEmpty']())_0x48197b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x8d9fa['numChildren']()&&_0x8d9fa['isIndexed'](this['index_'])){_0x48197b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3ae495;this['reverse_']?_0x3ae495=_0x8d9fa['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3ae495=_0x8d9fa['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x12f070=0x0;for(;_0x3ae495['hasNext']()&&_0x12f070<this['limit_'];){const _0x4580dc=_0x3ae495['getNext']();if(this['withinDirectionalStart'](_0x4580dc)){if(this['withinDirectionalEnd'](_0x4580dc))_0x48197b=_0x48197b['updateImmediateChild'](_0x4580dc['name'],_0x4580dc['node']),_0x12f070++;else break;}else continue;}}else{_0x48197b=_0x8d9fa['withIndex'](this['index_']),_0x48197b=_0x48197b['updatePriority'](g['EMPTY_NODE']);let _0x37d596;this['reverse_']?_0x37d596=_0x48197b['getReverseIterator'](this['index_']):_0x37d596=_0x48197b['getIterator'](this['index_']);let _0x3589f3=0x0;for(;_0x37d596['hasNext']();){const _0x3ea174=_0x37d596['getNext']();_0x3589f3<this['limit_']&&this['withinDirectionalStart'](_0x3ea174)&&this['withinDirectionalEnd'](_0x3ea174)?_0x3589f3++:_0x48197b=_0x48197b['updateImmediateChild'](_0x3ea174['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xde5a67,_0x48197b,_0x33bd56);}['updatePriority'](_0xdda2d3,_0x454798){return _0xdda2d3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x505f33,_0x328477,_0x5b7da4,_0x8c1001,_0x3ff1da){let _0x5a0b4a;if(this['reverse_']){const _0x5d0209=this['index_']['getCompare']();_0x5a0b4a=(_0x329846,_0x438158)=>_0x5d0209(_0x438158,_0x329846);}else _0x5a0b4a=this['index_']['getCompare']();const _0x51443d=_0x505f33;f(_0x51443d['numChildren']()===this['limit_'],'');const _0x379a65=new E(_0x328477,_0x5b7da4),_0x31cc3e=this['reverse_']?_0x51443d['getFirstChild'](this['index_']):_0x51443d['getLastChild'](this['index_']),_0x3f0155=this['rangedFilter_']['matches'](_0x379a65);if(_0x51443d['hasChild'](_0x328477)){const _0x506463=_0x51443d['getImmediateChild'](_0x328477);let _0x41d51b=_0x8c1001['getChildAfterChild'](this['index_'],_0x31cc3e,this['reverse_']);for(;_0x41d51b!=null&&(_0x41d51b['name']===_0x328477||_0x51443d['hasChild'](_0x41d51b['name']));)_0x41d51b=_0x8c1001['getChildAfterChild'](this['index_'],_0x41d51b,this['reverse_']);const _0x41bbe2=_0x41d51b==null?0x1:_0x5a0b4a(_0x41d51b,_0x379a65);if(_0x3f0155&&!_0x5b7da4['isEmpty']()&&_0x41bbe2>=0x0)return _0x3ff1da!=null&&_0x3ff1da['trackChildChange'](Pt(_0x328477,_0x5b7da4,_0x506463)),_0x51443d['updateImmediateChild'](_0x328477,_0x5b7da4);{_0x3ff1da!=null&&_0x3ff1da['trackChildChange'](Nt(_0x328477,_0x506463));const _0x5e71f3=_0x51443d['updateImmediateChild'](_0x328477,g['EMPTY_NODE']);return _0x41d51b!=null&&this['rangedFilter_']['matches'](_0x41d51b)?(_0x3ff1da!=null&&_0x3ff1da['trackChildChange'](tt(_0x41d51b['name'],_0x41d51b['node'])),_0x5e71f3['updateImmediateChild'](_0x41d51b['name'],_0x41d51b['node'])):_0x5e71f3;}}else return _0x5b7da4['isEmpty']()?_0x505f33:_0x3f0155&&_0x5a0b4a(_0x31cc3e,_0x379a65)>=0x0?(_0x3ff1da!=null&&(_0x3ff1da['trackChildChange'](Nt(_0x31cc3e['name'],_0x31cc3e['node'])),_0x3ff1da['trackChildChange'](tt(_0x328477,_0x5b7da4))),_0x51443d['updateImmediateChild'](_0x328477,_0x5b7da4)['updateImmediateChild'](_0x31cc3e['name'],g['EMPTY_NODE'])):_0x505f33;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3b6e7d=new Qi();return _0x3b6e7d['limitSet_']=this['limitSet_'],_0x3b6e7d['limit_']=this['limit_'],_0x3b6e7d['startSet_']=this['startSet_'],_0x3b6e7d['startAfterSet_']=this['startAfterSet_'],_0x3b6e7d['indexStartValue_']=this['indexStartValue_'],_0x3b6e7d['startNameSet_']=this['startNameSet_'],_0x3b6e7d['indexStartName_']=this['indexStartName_'],_0x3b6e7d['endSet_']=this['endSet_'],_0x3b6e7d['endBeforeSet_']=this['endBeforeSet_'],_0x3b6e7d['indexEndValue_']=this['indexEndValue_'],_0x3b6e7d['endNameSet_']=this['endNameSet_'],_0x3b6e7d['indexEndName_']=this['indexEndName_'],_0x3b6e7d['index_']=this['index_'],_0x3b6e7d['viewFrom_']=this['viewFrom_'],_0x3b6e7d;}}function qh(_0x17994c){return _0x17994c['loadsAllData']()?new Yi(_0x17994c['getIndex']()):_0x17994c['hasLimit']()?new Gh(_0x17994c):new Ot(_0x17994c);}function zh(_0x53ac57,_0x4426f6){const _0xd30f0c=_0x53ac57['copy']();return _0xd30f0c['limitSet_']=!0x0,_0xd30f0c['limit_']=_0x4426f6,_0xd30f0c['viewFrom_']='l',_0xd30f0c;}function jh(_0x3945d4,_0x2bb376,_0x185838){const _0x244992=_0x3945d4['copy']();return _0x244992['startSet_']=!0x0,_0x2bb376===void 0x0&&(_0x2bb376=null),_0x244992['indexStartValue_']=_0x2bb376,_0x185838!=null?(_0x244992['startNameSet_']=!0x0,_0x244992['indexStartName_']=_0x185838):(_0x244992['startNameSet_']=!0x1,_0x244992['indexStartName_']=''),_0x244992;}function Kh(_0x5b1376,_0x1da385,_0x2c482f){const _0x3156d8=_0x5b1376['copy']();return _0x3156d8['endSet_']=!0x0,_0x1da385===void 0x0&&(_0x1da385=null),_0x3156d8['indexEndValue_']=_0x1da385,_0x2c482f!==void 0x0?(_0x3156d8['endNameSet_']=!0x0,_0x3156d8['indexEndName_']=_0x2c482f):(_0x3156d8['endNameSet_']=!0x1,_0x3156d8['indexEndName_']=''),_0x3156d8;}function Do(_0xbcd1de,_0x7c9af6){const _0x4dbc66=_0xbcd1de['copy']();return _0x4dbc66['index_']=_0x7c9af6,_0x4dbc66;}function tr(_0x15adb4){const _0x2897f7={};if(_0x15adb4['isDefault']())return _0x2897f7;let _0x41c731;if(_0x15adb4['index_']===R?_0x41c731='$priority':_0x15adb4['index_']===Po?_0x41c731='$value':_0x15adb4['index_']===ye?_0x41c731='$key':(f(_0x15adb4['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x41c731=_0x15adb4['index_']['toString']()),_0x2897f7['orderBy']=O(_0x41c731),_0x15adb4['startSet_']){const _0x1cb2dd=_0x15adb4['startAfterSet_']?'startAfter':'startAt';_0x2897f7[_0x1cb2dd]=O(_0x15adb4['indexStartValue_']),_0x15adb4['startNameSet_']&&(_0x2897f7[_0x1cb2dd]+=','+O(_0x15adb4['indexStartName_']));}if(_0x15adb4['endSet_']){const _0x84252a=_0x15adb4['endBeforeSet_']?'endBefore':'endAt';_0x2897f7[_0x84252a]=O(_0x15adb4['indexEndValue_']),_0x15adb4['endNameSet_']&&(_0x2897f7[_0x84252a]+=','+O(_0x15adb4['indexEndName_']));}return _0x15adb4['limitSet_']&&(_0x15adb4['isViewFromLeft']()?_0x2897f7['limitToFirst']=_0x15adb4['limit_']:_0x2897f7['limitToLast']=_0x15adb4['limit_']),_0x2897f7;}function nr(_0x17b8f5){const _0x5f40b6={};if(_0x17b8f5['startSet_']&&(_0x5f40b6['sp']=_0x17b8f5['indexStartValue_'],_0x17b8f5['startNameSet_']&&(_0x5f40b6['sn']=_0x17b8f5['indexStartName_']),_0x5f40b6['sin']=!_0x17b8f5['startAfterSet_']),_0x17b8f5['endSet_']&&(_0x5f40b6['ep']=_0x17b8f5['indexEndValue_'],_0x17b8f5['endNameSet_']&&(_0x5f40b6['en']=_0x17b8f5['indexEndName_']),_0x5f40b6['ein']=!_0x17b8f5['endBeforeSet_']),_0x17b8f5['limitSet_']){_0x5f40b6['l']=_0x17b8f5['limit_'];let _0x20f834=_0x17b8f5['viewFrom_'];_0x20f834===''&&(_0x17b8f5['isViewFromLeft']()?_0x20f834='l':_0x20f834='r'),_0x5f40b6['vf']=_0x20f834;}return _0x17b8f5['index_']!==R&&(_0x5f40b6['i']=_0x17b8f5['index_']['toString']()),_0x5f40b6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1cbb41){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x431446,_0xa195c5){return _0xa195c5!==void 0x0?'tag$'+_0xa195c5:(f(_0x431446['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x431446['_path']['toString']());}constructor(_0x1cf19f,_0xfd70a7,_0x26dab2,_0xed3768){super(),this['repoInfo_']=_0x1cf19f,this['onDataUpdate_']=_0xfd70a7,this['authTokenProvider_']=_0x26dab2,this['appCheckTokenProvider_']=_0xed3768,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x5cb448,_0x59440c,_0xd6fb37,_0x5b5940){const _0x25a4cc=_0x5cb448['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x25a4cc+'\x20'+_0x5cb448['_queryIdentifier']);const _0x3b801e=fn['getListenId_'](_0x5cb448,_0xd6fb37),_0x301406={};this['listens_'][_0x3b801e]=_0x301406;const _0x4aea2f=tr(_0x5cb448['_queryParams']);this['restRequest_'](_0x25a4cc+'.json',_0x4aea2f,(_0x592b0d,_0x393eae)=>{let _0x168501=_0x393eae;if(_0x592b0d===0x194&&(_0x168501=null,_0x592b0d=null),_0x592b0d===null&&this['onDataUpdate_'](_0x25a4cc,_0x168501,!0x1,_0xd6fb37),Oe(this['listens_'],_0x3b801e)===_0x301406){let _0x510a17;_0x592b0d?_0x592b0d===0x191?_0x510a17='permission_denied':_0x510a17='rest_error:'+_0x592b0d:_0x510a17='ok',_0x5b5940(_0x510a17,null);}});}['unlisten'](_0x394169,_0x3158a7){const _0x348463=fn['getListenId_'](_0x394169,_0x3158a7);delete this['listens_'][_0x348463];}['get'](_0x34e7c2){const _0x2f5a3a=tr(_0x34e7c2['_queryParams']),_0x1c5583=_0x34e7c2['_path']['toString'](),_0x59b449=new Ve();return this['restRequest_'](_0x1c5583+'.json',_0x2f5a3a,(_0xa305e,_0x5a16a8)=>{let _0xc81d07=_0x5a16a8;_0xa305e===0x194&&(_0xc81d07=null,_0xa305e=null),_0xa305e===null?(this['onDataUpdate_'](_0x1c5583,_0xc81d07,!0x1,null),_0x59b449['resolve'](_0xc81d07)):_0x59b449['reject'](new Error(_0xc81d07));}),_0x59b449['promise'];}['refreshAuthToken'](_0x269803){}['restRequest_'](_0x24d232,_0x1a9887={},_0x1f50c0){return _0x1a9887['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xee71de,_0x3e5724])=>{_0xee71de&&_0xee71de['accessToken']&&(_0x1a9887['auth']=_0xee71de['accessToken']),_0x3e5724&&_0x3e5724['token']&&(_0x1a9887['ac']=_0x3e5724['token']);const _0x2b50fe=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x24d232+'?ns='+this['repoInfo_']['namespace']+at(_0x1a9887);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2b50fe);const _0x323252=new XMLHttpRequest();_0x323252['onreadystatechange']=()=>{if(_0x1f50c0&&_0x323252['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2b50fe+'\x20received.\x20status:',_0x323252['status'],'response:',_0x323252['responseText']);let _0xe04cfa=null;if(_0x323252['status']>=0xc8&&_0x323252['status']<0x12c){try{_0xe04cfa=bt(_0x323252['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2b50fe+':\x20'+_0x323252['responseText']);}_0x1f50c0(null,_0xe04cfa);}else _0x323252['status']!==0x191&&_0x323252['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2b50fe+'\x20Status:\x20'+_0x323252['status']),_0x1f50c0(_0x323252['status']);_0x1f50c0=null;}},_0x323252['open']('GET',_0x2b50fe,!0x0),_0x323252['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x169ebd){return this['rootNode_']['getChild'](_0x169ebd);}['updateSnapshot'](_0x27e6f8,_0x3d2d85){this['rootNode_']=this['rootNode_']['updateChild'](_0x27e6f8,_0x3d2d85);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x4cc1b5,_0xa9fb66,_0x15ba67){if(v(_0xa9fb66))_0x4cc1b5['value']=_0x15ba67,_0x4cc1b5['children']['clear']();else{if(_0x4cc1b5['value']!==null)_0x4cc1b5['value']=_0x4cc1b5['value']['updateChild'](_0xa9fb66,_0x15ba67);else{const _0x3032f4=y(_0xa9fb66);_0x4cc1b5['children']['has'](_0x3032f4)||_0x4cc1b5['children']['set'](_0x3032f4,pn());const _0xc7a2d1=_0x4cc1b5['children']['get'](_0x3032f4);_0xa9fb66=b(_0xa9fb66),Mo(_0xc7a2d1,_0xa9fb66,_0x15ba67);}}}function Ei(_0x3d798d,_0x52a120,_0x48b3f9){_0x3d798d['value']!==null?_0x48b3f9(_0x52a120,_0x3d798d['value']):Qh(_0x3d798d,(_0x416efc,_0x3f8063)=>{const _0x5e4643=new C(_0x52a120['toString']()+'/'+_0x416efc);Ei(_0x3f8063,_0x5e4643,_0x48b3f9);});}function Qh(_0x2da840,_0x4d1300){_0x2da840['children']['forEach']((_0x245d05,_0x5dd87e)=>{_0x4d1300(_0x5dd87e,_0x245d05);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0xa021fc){this['collection_']=_0xa021fc,this['last_']=null;}['get'](){const _0x269ecd=this['collection_']['get'](),_0x4f485e={..._0x269ecd};return this['last_']&&x(this['last_'],(_0x50bb21,_0x47e347)=>{_0x4f485e[_0x50bb21]=_0x4f485e[_0x50bb21]-_0x47e347;}),this['last_']=_0x269ecd,_0x4f485e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x52fe68,_0x579df0){this['server_']=_0x579df0,this['statsToReport_']={},this['statsListener_']=new Jh(_0x52fe68);const _0x1bdf2e=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1bdf2e));}['reportStats_'](){const _0x9e37f=this['statsListener_']['get'](),_0x2c03dc={};let _0x22123f=!0x1;x(_0x9e37f,(_0x485828,_0x371187)=>{_0x371187>0x0&&Y(this['statsToReport_'],_0x485828)&&(_0x2c03dc[_0x485828]=_0x371187,_0x22123f=!0x0);}),_0x22123f&&this['server_']['reportStats'](_0x2c03dc),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x59aae8){_0x59aae8[_0x59aae8['OVERWRITE']=0x0]='OVERWRITE',_0x59aae8[_0x59aae8['MERGE']=0x1]='MERGE',_0x59aae8[_0x59aae8['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x59aae8[_0x59aae8['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x3d7d2e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3d7d2e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4ace84,_0x41695b,_0x32b79a){this['path']=_0x4ace84,this['affectedTree']=_0x41695b,this['revert']=_0x32b79a,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x56b85c){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x10ba63=this['affectedTree']['subtree'](new C(_0x56b85c));return new _n(w(),_0x10ba63,this['revert']);}}else return f(y(this['path'])===_0x56b85c,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x1c84e3,_0x2744cd){this['source']=_0x1c84e3,this['path']=_0x2744cd,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3f4aa9){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x6beae5,_0x456112,_0x5eef03){this['source']=_0x6beae5,this['path']=_0x456112,this['snap']=_0x5eef03,this['type']=q['OVERWRITE'];}['operationForChild'](_0x247ad6){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x247ad6)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xdbd730,_0x45bcbd,_0x212462){this['source']=_0xdbd730,this['path']=_0x45bcbd,this['children']=_0x212462,this['type']=q['MERGE'];}['operationForChild'](_0x3656f5){if(v(this['path'])){const _0x2c3d58=this['children']['subtree'](new C(_0x3656f5));return _0x2c3d58['isEmpty']()?null:_0x2c3d58['value']?new Fe(this['source'],w(),_0x2c3d58['value']):new nt(this['source'],w(),_0x2c3d58);}else return f(y(this['path'])===_0x3656f5,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x5d60d5,_0x187bd5,_0x470423){this['node_']=_0x5d60d5,this['fullyInitialized_']=_0x187bd5,this['filtered_']=_0x470423;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x166337){if(v(_0x166337))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1a2b76=y(_0x166337);return this['isCompleteForChild'](_0x1a2b76);}['isCompleteForChild'](_0x321346){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x321346);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x298938){this['query_']=_0x298938,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x52aaaa,_0x267454,_0x460510,_0x18afc5){const _0x53c98f=[],_0x3f60ca=[];return _0x267454['forEach'](_0x92f87f=>{_0x92f87f['type']==='child_changed'&&_0x52aaaa['index_']['indexedValueChanged'](_0x92f87f['oldSnap'],_0x92f87f['snapshotNode'])&&_0x3f60ca['push']($h(_0x92f87f['childName'],_0x92f87f['snapshotNode']));}),mt(_0x52aaaa,_0x53c98f,'child_removed',_0x267454,_0x18afc5,_0x460510),mt(_0x52aaaa,_0x53c98f,'child_added',_0x267454,_0x18afc5,_0x460510),mt(_0x52aaaa,_0x53c98f,'child_moved',_0x3f60ca,_0x18afc5,_0x460510),mt(_0x52aaaa,_0x53c98f,'child_changed',_0x267454,_0x18afc5,_0x460510),mt(_0x52aaaa,_0x53c98f,'value',_0x267454,_0x18afc5,_0x460510),_0x53c98f;}function mt(_0x26ceca,_0x36ef95,_0x5a3625,_0x3f49ca,_0x1aecff,_0x3bff28){const _0x38ef00=_0x3f49ca['filter'](_0x58891f=>_0x58891f['type']===_0x5a3625);_0x38ef00['sort']((_0x40cdc1,_0x52c343)=>su(_0x26ceca,_0x40cdc1,_0x52c343)),_0x38ef00['forEach'](_0x3c453f=>{const _0x50b0e8=iu(_0x26ceca,_0x3c453f,_0x3bff28);_0x1aecff['forEach'](_0x14890b=>{_0x14890b['respondsTo'](_0x3c453f['type'])&&_0x36ef95['push'](_0x14890b['createEvent'](_0x50b0e8,_0x26ceca['query_']));});});}function iu(_0x281b04,_0xb1f46,_0x22dad7){return _0xb1f46['type']==='value'||_0xb1f46['type']==='child_removed'||(_0xb1f46['prevName']=_0x22dad7['getPredecessorChildName'](_0xb1f46['childName'],_0xb1f46['snapshotNode'],_0x281b04['index_'])),_0xb1f46;}function su(_0x3a80d7,_0x151b21,_0x26c100){if(_0x151b21['childName']==null||_0x26c100['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x37f07b=new E(_0x151b21['childName'],_0x151b21['snapshotNode']),_0x561d05=new E(_0x26c100['childName'],_0x26c100['snapshotNode']);return _0x3a80d7['index_']['compare'](_0x37f07b,_0x561d05);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x35db6d,_0xd3874f){return{'eventCache':_0x35db6d,'serverCache':_0xd3874f};}function wt(_0xf83471,_0x23017c,_0x465d01,_0x4a9558){return Dn(new Ce(_0x23017c,_0x465d01,_0x4a9558),_0xf83471['serverCache']);}function Lo(_0x176ec5,_0x2474c4,_0x3de5d4,_0x3b6c9c){return Dn(_0x176ec5['eventCache'],new Ce(_0x2474c4,_0x3de5d4,_0x3b6c9c));}function gn(_0x2a3eee){return _0x2a3eee['eventCache']['isFullyInitialized']()?_0x2a3eee['eventCache']['getNode']():null;}function Ue(_0x378131){return _0x378131['serverCache']['isFullyInitialized']()?_0x378131['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x24e7c4){let _0x7ec25c=new S(null);return x(_0x24e7c4,(_0x32f116,_0x2634c9)=>{_0x7ec25c=_0x7ec25c['set'](new C(_0x32f116),_0x2634c9);}),_0x7ec25c;}constructor(_0x408f07,_0x3e62a1=ru()){this['value']=_0x408f07,this['children']=_0x3e62a1;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1a93e2,_0x4ecec2){if(this['value']!=null&&_0x4ecec2(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1a93e2))return null;{const _0xfdcc65=y(_0x1a93e2),_0x2b9306=this['children']['get'](_0xfdcc65);if(_0x2b9306!==null){const _0x52cdb2=_0x2b9306['findRootMostMatchingPathAndValue'](b(_0x1a93e2),_0x4ecec2);return _0x52cdb2!=null?{'path':A(new C(_0xfdcc65),_0x52cdb2['path']),'value':_0x52cdb2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1b601e){return this['findRootMostMatchingPathAndValue'](_0x1b601e,()=>!0x0);}['subtree'](_0x44f3e5){if(v(_0x44f3e5))return this;{const _0x19d679=y(_0x44f3e5),_0x11eb26=this['children']['get'](_0x19d679);return _0x11eb26!==null?_0x11eb26['subtree'](b(_0x44f3e5)):new S(null);}}['set'](_0x1b0bae,_0x1079d3){if(v(_0x1b0bae))return new S(_0x1079d3,this['children']);{const _0x54afc4=y(_0x1b0bae),_0x285806=(this['children']['get'](_0x54afc4)||new S(null))['set'](b(_0x1b0bae),_0x1079d3),_0xb40db8=this['children']['insert'](_0x54afc4,_0x285806);return new S(this['value'],_0xb40db8);}}['remove'](_0xf44620){if(v(_0xf44620))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x1670f4=y(_0xf44620),_0x5e01e1=this['children']['get'](_0x1670f4);if(_0x5e01e1){const _0xce56f1=_0x5e01e1['remove'](b(_0xf44620));let _0x411b21;return _0xce56f1['isEmpty']()?_0x411b21=this['children']['remove'](_0x1670f4):_0x411b21=this['children']['insert'](_0x1670f4,_0xce56f1),this['value']===null&&_0x411b21['isEmpty']()?new S(null):new S(this['value'],_0x411b21);}else return this;}}['get'](_0x5d8311){if(v(_0x5d8311))return this['value'];{const _0x20e721=y(_0x5d8311),_0xba33ca=this['children']['get'](_0x20e721);return _0xba33ca?_0xba33ca['get'](b(_0x5d8311)):null;}}['setTree'](_0x453991,_0x2d7f3d){if(v(_0x453991))return _0x2d7f3d;{const _0x108e1f=y(_0x453991),_0x4797d9=(this['children']['get'](_0x108e1f)||new S(null))['setTree'](b(_0x453991),_0x2d7f3d);let _0xffa4b2;return _0x4797d9['isEmpty']()?_0xffa4b2=this['children']['remove'](_0x108e1f):_0xffa4b2=this['children']['insert'](_0x108e1f,_0x4797d9),new S(this['value'],_0xffa4b2);}}['fold'](_0x405c5b){return this['fold_'](w(),_0x405c5b);}['fold_'](_0xd13980,_0x4b6187){const _0x20f3ce={};return this['children']['inorderTraversal']((_0x34b5f5,_0x115531)=>{_0x20f3ce[_0x34b5f5]=_0x115531['fold_'](A(_0xd13980,_0x34b5f5),_0x4b6187);}),_0x4b6187(_0xd13980,this['value'],_0x20f3ce);}['findOnPath'](_0x27427c,_0x5dc3ac){return this['findOnPath_'](_0x27427c,w(),_0x5dc3ac);}['findOnPath_'](_0x1c9dea,_0x524291,_0x2061b9){const _0x27105f=this['value']?_0x2061b9(_0x524291,this['value']):!0x1;if(_0x27105f)return _0x27105f;if(v(_0x1c9dea))return null;{const _0x17bc9f=y(_0x1c9dea),_0x51a2ac=this['children']['get'](_0x17bc9f);return _0x51a2ac?_0x51a2ac['findOnPath_'](b(_0x1c9dea),A(_0x524291,_0x17bc9f),_0x2061b9):null;}}['foreachOnPath'](_0x1d5379,_0xca4f14){return this['foreachOnPath_'](_0x1d5379,w(),_0xca4f14);}['foreachOnPath_'](_0x1e9e3d,_0x4b16bb,_0x4b4ffd){if(v(_0x1e9e3d))return this;{this['value']&&_0x4b4ffd(_0x4b16bb,this['value']);const _0x5363de=y(_0x1e9e3d),_0x48445d=this['children']['get'](_0x5363de);return _0x48445d?_0x48445d['foreachOnPath_'](b(_0x1e9e3d),A(_0x4b16bb,_0x5363de),_0x4b4ffd):new S(null);}}['foreach'](_0x43f36f){this['foreach_'](w(),_0x43f36f);}['foreach_'](_0x4ae0ba,_0x533013){this['children']['inorderTraversal']((_0x560486,_0x20887d)=>{_0x20887d['foreach_'](A(_0x4ae0ba,_0x560486),_0x533013);}),this['value']&&_0x533013(_0x4ae0ba,this['value']);}['foreachChild'](_0x16329b){this['children']['inorderTraversal']((_0x4f30c2,_0x8fd30f)=>{_0x8fd30f['value']&&_0x16329b(_0x4f30c2,_0x8fd30f['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x3dfbcf){this['writeTree_']=_0x3dfbcf;}static['empty'](){return new j(new S(null));}}function Ct(_0xb533db,_0x39e148,_0x8a19a4){if(v(_0x39e148))return new j(new S(_0x8a19a4));{const _0x5e3454=_0xb533db['writeTree_']['findRootMostValueAndPath'](_0x39e148);if(_0x5e3454!=null){const _0x99018b=_0x5e3454['path'];let _0x11adeb=_0x5e3454['value'];const _0x49b3cd=F(_0x99018b,_0x39e148);return _0x11adeb=_0x11adeb['updateChild'](_0x49b3cd,_0x8a19a4),new j(_0xb533db['writeTree_']['set'](_0x99018b,_0x11adeb));}else{const _0xcd4b3=new S(_0x8a19a4),_0xcb331=_0xb533db['writeTree_']['setTree'](_0x39e148,_0xcd4b3);return new j(_0xcb331);}}}function Ii(_0x38f83a,_0x395670,_0x3b06e0){let _0x4a4a58=_0x38f83a;return x(_0x3b06e0,(_0x2acb24,_0x339119)=>{_0x4a4a58=Ct(_0x4a4a58,A(_0x395670,_0x2acb24),_0x339119);}),_0x4a4a58;}function sr(_0x3dd201,_0x22be7e){if(v(_0x22be7e))return j['empty']();{const _0x257134=_0x3dd201['writeTree_']['setTree'](_0x22be7e,new S(null));return new j(_0x257134);}}function wi(_0x528493,_0x29956b){return $e(_0x528493,_0x29956b)!=null;}function $e(_0x141f7e,_0x4ef13b){const _0x3f794a=_0x141f7e['writeTree_']['findRootMostValueAndPath'](_0x4ef13b);return _0x3f794a!=null?_0x141f7e['writeTree_']['get'](_0x3f794a['path'])['getChild'](F(_0x3f794a['path'],_0x4ef13b)):null;}function rr(_0x3324ab){const _0x34e4ec=[],_0x459142=_0x3324ab['writeTree_']['value'];return _0x459142!=null?_0x459142['isLeafNode']()||_0x459142['forEachChild'](R,(_0xe86cde,_0x8b3498)=>{_0x34e4ec['push'](new E(_0xe86cde,_0x8b3498));}):_0x3324ab['writeTree_']['children']['inorderTraversal']((_0x5c43b6,_0x938e6c)=>{_0x938e6c['value']!=null&&_0x34e4ec['push'](new E(_0x5c43b6,_0x938e6c['value']));}),_0x34e4ec;}function ve(_0x2f1992,_0x596d54){if(v(_0x596d54))return _0x2f1992;{const _0x50a55a=$e(_0x2f1992,_0x596d54);return _0x50a55a!=null?new j(new S(_0x50a55a)):new j(_0x2f1992['writeTree_']['subtree'](_0x596d54));}}function Ci(_0x19b147){return _0x19b147['writeTree_']['isEmpty']();}function it(_0x537b77,_0x3c4d1a){return xo(w(),_0x537b77['writeTree_'],_0x3c4d1a);}function xo(_0xa15efb,_0x3eb577,_0x7f81a8){if(_0x3eb577['value']!=null)return _0x7f81a8['updateChild'](_0xa15efb,_0x3eb577['value']);{let _0x2f70c6=null;return _0x3eb577['children']['inorderTraversal']((_0x3ff6b8,_0x446152)=>{_0x3ff6b8==='.priority'?(f(_0x446152['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2f70c6=_0x446152['value']):_0x7f81a8=xo(A(_0xa15efb,_0x3ff6b8),_0x446152,_0x7f81a8);}),!_0x7f81a8['getChild'](_0xa15efb)['isEmpty']()&&_0x2f70c6!==null&&(_0x7f81a8=_0x7f81a8['updateChild'](A(_0xa15efb,'.priority'),_0x2f70c6)),_0x7f81a8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x401cec,_0x475e2b){return Bo(_0x475e2b,_0x401cec);}function ou(_0x1412c2,_0x56b0c3,_0x4c1ba7,_0xfa9772,_0x48475d){f(_0xfa9772>_0x1412c2['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x48475d===void 0x0&&(_0x48475d=!0x0),_0x1412c2['allWrites']['push']({'path':_0x56b0c3,'snap':_0x4c1ba7,'writeId':_0xfa9772,'visible':_0x48475d}),_0x48475d&&(_0x1412c2['visibleWrites']=Ct(_0x1412c2['visibleWrites'],_0x56b0c3,_0x4c1ba7)),_0x1412c2['lastWriteId']=_0xfa9772;}function au(_0x491647,_0x580eb4,_0x79bc51,_0x5cdf8a){f(_0x5cdf8a>_0x491647['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x491647['allWrites']['push']({'path':_0x580eb4,'children':_0x79bc51,'writeId':_0x5cdf8a,'visible':!0x0}),_0x491647['visibleWrites']=Ii(_0x491647['visibleWrites'],_0x580eb4,_0x79bc51),_0x491647['lastWriteId']=_0x5cdf8a;}function cu(_0x1f1a85,_0x1c4f27){for(let _0x1d5c4e=0x0;_0x1d5c4e<_0x1f1a85['allWrites']['length'];_0x1d5c4e++){const _0x410cd1=_0x1f1a85['allWrites'][_0x1d5c4e];if(_0x410cd1['writeId']===_0x1c4f27)return _0x410cd1;}return null;}function lu(_0x33c201,_0xf6475d){const _0xca4d12=_0x33c201['allWrites']['findIndex'](_0x166789=>_0x166789['writeId']===_0xf6475d);f(_0xca4d12>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xf6b58f=_0x33c201['allWrites'][_0xca4d12];_0x33c201['allWrites']['splice'](_0xca4d12,0x1);let _0x247b98=_0xf6b58f['visible'],_0x4a44fa=!0x1,_0x6f2214=_0x33c201['allWrites']['length']-0x1;for(;_0x247b98&&_0x6f2214>=0x0;){const _0x336205=_0x33c201['allWrites'][_0x6f2214];_0x336205['visible']&&(_0x6f2214>=_0xca4d12&&hu(_0x336205,_0xf6b58f['path'])?_0x247b98=!0x1:$(_0xf6b58f['path'],_0x336205['path'])&&(_0x4a44fa=!0x0)),_0x6f2214--;}if(_0x247b98){if(_0x4a44fa)return uu(_0x33c201),!0x0;if(_0xf6b58f['snap'])_0x33c201['visibleWrites']=sr(_0x33c201['visibleWrites'],_0xf6b58f['path']);else{const _0x50705d=_0xf6b58f['children'];x(_0x50705d,_0xc0ab65=>{_0x33c201['visibleWrites']=sr(_0x33c201['visibleWrites'],A(_0xf6b58f['path'],_0xc0ab65));});}return!0x0;}else return!0x1;}function hu(_0x140a11,_0x49fb1c){if(_0x140a11['snap'])return $(_0x140a11['path'],_0x49fb1c);for(const _0x19e40a in _0x140a11['children'])if(_0x140a11['children']['hasOwnProperty'](_0x19e40a)&&$(A(_0x140a11['path'],_0x19e40a),_0x49fb1c))return!0x0;return!0x1;}function uu(_0x329bfb){_0x329bfb['visibleWrites']=Fo(_0x329bfb['allWrites'],du,w()),_0x329bfb['allWrites']['length']>0x0?_0x329bfb['lastWriteId']=_0x329bfb['allWrites'][_0x329bfb['allWrites']['length']-0x1]['writeId']:_0x329bfb['lastWriteId']=-0x1;}function du(_0x4636bf){return _0x4636bf['visible'];}function Fo(_0x367c7a,_0x1c64d2,_0x54df7f){let _0x109a5c=j['empty']();for(let _0x46f56c=0x0;_0x46f56c<_0x367c7a['length'];++_0x46f56c){const _0x5a284e=_0x367c7a[_0x46f56c];if(_0x1c64d2(_0x5a284e)){const _0x2281a1=_0x5a284e['path'];let _0x58bb67;if(_0x5a284e['snap'])$(_0x54df7f,_0x2281a1)?(_0x58bb67=F(_0x54df7f,_0x2281a1),_0x109a5c=Ct(_0x109a5c,_0x58bb67,_0x5a284e['snap'])):$(_0x2281a1,_0x54df7f)&&(_0x58bb67=F(_0x2281a1,_0x54df7f),_0x109a5c=Ct(_0x109a5c,w(),_0x5a284e['snap']['getChild'](_0x58bb67)));else{if(_0x5a284e['children']){if($(_0x54df7f,_0x2281a1))_0x58bb67=F(_0x54df7f,_0x2281a1),_0x109a5c=Ii(_0x109a5c,_0x58bb67,_0x5a284e['children']);else{if($(_0x2281a1,_0x54df7f)){if(_0x58bb67=F(_0x2281a1,_0x54df7f),v(_0x58bb67))_0x109a5c=Ii(_0x109a5c,w(),_0x5a284e['children']);else{const _0x5e56de=Oe(_0x5a284e['children'],y(_0x58bb67));if(_0x5e56de){const _0x42670c=_0x5e56de['getChild'](b(_0x58bb67));_0x109a5c=Ct(_0x109a5c,w(),_0x42670c);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x109a5c;}function Uo(_0x443318,_0x12839e,_0x19e709,_0x4a261c,_0x273b71){if(!_0x4a261c&&!_0x273b71){const _0x23f247=$e(_0x443318['visibleWrites'],_0x12839e);if(_0x23f247!=null)return _0x23f247;{const _0x45c19d=ve(_0x443318['visibleWrites'],_0x12839e);if(Ci(_0x45c19d))return _0x19e709;if(_0x19e709==null&&!wi(_0x45c19d,w()))return null;{const _0x3c80d9=_0x19e709||g['EMPTY_NODE'];return it(_0x45c19d,_0x3c80d9);}}}else{const _0x51aadd=ve(_0x443318['visibleWrites'],_0x12839e);if(!_0x273b71&&Ci(_0x51aadd))return _0x19e709;if(!_0x273b71&&_0x19e709==null&&!wi(_0x51aadd,w()))return null;{const _0x458316=function(_0x575883){return(_0x575883['visible']||_0x273b71)&&(!_0x4a261c||!~_0x4a261c['indexOf'](_0x575883['writeId']))&&($(_0x575883['path'],_0x12839e)||$(_0x12839e,_0x575883['path']));},_0x2e433=Fo(_0x443318['allWrites'],_0x458316,_0x12839e),_0x2d9357=_0x19e709||g['EMPTY_NODE'];return it(_0x2e433,_0x2d9357);}}}function fu(_0x1eb8ca,_0x32c9d2,_0x36421b){let _0xb0e16=g['EMPTY_NODE'];const _0x25be08=$e(_0x1eb8ca['visibleWrites'],_0x32c9d2);if(_0x25be08)return _0x25be08['isLeafNode']()||_0x25be08['forEachChild'](R,(_0x438167,_0x4ff06f)=>{_0xb0e16=_0xb0e16['updateImmediateChild'](_0x438167,_0x4ff06f);}),_0xb0e16;if(_0x36421b){const _0x4f7cc7=ve(_0x1eb8ca['visibleWrites'],_0x32c9d2);return _0x36421b['forEachChild'](R,(_0x37a52,_0x13eb19)=>{const _0x4acb11=it(ve(_0x4f7cc7,new C(_0x37a52)),_0x13eb19);_0xb0e16=_0xb0e16['updateImmediateChild'](_0x37a52,_0x4acb11);}),rr(_0x4f7cc7)['forEach'](_0x5b159c=>{_0xb0e16=_0xb0e16['updateImmediateChild'](_0x5b159c['name'],_0x5b159c['node']);}),_0xb0e16;}else{const _0x1b0d3d=ve(_0x1eb8ca['visibleWrites'],_0x32c9d2);return rr(_0x1b0d3d)['forEach'](_0x3b78ba=>{_0xb0e16=_0xb0e16['updateImmediateChild'](_0x3b78ba['name'],_0x3b78ba['node']);}),_0xb0e16;}}function pu(_0x108ad4,_0x33b9f4,_0x156360,_0x7a892c,_0x6b937b){f(_0x7a892c||_0x6b937b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2a9b64=A(_0x33b9f4,_0x156360);if(wi(_0x108ad4['visibleWrites'],_0x2a9b64))return null;{const _0x2a1aba=ve(_0x108ad4['visibleWrites'],_0x2a9b64);return Ci(_0x2a1aba)?_0x6b937b['getChild'](_0x156360):it(_0x2a1aba,_0x6b937b['getChild'](_0x156360));}}function _u(_0x48671b,_0x341353,_0x1c719f,_0x1c4087){const _0x5e6bc3=A(_0x341353,_0x1c719f),_0x2b3709=$e(_0x48671b['visibleWrites'],_0x5e6bc3);if(_0x2b3709!=null)return _0x2b3709;if(_0x1c4087['isCompleteForChild'](_0x1c719f)){const _0x36fd48=ve(_0x48671b['visibleWrites'],_0x5e6bc3);return it(_0x36fd48,_0x1c4087['getNode']()['getImmediateChild'](_0x1c719f));}else return null;}function gu(_0x2b4482,_0x5eede7){return $e(_0x2b4482['visibleWrites'],_0x5eede7);}function mu(_0x5293bb,_0x538f7a,_0x335817,_0xecd4e8,_0x1d399c,_0x24757f,_0x415c2c){let _0x18410d;const _0x1eb8de=ve(_0x5293bb['visibleWrites'],_0x538f7a),_0x452bbd=$e(_0x1eb8de,w());if(_0x452bbd!=null)_0x18410d=_0x452bbd;else{if(_0x335817!=null)_0x18410d=it(_0x1eb8de,_0x335817);else return[];}if(_0x18410d=_0x18410d['withIndex'](_0x415c2c),!_0x18410d['isEmpty']()&&!_0x18410d['isLeafNode']()){const _0x439e87=[],_0x1db89f=_0x415c2c['getCompare'](),_0x49b994=_0x24757f?_0x18410d['getReverseIteratorFrom'](_0xecd4e8,_0x415c2c):_0x18410d['getIteratorFrom'](_0xecd4e8,_0x415c2c);let _0x4fba44=_0x49b994['getNext']();for(;_0x4fba44&&_0x439e87['length']<_0x1d399c;)_0x1db89f(_0x4fba44,_0xecd4e8)!==0x0&&_0x439e87['push'](_0x4fba44),_0x4fba44=_0x49b994['getNext']();return _0x439e87;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x5d45c7,_0x465be6,_0x3309e8,_0x2b1d8a){return Uo(_0x5d45c7['writeTree'],_0x5d45c7['treePath'],_0x465be6,_0x3309e8,_0x2b1d8a);}function es(_0x31d00e,_0x4b204c){return fu(_0x31d00e['writeTree'],_0x31d00e['treePath'],_0x4b204c);}function or(_0x589bf2,_0x3b4131,_0x38366d,_0x33345b){return pu(_0x589bf2['writeTree'],_0x589bf2['treePath'],_0x3b4131,_0x38366d,_0x33345b);}function yn(_0x3b4c20,_0x2f1478){return gu(_0x3b4c20['writeTree'],A(_0x3b4c20['treePath'],_0x2f1478));}function vu(_0x596652,_0x1c2dc1,_0x20748a,_0x46b154,_0x1c46ba,_0x568896){return mu(_0x596652['writeTree'],_0x596652['treePath'],_0x1c2dc1,_0x20748a,_0x46b154,_0x1c46ba,_0x568896);}function ts(_0x38745a,_0x4ed1fd,_0x3369e5){return _u(_0x38745a['writeTree'],_0x38745a['treePath'],_0x4ed1fd,_0x3369e5);}function Wo(_0x2ba94d,_0x120b8c){return Bo(A(_0x2ba94d['treePath'],_0x120b8c),_0x2ba94d['writeTree']);}function Bo(_0x29d8d3,_0x8aca5d){return{'treePath':_0x29d8d3,'writeTree':_0x8aca5d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1cfdef){const _0x37ebbc=_0x1cfdef['type'],_0x3e60a5=_0x1cfdef['childName'];f(_0x37ebbc==='child_added'||_0x37ebbc==='child_changed'||_0x37ebbc==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3e60a5!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3bf6aa=this['changeMap']['get'](_0x3e60a5);if(_0x3bf6aa){const _0x14b9c3=_0x3bf6aa['type'];if(_0x37ebbc==='child_added'&&_0x14b9c3==='child_removed')this['changeMap']['set'](_0x3e60a5,Pt(_0x3e60a5,_0x1cfdef['snapshotNode'],_0x3bf6aa['snapshotNode']));else{if(_0x37ebbc==='child_removed'&&_0x14b9c3==='child_added')this['changeMap']['delete'](_0x3e60a5);else{if(_0x37ebbc==='child_removed'&&_0x14b9c3==='child_changed')this['changeMap']['set'](_0x3e60a5,Nt(_0x3e60a5,_0x3bf6aa['oldSnap']));else{if(_0x37ebbc==='child_changed'&&_0x14b9c3==='child_added')this['changeMap']['set'](_0x3e60a5,tt(_0x3e60a5,_0x1cfdef['snapshotNode']));else{if(_0x37ebbc==='child_changed'&&_0x14b9c3==='child_changed')this['changeMap']['set'](_0x3e60a5,Pt(_0x3e60a5,_0x1cfdef['snapshotNode'],_0x3bf6aa['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x1cfdef+'\x20occurred\x20after\x20'+_0x3bf6aa);}}}}}else this['changeMap']['set'](_0x3e60a5,_0x1cfdef);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4968f7){return null;}['getChildAfterChild'](_0x33d445,_0x53328e,_0x4b0cbe){return null;}}const Vo=new Iu();class ns{constructor(_0x5398a6,_0x587f57,_0x29f363=null){this['writes_']=_0x5398a6,this['viewCache_']=_0x587f57,this['optCompleteServerCache_']=_0x29f363;}['getCompleteChild'](_0xa03eb4){const _0x53a54a=this['viewCache_']['eventCache'];if(_0x53a54a['isCompleteForChild'](_0xa03eb4))return _0x53a54a['getNode']()['getImmediateChild'](_0xa03eb4);{const _0x53663c=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0xa03eb4,_0x53663c);}}['getChildAfterChild'](_0x44a7f8,_0xa9182b,_0x110f59){const _0x5d1d1d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0xfc0e51=vu(this['writes_'],_0x5d1d1d,_0xa9182b,0x1,_0x110f59,_0x44a7f8);return _0xfc0e51['length']===0x0?null:_0xfc0e51[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x5706b1){return{'filter':_0x5706b1};}function Cu(_0x58161e,_0x25a2ac){f(_0x25a2ac['eventCache']['getNode']()['isIndexed'](_0x58161e['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x25a2ac['serverCache']['getNode']()['isIndexed'](_0x58161e['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0xfe5e25,_0x4ad710,_0x26b793,_0x10a942,_0x2b9af7){const _0x5737ef=new Eu();let _0x406816,_0x2effee;if(_0x26b793['type']===q['OVERWRITE']){const _0x4d0d90=_0x26b793;_0x4d0d90['source']['fromUser']?_0x406816=Ti(_0xfe5e25,_0x4ad710,_0x4d0d90['path'],_0x4d0d90['snap'],_0x10a942,_0x2b9af7,_0x5737ef):(f(_0x4d0d90['source']['fromServer'],'Unknown\x20source.'),_0x2effee=_0x4d0d90['source']['tagged']||_0x4ad710['serverCache']['isFiltered']()&&!v(_0x4d0d90['path']),_0x406816=vn(_0xfe5e25,_0x4ad710,_0x4d0d90['path'],_0x4d0d90['snap'],_0x10a942,_0x2b9af7,_0x2effee,_0x5737ef));}else{if(_0x26b793['type']===q['MERGE']){const _0x299742=_0x26b793;_0x299742['source']['fromUser']?_0x406816=bu(_0xfe5e25,_0x4ad710,_0x299742['path'],_0x299742['children'],_0x10a942,_0x2b9af7,_0x5737ef):(f(_0x299742['source']['fromServer'],'Unknown\x20source.'),_0x2effee=_0x299742['source']['tagged']||_0x4ad710['serverCache']['isFiltered'](),_0x406816=Si(_0xfe5e25,_0x4ad710,_0x299742['path'],_0x299742['children'],_0x10a942,_0x2b9af7,_0x2effee,_0x5737ef));}else{if(_0x26b793['type']===q['ACK_USER_WRITE']){const _0x13ef87=_0x26b793;_0x13ef87['revert']?_0x406816=ku(_0xfe5e25,_0x4ad710,_0x13ef87['path'],_0x10a942,_0x2b9af7,_0x5737ef):_0x406816=Ru(_0xfe5e25,_0x4ad710,_0x13ef87['path'],_0x13ef87['affectedTree'],_0x10a942,_0x2b9af7,_0x5737ef);}else{if(_0x26b793['type']===q['LISTEN_COMPLETE'])_0x406816=Au(_0xfe5e25,_0x4ad710,_0x26b793['path'],_0x10a942,_0x5737ef);else throw ot('Unknown\x20operation\x20type:\x20'+_0x26b793['type']);}}}const _0x1ccb1b=_0x5737ef['getChanges']();return Su(_0x4ad710,_0x406816,_0x1ccb1b),{'viewCache':_0x406816,'changes':_0x1ccb1b};}function Su(_0x2817b7,_0x35994f,_0x58dfc9){const _0x39f0f4=_0x35994f['eventCache'];if(_0x39f0f4['isFullyInitialized']()){const _0x579a56=_0x39f0f4['getNode']()['isLeafNode']()||_0x39f0f4['getNode']()['isEmpty'](),_0x4958b1=gn(_0x2817b7);(_0x58dfc9['length']>0x0||!_0x2817b7['eventCache']['isFullyInitialized']()||_0x579a56&&!_0x39f0f4['getNode']()['equals'](_0x4958b1)||!_0x39f0f4['getNode']()['getPriority']()['equals'](_0x4958b1['getPriority']()))&&_0x58dfc9['push'](Oo(gn(_0x35994f)));}}function Ho(_0xa9597d,_0x7013d8,_0x5da695,_0x290047,_0x41c195,_0x3c7bc9){const _0x5ee10c=_0x7013d8['eventCache'];if(yn(_0x290047,_0x5da695)!=null)return _0x7013d8;{let _0x57b9dc,_0xaea7e5;if(v(_0x5da695)){if(f(_0x7013d8['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x7013d8['serverCache']['isFiltered']()){const _0x2566e3=Ue(_0x7013d8),_0x60762d=_0x2566e3 instanceof g?_0x2566e3:g['EMPTY_NODE'],_0x5258ac=es(_0x290047,_0x60762d);_0x57b9dc=_0xa9597d['filter']['updateFullNode'](_0x7013d8['eventCache']['getNode'](),_0x5258ac,_0x3c7bc9);}else{const _0x430f77=mn(_0x290047,Ue(_0x7013d8));_0x57b9dc=_0xa9597d['filter']['updateFullNode'](_0x7013d8['eventCache']['getNode'](),_0x430f77,_0x3c7bc9);}}else{const _0x5e1283=y(_0x5da695);if(_0x5e1283==='.priority'){f(we(_0x5da695)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x235932=_0x5ee10c['getNode']();_0xaea7e5=_0x7013d8['serverCache']['getNode']();const _0x5272e4=or(_0x290047,_0x5da695,_0x235932,_0xaea7e5);_0x5272e4!=null?_0x57b9dc=_0xa9597d['filter']['updatePriority'](_0x235932,_0x5272e4):_0x57b9dc=_0x5ee10c['getNode']();}else{const _0x5087cd=b(_0x5da695);let _0x13f8a5;if(_0x5ee10c['isCompleteForChild'](_0x5e1283)){_0xaea7e5=_0x7013d8['serverCache']['getNode']();const _0x2293b3=or(_0x290047,_0x5da695,_0x5ee10c['getNode'](),_0xaea7e5);_0x2293b3!=null?_0x13f8a5=_0x5ee10c['getNode']()['getImmediateChild'](_0x5e1283)['updateChild'](_0x5087cd,_0x2293b3):_0x13f8a5=_0x5ee10c['getNode']()['getImmediateChild'](_0x5e1283);}else _0x13f8a5=ts(_0x290047,_0x5e1283,_0x7013d8['serverCache']);_0x13f8a5!=null?_0x57b9dc=_0xa9597d['filter']['updateChild'](_0x5ee10c['getNode'](),_0x5e1283,_0x13f8a5,_0x5087cd,_0x41c195,_0x3c7bc9):_0x57b9dc=_0x5ee10c['getNode']();}}return wt(_0x7013d8,_0x57b9dc,_0x5ee10c['isFullyInitialized']()||v(_0x5da695),_0xa9597d['filter']['filtersNodes']());}}function vn(_0x2fca86,_0x4915ce,_0x1f8187,_0x587b06,_0x2ee124,_0xfaabc1,_0x280f89,_0xe5dd43){const _0x1d4cef=_0x4915ce['serverCache'];let _0x518085;const _0x3dc44f=_0x280f89?_0x2fca86['filter']:_0x2fca86['filter']['getIndexedFilter']();if(v(_0x1f8187))_0x518085=_0x3dc44f['updateFullNode'](_0x1d4cef['getNode'](),_0x587b06,null);else{if(_0x3dc44f['filtersNodes']()&&!_0x1d4cef['isFiltered']()){const _0x3c55a0=_0x1d4cef['getNode']()['updateChild'](_0x1f8187,_0x587b06);_0x518085=_0x3dc44f['updateFullNode'](_0x1d4cef['getNode'](),_0x3c55a0,null);}else{const _0x5d4499=y(_0x1f8187);if(!_0x1d4cef['isCompleteForPath'](_0x1f8187)&&we(_0x1f8187)>0x1)return _0x4915ce;const _0x533bc3=b(_0x1f8187),_0x884111=_0x1d4cef['getNode']()['getImmediateChild'](_0x5d4499)['updateChild'](_0x533bc3,_0x587b06);_0x5d4499==='.priority'?_0x518085=_0x3dc44f['updatePriority'](_0x1d4cef['getNode'](),_0x884111):_0x518085=_0x3dc44f['updateChild'](_0x1d4cef['getNode'](),_0x5d4499,_0x884111,_0x533bc3,Vo,null);}}const _0xf3279c=Lo(_0x4915ce,_0x518085,_0x1d4cef['isFullyInitialized']()||v(_0x1f8187),_0x3dc44f['filtersNodes']()),_0x20d3f6=new ns(_0x2ee124,_0xf3279c,_0xfaabc1);return Ho(_0x2fca86,_0xf3279c,_0x1f8187,_0x2ee124,_0x20d3f6,_0xe5dd43);}function Ti(_0x55d6ea,_0x23242a,_0x45b900,_0x358b79,_0x568b11,_0x6cd459,_0x325933){const _0x4040c4=_0x23242a['eventCache'];let _0x154a40,_0x44db70;const _0x466462=new ns(_0x568b11,_0x23242a,_0x6cd459);if(v(_0x45b900))_0x44db70=_0x55d6ea['filter']['updateFullNode'](_0x23242a['eventCache']['getNode'](),_0x358b79,_0x325933),_0x154a40=wt(_0x23242a,_0x44db70,!0x0,_0x55d6ea['filter']['filtersNodes']());else{const _0x8a4814=y(_0x45b900);if(_0x8a4814==='.priority')_0x44db70=_0x55d6ea['filter']['updatePriority'](_0x23242a['eventCache']['getNode'](),_0x358b79),_0x154a40=wt(_0x23242a,_0x44db70,_0x4040c4['isFullyInitialized'](),_0x4040c4['isFiltered']());else{const _0x3ea1d1=b(_0x45b900),_0x8790f6=_0x4040c4['getNode']()['getImmediateChild'](_0x8a4814);let _0x12888f;if(v(_0x3ea1d1))_0x12888f=_0x358b79;else{const _0x647d0=_0x466462['getCompleteChild'](_0x8a4814);_0x647d0!=null?Gi(_0x3ea1d1)==='.priority'&&_0x647d0['getChild'](To(_0x3ea1d1))['isEmpty']()?_0x12888f=_0x647d0:_0x12888f=_0x647d0['updateChild'](_0x3ea1d1,_0x358b79):_0x12888f=g['EMPTY_NODE'];}if(_0x8790f6['equals'](_0x12888f))_0x154a40=_0x23242a;else{const _0x309883=_0x55d6ea['filter']['updateChild'](_0x4040c4['getNode'](),_0x8a4814,_0x12888f,_0x3ea1d1,_0x466462,_0x325933);_0x154a40=wt(_0x23242a,_0x309883,_0x4040c4['isFullyInitialized'](),_0x55d6ea['filter']['filtersNodes']());}}}return _0x154a40;}function ar(_0x56a8be,_0x43a379){return _0x56a8be['eventCache']['isCompleteForChild'](_0x43a379);}function bu(_0x40767c,_0x269fc0,_0x1856a3,_0x24a524,_0x328625,_0x453536,_0x528d0f){let _0x17f9d2=_0x269fc0;return _0x24a524['foreach']((_0x1fe022,_0x6693af)=>{const _0x499ac4=A(_0x1856a3,_0x1fe022);ar(_0x269fc0,y(_0x499ac4))&&(_0x17f9d2=Ti(_0x40767c,_0x17f9d2,_0x499ac4,_0x6693af,_0x328625,_0x453536,_0x528d0f));}),_0x24a524['foreach']((_0x57afe1,_0x393271)=>{const _0x128a3f=A(_0x1856a3,_0x57afe1);ar(_0x269fc0,y(_0x128a3f))||(_0x17f9d2=Ti(_0x40767c,_0x17f9d2,_0x128a3f,_0x393271,_0x328625,_0x453536,_0x528d0f));}),_0x17f9d2;}function cr(_0x2644dd,_0x2e1351,_0x2375b4){return _0x2375b4['foreach']((_0x399b71,_0x4504ee)=>{_0x2e1351=_0x2e1351['updateChild'](_0x399b71,_0x4504ee);}),_0x2e1351;}function Si(_0x41644f,_0xa391d6,_0x58068e,_0x2f19db,_0x29e323,_0x470834,_0x1f0bc4,_0xd0e32c){if(_0xa391d6['serverCache']['getNode']()['isEmpty']()&&!_0xa391d6['serverCache']['isFullyInitialized']())return _0xa391d6;let _0x473af2=_0xa391d6,_0x113484;v(_0x58068e)?_0x113484=_0x2f19db:_0x113484=new S(null)['setTree'](_0x58068e,_0x2f19db);const _0x398b54=_0xa391d6['serverCache']['getNode']();return _0x113484['children']['inorderTraversal']((_0x290ed0,_0xaa30ac)=>{if(_0x398b54['hasChild'](_0x290ed0)){const _0x4a5fb6=_0xa391d6['serverCache']['getNode']()['getImmediateChild'](_0x290ed0),_0x32ead6=cr(_0x41644f,_0x4a5fb6,_0xaa30ac);_0x473af2=vn(_0x41644f,_0x473af2,new C(_0x290ed0),_0x32ead6,_0x29e323,_0x470834,_0x1f0bc4,_0xd0e32c);}}),_0x113484['children']['inorderTraversal']((_0x21ad34,_0x35b20c)=>{const _0x2f57b6=!_0xa391d6['serverCache']['isCompleteForChild'](_0x21ad34)&&_0x35b20c['value']===null;if(!_0x398b54['hasChild'](_0x21ad34)&&!_0x2f57b6){const _0xc7ed99=_0xa391d6['serverCache']['getNode']()['getImmediateChild'](_0x21ad34),_0x19daa2=cr(_0x41644f,_0xc7ed99,_0x35b20c);_0x473af2=vn(_0x41644f,_0x473af2,new C(_0x21ad34),_0x19daa2,_0x29e323,_0x470834,_0x1f0bc4,_0xd0e32c);}}),_0x473af2;}function Ru(_0x76f675,_0x3e2d27,_0x33a630,_0x305367,_0x4f033d,_0x1409b3,_0x231c7e){if(yn(_0x4f033d,_0x33a630)!=null)return _0x3e2d27;const _0x163ed6=_0x3e2d27['serverCache']['isFiltered'](),_0x3c1943=_0x3e2d27['serverCache'];if(_0x305367['value']!=null){if(v(_0x33a630)&&_0x3c1943['isFullyInitialized']()||_0x3c1943['isCompleteForPath'](_0x33a630))return vn(_0x76f675,_0x3e2d27,_0x33a630,_0x3c1943['getNode']()['getChild'](_0x33a630),_0x4f033d,_0x1409b3,_0x163ed6,_0x231c7e);if(v(_0x33a630)){let _0x4add06=new S(null);return _0x3c1943['getNode']()['forEachChild'](ye,(_0x3cdc78,_0x527e52)=>{_0x4add06=_0x4add06['set'](new C(_0x3cdc78),_0x527e52);}),Si(_0x76f675,_0x3e2d27,_0x33a630,_0x4add06,_0x4f033d,_0x1409b3,_0x163ed6,_0x231c7e);}else return _0x3e2d27;}else{let _0x4643c8=new S(null);return _0x305367['foreach']((_0x11adb4,_0x1fe1d7)=>{const _0x5c6a0b=A(_0x33a630,_0x11adb4);_0x3c1943['isCompleteForPath'](_0x5c6a0b)&&(_0x4643c8=_0x4643c8['set'](_0x11adb4,_0x3c1943['getNode']()['getChild'](_0x5c6a0b)));}),Si(_0x76f675,_0x3e2d27,_0x33a630,_0x4643c8,_0x4f033d,_0x1409b3,_0x163ed6,_0x231c7e);}}function Au(_0x4e49b7,_0x3fbd94,_0x3deef5,_0x56b3a7,_0x3b2e1e){const _0x145ccf=_0x3fbd94['serverCache'],_0x51f977=Lo(_0x3fbd94,_0x145ccf['getNode'](),_0x145ccf['isFullyInitialized']()||v(_0x3deef5),_0x145ccf['isFiltered']());return Ho(_0x4e49b7,_0x51f977,_0x3deef5,_0x56b3a7,Vo,_0x3b2e1e);}function ku(_0x4eda6d,_0x5d79eb,_0x1e567f,_0x3399b5,_0x14cba5,_0x2b6bd1){let _0x27515c;if(yn(_0x3399b5,_0x1e567f)!=null)return _0x5d79eb;{const _0x3cd56f=new ns(_0x3399b5,_0x5d79eb,_0x14cba5),_0x3e93f6=_0x5d79eb['eventCache']['getNode']();let _0x53ead6;if(v(_0x1e567f)||y(_0x1e567f)==='.priority'){let _0x77acaf;if(_0x5d79eb['serverCache']['isFullyInitialized']())_0x77acaf=mn(_0x3399b5,Ue(_0x5d79eb));else{const _0x40c378=_0x5d79eb['serverCache']['getNode']();f(_0x40c378 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x77acaf=es(_0x3399b5,_0x40c378);}_0x77acaf=_0x77acaf,_0x53ead6=_0x4eda6d['filter']['updateFullNode'](_0x3e93f6,_0x77acaf,_0x2b6bd1);}else{const _0x5af5fc=y(_0x1e567f);let _0x1a1167=ts(_0x3399b5,_0x5af5fc,_0x5d79eb['serverCache']);_0x1a1167==null&&_0x5d79eb['serverCache']['isCompleteForChild'](_0x5af5fc)&&(_0x1a1167=_0x3e93f6['getImmediateChild'](_0x5af5fc)),_0x1a1167!=null?_0x53ead6=_0x4eda6d['filter']['updateChild'](_0x3e93f6,_0x5af5fc,_0x1a1167,b(_0x1e567f),_0x3cd56f,_0x2b6bd1):_0x5d79eb['eventCache']['getNode']()['hasChild'](_0x5af5fc)?_0x53ead6=_0x4eda6d['filter']['updateChild'](_0x3e93f6,_0x5af5fc,g['EMPTY_NODE'],b(_0x1e567f),_0x3cd56f,_0x2b6bd1):_0x53ead6=_0x3e93f6,_0x53ead6['isEmpty']()&&_0x5d79eb['serverCache']['isFullyInitialized']()&&(_0x27515c=mn(_0x3399b5,Ue(_0x5d79eb)),_0x27515c['isLeafNode']()&&(_0x53ead6=_0x4eda6d['filter']['updateFullNode'](_0x53ead6,_0x27515c,_0x2b6bd1)));}return _0x27515c=_0x5d79eb['serverCache']['isFullyInitialized']()||yn(_0x3399b5,w())!=null,wt(_0x5d79eb,_0x53ead6,_0x27515c,_0x4eda6d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x12d35d,_0x2d1bc7){this['query_']=_0x12d35d,this['eventRegistrations_']=[];const _0x18d13c=this['query_']['_queryParams'],_0x3d69ca=new Yi(_0x18d13c['getIndex']()),_0x52645b=qh(_0x18d13c);this['processor_']=wu(_0x52645b);const _0x3213ea=_0x2d1bc7['serverCache'],_0x262dff=_0x2d1bc7['eventCache'],_0x211fdf=_0x3d69ca['updateFullNode'](g['EMPTY_NODE'],_0x3213ea['getNode'](),null),_0x3ff74e=_0x52645b['updateFullNode'](g['EMPTY_NODE'],_0x262dff['getNode'](),null),_0x5b9d55=new Ce(_0x211fdf,_0x3213ea['isFullyInitialized'](),_0x3d69ca['filtersNodes']()),_0x32f6b3=new Ce(_0x3ff74e,_0x262dff['isFullyInitialized'](),_0x52645b['filtersNodes']());this['viewCache_']=Dn(_0x32f6b3,_0x5b9d55),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x2db631){return _0x2db631['viewCache_']['serverCache']['getNode']();}function Ou(_0x463203){return gn(_0x463203['viewCache_']);}function Du(_0x1bbfc3,_0x375e94){const _0xcdb584=Ue(_0x1bbfc3['viewCache_']);return _0xcdb584&&(_0x1bbfc3['query']['_queryParams']['loadsAllData']()||!v(_0x375e94)&&!_0xcdb584['getImmediateChild'](y(_0x375e94))['isEmpty']())?_0xcdb584['getChild'](_0x375e94):null;}function lr(_0x36b9b8){return _0x36b9b8['eventRegistrations_']['length']===0x0;}function Mu(_0x331ad3,_0x48ff78){_0x331ad3['eventRegistrations_']['push'](_0x48ff78);}function hr(_0x1d21c0,_0x5be233,_0x11317d){const _0x11e53c=[];if(_0x11317d){f(_0x5be233==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x32454f=_0x1d21c0['query']['_path'];_0x1d21c0['eventRegistrations_']['forEach'](_0x3d8bb1=>{const _0x50cff8=_0x3d8bb1['createCancelEvent'](_0x11317d,_0x32454f);_0x50cff8&&_0x11e53c['push'](_0x50cff8);});}if(_0x5be233){let _0x53512a=[];for(let _0x4cb4e3=0x0;_0x4cb4e3<_0x1d21c0['eventRegistrations_']['length'];++_0x4cb4e3){const _0x313581=_0x1d21c0['eventRegistrations_'][_0x4cb4e3];if(!_0x313581['matches'](_0x5be233))_0x53512a['push'](_0x313581);else{if(_0x5be233['hasAnyCallback']()){_0x53512a=_0x53512a['concat'](_0x1d21c0['eventRegistrations_']['slice'](_0x4cb4e3+0x1));break;}}}_0x1d21c0['eventRegistrations_']=_0x53512a;}else _0x1d21c0['eventRegistrations_']=[];return _0x11e53c;}function ur(_0x595d16,_0x213e70,_0x15f699,_0x5e61c9){_0x213e70['type']===q['MERGE']&&_0x213e70['source']['queryId']!==null&&(f(Ue(_0x595d16['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x595d16['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x392aa1=_0x595d16['viewCache_'],_0x41279c=Tu(_0x595d16['processor_'],_0x392aa1,_0x213e70,_0x15f699,_0x5e61c9);return Cu(_0x595d16['processor_'],_0x41279c['viewCache']),f(_0x41279c['viewCache']['serverCache']['isFullyInitialized']()||!_0x392aa1['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x595d16['viewCache_']=_0x41279c['viewCache'],$o(_0x595d16,_0x41279c['changes'],_0x41279c['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x374717,_0x524f6b){const _0x4d0051=_0x374717['viewCache_']['eventCache'],_0x10d0bd=[];return _0x4d0051['getNode']()['isLeafNode']()||_0x4d0051['getNode']()['forEachChild'](R,(_0x1b8753,_0x39166a)=>{_0x10d0bd['push'](tt(_0x1b8753,_0x39166a));}),_0x4d0051['isFullyInitialized']()&&_0x10d0bd['push'](Oo(_0x4d0051['getNode']())),$o(_0x374717,_0x10d0bd,_0x4d0051['getNode'](),_0x524f6b);}function $o(_0x27b2ef,_0x558939,_0x2ac906,_0x39ec05){const _0x466e54=_0x39ec05?[_0x39ec05]:_0x27b2ef['eventRegistrations_'];return nu(_0x27b2ef['eventGenerator_'],_0x558939,_0x2ac906,_0x466e54);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x4defe3){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x4defe3;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x57ecab){return _0x57ecab['views']['size']===0x0;}function is(_0xda5f93,_0x5511d9,_0x235913,_0x2e4bc6){const _0x4eb4d4=_0x5511d9['source']['queryId'];if(_0x4eb4d4!==null){const _0x2b77a0=_0xda5f93['views']['get'](_0x4eb4d4);return f(_0x2b77a0!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2b77a0,_0x5511d9,_0x235913,_0x2e4bc6);}else{let _0x55c8be=[];for(const _0xf7bba8 of _0xda5f93['views']['values']())_0x55c8be=_0x55c8be['concat'](ur(_0xf7bba8,_0x5511d9,_0x235913,_0x2e4bc6));return _0x55c8be;}}function qo(_0x317cb6,_0x4a5598,_0x463a33,_0x4a1d4f,_0x37095d){const _0x44172b=_0x4a5598['_queryIdentifier'],_0x1ac921=_0x317cb6['views']['get'](_0x44172b);if(!_0x1ac921){let _0x275ea5=mn(_0x463a33,_0x37095d?_0x4a1d4f:null),_0x46a26f=!0x1;_0x275ea5?_0x46a26f=!0x0:_0x4a1d4f instanceof g?(_0x275ea5=es(_0x463a33,_0x4a1d4f),_0x46a26f=!0x1):(_0x275ea5=g['EMPTY_NODE'],_0x46a26f=!0x1);const _0x4c8a69=Dn(new Ce(_0x275ea5,_0x46a26f,!0x1),new Ce(_0x4a1d4f,_0x37095d,!0x1));return new Nu(_0x4a5598,_0x4c8a69);}return _0x1ac921;}function Wu(_0x9fefe4,_0x26a7a7,_0x36c78b,_0x4118ec,_0x55e136,_0x2209ea){const _0x388e0e=qo(_0x9fefe4,_0x26a7a7,_0x4118ec,_0x55e136,_0x2209ea);return _0x9fefe4['views']['has'](_0x26a7a7['_queryIdentifier'])||_0x9fefe4['views']['set'](_0x26a7a7['_queryIdentifier'],_0x388e0e),Mu(_0x388e0e,_0x36c78b),Lu(_0x388e0e,_0x36c78b);}function Bu(_0x536162,_0x352709,_0x2c335e,_0x2ffe88){const _0x31b8ab=_0x352709['_queryIdentifier'],_0x30fa7b=[];let _0x2d5030=[];const _0x4405f7=Te(_0x536162);if(_0x31b8ab==='default'){for(const [_0x34d455,_0x280f6e]of _0x536162['views']['entries']())_0x2d5030=_0x2d5030['concat'](hr(_0x280f6e,_0x2c335e,_0x2ffe88)),lr(_0x280f6e)&&(_0x536162['views']['delete'](_0x34d455),_0x280f6e['query']['_queryParams']['loadsAllData']()||_0x30fa7b['push'](_0x280f6e['query']));}else{const _0x58701d=_0x536162['views']['get'](_0x31b8ab);_0x58701d&&(_0x2d5030=_0x2d5030['concat'](hr(_0x58701d,_0x2c335e,_0x2ffe88)),lr(_0x58701d)&&(_0x536162['views']['delete'](_0x31b8ab),_0x58701d['query']['_queryParams']['loadsAllData']()||_0x30fa7b['push'](_0x58701d['query'])));}return _0x4405f7&&!Te(_0x536162)&&_0x30fa7b['push'](new(Fu())(_0x352709['_repo'],_0x352709['_path'])),{'removed':_0x30fa7b,'events':_0x2d5030};}function zo(_0x1cd8b4){const _0x1cba9d=[];for(const _0x332813 of _0x1cd8b4['views']['values']())_0x332813['query']['_queryParams']['loadsAllData']()||_0x1cba9d['push'](_0x332813);return _0x1cba9d;}function Ee(_0x56f481,_0x50989e){let _0xaca6e4=null;for(const _0x2c4ce9 of _0x56f481['views']['values']())_0xaca6e4=_0xaca6e4||Du(_0x2c4ce9,_0x50989e);return _0xaca6e4;}function jo(_0x3a1e59,_0x4a3f58){if(_0x4a3f58['_queryParams']['loadsAllData']())return Ln(_0x3a1e59);{const _0x3efd6b=_0x4a3f58['_queryIdentifier'];return _0x3a1e59['views']['get'](_0x3efd6b);}}function Ko(_0x55d270,_0x56af75){return jo(_0x55d270,_0x56af75)!=null;}function Te(_0xcb81b4){return Ln(_0xcb81b4)!=null;}function Ln(_0x2a0e37){for(const _0x598be0 of _0x2a0e37['views']['values']())if(_0x598be0['query']['_queryParams']['loadsAllData']())return _0x598be0;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x597895){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x597895;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x266d28){this['listenProvider_']=_0x266d28,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x43e52d,_0x291e3b,_0x1ab716,_0x3dd0a9,_0x82097f){return ou(_0x43e52d['pendingWriteTree_'],_0x291e3b,_0x1ab716,_0x3dd0a9,_0x82097f),_0x82097f?ht(_0x43e52d,new Fe(Ji(),_0x291e3b,_0x1ab716)):[];}function Gu(_0x3cf414,_0x182c71,_0x2967a6,_0x1f4062){au(_0x3cf414['pendingWriteTree_'],_0x182c71,_0x2967a6,_0x1f4062);const _0xa2f95c=S['fromObject'](_0x2967a6);return ht(_0x3cf414,new nt(Ji(),_0x182c71,_0xa2f95c));}function pe(_0x2b1ad6,_0x51e43a,_0x352430=!0x1){const _0x1fb8e1=cu(_0x2b1ad6['pendingWriteTree_'],_0x51e43a);if(lu(_0x2b1ad6['pendingWriteTree_'],_0x51e43a)){let _0x18ad15=new S(null);return _0x1fb8e1['snap']!=null?_0x18ad15=_0x18ad15['set'](w(),!0x0):x(_0x1fb8e1['children'],_0x38f4ea=>{_0x18ad15=_0x18ad15['set'](new C(_0x38f4ea),!0x0);}),ht(_0x2b1ad6,new _n(_0x1fb8e1['path'],_0x18ad15,_0x352430));}else return[];}function $t(_0x8d3da0,_0x19cd6a,_0x2cc4a5){return ht(_0x8d3da0,new Fe(Xi(),_0x19cd6a,_0x2cc4a5));}function qu(_0x24674a,_0xf0e05,_0x16877e){const _0xf28496=S['fromObject'](_0x16877e);return ht(_0x24674a,new nt(Xi(),_0xf0e05,_0xf28496));}function zu(_0x3bf576,_0x2cf39e){return ht(_0x3bf576,new Dt(Xi(),_0x2cf39e));}function ju(_0xa62267,_0x163c7b,_0x481c03){const _0x4e2aa0=rs(_0xa62267,_0x481c03);if(_0x4e2aa0){const _0x1ee467=os(_0x4e2aa0),_0xbcab91=_0x1ee467['path'],_0x42ec4f=_0x1ee467['queryId'],_0x2959d1=F(_0xbcab91,_0x163c7b),_0x5b854a=new Dt(Zi(_0x42ec4f),_0x2959d1);return as(_0xa62267,_0xbcab91,_0x5b854a);}else return[];}function wn(_0x219c91,_0x14e637,_0x21fdfa,_0x2d98af,_0x33a35c=!0x1){const _0x1f8560=_0x14e637['_path'],_0x31cba0=_0x219c91['syncPointTree_']['get'](_0x1f8560);let _0x498469=[];if(_0x31cba0&&(_0x14e637['_queryIdentifier']==='default'||Ko(_0x31cba0,_0x14e637))){const _0x1b62aa=Bu(_0x31cba0,_0x14e637,_0x21fdfa,_0x2d98af);Uu(_0x31cba0)&&(_0x219c91['syncPointTree_']=_0x219c91['syncPointTree_']['remove'](_0x1f8560));const _0x3dc40f=_0x1b62aa['removed'];if(_0x498469=_0x1b62aa['events'],!_0x33a35c){const _0xf6b14a=_0x3dc40f['findIndex'](_0x5b2e58=>_0x5b2e58['_queryParams']['loadsAllData']())!==-0x1,_0x2daeb5=_0x219c91['syncPointTree_']['findOnPath'](_0x1f8560,(_0x5083a1,_0x1e78e2)=>Te(_0x1e78e2));if(_0xf6b14a&&!_0x2daeb5){const _0x15ff3b=_0x219c91['syncPointTree_']['subtree'](_0x1f8560);if(!_0x15ff3b['isEmpty']()){const _0x5a9376=Qu(_0x15ff3b);for(let _0x3b1550=0x0;_0x3b1550<_0x5a9376['length'];++_0x3b1550){const _0x5c4203=_0x5a9376[_0x3b1550],_0x3f32eb=_0x5c4203['query'],_0x44e453=Xo(_0x219c91,_0x5c4203);_0x219c91['listenProvider_']['startListening'](Tt(_0x3f32eb),Mt(_0x219c91,_0x3f32eb),_0x44e453['hashFn'],_0x44e453['onComplete']);}}}!_0x2daeb5&&_0x3dc40f['length']>0x0&&!_0x2d98af&&(_0xf6b14a?_0x219c91['listenProvider_']['stopListening'](Tt(_0x14e637),null):_0x3dc40f['forEach'](_0x1b9764=>{const _0x52002e=_0x219c91['queryToTagMap']['get'](Fn(_0x1b9764));_0x219c91['listenProvider_']['stopListening'](Tt(_0x1b9764),_0x52002e);}));}Ju(_0x219c91,_0x3dc40f);}return _0x498469;}function Yo(_0x301db3,_0x4268c9,_0x2f102c,_0x19cffb){const _0x17e42d=rs(_0x301db3,_0x19cffb);if(_0x17e42d!=null){const _0x4b4641=os(_0x17e42d),_0x3d96c9=_0x4b4641['path'],_0x48b302=_0x4b4641['queryId'],_0x22f8f2=F(_0x3d96c9,_0x4268c9),_0x308cb4=new Fe(Zi(_0x48b302),_0x22f8f2,_0x2f102c);return as(_0x301db3,_0x3d96c9,_0x308cb4);}else return[];}function Ku(_0x589d34,_0x30277c,_0x4761b4,_0x2a3e12){const _0x50dc41=rs(_0x589d34,_0x2a3e12);if(_0x50dc41){const _0x24bb1d=os(_0x50dc41),_0x1beaa9=_0x24bb1d['path'],_0x579526=_0x24bb1d['queryId'],_0x55cf4f=F(_0x1beaa9,_0x30277c),_0x13473e=S['fromObject'](_0x4761b4),_0x7a93e7=new nt(Zi(_0x579526),_0x55cf4f,_0x13473e);return as(_0x589d34,_0x1beaa9,_0x7a93e7);}else return[];}function bi(_0x168bae,_0xd1b5eb,_0x4243bb,_0x4887f2=!0x1){const _0xee4037=_0xd1b5eb['_path'];let _0xbd104=null,_0x1f27a6=!0x1;_0x168bae['syncPointTree_']['foreachOnPath'](_0xee4037,(_0x5b012f,_0x5d73cf)=>{const _0xc5f440=F(_0x5b012f,_0xee4037);_0xbd104=_0xbd104||Ee(_0x5d73cf,_0xc5f440),_0x1f27a6=_0x1f27a6||Te(_0x5d73cf);});let _0x189684=_0x168bae['syncPointTree_']['get'](_0xee4037);_0x189684?(_0x1f27a6=_0x1f27a6||Te(_0x189684),_0xbd104=_0xbd104||Ee(_0x189684,w())):(_0x189684=new Go(),_0x168bae['syncPointTree_']=_0x168bae['syncPointTree_']['set'](_0xee4037,_0x189684));let _0x7cc8b8;_0xbd104!=null?_0x7cc8b8=!0x0:(_0x7cc8b8=!0x1,_0xbd104=g['EMPTY_NODE'],_0x168bae['syncPointTree_']['subtree'](_0xee4037)['foreachChild']((_0x25d09d,_0x16b5f5)=>{const _0x1aba3b=Ee(_0x16b5f5,w());_0x1aba3b&&(_0xbd104=_0xbd104['updateImmediateChild'](_0x25d09d,_0x1aba3b));}));const _0x3139fa=Ko(_0x189684,_0xd1b5eb);if(!_0x3139fa&&!_0xd1b5eb['_queryParams']['loadsAllData']()){const _0x1f2c20=Fn(_0xd1b5eb);f(!_0x168bae['queryToTagMap']['has'](_0x1f2c20),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x42d964=Xu();_0x168bae['queryToTagMap']['set'](_0x1f2c20,_0x42d964),_0x168bae['tagToQueryMap']['set'](_0x42d964,_0x1f2c20);}const _0xe1da75=Mn(_0x168bae['pendingWriteTree_'],_0xee4037);let _0x2936b1=Wu(_0x189684,_0xd1b5eb,_0x4243bb,_0xe1da75,_0xbd104,_0x7cc8b8);if(!_0x3139fa&&!_0x1f27a6&&!_0x4887f2){const _0x49faae=jo(_0x189684,_0xd1b5eb);_0x2936b1=_0x2936b1['concat'](Zu(_0x168bae,_0xd1b5eb,_0x49faae));}return _0x2936b1;}function xn(_0x47a680,_0x5aa2e9,_0xbb7ab9){const _0x2e1d61=_0x47a680['pendingWriteTree_'],_0x476070=_0x47a680['syncPointTree_']['findOnPath'](_0x5aa2e9,(_0x10fc0c,_0x4440d4)=>{const _0x547025=F(_0x10fc0c,_0x5aa2e9),_0x596000=Ee(_0x4440d4,_0x547025);if(_0x596000)return _0x596000;});return Uo(_0x2e1d61,_0x5aa2e9,_0x476070,_0xbb7ab9,!0x0);}function Yu(_0x3b8de5,_0x57369c){const _0x5b5dd0=_0x57369c['_path'];let _0x22a1b5=null;_0x3b8de5['syncPointTree_']['foreachOnPath'](_0x5b5dd0,(_0x55826c,_0x4d082b)=>{const _0x55ea37=F(_0x55826c,_0x5b5dd0);_0x22a1b5=_0x22a1b5||Ee(_0x4d082b,_0x55ea37);});let _0x55cbba=_0x3b8de5['syncPointTree_']['get'](_0x5b5dd0);_0x55cbba?_0x22a1b5=_0x22a1b5||Ee(_0x55cbba,w()):(_0x55cbba=new Go(),_0x3b8de5['syncPointTree_']=_0x3b8de5['syncPointTree_']['set'](_0x5b5dd0,_0x55cbba));const _0x267c61=_0x22a1b5!=null,_0x7cb662=_0x267c61?new Ce(_0x22a1b5,!0x0,!0x1):null,_0x3fcf9f=Mn(_0x3b8de5['pendingWriteTree_'],_0x57369c['_path']),_0x560df6=qo(_0x55cbba,_0x57369c,_0x3fcf9f,_0x267c61?_0x7cb662['getNode']():g['EMPTY_NODE'],_0x267c61);return Ou(_0x560df6);}function ht(_0x41bd22,_0x5757a6){return Qo(_0x5757a6,_0x41bd22['syncPointTree_'],null,Mn(_0x41bd22['pendingWriteTree_'],w()));}function Qo(_0x1b2335,_0x3c412c,_0x4b704d,_0x4c5b97){if(v(_0x1b2335['path']))return Jo(_0x1b2335,_0x3c412c,_0x4b704d,_0x4c5b97);{const _0x1dcfd3=_0x3c412c['get'](w());_0x4b704d==null&&_0x1dcfd3!=null&&(_0x4b704d=Ee(_0x1dcfd3,w()));let _0x1e1811=[];const _0xb208d0=y(_0x1b2335['path']),_0x329c3d=_0x1b2335['operationForChild'](_0xb208d0),_0x297551=_0x3c412c['children']['get'](_0xb208d0);if(_0x297551&&_0x329c3d){const _0x501e7b=_0x4b704d?_0x4b704d['getImmediateChild'](_0xb208d0):null,_0x37f7db=Wo(_0x4c5b97,_0xb208d0);_0x1e1811=_0x1e1811['concat'](Qo(_0x329c3d,_0x297551,_0x501e7b,_0x37f7db));}return _0x1dcfd3&&(_0x1e1811=_0x1e1811['concat'](is(_0x1dcfd3,_0x1b2335,_0x4c5b97,_0x4b704d))),_0x1e1811;}}function Jo(_0x217914,_0x2cd1d1,_0x48a03a,_0x32b2bb){const _0x4a8c79=_0x2cd1d1['get'](w());_0x48a03a==null&&_0x4a8c79!=null&&(_0x48a03a=Ee(_0x4a8c79,w()));let _0x27e23c=[];return _0x2cd1d1['children']['inorderTraversal']((_0x15f417,_0x2c6aff)=>{const _0x4bf364=_0x48a03a?_0x48a03a['getImmediateChild'](_0x15f417):null,_0x3ef107=Wo(_0x32b2bb,_0x15f417),_0x3e8046=_0x217914['operationForChild'](_0x15f417);_0x3e8046&&(_0x27e23c=_0x27e23c['concat'](Jo(_0x3e8046,_0x2c6aff,_0x4bf364,_0x3ef107)));}),_0x4a8c79&&(_0x27e23c=_0x27e23c['concat'](is(_0x4a8c79,_0x217914,_0x32b2bb,_0x48a03a))),_0x27e23c;}function Xo(_0x2b6178,_0x409871){const _0x2fb5c9=_0x409871['query'],_0x4059f8=Mt(_0x2b6178,_0x2fb5c9);return{'hashFn':()=>(Pu(_0x409871)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x451be6=>{if(_0x451be6==='ok')return _0x4059f8?ju(_0x2b6178,_0x2fb5c9['_path'],_0x4059f8):zu(_0x2b6178,_0x2fb5c9['_path']);{const _0x37a611=ql(_0x451be6,_0x2fb5c9);return wn(_0x2b6178,_0x2fb5c9,null,_0x37a611);}}};}function Mt(_0xd5441a,_0x24269c){const _0x22f046=Fn(_0x24269c);return _0xd5441a['queryToTagMap']['get'](_0x22f046);}function Fn(_0x4bfbc5){return _0x4bfbc5['_path']['toString']()+'$'+_0x4bfbc5['_queryIdentifier'];}function rs(_0x33f143,_0x8b5676){return _0x33f143['tagToQueryMap']['get'](_0x8b5676);}function os(_0x20268c){const _0x1b0c7e=_0x20268c['indexOf']('$');return f(_0x1b0c7e!==-0x1&&_0x1b0c7e<_0x20268c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x20268c['substr'](_0x1b0c7e+0x1),'path':new C(_0x20268c['substr'](0x0,_0x1b0c7e))};}function as(_0x19b686,_0x2f97fc,_0x4aecea){const _0x559152=_0x19b686['syncPointTree_']['get'](_0x2f97fc);f(_0x559152,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3de959=Mn(_0x19b686['pendingWriteTree_'],_0x2f97fc);return is(_0x559152,_0x4aecea,_0x3de959,null);}function Qu(_0x5d3576){return _0x5d3576['fold']((_0x5cc946,_0x2d9df8,_0x18ed5c)=>{if(_0x2d9df8&&Te(_0x2d9df8))return[Ln(_0x2d9df8)];{let _0x4aa47c=[];return _0x2d9df8&&(_0x4aa47c=zo(_0x2d9df8)),x(_0x18ed5c,(_0x466565,_0x2ceae5)=>{_0x4aa47c=_0x4aa47c['concat'](_0x2ceae5);}),_0x4aa47c;}});}function Tt(_0x232b91){return _0x232b91['_queryParams']['loadsAllData']()&&!_0x232b91['_queryParams']['isDefault']()?new(Hu())(_0x232b91['_repo'],_0x232b91['_path']):_0x232b91;}function Ju(_0xc73bc7,_0x145997){for(let _0x17f4e1=0x0;_0x17f4e1<_0x145997['length'];++_0x17f4e1){const _0x399ecf=_0x145997[_0x17f4e1];if(!_0x399ecf['_queryParams']['loadsAllData']()){const _0x45b723=Fn(_0x399ecf),_0x410384=_0xc73bc7['queryToTagMap']['get'](_0x45b723);_0xc73bc7['queryToTagMap']['delete'](_0x45b723),_0xc73bc7['tagToQueryMap']['delete'](_0x410384);}}}function Xu(){return $u++;}function Zu(_0x2d7c58,_0x1639e4,_0x56cf56){const _0x3c7839=_0x1639e4['_path'],_0xa2cc56=Mt(_0x2d7c58,_0x1639e4),_0x292141=Xo(_0x2d7c58,_0x56cf56),_0x164105=_0x2d7c58['listenProvider_']['startListening'](Tt(_0x1639e4),_0xa2cc56,_0x292141['hashFn'],_0x292141['onComplete']),_0x38b1db=_0x2d7c58['syncPointTree_']['subtree'](_0x3c7839);if(_0xa2cc56)f(!Te(_0x38b1db['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4f69d1=_0x38b1db['fold']((_0x4e9782,_0x12c738,_0x49c0de)=>{if(!v(_0x4e9782)&&_0x12c738&&Te(_0x12c738))return[Ln(_0x12c738)['query']];{let _0x209299=[];return _0x12c738&&(_0x209299=_0x209299['concat'](zo(_0x12c738)['map'](_0xd505df=>_0xd505df['query']))),x(_0x49c0de,(_0x213d8d,_0x4f9ef6)=>{_0x209299=_0x209299['concat'](_0x4f9ef6);}),_0x209299;}});for(let _0x3728da=0x0;_0x3728da<_0x4f69d1['length'];++_0x3728da){const _0x130618=_0x4f69d1[_0x3728da];_0x2d7c58['listenProvider_']['stopListening'](Tt(_0x130618),Mt(_0x2d7c58,_0x130618));}}return _0x164105;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x5a9e75){this['node_']=_0x5a9e75;}['getImmediateChild'](_0x2ee4fd){const _0x39b048=this['node_']['getImmediateChild'](_0x2ee4fd);return new cs(_0x39b048);}['node'](){return this['node_'];}}class ls{constructor(_0x312db1,_0x2b088e){this['syncTree_']=_0x312db1,this['path_']=_0x2b088e;}['getImmediateChild'](_0x38e597){const _0x37a135=A(this['path_'],_0x38e597);return new ls(this['syncTree_'],_0x37a135);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x577f21){return _0x577f21=_0x577f21||{},_0x577f21['timestamp']=_0x577f21['timestamp']||new Date()['getTime'](),_0x577f21;},fr=function(_0x1915d7,_0xfa583a,_0x172e97){if(!_0x1915d7||typeof _0x1915d7!='object')return _0x1915d7;if(f('.sv'in _0x1915d7,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1915d7['.sv']=='string')return td(_0x1915d7['.sv'],_0xfa583a,_0x172e97);if(typeof _0x1915d7['.sv']=='object')return nd(_0x1915d7['.sv'],_0xfa583a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1915d7,null,0x2));},td=function(_0x115a74,_0x5b9b8f,_0x47bd01){switch(_0x115a74){case'timestamp':return _0x47bd01['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x115a74);}},nd=function(_0x58f30f,_0x5e2538,_0x8786e9){_0x58f30f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x58f30f,null,0x2));const _0x2068c6=_0x58f30f['increment'];typeof _0x2068c6!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2068c6);const _0x5c22aa=_0x5e2538['node']();if(f(_0x5c22aa!==null&&typeof _0x5c22aa<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5c22aa['isLeafNode']())return _0x2068c6;const _0x491637=_0x5c22aa['getValue']();return typeof _0x491637!='number'?_0x2068c6:_0x491637+_0x2068c6;},Zo=function(_0x5665dc,_0x18e239,_0x113c3f,_0x4b52b9){return us(_0x18e239,new ls(_0x113c3f,_0x5665dc),_0x4b52b9);},hs=function(_0x4582bb,_0x40bdcf,_0x33ba1e){return us(_0x4582bb,new cs(_0x40bdcf),_0x33ba1e);};function us(_0x3548fe,_0x35a1e0,_0x29ac93){const _0x53a22c=_0x3548fe['getPriority']()['val'](),_0x1a1ff7=fr(_0x53a22c,_0x35a1e0['getImmediateChild']('.priority'),_0x29ac93);let _0x186571;if(_0x3548fe['isLeafNode']()){const _0x4e4da0=_0x3548fe,_0x2d59b4=fr(_0x4e4da0['getValue'](),_0x35a1e0,_0x29ac93);return _0x2d59b4!==_0x4e4da0['getValue']()||_0x1a1ff7!==_0x4e4da0['getPriority']()['val']()?new D(_0x2d59b4,N(_0x1a1ff7)):_0x3548fe;}else{const _0x23600c=_0x3548fe;return _0x186571=_0x23600c,_0x1a1ff7!==_0x23600c['getPriority']()['val']()&&(_0x186571=_0x186571['updatePriority'](new D(_0x1a1ff7))),_0x23600c['forEachChild'](R,(_0x3d82d9,_0x55bb45)=>{const _0x83cda3=us(_0x55bb45,_0x35a1e0['getImmediateChild'](_0x3d82d9),_0x29ac93);_0x83cda3!==_0x55bb45&&(_0x186571=_0x186571['updateImmediateChild'](_0x3d82d9,_0x83cda3));}),_0x186571;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x41d67d='',_0x464f2d=null,_0x934eb3={'children':{},'childCount':0x0}){this['name']=_0x41d67d,this['parent']=_0x464f2d,this['node']=_0x934eb3;}}function Un(_0x21442f,_0x262a84){let _0x4be1fc=_0x262a84 instanceof C?_0x262a84:new C(_0x262a84),_0x345df0=_0x21442f,_0x573d72=y(_0x4be1fc);for(;_0x573d72!==null;){const _0x2fb3c0=Oe(_0x345df0['node']['children'],_0x573d72)||{'children':{},'childCount':0x0};_0x345df0=new ds(_0x573d72,_0x345df0,_0x2fb3c0),_0x4be1fc=b(_0x4be1fc),_0x573d72=y(_0x4be1fc);}return _0x345df0;}function Ge(_0x448fe3){return _0x448fe3['node']['value'];}function fs(_0x18214a,_0x35d601){_0x18214a['node']['value']=_0x35d601,Ri(_0x18214a);}function ea(_0x1a37bd){return _0x1a37bd['node']['childCount']>0x0;}function id(_0x12928c){return Ge(_0x12928c)===void 0x0&&!ea(_0x12928c);}function Wn(_0x3d2917,_0xb5b5fc){x(_0x3d2917['node']['children'],(_0x53483c,_0x3ed8cc)=>{_0xb5b5fc(new ds(_0x53483c,_0x3d2917,_0x3ed8cc));});}function ta(_0x5db830,_0xf0a107,_0x10f032,_0xdcd167){_0x10f032&&_0xf0a107(_0x5db830),Wn(_0x5db830,_0x5bad32=>{ta(_0x5bad32,_0xf0a107,!0x0);});}function sd(_0x13d4fa,_0x4d0315,_0x1f352c){let _0x39611a=_0x13d4fa['parent'];for(;_0x39611a!==null;){if(_0x4d0315(_0x39611a))return!0x0;_0x39611a=_0x39611a['parent'];}return!0x1;}function Gt(_0x1f6e2b){return new C(_0x1f6e2b['parent']===null?_0x1f6e2b['name']:Gt(_0x1f6e2b['parent'])+'/'+_0x1f6e2b['name']);}function Ri(_0x5b5cd1){_0x5b5cd1['parent']!==null&&rd(_0x5b5cd1['parent'],_0x5b5cd1['name'],_0x5b5cd1);}function rd(_0x6f813e,_0x1438e1,_0x5900ca){const _0x501fa4=id(_0x5900ca),_0xb1b41a=Y(_0x6f813e['node']['children'],_0x1438e1);_0x501fa4&&_0xb1b41a?(delete _0x6f813e['node']['children'][_0x1438e1],_0x6f813e['node']['childCount']--,Ri(_0x6f813e)):!_0x501fa4&&!_0xb1b41a&&(_0x6f813e['node']['children'][_0x1438e1]=_0x5900ca['node'],_0x6f813e['node']['childCount']++,Ri(_0x6f813e));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x602ef7){return typeof _0x602ef7=='string'&&_0x602ef7['length']!==0x0&&!od['test'](_0x602ef7);},na=function(_0x28dbbb){return typeof _0x28dbbb=='string'&&_0x28dbbb['length']!==0x0&&!ad['test'](_0x28dbbb);},cd=function(_0x127795){return _0x127795&&(_0x127795=_0x127795['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x127795);},Cn=function(_0x33c0e8){return _0x33c0e8===null||typeof _0x33c0e8=='string'||typeof _0x33c0e8=='number'&&!Wi(_0x33c0e8)||_0x33c0e8&&typeof _0x33c0e8=='object'&&Y(_0x33c0e8,'.sv');},qt=function(_0x3b3b86,_0x23ddfa,_0xea003c,_0x1df5cf){_0x1df5cf&&_0x23ddfa===void 0x0||zt(Nn(_0x3b3b86,'value'),_0x23ddfa,_0xea003c);},zt=function(_0x3f0714,_0x14b10c,_0x59337f){const _0x111068=_0x59337f instanceof C?new Sh(_0x59337f,_0x3f0714):_0x59337f;if(_0x14b10c===void 0x0)throw new Error(_0x3f0714+'contains\x20undefined\x20'+Ne(_0x111068));if(typeof _0x14b10c=='function')throw new Error(_0x3f0714+'contains\x20a\x20function\x20'+Ne(_0x111068)+'\x20with\x20contents\x20=\x20'+_0x14b10c['toString']());if(Wi(_0x14b10c))throw new Error(_0x3f0714+'contains\x20'+_0x14b10c['toString']()+'\x20'+Ne(_0x111068));if(typeof _0x14b10c=='string'&&_0x14b10c['length']>oi/0x3&&Pn(_0x14b10c)>oi)throw new Error(_0x3f0714+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x111068)+'\x20(\x27'+_0x14b10c['substring'](0x0,0x32)+'...\x27)');if(_0x14b10c&&typeof _0x14b10c=='object'){let _0x36f18f=!0x1,_0x1eaf47=!0x1;if(x(_0x14b10c,(_0x40e363,_0x3040a9)=>{if(_0x40e363==='.value')_0x36f18f=!0x0;else{if(_0x40e363!=='.priority'&&_0x40e363!=='.sv'&&(_0x1eaf47=!0x0,!ps(_0x40e363)))throw new Error(_0x3f0714+'\x20contains\x20an\x20invalid\x20key\x20('+_0x40e363+')\x20'+Ne(_0x111068)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x111068,_0x40e363),zt(_0x3f0714,_0x3040a9,_0x111068),Rh(_0x111068);}),_0x36f18f&&_0x1eaf47)throw new Error(_0x3f0714+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x111068)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x19cdbf,_0x24e3fc){let _0x366f70,_0x4beefb;for(_0x366f70=0x0;_0x366f70<_0x24e3fc['length'];_0x366f70++){_0x4beefb=_0x24e3fc[_0x366f70];const _0x499bb2=kt(_0x4beefb);for(let _0x11ca2d=0x0;_0x11ca2d<_0x499bb2['length'];_0x11ca2d++)if(!(_0x499bb2[_0x11ca2d]==='.priority'&&_0x11ca2d===_0x499bb2['length']-0x1)){if(!ps(_0x499bb2[_0x11ca2d]))throw new Error(_0x19cdbf+'contains\x20an\x20invalid\x20key\x20('+_0x499bb2[_0x11ca2d]+')\x20in\x20path\x20'+_0x4beefb['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x24e3fc['sort'](Th);let _0x147021=null;for(_0x366f70=0x0;_0x366f70<_0x24e3fc['length'];_0x366f70++){if(_0x4beefb=_0x24e3fc[_0x366f70],_0x147021!==null&&$(_0x147021,_0x4beefb))throw new Error(_0x19cdbf+'contains\x20a\x20path\x20'+_0x147021['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4beefb['toString']());_0x147021=_0x4beefb;}},hd=function(_0x23bd06,_0x7f5209,_0x17476e,_0xd38569){const _0xe007f4=Nn(_0x23bd06,'values');if(!(_0x7f5209&&typeof _0x7f5209=='object')||Array['isArray'](_0x7f5209))throw new Error(_0xe007f4+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1e38b3=[];x(_0x7f5209,(_0x39cd4c,_0x32f5b1)=>{const _0x635719=new C(_0x39cd4c);if(zt(_0xe007f4,_0x32f5b1,A(_0x17476e,_0x635719)),Gi(_0x635719)==='.priority'&&!Cn(_0x32f5b1))throw new Error(_0xe007f4+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x635719['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1e38b3['push'](_0x635719);}),ld(_0xe007f4,_0x1e38b3);},_s=function(_0x4722ef,_0xe91de5,_0x1ac9e4,_0x1c094f){if(!na(_0x1ac9e4))throw new Error(Nn(_0x4722ef,_0xe91de5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1ac9e4+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x44bb2e,_0xa946f5,_0x199d67,_0x567a97){_0x199d67&&(_0x199d67=_0x199d67['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x44bb2e,_0xa946f5,_0x199d67);},gs=function(_0x1e20bc,_0x5a021a){if(y(_0x5a021a)==='.info')throw new Error(_0x1e20bc+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0xea3a86,_0xf8b488){const _0x595dce=_0xf8b488['path']['toString']();if(typeof _0xf8b488['repoInfo']['host']!='string'||_0xf8b488['repoInfo']['host']['length']===0x0||!ps(_0xf8b488['repoInfo']['namespace'])&&_0xf8b488['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x595dce['length']!==0x0&&!cd(_0x595dce))throw new Error(Nn(_0xea3a86,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x570ead,_0x5c1e73){let _0x28d0a2=null;for(let _0x1a4440=0x0;_0x1a4440<_0x5c1e73['length'];_0x1a4440++){const _0x416d54=_0x5c1e73[_0x1a4440],_0xd3734e=_0x416d54['getPath']();_0x28d0a2!==null&&!qi(_0xd3734e,_0x28d0a2['path'])&&(_0x570ead['eventLists_']['push'](_0x28d0a2),_0x28d0a2=null),_0x28d0a2===null&&(_0x28d0a2={'events':[],'path':_0xd3734e}),_0x28d0a2['events']['push'](_0x416d54);}_0x28d0a2&&_0x570ead['eventLists_']['push'](_0x28d0a2);}function ia(_0x146388,_0x403af5,_0xf4bef9){Bn(_0x146388,_0xf4bef9),sa(_0x146388,_0x39bac6=>qi(_0x39bac6,_0x403af5));}function V(_0x11fb60,_0xa809d5,_0x30f2ee){Bn(_0x11fb60,_0x30f2ee),sa(_0x11fb60,_0x2bcbae=>$(_0x2bcbae,_0xa809d5)||$(_0xa809d5,_0x2bcbae));}function sa(_0x54643c,_0x1511d1){_0x54643c['recursionDepth_']++;let _0x54504c=!0x0;for(let _0x272f1c=0x0;_0x272f1c<_0x54643c['eventLists_']['length'];_0x272f1c++){const _0x4c11cd=_0x54643c['eventLists_'][_0x272f1c];if(_0x4c11cd){const _0x16fa1c=_0x4c11cd['path'];_0x1511d1(_0x16fa1c)?(pd(_0x54643c['eventLists_'][_0x272f1c]),_0x54643c['eventLists_'][_0x272f1c]=null):_0x54504c=!0x1;}}_0x54504c&&(_0x54643c['eventLists_']=[]),_0x54643c['recursionDepth_']--;}function pd(_0x29f5d6){for(let _0x3833d0=0x0;_0x3833d0<_0x29f5d6['events']['length'];_0x3833d0++){const _0x1bdab9=_0x29f5d6['events'][_0x3833d0];if(_0x1bdab9!==null){_0x29f5d6['events'][_0x3833d0]=null;const _0x563860=_0x1bdab9['getEventRunner']();Et&&L('event:\x20'+_0x1bdab9['toString']()),lt(_0x563860);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x54e0ba,_0x118b52,_0x11b0e9,_0x17b450){this['repoInfo_']=_0x54e0ba,this['forceRestClient_']=_0x118b52,this['authTokenProvider_']=_0x11b0e9,this['appCheckProvider_']=_0x17b450,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x283daf,_0x20260c,_0x6ee0af){if(_0x283daf['stats_']=Hi(_0x283daf['repoInfo_']),_0x283daf['forceRestClient_']||Yl())_0x283daf['server_']=new fn(_0x283daf['repoInfo_'],(_0x469ff2,_0x37a5d5,_0x189289,_0xc4444c)=>{pr(_0x283daf,_0x469ff2,_0x37a5d5,_0x189289,_0xc4444c);},_0x283daf['authTokenProvider_'],_0x283daf['appCheckProvider_']),setTimeout(()=>_r(_0x283daf,!0x0),0x0);else{if(typeof _0x6ee0af<'u'&&_0x6ee0af!==null){if(typeof _0x6ee0af!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x6ee0af);}catch(_0x1d4b79){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1d4b79);}}_0x283daf['persistentConnection_']=new ie(_0x283daf['repoInfo_'],_0x20260c,(_0x22c4f3,_0x4cd5f0,_0x43d39a,_0x355b38)=>{pr(_0x283daf,_0x22c4f3,_0x4cd5f0,_0x43d39a,_0x355b38);},_0x5a752e=>{_r(_0x283daf,_0x5a752e);},_0x5424dc=>{yd(_0x283daf,_0x5424dc);},_0x283daf['authTokenProvider_'],_0x283daf['appCheckProvider_'],_0x6ee0af),_0x283daf['server_']=_0x283daf['persistentConnection_'];}_0x283daf['authTokenProvider_']['addTokenChangeListener'](_0x121060=>{_0x283daf['server_']['refreshAuthToken'](_0x121060);}),_0x283daf['appCheckProvider_']['addTokenChangeListener'](_0xf1190a=>{_0x283daf['server_']['refreshAppCheckToken'](_0xf1190a['token']);}),_0x283daf['statsReporter_']=eh(_0x283daf['repoInfo_'],()=>new eu(_0x283daf['stats_'],_0x283daf['server_'])),_0x283daf['infoData_']=new Yh(),_0x283daf['infoSyncTree_']=new dr({'startListening':(_0x200318,_0x400248,_0x4f6a4e,_0x1bc23)=>{let _0x50f1f9=[];const _0x5c93d3=_0x283daf['infoData_']['getNode'](_0x200318['_path']);return _0x5c93d3['isEmpty']()||(_0x50f1f9=$t(_0x283daf['infoSyncTree_'],_0x200318['_path'],_0x5c93d3),setTimeout(()=>{_0x1bc23('ok');},0x0)),_0x50f1f9;},'stopListening':()=>{}}),ms(_0x283daf,'connected',!0x1),_0x283daf['serverSyncTree_']=new dr({'startListening':(_0x181000,_0x5a2db8,_0x1d5c66,_0x1021eb)=>(_0x283daf['server_']['listen'](_0x181000,_0x1d5c66,_0x5a2db8,(_0x4dda92,_0x146e10)=>{const _0x1aa81b=_0x1021eb(_0x4dda92,_0x146e10);V(_0x283daf['eventQueue_'],_0x181000['_path'],_0x1aa81b);}),[]),'stopListening':(_0x38238e,_0x175fc3)=>{_0x283daf['server_']['unlisten'](_0x38238e,_0x175fc3);}});}function oa(_0x18953e){const _0xc1d80d=_0x18953e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xc1d80d;}function jt(_0x169055){return ed({'timestamp':oa(_0x169055)});}function pr(_0xb65707,_0x58769c,_0x24124f,_0x179333,_0x17f038){_0xb65707['dataUpdateCount']++;const _0x5b07d8=new C(_0x58769c);_0x24124f=_0xb65707['interceptServerDataCallback_']?_0xb65707['interceptServerDataCallback_'](_0x58769c,_0x24124f):_0x24124f;let _0x4f3cbc=[];if(_0x17f038){if(_0x179333){const _0xe85f58=ln(_0x24124f,_0x430895=>N(_0x430895));_0x4f3cbc=Ku(_0xb65707['serverSyncTree_'],_0x5b07d8,_0xe85f58,_0x17f038);}else{const _0x5744c4=N(_0x24124f);_0x4f3cbc=Yo(_0xb65707['serverSyncTree_'],_0x5b07d8,_0x5744c4,_0x17f038);}}else{if(_0x179333){const _0x38d2b5=ln(_0x24124f,_0x9fdf0f=>N(_0x9fdf0f));_0x4f3cbc=qu(_0xb65707['serverSyncTree_'],_0x5b07d8,_0x38d2b5);}else{const _0x42750a=N(_0x24124f);_0x4f3cbc=$t(_0xb65707['serverSyncTree_'],_0x5b07d8,_0x42750a);}}let _0xc740a2=_0x5b07d8;_0x4f3cbc['length']>0x0&&(_0xc740a2=st(_0xb65707,_0x5b07d8)),V(_0xb65707['eventQueue_'],_0xc740a2,_0x4f3cbc);}function _r(_0x313edc,_0x37b9f9){ms(_0x313edc,'connected',_0x37b9f9),_0x37b9f9===!0x1&&wd(_0x313edc);}function yd(_0x5458f7,_0x4fe6a1){x(_0x4fe6a1,(_0x4d7449,_0xe5f002)=>{ms(_0x5458f7,_0x4d7449,_0xe5f002);});}function ms(_0x466c38,_0x4fec1a,_0x331352){const _0x41c65b=new C('/.info/'+_0x4fec1a),_0x20720f=N(_0x331352);_0x466c38['infoData_']['updateSnapshot'](_0x41c65b,_0x20720f);const _0x2696a5=$t(_0x466c38['infoSyncTree_'],_0x41c65b,_0x20720f);V(_0x466c38['eventQueue_'],_0x41c65b,_0x2696a5);}function Vn(_0x3b2276){return _0x3b2276['nextWriteId_']++;}function vd(_0x44dc69,_0xc47e81,_0x20d98b){const _0x5c4113=Yu(_0x44dc69['serverSyncTree_'],_0xc47e81);return _0x5c4113!=null?Promise['resolve'](_0x5c4113):_0x44dc69['server_']['get'](_0xc47e81)['then'](_0x39f793=>{const _0x2f9501=N(_0x39f793)['withIndex'](_0xc47e81['_queryParams']['getIndex']());bi(_0x44dc69['serverSyncTree_'],_0xc47e81,_0x20d98b,!0x0);let _0x5dd313;if(_0xc47e81['_queryParams']['loadsAllData']())_0x5dd313=$t(_0x44dc69['serverSyncTree_'],_0xc47e81['_path'],_0x2f9501);else{const _0x1909a3=Mt(_0x44dc69['serverSyncTree_'],_0xc47e81);_0x5dd313=Yo(_0x44dc69['serverSyncTree_'],_0xc47e81['_path'],_0x2f9501,_0x1909a3);}return V(_0x44dc69['eventQueue_'],_0xc47e81['_path'],_0x5dd313),wn(_0x44dc69['serverSyncTree_'],_0xc47e81,_0x20d98b,null,!0x0),_0x2f9501;},_0x5a0fe9=>(ut(_0x44dc69,'get\x20for\x20query\x20'+O(_0xc47e81)+'\x20failed:\x20'+_0x5a0fe9),Promise['reject'](new Error(_0x5a0fe9))));}function Ed(_0x370053,_0x500130,_0x5eeadf,_0xf0f54a,_0x3d6784){ut(_0x370053,'set',{'path':_0x500130['toString'](),'value':_0x5eeadf,'priority':_0xf0f54a});const _0x2e3bd1=jt(_0x370053),_0x1dc49d=N(_0x5eeadf,_0xf0f54a),_0x26c4b3=xn(_0x370053['serverSyncTree_'],_0x500130),_0x183595=hs(_0x1dc49d,_0x26c4b3,_0x2e3bd1),_0x167ad7=Vn(_0x370053),_0x271ac4=ss(_0x370053['serverSyncTree_'],_0x500130,_0x183595,_0x167ad7,!0x0);Bn(_0x370053['eventQueue_'],_0x271ac4),_0x370053['server_']['put'](_0x500130['toString'](),_0x1dc49d['val'](!0x0),(_0x1d2017,_0x2ada4a)=>{const _0x2e5448=_0x1d2017==='ok';_0x2e5448||U('set\x20at\x20'+_0x500130+'\x20failed:\x20'+_0x1d2017);const _0x3d7738=pe(_0x370053['serverSyncTree_'],_0x167ad7,!_0x2e5448);V(_0x370053['eventQueue_'],_0x500130,_0x3d7738),Ai(_0x370053,_0x3d6784,_0x1d2017,_0x2ada4a);});const _0x174e44=vs(_0x370053,_0x500130);st(_0x370053,_0x174e44),V(_0x370053['eventQueue_'],_0x174e44,[]);}function Id(_0x390a99,_0xf2050d,_0x4ee116,_0x55fc0f){ut(_0x390a99,'update',{'path':_0xf2050d['toString'](),'value':_0x4ee116});let _0x49f4ae=!0x0;const _0x46dd7f=jt(_0x390a99),_0x3ba382={};if(x(_0x4ee116,(_0x43df4e,_0x4c19ef)=>{_0x49f4ae=!0x1,_0x3ba382[_0x43df4e]=Zo(A(_0xf2050d,_0x43df4e),N(_0x4c19ef),_0x390a99['serverSyncTree_'],_0x46dd7f);}),_0x49f4ae)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x390a99,_0x55fc0f,'ok',void 0x0);else{const _0x1f4d34=Vn(_0x390a99),_0x14b055=Gu(_0x390a99['serverSyncTree_'],_0xf2050d,_0x3ba382,_0x1f4d34);Bn(_0x390a99['eventQueue_'],_0x14b055),_0x390a99['server_']['merge'](_0xf2050d['toString'](),_0x4ee116,(_0x56af48,_0x176fe3)=>{const _0x4365dc=_0x56af48==='ok';_0x4365dc||U('update\x20at\x20'+_0xf2050d+'\x20failed:\x20'+_0x56af48);const _0x22d6ae=pe(_0x390a99['serverSyncTree_'],_0x1f4d34,!_0x4365dc),_0x39739b=_0x22d6ae['length']>0x0?st(_0x390a99,_0xf2050d):_0xf2050d;V(_0x390a99['eventQueue_'],_0x39739b,_0x22d6ae),Ai(_0x390a99,_0x55fc0f,_0x56af48,_0x176fe3);}),x(_0x4ee116,_0x268dfa=>{const _0x3657ae=vs(_0x390a99,A(_0xf2050d,_0x268dfa));st(_0x390a99,_0x3657ae);}),V(_0x390a99['eventQueue_'],_0xf2050d,[]);}}function wd(_0x48880a){ut(_0x48880a,'onDisconnectEvents');const _0x5e2240=jt(_0x48880a),_0x34635b=pn();Ei(_0x48880a['onDisconnect_'],w(),(_0x7385c2,_0x3bcee5)=>{const _0x43ca89=Zo(_0x7385c2,_0x3bcee5,_0x48880a['serverSyncTree_'],_0x5e2240);Mo(_0x34635b,_0x7385c2,_0x43ca89);});let _0x3e6c23=[];Ei(_0x34635b,w(),(_0x16c7fe,_0x499004)=>{_0x3e6c23=_0x3e6c23['concat']($t(_0x48880a['serverSyncTree_'],_0x16c7fe,_0x499004));const _0x2a323f=vs(_0x48880a,_0x16c7fe);st(_0x48880a,_0x2a323f);}),_0x48880a['onDisconnect_']=pn(),V(_0x48880a['eventQueue_'],w(),_0x3e6c23);}function Cd(_0x64c0a8,_0xf6d89c,_0x24b60e){let _0x57a691;y(_0xf6d89c['_path'])==='.info'?_0x57a691=bi(_0x64c0a8['infoSyncTree_'],_0xf6d89c,_0x24b60e):_0x57a691=bi(_0x64c0a8['serverSyncTree_'],_0xf6d89c,_0x24b60e),ia(_0x64c0a8['eventQueue_'],_0xf6d89c['_path'],_0x57a691);}function Td(_0x562061,_0x15ea4d,_0x4ef624){let _0x29f0e1;y(_0x15ea4d['_path'])==='.info'?_0x29f0e1=wn(_0x562061['infoSyncTree_'],_0x15ea4d,_0x4ef624):_0x29f0e1=wn(_0x562061['serverSyncTree_'],_0x15ea4d,_0x4ef624),ia(_0x562061['eventQueue_'],_0x15ea4d['_path'],_0x29f0e1);}function aa(_0x525b3e){_0x525b3e['persistentConnection_']&&_0x525b3e['persistentConnection_']['interrupt'](ra);}function Sd(_0x598cb0){_0x598cb0['persistentConnection_']&&_0x598cb0['persistentConnection_']['resume'](ra);}function ut(_0x28385d,..._0x25790a){let _0x4b7715='';_0x28385d['persistentConnection_']&&(_0x4b7715=_0x28385d['persistentConnection_']['id']+':'),L(_0x4b7715,..._0x25790a);}function Ai(_0x4b888c,_0x260c0e,_0x5d6333,_0x41cb4d){_0x260c0e&&lt(()=>{if(_0x5d6333==='ok')_0x260c0e(null);else{const _0x5e3084=(_0x5d6333||'error')['toUpperCase']();let _0x248d93=_0x5e3084;_0x41cb4d&&(_0x248d93+=':\x20'+_0x41cb4d);const _0x511910=new Error(_0x248d93);_0x511910['code']=_0x5e3084,_0x260c0e(_0x511910);}});}function bd(_0x344091,_0x39d52d,_0x2944e3,_0x54fbe2,_0x385aad,_0x595afd){ut(_0x344091,'transaction\x20on\x20'+_0x39d52d);const _0x5e65ef={'path':_0x39d52d,'update':_0x2944e3,'onComplete':_0x54fbe2,'status':null,'order':to(),'applyLocally':_0x595afd,'retryCount':0x0,'unwatcher':_0x385aad,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x14281c=ys(_0x344091,_0x39d52d,void 0x0);_0x5e65ef['currentInputSnapshot']=_0x14281c;const _0x19c6e6=_0x5e65ef['update'](_0x14281c['val']());if(_0x19c6e6===void 0x0)_0x5e65ef['unwatcher'](),_0x5e65ef['currentOutputSnapshotRaw']=null,_0x5e65ef['currentOutputSnapshotResolved']=null,_0x5e65ef['onComplete']&&_0x5e65ef['onComplete'](null,!0x1,_0x5e65ef['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x19c6e6,_0x5e65ef['path']),_0x5e65ef['status']=0x0;const _0x343ba7=Un(_0x344091['transactionQueueTree_'],_0x39d52d),_0x3b5c65=Ge(_0x343ba7)||[];_0x3b5c65['push'](_0x5e65ef),fs(_0x343ba7,_0x3b5c65);let _0x444b09;typeof _0x19c6e6=='object'&&_0x19c6e6!==null&&Y(_0x19c6e6,'.priority')?(_0x444b09=Oe(_0x19c6e6,'.priority'),f(Cn(_0x444b09),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x444b09=(xn(_0x344091['serverSyncTree_'],_0x39d52d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3bdd03=jt(_0x344091),_0x3dce7b=N(_0x19c6e6,_0x444b09),_0x1d990b=hs(_0x3dce7b,_0x14281c,_0x3bdd03);_0x5e65ef['currentOutputSnapshotRaw']=_0x3dce7b,_0x5e65ef['currentOutputSnapshotResolved']=_0x1d990b,_0x5e65ef['currentWriteId']=Vn(_0x344091);const _0x2ba10e=ss(_0x344091['serverSyncTree_'],_0x39d52d,_0x1d990b,_0x5e65ef['currentWriteId'],_0x5e65ef['applyLocally']);V(_0x344091['eventQueue_'],_0x39d52d,_0x2ba10e),Hn(_0x344091,_0x344091['transactionQueueTree_']);}}function ys(_0x117184,_0x187b61,_0x1ad754){return xn(_0x117184['serverSyncTree_'],_0x187b61,_0x1ad754)||g['EMPTY_NODE'];}function Hn(_0x2eaa6e,_0x3fa4ce=_0x2eaa6e['transactionQueueTree_']){if(_0x3fa4ce||$n(_0x2eaa6e,_0x3fa4ce),Ge(_0x3fa4ce)){const _0x18e606=la(_0x2eaa6e,_0x3fa4ce);f(_0x18e606['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x18e606['every'](_0x20a10c=>_0x20a10c['status']===0x0)&&Rd(_0x2eaa6e,Gt(_0x3fa4ce),_0x18e606);}else ea(_0x3fa4ce)&&Wn(_0x3fa4ce,_0x2da8d2=>{Hn(_0x2eaa6e,_0x2da8d2);});}function Rd(_0x5e1acb,_0x337ec0,_0x2c9cb1){const _0x5483cb=_0x2c9cb1['map'](_0x547719=>_0x547719['currentWriteId']),_0x107a7e=ys(_0x5e1acb,_0x337ec0,_0x5483cb);let _0x68bb98=_0x107a7e;const _0x3a812e=_0x107a7e['hash']();for(let _0x3a1631=0x0;_0x3a1631<_0x2c9cb1['length'];_0x3a1631++){const _0x578373=_0x2c9cb1[_0x3a1631];f(_0x578373['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x578373['status']=0x1,_0x578373['retryCount']++;const _0x3eb832=F(_0x337ec0,_0x578373['path']);_0x68bb98=_0x68bb98['updateChild'](_0x3eb832,_0x578373['currentOutputSnapshotRaw']);}const _0x4bd676=_0x68bb98['val'](!0x0),_0x291ba3=_0x337ec0;_0x5e1acb['server_']['put'](_0x291ba3['toString'](),_0x4bd676,_0x509464=>{ut(_0x5e1acb,'transaction\x20put\x20response',{'path':_0x291ba3['toString'](),'status':_0x509464});let _0x568544=[];if(_0x509464==='ok'){const _0x1450a8=[];for(let _0x5602cf=0x0;_0x5602cf<_0x2c9cb1['length'];_0x5602cf++)_0x2c9cb1[_0x5602cf]['status']=0x2,_0x568544=_0x568544['concat'](pe(_0x5e1acb['serverSyncTree_'],_0x2c9cb1[_0x5602cf]['currentWriteId'])),_0x2c9cb1[_0x5602cf]['onComplete']&&_0x1450a8['push'](()=>_0x2c9cb1[_0x5602cf]['onComplete'](null,!0x0,_0x2c9cb1[_0x5602cf]['currentOutputSnapshotResolved'])),_0x2c9cb1[_0x5602cf]['unwatcher']();$n(_0x5e1acb,Un(_0x5e1acb['transactionQueueTree_'],_0x337ec0)),Hn(_0x5e1acb,_0x5e1acb['transactionQueueTree_']),V(_0x5e1acb['eventQueue_'],_0x337ec0,_0x568544);for(let _0x54978e=0x0;_0x54978e<_0x1450a8['length'];_0x54978e++)lt(_0x1450a8[_0x54978e]);}else{if(_0x509464==='datastale'){for(let _0xc5e701=0x0;_0xc5e701<_0x2c9cb1['length'];_0xc5e701++)_0x2c9cb1[_0xc5e701]['status']===0x3?_0x2c9cb1[_0xc5e701]['status']=0x4:_0x2c9cb1[_0xc5e701]['status']=0x0;}else{U('transaction\x20at\x20'+_0x291ba3['toString']()+'\x20failed:\x20'+_0x509464);for(let _0x2feb1a=0x0;_0x2feb1a<_0x2c9cb1['length'];_0x2feb1a++)_0x2c9cb1[_0x2feb1a]['status']=0x4,_0x2c9cb1[_0x2feb1a]['abortReason']=_0x509464;}st(_0x5e1acb,_0x337ec0);}},_0x3a812e);}function st(_0x1b329e,_0x8504ce){const _0x166d1a=ca(_0x1b329e,_0x8504ce),_0x3c21c9=Gt(_0x166d1a),_0x4262c1=la(_0x1b329e,_0x166d1a);return Ad(_0x1b329e,_0x4262c1,_0x3c21c9),_0x3c21c9;}function Ad(_0x255018,_0x9ab2a1,_0x19bf97){if(_0x9ab2a1['length']===0x0)return;const _0xecb6f7=[];let _0x2e3285=[];const _0x21bb99=_0x9ab2a1['filter'](_0x10c9f0=>_0x10c9f0['status']===0x0)['map'](_0x20f234=>_0x20f234['currentWriteId']);for(let _0x3eaa62=0x0;_0x3eaa62<_0x9ab2a1['length'];_0x3eaa62++){const _0x22224a=_0x9ab2a1[_0x3eaa62],_0xdc814=F(_0x19bf97,_0x22224a['path']);let _0x156181=!0x1,_0x8f9583;if(f(_0xdc814!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x22224a['status']===0x4)_0x156181=!0x0,_0x8f9583=_0x22224a['abortReason'],_0x2e3285=_0x2e3285['concat'](pe(_0x255018['serverSyncTree_'],_0x22224a['currentWriteId'],!0x0));else{if(_0x22224a['status']===0x0){if(_0x22224a['retryCount']>=_d)_0x156181=!0x0,_0x8f9583='maxretry',_0x2e3285=_0x2e3285['concat'](pe(_0x255018['serverSyncTree_'],_0x22224a['currentWriteId'],!0x0));else{const _0x12d6a9=ys(_0x255018,_0x22224a['path'],_0x21bb99);_0x22224a['currentInputSnapshot']=_0x12d6a9;const _0x4f3a10=_0x9ab2a1[_0x3eaa62]['update'](_0x12d6a9['val']());if(_0x4f3a10!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x4f3a10,_0x22224a['path']);let _0x1bfdf1=N(_0x4f3a10);typeof _0x4f3a10=='object'&&_0x4f3a10!=null&&Y(_0x4f3a10,'.priority')||(_0x1bfdf1=_0x1bfdf1['updatePriority'](_0x12d6a9['getPriority']()));const _0x94850b=_0x22224a['currentWriteId'],_0x3fedcd=jt(_0x255018),_0x517d94=hs(_0x1bfdf1,_0x12d6a9,_0x3fedcd);_0x22224a['currentOutputSnapshotRaw']=_0x1bfdf1,_0x22224a['currentOutputSnapshotResolved']=_0x517d94,_0x22224a['currentWriteId']=Vn(_0x255018),_0x21bb99['splice'](_0x21bb99['indexOf'](_0x94850b),0x1),_0x2e3285=_0x2e3285['concat'](ss(_0x255018['serverSyncTree_'],_0x22224a['path'],_0x517d94,_0x22224a['currentWriteId'],_0x22224a['applyLocally'])),_0x2e3285=_0x2e3285['concat'](pe(_0x255018['serverSyncTree_'],_0x94850b,!0x0));}else _0x156181=!0x0,_0x8f9583='nodata',_0x2e3285=_0x2e3285['concat'](pe(_0x255018['serverSyncTree_'],_0x22224a['currentWriteId'],!0x0));}}}V(_0x255018['eventQueue_'],_0x19bf97,_0x2e3285),_0x2e3285=[],_0x156181&&(_0x9ab2a1[_0x3eaa62]['status']=0x2,function(_0x543aa7){setTimeout(_0x543aa7,Math['floor'](0x0));}(_0x9ab2a1[_0x3eaa62]['unwatcher']),_0x9ab2a1[_0x3eaa62]['onComplete']&&(_0x8f9583==='nodata'?_0xecb6f7['push'](()=>_0x9ab2a1[_0x3eaa62]['onComplete'](null,!0x1,_0x9ab2a1[_0x3eaa62]['currentInputSnapshot'])):_0xecb6f7['push'](()=>_0x9ab2a1[_0x3eaa62]['onComplete'](new Error(_0x8f9583),!0x1,null))));}$n(_0x255018,_0x255018['transactionQueueTree_']);for(let _0x37d089=0x0;_0x37d089<_0xecb6f7['length'];_0x37d089++)lt(_0xecb6f7[_0x37d089]);Hn(_0x255018,_0x255018['transactionQueueTree_']);}function ca(_0x58d6ae,_0x436547){let _0x50a48b,_0x133a30=_0x58d6ae['transactionQueueTree_'];for(_0x50a48b=y(_0x436547);_0x50a48b!==null&&Ge(_0x133a30)===void 0x0;)_0x133a30=Un(_0x133a30,_0x50a48b),_0x436547=b(_0x436547),_0x50a48b=y(_0x436547);return _0x133a30;}function la(_0x1dbf83,_0x2d08cc){const _0x44dacb=[];return ha(_0x1dbf83,_0x2d08cc,_0x44dacb),_0x44dacb['sort']((_0xa94f13,_0x3e7605)=>_0xa94f13['order']-_0x3e7605['order']),_0x44dacb;}function ha(_0x2241c0,_0x2a91e4,_0x39ef92){const _0x17e0e3=Ge(_0x2a91e4);if(_0x17e0e3){for(let _0x31c01d=0x0;_0x31c01d<_0x17e0e3['length'];_0x31c01d++)_0x39ef92['push'](_0x17e0e3[_0x31c01d]);}Wn(_0x2a91e4,_0x3c1bb3=>{ha(_0x2241c0,_0x3c1bb3,_0x39ef92);});}function $n(_0x34ded1,_0x1acace){const _0x26675a=Ge(_0x1acace);if(_0x26675a){let _0x3d5daf=0x0;for(let _0xbafcda=0x0;_0xbafcda<_0x26675a['length'];_0xbafcda++)_0x26675a[_0xbafcda]['status']!==0x2&&(_0x26675a[_0x3d5daf]=_0x26675a[_0xbafcda],_0x3d5daf++);_0x26675a['length']=_0x3d5daf,fs(_0x1acace,_0x26675a['length']>0x0?_0x26675a:void 0x0);}Wn(_0x1acace,_0x477589=>{$n(_0x34ded1,_0x477589);});}function vs(_0x3a8bfd,_0x1afa55){const _0x70cacd=Gt(ca(_0x3a8bfd,_0x1afa55)),_0x448f0b=Un(_0x3a8bfd['transactionQueueTree_'],_0x1afa55);return sd(_0x448f0b,_0x803f7e=>{ai(_0x3a8bfd,_0x803f7e);}),ai(_0x3a8bfd,_0x448f0b),ta(_0x448f0b,_0x44bd5e=>{ai(_0x3a8bfd,_0x44bd5e);}),_0x70cacd;}function ai(_0x29992e,_0x174664){const _0x475682=Ge(_0x174664);if(_0x475682){const _0x26f572=[];let _0x25a366=[],_0x3ee0c9=-0x1;for(let _0x13bbd2=0x0;_0x13bbd2<_0x475682['length'];_0x13bbd2++)_0x475682[_0x13bbd2]['status']===0x3||(_0x475682[_0x13bbd2]['status']===0x1?(f(_0x3ee0c9===_0x13bbd2-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3ee0c9=_0x13bbd2,_0x475682[_0x13bbd2]['status']=0x3,_0x475682[_0x13bbd2]['abortReason']='set'):(f(_0x475682[_0x13bbd2]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x475682[_0x13bbd2]['unwatcher'](),_0x25a366=_0x25a366['concat'](pe(_0x29992e['serverSyncTree_'],_0x475682[_0x13bbd2]['currentWriteId'],!0x0)),_0x475682[_0x13bbd2]['onComplete']&&_0x26f572['push'](_0x475682[_0x13bbd2]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3ee0c9===-0x1?fs(_0x174664,void 0x0):_0x475682['length']=_0x3ee0c9+0x1,V(_0x29992e['eventQueue_'],Gt(_0x174664),_0x25a366);for(let _0x2f0be1=0x0;_0x2f0be1<_0x26f572['length'];_0x2f0be1++)lt(_0x26f572[_0x2f0be1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x25009d){let _0x244eaf='';const _0x255d7b=_0x25009d['split']('/');for(let _0x3c2073=0x0;_0x3c2073<_0x255d7b['length'];_0x3c2073++)if(_0x255d7b[_0x3c2073]['length']>0x0){let _0x516082=_0x255d7b[_0x3c2073];try{_0x516082=decodeURIComponent(_0x516082['replace'](/\+/g,'\x20'));}catch{}_0x244eaf+='/'+_0x516082;}return _0x244eaf;}function Nd(_0x5aaef5){const _0x52e5f4={};_0x5aaef5['charAt'](0x0)==='?'&&(_0x5aaef5=_0x5aaef5['substring'](0x1));for(const _0x891842 of _0x5aaef5['split']('&')){if(_0x891842['length']===0x0)continue;const _0x54ff0c=_0x891842['split']('=');_0x54ff0c['length']===0x2?_0x52e5f4[decodeURIComponent(_0x54ff0c[0x0])]=decodeURIComponent(_0x54ff0c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x891842+'\x27\x20in\x20query\x20\x27'+_0x5aaef5+'\x27');}return _0x52e5f4;}const gr=function(_0x2dc679,_0x1b6daf){const _0x409660=Pd(_0x2dc679),_0xae0911=_0x409660['namespace'];_0x409660['domain']==='firebase.com'&&oe(_0x409660['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xae0911||_0xae0911==='undefined')&&_0x409660['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x409660['secure']||Bl();const _0x13b182=_0x409660['scheme']==='ws'||_0x409660['scheme']==='wss';return{'repoInfo':new _o(_0x409660['host'],_0x409660['secure'],_0xae0911,_0x13b182,_0x1b6daf,'',_0xae0911!==_0x409660['subdomain']),'path':new C(_0x409660['pathString'])};},Pd=function(_0xc5da88){let _0x1264bc='',_0x277cd9='',_0x251de1='',_0x57ad50='',_0x4e9874='',_0x4ec328=!0x0,_0x2a2cbf='https',_0xa30d99=0x1bb;if(typeof _0xc5da88=='string'){let _0x2f1d21=_0xc5da88['indexOf']('//');_0x2f1d21>=0x0&&(_0x2a2cbf=_0xc5da88['substring'](0x0,_0x2f1d21-0x1),_0xc5da88=_0xc5da88['substring'](_0x2f1d21+0x2));let _0x2893fc=_0xc5da88['indexOf']('/');_0x2893fc===-0x1&&(_0x2893fc=_0xc5da88['length']);let _0x372f68=_0xc5da88['indexOf']('?');_0x372f68===-0x1&&(_0x372f68=_0xc5da88['length']),_0x1264bc=_0xc5da88['substring'](0x0,Math['min'](_0x2893fc,_0x372f68)),_0x2893fc<_0x372f68&&(_0x57ad50=kd(_0xc5da88['substring'](_0x2893fc,_0x372f68)));const _0x2ce8a1=Nd(_0xc5da88['substring'](Math['min'](_0xc5da88['length'],_0x372f68)));_0x2f1d21=_0x1264bc['indexOf'](':'),_0x2f1d21>=0x0?(_0x4ec328=_0x2a2cbf==='https'||_0x2a2cbf==='wss',_0xa30d99=parseInt(_0x1264bc['substring'](_0x2f1d21+0x1),0xa)):_0x2f1d21=_0x1264bc['length'];const _0x50c20f=_0x1264bc['slice'](0x0,_0x2f1d21);if(_0x50c20f['toLowerCase']()==='localhost')_0x277cd9='localhost';else{if(_0x50c20f['split']('.')['length']<=0x2)_0x277cd9=_0x50c20f;else{const _0xdc820=_0x1264bc['indexOf']('.');_0x251de1=_0x1264bc['substring'](0x0,_0xdc820)['toLowerCase'](),_0x277cd9=_0x1264bc['substring'](_0xdc820+0x1),_0x4e9874=_0x251de1;}}'ns'in _0x2ce8a1&&(_0x4e9874=_0x2ce8a1['ns']);}return{'host':_0x1264bc,'port':_0xa30d99,'domain':_0x277cd9,'subdomain':_0x251de1,'secure':_0x4ec328,'scheme':_0x2a2cbf,'pathString':_0x57ad50,'namespace':_0x4e9874};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x14d00c=0x0;const _0x2ce468=[];return function(_0x13312d){const _0x288b0f=_0x13312d===_0x14d00c;_0x14d00c=_0x13312d;let _0x2c2692;const _0x5aa65f=new Array(0x8);for(_0x2c2692=0x7;_0x2c2692>=0x0;_0x2c2692--)_0x5aa65f[_0x2c2692]=mr['charAt'](_0x13312d%0x40),_0x13312d=Math['floor'](_0x13312d/0x40);f(_0x13312d===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x40a866=_0x5aa65f['join']('');if(_0x288b0f){for(_0x2c2692=0xb;_0x2c2692>=0x0&&_0x2ce468[_0x2c2692]===0x3f;_0x2c2692--)_0x2ce468[_0x2c2692]=0x0;_0x2ce468[_0x2c2692]++;}else{for(_0x2c2692=0x0;_0x2c2692<0xc;_0x2c2692++)_0x2ce468[_0x2c2692]=Math['floor'](Math['random']()*0x40);}for(_0x2c2692=0x0;_0x2c2692<0xc;_0x2c2692++)_0x40a866+=mr['charAt'](_0x2ce468[_0x2c2692]);return f(_0x40a866['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x40a866;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x5e38c2,_0x3649cf,_0xd7e89f,_0xecb868){this['eventType']=_0x5e38c2,this['eventRegistration']=_0x3649cf,this['snapshot']=_0xd7e89f,this['prevName']=_0xecb868;}['getPath'](){const _0x45c379=this['snapshot']['ref'];return this['eventType']==='value'?_0x45c379['_path']:_0x45c379['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x579751,_0x3fa1f8,_0x58149f){this['eventRegistration']=_0x579751,this['error']=_0x3fa1f8,this['path']=_0x58149f;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x30537d,_0x22da8b){this['snapshotCallback']=_0x30537d,this['cancelCallback']=_0x22da8b;}['onValue'](_0x3524e6,_0x4e8269){this['snapshotCallback']['call'](null,_0x3524e6,_0x4e8269);}['onCancel'](_0x3445ed){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3445ed);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4542f3){return this['snapshotCallback']===_0x4542f3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4542f3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4542f3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x1e4e98,_0x71710b,_0x3b703e,_0x4a7a9e){this['_repo']=_0x1e4e98,this['_path']=_0x71710b,this['_queryParams']=_0x3b703e,this['_orderByCalled']=_0x4a7a9e;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1c8df2=nr(this['_queryParams']),_0x209f17=Bi(_0x1c8df2);return _0x209f17==='{}'?'default':_0x209f17;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x30812d){if(_0x30812d=k(_0x30812d),!(_0x30812d instanceof be))return!0x1;const _0x856c4a=this['_repo']===_0x30812d['_repo'],_0x3169b8=qi(this['_path'],_0x30812d['_path']),_0x303104=this['_queryIdentifier']===_0x30812d['_queryIdentifier'];return _0x856c4a&&_0x3169b8&&_0x303104;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x103098,_0x594224){if(_0x103098['_orderByCalled']===!0x0)throw new Error(_0x594224+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3ebbe4){let _0x514f31=null,_0x5cc96c=null;if(_0x3ebbe4['hasStart']()&&(_0x514f31=_0x3ebbe4['getIndexStartValue']()),_0x3ebbe4['hasEnd']()&&(_0x5cc96c=_0x3ebbe4['getIndexEndValue']()),_0x3ebbe4['getIndex']()===ye){const _0x596f8b='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x12ac05='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3ebbe4['hasStart']()){if(_0x3ebbe4['getIndexStartName']()!==xe)throw new Error(_0x596f8b);if(typeof _0x514f31!='string')throw new Error(_0x12ac05);}if(_0x3ebbe4['hasEnd']()){if(_0x3ebbe4['getIndexEndName']()!==Ie)throw new Error(_0x596f8b);if(typeof _0x5cc96c!='string')throw new Error(_0x12ac05);}}else{if(_0x3ebbe4['getIndex']()===R){if(_0x514f31!=null&&!Cn(_0x514f31)||_0x5cc96c!=null&&!Cn(_0x5cc96c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3ebbe4['getIndex']()instanceof Ki||_0x3ebbe4['getIndex']()===Po,'unknown\x20index\x20type.'),_0x514f31!=null&&typeof _0x514f31=='object'||_0x5cc96c!=null&&typeof _0x5cc96c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x500899){if(_0x500899['hasStart']()&&_0x500899['hasEnd']()&&_0x500899['hasLimit']()&&!_0x500899['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x594902,_0x254a6){super(_0x594902,_0x254a6,new Qi(),!0x1);}get['parent'](){const _0x26bbb7=To(this['_path']);return _0x26bbb7===null?null:new Z(this['_repo'],_0x26bbb7);}get['root'](){let _0x237850=this;for(;_0x237850['parent']!==null;)_0x237850=_0x237850['parent'];return _0x237850;}}class rt{constructor(_0x528cd6,_0x1fd12e,_0x33650c){this['_node']=_0x528cd6,this['ref']=_0x1fd12e,this['_index']=_0x33650c;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4b53f2){const _0x746dab=new C(_0x4b53f2),_0x5bcef0=Lt(this['ref'],_0x4b53f2);return new rt(this['_node']['getChild'](_0x746dab),_0x5bcef0,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4f8032){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x15081b,_0x53d260)=>_0x4f8032(new rt(_0x53d260,Lt(this['ref'],_0x15081b),R)));}['hasChild'](_0x1a59f6){const _0x161bf8=new C(_0x1a59f6);return!this['_node']['getChild'](_0x161bf8)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x42a2ae,_0x46145f){return _0x42a2ae=k(_0x42a2ae),_0x42a2ae['_checkNotDeleted']('ref'),_0x46145f!==void 0x0?Lt(_0x42a2ae['_root'],_0x46145f):_0x42a2ae['_root'];}function Lt(_0x38810f,_0x22117a){return _0x38810f=k(_0x38810f),y(_0x38810f['_path'])===null?ud('child','path',_0x22117a):_s('child','path',_0x22117a),new Z(_0x38810f['_repo'],A(_0x38810f['_path'],_0x22117a));}function d_(_0x4a788f,_0x544baa){_0x4a788f=k(_0x4a788f),gs('push',_0x4a788f['_path']),qt('push',_0x544baa,_0x4a788f['_path'],!0x0);const _0xfae92d=oa(_0x4a788f['_repo']),_0x5bcb15=Od(_0xfae92d),_0x2d08cb=Lt(_0x4a788f,_0x5bcb15),_0x23fd2e=Lt(_0x4a788f,_0x5bcb15);let _0x4bed5a;return _0x544baa!=null?_0x4bed5a=Ld(_0x23fd2e,_0x544baa)['then'](()=>_0x23fd2e):_0x4bed5a=Promise['resolve'](_0x23fd2e),_0x2d08cb['then']=_0x4bed5a['then']['bind'](_0x4bed5a),_0x2d08cb['catch']=_0x4bed5a['then']['bind'](_0x4bed5a,void 0x0),_0x2d08cb;}function Ld(_0x539438,_0x3988d6){_0x539438=k(_0x539438),gs('set',_0x539438['_path']),qt('set',_0x3988d6,_0x539438['_path'],!0x1);const _0x44f14b=new Ve();return Ed(_0x539438['_repo'],_0x539438['_path'],_0x3988d6,null,_0x44f14b['wrapCallback'](()=>{})),_0x44f14b['promise'];}function f_(_0x125edc,_0x33eda7){hd('update',_0x33eda7,_0x125edc['_path']);const _0x22a5c3=new Ve();return Id(_0x125edc['_repo'],_0x125edc['_path'],_0x33eda7,_0x22a5c3['wrapCallback'](()=>{})),_0x22a5c3['promise'];}function p_(_0x27a188){_0x27a188=k(_0x27a188);const _0x44ef60=new ua(()=>{}),_0x5df4d2=new qn(_0x44ef60);return vd(_0x27a188['_repo'],_0x27a188,_0x5df4d2)['then'](_0x12a6ce=>new rt(_0x12a6ce,new Z(_0x27a188['_repo'],_0x27a188['_path']),_0x27a188['_queryParams']['getIndex']()));}class qn{constructor(_0x395525){this['callbackContext']=_0x395525;}['respondsTo'](_0x470c6f){return _0x470c6f==='value';}['createEvent'](_0x1fde13,_0x4c2a79){const _0x42f84e=_0x4c2a79['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x1fde13['snapshotNode'],new Z(_0x4c2a79['_repo'],_0x4c2a79['_path']),_0x42f84e));}['getEventRunner'](_0x414930){return _0x414930['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x414930['error']):()=>this['callbackContext']['onValue'](_0x414930['snapshot'],null);}['createCancelEvent'](_0xab06fa,_0x6b6fee){return this['callbackContext']['hasCancelCallback']?new Md(this,_0xab06fa,_0x6b6fee):null;}['matches'](_0x6e2ea7){return _0x6e2ea7 instanceof qn?!_0x6e2ea7['callbackContext']||!this['callbackContext']?!0x0:_0x6e2ea7['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x23a6a4,_0x12af12,_0x350c0a,_0x5b6036,_0x517636){const _0x4aa6e5=new ua(_0x350c0a,void 0x0),_0x4ff226=new qn(_0x4aa6e5);return Cd(_0x23a6a4['_repo'],_0x23a6a4,_0x4ff226),()=>Td(_0x23a6a4['_repo'],_0x23a6a4,_0x4ff226);}function Fd(_0x1bf8da,_0x32f18c,_0x19c2ed,_0x3e740a){return xd(_0x1bf8da,'value',_0x32f18c);}class dt{}class pa extends dt{constructor(_0x25c120,_0x5f808d){super(),this['_value']=_0x25c120,this['_key']=_0x5f808d,this['type']='endAt';}['_apply'](_0x2173da){qt('endAt',this['_value'],_0x2173da['_path'],!0x0);const _0x379392=Kh(_0x2173da['_queryParams'],this['_value'],this['_key']);if(fa(_0x379392),Gn(_0x379392),_0x2173da['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2173da['_repo'],_0x2173da['_path'],_0x379392,_0x2173da['_orderByCalled']);}}function __(_0x393073,_0x2b58fd){return new pa(_0x393073,_0x2b58fd);}class _a extends dt{constructor(_0x9f776f,_0x235f5f){super(),this['_value']=_0x9f776f,this['_key']=_0x235f5f,this['type']='startAt';}['_apply'](_0x2e298b){qt('startAt',this['_value'],_0x2e298b['_path'],!0x0);const _0xc39812=jh(_0x2e298b['_queryParams'],this['_value'],this['_key']);if(fa(_0xc39812),Gn(_0xc39812),_0x2e298b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2e298b['_repo'],_0x2e298b['_path'],_0xc39812,_0x2e298b['_orderByCalled']);}}function g_(_0x3ed2b8=null,_0x585925){return new _a(_0x3ed2b8,_0x585925);}class Ud extends dt{constructor(_0x50fe1d){super(),this['_limit']=_0x50fe1d,this['type']='limitToFirst';}['_apply'](_0x1e1114){if(_0x1e1114['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1e1114['_repo'],_0x1e1114['_path'],zh(_0x1e1114['_queryParams'],this['_limit']),_0x1e1114['_orderByCalled']);}}function m_(_0x2a6331){if(Math['floor'](_0x2a6331)!==_0x2a6331||_0x2a6331<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x2a6331);}class Wd extends dt{constructor(_0x4e3fb0){super(),this['_path']=_0x4e3fb0,this['type']='orderByChild';}['_apply'](_0x219c03){da(_0x219c03,'orderByChild');const _0x3891ee=new C(this['_path']);if(v(_0x3891ee))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x47bc30=new Ki(_0x3891ee),_0x482dfa=Do(_0x219c03['_queryParams'],_0x47bc30);return Gn(_0x482dfa),new be(_0x219c03['_repo'],_0x219c03['_path'],_0x482dfa,!0x0);}}function y_(_0x7bcc71){if(_0x7bcc71==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x7bcc71==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x7bcc71==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x7bcc71),new Wd(_0x7bcc71);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5c7a78){da(_0x5c7a78,'orderByKey');const _0x44c7b8=Do(_0x5c7a78['_queryParams'],ye);return Gn(_0x44c7b8),new be(_0x5c7a78['_repo'],_0x5c7a78['_path'],_0x44c7b8,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x21cad7,_0x21735e){super(),this['_value']=_0x21cad7,this['_key']=_0x21735e,this['type']='equalTo';}['_apply'](_0x2a14d1){if(qt('equalTo',this['_value'],_0x2a14d1['_path'],!0x1),_0x2a14d1['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2a14d1['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2a14d1));}}function E_(_0x3d7120,_0x5cd91e){return new Vd(_0x3d7120,_0x5cd91e);}function I_(_0x8d5a2e,..._0x29c4c1){let _0xa5efe9=k(_0x8d5a2e);for(const _0x4c63f of _0x29c4c1)_0xa5efe9=_0x4c63f['_apply'](_0xa5efe9);return _0xa5efe9;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x493f57,_0x3d3a0b,_0x130859,_0xc4aaae){const _0x4a552d=_0x3d3a0b['lastIndexOf'](':'),_0x4b41e7=_0x3d3a0b['substring'](0x0,_0x4a552d),_0x220532=Wt(_0x4b41e7);_0x493f57['repoInfo_']=new _o(_0x3d3a0b,_0x220532,_0x493f57['repoInfo_']['namespace'],_0x493f57['repoInfo_']['webSocketOnly'],_0x493f57['repoInfo_']['nodeAdmin'],_0x493f57['repoInfo_']['persistenceKey'],_0x493f57['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x130859),_0xc4aaae&&(_0x493f57['authTokenProvider_']=_0xc4aaae);}function qd(_0x3ca68c,_0x24d99a,_0x5bf8f4,_0x51e22d,_0x426ab0){let _0x28000b=_0x51e22d||_0x3ca68c['options']['databaseURL'];_0x28000b===void 0x0&&(_0x3ca68c['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3ca68c['options']['projectId']),_0x28000b=_0x3ca68c['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x562955=gr(_0x28000b,_0x426ab0),_0x26d41c=_0x562955['repoInfo'],_0x2cf364;typeof process<'u'&&Us&&(_0x2cf364=Us[Hd]),_0x2cf364?(_0x28000b='http://'+_0x2cf364+'?ns='+_0x26d41c['namespace'],_0x562955=gr(_0x28000b,_0x426ab0),_0x26d41c=_0x562955['repoInfo']):_0x562955['repoInfo']['secure'];const _0x2c8f3d=new Jl(_0x3ca68c['name'],_0x3ca68c['options'],_0x24d99a);dd('Invalid\x20Firebase\x20Database\x20URL',_0x562955),v(_0x562955['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x30a71b=jd(_0x26d41c,_0x3ca68c,_0x2c8f3d,new Ql(_0x3ca68c,_0x5bf8f4));return new Kd(_0x30a71b,_0x3ca68c);}function zd(_0x4458fb,_0x43527a){const _0x334ff4=ki[_0x43527a];(!_0x334ff4||_0x334ff4[_0x4458fb['key']]!==_0x4458fb)&&oe('Database\x20'+_0x43527a+'('+_0x4458fb['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4458fb),delete _0x334ff4[_0x4458fb['key']];}function jd(_0x606ca,_0x5c8d44,_0x54e93b,_0x401507){let _0x1a17a2=ki[_0x5c8d44['name']];_0x1a17a2||(_0x1a17a2={},ki[_0x5c8d44['name']]=_0x1a17a2);let _0x530eb7=_0x1a17a2[_0x606ca['toURLString']()];return _0x530eb7&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x530eb7=new gd(_0x606ca,$d,_0x54e93b,_0x401507),_0x1a17a2[_0x606ca['toURLString']()]=_0x530eb7,_0x530eb7;}class Kd{constructor(_0x4a8922,_0x5ce1f8){this['_repoInternal']=_0x4a8922,this['app']=_0x5ce1f8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4880a3){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x4880a3+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x363bdc=Qr(),_0x9fd9ca){const _0x245d69=Ui(_0x363bdc,'database')['getImmediate']({'identifier':_0x9fd9ca});if(!_0x245d69['_instanceStarted']){const _0xeaa17f=ac('database');_0xeaa17f&&Yd(_0x245d69,..._0xeaa17f);}return _0x245d69;}function Yd(_0x585f6e,_0x241181,_0x18ce3c,_0x322c30={}){_0x585f6e=k(_0x585f6e),_0x585f6e['_checkNotDeleted']('useEmulator');const _0x1cdd3d=_0x241181+':'+_0x18ce3c,_0x31cbf6=_0x585f6e['_repoInternal'];if(_0x585f6e['_instanceStarted']){if(_0x1cdd3d===_0x585f6e['_repoInternal']['repoInfo_']['host']&&De(_0x322c30,_0x31cbf6['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1529d7;if(_0x31cbf6['repoInfo_']['nodeAdmin'])_0x322c30['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1529d7=new tn(tn['OWNER']);else{if(_0x322c30['mockUserToken']){const _0x293590=typeof _0x322c30['mockUserToken']=='string'?_0x322c30['mockUserToken']:cc(_0x322c30['mockUserToken'],_0x585f6e['app']['options']['projectId']);_0x1529d7=new tn(_0x293590);}}Wt(_0x241181)&&jr(_0x241181),Gd(_0x31cbf6,_0x1cdd3d,_0x322c30,_0x1529d7);}function C_(_0x3b965c){_0x3b965c=k(_0x3b965c),_0x3b965c['_checkNotDeleted']('goOffline'),aa(_0x3b965c['_repo']);}function T_(_0x5b9f37){_0x5b9f37=k(_0x5b9f37),_0x5b9f37['_checkNotDeleted']('goOnline'),Sd(_0x5b9f37['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x134b07){Ll(ct),et(new Me('database',(_0x59fc29,{instanceIdentifier:_0x5db6be})=>{const _0x8452b4=_0x59fc29['getProvider']('app')['getImmediate'](),_0x4ae8a7=_0x59fc29['getProvider']('auth-internal'),_0x595236=_0x59fc29['getProvider']('app-check-internal');return qd(_0x8452b4,_0x4ae8a7,_0x595236,_0x5db6be);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x134b07),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x42a06a,_0x1e419f){this['committed']=_0x42a06a,this['snapshot']=_0x1e419f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x545ede,_0x459c6a,_0x5455ad){if(_0x545ede=k(_0x545ede),gs('Reference.transaction',_0x545ede['_path']),_0x545ede['key']==='.length'||_0x545ede['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x545ede['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5a984c=!0x0,_0x5539a3=new Ve(),_0x5016dd=(_0x231f52,_0x508146,_0x4e0772)=>{let _0x3d6f85=null;_0x231f52?_0x5539a3['reject'](_0x231f52):(_0x3d6f85=new rt(_0x4e0772,new Z(_0x545ede['_repo'],_0x545ede['_path']),R),_0x5539a3['resolve'](new Xd(_0x508146,_0x3d6f85)));},_0x5bf9d8=Fd(_0x545ede,()=>{});return bd(_0x545ede['_repo'],_0x545ede['_path'],_0x459c6a,_0x5016dd,_0x5bf9d8,_0x5a984c),_0x5539a3['promise'];}ie['prototype']['simpleListen']=function(_0x386cee,_0x1a14e8){this['sendRequest']('q',{'p':_0x386cee},_0x1a14e8);},ie['prototype']['echo']=function(_0x4e411b,_0x3d4ffe){this['sendRequest']('echo',{'d':_0x4e411b},_0x3d4ffe);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x5b98ae,..._0x2cfe2f){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x5b98ae,..._0x2cfe2f);}function nn(_0x5f5317,..._0xee2669){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x5f5317,..._0xee2669);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x434aba,..._0x2b58dc){throw Es(_0x434aba,..._0x2b58dc);}function J(_0x4946a5,..._0x257d5e){return Es(_0x4946a5,..._0x257d5e);}function ya(_0x582707,_0x5c607e,_0x4feb88){const _0x40939e={...Zd(),[_0x5c607e]:_0x4feb88};return new Ut('auth','Firebase',_0x40939e)['create'](_0x5c607e,{'appName':_0x582707['name']});}function se(_0x2bfd17){return ya(_0x2bfd17,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x3b602b,..._0x37d1e0){if(typeof _0x3b602b!='string'){const _0x2bdad0=_0x37d1e0[0x0],_0x691558=[..._0x37d1e0['slice'](0x1)];return _0x691558[0x0]&&(_0x691558[0x0]['appName']=_0x3b602b['name']),_0x3b602b['_errorFactory']['create'](_0x2bdad0,..._0x691558);}return ma['create'](_0x3b602b,..._0x37d1e0);}function m(_0x268b2e,_0x2a7b25,..._0x5ab54b){if(!_0x268b2e)throw Es(_0x2a7b25,..._0x5ab54b);}function te(_0x1c60ac){const _0x508275='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1c60ac;throw nn(_0x508275),new Error(_0x508275);}function ae(_0x4143a6,_0x759c7c){_0x4143a6||te(_0x759c7c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x8c53fa;return typeof self<'u'&&((_0x8c53fa=self['location'])==null?void 0x0:_0x8c53fa['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4598cb;return typeof self<'u'&&((_0x4598cb=self['location'])==null?void 0x0:_0x4598cb['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x34538c=navigator;return _0x34538c['languages']&&_0x34538c['languages'][0x0]||_0x34538c['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x31f659,_0x286ebe){this['shortDelay']=_0x31f659,this['longDelay']=_0x286ebe,ae(_0x286ebe>_0x31f659,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x583fce,_0x229abf){ae(_0x583fce['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x514ae3}=_0x583fce['emulator'];return _0x229abf?''+_0x514ae3+(_0x229abf['startsWith']('/')?_0x229abf['slice'](0x1):_0x229abf):_0x514ae3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5cbbd8,_0x42aa4a,_0x5a3ea0){this['fetchImpl']=_0x5cbbd8,_0x42aa4a&&(this['headersImpl']=_0x42aa4a),_0x5a3ea0&&(this['responseImpl']=_0x5a3ea0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x22f202,_0x39edd4){return _0x22f202['tenantId']&&!_0x39edd4['tenantId']?{..._0x39edd4,'tenantId':_0x22f202['tenantId']}:_0x39edd4;}async function Ae(_0x372d58,_0x2a3cc7,_0x52af54,_0x19d7fd,_0x327641={}){return Ea(_0x372d58,_0x327641,async()=>{let _0x4a9c0a={},_0xe01890={};_0x19d7fd&&(_0x2a3cc7==='GET'?_0xe01890=_0x19d7fd:_0x4a9c0a={'body':JSON['stringify'](_0x19d7fd)});const _0x24b846=at({..._0xe01890,'key':_0x372d58['config']['apiKey']})['slice'](0x1),_0x5e13c5=await _0x372d58['_getAdditionalHeaders']();_0x5e13c5['Content-Type']='application/json',_0x372d58['languageCode']&&(_0x5e13c5['X-Firebase-Locale']=_0x372d58['languageCode']);const _0xff5318={'method':_0x2a3cc7,'headers':_0x5e13c5,..._0x4a9c0a};return lc()||(_0xff5318['referrerPolicy']='strict-origin-when-cross-origin'),_0x372d58['emulatorConfig']&&Wt(_0x372d58['emulatorConfig']['host'])&&(_0xff5318['credentials']='include'),va['fetch']()(await Ia(_0x372d58,_0x372d58['config']['apiHost'],_0x52af54,_0x24b846),_0xff5318);});}async function Ea(_0x336b5e,_0x481571,_0x39cd04){_0x336b5e['_canInitEmulator']=!0x1;const _0x44d245={...rf,..._0x481571};try{const _0x5888b4=new lf(_0x336b5e),_0x767105=await Promise['race']([_0x39cd04(),_0x5888b4['promise']]);_0x5888b4['clearNetworkTimeout']();const _0x5bb59f=await _0x767105['json']();if('needConfirmation'in _0x5bb59f)throw en(_0x336b5e,'account-exists-with-different-credential',_0x5bb59f);if(_0x767105['ok']&&!('errorMessage'in _0x5bb59f))return _0x5bb59f;{const _0x459f92=_0x767105['ok']?_0x5bb59f['errorMessage']:_0x5bb59f['error']['message'],[_0x35422e,_0x47dfdc]=_0x459f92['split']('\x20:\x20');if(_0x35422e==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x336b5e,'credential-already-in-use',_0x5bb59f);if(_0x35422e==='EMAIL_EXISTS')throw en(_0x336b5e,'email-already-in-use',_0x5bb59f);if(_0x35422e==='USER_DISABLED')throw en(_0x336b5e,'user-disabled',_0x5bb59f);const _0x1e14aa=_0x44d245[_0x35422e]||_0x35422e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x47dfdc)throw ya(_0x336b5e,_0x1e14aa,_0x47dfdc);K(_0x336b5e,_0x1e14aa);}}catch(_0x56415e){if(_0x56415e instanceof Se)throw _0x56415e;K(_0x336b5e,'network-request-failed',{'message':String(_0x56415e)});}}async function Yt(_0x419505,_0x3afa08,_0x117880,_0x45535e,_0x448ffc={}){const _0x5e77ce=await Ae(_0x419505,_0x3afa08,_0x117880,_0x45535e,_0x448ffc);return'mfaPendingCredential'in _0x5e77ce&&K(_0x419505,'multi-factor-auth-required',{'_serverResponse':_0x5e77ce}),_0x5e77ce;}async function Ia(_0xbacf7b,_0x380a14,_0x221e48,_0x409b6b){const _0xe58228=''+_0x380a14+_0x221e48+'?'+_0x409b6b,_0x3f854f=_0xbacf7b,_0x1a78e1=_0x3f854f['config']['emulator']?Is(_0xbacf7b['config'],_0xe58228):_0xbacf7b['config']['apiScheme']+'://'+_0xe58228;return of['includes'](_0x221e48)&&(await _0x3f854f['_persistenceManagerAvailable'],_0x3f854f['_getPersistenceType']()==='COOKIE')?_0x3f854f['_getPersistence']()['_getFinalTarget'](_0x1a78e1)['toString']():_0x1a78e1;}function cf(_0x37b152){switch(_0x37b152){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4b0236){this['auth']=_0x4b0236,this['timer']=null,this['promise']=new Promise((_0x46fd4f,_0x33c648)=>{this['timer']=setTimeout(()=>_0x33c648(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1783dd,_0x379cbe,_0x3024ce){const _0xc1302b={'appName':_0x1783dd['name']};_0x3024ce['email']&&(_0xc1302b['email']=_0x3024ce['email']),_0x3024ce['phoneNumber']&&(_0xc1302b['phoneNumber']=_0x3024ce['phoneNumber']);const _0x5661e5=J(_0x1783dd,_0x379cbe,_0xc1302b);return _0x5661e5['customData']['_tokenResponse']=_0x3024ce,_0x5661e5;}function vr(_0x1e4312){return _0x1e4312!==void 0x0&&_0x1e4312['enterprise']!==void 0x0;}class hf{constructor(_0x23e62a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x23e62a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x23e62a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x23e62a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x20c899){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5c7d5a of this['recaptchaEnforcementState'])if(_0x5c7d5a['provider']&&_0x5c7d5a['provider']===_0x20c899)return cf(_0x5c7d5a['enforcementState']);return null;}['isProviderEnabled'](_0x1066db){return this['getProviderEnforcementState'](_0x1066db)==='ENFORCE'||this['getProviderEnforcementState'](_0x1066db)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x4598df,_0x408382){return Ae(_0x4598df,'GET','/v2/recaptchaConfig',Re(_0x4598df,_0x408382));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4f32df,_0xe61238){return Ae(_0x4f32df,'POST','/v1/accounts:delete',_0xe61238);}async function Sn(_0x291472,_0x32d243){return Ae(_0x291472,'POST','/v1/accounts:lookup',_0x32d243);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x2fc8dc){if(_0x2fc8dc)try{const _0x57d40a=new Date(Number(_0x2fc8dc));if(!isNaN(_0x57d40a['getTime']()))return _0x57d40a['toUTCString']();}catch{}}async function ff(_0x12bbcc,_0x5089d0=!0x1){const _0x10a663=k(_0x12bbcc),_0x5edee3=await _0x10a663['getIdToken'](_0x5089d0),_0x3dc28c=ws(_0x5edee3);m(_0x3dc28c&&_0x3dc28c['exp']&&_0x3dc28c['auth_time']&&_0x3dc28c['iat'],_0x10a663['auth'],'internal-error');const _0x4cbe39=typeof _0x3dc28c['firebase']=='object'?_0x3dc28c['firebase']:void 0x0,_0x3fcb12=_0x4cbe39==null?void 0x0:_0x4cbe39['sign_in_provider'];return{'claims':_0x3dc28c,'token':_0x5edee3,'authTime':St(ci(_0x3dc28c['auth_time'])),'issuedAtTime':St(ci(_0x3dc28c['iat'])),'expirationTime':St(ci(_0x3dc28c['exp'])),'signInProvider':_0x3fcb12||null,'signInSecondFactor':(_0x4cbe39==null?void 0x0:_0x4cbe39['sign_in_second_factor'])||null};}function ci(_0x22425a){return Number(_0x22425a)*0x3e8;}function ws(_0x5a755e){const [_0x1a73ff,_0x3cf384,_0x2aedd1]=_0x5a755e['split']('.');if(_0x1a73ff===void 0x0||_0x3cf384===void 0x0||_0x2aedd1===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x201fbc=cn(_0x3cf384);return _0x201fbc?JSON['parse'](_0x201fbc):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x448665){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x448665==null?void 0x0:_0x448665['toString']()),null;}}function Er(_0x5ef1ac){const _0x2eac4b=ws(_0x5ef1ac);return m(_0x2eac4b,'internal-error'),m(typeof _0x2eac4b['exp']<'u','internal-error'),m(typeof _0x2eac4b['iat']<'u','internal-error'),Number(_0x2eac4b['exp'])-Number(_0x2eac4b['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x85de3d,_0x269632,_0x5d67af=!0x1){if(_0x5d67af)return _0x269632;try{return await _0x269632;}catch(_0xcfe0f4){throw _0xcfe0f4 instanceof Se&&pf(_0xcfe0f4)&&_0x85de3d['auth']['currentUser']===_0x85de3d&&await _0x85de3d['auth']['signOut'](),_0xcfe0f4;}}function pf({code:_0x43dd86}){return _0x43dd86==='auth/user-disabled'||_0x43dd86==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x2a68ef){this['user']=_0x2a68ef,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x595698){if(_0x595698){const _0x725722=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x725722;}else{this['errorBackoff']=0x7530;const _0x40cff0=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x40cff0);}}['schedule'](_0x24ca59=!0x1){if(!this['isRunning'])return;const _0x12800d=this['getInterval'](_0x24ca59);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x12800d);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4e9c65){(_0x4e9c65==null?void 0x0:_0x4e9c65['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5dd8be,_0x5936ac){this['createdAt']=_0x5dd8be,this['lastLoginAt']=_0x5936ac,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0xf0f305){this['createdAt']=_0xf0f305['createdAt'],this['lastLoginAt']=_0xf0f305['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x51b7ab){var _0x142e2a;const _0x33c98a=_0x51b7ab['auth'],_0x2d1701=await _0x51b7ab['getIdToken'](),_0x320778=await xt(_0x51b7ab,Sn(_0x33c98a,{'idToken':_0x2d1701}));m(_0x320778==null?void 0x0:_0x320778['users']['length'],_0x33c98a,'internal-error');const _0x27bc5e=_0x320778['users'][0x0];_0x51b7ab['_notifyReloadListener'](_0x27bc5e);const _0x335a03=(_0x142e2a=_0x27bc5e['providerUserInfo'])!=null&&_0x142e2a['length']?wa(_0x27bc5e['providerUserInfo']):[],_0x1ddec6=mf(_0x51b7ab['providerData'],_0x335a03),_0x1da555=_0x51b7ab['isAnonymous'],_0x52ad84=!(_0x51b7ab['email']&&_0x27bc5e['passwordHash'])&&!(_0x1ddec6!=null&&_0x1ddec6['length']),_0x2e3cb7=_0x1da555?_0x52ad84:!0x1,_0x55b405={'uid':_0x27bc5e['localId'],'displayName':_0x27bc5e['displayName']||null,'photoURL':_0x27bc5e['photoUrl']||null,'email':_0x27bc5e['email']||null,'emailVerified':_0x27bc5e['emailVerified']||!0x1,'phoneNumber':_0x27bc5e['phoneNumber']||null,'tenantId':_0x27bc5e['tenantId']||null,'providerData':_0x1ddec6,'metadata':new Pi(_0x27bc5e['createdAt'],_0x27bc5e['lastLoginAt']),'isAnonymous':_0x2e3cb7};Object['assign'](_0x51b7ab,_0x55b405);}async function gf(_0x16133d){const _0x534d32=k(_0x16133d);await bn(_0x534d32),await _0x534d32['auth']['_persistUserIfCurrent'](_0x534d32),_0x534d32['auth']['_notifyListenersIfCurrent'](_0x534d32);}function mf(_0x2580aa,_0x42ed76){return[..._0x2580aa['filter'](_0x8fe0eb=>!_0x42ed76['some'](_0xc33bf5=>_0xc33bf5['providerId']===_0x8fe0eb['providerId'])),..._0x42ed76];}function wa(_0xeb8533){return _0xeb8533['map'](({providerId:_0x45dd10,..._0x4f50b1})=>({'providerId':_0x45dd10,'uid':_0x4f50b1['rawId']||'','displayName':_0x4f50b1['displayName']||null,'email':_0x4f50b1['email']||null,'phoneNumber':_0x4f50b1['phoneNumber']||null,'photoURL':_0x4f50b1['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x35f83b,_0x14497f){const _0x591487=await Ea(_0x35f83b,{},async()=>{const _0xbf68b1=at({'grant_type':'refresh_token','refresh_token':_0x14497f})['slice'](0x1),{tokenApiHost:_0x2ddefc,apiKey:_0x2ff6d5}=_0x35f83b['config'],_0x587dd1=await Ia(_0x35f83b,_0x2ddefc,'/v1/token','key='+_0x2ff6d5),_0x1228e8=await _0x35f83b['_getAdditionalHeaders']();_0x1228e8['Content-Type']='application/x-www-form-urlencoded';const _0x4717df={'method':'POST','headers':_0x1228e8,'body':_0xbf68b1};return _0x35f83b['emulatorConfig']&&Wt(_0x35f83b['emulatorConfig']['host'])&&(_0x4717df['credentials']='include'),va['fetch']()(_0x587dd1,_0x4717df);});return{'accessToken':_0x591487['access_token'],'expiresIn':_0x591487['expires_in'],'refreshToken':_0x591487['refresh_token']};}async function vf(_0x332d69,_0x5f3766){return Ae(_0x332d69,'POST','/v2/accounts:revokeToken',Re(_0x332d69,_0x5f3766));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5eec00){m(_0x5eec00['idToken'],'internal-error'),m(typeof _0x5eec00['idToken']<'u','internal-error'),m(typeof _0x5eec00['refreshToken']<'u','internal-error');const _0x416d00='expiresIn'in _0x5eec00&&typeof _0x5eec00['expiresIn']<'u'?Number(_0x5eec00['expiresIn']):Er(_0x5eec00['idToken']);this['updateTokensAndExpiration'](_0x5eec00['idToken'],_0x5eec00['refreshToken'],_0x416d00);}['updateFromIdToken'](_0x377168){m(_0x377168['length']!==0x0,'internal-error');const _0xd638c9=Er(_0x377168);this['updateTokensAndExpiration'](_0x377168,null,_0xd638c9);}async['getToken'](_0x4f4606,_0x57d5bb=!0x1){return!_0x57d5bb&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4f4606,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4f4606,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x55d199,_0x166411){const {accessToken:_0x21c11d,refreshToken:_0x31715c,expiresIn:_0x192cd2}=await yf(_0x55d199,_0x166411);this['updateTokensAndExpiration'](_0x21c11d,_0x31715c,Number(_0x192cd2));}['updateTokensAndExpiration'](_0x212e17,_0x60c602,_0x4a0b89){this['refreshToken']=_0x60c602||null,this['accessToken']=_0x212e17||null,this['expirationTime']=Date['now']()+_0x4a0b89*0x3e8;}static['fromJSON'](_0x688eb7,_0x1a000a){const {refreshToken:_0x47f9d8,accessToken:_0x4e9e94,expirationTime:_0x1a3270}=_0x1a000a,_0x32aabe=new Je();return _0x47f9d8&&(m(typeof _0x47f9d8=='string','internal-error',{'appName':_0x688eb7}),_0x32aabe['refreshToken']=_0x47f9d8),_0x4e9e94&&(m(typeof _0x4e9e94=='string','internal-error',{'appName':_0x688eb7}),_0x32aabe['accessToken']=_0x4e9e94),_0x1a3270&&(m(typeof _0x1a3270=='number','internal-error',{'appName':_0x688eb7}),_0x32aabe['expirationTime']=_0x1a3270),_0x32aabe;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x312032){this['accessToken']=_0x312032['accessToken'],this['refreshToken']=_0x312032['refreshToken'],this['expirationTime']=_0x312032['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x2746ba,_0xa8addc){m(typeof _0x2746ba=='string'||typeof _0x2746ba>'u','internal-error',{'appName':_0xa8addc});}class z{constructor({uid:_0x340109,auth:_0x1ed189,stsTokenManager:_0x54a6cb,..._0x240adb}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x340109,this['auth']=_0x1ed189,this['stsTokenManager']=_0x54a6cb,this['accessToken']=_0x54a6cb['accessToken'],this['displayName']=_0x240adb['displayName']||null,this['email']=_0x240adb['email']||null,this['emailVerified']=_0x240adb['emailVerified']||!0x1,this['phoneNumber']=_0x240adb['phoneNumber']||null,this['photoURL']=_0x240adb['photoURL']||null,this['isAnonymous']=_0x240adb['isAnonymous']||!0x1,this['tenantId']=_0x240adb['tenantId']||null,this['providerData']=_0x240adb['providerData']?[..._0x240adb['providerData']]:[],this['metadata']=new Pi(_0x240adb['createdAt']||void 0x0,_0x240adb['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2a6e61){const _0x41e363=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x2a6e61));return m(_0x41e363,this['auth'],'internal-error'),this['accessToken']!==_0x41e363&&(this['accessToken']=_0x41e363,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x41e363;}['getIdTokenResult'](_0x48a636){return ff(this,_0x48a636);}['reload'](){return gf(this);}['_assign'](_0xd15119){this!==_0xd15119&&(m(this['uid']===_0xd15119['uid'],this['auth'],'internal-error'),this['displayName']=_0xd15119['displayName'],this['photoURL']=_0xd15119['photoURL'],this['email']=_0xd15119['email'],this['emailVerified']=_0xd15119['emailVerified'],this['phoneNumber']=_0xd15119['phoneNumber'],this['isAnonymous']=_0xd15119['isAnonymous'],this['tenantId']=_0xd15119['tenantId'],this['providerData']=_0xd15119['providerData']['map'](_0x481fea=>({..._0x481fea})),this['metadata']['_copy'](_0xd15119['metadata']),this['stsTokenManager']['_assign'](_0xd15119['stsTokenManager']));}['_clone'](_0x5dfc44){const _0x29f51f=new z({...this,'auth':_0x5dfc44,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x29f51f['metadata']['_copy'](this['metadata']),_0x29f51f;}['_onReload'](_0x5187c4){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5187c4,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x493aa5){this['reloadListener']?this['reloadListener'](_0x493aa5):this['reloadUserInfo']=_0x493aa5;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5b387f,_0x47b6c9=!0x1){let _0x3a944d=!0x1;_0x5b387f['idToken']&&_0x5b387f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5b387f),_0x3a944d=!0x0),_0x47b6c9&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3a944d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2cf085=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2cf085})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x290c1f=>({..._0x290c1f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x34db2c,_0x10b428){const _0xbc01ca=_0x10b428['displayName']??void 0x0,_0x33f704=_0x10b428['email']??void 0x0,_0x5b62e4=_0x10b428['phoneNumber']??void 0x0,_0x53129f=_0x10b428['photoURL']??void 0x0,_0x1b8dfd=_0x10b428['tenantId']??void 0x0,_0x1d1d37=_0x10b428['_redirectEventId']??void 0x0,_0x4c5a6c=_0x10b428['createdAt']??void 0x0,_0x4ffa96=_0x10b428['lastLoginAt']??void 0x0,{uid:_0x380529,emailVerified:_0x3aa517,isAnonymous:_0x3d6b00,providerData:_0x365d39,stsTokenManager:_0x12c2fa}=_0x10b428;m(_0x380529&&_0x12c2fa,_0x34db2c,'internal-error');const _0x228bb7=Je['fromJSON'](this['name'],_0x12c2fa);m(typeof _0x380529=='string',_0x34db2c,'internal-error'),ce(_0xbc01ca,_0x34db2c['name']),ce(_0x33f704,_0x34db2c['name']),m(typeof _0x3aa517=='boolean',_0x34db2c,'internal-error'),m(typeof _0x3d6b00=='boolean',_0x34db2c,'internal-error'),ce(_0x5b62e4,_0x34db2c['name']),ce(_0x53129f,_0x34db2c['name']),ce(_0x1b8dfd,_0x34db2c['name']),ce(_0x1d1d37,_0x34db2c['name']),ce(_0x4c5a6c,_0x34db2c['name']),ce(_0x4ffa96,_0x34db2c['name']);const _0x37606c=new z({'uid':_0x380529,'auth':_0x34db2c,'email':_0x33f704,'emailVerified':_0x3aa517,'displayName':_0xbc01ca,'isAnonymous':_0x3d6b00,'photoURL':_0x53129f,'phoneNumber':_0x5b62e4,'tenantId':_0x1b8dfd,'stsTokenManager':_0x228bb7,'createdAt':_0x4c5a6c,'lastLoginAt':_0x4ffa96});return _0x365d39&&Array['isArray'](_0x365d39)&&(_0x37606c['providerData']=_0x365d39['map'](_0x2ece26=>({..._0x2ece26}))),_0x1d1d37&&(_0x37606c['_redirectEventId']=_0x1d1d37),_0x37606c;}static async['_fromIdTokenResponse'](_0x8f2531,_0x4aaf92,_0x1116f8=!0x1){const _0x36899b=new Je();_0x36899b['updateFromServerResponse'](_0x4aaf92);const _0x17809d=new z({'uid':_0x4aaf92['localId'],'auth':_0x8f2531,'stsTokenManager':_0x36899b,'isAnonymous':_0x1116f8});return await bn(_0x17809d),_0x17809d;}static async['_fromGetAccountInfoResponse'](_0x1b10c5,_0xaffc14,_0x41e84f){const _0x3aeb4e=_0xaffc14['users'][0x0];m(_0x3aeb4e['localId']!==void 0x0,'internal-error');const _0x2e47c9=_0x3aeb4e['providerUserInfo']!==void 0x0?wa(_0x3aeb4e['providerUserInfo']):[],_0x11779a=!(_0x3aeb4e['email']&&_0x3aeb4e['passwordHash'])&&!(_0x2e47c9!=null&&_0x2e47c9['length']),_0x4225db=new Je();_0x4225db['updateFromIdToken'](_0x41e84f);const _0x10910d=new z({'uid':_0x3aeb4e['localId'],'auth':_0x1b10c5,'stsTokenManager':_0x4225db,'isAnonymous':_0x11779a}),_0x43bfd9={'uid':_0x3aeb4e['localId'],'displayName':_0x3aeb4e['displayName']||null,'photoURL':_0x3aeb4e['photoUrl']||null,'email':_0x3aeb4e['email']||null,'emailVerified':_0x3aeb4e['emailVerified']||!0x1,'phoneNumber':_0x3aeb4e['phoneNumber']||null,'tenantId':_0x3aeb4e['tenantId']||null,'providerData':_0x2e47c9,'metadata':new Pi(_0x3aeb4e['createdAt'],_0x3aeb4e['lastLoginAt']),'isAnonymous':!(_0x3aeb4e['email']&&_0x3aeb4e['passwordHash'])&&!(_0x2e47c9!=null&&_0x2e47c9['length'])};return Object['assign'](_0x10910d,_0x43bfd9),_0x10910d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x19fc08){ae(_0x19fc08 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x489bd2=Ir['get'](_0x19fc08);return _0x489bd2?(ae(_0x489bd2 instanceof _0x19fc08,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x489bd2):(_0x489bd2=new _0x19fc08(),Ir['set'](_0x19fc08,_0x489bd2),_0x489bd2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2171f6,_0x45581b){this['storage'][_0x2171f6]=_0x45581b;}async['_get'](_0x3c010f){const _0x1da0bf=this['storage'][_0x3c010f];return _0x1da0bf===void 0x0?null:_0x1da0bf;}async['_remove'](_0x16e342){delete this['storage'][_0x16e342];}['_addListener'](_0xd4c219,_0x1bf61b){}['_removeListener'](_0x205537,_0x1c4707){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0xde382b,_0x29e101,_0x353744){return'firebase:'+_0xde382b+':'+_0x29e101+':'+_0x353744;}class Xe{constructor(_0x5c925c,_0x473d9b,_0x289d11){this['persistence']=_0x5c925c,this['auth']=_0x473d9b,this['userKey']=_0x289d11;const {config:_0x220d36,name:_0xf021f4}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x220d36['apiKey'],_0xf021f4),this['fullPersistenceKey']=sn('persistence',_0x220d36['apiKey'],_0xf021f4),this['boundEventHandler']=_0x473d9b['_onStorageEvent']['bind'](_0x473d9b),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x466d24){return this['persistence']['_set'](this['fullUserKey'],_0x466d24['toJSON']());}async['getCurrentUser'](){const _0x36190f=await this['persistence']['_get'](this['fullUserKey']);if(!_0x36190f)return null;if(typeof _0x36190f=='string'){const _0x5e40f1=await Sn(this['auth'],{'idToken':_0x36190f})['catch'](()=>{});return _0x5e40f1?z['_fromGetAccountInfoResponse'](this['auth'],_0x5e40f1,_0x36190f):null;}return z['_fromJSON'](this['auth'],_0x36190f);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x34dba2){if(this['persistence']===_0x34dba2)return;const _0x235845=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x34dba2,_0x235845)return this['setCurrentUser'](_0x235845);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3e4caf,_0x1a905c,_0x373a06='authUser'){if(!_0x1a905c['length'])return new Xe(ne(wr),_0x3e4caf,_0x373a06);const _0x475525=(await Promise['all'](_0x1a905c['map'](async _0x3465f2=>{if(await _0x3465f2['_isAvailable']())return _0x3465f2;})))['filter'](_0x57f16e=>_0x57f16e);let _0x3a7f08=_0x475525[0x0]||ne(wr);const _0x576e44=sn(_0x373a06,_0x3e4caf['config']['apiKey'],_0x3e4caf['name']);let _0xc25371=null;for(const _0x232c04 of _0x1a905c)try{const _0x182f4d=await _0x232c04['_get'](_0x576e44);if(_0x182f4d){let _0x2fb4cb;if(typeof _0x182f4d=='string'){const _0x25228b=await Sn(_0x3e4caf,{'idToken':_0x182f4d})['catch'](()=>{});if(!_0x25228b)break;_0x2fb4cb=await z['_fromGetAccountInfoResponse'](_0x3e4caf,_0x25228b,_0x182f4d);}else _0x2fb4cb=z['_fromJSON'](_0x3e4caf,_0x182f4d);_0x232c04!==_0x3a7f08&&(_0xc25371=_0x2fb4cb),_0x3a7f08=_0x232c04;break;}}catch{}const _0x50bfb2=_0x475525['filter'](_0x34c532=>_0x34c532['_shouldAllowMigration']);return!_0x3a7f08['_shouldAllowMigration']||!_0x50bfb2['length']?new Xe(_0x3a7f08,_0x3e4caf,_0x373a06):(_0x3a7f08=_0x50bfb2[0x0],_0xc25371&&await _0x3a7f08['_set'](_0x576e44,_0xc25371['toJSON']()),await Promise['all'](_0x1a905c['map'](async _0x258d0d=>{if(_0x258d0d!==_0x3a7f08)try{await _0x258d0d['_remove'](_0x576e44);}catch{}})),new Xe(_0x3a7f08,_0x3e4caf,_0x373a06));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x5d6363){const _0x24633e=_0x5d6363['toLowerCase']();if(_0x24633e['includes']('opera/')||_0x24633e['includes']('opr/')||_0x24633e['includes']('opios/'))return'Opera';if(Ra(_0x24633e))return'IEMobile';if(_0x24633e['includes']('msie')||_0x24633e['includes']('trident/'))return'IE';if(_0x24633e['includes']('edge/'))return'Edge';if(Ta(_0x24633e))return'Firefox';if(_0x24633e['includes']('silk/'))return'Silk';if(ka(_0x24633e))return'Blackberry';if(Na(_0x24633e))return'Webos';if(Sa(_0x24633e))return'Safari';if((_0x24633e['includes']('chrome/')||ba(_0x24633e))&&!_0x24633e['includes']('edge/'))return'Chrome';if(Aa(_0x24633e))return'Android';{const _0x193322=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1baf46=_0x5d6363['match'](_0x193322);if((_0x1baf46==null?void 0x0:_0x1baf46['length'])===0x2)return _0x1baf46[0x1];}return'Other';}function Ta(_0x50d9d3=W()){return/firefox\//i['test'](_0x50d9d3);}function Sa(_0x1c8507=W()){const _0x5dbd1d=_0x1c8507['toLowerCase']();return _0x5dbd1d['includes']('safari/')&&!_0x5dbd1d['includes']('chrome/')&&!_0x5dbd1d['includes']('crios/')&&!_0x5dbd1d['includes']('android');}function ba(_0x5791f9=W()){return/crios\//i['test'](_0x5791f9);}function Ra(_0x5d5a55=W()){return/iemobile/i['test'](_0x5d5a55);}function Aa(_0x2c8a1a=W()){return/android/i['test'](_0x2c8a1a);}function ka(_0x36ac97=W()){return/blackberry/i['test'](_0x36ac97);}function Na(_0x25bd91=W()){return/webos/i['test'](_0x25bd91);}function Cs(_0x481b4a=W()){return/iphone|ipad|ipod/i['test'](_0x481b4a)||/macintosh/i['test'](_0x481b4a)&&/mobile/i['test'](_0x481b4a);}function Ef(_0x516906=W()){var _0x389bc3;return Cs(_0x516906)&&!!((_0x389bc3=window['navigator'])!=null&&_0x389bc3['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2d92f2=W()){return Cs(_0x2d92f2)||Aa(_0x2d92f2)||Na(_0x2d92f2)||ka(_0x2d92f2)||/windows phone/i['test'](_0x2d92f2)||Ra(_0x2d92f2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x56a6f2,_0x2d18dd=[]){let _0x43cc42;switch(_0x56a6f2){case'Browser':_0x43cc42=Cr(W());break;case'Worker':_0x43cc42=Cr(W())+'-'+_0x56a6f2;break;default:_0x43cc42=_0x56a6f2;}const _0x2299c0=_0x2d18dd['length']?_0x2d18dd['join'](','):'FirebaseCore-web';return _0x43cc42+'/JsCore/'+ct+'/'+_0x2299c0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x17fb39){this['auth']=_0x17fb39,this['queue']=[];}['pushCallback'](_0x2c0580,_0x2a4815){const _0x4be660=_0x2d500e=>new Promise((_0x34e082,_0x2e2777)=>{try{const _0xe904c7=_0x2c0580(_0x2d500e);_0x34e082(_0xe904c7);}catch(_0x4b036c){_0x2e2777(_0x4b036c);}});_0x4be660['onAbort']=_0x2a4815,this['queue']['push'](_0x4be660);const _0x2bb294=this['queue']['length']-0x1;return()=>{this['queue'][_0x2bb294]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4676c4){if(this['auth']['currentUser']===_0x4676c4)return;const _0x13b1d6=[];try{for(const _0x4a3a2a of this['queue'])await _0x4a3a2a(_0x4676c4),_0x4a3a2a['onAbort']&&_0x13b1d6['push'](_0x4a3a2a['onAbort']);}catch(_0x57224e){_0x13b1d6['reverse']();for(const _0x511fa7 of _0x13b1d6)try{_0x511fa7();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x57224e==null?void 0x0:_0x57224e['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x3c50fc,_0x592d48={}){return Ae(_0x3c50fc,'GET','/v2/passwordPolicy',Re(_0x3c50fc,_0x592d48));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x391e6e){var _0x25dc09;const _0x1f7cba=_0x391e6e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1f7cba['minPasswordLength']??Tf,_0x1f7cba['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1f7cba['maxPasswordLength']),_0x1f7cba['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1f7cba['containsLowercaseCharacter']),_0x1f7cba['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1f7cba['containsUppercaseCharacter']),_0x1f7cba['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1f7cba['containsNumericCharacter']),_0x1f7cba['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1f7cba['containsNonAlphanumericCharacter']),this['enforcementState']=_0x391e6e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x25dc09=_0x391e6e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x25dc09['join'](''))??'',this['forceUpgradeOnSignin']=_0x391e6e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x391e6e['schemaVersion'];}['validatePassword'](_0x56a08){const _0x40e95c={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x56a08,_0x40e95c),this['validatePasswordCharacterOptions'](_0x56a08,_0x40e95c),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['meetsMinPasswordLength']??!0x0),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['meetsMaxPasswordLength']??!0x0),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['containsLowercaseLetter']??!0x0),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['containsUppercaseLetter']??!0x0),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['containsNumericCharacter']??!0x0),_0x40e95c['isValid']&&(_0x40e95c['isValid']=_0x40e95c['containsNonAlphanumericCharacter']??!0x0),_0x40e95c;}['validatePasswordLengthOptions'](_0x169466,_0x3b4207){const _0x3c70cb=this['customStrengthOptions']['minPasswordLength'],_0x52e38b=this['customStrengthOptions']['maxPasswordLength'];_0x3c70cb&&(_0x3b4207['meetsMinPasswordLength']=_0x169466['length']>=_0x3c70cb),_0x52e38b&&(_0x3b4207['meetsMaxPasswordLength']=_0x169466['length']<=_0x52e38b);}['validatePasswordCharacterOptions'](_0x259791,_0x2f2848){this['updatePasswordCharacterOptionsStatuses'](_0x2f2848,!0x1,!0x1,!0x1,!0x1);let _0x1e29a7;for(let _0x5f59c8=0x0;_0x5f59c8<_0x259791['length'];_0x5f59c8++)_0x1e29a7=_0x259791['charAt'](_0x5f59c8),this['updatePasswordCharacterOptionsStatuses'](_0x2f2848,_0x1e29a7>='a'&&_0x1e29a7<='z',_0x1e29a7>='A'&&_0x1e29a7<='Z',_0x1e29a7>='0'&&_0x1e29a7<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1e29a7));}['updatePasswordCharacterOptionsStatuses'](_0x5843d2,_0xc2b540,_0x4c784a,_0x55211c,_0x3b6ece){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5843d2['containsLowercaseLetter']||(_0x5843d2['containsLowercaseLetter']=_0xc2b540)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5843d2['containsUppercaseLetter']||(_0x5843d2['containsUppercaseLetter']=_0x4c784a)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5843d2['containsNumericCharacter']||(_0x5843d2['containsNumericCharacter']=_0x55211c)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5843d2['containsNonAlphanumericCharacter']||(_0x5843d2['containsNonAlphanumericCharacter']=_0x3b6ece));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x41d8c9,_0x5d8821,_0x40f8a5,_0x142f0a){this['app']=_0x41d8c9,this['heartbeatServiceProvider']=_0x5d8821,this['appCheckServiceProvider']=_0x40f8a5,this['config']=_0x142f0a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x41d8c9['name'],this['clientVersion']=_0x142f0a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4f71c7=>this['_resolvePersistenceManagerAvailable']=_0x4f71c7);}['_initializeWithPersistence'](_0x5e633c,_0x18fc63){return _0x18fc63&&(this['_popupRedirectResolver']=ne(_0x18fc63)),this['_initializationPromise']=this['queue'](async()=>{var _0x380d2f,_0x10bc8b,_0x3df829;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x5e633c),(_0x380d2f=this['_resolvePersistenceManagerAvailable'])==null||_0x380d2f['call'](this),!this['_deleted'])){if((_0x10bc8b=this['_popupRedirectResolver'])!=null&&_0x10bc8b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x18fc63),this['lastNotifiedUid']=((_0x3df829=this['currentUser'])==null?void 0x0:_0x3df829['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2520fb=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2520fb)){if(this['currentUser']&&_0x2520fb&&this['currentUser']['uid']===_0x2520fb['uid']){this['_currentUser']['_assign'](_0x2520fb),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2520fb,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2c8328){try{const _0x58b815=await Sn(this,{'idToken':_0x2c8328}),_0x450d80=await z['_fromGetAccountInfoResponse'](this,_0x58b815,_0x2c8328);await this['directlySetCurrentUser'](_0x450d80);}catch(_0x32c3e2){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x32c3e2),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x28b80e){var _0x160d64;if(H(this['app'])){const _0xad0500=this['app']['settings']['authIdToken'];return _0xad0500?new Promise(_0x414e59=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xad0500)['then'](_0x414e59,_0x414e59));}):this['directlySetCurrentUser'](null);}const _0x4bd8f4=await this['assertedPersistence']['getCurrentUser']();let _0x43930=_0x4bd8f4,_0x262ffc=!0x1;if(_0x28b80e&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x496818=(_0x160d64=this['redirectUser'])==null?void 0x0:_0x160d64['_redirectEventId'],_0x55c854=_0x43930==null?void 0x0:_0x43930['_redirectEventId'],_0x481223=await this['tryRedirectSignIn'](_0x28b80e);(!_0x496818||_0x496818===_0x55c854)&&(_0x481223!=null&&_0x481223['user'])&&(_0x43930=_0x481223['user'],_0x262ffc=!0x0);}if(!_0x43930)return this['directlySetCurrentUser'](null);if(!_0x43930['_redirectEventId']){if(_0x262ffc)try{await this['beforeStateQueue']['runMiddleware'](_0x43930);}catch(_0x2be282){_0x43930=_0x4bd8f4,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2be282));}return _0x43930?this['reloadAndSetCurrentUserOrClear'](_0x43930):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x43930['_redirectEventId']?this['directlySetCurrentUser'](_0x43930):this['reloadAndSetCurrentUserOrClear'](_0x43930);}async['tryRedirectSignIn'](_0x4fa055){let _0x2ce1bf=null;try{_0x2ce1bf=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4fa055,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2ce1bf;}async['reloadAndSetCurrentUserOrClear'](_0x4e29f4){try{await bn(_0x4e29f4);}catch(_0x41fc59){if((_0x41fc59==null?void 0x0:_0x41fc59['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4e29f4);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x50979d){if(H(this['app']))return Promise['reject'](se(this));const _0x3541f0=_0x50979d?k(_0x50979d):null;return _0x3541f0&&m(_0x3541f0['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3541f0&&_0x3541f0['_clone'](this));}async['_updateCurrentUser'](_0x91f3b3,_0x401883=!0x1){if(!this['_deleted'])return _0x91f3b3&&m(this['tenantId']===_0x91f3b3['tenantId'],this,'tenant-id-mismatch'),_0x401883||await this['beforeStateQueue']['runMiddleware'](_0x91f3b3),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x91f3b3),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5dc1cc){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x5dc1cc));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x388638){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3d7a0c=this['_getPasswordPolicyInternal']();return _0x3d7a0c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3d7a0c['validatePassword'](_0x388638);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x54e584=await Cf(this),_0x2a71f1=new Sf(_0x54e584);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2a71f1:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2a71f1;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5ba602){this['_errorFactory']=new Ut('auth','Firebase',_0x5ba602());}['onAuthStateChanged'](_0x1fb2a8,_0x5f074e,_0x284961){return this['registerStateListener'](this['authStateSubscription'],_0x1fb2a8,_0x5f074e,_0x284961);}['beforeAuthStateChanged'](_0x879991,_0x3f984f){return this['beforeStateQueue']['pushCallback'](_0x879991,_0x3f984f);}['onIdTokenChanged'](_0x28b375,_0x47f9ef,_0x518ebf){return this['registerStateListener'](this['idTokenSubscription'],_0x28b375,_0x47f9ef,_0x518ebf);}['authStateReady'](){return new Promise((_0x58dd3f,_0x3f215e)=>{if(this['currentUser'])_0x58dd3f();else{const _0x1ad655=this['onAuthStateChanged'](()=>{_0x1ad655(),_0x58dd3f();},_0x3f215e);}});}async['revokeAccessToken'](_0x1fcc59){if(this['currentUser']){const _0x438b8c=await this['currentUser']['getIdToken'](),_0x3e4593={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1fcc59,'idToken':_0x438b8c};this['tenantId']!=null&&(_0x3e4593['tenantId']=this['tenantId']),await vf(this,_0x3e4593);}}['toJSON'](){var _0x3496ef;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3496ef=this['_currentUser'])==null?void 0x0:_0x3496ef['toJSON']()};}async['_setRedirectUser'](_0x1cd21d,_0x49e81d){const _0x2567af=await this['getOrInitRedirectPersistenceManager'](_0x49e81d);return _0x1cd21d===null?_0x2567af['removeCurrentUser']():_0x2567af['setCurrentUser'](_0x1cd21d);}async['getOrInitRedirectPersistenceManager'](_0x1a61f7){if(!this['redirectPersistenceManager']){const _0xccba7c=_0x1a61f7&&ne(_0x1a61f7)||this['_popupRedirectResolver'];m(_0xccba7c,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0xccba7c['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x44e166){var _0x179c2d,_0xd02392;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x179c2d=this['_currentUser'])==null?void 0x0:_0x179c2d['_redirectEventId'])===_0x44e166?this['_currentUser']:((_0xd02392=this['redirectUser'])==null?void 0x0:_0xd02392['_redirectEventId'])===_0x44e166?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x480575){if(_0x480575===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x480575));}['_notifyListenersIfCurrent'](_0x2a61d7){_0x2a61d7===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2ce485;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x31a41a=((_0x2ce485=this['currentUser'])==null?void 0x0:_0x2ce485['uid'])??null;this['lastNotifiedUid']!==_0x31a41a&&(this['lastNotifiedUid']=_0x31a41a,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x199d81,_0xea60d4,_0x37c046,_0x50d80d){if(this['_deleted'])return()=>{};const _0x32af30=typeof _0xea60d4=='function'?_0xea60d4:_0xea60d4['next']['bind'](_0xea60d4);let _0x544061=!0x1;const _0x48b49f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x48b49f,this,'internal-error'),_0x48b49f['then'](()=>{_0x544061||_0x32af30(this['currentUser']);}),typeof _0xea60d4=='function'){const _0x5963af=_0x199d81['addObserver'](_0xea60d4,_0x37c046,_0x50d80d);return()=>{_0x544061=!0x0,_0x5963af();};}else{const _0xaf5f8c=_0x199d81['addObserver'](_0xea60d4);return()=>{_0x544061=!0x0,_0xaf5f8c();};}}async['directlySetCurrentUser'](_0x48563e){this['currentUser']&&this['currentUser']!==_0x48563e&&this['_currentUser']['_stopProactiveRefresh'](),_0x48563e&&this['isProactiveRefreshEnabled']&&_0x48563e['_startProactiveRefresh'](),this['currentUser']=_0x48563e,_0x48563e?await this['assertedPersistence']['setCurrentUser'](_0x48563e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1aabf7){return this['operations']=this['operations']['then'](_0x1aabf7,_0x1aabf7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x271076){!_0x271076||this['frameworks']['includes'](_0x271076)||(this['frameworks']['push'](_0x271076),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x22c1ab;const _0x4af5f9={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4af5f9['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5e3ed4=await((_0x22c1ab=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x22c1ab['getHeartbeatsHeader']());_0x5e3ed4&&(_0x4af5f9['X-Firebase-Client']=_0x5e3ed4);const _0x9c5d8d=await this['_getAppCheckToken']();return _0x9c5d8d&&(_0x4af5f9['X-Firebase-AppCheck']=_0x9c5d8d),_0x4af5f9;}async['_getAppCheckToken'](){var _0xa2de57;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x80b69=await((_0xa2de57=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xa2de57['getToken']());return _0x80b69!=null&&_0x80b69['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x80b69['error']),_0x80b69==null?void 0x0:_0x80b69['token'];}}function qe(_0x36af9c){return k(_0x36af9c);}class Tr{constructor(_0x217220){this['auth']=_0x217220,this['observer']=null,this['addObserver']=Ic(_0x20ae3f=>this['observer']=_0x20ae3f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2b5e94){zn=_0x2b5e94;}function Da(_0x5b5640){return zn['loadJS'](_0x5b5640);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x40e5f6){return'__'+_0x40e5f6+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x50845b){_0x50845b();}['execute'](_0x24d7c2,_0x51448a){return Promise['resolve']('token');}['render'](_0x367710,_0x12b50c){return'';}}class Of{['ready'](_0x2a3adc){_0x2a3adc();}['execute'](_0x553d88,_0x47d51d){return Promise['resolve']('token');}['render'](_0x218a4a,_0xd94e29){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3836e5){this['type']=Df,this['auth']=qe(_0x3836e5);}async['verify'](_0x29584f='verify',_0x13d11a=!0x1){async function _0x468e0e(_0x43284f){if(!_0x13d11a){if(_0x43284f['tenantId']==null&&_0x43284f['_agentRecaptchaConfig']!=null)return _0x43284f['_agentRecaptchaConfig']['siteKey'];if(_0x43284f['tenantId']!=null&&_0x43284f['_tenantRecaptchaConfigs'][_0x43284f['tenantId']]!==void 0x0)return _0x43284f['_tenantRecaptchaConfigs'][_0x43284f['tenantId']]['siteKey'];}return new Promise(async(_0x58bad0,_0x34e0f6)=>{uf(_0x43284f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2fbf55=>{if(_0x2fbf55['recaptchaKey']===void 0x0)_0x34e0f6(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xed290=new hf(_0x2fbf55);return _0x43284f['tenantId']==null?_0x43284f['_agentRecaptchaConfig']=_0xed290:_0x43284f['_tenantRecaptchaConfigs'][_0x43284f['tenantId']]=_0xed290,_0x58bad0(_0xed290['siteKey']);}})['catch'](_0x35063e=>{_0x34e0f6(_0x35063e);});});}function _0x47d594(_0x3a6473,_0x12c820,_0x92d8e2){const _0xf54dcb=window['grecaptcha'];vr(_0xf54dcb)?_0xf54dcb['enterprise']['ready'](()=>{_0xf54dcb['enterprise']['execute'](_0x3a6473,{'action':_0x29584f})['then'](_0x28ae29=>{_0x12c820(_0x28ae29);})['catch'](()=>{_0x12c820(Ma);});}):_0x92d8e2(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1cbc2d,_0x1cf9b6)=>{_0x468e0e(this['auth'])['then'](async _0x50e151=>{if(!_0x13d11a&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x47d594(_0x50e151,_0x1cbc2d,_0x1cf9b6);else{if(typeof window>'u'){_0x1cf9b6(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x30a08d=Af();_0x30a08d['length']!==0x0&&(_0x30a08d+=_0x50e151+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x26ef57;(_0x26ef57=le['scriptInjectionDeferred'])==null||_0x26ef57['resolve']();},Da(_0x30a08d)['then'](()=>{var _0x1c3787;return(_0x1c3787=le['scriptInjectionDeferred'])==null?void 0x0:_0x1c3787['promise'];})['then'](()=>{_0x47d594(_0x50e151,_0x1cbc2d,_0x1cf9b6);})['catch'](_0x3c2d64=>{_0x1cf9b6(_0x3c2d64);});}})['catch'](_0x4cc6cb=>{_0x1cf9b6(_0x4cc6cb);});});}}le['scriptInjectionDeferred']=null;async function br(_0xeaa1a2,_0x1766dd,_0xebcef9,_0x85ddc=!0x1,_0x2b8387=!0x1){const _0x4e15c1=new le(_0xeaa1a2);let _0xc92f6;if(_0x2b8387)_0xc92f6=Ma;else try{_0xc92f6=await _0x4e15c1['verify'](_0xebcef9);}catch{_0xc92f6=await _0x4e15c1['verify'](_0xebcef9,!0x0);}const _0x47f452={..._0x1766dd};if(_0xebcef9==='mfaSmsEnrollment'||_0xebcef9==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x47f452){const _0xc2b207=_0x47f452['phoneEnrollmentInfo']['phoneNumber'],_0x53b5b4=_0x47f452['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x47f452,{'phoneEnrollmentInfo':{'phoneNumber':_0xc2b207,'recaptchaToken':_0x53b5b4,'captchaResponse':_0xc92f6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x47f452){const _0x5d6d91=_0x47f452['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x47f452,{'phoneSignInInfo':{'recaptchaToken':_0x5d6d91,'captchaResponse':_0xc92f6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x47f452;}return _0x85ddc?Object['assign'](_0x47f452,{'captchaResp':_0xc92f6}):Object['assign'](_0x47f452,{'captchaResponse':_0xc92f6}),Object['assign'](_0x47f452,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x47f452,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x47f452;}async function Oi(_0x369988,_0xbba29a,_0x1e55df,_0x359dec,_0x31b6d8){var _0x214829;if((_0x214829=_0x369988['_getRecaptchaConfig']())!=null&&_0x214829['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x368b4c=await br(_0x369988,_0xbba29a,_0x1e55df,_0x1e55df==='getOobCode');return _0x359dec(_0x369988,_0x368b4c);}else return _0x359dec(_0x369988,_0xbba29a)['catch'](async _0x1f0e19=>{if(_0x1f0e19['code']==='auth/missing-recaptcha-token'){console['log'](_0x1e55df+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5c0534=await br(_0x369988,_0xbba29a,_0x1e55df,_0x1e55df==='getOobCode');return _0x359dec(_0x369988,_0x5c0534);}else return Promise['reject'](_0x1f0e19);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x451cc9,_0x4e4661){const _0x52c8c4=Ui(_0x451cc9,'auth');if(_0x52c8c4['isInitialized']()){const _0x3ecab0=_0x52c8c4['getImmediate'](),_0xe8004a=_0x52c8c4['getOptions']();if(De(_0xe8004a,_0x4e4661??{}))return _0x3ecab0;K(_0x3ecab0,'already-initialized');}return _0x52c8c4['initialize']({'options':_0x4e4661});}function Lf(_0x1314c0,_0x79dc14){const _0x29099c=(_0x79dc14==null?void 0x0:_0x79dc14['persistence'])||[],_0x17c5df=(Array['isArray'](_0x29099c)?_0x29099c:[_0x29099c])['map'](ne);_0x79dc14!=null&&_0x79dc14['errorMap']&&_0x1314c0['_updateErrorMap'](_0x79dc14['errorMap']),_0x1314c0['_initializeWithPersistence'](_0x17c5df,_0x79dc14==null?void 0x0:_0x79dc14['popupRedirectResolver']);}function xf(_0xe4f085,_0x20a5be,_0x16ec7a){const _0x14796c=qe(_0xe4f085);m(/^https?:\/\//['test'](_0x20a5be),_0x14796c,'invalid-emulator-scheme');const _0x3857fd=!0x1,_0x3e0097=La(_0x20a5be),{host:_0x1a2dec,port:_0xace02e}=Ff(_0x20a5be),_0x1216d6=_0xace02e===null?'':':'+_0xace02e,_0x41d169={'url':_0x3e0097+'//'+_0x1a2dec+_0x1216d6+'/'},_0x126729=Object['freeze']({'host':_0x1a2dec,'port':_0xace02e,'protocol':_0x3e0097['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3857fd})});if(!_0x14796c['_canInitEmulator']){m(_0x14796c['config']['emulator']&&_0x14796c['emulatorConfig'],_0x14796c,'emulator-config-failed'),m(De(_0x41d169,_0x14796c['config']['emulator'])&&De(_0x126729,_0x14796c['emulatorConfig']),_0x14796c,'emulator-config-failed');return;}_0x14796c['config']['emulator']=_0x41d169,_0x14796c['emulatorConfig']=_0x126729,_0x14796c['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x1a2dec)?jr(_0x3e0097+'//'+_0x1a2dec+_0x1216d6):Uf();}function La(_0x370028){const _0x26da73=_0x370028['indexOf'](':');return _0x26da73<0x0?'':_0x370028['substr'](0x0,_0x26da73+0x1);}function Ff(_0x16655f){const _0x2fe546=La(_0x16655f),_0x25e513=/(\/\/)?([^?#/]+)/['exec'](_0x16655f['substr'](_0x2fe546['length']));if(!_0x25e513)return{'host':'','port':null};const _0xfe07d4=_0x25e513[0x2]['split']('@')['pop']()||'',_0x473b1f=/^(\[[^\]]+\])(:|$)/['exec'](_0xfe07d4);if(_0x473b1f){const _0x35cce6=_0x473b1f[0x1];return{'host':_0x35cce6,'port':Rr(_0xfe07d4['substr'](_0x35cce6['length']+0x1))};}else{const [_0x16c34f,_0xef762b]=_0xfe07d4['split'](':');return{'host':_0x16c34f,'port':Rr(_0xef762b)};}}function Rr(_0x5d2a60){if(!_0x5d2a60)return null;const _0x346407=Number(_0x5d2a60);return isNaN(_0x346407)?null:_0x346407;}function Uf(){function _0x3e4553(){const _0xe858f1=document['createElement']('p'),_0x2e7071=_0xe858f1['style'];_0xe858f1['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2e7071['position']='fixed',_0x2e7071['width']='100%',_0x2e7071['backgroundColor']='#ffffff',_0x2e7071['border']='.1em\x20solid\x20#000000',_0x2e7071['color']='#b50000',_0x2e7071['bottom']='0px',_0x2e7071['left']='0px',_0x2e7071['margin']='0px',_0x2e7071['zIndex']='10000',_0x2e7071['textAlign']='center',_0xe858f1['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xe858f1);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3e4553):_0x3e4553());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2abc40,_0x302774){this['providerId']=_0x2abc40,this['signInMethod']=_0x302774;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x384e06){return te('not\x20implemented');}['_linkToIdToken'](_0x36b492,_0x21c0c2){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x15058d){return te('not\x20implemented');}}async function Wf(_0x247113,_0x44a51){return Ae(_0x247113,'POST','/v1/accounts:signUp',_0x44a51);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2009a6,_0x159332){return Yt(_0x2009a6,'POST','/v1/accounts:signInWithPassword',Re(_0x2009a6,_0x159332));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x2ac21d,_0x44834b){return Yt(_0x2ac21d,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2ac21d,_0x44834b));}async function Hf(_0x4e9440,_0x933591){return Yt(_0x4e9440,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4e9440,_0x933591));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x5895a5,_0x1747d6,_0x1f52d8,_0x24b3b7=null){super('password',_0x1f52d8),this['_email']=_0x5895a5,this['_password']=_0x1747d6,this['_tenantId']=_0x24b3b7;}static['_fromEmailAndPassword'](_0x45ec79,_0x3a3646){return new Ft(_0x45ec79,_0x3a3646,'password');}static['_fromEmailAndCode'](_0x41ef43,_0x527c03,_0x121810=null){return new Ft(_0x41ef43,_0x527c03,'emailLink',_0x121810);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3a6616){const _0x1dd44d=typeof _0x3a6616=='string'?JSON['parse'](_0x3a6616):_0x3a6616;if(_0x1dd44d!=null&&_0x1dd44d['email']&&(_0x1dd44d!=null&&_0x1dd44d['password'])){if(_0x1dd44d['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1dd44d['email'],_0x1dd44d['password']);if(_0x1dd44d['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1dd44d['email'],_0x1dd44d['password'],_0x1dd44d['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4f95b9){switch(this['signInMethod']){case'password':const _0x55c3ed={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4f95b9,_0x55c3ed,'signInWithPassword',Bf);case'emailLink':return Vf(_0x4f95b9,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x4f95b9,'internal-error');}}async['_linkToIdToken'](_0x2aceaf,_0x5ef2dc){switch(this['signInMethod']){case'password':const _0x36e50a={'idToken':_0x5ef2dc,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2aceaf,_0x36e50a,'signUpPassword',Wf);case'emailLink':return Hf(_0x2aceaf,{'idToken':_0x5ef2dc,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2aceaf,'internal-error');}}['_getReauthenticationResolver'](_0x3c3847){return this['_getIdTokenResponse'](_0x3c3847);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x594cad,_0x175135){return Yt(_0x594cad,'POST','/v1/accounts:signInWithIdp',Re(_0x594cad,_0x175135));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x616578){const _0x2a5f95=new We(_0x616578['providerId'],_0x616578['signInMethod']);return _0x616578['idToken']||_0x616578['accessToken']?(_0x616578['idToken']&&(_0x2a5f95['idToken']=_0x616578['idToken']),_0x616578['accessToken']&&(_0x2a5f95['accessToken']=_0x616578['accessToken']),_0x616578['nonce']&&!_0x616578['pendingToken']&&(_0x2a5f95['nonce']=_0x616578['nonce']),_0x616578['pendingToken']&&(_0x2a5f95['pendingToken']=_0x616578['pendingToken'])):_0x616578['oauthToken']&&_0x616578['oauthTokenSecret']?(_0x2a5f95['accessToken']=_0x616578['oauthToken'],_0x2a5f95['secret']=_0x616578['oauthTokenSecret']):K('argument-error'),_0x2a5f95;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x554356){const _0x3a7f64=typeof _0x554356=='string'?JSON['parse'](_0x554356):_0x554356,{providerId:_0x24a4d9,signInMethod:_0x412c63,..._0x3b5612}=_0x3a7f64;if(!_0x24a4d9||!_0x412c63)return null;const _0x578b5c=new We(_0x24a4d9,_0x412c63);return _0x578b5c['idToken']=_0x3b5612['idToken']||void 0x0,_0x578b5c['accessToken']=_0x3b5612['accessToken']||void 0x0,_0x578b5c['secret']=_0x3b5612['secret'],_0x578b5c['nonce']=_0x3b5612['nonce'],_0x578b5c['pendingToken']=_0x3b5612['pendingToken']||null,_0x578b5c;}['_getIdTokenResponse'](_0x5a54fa){const _0x920d67=this['buildRequest']();return Ze(_0x5a54fa,_0x920d67);}['_linkToIdToken'](_0x1290c2,_0x3f7ae0){const _0x2a03cf=this['buildRequest']();return _0x2a03cf['idToken']=_0x3f7ae0,Ze(_0x1290c2,_0x2a03cf);}['_getReauthenticationResolver'](_0x5d7a18){const _0x2d01f3=this['buildRequest']();return _0x2d01f3['autoCreate']=!0x1,Ze(_0x5d7a18,_0x2d01f3);}['buildRequest'](){const _0x267828={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x267828['pendingToken']=this['pendingToken'];else{const _0x5aba4a={};this['idToken']&&(_0x5aba4a['id_token']=this['idToken']),this['accessToken']&&(_0x5aba4a['access_token']=this['accessToken']),this['secret']&&(_0x5aba4a['oauth_token_secret']=this['secret']),_0x5aba4a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5aba4a['nonce']=this['nonce']),_0x267828['postBody']=at(_0x5aba4a);}return _0x267828;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x4405f0){switch(_0x4405f0){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x273ed7){const _0x5d99b1=yt(vt(_0x273ed7))['link'],_0x2102d2=_0x5d99b1?yt(vt(_0x5d99b1))['deep_link_id']:null,_0x26ed9c=yt(vt(_0x273ed7))['deep_link_id'];return(_0x26ed9c?yt(vt(_0x26ed9c))['link']:null)||_0x26ed9c||_0x2102d2||_0x5d99b1||_0x273ed7;}class Ss{constructor(_0x58f7f5){const _0x1ead50=yt(vt(_0x58f7f5)),_0x30499b=_0x1ead50['apiKey']??null,_0x23c7cb=_0x1ead50['oobCode']??null,_0x1f1a77=Gf(_0x1ead50['mode']??null);m(_0x30499b&&_0x23c7cb&&_0x1f1a77,'argument-error'),this['apiKey']=_0x30499b,this['operation']=_0x1f1a77,this['code']=_0x23c7cb,this['continueUrl']=_0x1ead50['continueUrl']??null,this['languageCode']=_0x1ead50['lang']??null,this['tenantId']=_0x1ead50['tenantId']??null;}static['parseLink'](_0x4dd6df){const _0x269839=qf(_0x4dd6df);try{return new Ss(_0x269839);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2fdef8,_0x2f6794){return Ft['_fromEmailAndPassword'](_0x2fdef8,_0x2f6794);}static['credentialWithLink'](_0x7109f5,_0x346eb1){const _0x47e8b2=Ss['parseLink'](_0x346eb1);return m(_0x47e8b2,'argument-error'),Ft['_fromEmailAndCode'](_0x7109f5,_0x47e8b2['code'],_0x47e8b2['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x3487d1){this['providerId']=_0x3487d1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2cede9){this['defaultLanguageCode']=_0x2cede9;}['setCustomParameters'](_0x443007){return this['customParameters']=_0x443007,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3b76f6){return this['scopes']['includes'](_0x3b76f6)||this['scopes']['push'](_0x3b76f6),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x3e7ad5){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3e7ad5});}static['credentialFromResult'](_0xf59601){return he['credentialFromTaggedObject'](_0xf59601);}static['credentialFromError'](_0x3c5703){return he['credentialFromTaggedObject'](_0x3c5703['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x282ff6}){if(!_0x282ff6||!('oauthAccessToken'in _0x282ff6)||!_0x282ff6['oauthAccessToken'])return null;try{return he['credential'](_0x282ff6['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x51a92c,_0x582b58){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x51a92c,'accessToken':_0x582b58});}static['credentialFromResult'](_0x2ba5c4){return ue['credentialFromTaggedObject'](_0x2ba5c4);}static['credentialFromError'](_0xac7a27){return ue['credentialFromTaggedObject'](_0xac7a27['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x276bf1}){if(!_0x276bf1)return null;const {oauthIdToken:_0x1df9da,oauthAccessToken:_0x369beb}=_0x276bf1;if(!_0x1df9da&&!_0x369beb)return null;try{return ue['credential'](_0x1df9da,_0x369beb);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x46e87e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x46e87e});}static['credentialFromResult'](_0x574ac5){return de['credentialFromTaggedObject'](_0x574ac5);}static['credentialFromError'](_0x454948){return de['credentialFromTaggedObject'](_0x454948['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x21aaa2}){if(!_0x21aaa2||!('oauthAccessToken'in _0x21aaa2)||!_0x21aaa2['oauthAccessToken'])return null;try{return de['credential'](_0x21aaa2['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x2ce98b,_0x148dd7){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2ce98b,'oauthTokenSecret':_0x148dd7});}static['credentialFromResult'](_0x87a476){return fe['credentialFromTaggedObject'](_0x87a476);}static['credentialFromError'](_0x3164e4){return fe['credentialFromTaggedObject'](_0x3164e4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x12d286}){if(!_0x12d286)return null;const {oauthAccessToken:_0x7cfedd,oauthTokenSecret:_0x4a5a58}=_0x12d286;if(!_0x7cfedd||!_0x4a5a58)return null;try{return fe['credential'](_0x7cfedd,_0x4a5a58);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3cd14d,_0x4122f1){return Yt(_0x3cd14d,'POST','/v1/accounts:signUp',Re(_0x3cd14d,_0x4122f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x520f11){this['user']=_0x520f11['user'],this['providerId']=_0x520f11['providerId'],this['_tokenResponse']=_0x520f11['_tokenResponse'],this['operationType']=_0x520f11['operationType'];}static async['_fromIdTokenResponse'](_0x171c87,_0x2f247f,_0x31456b,_0x133ba8=!0x1){const _0x4bc339=await z['_fromIdTokenResponse'](_0x171c87,_0x31456b,_0x133ba8),_0x437f10=Ar(_0x31456b);return new Be({'user':_0x4bc339,'providerId':_0x437f10,'_tokenResponse':_0x31456b,'operationType':_0x2f247f});}static async['_forOperation'](_0xd9bf6a,_0x3a6670,_0xfa35db){await _0xd9bf6a['_updateTokensIfNecessary'](_0xfa35db,!0x0);const _0x32d4f2=Ar(_0xfa35db);return new Be({'user':_0xd9bf6a,'providerId':_0x32d4f2,'_tokenResponse':_0xfa35db,'operationType':_0x3a6670});}}function Ar(_0x49bf52){return _0x49bf52['providerId']?_0x49bf52['providerId']:'phoneNumber'in _0x49bf52?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x52ccdd,_0x3376cb,_0x57af8b,_0x45547b){super(_0x3376cb['code'],_0x3376cb['message']),this['operationType']=_0x57af8b,this['user']=_0x45547b,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x52ccdd['name'],'tenantId':_0x52ccdd['tenantId']??void 0x0,'_serverResponse':_0x3376cb['customData']['_serverResponse'],'operationType':_0x57af8b};}static['_fromErrorAndOperation'](_0x395574,_0x5a5f8a,_0x17952b,_0x156021){return new Rn(_0x395574,_0x5a5f8a,_0x17952b,_0x156021);}}function Fa(_0x32107d,_0x3ed512,_0x4f69f4,_0xe96335){return(_0x3ed512==='reauthenticate'?_0x4f69f4['_getReauthenticationResolver'](_0x32107d):_0x4f69f4['_getIdTokenResponse'](_0x32107d))['catch'](_0x5d2c1d=>{throw _0x5d2c1d['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x32107d,_0x5d2c1d,_0x3ed512,_0xe96335):_0x5d2c1d;});}async function jf(_0x4662f1,_0x50db42,_0x1703e4=!0x1){const _0x218672=await xt(_0x4662f1,_0x50db42['_linkToIdToken'](_0x4662f1['auth'],await _0x4662f1['getIdToken']()),_0x1703e4);return Be['_forOperation'](_0x4662f1,'link',_0x218672);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x412ee5,_0x5e5f92,_0xba81d9=!0x1){const {auth:_0x38b93c}=_0x412ee5;if(H(_0x38b93c['app']))return Promise['reject'](se(_0x38b93c));const _0x21ac13='reauthenticate';try{const _0x3c782d=await xt(_0x412ee5,Fa(_0x38b93c,_0x21ac13,_0x5e5f92,_0x412ee5),_0xba81d9);m(_0x3c782d['idToken'],_0x38b93c,'internal-error');const _0x558bdf=ws(_0x3c782d['idToken']);m(_0x558bdf,_0x38b93c,'internal-error');const {sub:_0x2264e6}=_0x558bdf;return m(_0x412ee5['uid']===_0x2264e6,_0x38b93c,'user-mismatch'),Be['_forOperation'](_0x412ee5,_0x21ac13,_0x3c782d);}catch(_0x434353){throw(_0x434353==null?void 0x0:_0x434353['code'])==='auth/user-not-found'&&K(_0x38b93c,'user-mismatch'),_0x434353;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0xf629fe,_0x105779,_0x756ee9=!0x1){if(H(_0xf629fe['app']))return Promise['reject'](se(_0xf629fe));const _0x405beb='signIn',_0x216560=await Fa(_0xf629fe,_0x405beb,_0x105779),_0x1e39db=await Be['_fromIdTokenResponse'](_0xf629fe,_0x405beb,_0x216560);return _0x756ee9||await _0xf629fe['_updateCurrentUser'](_0x1e39db['user']),_0x1e39db;}async function Yf(_0x25c243,_0x224c52){return Ua(qe(_0x25c243),_0x224c52);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x5a1987){const _0x490d54=qe(_0x5a1987);_0x490d54['_getPasswordPolicyInternal']()&&await _0x490d54['_updatePasswordPolicy']();}async function R_(_0x5064d3,_0x3a5c40,_0x75bc05){if(H(_0x5064d3['app']))return Promise['reject'](se(_0x5064d3));const _0x1f3048=qe(_0x5064d3),_0x85571c=await Oi(_0x1f3048,{'returnSecureToken':!0x0,'email':_0x3a5c40,'password':_0x75bc05,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x2584af=>{throw _0x2584af['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5064d3),_0x2584af;}),_0x21a01e=await Be['_fromIdTokenResponse'](_0x1f3048,'signIn',_0x85571c);return await _0x1f3048['_updateCurrentUser'](_0x21a01e['user']),_0x21a01e;}function A_(_0xa10405,_0x4aa12f,_0x294330){return H(_0xa10405['app'])?Promise['reject'](se(_0xa10405)):Yf(k(_0xa10405),ft['credential'](_0x4aa12f,_0x294330))['catch'](async _0x5a8a2d=>{throw _0x5a8a2d['code']==='auth/password-does-not-meet-requirements'&&Wa(_0xa10405),_0x5a8a2d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x31149d,_0x44207f){return k(_0x31149d)['setPersistence'](_0x44207f);}function Qf(_0x2341a6,_0x42310b,_0x1169c8,_0x1ef600){return k(_0x2341a6)['onIdTokenChanged'](_0x42310b,_0x1169c8,_0x1ef600);}function Jf(_0x3fbded,_0x1665c9,_0x1c660e){return k(_0x3fbded)['beforeAuthStateChanged'](_0x1665c9,_0x1c660e);}function N_(_0x205cee,_0x47a581,_0x1c6300,_0x46ff0b){return k(_0x205cee)['onAuthStateChanged'](_0x47a581,_0x1c6300,_0x46ff0b);}function P_(_0x32930e){return k(_0x32930e)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x476ea7,_0x1901d7){this['storageRetriever']=_0x476ea7,this['type']=_0x1901d7;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4c46ca,_0x549b5c){return this['storage']['setItem'](_0x4c46ca,JSON['stringify'](_0x549b5c)),Promise['resolve']();}['_get'](_0x924369){const _0x689be9=this['storage']['getItem'](_0x924369);return Promise['resolve'](_0x689be9?JSON['parse'](_0x689be9):null);}['_remove'](_0x1910e7){return this['storage']['removeItem'](_0x1910e7),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x35d7d2,_0x28aca5)=>this['onStorageEvent'](_0x35d7d2,_0x28aca5),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x6a1276){for(const _0x313968 of Object['keys'](this['listeners'])){const _0x56e3a5=this['storage']['getItem'](_0x313968),_0x1f890a=this['localCache'][_0x313968];_0x56e3a5!==_0x1f890a&&_0x6a1276(_0x313968,_0x1f890a,_0x56e3a5);}}['onStorageEvent'](_0x32b9bb,_0x4d72c3=!0x1){if(!_0x32b9bb['key']){this['forAllChangedKeys']((_0x595dd8,_0x29f3c3,_0x1ab4f0)=>{this['notifyListeners'](_0x595dd8,_0x1ab4f0);});return;}const _0x5ab3a6=_0x32b9bb['key'];_0x4d72c3?this['detachListener']():this['stopPolling']();const _0x295110=()=>{const _0x461caa=this['storage']['getItem'](_0x5ab3a6);!_0x4d72c3&&this['localCache'][_0x5ab3a6]===_0x461caa||this['notifyListeners'](_0x5ab3a6,_0x461caa);},_0x188caf=this['storage']['getItem'](_0x5ab3a6);If()&&_0x188caf!==_0x32b9bb['newValue']&&_0x32b9bb['newValue']!==_0x32b9bb['oldValue']?setTimeout(_0x295110,Zf):_0x295110();}['notifyListeners'](_0x320b88,_0x2496fe){this['localCache'][_0x320b88]=_0x2496fe;const _0x27cdc6=this['listeners'][_0x320b88];if(_0x27cdc6){for(const _0x25b6b8 of Array['from'](_0x27cdc6))_0x25b6b8(_0x2496fe&&JSON['parse'](_0x2496fe));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x222fe1,_0x1e0f7f,_0x32def5)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x222fe1,'oldValue':_0x1e0f7f,'newValue':_0x32def5}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x20cdae,_0x1ab7d8){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x20cdae]||(this['listeners'][_0x20cdae]=new Set(),this['localCache'][_0x20cdae]=this['storage']['getItem'](_0x20cdae)),this['listeners'][_0x20cdae]['add'](_0x1ab7d8);}['_removeListener'](_0x12b607,_0x47c7bc){this['listeners'][_0x12b607]&&(this['listeners'][_0x12b607]['delete'](_0x47c7bc),this['listeners'][_0x12b607]['size']===0x0&&delete this['listeners'][_0x12b607]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x56a264,_0x5c726b){await super['_set'](_0x56a264,_0x5c726b),this['localCache'][_0x56a264]=JSON['stringify'](_0x5c726b);}async['_get'](_0x4556bc){const _0x297e04=await super['_get'](_0x4556bc);return this['localCache'][_0x4556bc]=JSON['stringify'](_0x297e04),_0x297e04;}async['_remove'](_0x1a9303){await super['_remove'](_0x1a9303),delete this['localCache'][_0x1a9303];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1b8f79,_0x4e4171){}['_removeListener'](_0x15a633,_0x3cb619){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xe25bb4){return Promise['all'](_0xe25bb4['map'](async _0x2e5e69=>{try{return{'fulfilled':!0x0,'value':await _0x2e5e69};}catch(_0x2e377a){return{'fulfilled':!0x1,'reason':_0x2e377a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x974294){this['eventTarget']=_0x974294,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3e64d1){const _0x4030c4=this['receivers']['find'](_0x32fba8=>_0x32fba8['isListeningto'](_0x3e64d1));if(_0x4030c4)return _0x4030c4;const _0xe1a923=new jn(_0x3e64d1);return this['receivers']['push'](_0xe1a923),_0xe1a923;}['isListeningto'](_0x365019){return this['eventTarget']===_0x365019;}async['handleEvent'](_0x44382a){const _0x5dce53=_0x44382a,{eventId:_0x1e5746,eventType:_0xb18610,data:_0x53e13a}=_0x5dce53['data'],_0xee68c7=this['handlersMap'][_0xb18610];if(!(_0xee68c7!=null&&_0xee68c7['size']))return;_0x5dce53['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1e5746,'eventType':_0xb18610});const _0x35f44c=Array['from'](_0xee68c7)['map'](async _0x568a8c=>_0x568a8c(_0x5dce53['origin'],_0x53e13a)),_0x9db3ae=await tp(_0x35f44c);_0x5dce53['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1e5746,'eventType':_0xb18610,'response':_0x9db3ae});}['_subscribe'](_0x5b7cd3,_0x4e5497){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5b7cd3]||(this['handlersMap'][_0x5b7cd3]=new Set()),this['handlersMap'][_0x5b7cd3]['add'](_0x4e5497);}['_unsubscribe'](_0x115c2a,_0x3ec2bb){this['handlersMap'][_0x115c2a]&&_0x3ec2bb&&this['handlersMap'][_0x115c2a]['delete'](_0x3ec2bb),(!_0x3ec2bb||this['handlersMap'][_0x115c2a]['size']===0x0)&&delete this['handlersMap'][_0x115c2a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x3cf59c='',_0x310e9b=0xa){let _0x428c25='';for(let _0x98ce4e=0x0;_0x98ce4e<_0x310e9b;_0x98ce4e++)_0x428c25+=Math['floor'](Math['random']()*0xa);return _0x3cf59c+_0x428c25;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x172881){this['target']=_0x172881,this['handlers']=new Set();}['removeMessageHandler'](_0x3a7165){_0x3a7165['messageChannel']&&(_0x3a7165['messageChannel']['port1']['removeEventListener']('message',_0x3a7165['onMessage']),_0x3a7165['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3a7165);}async['_send'](_0x1fc1ca,_0x65b40b,_0x134c1c=0x32){const _0x1d590f=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1d590f)throw new Error('connection_unavailable');let _0x54d3ac,_0x13024c;return new Promise((_0x2cf014,_0x51427f)=>{const _0x4f25ee=bs('',0x14);_0x1d590f['port1']['start']();const _0x3f0005=setTimeout(()=>{_0x51427f(new Error('unsupported_event'));},_0x134c1c);_0x13024c={'messageChannel':_0x1d590f,'onMessage'(_0x55d720){const _0x19baba=_0x55d720;if(_0x19baba['data']['eventId']===_0x4f25ee)switch(_0x19baba['data']['status']){case'ack':clearTimeout(_0x3f0005),_0x54d3ac=setTimeout(()=>{_0x51427f(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x54d3ac),_0x2cf014(_0x19baba['data']['response']);break;default:clearTimeout(_0x3f0005),clearTimeout(_0x54d3ac),_0x51427f(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x13024c),_0x1d590f['port1']['addEventListener']('message',_0x13024c['onMessage']),this['target']['postMessage']({'eventType':_0x1fc1ca,'eventId':_0x4f25ee,'data':_0x65b40b},[_0x1d590f['port2']]);})['finally'](()=>{_0x13024c&&this['removeMessageHandler'](_0x13024c);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x30810b){X()['location']['href']=_0x30810b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0xf2417f;return((_0xf2417f=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xf2417f['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5ddd14){this['request']=_0x5ddd14;}['toPromise'](){return new Promise((_0x293879,_0xb16eee)=>{this['request']['addEventListener']('success',()=>{_0x293879(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xb16eee(this['request']['error']);});});}}function Kn(_0x54e591,_0x2f5f2a){return _0x54e591['transaction']([kn],_0x2f5f2a?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x1c8bc8=indexedDB['deleteDatabase'](qa);return new Jt(_0x1c8bc8)['toPromise']();}function ja(){const _0x2a3ace=indexedDB['open'](qa,ap);return new Promise((_0x32bbc7,_0x5bb327)=>{_0x2a3ace['addEventListener']('error',()=>{_0x5bb327(_0x2a3ace['error']);}),_0x2a3ace['addEventListener']('upgradeneeded',()=>{const _0xa8cfd2=_0x2a3ace['result'];try{_0xa8cfd2['createObjectStore'](kn,{'keyPath':za});}catch(_0x370aa2){_0x5bb327(_0x370aa2);}}),_0x2a3ace['addEventListener']('success',async()=>{const _0x4da8a7=_0x2a3ace['result'];_0x4da8a7['objectStoreNames']['contains'](kn)?_0x32bbc7(_0x4da8a7):(_0x4da8a7['close'](),await cp(),_0x32bbc7(await ja()));});});}async function kr(_0x373aff,_0x3ae074,_0x438352){const _0x14f4eb=Kn(_0x373aff,!0x0)['put']({[za]:_0x3ae074,'value':_0x438352});return new Jt(_0x14f4eb)['toPromise']();}async function lp(_0x198154,_0x1d5ca3){const _0x17fcec=Kn(_0x198154,!0x1)['get'](_0x1d5ca3),_0x309623=await new Jt(_0x17fcec)['toPromise']();return _0x309623===void 0x0?null:_0x309623['value'];}function Nr(_0x1be61b,_0x5c3284){const _0x348ecc=Kn(_0x1be61b,!0x0)['delete'](_0x5c3284);return new Jt(_0x348ecc)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x10b23f){let _0x58c256=0x0;for(;;)try{const _0x1a4d9d=await this['_openDb']();return await _0x10b23f(_0x1a4d9d);}catch(_0x3e0fd2){if(_0x58c256++>up)throw _0x3e0fd2;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0xa35815,_0x204b07)=>({'keyProcessed':(await this['_poll']())['includes'](_0x204b07['key'])})),this['receiver']['_subscribe']('ping',async(_0x5e5cfe,_0x118d34)=>['keyChanged']);}async['initializeSender'](){var _0x2ba26c,_0x2a08d4;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x42b03b=await this['sender']['_send']('ping',{},0x320);_0x42b03b&&(_0x2ba26c=_0x42b03b[0x0])!=null&&_0x2ba26c['fulfilled']&&(_0x2a08d4=_0x42b03b[0x0])!=null&&_0x2a08d4['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3b7c52){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3b7c52},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4c71b1=>{await kr(_0x4c71b1,An,'1'),await Nr(_0x4c71b1,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x39c2c1){this['pendingWrites']++;try{await _0x39c2c1();}finally{this['pendingWrites']--;}}async['_set'](_0x260e45,_0x315ce9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x7dddeb=>kr(_0x7dddeb,_0x260e45,_0x315ce9)),this['localCache'][_0x260e45]=_0x315ce9,this['notifyServiceWorker'](_0x260e45)));}async['_get'](_0x233abe){const _0x2dda2e=await this['_withRetries'](_0x407a43=>lp(_0x407a43,_0x233abe));return this['localCache'][_0x233abe]=_0x2dda2e,_0x2dda2e;}async['_remove'](_0x2f3aab){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1c78c5=>Nr(_0x1c78c5,_0x2f3aab)),delete this['localCache'][_0x2f3aab],this['notifyServiceWorker'](_0x2f3aab)));}async['_poll'](){const _0x353972=await this['_withRetries'](_0x5cf0f8=>{const _0x4620ea=Kn(_0x5cf0f8,!0x1)['getAll']();return new Jt(_0x4620ea)['toPromise']();});if(!_0x353972)return[];if(this['pendingWrites']!==0x0)return[];const _0xda37cb=[],_0x202f01=new Set();if(_0x353972['length']!==0x0){for(const {fbase_key:_0x39e1e0,value:_0x22fa53}of _0x353972)_0x202f01['add'](_0x39e1e0),JSON['stringify'](this['localCache'][_0x39e1e0])!==JSON['stringify'](_0x22fa53)&&(this['notifyListeners'](_0x39e1e0,_0x22fa53),_0xda37cb['push'](_0x39e1e0));}for(const _0x46867c of Object['keys'](this['localCache']))this['localCache'][_0x46867c]&&!_0x202f01['has'](_0x46867c)&&(this['notifyListeners'](_0x46867c,null),_0xda37cb['push'](_0x46867c));return _0xda37cb;}['notifyListeners'](_0xa26c47,_0x50177d){this['localCache'][_0xa26c47]=_0x50177d;const _0x1fe50b=this['listeners'][_0xa26c47];if(_0x1fe50b){for(const _0x26d987 of Array['from'](_0x1fe50b))_0x26d987(_0x50177d);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1b61f6,_0x42a836){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1b61f6]||(this['listeners'][_0x1b61f6]=new Set(),this['_get'](_0x1b61f6)),this['listeners'][_0x1b61f6]['add'](_0x42a836);}['_removeListener'](_0xfd885a,_0x30b4e4){this['listeners'][_0xfd885a]&&(this['listeners'][_0xfd885a]['delete'](_0x30b4e4),this['listeners'][_0xfd885a]['size']===0x0&&delete this['listeners'][_0xfd885a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x1b5ecc,_0x42bbd6){return _0x42bbd6?ne(_0x42bbd6):(m(_0x1b5ecc['_popupRedirectResolver'],_0x1b5ecc,'argument-error'),_0x1b5ecc['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x49782c){super('custom','custom'),this['params']=_0x49782c;}['_getIdTokenResponse'](_0xb09194){return Ze(_0xb09194,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1f4074,_0x4f2593){return Ze(_0x1f4074,this['_buildIdpRequest'](_0x4f2593));}['_getReauthenticationResolver'](_0x3c8e14){return Ze(_0x3c8e14,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x43e519){const _0x44cf9a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x43e519&&(_0x44cf9a['idToken']=_0x43e519),_0x44cf9a;}}function pp(_0x55bf46){return Ua(_0x55bf46['auth'],new Rs(_0x55bf46),_0x55bf46['bypassAuthState']);}function _p(_0x12c181){const {auth:_0x3d7623,user:_0x1be8fc}=_0x12c181;return m(_0x1be8fc,_0x3d7623,'internal-error'),Kf(_0x1be8fc,new Rs(_0x12c181),_0x12c181['bypassAuthState']);}async function gp(_0x226aad){const {auth:_0x46e71d,user:_0x5b96a0}=_0x226aad;return m(_0x5b96a0,_0x46e71d,'internal-error'),jf(_0x5b96a0,new Rs(_0x226aad),_0x226aad['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0xc1b4c7,_0x564391,_0x190f6a,_0x3500ab,_0x285c53=!0x1){this['auth']=_0xc1b4c7,this['resolver']=_0x190f6a,this['user']=_0x3500ab,this['bypassAuthState']=_0x285c53,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x564391)?_0x564391:[_0x564391];}['execute'](){return new Promise(async(_0x1e10d4,_0x48ccbc)=>{this['pendingPromise']={'resolve':_0x1e10d4,'reject':_0x48ccbc};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x24bbe0){this['reject'](_0x24bbe0);}});}async['onAuthEvent'](_0x39705c){const {urlResponse:_0x425943,sessionId:_0x5b186d,postBody:_0xff8dd2,tenantId:_0x2104e2,error:_0x8511fd,type:_0x45f2e4}=_0x39705c;if(_0x8511fd){this['reject'](_0x8511fd);return;}const _0x31af9b={'auth':this['auth'],'requestUri':_0x425943,'sessionId':_0x5b186d,'tenantId':_0x2104e2||void 0x0,'postBody':_0xff8dd2||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x45f2e4)(_0x31af9b));}catch(_0x47d3ba){this['reject'](_0x47d3ba);}}['onError'](_0x482ead){this['reject'](_0x482ead);}['getIdpTask'](_0x47ec75){switch(_0x47ec75){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x6262db){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x6262db),this['unregisterAndCleanUp']();}['reject'](_0x29f048){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x29f048),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x43c474,_0x12546c,_0x31b90d,_0x6457ed,_0x81ac6f){super(_0x43c474,_0x12546c,_0x6457ed,_0x81ac6f),this['provider']=_0x31b90d,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x4f7f7c=await this['execute']();return m(_0x4f7f7c,this['auth'],'internal-error'),_0x4f7f7c;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x49f91c=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x49f91c),this['authWindow']['associatedEvent']=_0x49f91c,this['resolver']['_originValidation'](this['auth'])['catch'](_0xe5fd58=>{this['reject'](_0xe5fd58);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2c06f4=>{_0x2c06f4||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4cb3af;return((_0x4cb3af=this['authWindow'])==null?void 0x0:_0x4cb3af['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xbed0e0=()=>{var _0x23520c,_0x437827;if((_0x437827=(_0x23520c=this['authWindow'])==null?void 0x0:_0x23520c['window'])!=null&&_0x437827['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xbed0e0,mp['get']());};_0xbed0e0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x712627,_0x3c06ce,_0x54eaca=!0x1){super(_0x712627,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3c06ce,void 0x0,_0x54eaca),this['eventId']=null;}async['execute'](){let _0x33b6b2=rn['get'](this['auth']['_key']());if(!_0x33b6b2){try{const _0x58e9fd=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x33b6b2=()=>Promise['resolve'](_0x58e9fd);}catch(_0x1ca342){_0x33b6b2=()=>Promise['reject'](_0x1ca342);}rn['set'](this['auth']['_key'](),_0x33b6b2);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x33b6b2();}async['onAuthEvent'](_0x235bae){if(_0x235bae['type']==='signInViaRedirect')return super['onAuthEvent'](_0x235bae);if(_0x235bae['type']==='unknown'){this['resolve'](null);return;}if(_0x235bae['eventId']){const _0x3e5d94=await this['auth']['_redirectUserForId'](_0x235bae['eventId']);if(_0x3e5d94)return this['user']=_0x3e5d94,super['onAuthEvent'](_0x235bae);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x354e11,_0x2e696b){const _0x33dd51=Cp(_0x2e696b),_0x307343=wp(_0x354e11);if(!await _0x307343['_isAvailable']())return!0x1;const _0x5bea57=await _0x307343['_get'](_0x33dd51)==='true';return await _0x307343['_remove'](_0x33dd51),_0x5bea57;}function Ip(_0x238b36,_0x3c8783){rn['set'](_0x238b36['_key'](),_0x3c8783);}function wp(_0x52617e){return ne(_0x52617e['_redirectPersistence']);}function Cp(_0x1435b1){return sn(yp,_0x1435b1['config']['apiKey'],_0x1435b1['name']);}async function Tp(_0xdf1881,_0x25f76a,_0x1ae3d9=!0x1){if(H(_0xdf1881['app']))return Promise['reject'](se(_0xdf1881));const _0x24a7ea=qe(_0xdf1881),_0x3c6824=fp(_0x24a7ea,_0x25f76a),_0x1bc072=await new vp(_0x24a7ea,_0x3c6824,_0x1ae3d9)['execute']();return _0x1bc072&&!_0x1ae3d9&&(delete _0x1bc072['user']['_redirectEventId'],await _0x24a7ea['_persistUserIfCurrent'](_0x1bc072['user']),await _0x24a7ea['_setRedirectUser'](null,_0x25f76a)),_0x1bc072;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4f7903){this['auth']=_0x4f7903,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3ec3fb){this['consumers']['add'](_0x3ec3fb),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3ec3fb)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3ec3fb),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1c526c){this['consumers']['delete'](_0x1c526c);}['onEvent'](_0x5e6e83){if(this['hasEventBeenHandled'](_0x5e6e83))return!0x1;let _0x4d182f=!0x1;return this['consumers']['forEach'](_0x1c1075=>{this['isEventForConsumer'](_0x5e6e83,_0x1c1075)&&(_0x4d182f=!0x0,this['sendToConsumer'](_0x5e6e83,_0x1c1075),this['saveEventToCache'](_0x5e6e83));}),this['hasHandledPotentialRedirect']||!Rp(_0x5e6e83)||(this['hasHandledPotentialRedirect']=!0x0,_0x4d182f||(this['queuedRedirectEvent']=_0x5e6e83,_0x4d182f=!0x0)),_0x4d182f;}['sendToConsumer'](_0x4e276c,_0x43442d){var _0x393df2;if(_0x4e276c['error']&&!Qa(_0x4e276c)){const _0x492602=((_0x393df2=_0x4e276c['error']['code'])==null?void 0x0:_0x393df2['split']('auth/')[0x1])||'internal-error';_0x43442d['onError'](J(this['auth'],_0x492602));}else _0x43442d['onAuthEvent'](_0x4e276c);}['isEventForConsumer'](_0x5238e1,_0x3f635c){const _0x350410=_0x3f635c['eventId']===null||!!_0x5238e1['eventId']&&_0x5238e1['eventId']===_0x3f635c['eventId'];return _0x3f635c['filter']['includes'](_0x5238e1['type'])&&_0x350410;}['hasEventBeenHandled'](_0x218975){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x218975));}['saveEventToCache'](_0x3f9b8d){this['cachedEventUids']['add'](Pr(_0x3f9b8d)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0xeb08ab){return[_0xeb08ab['type'],_0xeb08ab['eventId'],_0xeb08ab['sessionId'],_0xeb08ab['tenantId']]['filter'](_0x4d45e3=>_0x4d45e3)['join']('-');}function Qa({type:_0x465e6b,error:_0x27a84b}){return _0x465e6b==='unknown'&&(_0x27a84b==null?void 0x0:_0x27a84b['code'])==='auth/no-auth-event';}function Rp(_0x25d8e3){switch(_0x25d8e3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x25d8e3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x3e8078,_0x1b216a={}){return Ae(_0x3e8078,'GET','/v1/projects',_0x1b216a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0xca3645){if(_0xca3645['config']['emulator'])return;const {authorizedDomains:_0x489b7e}=await Ap(_0xca3645);for(const _0x44b45c of _0x489b7e)try{if(Op(_0x44b45c))return;}catch{}K(_0xca3645,'unauthorized-domain');}function Op(_0x299a9c){const _0x59d503=Ni(),{protocol:_0x4bc7ea,hostname:_0x41ed5f}=new URL(_0x59d503);if(_0x299a9c['startsWith']('chrome-extension://')){const _0x21d2ec=new URL(_0x299a9c);return _0x21d2ec['hostname']===''&&_0x41ed5f===''?_0x4bc7ea==='chrome-extension:'&&_0x299a9c['replace']('chrome-extension://','')===_0x59d503['replace']('chrome-extension://',''):_0x4bc7ea==='chrome-extension:'&&_0x21d2ec['hostname']===_0x41ed5f;}if(!Np['test'](_0x4bc7ea))return!0x1;if(kp['test'](_0x299a9c))return _0x41ed5f===_0x299a9c;const _0x5d91bf=_0x299a9c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5d91bf+'|'+_0x5d91bf+')$','i')['test'](_0x41ed5f);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x5a53a0=X()['___jsl'];if(_0x5a53a0!=null&&_0x5a53a0['H']){for(const _0x22a021 of Object['keys'](_0x5a53a0['H']))if(_0x5a53a0['H'][_0x22a021]['r']=_0x5a53a0['H'][_0x22a021]['r']||[],_0x5a53a0['H'][_0x22a021]['L']=_0x5a53a0['H'][_0x22a021]['L']||[],_0x5a53a0['H'][_0x22a021]['r']=[..._0x5a53a0['H'][_0x22a021]['L']],_0x5a53a0['CP']){for(let _0x53d2a2=0x0;_0x53d2a2<_0x5a53a0['CP']['length'];_0x53d2a2++)_0x5a53a0['CP'][_0x53d2a2]=null;}}}function Mp(_0x25549b){return new Promise((_0x40896f,_0x28c215)=>{var _0x361e49,_0x2b5f7b,_0x43779d;function _0x160190(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x40896f(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x28c215(J(_0x25549b,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x2b5f7b=(_0x361e49=X()['gapi'])==null?void 0x0:_0x361e49['iframes'])!=null&&_0x2b5f7b['Iframe'])_0x40896f(gapi['iframes']['getContext']());else{if((_0x43779d=X()['gapi'])!=null&&_0x43779d['load'])_0x160190();else{const _0x5588b8=Nf('iframefcb');return X()[_0x5588b8]=()=>{gapi['load']?_0x160190():_0x28c215(J(_0x25549b,'network-request-failed'));},Da(kf()+'?onload='+_0x5588b8)['catch'](_0x4ae6c5=>_0x28c215(_0x4ae6c5));}}})['catch'](_0xebd9fd=>{throw on=null,_0xebd9fd;});}let on=null;function Lp(_0xb57e40){return on=on||Mp(_0xb57e40),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x484d2c){const _0x408581=_0x484d2c['config'];m(_0x408581['authDomain'],_0x484d2c,'auth-domain-config-required');const _0x18c2ed=_0x408581['emulator']?Is(_0x408581,Up):'https://'+_0x484d2c['config']['authDomain']+'/'+Fp,_0x159cc7={'apiKey':_0x408581['apiKey'],'appName':_0x484d2c['name'],'v':ct},_0x243414=Bp['get'](_0x484d2c['config']['apiHost']);_0x243414&&(_0x159cc7['eid']=_0x243414);const _0x46a706=_0x484d2c['_getFrameworks']();return _0x46a706['length']&&(_0x159cc7['fw']=_0x46a706['join'](',')),_0x18c2ed+'?'+at(_0x159cc7)['slice'](0x1);}async function Hp(_0xb9014a){const _0x45998a=await Lp(_0xb9014a),_0x453655=X()['gapi'];return m(_0x453655,_0xb9014a,'internal-error'),_0x45998a['open']({'where':document['body'],'url':Vp(_0xb9014a),'messageHandlersFilter':_0x453655['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x1a3cbe=>new Promise(async(_0x4f4a43,_0x46121e)=>{await _0x1a3cbe['restyle']({'setHideOnLeave':!0x1});const _0x24eea5=J(_0xb9014a,'network-request-failed'),_0x4a0aeb=X()['setTimeout'](()=>{_0x46121e(_0x24eea5);},xp['get']());function _0x5696b8(){X()['clearTimeout'](_0x4a0aeb),_0x4f4a43(_0x1a3cbe);}_0x1a3cbe['ping'](_0x5696b8)['then'](_0x5696b8,()=>{_0x46121e(_0x24eea5);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xa4993){this['window']=_0xa4993,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x40f617,_0x2bdfb6,_0x26438b,_0x16dca8=Gp,_0x24a680=qp){const _0x70d2e7=Math['max']((window['screen']['availHeight']-_0x24a680)/0x2,0x0)['toString'](),_0x11fa5d=Math['max']((window['screen']['availWidth']-_0x16dca8)/0x2,0x0)['toString']();let _0x20bcc3='';const _0x38c663={...$p,'width':_0x16dca8['toString'](),'height':_0x24a680['toString'](),'top':_0x70d2e7,'left':_0x11fa5d},_0x405800=W()['toLowerCase']();_0x26438b&&(_0x20bcc3=ba(_0x405800)?zp:_0x26438b),Ta(_0x405800)&&(_0x2bdfb6=_0x2bdfb6||jp,_0x38c663['scrollbars']='yes');const _0x1038b1=Object['entries'](_0x38c663)['reduce']((_0x44d648,[_0x48bec1,_0x417810])=>''+_0x44d648+_0x48bec1+'='+_0x417810+',','');if(Ef(_0x405800)&&_0x20bcc3!=='_self')return Yp(_0x2bdfb6||'',_0x20bcc3),new Dr(null);const _0xb4677a=window['open'](_0x2bdfb6||'',_0x20bcc3,_0x1038b1);m(_0xb4677a,_0x40f617,'popup-blocked');try{_0xb4677a['focus']();}catch{}return new Dr(_0xb4677a);}function Yp(_0x385c14,_0x1a73a0){const _0x50f97f=document['createElement']('a');_0x50f97f['href']=_0x385c14,_0x50f97f['target']=_0x1a73a0;const _0x7aff6c=document['createEvent']('MouseEvent');_0x7aff6c['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x50f97f['dispatchEvent'](_0x7aff6c);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x4f4836,_0x5bc796,_0x250816,_0x3d114d,_0x4ced4d,_0x138694){m(_0x4f4836['config']['authDomain'],_0x4f4836,'auth-domain-config-required'),m(_0x4f4836['config']['apiKey'],_0x4f4836,'invalid-api-key');const _0x365950={'apiKey':_0x4f4836['config']['apiKey'],'appName':_0x4f4836['name'],'authType':_0x250816,'redirectUrl':_0x3d114d,'v':ct,'eventId':_0x4ced4d};if(_0x5bc796 instanceof xa){_0x5bc796['setDefaultLanguage'](_0x4f4836['languageCode']),_0x365950['providerId']=_0x5bc796['providerId']||'',hi(_0x5bc796['getCustomParameters']())||(_0x365950['customParameters']=JSON['stringify'](_0x5bc796['getCustomParameters']()));for(const [_0x61434b,_0x2e88f3]of Object['entries']({}))_0x365950[_0x61434b]=_0x2e88f3;}if(_0x5bc796 instanceof Qt){const _0x389e77=_0x5bc796['getScopes']()['filter'](_0x1f6a52=>_0x1f6a52!=='');_0x389e77['length']>0x0&&(_0x365950['scopes']=_0x389e77['join'](','));}_0x4f4836['tenantId']&&(_0x365950['tid']=_0x4f4836['tenantId']);const _0x527468=_0x365950;for(const _0x5278f0 of Object['keys'](_0x527468))_0x527468[_0x5278f0]===void 0x0&&delete _0x527468[_0x5278f0];const _0x1de4da=await _0x4f4836['_getAppCheckToken'](),_0x236113=_0x1de4da?'#'+Xp+'='+encodeURIComponent(_0x1de4da):'';return Zp(_0x4f4836)+'?'+at(_0x527468)['slice'](0x1)+_0x236113;}function Zp({config:_0x16210b}){return _0x16210b['emulator']?Is(_0x16210b,Jp):'https://'+_0x16210b['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x5c3e82,_0x4b2766,_0x25a91e,_0x268834){var _0xe186c6;ae((_0xe186c6=this['eventManagers'][_0x5c3e82['_key']()])==null?void 0x0:_0xe186c6['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xbc28a4=await Mr(_0x5c3e82,_0x4b2766,_0x25a91e,Ni(),_0x268834);return Kp(_0x5c3e82,_0xbc28a4,bs());}async['_openRedirect'](_0x17268c,_0x191002,_0x323139,_0x5c5dfc){await this['_originValidation'](_0x17268c);const _0x2763be=await Mr(_0x17268c,_0x191002,_0x323139,Ni(),_0x5c5dfc);return ip(_0x2763be),new Promise(()=>{});}['_initialize'](_0x52cc57){const _0x35b4c8=_0x52cc57['_key']();if(this['eventManagers'][_0x35b4c8]){const {manager:_0x3ca6b5,promise:_0x4f8bb1}=this['eventManagers'][_0x35b4c8];return _0x3ca6b5?Promise['resolve'](_0x3ca6b5):(ae(_0x4f8bb1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4f8bb1);}const _0x4079b2=this['initAndGetManager'](_0x52cc57);return this['eventManagers'][_0x35b4c8]={'promise':_0x4079b2},_0x4079b2['catch'](()=>{delete this['eventManagers'][_0x35b4c8];}),_0x4079b2;}async['initAndGetManager'](_0x2b059e){const _0xc891df=await Hp(_0x2b059e),_0x11dfd9=new bp(_0x2b059e);return _0xc891df['register']('authEvent',_0x3843e5=>(m(_0x3843e5==null?void 0x0:_0x3843e5['authEvent'],_0x2b059e,'invalid-auth-event'),{'status':_0x11dfd9['onEvent'](_0x3843e5['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2b059e['_key']()]={'manager':_0x11dfd9},this['iframes'][_0x2b059e['_key']()]=_0xc891df,_0x11dfd9;}['_isIframeWebStorageSupported'](_0x18d663,_0x20be6c){this['iframes'][_0x18d663['_key']()]['send'](li,{'type':li},_0x2b0702=>{var _0x174648;const _0x3d5d1e=(_0x174648=_0x2b0702==null?void 0x0:_0x2b0702[0x0])==null?void 0x0:_0x174648[li];_0x3d5d1e!==void 0x0&&_0x20be6c(!!_0x3d5d1e),K(_0x18d663,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x133c1c){const _0x265a48=_0x133c1c['_key']();return this['originValidationPromises'][_0x265a48]||(this['originValidationPromises'][_0x265a48]=Pp(_0x133c1c)),this['originValidationPromises'][_0x265a48];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x39b39b){this['auth']=_0x39b39b,this['internalListeners']=new Map();}['getUid'](){var _0x5f0700;return this['assertAuthConfigured'](),((_0x5f0700=this['auth']['currentUser'])==null?void 0x0:_0x5f0700['uid'])||null;}async['getToken'](_0x538b5a){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x538b5a)}:null;}['addAuthTokenListener'](_0x1d31bd){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1d31bd))return;const _0x100312=this['auth']['onIdTokenChanged'](_0xe2a71f=>{_0x1d31bd((_0xe2a71f==null?void 0x0:_0xe2a71f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1d31bd,_0x100312),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2e85ca){this['assertAuthConfigured']();const _0x139d7c=this['internalListeners']['get'](_0x2e85ca);_0x139d7c&&(this['internalListeners']['delete'](_0x2e85ca),_0x139d7c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x51ef2f){switch(_0x51ef2f){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x5c90e8){et(new Me('auth',(_0x555ef3,{options:_0x51f816})=>{const _0x5c258d=_0x555ef3['getProvider']('app')['getImmediate'](),_0x598e07=_0x555ef3['getProvider']('heartbeat'),_0x3cc2f7=_0x555ef3['getProvider']('app-check-internal'),{apiKey:_0x33ad79,authDomain:_0x54c94d}=_0x5c258d['options'];m(_0x33ad79&&!_0x33ad79['includes'](':'),'invalid-api-key',{'appName':_0x5c258d['name']});const _0x4e24a8={'apiKey':_0x33ad79,'authDomain':_0x54c94d,'clientPlatform':_0x5c90e8,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x5c90e8)},_0x47c326=new bf(_0x5c258d,_0x598e07,_0x3cc2f7,_0x4e24a8);return Lf(_0x47c326,_0x51f816),_0x47c326;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x50284d,_0x579076,_0x3adf37)=>{_0x50284d['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3d99f1=>{const _0xf45d04=qe(_0x3d99f1['getProvider']('auth')['getImmediate']());return(_0x4fde6b=>new n_(_0x4fde6b))(_0xf45d04);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x5c90e8)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x38674b=>async _0x54f2d7=>{const _0xf0e790=_0x54f2d7&&await _0x54f2d7['getIdTokenResult'](),_0x541251=_0xf0e790&&(new Date()['getTime']()-Date['parse'](_0xf0e790['issuedAtTime']))/0x3e8;if(_0x541251&&_0x541251>o_)return;const _0x5d0784=_0xf0e790==null?void 0x0:_0xf0e790['token'];Fr!==_0x5d0784&&(Fr=_0x5d0784,await fetch(_0x38674b,{'method':_0x5d0784?'POST':'DELETE','headers':_0x5d0784?{'Authorization':'Bearer\x20'+_0x5d0784}:{}}));};function O_(_0x105352=Qr()){const _0x3b89c8=Ui(_0x105352,'auth');if(_0x3b89c8['isInitialized']())return _0x3b89c8['getImmediate']();const _0x37a4ef=Mf(_0x105352,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x5b6970=Gr('authTokenSyncURL');if(_0x5b6970&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x8cc9f5=new URL(_0x5b6970,location['origin']);if(location['origin']===_0x8cc9f5['origin']){const _0x502c9b=a_(_0x8cc9f5['toString']());Jf(_0x37a4ef,_0x502c9b,()=>_0x502c9b(_0x37a4ef['currentUser'])),Qf(_0x37a4ef,_0x2c7957=>_0x502c9b(_0x2c7957));}}const _0x1c3faa=Hr('auth');return _0x1c3faa&&xf(_0x37a4ef,'http://'+_0x1c3faa),_0x37a4ef;}function c_(){var _0x5a7529;return((_0x5a7529=document['getElementsByTagName']('head'))==null?void 0x0:_0x5a7529[0x0])??document;}Rf({'loadJS'(_0x1808fa){return new Promise((_0x4cab08,_0x5a2cd2)=>{const _0x3a103e=document['createElement']('script');_0x3a103e['setAttribute']('src',_0x1808fa),_0x3a103e['onload']=_0x4cab08,_0x3a103e['onerror']=_0x3f0db5=>{const _0x534254=J('internal-error');_0x534254['customData']=_0x3f0db5,_0x5a2cd2(_0x534254);},_0x3a103e['type']='text/javascript',_0x3a103e['charset']='UTF-8',c_()['appendChild'](_0x3a103e);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};