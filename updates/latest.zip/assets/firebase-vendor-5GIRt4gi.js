const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x41c80f,_0x1658e4){if(!_0x41c80f)throw ot(_0x1658e4);},ot=function(_0x12dd2b){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x12dd2b);},Wr=function(_0x415f12){const _0x54ffc9=[];let _0x297a58=0x0;for(let _0x3f2f3c=0x0;_0x3f2f3c<_0x415f12['length'];_0x3f2f3c++){let _0x51f37d=_0x415f12['charCodeAt'](_0x3f2f3c);_0x51f37d<0x80?_0x54ffc9[_0x297a58++]=_0x51f37d:_0x51f37d<0x800?(_0x54ffc9[_0x297a58++]=_0x51f37d>>0x6|0xc0,_0x54ffc9[_0x297a58++]=_0x51f37d&0x3f|0x80):(_0x51f37d&0xfc00)===0xd800&&_0x3f2f3c+0x1<_0x415f12['length']&&(_0x415f12['charCodeAt'](_0x3f2f3c+0x1)&0xfc00)===0xdc00?(_0x51f37d=0x10000+((_0x51f37d&0x3ff)<<0xa)+(_0x415f12['charCodeAt'](++_0x3f2f3c)&0x3ff),_0x54ffc9[_0x297a58++]=_0x51f37d>>0x12|0xf0,_0x54ffc9[_0x297a58++]=_0x51f37d>>0xc&0x3f|0x80,_0x54ffc9[_0x297a58++]=_0x51f37d>>0x6&0x3f|0x80,_0x54ffc9[_0x297a58++]=_0x51f37d&0x3f|0x80):(_0x54ffc9[_0x297a58++]=_0x51f37d>>0xc|0xe0,_0x54ffc9[_0x297a58++]=_0x51f37d>>0x6&0x3f|0x80,_0x54ffc9[_0x297a58++]=_0x51f37d&0x3f|0x80);}return _0x54ffc9;},Za=function(_0x43345e){const _0x4c3e37=[];let _0x294f27=0x0,_0x1ae819=0x0;for(;_0x294f27<_0x43345e['length'];){const _0x1cf7cb=_0x43345e[_0x294f27++];if(_0x1cf7cb<0x80)_0x4c3e37[_0x1ae819++]=String['fromCharCode'](_0x1cf7cb);else{if(_0x1cf7cb>0xbf&&_0x1cf7cb<0xe0){const _0xaa14f6=_0x43345e[_0x294f27++];_0x4c3e37[_0x1ae819++]=String['fromCharCode']((_0x1cf7cb&0x1f)<<0x6|_0xaa14f6&0x3f);}else{if(_0x1cf7cb>0xef&&_0x1cf7cb<0x16d){const _0x233548=_0x43345e[_0x294f27++],_0x1a3c55=_0x43345e[_0x294f27++],_0x220062=_0x43345e[_0x294f27++],_0x5c0f80=((_0x1cf7cb&0x7)<<0x12|(_0x233548&0x3f)<<0xc|(_0x1a3c55&0x3f)<<0x6|_0x220062&0x3f)-0x10000;_0x4c3e37[_0x1ae819++]=String['fromCharCode'](0xd800+(_0x5c0f80>>0xa)),_0x4c3e37[_0x1ae819++]=String['fromCharCode'](0xdc00+(_0x5c0f80&0x3ff));}else{const _0x311d02=_0x43345e[_0x294f27++],_0x4d48cd=_0x43345e[_0x294f27++];_0x4c3e37[_0x1ae819++]=String['fromCharCode']((_0x1cf7cb&0xf)<<0xc|(_0x311d02&0x3f)<<0x6|_0x4d48cd&0x3f);}}}}return _0x4c3e37['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xa88d8f,_0x599358){if(!Array['isArray'](_0xa88d8f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x71c31=_0x599358?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x343c83=[];for(let _0x56bd45=0x0;_0x56bd45<_0xa88d8f['length'];_0x56bd45+=0x3){const _0x1b9f38=_0xa88d8f[_0x56bd45],_0x1cb599=_0x56bd45+0x1<_0xa88d8f['length'],_0x205409=_0x1cb599?_0xa88d8f[_0x56bd45+0x1]:0x0,_0x599b6d=_0x56bd45+0x2<_0xa88d8f['length'],_0x2505a8=_0x599b6d?_0xa88d8f[_0x56bd45+0x2]:0x0,_0x4363c2=_0x1b9f38>>0x2,_0x1695f5=(_0x1b9f38&0x3)<<0x4|_0x205409>>0x4;let _0x5c1658=(_0x205409&0xf)<<0x2|_0x2505a8>>0x6,_0x5a1e38=_0x2505a8&0x3f;_0x599b6d||(_0x5a1e38=0x40,_0x1cb599||(_0x5c1658=0x40)),_0x343c83['push'](_0x71c31[_0x4363c2],_0x71c31[_0x1695f5],_0x71c31[_0x5c1658],_0x71c31[_0x5a1e38]);}return _0x343c83['join']('');},'encodeString'(_0x17494e,_0x1b8f25){return this['HAS_NATIVE_SUPPORT']&&!_0x1b8f25?btoa(_0x17494e):this['encodeByteArray'](Wr(_0x17494e),_0x1b8f25);},'decodeString'(_0x45e919,_0x1d60d7){return this['HAS_NATIVE_SUPPORT']&&!_0x1d60d7?atob(_0x45e919):Za(this['decodeStringToByteArray'](_0x45e919,_0x1d60d7));},'decodeStringToByteArray'(_0x5cc36b,_0x1957ca){this['init_']();const _0x289255=_0x1957ca?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4ff349=[];for(let _0x50a09d=0x0;_0x50a09d<_0x5cc36b['length'];){const _0x4624ae=_0x289255[_0x5cc36b['charAt'](_0x50a09d++)],_0x363b7a=_0x50a09d<_0x5cc36b['length']?_0x289255[_0x5cc36b['charAt'](_0x50a09d)]:0x0;++_0x50a09d;const _0x263399=_0x50a09d<_0x5cc36b['length']?_0x289255[_0x5cc36b['charAt'](_0x50a09d)]:0x40;++_0x50a09d;const _0x156548=_0x50a09d<_0x5cc36b['length']?_0x289255[_0x5cc36b['charAt'](_0x50a09d)]:0x40;if(++_0x50a09d,_0x4624ae==null||_0x363b7a==null||_0x263399==null||_0x156548==null)throw new ec();const _0x1a6676=_0x4624ae<<0x2|_0x363b7a>>0x4;if(_0x4ff349['push'](_0x1a6676),_0x263399!==0x40){const _0x1129a9=_0x363b7a<<0x4&0xf0|_0x263399>>0x2;if(_0x4ff349['push'](_0x1129a9),_0x156548!==0x40){const _0x29b5bf=_0x263399<<0x6&0xc0|_0x156548;_0x4ff349['push'](_0x29b5bf);}}}return _0x4ff349;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x196429=0x0;_0x196429<this['ENCODED_VALS']['length'];_0x196429++)this['byteToCharMap_'][_0x196429]=this['ENCODED_VALS']['charAt'](_0x196429),this['charToByteMap_'][this['byteToCharMap_'][_0x196429]]=_0x196429,this['byteToCharMapWebSafe_'][_0x196429]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x196429),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x196429]]=_0x196429,_0x196429>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x196429)]=_0x196429,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x196429)]=_0x196429);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x8894c8){const _0x419cb3=Wr(_0x8894c8);return Di['encodeByteArray'](_0x419cb3,!0x0);},an=function(_0x2c1f05){return Br(_0x2c1f05)['replace'](/\./g,'');},cn=function(_0x9f1a29){try{return Di['decodeString'](_0x9f1a29,!0x0);}catch(_0x30b90d){console['error']('base64Decode\x20failed:\x20',_0x30b90d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x21b9a8){return Vr(void 0x0,_0x21b9a8);}function Vr(_0x72807e,_0x1b237a){if(!(_0x1b237a instanceof Object))return _0x1b237a;switch(_0x1b237a['constructor']){case Date:const _0x512feb=_0x1b237a;return new Date(_0x512feb['getTime']());case Object:_0x72807e===void 0x0&&(_0x72807e={});break;case Array:_0x72807e=[];break;default:return _0x1b237a;}for(const _0x2a90c9 in _0x1b237a)!_0x1b237a['hasOwnProperty'](_0x2a90c9)||!nc(_0x2a90c9)||(_0x72807e[_0x2a90c9]=Vr(_0x72807e[_0x2a90c9],_0x1b237a[_0x2a90c9]));return _0x72807e;}function nc(_0x2bacd6){return _0x2bacd6!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x4533a8=As['__FIREBASE_DEFAULTS__'];if(_0x4533a8)return JSON['parse'](_0x4533a8);},oc=()=>{if(typeof document>'u')return;let _0x201635;try{_0x201635=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x51949e=_0x201635&&cn(_0x201635[0x1]);return _0x51949e&&JSON['parse'](_0x51949e);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x215fd4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x215fd4);return;}},Hr=_0x3c30c3=>{var _0xa48abd,_0x4ac731;return(_0x4ac731=(_0xa48abd=Mi())==null?void 0x0:_0xa48abd['emulatorHosts'])==null?void 0x0:_0x4ac731[_0x3c30c3];},ac=_0x26f878=>{const _0x31ba4a=Hr(_0x26f878);if(!_0x31ba4a)return;const _0x1d6d1f=_0x31ba4a['lastIndexOf'](':');if(_0x1d6d1f<=0x0||_0x1d6d1f+0x1===_0x31ba4a['length'])throw new Error('Invalid\x20host\x20'+_0x31ba4a+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x44a48c=parseInt(_0x31ba4a['substring'](_0x1d6d1f+0x1),0xa);return _0x31ba4a[0x0]==='['?[_0x31ba4a['substring'](0x1,_0x1d6d1f-0x1),_0x44a48c]:[_0x31ba4a['substring'](0x0,_0x1d6d1f),_0x44a48c];},$r=()=>{var _0x1d4c0f;return(_0x1d4c0f=Mi())==null?void 0x0:_0x1d4c0f['config'];},Gr=_0x2d3f07=>{var _0x6723fc;return(_0x6723fc=Mi())==null?void 0x0:_0x6723fc['_'+_0x2d3f07];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4177ca,_0x3b862c)=>{this['resolve']=_0x4177ca,this['reject']=_0x3b862c;});}['wrapCallback'](_0x10212a){return(_0x3fc579,_0x41d9b2)=>{_0x3fc579?this['reject'](_0x3fc579):this['resolve'](_0x41d9b2),typeof _0x10212a=='function'&&(this['promise']['catch'](()=>{}),_0x10212a['length']===0x1?_0x10212a(_0x3fc579):_0x10212a(_0x3fc579,_0x41d9b2));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x5c4b69,_0x39e394){if(_0x5c4b69['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x6c3837={'alg':'none','type':'JWT'},_0x2f593c=_0x39e394||'demo-project',_0x118ff6=_0x5c4b69['iat']||0x0,_0x4c1a5e=_0x5c4b69['sub']||_0x5c4b69['user_id'];if(!_0x4c1a5e)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3530db={'iss':'https://securetoken.google.com/'+_0x2f593c,'aud':_0x2f593c,'iat':_0x118ff6,'exp':_0x118ff6+0xe10,'auth_time':_0x118ff6,'sub':_0x4c1a5e,'user_id':_0x4c1a5e,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5c4b69};return[an(JSON['stringify'](_0x6c3837)),an(JSON['stringify'](_0x3530db)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x5dfd19=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5dfd19=='object'&&_0x5dfd19['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1e18ff=W();return _0x1e18ff['indexOf']('MSIE\x20')>=0x0||_0x1e18ff['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4a95a7,_0x772813)=>{try{let _0x30c511=!0x0;const _0x100c59='validate-browser-context-for-indexeddb-analytics-module',_0x52bde5=self['indexedDB']['open'](_0x100c59);_0x52bde5['onsuccess']=()=>{_0x52bde5['result']['close'](),_0x30c511||self['indexedDB']['deleteDatabase'](_0x100c59),_0x4a95a7(!0x0);},_0x52bde5['onupgradeneeded']=()=>{_0x30c511=!0x1;},_0x52bde5['onerror']=()=>{var _0xd80b66;_0x772813(((_0xd80b66=_0x52bde5['error'])==null?void 0x0:_0xd80b66['message'])||'');};}catch(_0x4ae1dd){_0x772813(_0x4ae1dd);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x427935,_0x51ebf7,_0x145dbf){super(_0x51ebf7),this['code']=_0x427935,this['customData']=_0x145dbf,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x400e6a,_0x2c38ae,_0x20541e){this['service']=_0x400e6a,this['serviceName']=_0x2c38ae,this['errors']=_0x20541e;}['create'](_0x3323bd,..._0x9d53e8){const _0x7ce27c=_0x9d53e8[0x0]||{},_0x22220c=this['service']+'/'+_0x3323bd,_0x92bc1a=this['errors'][_0x3323bd],_0x380999=_0x92bc1a?gc(_0x92bc1a,_0x7ce27c):'Error',_0x50a244=this['serviceName']+':\x20'+_0x380999+'\x20('+_0x22220c+').';return new Se(_0x22220c,_0x50a244,_0x7ce27c);}}function gc(_0x4185a0,_0x38a92d){return _0x4185a0['replace'](mc,(_0x1855ed,_0x4c80e3)=>{const _0x27bfd4=_0x38a92d[_0x4c80e3];return _0x27bfd4!=null?String(_0x27bfd4):'<'+_0x4c80e3+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x5cce65){return JSON['parse'](_0x5cce65);}function O(_0x3ed7f1){return JSON['stringify'](_0x3ed7f1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x1afcfe){let _0x30a6f7={},_0x161cb2={},_0x4295fd={},_0x45a295='';try{const _0x574b01=_0x1afcfe['split']('.');_0x30a6f7=bt(cn(_0x574b01[0x0])||''),_0x161cb2=bt(cn(_0x574b01[0x1])||''),_0x45a295=_0x574b01[0x2],_0x4295fd=_0x161cb2['d']||{},delete _0x161cb2['d'];}catch{}return{'header':_0x30a6f7,'claims':_0x161cb2,'data':_0x4295fd,'signature':_0x45a295};},yc=function(_0x49e90d){const _0x195435=zr(_0x49e90d),_0x1f9bd9=_0x195435['claims'];return!!_0x1f9bd9&&typeof _0x1f9bd9=='object'&&_0x1f9bd9['hasOwnProperty']('iat');},vc=function(_0x6d69e4){const _0x16895f=zr(_0x6d69e4)['claims'];return typeof _0x16895f=='object'&&_0x16895f['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x7d1d47,_0x2b0eca){return Object['prototype']['hasOwnProperty']['call'](_0x7d1d47,_0x2b0eca);}function Oe(_0x4928db,_0x3337a3){if(Object['prototype']['hasOwnProperty']['call'](_0x4928db,_0x3337a3))return _0x4928db[_0x3337a3];}function hi(_0x58808f){for(const _0xde487e in _0x58808f)if(Object['prototype']['hasOwnProperty']['call'](_0x58808f,_0xde487e))return!0x1;return!0x0;}function ln(_0x10e0a2,_0x4a7fab,_0x37bc79){const _0x5dbec4={};for(const _0x19679d in _0x10e0a2)Object['prototype']['hasOwnProperty']['call'](_0x10e0a2,_0x19679d)&&(_0x5dbec4[_0x19679d]=_0x4a7fab['call'](_0x37bc79,_0x10e0a2[_0x19679d],_0x19679d,_0x10e0a2));return _0x5dbec4;}function De(_0x5027cc,_0x541546){if(_0x5027cc===_0x541546)return!0x0;const _0x4b6a90=Object['keys'](_0x5027cc),_0x4e5351=Object['keys'](_0x541546);for(const _0x23bf78 of _0x4b6a90){if(!_0x4e5351['includes'](_0x23bf78))return!0x1;const _0x598a8b=_0x5027cc[_0x23bf78],_0x3322cb=_0x541546[_0x23bf78];if(ks(_0x598a8b)&&ks(_0x3322cb)){if(!De(_0x598a8b,_0x3322cb))return!0x1;}else{if(_0x598a8b!==_0x3322cb)return!0x1;}}for(const _0x341c41 of _0x4e5351)if(!_0x4b6a90['includes'](_0x341c41))return!0x1;return!0x0;}function ks(_0x549017){return _0x549017!==null&&typeof _0x549017=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x224ae9){const _0x473efd=[];for(const [_0x3a52ce,_0x25f28d]of Object['entries'](_0x224ae9))Array['isArray'](_0x25f28d)?_0x25f28d['forEach'](_0x2eb376=>{_0x473efd['push'](encodeURIComponent(_0x3a52ce)+'='+encodeURIComponent(_0x2eb376));}):_0x473efd['push'](encodeURIComponent(_0x3a52ce)+'='+encodeURIComponent(_0x25f28d));return _0x473efd['length']?'&'+_0x473efd['join']('&'):'';}function yt(_0x1385d6){const _0x21e5f2={};return _0x1385d6['replace'](/^\?/,'')['split']('&')['forEach'](_0xf2dcec=>{if(_0xf2dcec){const [_0x220907,_0x5b3cd0]=_0xf2dcec['split']('=');_0x21e5f2[decodeURIComponent(_0x220907)]=decodeURIComponent(_0x5b3cd0);}}),_0x21e5f2;}function vt(_0xc48e35){const _0x277265=_0xc48e35['indexOf']('?');if(!_0x277265)return'';const _0x1295f7=_0xc48e35['indexOf']('#',_0x277265);return _0xc48e35['substring'](_0x277265,_0x1295f7>0x0?_0x1295f7:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5a3871=0x1;_0x5a3871<this['blockSize'];++_0x5a3871)this['pad_'][_0x5a3871]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1cc110,_0x3c3a72){_0x3c3a72||(_0x3c3a72=0x0);const _0x21b9f8=this['W_'];if(typeof _0x1cc110=='string'){for(let _0x1e7faf=0x0;_0x1e7faf<0x10;_0x1e7faf++)_0x21b9f8[_0x1e7faf]=_0x1cc110['charCodeAt'](_0x3c3a72)<<0x18|_0x1cc110['charCodeAt'](_0x3c3a72+0x1)<<0x10|_0x1cc110['charCodeAt'](_0x3c3a72+0x2)<<0x8|_0x1cc110['charCodeAt'](_0x3c3a72+0x3),_0x3c3a72+=0x4;}else{for(let _0x31d5fc=0x0;_0x31d5fc<0x10;_0x31d5fc++)_0x21b9f8[_0x31d5fc]=_0x1cc110[_0x3c3a72]<<0x18|_0x1cc110[_0x3c3a72+0x1]<<0x10|_0x1cc110[_0x3c3a72+0x2]<<0x8|_0x1cc110[_0x3c3a72+0x3],_0x3c3a72+=0x4;}for(let _0x57c776=0x10;_0x57c776<0x50;_0x57c776++){const _0x21190f=_0x21b9f8[_0x57c776-0x3]^_0x21b9f8[_0x57c776-0x8]^_0x21b9f8[_0x57c776-0xe]^_0x21b9f8[_0x57c776-0x10];_0x21b9f8[_0x57c776]=(_0x21190f<<0x1|_0x21190f>>>0x1f)&0xffffffff;}let _0xabbf=this['chain_'][0x0],_0x5ea399=this['chain_'][0x1],_0x22416f=this['chain_'][0x2],_0x17bcbf=this['chain_'][0x3],_0x58bf22=this['chain_'][0x4],_0x37da82,_0x49bd60;for(let _0xd3539=0x0;_0xd3539<0x50;_0xd3539++){_0xd3539<0x28?_0xd3539<0x14?(_0x37da82=_0x17bcbf^_0x5ea399&(_0x22416f^_0x17bcbf),_0x49bd60=0x5a827999):(_0x37da82=_0x5ea399^_0x22416f^_0x17bcbf,_0x49bd60=0x6ed9eba1):_0xd3539<0x3c?(_0x37da82=_0x5ea399&_0x22416f|_0x17bcbf&(_0x5ea399|_0x22416f),_0x49bd60=0x8f1bbcdc):(_0x37da82=_0x5ea399^_0x22416f^_0x17bcbf,_0x49bd60=0xca62c1d6);const _0x5ebb0a=(_0xabbf<<0x5|_0xabbf>>>0x1b)+_0x37da82+_0x58bf22+_0x49bd60+_0x21b9f8[_0xd3539]&0xffffffff;_0x58bf22=_0x17bcbf,_0x17bcbf=_0x22416f,_0x22416f=(_0x5ea399<<0x1e|_0x5ea399>>>0x2)&0xffffffff,_0x5ea399=_0xabbf,_0xabbf=_0x5ebb0a;}this['chain_'][0x0]=this['chain_'][0x0]+_0xabbf&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5ea399&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x22416f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x17bcbf&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x58bf22&0xffffffff;}['update'](_0x22eca5,_0x536e79){if(_0x22eca5==null)return;_0x536e79===void 0x0&&(_0x536e79=_0x22eca5['length']);const _0x118116=_0x536e79-this['blockSize'];let _0x2e5fa7=0x0;const _0x34ef25=this['buf_'];let _0x492f2e=this['inbuf_'];for(;_0x2e5fa7<_0x536e79;){if(_0x492f2e===0x0){for(;_0x2e5fa7<=_0x118116;)this['compress_'](_0x22eca5,_0x2e5fa7),_0x2e5fa7+=this['blockSize'];}if(typeof _0x22eca5=='string'){for(;_0x2e5fa7<_0x536e79;)if(_0x34ef25[_0x492f2e]=_0x22eca5['charCodeAt'](_0x2e5fa7),++_0x492f2e,++_0x2e5fa7,_0x492f2e===this['blockSize']){this['compress_'](_0x34ef25),_0x492f2e=0x0;break;}}else{for(;_0x2e5fa7<_0x536e79;)if(_0x34ef25[_0x492f2e]=_0x22eca5[_0x2e5fa7],++_0x492f2e,++_0x2e5fa7,_0x492f2e===this['blockSize']){this['compress_'](_0x34ef25),_0x492f2e=0x0;break;}}}this['inbuf_']=_0x492f2e,this['total_']+=_0x536e79;}['digest'](){const _0x3873df=[];let _0x53b657=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x261974=this['blockSize']-0x1;_0x261974>=0x38;_0x261974--)this['buf_'][_0x261974]=_0x53b657&0xff,_0x53b657/=0x100;this['compress_'](this['buf_']);let _0x3467c0=0x0;for(let _0x1708d7=0x0;_0x1708d7<0x5;_0x1708d7++)for(let _0x46ffed=0x18;_0x46ffed>=0x0;_0x46ffed-=0x8)_0x3873df[_0x3467c0]=this['chain_'][_0x1708d7]>>_0x46ffed&0xff,++_0x3467c0;return _0x3873df;}}function Ic(_0x53e7f2,_0x466a0d){const _0x3ddbd8=new wc(_0x53e7f2,_0x466a0d);return _0x3ddbd8['subscribe']['bind'](_0x3ddbd8);}class wc{constructor(_0x3326e3,_0xa2a458){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xa2a458,this['task']['then'](()=>{_0x3326e3(this);})['catch'](_0x24e22a=>{this['error'](_0x24e22a);});}['next'](_0x2e0e9c){this['forEachObserver'](_0x2cdb25=>{_0x2cdb25['next'](_0x2e0e9c);});}['error'](_0x202ecc){this['forEachObserver'](_0x4ed92c=>{_0x4ed92c['error'](_0x202ecc);}),this['close'](_0x202ecc);}['complete'](){this['forEachObserver'](_0x4cac85=>{_0x4cac85['complete']();}),this['close']();}['subscribe'](_0x17df0d,_0x5d10df,_0x419b0c){let _0x5c8ed0;if(_0x17df0d===void 0x0&&_0x5d10df===void 0x0&&_0x419b0c===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x17df0d,['next','error','complete'])?_0x5c8ed0=_0x17df0d:_0x5c8ed0={'next':_0x17df0d,'error':_0x5d10df,'complete':_0x419b0c},_0x5c8ed0['next']===void 0x0&&(_0x5c8ed0['next']=Qn),_0x5c8ed0['error']===void 0x0&&(_0x5c8ed0['error']=Qn),_0x5c8ed0['complete']===void 0x0&&(_0x5c8ed0['complete']=Qn);const _0x218cb6=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5c8ed0['error'](this['finalError']):_0x5c8ed0['complete']();}catch{}}),this['observers']['push'](_0x5c8ed0),_0x218cb6;}['unsubscribeOne'](_0xe38967){this['observers']===void 0x0||this['observers'][_0xe38967]===void 0x0||(delete this['observers'][_0xe38967],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x16d102){if(!this['finalized']){for(let _0x2512b3=0x0;_0x2512b3<this['observers']['length'];_0x2512b3++)this['sendOne'](_0x2512b3,_0x16d102);}}['sendOne'](_0x100a9c,_0x1ed580){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x100a9c]!==void 0x0)try{_0x1ed580(this['observers'][_0x100a9c]);}catch(_0x1ca410){typeof console<'u'&&console['error']&&console['error'](_0x1ca410);}});}['close'](_0x552532){this['finalized']||(this['finalized']=!0x0,_0x552532!==void 0x0&&(this['finalError']=_0x552532),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x2bfacc,_0x1f9071){if(typeof _0x2bfacc!='object'||_0x2bfacc===null)return!0x1;for(const _0x28529c of _0x1f9071)if(_0x28529c in _0x2bfacc&&typeof _0x2bfacc[_0x28529c]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x1a6a00,_0x4f3894){return _0x1a6a00+'\x20failed:\x20'+_0x4f3894+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x234b77){const _0x40c5d7=[];let _0x500cd3=0x0;for(let _0x105002=0x0;_0x105002<_0x234b77['length'];_0x105002++){let _0x3f25e8=_0x234b77['charCodeAt'](_0x105002);if(_0x3f25e8>=0xd800&&_0x3f25e8<=0xdbff){const _0x18f901=_0x3f25e8-0xd800;_0x105002++,f(_0x105002<_0x234b77['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x27073b=_0x234b77['charCodeAt'](_0x105002)-0xdc00;_0x3f25e8=0x10000+(_0x18f901<<0xa)+_0x27073b;}_0x3f25e8<0x80?_0x40c5d7[_0x500cd3++]=_0x3f25e8:_0x3f25e8<0x800?(_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0x6|0xc0,_0x40c5d7[_0x500cd3++]=_0x3f25e8&0x3f|0x80):_0x3f25e8<0x10000?(_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0xc|0xe0,_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0x6&0x3f|0x80,_0x40c5d7[_0x500cd3++]=_0x3f25e8&0x3f|0x80):(_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0x12|0xf0,_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0xc&0x3f|0x80,_0x40c5d7[_0x500cd3++]=_0x3f25e8>>0x6&0x3f|0x80,_0x40c5d7[_0x500cd3++]=_0x3f25e8&0x3f|0x80);}return _0x40c5d7;},Pn=function(_0x26ba9b){let _0xd33556=0x0;for(let _0x3332ab=0x0;_0x3332ab<_0x26ba9b['length'];_0x3332ab++){const _0x1c5fdc=_0x26ba9b['charCodeAt'](_0x3332ab);_0x1c5fdc<0x80?_0xd33556++:_0x1c5fdc<0x800?_0xd33556+=0x2:_0x1c5fdc>=0xd800&&_0x1c5fdc<=0xdbff?(_0xd33556+=0x4,_0x3332ab++):_0xd33556+=0x3;}return _0xd33556;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x2cf55c){return _0x2cf55c&&_0x2cf55c['_delegate']?_0x2cf55c['_delegate']:_0x2cf55c;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x8f74ad){try{return(_0x8f74ad['startsWith']('http://')||_0x8f74ad['startsWith']('https://')?new URL(_0x8f74ad)['hostname']:_0x8f74ad)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x419408){return(await fetch(_0x419408,{'credentials':'include'}))['ok'];}class Me{constructor(_0x170196,_0xec728,_0x6a7182){this['name']=_0x170196,this['instanceFactory']=_0xec728,this['type']=_0x6a7182,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x562b19){return this['instantiationMode']=_0x562b19,this;}['setMultipleInstances'](_0xaf10fc){return this['multipleInstances']=_0xaf10fc,this;}['setServiceProps'](_0x5dbabc){return this['serviceProps']=_0x5dbabc,this;}['setInstanceCreatedCallback'](_0x1ea735){return this['onInstanceCreated']=_0x1ea735,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x54c660,_0xcf3792){this['name']=_0x54c660,this['container']=_0xcf3792,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2ae73c){const _0x2c2550=this['normalizeInstanceIdentifier'](_0x2ae73c);if(!this['instancesDeferred']['has'](_0x2c2550)){const _0x63e9a7=new Ve();if(this['instancesDeferred']['set'](_0x2c2550,_0x63e9a7),this['isInitialized'](_0x2c2550)||this['shouldAutoInitialize']())try{const _0x45aba4=this['getOrInitializeService']({'instanceIdentifier':_0x2c2550});_0x45aba4&&_0x63e9a7['resolve'](_0x45aba4);}catch{}}return this['instancesDeferred']['get'](_0x2c2550)['promise'];}['getImmediate'](_0x581f03){const _0x2f2315=this['normalizeInstanceIdentifier'](_0x581f03==null?void 0x0:_0x581f03['identifier']),_0x437ac5=(_0x581f03==null?void 0x0:_0x581f03['optional'])??!0x1;if(this['isInitialized'](_0x2f2315)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2f2315});}catch(_0x2b9d89){if(_0x437ac5)return null;throw _0x2b9d89;}else{if(_0x437ac5)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x62fae4){if(_0x62fae4['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x62fae4['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x62fae4,!!this['shouldAutoInitialize']()){if(Rc(_0x62fae4))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x276008,_0x28e834]of this['instancesDeferred']['entries']()){const _0x1f8471=this['normalizeInstanceIdentifier'](_0x276008);try{const _0x23da1b=this['getOrInitializeService']({'instanceIdentifier':_0x1f8471});_0x28e834['resolve'](_0x23da1b);}catch{}}}}['clearInstance'](_0x4fc6bf=ke){this['instancesDeferred']['delete'](_0x4fc6bf),this['instancesOptions']['delete'](_0x4fc6bf),this['instances']['delete'](_0x4fc6bf);}async['delete'](){const _0x57aeb3=Array['from'](this['instances']['values']());await Promise['all']([..._0x57aeb3['filter'](_0x41290e=>'INTERNAL'in _0x41290e)['map'](_0x14e2cf=>_0x14e2cf['INTERNAL']['delete']()),..._0x57aeb3['filter'](_0x30eb90=>'_delete'in _0x30eb90)['map'](_0x59fe73=>_0x59fe73['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2e0800=ke){return this['instances']['has'](_0x2e0800);}['getOptions'](_0xf73a27=ke){return this['instancesOptions']['get'](_0xf73a27)||{};}['initialize'](_0x1dddaa={}){const {options:_0x26345c={}}=_0x1dddaa,_0x3dd4df=this['normalizeInstanceIdentifier'](_0x1dddaa['instanceIdentifier']);if(this['isInitialized'](_0x3dd4df))throw Error(this['name']+'('+_0x3dd4df+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x499811=this['getOrInitializeService']({'instanceIdentifier':_0x3dd4df,'options':_0x26345c});for(const [_0x320635,_0x575152]of this['instancesDeferred']['entries']()){const _0x4a57b8=this['normalizeInstanceIdentifier'](_0x320635);_0x3dd4df===_0x4a57b8&&_0x575152['resolve'](_0x499811);}return _0x499811;}['onInit'](_0x1b8695,_0x2b85c8){const _0x531b2b=this['normalizeInstanceIdentifier'](_0x2b85c8),_0x137096=this['onInitCallbacks']['get'](_0x531b2b)??new Set();_0x137096['add'](_0x1b8695),this['onInitCallbacks']['set'](_0x531b2b,_0x137096);const _0x2e73cd=this['instances']['get'](_0x531b2b);return _0x2e73cd&&_0x1b8695(_0x2e73cd,_0x531b2b),()=>{_0x137096['delete'](_0x1b8695);};}['invokeOnInitCallbacks'](_0x24a37d,_0x5100b3){const _0x4ddb07=this['onInitCallbacks']['get'](_0x5100b3);if(_0x4ddb07){for(const _0x3cbe91 of _0x4ddb07)try{_0x3cbe91(_0x24a37d,_0x5100b3);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x51b30d,options:_0xdb82d4={}}){let _0x5600f2=this['instances']['get'](_0x51b30d);if(!_0x5600f2&&this['component']&&(_0x5600f2=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x51b30d),'options':_0xdb82d4}),this['instances']['set'](_0x51b30d,_0x5600f2),this['instancesOptions']['set'](_0x51b30d,_0xdb82d4),this['invokeOnInitCallbacks'](_0x5600f2,_0x51b30d),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x51b30d,_0x5600f2);}catch{}return _0x5600f2||null;}['normalizeInstanceIdentifier'](_0x22acc4=ke){return this['component']?this['component']['multipleInstances']?_0x22acc4:ke:_0x22acc4;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0xf6016a){return _0xf6016a===ke?void 0x0:_0xf6016a;}function Rc(_0x45be55){return _0x45be55['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3d0fe4){this['name']=_0x3d0fe4,this['providers']=new Map();}['addComponent'](_0x5f0fa6){const _0x5da0c4=this['getProvider'](_0x5f0fa6['name']);if(_0x5da0c4['isComponentSet']())throw new Error('Component\x20'+_0x5f0fa6['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5da0c4['setComponent'](_0x5f0fa6);}['addOrOverwriteComponent'](_0x2d8dd3){this['getProvider'](_0x2d8dd3['name'])['isComponentSet']()&&this['providers']['delete'](_0x2d8dd3['name']),this['addComponent'](_0x2d8dd3);}['getProvider'](_0x340b85){if(this['providers']['has'](_0x340b85))return this['providers']['get'](_0x340b85);const _0x185377=new Sc(_0x340b85,this);return this['providers']['set'](_0x340b85,_0x185377),_0x185377;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x387b03){_0x387b03[_0x387b03['DEBUG']=0x0]='DEBUG',_0x387b03[_0x387b03['VERBOSE']=0x1]='VERBOSE',_0x387b03[_0x387b03['INFO']=0x2]='INFO',_0x387b03[_0x387b03['WARN']=0x3]='WARN',_0x387b03[_0x387b03['ERROR']=0x4]='ERROR',_0x387b03[_0x387b03['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2920cd,_0x7c4344,..._0x205aec)=>{if(_0x7c4344<_0x2920cd['logLevel'])return;const _0x407d70=new Date()['toISOString'](),_0x36465b=Pc[_0x7c4344];if(_0x36465b)console[_0x36465b]('['+_0x407d70+']\x20\x20'+_0x2920cd['name']+':',..._0x205aec);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x7c4344+')');};class xi{constructor(_0x63b2af){this['name']=_0x63b2af,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xfbecf2){if(!(_0xfbecf2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xfbecf2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xfbecf2;}['setLogLevel'](_0x1b0cba){this['_logLevel']=typeof _0x1b0cba=='string'?kc[_0x1b0cba]:_0x1b0cba;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3a978c){if(typeof _0x3a978c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3a978c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x29dfc3){this['_userLogHandler']=_0x29dfc3;}['debug'](..._0x53109b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x53109b),this['_logHandler'](this,T['DEBUG'],..._0x53109b);}['log'](..._0x325975){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x325975),this['_logHandler'](this,T['VERBOSE'],..._0x325975);}['info'](..._0x510015){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x510015),this['_logHandler'](this,T['INFO'],..._0x510015);}['warn'](..._0xdac853){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xdac853),this['_logHandler'](this,T['WARN'],..._0xdac853);}['error'](..._0x3ee706){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3ee706),this['_logHandler'](this,T['ERROR'],..._0x3ee706);}}const Dc=(_0x121096,_0x222c3b)=>_0x222c3b['some'](_0x1a76a0=>_0x121096 instanceof _0x1a76a0);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x4331ad){const _0x5520a0=new Promise((_0x473dea,_0x11201b)=>{const _0x1ccb95=()=>{_0x4331ad['removeEventListener']('success',_0x36abfe),_0x4331ad['removeEventListener']('error',_0x121ff7);},_0x36abfe=()=>{_0x473dea(_e(_0x4331ad['result'])),_0x1ccb95();},_0x121ff7=()=>{_0x11201b(_0x4331ad['error']),_0x1ccb95();};_0x4331ad['addEventListener']('success',_0x36abfe),_0x4331ad['addEventListener']('error',_0x121ff7);});return _0x5520a0['then'](_0xd5adfb=>{_0xd5adfb instanceof IDBCursor&&Kr['set'](_0xd5adfb,_0x4331ad);})['catch'](()=>{}),Fi['set'](_0x5520a0,_0x4331ad),_0x5520a0;}function Fc(_0x3e64d0){if(ui['has'](_0x3e64d0))return;const _0x455719=new Promise((_0x270e0b,_0x2c630d)=>{const _0x3b9fed=()=>{_0x3e64d0['removeEventListener']('complete',_0x19082a),_0x3e64d0['removeEventListener']('error',_0x44b842),_0x3e64d0['removeEventListener']('abort',_0x44b842);},_0x19082a=()=>{_0x270e0b(),_0x3b9fed();},_0x44b842=()=>{_0x2c630d(_0x3e64d0['error']||new DOMException('AbortError','AbortError')),_0x3b9fed();};_0x3e64d0['addEventListener']('complete',_0x19082a),_0x3e64d0['addEventListener']('error',_0x44b842),_0x3e64d0['addEventListener']('abort',_0x44b842);});ui['set'](_0x3e64d0,_0x455719);}let di={'get'(_0x5bcd29,_0x104391,_0x594a4c){if(_0x5bcd29 instanceof IDBTransaction){if(_0x104391==='done')return ui['get'](_0x5bcd29);if(_0x104391==='objectStoreNames')return _0x5bcd29['objectStoreNames']||Yr['get'](_0x5bcd29);if(_0x104391==='store')return _0x594a4c['objectStoreNames'][0x1]?void 0x0:_0x594a4c['objectStore'](_0x594a4c['objectStoreNames'][0x0]);}return _e(_0x5bcd29[_0x104391]);},'set'(_0x4e5ed5,_0x164fc4,_0x4361ee){return _0x4e5ed5[_0x164fc4]=_0x4361ee,!0x0;},'has'(_0x159d8d,_0x4219f5){return _0x159d8d instanceof IDBTransaction&&(_0x4219f5==='done'||_0x4219f5==='store')?!0x0:_0x4219f5 in _0x159d8d;}};function Uc(_0x566806){di=_0x566806(di);}function Wc(_0x2bf0c7){return _0x2bf0c7===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x233f40,..._0x32badd){const _0x5a5284=_0x2bf0c7['call'](Xn(this),_0x233f40,..._0x32badd);return Yr['set'](_0x5a5284,_0x233f40['sort']?_0x233f40['sort']():[_0x233f40]),_e(_0x5a5284);}:Lc()['includes'](_0x2bf0c7)?function(..._0x101911){return _0x2bf0c7['apply'](Xn(this),_0x101911),_e(Kr['get'](this));}:function(..._0x1923b0){return _e(_0x2bf0c7['apply'](Xn(this),_0x1923b0));};}function Bc(_0x48857a){return typeof _0x48857a=='function'?Wc(_0x48857a):(_0x48857a instanceof IDBTransaction&&Fc(_0x48857a),Dc(_0x48857a,Mc())?new Proxy(_0x48857a,di):_0x48857a);}function _e(_0x2ffe84){if(_0x2ffe84 instanceof IDBRequest)return xc(_0x2ffe84);if(Jn['has'](_0x2ffe84))return Jn['get'](_0x2ffe84);const _0x475a18=Bc(_0x2ffe84);return _0x475a18!==_0x2ffe84&&(Jn['set'](_0x2ffe84,_0x475a18),Fi['set'](_0x475a18,_0x2ffe84)),_0x475a18;}const Xn=_0x2ed8a9=>Fi['get'](_0x2ed8a9);function Vc(_0x53c9a9,_0x5bae8c,{blocked:_0x2337c6,upgrade:_0x5d7974,blocking:_0x2b5881,terminated:_0x590023}={}){const _0x2136a3=indexedDB['open'](_0x53c9a9,_0x5bae8c),_0x576721=_e(_0x2136a3);return _0x5d7974&&_0x2136a3['addEventListener']('upgradeneeded',_0x59a74b=>{_0x5d7974(_e(_0x2136a3['result']),_0x59a74b['oldVersion'],_0x59a74b['newVersion'],_e(_0x2136a3['transaction']),_0x59a74b);}),_0x2337c6&&_0x2136a3['addEventListener']('blocked',_0x262641=>_0x2337c6(_0x262641['oldVersion'],_0x262641['newVersion'],_0x262641)),_0x576721['then'](_0x201ff2=>{_0x590023&&_0x201ff2['addEventListener']('close',()=>_0x590023()),_0x2b5881&&_0x201ff2['addEventListener']('versionchange',_0x1a91c8=>_0x2b5881(_0x1a91c8['oldVersion'],_0x1a91c8['newVersion'],_0x1a91c8));})['catch'](()=>{}),_0x576721;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x30273c,_0x139335){if(!(_0x30273c instanceof IDBDatabase&&!(_0x139335 in _0x30273c)&&typeof _0x139335=='string'))return;if(Zn['get'](_0x139335))return Zn['get'](_0x139335);const _0x3b170a=_0x139335['replace'](/FromIndex$/,''),_0x2e7d4c=_0x139335!==_0x3b170a,_0x55a701=$c['includes'](_0x3b170a);if(!(_0x3b170a in(_0x2e7d4c?IDBIndex:IDBObjectStore)['prototype'])||!(_0x55a701||Hc['includes'](_0x3b170a)))return;const _0x21d8ea=async function(_0x5e9742,..._0x119333){const _0x76382f=this['transaction'](_0x5e9742,_0x55a701?'readwrite':'readonly');let _0x1a4a92=_0x76382f['store'];return _0x2e7d4c&&(_0x1a4a92=_0x1a4a92['index'](_0x119333['shift']())),(await Promise['all']([_0x1a4a92[_0x3b170a](..._0x119333),_0x55a701&&_0x76382f['done']]))[0x0];};return Zn['set'](_0x139335,_0x21d8ea),_0x21d8ea;}Uc(_0x477ee9=>({..._0x477ee9,'get':(_0x4c1593,_0x2cd5b7,_0x19bac2)=>Os(_0x4c1593,_0x2cd5b7)||_0x477ee9['get'](_0x4c1593,_0x2cd5b7,_0x19bac2),'has':(_0x531ca5,_0x553b9a)=>!!Os(_0x531ca5,_0x553b9a)||_0x477ee9['has'](_0x531ca5,_0x553b9a)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x547d4f){this['container']=_0x547d4f;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x9bafca=>{if(qc(_0x9bafca)){const _0x270749=_0x9bafca['getImmediate']();return _0x270749['library']+'/'+_0x270749['version'];}else return null;})['filter'](_0x335814=>_0x335814)['join']('\x20');}}function qc(_0x486459){const _0x1c0aa6=_0x486459['getComponent']();return(_0x1c0aa6==null?void 0x0:_0x1c0aa6['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x3149f3,_0x409a27){try{_0x3149f3['container']['addComponent'](_0x409a27);}catch(_0x5787d9){re['debug']('Component\x20'+_0x409a27['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3149f3['name'],_0x5787d9);}}function et(_0x357972){const _0x507873=_0x357972['name'];if(gi['has'](_0x507873))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x507873+'.'),!0x1;gi['set'](_0x507873,_0x357972);for(const _0x5d4a16 of Le['values']())Ms(_0x5d4a16,_0x357972);for(const _0x5ba53d of _i['values']())Ms(_0x5ba53d,_0x357972);return!0x0;}function Ui(_0x517061,_0x3e9fc0){const _0x2807a3=_0x517061['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2807a3&&_0x2807a3['triggerHeartbeat'](),_0x517061['container']['getProvider'](_0x3e9fc0);}function H(_0x1a1980){return _0x1a1980==null?!0x1:_0x1a1980['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5623c8,_0x1fcb87,_0x7bb67b){this['_isDeleted']=!0x1,this['_options']={..._0x5623c8},this['_config']={..._0x1fcb87},this['_name']=_0x1fcb87['name'],this['_automaticDataCollectionEnabled']=_0x1fcb87['automaticDataCollectionEnabled'],this['_container']=_0x7bb67b,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x44ad29){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x44ad29;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x24881c){this['_isDeleted']=_0x24881c;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x2d56cd,_0x245b30={}){let _0x4a1385=_0x2d56cd;typeof _0x245b30!='object'&&(_0x245b30={'name':_0x245b30});const _0x45edce={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x245b30},_0x22ef6b=_0x45edce['name'];if(typeof _0x22ef6b!='string'||!_0x22ef6b)throw ge['create']('bad-app-name',{'appName':String(_0x22ef6b)});if(_0x4a1385||(_0x4a1385=$r()),!_0x4a1385)throw ge['create']('no-options');const _0x58495e=Le['get'](_0x22ef6b);if(_0x58495e){if(De(_0x4a1385,_0x58495e['options'])&&De(_0x45edce,_0x58495e['config']))return _0x58495e;throw ge['create']('duplicate-app',{'appName':_0x22ef6b});}const _0x3ba0a3=new Ac(_0x22ef6b);for(const _0x585187 of gi['values']())_0x3ba0a3['addComponent'](_0x585187);const _0x3021ad=new Il(_0x4a1385,_0x45edce,_0x3ba0a3);return Le['set'](_0x22ef6b,_0x3021ad),_0x3021ad;}function Qr(_0x174bf8=pi){const _0x4d1bdd=Le['get'](_0x174bf8);if(!_0x4d1bdd&&_0x174bf8===pi&&$r())return wl();if(!_0x4d1bdd)throw ge['create']('no-app',{'appName':_0x174bf8});return _0x4d1bdd;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3e6ebb){let _0x36064d=!0x1;const _0x3b6af3=_0x3e6ebb['name'];Le['has'](_0x3b6af3)?(_0x36064d=!0x0,Le['delete'](_0x3b6af3)):_i['has'](_0x3b6af3)&&_0x3e6ebb['decRefCount']()<=0x0&&(_i['delete'](_0x3b6af3),_0x36064d=!0x0),_0x36064d&&(await Promise['all'](_0x3e6ebb['container']['getProviders']()['map'](_0x4d086a=>_0x4d086a['delete']())),_0x3e6ebb['isDeleted']=!0x0);}function me(_0x5e09aa,_0x346556,_0x2cf0c1){let _0x1bce88=vl[_0x5e09aa]??_0x5e09aa;_0x2cf0c1&&(_0x1bce88+='-'+_0x2cf0c1);const _0x347f46=_0x1bce88['match'](/\s|\//),_0x2bfc2d=_0x346556['match'](/\s|\//);if(_0x347f46||_0x2bfc2d){const _0x40e2d4=['Unable\x20to\x20register\x20library\x20\x22'+_0x1bce88+'\x22\x20with\x20version\x20\x22'+_0x346556+'\x22:'];_0x347f46&&_0x40e2d4['push']('library\x20name\x20\x22'+_0x1bce88+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x347f46&&_0x2bfc2d&&_0x40e2d4['push']('and'),_0x2bfc2d&&_0x40e2d4['push']('version\x20name\x20\x22'+_0x346556+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x40e2d4['join']('\x20'));return;}et(new Me(_0x1bce88+'-version',()=>({'library':_0x1bce88,'version':_0x346556}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1051a4,_0x5a1496)=>{switch(_0x5a1496){case 0x0:try{_0x1051a4['createObjectStore'](Rt);}catch(_0x70a4a6){console['warn'](_0x70a4a6);}}}})['catch'](_0x5be4f2=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5be4f2['message']});})),ei;}async function Sl(_0x48285c){try{const _0x408609=(await Jr())['transaction'](Rt),_0x40ca7c=await _0x408609['objectStore'](Rt)['get'](Xr(_0x48285c));return await _0x408609['done'],_0x40ca7c;}catch(_0x479240){if(_0x479240 instanceof Se)re['warn'](_0x479240['message']);else{const _0x417ba1=ge['create']('idb-get',{'originalErrorMessage':_0x479240==null?void 0x0:_0x479240['message']});re['warn'](_0x417ba1['message']);}}}async function Ls(_0x118285,_0x469319){try{const _0x152877=(await Jr())['transaction'](Rt,'readwrite');await _0x152877['objectStore'](Rt)['put'](_0x469319,Xr(_0x118285)),await _0x152877['done'];}catch(_0x35b8a6){if(_0x35b8a6 instanceof Se)re['warn'](_0x35b8a6['message']);else{const _0x277893=ge['create']('idb-set',{'originalErrorMessage':_0x35b8a6==null?void 0x0:_0x35b8a6['message']});re['warn'](_0x277893['message']);}}}function Xr(_0x34623c){return _0x34623c['name']+'!'+_0x34623c['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x58070f){this['container']=_0x58070f,this['_heartbeatsCache']=null;const _0x5c3f0e=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5c3f0e),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3c9d3c=>(this['_heartbeatsCache']=_0x3c9d3c,_0x3c9d3c));}async['triggerHeartbeat'](){var _0x283f72,_0xe9b619;try{const _0x6e4c5f=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xaf9769=xs();if(((_0x283f72=this['_heartbeatsCache'])==null?void 0x0:_0x283f72['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xe9b619=this['_heartbeatsCache'])==null?void 0x0:_0xe9b619['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xaf9769||this['_heartbeatsCache']['heartbeats']['some'](_0x205d58=>_0x205d58['date']===_0xaf9769))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xaf9769,'agent':_0x6e4c5f}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x3fdb47=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3fdb47,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4e7b67){re['warn'](_0x4e7b67);}}async['getHeartbeatsHeader'](){var _0x38921c;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x38921c=this['_heartbeatsCache'])==null?void 0x0:_0x38921c['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x489906=xs(),{heartbeatsToSend:_0x194cce,unsentEntries:_0x19499c}=kl(this['_heartbeatsCache']['heartbeats']),_0x3cc153=an(JSON['stringify']({'version':0x2,'heartbeats':_0x194cce}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x489906,_0x19499c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x19499c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3cc153;}catch(_0x36d7dd){return re['warn'](_0x36d7dd),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x393dc4,_0x3122d9=bl){const _0x503328=[];let _0x20b47f=_0x393dc4['slice']();for(const _0x20b4dd of _0x393dc4){const _0x3700ce=_0x503328['find'](_0x26e9a1=>_0x26e9a1['agent']===_0x20b4dd['agent']);if(_0x3700ce){if(_0x3700ce['dates']['push'](_0x20b4dd['date']),Fs(_0x503328)>_0x3122d9){_0x3700ce['dates']['pop']();break;}}else{if(_0x503328['push']({'agent':_0x20b4dd['agent'],'dates':[_0x20b4dd['date']]}),Fs(_0x503328)>_0x3122d9){_0x503328['pop']();break;}}_0x20b47f=_0x20b47f['slice'](0x1);}return{'heartbeatsToSend':_0x503328,'unsentEntries':_0x20b47f};}class Nl{constructor(_0x44ee67){this['app']=_0x44ee67,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x26c3ef=await Sl(this['app']);return _0x26c3ef!=null&&_0x26c3ef['heartbeats']?_0x26c3ef:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x588022){if(await this['_canUseIndexedDBPromise']){const _0x56f3a5=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x588022['lastSentHeartbeatDate']??_0x56f3a5['lastSentHeartbeatDate'],'heartbeats':_0x588022['heartbeats']});}else return;}async['add'](_0x17540f){if(await this['_canUseIndexedDBPromise']){const _0x5352a3=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x17540f['lastSentHeartbeatDate']??_0x5352a3['lastSentHeartbeatDate'],'heartbeats':[..._0x5352a3['heartbeats'],..._0x17540f['heartbeats']]});}else return;}}function Fs(_0x41936c){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x41936c}))['length'];}function Pl(_0x24450b){if(_0x24450b['length']===0x0)return-0x1;let _0x1dc05a=0x0,_0x109626=_0x24450b[0x0]['date'];for(let _0x27a59e=0x1;_0x27a59e<_0x24450b['length'];_0x27a59e++)_0x24450b[_0x27a59e]['date']<_0x109626&&(_0x109626=_0x24450b[_0x27a59e]['date'],_0x1dc05a=_0x27a59e);return _0x1dc05a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x59aa5a){et(new Me('platform-logger',_0x27a945=>new Gc(_0x27a945),'PRIVATE')),et(new Me('heartbeat',_0x9cb9ba=>new Al(_0x9cb9ba),'PRIVATE')),me(fi,Ds,_0x59aa5a),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x526b3e){Zr=_0x526b3e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x3ea67c){this['domStorage_']=_0x3ea67c,this['prefix_']='firebase:';}['set'](_0xc1b48f,_0x4a495d){_0x4a495d==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xc1b48f)):this['domStorage_']['setItem'](this['prefixedName_'](_0xc1b48f),O(_0x4a495d));}['get'](_0x38780e){const _0x16ca59=this['domStorage_']['getItem'](this['prefixedName_'](_0x38780e));return _0x16ca59==null?null:bt(_0x16ca59);}['remove'](_0x339933){this['domStorage_']['removeItem'](this['prefixedName_'](_0x339933));}['prefixedName_'](_0xc114ed){return this['prefix_']+_0xc114ed;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x34cece,_0x34fd02){_0x34fd02==null?delete this['cache_'][_0x34cece]:this['cache_'][_0x34cece]=_0x34fd02;}['get'](_0x430e50){return Y(this['cache_'],_0x430e50)?this['cache_'][_0x430e50]:null;}['remove'](_0x12015f){delete this['cache_'][_0x12015f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x4d9367){try{if(typeof window<'u'&&typeof window[_0x4d9367]<'u'){const _0x2c9bd6=window[_0x4d9367];return _0x2c9bd6['setItem']('firebase:sentinel','cache'),_0x2c9bd6['removeItem']('firebase:sentinel'),new xl(_0x2c9bd6);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x3c4f57=0x1;return function(){return _0x3c4f57++;};}()),no=function(_0xb1c66a){const _0x584f81=Tc(_0xb1c66a),_0x5ae1ac=new Ec();_0x5ae1ac['update'](_0x584f81);const _0x214c2a=_0x5ae1ac['digest']();return Di['encodeByteArray'](_0x214c2a);},Bt=function(..._0x550261){let _0x24c7cf='';for(let _0x2d7b73=0x0;_0x2d7b73<_0x550261['length'];_0x2d7b73++){const _0x2da1bc=_0x550261[_0x2d7b73];Array['isArray'](_0x2da1bc)||_0x2da1bc&&typeof _0x2da1bc=='object'&&typeof _0x2da1bc['length']=='number'?_0x24c7cf+=Bt['apply'](null,_0x2da1bc):typeof _0x2da1bc=='object'?_0x24c7cf+=O(_0x2da1bc):_0x24c7cf+=_0x2da1bc,_0x24c7cf+='\x20';}return _0x24c7cf;};let Et=null,Vs=!0x0;const Wl=function(_0x5396c0,_0x491868){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5243c5){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x2f0624=Bt['apply'](null,_0x5243c5);Et(_0x2f0624);}},Vt=function(_0x4e1a0b){return function(..._0x3df39d){L(_0x4e1a0b,..._0x3df39d);};},mi=function(..._0x468d3a){const _0x27596d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x468d3a);Qe['error'](_0x27596d);},oe=function(..._0x6970a5){const _0x142f4e='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x6970a5);throw Qe['error'](_0x142f4e),new Error(_0x142f4e);},U=function(..._0x83d54b){const _0x5ea433='FIREBASE\x20WARNING:\x20'+Bt(..._0x83d54b);Qe['warn'](_0x5ea433);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x4d3947){return typeof _0x4d3947=='number'&&(_0x4d3947!==_0x4d3947||_0x4d3947===Number['POSITIVE_INFINITY']||_0x4d3947===Number['NEGATIVE_INFINITY']);},Vl=function(_0x10d227){if(document['readyState']==='complete')_0x10d227();else{let _0xd2ef39=!0x1;const _0x27c046=function(){if(!document['body']){setTimeout(_0x27c046,Math['floor'](0xa));return;}_0xd2ef39||(_0xd2ef39=!0x0,_0x10d227());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x27c046,!0x1),window['addEventListener']('load',_0x27c046,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x27c046();}),window['attachEvent']('onload',_0x27c046));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4136da,_0x2cca1b){if(_0x4136da===_0x2cca1b)return 0x0;if(_0x4136da===xe||_0x2cca1b===Ie)return-0x1;if(_0x2cca1b===xe||_0x4136da===Ie)return 0x1;{const _0x5a7ef2=Hs(_0x4136da),_0x5d6058=Hs(_0x2cca1b);return _0x5a7ef2!==null?_0x5d6058!==null?_0x5a7ef2-_0x5d6058===0x0?_0x4136da['length']-_0x2cca1b['length']:_0x5a7ef2-_0x5d6058:-0x1:_0x5d6058!==null?0x1:_0x4136da<_0x2cca1b?-0x1:0x1;}},Hl=function(_0x5dfaba,_0x136636){return _0x5dfaba===_0x136636?0x0:_0x5dfaba<_0x136636?-0x1:0x1;},pt=function(_0x10d0d7,_0x52bb6f){if(_0x52bb6f&&_0x10d0d7 in _0x52bb6f)return _0x52bb6f[_0x10d0d7];throw new Error('Missing\x20required\x20key\x20('+_0x10d0d7+')\x20in\x20object:\x20'+O(_0x52bb6f));},Bi=function(_0x4a3fc4){if(typeof _0x4a3fc4!='object'||_0x4a3fc4===null)return O(_0x4a3fc4);const _0x31d006=[];for(const _0x2f1bf9 in _0x4a3fc4)_0x31d006['push'](_0x2f1bf9);_0x31d006['sort']();let _0x9f3727='{';for(let _0x3a161b=0x0;_0x3a161b<_0x31d006['length'];_0x3a161b++)_0x3a161b!==0x0&&(_0x9f3727+=','),_0x9f3727+=O(_0x31d006[_0x3a161b]),_0x9f3727+=':',_0x9f3727+=Bi(_0x4a3fc4[_0x31d006[_0x3a161b]]);return _0x9f3727+='}',_0x9f3727;},io=function(_0x5ad321,_0x54fee2){const _0x261c6a=_0x5ad321['length'];if(_0x261c6a<=_0x54fee2)return[_0x5ad321];const _0x203ffa=[];for(let _0xc79703=0x0;_0xc79703<_0x261c6a;_0xc79703+=_0x54fee2)_0xc79703+_0x54fee2>_0x261c6a?_0x203ffa['push'](_0x5ad321['substring'](_0xc79703,_0x261c6a)):_0x203ffa['push'](_0x5ad321['substring'](_0xc79703,_0xc79703+_0x54fee2));return _0x203ffa;};function x(_0x2c19fd,_0x37189e){for(const _0x4bf6dd in _0x2c19fd)_0x2c19fd['hasOwnProperty'](_0x4bf6dd)&&_0x37189e(_0x4bf6dd,_0x2c19fd[_0x4bf6dd]);}const so=function(_0x2a4b7f){f(!Wi(_0x2a4b7f),'Invalid\x20JSON\x20number');const _0x599b27=0xb,_0x5b7c0d=0x34,_0x50ba20=(0x1<<_0x599b27-0x1)-0x1;let _0x2500d8,_0x4c6c41,_0x2249ef,_0x2ce284,_0x510fec;_0x2a4b7f===0x0?(_0x4c6c41=0x0,_0x2249ef=0x0,_0x2500d8=0x1/_0x2a4b7f===-0x1/0x0?0x1:0x0):(_0x2500d8=_0x2a4b7f<0x0,_0x2a4b7f=Math['abs'](_0x2a4b7f),_0x2a4b7f>=Math['pow'](0x2,0x1-_0x50ba20)?(_0x2ce284=Math['min'](Math['floor'](Math['log'](_0x2a4b7f)/Math['LN2']),_0x50ba20),_0x4c6c41=_0x2ce284+_0x50ba20,_0x2249ef=Math['round'](_0x2a4b7f*Math['pow'](0x2,_0x5b7c0d-_0x2ce284)-Math['pow'](0x2,_0x5b7c0d))):(_0x4c6c41=0x0,_0x2249ef=Math['round'](_0x2a4b7f/Math['pow'](0x2,0x1-_0x50ba20-_0x5b7c0d))));const _0x23fb68=[];for(_0x510fec=_0x5b7c0d;_0x510fec;_0x510fec-=0x1)_0x23fb68['push'](_0x2249ef%0x2?0x1:0x0),_0x2249ef=Math['floor'](_0x2249ef/0x2);for(_0x510fec=_0x599b27;_0x510fec;_0x510fec-=0x1)_0x23fb68['push'](_0x4c6c41%0x2?0x1:0x0),_0x4c6c41=Math['floor'](_0x4c6c41/0x2);_0x23fb68['push'](_0x2500d8?0x1:0x0),_0x23fb68['reverse']();const _0x32eae0=_0x23fb68['join']('');let _0x3e789e='';for(_0x510fec=0x0;_0x510fec<0x40;_0x510fec+=0x8){let _0x40915b=parseInt(_0x32eae0['substr'](_0x510fec,0x8),0x2)['toString'](0x10);_0x40915b['length']===0x1&&(_0x40915b='0'+_0x40915b),_0x3e789e=_0x3e789e+_0x40915b;}return _0x3e789e['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x18b932,_0x57faf4){let _0x404f9a='Unknown\x20Error';_0x18b932==='too_big'?_0x404f9a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x18b932==='permission_denied'?_0x404f9a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x18b932==='unavailable'&&(_0x404f9a='The\x20service\x20is\x20unavailable');const _0x22ac33=new Error(_0x18b932+'\x20at\x20'+_0x57faf4['_path']['toString']()+':\x20'+_0x404f9a);return _0x22ac33['code']=_0x18b932['toUpperCase'](),_0x22ac33;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x301ad2){if(zl['test'](_0x301ad2)){const _0xaabc0b=Number(_0x301ad2);if(_0xaabc0b>=jl&&_0xaabc0b<=Kl)return _0xaabc0b;}return null;},lt=function(_0x1e418a){try{_0x1e418a();}catch(_0x1ac781){setTimeout(()=>{const _0x7fae09=_0x1ac781['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x7fae09),_0x1ac781;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x525920,_0x58989){const _0x5875cb=setTimeout(_0x525920,_0x58989);return typeof _0x5875cb=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5875cb):typeof _0x5875cb=='object'&&_0x5875cb['unref']&&_0x5875cb['unref'](),_0x5875cb;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x232a8d,_0x37ec6c){this['appCheckProvider']=_0x37ec6c,this['appName']=_0x232a8d['name'],H(_0x232a8d)&&_0x232a8d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x232a8d['settings']['appCheckToken']),this['appCheck']=_0x37ec6c==null?void 0x0:_0x37ec6c['getImmediate']({'optional':!0x0}),this['appCheck']||_0x37ec6c==null||_0x37ec6c['get']()['then'](_0x1e214b=>this['appCheck']=_0x1e214b);}['getToken'](_0x225c9f){if(this['serverAppAppCheckToken']){if(_0x225c9f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x225c9f):new Promise((_0x338c94,_0xc721f2)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x225c9f)['then'](_0x338c94,_0xc721f2):_0x338c94(null);},0x0);});}['addTokenChangeListener'](_0x532ab3){var _0x2d824e;(_0x2d824e=this['appCheckProvider'])==null||_0x2d824e['get']()['then'](_0x45b1e2=>_0x45b1e2['addTokenListener'](_0x532ab3));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0xa95579,_0x4f454c,_0x2b2f52){this['appName_']=_0xa95579,this['firebaseOptions_']=_0x4f454c,this['authProvider_']=_0x2b2f52,this['auth_']=null,this['auth_']=_0x2b2f52['getImmediate']({'optional':!0x0}),this['auth_']||_0x2b2f52['onInit'](_0x56a9a5=>this['auth_']=_0x56a9a5);}['getToken'](_0x4b2550){return this['auth_']?this['auth_']['getToken'](_0x4b2550)['catch'](_0x4416a1=>_0x4416a1&&_0x4416a1['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4416a1)):new Promise((_0x273247,_0x5807ff)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4b2550)['then'](_0x273247,_0x5807ff):_0x273247(null);},0x0);});}['addTokenChangeListener'](_0x3bdfec){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3bdfec):this['authProvider_']['get']()['then'](_0xe414c=>_0xe414c['addAuthTokenListener'](_0x3bdfec));}['removeTokenChangeListener'](_0x1de374){this['authProvider_']['get']()['then'](_0x5e715a=>_0x5e715a['removeAuthTokenListener'](_0x1de374));}['notifyForInvalidToken'](){let _0x38afe8='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x38afe8+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x38afe8+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x38afe8+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x38afe8);}}class tn{constructor(_0x39c171){this['accessToken']=_0x39c171;}['getToken'](_0x411384){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4eeeec){_0x4eeeec(this['accessToken']);}['removeTokenChangeListener'](_0x208c43){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x2117c0,_0x1a7951,_0x139531,_0x9d60f3,_0x5d6c9b=!0x1,_0x1305b6='',_0x1585ce=!0x1,_0x2411ae=!0x1,_0x446cd9=null){this['secure']=_0x1a7951,this['namespace']=_0x139531,this['webSocketOnly']=_0x9d60f3,this['nodeAdmin']=_0x5d6c9b,this['persistenceKey']=_0x1305b6,this['includeNamespaceInQueryParams']=_0x1585ce,this['isUsingEmulator']=_0x2411ae,this['emulatorOptions']=_0x446cd9,this['_host']=_0x2117c0['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x2117c0)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x81ca32){_0x81ca32!==this['internalHost']&&(this['internalHost']=_0x81ca32,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4a916f=this['toURLString']();return this['persistenceKey']&&(_0x4a916f+='<'+this['persistenceKey']+'>'),_0x4a916f;}['toURLString'](){const _0xc8a672=this['secure']?'https://':'http://',_0x44a366=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xc8a672+this['host']+'/'+_0x44a366;}}function Xl(_0x289bd9){return _0x289bd9['host']!==_0x289bd9['internalHost']||_0x289bd9['isCustomHost']()||_0x289bd9['includeNamespaceInQueryParams'];}function go(_0xc8542b,_0x7616c8,_0x390112){f(typeof _0x7616c8=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x390112=='object','typeof\x20params\x20must\x20==\x20object');let _0x57afe2;if(_0x7616c8===fo)_0x57afe2=(_0xc8542b['secure']?'wss://':'ws://')+_0xc8542b['internalHost']+'/.ws?';else{if(_0x7616c8===po)_0x57afe2=(_0xc8542b['secure']?'https://':'http://')+_0xc8542b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x7616c8);}Xl(_0xc8542b)&&(_0x390112['ns']=_0xc8542b['namespace']);const _0x52f893=[];return x(_0x390112,(_0x2f89a1,_0x5d7578)=>{_0x52f893['push'](_0x2f89a1+'='+_0x5d7578);}),_0x57afe2+_0x52f893['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0xa290a7,_0x5a6c8f=0x1){Y(this['counters_'],_0xa290a7)||(this['counters_'][_0xa290a7]=0x0),this['counters_'][_0xa290a7]+=_0x5a6c8f;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x16fc8d){const _0x3f9de8=_0x16fc8d['toString']();return ti[_0x3f9de8]||(ti[_0x3f9de8]=new Zl()),ti[_0x3f9de8];}function eh(_0xdb0e72,_0x5ef529){const _0x75174e=_0xdb0e72['toString']();return ni[_0x75174e]||(ni[_0x75174e]=_0x5ef529()),ni[_0x75174e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4d824a){this['onMessage_']=_0x4d824a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4a0160,_0x4ed006){this['closeAfterResponse']=_0x4a0160,this['onClose']=_0x4ed006,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x30d32a,_0x3b78c1){for(this['pendingResponses'][_0x30d32a]=_0x3b78c1;this['pendingResponses'][this['currentResponseNum']];){const _0x1d637d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x286e87=0x0;_0x286e87<_0x1d637d['length'];++_0x286e87)_0x1d637d[_0x286e87]&&lt(()=>{this['onMessage_'](_0x1d637d[_0x286e87]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x330cf9,_0x37439e,_0x59c305,_0x1f5b8c,_0x410fcd,_0xc2e03c,_0x39ff79){this['connId']=_0x330cf9,this['repoInfo']=_0x37439e,this['applicationId']=_0x59c305,this['appCheckToken']=_0x1f5b8c,this['authToken']=_0x410fcd,this['transportSessionId']=_0xc2e03c,this['lastSessionId']=_0x39ff79,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x330cf9),this['stats_']=Hi(_0x37439e),this['urlFn']=_0x4a26e3=>(this['appCheckToken']&&(_0x4a26e3[yi]=this['appCheckToken']),go(_0x37439e,po,_0x4a26e3));}['open'](_0x240076,_0x3c9ad5){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3c9ad5,this['myPacketOrderer']=new th(_0x240076),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x42118b)=>{const [_0x420ed0,_0x2d9adc,_0x43faa6,_0x28f9a0,_0x360731]=_0x42118b;if(this['incrementIncomingBytes_'](_0x42118b),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x420ed0===$s)this['id']=_0x2d9adc,this['password']=_0x43faa6;else{if(_0x420ed0===nh)_0x2d9adc?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2d9adc,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x420ed0);}}},(..._0x10fa39)=>{const [_0x3173cd,_0x67fcd1]=_0x10fa39;this['incrementIncomingBytes_'](_0x10fa39),this['myPacketOrderer']['handleResponse'](_0x3173cd,_0x67fcd1);},()=>{this['onClosed_']();},this['urlFn']);const _0x34925f={};_0x34925f[$s]='t',_0x34925f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x34925f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x34925f[ro]=Vi,this['transportSessionId']&&(_0x34925f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x34925f[ho]=this['lastSessionId']),this['applicationId']&&(_0x34925f[uo]=this['applicationId']),this['appCheckToken']&&(_0x34925f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x34925f[ao]=co);const _0x16b3a5=this['urlFn'](_0x34925f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x16b3a5),this['scriptTagHolder']['addTag'](_0x16b3a5,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3c8252){const _0x1a0116=O(_0x3c8252);this['bytesSent']+=_0x1a0116['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1a0116['length']);const _0x15356b=Br(_0x1a0116),_0x381a9a=io(_0x15356b,hh);for(let _0x7b7423=0x0;_0x7b7423<_0x381a9a['length'];_0x7b7423++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x381a9a['length'],_0x381a9a[_0x7b7423]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x66d2a0,_0x12c20c){this['myDisconnFrame']=document['createElement']('iframe');const _0x3f03fd={};_0x3f03fd[lh]='t',_0x3f03fd[mo]=_0x66d2a0,_0x3f03fd[yo]=_0x12c20c,this['myDisconnFrame']['src']=this['urlFn'](_0x3f03fd),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4056b3){const _0x1421ca=O(_0x4056b3)['length'];this['bytesReceived']+=_0x1421ca,this['stats_']['incrementCounter']('bytes_received',_0x1421ca);}}class $i{constructor(_0x61660d,_0x180349,_0x4a39f6,_0x2acd34){this['onDisconnect']=_0x4a39f6,this['urlFn']=_0x2acd34,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x61660d,window[sh+this['uniqueCallbackIdentifier']]=_0x180349,this['myIFrame']=$i['createIFrame_']();let _0x3efe50='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3efe50='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x400bc6='<html><body>'+_0x3efe50+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x400bc6),this['myIFrame']['doc']['close']();}catch(_0x400409){L('frame\x20writing\x20exception'),_0x400409['stack']&&L(_0x400409['stack']),L(_0x400409);}}}static['createIFrame_'](){const _0x563b32=document['createElement']('iframe');if(_0x563b32['style']['display']='none',document['body']){document['body']['appendChild'](_0x563b32);try{_0x563b32['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x14bf3c=document['domain'];_0x563b32['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x14bf3c+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x563b32['contentDocument']?_0x563b32['doc']=_0x563b32['contentDocument']:_0x563b32['contentWindow']?_0x563b32['doc']=_0x563b32['contentWindow']['document']:_0x563b32['document']&&(_0x563b32['doc']=_0x563b32['document']),_0x563b32;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x46220=this['onDisconnect'];_0x46220&&(this['onDisconnect']=null,_0x46220());}['startLongPoll'](_0x59a312,_0x344c82){for(this['myID']=_0x59a312,this['myPW']=_0x344c82,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x429c9e={};_0x429c9e[mo]=this['myID'],_0x429c9e[yo]=this['myPW'],_0x429c9e[vo]=this['currentSerial'];let _0x40f20b=this['urlFn'](_0x429c9e),_0x3c867a='',_0x4041ed=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x3c867a['length']<=Eo;){const _0x5ad71f=this['pendingSegs']['shift']();_0x3c867a=_0x3c867a+'&'+oh+_0x4041ed+'='+_0x5ad71f['seg']+'&'+ah+_0x4041ed+'='+_0x5ad71f['ts']+'&'+ch+_0x4041ed+'='+_0x5ad71f['d'],_0x4041ed++;}return _0x40f20b=_0x40f20b+_0x3c867a,this['addLongPollTag_'](_0x40f20b,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x376546,_0x16b1bb,_0x4e34ac){this['pendingSegs']['push']({'seg':_0x376546,'ts':_0x16b1bb,'d':_0x4e34ac}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x367e3d,_0x7bfab6){this['outstandingRequests']['add'](_0x7bfab6);const _0x5174c8=()=>{this['outstandingRequests']['delete'](_0x7bfab6),this['newRequest_']();},_0x57367f=setTimeout(_0x5174c8,Math['floor'](uh)),_0x5c9fb1=()=>{clearTimeout(_0x57367f),_0x5174c8();};this['addTag'](_0x367e3d,_0x5c9fb1);}['addTag'](_0x53b015,_0x47c8f4){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3e0ff9=this['myIFrame']['doc']['createElement']('script');_0x3e0ff9['type']='text/javascript',_0x3e0ff9['async']=!0x0,_0x3e0ff9['src']=_0x53b015,_0x3e0ff9['onload']=_0x3e0ff9['onreadystatechange']=function(){const _0x540d43=_0x3e0ff9['readyState'];(!_0x540d43||_0x540d43==='loaded'||_0x540d43==='complete')&&(_0x3e0ff9['onload']=_0x3e0ff9['onreadystatechange']=null,_0x3e0ff9['parentNode']&&_0x3e0ff9['parentNode']['removeChild'](_0x3e0ff9),_0x47c8f4());},_0x3e0ff9['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x53b015),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3e0ff9);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x32a241,_0x1eb55f,_0x42191b,_0x1ddcb7,_0x12dc8b,_0x1ff7c2,_0x5a6ed1){this['connId']=_0x32a241,this['applicationId']=_0x42191b,this['appCheckToken']=_0x1ddcb7,this['authToken']=_0x12dc8b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x1eb55f),this['connURL']=G['connectionURL_'](_0x1eb55f,_0x1ff7c2,_0x5a6ed1,_0x1ddcb7,_0x42191b),this['nodeAdmin']=_0x1eb55f['nodeAdmin'];}static['connectionURL_'](_0x45aaf3,_0x181e20,_0x57280a,_0x109639,_0x463770){const _0x1db03b={};return _0x1db03b[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1db03b[ao]=co),_0x181e20&&(_0x1db03b[oo]=_0x181e20),_0x57280a&&(_0x1db03b[ho]=_0x57280a),_0x109639&&(_0x1db03b[yi]=_0x109639),_0x463770&&(_0x1db03b[uo]=_0x463770),go(_0x45aaf3,fo,_0x1db03b);}['open'](_0xa80184,_0x1d73d4){this['onDisconnect']=_0x1d73d4,this['onMessage']=_0xa80184,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1895fc;dc(),this['mySock']=new hn(this['connURL'],[],_0x1895fc);}catch(_0x5c4224){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x58a8cb=_0x5c4224['message']||_0x5c4224['data'];_0x58a8cb&&this['log_'](_0x58a8cb),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3d7db7=>{this['handleIncomingFrame'](_0x3d7db7);},this['mySock']['onerror']=_0x2aed28=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3abeca=_0x2aed28['message']||_0x2aed28['data'];_0x3abeca&&this['log_'](_0x3abeca),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x335e7a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x55cfcd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x45d0f9=navigator['userAgent']['match'](_0x55cfcd);_0x45d0f9&&_0x45d0f9['length']>0x1&&parseFloat(_0x45d0f9[0x1])<4.4&&(_0x335e7a=!0x0);}return!_0x335e7a&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3370db){if(this['frames']['push'](_0x3370db),this['frames']['length']===this['totalFrames']){const _0x148728=this['frames']['join']('');this['frames']=null;const _0x5707d7=bt(_0x148728);this['onMessage'](_0x5707d7);}}['handleNewFrameCount_'](_0x72fa0f){this['totalFrames']=_0x72fa0f,this['frames']=[];}['extractFrameCount_'](_0x346d46){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x346d46['length']<=0x6){const _0x4c1eb3=Number(_0x346d46);if(!isNaN(_0x4c1eb3))return this['handleNewFrameCount_'](_0x4c1eb3),null;}return this['handleNewFrameCount_'](0x1),_0x346d46;}['handleIncomingFrame'](_0x5d7eb9){if(this['mySock']===null)return;const _0x25f1c8=_0x5d7eb9['data'];if(this['bytesReceived']+=_0x25f1c8['length'],this['stats_']['incrementCounter']('bytes_received',_0x25f1c8['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x25f1c8);else{const _0x509f10=this['extractFrameCount_'](_0x25f1c8);_0x509f10!==null&&this['appendFrame_'](_0x509f10);}}['send'](_0x2092a1){this['resetKeepAlive']();const _0xc7a261=O(_0x2092a1);this['bytesSent']+=_0xc7a261['length'],this['stats_']['incrementCounter']('bytes_sent',_0xc7a261['length']);const _0x22802d=io(_0xc7a261,fh);_0x22802d['length']>0x1&&this['sendString_'](String(_0x22802d['length']));for(let _0x3436d6=0x0;_0x3436d6<_0x22802d['length'];_0x3436d6++)this['sendString_'](_0x22802d[_0x3436d6]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x317dcb){try{this['mySock']['send'](_0x317dcb);}catch(_0x1e50ee){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1e50ee['message']||_0x1e50ee['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2127b7){this['initTransports_'](_0x2127b7);}['initTransports_'](_0x40c269){const _0x468aab=G&&G['isAvailable']();let _0x52e327=_0x468aab&&!G['previouslyFailed']();if(_0x40c269['webSocketOnly']&&(_0x468aab||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x52e327=!0x0),_0x52e327)this['transports_']=[G];else{const _0x2d5850=this['transports_']=[];for(const _0x2c272b of At['ALL_TRANSPORTS'])_0x2c272b&&_0x2c272b['isAvailable']()&&_0x2d5850['push'](_0x2c272b);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x234867,_0x392ed0,_0x2d0303,_0x5a9d14,_0x4b5c58,_0x3a34c6,_0x2b6ec6,_0x5dec51,_0x4570bd,_0x33553e){this['id']=_0x234867,this['repoInfo_']=_0x392ed0,this['applicationId_']=_0x2d0303,this['appCheckToken_']=_0x5a9d14,this['authToken_']=_0x4b5c58,this['onMessage_']=_0x3a34c6,this['onReady_']=_0x2b6ec6,this['onDisconnect_']=_0x5dec51,this['onKill_']=_0x4570bd,this['lastSessionId']=_0x33553e,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x392ed0),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3d3c1a=this['transportManager_']['initialTransport']();this['conn_']=new _0x3d3c1a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3d3c1a['responsesRequiredToBeHealthy']||0x0;const _0x400dff=this['connReceiver_'](this['conn_']),_0x5546ef=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x400dff,_0x5546ef);},Math['floor'](0x0));const _0xe0e5f7=_0x3d3c1a['healthyTimeout']||0x0;_0xe0e5f7>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xe0e5f7)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1870ba){return _0x18c46b=>{_0x1870ba===this['conn_']?this['onConnectionLost_'](_0x18c46b):_0x1870ba===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x379fef){return _0x16e1b8=>{this['state_']!==0x2&&(_0x379fef===this['rx_']?this['onPrimaryMessageReceived_'](_0x16e1b8):_0x379fef===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x16e1b8):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x28385e){const _0x4f1e35={'t':'d','d':_0x28385e};this['sendData_'](_0x4f1e35);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x241e81){if(ii in _0x241e81){const _0x18726d=_0x241e81[ii];_0x18726d===js?this['upgradeIfSecondaryHealthy_']():_0x18726d===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x18726d===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3b8f92){const _0x3f9b6b=pt('t',_0x3b8f92),_0x34cb27=pt('d',_0x3b8f92);if(_0x3f9b6b==='c')this['onSecondaryControl_'](_0x34cb27);else{if(_0x3f9b6b==='d')this['pendingDataMessages']['push'](_0x34cb27);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3f9b6b);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x520ce3){const _0x435d53=pt('t',_0x520ce3),_0x5397f2=pt('d',_0x520ce3);_0x435d53==='c'?this['onControl_'](_0x5397f2):_0x435d53==='d'&&this['onDataMessage_'](_0x5397f2);}['onDataMessage_'](_0x581a97){this['onPrimaryResponse_'](),this['onMessage_'](_0x581a97);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x106efb){const _0x19ff1d=pt(ii,_0x106efb);if(Gs in _0x106efb){const _0x27e5e8=_0x106efb[Gs];if(_0x19ff1d===Ih){const _0x124acf={..._0x27e5e8};this['repoInfo_']['isUsingEmulator']&&(_0x124acf['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x124acf);}else{if(_0x19ff1d===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x269fbd=0x0;_0x269fbd<this['pendingDataMessages']['length'];++_0x269fbd)this['onDataMessage_'](this['pendingDataMessages'][_0x269fbd]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x19ff1d===vh?this['onConnectionShutdown_'](_0x27e5e8):_0x19ff1d===qs?this['onReset_'](_0x27e5e8):_0x19ff1d===Eh?mi('Server\x20Error:\x20'+_0x27e5e8):_0x19ff1d===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x19ff1d);}}}['onHandshake_'](_0x258558){const _0x40387a=_0x258558['ts'],_0xf44c95=_0x258558['v'],_0x3c507e=_0x258558['h'];this['sessionId']=_0x258558['s'],this['repoInfo_']['host']=_0x3c507e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x40387a),Vi!==_0xf44c95&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x1559c5=this['transportManager_']['upgradeTransport']();_0x1559c5&&this['startUpgrade_'](_0x1559c5);}['startUpgrade_'](_0x3b6ddc){this['secondaryConn_']=new _0x3b6ddc(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3b6ddc['responsesRequiredToBeHealthy']||0x0;const _0x1b8f05=this['connReceiver_'](this['secondaryConn_']),_0x76ed29=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1b8f05,_0x76ed29),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x4d97e6){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4d97e6),this['repoInfo_']['host']=_0x4d97e6,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1e57ab,_0x3c556d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1e57ab,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3c556d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x40577e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x40577e||this['rx_']===_0x40577e)&&this['close']();}['onConnectionLost_'](_0x49ab93){this['conn_']=null,!_0x49ab93&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x1162a2){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x1162a2),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x18363a){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x18363a);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x546f94,_0x38662,_0x239c22,_0x361c99){}['merge'](_0x83525e,_0x3f8d15,_0x14ba6b,_0x1bf9d0){}['refreshAuthToken'](_0x3e2168){}['refreshAppCheckToken'](_0x4acab5){}['onDisconnectPut'](_0x306b1a,_0x4a950d,_0x32b544){}['onDisconnectMerge'](_0x545c27,_0x21b954,_0x43d2b4){}['onDisconnectCancel'](_0x20ed00,_0x1d2f4b){}['reportStats'](_0x3aa3ac){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x464bdd){this['allowedEvents_']=_0x464bdd,this['listeners_']={},f(Array['isArray'](_0x464bdd)&&_0x464bdd['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x552f5c,..._0xee356c){if(Array['isArray'](this['listeners_'][_0x552f5c])){const _0x24512d=[...this['listeners_'][_0x552f5c]];for(let _0x72402b=0x0;_0x72402b<_0x24512d['length'];_0x72402b++)_0x24512d[_0x72402b]['callback']['apply'](_0x24512d[_0x72402b]['context'],_0xee356c);}}['on'](_0x56f9eb,_0x292bae,_0x3b81d8){this['validateEventType_'](_0x56f9eb),this['listeners_'][_0x56f9eb]=this['listeners_'][_0x56f9eb]||[],this['listeners_'][_0x56f9eb]['push']({'callback':_0x292bae,'context':_0x3b81d8});const _0x295e3b=this['getInitialEvent'](_0x56f9eb);_0x295e3b&&_0x292bae['apply'](_0x3b81d8,_0x295e3b);}['off'](_0x2454c7,_0x37ac81,_0x7eaa81){this['validateEventType_'](_0x2454c7);const _0x2bb492=this['listeners_'][_0x2454c7]||[];for(let _0x249fa0=0x0;_0x249fa0<_0x2bb492['length'];_0x249fa0++)if(_0x2bb492[_0x249fa0]['callback']===_0x37ac81&&(!_0x7eaa81||_0x7eaa81===_0x2bb492[_0x249fa0]['context'])){_0x2bb492['splice'](_0x249fa0,0x1);return;}}['validateEventType_'](_0x3e59e3){f(this['allowedEvents_']['find'](_0x369aac=>_0x369aac===_0x3e59e3),'Unknown\x20event:\x20'+_0x3e59e3);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3c86b0){return f(_0x3c86b0==='online','Unknown\x20event\x20type:\x20'+_0x3c86b0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x690b24,_0x446abb){if(_0x446abb===void 0x0){this['pieces_']=_0x690b24['split']('/');let _0x2441da=0x0;for(let _0x2ac94f=0x0;_0x2ac94f<this['pieces_']['length'];_0x2ac94f++)this['pieces_'][_0x2ac94f]['length']>0x0&&(this['pieces_'][_0x2441da]=this['pieces_'][_0x2ac94f],_0x2441da++);this['pieces_']['length']=_0x2441da,this['pieceNum_']=0x0;}else this['pieces_']=_0x690b24,this['pieceNum_']=_0x446abb;}['toString'](){let _0x3887f4='';for(let _0x389c26=this['pieceNum_'];_0x389c26<this['pieces_']['length'];_0x389c26++)this['pieces_'][_0x389c26]!==''&&(_0x3887f4+='/'+this['pieces_'][_0x389c26]);return _0x3887f4||'/';}}function w(){return new C('');}function y(_0x544265){return _0x544265['pieceNum_']>=_0x544265['pieces_']['length']?null:_0x544265['pieces_'][_0x544265['pieceNum_']];}function we(_0x3931f7){return _0x3931f7['pieces_']['length']-_0x3931f7['pieceNum_'];}function b(_0x22b918){let _0x57c479=_0x22b918['pieceNum_'];return _0x57c479<_0x22b918['pieces_']['length']&&_0x57c479++,new C(_0x22b918['pieces_'],_0x57c479);}function Gi(_0x5347d8){return _0x5347d8['pieceNum_']<_0x5347d8['pieces_']['length']?_0x5347d8['pieces_'][_0x5347d8['pieces_']['length']-0x1]:null;}function Ch(_0xb7a1e0){let _0x37eefa='';for(let _0x946144=_0xb7a1e0['pieceNum_'];_0x946144<_0xb7a1e0['pieces_']['length'];_0x946144++)_0xb7a1e0['pieces_'][_0x946144]!==''&&(_0x37eefa+='/'+encodeURIComponent(String(_0xb7a1e0['pieces_'][_0x946144])));return _0x37eefa||'/';}function kt(_0x4be79d,_0x4d59a1=0x0){return _0x4be79d['pieces_']['slice'](_0x4be79d['pieceNum_']+_0x4d59a1);}function To(_0x1f75b2){if(_0x1f75b2['pieceNum_']>=_0x1f75b2['pieces_']['length'])return null;const _0x565393=[];for(let _0x1b833b=_0x1f75b2['pieceNum_'];_0x1b833b<_0x1f75b2['pieces_']['length']-0x1;_0x1b833b++)_0x565393['push'](_0x1f75b2['pieces_'][_0x1b833b]);return new C(_0x565393,0x0);}function A(_0x1aa26d,_0x1db8a6){const _0x51a5ca=[];for(let _0x4c95bf=_0x1aa26d['pieceNum_'];_0x4c95bf<_0x1aa26d['pieces_']['length'];_0x4c95bf++)_0x51a5ca['push'](_0x1aa26d['pieces_'][_0x4c95bf]);if(_0x1db8a6 instanceof C){for(let _0x4576d8=_0x1db8a6['pieceNum_'];_0x4576d8<_0x1db8a6['pieces_']['length'];_0x4576d8++)_0x51a5ca['push'](_0x1db8a6['pieces_'][_0x4576d8]);}else{const _0x256416=_0x1db8a6['split']('/');for(let _0x534afe=0x0;_0x534afe<_0x256416['length'];_0x534afe++)_0x256416[_0x534afe]['length']>0x0&&_0x51a5ca['push'](_0x256416[_0x534afe]);}return new C(_0x51a5ca,0x0);}function v(_0x244e60){return _0x244e60['pieceNum_']>=_0x244e60['pieces_']['length'];}function F(_0x465b36,_0x4c9ced){const _0x949bf8=y(_0x465b36),_0x3493b6=y(_0x4c9ced);if(_0x949bf8===null)return _0x4c9ced;if(_0x949bf8===_0x3493b6)return F(b(_0x465b36),b(_0x4c9ced));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4c9ced+')\x20is\x20not\x20within\x20outerPath\x20('+_0x465b36+')');}function Th(_0x1b0700,_0x23a929){const _0x1bd725=kt(_0x1b0700,0x0),_0x390629=kt(_0x23a929,0x0);for(let _0x28fe28=0x0;_0x28fe28<_0x1bd725['length']&&_0x28fe28<_0x390629['length'];_0x28fe28++){const _0x478b9a=He(_0x1bd725[_0x28fe28],_0x390629[_0x28fe28]);if(_0x478b9a!==0x0)return _0x478b9a;}return _0x1bd725['length']===_0x390629['length']?0x0:_0x1bd725['length']<_0x390629['length']?-0x1:0x1;}function qi(_0xdb821e,_0x4aad76){if(we(_0xdb821e)!==we(_0x4aad76))return!0x1;for(let _0x1593ec=_0xdb821e['pieceNum_'],_0x1b3379=_0x4aad76['pieceNum_'];_0x1593ec<=_0xdb821e['pieces_']['length'];_0x1593ec++,_0x1b3379++)if(_0xdb821e['pieces_'][_0x1593ec]!==_0x4aad76['pieces_'][_0x1b3379])return!0x1;return!0x0;}function $(_0x1dd967,_0x4e0421){let _0x4a13fd=_0x1dd967['pieceNum_'],_0x47ab51=_0x4e0421['pieceNum_'];if(we(_0x1dd967)>we(_0x4e0421))return!0x1;for(;_0x4a13fd<_0x1dd967['pieces_']['length'];){if(_0x1dd967['pieces_'][_0x4a13fd]!==_0x4e0421['pieces_'][_0x47ab51])return!0x1;++_0x4a13fd,++_0x47ab51;}return!0x0;}class Sh{constructor(_0x3388fc,_0x544042){this['errorPrefix_']=_0x544042,this['parts_']=kt(_0x3388fc,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5e4246=0x0;_0x5e4246<this['parts_']['length'];_0x5e4246++)this['byteLength_']+=Pn(this['parts_'][_0x5e4246]);So(this);}}function bh(_0x44bf1c,_0x31479a){_0x44bf1c['parts_']['length']>0x0&&(_0x44bf1c['byteLength_']+=0x1),_0x44bf1c['parts_']['push'](_0x31479a),_0x44bf1c['byteLength_']+=Pn(_0x31479a),So(_0x44bf1c);}function Rh(_0x5dab2e){const _0x42292a=_0x5dab2e['parts_']['pop']();_0x5dab2e['byteLength_']-=Pn(_0x42292a),_0x5dab2e['parts_']['length']>0x0&&(_0x5dab2e['byteLength_']-=0x1);}function So(_0x416dc8){if(_0x416dc8['byteLength_']>Js)throw new Error(_0x416dc8['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x416dc8['byteLength_']+').');if(_0x416dc8['parts_']['length']>Qs)throw new Error(_0x416dc8['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x416dc8));}function Ne(_0xd2dbd7){return _0xd2dbd7['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xd2dbd7['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x2223fe,_0x466fc1;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x466fc1='visibilitychange',_0x2223fe='hidden'):typeof document['mozHidden']<'u'?(_0x466fc1='mozvisibilitychange',_0x2223fe='mozHidden'):typeof document['msHidden']<'u'?(_0x466fc1='msvisibilitychange',_0x2223fe='msHidden'):typeof document['webkitHidden']<'u'&&(_0x466fc1='webkitvisibilitychange',_0x2223fe='webkitHidden')),this['visible_']=!0x0,_0x466fc1&&document['addEventListener'](_0x466fc1,()=>{const _0x28185d=!document[_0x2223fe];_0x28185d!==this['visible_']&&(this['visible_']=_0x28185d,this['trigger']('visible',_0x28185d));},!0x1);}['getInitialEvent'](_0x1c0a84){return f(_0x1c0a84==='visible','Unknown\x20event\x20type:\x20'+_0x1c0a84),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0xf9638b,_0x173994,_0x14c459,_0x2d86fa,_0x2a8ae3,_0xa44975,_0x2e12df,_0x15fcd9){if(super(),this['repoInfo_']=_0xf9638b,this['applicationId_']=_0x173994,this['onDataUpdate_']=_0x14c459,this['onConnectStatus_']=_0x2d86fa,this['onServerInfoUpdate_']=_0x2a8ae3,this['authTokenProvider_']=_0xa44975,this['appCheckTokenProvider_']=_0x2e12df,this['authOverride_']=_0x15fcd9,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x15fcd9)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0xf9638b['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4b746a,_0x4c624b,_0x1529e9){const _0x14d876=++this['requestNumber_'],_0x46235b={'r':_0x14d876,'a':_0x4b746a,'b':_0x4c624b};this['log_'](O(_0x46235b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x46235b),_0x1529e9&&(this['requestCBHash_'][_0x14d876]=_0x1529e9);}['get'](_0x1d1d27){this['initConnection_']();const _0xa47c5b=new Ve(),_0x3234c8={'action':'g','request':{'p':_0x1d1d27['_path']['toString'](),'q':_0x1d1d27['_queryObject']},'onComplete':_0x13ca46=>{const _0x245e6b=_0x13ca46['d'];_0x13ca46['s']==='ok'?_0xa47c5b['resolve'](_0x245e6b):_0xa47c5b['reject'](_0x245e6b);}};this['outstandingGets_']['push'](_0x3234c8),this['outstandingGetCount_']++;const _0x56994b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x56994b),_0xa47c5b['promise'];}['listen'](_0x1909d9,_0x2fd9c3,_0x53f0f4,_0x5689a1){this['initConnection_']();const _0x260981=_0x1909d9['_queryIdentifier'],_0x31d134=_0x1909d9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x31d134+'\x20'+_0x260981),this['listens']['has'](_0x31d134)||this['listens']['set'](_0x31d134,new Map()),f(_0x1909d9['_queryParams']['isDefault']()||!_0x1909d9['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x31d134)['has'](_0x260981),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5aa407={'onComplete':_0x5689a1,'hashFn':_0x2fd9c3,'query':_0x1909d9,'tag':_0x53f0f4};this['listens']['get'](_0x31d134)['set'](_0x260981,_0x5aa407),this['connected_']&&this['sendListen_'](_0x5aa407);}['sendGet_'](_0x55b2b7){const _0x546819=this['outstandingGets_'][_0x55b2b7];this['sendRequest']('g',_0x546819['request'],_0x5eda8f=>{delete this['outstandingGets_'][_0x55b2b7],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x546819['onComplete']&&_0x546819['onComplete'](_0x5eda8f);});}['sendListen_'](_0x564c5e){const _0x55aef6=_0x564c5e['query'],_0x4998a7=_0x55aef6['_path']['toString'](),_0x3d6f35=_0x55aef6['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4998a7+'\x20for\x20'+_0x3d6f35);const _0x53c983={'p':_0x4998a7},_0x3a8003='q';_0x564c5e['tag']&&(_0x53c983['q']=_0x55aef6['_queryObject'],_0x53c983['t']=_0x564c5e['tag']),_0x53c983['h']=_0x564c5e['hashFn'](),this['sendRequest'](_0x3a8003,_0x53c983,_0x1cc649=>{const _0x16586f=_0x1cc649['d'],_0x318683=_0x1cc649['s'];ie['warnOnListenWarnings_'](_0x16586f,_0x55aef6),(this['listens']['get'](_0x4998a7)&&this['listens']['get'](_0x4998a7)['get'](_0x3d6f35))===_0x564c5e&&(this['log_']('listen\x20response',_0x1cc649),_0x318683!=='ok'&&this['removeListen_'](_0x4998a7,_0x3d6f35),_0x564c5e['onComplete']&&_0x564c5e['onComplete'](_0x318683,_0x16586f));});}static['warnOnListenWarnings_'](_0x5d52c9,_0x167311){if(_0x5d52c9&&typeof _0x5d52c9=='object'&&Y(_0x5d52c9,'w')){const _0x5c626f=Oe(_0x5d52c9,'w');if(Array['isArray'](_0x5c626f)&&~_0x5c626f['indexOf']('no_index')){const _0x3d307d='\x22.indexOn\x22:\x20\x22'+_0x167311['_queryParams']['getIndex']()['toString']()+'\x22',_0x3dd888=_0x167311['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3d307d+'\x20at\x20'+_0x3dd888+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x257577){this['authToken_']=_0x257577,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x257577);}['reduceReconnectDelayIfAdminCredential_'](_0x14d59e){(_0x14d59e&&_0x14d59e['length']===0x28||vc(_0x14d59e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x242278){this['appCheckToken_']=_0x242278,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xe48437=this['authToken_'],_0x59709d=yc(_0xe48437)?'auth':'gauth',_0xf3070c={'cred':_0xe48437};this['authOverride_']===null?_0xf3070c['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xf3070c['authvar']=this['authOverride_']),this['sendRequest'](_0x59709d,_0xf3070c,_0x4e2d99=>{const _0x562b70=_0x4e2d99['s'],_0x3d3186=_0x4e2d99['d']||'error';this['authToken_']===_0xe48437&&(_0x562b70==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x562b70,_0x3d3186));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2ad6cc=>{const _0x37a523=_0x2ad6cc['s'],_0x42ecb6=_0x2ad6cc['d']||'error';_0x37a523==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x37a523,_0x42ecb6);});}['unlisten'](_0x35c5a9,_0xb367cd){const _0x58dc96=_0x35c5a9['_path']['toString'](),_0x5cd788=_0x35c5a9['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x58dc96+'\x20'+_0x5cd788),f(_0x35c5a9['_queryParams']['isDefault']()||!_0x35c5a9['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x58dc96,_0x5cd788)&&this['connected_']&&this['sendUnlisten_'](_0x58dc96,_0x5cd788,_0x35c5a9['_queryObject'],_0xb367cd);}['sendUnlisten_'](_0x35cf2e,_0x219f06,_0x48c254,_0x1fe2bf){this['log_']('Unlisten\x20on\x20'+_0x35cf2e+'\x20for\x20'+_0x219f06);const _0x2270b1={'p':_0x35cf2e},_0x1ff80e='n';_0x1fe2bf&&(_0x2270b1['q']=_0x48c254,_0x2270b1['t']=_0x1fe2bf),this['sendRequest'](_0x1ff80e,_0x2270b1);}['onDisconnectPut'](_0x26eab7,_0x54411b,_0x4521ea){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x26eab7,_0x54411b,_0x4521ea):this['onDisconnectRequestQueue_']['push']({'pathString':_0x26eab7,'action':'o','data':_0x54411b,'onComplete':_0x4521ea});}['onDisconnectMerge'](_0x53dd6d,_0x1bdd45,_0x2b4703){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x53dd6d,_0x1bdd45,_0x2b4703):this['onDisconnectRequestQueue_']['push']({'pathString':_0x53dd6d,'action':'om','data':_0x1bdd45,'onComplete':_0x2b4703});}['onDisconnectCancel'](_0x13f729,_0x2fe8d2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x13f729,null,_0x2fe8d2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x13f729,'action':'oc','data':null,'onComplete':_0x2fe8d2});}['sendOnDisconnect_'](_0x53847f,_0x1b0a49,_0x37fe33,_0x370194){const _0x111777={'p':_0x1b0a49,'d':_0x37fe33};this['log_']('onDisconnect\x20'+_0x53847f,_0x111777),this['sendRequest'](_0x53847f,_0x111777,_0x2e0822=>{_0x370194&&setTimeout(()=>{_0x370194(_0x2e0822['s'],_0x2e0822['d']);},Math['floor'](0x0));});}['put'](_0x12dfd0,_0x4b0a23,_0x12fe54,_0x5b9257){this['putInternal']('p',_0x12dfd0,_0x4b0a23,_0x12fe54,_0x5b9257);}['merge'](_0x4b2cc4,_0x5f51c7,_0x4da671,_0xb2812f){this['putInternal']('m',_0x4b2cc4,_0x5f51c7,_0x4da671,_0xb2812f);}['putInternal'](_0x49eb90,_0xc2f2bc,_0x4bc1e9,_0x3cb233,_0x309d35){this['initConnection_']();const _0x29d62c={'p':_0xc2f2bc,'d':_0x4bc1e9};_0x309d35!==void 0x0&&(_0x29d62c['h']=_0x309d35),this['outstandingPuts_']['push']({'action':_0x49eb90,'request':_0x29d62c,'onComplete':_0x3cb233}),this['outstandingPutCount_']++;const _0x14403f=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x14403f):this['log_']('Buffering\x20put:\x20'+_0xc2f2bc);}['sendPut_'](_0xf96bab){const _0x58636b=this['outstandingPuts_'][_0xf96bab]['action'],_0x30b965=this['outstandingPuts_'][_0xf96bab]['request'],_0x1d169e=this['outstandingPuts_'][_0xf96bab]['onComplete'];this['outstandingPuts_'][_0xf96bab]['queued']=this['connected_'],this['sendRequest'](_0x58636b,_0x30b965,_0x5b257d=>{this['log_'](_0x58636b+'\x20response',_0x5b257d),delete this['outstandingPuts_'][_0xf96bab],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1d169e&&_0x1d169e(_0x5b257d['s'],_0x5b257d['d']);});}['reportStats'](_0x583578){if(this['connected_']){const _0x6f7481={'c':_0x583578};this['log_']('reportStats',_0x6f7481),this['sendRequest']('s',_0x6f7481,_0x15372e=>{if(_0x15372e['s']!=='ok'){const _0x2dd2fb=_0x15372e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2dd2fb);}});}}['onDataMessage_'](_0x5c2241){if('r'in _0x5c2241){this['log_']('from\x20server:\x20'+O(_0x5c2241));const _0x187683=_0x5c2241['r'],_0x26e8d3=this['requestCBHash_'][_0x187683];_0x26e8d3&&(delete this['requestCBHash_'][_0x187683],_0x26e8d3(_0x5c2241['b']));}else{if('error'in _0x5c2241)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5c2241['error'];'a'in _0x5c2241&&this['onDataPush_'](_0x5c2241['a'],_0x5c2241['b']);}}['onDataPush_'](_0x10a30a,_0x5968bc){this['log_']('handleServerMessage',_0x10a30a,_0x5968bc),_0x10a30a==='d'?this['onDataUpdate_'](_0x5968bc['p'],_0x5968bc['d'],!0x1,_0x5968bc['t']):_0x10a30a==='m'?this['onDataUpdate_'](_0x5968bc['p'],_0x5968bc['d'],!0x0,_0x5968bc['t']):_0x10a30a==='c'?this['onListenRevoked_'](_0x5968bc['p'],_0x5968bc['q']):_0x10a30a==='ac'?this['onAuthRevoked_'](_0x5968bc['s'],_0x5968bc['d']):_0x10a30a==='apc'?this['onAppCheckRevoked_'](_0x5968bc['s'],_0x5968bc['d']):_0x10a30a==='sd'?this['onSecurityDebugPacket_'](_0x5968bc):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x10a30a)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x30eb7a,_0x46cd27){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x30eb7a),this['lastSessionId']=_0x46cd27,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x43fcaa){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x43fcaa));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x159389){_0x159389&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x159389;}['onOnline_'](_0x4681ca){_0x4681ca?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5da0b0=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x25117b=Math['max'](0x0,this['reconnectDelay_']-_0x5da0b0);_0x25117b=Math['random']()*_0x25117b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x25117b+'ms'),this['scheduleConnect_'](_0x25117b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2e1d61=this['onDataMessage_']['bind'](this),_0x1c215f=this['onReady_']['bind'](this),_0x31ffce=this['onRealtimeDisconnect_']['bind'](this),_0x500dda=this['id']+':'+ie['nextConnectionId_']++,_0x5322ce=this['lastSessionId'];let _0x9244c0=!0x1,_0x42ac62=null;const _0x196d79=function(){_0x42ac62?_0x42ac62['close']():(_0x9244c0=!0x0,_0x31ffce());},_0x11481a=function(_0xf4d366){f(_0x42ac62,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x42ac62['sendRequest'](_0xf4d366);};this['realtime_']={'close':_0x196d79,'sendRequest':_0x11481a};const _0x52ff85=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3fe8fd,_0xaaa58b]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x52ff85),this['appCheckTokenProvider_']['getToken'](_0x52ff85)]);_0x9244c0?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3fe8fd&&_0x3fe8fd['accessToken'],this['appCheckToken_']=_0xaaa58b&&_0xaaa58b['token'],_0x42ac62=new wh(_0x500dda,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2e1d61,_0x1c215f,_0x31ffce,_0x58a8d1=>{U(_0x58a8d1+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5322ce));}catch(_0x2c6a89){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2c6a89),_0x9244c0||(this['repoInfo_']['nodeAdmin']&&U(_0x2c6a89),_0x196d79());}}}['interrupt'](_0x1ae7fc){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x1ae7fc),this['interruptReasons_'][_0x1ae7fc]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x39b5c8){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x39b5c8),delete this['interruptReasons_'][_0x39b5c8],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x254d0f){const _0x68a5ea=_0x254d0f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x68a5ea});}['cancelSentTransactions_'](){for(let _0x28d603=0x0;_0x28d603<this['outstandingPuts_']['length'];_0x28d603++){const _0x13734b=this['outstandingPuts_'][_0x28d603];_0x13734b&&'h'in _0x13734b['request']&&_0x13734b['queued']&&(_0x13734b['onComplete']&&_0x13734b['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x28d603],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x419fdb,_0x4d95a9){let _0x3ff75b;_0x4d95a9?_0x3ff75b=_0x4d95a9['map'](_0x49bf46=>Bi(_0x49bf46))['join']('$'):_0x3ff75b='default';const _0x343b64=this['removeListen_'](_0x419fdb,_0x3ff75b);_0x343b64&&_0x343b64['onComplete']&&_0x343b64['onComplete']('permission_denied');}['removeListen_'](_0x3275a6,_0xb14948){const _0x32c56d=new C(_0x3275a6)['toString']();let _0x41084d;if(this['listens']['has'](_0x32c56d)){const _0x32f24b=this['listens']['get'](_0x32c56d);_0x41084d=_0x32f24b['get'](_0xb14948),_0x32f24b['delete'](_0xb14948),_0x32f24b['size']===0x0&&this['listens']['delete'](_0x32c56d);}else _0x41084d=void 0x0;return _0x41084d;}['onAuthRevoked_'](_0x446e5d,_0x2bbe18){L('Auth\x20token\x20revoked:\x20'+_0x446e5d+'/'+_0x2bbe18),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x446e5d==='invalid_token'||_0x446e5d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x46957f,_0x667082){L('App\x20check\x20token\x20revoked:\x20'+_0x46957f+'/'+_0x667082),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x46957f==='invalid_token'||_0x46957f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x55d534){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x55d534):'msg'in _0x55d534&&console['log']('FIREBASE:\x20'+_0x55d534['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x59d2f1 of this['listens']['values']())for(const _0xfbade6 of _0x59d2f1['values']())this['sendListen_'](_0xfbade6);for(let _0x4f1c43=0x0;_0x4f1c43<this['outstandingPuts_']['length'];_0x4f1c43++)this['outstandingPuts_'][_0x4f1c43]&&this['sendPut_'](_0x4f1c43);for(;this['onDisconnectRequestQueue_']['length'];){const _0x526783=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x526783['action'],_0x526783['pathString'],_0x526783['data'],_0x526783['onComplete']);}for(let _0x592167=0x0;_0x592167<this['outstandingGets_']['length'];_0x592167++)this['outstandingGets_'][_0x592167]&&this['sendGet_'](_0x592167);}['sendConnectStats_'](){const _0x544c27={};let _0x235e92='js';_0x544c27['sdk.'+_0x235e92+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x544c27['framework.cordova']=0x1:qr()&&(_0x544c27['framework.reactnative']=0x1),this['reportStats'](_0x544c27);}['shouldReconnect_'](){const _0x7735b4=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x7735b4;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1aada0,_0x58adfb){this['name']=_0x1aada0,this['node']=_0x58adfb;}static['Wrap'](_0x145cbc,_0x240259){return new E(_0x145cbc,_0x240259);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x11f146,_0x1e93b0){const _0x2553f8=new E(xe,_0x11f146),_0x532d96=new E(xe,_0x1e93b0);return this['compare'](_0x2553f8,_0x532d96)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1dcf14){Xt=_0x1dcf14;}['compare'](_0x4efd43,_0x60b6c4){return He(_0x4efd43['name'],_0x60b6c4['name']);}['isDefinedOn'](_0x1697e8){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x138266,_0xb2e58d){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x2d173c,_0x208135){return f(typeof _0x2d173c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2d173c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x18627a,_0x5331cc,_0x55690e,_0x5e477c,_0x247566=null){this['isReverse_']=_0x5e477c,this['resultGenerator_']=_0x247566,this['nodeStack_']=[];let _0x3c6895=0x1;for(;!_0x18627a['isEmpty']();)if(_0x18627a=_0x18627a,_0x3c6895=_0x5331cc?_0x55690e(_0x18627a['key'],_0x5331cc):0x1,_0x5e477c&&(_0x3c6895*=-0x1),_0x3c6895<0x0)this['isReverse_']?_0x18627a=_0x18627a['left']:_0x18627a=_0x18627a['right'];else{if(_0x3c6895===0x0){this['nodeStack_']['push'](_0x18627a);break;}else this['nodeStack_']['push'](_0x18627a),this['isReverse_']?_0x18627a=_0x18627a['right']:_0x18627a=_0x18627a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1d9800=this['nodeStack_']['pop'](),_0x1ac5ff;if(this['resultGenerator_']?_0x1ac5ff=this['resultGenerator_'](_0x1d9800['key'],_0x1d9800['value']):_0x1ac5ff={'key':_0x1d9800['key'],'value':_0x1d9800['value']},this['isReverse_']){for(_0x1d9800=_0x1d9800['left'];!_0x1d9800['isEmpty']();)this['nodeStack_']['push'](_0x1d9800),_0x1d9800=_0x1d9800['right'];}else{for(_0x1d9800=_0x1d9800['right'];!_0x1d9800['isEmpty']();)this['nodeStack_']['push'](_0x1d9800),_0x1d9800=_0x1d9800['left'];}return _0x1ac5ff;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x14a083=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x14a083['key'],_0x14a083['value']):{'key':_0x14a083['key'],'value':_0x14a083['value']};}}class M{constructor(_0x514d23,_0x5c8e72,_0x58bf21,_0xc364d5,_0x7f158){this['key']=_0x514d23,this['value']=_0x5c8e72,this['color']=_0x58bf21??M['RED'],this['left']=_0xc364d5??B['EMPTY_NODE'],this['right']=_0x7f158??B['EMPTY_NODE'];}['copy'](_0x4c7e15,_0x1defdc,_0x437cde,_0x371c63,_0x171416){return new M(_0x4c7e15??this['key'],_0x1defdc??this['value'],_0x437cde??this['color'],_0x371c63??this['left'],_0x171416??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x389699){return this['left']['inorderTraversal'](_0x389699)||!!_0x389699(this['key'],this['value'])||this['right']['inorderTraversal'](_0x389699);}['reverseTraversal'](_0x572648){return this['right']['reverseTraversal'](_0x572648)||_0x572648(this['key'],this['value'])||this['left']['reverseTraversal'](_0x572648);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2b2d41,_0x71f2f,_0x333baf){let _0x5e1caf=this;const _0x38b8bf=_0x333baf(_0x2b2d41,_0x5e1caf['key']);return _0x38b8bf<0x0?_0x5e1caf=_0x5e1caf['copy'](null,null,null,_0x5e1caf['left']['insert'](_0x2b2d41,_0x71f2f,_0x333baf),null):_0x38b8bf===0x0?_0x5e1caf=_0x5e1caf['copy'](null,_0x71f2f,null,null,null):_0x5e1caf=_0x5e1caf['copy'](null,null,null,null,_0x5e1caf['right']['insert'](_0x2b2d41,_0x71f2f,_0x333baf)),_0x5e1caf['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x493651=this;return!_0x493651['left']['isRed_']()&&!_0x493651['left']['left']['isRed_']()&&(_0x493651=_0x493651['moveRedLeft_']()),_0x493651=_0x493651['copy'](null,null,null,_0x493651['left']['removeMin_'](),null),_0x493651['fixUp_']();}['remove'](_0x54d5f0,_0x2fb10e){let _0x25da0c,_0xe32446;if(_0x25da0c=this,_0x2fb10e(_0x54d5f0,_0x25da0c['key'])<0x0)!_0x25da0c['left']['isEmpty']()&&!_0x25da0c['left']['isRed_']()&&!_0x25da0c['left']['left']['isRed_']()&&(_0x25da0c=_0x25da0c['moveRedLeft_']()),_0x25da0c=_0x25da0c['copy'](null,null,null,_0x25da0c['left']['remove'](_0x54d5f0,_0x2fb10e),null);else{if(_0x25da0c['left']['isRed_']()&&(_0x25da0c=_0x25da0c['rotateRight_']()),!_0x25da0c['right']['isEmpty']()&&!_0x25da0c['right']['isRed_']()&&!_0x25da0c['right']['left']['isRed_']()&&(_0x25da0c=_0x25da0c['moveRedRight_']()),_0x2fb10e(_0x54d5f0,_0x25da0c['key'])===0x0){if(_0x25da0c['right']['isEmpty']())return B['EMPTY_NODE'];_0xe32446=_0x25da0c['right']['min_'](),_0x25da0c=_0x25da0c['copy'](_0xe32446['key'],_0xe32446['value'],null,null,_0x25da0c['right']['removeMin_']());}_0x25da0c=_0x25da0c['copy'](null,null,null,null,_0x25da0c['right']['remove'](_0x54d5f0,_0x2fb10e));}return _0x25da0c['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x27f57a=this;return _0x27f57a['right']['isRed_']()&&!_0x27f57a['left']['isRed_']()&&(_0x27f57a=_0x27f57a['rotateLeft_']()),_0x27f57a['left']['isRed_']()&&_0x27f57a['left']['left']['isRed_']()&&(_0x27f57a=_0x27f57a['rotateRight_']()),_0x27f57a['left']['isRed_']()&&_0x27f57a['right']['isRed_']()&&(_0x27f57a=_0x27f57a['colorFlip_']()),_0x27f57a;}['moveRedLeft_'](){let _0xba4552=this['colorFlip_']();return _0xba4552['right']['left']['isRed_']()&&(_0xba4552=_0xba4552['copy'](null,null,null,null,_0xba4552['right']['rotateRight_']()),_0xba4552=_0xba4552['rotateLeft_'](),_0xba4552=_0xba4552['colorFlip_']()),_0xba4552;}['moveRedRight_'](){let _0x14b673=this['colorFlip_']();return _0x14b673['left']['left']['isRed_']()&&(_0x14b673=_0x14b673['rotateRight_'](),_0x14b673=_0x14b673['colorFlip_']()),_0x14b673;}['rotateLeft_'](){const _0x4d27a1=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4d27a1,null);}['rotateRight_'](){const _0x4d2da2=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4d2da2);}['colorFlip_'](){const _0x46a905=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x844506=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x46a905,_0x844506);}['checkMaxDepth_'](){const _0x4bec7c=this['check_']();return Math['pow'](0x2,_0x4bec7c)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x131984=this['left']['check_']();if(_0x131984!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x131984+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x580f43,_0x5c1764,_0x2d7fd1,_0xa4cac2,_0x98b5b0){return this;}['insert'](_0x4daaa4,_0x37bcc0,_0x3e0516){return new M(_0x4daaa4,_0x37bcc0,null);}['remove'](_0x17c09b,_0x3cfd3b){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4ed8bd){return!0x1;}['reverseTraversal'](_0x4c3879){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x58e22f,_0x24d6f6=B['EMPTY_NODE']){this['comparator_']=_0x58e22f,this['root_']=_0x24d6f6;}['insert'](_0x5bdd45,_0x3b1ce7){return new B(this['comparator_'],this['root_']['insert'](_0x5bdd45,_0x3b1ce7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x735825){return new B(this['comparator_'],this['root_']['remove'](_0x735825,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x31f507){let _0x4f2036,_0x5c87dd=this['root_'];for(;!_0x5c87dd['isEmpty']();){if(_0x4f2036=this['comparator_'](_0x31f507,_0x5c87dd['key']),_0x4f2036===0x0)return _0x5c87dd['value'];_0x4f2036<0x0?_0x5c87dd=_0x5c87dd['left']:_0x4f2036>0x0&&(_0x5c87dd=_0x5c87dd['right']);}return null;}['getPredecessorKey'](_0x55b5fc){let _0x3e51bb,_0x408a73=this['root_'],_0x5255df=null;for(;!_0x408a73['isEmpty']();)if(_0x3e51bb=this['comparator_'](_0x55b5fc,_0x408a73['key']),_0x3e51bb===0x0){if(_0x408a73['left']['isEmpty']())return _0x5255df?_0x5255df['key']:null;for(_0x408a73=_0x408a73['left'];!_0x408a73['right']['isEmpty']();)_0x408a73=_0x408a73['right'];return _0x408a73['key'];}else _0x3e51bb<0x0?_0x408a73=_0x408a73['left']:_0x3e51bb>0x0&&(_0x5255df=_0x408a73,_0x408a73=_0x408a73['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xb8623c){return this['root_']['inorderTraversal'](_0xb8623c);}['reverseTraversal'](_0x4247eb){return this['root_']['reverseTraversal'](_0x4247eb);}['getIterator'](_0x2cfbc2){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x2cfbc2);}['getIteratorFrom'](_0x58564c,_0x546be4){return new Zt(this['root_'],_0x58564c,this['comparator_'],!0x1,_0x546be4);}['getReverseIteratorFrom'](_0x21ebe0,_0x400881){return new Zt(this['root_'],_0x21ebe0,this['comparator_'],!0x0,_0x400881);}['getReverseIterator'](_0x8ae274){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x8ae274);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x8d04be,_0x43036a){return He(_0x8d04be['name'],_0x43036a['name']);}function ji(_0x5e52d8,_0x360ee8){return He(_0x5e52d8,_0x360ee8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x438650){vi=_0x438650;}const Ro=function(_0x2154f2){return typeof _0x2154f2=='number'?'number:'+so(_0x2154f2):'string:'+_0x2154f2;},Ao=function(_0x14b5e0){if(_0x14b5e0['isLeafNode']()){const _0x2056d4=_0x14b5e0['val']();f(typeof _0x2056d4=='string'||typeof _0x2056d4=='number'||typeof _0x2056d4=='object'&&Y(_0x2056d4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x14b5e0===vi||_0x14b5e0['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x14b5e0===vi||_0x14b5e0['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x5ae69a){er=_0x5ae69a;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xed8cbd,_0x80d0b8=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xed8cbd,this['priorityNode_']=_0x80d0b8,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3fdb8c){return new D(this['value_'],_0x3fdb8c);}['getImmediateChild'](_0x1eb7fe){return _0x1eb7fe==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1be564){return v(_0x1be564)?this:y(_0x1be564)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1dea27,_0x5ce553){return null;}['updateImmediateChild'](_0x227e8e,_0x28738d){return _0x227e8e==='.priority'?this['updatePriority'](_0x28738d):_0x28738d['isEmpty']()&&_0x227e8e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x227e8e,_0x28738d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x983910,_0x25643a){const _0x328d81=y(_0x983910);return _0x328d81===null?_0x25643a:_0x25643a['isEmpty']()&&_0x328d81!=='.priority'?this:(f(_0x328d81!=='.priority'||we(_0x983910)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x328d81,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x983910),_0x25643a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x38fcb6,_0x1e8243){return!0x1;}['val'](_0x2b92c0){return _0x2b92c0&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1bef6b='';this['priorityNode_']['isEmpty']()||(_0x1bef6b+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x22583f=typeof this['value_'];_0x1bef6b+=_0x22583f+':',_0x22583f==='number'?_0x1bef6b+=so(this['value_']):_0x1bef6b+=this['value_'],this['lazyHash_']=no(_0x1bef6b);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x31fe2d){return _0x31fe2d===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x31fe2d instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x31fe2d['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x31fe2d));}['compareToLeafNode_'](_0x8f23d9){const _0x55dde4=typeof _0x8f23d9['value_'],_0x79bd14=typeof this['value_'],_0x59ef44=D['VALUE_TYPE_ORDER']['indexOf'](_0x55dde4),_0x2a1203=D['VALUE_TYPE_ORDER']['indexOf'](_0x79bd14);return f(_0x59ef44>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x55dde4),f(_0x2a1203>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x79bd14),_0x59ef44===_0x2a1203?_0x79bd14==='object'?0x0:this['value_']<_0x8f23d9['value_']?-0x1:this['value_']===_0x8f23d9['value_']?0x0:0x1:_0x2a1203-_0x59ef44;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x451454){if(_0x451454===this)return!0x0;if(_0x451454['isLeafNode']()){const _0x48f278=_0x451454;return this['value_']===_0x48f278['value_']&&this['priorityNode_']['equals'](_0x48f278['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x367efa){ko=_0x367efa;}function xh(_0x16a302){No=_0x16a302;}class Fh extends On{['compare'](_0x3a8164,_0x1e17cb){const _0x83752=_0x3a8164['node']['getPriority'](),_0x3f4bd9=_0x1e17cb['node']['getPriority'](),_0x3d9812=_0x83752['compareTo'](_0x3f4bd9);return _0x3d9812===0x0?He(_0x3a8164['name'],_0x1e17cb['name']):_0x3d9812;}['isDefinedOn'](_0x398279){return!_0x398279['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x314859,_0x187bd3){return!_0x314859['getPriority']()['equals'](_0x187bd3['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x3525a7,_0x1325fb){const _0x5a5633=ko(_0x3525a7);return new E(_0x1325fb,new D('[PRIORITY-POST]',_0x5a5633));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x17d8b3){const _0x2e33b5=_0x49311f=>parseInt(Math['log'](_0x49311f)/Uh,0xa),_0x45e700=_0xaa78d4=>parseInt(Array(_0xaa78d4+0x1)['join']('1'),0x2);this['count']=_0x2e33b5(_0x17d8b3+0x1),this['current_']=this['count']-0x1;const _0x1373a4=_0x45e700(this['count']);this['bits_']=_0x17d8b3+0x1&_0x1373a4;}['nextBitIsOne'](){const _0x5c9f5b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5c9f5b;}}const dn=function(_0xd868a0,_0x18f187,_0x155a0c,_0x127218){_0xd868a0['sort'](_0x18f187);const _0x536c52=function(_0xaae516,_0x29eda9){const _0xabbf2f=_0x29eda9-_0xaae516;let _0x43971f,_0x1f667d;if(_0xabbf2f===0x0)return null;if(_0xabbf2f===0x1)return _0x43971f=_0xd868a0[_0xaae516],_0x1f667d=_0x155a0c?_0x155a0c(_0x43971f):_0x43971f,new M(_0x1f667d,_0x43971f['node'],M['BLACK'],null,null);{const _0x30953b=parseInt(_0xabbf2f/0x2,0xa)+_0xaae516,_0x4ba465=_0x536c52(_0xaae516,_0x30953b),_0x276e04=_0x536c52(_0x30953b+0x1,_0x29eda9);return _0x43971f=_0xd868a0[_0x30953b],_0x1f667d=_0x155a0c?_0x155a0c(_0x43971f):_0x43971f,new M(_0x1f667d,_0x43971f['node'],M['BLACK'],_0x4ba465,_0x276e04);}},_0x4ef7cc=function(_0x1ed6dd){let _0x3f96a5=null,_0x1b3bd2=null,_0x11b27d=_0xd868a0['length'];const _0x1d58df=function(_0x48999a,_0x133f13){const _0x2e35d2=_0x11b27d-_0x48999a,_0x36a6f7=_0x11b27d;_0x11b27d-=_0x48999a;const _0x2ddf87=_0x536c52(_0x2e35d2+0x1,_0x36a6f7),_0x1de6d7=_0xd868a0[_0x2e35d2],_0x13e229=_0x155a0c?_0x155a0c(_0x1de6d7):_0x1de6d7;_0x61d2bf(new M(_0x13e229,_0x1de6d7['node'],_0x133f13,null,_0x2ddf87));},_0x61d2bf=function(_0x26d02e){_0x3f96a5?(_0x3f96a5['left']=_0x26d02e,_0x3f96a5=_0x26d02e):(_0x1b3bd2=_0x26d02e,_0x3f96a5=_0x26d02e);};for(let _0x5da6fc=0x0;_0x5da6fc<_0x1ed6dd['count'];++_0x5da6fc){const _0x309741=_0x1ed6dd['nextBitIsOne'](),_0x3d5d3c=Math['pow'](0x2,_0x1ed6dd['count']-(_0x5da6fc+0x1));_0x309741?_0x1d58df(_0x3d5d3c,M['BLACK']):(_0x1d58df(_0x3d5d3c,M['BLACK']),_0x1d58df(_0x3d5d3c,M['RED']));}return _0x1b3bd2;},_0x584664=new Wh(_0xd868a0['length']),_0x234dbf=_0x4ef7cc(_0x584664);return new B(_0x127218||_0x18f187,_0x234dbf);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x14b945,_0xa4e860){this['indexes_']=_0x14b945,this['indexSet_']=_0xa4e860;}['get'](_0x481877){const _0x4ef091=Oe(this['indexes_'],_0x481877);if(!_0x4ef091)throw new Error('No\x20index\x20defined\x20for\x20'+_0x481877);return _0x4ef091 instanceof B?_0x4ef091:null;}['hasIndex'](_0x4c6e48){return Y(this['indexSet_'],_0x4c6e48['toString']());}['addIndex'](_0x45e44b,_0x32855c){f(_0x45e44b!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2d1d94=[];let _0x387bb2=!0x1;const _0x40cd81=_0x32855c['getIterator'](E['Wrap']);let _0xeda28e=_0x40cd81['getNext']();for(;_0xeda28e;)_0x387bb2=_0x387bb2||_0x45e44b['isDefinedOn'](_0xeda28e['node']),_0x2d1d94['push'](_0xeda28e),_0xeda28e=_0x40cd81['getNext']();let _0x342882;_0x387bb2?_0x342882=dn(_0x2d1d94,_0x45e44b['getCompare']()):_0x342882=je;const _0x3670f8=_0x45e44b['toString'](),_0x31067a={...this['indexSet_']};_0x31067a[_0x3670f8]=_0x45e44b;const _0x119c14={...this['indexes_']};return _0x119c14[_0x3670f8]=_0x342882,new ee(_0x119c14,_0x31067a);}['addToIndexes'](_0x4b157f,_0x4dc070){const _0x3ef46e=ln(this['indexes_'],(_0x33ea82,_0x36f481)=>{const _0x3985b8=Oe(this['indexSet_'],_0x36f481);if(f(_0x3985b8,'Missing\x20index\x20implementation\x20for\x20'+_0x36f481),_0x33ea82===je){if(_0x3985b8['isDefinedOn'](_0x4b157f['node'])){const _0x462a88=[],_0x1402f8=_0x4dc070['getIterator'](E['Wrap']);let _0x16d2d7=_0x1402f8['getNext']();for(;_0x16d2d7;)_0x16d2d7['name']!==_0x4b157f['name']&&_0x462a88['push'](_0x16d2d7),_0x16d2d7=_0x1402f8['getNext']();return _0x462a88['push'](_0x4b157f),dn(_0x462a88,_0x3985b8['getCompare']());}else return je;}else{const _0x5945d0=_0x4dc070['get'](_0x4b157f['name']);let _0x355bad=_0x33ea82;return _0x5945d0&&(_0x355bad=_0x355bad['remove'](new E(_0x4b157f['name'],_0x5945d0))),_0x355bad['insert'](_0x4b157f,_0x4b157f['node']);}});return new ee(_0x3ef46e,this['indexSet_']);}['removeFromIndexes'](_0x4442e3,_0x2ed5c7){const _0xed2c16=ln(this['indexes_'],_0x1cd420=>{if(_0x1cd420===je)return _0x1cd420;{const _0x23670d=_0x2ed5c7['get'](_0x4442e3['name']);return _0x23670d?_0x1cd420['remove'](new E(_0x4442e3['name'],_0x23670d)):_0x1cd420;}});return new ee(_0xed2c16,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x12f31f,_0x5967dc,_0x21be67){this['children_']=_0x12f31f,this['priorityNode_']=_0x5967dc,this['indexMap_']=_0x21be67,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0xf24064){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xf24064,this['indexMap_']);}['getImmediateChild'](_0x3786ba){if(_0x3786ba==='.priority')return this['getPriority']();{const _0x28d974=this['children_']['get'](_0x3786ba);return _0x28d974===null?gt:_0x28d974;}}['getChild'](_0x13f316){const _0x6aa2d=y(_0x13f316);return _0x6aa2d===null?this:this['getImmediateChild'](_0x6aa2d)['getChild'](b(_0x13f316));}['hasChild'](_0x502700){return this['children_']['get'](_0x502700)!==null;}['updateImmediateChild'](_0x10cbf3,_0x243b04){if(f(_0x243b04,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x10cbf3==='.priority')return this['updatePriority'](_0x243b04);{const _0x458458=new E(_0x10cbf3,_0x243b04);let _0x1d07b1,_0x13d332;_0x243b04['isEmpty']()?(_0x1d07b1=this['children_']['remove'](_0x10cbf3),_0x13d332=this['indexMap_']['removeFromIndexes'](_0x458458,this['children_'])):(_0x1d07b1=this['children_']['insert'](_0x10cbf3,_0x243b04),_0x13d332=this['indexMap_']['addToIndexes'](_0x458458,this['children_']));const _0x51586a=_0x1d07b1['isEmpty']()?gt:this['priorityNode_'];return new g(_0x1d07b1,_0x51586a,_0x13d332);}}['updateChild'](_0x2c6a4c,_0x280ac8){const _0xbcc32c=y(_0x2c6a4c);if(_0xbcc32c===null)return _0x280ac8;{f(y(_0x2c6a4c)!=='.priority'||we(_0x2c6a4c)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2d32b9=this['getImmediateChild'](_0xbcc32c)['updateChild'](b(_0x2c6a4c),_0x280ac8);return this['updateImmediateChild'](_0xbcc32c,_0x2d32b9);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5e73){if(this['isEmpty']())return null;const _0x5b3103={};let _0x511f0f=0x0,_0x4efdbd=0x0,_0x2385ea=!0x0;if(this['forEachChild'](R,(_0x5637be,_0x286920)=>{_0x5b3103[_0x5637be]=_0x286920['val'](_0x5e73),_0x511f0f++,_0x2385ea&&g['INTEGER_REGEXP_']['test'](_0x5637be)?_0x4efdbd=Math['max'](_0x4efdbd,Number(_0x5637be)):_0x2385ea=!0x1;}),!_0x5e73&&_0x2385ea&&_0x4efdbd<0x2*_0x511f0f){const _0x14b904=[];for(const _0x433799 in _0x5b3103)_0x14b904[_0x433799]=_0x5b3103[_0x433799];return _0x14b904;}else return _0x5e73&&!this['getPriority']()['isEmpty']()&&(_0x5b3103['.priority']=this['getPriority']()['val']()),_0x5b3103;}['hash'](){if(this['lazyHash_']===null){let _0x22178c='';this['getPriority']()['isEmpty']()||(_0x22178c+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x21ecef,_0x2d4e50)=>{const _0x17e16c=_0x2d4e50['hash']();_0x17e16c!==''&&(_0x22178c+=':'+_0x21ecef+':'+_0x17e16c);}),this['lazyHash_']=_0x22178c===''?'':no(_0x22178c);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1c14d2,_0x26ea97,_0x116d79){const _0x40792e=this['resolveIndex_'](_0x116d79);if(_0x40792e){const _0x819282=_0x40792e['getPredecessorKey'](new E(_0x1c14d2,_0x26ea97));return _0x819282?_0x819282['name']:null;}else return this['children_']['getPredecessorKey'](_0x1c14d2);}['getFirstChildName'](_0x202233){const _0xff1dcb=this['resolveIndex_'](_0x202233);if(_0xff1dcb){const _0x3130ee=_0xff1dcb['minKey']();return _0x3130ee&&_0x3130ee['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3095a8){const _0x576692=this['getFirstChildName'](_0x3095a8);return _0x576692?new E(_0x576692,this['children_']['get'](_0x576692)):null;}['getLastChildName'](_0x56092d){const _0xbee018=this['resolveIndex_'](_0x56092d);if(_0xbee018){const _0x5138e8=_0xbee018['maxKey']();return _0x5138e8&&_0x5138e8['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4cf1f5){const _0x3d10b8=this['getLastChildName'](_0x4cf1f5);return _0x3d10b8?new E(_0x3d10b8,this['children_']['get'](_0x3d10b8)):null;}['forEachChild'](_0x4f74c1,_0x5968f8){const _0x310970=this['resolveIndex_'](_0x4f74c1);return _0x310970?_0x310970['inorderTraversal'](_0x2b38c4=>_0x5968f8(_0x2b38c4['name'],_0x2b38c4['node'])):this['children_']['inorderTraversal'](_0x5968f8);}['getIterator'](_0x34472f){return this['getIteratorFrom'](_0x34472f['minPost'](),_0x34472f);}['getIteratorFrom'](_0xdbbc1,_0x1c31ff){const _0x5e30d4=this['resolveIndex_'](_0x1c31ff);if(_0x5e30d4)return _0x5e30d4['getIteratorFrom'](_0xdbbc1,_0x199b2c=>_0x199b2c);{const _0x2423ba=this['children_']['getIteratorFrom'](_0xdbbc1['name'],E['Wrap']);let _0x3b3360=_0x2423ba['peek']();for(;_0x3b3360!=null&&_0x1c31ff['compare'](_0x3b3360,_0xdbbc1)<0x0;)_0x2423ba['getNext'](),_0x3b3360=_0x2423ba['peek']();return _0x2423ba;}}['getReverseIterator'](_0x4abb5c){return this['getReverseIteratorFrom'](_0x4abb5c['maxPost'](),_0x4abb5c);}['getReverseIteratorFrom'](_0x2dbded,_0x44808a){const _0x2961c9=this['resolveIndex_'](_0x44808a);if(_0x2961c9)return _0x2961c9['getReverseIteratorFrom'](_0x2dbded,_0x31e9e5=>_0x31e9e5);{const _0x122af7=this['children_']['getReverseIteratorFrom'](_0x2dbded['name'],E['Wrap']);let _0x333ef3=_0x122af7['peek']();for(;_0x333ef3!=null&&_0x44808a['compare'](_0x333ef3,_0x2dbded)>0x0;)_0x122af7['getNext'](),_0x333ef3=_0x122af7['peek']();return _0x122af7;}}['compareTo'](_0x25ece1){return this['isEmpty']()?_0x25ece1['isEmpty']()?0x0:-0x1:_0x25ece1['isLeafNode']()||_0x25ece1['isEmpty']()?0x1:_0x25ece1===Ht?-0x1:0x0;}['withIndex'](_0x1a8f8f){if(_0x1a8f8f===ye||this['indexMap_']['hasIndex'](_0x1a8f8f))return this;{const _0x322a7f=this['indexMap_']['addIndex'](_0x1a8f8f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x322a7f);}}['isIndexed'](_0xa8ab93){return _0xa8ab93===ye||this['indexMap_']['hasIndex'](_0xa8ab93);}['equals'](_0x157b21){if(_0x157b21===this)return!0x0;if(_0x157b21['isLeafNode']())return!0x1;{const _0x3e62fe=_0x157b21;if(this['getPriority']()['equals'](_0x3e62fe['getPriority']())){if(this['children_']['count']()===_0x3e62fe['children_']['count']()){const _0x2b243a=this['getIterator'](R),_0x2ca9a3=_0x3e62fe['getIterator'](R);let _0x30313e=_0x2b243a['getNext'](),_0x4c9f65=_0x2ca9a3['getNext']();for(;_0x30313e&&_0x4c9f65;){if(_0x30313e['name']!==_0x4c9f65['name']||!_0x30313e['node']['equals'](_0x4c9f65['node']))return!0x1;_0x30313e=_0x2b243a['getNext'](),_0x4c9f65=_0x2ca9a3['getNext']();}return _0x30313e===null&&_0x4c9f65===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x137d15){return _0x137d15===ye?null:this['indexMap_']['get'](_0x137d15['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x236fdc){return _0x236fdc===this?0x0:0x1;}['equals'](_0x459cc0){return _0x459cc0===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3ad267){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x46277e,_0x329cd1=null){if(_0x46277e===null)return g['EMPTY_NODE'];if(typeof _0x46277e=='object'&&'.priority'in _0x46277e&&(_0x329cd1=_0x46277e['.priority']),f(_0x329cd1===null||typeof _0x329cd1=='string'||typeof _0x329cd1=='number'||typeof _0x329cd1=='object'&&'.sv'in _0x329cd1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x329cd1),typeof _0x46277e=='object'&&'.value'in _0x46277e&&_0x46277e['.value']!==null&&(_0x46277e=_0x46277e['.value']),typeof _0x46277e!='object'||'.sv'in _0x46277e){const _0x55661a=_0x46277e;return new D(_0x55661a,N(_0x329cd1));}if(!(_0x46277e instanceof Array)&&Vh){const _0xd9d04f=[];let _0x4db836=!0x1;if(x(_0x46277e,(_0x55929e,_0x396fa8)=>{if(_0x55929e['substring'](0x0,0x1)!=='.'){const _0x3afd84=N(_0x396fa8);_0x3afd84['isEmpty']()||(_0x4db836=_0x4db836||!_0x3afd84['getPriority']()['isEmpty'](),_0xd9d04f['push'](new E(_0x55929e,_0x3afd84)));}}),_0xd9d04f['length']===0x0)return g['EMPTY_NODE'];const _0x517296=dn(_0xd9d04f,Dh,_0x2b8174=>_0x2b8174['name'],ji);if(_0x4db836){const _0x2eea68=dn(_0xd9d04f,R['getCompare']());return new g(_0x517296,N(_0x329cd1),new ee({'.priority':_0x2eea68},{'.priority':R}));}else return new g(_0x517296,N(_0x329cd1),ee['Default']);}else{let _0x33c828=g['EMPTY_NODE'];return x(_0x46277e,(_0x5bf328,_0x28c4d2)=>{if(Y(_0x46277e,_0x5bf328)&&_0x5bf328['substring'](0x0,0x1)!=='.'){const _0x47943b=N(_0x28c4d2);(_0x47943b['isLeafNode']()||!_0x47943b['isEmpty']())&&(_0x33c828=_0x33c828['updateImmediateChild'](_0x5bf328,_0x47943b));}}),_0x33c828['updatePriority'](N(_0x329cd1));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3ece28){super(),this['indexPath_']=_0x3ece28,f(!v(_0x3ece28)&&y(_0x3ece28)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x49d6a0){return _0x49d6a0['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2f3ff2){return!_0x2f3ff2['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x11919b,_0x1c68c6){const _0x3b0c22=this['extractChild'](_0x11919b['node']),_0x5324e8=this['extractChild'](_0x1c68c6['node']),_0xed25de=_0x3b0c22['compareTo'](_0x5324e8);return _0xed25de===0x0?He(_0x11919b['name'],_0x1c68c6['name']):_0xed25de;}['makePost'](_0x43be7a,_0xaa0064){const _0x533987=N(_0x43be7a),_0x55f35a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x533987);return new E(_0xaa0064,_0x55f35a);}['maxPost'](){const _0x141df9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x141df9);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x13bbfc,_0x480d79){const _0x527f2e=_0x13bbfc['node']['compareTo'](_0x480d79['node']);return _0x527f2e===0x0?He(_0x13bbfc['name'],_0x480d79['name']):_0x527f2e;}['isDefinedOn'](_0x18af32){return!0x0;}['indexedValueChanged'](_0x3c1ec9,_0xe24ca7){return!_0x3c1ec9['equals'](_0xe24ca7);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x526a59,_0x564c08){const _0x1a9ee5=N(_0x526a59);return new E(_0x564c08,_0x1a9ee5);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x27542d){return{'type':'value','snapshotNode':_0x27542d};}function tt(_0x19a6b1,_0x57a2b7){return{'type':'child_added','snapshotNode':_0x57a2b7,'childName':_0x19a6b1};}function Nt(_0x5898e2,_0x30b4d6){return{'type':'child_removed','snapshotNode':_0x30b4d6,'childName':_0x5898e2};}function Pt(_0x254a9b,_0x11f3f1,_0xcd73eb){return{'type':'child_changed','snapshotNode':_0x11f3f1,'childName':_0x254a9b,'oldSnap':_0xcd73eb};}function $h(_0x4abd5e,_0x28cb07){return{'type':'child_moved','snapshotNode':_0x28cb07,'childName':_0x4abd5e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x3b0a11){this['index_']=_0x3b0a11;}['updateChild'](_0x19faf4,_0xf4837,_0x3b34e2,_0x4b2708,_0x45e199,_0x595ed1){f(_0x19faf4['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x48483e=_0x19faf4['getImmediateChild'](_0xf4837);return _0x48483e['getChild'](_0x4b2708)['equals'](_0x3b34e2['getChild'](_0x4b2708))&&_0x48483e['isEmpty']()===_0x3b34e2['isEmpty']()||(_0x595ed1!=null&&(_0x3b34e2['isEmpty']()?_0x19faf4['hasChild'](_0xf4837)?_0x595ed1['trackChildChange'](Nt(_0xf4837,_0x48483e)):f(_0x19faf4['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x48483e['isEmpty']()?_0x595ed1['trackChildChange'](tt(_0xf4837,_0x3b34e2)):_0x595ed1['trackChildChange'](Pt(_0xf4837,_0x3b34e2,_0x48483e))),_0x19faf4['isLeafNode']()&&_0x3b34e2['isEmpty']())?_0x19faf4:_0x19faf4['updateImmediateChild'](_0xf4837,_0x3b34e2)['withIndex'](this['index_']);}['updateFullNode'](_0x64bcbf,_0x1f9824,_0xcdfba){return _0xcdfba!=null&&(_0x64bcbf['isLeafNode']()||_0x64bcbf['forEachChild'](R,(_0x2f8548,_0x3a08b8)=>{_0x1f9824['hasChild'](_0x2f8548)||_0xcdfba['trackChildChange'](Nt(_0x2f8548,_0x3a08b8));}),_0x1f9824['isLeafNode']()||_0x1f9824['forEachChild'](R,(_0x58656b,_0xf94d9)=>{if(_0x64bcbf['hasChild'](_0x58656b)){const _0x5951ca=_0x64bcbf['getImmediateChild'](_0x58656b);_0x5951ca['equals'](_0xf94d9)||_0xcdfba['trackChildChange'](Pt(_0x58656b,_0xf94d9,_0x5951ca));}else _0xcdfba['trackChildChange'](tt(_0x58656b,_0xf94d9));})),_0x1f9824['withIndex'](this['index_']);}['updatePriority'](_0x7c198f,_0x3f5375){return _0x7c198f['isEmpty']()?g['EMPTY_NODE']:_0x7c198f['updatePriority'](_0x3f5375);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x25e726){this['indexedFilter_']=new Yi(_0x25e726['getIndex']()),this['index_']=_0x25e726['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x25e726),this['endPost_']=Ot['getEndPost_'](_0x25e726),this['startIsInclusive_']=!_0x25e726['startAfterSet_'],this['endIsInclusive_']=!_0x25e726['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x544c7f){const _0x428b1a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x544c7f)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x544c7f)<0x0,_0x572610=this['endIsInclusive_']?this['index_']['compare'](_0x544c7f,this['getEndPost']())<=0x0:this['index_']['compare'](_0x544c7f,this['getEndPost']())<0x0;return _0x428b1a&&_0x572610;}['updateChild'](_0x307209,_0x23a41f,_0x5470de,_0x2aa4bd,_0x258b5f,_0x5e367c){return this['matches'](new E(_0x23a41f,_0x5470de))||(_0x5470de=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x307209,_0x23a41f,_0x5470de,_0x2aa4bd,_0x258b5f,_0x5e367c);}['updateFullNode'](_0x98fa16,_0x104b68,_0x155118){_0x104b68['isLeafNode']()&&(_0x104b68=g['EMPTY_NODE']);let _0x1df63f=_0x104b68['withIndex'](this['index_']);_0x1df63f=_0x1df63f['updatePriority'](g['EMPTY_NODE']);const _0x56cf2a=this;return _0x104b68['forEachChild'](R,(_0x3a711b,_0x337275)=>{_0x56cf2a['matches'](new E(_0x3a711b,_0x337275))||(_0x1df63f=_0x1df63f['updateImmediateChild'](_0x3a711b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x98fa16,_0x1df63f,_0x155118);}['updatePriority'](_0x35365e,_0x364c75){return _0x35365e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3ceb1a){if(_0x3ceb1a['hasStart']()){const _0x54d77b=_0x3ceb1a['getIndexStartName']();return _0x3ceb1a['getIndex']()['makePost'](_0x3ceb1a['getIndexStartValue'](),_0x54d77b);}else return _0x3ceb1a['getIndex']()['minPost']();}static['getEndPost_'](_0x42ed7d){if(_0x42ed7d['hasEnd']()){const _0x4321a=_0x42ed7d['getIndexEndName']();return _0x42ed7d['getIndex']()['makePost'](_0x42ed7d['getIndexEndValue'](),_0x4321a);}else return _0x42ed7d['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xe2c9bb){this['withinDirectionalStart']=_0x5bcc12=>this['reverse_']?this['withinEndPost'](_0x5bcc12):this['withinStartPost'](_0x5bcc12),this['withinDirectionalEnd']=_0x440a91=>this['reverse_']?this['withinStartPost'](_0x440a91):this['withinEndPost'](_0x440a91),this['withinStartPost']=_0x3a7208=>{const _0x4398b9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3a7208);return this['startIsInclusive_']?_0x4398b9<=0x0:_0x4398b9<0x0;},this['withinEndPost']=_0x22bcbb=>{const _0x4f6264=this['index_']['compare'](_0x22bcbb,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4f6264<=0x0:_0x4f6264<0x0;},this['rangedFilter_']=new Ot(_0xe2c9bb),this['index_']=_0xe2c9bb['getIndex'](),this['limit_']=_0xe2c9bb['getLimit'](),this['reverse_']=!_0xe2c9bb['isViewFromLeft'](),this['startIsInclusive_']=!_0xe2c9bb['startAfterSet_'],this['endIsInclusive_']=!_0xe2c9bb['endBeforeSet_'];}['updateChild'](_0x5f2bf6,_0x5c92d3,_0x2e9a50,_0x26c49d,_0x1149db,_0x399ed3){return this['rangedFilter_']['matches'](new E(_0x5c92d3,_0x2e9a50))||(_0x2e9a50=g['EMPTY_NODE']),_0x5f2bf6['getImmediateChild'](_0x5c92d3)['equals'](_0x2e9a50)?_0x5f2bf6:_0x5f2bf6['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5f2bf6,_0x5c92d3,_0x2e9a50,_0x26c49d,_0x1149db,_0x399ed3):this['fullLimitUpdateChild_'](_0x5f2bf6,_0x5c92d3,_0x2e9a50,_0x1149db,_0x399ed3);}['updateFullNode'](_0xa33e40,_0x1ef578,_0x2b4097){let _0x1865b4;if(_0x1ef578['isLeafNode']()||_0x1ef578['isEmpty']())_0x1865b4=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1ef578['numChildren']()&&_0x1ef578['isIndexed'](this['index_'])){_0x1865b4=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3a2426;this['reverse_']?_0x3a2426=_0x1ef578['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3a2426=_0x1ef578['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4f5106=0x0;for(;_0x3a2426['hasNext']()&&_0x4f5106<this['limit_'];){const _0x262cd7=_0x3a2426['getNext']();if(this['withinDirectionalStart'](_0x262cd7)){if(this['withinDirectionalEnd'](_0x262cd7))_0x1865b4=_0x1865b4['updateImmediateChild'](_0x262cd7['name'],_0x262cd7['node']),_0x4f5106++;else break;}else continue;}}else{_0x1865b4=_0x1ef578['withIndex'](this['index_']),_0x1865b4=_0x1865b4['updatePriority'](g['EMPTY_NODE']);let _0x4e248b;this['reverse_']?_0x4e248b=_0x1865b4['getReverseIterator'](this['index_']):_0x4e248b=_0x1865b4['getIterator'](this['index_']);let _0x3bd2cd=0x0;for(;_0x4e248b['hasNext']();){const _0x47edae=_0x4e248b['getNext']();_0x3bd2cd<this['limit_']&&this['withinDirectionalStart'](_0x47edae)&&this['withinDirectionalEnd'](_0x47edae)?_0x3bd2cd++:_0x1865b4=_0x1865b4['updateImmediateChild'](_0x47edae['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xa33e40,_0x1865b4,_0x2b4097);}['updatePriority'](_0x38ccd0,_0x167bbd){return _0x38ccd0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3ff1e1,_0x34bed6,_0x4ec393,_0x46fd51,_0x49aedd){let _0x48599f;if(this['reverse_']){const _0x3c2f53=this['index_']['getCompare']();_0x48599f=(_0x4142e0,_0x2b1af7)=>_0x3c2f53(_0x2b1af7,_0x4142e0);}else _0x48599f=this['index_']['getCompare']();const _0xb26c1f=_0x3ff1e1;f(_0xb26c1f['numChildren']()===this['limit_'],'');const _0x41fac4=new E(_0x34bed6,_0x4ec393),_0x18bf5c=this['reverse_']?_0xb26c1f['getFirstChild'](this['index_']):_0xb26c1f['getLastChild'](this['index_']),_0x4846a6=this['rangedFilter_']['matches'](_0x41fac4);if(_0xb26c1f['hasChild'](_0x34bed6)){const _0x16eaa7=_0xb26c1f['getImmediateChild'](_0x34bed6);let _0x1dc32a=_0x46fd51['getChildAfterChild'](this['index_'],_0x18bf5c,this['reverse_']);for(;_0x1dc32a!=null&&(_0x1dc32a['name']===_0x34bed6||_0xb26c1f['hasChild'](_0x1dc32a['name']));)_0x1dc32a=_0x46fd51['getChildAfterChild'](this['index_'],_0x1dc32a,this['reverse_']);const _0x4a23d3=_0x1dc32a==null?0x1:_0x48599f(_0x1dc32a,_0x41fac4);if(_0x4846a6&&!_0x4ec393['isEmpty']()&&_0x4a23d3>=0x0)return _0x49aedd!=null&&_0x49aedd['trackChildChange'](Pt(_0x34bed6,_0x4ec393,_0x16eaa7)),_0xb26c1f['updateImmediateChild'](_0x34bed6,_0x4ec393);{_0x49aedd!=null&&_0x49aedd['trackChildChange'](Nt(_0x34bed6,_0x16eaa7));const _0x19abcb=_0xb26c1f['updateImmediateChild'](_0x34bed6,g['EMPTY_NODE']);return _0x1dc32a!=null&&this['rangedFilter_']['matches'](_0x1dc32a)?(_0x49aedd!=null&&_0x49aedd['trackChildChange'](tt(_0x1dc32a['name'],_0x1dc32a['node'])),_0x19abcb['updateImmediateChild'](_0x1dc32a['name'],_0x1dc32a['node'])):_0x19abcb;}}else return _0x4ec393['isEmpty']()?_0x3ff1e1:_0x4846a6&&_0x48599f(_0x18bf5c,_0x41fac4)>=0x0?(_0x49aedd!=null&&(_0x49aedd['trackChildChange'](Nt(_0x18bf5c['name'],_0x18bf5c['node'])),_0x49aedd['trackChildChange'](tt(_0x34bed6,_0x4ec393))),_0xb26c1f['updateImmediateChild'](_0x34bed6,_0x4ec393)['updateImmediateChild'](_0x18bf5c['name'],g['EMPTY_NODE'])):_0x3ff1e1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1e4fc9=new Qi();return _0x1e4fc9['limitSet_']=this['limitSet_'],_0x1e4fc9['limit_']=this['limit_'],_0x1e4fc9['startSet_']=this['startSet_'],_0x1e4fc9['startAfterSet_']=this['startAfterSet_'],_0x1e4fc9['indexStartValue_']=this['indexStartValue_'],_0x1e4fc9['startNameSet_']=this['startNameSet_'],_0x1e4fc9['indexStartName_']=this['indexStartName_'],_0x1e4fc9['endSet_']=this['endSet_'],_0x1e4fc9['endBeforeSet_']=this['endBeforeSet_'],_0x1e4fc9['indexEndValue_']=this['indexEndValue_'],_0x1e4fc9['endNameSet_']=this['endNameSet_'],_0x1e4fc9['indexEndName_']=this['indexEndName_'],_0x1e4fc9['index_']=this['index_'],_0x1e4fc9['viewFrom_']=this['viewFrom_'],_0x1e4fc9;}}function qh(_0x5d5a91){return _0x5d5a91['loadsAllData']()?new Yi(_0x5d5a91['getIndex']()):_0x5d5a91['hasLimit']()?new Gh(_0x5d5a91):new Ot(_0x5d5a91);}function zh(_0x14bf9c,_0x1d4579){const _0x37c711=_0x14bf9c['copy']();return _0x37c711['limitSet_']=!0x0,_0x37c711['limit_']=_0x1d4579,_0x37c711['viewFrom_']='l',_0x37c711;}function jh(_0x5150c9,_0x280bd0,_0x400a34){const _0x9b683=_0x5150c9['copy']();return _0x9b683['startSet_']=!0x0,_0x280bd0===void 0x0&&(_0x280bd0=null),_0x9b683['indexStartValue_']=_0x280bd0,_0x400a34!=null?(_0x9b683['startNameSet_']=!0x0,_0x9b683['indexStartName_']=_0x400a34):(_0x9b683['startNameSet_']=!0x1,_0x9b683['indexStartName_']=''),_0x9b683;}function Kh(_0x3eea3c,_0xf832b9,_0x2a48fa){const _0x2eaf94=_0x3eea3c['copy']();return _0x2eaf94['endSet_']=!0x0,_0xf832b9===void 0x0&&(_0xf832b9=null),_0x2eaf94['indexEndValue_']=_0xf832b9,_0x2a48fa!==void 0x0?(_0x2eaf94['endNameSet_']=!0x0,_0x2eaf94['indexEndName_']=_0x2a48fa):(_0x2eaf94['endNameSet_']=!0x1,_0x2eaf94['indexEndName_']=''),_0x2eaf94;}function Do(_0x43b118,_0x722cd1){const _0x470a23=_0x43b118['copy']();return _0x470a23['index_']=_0x722cd1,_0x470a23;}function tr(_0x15555e){const _0x2baa18={};if(_0x15555e['isDefault']())return _0x2baa18;let _0x5efbf5;if(_0x15555e['index_']===R?_0x5efbf5='$priority':_0x15555e['index_']===Po?_0x5efbf5='$value':_0x15555e['index_']===ye?_0x5efbf5='$key':(f(_0x15555e['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5efbf5=_0x15555e['index_']['toString']()),_0x2baa18['orderBy']=O(_0x5efbf5),_0x15555e['startSet_']){const _0x646619=_0x15555e['startAfterSet_']?'startAfter':'startAt';_0x2baa18[_0x646619]=O(_0x15555e['indexStartValue_']),_0x15555e['startNameSet_']&&(_0x2baa18[_0x646619]+=','+O(_0x15555e['indexStartName_']));}if(_0x15555e['endSet_']){const _0x213e5f=_0x15555e['endBeforeSet_']?'endBefore':'endAt';_0x2baa18[_0x213e5f]=O(_0x15555e['indexEndValue_']),_0x15555e['endNameSet_']&&(_0x2baa18[_0x213e5f]+=','+O(_0x15555e['indexEndName_']));}return _0x15555e['limitSet_']&&(_0x15555e['isViewFromLeft']()?_0x2baa18['limitToFirst']=_0x15555e['limit_']:_0x2baa18['limitToLast']=_0x15555e['limit_']),_0x2baa18;}function nr(_0x13d38f){const _0x31327e={};if(_0x13d38f['startSet_']&&(_0x31327e['sp']=_0x13d38f['indexStartValue_'],_0x13d38f['startNameSet_']&&(_0x31327e['sn']=_0x13d38f['indexStartName_']),_0x31327e['sin']=!_0x13d38f['startAfterSet_']),_0x13d38f['endSet_']&&(_0x31327e['ep']=_0x13d38f['indexEndValue_'],_0x13d38f['endNameSet_']&&(_0x31327e['en']=_0x13d38f['indexEndName_']),_0x31327e['ein']=!_0x13d38f['endBeforeSet_']),_0x13d38f['limitSet_']){_0x31327e['l']=_0x13d38f['limit_'];let _0x59af05=_0x13d38f['viewFrom_'];_0x59af05===''&&(_0x13d38f['isViewFromLeft']()?_0x59af05='l':_0x59af05='r'),_0x31327e['vf']=_0x59af05;}return _0x13d38f['index_']!==R&&(_0x31327e['i']=_0x13d38f['index_']['toString']()),_0x31327e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x412231){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2ea4b3,_0xd5c796){return _0xd5c796!==void 0x0?'tag$'+_0xd5c796:(f(_0x2ea4b3['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2ea4b3['_path']['toString']());}constructor(_0x570843,_0x38fd4b,_0x3ac083,_0x244b9f){super(),this['repoInfo_']=_0x570843,this['onDataUpdate_']=_0x38fd4b,this['authTokenProvider_']=_0x3ac083,this['appCheckTokenProvider_']=_0x244b9f,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x1b7fd2,_0x4aa9f4,_0x52a6f8,_0x219065){const _0x48f033=_0x1b7fd2['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x48f033+'\x20'+_0x1b7fd2['_queryIdentifier']);const _0x4bc51b=fn['getListenId_'](_0x1b7fd2,_0x52a6f8),_0x29c049={};this['listens_'][_0x4bc51b]=_0x29c049;const _0x2bf60c=tr(_0x1b7fd2['_queryParams']);this['restRequest_'](_0x48f033+'.json',_0x2bf60c,(_0x5609bd,_0xf526f5)=>{let _0xe692b3=_0xf526f5;if(_0x5609bd===0x194&&(_0xe692b3=null,_0x5609bd=null),_0x5609bd===null&&this['onDataUpdate_'](_0x48f033,_0xe692b3,!0x1,_0x52a6f8),Oe(this['listens_'],_0x4bc51b)===_0x29c049){let _0xeb6951;_0x5609bd?_0x5609bd===0x191?_0xeb6951='permission_denied':_0xeb6951='rest_error:'+_0x5609bd:_0xeb6951='ok',_0x219065(_0xeb6951,null);}});}['unlisten'](_0x4f35ae,_0x12d2c8){const _0x561a71=fn['getListenId_'](_0x4f35ae,_0x12d2c8);delete this['listens_'][_0x561a71];}['get'](_0x139305){const _0x1a16b4=tr(_0x139305['_queryParams']),_0x2d4840=_0x139305['_path']['toString'](),_0x4ce657=new Ve();return this['restRequest_'](_0x2d4840+'.json',_0x1a16b4,(_0x344995,_0x3a1952)=>{let _0x24a552=_0x3a1952;_0x344995===0x194&&(_0x24a552=null,_0x344995=null),_0x344995===null?(this['onDataUpdate_'](_0x2d4840,_0x24a552,!0x1,null),_0x4ce657['resolve'](_0x24a552)):_0x4ce657['reject'](new Error(_0x24a552));}),_0x4ce657['promise'];}['refreshAuthToken'](_0x3ec0fb){}['restRequest_'](_0x64f044,_0x1ea951={},_0x17ef86){return _0x1ea951['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1a2051,_0x1b7e23])=>{_0x1a2051&&_0x1a2051['accessToken']&&(_0x1ea951['auth']=_0x1a2051['accessToken']),_0x1b7e23&&_0x1b7e23['token']&&(_0x1ea951['ac']=_0x1b7e23['token']);const _0x9434bb=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x64f044+'?ns='+this['repoInfo_']['namespace']+at(_0x1ea951);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x9434bb);const _0x341947=new XMLHttpRequest();_0x341947['onreadystatechange']=()=>{if(_0x17ef86&&_0x341947['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x9434bb+'\x20received.\x20status:',_0x341947['status'],'response:',_0x341947['responseText']);let _0x419599=null;if(_0x341947['status']>=0xc8&&_0x341947['status']<0x12c){try{_0x419599=bt(_0x341947['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x9434bb+':\x20'+_0x341947['responseText']);}_0x17ef86(null,_0x419599);}else _0x341947['status']!==0x191&&_0x341947['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x9434bb+'\x20Status:\x20'+_0x341947['status']),_0x17ef86(_0x341947['status']);_0x17ef86=null;}},_0x341947['open']('GET',_0x9434bb,!0x0),_0x341947['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xaf2ef9){return this['rootNode_']['getChild'](_0xaf2ef9);}['updateSnapshot'](_0x2070e2,_0x273a50){this['rootNode_']=this['rootNode_']['updateChild'](_0x2070e2,_0x273a50);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x59afcb,_0x41f758,_0x3b87bf){if(v(_0x41f758))_0x59afcb['value']=_0x3b87bf,_0x59afcb['children']['clear']();else{if(_0x59afcb['value']!==null)_0x59afcb['value']=_0x59afcb['value']['updateChild'](_0x41f758,_0x3b87bf);else{const _0x2b32b4=y(_0x41f758);_0x59afcb['children']['has'](_0x2b32b4)||_0x59afcb['children']['set'](_0x2b32b4,pn());const _0x552e81=_0x59afcb['children']['get'](_0x2b32b4);_0x41f758=b(_0x41f758),Mo(_0x552e81,_0x41f758,_0x3b87bf);}}}function Ei(_0x2c10a8,_0x2bb813,_0x28dafc){_0x2c10a8['value']!==null?_0x28dafc(_0x2bb813,_0x2c10a8['value']):Qh(_0x2c10a8,(_0x56e987,_0x144bb4)=>{const _0x1339f9=new C(_0x2bb813['toString']()+'/'+_0x56e987);Ei(_0x144bb4,_0x1339f9,_0x28dafc);});}function Qh(_0x30f4e6,_0x1ec11a){_0x30f4e6['children']['forEach']((_0x161246,_0x2681c7)=>{_0x1ec11a(_0x2681c7,_0x161246);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x24e9d9){this['collection_']=_0x24e9d9,this['last_']=null;}['get'](){const _0x585b72=this['collection_']['get'](),_0x5754ad={..._0x585b72};return this['last_']&&x(this['last_'],(_0x4a2d09,_0x3ce34a)=>{_0x5754ad[_0x4a2d09]=_0x5754ad[_0x4a2d09]-_0x3ce34a;}),this['last_']=_0x585b72,_0x5754ad;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x3a30a4,_0x49afc0){this['server_']=_0x49afc0,this['statsToReport_']={},this['statsListener_']=new Jh(_0x3a30a4);const _0x1d8265=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x1d8265));}['reportStats_'](){const _0x37188a=this['statsListener_']['get'](),_0x209dbd={};let _0x3cba36=!0x1;x(_0x37188a,(_0x52150b,_0x2606a0)=>{_0x2606a0>0x0&&Y(this['statsToReport_'],_0x52150b)&&(_0x209dbd[_0x52150b]=_0x2606a0,_0x3cba36=!0x0);}),_0x3cba36&&this['server_']['reportStats'](_0x209dbd),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x587685){_0x587685[_0x587685['OVERWRITE']=0x0]='OVERWRITE',_0x587685[_0x587685['MERGE']=0x1]='MERGE',_0x587685[_0x587685['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x587685[_0x587685['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x203403){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x203403,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x3f6b04,_0x18250e,_0x2b3750){this['path']=_0x3f6b04,this['affectedTree']=_0x18250e,this['revert']=_0x2b3750,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x3b4866){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xd91ab2=this['affectedTree']['subtree'](new C(_0x3b4866));return new _n(w(),_0xd91ab2,this['revert']);}}else return f(y(this['path'])===_0x3b4866,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0xb92ac0,_0x4a4354){this['source']=_0xb92ac0,this['path']=_0x4a4354,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x261216){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x379c30,_0x52c134,_0x581284){this['source']=_0x379c30,this['path']=_0x52c134,this['snap']=_0x581284,this['type']=q['OVERWRITE'];}['operationForChild'](_0x35fd96){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x35fd96)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xa3dc1c,_0x58a088,_0x45d403){this['source']=_0xa3dc1c,this['path']=_0x58a088,this['children']=_0x45d403,this['type']=q['MERGE'];}['operationForChild'](_0x450943){if(v(this['path'])){const _0x3bf173=this['children']['subtree'](new C(_0x450943));return _0x3bf173['isEmpty']()?null:_0x3bf173['value']?new Fe(this['source'],w(),_0x3bf173['value']):new nt(this['source'],w(),_0x3bf173);}else return f(y(this['path'])===_0x450943,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x22db9e,_0x973573,_0x2e4e08){this['node_']=_0x22db9e,this['fullyInitialized_']=_0x973573,this['filtered_']=_0x2e4e08;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x130f7c){if(v(_0x130f7c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1fc0e2=y(_0x130f7c);return this['isCompleteForChild'](_0x1fc0e2);}['isCompleteForChild'](_0x5b68d1){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5b68d1);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x3d7644){this['query_']=_0x3d7644,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4d0a24,_0xf573c2,_0x2abd18,_0x25ee7d){const _0x19b7a1=[],_0x350486=[];return _0xf573c2['forEach'](_0x318c72=>{_0x318c72['type']==='child_changed'&&_0x4d0a24['index_']['indexedValueChanged'](_0x318c72['oldSnap'],_0x318c72['snapshotNode'])&&_0x350486['push']($h(_0x318c72['childName'],_0x318c72['snapshotNode']));}),mt(_0x4d0a24,_0x19b7a1,'child_removed',_0xf573c2,_0x25ee7d,_0x2abd18),mt(_0x4d0a24,_0x19b7a1,'child_added',_0xf573c2,_0x25ee7d,_0x2abd18),mt(_0x4d0a24,_0x19b7a1,'child_moved',_0x350486,_0x25ee7d,_0x2abd18),mt(_0x4d0a24,_0x19b7a1,'child_changed',_0xf573c2,_0x25ee7d,_0x2abd18),mt(_0x4d0a24,_0x19b7a1,'value',_0xf573c2,_0x25ee7d,_0x2abd18),_0x19b7a1;}function mt(_0x174ba7,_0x405d53,_0x5f186f,_0x5c76d2,_0x3a9335,_0x1ea450){const _0xfcd177=_0x5c76d2['filter'](_0x144b79=>_0x144b79['type']===_0x5f186f);_0xfcd177['sort']((_0x4d06bb,_0xe0dbec)=>su(_0x174ba7,_0x4d06bb,_0xe0dbec)),_0xfcd177['forEach'](_0x10dc6a=>{const _0x48796d=iu(_0x174ba7,_0x10dc6a,_0x1ea450);_0x3a9335['forEach'](_0x28b594=>{_0x28b594['respondsTo'](_0x10dc6a['type'])&&_0x405d53['push'](_0x28b594['createEvent'](_0x48796d,_0x174ba7['query_']));});});}function iu(_0xe990f7,_0x903a76,_0x1da09e){return _0x903a76['type']==='value'||_0x903a76['type']==='child_removed'||(_0x903a76['prevName']=_0x1da09e['getPredecessorChildName'](_0x903a76['childName'],_0x903a76['snapshotNode'],_0xe990f7['index_'])),_0x903a76;}function su(_0x2cb0f6,_0x5e04f3,_0x2f3e72){if(_0x5e04f3['childName']==null||_0x2f3e72['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x1d4102=new E(_0x5e04f3['childName'],_0x5e04f3['snapshotNode']),_0x550497=new E(_0x2f3e72['childName'],_0x2f3e72['snapshotNode']);return _0x2cb0f6['index_']['compare'](_0x1d4102,_0x550497);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x88d8de,_0x105266){return{'eventCache':_0x88d8de,'serverCache':_0x105266};}function wt(_0x4e3c4a,_0x163db6,_0x2818ab,_0x3d7968){return Dn(new Ce(_0x163db6,_0x2818ab,_0x3d7968),_0x4e3c4a['serverCache']);}function Lo(_0x74a6d,_0x5dae94,_0xaac4a,_0x9bb91f){return Dn(_0x74a6d['eventCache'],new Ce(_0x5dae94,_0xaac4a,_0x9bb91f));}function gn(_0x20e5b5){return _0x20e5b5['eventCache']['isFullyInitialized']()?_0x20e5b5['eventCache']['getNode']():null;}function Ue(_0x36cfbd){return _0x36cfbd['serverCache']['isFullyInitialized']()?_0x36cfbd['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x516398){let _0x2c594e=new S(null);return x(_0x516398,(_0x29787b,_0x39d7c0)=>{_0x2c594e=_0x2c594e['set'](new C(_0x29787b),_0x39d7c0);}),_0x2c594e;}constructor(_0x1af315,_0x1fe139=ru()){this['value']=_0x1af315,this['children']=_0x1fe139;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x444123,_0x1dadc7){if(this['value']!=null&&_0x1dadc7(this['value']))return{'path':w(),'value':this['value']};if(v(_0x444123))return null;{const _0x1e7a5a=y(_0x444123),_0x42a843=this['children']['get'](_0x1e7a5a);if(_0x42a843!==null){const _0x33fbed=_0x42a843['findRootMostMatchingPathAndValue'](b(_0x444123),_0x1dadc7);return _0x33fbed!=null?{'path':A(new C(_0x1e7a5a),_0x33fbed['path']),'value':_0x33fbed['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x48be1a){return this['findRootMostMatchingPathAndValue'](_0x48be1a,()=>!0x0);}['subtree'](_0x14c18b){if(v(_0x14c18b))return this;{const _0x4c6189=y(_0x14c18b),_0x222e1b=this['children']['get'](_0x4c6189);return _0x222e1b!==null?_0x222e1b['subtree'](b(_0x14c18b)):new S(null);}}['set'](_0x461129,_0x16fc27){if(v(_0x461129))return new S(_0x16fc27,this['children']);{const _0x116adb=y(_0x461129),_0xa3a121=(this['children']['get'](_0x116adb)||new S(null))['set'](b(_0x461129),_0x16fc27),_0x374010=this['children']['insert'](_0x116adb,_0xa3a121);return new S(this['value'],_0x374010);}}['remove'](_0x14c976){if(v(_0x14c976))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0xc3e8ba=y(_0x14c976),_0x566c32=this['children']['get'](_0xc3e8ba);if(_0x566c32){const _0xfebd4a=_0x566c32['remove'](b(_0x14c976));let _0x39ab9;return _0xfebd4a['isEmpty']()?_0x39ab9=this['children']['remove'](_0xc3e8ba):_0x39ab9=this['children']['insert'](_0xc3e8ba,_0xfebd4a),this['value']===null&&_0x39ab9['isEmpty']()?new S(null):new S(this['value'],_0x39ab9);}else return this;}}['get'](_0x1d5caa){if(v(_0x1d5caa))return this['value'];{const _0x4e1e19=y(_0x1d5caa),_0x2094ed=this['children']['get'](_0x4e1e19);return _0x2094ed?_0x2094ed['get'](b(_0x1d5caa)):null;}}['setTree'](_0x57325f,_0x2dd722){if(v(_0x57325f))return _0x2dd722;{const _0x3bab26=y(_0x57325f),_0x4bf45a=(this['children']['get'](_0x3bab26)||new S(null))['setTree'](b(_0x57325f),_0x2dd722);let _0x2c5514;return _0x4bf45a['isEmpty']()?_0x2c5514=this['children']['remove'](_0x3bab26):_0x2c5514=this['children']['insert'](_0x3bab26,_0x4bf45a),new S(this['value'],_0x2c5514);}}['fold'](_0x4ee7b0){return this['fold_'](w(),_0x4ee7b0);}['fold_'](_0x232dee,_0x229127){const _0x422aed={};return this['children']['inorderTraversal']((_0x40f724,_0x5decc3)=>{_0x422aed[_0x40f724]=_0x5decc3['fold_'](A(_0x232dee,_0x40f724),_0x229127);}),_0x229127(_0x232dee,this['value'],_0x422aed);}['findOnPath'](_0x5e09a9,_0x3af53c){return this['findOnPath_'](_0x5e09a9,w(),_0x3af53c);}['findOnPath_'](_0x2fb469,_0x2a4a1a,_0x824aea){const _0x1d80fe=this['value']?_0x824aea(_0x2a4a1a,this['value']):!0x1;if(_0x1d80fe)return _0x1d80fe;if(v(_0x2fb469))return null;{const _0x36fc5b=y(_0x2fb469),_0x2e5fbd=this['children']['get'](_0x36fc5b);return _0x2e5fbd?_0x2e5fbd['findOnPath_'](b(_0x2fb469),A(_0x2a4a1a,_0x36fc5b),_0x824aea):null;}}['foreachOnPath'](_0x5768b5,_0x3403f6){return this['foreachOnPath_'](_0x5768b5,w(),_0x3403f6);}['foreachOnPath_'](_0x417bbb,_0x1e3c48,_0x1f2f9e){if(v(_0x417bbb))return this;{this['value']&&_0x1f2f9e(_0x1e3c48,this['value']);const _0x553fcd=y(_0x417bbb),_0x24a4aa=this['children']['get'](_0x553fcd);return _0x24a4aa?_0x24a4aa['foreachOnPath_'](b(_0x417bbb),A(_0x1e3c48,_0x553fcd),_0x1f2f9e):new S(null);}}['foreach'](_0x4d4805){this['foreach_'](w(),_0x4d4805);}['foreach_'](_0x434620,_0xfcfd1){this['children']['inorderTraversal']((_0x5aa255,_0x34a7cf)=>{_0x34a7cf['foreach_'](A(_0x434620,_0x5aa255),_0xfcfd1);}),this['value']&&_0xfcfd1(_0x434620,this['value']);}['foreachChild'](_0x37e97e){this['children']['inorderTraversal']((_0xd7eb16,_0x18731b)=>{_0x18731b['value']&&_0x37e97e(_0xd7eb16,_0x18731b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x709da8){this['writeTree_']=_0x709da8;}static['empty'](){return new j(new S(null));}}function Ct(_0x5076c4,_0xf368ad,_0x1421af){if(v(_0xf368ad))return new j(new S(_0x1421af));{const _0xbf79c3=_0x5076c4['writeTree_']['findRootMostValueAndPath'](_0xf368ad);if(_0xbf79c3!=null){const _0x3230c4=_0xbf79c3['path'];let _0x13dbfd=_0xbf79c3['value'];const _0xab375=F(_0x3230c4,_0xf368ad);return _0x13dbfd=_0x13dbfd['updateChild'](_0xab375,_0x1421af),new j(_0x5076c4['writeTree_']['set'](_0x3230c4,_0x13dbfd));}else{const _0x30ba92=new S(_0x1421af),_0x4f85f9=_0x5076c4['writeTree_']['setTree'](_0xf368ad,_0x30ba92);return new j(_0x4f85f9);}}}function Ii(_0x21b012,_0x2d39e5,_0x22c52f){let _0x17c03d=_0x21b012;return x(_0x22c52f,(_0x9e360c,_0xa1cf5b)=>{_0x17c03d=Ct(_0x17c03d,A(_0x2d39e5,_0x9e360c),_0xa1cf5b);}),_0x17c03d;}function sr(_0x49c946,_0x5a9950){if(v(_0x5a9950))return j['empty']();{const _0x4fb507=_0x49c946['writeTree_']['setTree'](_0x5a9950,new S(null));return new j(_0x4fb507);}}function wi(_0x169a2e,_0x2db08d){return $e(_0x169a2e,_0x2db08d)!=null;}function $e(_0xf9d10,_0x80df4b){const _0x599011=_0xf9d10['writeTree_']['findRootMostValueAndPath'](_0x80df4b);return _0x599011!=null?_0xf9d10['writeTree_']['get'](_0x599011['path'])['getChild'](F(_0x599011['path'],_0x80df4b)):null;}function rr(_0x48003f){const _0x384652=[],_0x371ab2=_0x48003f['writeTree_']['value'];return _0x371ab2!=null?_0x371ab2['isLeafNode']()||_0x371ab2['forEachChild'](R,(_0x754f03,_0x111de1)=>{_0x384652['push'](new E(_0x754f03,_0x111de1));}):_0x48003f['writeTree_']['children']['inorderTraversal']((_0x8a09,_0x9128d8)=>{_0x9128d8['value']!=null&&_0x384652['push'](new E(_0x8a09,_0x9128d8['value']));}),_0x384652;}function ve(_0x3ea6f7,_0x3101b0){if(v(_0x3101b0))return _0x3ea6f7;{const _0x549dfb=$e(_0x3ea6f7,_0x3101b0);return _0x549dfb!=null?new j(new S(_0x549dfb)):new j(_0x3ea6f7['writeTree_']['subtree'](_0x3101b0));}}function Ci(_0x3a8540){return _0x3a8540['writeTree_']['isEmpty']();}function it(_0x8bae4f,_0x556fd0){return xo(w(),_0x8bae4f['writeTree_'],_0x556fd0);}function xo(_0x46e2c5,_0x2a1ba0,_0x1a3359){if(_0x2a1ba0['value']!=null)return _0x1a3359['updateChild'](_0x46e2c5,_0x2a1ba0['value']);{let _0x8272ef=null;return _0x2a1ba0['children']['inorderTraversal']((_0x2aa57b,_0x647871)=>{_0x2aa57b==='.priority'?(f(_0x647871['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x8272ef=_0x647871['value']):_0x1a3359=xo(A(_0x46e2c5,_0x2aa57b),_0x647871,_0x1a3359);}),!_0x1a3359['getChild'](_0x46e2c5)['isEmpty']()&&_0x8272ef!==null&&(_0x1a3359=_0x1a3359['updateChild'](A(_0x46e2c5,'.priority'),_0x8272ef)),_0x1a3359;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1d2093,_0x250591){return Bo(_0x250591,_0x1d2093);}function ou(_0x2eb390,_0xbd455,_0x532bf0,_0x1a2eaf,_0x50b684){f(_0x1a2eaf>_0x2eb390['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x50b684===void 0x0&&(_0x50b684=!0x0),_0x2eb390['allWrites']['push']({'path':_0xbd455,'snap':_0x532bf0,'writeId':_0x1a2eaf,'visible':_0x50b684}),_0x50b684&&(_0x2eb390['visibleWrites']=Ct(_0x2eb390['visibleWrites'],_0xbd455,_0x532bf0)),_0x2eb390['lastWriteId']=_0x1a2eaf;}function au(_0x9c6c94,_0x25a2dc,_0x5dcaab,_0x107b20){f(_0x107b20>_0x9c6c94['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x9c6c94['allWrites']['push']({'path':_0x25a2dc,'children':_0x5dcaab,'writeId':_0x107b20,'visible':!0x0}),_0x9c6c94['visibleWrites']=Ii(_0x9c6c94['visibleWrites'],_0x25a2dc,_0x5dcaab),_0x9c6c94['lastWriteId']=_0x107b20;}function cu(_0x58e7b3,_0x5e49e4){for(let _0x5b823f=0x0;_0x5b823f<_0x58e7b3['allWrites']['length'];_0x5b823f++){const _0x4ad1ba=_0x58e7b3['allWrites'][_0x5b823f];if(_0x4ad1ba['writeId']===_0x5e49e4)return _0x4ad1ba;}return null;}function lu(_0x2c6413,_0x50df10){const _0x3cff87=_0x2c6413['allWrites']['findIndex'](_0x46802c=>_0x46802c['writeId']===_0x50df10);f(_0x3cff87>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xe6cea9=_0x2c6413['allWrites'][_0x3cff87];_0x2c6413['allWrites']['splice'](_0x3cff87,0x1);let _0x307092=_0xe6cea9['visible'],_0x595a72=!0x1,_0xf3e071=_0x2c6413['allWrites']['length']-0x1;for(;_0x307092&&_0xf3e071>=0x0;){const _0x19d574=_0x2c6413['allWrites'][_0xf3e071];_0x19d574['visible']&&(_0xf3e071>=_0x3cff87&&hu(_0x19d574,_0xe6cea9['path'])?_0x307092=!0x1:$(_0xe6cea9['path'],_0x19d574['path'])&&(_0x595a72=!0x0)),_0xf3e071--;}if(_0x307092){if(_0x595a72)return uu(_0x2c6413),!0x0;if(_0xe6cea9['snap'])_0x2c6413['visibleWrites']=sr(_0x2c6413['visibleWrites'],_0xe6cea9['path']);else{const _0x7aebcf=_0xe6cea9['children'];x(_0x7aebcf,_0x3dc592=>{_0x2c6413['visibleWrites']=sr(_0x2c6413['visibleWrites'],A(_0xe6cea9['path'],_0x3dc592));});}return!0x0;}else return!0x1;}function hu(_0x599f7f,_0x4d2ae9){if(_0x599f7f['snap'])return $(_0x599f7f['path'],_0x4d2ae9);for(const _0x13d698 in _0x599f7f['children'])if(_0x599f7f['children']['hasOwnProperty'](_0x13d698)&&$(A(_0x599f7f['path'],_0x13d698),_0x4d2ae9))return!0x0;return!0x1;}function uu(_0x5547b5){_0x5547b5['visibleWrites']=Fo(_0x5547b5['allWrites'],du,w()),_0x5547b5['allWrites']['length']>0x0?_0x5547b5['lastWriteId']=_0x5547b5['allWrites'][_0x5547b5['allWrites']['length']-0x1]['writeId']:_0x5547b5['lastWriteId']=-0x1;}function du(_0x2318a7){return _0x2318a7['visible'];}function Fo(_0x33334a,_0x419de3,_0x592484){let _0x1bed7a=j['empty']();for(let _0x110158=0x0;_0x110158<_0x33334a['length'];++_0x110158){const _0x48f198=_0x33334a[_0x110158];if(_0x419de3(_0x48f198)){const _0x3fa570=_0x48f198['path'];let _0x409c54;if(_0x48f198['snap'])$(_0x592484,_0x3fa570)?(_0x409c54=F(_0x592484,_0x3fa570),_0x1bed7a=Ct(_0x1bed7a,_0x409c54,_0x48f198['snap'])):$(_0x3fa570,_0x592484)&&(_0x409c54=F(_0x3fa570,_0x592484),_0x1bed7a=Ct(_0x1bed7a,w(),_0x48f198['snap']['getChild'](_0x409c54)));else{if(_0x48f198['children']){if($(_0x592484,_0x3fa570))_0x409c54=F(_0x592484,_0x3fa570),_0x1bed7a=Ii(_0x1bed7a,_0x409c54,_0x48f198['children']);else{if($(_0x3fa570,_0x592484)){if(_0x409c54=F(_0x3fa570,_0x592484),v(_0x409c54))_0x1bed7a=Ii(_0x1bed7a,w(),_0x48f198['children']);else{const _0x23bd18=Oe(_0x48f198['children'],y(_0x409c54));if(_0x23bd18){const _0x701103=_0x23bd18['getChild'](b(_0x409c54));_0x1bed7a=Ct(_0x1bed7a,w(),_0x701103);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1bed7a;}function Uo(_0xbc8192,_0x22ecef,_0x3874de,_0x3bb736,_0x24a10b){if(!_0x3bb736&&!_0x24a10b){const _0x3e2abc=$e(_0xbc8192['visibleWrites'],_0x22ecef);if(_0x3e2abc!=null)return _0x3e2abc;{const _0x521f1e=ve(_0xbc8192['visibleWrites'],_0x22ecef);if(Ci(_0x521f1e))return _0x3874de;if(_0x3874de==null&&!wi(_0x521f1e,w()))return null;{const _0x27805d=_0x3874de||g['EMPTY_NODE'];return it(_0x521f1e,_0x27805d);}}}else{const _0x19ecae=ve(_0xbc8192['visibleWrites'],_0x22ecef);if(!_0x24a10b&&Ci(_0x19ecae))return _0x3874de;if(!_0x24a10b&&_0x3874de==null&&!wi(_0x19ecae,w()))return null;{const _0x1c3865=function(_0x599004){return(_0x599004['visible']||_0x24a10b)&&(!_0x3bb736||!~_0x3bb736['indexOf'](_0x599004['writeId']))&&($(_0x599004['path'],_0x22ecef)||$(_0x22ecef,_0x599004['path']));},_0x34a91c=Fo(_0xbc8192['allWrites'],_0x1c3865,_0x22ecef),_0x18df1b=_0x3874de||g['EMPTY_NODE'];return it(_0x34a91c,_0x18df1b);}}}function fu(_0xfa1e80,_0x29baf4,_0x4e8ce8){let _0x236654=g['EMPTY_NODE'];const _0x3862c0=$e(_0xfa1e80['visibleWrites'],_0x29baf4);if(_0x3862c0)return _0x3862c0['isLeafNode']()||_0x3862c0['forEachChild'](R,(_0x22f561,_0x19b2fd)=>{_0x236654=_0x236654['updateImmediateChild'](_0x22f561,_0x19b2fd);}),_0x236654;if(_0x4e8ce8){const _0x3d5cb2=ve(_0xfa1e80['visibleWrites'],_0x29baf4);return _0x4e8ce8['forEachChild'](R,(_0x2fe590,_0x1c7ef9)=>{const _0x7aa89e=it(ve(_0x3d5cb2,new C(_0x2fe590)),_0x1c7ef9);_0x236654=_0x236654['updateImmediateChild'](_0x2fe590,_0x7aa89e);}),rr(_0x3d5cb2)['forEach'](_0x37b9f7=>{_0x236654=_0x236654['updateImmediateChild'](_0x37b9f7['name'],_0x37b9f7['node']);}),_0x236654;}else{const _0x321192=ve(_0xfa1e80['visibleWrites'],_0x29baf4);return rr(_0x321192)['forEach'](_0x506096=>{_0x236654=_0x236654['updateImmediateChild'](_0x506096['name'],_0x506096['node']);}),_0x236654;}}function pu(_0x13689b,_0x1ebec4,_0x206aee,_0x35b725,_0x553417){f(_0x35b725||_0x553417,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4ad648=A(_0x1ebec4,_0x206aee);if(wi(_0x13689b['visibleWrites'],_0x4ad648))return null;{const _0x54b221=ve(_0x13689b['visibleWrites'],_0x4ad648);return Ci(_0x54b221)?_0x553417['getChild'](_0x206aee):it(_0x54b221,_0x553417['getChild'](_0x206aee));}}function _u(_0xe024d2,_0x2b9c93,_0x5188c3,_0x3fa5ca){const _0x3e9f90=A(_0x2b9c93,_0x5188c3),_0x350654=$e(_0xe024d2['visibleWrites'],_0x3e9f90);if(_0x350654!=null)return _0x350654;if(_0x3fa5ca['isCompleteForChild'](_0x5188c3)){const _0x1aac2b=ve(_0xe024d2['visibleWrites'],_0x3e9f90);return it(_0x1aac2b,_0x3fa5ca['getNode']()['getImmediateChild'](_0x5188c3));}else return null;}function gu(_0x255f37,_0x3f6b19){return $e(_0x255f37['visibleWrites'],_0x3f6b19);}function mu(_0x53c80c,_0x42459d,_0x2d34c2,_0x586673,_0x2679ba,_0x2a5328,_0x1642a7){let _0xd83a0;const _0x25fcb0=ve(_0x53c80c['visibleWrites'],_0x42459d),_0x552b05=$e(_0x25fcb0,w());if(_0x552b05!=null)_0xd83a0=_0x552b05;else{if(_0x2d34c2!=null)_0xd83a0=it(_0x25fcb0,_0x2d34c2);else return[];}if(_0xd83a0=_0xd83a0['withIndex'](_0x1642a7),!_0xd83a0['isEmpty']()&&!_0xd83a0['isLeafNode']()){const _0x3a0577=[],_0x3baa44=_0x1642a7['getCompare'](),_0xb575b1=_0x2a5328?_0xd83a0['getReverseIteratorFrom'](_0x586673,_0x1642a7):_0xd83a0['getIteratorFrom'](_0x586673,_0x1642a7);let _0x24f841=_0xb575b1['getNext']();for(;_0x24f841&&_0x3a0577['length']<_0x2679ba;)_0x3baa44(_0x24f841,_0x586673)!==0x0&&_0x3a0577['push'](_0x24f841),_0x24f841=_0xb575b1['getNext']();return _0x3a0577;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x36fdc7,_0x434dda,_0x1bb376,_0xeed6ef){return Uo(_0x36fdc7['writeTree'],_0x36fdc7['treePath'],_0x434dda,_0x1bb376,_0xeed6ef);}function es(_0x5e953d,_0x200369){return fu(_0x5e953d['writeTree'],_0x5e953d['treePath'],_0x200369);}function or(_0x3a83d9,_0x169f8f,_0x5e4dd2,_0x2fb907){return pu(_0x3a83d9['writeTree'],_0x3a83d9['treePath'],_0x169f8f,_0x5e4dd2,_0x2fb907);}function yn(_0x2f6cf4,_0x531c12){return gu(_0x2f6cf4['writeTree'],A(_0x2f6cf4['treePath'],_0x531c12));}function vu(_0x4b3fe8,_0x14da14,_0x5b3f18,_0x585821,_0x2a1d39,_0x2ec7ac){return mu(_0x4b3fe8['writeTree'],_0x4b3fe8['treePath'],_0x14da14,_0x5b3f18,_0x585821,_0x2a1d39,_0x2ec7ac);}function ts(_0x493266,_0x3f396c,_0x7cf63d){return _u(_0x493266['writeTree'],_0x493266['treePath'],_0x3f396c,_0x7cf63d);}function Wo(_0x3a9fd1,_0x494e96){return Bo(A(_0x3a9fd1['treePath'],_0x494e96),_0x3a9fd1['writeTree']);}function Bo(_0x5e393f,_0xa1305c){return{'treePath':_0x5e393f,'writeTree':_0xa1305c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4389c7){const _0x2239d2=_0x4389c7['type'],_0x300322=_0x4389c7['childName'];f(_0x2239d2==='child_added'||_0x2239d2==='child_changed'||_0x2239d2==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x300322!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4281eb=this['changeMap']['get'](_0x300322);if(_0x4281eb){const _0x28840d=_0x4281eb['type'];if(_0x2239d2==='child_added'&&_0x28840d==='child_removed')this['changeMap']['set'](_0x300322,Pt(_0x300322,_0x4389c7['snapshotNode'],_0x4281eb['snapshotNode']));else{if(_0x2239d2==='child_removed'&&_0x28840d==='child_added')this['changeMap']['delete'](_0x300322);else{if(_0x2239d2==='child_removed'&&_0x28840d==='child_changed')this['changeMap']['set'](_0x300322,Nt(_0x300322,_0x4281eb['oldSnap']));else{if(_0x2239d2==='child_changed'&&_0x28840d==='child_added')this['changeMap']['set'](_0x300322,tt(_0x300322,_0x4389c7['snapshotNode']));else{if(_0x2239d2==='child_changed'&&_0x28840d==='child_changed')this['changeMap']['set'](_0x300322,Pt(_0x300322,_0x4389c7['snapshotNode'],_0x4281eb['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x4389c7+'\x20occurred\x20after\x20'+_0x4281eb);}}}}}else this['changeMap']['set'](_0x300322,_0x4389c7);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4daa5a){return null;}['getChildAfterChild'](_0x582864,_0x532616,_0x1c5e5e){return null;}}const Vo=new Iu();class ns{constructor(_0x45d98f,_0x35ad15,_0x241767=null){this['writes_']=_0x45d98f,this['viewCache_']=_0x35ad15,this['optCompleteServerCache_']=_0x241767;}['getCompleteChild'](_0x4e5db6){const _0x2e2c88=this['viewCache_']['eventCache'];if(_0x2e2c88['isCompleteForChild'](_0x4e5db6))return _0x2e2c88['getNode']()['getImmediateChild'](_0x4e5db6);{const _0x2b9da0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x4e5db6,_0x2b9da0);}}['getChildAfterChild'](_0x3a8166,_0x2f68b6,_0x28996a){const _0x50dd55=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x516e7a=vu(this['writes_'],_0x50dd55,_0x2f68b6,0x1,_0x28996a,_0x3a8166);return _0x516e7a['length']===0x0?null:_0x516e7a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x115a4f){return{'filter':_0x115a4f};}function Cu(_0x32e909,_0x4bda08){f(_0x4bda08['eventCache']['getNode']()['isIndexed'](_0x32e909['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4bda08['serverCache']['getNode']()['isIndexed'](_0x32e909['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x211c4b,_0x4ccfee,_0x2f1931,_0x3a0a7f,_0x345474){const _0x54b5d9=new Eu();let _0x375c00,_0x54e9cf;if(_0x2f1931['type']===q['OVERWRITE']){const _0x51b3eb=_0x2f1931;_0x51b3eb['source']['fromUser']?_0x375c00=Ti(_0x211c4b,_0x4ccfee,_0x51b3eb['path'],_0x51b3eb['snap'],_0x3a0a7f,_0x345474,_0x54b5d9):(f(_0x51b3eb['source']['fromServer'],'Unknown\x20source.'),_0x54e9cf=_0x51b3eb['source']['tagged']||_0x4ccfee['serverCache']['isFiltered']()&&!v(_0x51b3eb['path']),_0x375c00=vn(_0x211c4b,_0x4ccfee,_0x51b3eb['path'],_0x51b3eb['snap'],_0x3a0a7f,_0x345474,_0x54e9cf,_0x54b5d9));}else{if(_0x2f1931['type']===q['MERGE']){const _0x2b5bc0=_0x2f1931;_0x2b5bc0['source']['fromUser']?_0x375c00=bu(_0x211c4b,_0x4ccfee,_0x2b5bc0['path'],_0x2b5bc0['children'],_0x3a0a7f,_0x345474,_0x54b5d9):(f(_0x2b5bc0['source']['fromServer'],'Unknown\x20source.'),_0x54e9cf=_0x2b5bc0['source']['tagged']||_0x4ccfee['serverCache']['isFiltered'](),_0x375c00=Si(_0x211c4b,_0x4ccfee,_0x2b5bc0['path'],_0x2b5bc0['children'],_0x3a0a7f,_0x345474,_0x54e9cf,_0x54b5d9));}else{if(_0x2f1931['type']===q['ACK_USER_WRITE']){const _0x4aac4a=_0x2f1931;_0x4aac4a['revert']?_0x375c00=ku(_0x211c4b,_0x4ccfee,_0x4aac4a['path'],_0x3a0a7f,_0x345474,_0x54b5d9):_0x375c00=Ru(_0x211c4b,_0x4ccfee,_0x4aac4a['path'],_0x4aac4a['affectedTree'],_0x3a0a7f,_0x345474,_0x54b5d9);}else{if(_0x2f1931['type']===q['LISTEN_COMPLETE'])_0x375c00=Au(_0x211c4b,_0x4ccfee,_0x2f1931['path'],_0x3a0a7f,_0x54b5d9);else throw ot('Unknown\x20operation\x20type:\x20'+_0x2f1931['type']);}}}const _0x1f86c5=_0x54b5d9['getChanges']();return Su(_0x4ccfee,_0x375c00,_0x1f86c5),{'viewCache':_0x375c00,'changes':_0x1f86c5};}function Su(_0x2042f2,_0xbd256c,_0x2f4a4f){const _0x21b84e=_0xbd256c['eventCache'];if(_0x21b84e['isFullyInitialized']()){const _0xa91d70=_0x21b84e['getNode']()['isLeafNode']()||_0x21b84e['getNode']()['isEmpty'](),_0x3113d5=gn(_0x2042f2);(_0x2f4a4f['length']>0x0||!_0x2042f2['eventCache']['isFullyInitialized']()||_0xa91d70&&!_0x21b84e['getNode']()['equals'](_0x3113d5)||!_0x21b84e['getNode']()['getPriority']()['equals'](_0x3113d5['getPriority']()))&&_0x2f4a4f['push'](Oo(gn(_0xbd256c)));}}function Ho(_0x3feb28,_0xac114a,_0x215534,_0x80ab7c,_0x33242c,_0x55bfff){const _0x44719d=_0xac114a['eventCache'];if(yn(_0x80ab7c,_0x215534)!=null)return _0xac114a;{let _0x556883,_0x5ed330;if(v(_0x215534)){if(f(_0xac114a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xac114a['serverCache']['isFiltered']()){const _0x54e0b3=Ue(_0xac114a),_0x32b868=_0x54e0b3 instanceof g?_0x54e0b3:g['EMPTY_NODE'],_0x1706b3=es(_0x80ab7c,_0x32b868);_0x556883=_0x3feb28['filter']['updateFullNode'](_0xac114a['eventCache']['getNode'](),_0x1706b3,_0x55bfff);}else{const _0xd3120a=mn(_0x80ab7c,Ue(_0xac114a));_0x556883=_0x3feb28['filter']['updateFullNode'](_0xac114a['eventCache']['getNode'](),_0xd3120a,_0x55bfff);}}else{const _0x2b09c1=y(_0x215534);if(_0x2b09c1==='.priority'){f(we(_0x215534)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xb74259=_0x44719d['getNode']();_0x5ed330=_0xac114a['serverCache']['getNode']();const _0x1f8663=or(_0x80ab7c,_0x215534,_0xb74259,_0x5ed330);_0x1f8663!=null?_0x556883=_0x3feb28['filter']['updatePriority'](_0xb74259,_0x1f8663):_0x556883=_0x44719d['getNode']();}else{const _0x5593b1=b(_0x215534);let _0x32c55b;if(_0x44719d['isCompleteForChild'](_0x2b09c1)){_0x5ed330=_0xac114a['serverCache']['getNode']();const _0x57c597=or(_0x80ab7c,_0x215534,_0x44719d['getNode'](),_0x5ed330);_0x57c597!=null?_0x32c55b=_0x44719d['getNode']()['getImmediateChild'](_0x2b09c1)['updateChild'](_0x5593b1,_0x57c597):_0x32c55b=_0x44719d['getNode']()['getImmediateChild'](_0x2b09c1);}else _0x32c55b=ts(_0x80ab7c,_0x2b09c1,_0xac114a['serverCache']);_0x32c55b!=null?_0x556883=_0x3feb28['filter']['updateChild'](_0x44719d['getNode'](),_0x2b09c1,_0x32c55b,_0x5593b1,_0x33242c,_0x55bfff):_0x556883=_0x44719d['getNode']();}}return wt(_0xac114a,_0x556883,_0x44719d['isFullyInitialized']()||v(_0x215534),_0x3feb28['filter']['filtersNodes']());}}function vn(_0x425639,_0x4c79fa,_0x3af777,_0x5761a3,_0xb6848c,_0xc29128,_0x2cd280,_0x54f096){const _0xd1b382=_0x4c79fa['serverCache'];let _0x24865d;const _0x4f5fed=_0x2cd280?_0x425639['filter']:_0x425639['filter']['getIndexedFilter']();if(v(_0x3af777))_0x24865d=_0x4f5fed['updateFullNode'](_0xd1b382['getNode'](),_0x5761a3,null);else{if(_0x4f5fed['filtersNodes']()&&!_0xd1b382['isFiltered']()){const _0x30ef72=_0xd1b382['getNode']()['updateChild'](_0x3af777,_0x5761a3);_0x24865d=_0x4f5fed['updateFullNode'](_0xd1b382['getNode'](),_0x30ef72,null);}else{const _0x2b2e48=y(_0x3af777);if(!_0xd1b382['isCompleteForPath'](_0x3af777)&&we(_0x3af777)>0x1)return _0x4c79fa;const _0x1b534e=b(_0x3af777),_0x5db34c=_0xd1b382['getNode']()['getImmediateChild'](_0x2b2e48)['updateChild'](_0x1b534e,_0x5761a3);_0x2b2e48==='.priority'?_0x24865d=_0x4f5fed['updatePriority'](_0xd1b382['getNode'](),_0x5db34c):_0x24865d=_0x4f5fed['updateChild'](_0xd1b382['getNode'](),_0x2b2e48,_0x5db34c,_0x1b534e,Vo,null);}}const _0xcc9584=Lo(_0x4c79fa,_0x24865d,_0xd1b382['isFullyInitialized']()||v(_0x3af777),_0x4f5fed['filtersNodes']()),_0xfbee5a=new ns(_0xb6848c,_0xcc9584,_0xc29128);return Ho(_0x425639,_0xcc9584,_0x3af777,_0xb6848c,_0xfbee5a,_0x54f096);}function Ti(_0x10ac4a,_0x59cc98,_0x154162,_0x5a8744,_0x1690dd,_0x1df1f4,_0x417276){const _0x206fa4=_0x59cc98['eventCache'];let _0x2cddb8,_0x3463fc;const _0x5d2a03=new ns(_0x1690dd,_0x59cc98,_0x1df1f4);if(v(_0x154162))_0x3463fc=_0x10ac4a['filter']['updateFullNode'](_0x59cc98['eventCache']['getNode'](),_0x5a8744,_0x417276),_0x2cddb8=wt(_0x59cc98,_0x3463fc,!0x0,_0x10ac4a['filter']['filtersNodes']());else{const _0x4baefa=y(_0x154162);if(_0x4baefa==='.priority')_0x3463fc=_0x10ac4a['filter']['updatePriority'](_0x59cc98['eventCache']['getNode'](),_0x5a8744),_0x2cddb8=wt(_0x59cc98,_0x3463fc,_0x206fa4['isFullyInitialized'](),_0x206fa4['isFiltered']());else{const _0x2dfeef=b(_0x154162),_0x278c65=_0x206fa4['getNode']()['getImmediateChild'](_0x4baefa);let _0x4c6fbb;if(v(_0x2dfeef))_0x4c6fbb=_0x5a8744;else{const _0x2721d0=_0x5d2a03['getCompleteChild'](_0x4baefa);_0x2721d0!=null?Gi(_0x2dfeef)==='.priority'&&_0x2721d0['getChild'](To(_0x2dfeef))['isEmpty']()?_0x4c6fbb=_0x2721d0:_0x4c6fbb=_0x2721d0['updateChild'](_0x2dfeef,_0x5a8744):_0x4c6fbb=g['EMPTY_NODE'];}if(_0x278c65['equals'](_0x4c6fbb))_0x2cddb8=_0x59cc98;else{const _0x17c8a8=_0x10ac4a['filter']['updateChild'](_0x206fa4['getNode'](),_0x4baefa,_0x4c6fbb,_0x2dfeef,_0x5d2a03,_0x417276);_0x2cddb8=wt(_0x59cc98,_0x17c8a8,_0x206fa4['isFullyInitialized'](),_0x10ac4a['filter']['filtersNodes']());}}}return _0x2cddb8;}function ar(_0x9f3844,_0x274fa0){return _0x9f3844['eventCache']['isCompleteForChild'](_0x274fa0);}function bu(_0xeb4f88,_0x2eb3df,_0x308f03,_0x140958,_0x4e9da1,_0x5997b4,_0x5ae85c){let _0x56523d=_0x2eb3df;return _0x140958['foreach']((_0x1dfb99,_0x499bdd)=>{const _0x1ae7cf=A(_0x308f03,_0x1dfb99);ar(_0x2eb3df,y(_0x1ae7cf))&&(_0x56523d=Ti(_0xeb4f88,_0x56523d,_0x1ae7cf,_0x499bdd,_0x4e9da1,_0x5997b4,_0x5ae85c));}),_0x140958['foreach']((_0x4380ee,_0x5b4b5c)=>{const _0x1449fb=A(_0x308f03,_0x4380ee);ar(_0x2eb3df,y(_0x1449fb))||(_0x56523d=Ti(_0xeb4f88,_0x56523d,_0x1449fb,_0x5b4b5c,_0x4e9da1,_0x5997b4,_0x5ae85c));}),_0x56523d;}function cr(_0x296729,_0x64d229,_0x5ce57a){return _0x5ce57a['foreach']((_0x347504,_0x59c489)=>{_0x64d229=_0x64d229['updateChild'](_0x347504,_0x59c489);}),_0x64d229;}function Si(_0x495c8b,_0x2707ce,_0x571dde,_0x46070f,_0x10f5ec,_0x381d9c,_0x3a3fdf,_0x4f3f95){if(_0x2707ce['serverCache']['getNode']()['isEmpty']()&&!_0x2707ce['serverCache']['isFullyInitialized']())return _0x2707ce;let _0x31b128=_0x2707ce,_0x39a89f;v(_0x571dde)?_0x39a89f=_0x46070f:_0x39a89f=new S(null)['setTree'](_0x571dde,_0x46070f);const _0x50dc51=_0x2707ce['serverCache']['getNode']();return _0x39a89f['children']['inorderTraversal']((_0xba2010,_0x20a6c1)=>{if(_0x50dc51['hasChild'](_0xba2010)){const _0x4caaae=_0x2707ce['serverCache']['getNode']()['getImmediateChild'](_0xba2010),_0x418066=cr(_0x495c8b,_0x4caaae,_0x20a6c1);_0x31b128=vn(_0x495c8b,_0x31b128,new C(_0xba2010),_0x418066,_0x10f5ec,_0x381d9c,_0x3a3fdf,_0x4f3f95);}}),_0x39a89f['children']['inorderTraversal']((_0x340891,_0x17bf54)=>{const _0x11aa8f=!_0x2707ce['serverCache']['isCompleteForChild'](_0x340891)&&_0x17bf54['value']===null;if(!_0x50dc51['hasChild'](_0x340891)&&!_0x11aa8f){const _0x4ce6ce=_0x2707ce['serverCache']['getNode']()['getImmediateChild'](_0x340891),_0xec3e19=cr(_0x495c8b,_0x4ce6ce,_0x17bf54);_0x31b128=vn(_0x495c8b,_0x31b128,new C(_0x340891),_0xec3e19,_0x10f5ec,_0x381d9c,_0x3a3fdf,_0x4f3f95);}}),_0x31b128;}function Ru(_0x11cf75,_0x1eee13,_0x1734bc,_0x2aa617,_0x3347cb,_0x29f4ce,_0x19ba7f){if(yn(_0x3347cb,_0x1734bc)!=null)return _0x1eee13;const _0x172b27=_0x1eee13['serverCache']['isFiltered'](),_0xeca366=_0x1eee13['serverCache'];if(_0x2aa617['value']!=null){if(v(_0x1734bc)&&_0xeca366['isFullyInitialized']()||_0xeca366['isCompleteForPath'](_0x1734bc))return vn(_0x11cf75,_0x1eee13,_0x1734bc,_0xeca366['getNode']()['getChild'](_0x1734bc),_0x3347cb,_0x29f4ce,_0x172b27,_0x19ba7f);if(v(_0x1734bc)){let _0x35827a=new S(null);return _0xeca366['getNode']()['forEachChild'](ye,(_0x1bb769,_0x301a7e)=>{_0x35827a=_0x35827a['set'](new C(_0x1bb769),_0x301a7e);}),Si(_0x11cf75,_0x1eee13,_0x1734bc,_0x35827a,_0x3347cb,_0x29f4ce,_0x172b27,_0x19ba7f);}else return _0x1eee13;}else{let _0x3ad268=new S(null);return _0x2aa617['foreach']((_0x224455,_0x17c7b2)=>{const _0x5b7503=A(_0x1734bc,_0x224455);_0xeca366['isCompleteForPath'](_0x5b7503)&&(_0x3ad268=_0x3ad268['set'](_0x224455,_0xeca366['getNode']()['getChild'](_0x5b7503)));}),Si(_0x11cf75,_0x1eee13,_0x1734bc,_0x3ad268,_0x3347cb,_0x29f4ce,_0x172b27,_0x19ba7f);}}function Au(_0x362b42,_0x462d8c,_0x436db6,_0x47bf9b,_0xd76b6b){const _0x3c2dfd=_0x462d8c['serverCache'],_0x2907ab=Lo(_0x462d8c,_0x3c2dfd['getNode'](),_0x3c2dfd['isFullyInitialized']()||v(_0x436db6),_0x3c2dfd['isFiltered']());return Ho(_0x362b42,_0x2907ab,_0x436db6,_0x47bf9b,Vo,_0xd76b6b);}function ku(_0x17d8df,_0x18fd8b,_0x920e6f,_0x543536,_0x4f6ef9,_0x314705){let _0x45e685;if(yn(_0x543536,_0x920e6f)!=null)return _0x18fd8b;{const _0x2fb073=new ns(_0x543536,_0x18fd8b,_0x4f6ef9),_0x33d187=_0x18fd8b['eventCache']['getNode']();let _0x1d21a8;if(v(_0x920e6f)||y(_0x920e6f)==='.priority'){let _0x5aad2a;if(_0x18fd8b['serverCache']['isFullyInitialized']())_0x5aad2a=mn(_0x543536,Ue(_0x18fd8b));else{const _0x551e52=_0x18fd8b['serverCache']['getNode']();f(_0x551e52 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5aad2a=es(_0x543536,_0x551e52);}_0x5aad2a=_0x5aad2a,_0x1d21a8=_0x17d8df['filter']['updateFullNode'](_0x33d187,_0x5aad2a,_0x314705);}else{const _0x3a8c57=y(_0x920e6f);let _0x9ec94e=ts(_0x543536,_0x3a8c57,_0x18fd8b['serverCache']);_0x9ec94e==null&&_0x18fd8b['serverCache']['isCompleteForChild'](_0x3a8c57)&&(_0x9ec94e=_0x33d187['getImmediateChild'](_0x3a8c57)),_0x9ec94e!=null?_0x1d21a8=_0x17d8df['filter']['updateChild'](_0x33d187,_0x3a8c57,_0x9ec94e,b(_0x920e6f),_0x2fb073,_0x314705):_0x18fd8b['eventCache']['getNode']()['hasChild'](_0x3a8c57)?_0x1d21a8=_0x17d8df['filter']['updateChild'](_0x33d187,_0x3a8c57,g['EMPTY_NODE'],b(_0x920e6f),_0x2fb073,_0x314705):_0x1d21a8=_0x33d187,_0x1d21a8['isEmpty']()&&_0x18fd8b['serverCache']['isFullyInitialized']()&&(_0x45e685=mn(_0x543536,Ue(_0x18fd8b)),_0x45e685['isLeafNode']()&&(_0x1d21a8=_0x17d8df['filter']['updateFullNode'](_0x1d21a8,_0x45e685,_0x314705)));}return _0x45e685=_0x18fd8b['serverCache']['isFullyInitialized']()||yn(_0x543536,w())!=null,wt(_0x18fd8b,_0x1d21a8,_0x45e685,_0x17d8df['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3fced8,_0x2f6b0e){this['query_']=_0x3fced8,this['eventRegistrations_']=[];const _0x3254b4=this['query_']['_queryParams'],_0x522ec4=new Yi(_0x3254b4['getIndex']()),_0x1b5554=qh(_0x3254b4);this['processor_']=wu(_0x1b5554);const _0x13dd43=_0x2f6b0e['serverCache'],_0x13692a=_0x2f6b0e['eventCache'],_0x10f2dc=_0x522ec4['updateFullNode'](g['EMPTY_NODE'],_0x13dd43['getNode'](),null),_0x47e27a=_0x1b5554['updateFullNode'](g['EMPTY_NODE'],_0x13692a['getNode'](),null),_0x5240e4=new Ce(_0x10f2dc,_0x13dd43['isFullyInitialized'](),_0x522ec4['filtersNodes']()),_0x49507e=new Ce(_0x47e27a,_0x13692a['isFullyInitialized'](),_0x1b5554['filtersNodes']());this['viewCache_']=Dn(_0x49507e,_0x5240e4),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x26a1fe){return _0x26a1fe['viewCache_']['serverCache']['getNode']();}function Ou(_0x2781a9){return gn(_0x2781a9['viewCache_']);}function Du(_0x4f3e13,_0x164db9){const _0x30aed3=Ue(_0x4f3e13['viewCache_']);return _0x30aed3&&(_0x4f3e13['query']['_queryParams']['loadsAllData']()||!v(_0x164db9)&&!_0x30aed3['getImmediateChild'](y(_0x164db9))['isEmpty']())?_0x30aed3['getChild'](_0x164db9):null;}function lr(_0x5307b6){return _0x5307b6['eventRegistrations_']['length']===0x0;}function Mu(_0x36cb56,_0x2f5555){_0x36cb56['eventRegistrations_']['push'](_0x2f5555);}function hr(_0x2af4e3,_0x289d57,_0x38878e){const _0x2c93f3=[];if(_0x38878e){f(_0x289d57==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3990eb=_0x2af4e3['query']['_path'];_0x2af4e3['eventRegistrations_']['forEach'](_0x7295d=>{const _0x5e1d38=_0x7295d['createCancelEvent'](_0x38878e,_0x3990eb);_0x5e1d38&&_0x2c93f3['push'](_0x5e1d38);});}if(_0x289d57){let _0x26bcc5=[];for(let _0xa31ca0=0x0;_0xa31ca0<_0x2af4e3['eventRegistrations_']['length'];++_0xa31ca0){const _0x5f0477=_0x2af4e3['eventRegistrations_'][_0xa31ca0];if(!_0x5f0477['matches'](_0x289d57))_0x26bcc5['push'](_0x5f0477);else{if(_0x289d57['hasAnyCallback']()){_0x26bcc5=_0x26bcc5['concat'](_0x2af4e3['eventRegistrations_']['slice'](_0xa31ca0+0x1));break;}}}_0x2af4e3['eventRegistrations_']=_0x26bcc5;}else _0x2af4e3['eventRegistrations_']=[];return _0x2c93f3;}function ur(_0x35582f,_0x330dfd,_0x519176,_0x7aa855){_0x330dfd['type']===q['MERGE']&&_0x330dfd['source']['queryId']!==null&&(f(Ue(_0x35582f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x35582f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1e058d=_0x35582f['viewCache_'],_0x3becea=Tu(_0x35582f['processor_'],_0x1e058d,_0x330dfd,_0x519176,_0x7aa855);return Cu(_0x35582f['processor_'],_0x3becea['viewCache']),f(_0x3becea['viewCache']['serverCache']['isFullyInitialized']()||!_0x1e058d['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x35582f['viewCache_']=_0x3becea['viewCache'],$o(_0x35582f,_0x3becea['changes'],_0x3becea['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x535415,_0x3ba1ee){const _0x309aff=_0x535415['viewCache_']['eventCache'],_0x25ca68=[];return _0x309aff['getNode']()['isLeafNode']()||_0x309aff['getNode']()['forEachChild'](R,(_0x135826,_0x18842b)=>{_0x25ca68['push'](tt(_0x135826,_0x18842b));}),_0x309aff['isFullyInitialized']()&&_0x25ca68['push'](Oo(_0x309aff['getNode']())),$o(_0x535415,_0x25ca68,_0x309aff['getNode'](),_0x3ba1ee);}function $o(_0x5ab8a5,_0x175335,_0x1e0cfe,_0x36bfc2){const _0x36b813=_0x36bfc2?[_0x36bfc2]:_0x5ab8a5['eventRegistrations_'];return nu(_0x5ab8a5['eventGenerator_'],_0x175335,_0x1e0cfe,_0x36b813);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x113334){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x113334;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x18cd10){return _0x18cd10['views']['size']===0x0;}function is(_0x25c2c6,_0x250748,_0x312992,_0x3eefbd){const _0x193cc0=_0x250748['source']['queryId'];if(_0x193cc0!==null){const _0x2b96e8=_0x25c2c6['views']['get'](_0x193cc0);return f(_0x2b96e8!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2b96e8,_0x250748,_0x312992,_0x3eefbd);}else{let _0x13f70c=[];for(const _0x4f45cd of _0x25c2c6['views']['values']())_0x13f70c=_0x13f70c['concat'](ur(_0x4f45cd,_0x250748,_0x312992,_0x3eefbd));return _0x13f70c;}}function qo(_0x5311eb,_0x17bbcc,_0x1edb8d,_0x2a1377,_0x2f0d87){const _0x546566=_0x17bbcc['_queryIdentifier'],_0x1ec36d=_0x5311eb['views']['get'](_0x546566);if(!_0x1ec36d){let _0x1ae8d9=mn(_0x1edb8d,_0x2f0d87?_0x2a1377:null),_0x2966fa=!0x1;_0x1ae8d9?_0x2966fa=!0x0:_0x2a1377 instanceof g?(_0x1ae8d9=es(_0x1edb8d,_0x2a1377),_0x2966fa=!0x1):(_0x1ae8d9=g['EMPTY_NODE'],_0x2966fa=!0x1);const _0x24d9d5=Dn(new Ce(_0x1ae8d9,_0x2966fa,!0x1),new Ce(_0x2a1377,_0x2f0d87,!0x1));return new Nu(_0x17bbcc,_0x24d9d5);}return _0x1ec36d;}function Wu(_0x3a20f3,_0x4c690b,_0x57113f,_0x47331d,_0x4e5f2b,_0x1f42fa){const _0x19ba1a=qo(_0x3a20f3,_0x4c690b,_0x47331d,_0x4e5f2b,_0x1f42fa);return _0x3a20f3['views']['has'](_0x4c690b['_queryIdentifier'])||_0x3a20f3['views']['set'](_0x4c690b['_queryIdentifier'],_0x19ba1a),Mu(_0x19ba1a,_0x57113f),Lu(_0x19ba1a,_0x57113f);}function Bu(_0x1ae7ef,_0x3b676e,_0x23efe3,_0x5351e7){const _0x13c27f=_0x3b676e['_queryIdentifier'],_0x16e0bb=[];let _0x53f9c3=[];const _0x59adcc=Te(_0x1ae7ef);if(_0x13c27f==='default'){for(const [_0x35d69a,_0x5601a0]of _0x1ae7ef['views']['entries']())_0x53f9c3=_0x53f9c3['concat'](hr(_0x5601a0,_0x23efe3,_0x5351e7)),lr(_0x5601a0)&&(_0x1ae7ef['views']['delete'](_0x35d69a),_0x5601a0['query']['_queryParams']['loadsAllData']()||_0x16e0bb['push'](_0x5601a0['query']));}else{const _0x14c505=_0x1ae7ef['views']['get'](_0x13c27f);_0x14c505&&(_0x53f9c3=_0x53f9c3['concat'](hr(_0x14c505,_0x23efe3,_0x5351e7)),lr(_0x14c505)&&(_0x1ae7ef['views']['delete'](_0x13c27f),_0x14c505['query']['_queryParams']['loadsAllData']()||_0x16e0bb['push'](_0x14c505['query'])));}return _0x59adcc&&!Te(_0x1ae7ef)&&_0x16e0bb['push'](new(Fu())(_0x3b676e['_repo'],_0x3b676e['_path'])),{'removed':_0x16e0bb,'events':_0x53f9c3};}function zo(_0x56d480){const _0x40d5d0=[];for(const _0xc47767 of _0x56d480['views']['values']())_0xc47767['query']['_queryParams']['loadsAllData']()||_0x40d5d0['push'](_0xc47767);return _0x40d5d0;}function Ee(_0x3611c1,_0x534666){let _0x336f2b=null;for(const _0xb205e3 of _0x3611c1['views']['values']())_0x336f2b=_0x336f2b||Du(_0xb205e3,_0x534666);return _0x336f2b;}function jo(_0x88fca5,_0x4246f2){if(_0x4246f2['_queryParams']['loadsAllData']())return Ln(_0x88fca5);{const _0x4dfd1b=_0x4246f2['_queryIdentifier'];return _0x88fca5['views']['get'](_0x4dfd1b);}}function Ko(_0x472611,_0x5b1b22){return jo(_0x472611,_0x5b1b22)!=null;}function Te(_0xd73b90){return Ln(_0xd73b90)!=null;}function Ln(_0x44b244){for(const _0x11bcc5 of _0x44b244['views']['values']())if(_0x11bcc5['query']['_queryParams']['loadsAllData']())return _0x11bcc5;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x3133e7){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x3133e7;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x5c06ae){this['listenProvider_']=_0x5c06ae,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x1c9380,_0x4ef94f,_0x14af67,_0x520957,_0x2dd2d7){return ou(_0x1c9380['pendingWriteTree_'],_0x4ef94f,_0x14af67,_0x520957,_0x2dd2d7),_0x2dd2d7?ht(_0x1c9380,new Fe(Ji(),_0x4ef94f,_0x14af67)):[];}function Gu(_0x1bf87c,_0x17b0ce,_0x153470,_0x42ded1){au(_0x1bf87c['pendingWriteTree_'],_0x17b0ce,_0x153470,_0x42ded1);const _0x42c2ab=S['fromObject'](_0x153470);return ht(_0x1bf87c,new nt(Ji(),_0x17b0ce,_0x42c2ab));}function pe(_0x5f1090,_0xa603bf,_0x5b5e2a=!0x1){const _0x3073f3=cu(_0x5f1090['pendingWriteTree_'],_0xa603bf);if(lu(_0x5f1090['pendingWriteTree_'],_0xa603bf)){let _0x40bab7=new S(null);return _0x3073f3['snap']!=null?_0x40bab7=_0x40bab7['set'](w(),!0x0):x(_0x3073f3['children'],_0x2e5c94=>{_0x40bab7=_0x40bab7['set'](new C(_0x2e5c94),!0x0);}),ht(_0x5f1090,new _n(_0x3073f3['path'],_0x40bab7,_0x5b5e2a));}else return[];}function $t(_0x97f161,_0x5ee5b7,_0x2dc174){return ht(_0x97f161,new Fe(Xi(),_0x5ee5b7,_0x2dc174));}function qu(_0x4160bb,_0xcd75fe,_0x46e79e){const _0x1b7639=S['fromObject'](_0x46e79e);return ht(_0x4160bb,new nt(Xi(),_0xcd75fe,_0x1b7639));}function zu(_0x55ad15,_0x20dd42){return ht(_0x55ad15,new Dt(Xi(),_0x20dd42));}function ju(_0x4b2ac0,_0x53f526,_0xd93d7a){const _0x264ffc=rs(_0x4b2ac0,_0xd93d7a);if(_0x264ffc){const _0x3fa657=os(_0x264ffc),_0x1c3d30=_0x3fa657['path'],_0x6ed137=_0x3fa657['queryId'],_0x289546=F(_0x1c3d30,_0x53f526),_0x426598=new Dt(Zi(_0x6ed137),_0x289546);return as(_0x4b2ac0,_0x1c3d30,_0x426598);}else return[];}function wn(_0x1c5a08,_0x103d75,_0xa2ca19,_0x419443,_0x10ba53=!0x1){const _0x36c24c=_0x103d75['_path'],_0x403ce6=_0x1c5a08['syncPointTree_']['get'](_0x36c24c);let _0x540060=[];if(_0x403ce6&&(_0x103d75['_queryIdentifier']==='default'||Ko(_0x403ce6,_0x103d75))){const _0x20cd47=Bu(_0x403ce6,_0x103d75,_0xa2ca19,_0x419443);Uu(_0x403ce6)&&(_0x1c5a08['syncPointTree_']=_0x1c5a08['syncPointTree_']['remove'](_0x36c24c));const _0x32a90c=_0x20cd47['removed'];if(_0x540060=_0x20cd47['events'],!_0x10ba53){const _0x30eade=_0x32a90c['findIndex'](_0x33cb3f=>_0x33cb3f['_queryParams']['loadsAllData']())!==-0x1,_0x4e5c8f=_0x1c5a08['syncPointTree_']['findOnPath'](_0x36c24c,(_0x45866b,_0x2c2cd3)=>Te(_0x2c2cd3));if(_0x30eade&&!_0x4e5c8f){const _0x3ef2ea=_0x1c5a08['syncPointTree_']['subtree'](_0x36c24c);if(!_0x3ef2ea['isEmpty']()){const _0x94a4cf=Qu(_0x3ef2ea);for(let _0x24933e=0x0;_0x24933e<_0x94a4cf['length'];++_0x24933e){const _0x38d9c2=_0x94a4cf[_0x24933e],_0x1d89cc=_0x38d9c2['query'],_0x12af49=Xo(_0x1c5a08,_0x38d9c2);_0x1c5a08['listenProvider_']['startListening'](Tt(_0x1d89cc),Mt(_0x1c5a08,_0x1d89cc),_0x12af49['hashFn'],_0x12af49['onComplete']);}}}!_0x4e5c8f&&_0x32a90c['length']>0x0&&!_0x419443&&(_0x30eade?_0x1c5a08['listenProvider_']['stopListening'](Tt(_0x103d75),null):_0x32a90c['forEach'](_0xb20785=>{const _0x20b3ff=_0x1c5a08['queryToTagMap']['get'](Fn(_0xb20785));_0x1c5a08['listenProvider_']['stopListening'](Tt(_0xb20785),_0x20b3ff);}));}Ju(_0x1c5a08,_0x32a90c);}return _0x540060;}function Yo(_0x3454c7,_0x527449,_0x4d49c3,_0x3c0ea0){const _0x3fad45=rs(_0x3454c7,_0x3c0ea0);if(_0x3fad45!=null){const _0x5b86ac=os(_0x3fad45),_0x1d2b0e=_0x5b86ac['path'],_0x2d4dd1=_0x5b86ac['queryId'],_0x3844f5=F(_0x1d2b0e,_0x527449),_0x19d954=new Fe(Zi(_0x2d4dd1),_0x3844f5,_0x4d49c3);return as(_0x3454c7,_0x1d2b0e,_0x19d954);}else return[];}function Ku(_0x2d689a,_0x50a633,_0x378654,_0x5d24d7){const _0x287677=rs(_0x2d689a,_0x5d24d7);if(_0x287677){const _0x61db94=os(_0x287677),_0x472627=_0x61db94['path'],_0x37b5d2=_0x61db94['queryId'],_0x3d00e9=F(_0x472627,_0x50a633),_0x441342=S['fromObject'](_0x378654),_0x441d9e=new nt(Zi(_0x37b5d2),_0x3d00e9,_0x441342);return as(_0x2d689a,_0x472627,_0x441d9e);}else return[];}function bi(_0x4ec72d,_0xe9b027,_0x26cc30,_0x353529=!0x1){const _0x4400e5=_0xe9b027['_path'];let _0xcaaa76=null,_0x138fa1=!0x1;_0x4ec72d['syncPointTree_']['foreachOnPath'](_0x4400e5,(_0x3562cd,_0x3a9e38)=>{const _0x1641ad=F(_0x3562cd,_0x4400e5);_0xcaaa76=_0xcaaa76||Ee(_0x3a9e38,_0x1641ad),_0x138fa1=_0x138fa1||Te(_0x3a9e38);});let _0x446ccc=_0x4ec72d['syncPointTree_']['get'](_0x4400e5);_0x446ccc?(_0x138fa1=_0x138fa1||Te(_0x446ccc),_0xcaaa76=_0xcaaa76||Ee(_0x446ccc,w())):(_0x446ccc=new Go(),_0x4ec72d['syncPointTree_']=_0x4ec72d['syncPointTree_']['set'](_0x4400e5,_0x446ccc));let _0x4c3bc1;_0xcaaa76!=null?_0x4c3bc1=!0x0:(_0x4c3bc1=!0x1,_0xcaaa76=g['EMPTY_NODE'],_0x4ec72d['syncPointTree_']['subtree'](_0x4400e5)['foreachChild']((_0x2e15a0,_0x7f5b6c)=>{const _0x3938b5=Ee(_0x7f5b6c,w());_0x3938b5&&(_0xcaaa76=_0xcaaa76['updateImmediateChild'](_0x2e15a0,_0x3938b5));}));const _0x4120fc=Ko(_0x446ccc,_0xe9b027);if(!_0x4120fc&&!_0xe9b027['_queryParams']['loadsAllData']()){const _0x57096=Fn(_0xe9b027);f(!_0x4ec72d['queryToTagMap']['has'](_0x57096),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2530e2=Xu();_0x4ec72d['queryToTagMap']['set'](_0x57096,_0x2530e2),_0x4ec72d['tagToQueryMap']['set'](_0x2530e2,_0x57096);}const _0x1de7c8=Mn(_0x4ec72d['pendingWriteTree_'],_0x4400e5);let _0x3c135c=Wu(_0x446ccc,_0xe9b027,_0x26cc30,_0x1de7c8,_0xcaaa76,_0x4c3bc1);if(!_0x4120fc&&!_0x138fa1&&!_0x353529){const _0x3f5dd9=jo(_0x446ccc,_0xe9b027);_0x3c135c=_0x3c135c['concat'](Zu(_0x4ec72d,_0xe9b027,_0x3f5dd9));}return _0x3c135c;}function xn(_0x247c44,_0x52fd69,_0x211072){const _0x22946d=_0x247c44['pendingWriteTree_'],_0x5b256b=_0x247c44['syncPointTree_']['findOnPath'](_0x52fd69,(_0x3d8525,_0xb9aebb)=>{const _0x4b039d=F(_0x3d8525,_0x52fd69),_0xa250e2=Ee(_0xb9aebb,_0x4b039d);if(_0xa250e2)return _0xa250e2;});return Uo(_0x22946d,_0x52fd69,_0x5b256b,_0x211072,!0x0);}function Yu(_0x25adcc,_0xea3d3c){const _0x4de001=_0xea3d3c['_path'];let _0x38815a=null;_0x25adcc['syncPointTree_']['foreachOnPath'](_0x4de001,(_0x5972ec,_0xd9d123)=>{const _0xec9163=F(_0x5972ec,_0x4de001);_0x38815a=_0x38815a||Ee(_0xd9d123,_0xec9163);});let _0xba37a0=_0x25adcc['syncPointTree_']['get'](_0x4de001);_0xba37a0?_0x38815a=_0x38815a||Ee(_0xba37a0,w()):(_0xba37a0=new Go(),_0x25adcc['syncPointTree_']=_0x25adcc['syncPointTree_']['set'](_0x4de001,_0xba37a0));const _0x15dad0=_0x38815a!=null,_0x3274e6=_0x15dad0?new Ce(_0x38815a,!0x0,!0x1):null,_0x598c42=Mn(_0x25adcc['pendingWriteTree_'],_0xea3d3c['_path']),_0x5ae00d=qo(_0xba37a0,_0xea3d3c,_0x598c42,_0x15dad0?_0x3274e6['getNode']():g['EMPTY_NODE'],_0x15dad0);return Ou(_0x5ae00d);}function ht(_0xee7a6d,_0x5afcc0){return Qo(_0x5afcc0,_0xee7a6d['syncPointTree_'],null,Mn(_0xee7a6d['pendingWriteTree_'],w()));}function Qo(_0x4a096a,_0x338ce9,_0x295452,_0xd45b01){if(v(_0x4a096a['path']))return Jo(_0x4a096a,_0x338ce9,_0x295452,_0xd45b01);{const _0x19def6=_0x338ce9['get'](w());_0x295452==null&&_0x19def6!=null&&(_0x295452=Ee(_0x19def6,w()));let _0x30b442=[];const _0x1088eb=y(_0x4a096a['path']),_0x1ba9b9=_0x4a096a['operationForChild'](_0x1088eb),_0x3d5c8a=_0x338ce9['children']['get'](_0x1088eb);if(_0x3d5c8a&&_0x1ba9b9){const _0x3e4a97=_0x295452?_0x295452['getImmediateChild'](_0x1088eb):null,_0x55cee9=Wo(_0xd45b01,_0x1088eb);_0x30b442=_0x30b442['concat'](Qo(_0x1ba9b9,_0x3d5c8a,_0x3e4a97,_0x55cee9));}return _0x19def6&&(_0x30b442=_0x30b442['concat'](is(_0x19def6,_0x4a096a,_0xd45b01,_0x295452))),_0x30b442;}}function Jo(_0x343c32,_0x781c56,_0x181231,_0x9a51ef){const _0x253c53=_0x781c56['get'](w());_0x181231==null&&_0x253c53!=null&&(_0x181231=Ee(_0x253c53,w()));let _0x18e894=[];return _0x781c56['children']['inorderTraversal']((_0x53c12a,_0x206616)=>{const _0x55922d=_0x181231?_0x181231['getImmediateChild'](_0x53c12a):null,_0x3e246f=Wo(_0x9a51ef,_0x53c12a),_0x4d99be=_0x343c32['operationForChild'](_0x53c12a);_0x4d99be&&(_0x18e894=_0x18e894['concat'](Jo(_0x4d99be,_0x206616,_0x55922d,_0x3e246f)));}),_0x253c53&&(_0x18e894=_0x18e894['concat'](is(_0x253c53,_0x343c32,_0x9a51ef,_0x181231))),_0x18e894;}function Xo(_0x4836fc,_0x34803f){const _0x531134=_0x34803f['query'],_0x264891=Mt(_0x4836fc,_0x531134);return{'hashFn':()=>(Pu(_0x34803f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1ad5e2=>{if(_0x1ad5e2==='ok')return _0x264891?ju(_0x4836fc,_0x531134['_path'],_0x264891):zu(_0x4836fc,_0x531134['_path']);{const _0x21b145=ql(_0x1ad5e2,_0x531134);return wn(_0x4836fc,_0x531134,null,_0x21b145);}}};}function Mt(_0x19d9e9,_0x5a6db3){const _0x3dd964=Fn(_0x5a6db3);return _0x19d9e9['queryToTagMap']['get'](_0x3dd964);}function Fn(_0x216b60){return _0x216b60['_path']['toString']()+'$'+_0x216b60['_queryIdentifier'];}function rs(_0xfb4667,_0xe0f2eb){return _0xfb4667['tagToQueryMap']['get'](_0xe0f2eb);}function os(_0x1237e2){const _0x43ba84=_0x1237e2['indexOf']('$');return f(_0x43ba84!==-0x1&&_0x43ba84<_0x1237e2['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1237e2['substr'](_0x43ba84+0x1),'path':new C(_0x1237e2['substr'](0x0,_0x43ba84))};}function as(_0x47aa93,_0x1e26ce,_0xfd22bb){const _0x385de5=_0x47aa93['syncPointTree_']['get'](_0x1e26ce);f(_0x385de5,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x19d82c=Mn(_0x47aa93['pendingWriteTree_'],_0x1e26ce);return is(_0x385de5,_0xfd22bb,_0x19d82c,null);}function Qu(_0x150614){return _0x150614['fold']((_0x16e906,_0x14f931,_0x34c3d1)=>{if(_0x14f931&&Te(_0x14f931))return[Ln(_0x14f931)];{let _0x138e7e=[];return _0x14f931&&(_0x138e7e=zo(_0x14f931)),x(_0x34c3d1,(_0x3138e4,_0x354c00)=>{_0x138e7e=_0x138e7e['concat'](_0x354c00);}),_0x138e7e;}});}function Tt(_0x2f0536){return _0x2f0536['_queryParams']['loadsAllData']()&&!_0x2f0536['_queryParams']['isDefault']()?new(Hu())(_0x2f0536['_repo'],_0x2f0536['_path']):_0x2f0536;}function Ju(_0x51503c,_0x41708b){for(let _0x1ab441=0x0;_0x1ab441<_0x41708b['length'];++_0x1ab441){const _0x40c413=_0x41708b[_0x1ab441];if(!_0x40c413['_queryParams']['loadsAllData']()){const _0x3fc1f9=Fn(_0x40c413),_0x1e0556=_0x51503c['queryToTagMap']['get'](_0x3fc1f9);_0x51503c['queryToTagMap']['delete'](_0x3fc1f9),_0x51503c['tagToQueryMap']['delete'](_0x1e0556);}}}function Xu(){return $u++;}function Zu(_0x12b543,_0x2121a7,_0x3f834d){const _0x22cddc=_0x2121a7['_path'],_0x34b756=Mt(_0x12b543,_0x2121a7),_0xe40baa=Xo(_0x12b543,_0x3f834d),_0x40d93f=_0x12b543['listenProvider_']['startListening'](Tt(_0x2121a7),_0x34b756,_0xe40baa['hashFn'],_0xe40baa['onComplete']),_0x909f79=_0x12b543['syncPointTree_']['subtree'](_0x22cddc);if(_0x34b756)f(!Te(_0x909f79['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4141c3=_0x909f79['fold']((_0x2aa4f5,_0x502bf8,_0x57bed6)=>{if(!v(_0x2aa4f5)&&_0x502bf8&&Te(_0x502bf8))return[Ln(_0x502bf8)['query']];{let _0x34c069=[];return _0x502bf8&&(_0x34c069=_0x34c069['concat'](zo(_0x502bf8)['map'](_0x2861ce=>_0x2861ce['query']))),x(_0x57bed6,(_0x23d4e7,_0x2de822)=>{_0x34c069=_0x34c069['concat'](_0x2de822);}),_0x34c069;}});for(let _0x151e82=0x0;_0x151e82<_0x4141c3['length'];++_0x151e82){const _0x40d5e6=_0x4141c3[_0x151e82];_0x12b543['listenProvider_']['stopListening'](Tt(_0x40d5e6),Mt(_0x12b543,_0x40d5e6));}}return _0x40d93f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x351eda){this['node_']=_0x351eda;}['getImmediateChild'](_0x885d5d){const _0x461f17=this['node_']['getImmediateChild'](_0x885d5d);return new cs(_0x461f17);}['node'](){return this['node_'];}}class ls{constructor(_0x8ce644,_0x462459){this['syncTree_']=_0x8ce644,this['path_']=_0x462459;}['getImmediateChild'](_0xa9baa6){const _0x402c0f=A(this['path_'],_0xa9baa6);return new ls(this['syncTree_'],_0x402c0f);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x4a4f57){return _0x4a4f57=_0x4a4f57||{},_0x4a4f57['timestamp']=_0x4a4f57['timestamp']||new Date()['getTime'](),_0x4a4f57;},fr=function(_0x2cc77e,_0x250778,_0x4c29cb){if(!_0x2cc77e||typeof _0x2cc77e!='object')return _0x2cc77e;if(f('.sv'in _0x2cc77e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x2cc77e['.sv']=='string')return td(_0x2cc77e['.sv'],_0x250778,_0x4c29cb);if(typeof _0x2cc77e['.sv']=='object')return nd(_0x2cc77e['.sv'],_0x250778);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2cc77e,null,0x2));},td=function(_0x41a5e9,_0x717341,_0x8a16ae){switch(_0x41a5e9){case'timestamp':return _0x8a16ae['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x41a5e9);}},nd=function(_0xf687ee,_0x2de2d7,_0x4616af){_0xf687ee['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xf687ee,null,0x2));const _0x5ec4eb=_0xf687ee['increment'];typeof _0x5ec4eb!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5ec4eb);const _0x5d8b7e=_0x2de2d7['node']();if(f(_0x5d8b7e!==null&&typeof _0x5d8b7e<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5d8b7e['isLeafNode']())return _0x5ec4eb;const _0x171059=_0x5d8b7e['getValue']();return typeof _0x171059!='number'?_0x5ec4eb:_0x171059+_0x5ec4eb;},Zo=function(_0x1a8321,_0x5405c6,_0x48b8d5,_0x129d7b){return us(_0x5405c6,new ls(_0x48b8d5,_0x1a8321),_0x129d7b);},hs=function(_0x58016c,_0x264563,_0x26af2c){return us(_0x58016c,new cs(_0x264563),_0x26af2c);};function us(_0x4b53db,_0x43be5d,_0x51c058){const _0x3d8134=_0x4b53db['getPriority']()['val'](),_0x130423=fr(_0x3d8134,_0x43be5d['getImmediateChild']('.priority'),_0x51c058);let _0x1ec894;if(_0x4b53db['isLeafNode']()){const _0x115cdf=_0x4b53db,_0x21e8de=fr(_0x115cdf['getValue'](),_0x43be5d,_0x51c058);return _0x21e8de!==_0x115cdf['getValue']()||_0x130423!==_0x115cdf['getPriority']()['val']()?new D(_0x21e8de,N(_0x130423)):_0x4b53db;}else{const _0x3bf9c7=_0x4b53db;return _0x1ec894=_0x3bf9c7,_0x130423!==_0x3bf9c7['getPriority']()['val']()&&(_0x1ec894=_0x1ec894['updatePriority'](new D(_0x130423))),_0x3bf9c7['forEachChild'](R,(_0x2c4846,_0x160e6f)=>{const _0x46e08e=us(_0x160e6f,_0x43be5d['getImmediateChild'](_0x2c4846),_0x51c058);_0x46e08e!==_0x160e6f&&(_0x1ec894=_0x1ec894['updateImmediateChild'](_0x2c4846,_0x46e08e));}),_0x1ec894;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x306c97='',_0x3fcf74=null,_0x3768ff={'children':{},'childCount':0x0}){this['name']=_0x306c97,this['parent']=_0x3fcf74,this['node']=_0x3768ff;}}function Un(_0x4107c4,_0x460ef3){let _0x160294=_0x460ef3 instanceof C?_0x460ef3:new C(_0x460ef3),_0xb40938=_0x4107c4,_0x3c1791=y(_0x160294);for(;_0x3c1791!==null;){const _0x53a9f7=Oe(_0xb40938['node']['children'],_0x3c1791)||{'children':{},'childCount':0x0};_0xb40938=new ds(_0x3c1791,_0xb40938,_0x53a9f7),_0x160294=b(_0x160294),_0x3c1791=y(_0x160294);}return _0xb40938;}function Ge(_0x3e4080){return _0x3e4080['node']['value'];}function fs(_0x1b687b,_0x1d855d){_0x1b687b['node']['value']=_0x1d855d,Ri(_0x1b687b);}function ea(_0x28f9e3){return _0x28f9e3['node']['childCount']>0x0;}function id(_0x44d095){return Ge(_0x44d095)===void 0x0&&!ea(_0x44d095);}function Wn(_0x3d590a,_0x4fb33b){x(_0x3d590a['node']['children'],(_0x501904,_0x5dd7eb)=>{_0x4fb33b(new ds(_0x501904,_0x3d590a,_0x5dd7eb));});}function ta(_0x5199e1,_0x3f8534,_0x1725ed,_0x46852e){_0x1725ed&&_0x3f8534(_0x5199e1),Wn(_0x5199e1,_0x844c28=>{ta(_0x844c28,_0x3f8534,!0x0);});}function sd(_0x1a8730,_0x359bc4,_0xfa72ff){let _0x3df89e=_0x1a8730['parent'];for(;_0x3df89e!==null;){if(_0x359bc4(_0x3df89e))return!0x0;_0x3df89e=_0x3df89e['parent'];}return!0x1;}function Gt(_0x46380d){return new C(_0x46380d['parent']===null?_0x46380d['name']:Gt(_0x46380d['parent'])+'/'+_0x46380d['name']);}function Ri(_0x10a4df){_0x10a4df['parent']!==null&&rd(_0x10a4df['parent'],_0x10a4df['name'],_0x10a4df);}function rd(_0x389531,_0x1712db,_0x6e480f){const _0x4f9d4f=id(_0x6e480f),_0x41a694=Y(_0x389531['node']['children'],_0x1712db);_0x4f9d4f&&_0x41a694?(delete _0x389531['node']['children'][_0x1712db],_0x389531['node']['childCount']--,Ri(_0x389531)):!_0x4f9d4f&&!_0x41a694&&(_0x389531['node']['children'][_0x1712db]=_0x6e480f['node'],_0x389531['node']['childCount']++,Ri(_0x389531));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x3927f0){return typeof _0x3927f0=='string'&&_0x3927f0['length']!==0x0&&!od['test'](_0x3927f0);},na=function(_0x4edd1c){return typeof _0x4edd1c=='string'&&_0x4edd1c['length']!==0x0&&!ad['test'](_0x4edd1c);},cd=function(_0x18ce36){return _0x18ce36&&(_0x18ce36=_0x18ce36['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x18ce36);},Cn=function(_0x477c33){return _0x477c33===null||typeof _0x477c33=='string'||typeof _0x477c33=='number'&&!Wi(_0x477c33)||_0x477c33&&typeof _0x477c33=='object'&&Y(_0x477c33,'.sv');},qt=function(_0x291959,_0x2b0840,_0x20cb54,_0xef44fd){_0xef44fd&&_0x2b0840===void 0x0||zt(Nn(_0x291959,'value'),_0x2b0840,_0x20cb54);},zt=function(_0x51569f,_0x3c02b9,_0x242f08){const _0x4f2934=_0x242f08 instanceof C?new Sh(_0x242f08,_0x51569f):_0x242f08;if(_0x3c02b9===void 0x0)throw new Error(_0x51569f+'contains\x20undefined\x20'+Ne(_0x4f2934));if(typeof _0x3c02b9=='function')throw new Error(_0x51569f+'contains\x20a\x20function\x20'+Ne(_0x4f2934)+'\x20with\x20contents\x20=\x20'+_0x3c02b9['toString']());if(Wi(_0x3c02b9))throw new Error(_0x51569f+'contains\x20'+_0x3c02b9['toString']()+'\x20'+Ne(_0x4f2934));if(typeof _0x3c02b9=='string'&&_0x3c02b9['length']>oi/0x3&&Pn(_0x3c02b9)>oi)throw new Error(_0x51569f+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x4f2934)+'\x20(\x27'+_0x3c02b9['substring'](0x0,0x32)+'...\x27)');if(_0x3c02b9&&typeof _0x3c02b9=='object'){let _0x24e4ff=!0x1,_0x1970b6=!0x1;if(x(_0x3c02b9,(_0x24cd5b,_0xf2c62c)=>{if(_0x24cd5b==='.value')_0x24e4ff=!0x0;else{if(_0x24cd5b!=='.priority'&&_0x24cd5b!=='.sv'&&(_0x1970b6=!0x0,!ps(_0x24cd5b)))throw new Error(_0x51569f+'\x20contains\x20an\x20invalid\x20key\x20('+_0x24cd5b+')\x20'+Ne(_0x4f2934)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x4f2934,_0x24cd5b),zt(_0x51569f,_0xf2c62c,_0x4f2934),Rh(_0x4f2934);}),_0x24e4ff&&_0x1970b6)throw new Error(_0x51569f+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x4f2934)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x1ca594,_0x2f3192){let _0x25f018,_0x5d7738;for(_0x25f018=0x0;_0x25f018<_0x2f3192['length'];_0x25f018++){_0x5d7738=_0x2f3192[_0x25f018];const _0x48032c=kt(_0x5d7738);for(let _0x5b9bdc=0x0;_0x5b9bdc<_0x48032c['length'];_0x5b9bdc++)if(!(_0x48032c[_0x5b9bdc]==='.priority'&&_0x5b9bdc===_0x48032c['length']-0x1)){if(!ps(_0x48032c[_0x5b9bdc]))throw new Error(_0x1ca594+'contains\x20an\x20invalid\x20key\x20('+_0x48032c[_0x5b9bdc]+')\x20in\x20path\x20'+_0x5d7738['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2f3192['sort'](Th);let _0x3ac693=null;for(_0x25f018=0x0;_0x25f018<_0x2f3192['length'];_0x25f018++){if(_0x5d7738=_0x2f3192[_0x25f018],_0x3ac693!==null&&$(_0x3ac693,_0x5d7738))throw new Error(_0x1ca594+'contains\x20a\x20path\x20'+_0x3ac693['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5d7738['toString']());_0x3ac693=_0x5d7738;}},hd=function(_0x19896f,_0x4ea73f,_0x51fd62,_0x495d64){const _0x3dbae7=Nn(_0x19896f,'values');if(!(_0x4ea73f&&typeof _0x4ea73f=='object')||Array['isArray'](_0x4ea73f))throw new Error(_0x3dbae7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x367fdd=[];x(_0x4ea73f,(_0x49e47b,_0x3fce66)=>{const _0x5bfede=new C(_0x49e47b);if(zt(_0x3dbae7,_0x3fce66,A(_0x51fd62,_0x5bfede)),Gi(_0x5bfede)==='.priority'&&!Cn(_0x3fce66))throw new Error(_0x3dbae7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5bfede['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x367fdd['push'](_0x5bfede);}),ld(_0x3dbae7,_0x367fdd);},_s=function(_0x56514d,_0x46329b,_0x3d0820,_0x307ac4){if(!na(_0x3d0820))throw new Error(Nn(_0x56514d,_0x46329b)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x3d0820+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5609f9,_0x3b22ad,_0x5e8eeb,_0x1c011a){_0x5e8eeb&&(_0x5e8eeb=_0x5e8eeb['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5609f9,_0x3b22ad,_0x5e8eeb);},gs=function(_0x429880,_0xa34636){if(y(_0xa34636)==='.info')throw new Error(_0x429880+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x9d01e0,_0x1b292f){const _0x405f79=_0x1b292f['path']['toString']();if(typeof _0x1b292f['repoInfo']['host']!='string'||_0x1b292f['repoInfo']['host']['length']===0x0||!ps(_0x1b292f['repoInfo']['namespace'])&&_0x1b292f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x405f79['length']!==0x0&&!cd(_0x405f79))throw new Error(Nn(_0x9d01e0,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x3a1210,_0x333d0a){let _0x16ada7=null;for(let _0xb748e1=0x0;_0xb748e1<_0x333d0a['length'];_0xb748e1++){const _0x40cf18=_0x333d0a[_0xb748e1],_0x1b5cbd=_0x40cf18['getPath']();_0x16ada7!==null&&!qi(_0x1b5cbd,_0x16ada7['path'])&&(_0x3a1210['eventLists_']['push'](_0x16ada7),_0x16ada7=null),_0x16ada7===null&&(_0x16ada7={'events':[],'path':_0x1b5cbd}),_0x16ada7['events']['push'](_0x40cf18);}_0x16ada7&&_0x3a1210['eventLists_']['push'](_0x16ada7);}function ia(_0x4c02ca,_0x447eaa,_0x4b6bdc){Bn(_0x4c02ca,_0x4b6bdc),sa(_0x4c02ca,_0x263028=>qi(_0x263028,_0x447eaa));}function V(_0x27ee60,_0x4f6f3f,_0x1fe2c4){Bn(_0x27ee60,_0x1fe2c4),sa(_0x27ee60,_0x54c665=>$(_0x54c665,_0x4f6f3f)||$(_0x4f6f3f,_0x54c665));}function sa(_0x364037,_0x1d3ec7){_0x364037['recursionDepth_']++;let _0x3b0beb=!0x0;for(let _0xc82e8e=0x0;_0xc82e8e<_0x364037['eventLists_']['length'];_0xc82e8e++){const _0xc5a5b0=_0x364037['eventLists_'][_0xc82e8e];if(_0xc5a5b0){const _0x5ab2ed=_0xc5a5b0['path'];_0x1d3ec7(_0x5ab2ed)?(pd(_0x364037['eventLists_'][_0xc82e8e]),_0x364037['eventLists_'][_0xc82e8e]=null):_0x3b0beb=!0x1;}}_0x3b0beb&&(_0x364037['eventLists_']=[]),_0x364037['recursionDepth_']--;}function pd(_0x266015){for(let _0x514855=0x0;_0x514855<_0x266015['events']['length'];_0x514855++){const _0x1eeadb=_0x266015['events'][_0x514855];if(_0x1eeadb!==null){_0x266015['events'][_0x514855]=null;const _0x1ca2b4=_0x1eeadb['getEventRunner']();Et&&L('event:\x20'+_0x1eeadb['toString']()),lt(_0x1ca2b4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x7e912c,_0x147f8e,_0x10a45a,_0x2ad77c){this['repoInfo_']=_0x7e912c,this['forceRestClient_']=_0x147f8e,this['authTokenProvider_']=_0x10a45a,this['appCheckProvider_']=_0x2ad77c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x47fd99,_0x226f6c,_0x11e224){if(_0x47fd99['stats_']=Hi(_0x47fd99['repoInfo_']),_0x47fd99['forceRestClient_']||Yl())_0x47fd99['server_']=new fn(_0x47fd99['repoInfo_'],(_0x412257,_0x3ae4ba,_0x5afb99,_0x33c3e9)=>{pr(_0x47fd99,_0x412257,_0x3ae4ba,_0x5afb99,_0x33c3e9);},_0x47fd99['authTokenProvider_'],_0x47fd99['appCheckProvider_']),setTimeout(()=>_r(_0x47fd99,!0x0),0x0);else{if(typeof _0x11e224<'u'&&_0x11e224!==null){if(typeof _0x11e224!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x11e224);}catch(_0x852494){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x852494);}}_0x47fd99['persistentConnection_']=new ie(_0x47fd99['repoInfo_'],_0x226f6c,(_0x20d554,_0xd8aa9b,_0x154823,_0x378f39)=>{pr(_0x47fd99,_0x20d554,_0xd8aa9b,_0x154823,_0x378f39);},_0x1a480f=>{_r(_0x47fd99,_0x1a480f);},_0x24755c=>{yd(_0x47fd99,_0x24755c);},_0x47fd99['authTokenProvider_'],_0x47fd99['appCheckProvider_'],_0x11e224),_0x47fd99['server_']=_0x47fd99['persistentConnection_'];}_0x47fd99['authTokenProvider_']['addTokenChangeListener'](_0x4d0f14=>{_0x47fd99['server_']['refreshAuthToken'](_0x4d0f14);}),_0x47fd99['appCheckProvider_']['addTokenChangeListener'](_0x537d49=>{_0x47fd99['server_']['refreshAppCheckToken'](_0x537d49['token']);}),_0x47fd99['statsReporter_']=eh(_0x47fd99['repoInfo_'],()=>new eu(_0x47fd99['stats_'],_0x47fd99['server_'])),_0x47fd99['infoData_']=new Yh(),_0x47fd99['infoSyncTree_']=new dr({'startListening':(_0x2e53b2,_0x289c31,_0x34a395,_0x191941)=>{let _0x1111f8=[];const _0x4d42d1=_0x47fd99['infoData_']['getNode'](_0x2e53b2['_path']);return _0x4d42d1['isEmpty']()||(_0x1111f8=$t(_0x47fd99['infoSyncTree_'],_0x2e53b2['_path'],_0x4d42d1),setTimeout(()=>{_0x191941('ok');},0x0)),_0x1111f8;},'stopListening':()=>{}}),ms(_0x47fd99,'connected',!0x1),_0x47fd99['serverSyncTree_']=new dr({'startListening':(_0x3d8cad,_0x1ec895,_0x5120f0,_0x99f89b)=>(_0x47fd99['server_']['listen'](_0x3d8cad,_0x5120f0,_0x1ec895,(_0x338790,_0x9fda0c)=>{const _0x5251ed=_0x99f89b(_0x338790,_0x9fda0c);V(_0x47fd99['eventQueue_'],_0x3d8cad['_path'],_0x5251ed);}),[]),'stopListening':(_0x3efc56,_0x45e2e6)=>{_0x47fd99['server_']['unlisten'](_0x3efc56,_0x45e2e6);}});}function oa(_0x55c46f){const _0x21cf9b=_0x55c46f['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x21cf9b;}function jt(_0xb3672d){return ed({'timestamp':oa(_0xb3672d)});}function pr(_0x2d51bb,_0x66f29f,_0x16b3fa,_0x295787,_0x7f8ac7){_0x2d51bb['dataUpdateCount']++;const _0x54a371=new C(_0x66f29f);_0x16b3fa=_0x2d51bb['interceptServerDataCallback_']?_0x2d51bb['interceptServerDataCallback_'](_0x66f29f,_0x16b3fa):_0x16b3fa;let _0x532201=[];if(_0x7f8ac7){if(_0x295787){const _0x415158=ln(_0x16b3fa,_0x3e8286=>N(_0x3e8286));_0x532201=Ku(_0x2d51bb['serverSyncTree_'],_0x54a371,_0x415158,_0x7f8ac7);}else{const _0x1ef178=N(_0x16b3fa);_0x532201=Yo(_0x2d51bb['serverSyncTree_'],_0x54a371,_0x1ef178,_0x7f8ac7);}}else{if(_0x295787){const _0x404bda=ln(_0x16b3fa,_0x3c38fe=>N(_0x3c38fe));_0x532201=qu(_0x2d51bb['serverSyncTree_'],_0x54a371,_0x404bda);}else{const _0x528168=N(_0x16b3fa);_0x532201=$t(_0x2d51bb['serverSyncTree_'],_0x54a371,_0x528168);}}let _0x30ff2a=_0x54a371;_0x532201['length']>0x0&&(_0x30ff2a=st(_0x2d51bb,_0x54a371)),V(_0x2d51bb['eventQueue_'],_0x30ff2a,_0x532201);}function _r(_0xdb9bb0,_0x37d74f){ms(_0xdb9bb0,'connected',_0x37d74f),_0x37d74f===!0x1&&wd(_0xdb9bb0);}function yd(_0x4f2a16,_0x266852){x(_0x266852,(_0x1b0a28,_0x5abb48)=>{ms(_0x4f2a16,_0x1b0a28,_0x5abb48);});}function ms(_0x409af4,_0x3ae328,_0x3e6b51){const _0x4765a3=new C('/.info/'+_0x3ae328),_0x22d709=N(_0x3e6b51);_0x409af4['infoData_']['updateSnapshot'](_0x4765a3,_0x22d709);const _0x23eb1c=$t(_0x409af4['infoSyncTree_'],_0x4765a3,_0x22d709);V(_0x409af4['eventQueue_'],_0x4765a3,_0x23eb1c);}function Vn(_0x2711fe){return _0x2711fe['nextWriteId_']++;}function vd(_0xbcea36,_0x4b3028,_0xb94dec){const _0x23d6b8=Yu(_0xbcea36['serverSyncTree_'],_0x4b3028);return _0x23d6b8!=null?Promise['resolve'](_0x23d6b8):_0xbcea36['server_']['get'](_0x4b3028)['then'](_0x3e5805=>{const _0x560244=N(_0x3e5805)['withIndex'](_0x4b3028['_queryParams']['getIndex']());bi(_0xbcea36['serverSyncTree_'],_0x4b3028,_0xb94dec,!0x0);let _0x1da700;if(_0x4b3028['_queryParams']['loadsAllData']())_0x1da700=$t(_0xbcea36['serverSyncTree_'],_0x4b3028['_path'],_0x560244);else{const _0x1bfd81=Mt(_0xbcea36['serverSyncTree_'],_0x4b3028);_0x1da700=Yo(_0xbcea36['serverSyncTree_'],_0x4b3028['_path'],_0x560244,_0x1bfd81);}return V(_0xbcea36['eventQueue_'],_0x4b3028['_path'],_0x1da700),wn(_0xbcea36['serverSyncTree_'],_0x4b3028,_0xb94dec,null,!0x0),_0x560244;},_0x3c6627=>(ut(_0xbcea36,'get\x20for\x20query\x20'+O(_0x4b3028)+'\x20failed:\x20'+_0x3c6627),Promise['reject'](new Error(_0x3c6627))));}function Ed(_0x565da6,_0x3137dd,_0x288a71,_0x511ac9,_0x295ba5){ut(_0x565da6,'set',{'path':_0x3137dd['toString'](),'value':_0x288a71,'priority':_0x511ac9});const _0x91358e=jt(_0x565da6),_0x395d38=N(_0x288a71,_0x511ac9),_0x11ef14=xn(_0x565da6['serverSyncTree_'],_0x3137dd),_0x2b8e17=hs(_0x395d38,_0x11ef14,_0x91358e),_0x1f098d=Vn(_0x565da6),_0x3d2694=ss(_0x565da6['serverSyncTree_'],_0x3137dd,_0x2b8e17,_0x1f098d,!0x0);Bn(_0x565da6['eventQueue_'],_0x3d2694),_0x565da6['server_']['put'](_0x3137dd['toString'](),_0x395d38['val'](!0x0),(_0x305aee,_0x4997b0)=>{const _0x519719=_0x305aee==='ok';_0x519719||U('set\x20at\x20'+_0x3137dd+'\x20failed:\x20'+_0x305aee);const _0x2fe5c3=pe(_0x565da6['serverSyncTree_'],_0x1f098d,!_0x519719);V(_0x565da6['eventQueue_'],_0x3137dd,_0x2fe5c3),Ai(_0x565da6,_0x295ba5,_0x305aee,_0x4997b0);});const _0x486b4e=vs(_0x565da6,_0x3137dd);st(_0x565da6,_0x486b4e),V(_0x565da6['eventQueue_'],_0x486b4e,[]);}function Id(_0x30fc1d,_0x4347aa,_0x5deda9,_0x72ca4){ut(_0x30fc1d,'update',{'path':_0x4347aa['toString'](),'value':_0x5deda9});let _0x50f882=!0x0;const _0x3638a5=jt(_0x30fc1d),_0x45990c={};if(x(_0x5deda9,(_0x28671a,_0x22b2db)=>{_0x50f882=!0x1,_0x45990c[_0x28671a]=Zo(A(_0x4347aa,_0x28671a),N(_0x22b2db),_0x30fc1d['serverSyncTree_'],_0x3638a5);}),_0x50f882)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x30fc1d,_0x72ca4,'ok',void 0x0);else{const _0x3f4fb7=Vn(_0x30fc1d),_0x248789=Gu(_0x30fc1d['serverSyncTree_'],_0x4347aa,_0x45990c,_0x3f4fb7);Bn(_0x30fc1d['eventQueue_'],_0x248789),_0x30fc1d['server_']['merge'](_0x4347aa['toString'](),_0x5deda9,(_0x54f1ad,_0x206959)=>{const _0xc9fb2c=_0x54f1ad==='ok';_0xc9fb2c||U('update\x20at\x20'+_0x4347aa+'\x20failed:\x20'+_0x54f1ad);const _0x424b01=pe(_0x30fc1d['serverSyncTree_'],_0x3f4fb7,!_0xc9fb2c),_0x9b85a6=_0x424b01['length']>0x0?st(_0x30fc1d,_0x4347aa):_0x4347aa;V(_0x30fc1d['eventQueue_'],_0x9b85a6,_0x424b01),Ai(_0x30fc1d,_0x72ca4,_0x54f1ad,_0x206959);}),x(_0x5deda9,_0x35b62a=>{const _0x1db10a=vs(_0x30fc1d,A(_0x4347aa,_0x35b62a));st(_0x30fc1d,_0x1db10a);}),V(_0x30fc1d['eventQueue_'],_0x4347aa,[]);}}function wd(_0x541a7c){ut(_0x541a7c,'onDisconnectEvents');const _0x37faa4=jt(_0x541a7c),_0xabd037=pn();Ei(_0x541a7c['onDisconnect_'],w(),(_0x5e1b42,_0x52d7b9)=>{const _0x43fcf7=Zo(_0x5e1b42,_0x52d7b9,_0x541a7c['serverSyncTree_'],_0x37faa4);Mo(_0xabd037,_0x5e1b42,_0x43fcf7);});let _0x46b15e=[];Ei(_0xabd037,w(),(_0x1d5431,_0x34ccc0)=>{_0x46b15e=_0x46b15e['concat']($t(_0x541a7c['serverSyncTree_'],_0x1d5431,_0x34ccc0));const _0x46d648=vs(_0x541a7c,_0x1d5431);st(_0x541a7c,_0x46d648);}),_0x541a7c['onDisconnect_']=pn(),V(_0x541a7c['eventQueue_'],w(),_0x46b15e);}function Cd(_0x5dfd32,_0x49857a,_0x4a55fc){let _0x440f5c;y(_0x49857a['_path'])==='.info'?_0x440f5c=bi(_0x5dfd32['infoSyncTree_'],_0x49857a,_0x4a55fc):_0x440f5c=bi(_0x5dfd32['serverSyncTree_'],_0x49857a,_0x4a55fc),ia(_0x5dfd32['eventQueue_'],_0x49857a['_path'],_0x440f5c);}function Td(_0xfe89f4,_0x54626f,_0x477422){let _0x2ed6e4;y(_0x54626f['_path'])==='.info'?_0x2ed6e4=wn(_0xfe89f4['infoSyncTree_'],_0x54626f,_0x477422):_0x2ed6e4=wn(_0xfe89f4['serverSyncTree_'],_0x54626f,_0x477422),ia(_0xfe89f4['eventQueue_'],_0x54626f['_path'],_0x2ed6e4);}function aa(_0x26ff04){_0x26ff04['persistentConnection_']&&_0x26ff04['persistentConnection_']['interrupt'](ra);}function Sd(_0xde9e6b){_0xde9e6b['persistentConnection_']&&_0xde9e6b['persistentConnection_']['resume'](ra);}function ut(_0x1b1d1e,..._0x1cfe44){let _0x5d4000='';_0x1b1d1e['persistentConnection_']&&(_0x5d4000=_0x1b1d1e['persistentConnection_']['id']+':'),L(_0x5d4000,..._0x1cfe44);}function Ai(_0x23c3e4,_0x177a1c,_0x3aac21,_0x4dcdf6){_0x177a1c&&lt(()=>{if(_0x3aac21==='ok')_0x177a1c(null);else{const _0x3da827=(_0x3aac21||'error')['toUpperCase']();let _0x381d30=_0x3da827;_0x4dcdf6&&(_0x381d30+=':\x20'+_0x4dcdf6);const _0x458f48=new Error(_0x381d30);_0x458f48['code']=_0x3da827,_0x177a1c(_0x458f48);}});}function bd(_0x1a482b,_0x309c84,_0x41ef25,_0x5e65de,_0x33131a,_0x59885f){ut(_0x1a482b,'transaction\x20on\x20'+_0x309c84);const _0x55a7f7={'path':_0x309c84,'update':_0x41ef25,'onComplete':_0x5e65de,'status':null,'order':to(),'applyLocally':_0x59885f,'retryCount':0x0,'unwatcher':_0x33131a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3e3978=ys(_0x1a482b,_0x309c84,void 0x0);_0x55a7f7['currentInputSnapshot']=_0x3e3978;const _0x42045d=_0x55a7f7['update'](_0x3e3978['val']());if(_0x42045d===void 0x0)_0x55a7f7['unwatcher'](),_0x55a7f7['currentOutputSnapshotRaw']=null,_0x55a7f7['currentOutputSnapshotResolved']=null,_0x55a7f7['onComplete']&&_0x55a7f7['onComplete'](null,!0x1,_0x55a7f7['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x42045d,_0x55a7f7['path']),_0x55a7f7['status']=0x0;const _0x26ac9b=Un(_0x1a482b['transactionQueueTree_'],_0x309c84),_0x5a75b6=Ge(_0x26ac9b)||[];_0x5a75b6['push'](_0x55a7f7),fs(_0x26ac9b,_0x5a75b6);let _0x424c2d;typeof _0x42045d=='object'&&_0x42045d!==null&&Y(_0x42045d,'.priority')?(_0x424c2d=Oe(_0x42045d,'.priority'),f(Cn(_0x424c2d),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x424c2d=(xn(_0x1a482b['serverSyncTree_'],_0x309c84)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2d4037=jt(_0x1a482b),_0x4f8783=N(_0x42045d,_0x424c2d),_0x14ab1e=hs(_0x4f8783,_0x3e3978,_0x2d4037);_0x55a7f7['currentOutputSnapshotRaw']=_0x4f8783,_0x55a7f7['currentOutputSnapshotResolved']=_0x14ab1e,_0x55a7f7['currentWriteId']=Vn(_0x1a482b);const _0x117cd1=ss(_0x1a482b['serverSyncTree_'],_0x309c84,_0x14ab1e,_0x55a7f7['currentWriteId'],_0x55a7f7['applyLocally']);V(_0x1a482b['eventQueue_'],_0x309c84,_0x117cd1),Hn(_0x1a482b,_0x1a482b['transactionQueueTree_']);}}function ys(_0xf41a62,_0x3cd7a3,_0x232636){return xn(_0xf41a62['serverSyncTree_'],_0x3cd7a3,_0x232636)||g['EMPTY_NODE'];}function Hn(_0x5eaf6a,_0x731ccf=_0x5eaf6a['transactionQueueTree_']){if(_0x731ccf||$n(_0x5eaf6a,_0x731ccf),Ge(_0x731ccf)){const _0x16d2e7=la(_0x5eaf6a,_0x731ccf);f(_0x16d2e7['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x16d2e7['every'](_0x3469f4=>_0x3469f4['status']===0x0)&&Rd(_0x5eaf6a,Gt(_0x731ccf),_0x16d2e7);}else ea(_0x731ccf)&&Wn(_0x731ccf,_0x57d6de=>{Hn(_0x5eaf6a,_0x57d6de);});}function Rd(_0x2cf7c5,_0x2e60b1,_0x5ecd6a){const _0x3a8651=_0x5ecd6a['map'](_0x51c72c=>_0x51c72c['currentWriteId']),_0x5b699c=ys(_0x2cf7c5,_0x2e60b1,_0x3a8651);let _0x374f04=_0x5b699c;const _0x4bd3e=_0x5b699c['hash']();for(let _0x4a5830=0x0;_0x4a5830<_0x5ecd6a['length'];_0x4a5830++){const _0x45ecf1=_0x5ecd6a[_0x4a5830];f(_0x45ecf1['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x45ecf1['status']=0x1,_0x45ecf1['retryCount']++;const _0x4cec65=F(_0x2e60b1,_0x45ecf1['path']);_0x374f04=_0x374f04['updateChild'](_0x4cec65,_0x45ecf1['currentOutputSnapshotRaw']);}const _0x3b7e83=_0x374f04['val'](!0x0),_0x34db75=_0x2e60b1;_0x2cf7c5['server_']['put'](_0x34db75['toString'](),_0x3b7e83,_0x59eb84=>{ut(_0x2cf7c5,'transaction\x20put\x20response',{'path':_0x34db75['toString'](),'status':_0x59eb84});let _0x12216e=[];if(_0x59eb84==='ok'){const _0xcc686d=[];for(let _0x6b11d4=0x0;_0x6b11d4<_0x5ecd6a['length'];_0x6b11d4++)_0x5ecd6a[_0x6b11d4]['status']=0x2,_0x12216e=_0x12216e['concat'](pe(_0x2cf7c5['serverSyncTree_'],_0x5ecd6a[_0x6b11d4]['currentWriteId'])),_0x5ecd6a[_0x6b11d4]['onComplete']&&_0xcc686d['push'](()=>_0x5ecd6a[_0x6b11d4]['onComplete'](null,!0x0,_0x5ecd6a[_0x6b11d4]['currentOutputSnapshotResolved'])),_0x5ecd6a[_0x6b11d4]['unwatcher']();$n(_0x2cf7c5,Un(_0x2cf7c5['transactionQueueTree_'],_0x2e60b1)),Hn(_0x2cf7c5,_0x2cf7c5['transactionQueueTree_']),V(_0x2cf7c5['eventQueue_'],_0x2e60b1,_0x12216e);for(let _0x4270be=0x0;_0x4270be<_0xcc686d['length'];_0x4270be++)lt(_0xcc686d[_0x4270be]);}else{if(_0x59eb84==='datastale'){for(let _0x42cd59=0x0;_0x42cd59<_0x5ecd6a['length'];_0x42cd59++)_0x5ecd6a[_0x42cd59]['status']===0x3?_0x5ecd6a[_0x42cd59]['status']=0x4:_0x5ecd6a[_0x42cd59]['status']=0x0;}else{U('transaction\x20at\x20'+_0x34db75['toString']()+'\x20failed:\x20'+_0x59eb84);for(let _0x358fa1=0x0;_0x358fa1<_0x5ecd6a['length'];_0x358fa1++)_0x5ecd6a[_0x358fa1]['status']=0x4,_0x5ecd6a[_0x358fa1]['abortReason']=_0x59eb84;}st(_0x2cf7c5,_0x2e60b1);}},_0x4bd3e);}function st(_0x889de0,_0x48aaa3){const _0x52cb09=ca(_0x889de0,_0x48aaa3),_0x3893cd=Gt(_0x52cb09),_0x3c1ce2=la(_0x889de0,_0x52cb09);return Ad(_0x889de0,_0x3c1ce2,_0x3893cd),_0x3893cd;}function Ad(_0x57d306,_0xfb280f,_0x3d78f5){if(_0xfb280f['length']===0x0)return;const _0x3a1fff=[];let _0xd43f6=[];const _0x310da1=_0xfb280f['filter'](_0x81fcb6=>_0x81fcb6['status']===0x0)['map'](_0x5b73c3=>_0x5b73c3['currentWriteId']);for(let _0x4d191a=0x0;_0x4d191a<_0xfb280f['length'];_0x4d191a++){const _0x43916b=_0xfb280f[_0x4d191a],_0x30eea4=F(_0x3d78f5,_0x43916b['path']);let _0x4cdded=!0x1,_0x511e60;if(f(_0x30eea4!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x43916b['status']===0x4)_0x4cdded=!0x0,_0x511e60=_0x43916b['abortReason'],_0xd43f6=_0xd43f6['concat'](pe(_0x57d306['serverSyncTree_'],_0x43916b['currentWriteId'],!0x0));else{if(_0x43916b['status']===0x0){if(_0x43916b['retryCount']>=_d)_0x4cdded=!0x0,_0x511e60='maxretry',_0xd43f6=_0xd43f6['concat'](pe(_0x57d306['serverSyncTree_'],_0x43916b['currentWriteId'],!0x0));else{const _0x4142c1=ys(_0x57d306,_0x43916b['path'],_0x310da1);_0x43916b['currentInputSnapshot']=_0x4142c1;const _0x22eeeb=_0xfb280f[_0x4d191a]['update'](_0x4142c1['val']());if(_0x22eeeb!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x22eeeb,_0x43916b['path']);let _0x525267=N(_0x22eeeb);typeof _0x22eeeb=='object'&&_0x22eeeb!=null&&Y(_0x22eeeb,'.priority')||(_0x525267=_0x525267['updatePriority'](_0x4142c1['getPriority']()));const _0x3880b2=_0x43916b['currentWriteId'],_0x363ff7=jt(_0x57d306),_0x72d9dd=hs(_0x525267,_0x4142c1,_0x363ff7);_0x43916b['currentOutputSnapshotRaw']=_0x525267,_0x43916b['currentOutputSnapshotResolved']=_0x72d9dd,_0x43916b['currentWriteId']=Vn(_0x57d306),_0x310da1['splice'](_0x310da1['indexOf'](_0x3880b2),0x1),_0xd43f6=_0xd43f6['concat'](ss(_0x57d306['serverSyncTree_'],_0x43916b['path'],_0x72d9dd,_0x43916b['currentWriteId'],_0x43916b['applyLocally'])),_0xd43f6=_0xd43f6['concat'](pe(_0x57d306['serverSyncTree_'],_0x3880b2,!0x0));}else _0x4cdded=!0x0,_0x511e60='nodata',_0xd43f6=_0xd43f6['concat'](pe(_0x57d306['serverSyncTree_'],_0x43916b['currentWriteId'],!0x0));}}}V(_0x57d306['eventQueue_'],_0x3d78f5,_0xd43f6),_0xd43f6=[],_0x4cdded&&(_0xfb280f[_0x4d191a]['status']=0x2,function(_0x427173){setTimeout(_0x427173,Math['floor'](0x0));}(_0xfb280f[_0x4d191a]['unwatcher']),_0xfb280f[_0x4d191a]['onComplete']&&(_0x511e60==='nodata'?_0x3a1fff['push'](()=>_0xfb280f[_0x4d191a]['onComplete'](null,!0x1,_0xfb280f[_0x4d191a]['currentInputSnapshot'])):_0x3a1fff['push'](()=>_0xfb280f[_0x4d191a]['onComplete'](new Error(_0x511e60),!0x1,null))));}$n(_0x57d306,_0x57d306['transactionQueueTree_']);for(let _0x385a1c=0x0;_0x385a1c<_0x3a1fff['length'];_0x385a1c++)lt(_0x3a1fff[_0x385a1c]);Hn(_0x57d306,_0x57d306['transactionQueueTree_']);}function ca(_0x5263c9,_0x120211){let _0x309509,_0x593624=_0x5263c9['transactionQueueTree_'];for(_0x309509=y(_0x120211);_0x309509!==null&&Ge(_0x593624)===void 0x0;)_0x593624=Un(_0x593624,_0x309509),_0x120211=b(_0x120211),_0x309509=y(_0x120211);return _0x593624;}function la(_0x1c50bc,_0x23f5e0){const _0xf86f26=[];return ha(_0x1c50bc,_0x23f5e0,_0xf86f26),_0xf86f26['sort']((_0x476f51,_0x37d522)=>_0x476f51['order']-_0x37d522['order']),_0xf86f26;}function ha(_0x3b472d,_0x22869f,_0x223f8){const _0x5d2dd1=Ge(_0x22869f);if(_0x5d2dd1){for(let _0x20c197=0x0;_0x20c197<_0x5d2dd1['length'];_0x20c197++)_0x223f8['push'](_0x5d2dd1[_0x20c197]);}Wn(_0x22869f,_0x9d070d=>{ha(_0x3b472d,_0x9d070d,_0x223f8);});}function $n(_0x249087,_0x548916){const _0x10e842=Ge(_0x548916);if(_0x10e842){let _0x58e831=0x0;for(let _0x16e56d=0x0;_0x16e56d<_0x10e842['length'];_0x16e56d++)_0x10e842[_0x16e56d]['status']!==0x2&&(_0x10e842[_0x58e831]=_0x10e842[_0x16e56d],_0x58e831++);_0x10e842['length']=_0x58e831,fs(_0x548916,_0x10e842['length']>0x0?_0x10e842:void 0x0);}Wn(_0x548916,_0x4ba40b=>{$n(_0x249087,_0x4ba40b);});}function vs(_0x501a47,_0x27986a){const _0x5121f2=Gt(ca(_0x501a47,_0x27986a)),_0x3fae90=Un(_0x501a47['transactionQueueTree_'],_0x27986a);return sd(_0x3fae90,_0x5eeb24=>{ai(_0x501a47,_0x5eeb24);}),ai(_0x501a47,_0x3fae90),ta(_0x3fae90,_0x1dee01=>{ai(_0x501a47,_0x1dee01);}),_0x5121f2;}function ai(_0x46b1a3,_0x410181){const _0x44b277=Ge(_0x410181);if(_0x44b277){const _0x48bd11=[];let _0x56f469=[],_0x3851cf=-0x1;for(let _0x20a04e=0x0;_0x20a04e<_0x44b277['length'];_0x20a04e++)_0x44b277[_0x20a04e]['status']===0x3||(_0x44b277[_0x20a04e]['status']===0x1?(f(_0x3851cf===_0x20a04e-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3851cf=_0x20a04e,_0x44b277[_0x20a04e]['status']=0x3,_0x44b277[_0x20a04e]['abortReason']='set'):(f(_0x44b277[_0x20a04e]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x44b277[_0x20a04e]['unwatcher'](),_0x56f469=_0x56f469['concat'](pe(_0x46b1a3['serverSyncTree_'],_0x44b277[_0x20a04e]['currentWriteId'],!0x0)),_0x44b277[_0x20a04e]['onComplete']&&_0x48bd11['push'](_0x44b277[_0x20a04e]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3851cf===-0x1?fs(_0x410181,void 0x0):_0x44b277['length']=_0x3851cf+0x1,V(_0x46b1a3['eventQueue_'],Gt(_0x410181),_0x56f469);for(let _0x5e487c=0x0;_0x5e487c<_0x48bd11['length'];_0x5e487c++)lt(_0x48bd11[_0x5e487c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0xfcc616){let _0x22a671='';const _0x2929d2=_0xfcc616['split']('/');for(let _0x1d6d73=0x0;_0x1d6d73<_0x2929d2['length'];_0x1d6d73++)if(_0x2929d2[_0x1d6d73]['length']>0x0){let _0x5477ae=_0x2929d2[_0x1d6d73];try{_0x5477ae=decodeURIComponent(_0x5477ae['replace'](/\+/g,'\x20'));}catch{}_0x22a671+='/'+_0x5477ae;}return _0x22a671;}function Nd(_0x2772e2){const _0xc6c66a={};_0x2772e2['charAt'](0x0)==='?'&&(_0x2772e2=_0x2772e2['substring'](0x1));for(const _0x277ba5 of _0x2772e2['split']('&')){if(_0x277ba5['length']===0x0)continue;const _0x3c7857=_0x277ba5['split']('=');_0x3c7857['length']===0x2?_0xc6c66a[decodeURIComponent(_0x3c7857[0x0])]=decodeURIComponent(_0x3c7857[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x277ba5+'\x27\x20in\x20query\x20\x27'+_0x2772e2+'\x27');}return _0xc6c66a;}const gr=function(_0x372eb7,_0x5ae663){const _0x12f1e6=Pd(_0x372eb7),_0x16ade3=_0x12f1e6['namespace'];_0x12f1e6['domain']==='firebase.com'&&oe(_0x12f1e6['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x16ade3||_0x16ade3==='undefined')&&_0x12f1e6['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x12f1e6['secure']||Bl();const _0x500db3=_0x12f1e6['scheme']==='ws'||_0x12f1e6['scheme']==='wss';return{'repoInfo':new _o(_0x12f1e6['host'],_0x12f1e6['secure'],_0x16ade3,_0x500db3,_0x5ae663,'',_0x16ade3!==_0x12f1e6['subdomain']),'path':new C(_0x12f1e6['pathString'])};},Pd=function(_0x3a62ab){let _0x1e00d2='',_0x1210fb='',_0x544583='',_0x381fb9='',_0x54034f='',_0x1d85bf=!0x0,_0x59a3b7='https',_0x4e045c=0x1bb;if(typeof _0x3a62ab=='string'){let _0x13f4ab=_0x3a62ab['indexOf']('//');_0x13f4ab>=0x0&&(_0x59a3b7=_0x3a62ab['substring'](0x0,_0x13f4ab-0x1),_0x3a62ab=_0x3a62ab['substring'](_0x13f4ab+0x2));let _0x429ae7=_0x3a62ab['indexOf']('/');_0x429ae7===-0x1&&(_0x429ae7=_0x3a62ab['length']);let _0x2a8c6a=_0x3a62ab['indexOf']('?');_0x2a8c6a===-0x1&&(_0x2a8c6a=_0x3a62ab['length']),_0x1e00d2=_0x3a62ab['substring'](0x0,Math['min'](_0x429ae7,_0x2a8c6a)),_0x429ae7<_0x2a8c6a&&(_0x381fb9=kd(_0x3a62ab['substring'](_0x429ae7,_0x2a8c6a)));const _0x1750eb=Nd(_0x3a62ab['substring'](Math['min'](_0x3a62ab['length'],_0x2a8c6a)));_0x13f4ab=_0x1e00d2['indexOf'](':'),_0x13f4ab>=0x0?(_0x1d85bf=_0x59a3b7==='https'||_0x59a3b7==='wss',_0x4e045c=parseInt(_0x1e00d2['substring'](_0x13f4ab+0x1),0xa)):_0x13f4ab=_0x1e00d2['length'];const _0x124a93=_0x1e00d2['slice'](0x0,_0x13f4ab);if(_0x124a93['toLowerCase']()==='localhost')_0x1210fb='localhost';else{if(_0x124a93['split']('.')['length']<=0x2)_0x1210fb=_0x124a93;else{const _0x590dcf=_0x1e00d2['indexOf']('.');_0x544583=_0x1e00d2['substring'](0x0,_0x590dcf)['toLowerCase'](),_0x1210fb=_0x1e00d2['substring'](_0x590dcf+0x1),_0x54034f=_0x544583;}}'ns'in _0x1750eb&&(_0x54034f=_0x1750eb['ns']);}return{'host':_0x1e00d2,'port':_0x4e045c,'domain':_0x1210fb,'subdomain':_0x544583,'secure':_0x1d85bf,'scheme':_0x59a3b7,'pathString':_0x381fb9,'namespace':_0x54034f};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x11ff7a=0x0;const _0x25a8e8=[];return function(_0x4a7436){const _0x433557=_0x4a7436===_0x11ff7a;_0x11ff7a=_0x4a7436;let _0x2a69aa;const _0xc5153a=new Array(0x8);for(_0x2a69aa=0x7;_0x2a69aa>=0x0;_0x2a69aa--)_0xc5153a[_0x2a69aa]=mr['charAt'](_0x4a7436%0x40),_0x4a7436=Math['floor'](_0x4a7436/0x40);f(_0x4a7436===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3ac6ad=_0xc5153a['join']('');if(_0x433557){for(_0x2a69aa=0xb;_0x2a69aa>=0x0&&_0x25a8e8[_0x2a69aa]===0x3f;_0x2a69aa--)_0x25a8e8[_0x2a69aa]=0x0;_0x25a8e8[_0x2a69aa]++;}else{for(_0x2a69aa=0x0;_0x2a69aa<0xc;_0x2a69aa++)_0x25a8e8[_0x2a69aa]=Math['floor'](Math['random']()*0x40);}for(_0x2a69aa=0x0;_0x2a69aa<0xc;_0x2a69aa++)_0x3ac6ad+=mr['charAt'](_0x25a8e8[_0x2a69aa]);return f(_0x3ac6ad['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3ac6ad;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x142cc7,_0x5eea24,_0x31b62d,_0x4dfbf0){this['eventType']=_0x142cc7,this['eventRegistration']=_0x5eea24,this['snapshot']=_0x31b62d,this['prevName']=_0x4dfbf0;}['getPath'](){const _0x230637=this['snapshot']['ref'];return this['eventType']==='value'?_0x230637['_path']:_0x230637['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x15fd62,_0x710b5c,_0x14bdcd){this['eventRegistration']=_0x15fd62,this['error']=_0x710b5c,this['path']=_0x14bdcd;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x298e68,_0x5b902d){this['snapshotCallback']=_0x298e68,this['cancelCallback']=_0x5b902d;}['onValue'](_0x56e300,_0x275efa){this['snapshotCallback']['call'](null,_0x56e300,_0x275efa);}['onCancel'](_0x2fa4d0){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2fa4d0);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xf63d36){return this['snapshotCallback']===_0xf63d36['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xf63d36['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xf63d36['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x274cfa,_0x1448a8,_0x47a218,_0x4c3181){this['_repo']=_0x274cfa,this['_path']=_0x1448a8,this['_queryParams']=_0x47a218,this['_orderByCalled']=_0x4c3181;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x39b179=nr(this['_queryParams']),_0x5a588f=Bi(_0x39b179);return _0x5a588f==='{}'?'default':_0x5a588f;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x31c49a){if(_0x31c49a=k(_0x31c49a),!(_0x31c49a instanceof be))return!0x1;const _0xba1337=this['_repo']===_0x31c49a['_repo'],_0x56515a=qi(this['_path'],_0x31c49a['_path']),_0xf539a9=this['_queryIdentifier']===_0x31c49a['_queryIdentifier'];return _0xba1337&&_0x56515a&&_0xf539a9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x45c1c5,_0x5f3094){if(_0x45c1c5['_orderByCalled']===!0x0)throw new Error(_0x5f3094+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3ce2e8){let _0x26f392=null,_0x7e7b56=null;if(_0x3ce2e8['hasStart']()&&(_0x26f392=_0x3ce2e8['getIndexStartValue']()),_0x3ce2e8['hasEnd']()&&(_0x7e7b56=_0x3ce2e8['getIndexEndValue']()),_0x3ce2e8['getIndex']()===ye){const _0x36de85='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x329c35='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3ce2e8['hasStart']()){if(_0x3ce2e8['getIndexStartName']()!==xe)throw new Error(_0x36de85);if(typeof _0x26f392!='string')throw new Error(_0x329c35);}if(_0x3ce2e8['hasEnd']()){if(_0x3ce2e8['getIndexEndName']()!==Ie)throw new Error(_0x36de85);if(typeof _0x7e7b56!='string')throw new Error(_0x329c35);}}else{if(_0x3ce2e8['getIndex']()===R){if(_0x26f392!=null&&!Cn(_0x26f392)||_0x7e7b56!=null&&!Cn(_0x7e7b56))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3ce2e8['getIndex']()instanceof Ki||_0x3ce2e8['getIndex']()===Po,'unknown\x20index\x20type.'),_0x26f392!=null&&typeof _0x26f392=='object'||_0x7e7b56!=null&&typeof _0x7e7b56=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x5c4d12){if(_0x5c4d12['hasStart']()&&_0x5c4d12['hasEnd']()&&_0x5c4d12['hasLimit']()&&!_0x5c4d12['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x1de269,_0x274bdb){super(_0x1de269,_0x274bdb,new Qi(),!0x1);}get['parent'](){const _0x29c824=To(this['_path']);return _0x29c824===null?null:new Z(this['_repo'],_0x29c824);}get['root'](){let _0xb04e6c=this;for(;_0xb04e6c['parent']!==null;)_0xb04e6c=_0xb04e6c['parent'];return _0xb04e6c;}}class rt{constructor(_0x58758d,_0x24dea2,_0x50459e){this['_node']=_0x58758d,this['ref']=_0x24dea2,this['_index']=_0x50459e;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x237789){const _0x170947=new C(_0x237789),_0x5d8c9e=Lt(this['ref'],_0x237789);return new rt(this['_node']['getChild'](_0x170947),_0x5d8c9e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x25dce7){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3434a6,_0xbaf063)=>_0x25dce7(new rt(_0xbaf063,Lt(this['ref'],_0x3434a6),R)));}['hasChild'](_0x47e447){const _0x29c722=new C(_0x47e447);return!this['_node']['getChild'](_0x29c722)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x85108e,_0x2dba13){return _0x85108e=k(_0x85108e),_0x85108e['_checkNotDeleted']('ref'),_0x2dba13!==void 0x0?Lt(_0x85108e['_root'],_0x2dba13):_0x85108e['_root'];}function Lt(_0x502582,_0x5a969a){return _0x502582=k(_0x502582),y(_0x502582['_path'])===null?ud('child','path',_0x5a969a):_s('child','path',_0x5a969a),new Z(_0x502582['_repo'],A(_0x502582['_path'],_0x5a969a));}function d_(_0x28d0cf,_0x1a7a4a){_0x28d0cf=k(_0x28d0cf),gs('push',_0x28d0cf['_path']),qt('push',_0x1a7a4a,_0x28d0cf['_path'],!0x0);const _0x276f29=oa(_0x28d0cf['_repo']),_0x2cbdf6=Od(_0x276f29),_0x457421=Lt(_0x28d0cf,_0x2cbdf6),_0x5b0593=Lt(_0x28d0cf,_0x2cbdf6);let _0x44237e;return _0x1a7a4a!=null?_0x44237e=Ld(_0x5b0593,_0x1a7a4a)['then'](()=>_0x5b0593):_0x44237e=Promise['resolve'](_0x5b0593),_0x457421['then']=_0x44237e['then']['bind'](_0x44237e),_0x457421['catch']=_0x44237e['then']['bind'](_0x44237e,void 0x0),_0x457421;}function Ld(_0x3c7a56,_0x4b83f2){_0x3c7a56=k(_0x3c7a56),gs('set',_0x3c7a56['_path']),qt('set',_0x4b83f2,_0x3c7a56['_path'],!0x1);const _0x58887c=new Ve();return Ed(_0x3c7a56['_repo'],_0x3c7a56['_path'],_0x4b83f2,null,_0x58887c['wrapCallback'](()=>{})),_0x58887c['promise'];}function f_(_0x1fbe1c,_0x34e786){hd('update',_0x34e786,_0x1fbe1c['_path']);const _0x115d9a=new Ve();return Id(_0x1fbe1c['_repo'],_0x1fbe1c['_path'],_0x34e786,_0x115d9a['wrapCallback'](()=>{})),_0x115d9a['promise'];}function p_(_0xdcdffe){_0xdcdffe=k(_0xdcdffe);const _0x1535f1=new ua(()=>{}),_0x408991=new qn(_0x1535f1);return vd(_0xdcdffe['_repo'],_0xdcdffe,_0x408991)['then'](_0x2b90bb=>new rt(_0x2b90bb,new Z(_0xdcdffe['_repo'],_0xdcdffe['_path']),_0xdcdffe['_queryParams']['getIndex']()));}class qn{constructor(_0xcee6da){this['callbackContext']=_0xcee6da;}['respondsTo'](_0x3371f7){return _0x3371f7==='value';}['createEvent'](_0x515fd6,_0x3d0898){const _0x2dadc4=_0x3d0898['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x515fd6['snapshotNode'],new Z(_0x3d0898['_repo'],_0x3d0898['_path']),_0x2dadc4));}['getEventRunner'](_0x58fe9f){return _0x58fe9f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x58fe9f['error']):()=>this['callbackContext']['onValue'](_0x58fe9f['snapshot'],null);}['createCancelEvent'](_0x260c0f,_0x1be489){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x260c0f,_0x1be489):null;}['matches'](_0x241526){return _0x241526 instanceof qn?!_0x241526['callbackContext']||!this['callbackContext']?!0x0:_0x241526['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x26eced,_0x2517fc,_0x289df1,_0x32a93c,_0x113939){const _0x3af60b=new ua(_0x289df1,void 0x0),_0x58fa90=new qn(_0x3af60b);return Cd(_0x26eced['_repo'],_0x26eced,_0x58fa90),()=>Td(_0x26eced['_repo'],_0x26eced,_0x58fa90);}function Fd(_0x1deec2,_0x50c1e4,_0x3bd68d,_0x3479e0){return xd(_0x1deec2,'value',_0x50c1e4);}class dt{}class pa extends dt{constructor(_0x239200,_0x4bc628){super(),this['_value']=_0x239200,this['_key']=_0x4bc628,this['type']='endAt';}['_apply'](_0x463730){qt('endAt',this['_value'],_0x463730['_path'],!0x0);const _0x2dfdc0=Kh(_0x463730['_queryParams'],this['_value'],this['_key']);if(fa(_0x2dfdc0),Gn(_0x2dfdc0),_0x463730['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x463730['_repo'],_0x463730['_path'],_0x2dfdc0,_0x463730['_orderByCalled']);}}function __(_0x18a137,_0x1ccce0){return new pa(_0x18a137,_0x1ccce0);}class _a extends dt{constructor(_0x11a511,_0x5d7af7){super(),this['_value']=_0x11a511,this['_key']=_0x5d7af7,this['type']='startAt';}['_apply'](_0x5efb1a){qt('startAt',this['_value'],_0x5efb1a['_path'],!0x0);const _0x8b5b0b=jh(_0x5efb1a['_queryParams'],this['_value'],this['_key']);if(fa(_0x8b5b0b),Gn(_0x8b5b0b),_0x5efb1a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x5efb1a['_repo'],_0x5efb1a['_path'],_0x8b5b0b,_0x5efb1a['_orderByCalled']);}}function g_(_0x202628=null,_0x3230a8){return new _a(_0x202628,_0x3230a8);}class Ud extends dt{constructor(_0x37c977){super(),this['_limit']=_0x37c977,this['type']='limitToFirst';}['_apply'](_0x1e7747){if(_0x1e7747['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1e7747['_repo'],_0x1e7747['_path'],zh(_0x1e7747['_queryParams'],this['_limit']),_0x1e7747['_orderByCalled']);}}function m_(_0x165715){if(Math['floor'](_0x165715)!==_0x165715||_0x165715<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x165715);}class Wd extends dt{constructor(_0x26104e){super(),this['_path']=_0x26104e,this['type']='orderByChild';}['_apply'](_0x329324){da(_0x329324,'orderByChild');const _0x35b43a=new C(this['_path']);if(v(_0x35b43a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x175641=new Ki(_0x35b43a),_0x2108b0=Do(_0x329324['_queryParams'],_0x175641);return Gn(_0x2108b0),new be(_0x329324['_repo'],_0x329324['_path'],_0x2108b0,!0x0);}}function y_(_0x4c4f4b){if(_0x4c4f4b==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4c4f4b==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4c4f4b==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x4c4f4b),new Wd(_0x4c4f4b);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x53424c){da(_0x53424c,'orderByKey');const _0x5e5952=Do(_0x53424c['_queryParams'],ye);return Gn(_0x5e5952),new be(_0x53424c['_repo'],_0x53424c['_path'],_0x5e5952,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x4c009f,_0x58386d){super(),this['_value']=_0x4c009f,this['_key']=_0x58386d,this['type']='equalTo';}['_apply'](_0x5d1b99){if(qt('equalTo',this['_value'],_0x5d1b99['_path'],!0x1),_0x5d1b99['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5d1b99['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x5d1b99));}}function E_(_0x1d4e00,_0x2cdcd0){return new Vd(_0x1d4e00,_0x2cdcd0);}function I_(_0x5d596e,..._0x4060f4){let _0x1cf8d6=k(_0x5d596e);for(const _0x40ad51 of _0x4060f4)_0x1cf8d6=_0x40ad51['_apply'](_0x1cf8d6);return _0x1cf8d6;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x125edb,_0x33a5ca,_0x42ed94,_0x218a10){const _0x4b5492=_0x33a5ca['lastIndexOf'](':'),_0xa223f9=_0x33a5ca['substring'](0x0,_0x4b5492),_0xc49687=Wt(_0xa223f9);_0x125edb['repoInfo_']=new _o(_0x33a5ca,_0xc49687,_0x125edb['repoInfo_']['namespace'],_0x125edb['repoInfo_']['webSocketOnly'],_0x125edb['repoInfo_']['nodeAdmin'],_0x125edb['repoInfo_']['persistenceKey'],_0x125edb['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x42ed94),_0x218a10&&(_0x125edb['authTokenProvider_']=_0x218a10);}function qd(_0x2cbfb3,_0xcd60b5,_0x17eacf,_0x106b64,_0x2a0cc3){let _0x595764=_0x106b64||_0x2cbfb3['options']['databaseURL'];_0x595764===void 0x0&&(_0x2cbfb3['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2cbfb3['options']['projectId']),_0x595764=_0x2cbfb3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5ed04e=gr(_0x595764,_0x2a0cc3),_0x7d6d64=_0x5ed04e['repoInfo'],_0x4add8e;typeof process<'u'&&Us&&(_0x4add8e=Us[Hd]),_0x4add8e?(_0x595764='http://'+_0x4add8e+'?ns='+_0x7d6d64['namespace'],_0x5ed04e=gr(_0x595764,_0x2a0cc3),_0x7d6d64=_0x5ed04e['repoInfo']):_0x5ed04e['repoInfo']['secure'];const _0x170387=new Jl(_0x2cbfb3['name'],_0x2cbfb3['options'],_0xcd60b5);dd('Invalid\x20Firebase\x20Database\x20URL',_0x5ed04e),v(_0x5ed04e['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3827a0=jd(_0x7d6d64,_0x2cbfb3,_0x170387,new Ql(_0x2cbfb3,_0x17eacf));return new Kd(_0x3827a0,_0x2cbfb3);}function zd(_0x4b8f99,_0x5f4bed){const _0x3cf9c9=ki[_0x5f4bed];(!_0x3cf9c9||_0x3cf9c9[_0x4b8f99['key']]!==_0x4b8f99)&&oe('Database\x20'+_0x5f4bed+'('+_0x4b8f99['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4b8f99),delete _0x3cf9c9[_0x4b8f99['key']];}function jd(_0x6f4ed3,_0xa69b0e,_0x2f0605,_0x3a74e7){let _0x4bfc25=ki[_0xa69b0e['name']];_0x4bfc25||(_0x4bfc25={},ki[_0xa69b0e['name']]=_0x4bfc25);let _0x4733ef=_0x4bfc25[_0x6f4ed3['toURLString']()];return _0x4733ef&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4733ef=new gd(_0x6f4ed3,$d,_0x2f0605,_0x3a74e7),_0x4bfc25[_0x6f4ed3['toURLString']()]=_0x4733ef,_0x4733ef;}class Kd{constructor(_0x6e9a70,_0x4041d1){this['_repoInternal']=_0x6e9a70,this['app']=_0x4041d1,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3c22b1){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x3c22b1+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x3245b1=Qr(),_0x277583){const _0x4f6653=Ui(_0x3245b1,'database')['getImmediate']({'identifier':_0x277583});if(!_0x4f6653['_instanceStarted']){const _0x211cfc=ac('database');_0x211cfc&&Yd(_0x4f6653,..._0x211cfc);}return _0x4f6653;}function Yd(_0x8c4b5a,_0x187896,_0xc4b5d2,_0x26b949={}){_0x8c4b5a=k(_0x8c4b5a),_0x8c4b5a['_checkNotDeleted']('useEmulator');const _0x3597dc=_0x187896+':'+_0xc4b5d2,_0xb79946=_0x8c4b5a['_repoInternal'];if(_0x8c4b5a['_instanceStarted']){if(_0x3597dc===_0x8c4b5a['_repoInternal']['repoInfo_']['host']&&De(_0x26b949,_0xb79946['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x39d1a4;if(_0xb79946['repoInfo_']['nodeAdmin'])_0x26b949['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x39d1a4=new tn(tn['OWNER']);else{if(_0x26b949['mockUserToken']){const _0xcc98c6=typeof _0x26b949['mockUserToken']=='string'?_0x26b949['mockUserToken']:cc(_0x26b949['mockUserToken'],_0x8c4b5a['app']['options']['projectId']);_0x39d1a4=new tn(_0xcc98c6);}}Wt(_0x187896)&&jr(_0x187896),Gd(_0xb79946,_0x3597dc,_0x26b949,_0x39d1a4);}function C_(_0x892a36){_0x892a36=k(_0x892a36),_0x892a36['_checkNotDeleted']('goOffline'),aa(_0x892a36['_repo']);}function T_(_0x14d027){_0x14d027=k(_0x14d027),_0x14d027['_checkNotDeleted']('goOnline'),Sd(_0x14d027['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x2e403f){Ll(ct),et(new Me('database',(_0x29c860,{instanceIdentifier:_0x41f969})=>{const _0x4bea3d=_0x29c860['getProvider']('app')['getImmediate'](),_0x24b17f=_0x29c860['getProvider']('auth-internal'),_0x10c068=_0x29c860['getProvider']('app-check-internal');return qd(_0x4bea3d,_0x24b17f,_0x10c068,_0x41f969);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x2e403f),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x40c971,_0x4c17ff){this['committed']=_0x40c971,this['snapshot']=_0x4c17ff;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x4102bb,_0x55e7ed,_0x5275fa){if(_0x4102bb=k(_0x4102bb),gs('Reference.transaction',_0x4102bb['_path']),_0x4102bb['key']==='.length'||_0x4102bb['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4102bb['key']+'\x20is\x20a\x20read-only\x20object.';const _0x4b7510=!0x0,_0x31c6d1=new Ve(),_0x42413e=(_0x2f5fb9,_0x4a6717,_0x37e549)=>{let _0x38cbfa=null;_0x2f5fb9?_0x31c6d1['reject'](_0x2f5fb9):(_0x38cbfa=new rt(_0x37e549,new Z(_0x4102bb['_repo'],_0x4102bb['_path']),R),_0x31c6d1['resolve'](new Xd(_0x4a6717,_0x38cbfa)));},_0x11cae7=Fd(_0x4102bb,()=>{});return bd(_0x4102bb['_repo'],_0x4102bb['_path'],_0x55e7ed,_0x42413e,_0x11cae7,_0x4b7510),_0x31c6d1['promise'];}ie['prototype']['simpleListen']=function(_0x1ae8f2,_0x173e2b){this['sendRequest']('q',{'p':_0x1ae8f2},_0x173e2b);},ie['prototype']['echo']=function(_0xcaf405,_0x108420){this['sendRequest']('echo',{'d':_0xcaf405},_0x108420);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x561282,..._0x5be888){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x561282,..._0x5be888);}function nn(_0x53aa91,..._0x3ea99b){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x53aa91,..._0x3ea99b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x151680,..._0x3464e8){throw Es(_0x151680,..._0x3464e8);}function J(_0x159558,..._0x53062b){return Es(_0x159558,..._0x53062b);}function ya(_0x43456d,_0x1e875c,_0x56bf44){const _0x109b98={...Zd(),[_0x1e875c]:_0x56bf44};return new Ut('auth','Firebase',_0x109b98)['create'](_0x1e875c,{'appName':_0x43456d['name']});}function se(_0x1405cf){return ya(_0x1405cf,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x488ed7,..._0x171414){if(typeof _0x488ed7!='string'){const _0x1995e3=_0x171414[0x0],_0x474552=[..._0x171414['slice'](0x1)];return _0x474552[0x0]&&(_0x474552[0x0]['appName']=_0x488ed7['name']),_0x488ed7['_errorFactory']['create'](_0x1995e3,..._0x474552);}return ma['create'](_0x488ed7,..._0x171414);}function m(_0x6d05fc,_0x27523c,..._0x1616bd){if(!_0x6d05fc)throw Es(_0x27523c,..._0x1616bd);}function te(_0x282f05){const _0x272c37='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x282f05;throw nn(_0x272c37),new Error(_0x272c37);}function ae(_0x1b4a70,_0x379d96){_0x1b4a70||te(_0x379d96);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x4d5efe;return typeof self<'u'&&((_0x4d5efe=self['location'])==null?void 0x0:_0x4d5efe['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x565a71;return typeof self<'u'&&((_0x565a71=self['location'])==null?void 0x0:_0x565a71['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x1d6604=navigator;return _0x1d6604['languages']&&_0x1d6604['languages'][0x0]||_0x1d6604['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x315f06,_0x230b8d){this['shortDelay']=_0x315f06,this['longDelay']=_0x230b8d,ae(_0x230b8d>_0x315f06,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x3a19c7,_0x19e1b8){ae(_0x3a19c7['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1f6bc3}=_0x3a19c7['emulator'];return _0x19e1b8?''+_0x1f6bc3+(_0x19e1b8['startsWith']('/')?_0x19e1b8['slice'](0x1):_0x19e1b8):_0x1f6bc3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x2dcf26,_0x301d92,_0x2790ad){this['fetchImpl']=_0x2dcf26,_0x301d92&&(this['headersImpl']=_0x301d92),_0x2790ad&&(this['responseImpl']=_0x2790ad);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x22df9,_0x4c38ed){return _0x22df9['tenantId']&&!_0x4c38ed['tenantId']?{..._0x4c38ed,'tenantId':_0x22df9['tenantId']}:_0x4c38ed;}async function Ae(_0x32acb3,_0x15a787,_0x434e9d,_0x293492,_0x132cdd={}){return Ea(_0x32acb3,_0x132cdd,async()=>{let _0x1b6916={},_0x461b32={};_0x293492&&(_0x15a787==='GET'?_0x461b32=_0x293492:_0x1b6916={'body':JSON['stringify'](_0x293492)});const _0x93953c=at({..._0x461b32,'key':_0x32acb3['config']['apiKey']})['slice'](0x1),_0x514fb3=await _0x32acb3['_getAdditionalHeaders']();_0x514fb3['Content-Type']='application/json',_0x32acb3['languageCode']&&(_0x514fb3['X-Firebase-Locale']=_0x32acb3['languageCode']);const _0x3ddedb={'method':_0x15a787,'headers':_0x514fb3,..._0x1b6916};return lc()||(_0x3ddedb['referrerPolicy']='strict-origin-when-cross-origin'),_0x32acb3['emulatorConfig']&&Wt(_0x32acb3['emulatorConfig']['host'])&&(_0x3ddedb['credentials']='include'),va['fetch']()(await Ia(_0x32acb3,_0x32acb3['config']['apiHost'],_0x434e9d,_0x93953c),_0x3ddedb);});}async function Ea(_0x5276e5,_0x51449c,_0x25d562){_0x5276e5['_canInitEmulator']=!0x1;const _0x268db1={...rf,..._0x51449c};try{const _0x4f4458=new lf(_0x5276e5),_0x5a4cb9=await Promise['race']([_0x25d562(),_0x4f4458['promise']]);_0x4f4458['clearNetworkTimeout']();const _0x300ceb=await _0x5a4cb9['json']();if('needConfirmation'in _0x300ceb)throw en(_0x5276e5,'account-exists-with-different-credential',_0x300ceb);if(_0x5a4cb9['ok']&&!('errorMessage'in _0x300ceb))return _0x300ceb;{const _0x2ed68c=_0x5a4cb9['ok']?_0x300ceb['errorMessage']:_0x300ceb['error']['message'],[_0x9cc541,_0x557f99]=_0x2ed68c['split']('\x20:\x20');if(_0x9cc541==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5276e5,'credential-already-in-use',_0x300ceb);if(_0x9cc541==='EMAIL_EXISTS')throw en(_0x5276e5,'email-already-in-use',_0x300ceb);if(_0x9cc541==='USER_DISABLED')throw en(_0x5276e5,'user-disabled',_0x300ceb);const _0x4e219b=_0x268db1[_0x9cc541]||_0x9cc541['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x557f99)throw ya(_0x5276e5,_0x4e219b,_0x557f99);K(_0x5276e5,_0x4e219b);}}catch(_0x59239d){if(_0x59239d instanceof Se)throw _0x59239d;K(_0x5276e5,'network-request-failed',{'message':String(_0x59239d)});}}async function Yt(_0x473592,_0xfd7c61,_0x442947,_0x4e4f20,_0x72c5d3={}){const _0x358bba=await Ae(_0x473592,_0xfd7c61,_0x442947,_0x4e4f20,_0x72c5d3);return'mfaPendingCredential'in _0x358bba&&K(_0x473592,'multi-factor-auth-required',{'_serverResponse':_0x358bba}),_0x358bba;}async function Ia(_0x1440d8,_0x459403,_0x5ad90a,_0xfb864c){const _0x3cc889=''+_0x459403+_0x5ad90a+'?'+_0xfb864c,_0x2bd7a1=_0x1440d8,_0xc5c610=_0x2bd7a1['config']['emulator']?Is(_0x1440d8['config'],_0x3cc889):_0x1440d8['config']['apiScheme']+'://'+_0x3cc889;return of['includes'](_0x5ad90a)&&(await _0x2bd7a1['_persistenceManagerAvailable'],_0x2bd7a1['_getPersistenceType']()==='COOKIE')?_0x2bd7a1['_getPersistence']()['_getFinalTarget'](_0xc5c610)['toString']():_0xc5c610;}function cf(_0x8b686e){switch(_0x8b686e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1b582f){this['auth']=_0x1b582f,this['timer']=null,this['promise']=new Promise((_0x2bfc5a,_0x5deeb3)=>{this['timer']=setTimeout(()=>_0x5deeb3(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1c9a87,_0x5d8815,_0x25432){const _0x3a7cc0={'appName':_0x1c9a87['name']};_0x25432['email']&&(_0x3a7cc0['email']=_0x25432['email']),_0x25432['phoneNumber']&&(_0x3a7cc0['phoneNumber']=_0x25432['phoneNumber']);const _0x5834f=J(_0x1c9a87,_0x5d8815,_0x3a7cc0);return _0x5834f['customData']['_tokenResponse']=_0x25432,_0x5834f;}function vr(_0x36c718){return _0x36c718!==void 0x0&&_0x36c718['enterprise']!==void 0x0;}class hf{constructor(_0x18ac27){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x18ac27['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x18ac27['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x18ac27['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5ec1ef){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3fcea0 of this['recaptchaEnforcementState'])if(_0x3fcea0['provider']&&_0x3fcea0['provider']===_0x5ec1ef)return cf(_0x3fcea0['enforcementState']);return null;}['isProviderEnabled'](_0x5997d8){return this['getProviderEnforcementState'](_0x5997d8)==='ENFORCE'||this['getProviderEnforcementState'](_0x5997d8)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x55d14f,_0x10acdd){return Ae(_0x55d14f,'GET','/v2/recaptchaConfig',Re(_0x55d14f,_0x10acdd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x556983,_0x189d49){return Ae(_0x556983,'POST','/v1/accounts:delete',_0x189d49);}async function Sn(_0x492f5f,_0x3a9e73){return Ae(_0x492f5f,'POST','/v1/accounts:lookup',_0x3a9e73);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x54c54b){if(_0x54c54b)try{const _0x15cde1=new Date(Number(_0x54c54b));if(!isNaN(_0x15cde1['getTime']()))return _0x15cde1['toUTCString']();}catch{}}async function ff(_0x12e30c,_0x1d546c=!0x1){const _0x2dd31c=k(_0x12e30c),_0x1e76b0=await _0x2dd31c['getIdToken'](_0x1d546c),_0xa3a494=ws(_0x1e76b0);m(_0xa3a494&&_0xa3a494['exp']&&_0xa3a494['auth_time']&&_0xa3a494['iat'],_0x2dd31c['auth'],'internal-error');const _0x242a3f=typeof _0xa3a494['firebase']=='object'?_0xa3a494['firebase']:void 0x0,_0x2d5ad5=_0x242a3f==null?void 0x0:_0x242a3f['sign_in_provider'];return{'claims':_0xa3a494,'token':_0x1e76b0,'authTime':St(ci(_0xa3a494['auth_time'])),'issuedAtTime':St(ci(_0xa3a494['iat'])),'expirationTime':St(ci(_0xa3a494['exp'])),'signInProvider':_0x2d5ad5||null,'signInSecondFactor':(_0x242a3f==null?void 0x0:_0x242a3f['sign_in_second_factor'])||null};}function ci(_0x1c412d){return Number(_0x1c412d)*0x3e8;}function ws(_0x57aae3){const [_0x1fadc5,_0x49944e,_0x17d170]=_0x57aae3['split']('.');if(_0x1fadc5===void 0x0||_0x49944e===void 0x0||_0x17d170===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x9e541d=cn(_0x49944e);return _0x9e541d?JSON['parse'](_0x9e541d):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3113fa){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3113fa==null?void 0x0:_0x3113fa['toString']()),null;}}function Er(_0xbcbe6){const _0x1f6a6c=ws(_0xbcbe6);return m(_0x1f6a6c,'internal-error'),m(typeof _0x1f6a6c['exp']<'u','internal-error'),m(typeof _0x1f6a6c['iat']<'u','internal-error'),Number(_0x1f6a6c['exp'])-Number(_0x1f6a6c['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0xc6bb44,_0x4c6a1c,_0x4b6641=!0x1){if(_0x4b6641)return _0x4c6a1c;try{return await _0x4c6a1c;}catch(_0x136541){throw _0x136541 instanceof Se&&pf(_0x136541)&&_0xc6bb44['auth']['currentUser']===_0xc6bb44&&await _0xc6bb44['auth']['signOut'](),_0x136541;}}function pf({code:_0x2585ea}){return _0x2585ea==='auth/user-disabled'||_0x2585ea==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x298a0a){this['user']=_0x298a0a,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x12e858){if(_0x12e858){const _0x1da1d3=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1da1d3;}else{this['errorBackoff']=0x7530;const _0x33f05=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x33f05);}}['schedule'](_0x4b3142=!0x1){if(!this['isRunning'])return;const _0xcffce8=this['getInterval'](_0x4b3142);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xcffce8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x504fca){(_0x504fca==null?void 0x0:_0x504fca['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x45d95c,_0xbfe7c8){this['createdAt']=_0x45d95c,this['lastLoginAt']=_0xbfe7c8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x43fc40){this['createdAt']=_0x43fc40['createdAt'],this['lastLoginAt']=_0x43fc40['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x4e5bd5){var _0x1c51d4;const _0x262d5c=_0x4e5bd5['auth'],_0x2fed2b=await _0x4e5bd5['getIdToken'](),_0x381518=await xt(_0x4e5bd5,Sn(_0x262d5c,{'idToken':_0x2fed2b}));m(_0x381518==null?void 0x0:_0x381518['users']['length'],_0x262d5c,'internal-error');const _0xc1854e=_0x381518['users'][0x0];_0x4e5bd5['_notifyReloadListener'](_0xc1854e);const _0x485113=(_0x1c51d4=_0xc1854e['providerUserInfo'])!=null&&_0x1c51d4['length']?wa(_0xc1854e['providerUserInfo']):[],_0x4c87f0=mf(_0x4e5bd5['providerData'],_0x485113),_0x320b07=_0x4e5bd5['isAnonymous'],_0x3816b1=!(_0x4e5bd5['email']&&_0xc1854e['passwordHash'])&&!(_0x4c87f0!=null&&_0x4c87f0['length']),_0x47a9cb=_0x320b07?_0x3816b1:!0x1,_0x3ac63f={'uid':_0xc1854e['localId'],'displayName':_0xc1854e['displayName']||null,'photoURL':_0xc1854e['photoUrl']||null,'email':_0xc1854e['email']||null,'emailVerified':_0xc1854e['emailVerified']||!0x1,'phoneNumber':_0xc1854e['phoneNumber']||null,'tenantId':_0xc1854e['tenantId']||null,'providerData':_0x4c87f0,'metadata':new Pi(_0xc1854e['createdAt'],_0xc1854e['lastLoginAt']),'isAnonymous':_0x47a9cb};Object['assign'](_0x4e5bd5,_0x3ac63f);}async function gf(_0x6f5731){const _0x4b4737=k(_0x6f5731);await bn(_0x4b4737),await _0x4b4737['auth']['_persistUserIfCurrent'](_0x4b4737),_0x4b4737['auth']['_notifyListenersIfCurrent'](_0x4b4737);}function mf(_0x587f60,_0x2985da){return[..._0x587f60['filter'](_0x1a2cfc=>!_0x2985da['some'](_0x1554a0=>_0x1554a0['providerId']===_0x1a2cfc['providerId'])),..._0x2985da];}function wa(_0x6f0c4a){return _0x6f0c4a['map'](({providerId:_0x4af0bc,..._0x4cce4e})=>({'providerId':_0x4af0bc,'uid':_0x4cce4e['rawId']||'','displayName':_0x4cce4e['displayName']||null,'email':_0x4cce4e['email']||null,'phoneNumber':_0x4cce4e['phoneNumber']||null,'photoURL':_0x4cce4e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x55d1b2,_0x13594b){const _0x474df5=await Ea(_0x55d1b2,{},async()=>{const _0x459d71=at({'grant_type':'refresh_token','refresh_token':_0x13594b})['slice'](0x1),{tokenApiHost:_0x495116,apiKey:_0x119c0b}=_0x55d1b2['config'],_0x5862b1=await Ia(_0x55d1b2,_0x495116,'/v1/token','key='+_0x119c0b),_0x2bc4c0=await _0x55d1b2['_getAdditionalHeaders']();_0x2bc4c0['Content-Type']='application/x-www-form-urlencoded';const _0x220803={'method':'POST','headers':_0x2bc4c0,'body':_0x459d71};return _0x55d1b2['emulatorConfig']&&Wt(_0x55d1b2['emulatorConfig']['host'])&&(_0x220803['credentials']='include'),va['fetch']()(_0x5862b1,_0x220803);});return{'accessToken':_0x474df5['access_token'],'expiresIn':_0x474df5['expires_in'],'refreshToken':_0x474df5['refresh_token']};}async function vf(_0x17f6db,_0x49ecc8){return Ae(_0x17f6db,'POST','/v2/accounts:revokeToken',Re(_0x17f6db,_0x49ecc8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x29aa68){m(_0x29aa68['idToken'],'internal-error'),m(typeof _0x29aa68['idToken']<'u','internal-error'),m(typeof _0x29aa68['refreshToken']<'u','internal-error');const _0x1ba613='expiresIn'in _0x29aa68&&typeof _0x29aa68['expiresIn']<'u'?Number(_0x29aa68['expiresIn']):Er(_0x29aa68['idToken']);this['updateTokensAndExpiration'](_0x29aa68['idToken'],_0x29aa68['refreshToken'],_0x1ba613);}['updateFromIdToken'](_0x13669c){m(_0x13669c['length']!==0x0,'internal-error');const _0x308e0c=Er(_0x13669c);this['updateTokensAndExpiration'](_0x13669c,null,_0x308e0c);}async['getToken'](_0x47c0d4,_0x30993e=!0x1){return!_0x30993e&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x47c0d4,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x47c0d4,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1cab63,_0x10a311){const {accessToken:_0x104cb7,refreshToken:_0x5e4331,expiresIn:_0x3392d5}=await yf(_0x1cab63,_0x10a311);this['updateTokensAndExpiration'](_0x104cb7,_0x5e4331,Number(_0x3392d5));}['updateTokensAndExpiration'](_0x61fcf2,_0x2e10c9,_0x228417){this['refreshToken']=_0x2e10c9||null,this['accessToken']=_0x61fcf2||null,this['expirationTime']=Date['now']()+_0x228417*0x3e8;}static['fromJSON'](_0x3865f3,_0x21252c){const {refreshToken:_0x32b661,accessToken:_0x387db3,expirationTime:_0x1701e5}=_0x21252c,_0x28b641=new Je();return _0x32b661&&(m(typeof _0x32b661=='string','internal-error',{'appName':_0x3865f3}),_0x28b641['refreshToken']=_0x32b661),_0x387db3&&(m(typeof _0x387db3=='string','internal-error',{'appName':_0x3865f3}),_0x28b641['accessToken']=_0x387db3),_0x1701e5&&(m(typeof _0x1701e5=='number','internal-error',{'appName':_0x3865f3}),_0x28b641['expirationTime']=_0x1701e5),_0x28b641;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3da05d){this['accessToken']=_0x3da05d['accessToken'],this['refreshToken']=_0x3da05d['refreshToken'],this['expirationTime']=_0x3da05d['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x179f9f,_0x509af4){m(typeof _0x179f9f=='string'||typeof _0x179f9f>'u','internal-error',{'appName':_0x509af4});}class z{constructor({uid:_0x1a19f9,auth:_0x57b22e,stsTokenManager:_0x17b162,..._0x32637f}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1a19f9,this['auth']=_0x57b22e,this['stsTokenManager']=_0x17b162,this['accessToken']=_0x17b162['accessToken'],this['displayName']=_0x32637f['displayName']||null,this['email']=_0x32637f['email']||null,this['emailVerified']=_0x32637f['emailVerified']||!0x1,this['phoneNumber']=_0x32637f['phoneNumber']||null,this['photoURL']=_0x32637f['photoURL']||null,this['isAnonymous']=_0x32637f['isAnonymous']||!0x1,this['tenantId']=_0x32637f['tenantId']||null,this['providerData']=_0x32637f['providerData']?[..._0x32637f['providerData']]:[],this['metadata']=new Pi(_0x32637f['createdAt']||void 0x0,_0x32637f['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1fc683){const _0x1e457e=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1fc683));return m(_0x1e457e,this['auth'],'internal-error'),this['accessToken']!==_0x1e457e&&(this['accessToken']=_0x1e457e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1e457e;}['getIdTokenResult'](_0x11dbfc){return ff(this,_0x11dbfc);}['reload'](){return gf(this);}['_assign'](_0x29fb22){this!==_0x29fb22&&(m(this['uid']===_0x29fb22['uid'],this['auth'],'internal-error'),this['displayName']=_0x29fb22['displayName'],this['photoURL']=_0x29fb22['photoURL'],this['email']=_0x29fb22['email'],this['emailVerified']=_0x29fb22['emailVerified'],this['phoneNumber']=_0x29fb22['phoneNumber'],this['isAnonymous']=_0x29fb22['isAnonymous'],this['tenantId']=_0x29fb22['tenantId'],this['providerData']=_0x29fb22['providerData']['map'](_0x5f54b6=>({..._0x5f54b6})),this['metadata']['_copy'](_0x29fb22['metadata']),this['stsTokenManager']['_assign'](_0x29fb22['stsTokenManager']));}['_clone'](_0xdca7f6){const _0x13ec65=new z({...this,'auth':_0xdca7f6,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x13ec65['metadata']['_copy'](this['metadata']),_0x13ec65;}['_onReload'](_0x3bc355){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x3bc355,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x151121){this['reloadListener']?this['reloadListener'](_0x151121):this['reloadUserInfo']=_0x151121;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xb0164c,_0x188c6c=!0x1){let _0x195ffa=!0x1;_0xb0164c['idToken']&&_0xb0164c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xb0164c),_0x195ffa=!0x0),_0x188c6c&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x195ffa&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x2a9c99=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x2a9c99})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xee500e=>({..._0xee500e})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x42ac56,_0x54e779){const _0x271364=_0x54e779['displayName']??void 0x0,_0x268893=_0x54e779['email']??void 0x0,_0x44e54a=_0x54e779['phoneNumber']??void 0x0,_0x1e0d5b=_0x54e779['photoURL']??void 0x0,_0x411d6d=_0x54e779['tenantId']??void 0x0,_0x5d21e3=_0x54e779['_redirectEventId']??void 0x0,_0x1dfb3d=_0x54e779['createdAt']??void 0x0,_0x1b6085=_0x54e779['lastLoginAt']??void 0x0,{uid:_0x53a606,emailVerified:_0x1d8458,isAnonymous:_0x118c02,providerData:_0x427e49,stsTokenManager:_0x1af3f5}=_0x54e779;m(_0x53a606&&_0x1af3f5,_0x42ac56,'internal-error');const _0x5a8901=Je['fromJSON'](this['name'],_0x1af3f5);m(typeof _0x53a606=='string',_0x42ac56,'internal-error'),ce(_0x271364,_0x42ac56['name']),ce(_0x268893,_0x42ac56['name']),m(typeof _0x1d8458=='boolean',_0x42ac56,'internal-error'),m(typeof _0x118c02=='boolean',_0x42ac56,'internal-error'),ce(_0x44e54a,_0x42ac56['name']),ce(_0x1e0d5b,_0x42ac56['name']),ce(_0x411d6d,_0x42ac56['name']),ce(_0x5d21e3,_0x42ac56['name']),ce(_0x1dfb3d,_0x42ac56['name']),ce(_0x1b6085,_0x42ac56['name']);const _0x13844b=new z({'uid':_0x53a606,'auth':_0x42ac56,'email':_0x268893,'emailVerified':_0x1d8458,'displayName':_0x271364,'isAnonymous':_0x118c02,'photoURL':_0x1e0d5b,'phoneNumber':_0x44e54a,'tenantId':_0x411d6d,'stsTokenManager':_0x5a8901,'createdAt':_0x1dfb3d,'lastLoginAt':_0x1b6085});return _0x427e49&&Array['isArray'](_0x427e49)&&(_0x13844b['providerData']=_0x427e49['map'](_0x284ffc=>({..._0x284ffc}))),_0x5d21e3&&(_0x13844b['_redirectEventId']=_0x5d21e3),_0x13844b;}static async['_fromIdTokenResponse'](_0x2883ec,_0x196a1b,_0x447df4=!0x1){const _0x5b300e=new Je();_0x5b300e['updateFromServerResponse'](_0x196a1b);const _0x38724c=new z({'uid':_0x196a1b['localId'],'auth':_0x2883ec,'stsTokenManager':_0x5b300e,'isAnonymous':_0x447df4});return await bn(_0x38724c),_0x38724c;}static async['_fromGetAccountInfoResponse'](_0x481fb5,_0x126069,_0x384f69){const _0x2039d1=_0x126069['users'][0x0];m(_0x2039d1['localId']!==void 0x0,'internal-error');const _0x43d7d1=_0x2039d1['providerUserInfo']!==void 0x0?wa(_0x2039d1['providerUserInfo']):[],_0x11b4f4=!(_0x2039d1['email']&&_0x2039d1['passwordHash'])&&!(_0x43d7d1!=null&&_0x43d7d1['length']),_0x4de6f6=new Je();_0x4de6f6['updateFromIdToken'](_0x384f69);const _0x159941=new z({'uid':_0x2039d1['localId'],'auth':_0x481fb5,'stsTokenManager':_0x4de6f6,'isAnonymous':_0x11b4f4}),_0x27cbf7={'uid':_0x2039d1['localId'],'displayName':_0x2039d1['displayName']||null,'photoURL':_0x2039d1['photoUrl']||null,'email':_0x2039d1['email']||null,'emailVerified':_0x2039d1['emailVerified']||!0x1,'phoneNumber':_0x2039d1['phoneNumber']||null,'tenantId':_0x2039d1['tenantId']||null,'providerData':_0x43d7d1,'metadata':new Pi(_0x2039d1['createdAt'],_0x2039d1['lastLoginAt']),'isAnonymous':!(_0x2039d1['email']&&_0x2039d1['passwordHash'])&&!(_0x43d7d1!=null&&_0x43d7d1['length'])};return Object['assign'](_0x159941,_0x27cbf7),_0x159941;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x32aca4){ae(_0x32aca4 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2fe828=Ir['get'](_0x32aca4);return _0x2fe828?(ae(_0x2fe828 instanceof _0x32aca4,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2fe828):(_0x2fe828=new _0x32aca4(),Ir['set'](_0x32aca4,_0x2fe828),_0x2fe828);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x34cb56,_0x3947f6){this['storage'][_0x34cb56]=_0x3947f6;}async['_get'](_0x53b1c2){const _0x146dfe=this['storage'][_0x53b1c2];return _0x146dfe===void 0x0?null:_0x146dfe;}async['_remove'](_0x3c5c22){delete this['storage'][_0x3c5c22];}['_addListener'](_0x382036,_0x29bfc2){}['_removeListener'](_0x49da90,_0x3abe3a){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x137873,_0x12476f,_0x570741){return'firebase:'+_0x137873+':'+_0x12476f+':'+_0x570741;}class Xe{constructor(_0x4a1353,_0x4a8705,_0xa3377a){this['persistence']=_0x4a1353,this['auth']=_0x4a8705,this['userKey']=_0xa3377a;const {config:_0x335f09,name:_0x4d4991}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x335f09['apiKey'],_0x4d4991),this['fullPersistenceKey']=sn('persistence',_0x335f09['apiKey'],_0x4d4991),this['boundEventHandler']=_0x4a8705['_onStorageEvent']['bind'](_0x4a8705),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x53874a){return this['persistence']['_set'](this['fullUserKey'],_0x53874a['toJSON']());}async['getCurrentUser'](){const _0x5e2192=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5e2192)return null;if(typeof _0x5e2192=='string'){const _0x32eca4=await Sn(this['auth'],{'idToken':_0x5e2192})['catch'](()=>{});return _0x32eca4?z['_fromGetAccountInfoResponse'](this['auth'],_0x32eca4,_0x5e2192):null;}return z['_fromJSON'](this['auth'],_0x5e2192);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x89c63b){if(this['persistence']===_0x89c63b)return;const _0x5d6d41=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x89c63b,_0x5d6d41)return this['setCurrentUser'](_0x5d6d41);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5f2c5d,_0x26bb4b,_0x14da94='authUser'){if(!_0x26bb4b['length'])return new Xe(ne(wr),_0x5f2c5d,_0x14da94);const _0x3a3895=(await Promise['all'](_0x26bb4b['map'](async _0x553a41=>{if(await _0x553a41['_isAvailable']())return _0x553a41;})))['filter'](_0x3dafaa=>_0x3dafaa);let _0x11206c=_0x3a3895[0x0]||ne(wr);const _0x592778=sn(_0x14da94,_0x5f2c5d['config']['apiKey'],_0x5f2c5d['name']);let _0x3890c3=null;for(const _0x272d7c of _0x26bb4b)try{const _0x40bcc8=await _0x272d7c['_get'](_0x592778);if(_0x40bcc8){let _0x3f1ea1;if(typeof _0x40bcc8=='string'){const _0x168312=await Sn(_0x5f2c5d,{'idToken':_0x40bcc8})['catch'](()=>{});if(!_0x168312)break;_0x3f1ea1=await z['_fromGetAccountInfoResponse'](_0x5f2c5d,_0x168312,_0x40bcc8);}else _0x3f1ea1=z['_fromJSON'](_0x5f2c5d,_0x40bcc8);_0x272d7c!==_0x11206c&&(_0x3890c3=_0x3f1ea1),_0x11206c=_0x272d7c;break;}}catch{}const _0x4c1888=_0x3a3895['filter'](_0x4fc288=>_0x4fc288['_shouldAllowMigration']);return!_0x11206c['_shouldAllowMigration']||!_0x4c1888['length']?new Xe(_0x11206c,_0x5f2c5d,_0x14da94):(_0x11206c=_0x4c1888[0x0],_0x3890c3&&await _0x11206c['_set'](_0x592778,_0x3890c3['toJSON']()),await Promise['all'](_0x26bb4b['map'](async _0x28ced4=>{if(_0x28ced4!==_0x11206c)try{await _0x28ced4['_remove'](_0x592778);}catch{}})),new Xe(_0x11206c,_0x5f2c5d,_0x14da94));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x5c8adf){const _0x3f8048=_0x5c8adf['toLowerCase']();if(_0x3f8048['includes']('opera/')||_0x3f8048['includes']('opr/')||_0x3f8048['includes']('opios/'))return'Opera';if(Ra(_0x3f8048))return'IEMobile';if(_0x3f8048['includes']('msie')||_0x3f8048['includes']('trident/'))return'IE';if(_0x3f8048['includes']('edge/'))return'Edge';if(Ta(_0x3f8048))return'Firefox';if(_0x3f8048['includes']('silk/'))return'Silk';if(ka(_0x3f8048))return'Blackberry';if(Na(_0x3f8048))return'Webos';if(Sa(_0x3f8048))return'Safari';if((_0x3f8048['includes']('chrome/')||ba(_0x3f8048))&&!_0x3f8048['includes']('edge/'))return'Chrome';if(Aa(_0x3f8048))return'Android';{const _0x429c19=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5f443b=_0x5c8adf['match'](_0x429c19);if((_0x5f443b==null?void 0x0:_0x5f443b['length'])===0x2)return _0x5f443b[0x1];}return'Other';}function Ta(_0x4f8c5f=W()){return/firefox\//i['test'](_0x4f8c5f);}function Sa(_0x568a04=W()){const _0x5684cb=_0x568a04['toLowerCase']();return _0x5684cb['includes']('safari/')&&!_0x5684cb['includes']('chrome/')&&!_0x5684cb['includes']('crios/')&&!_0x5684cb['includes']('android');}function ba(_0x47ee90=W()){return/crios\//i['test'](_0x47ee90);}function Ra(_0x210578=W()){return/iemobile/i['test'](_0x210578);}function Aa(_0x4582a6=W()){return/android/i['test'](_0x4582a6);}function ka(_0x5222b9=W()){return/blackberry/i['test'](_0x5222b9);}function Na(_0x21cb0b=W()){return/webos/i['test'](_0x21cb0b);}function Cs(_0x5783d8=W()){return/iphone|ipad|ipod/i['test'](_0x5783d8)||/macintosh/i['test'](_0x5783d8)&&/mobile/i['test'](_0x5783d8);}function Ef(_0x49ec62=W()){var _0x4160f1;return Cs(_0x49ec62)&&!!((_0x4160f1=window['navigator'])!=null&&_0x4160f1['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x437cfe=W()){return Cs(_0x437cfe)||Aa(_0x437cfe)||Na(_0x437cfe)||ka(_0x437cfe)||/windows phone/i['test'](_0x437cfe)||Ra(_0x437cfe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x35916d,_0x28bd49=[]){let _0x30e182;switch(_0x35916d){case'Browser':_0x30e182=Cr(W());break;case'Worker':_0x30e182=Cr(W())+'-'+_0x35916d;break;default:_0x30e182=_0x35916d;}const _0x460496=_0x28bd49['length']?_0x28bd49['join'](','):'FirebaseCore-web';return _0x30e182+'/JsCore/'+ct+'/'+_0x460496;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x29f9a1){this['auth']=_0x29f9a1,this['queue']=[];}['pushCallback'](_0x49300f,_0x25903f){const _0x4b5ed2=_0x200772=>new Promise((_0x1423f2,_0x473f62)=>{try{const _0x271c6a=_0x49300f(_0x200772);_0x1423f2(_0x271c6a);}catch(_0x1dd3fb){_0x473f62(_0x1dd3fb);}});_0x4b5ed2['onAbort']=_0x25903f,this['queue']['push'](_0x4b5ed2);const _0x1d2303=this['queue']['length']-0x1;return()=>{this['queue'][_0x1d2303]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2a1f11){if(this['auth']['currentUser']===_0x2a1f11)return;const _0x3ecc20=[];try{for(const _0x1040be of this['queue'])await _0x1040be(_0x2a1f11),_0x1040be['onAbort']&&_0x3ecc20['push'](_0x1040be['onAbort']);}catch(_0x44baf1){_0x3ecc20['reverse']();for(const _0xaa70f of _0x3ecc20)try{_0xaa70f();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x44baf1==null?void 0x0:_0x44baf1['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x25001b,_0x556b21={}){return Ae(_0x25001b,'GET','/v2/passwordPolicy',Re(_0x25001b,_0x556b21));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x1946b8){var _0x212c5a;const _0x2b6778=_0x1946b8['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2b6778['minPasswordLength']??Tf,_0x2b6778['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2b6778['maxPasswordLength']),_0x2b6778['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2b6778['containsLowercaseCharacter']),_0x2b6778['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2b6778['containsUppercaseCharacter']),_0x2b6778['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2b6778['containsNumericCharacter']),_0x2b6778['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2b6778['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1946b8['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x212c5a=_0x1946b8['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x212c5a['join'](''))??'',this['forceUpgradeOnSignin']=_0x1946b8['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1946b8['schemaVersion'];}['validatePassword'](_0x5ec3cd){const _0xa8f7ce={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5ec3cd,_0xa8f7ce),this['validatePasswordCharacterOptions'](_0x5ec3cd,_0xa8f7ce),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['meetsMinPasswordLength']??!0x0),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['meetsMaxPasswordLength']??!0x0),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['containsLowercaseLetter']??!0x0),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['containsUppercaseLetter']??!0x0),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['containsNumericCharacter']??!0x0),_0xa8f7ce['isValid']&&(_0xa8f7ce['isValid']=_0xa8f7ce['containsNonAlphanumericCharacter']??!0x0),_0xa8f7ce;}['validatePasswordLengthOptions'](_0x2c40fe,_0x488b7a){const _0x4cb8ca=this['customStrengthOptions']['minPasswordLength'],_0x1b003c=this['customStrengthOptions']['maxPasswordLength'];_0x4cb8ca&&(_0x488b7a['meetsMinPasswordLength']=_0x2c40fe['length']>=_0x4cb8ca),_0x1b003c&&(_0x488b7a['meetsMaxPasswordLength']=_0x2c40fe['length']<=_0x1b003c);}['validatePasswordCharacterOptions'](_0x5f2df8,_0x415c1a){this['updatePasswordCharacterOptionsStatuses'](_0x415c1a,!0x1,!0x1,!0x1,!0x1);let _0x386d8b;for(let _0x3fc4c2=0x0;_0x3fc4c2<_0x5f2df8['length'];_0x3fc4c2++)_0x386d8b=_0x5f2df8['charAt'](_0x3fc4c2),this['updatePasswordCharacterOptionsStatuses'](_0x415c1a,_0x386d8b>='a'&&_0x386d8b<='z',_0x386d8b>='A'&&_0x386d8b<='Z',_0x386d8b>='0'&&_0x386d8b<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x386d8b));}['updatePasswordCharacterOptionsStatuses'](_0x84682b,_0x4e860c,_0x2470a4,_0x39c883,_0x4980ed){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x84682b['containsLowercaseLetter']||(_0x84682b['containsLowercaseLetter']=_0x4e860c)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x84682b['containsUppercaseLetter']||(_0x84682b['containsUppercaseLetter']=_0x2470a4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x84682b['containsNumericCharacter']||(_0x84682b['containsNumericCharacter']=_0x39c883)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x84682b['containsNonAlphanumericCharacter']||(_0x84682b['containsNonAlphanumericCharacter']=_0x4980ed));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x4579ac,_0x4e83d3,_0xdb3ca3,_0x2ddd75){this['app']=_0x4579ac,this['heartbeatServiceProvider']=_0x4e83d3,this['appCheckServiceProvider']=_0xdb3ca3,this['config']=_0x2ddd75,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4579ac['name'],this['clientVersion']=_0x2ddd75['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2a84a3=>this['_resolvePersistenceManagerAvailable']=_0x2a84a3);}['_initializeWithPersistence'](_0x39bcf9,_0x5c5f09){return _0x5c5f09&&(this['_popupRedirectResolver']=ne(_0x5c5f09)),this['_initializationPromise']=this['queue'](async()=>{var _0x19e64e,_0xbedbc5,_0x547425;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x39bcf9),(_0x19e64e=this['_resolvePersistenceManagerAvailable'])==null||_0x19e64e['call'](this),!this['_deleted'])){if((_0xbedbc5=this['_popupRedirectResolver'])!=null&&_0xbedbc5['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5c5f09),this['lastNotifiedUid']=((_0x547425=this['currentUser'])==null?void 0x0:_0x547425['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5bce44=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5bce44)){if(this['currentUser']&&_0x5bce44&&this['currentUser']['uid']===_0x5bce44['uid']){this['_currentUser']['_assign'](_0x5bce44),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5bce44,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2d88c4){try{const _0x4cb319=await Sn(this,{'idToken':_0x2d88c4}),_0x3d42b3=await z['_fromGetAccountInfoResponse'](this,_0x4cb319,_0x2d88c4);await this['directlySetCurrentUser'](_0x3d42b3);}catch(_0x41686b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x41686b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x10c788){var _0x2f56d7;if(H(this['app'])){const _0x3dac5d=this['app']['settings']['authIdToken'];return _0x3dac5d?new Promise(_0x36a9bd=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3dac5d)['then'](_0x36a9bd,_0x36a9bd));}):this['directlySetCurrentUser'](null);}const _0x5ce6a8=await this['assertedPersistence']['getCurrentUser']();let _0x51ce5f=_0x5ce6a8,_0x40702c=!0x1;if(_0x10c788&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x110723=(_0x2f56d7=this['redirectUser'])==null?void 0x0:_0x2f56d7['_redirectEventId'],_0x4fcb51=_0x51ce5f==null?void 0x0:_0x51ce5f['_redirectEventId'],_0x33df9a=await this['tryRedirectSignIn'](_0x10c788);(!_0x110723||_0x110723===_0x4fcb51)&&(_0x33df9a!=null&&_0x33df9a['user'])&&(_0x51ce5f=_0x33df9a['user'],_0x40702c=!0x0);}if(!_0x51ce5f)return this['directlySetCurrentUser'](null);if(!_0x51ce5f['_redirectEventId']){if(_0x40702c)try{await this['beforeStateQueue']['runMiddleware'](_0x51ce5f);}catch(_0x110a0b){_0x51ce5f=_0x5ce6a8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x110a0b));}return _0x51ce5f?this['reloadAndSetCurrentUserOrClear'](_0x51ce5f):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x51ce5f['_redirectEventId']?this['directlySetCurrentUser'](_0x51ce5f):this['reloadAndSetCurrentUserOrClear'](_0x51ce5f);}async['tryRedirectSignIn'](_0x14ee80){let _0x1f2ebd=null;try{_0x1f2ebd=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x14ee80,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1f2ebd;}async['reloadAndSetCurrentUserOrClear'](_0x23c9d8){try{await bn(_0x23c9d8);}catch(_0x505fcd){if((_0x505fcd==null?void 0x0:_0x505fcd['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x23c9d8);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x364402){if(H(this['app']))return Promise['reject'](se(this));const _0x26286d=_0x364402?k(_0x364402):null;return _0x26286d&&m(_0x26286d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x26286d&&_0x26286d['_clone'](this));}async['_updateCurrentUser'](_0x15a4b8,_0xa17445=!0x1){if(!this['_deleted'])return _0x15a4b8&&m(this['tenantId']===_0x15a4b8['tenantId'],this,'tenant-id-mismatch'),_0xa17445||await this['beforeStateQueue']['runMiddleware'](_0x15a4b8),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x15a4b8),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xed8201){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xed8201));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x9bdd4d){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x17e345=this['_getPasswordPolicyInternal']();return _0x17e345['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x17e345['validatePassword'](_0x9bdd4d);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xaa0054=await Cf(this),_0x35c9b4=new Sf(_0xaa0054);this['tenantId']===null?this['_projectPasswordPolicy']=_0x35c9b4:this['_tenantPasswordPolicies'][this['tenantId']]=_0x35c9b4;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xf54ce2){this['_errorFactory']=new Ut('auth','Firebase',_0xf54ce2());}['onAuthStateChanged'](_0x230524,_0x1b5bfc,_0x415524){return this['registerStateListener'](this['authStateSubscription'],_0x230524,_0x1b5bfc,_0x415524);}['beforeAuthStateChanged'](_0x420851,_0x51044f){return this['beforeStateQueue']['pushCallback'](_0x420851,_0x51044f);}['onIdTokenChanged'](_0x5b5737,_0xc9231e,_0x2a6d68){return this['registerStateListener'](this['idTokenSubscription'],_0x5b5737,_0xc9231e,_0x2a6d68);}['authStateReady'](){return new Promise((_0x5c6c1b,_0x1082bc)=>{if(this['currentUser'])_0x5c6c1b();else{const _0x39f4de=this['onAuthStateChanged'](()=>{_0x39f4de(),_0x5c6c1b();},_0x1082bc);}});}async['revokeAccessToken'](_0x29011b){if(this['currentUser']){const _0x21a13b=await this['currentUser']['getIdToken'](),_0x19670c={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x29011b,'idToken':_0x21a13b};this['tenantId']!=null&&(_0x19670c['tenantId']=this['tenantId']),await vf(this,_0x19670c);}}['toJSON'](){var _0x48b1d1;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x48b1d1=this['_currentUser'])==null?void 0x0:_0x48b1d1['toJSON']()};}async['_setRedirectUser'](_0x289a24,_0xa9ea3d){const _0x2ce97e=await this['getOrInitRedirectPersistenceManager'](_0xa9ea3d);return _0x289a24===null?_0x2ce97e['removeCurrentUser']():_0x2ce97e['setCurrentUser'](_0x289a24);}async['getOrInitRedirectPersistenceManager'](_0x5d1b14){if(!this['redirectPersistenceManager']){const _0x4c15f1=_0x5d1b14&&ne(_0x5d1b14)||this['_popupRedirectResolver'];m(_0x4c15f1,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4c15f1['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2d2288){var _0x14c9b2,_0x4fd24e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x14c9b2=this['_currentUser'])==null?void 0x0:_0x14c9b2['_redirectEventId'])===_0x2d2288?this['_currentUser']:((_0x4fd24e=this['redirectUser'])==null?void 0x0:_0x4fd24e['_redirectEventId'])===_0x2d2288?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4278a5){if(_0x4278a5===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4278a5));}['_notifyListenersIfCurrent'](_0x746847){_0x746847===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5c3619;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x417a66=((_0x5c3619=this['currentUser'])==null?void 0x0:_0x5c3619['uid'])??null;this['lastNotifiedUid']!==_0x417a66&&(this['lastNotifiedUid']=_0x417a66,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xc17cc0,_0x7b4d35,_0x5772ba,_0x48ebb5){if(this['_deleted'])return()=>{};const _0x1aec27=typeof _0x7b4d35=='function'?_0x7b4d35:_0x7b4d35['next']['bind'](_0x7b4d35);let _0x34ac31=!0x1;const _0x479d91=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x479d91,this,'internal-error'),_0x479d91['then'](()=>{_0x34ac31||_0x1aec27(this['currentUser']);}),typeof _0x7b4d35=='function'){const _0x46b377=_0xc17cc0['addObserver'](_0x7b4d35,_0x5772ba,_0x48ebb5);return()=>{_0x34ac31=!0x0,_0x46b377();};}else{const _0x4ba550=_0xc17cc0['addObserver'](_0x7b4d35);return()=>{_0x34ac31=!0x0,_0x4ba550();};}}async['directlySetCurrentUser'](_0x1aba78){this['currentUser']&&this['currentUser']!==_0x1aba78&&this['_currentUser']['_stopProactiveRefresh'](),_0x1aba78&&this['isProactiveRefreshEnabled']&&_0x1aba78['_startProactiveRefresh'](),this['currentUser']=_0x1aba78,_0x1aba78?await this['assertedPersistence']['setCurrentUser'](_0x1aba78):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xda906e){return this['operations']=this['operations']['then'](_0xda906e,_0xda906e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x481646){!_0x481646||this['frameworks']['includes'](_0x481646)||(this['frameworks']['push'](_0x481646),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x86d9b3;const _0x536696={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x536696['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3c1ffe=await((_0x86d9b3=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x86d9b3['getHeartbeatsHeader']());_0x3c1ffe&&(_0x536696['X-Firebase-Client']=_0x3c1ffe);const _0x565cde=await this['_getAppCheckToken']();return _0x565cde&&(_0x536696['X-Firebase-AppCheck']=_0x565cde),_0x536696;}async['_getAppCheckToken'](){var _0x2db84e;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5c3162=await((_0x2db84e=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2db84e['getToken']());return _0x5c3162!=null&&_0x5c3162['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5c3162['error']),_0x5c3162==null?void 0x0:_0x5c3162['token'];}}function qe(_0x2ae14c){return k(_0x2ae14c);}class Tr{constructor(_0x52be6c){this['auth']=_0x52be6c,this['observer']=null,this['addObserver']=Ic(_0x1c9ff8=>this['observer']=_0x1c9ff8);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x3a43ec){zn=_0x3a43ec;}function Da(_0x539c43){return zn['loadJS'](_0x539c43);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x4fa616){return'__'+_0x4fa616+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x5b3d76){_0x5b3d76();}['execute'](_0x8a8234,_0x4c6201){return Promise['resolve']('token');}['render'](_0x4a3fc8,_0x23178a){return'';}}class Of{['ready'](_0x565d72){_0x565d72();}['execute'](_0x2b4101,_0x1165a6){return Promise['resolve']('token');}['render'](_0x4961ff,_0x55d24b){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x6764f){this['type']=Df,this['auth']=qe(_0x6764f);}async['verify'](_0x29fa01='verify',_0x159e38=!0x1){async function _0x44e1a2(_0x245f9a){if(!_0x159e38){if(_0x245f9a['tenantId']==null&&_0x245f9a['_agentRecaptchaConfig']!=null)return _0x245f9a['_agentRecaptchaConfig']['siteKey'];if(_0x245f9a['tenantId']!=null&&_0x245f9a['_tenantRecaptchaConfigs'][_0x245f9a['tenantId']]!==void 0x0)return _0x245f9a['_tenantRecaptchaConfigs'][_0x245f9a['tenantId']]['siteKey'];}return new Promise(async(_0x5590de,_0x39798d)=>{uf(_0x245f9a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3a360d=>{if(_0x3a360d['recaptchaKey']===void 0x0)_0x39798d(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x581eb5=new hf(_0x3a360d);return _0x245f9a['tenantId']==null?_0x245f9a['_agentRecaptchaConfig']=_0x581eb5:_0x245f9a['_tenantRecaptchaConfigs'][_0x245f9a['tenantId']]=_0x581eb5,_0x5590de(_0x581eb5['siteKey']);}})['catch'](_0x18c500=>{_0x39798d(_0x18c500);});});}function _0x37c96b(_0x171775,_0x1ca28b,_0x2bfb9a){const _0x3be2c0=window['grecaptcha'];vr(_0x3be2c0)?_0x3be2c0['enterprise']['ready'](()=>{_0x3be2c0['enterprise']['execute'](_0x171775,{'action':_0x29fa01})['then'](_0x446067=>{_0x1ca28b(_0x446067);})['catch'](()=>{_0x1ca28b(Ma);});}):_0x2bfb9a(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x222bc1,_0x470805)=>{_0x44e1a2(this['auth'])['then'](async _0x33a7db=>{if(!_0x159e38&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x37c96b(_0x33a7db,_0x222bc1,_0x470805);else{if(typeof window>'u'){_0x470805(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x149183=Af();_0x149183['length']!==0x0&&(_0x149183+=_0x33a7db+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x5085fb;(_0x5085fb=le['scriptInjectionDeferred'])==null||_0x5085fb['resolve']();},Da(_0x149183)['then'](()=>{var _0x49baa0;return(_0x49baa0=le['scriptInjectionDeferred'])==null?void 0x0:_0x49baa0['promise'];})['then'](()=>{_0x37c96b(_0x33a7db,_0x222bc1,_0x470805);})['catch'](_0x3cd4fa=>{_0x470805(_0x3cd4fa);});}})['catch'](_0x12ab53=>{_0x470805(_0x12ab53);});});}}le['scriptInjectionDeferred']=null;async function br(_0x287a47,_0x1e9417,_0x3f1960,_0x5f0aff=!0x1,_0x318d3b=!0x1){const _0x5a149b=new le(_0x287a47);let _0x57e1bf;if(_0x318d3b)_0x57e1bf=Ma;else try{_0x57e1bf=await _0x5a149b['verify'](_0x3f1960);}catch{_0x57e1bf=await _0x5a149b['verify'](_0x3f1960,!0x0);}const _0x1d725d={..._0x1e9417};if(_0x3f1960==='mfaSmsEnrollment'||_0x3f1960==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1d725d){const _0x1ffc8d=_0x1d725d['phoneEnrollmentInfo']['phoneNumber'],_0x751b5=_0x1d725d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1d725d,{'phoneEnrollmentInfo':{'phoneNumber':_0x1ffc8d,'recaptchaToken':_0x751b5,'captchaResponse':_0x57e1bf,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1d725d){const _0x51b428=_0x1d725d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1d725d,{'phoneSignInInfo':{'recaptchaToken':_0x51b428,'captchaResponse':_0x57e1bf,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1d725d;}return _0x5f0aff?Object['assign'](_0x1d725d,{'captchaResp':_0x57e1bf}):Object['assign'](_0x1d725d,{'captchaResponse':_0x57e1bf}),Object['assign'](_0x1d725d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1d725d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1d725d;}async function Oi(_0x10221d,_0x5dc40a,_0x2cdcfe,_0x46799e,_0x5930b6){var _0x22212c;if((_0x22212c=_0x10221d['_getRecaptchaConfig']())!=null&&_0x22212c['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x17e1b7=await br(_0x10221d,_0x5dc40a,_0x2cdcfe,_0x2cdcfe==='getOobCode');return _0x46799e(_0x10221d,_0x17e1b7);}else return _0x46799e(_0x10221d,_0x5dc40a)['catch'](async _0x349553=>{if(_0x349553['code']==='auth/missing-recaptcha-token'){console['log'](_0x2cdcfe+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x457101=await br(_0x10221d,_0x5dc40a,_0x2cdcfe,_0x2cdcfe==='getOobCode');return _0x46799e(_0x10221d,_0x457101);}else return Promise['reject'](_0x349553);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x262bae,_0x147097){const _0x3c5ec5=Ui(_0x262bae,'auth');if(_0x3c5ec5['isInitialized']()){const _0xdbd7d9=_0x3c5ec5['getImmediate'](),_0x2e9afb=_0x3c5ec5['getOptions']();if(De(_0x2e9afb,_0x147097??{}))return _0xdbd7d9;K(_0xdbd7d9,'already-initialized');}return _0x3c5ec5['initialize']({'options':_0x147097});}function Lf(_0x2695b4,_0xb673a9){const _0x19875f=(_0xb673a9==null?void 0x0:_0xb673a9['persistence'])||[],_0x59bd6b=(Array['isArray'](_0x19875f)?_0x19875f:[_0x19875f])['map'](ne);_0xb673a9!=null&&_0xb673a9['errorMap']&&_0x2695b4['_updateErrorMap'](_0xb673a9['errorMap']),_0x2695b4['_initializeWithPersistence'](_0x59bd6b,_0xb673a9==null?void 0x0:_0xb673a9['popupRedirectResolver']);}function xf(_0x1df303,_0x29b65c,_0x490480){const _0x14ac26=qe(_0x1df303);m(/^https?:\/\//['test'](_0x29b65c),_0x14ac26,'invalid-emulator-scheme');const _0x3be411=!0x1,_0x43d399=La(_0x29b65c),{host:_0x3f53a2,port:_0x5a6663}=Ff(_0x29b65c),_0x5ee41c=_0x5a6663===null?'':':'+_0x5a6663,_0x27e2b8={'url':_0x43d399+'//'+_0x3f53a2+_0x5ee41c+'/'},_0x50b891=Object['freeze']({'host':_0x3f53a2,'port':_0x5a6663,'protocol':_0x43d399['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3be411})});if(!_0x14ac26['_canInitEmulator']){m(_0x14ac26['config']['emulator']&&_0x14ac26['emulatorConfig'],_0x14ac26,'emulator-config-failed'),m(De(_0x27e2b8,_0x14ac26['config']['emulator'])&&De(_0x50b891,_0x14ac26['emulatorConfig']),_0x14ac26,'emulator-config-failed');return;}_0x14ac26['config']['emulator']=_0x27e2b8,_0x14ac26['emulatorConfig']=_0x50b891,_0x14ac26['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3f53a2)?jr(_0x43d399+'//'+_0x3f53a2+_0x5ee41c):Uf();}function La(_0x388ec6){const _0x542324=_0x388ec6['indexOf'](':');return _0x542324<0x0?'':_0x388ec6['substr'](0x0,_0x542324+0x1);}function Ff(_0x21b547){const _0x10c761=La(_0x21b547),_0x46a564=/(\/\/)?([^?#/]+)/['exec'](_0x21b547['substr'](_0x10c761['length']));if(!_0x46a564)return{'host':'','port':null};const _0x24e098=_0x46a564[0x2]['split']('@')['pop']()||'',_0x9354b8=/^(\[[^\]]+\])(:|$)/['exec'](_0x24e098);if(_0x9354b8){const _0x44feb5=_0x9354b8[0x1];return{'host':_0x44feb5,'port':Rr(_0x24e098['substr'](_0x44feb5['length']+0x1))};}else{const [_0x30a9a7,_0x190983]=_0x24e098['split'](':');return{'host':_0x30a9a7,'port':Rr(_0x190983)};}}function Rr(_0xb9a06){if(!_0xb9a06)return null;const _0x11292f=Number(_0xb9a06);return isNaN(_0x11292f)?null:_0x11292f;}function Uf(){function _0x1fbf52(){const _0x514ae9=document['createElement']('p'),_0x158a5d=_0x514ae9['style'];_0x514ae9['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x158a5d['position']='fixed',_0x158a5d['width']='100%',_0x158a5d['backgroundColor']='#ffffff',_0x158a5d['border']='.1em\x20solid\x20#000000',_0x158a5d['color']='#b50000',_0x158a5d['bottom']='0px',_0x158a5d['left']='0px',_0x158a5d['margin']='0px',_0x158a5d['zIndex']='10000',_0x158a5d['textAlign']='center',_0x514ae9['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x514ae9);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1fbf52):_0x1fbf52());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x5ccdf0,_0x3eff2f){this['providerId']=_0x5ccdf0,this['signInMethod']=_0x3eff2f;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x2c143d){return te('not\x20implemented');}['_linkToIdToken'](_0x2b37d0,_0x4ac0c5){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x4cc76f){return te('not\x20implemented');}}async function Wf(_0x2870e1,_0x410df8){return Ae(_0x2870e1,'POST','/v1/accounts:signUp',_0x410df8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x746fea,_0x16bfd2){return Yt(_0x746fea,'POST','/v1/accounts:signInWithPassword',Re(_0x746fea,_0x16bfd2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4d7e97,_0x14295b){return Yt(_0x4d7e97,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4d7e97,_0x14295b));}async function Hf(_0x323cf1,_0x3fa5f6){return Yt(_0x323cf1,'POST','/v1/accounts:signInWithEmailLink',Re(_0x323cf1,_0x3fa5f6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x1d394f,_0x127c89,_0x5a929f,_0x4eac4c=null){super('password',_0x5a929f),this['_email']=_0x1d394f,this['_password']=_0x127c89,this['_tenantId']=_0x4eac4c;}static['_fromEmailAndPassword'](_0x59a88d,_0x3563e6){return new Ft(_0x59a88d,_0x3563e6,'password');}static['_fromEmailAndCode'](_0x8ae5d6,_0x4dafa1,_0x2e9e86=null){return new Ft(_0x8ae5d6,_0x4dafa1,'emailLink',_0x2e9e86);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3c6d01){const _0x318979=typeof _0x3c6d01=='string'?JSON['parse'](_0x3c6d01):_0x3c6d01;if(_0x318979!=null&&_0x318979['email']&&(_0x318979!=null&&_0x318979['password'])){if(_0x318979['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x318979['email'],_0x318979['password']);if(_0x318979['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x318979['email'],_0x318979['password'],_0x318979['tenantId']);}return null;}async['_getIdTokenResponse'](_0x171991){switch(this['signInMethod']){case'password':const _0x399628={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x171991,_0x399628,'signInWithPassword',Bf);case'emailLink':return Vf(_0x171991,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x171991,'internal-error');}}async['_linkToIdToken'](_0x436568,_0x166ef7){switch(this['signInMethod']){case'password':const _0x51212a={'idToken':_0x166ef7,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x436568,_0x51212a,'signUpPassword',Wf);case'emailLink':return Hf(_0x436568,{'idToken':_0x166ef7,'email':this['_email'],'oobCode':this['_password']});default:K(_0x436568,'internal-error');}}['_getReauthenticationResolver'](_0x4ff576){return this['_getIdTokenResponse'](_0x4ff576);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0xa91a80,_0x2dbde8){return Yt(_0xa91a80,'POST','/v1/accounts:signInWithIdp',Re(_0xa91a80,_0x2dbde8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x49d562){const _0x5b3ad4=new We(_0x49d562['providerId'],_0x49d562['signInMethod']);return _0x49d562['idToken']||_0x49d562['accessToken']?(_0x49d562['idToken']&&(_0x5b3ad4['idToken']=_0x49d562['idToken']),_0x49d562['accessToken']&&(_0x5b3ad4['accessToken']=_0x49d562['accessToken']),_0x49d562['nonce']&&!_0x49d562['pendingToken']&&(_0x5b3ad4['nonce']=_0x49d562['nonce']),_0x49d562['pendingToken']&&(_0x5b3ad4['pendingToken']=_0x49d562['pendingToken'])):_0x49d562['oauthToken']&&_0x49d562['oauthTokenSecret']?(_0x5b3ad4['accessToken']=_0x49d562['oauthToken'],_0x5b3ad4['secret']=_0x49d562['oauthTokenSecret']):K('argument-error'),_0x5b3ad4;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4c7a72){const _0x366e5c=typeof _0x4c7a72=='string'?JSON['parse'](_0x4c7a72):_0x4c7a72,{providerId:_0x35c303,signInMethod:_0x525565,..._0xfd503a}=_0x366e5c;if(!_0x35c303||!_0x525565)return null;const _0x58da0e=new We(_0x35c303,_0x525565);return _0x58da0e['idToken']=_0xfd503a['idToken']||void 0x0,_0x58da0e['accessToken']=_0xfd503a['accessToken']||void 0x0,_0x58da0e['secret']=_0xfd503a['secret'],_0x58da0e['nonce']=_0xfd503a['nonce'],_0x58da0e['pendingToken']=_0xfd503a['pendingToken']||null,_0x58da0e;}['_getIdTokenResponse'](_0x49323d){const _0x3a881a=this['buildRequest']();return Ze(_0x49323d,_0x3a881a);}['_linkToIdToken'](_0x79c41,_0x42c066){const _0x48203c=this['buildRequest']();return _0x48203c['idToken']=_0x42c066,Ze(_0x79c41,_0x48203c);}['_getReauthenticationResolver'](_0x5d2931){const _0x26960b=this['buildRequest']();return _0x26960b['autoCreate']=!0x1,Ze(_0x5d2931,_0x26960b);}['buildRequest'](){const _0x45d44f={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x45d44f['pendingToken']=this['pendingToken'];else{const _0x33994a={};this['idToken']&&(_0x33994a['id_token']=this['idToken']),this['accessToken']&&(_0x33994a['access_token']=this['accessToken']),this['secret']&&(_0x33994a['oauth_token_secret']=this['secret']),_0x33994a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x33994a['nonce']=this['nonce']),_0x45d44f['postBody']=at(_0x33994a);}return _0x45d44f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x4f0eaf){switch(_0x4f0eaf){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x3c2199){const _0x148a61=yt(vt(_0x3c2199))['link'],_0x81ffe1=_0x148a61?yt(vt(_0x148a61))['deep_link_id']:null,_0x118cb0=yt(vt(_0x3c2199))['deep_link_id'];return(_0x118cb0?yt(vt(_0x118cb0))['link']:null)||_0x118cb0||_0x81ffe1||_0x148a61||_0x3c2199;}class Ss{constructor(_0x47a175){const _0x33c823=yt(vt(_0x47a175)),_0x5f07c9=_0x33c823['apiKey']??null,_0x3cf79c=_0x33c823['oobCode']??null,_0x560f3d=Gf(_0x33c823['mode']??null);m(_0x5f07c9&&_0x3cf79c&&_0x560f3d,'argument-error'),this['apiKey']=_0x5f07c9,this['operation']=_0x560f3d,this['code']=_0x3cf79c,this['continueUrl']=_0x33c823['continueUrl']??null,this['languageCode']=_0x33c823['lang']??null,this['tenantId']=_0x33c823['tenantId']??null;}static['parseLink'](_0x27699e){const _0x581b48=qf(_0x27699e);try{return new Ss(_0x581b48);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x59c180,_0x374c34){return Ft['_fromEmailAndPassword'](_0x59c180,_0x374c34);}static['credentialWithLink'](_0x5ef772,_0xb6aa26){const _0x13656c=Ss['parseLink'](_0xb6aa26);return m(_0x13656c,'argument-error'),Ft['_fromEmailAndCode'](_0x5ef772,_0x13656c['code'],_0x13656c['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x8f37d4){this['providerId']=_0x8f37d4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3eb85a){this['defaultLanguageCode']=_0x3eb85a;}['setCustomParameters'](_0xbc622f){return this['customParameters']=_0xbc622f,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3829c4){return this['scopes']['includes'](_0x3829c4)||this['scopes']['push'](_0x3829c4),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x11f1a5){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x11f1a5});}static['credentialFromResult'](_0x253581){return he['credentialFromTaggedObject'](_0x253581);}static['credentialFromError'](_0xd45f37){return he['credentialFromTaggedObject'](_0xd45f37['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4e3261}){if(!_0x4e3261||!('oauthAccessToken'in _0x4e3261)||!_0x4e3261['oauthAccessToken'])return null;try{return he['credential'](_0x4e3261['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x505b90,_0xee1aa4){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x505b90,'accessToken':_0xee1aa4});}static['credentialFromResult'](_0xc464db){return ue['credentialFromTaggedObject'](_0xc464db);}static['credentialFromError'](_0x553a62){return ue['credentialFromTaggedObject'](_0x553a62['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xe4b68a}){if(!_0xe4b68a)return null;const {oauthIdToken:_0x7590cb,oauthAccessToken:_0x4e069a}=_0xe4b68a;if(!_0x7590cb&&!_0x4e069a)return null;try{return ue['credential'](_0x7590cb,_0x4e069a);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x570836){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x570836});}static['credentialFromResult'](_0x47d4d9){return de['credentialFromTaggedObject'](_0x47d4d9);}static['credentialFromError'](_0x1c12bb){return de['credentialFromTaggedObject'](_0x1c12bb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b6476}){if(!_0x4b6476||!('oauthAccessToken'in _0x4b6476)||!_0x4b6476['oauthAccessToken'])return null;try{return de['credential'](_0x4b6476['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x5c40e2,_0x11734c){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5c40e2,'oauthTokenSecret':_0x11734c});}static['credentialFromResult'](_0x4e2f9a){return fe['credentialFromTaggedObject'](_0x4e2f9a);}static['credentialFromError'](_0x2e6b5f){return fe['credentialFromTaggedObject'](_0x2e6b5f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x25160e}){if(!_0x25160e)return null;const {oauthAccessToken:_0x3b77d9,oauthTokenSecret:_0x24255c}=_0x25160e;if(!_0x3b77d9||!_0x24255c)return null;try{return fe['credential'](_0x3b77d9,_0x24255c);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3df0c2,_0x3147c0){return Yt(_0x3df0c2,'POST','/v1/accounts:signUp',Re(_0x3df0c2,_0x3147c0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x547e62){this['user']=_0x547e62['user'],this['providerId']=_0x547e62['providerId'],this['_tokenResponse']=_0x547e62['_tokenResponse'],this['operationType']=_0x547e62['operationType'];}static async['_fromIdTokenResponse'](_0x3d9d39,_0x29da00,_0x123c49,_0x1544a8=!0x1){const _0x3228ad=await z['_fromIdTokenResponse'](_0x3d9d39,_0x123c49,_0x1544a8),_0x394f9e=Ar(_0x123c49);return new Be({'user':_0x3228ad,'providerId':_0x394f9e,'_tokenResponse':_0x123c49,'operationType':_0x29da00});}static async['_forOperation'](_0x4d2ad0,_0x3f9c25,_0x312994){await _0x4d2ad0['_updateTokensIfNecessary'](_0x312994,!0x0);const _0xfee991=Ar(_0x312994);return new Be({'user':_0x4d2ad0,'providerId':_0xfee991,'_tokenResponse':_0x312994,'operationType':_0x3f9c25});}}function Ar(_0x14f33e){return _0x14f33e['providerId']?_0x14f33e['providerId']:'phoneNumber'in _0x14f33e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x45ade2,_0x2116ab,_0x41d09f,_0x18ced3){super(_0x2116ab['code'],_0x2116ab['message']),this['operationType']=_0x41d09f,this['user']=_0x18ced3,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x45ade2['name'],'tenantId':_0x45ade2['tenantId']??void 0x0,'_serverResponse':_0x2116ab['customData']['_serverResponse'],'operationType':_0x41d09f};}static['_fromErrorAndOperation'](_0x33b677,_0x429b8d,_0x26eda8,_0x445fec){return new Rn(_0x33b677,_0x429b8d,_0x26eda8,_0x445fec);}}function Fa(_0x2e0889,_0x510fc9,_0x1ef7f0,_0x5654f9){return(_0x510fc9==='reauthenticate'?_0x1ef7f0['_getReauthenticationResolver'](_0x2e0889):_0x1ef7f0['_getIdTokenResponse'](_0x2e0889))['catch'](_0x1f6c82=>{throw _0x1f6c82['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x2e0889,_0x1f6c82,_0x510fc9,_0x5654f9):_0x1f6c82;});}async function jf(_0x3d2162,_0x70ca13,_0x4859f2=!0x1){const _0x1921e7=await xt(_0x3d2162,_0x70ca13['_linkToIdToken'](_0x3d2162['auth'],await _0x3d2162['getIdToken']()),_0x4859f2);return Be['_forOperation'](_0x3d2162,'link',_0x1921e7);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x280239,_0x7316aa,_0x2ead24=!0x1){const {auth:_0x1c4661}=_0x280239;if(H(_0x1c4661['app']))return Promise['reject'](se(_0x1c4661));const _0x1bd129='reauthenticate';try{const _0x137943=await xt(_0x280239,Fa(_0x1c4661,_0x1bd129,_0x7316aa,_0x280239),_0x2ead24);m(_0x137943['idToken'],_0x1c4661,'internal-error');const _0x44eb0e=ws(_0x137943['idToken']);m(_0x44eb0e,_0x1c4661,'internal-error');const {sub:_0x4e91d9}=_0x44eb0e;return m(_0x280239['uid']===_0x4e91d9,_0x1c4661,'user-mismatch'),Be['_forOperation'](_0x280239,_0x1bd129,_0x137943);}catch(_0x4a7b06){throw(_0x4a7b06==null?void 0x0:_0x4a7b06['code'])==='auth/user-not-found'&&K(_0x1c4661,'user-mismatch'),_0x4a7b06;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x3b57b2,_0x52bb6d,_0x17c89c=!0x1){if(H(_0x3b57b2['app']))return Promise['reject'](se(_0x3b57b2));const _0x552fe8='signIn',_0x4f9027=await Fa(_0x3b57b2,_0x552fe8,_0x52bb6d),_0x100f82=await Be['_fromIdTokenResponse'](_0x3b57b2,_0x552fe8,_0x4f9027);return _0x17c89c||await _0x3b57b2['_updateCurrentUser'](_0x100f82['user']),_0x100f82;}async function Yf(_0x2ba37c,_0x71d10f){return Ua(qe(_0x2ba37c),_0x71d10f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x415c10){const _0x38e744=qe(_0x415c10);_0x38e744['_getPasswordPolicyInternal']()&&await _0x38e744['_updatePasswordPolicy']();}async function R_(_0x4e9c4f,_0x3bb119,_0x1189b1){if(H(_0x4e9c4f['app']))return Promise['reject'](se(_0x4e9c4f));const _0x3ddab3=qe(_0x4e9c4f),_0x593bd4=await Oi(_0x3ddab3,{'returnSecureToken':!0x0,'email':_0x3bb119,'password':_0x1189b1,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x2c17cb=>{throw _0x2c17cb['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4e9c4f),_0x2c17cb;}),_0x3998f4=await Be['_fromIdTokenResponse'](_0x3ddab3,'signIn',_0x593bd4);return await _0x3ddab3['_updateCurrentUser'](_0x3998f4['user']),_0x3998f4;}function A_(_0x34d23a,_0x1f4062,_0x9d906e){return H(_0x34d23a['app'])?Promise['reject'](se(_0x34d23a)):Yf(k(_0x34d23a),ft['credential'](_0x1f4062,_0x9d906e))['catch'](async _0x4b3738=>{throw _0x4b3738['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x34d23a),_0x4b3738;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x47caae,_0x5b64c0){return k(_0x47caae)['setPersistence'](_0x5b64c0);}function Qf(_0x29a37b,_0x47c16b,_0x4d9178,_0x15acfd){return k(_0x29a37b)['onIdTokenChanged'](_0x47c16b,_0x4d9178,_0x15acfd);}function Jf(_0x1e8842,_0x41e920,_0x4f7414){return k(_0x1e8842)['beforeAuthStateChanged'](_0x41e920,_0x4f7414);}function N_(_0x3dabfe,_0x29c7e2,_0x52c99a,_0x5109fa){return k(_0x3dabfe)['onAuthStateChanged'](_0x29c7e2,_0x52c99a,_0x5109fa);}function P_(_0x4ec80b){return k(_0x4ec80b)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0xb77dcc,_0x51362c){this['storageRetriever']=_0xb77dcc,this['type']=_0x51362c;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4b65fe,_0x5102b8){return this['storage']['setItem'](_0x4b65fe,JSON['stringify'](_0x5102b8)),Promise['resolve']();}['_get'](_0xcbcde0){const _0x12c16c=this['storage']['getItem'](_0xcbcde0);return Promise['resolve'](_0x12c16c?JSON['parse'](_0x12c16c):null);}['_remove'](_0xe2b2bd){return this['storage']['removeItem'](_0xe2b2bd),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x13719a,_0x96053e)=>this['onStorageEvent'](_0x13719a,_0x96053e),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2a4114){for(const _0x85d7a9 of Object['keys'](this['listeners'])){const _0x3de612=this['storage']['getItem'](_0x85d7a9),_0x428adf=this['localCache'][_0x85d7a9];_0x3de612!==_0x428adf&&_0x2a4114(_0x85d7a9,_0x428adf,_0x3de612);}}['onStorageEvent'](_0x1da299,_0x197d80=!0x1){if(!_0x1da299['key']){this['forAllChangedKeys']((_0x1d9b50,_0x3d9d64,_0x3895aa)=>{this['notifyListeners'](_0x1d9b50,_0x3895aa);});return;}const _0x23f172=_0x1da299['key'];_0x197d80?this['detachListener']():this['stopPolling']();const _0x248086=()=>{const _0x386235=this['storage']['getItem'](_0x23f172);!_0x197d80&&this['localCache'][_0x23f172]===_0x386235||this['notifyListeners'](_0x23f172,_0x386235);},_0x1a9108=this['storage']['getItem'](_0x23f172);If()&&_0x1a9108!==_0x1da299['newValue']&&_0x1da299['newValue']!==_0x1da299['oldValue']?setTimeout(_0x248086,Zf):_0x248086();}['notifyListeners'](_0x5257f9,_0xaec487){this['localCache'][_0x5257f9]=_0xaec487;const _0x19a2db=this['listeners'][_0x5257f9];if(_0x19a2db){for(const _0x739bac of Array['from'](_0x19a2db))_0x739bac(_0xaec487&&JSON['parse'](_0xaec487));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x13c2bd,_0x782bca,_0x527c91)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x13c2bd,'oldValue':_0x782bca,'newValue':_0x527c91}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x5813e5,_0x2f8c65){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x5813e5]||(this['listeners'][_0x5813e5]=new Set(),this['localCache'][_0x5813e5]=this['storage']['getItem'](_0x5813e5)),this['listeners'][_0x5813e5]['add'](_0x2f8c65);}['_removeListener'](_0x196432,_0x3a5f6d){this['listeners'][_0x196432]&&(this['listeners'][_0x196432]['delete'](_0x3a5f6d),this['listeners'][_0x196432]['size']===0x0&&delete this['listeners'][_0x196432]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3733ea,_0x4cadb1){await super['_set'](_0x3733ea,_0x4cadb1),this['localCache'][_0x3733ea]=JSON['stringify'](_0x4cadb1);}async['_get'](_0x4063b5){const _0x43e765=await super['_get'](_0x4063b5);return this['localCache'][_0x4063b5]=JSON['stringify'](_0x43e765),_0x43e765;}async['_remove'](_0x23e576){await super['_remove'](_0x23e576),delete this['localCache'][_0x23e576];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x439b35,_0x1cec60){}['_removeListener'](_0x37b67f,_0x492419){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x4aa2d2){return Promise['all'](_0x4aa2d2['map'](async _0x4ea648=>{try{return{'fulfilled':!0x0,'value':await _0x4ea648};}catch(_0x1ddbf6){return{'fulfilled':!0x1,'reason':_0x1ddbf6};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x31b91b){this['eventTarget']=_0x31b91b,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x991807){const _0x1799e8=this['receivers']['find'](_0x1335dd=>_0x1335dd['isListeningto'](_0x991807));if(_0x1799e8)return _0x1799e8;const _0x49c316=new jn(_0x991807);return this['receivers']['push'](_0x49c316),_0x49c316;}['isListeningto'](_0x2eceef){return this['eventTarget']===_0x2eceef;}async['handleEvent'](_0x5ad941){const _0x1b733f=_0x5ad941,{eventId:_0x144909,eventType:_0xa14d9b,data:_0x4a761c}=_0x1b733f['data'],_0x50e8b9=this['handlersMap'][_0xa14d9b];if(!(_0x50e8b9!=null&&_0x50e8b9['size']))return;_0x1b733f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x144909,'eventType':_0xa14d9b});const _0x3da366=Array['from'](_0x50e8b9)['map'](async _0x332f33=>_0x332f33(_0x1b733f['origin'],_0x4a761c)),_0x63865e=await tp(_0x3da366);_0x1b733f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x144909,'eventType':_0xa14d9b,'response':_0x63865e});}['_subscribe'](_0x254f1b,_0x5f2caa){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x254f1b]||(this['handlersMap'][_0x254f1b]=new Set()),this['handlersMap'][_0x254f1b]['add'](_0x5f2caa);}['_unsubscribe'](_0x2e658b,_0x300461){this['handlersMap'][_0x2e658b]&&_0x300461&&this['handlersMap'][_0x2e658b]['delete'](_0x300461),(!_0x300461||this['handlersMap'][_0x2e658b]['size']===0x0)&&delete this['handlersMap'][_0x2e658b],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x564fb2='',_0xa56cfa=0xa){let _0x47cc32='';for(let _0x30d569=0x0;_0x30d569<_0xa56cfa;_0x30d569++)_0x47cc32+=Math['floor'](Math['random']()*0xa);return _0x564fb2+_0x47cc32;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x599861){this['target']=_0x599861,this['handlers']=new Set();}['removeMessageHandler'](_0x5865c8){_0x5865c8['messageChannel']&&(_0x5865c8['messageChannel']['port1']['removeEventListener']('message',_0x5865c8['onMessage']),_0x5865c8['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5865c8);}async['_send'](_0x116622,_0x570a70,_0x107713=0x32){const _0x2a4745=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2a4745)throw new Error('connection_unavailable');let _0x3b0ca4,_0x4246a1;return new Promise((_0x7149f,_0x47416d)=>{const _0x4bdf23=bs('',0x14);_0x2a4745['port1']['start']();const _0x1b2de6=setTimeout(()=>{_0x47416d(new Error('unsupported_event'));},_0x107713);_0x4246a1={'messageChannel':_0x2a4745,'onMessage'(_0x2f63c1){const _0x43aadc=_0x2f63c1;if(_0x43aadc['data']['eventId']===_0x4bdf23)switch(_0x43aadc['data']['status']){case'ack':clearTimeout(_0x1b2de6),_0x3b0ca4=setTimeout(()=>{_0x47416d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3b0ca4),_0x7149f(_0x43aadc['data']['response']);break;default:clearTimeout(_0x1b2de6),clearTimeout(_0x3b0ca4),_0x47416d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4246a1),_0x2a4745['port1']['addEventListener']('message',_0x4246a1['onMessage']),this['target']['postMessage']({'eventType':_0x116622,'eventId':_0x4bdf23,'data':_0x570a70},[_0x2a4745['port2']]);})['finally'](()=>{_0x4246a1&&this['removeMessageHandler'](_0x4246a1);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x9a5ab3){X()['location']['href']=_0x9a5ab3;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x332d94;return((_0x332d94=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x332d94['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x2226b8){this['request']=_0x2226b8;}['toPromise'](){return new Promise((_0x5db746,_0x51a62d)=>{this['request']['addEventListener']('success',()=>{_0x5db746(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x51a62d(this['request']['error']);});});}}function Kn(_0x15ff72,_0x262aa4){return _0x15ff72['transaction']([kn],_0x262aa4?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x125b19=indexedDB['deleteDatabase'](qa);return new Jt(_0x125b19)['toPromise']();}function ja(){const _0x359b8b=indexedDB['open'](qa,ap);return new Promise((_0x5b73e4,_0x2d18cf)=>{_0x359b8b['addEventListener']('error',()=>{_0x2d18cf(_0x359b8b['error']);}),_0x359b8b['addEventListener']('upgradeneeded',()=>{const _0x5e64bb=_0x359b8b['result'];try{_0x5e64bb['createObjectStore'](kn,{'keyPath':za});}catch(_0x5a1206){_0x2d18cf(_0x5a1206);}}),_0x359b8b['addEventListener']('success',async()=>{const _0x5a00e2=_0x359b8b['result'];_0x5a00e2['objectStoreNames']['contains'](kn)?_0x5b73e4(_0x5a00e2):(_0x5a00e2['close'](),await cp(),_0x5b73e4(await ja()));});});}async function kr(_0x5488c3,_0x15be35,_0x190e5a){const _0x5d93a1=Kn(_0x5488c3,!0x0)['put']({[za]:_0x15be35,'value':_0x190e5a});return new Jt(_0x5d93a1)['toPromise']();}async function lp(_0x2ebeeb,_0x366359){const _0xc495bd=Kn(_0x2ebeeb,!0x1)['get'](_0x366359),_0x345ed0=await new Jt(_0xc495bd)['toPromise']();return _0x345ed0===void 0x0?null:_0x345ed0['value'];}function Nr(_0x4fa8a1,_0x3b3a32){const _0x3636c5=Kn(_0x4fa8a1,!0x0)['delete'](_0x3b3a32);return new Jt(_0x3636c5)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x39e4cf){let _0x46bd07=0x0;for(;;)try{const _0x19120f=await this['_openDb']();return await _0x39e4cf(_0x19120f);}catch(_0x3912b0){if(_0x46bd07++>up)throw _0x3912b0;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0xcb4469,_0x193d15)=>({'keyProcessed':(await this['_poll']())['includes'](_0x193d15['key'])})),this['receiver']['_subscribe']('ping',async(_0x45c688,_0x3bbeba)=>['keyChanged']);}async['initializeSender'](){var _0x1b6c0f,_0x3567ab;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0xbbfa9f=await this['sender']['_send']('ping',{},0x320);_0xbbfa9f&&(_0x1b6c0f=_0xbbfa9f[0x0])!=null&&_0x1b6c0f['fulfilled']&&(_0x3567ab=_0xbbfa9f[0x0])!=null&&_0x3567ab['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5c5b75){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5c5b75},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1edc2a=>{await kr(_0x1edc2a,An,'1'),await Nr(_0x1edc2a,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x591369){this['pendingWrites']++;try{await _0x591369();}finally{this['pendingWrites']--;}}async['_set'](_0x14a2da,_0x141bf8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x33edc1=>kr(_0x33edc1,_0x14a2da,_0x141bf8)),this['localCache'][_0x14a2da]=_0x141bf8,this['notifyServiceWorker'](_0x14a2da)));}async['_get'](_0x3d9e32){const _0xeced26=await this['_withRetries'](_0x4958cc=>lp(_0x4958cc,_0x3d9e32));return this['localCache'][_0x3d9e32]=_0xeced26,_0xeced26;}async['_remove'](_0x56abc0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x58abdf=>Nr(_0x58abdf,_0x56abc0)),delete this['localCache'][_0x56abc0],this['notifyServiceWorker'](_0x56abc0)));}async['_poll'](){const _0x48e311=await this['_withRetries'](_0x15d414=>{const _0x144829=Kn(_0x15d414,!0x1)['getAll']();return new Jt(_0x144829)['toPromise']();});if(!_0x48e311)return[];if(this['pendingWrites']!==0x0)return[];const _0x386afa=[],_0x4d9bb4=new Set();if(_0x48e311['length']!==0x0){for(const {fbase_key:_0x57e02e,value:_0x4c4362}of _0x48e311)_0x4d9bb4['add'](_0x57e02e),JSON['stringify'](this['localCache'][_0x57e02e])!==JSON['stringify'](_0x4c4362)&&(this['notifyListeners'](_0x57e02e,_0x4c4362),_0x386afa['push'](_0x57e02e));}for(const _0xfe9427 of Object['keys'](this['localCache']))this['localCache'][_0xfe9427]&&!_0x4d9bb4['has'](_0xfe9427)&&(this['notifyListeners'](_0xfe9427,null),_0x386afa['push'](_0xfe9427));return _0x386afa;}['notifyListeners'](_0x377080,_0x18e46f){this['localCache'][_0x377080]=_0x18e46f;const _0xa85fbe=this['listeners'][_0x377080];if(_0xa85fbe){for(const _0xfd1b40 of Array['from'](_0xa85fbe))_0xfd1b40(_0x18e46f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x443024,_0x526734){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x443024]||(this['listeners'][_0x443024]=new Set(),this['_get'](_0x443024)),this['listeners'][_0x443024]['add'](_0x526734);}['_removeListener'](_0x591537,_0x570456){this['listeners'][_0x591537]&&(this['listeners'][_0x591537]['delete'](_0x570456),this['listeners'][_0x591537]['size']===0x0&&delete this['listeners'][_0x591537]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x153fba,_0xf51a55){return _0xf51a55?ne(_0xf51a55):(m(_0x153fba['_popupRedirectResolver'],_0x153fba,'argument-error'),_0x153fba['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x5dbd92){super('custom','custom'),this['params']=_0x5dbd92;}['_getIdTokenResponse'](_0x3eeccf){return Ze(_0x3eeccf,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1a5779,_0xe70d51){return Ze(_0x1a5779,this['_buildIdpRequest'](_0xe70d51));}['_getReauthenticationResolver'](_0x55596c){return Ze(_0x55596c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xe9c9ab){const _0x5ce7ca={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xe9c9ab&&(_0x5ce7ca['idToken']=_0xe9c9ab),_0x5ce7ca;}}function pp(_0x479115){return Ua(_0x479115['auth'],new Rs(_0x479115),_0x479115['bypassAuthState']);}function _p(_0x2d0d7c){const {auth:_0x5d8448,user:_0x2aa362}=_0x2d0d7c;return m(_0x2aa362,_0x5d8448,'internal-error'),Kf(_0x2aa362,new Rs(_0x2d0d7c),_0x2d0d7c['bypassAuthState']);}async function gp(_0x1f7b65){const {auth:_0x1ade7a,user:_0xde49d2}=_0x1f7b65;return m(_0xde49d2,_0x1ade7a,'internal-error'),jf(_0xde49d2,new Rs(_0x1f7b65),_0x1f7b65['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2321c2,_0x3c4cba,_0x2c48ec,_0x417e9c,_0xd2e660=!0x1){this['auth']=_0x2321c2,this['resolver']=_0x2c48ec,this['user']=_0x417e9c,this['bypassAuthState']=_0xd2e660,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3c4cba)?_0x3c4cba:[_0x3c4cba];}['execute'](){return new Promise(async(_0xb3f38d,_0x50209f)=>{this['pendingPromise']={'resolve':_0xb3f38d,'reject':_0x50209f};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5b76f3){this['reject'](_0x5b76f3);}});}async['onAuthEvent'](_0x15dda2){const {urlResponse:_0x5ec276,sessionId:_0x4cf356,postBody:_0x5af171,tenantId:_0x98207b,error:_0xe0553e,type:_0x105a35}=_0x15dda2;if(_0xe0553e){this['reject'](_0xe0553e);return;}const _0x52c9ac={'auth':this['auth'],'requestUri':_0x5ec276,'sessionId':_0x4cf356,'tenantId':_0x98207b||void 0x0,'postBody':_0x5af171||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x105a35)(_0x52c9ac));}catch(_0x26e520){this['reject'](_0x26e520);}}['onError'](_0x2ffeed){this['reject'](_0x2ffeed);}['getIdpTask'](_0x24e411){switch(_0x24e411){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x3f59de){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3f59de),this['unregisterAndCleanUp']();}['reject'](_0x1f9b9e){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1f9b9e),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x122a05,_0x3ae470,_0x23e937,_0x2073e4,_0x25bcbf){super(_0x122a05,_0x3ae470,_0x2073e4,_0x25bcbf),this['provider']=_0x23e937,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x5b19c3=await this['execute']();return m(_0x5b19c3,this['auth'],'internal-error'),_0x5b19c3;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x10f9e5=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x10f9e5),this['authWindow']['associatedEvent']=_0x10f9e5,this['resolver']['_originValidation'](this['auth'])['catch'](_0x32f48a=>{this['reject'](_0x32f48a);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x29364d=>{_0x29364d||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x425504;return((_0x425504=this['authWindow'])==null?void 0x0:_0x425504['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x56fa2e=()=>{var _0x53b987,_0x5e466e;if((_0x5e466e=(_0x53b987=this['authWindow'])==null?void 0x0:_0x53b987['window'])!=null&&_0x5e466e['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x56fa2e,mp['get']());};_0x56fa2e();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x4a198e,_0x4967f6,_0xe7e20a=!0x1){super(_0x4a198e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4967f6,void 0x0,_0xe7e20a),this['eventId']=null;}async['execute'](){let _0x1b18be=rn['get'](this['auth']['_key']());if(!_0x1b18be){try{const _0x336394=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x1b18be=()=>Promise['resolve'](_0x336394);}catch(_0x3e9c1b){_0x1b18be=()=>Promise['reject'](_0x3e9c1b);}rn['set'](this['auth']['_key'](),_0x1b18be);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1b18be();}async['onAuthEvent'](_0x52dc25){if(_0x52dc25['type']==='signInViaRedirect')return super['onAuthEvent'](_0x52dc25);if(_0x52dc25['type']==='unknown'){this['resolve'](null);return;}if(_0x52dc25['eventId']){const _0x40d052=await this['auth']['_redirectUserForId'](_0x52dc25['eventId']);if(_0x40d052)return this['user']=_0x40d052,super['onAuthEvent'](_0x52dc25);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x145c1a,_0x55cffa){const _0x476d3a=Cp(_0x55cffa),_0x4e96e0=wp(_0x145c1a);if(!await _0x4e96e0['_isAvailable']())return!0x1;const _0x1f248b=await _0x4e96e0['_get'](_0x476d3a)==='true';return await _0x4e96e0['_remove'](_0x476d3a),_0x1f248b;}function Ip(_0x1f0d5e,_0x11e397){rn['set'](_0x1f0d5e['_key'](),_0x11e397);}function wp(_0x28f5f3){return ne(_0x28f5f3['_redirectPersistence']);}function Cp(_0x2a86d6){return sn(yp,_0x2a86d6['config']['apiKey'],_0x2a86d6['name']);}async function Tp(_0x31cd0c,_0x35170b,_0x34b0c2=!0x1){if(H(_0x31cd0c['app']))return Promise['reject'](se(_0x31cd0c));const _0x23136b=qe(_0x31cd0c),_0x1162f3=fp(_0x23136b,_0x35170b),_0x3d30cc=await new vp(_0x23136b,_0x1162f3,_0x34b0c2)['execute']();return _0x3d30cc&&!_0x34b0c2&&(delete _0x3d30cc['user']['_redirectEventId'],await _0x23136b['_persistUserIfCurrent'](_0x3d30cc['user']),await _0x23136b['_setRedirectUser'](null,_0x35170b)),_0x3d30cc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x3af819){this['auth']=_0x3af819,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1ddd4e){this['consumers']['add'](_0x1ddd4e),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1ddd4e)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1ddd4e),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3fd866){this['consumers']['delete'](_0x3fd866);}['onEvent'](_0x26d413){if(this['hasEventBeenHandled'](_0x26d413))return!0x1;let _0x305c0f=!0x1;return this['consumers']['forEach'](_0x5ea7fc=>{this['isEventForConsumer'](_0x26d413,_0x5ea7fc)&&(_0x305c0f=!0x0,this['sendToConsumer'](_0x26d413,_0x5ea7fc),this['saveEventToCache'](_0x26d413));}),this['hasHandledPotentialRedirect']||!Rp(_0x26d413)||(this['hasHandledPotentialRedirect']=!0x0,_0x305c0f||(this['queuedRedirectEvent']=_0x26d413,_0x305c0f=!0x0)),_0x305c0f;}['sendToConsumer'](_0x2e6230,_0x2cff5a){var _0x527910;if(_0x2e6230['error']&&!Qa(_0x2e6230)){const _0x18d361=((_0x527910=_0x2e6230['error']['code'])==null?void 0x0:_0x527910['split']('auth/')[0x1])||'internal-error';_0x2cff5a['onError'](J(this['auth'],_0x18d361));}else _0x2cff5a['onAuthEvent'](_0x2e6230);}['isEventForConsumer'](_0x4e97df,_0x5684d6){const _0x10195b=_0x5684d6['eventId']===null||!!_0x4e97df['eventId']&&_0x4e97df['eventId']===_0x5684d6['eventId'];return _0x5684d6['filter']['includes'](_0x4e97df['type'])&&_0x10195b;}['hasEventBeenHandled'](_0x8b9e81){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x8b9e81));}['saveEventToCache'](_0x37c719){this['cachedEventUids']['add'](Pr(_0x37c719)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2b5db3){return[_0x2b5db3['type'],_0x2b5db3['eventId'],_0x2b5db3['sessionId'],_0x2b5db3['tenantId']]['filter'](_0x588be9=>_0x588be9)['join']('-');}function Qa({type:_0x4efcca,error:_0x363a9c}){return _0x4efcca==='unknown'&&(_0x363a9c==null?void 0x0:_0x363a9c['code'])==='auth/no-auth-event';}function Rp(_0x5b278e){switch(_0x5b278e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x5b278e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2824c8,_0x2ca701={}){return Ae(_0x2824c8,'GET','/v1/projects',_0x2ca701);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3db583){if(_0x3db583['config']['emulator'])return;const {authorizedDomains:_0x225230}=await Ap(_0x3db583);for(const _0x3a0260 of _0x225230)try{if(Op(_0x3a0260))return;}catch{}K(_0x3db583,'unauthorized-domain');}function Op(_0xd40819){const _0x2ae29b=Ni(),{protocol:_0x280619,hostname:_0xcfe952}=new URL(_0x2ae29b);if(_0xd40819['startsWith']('chrome-extension://')){const _0x32bb36=new URL(_0xd40819);return _0x32bb36['hostname']===''&&_0xcfe952===''?_0x280619==='chrome-extension:'&&_0xd40819['replace']('chrome-extension://','')===_0x2ae29b['replace']('chrome-extension://',''):_0x280619==='chrome-extension:'&&_0x32bb36['hostname']===_0xcfe952;}if(!Np['test'](_0x280619))return!0x1;if(kp['test'](_0xd40819))return _0xcfe952===_0xd40819;const _0x56d811=_0xd40819['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x56d811+'|'+_0x56d811+')$','i')['test'](_0xcfe952);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x216c39=X()['___jsl'];if(_0x216c39!=null&&_0x216c39['H']){for(const _0x386c8c of Object['keys'](_0x216c39['H']))if(_0x216c39['H'][_0x386c8c]['r']=_0x216c39['H'][_0x386c8c]['r']||[],_0x216c39['H'][_0x386c8c]['L']=_0x216c39['H'][_0x386c8c]['L']||[],_0x216c39['H'][_0x386c8c]['r']=[..._0x216c39['H'][_0x386c8c]['L']],_0x216c39['CP']){for(let _0x5dea6b=0x0;_0x5dea6b<_0x216c39['CP']['length'];_0x5dea6b++)_0x216c39['CP'][_0x5dea6b]=null;}}}function Mp(_0x2a8e58){return new Promise((_0x3f8308,_0x5e88eb)=>{var _0x240bdb,_0x58eab0,_0x34f943;function _0x3fb6ad(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3f8308(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x5e88eb(J(_0x2a8e58,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x58eab0=(_0x240bdb=X()['gapi'])==null?void 0x0:_0x240bdb['iframes'])!=null&&_0x58eab0['Iframe'])_0x3f8308(gapi['iframes']['getContext']());else{if((_0x34f943=X()['gapi'])!=null&&_0x34f943['load'])_0x3fb6ad();else{const _0xd17c04=Nf('iframefcb');return X()[_0xd17c04]=()=>{gapi['load']?_0x3fb6ad():_0x5e88eb(J(_0x2a8e58,'network-request-failed'));},Da(kf()+'?onload='+_0xd17c04)['catch'](_0x386eaa=>_0x5e88eb(_0x386eaa));}}})['catch'](_0x2de68d=>{throw on=null,_0x2de68d;});}let on=null;function Lp(_0x4f8669){return on=on||Mp(_0x4f8669),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x420e55){const _0x340215=_0x420e55['config'];m(_0x340215['authDomain'],_0x420e55,'auth-domain-config-required');const _0x3a3dcf=_0x340215['emulator']?Is(_0x340215,Up):'https://'+_0x420e55['config']['authDomain']+'/'+Fp,_0x5ce081={'apiKey':_0x340215['apiKey'],'appName':_0x420e55['name'],'v':ct},_0x518af4=Bp['get'](_0x420e55['config']['apiHost']);_0x518af4&&(_0x5ce081['eid']=_0x518af4);const _0x4d2b2a=_0x420e55['_getFrameworks']();return _0x4d2b2a['length']&&(_0x5ce081['fw']=_0x4d2b2a['join'](',')),_0x3a3dcf+'?'+at(_0x5ce081)['slice'](0x1);}async function Hp(_0x48a791){const _0x1956e9=await Lp(_0x48a791),_0x33b9ad=X()['gapi'];return m(_0x33b9ad,_0x48a791,'internal-error'),_0x1956e9['open']({'where':document['body'],'url':Vp(_0x48a791),'messageHandlersFilter':_0x33b9ad['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x36d1dd=>new Promise(async(_0x1af6cd,_0x20c809)=>{await _0x36d1dd['restyle']({'setHideOnLeave':!0x1});const _0x17e2d4=J(_0x48a791,'network-request-failed'),_0x6be670=X()['setTimeout'](()=>{_0x20c809(_0x17e2d4);},xp['get']());function _0x4908ff(){X()['clearTimeout'](_0x6be670),_0x1af6cd(_0x36d1dd);}_0x36d1dd['ping'](_0x4908ff)['then'](_0x4908ff,()=>{_0x20c809(_0x17e2d4);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x4d6d6d){this['window']=_0x4d6d6d,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x301c25,_0x5d47b5,_0x25ccd0,_0x3119e8=Gp,_0x1c1d22=qp){const _0x45d7eb=Math['max']((window['screen']['availHeight']-_0x1c1d22)/0x2,0x0)['toString'](),_0x543740=Math['max']((window['screen']['availWidth']-_0x3119e8)/0x2,0x0)['toString']();let _0x6093b1='';const _0x57f127={...$p,'width':_0x3119e8['toString'](),'height':_0x1c1d22['toString'](),'top':_0x45d7eb,'left':_0x543740},_0x40e818=W()['toLowerCase']();_0x25ccd0&&(_0x6093b1=ba(_0x40e818)?zp:_0x25ccd0),Ta(_0x40e818)&&(_0x5d47b5=_0x5d47b5||jp,_0x57f127['scrollbars']='yes');const _0x2f6ad6=Object['entries'](_0x57f127)['reduce']((_0x4ed08d,[_0x3dfc78,_0x2c5e10])=>''+_0x4ed08d+_0x3dfc78+'='+_0x2c5e10+',','');if(Ef(_0x40e818)&&_0x6093b1!=='_self')return Yp(_0x5d47b5||'',_0x6093b1),new Dr(null);const _0x15a008=window['open'](_0x5d47b5||'',_0x6093b1,_0x2f6ad6);m(_0x15a008,_0x301c25,'popup-blocked');try{_0x15a008['focus']();}catch{}return new Dr(_0x15a008);}function Yp(_0x1f3ce4,_0x1cc61f){const _0x18b4c5=document['createElement']('a');_0x18b4c5['href']=_0x1f3ce4,_0x18b4c5['target']=_0x1cc61f;const _0x1431d4=document['createEvent']('MouseEvent');_0x1431d4['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x18b4c5['dispatchEvent'](_0x1431d4);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x5a64a4,_0x5c8ea9,_0x19fb78,_0x582027,_0x4cee7c,_0x371513){m(_0x5a64a4['config']['authDomain'],_0x5a64a4,'auth-domain-config-required'),m(_0x5a64a4['config']['apiKey'],_0x5a64a4,'invalid-api-key');const _0x20470c={'apiKey':_0x5a64a4['config']['apiKey'],'appName':_0x5a64a4['name'],'authType':_0x19fb78,'redirectUrl':_0x582027,'v':ct,'eventId':_0x4cee7c};if(_0x5c8ea9 instanceof xa){_0x5c8ea9['setDefaultLanguage'](_0x5a64a4['languageCode']),_0x20470c['providerId']=_0x5c8ea9['providerId']||'',hi(_0x5c8ea9['getCustomParameters']())||(_0x20470c['customParameters']=JSON['stringify'](_0x5c8ea9['getCustomParameters']()));for(const [_0x116d58,_0x147da2]of Object['entries']({}))_0x20470c[_0x116d58]=_0x147da2;}if(_0x5c8ea9 instanceof Qt){const _0x144e2a=_0x5c8ea9['getScopes']()['filter'](_0x1bbe56=>_0x1bbe56!=='');_0x144e2a['length']>0x0&&(_0x20470c['scopes']=_0x144e2a['join'](','));}_0x5a64a4['tenantId']&&(_0x20470c['tid']=_0x5a64a4['tenantId']);const _0x1c9c81=_0x20470c;for(const _0x35e1c5 of Object['keys'](_0x1c9c81))_0x1c9c81[_0x35e1c5]===void 0x0&&delete _0x1c9c81[_0x35e1c5];const _0x4622bb=await _0x5a64a4['_getAppCheckToken'](),_0x437b63=_0x4622bb?'#'+Xp+'='+encodeURIComponent(_0x4622bb):'';return Zp(_0x5a64a4)+'?'+at(_0x1c9c81)['slice'](0x1)+_0x437b63;}function Zp({config:_0x41a9d8}){return _0x41a9d8['emulator']?Is(_0x41a9d8,Jp):'https://'+_0x41a9d8['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x420aba,_0x5a7c53,_0x4f6638,_0x1f92a4){var _0x145641;ae((_0x145641=this['eventManagers'][_0x420aba['_key']()])==null?void 0x0:_0x145641['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3d6fe7=await Mr(_0x420aba,_0x5a7c53,_0x4f6638,Ni(),_0x1f92a4);return Kp(_0x420aba,_0x3d6fe7,bs());}async['_openRedirect'](_0x3a8e05,_0x3209b3,_0x1d2de1,_0x54e539){await this['_originValidation'](_0x3a8e05);const _0x3dbe82=await Mr(_0x3a8e05,_0x3209b3,_0x1d2de1,Ni(),_0x54e539);return ip(_0x3dbe82),new Promise(()=>{});}['_initialize'](_0x5e8703){const _0x312eb0=_0x5e8703['_key']();if(this['eventManagers'][_0x312eb0]){const {manager:_0x1e006a,promise:_0x57b398}=this['eventManagers'][_0x312eb0];return _0x1e006a?Promise['resolve'](_0x1e006a):(ae(_0x57b398,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x57b398);}const _0x385388=this['initAndGetManager'](_0x5e8703);return this['eventManagers'][_0x312eb0]={'promise':_0x385388},_0x385388['catch'](()=>{delete this['eventManagers'][_0x312eb0];}),_0x385388;}async['initAndGetManager'](_0x1e6636){const _0x152dbd=await Hp(_0x1e6636),_0x272370=new bp(_0x1e6636);return _0x152dbd['register']('authEvent',_0x2c135e=>(m(_0x2c135e==null?void 0x0:_0x2c135e['authEvent'],_0x1e6636,'invalid-auth-event'),{'status':_0x272370['onEvent'](_0x2c135e['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1e6636['_key']()]={'manager':_0x272370},this['iframes'][_0x1e6636['_key']()]=_0x152dbd,_0x272370;}['_isIframeWebStorageSupported'](_0x437b25,_0x1f8cc2){this['iframes'][_0x437b25['_key']()]['send'](li,{'type':li},_0xab396f=>{var _0x1b3c1b;const _0x484801=(_0x1b3c1b=_0xab396f==null?void 0x0:_0xab396f[0x0])==null?void 0x0:_0x1b3c1b[li];_0x484801!==void 0x0&&_0x1f8cc2(!!_0x484801),K(_0x437b25,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xff224f){const _0x4bc256=_0xff224f['_key']();return this['originValidationPromises'][_0x4bc256]||(this['originValidationPromises'][_0x4bc256]=Pp(_0xff224f)),this['originValidationPromises'][_0x4bc256];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x33631f){this['auth']=_0x33631f,this['internalListeners']=new Map();}['getUid'](){var _0x426775;return this['assertAuthConfigured'](),((_0x426775=this['auth']['currentUser'])==null?void 0x0:_0x426775['uid'])||null;}async['getToken'](_0x55ad86){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x55ad86)}:null;}['addAuthTokenListener'](_0x56c089){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x56c089))return;const _0x183dd2=this['auth']['onIdTokenChanged'](_0xe10696=>{_0x56c089((_0xe10696==null?void 0x0:_0xe10696['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x56c089,_0x183dd2),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x7b110e){this['assertAuthConfigured']();const _0x3ce4a8=this['internalListeners']['get'](_0x7b110e);_0x3ce4a8&&(this['internalListeners']['delete'](_0x7b110e),_0x3ce4a8(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x4d9b31){switch(_0x4d9b31){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x2d79dc){et(new Me('auth',(_0x5d2537,{options:_0x207a23})=>{const _0x207757=_0x5d2537['getProvider']('app')['getImmediate'](),_0x1bc69d=_0x5d2537['getProvider']('heartbeat'),_0x1f52d0=_0x5d2537['getProvider']('app-check-internal'),{apiKey:_0x24629c,authDomain:_0x432673}=_0x207757['options'];m(_0x24629c&&!_0x24629c['includes'](':'),'invalid-api-key',{'appName':_0x207757['name']});const _0x1feea3={'apiKey':_0x24629c,'authDomain':_0x432673,'clientPlatform':_0x2d79dc,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x2d79dc)},_0x4d8cad=new bf(_0x207757,_0x1bc69d,_0x1f52d0,_0x1feea3);return Lf(_0x4d8cad,_0x207a23),_0x4d8cad;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x8d5f1e,_0x580932,_0xaff4b8)=>{_0x8d5f1e['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x5831ed=>{const _0x58e055=qe(_0x5831ed['getProvider']('auth')['getImmediate']());return(_0x5903c4=>new n_(_0x5903c4))(_0x58e055);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x2d79dc)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x3b2d86=>async _0x1a6302=>{const _0x4b6ea5=_0x1a6302&&await _0x1a6302['getIdTokenResult'](),_0x3eca07=_0x4b6ea5&&(new Date()['getTime']()-Date['parse'](_0x4b6ea5['issuedAtTime']))/0x3e8;if(_0x3eca07&&_0x3eca07>o_)return;const _0x2eaa27=_0x4b6ea5==null?void 0x0:_0x4b6ea5['token'];Fr!==_0x2eaa27&&(Fr=_0x2eaa27,await fetch(_0x3b2d86,{'method':_0x2eaa27?'POST':'DELETE','headers':_0x2eaa27?{'Authorization':'Bearer\x20'+_0x2eaa27}:{}}));};function O_(_0xd1dd36=Qr()){const _0x12873b=Ui(_0xd1dd36,'auth');if(_0x12873b['isInitialized']())return _0x12873b['getImmediate']();const _0x3ea345=Mf(_0xd1dd36,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x40930e=Gr('authTokenSyncURL');if(_0x40930e&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x48f423=new URL(_0x40930e,location['origin']);if(location['origin']===_0x48f423['origin']){const _0x59c208=a_(_0x48f423['toString']());Jf(_0x3ea345,_0x59c208,()=>_0x59c208(_0x3ea345['currentUser'])),Qf(_0x3ea345,_0x2417ce=>_0x59c208(_0x2417ce));}}const _0x33a58a=Hr('auth');return _0x33a58a&&xf(_0x3ea345,'http://'+_0x33a58a),_0x3ea345;}function c_(){var _0x4f64ba;return((_0x4f64ba=document['getElementsByTagName']('head'))==null?void 0x0:_0x4f64ba[0x0])??document;}Rf({'loadJS'(_0x128b98){return new Promise((_0x223c14,_0x135e3d)=>{const _0x1999fd=document['createElement']('script');_0x1999fd['setAttribute']('src',_0x128b98),_0x1999fd['onload']=_0x223c14,_0x1999fd['onerror']=_0x5a96e4=>{const _0x3e8875=J('internal-error');_0x3e8875['customData']=_0x5a96e4,_0x135e3d(_0x3e8875);},_0x1999fd['type']='text/javascript',_0x1999fd['charset']='UTF-8',c_()['appendChild'](_0x1999fd);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};