const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2976e0,_0x3c1698){if(!_0x2976e0)throw ot(_0x3c1698);},ot=function(_0x959319){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x959319);},Wr=function(_0x651739){const _0x802e74=[];let _0x2e3147=0x0;for(let _0x2b2cb7=0x0;_0x2b2cb7<_0x651739['length'];_0x2b2cb7++){let _0x2dac76=_0x651739['charCodeAt'](_0x2b2cb7);_0x2dac76<0x80?_0x802e74[_0x2e3147++]=_0x2dac76:_0x2dac76<0x800?(_0x802e74[_0x2e3147++]=_0x2dac76>>0x6|0xc0,_0x802e74[_0x2e3147++]=_0x2dac76&0x3f|0x80):(_0x2dac76&0xfc00)===0xd800&&_0x2b2cb7+0x1<_0x651739['length']&&(_0x651739['charCodeAt'](_0x2b2cb7+0x1)&0xfc00)===0xdc00?(_0x2dac76=0x10000+((_0x2dac76&0x3ff)<<0xa)+(_0x651739['charCodeAt'](++_0x2b2cb7)&0x3ff),_0x802e74[_0x2e3147++]=_0x2dac76>>0x12|0xf0,_0x802e74[_0x2e3147++]=_0x2dac76>>0xc&0x3f|0x80,_0x802e74[_0x2e3147++]=_0x2dac76>>0x6&0x3f|0x80,_0x802e74[_0x2e3147++]=_0x2dac76&0x3f|0x80):(_0x802e74[_0x2e3147++]=_0x2dac76>>0xc|0xe0,_0x802e74[_0x2e3147++]=_0x2dac76>>0x6&0x3f|0x80,_0x802e74[_0x2e3147++]=_0x2dac76&0x3f|0x80);}return _0x802e74;},Za=function(_0x43da22){const _0x109b4b=[];let _0x40f1d0=0x0,_0x3b9bcc=0x0;for(;_0x40f1d0<_0x43da22['length'];){const _0xb2b99=_0x43da22[_0x40f1d0++];if(_0xb2b99<0x80)_0x109b4b[_0x3b9bcc++]=String['fromCharCode'](_0xb2b99);else{if(_0xb2b99>0xbf&&_0xb2b99<0xe0){const _0x44cbb0=_0x43da22[_0x40f1d0++];_0x109b4b[_0x3b9bcc++]=String['fromCharCode']((_0xb2b99&0x1f)<<0x6|_0x44cbb0&0x3f);}else{if(_0xb2b99>0xef&&_0xb2b99<0x16d){const _0x115445=_0x43da22[_0x40f1d0++],_0x19ad95=_0x43da22[_0x40f1d0++],_0x5ee683=_0x43da22[_0x40f1d0++],_0x5a9c58=((_0xb2b99&0x7)<<0x12|(_0x115445&0x3f)<<0xc|(_0x19ad95&0x3f)<<0x6|_0x5ee683&0x3f)-0x10000;_0x109b4b[_0x3b9bcc++]=String['fromCharCode'](0xd800+(_0x5a9c58>>0xa)),_0x109b4b[_0x3b9bcc++]=String['fromCharCode'](0xdc00+(_0x5a9c58&0x3ff));}else{const _0x14e64a=_0x43da22[_0x40f1d0++],_0x41f08e=_0x43da22[_0x40f1d0++];_0x109b4b[_0x3b9bcc++]=String['fromCharCode']((_0xb2b99&0xf)<<0xc|(_0x14e64a&0x3f)<<0x6|_0x41f08e&0x3f);}}}}return _0x109b4b['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x21dcb3,_0x3ca749){if(!Array['isArray'](_0x21dcb3))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x45b715=_0x3ca749?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x877e0a=[];for(let _0x410f75=0x0;_0x410f75<_0x21dcb3['length'];_0x410f75+=0x3){const _0x21b5e0=_0x21dcb3[_0x410f75],_0x434bc2=_0x410f75+0x1<_0x21dcb3['length'],_0x38655c=_0x434bc2?_0x21dcb3[_0x410f75+0x1]:0x0,_0x1d0f6a=_0x410f75+0x2<_0x21dcb3['length'],_0x55e481=_0x1d0f6a?_0x21dcb3[_0x410f75+0x2]:0x0,_0xdbb4f2=_0x21b5e0>>0x2,_0x3cc3b2=(_0x21b5e0&0x3)<<0x4|_0x38655c>>0x4;let _0x5db527=(_0x38655c&0xf)<<0x2|_0x55e481>>0x6,_0x37b4bd=_0x55e481&0x3f;_0x1d0f6a||(_0x37b4bd=0x40,_0x434bc2||(_0x5db527=0x40)),_0x877e0a['push'](_0x45b715[_0xdbb4f2],_0x45b715[_0x3cc3b2],_0x45b715[_0x5db527],_0x45b715[_0x37b4bd]);}return _0x877e0a['join']('');},'encodeString'(_0x580b72,_0x3301d4){return this['HAS_NATIVE_SUPPORT']&&!_0x3301d4?btoa(_0x580b72):this['encodeByteArray'](Wr(_0x580b72),_0x3301d4);},'decodeString'(_0x146a9a,_0x257355){return this['HAS_NATIVE_SUPPORT']&&!_0x257355?atob(_0x146a9a):Za(this['decodeStringToByteArray'](_0x146a9a,_0x257355));},'decodeStringToByteArray'(_0x3eb3b9,_0x50d9cb){this['init_']();const _0xeddb10=_0x50d9cb?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4c7be1=[];for(let _0x1b4824=0x0;_0x1b4824<_0x3eb3b9['length'];){const _0x41929b=_0xeddb10[_0x3eb3b9['charAt'](_0x1b4824++)],_0x376209=_0x1b4824<_0x3eb3b9['length']?_0xeddb10[_0x3eb3b9['charAt'](_0x1b4824)]:0x0;++_0x1b4824;const _0x409cf7=_0x1b4824<_0x3eb3b9['length']?_0xeddb10[_0x3eb3b9['charAt'](_0x1b4824)]:0x40;++_0x1b4824;const _0x2c276f=_0x1b4824<_0x3eb3b9['length']?_0xeddb10[_0x3eb3b9['charAt'](_0x1b4824)]:0x40;if(++_0x1b4824,_0x41929b==null||_0x376209==null||_0x409cf7==null||_0x2c276f==null)throw new ec();const _0x1c7ba6=_0x41929b<<0x2|_0x376209>>0x4;if(_0x4c7be1['push'](_0x1c7ba6),_0x409cf7!==0x40){const _0x59aaac=_0x376209<<0x4&0xf0|_0x409cf7>>0x2;if(_0x4c7be1['push'](_0x59aaac),_0x2c276f!==0x40){const _0x539179=_0x409cf7<<0x6&0xc0|_0x2c276f;_0x4c7be1['push'](_0x539179);}}}return _0x4c7be1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xae829f=0x0;_0xae829f<this['ENCODED_VALS']['length'];_0xae829f++)this['byteToCharMap_'][_0xae829f]=this['ENCODED_VALS']['charAt'](_0xae829f),this['charToByteMap_'][this['byteToCharMap_'][_0xae829f]]=_0xae829f,this['byteToCharMapWebSafe_'][_0xae829f]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xae829f),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xae829f]]=_0xae829f,_0xae829f>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xae829f)]=_0xae829f,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xae829f)]=_0xae829f);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x5c5208){const _0x410501=Wr(_0x5c5208);return Di['encodeByteArray'](_0x410501,!0x0);},an=function(_0x195bf2){return Br(_0x195bf2)['replace'](/\./g,'');},cn=function(_0x712fb5){try{return Di['decodeString'](_0x712fb5,!0x0);}catch(_0x32d07c){console['error']('base64Decode\x20failed:\x20',_0x32d07c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x56ef1a){return Vr(void 0x0,_0x56ef1a);}function Vr(_0x56d270,_0x4964c7){if(!(_0x4964c7 instanceof Object))return _0x4964c7;switch(_0x4964c7['constructor']){case Date:const _0x292fc3=_0x4964c7;return new Date(_0x292fc3['getTime']());case Object:_0x56d270===void 0x0&&(_0x56d270={});break;case Array:_0x56d270=[];break;default:return _0x4964c7;}for(const _0x59138b in _0x4964c7)!_0x4964c7['hasOwnProperty'](_0x59138b)||!nc(_0x59138b)||(_0x56d270[_0x59138b]=Vr(_0x56d270[_0x59138b],_0x4964c7[_0x59138b]));return _0x56d270;}function nc(_0x163805){return _0x163805!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x10853d=As['__FIREBASE_DEFAULTS__'];if(_0x10853d)return JSON['parse'](_0x10853d);},oc=()=>{if(typeof document>'u')return;let _0x4434d1;try{_0x4434d1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x22704f=_0x4434d1&&cn(_0x4434d1[0x1]);return _0x22704f&&JSON['parse'](_0x22704f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x3f21d6){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3f21d6);return;}},Hr=_0x17fdd2=>{var _0x1813e4,_0x410bc2;return(_0x410bc2=(_0x1813e4=Mi())==null?void 0x0:_0x1813e4['emulatorHosts'])==null?void 0x0:_0x410bc2[_0x17fdd2];},ac=_0x30fc9d=>{const _0x221073=Hr(_0x30fc9d);if(!_0x221073)return;const _0x2ace39=_0x221073['lastIndexOf'](':');if(_0x2ace39<=0x0||_0x2ace39+0x1===_0x221073['length'])throw new Error('Invalid\x20host\x20'+_0x221073+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1a3c87=parseInt(_0x221073['substring'](_0x2ace39+0x1),0xa);return _0x221073[0x0]==='['?[_0x221073['substring'](0x1,_0x2ace39-0x1),_0x1a3c87]:[_0x221073['substring'](0x0,_0x2ace39),_0x1a3c87];},$r=()=>{var _0x5a41ff;return(_0x5a41ff=Mi())==null?void 0x0:_0x5a41ff['config'];},Gr=_0x43de1e=>{var _0x33bee6;return(_0x33bee6=Mi())==null?void 0x0:_0x33bee6['_'+_0x43de1e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4e8271,_0x51013b)=>{this['resolve']=_0x4e8271,this['reject']=_0x51013b;});}['wrapCallback'](_0x1ca8dc){return(_0x267a17,_0x59f1af)=>{_0x267a17?this['reject'](_0x267a17):this['resolve'](_0x59f1af),typeof _0x1ca8dc=='function'&&(this['promise']['catch'](()=>{}),_0x1ca8dc['length']===0x1?_0x1ca8dc(_0x267a17):_0x1ca8dc(_0x267a17,_0x59f1af));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3928b6,_0x28e49e){if(_0x3928b6['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5339cd={'alg':'none','type':'JWT'},_0x40cdc6=_0x28e49e||'demo-project',_0x23e9a9=_0x3928b6['iat']||0x0,_0x43725c=_0x3928b6['sub']||_0x3928b6['user_id'];if(!_0x43725c)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x58a2ac={'iss':'https://securetoken.google.com/'+_0x40cdc6,'aud':_0x40cdc6,'iat':_0x23e9a9,'exp':_0x23e9a9+0xe10,'auth_time':_0x23e9a9,'sub':_0x43725c,'user_id':_0x43725c,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3928b6};return[an(JSON['stringify'](_0x5339cd)),an(JSON['stringify'](_0x58a2ac)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x1b73e8=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1b73e8=='object'&&_0x1b73e8['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x2eda87=W();return _0x2eda87['indexOf']('MSIE\x20')>=0x0||_0x2eda87['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x3080b6,_0x4254d0)=>{try{let _0x4f08dc=!0x0;const _0x19a825='validate-browser-context-for-indexeddb-analytics-module',_0x3264a4=self['indexedDB']['open'](_0x19a825);_0x3264a4['onsuccess']=()=>{_0x3264a4['result']['close'](),_0x4f08dc||self['indexedDB']['deleteDatabase'](_0x19a825),_0x3080b6(!0x0);},_0x3264a4['onupgradeneeded']=()=>{_0x4f08dc=!0x1;},_0x3264a4['onerror']=()=>{var _0x3deb2c;_0x4254d0(((_0x3deb2c=_0x3264a4['error'])==null?void 0x0:_0x3deb2c['message'])||'');};}catch(_0x1ea089){_0x4254d0(_0x1ea089);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x29bbf9,_0x3d0700,_0x3a6fc3){super(_0x3d0700),this['code']=_0x29bbf9,this['customData']=_0x3a6fc3,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x58ca9b,_0x472976,_0x432c02){this['service']=_0x58ca9b,this['serviceName']=_0x472976,this['errors']=_0x432c02;}['create'](_0x5c30bf,..._0x69d2f2){const _0x2b3ad3=_0x69d2f2[0x0]||{},_0x24ec39=this['service']+'/'+_0x5c30bf,_0x19168d=this['errors'][_0x5c30bf],_0x2a873d=_0x19168d?gc(_0x19168d,_0x2b3ad3):'Error',_0x538c75=this['serviceName']+':\x20'+_0x2a873d+'\x20('+_0x24ec39+').';return new Se(_0x24ec39,_0x538c75,_0x2b3ad3);}}function gc(_0x5d8c39,_0x2b6ccf){return _0x5d8c39['replace'](mc,(_0x465cdd,_0x28caa2)=>{const _0x55eed1=_0x2b6ccf[_0x28caa2];return _0x55eed1!=null?String(_0x55eed1):'<'+_0x28caa2+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x9dc9d9){return JSON['parse'](_0x9dc9d9);}function O(_0x1f9dd1){return JSON['stringify'](_0x1f9dd1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x10a260){let _0x5c77ef={},_0x50e794={},_0x5a4d5b={},_0x39b81a='';try{const _0xc60bc2=_0x10a260['split']('.');_0x5c77ef=bt(cn(_0xc60bc2[0x0])||''),_0x50e794=bt(cn(_0xc60bc2[0x1])||''),_0x39b81a=_0xc60bc2[0x2],_0x5a4d5b=_0x50e794['d']||{},delete _0x50e794['d'];}catch{}return{'header':_0x5c77ef,'claims':_0x50e794,'data':_0x5a4d5b,'signature':_0x39b81a};},yc=function(_0x5f5a51){const _0x187261=zr(_0x5f5a51),_0x5d08df=_0x187261['claims'];return!!_0x5d08df&&typeof _0x5d08df=='object'&&_0x5d08df['hasOwnProperty']('iat');},vc=function(_0x4a2ed2){const _0x109f42=zr(_0x4a2ed2)['claims'];return typeof _0x109f42=='object'&&_0x109f42['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4d3ca1,_0x58058a){return Object['prototype']['hasOwnProperty']['call'](_0x4d3ca1,_0x58058a);}function Oe(_0x44c0a2,_0x65dc9b){if(Object['prototype']['hasOwnProperty']['call'](_0x44c0a2,_0x65dc9b))return _0x44c0a2[_0x65dc9b];}function hi(_0xa89d96){for(const _0x592b01 in _0xa89d96)if(Object['prototype']['hasOwnProperty']['call'](_0xa89d96,_0x592b01))return!0x1;return!0x0;}function ln(_0x13704e,_0x3e4ba8,_0x163fa7){const _0x1f3f8d={};for(const _0x18270f in _0x13704e)Object['prototype']['hasOwnProperty']['call'](_0x13704e,_0x18270f)&&(_0x1f3f8d[_0x18270f]=_0x3e4ba8['call'](_0x163fa7,_0x13704e[_0x18270f],_0x18270f,_0x13704e));return _0x1f3f8d;}function De(_0x2de420,_0x4a58df){if(_0x2de420===_0x4a58df)return!0x0;const _0x472da8=Object['keys'](_0x2de420),_0x5c26ec=Object['keys'](_0x4a58df);for(const _0x55cac0 of _0x472da8){if(!_0x5c26ec['includes'](_0x55cac0))return!0x1;const _0x3496cb=_0x2de420[_0x55cac0],_0x49d497=_0x4a58df[_0x55cac0];if(ks(_0x3496cb)&&ks(_0x49d497)){if(!De(_0x3496cb,_0x49d497))return!0x1;}else{if(_0x3496cb!==_0x49d497)return!0x1;}}for(const _0x6504c of _0x5c26ec)if(!_0x472da8['includes'](_0x6504c))return!0x1;return!0x0;}function ks(_0x5a2bcd){return _0x5a2bcd!==null&&typeof _0x5a2bcd=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x327e60){const _0x404dd2=[];for(const [_0x2d15fb,_0x8cd322]of Object['entries'](_0x327e60))Array['isArray'](_0x8cd322)?_0x8cd322['forEach'](_0x5bea8b=>{_0x404dd2['push'](encodeURIComponent(_0x2d15fb)+'='+encodeURIComponent(_0x5bea8b));}):_0x404dd2['push'](encodeURIComponent(_0x2d15fb)+'='+encodeURIComponent(_0x8cd322));return _0x404dd2['length']?'&'+_0x404dd2['join']('&'):'';}function yt(_0x2050a9){const _0x3120b5={};return _0x2050a9['replace'](/^\?/,'')['split']('&')['forEach'](_0x263cbf=>{if(_0x263cbf){const [_0x88ddce,_0x4c6d06]=_0x263cbf['split']('=');_0x3120b5[decodeURIComponent(_0x88ddce)]=decodeURIComponent(_0x4c6d06);}}),_0x3120b5;}function vt(_0x111561){const _0x375cdc=_0x111561['indexOf']('?');if(!_0x375cdc)return'';const _0x23cc23=_0x111561['indexOf']('#',_0x375cdc);return _0x111561['substring'](_0x375cdc,_0x23cc23>0x0?_0x23cc23:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x19af8b=0x1;_0x19af8b<this['blockSize'];++_0x19af8b)this['pad_'][_0x19af8b]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x16a535,_0x1a3d0d){_0x1a3d0d||(_0x1a3d0d=0x0);const _0x147c4d=this['W_'];if(typeof _0x16a535=='string'){for(let _0x15a01a=0x0;_0x15a01a<0x10;_0x15a01a++)_0x147c4d[_0x15a01a]=_0x16a535['charCodeAt'](_0x1a3d0d)<<0x18|_0x16a535['charCodeAt'](_0x1a3d0d+0x1)<<0x10|_0x16a535['charCodeAt'](_0x1a3d0d+0x2)<<0x8|_0x16a535['charCodeAt'](_0x1a3d0d+0x3),_0x1a3d0d+=0x4;}else{for(let _0x5eb9d4=0x0;_0x5eb9d4<0x10;_0x5eb9d4++)_0x147c4d[_0x5eb9d4]=_0x16a535[_0x1a3d0d]<<0x18|_0x16a535[_0x1a3d0d+0x1]<<0x10|_0x16a535[_0x1a3d0d+0x2]<<0x8|_0x16a535[_0x1a3d0d+0x3],_0x1a3d0d+=0x4;}for(let _0x15ee63=0x10;_0x15ee63<0x50;_0x15ee63++){const _0x41537e=_0x147c4d[_0x15ee63-0x3]^_0x147c4d[_0x15ee63-0x8]^_0x147c4d[_0x15ee63-0xe]^_0x147c4d[_0x15ee63-0x10];_0x147c4d[_0x15ee63]=(_0x41537e<<0x1|_0x41537e>>>0x1f)&0xffffffff;}let _0xd634dc=this['chain_'][0x0],_0x215b23=this['chain_'][0x1],_0x2a3130=this['chain_'][0x2],_0x357bab=this['chain_'][0x3],_0x5ce95a=this['chain_'][0x4],_0x1b9454,_0x458dc4;for(let _0x3bd7f2=0x0;_0x3bd7f2<0x50;_0x3bd7f2++){_0x3bd7f2<0x28?_0x3bd7f2<0x14?(_0x1b9454=_0x357bab^_0x215b23&(_0x2a3130^_0x357bab),_0x458dc4=0x5a827999):(_0x1b9454=_0x215b23^_0x2a3130^_0x357bab,_0x458dc4=0x6ed9eba1):_0x3bd7f2<0x3c?(_0x1b9454=_0x215b23&_0x2a3130|_0x357bab&(_0x215b23|_0x2a3130),_0x458dc4=0x8f1bbcdc):(_0x1b9454=_0x215b23^_0x2a3130^_0x357bab,_0x458dc4=0xca62c1d6);const _0x3544af=(_0xd634dc<<0x5|_0xd634dc>>>0x1b)+_0x1b9454+_0x5ce95a+_0x458dc4+_0x147c4d[_0x3bd7f2]&0xffffffff;_0x5ce95a=_0x357bab,_0x357bab=_0x2a3130,_0x2a3130=(_0x215b23<<0x1e|_0x215b23>>>0x2)&0xffffffff,_0x215b23=_0xd634dc,_0xd634dc=_0x3544af;}this['chain_'][0x0]=this['chain_'][0x0]+_0xd634dc&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x215b23&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2a3130&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x357bab&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5ce95a&0xffffffff;}['update'](_0x494466,_0x2a5b13){if(_0x494466==null)return;_0x2a5b13===void 0x0&&(_0x2a5b13=_0x494466['length']);const _0x30435a=_0x2a5b13-this['blockSize'];let _0x268466=0x0;const _0x35ae30=this['buf_'];let _0x52fe0d=this['inbuf_'];for(;_0x268466<_0x2a5b13;){if(_0x52fe0d===0x0){for(;_0x268466<=_0x30435a;)this['compress_'](_0x494466,_0x268466),_0x268466+=this['blockSize'];}if(typeof _0x494466=='string'){for(;_0x268466<_0x2a5b13;)if(_0x35ae30[_0x52fe0d]=_0x494466['charCodeAt'](_0x268466),++_0x52fe0d,++_0x268466,_0x52fe0d===this['blockSize']){this['compress_'](_0x35ae30),_0x52fe0d=0x0;break;}}else{for(;_0x268466<_0x2a5b13;)if(_0x35ae30[_0x52fe0d]=_0x494466[_0x268466],++_0x52fe0d,++_0x268466,_0x52fe0d===this['blockSize']){this['compress_'](_0x35ae30),_0x52fe0d=0x0;break;}}}this['inbuf_']=_0x52fe0d,this['total_']+=_0x2a5b13;}['digest'](){const _0x4a92da=[];let _0xff2739=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2a0d0a=this['blockSize']-0x1;_0x2a0d0a>=0x38;_0x2a0d0a--)this['buf_'][_0x2a0d0a]=_0xff2739&0xff,_0xff2739/=0x100;this['compress_'](this['buf_']);let _0x3b9e1b=0x0;for(let _0x4c7178=0x0;_0x4c7178<0x5;_0x4c7178++)for(let _0x2928d0=0x18;_0x2928d0>=0x0;_0x2928d0-=0x8)_0x4a92da[_0x3b9e1b]=this['chain_'][_0x4c7178]>>_0x2928d0&0xff,++_0x3b9e1b;return _0x4a92da;}}function Ic(_0x1eb1a4,_0x4c6b48){const _0x246c76=new wc(_0x1eb1a4,_0x4c6b48);return _0x246c76['subscribe']['bind'](_0x246c76);}class wc{constructor(_0x4067c1,_0x24c873){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x24c873,this['task']['then'](()=>{_0x4067c1(this);})['catch'](_0x3e709e=>{this['error'](_0x3e709e);});}['next'](_0x3e5119){this['forEachObserver'](_0x10a285=>{_0x10a285['next'](_0x3e5119);});}['error'](_0x37dd4b){this['forEachObserver'](_0x42bfb6=>{_0x42bfb6['error'](_0x37dd4b);}),this['close'](_0x37dd4b);}['complete'](){this['forEachObserver'](_0x5427a0=>{_0x5427a0['complete']();}),this['close']();}['subscribe'](_0x161b03,_0x521ba4,_0x150d44){let _0x39b705;if(_0x161b03===void 0x0&&_0x521ba4===void 0x0&&_0x150d44===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x161b03,['next','error','complete'])?_0x39b705=_0x161b03:_0x39b705={'next':_0x161b03,'error':_0x521ba4,'complete':_0x150d44},_0x39b705['next']===void 0x0&&(_0x39b705['next']=Qn),_0x39b705['error']===void 0x0&&(_0x39b705['error']=Qn),_0x39b705['complete']===void 0x0&&(_0x39b705['complete']=Qn);const _0x5839ac=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x39b705['error'](this['finalError']):_0x39b705['complete']();}catch{}}),this['observers']['push'](_0x39b705),_0x5839ac;}['unsubscribeOne'](_0xbce437){this['observers']===void 0x0||this['observers'][_0xbce437]===void 0x0||(delete this['observers'][_0xbce437],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0xcd9a98){if(!this['finalized']){for(let _0x563486=0x0;_0x563486<this['observers']['length'];_0x563486++)this['sendOne'](_0x563486,_0xcd9a98);}}['sendOne'](_0x5d6b8c,_0x22d063){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5d6b8c]!==void 0x0)try{_0x22d063(this['observers'][_0x5d6b8c]);}catch(_0x80a554){typeof console<'u'&&console['error']&&console['error'](_0x80a554);}});}['close'](_0x2ac860){this['finalized']||(this['finalized']=!0x0,_0x2ac860!==void 0x0&&(this['finalError']=_0x2ac860),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x13ec62,_0x1216ba){if(typeof _0x13ec62!='object'||_0x13ec62===null)return!0x1;for(const _0x3a7d47 of _0x1216ba)if(_0x3a7d47 in _0x13ec62&&typeof _0x13ec62[_0x3a7d47]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x40fb87,_0x381cb5){return _0x40fb87+'\x20failed:\x20'+_0x381cb5+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x36110d){const _0x528421=[];let _0x3ab8c9=0x0;for(let _0x38f3d6=0x0;_0x38f3d6<_0x36110d['length'];_0x38f3d6++){let _0x23154f=_0x36110d['charCodeAt'](_0x38f3d6);if(_0x23154f>=0xd800&&_0x23154f<=0xdbff){const _0x51d988=_0x23154f-0xd800;_0x38f3d6++,f(_0x38f3d6<_0x36110d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2efd5c=_0x36110d['charCodeAt'](_0x38f3d6)-0xdc00;_0x23154f=0x10000+(_0x51d988<<0xa)+_0x2efd5c;}_0x23154f<0x80?_0x528421[_0x3ab8c9++]=_0x23154f:_0x23154f<0x800?(_0x528421[_0x3ab8c9++]=_0x23154f>>0x6|0xc0,_0x528421[_0x3ab8c9++]=_0x23154f&0x3f|0x80):_0x23154f<0x10000?(_0x528421[_0x3ab8c9++]=_0x23154f>>0xc|0xe0,_0x528421[_0x3ab8c9++]=_0x23154f>>0x6&0x3f|0x80,_0x528421[_0x3ab8c9++]=_0x23154f&0x3f|0x80):(_0x528421[_0x3ab8c9++]=_0x23154f>>0x12|0xf0,_0x528421[_0x3ab8c9++]=_0x23154f>>0xc&0x3f|0x80,_0x528421[_0x3ab8c9++]=_0x23154f>>0x6&0x3f|0x80,_0x528421[_0x3ab8c9++]=_0x23154f&0x3f|0x80);}return _0x528421;},Pn=function(_0x7232b9){let _0x27c534=0x0;for(let _0x32ce40=0x0;_0x32ce40<_0x7232b9['length'];_0x32ce40++){const _0x2c5120=_0x7232b9['charCodeAt'](_0x32ce40);_0x2c5120<0x80?_0x27c534++:_0x2c5120<0x800?_0x27c534+=0x2:_0x2c5120>=0xd800&&_0x2c5120<=0xdbff?(_0x27c534+=0x4,_0x32ce40++):_0x27c534+=0x3;}return _0x27c534;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x361fe9){return _0x361fe9&&_0x361fe9['_delegate']?_0x361fe9['_delegate']:_0x361fe9;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x33d332){try{return(_0x33d332['startsWith']('http://')||_0x33d332['startsWith']('https://')?new URL(_0x33d332)['hostname']:_0x33d332)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x21d2ca){return(await fetch(_0x21d2ca,{'credentials':'include'}))['ok'];}class Me{constructor(_0xa4804e,_0x4d4062,_0x3dedc0){this['name']=_0xa4804e,this['instanceFactory']=_0x4d4062,this['type']=_0x3dedc0,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3de137){return this['instantiationMode']=_0x3de137,this;}['setMultipleInstances'](_0x59ad55){return this['multipleInstances']=_0x59ad55,this;}['setServiceProps'](_0x39b374){return this['serviceProps']=_0x39b374,this;}['setInstanceCreatedCallback'](_0x2c741e){return this['onInstanceCreated']=_0x2c741e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x3704e2,_0xcf0faa){this['name']=_0x3704e2,this['container']=_0xcf0faa,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2d0a80){const _0x39a9ea=this['normalizeInstanceIdentifier'](_0x2d0a80);if(!this['instancesDeferred']['has'](_0x39a9ea)){const _0x141247=new Ve();if(this['instancesDeferred']['set'](_0x39a9ea,_0x141247),this['isInitialized'](_0x39a9ea)||this['shouldAutoInitialize']())try{const _0x4cd2b3=this['getOrInitializeService']({'instanceIdentifier':_0x39a9ea});_0x4cd2b3&&_0x141247['resolve'](_0x4cd2b3);}catch{}}return this['instancesDeferred']['get'](_0x39a9ea)['promise'];}['getImmediate'](_0x13b947){const _0xf92a1e=this['normalizeInstanceIdentifier'](_0x13b947==null?void 0x0:_0x13b947['identifier']),_0x49a1e3=(_0x13b947==null?void 0x0:_0x13b947['optional'])??!0x1;if(this['isInitialized'](_0xf92a1e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xf92a1e});}catch(_0x41286b){if(_0x49a1e3)return null;throw _0x41286b;}else{if(_0x49a1e3)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4da9d6){if(_0x4da9d6['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4da9d6['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4da9d6,!!this['shouldAutoInitialize']()){if(Rc(_0x4da9d6))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x65b713,_0x9aec19]of this['instancesDeferred']['entries']()){const _0x959c6c=this['normalizeInstanceIdentifier'](_0x65b713);try{const _0x36badf=this['getOrInitializeService']({'instanceIdentifier':_0x959c6c});_0x9aec19['resolve'](_0x36badf);}catch{}}}}['clearInstance'](_0x16dbcf=ke){this['instancesDeferred']['delete'](_0x16dbcf),this['instancesOptions']['delete'](_0x16dbcf),this['instances']['delete'](_0x16dbcf);}async['delete'](){const _0x5d04ea=Array['from'](this['instances']['values']());await Promise['all']([..._0x5d04ea['filter'](_0x52dad4=>'INTERNAL'in _0x52dad4)['map'](_0x4fa651=>_0x4fa651['INTERNAL']['delete']()),..._0x5d04ea['filter'](_0x204926=>'_delete'in _0x204926)['map'](_0x38b079=>_0x38b079['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5bcfa4=ke){return this['instances']['has'](_0x5bcfa4);}['getOptions'](_0x4927b3=ke){return this['instancesOptions']['get'](_0x4927b3)||{};}['initialize'](_0x5132db={}){const {options:_0x184d1b={}}=_0x5132db,_0x5995f3=this['normalizeInstanceIdentifier'](_0x5132db['instanceIdentifier']);if(this['isInitialized'](_0x5995f3))throw Error(this['name']+'('+_0x5995f3+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x39739e=this['getOrInitializeService']({'instanceIdentifier':_0x5995f3,'options':_0x184d1b});for(const [_0x58a9b6,_0x215efb]of this['instancesDeferred']['entries']()){const _0x297260=this['normalizeInstanceIdentifier'](_0x58a9b6);_0x5995f3===_0x297260&&_0x215efb['resolve'](_0x39739e);}return _0x39739e;}['onInit'](_0x1d8c51,_0x21aaad){const _0x4e8142=this['normalizeInstanceIdentifier'](_0x21aaad),_0x587a68=this['onInitCallbacks']['get'](_0x4e8142)??new Set();_0x587a68['add'](_0x1d8c51),this['onInitCallbacks']['set'](_0x4e8142,_0x587a68);const _0x490f77=this['instances']['get'](_0x4e8142);return _0x490f77&&_0x1d8c51(_0x490f77,_0x4e8142),()=>{_0x587a68['delete'](_0x1d8c51);};}['invokeOnInitCallbacks'](_0x33f96f,_0x310f9c){const _0x3f1006=this['onInitCallbacks']['get'](_0x310f9c);if(_0x3f1006){for(const _0x40ad36 of _0x3f1006)try{_0x40ad36(_0x33f96f,_0x310f9c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5bca89,options:_0x3f0650={}}){let _0x4aa336=this['instances']['get'](_0x5bca89);if(!_0x4aa336&&this['component']&&(_0x4aa336=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5bca89),'options':_0x3f0650}),this['instances']['set'](_0x5bca89,_0x4aa336),this['instancesOptions']['set'](_0x5bca89,_0x3f0650),this['invokeOnInitCallbacks'](_0x4aa336,_0x5bca89),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5bca89,_0x4aa336);}catch{}return _0x4aa336||null;}['normalizeInstanceIdentifier'](_0x1392a9=ke){return this['component']?this['component']['multipleInstances']?_0x1392a9:ke:_0x1392a9;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x243d57){return _0x243d57===ke?void 0x0:_0x243d57;}function Rc(_0x468c15){return _0x468c15['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xc07ad8){this['name']=_0xc07ad8,this['providers']=new Map();}['addComponent'](_0x2ee751){const _0x419a67=this['getProvider'](_0x2ee751['name']);if(_0x419a67['isComponentSet']())throw new Error('Component\x20'+_0x2ee751['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x419a67['setComponent'](_0x2ee751);}['addOrOverwriteComponent'](_0x4b4ba8){this['getProvider'](_0x4b4ba8['name'])['isComponentSet']()&&this['providers']['delete'](_0x4b4ba8['name']),this['addComponent'](_0x4b4ba8);}['getProvider'](_0x402f7c){if(this['providers']['has'](_0x402f7c))return this['providers']['get'](_0x402f7c);const _0x2c07f6=new Sc(_0x402f7c,this);return this['providers']['set'](_0x402f7c,_0x2c07f6),_0x2c07f6;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xb0245e){_0xb0245e[_0xb0245e['DEBUG']=0x0]='DEBUG',_0xb0245e[_0xb0245e['VERBOSE']=0x1]='VERBOSE',_0xb0245e[_0xb0245e['INFO']=0x2]='INFO',_0xb0245e[_0xb0245e['WARN']=0x3]='WARN',_0xb0245e[_0xb0245e['ERROR']=0x4]='ERROR',_0xb0245e[_0xb0245e['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x3fe8b2,_0x527f16,..._0x238d35)=>{if(_0x527f16<_0x3fe8b2['logLevel'])return;const _0x41dedb=new Date()['toISOString'](),_0x27bdfe=Pc[_0x527f16];if(_0x27bdfe)console[_0x27bdfe]('['+_0x41dedb+']\x20\x20'+_0x3fe8b2['name']+':',..._0x238d35);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x527f16+')');};class xi{constructor(_0x48b835){this['name']=_0x48b835,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x34639d){if(!(_0x34639d in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x34639d+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x34639d;}['setLogLevel'](_0xda1b76){this['_logLevel']=typeof _0xda1b76=='string'?kc[_0xda1b76]:_0xda1b76;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x295873){if(typeof _0x295873!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x295873;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0xbb74d8){this['_userLogHandler']=_0xbb74d8;}['debug'](..._0x16e62b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x16e62b),this['_logHandler'](this,T['DEBUG'],..._0x16e62b);}['log'](..._0x2dd8cf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2dd8cf),this['_logHandler'](this,T['VERBOSE'],..._0x2dd8cf);}['info'](..._0xa3e417){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xa3e417),this['_logHandler'](this,T['INFO'],..._0xa3e417);}['warn'](..._0x376fe5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x376fe5),this['_logHandler'](this,T['WARN'],..._0x376fe5);}['error'](..._0x4e1f76){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4e1f76),this['_logHandler'](this,T['ERROR'],..._0x4e1f76);}}const Dc=(_0x5dc60d,_0x400470)=>_0x400470['some'](_0x5580c3=>_0x5dc60d instanceof _0x5580c3);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x360744){const _0x2d3594=new Promise((_0x5c3d28,_0x24c8c3)=>{const _0x34948a=()=>{_0x360744['removeEventListener']('success',_0x3c5a77),_0x360744['removeEventListener']('error',_0x5bb0de);},_0x3c5a77=()=>{_0x5c3d28(_e(_0x360744['result'])),_0x34948a();},_0x5bb0de=()=>{_0x24c8c3(_0x360744['error']),_0x34948a();};_0x360744['addEventListener']('success',_0x3c5a77),_0x360744['addEventListener']('error',_0x5bb0de);});return _0x2d3594['then'](_0x29eef5=>{_0x29eef5 instanceof IDBCursor&&Kr['set'](_0x29eef5,_0x360744);})['catch'](()=>{}),Fi['set'](_0x2d3594,_0x360744),_0x2d3594;}function Fc(_0x4d8c10){if(ui['has'](_0x4d8c10))return;const _0x4393af=new Promise((_0x21b260,_0x58cbe0)=>{const _0x4d85a7=()=>{_0x4d8c10['removeEventListener']('complete',_0xf747aa),_0x4d8c10['removeEventListener']('error',_0x2a7986),_0x4d8c10['removeEventListener']('abort',_0x2a7986);},_0xf747aa=()=>{_0x21b260(),_0x4d85a7();},_0x2a7986=()=>{_0x58cbe0(_0x4d8c10['error']||new DOMException('AbortError','AbortError')),_0x4d85a7();};_0x4d8c10['addEventListener']('complete',_0xf747aa),_0x4d8c10['addEventListener']('error',_0x2a7986),_0x4d8c10['addEventListener']('abort',_0x2a7986);});ui['set'](_0x4d8c10,_0x4393af);}let di={'get'(_0x371d46,_0x284aa7,_0x451cbb){if(_0x371d46 instanceof IDBTransaction){if(_0x284aa7==='done')return ui['get'](_0x371d46);if(_0x284aa7==='objectStoreNames')return _0x371d46['objectStoreNames']||Yr['get'](_0x371d46);if(_0x284aa7==='store')return _0x451cbb['objectStoreNames'][0x1]?void 0x0:_0x451cbb['objectStore'](_0x451cbb['objectStoreNames'][0x0]);}return _e(_0x371d46[_0x284aa7]);},'set'(_0x5db19c,_0x1bd29a,_0x4d3e1d){return _0x5db19c[_0x1bd29a]=_0x4d3e1d,!0x0;},'has'(_0x181f11,_0x257879){return _0x181f11 instanceof IDBTransaction&&(_0x257879==='done'||_0x257879==='store')?!0x0:_0x257879 in _0x181f11;}};function Uc(_0x1a3bd5){di=_0x1a3bd5(di);}function Wc(_0x190473){return _0x190473===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x58197c,..._0x2dd1ba){const _0x489ed3=_0x190473['call'](Xn(this),_0x58197c,..._0x2dd1ba);return Yr['set'](_0x489ed3,_0x58197c['sort']?_0x58197c['sort']():[_0x58197c]),_e(_0x489ed3);}:Lc()['includes'](_0x190473)?function(..._0x310d55){return _0x190473['apply'](Xn(this),_0x310d55),_e(Kr['get'](this));}:function(..._0x1c6925){return _e(_0x190473['apply'](Xn(this),_0x1c6925));};}function Bc(_0x361b68){return typeof _0x361b68=='function'?Wc(_0x361b68):(_0x361b68 instanceof IDBTransaction&&Fc(_0x361b68),Dc(_0x361b68,Mc())?new Proxy(_0x361b68,di):_0x361b68);}function _e(_0x1f7a0a){if(_0x1f7a0a instanceof IDBRequest)return xc(_0x1f7a0a);if(Jn['has'](_0x1f7a0a))return Jn['get'](_0x1f7a0a);const _0x284875=Bc(_0x1f7a0a);return _0x284875!==_0x1f7a0a&&(Jn['set'](_0x1f7a0a,_0x284875),Fi['set'](_0x284875,_0x1f7a0a)),_0x284875;}const Xn=_0xd13b52=>Fi['get'](_0xd13b52);function Vc(_0x1fabfa,_0x28ad5a,{blocked:_0x280fbf,upgrade:_0x12f57f,blocking:_0x32e4ca,terminated:_0x1d8b7d}={}){const _0x334b69=indexedDB['open'](_0x1fabfa,_0x28ad5a),_0x418f41=_e(_0x334b69);return _0x12f57f&&_0x334b69['addEventListener']('upgradeneeded',_0x2c2000=>{_0x12f57f(_e(_0x334b69['result']),_0x2c2000['oldVersion'],_0x2c2000['newVersion'],_e(_0x334b69['transaction']),_0x2c2000);}),_0x280fbf&&_0x334b69['addEventListener']('blocked',_0x51dab8=>_0x280fbf(_0x51dab8['oldVersion'],_0x51dab8['newVersion'],_0x51dab8)),_0x418f41['then'](_0x190c2f=>{_0x1d8b7d&&_0x190c2f['addEventListener']('close',()=>_0x1d8b7d()),_0x32e4ca&&_0x190c2f['addEventListener']('versionchange',_0xd29567=>_0x32e4ca(_0xd29567['oldVersion'],_0xd29567['newVersion'],_0xd29567));})['catch'](()=>{}),_0x418f41;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x244870,_0xf0e18a){if(!(_0x244870 instanceof IDBDatabase&&!(_0xf0e18a in _0x244870)&&typeof _0xf0e18a=='string'))return;if(Zn['get'](_0xf0e18a))return Zn['get'](_0xf0e18a);const _0x3866c2=_0xf0e18a['replace'](/FromIndex$/,''),_0x1ae89e=_0xf0e18a!==_0x3866c2,_0x9463c0=$c['includes'](_0x3866c2);if(!(_0x3866c2 in(_0x1ae89e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x9463c0||Hc['includes'](_0x3866c2)))return;const _0x4c9122=async function(_0x21cb08,..._0xa2038f){const _0x21d49a=this['transaction'](_0x21cb08,_0x9463c0?'readwrite':'readonly');let _0x39a396=_0x21d49a['store'];return _0x1ae89e&&(_0x39a396=_0x39a396['index'](_0xa2038f['shift']())),(await Promise['all']([_0x39a396[_0x3866c2](..._0xa2038f),_0x9463c0&&_0x21d49a['done']]))[0x0];};return Zn['set'](_0xf0e18a,_0x4c9122),_0x4c9122;}Uc(_0x18d826=>({..._0x18d826,'get':(_0x4018c5,_0x924e2a,_0x1c0050)=>Os(_0x4018c5,_0x924e2a)||_0x18d826['get'](_0x4018c5,_0x924e2a,_0x1c0050),'has':(_0x51db84,_0x4b48d7)=>!!Os(_0x51db84,_0x4b48d7)||_0x18d826['has'](_0x51db84,_0x4b48d7)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x9fa08d){this['container']=_0x9fa08d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x232f3d=>{if(qc(_0x232f3d)){const _0x24acc8=_0x232f3d['getImmediate']();return _0x24acc8['library']+'/'+_0x24acc8['version'];}else return null;})['filter'](_0x345c4c=>_0x345c4c)['join']('\x20');}}function qc(_0x3b8cb2){const _0x1ce3b9=_0x3b8cb2['getComponent']();return(_0x1ce3b9==null?void 0x0:_0x1ce3b9['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x335b09,_0x33e946){try{_0x335b09['container']['addComponent'](_0x33e946);}catch(_0x2529b8){re['debug']('Component\x20'+_0x33e946['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x335b09['name'],_0x2529b8);}}function et(_0xea3f29){const _0x13f099=_0xea3f29['name'];if(gi['has'](_0x13f099))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x13f099+'.'),!0x1;gi['set'](_0x13f099,_0xea3f29);for(const _0x4d20b8 of Le['values']())Ms(_0x4d20b8,_0xea3f29);for(const _0x5c7409 of _i['values']())Ms(_0x5c7409,_0xea3f29);return!0x0;}function Ui(_0x29bea6,_0x525699){const _0x3fee25=_0x29bea6['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3fee25&&_0x3fee25['triggerHeartbeat'](),_0x29bea6['container']['getProvider'](_0x525699);}function H(_0x4ad0e5){return _0x4ad0e5==null?!0x1:_0x4ad0e5['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x10b214,_0x271216,_0x4ca548){this['_isDeleted']=!0x1,this['_options']={..._0x10b214},this['_config']={..._0x271216},this['_name']=_0x271216['name'],this['_automaticDataCollectionEnabled']=_0x271216['automaticDataCollectionEnabled'],this['_container']=_0x4ca548,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1560b2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1560b2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x45f989){this['_isDeleted']=_0x45f989;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x491763,_0x404c9d={}){let _0x2612d7=_0x491763;typeof _0x404c9d!='object'&&(_0x404c9d={'name':_0x404c9d});const _0x10f42a={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x404c9d},_0x546964=_0x10f42a['name'];if(typeof _0x546964!='string'||!_0x546964)throw ge['create']('bad-app-name',{'appName':String(_0x546964)});if(_0x2612d7||(_0x2612d7=$r()),!_0x2612d7)throw ge['create']('no-options');const _0x180e45=Le['get'](_0x546964);if(_0x180e45){if(De(_0x2612d7,_0x180e45['options'])&&De(_0x10f42a,_0x180e45['config']))return _0x180e45;throw ge['create']('duplicate-app',{'appName':_0x546964});}const _0x5dbc55=new Ac(_0x546964);for(const _0x397e12 of gi['values']())_0x5dbc55['addComponent'](_0x397e12);const _0x1d9e33=new Il(_0x2612d7,_0x10f42a,_0x5dbc55);return Le['set'](_0x546964,_0x1d9e33),_0x1d9e33;}function Qr(_0x3a9598=pi){const _0x31c32d=Le['get'](_0x3a9598);if(!_0x31c32d&&_0x3a9598===pi&&$r())return wl();if(!_0x31c32d)throw ge['create']('no-app',{'appName':_0x3a9598});return _0x31c32d;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3bf3c5){let _0x296436=!0x1;const _0x1f9487=_0x3bf3c5['name'];Le['has'](_0x1f9487)?(_0x296436=!0x0,Le['delete'](_0x1f9487)):_i['has'](_0x1f9487)&&_0x3bf3c5['decRefCount']()<=0x0&&(_i['delete'](_0x1f9487),_0x296436=!0x0),_0x296436&&(await Promise['all'](_0x3bf3c5['container']['getProviders']()['map'](_0x1407dc=>_0x1407dc['delete']())),_0x3bf3c5['isDeleted']=!0x0);}function me(_0x38eea9,_0xcfe93a,_0x16b898){let _0x4d4f1e=vl[_0x38eea9]??_0x38eea9;_0x16b898&&(_0x4d4f1e+='-'+_0x16b898);const _0x16ddb9=_0x4d4f1e['match'](/\s|\//),_0x4e7433=_0xcfe93a['match'](/\s|\//);if(_0x16ddb9||_0x4e7433){const _0x348c8b=['Unable\x20to\x20register\x20library\x20\x22'+_0x4d4f1e+'\x22\x20with\x20version\x20\x22'+_0xcfe93a+'\x22:'];_0x16ddb9&&_0x348c8b['push']('library\x20name\x20\x22'+_0x4d4f1e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x16ddb9&&_0x4e7433&&_0x348c8b['push']('and'),_0x4e7433&&_0x348c8b['push']('version\x20name\x20\x22'+_0xcfe93a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x348c8b['join']('\x20'));return;}et(new Me(_0x4d4f1e+'-version',()=>({'library':_0x4d4f1e,'version':_0xcfe93a}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x397195,_0x4b153c)=>{switch(_0x4b153c){case 0x0:try{_0x397195['createObjectStore'](Rt);}catch(_0x28950a){console['warn'](_0x28950a);}}}})['catch'](_0x5221aa=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x5221aa['message']});})),ei;}async function Sl(_0x1545dc){try{const _0x3ef021=(await Jr())['transaction'](Rt),_0x306299=await _0x3ef021['objectStore'](Rt)['get'](Xr(_0x1545dc));return await _0x3ef021['done'],_0x306299;}catch(_0x47cc76){if(_0x47cc76 instanceof Se)re['warn'](_0x47cc76['message']);else{const _0x5e41b5=ge['create']('idb-get',{'originalErrorMessage':_0x47cc76==null?void 0x0:_0x47cc76['message']});re['warn'](_0x5e41b5['message']);}}}async function Ls(_0x21b301,_0x5eff79){try{const _0x11340c=(await Jr())['transaction'](Rt,'readwrite');await _0x11340c['objectStore'](Rt)['put'](_0x5eff79,Xr(_0x21b301)),await _0x11340c['done'];}catch(_0x5d8ed7){if(_0x5d8ed7 instanceof Se)re['warn'](_0x5d8ed7['message']);else{const _0x57ad58=ge['create']('idb-set',{'originalErrorMessage':_0x5d8ed7==null?void 0x0:_0x5d8ed7['message']});re['warn'](_0x57ad58['message']);}}}function Xr(_0x3a2e75){return _0x3a2e75['name']+'!'+_0x3a2e75['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x1cfccc){this['container']=_0x1cfccc,this['_heartbeatsCache']=null;const _0x292ff9=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x292ff9),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3ab61f=>(this['_heartbeatsCache']=_0x3ab61f,_0x3ab61f));}async['triggerHeartbeat'](){var _0x52946e,_0x4e8e02;try{const _0x155dbd=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xaff76e=xs();if(((_0x52946e=this['_heartbeatsCache'])==null?void 0x0:_0x52946e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4e8e02=this['_heartbeatsCache'])==null?void 0x0:_0x4e8e02['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xaff76e||this['_heartbeatsCache']['heartbeats']['some'](_0x9b96ab=>_0x9b96ab['date']===_0xaff76e))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xaff76e,'agent':_0x155dbd}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x15d6af=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x15d6af,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x46f09e){re['warn'](_0x46f09e);}}async['getHeartbeatsHeader'](){var _0x30728b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x30728b=this['_heartbeatsCache'])==null?void 0x0:_0x30728b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xbdbfad=xs(),{heartbeatsToSend:_0x8de0b3,unsentEntries:_0x5a1626}=kl(this['_heartbeatsCache']['heartbeats']),_0x488272=an(JSON['stringify']({'version':0x2,'heartbeats':_0x8de0b3}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xbdbfad,_0x5a1626['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5a1626,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x488272;}catch(_0x1a660e){return re['warn'](_0x1a660e),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x3dcf9c,_0x432f9b=bl){const _0x48450e=[];let _0x15b993=_0x3dcf9c['slice']();for(const _0x5f161b of _0x3dcf9c){const _0x356bda=_0x48450e['find'](_0x4f02a1=>_0x4f02a1['agent']===_0x5f161b['agent']);if(_0x356bda){if(_0x356bda['dates']['push'](_0x5f161b['date']),Fs(_0x48450e)>_0x432f9b){_0x356bda['dates']['pop']();break;}}else{if(_0x48450e['push']({'agent':_0x5f161b['agent'],'dates':[_0x5f161b['date']]}),Fs(_0x48450e)>_0x432f9b){_0x48450e['pop']();break;}}_0x15b993=_0x15b993['slice'](0x1);}return{'heartbeatsToSend':_0x48450e,'unsentEntries':_0x15b993};}class Nl{constructor(_0x508a06){this['app']=_0x508a06,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x126b45=await Sl(this['app']);return _0x126b45!=null&&_0x126b45['heartbeats']?_0x126b45:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x249497){if(await this['_canUseIndexedDBPromise']){const _0x3271f3=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x249497['lastSentHeartbeatDate']??_0x3271f3['lastSentHeartbeatDate'],'heartbeats':_0x249497['heartbeats']});}else return;}async['add'](_0x53f2be){if(await this['_canUseIndexedDBPromise']){const _0x21758a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x53f2be['lastSentHeartbeatDate']??_0x21758a['lastSentHeartbeatDate'],'heartbeats':[..._0x21758a['heartbeats'],..._0x53f2be['heartbeats']]});}else return;}}function Fs(_0x72634d){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x72634d}))['length'];}function Pl(_0x4a9a99){if(_0x4a9a99['length']===0x0)return-0x1;let _0x3b839f=0x0,_0x20eccb=_0x4a9a99[0x0]['date'];for(let _0x24987c=0x1;_0x24987c<_0x4a9a99['length'];_0x24987c++)_0x4a9a99[_0x24987c]['date']<_0x20eccb&&(_0x20eccb=_0x4a9a99[_0x24987c]['date'],_0x3b839f=_0x24987c);return _0x3b839f;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x583582){et(new Me('platform-logger',_0x5a0bb5=>new Gc(_0x5a0bb5),'PRIVATE')),et(new Me('heartbeat',_0x35fbc5=>new Al(_0x35fbc5),'PRIVATE')),me(fi,Ds,_0x583582),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x286711){Zr=_0x286711;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x125ef4){this['domStorage_']=_0x125ef4,this['prefix_']='firebase:';}['set'](_0x1fdab6,_0x311afb){_0x311afb==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1fdab6)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1fdab6),O(_0x311afb));}['get'](_0xe7dd96){const _0x498c40=this['domStorage_']['getItem'](this['prefixedName_'](_0xe7dd96));return _0x498c40==null?null:bt(_0x498c40);}['remove'](_0x5f28f1){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5f28f1));}['prefixedName_'](_0x9c1e46){return this['prefix_']+_0x9c1e46;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5c62d0,_0x3eb199){_0x3eb199==null?delete this['cache_'][_0x5c62d0]:this['cache_'][_0x5c62d0]=_0x3eb199;}['get'](_0x10d109){return Y(this['cache_'],_0x10d109)?this['cache_'][_0x10d109]:null;}['remove'](_0x313712){delete this['cache_'][_0x313712];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x17ee9b){try{if(typeof window<'u'&&typeof window[_0x17ee9b]<'u'){const _0x18536f=window[_0x17ee9b];return _0x18536f['setItem']('firebase:sentinel','cache'),_0x18536f['removeItem']('firebase:sentinel'),new xl(_0x18536f);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x49dd58=0x1;return function(){return _0x49dd58++;};}()),no=function(_0x3c2c57){const _0x207ce1=Tc(_0x3c2c57),_0xc0e192=new Ec();_0xc0e192['update'](_0x207ce1);const _0x183a5f=_0xc0e192['digest']();return Di['encodeByteArray'](_0x183a5f);},Bt=function(..._0x5e13ae){let _0x201806='';for(let _0xf088c=0x0;_0xf088c<_0x5e13ae['length'];_0xf088c++){const _0x5d114b=_0x5e13ae[_0xf088c];Array['isArray'](_0x5d114b)||_0x5d114b&&typeof _0x5d114b=='object'&&typeof _0x5d114b['length']=='number'?_0x201806+=Bt['apply'](null,_0x5d114b):typeof _0x5d114b=='object'?_0x201806+=O(_0x5d114b):_0x201806+=_0x5d114b,_0x201806+='\x20';}return _0x201806;};let Et=null,Vs=!0x0;const Wl=function(_0x3e79b1,_0x26d7e2){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0xca9f57){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x55da6a=Bt['apply'](null,_0xca9f57);Et(_0x55da6a);}},Vt=function(_0x31841b){return function(..._0x39f6a1){L(_0x31841b,..._0x39f6a1);};},mi=function(..._0x5b8509){const _0x41e03f='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x5b8509);Qe['error'](_0x41e03f);},oe=function(..._0x2a68bc){const _0x351367='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x2a68bc);throw Qe['error'](_0x351367),new Error(_0x351367);},U=function(..._0x451a46){const _0x10680c='FIREBASE\x20WARNING:\x20'+Bt(..._0x451a46);Qe['warn'](_0x10680c);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x5880f0){return typeof _0x5880f0=='number'&&(_0x5880f0!==_0x5880f0||_0x5880f0===Number['POSITIVE_INFINITY']||_0x5880f0===Number['NEGATIVE_INFINITY']);},Vl=function(_0x452788){if(document['readyState']==='complete')_0x452788();else{let _0x5e658b=!0x1;const _0x5d3961=function(){if(!document['body']){setTimeout(_0x5d3961,Math['floor'](0xa));return;}_0x5e658b||(_0x5e658b=!0x0,_0x452788());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5d3961,!0x1),window['addEventListener']('load',_0x5d3961,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5d3961();}),window['attachEvent']('onload',_0x5d3961));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x577539,_0x4280aa){if(_0x577539===_0x4280aa)return 0x0;if(_0x577539===xe||_0x4280aa===Ie)return-0x1;if(_0x4280aa===xe||_0x577539===Ie)return 0x1;{const _0x2e2c1f=Hs(_0x577539),_0x493bf2=Hs(_0x4280aa);return _0x2e2c1f!==null?_0x493bf2!==null?_0x2e2c1f-_0x493bf2===0x0?_0x577539['length']-_0x4280aa['length']:_0x2e2c1f-_0x493bf2:-0x1:_0x493bf2!==null?0x1:_0x577539<_0x4280aa?-0x1:0x1;}},Hl=function(_0x46864b,_0x46ad35){return _0x46864b===_0x46ad35?0x0:_0x46864b<_0x46ad35?-0x1:0x1;},pt=function(_0x9a508c,_0x4ad2e9){if(_0x4ad2e9&&_0x9a508c in _0x4ad2e9)return _0x4ad2e9[_0x9a508c];throw new Error('Missing\x20required\x20key\x20('+_0x9a508c+')\x20in\x20object:\x20'+O(_0x4ad2e9));},Bi=function(_0xfc1d3){if(typeof _0xfc1d3!='object'||_0xfc1d3===null)return O(_0xfc1d3);const _0x4e3ec4=[];for(const _0x386554 in _0xfc1d3)_0x4e3ec4['push'](_0x386554);_0x4e3ec4['sort']();let _0x556107='{';for(let _0x56b5b7=0x0;_0x56b5b7<_0x4e3ec4['length'];_0x56b5b7++)_0x56b5b7!==0x0&&(_0x556107+=','),_0x556107+=O(_0x4e3ec4[_0x56b5b7]),_0x556107+=':',_0x556107+=Bi(_0xfc1d3[_0x4e3ec4[_0x56b5b7]]);return _0x556107+='}',_0x556107;},io=function(_0x932fa8,_0x45fdcc){const _0x4fe367=_0x932fa8['length'];if(_0x4fe367<=_0x45fdcc)return[_0x932fa8];const _0x3da17a=[];for(let _0x4d9670=0x0;_0x4d9670<_0x4fe367;_0x4d9670+=_0x45fdcc)_0x4d9670+_0x45fdcc>_0x4fe367?_0x3da17a['push'](_0x932fa8['substring'](_0x4d9670,_0x4fe367)):_0x3da17a['push'](_0x932fa8['substring'](_0x4d9670,_0x4d9670+_0x45fdcc));return _0x3da17a;};function x(_0x51c784,_0x990bbd){for(const _0x2ab78b in _0x51c784)_0x51c784['hasOwnProperty'](_0x2ab78b)&&_0x990bbd(_0x2ab78b,_0x51c784[_0x2ab78b]);}const so=function(_0x4dbff6){f(!Wi(_0x4dbff6),'Invalid\x20JSON\x20number');const _0x17d85b=0xb,_0x22b1eb=0x34,_0x47eb3e=(0x1<<_0x17d85b-0x1)-0x1;let _0x30fc9f,_0x56adda,_0x249eaf,_0x119c93,_0x797e9;_0x4dbff6===0x0?(_0x56adda=0x0,_0x249eaf=0x0,_0x30fc9f=0x1/_0x4dbff6===-0x1/0x0?0x1:0x0):(_0x30fc9f=_0x4dbff6<0x0,_0x4dbff6=Math['abs'](_0x4dbff6),_0x4dbff6>=Math['pow'](0x2,0x1-_0x47eb3e)?(_0x119c93=Math['min'](Math['floor'](Math['log'](_0x4dbff6)/Math['LN2']),_0x47eb3e),_0x56adda=_0x119c93+_0x47eb3e,_0x249eaf=Math['round'](_0x4dbff6*Math['pow'](0x2,_0x22b1eb-_0x119c93)-Math['pow'](0x2,_0x22b1eb))):(_0x56adda=0x0,_0x249eaf=Math['round'](_0x4dbff6/Math['pow'](0x2,0x1-_0x47eb3e-_0x22b1eb))));const _0x5ce750=[];for(_0x797e9=_0x22b1eb;_0x797e9;_0x797e9-=0x1)_0x5ce750['push'](_0x249eaf%0x2?0x1:0x0),_0x249eaf=Math['floor'](_0x249eaf/0x2);for(_0x797e9=_0x17d85b;_0x797e9;_0x797e9-=0x1)_0x5ce750['push'](_0x56adda%0x2?0x1:0x0),_0x56adda=Math['floor'](_0x56adda/0x2);_0x5ce750['push'](_0x30fc9f?0x1:0x0),_0x5ce750['reverse']();const _0x4aec14=_0x5ce750['join']('');let _0x3c6151='';for(_0x797e9=0x0;_0x797e9<0x40;_0x797e9+=0x8){let _0x41ce7d=parseInt(_0x4aec14['substr'](_0x797e9,0x8),0x2)['toString'](0x10);_0x41ce7d['length']===0x1&&(_0x41ce7d='0'+_0x41ce7d),_0x3c6151=_0x3c6151+_0x41ce7d;}return _0x3c6151['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x35cdff,_0x4d80fd){let _0x4d5338='Unknown\x20Error';_0x35cdff==='too_big'?_0x4d5338='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x35cdff==='permission_denied'?_0x4d5338='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x35cdff==='unavailable'&&(_0x4d5338='The\x20service\x20is\x20unavailable');const _0x335261=new Error(_0x35cdff+'\x20at\x20'+_0x4d80fd['_path']['toString']()+':\x20'+_0x4d5338);return _0x335261['code']=_0x35cdff['toUpperCase'](),_0x335261;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x31820d){if(zl['test'](_0x31820d)){const _0x195998=Number(_0x31820d);if(_0x195998>=jl&&_0x195998<=Kl)return _0x195998;}return null;},lt=function(_0x21d9c3){try{_0x21d9c3();}catch(_0x16eafa){setTimeout(()=>{const _0x4b8420=_0x16eafa['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4b8420),_0x16eafa;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x91f9ed,_0x33018b){const _0x468034=setTimeout(_0x91f9ed,_0x33018b);return typeof _0x468034=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x468034):typeof _0x468034=='object'&&_0x468034['unref']&&_0x468034['unref'](),_0x468034;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x2b16bd,_0x3c79cc){this['appCheckProvider']=_0x3c79cc,this['appName']=_0x2b16bd['name'],H(_0x2b16bd)&&_0x2b16bd['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2b16bd['settings']['appCheckToken']),this['appCheck']=_0x3c79cc==null?void 0x0:_0x3c79cc['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3c79cc==null||_0x3c79cc['get']()['then'](_0x5dcdbf=>this['appCheck']=_0x5dcdbf);}['getToken'](_0x2c274c){if(this['serverAppAppCheckToken']){if(_0x2c274c)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2c274c):new Promise((_0x85b746,_0x13ccee)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2c274c)['then'](_0x85b746,_0x13ccee):_0x85b746(null);},0x0);});}['addTokenChangeListener'](_0x26602b){var _0x22a842;(_0x22a842=this['appCheckProvider'])==null||_0x22a842['get']()['then'](_0x572cff=>_0x572cff['addTokenListener'](_0x26602b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x33bbec,_0x53a8e7,_0x1a3eb3){this['appName_']=_0x33bbec,this['firebaseOptions_']=_0x53a8e7,this['authProvider_']=_0x1a3eb3,this['auth_']=null,this['auth_']=_0x1a3eb3['getImmediate']({'optional':!0x0}),this['auth_']||_0x1a3eb3['onInit'](_0x4598d9=>this['auth_']=_0x4598d9);}['getToken'](_0x387b54){return this['auth_']?this['auth_']['getToken'](_0x387b54)['catch'](_0x51f56a=>_0x51f56a&&_0x51f56a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x51f56a)):new Promise((_0x2b37d9,_0x2796c4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x387b54)['then'](_0x2b37d9,_0x2796c4):_0x2b37d9(null);},0x0);});}['addTokenChangeListener'](_0x25c38d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x25c38d):this['authProvider_']['get']()['then'](_0x599d58=>_0x599d58['addAuthTokenListener'](_0x25c38d));}['removeTokenChangeListener'](_0x3685f4){this['authProvider_']['get']()['then'](_0x2f792a=>_0x2f792a['removeAuthTokenListener'](_0x3685f4));}['notifyForInvalidToken'](){let _0xa8f2dd='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xa8f2dd+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xa8f2dd+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xa8f2dd+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xa8f2dd);}}class tn{constructor(_0xc599a2){this['accessToken']=_0xc599a2;}['getToken'](_0x214c99){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x496b03){_0x496b03(this['accessToken']);}['removeTokenChangeListener'](_0x3d1961){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1d9200,_0x51bc66,_0x41df12,_0x203cec,_0x22074f=!0x1,_0x381585='',_0x2a249f=!0x1,_0x2f1792=!0x1,_0x35f1b3=null){this['secure']=_0x51bc66,this['namespace']=_0x41df12,this['webSocketOnly']=_0x203cec,this['nodeAdmin']=_0x22074f,this['persistenceKey']=_0x381585,this['includeNamespaceInQueryParams']=_0x2a249f,this['isUsingEmulator']=_0x2f1792,this['emulatorOptions']=_0x35f1b3,this['_host']=_0x1d9200['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1d9200)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x46e1d6){_0x46e1d6!==this['internalHost']&&(this['internalHost']=_0x46e1d6,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x110103=this['toURLString']();return this['persistenceKey']&&(_0x110103+='<'+this['persistenceKey']+'>'),_0x110103;}['toURLString'](){const _0x57b0ed=this['secure']?'https://':'http://',_0x473651=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x57b0ed+this['host']+'/'+_0x473651;}}function Xl(_0x2034a5){return _0x2034a5['host']!==_0x2034a5['internalHost']||_0x2034a5['isCustomHost']()||_0x2034a5['includeNamespaceInQueryParams'];}function go(_0x4c072b,_0x751696,_0x405ce8){f(typeof _0x751696=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x405ce8=='object','typeof\x20params\x20must\x20==\x20object');let _0x46846b;if(_0x751696===fo)_0x46846b=(_0x4c072b['secure']?'wss://':'ws://')+_0x4c072b['internalHost']+'/.ws?';else{if(_0x751696===po)_0x46846b=(_0x4c072b['secure']?'https://':'http://')+_0x4c072b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x751696);}Xl(_0x4c072b)&&(_0x405ce8['ns']=_0x4c072b['namespace']);const _0xf0d1b6=[];return x(_0x405ce8,(_0x18b222,_0x224a09)=>{_0xf0d1b6['push'](_0x18b222+'='+_0x224a09);}),_0x46846b+_0xf0d1b6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x26cb8f,_0x4498e5=0x1){Y(this['counters_'],_0x26cb8f)||(this['counters_'][_0x26cb8f]=0x0),this['counters_'][_0x26cb8f]+=_0x4498e5;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x3164a2){const _0x1021c0=_0x3164a2['toString']();return ti[_0x1021c0]||(ti[_0x1021c0]=new Zl()),ti[_0x1021c0];}function eh(_0x141204,_0x50df14){const _0x5e8a7e=_0x141204['toString']();return ni[_0x5e8a7e]||(ni[_0x5e8a7e]=_0x50df14()),ni[_0x5e8a7e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5abbae){this['onMessage_']=_0x5abbae,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2ed583,_0x4b9a6d){this['closeAfterResponse']=_0x2ed583,this['onClose']=_0x4b9a6d,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x122234,_0x520afd){for(this['pendingResponses'][_0x122234]=_0x520afd;this['pendingResponses'][this['currentResponseNum']];){const _0x50f8d6=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x8525f5=0x0;_0x8525f5<_0x50f8d6['length'];++_0x8525f5)_0x50f8d6[_0x8525f5]&&lt(()=>{this['onMessage_'](_0x50f8d6[_0x8525f5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x5689ac,_0x5db28e,_0x2b0658,_0x240079,_0x3a489e,_0x4d7d33,_0x62cf70){this['connId']=_0x5689ac,this['repoInfo']=_0x5db28e,this['applicationId']=_0x2b0658,this['appCheckToken']=_0x240079,this['authToken']=_0x3a489e,this['transportSessionId']=_0x4d7d33,this['lastSessionId']=_0x62cf70,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x5689ac),this['stats_']=Hi(_0x5db28e),this['urlFn']=_0x417e0c=>(this['appCheckToken']&&(_0x417e0c[yi]=this['appCheckToken']),go(_0x5db28e,po,_0x417e0c));}['open'](_0x5b5841,_0x251c79){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x251c79,this['myPacketOrderer']=new th(_0x5b5841),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x35bf99)=>{const [_0x559559,_0x129584,_0x11665c,_0x1dba26,_0x4c61a9]=_0x35bf99;if(this['incrementIncomingBytes_'](_0x35bf99),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x559559===$s)this['id']=_0x129584,this['password']=_0x11665c;else{if(_0x559559===nh)_0x129584?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x129584,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x559559);}}},(..._0x3564c6)=>{const [_0x4a4dcd,_0x390388]=_0x3564c6;this['incrementIncomingBytes_'](_0x3564c6),this['myPacketOrderer']['handleResponse'](_0x4a4dcd,_0x390388);},()=>{this['onClosed_']();},this['urlFn']);const _0x5032e4={};_0x5032e4[$s]='t',_0x5032e4[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5032e4[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5032e4[ro]=Vi,this['transportSessionId']&&(_0x5032e4[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x5032e4[ho]=this['lastSessionId']),this['applicationId']&&(_0x5032e4[uo]=this['applicationId']),this['appCheckToken']&&(_0x5032e4[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5032e4[ao]=co);const _0x153a0b=this['urlFn'](_0x5032e4);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x153a0b),this['scriptTagHolder']['addTag'](_0x153a0b,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x283a92){const _0x31e8fc=O(_0x283a92);this['bytesSent']+=_0x31e8fc['length'],this['stats_']['incrementCounter']('bytes_sent',_0x31e8fc['length']);const _0xf1ef7f=Br(_0x31e8fc),_0x1cdedd=io(_0xf1ef7f,hh);for(let _0x15f791=0x0;_0x15f791<_0x1cdedd['length'];_0x15f791++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1cdedd['length'],_0x1cdedd[_0x15f791]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x108a55,_0x4df66d){this['myDisconnFrame']=document['createElement']('iframe');const _0xc5ca62={};_0xc5ca62[lh]='t',_0xc5ca62[mo]=_0x108a55,_0xc5ca62[yo]=_0x4df66d,this['myDisconnFrame']['src']=this['urlFn'](_0xc5ca62),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x277f2f){const _0x41b67a=O(_0x277f2f)['length'];this['bytesReceived']+=_0x41b67a,this['stats_']['incrementCounter']('bytes_received',_0x41b67a);}}class $i{constructor(_0x11fe1b,_0x2f6a67,_0x18dec5,_0x5dbe24){this['onDisconnect']=_0x18dec5,this['urlFn']=_0x5dbe24,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x11fe1b,window[sh+this['uniqueCallbackIdentifier']]=_0x2f6a67,this['myIFrame']=$i['createIFrame_']();let _0x4702b3='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4702b3='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x364b63='<html><body>'+_0x4702b3+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x364b63),this['myIFrame']['doc']['close']();}catch(_0x277cae){L('frame\x20writing\x20exception'),_0x277cae['stack']&&L(_0x277cae['stack']),L(_0x277cae);}}}static['createIFrame_'](){const _0xa977c1=document['createElement']('iframe');if(_0xa977c1['style']['display']='none',document['body']){document['body']['appendChild'](_0xa977c1);try{_0xa977c1['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x389cf9=document['domain'];_0xa977c1['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x389cf9+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xa977c1['contentDocument']?_0xa977c1['doc']=_0xa977c1['contentDocument']:_0xa977c1['contentWindow']?_0xa977c1['doc']=_0xa977c1['contentWindow']['document']:_0xa977c1['document']&&(_0xa977c1['doc']=_0xa977c1['document']),_0xa977c1;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1c7101=this['onDisconnect'];_0x1c7101&&(this['onDisconnect']=null,_0x1c7101());}['startLongPoll'](_0x1c9677,_0x1607b2){for(this['myID']=_0x1c9677,this['myPW']=_0x1607b2,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x27bc79={};_0x27bc79[mo]=this['myID'],_0x27bc79[yo]=this['myPW'],_0x27bc79[vo]=this['currentSerial'];let _0x50fb72=this['urlFn'](_0x27bc79),_0x5292c2='',_0x11b495=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5292c2['length']<=Eo;){const _0x2320f8=this['pendingSegs']['shift']();_0x5292c2=_0x5292c2+'&'+oh+_0x11b495+'='+_0x2320f8['seg']+'&'+ah+_0x11b495+'='+_0x2320f8['ts']+'&'+ch+_0x11b495+'='+_0x2320f8['d'],_0x11b495++;}return _0x50fb72=_0x50fb72+_0x5292c2,this['addLongPollTag_'](_0x50fb72,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x14a5e0,_0x282654,_0x371097){this['pendingSegs']['push']({'seg':_0x14a5e0,'ts':_0x282654,'d':_0x371097}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x45ed15,_0x4f3101){this['outstandingRequests']['add'](_0x4f3101);const _0x556912=()=>{this['outstandingRequests']['delete'](_0x4f3101),this['newRequest_']();},_0x3313a4=setTimeout(_0x556912,Math['floor'](uh)),_0x528fcc=()=>{clearTimeout(_0x3313a4),_0x556912();};this['addTag'](_0x45ed15,_0x528fcc);}['addTag'](_0x4e456e,_0x2405cd){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3998b4=this['myIFrame']['doc']['createElement']('script');_0x3998b4['type']='text/javascript',_0x3998b4['async']=!0x0,_0x3998b4['src']=_0x4e456e,_0x3998b4['onload']=_0x3998b4['onreadystatechange']=function(){const _0x9cfa3d=_0x3998b4['readyState'];(!_0x9cfa3d||_0x9cfa3d==='loaded'||_0x9cfa3d==='complete')&&(_0x3998b4['onload']=_0x3998b4['onreadystatechange']=null,_0x3998b4['parentNode']&&_0x3998b4['parentNode']['removeChild'](_0x3998b4),_0x2405cd());},_0x3998b4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4e456e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3998b4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x1ebd26,_0x3c29ef,_0x1250ce,_0x1d8721,_0x11ec91,_0x4d80a4,_0x1c0935){this['connId']=_0x1ebd26,this['applicationId']=_0x1250ce,this['appCheckToken']=_0x1d8721,this['authToken']=_0x11ec91,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x3c29ef),this['connURL']=G['connectionURL_'](_0x3c29ef,_0x4d80a4,_0x1c0935,_0x1d8721,_0x1250ce),this['nodeAdmin']=_0x3c29ef['nodeAdmin'];}static['connectionURL_'](_0x1813f1,_0x27db77,_0x1f17ed,_0x2b65dd,_0x55b45b){const _0xa737f3={};return _0xa737f3[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xa737f3[ao]=co),_0x27db77&&(_0xa737f3[oo]=_0x27db77),_0x1f17ed&&(_0xa737f3[ho]=_0x1f17ed),_0x2b65dd&&(_0xa737f3[yi]=_0x2b65dd),_0x55b45b&&(_0xa737f3[uo]=_0x55b45b),go(_0x1813f1,fo,_0xa737f3);}['open'](_0x4d8bb7,_0x18558f){this['onDisconnect']=_0x18558f,this['onMessage']=_0x4d8bb7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1944fa;dc(),this['mySock']=new hn(this['connURL'],[],_0x1944fa);}catch(_0x3f46b5){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1b6421=_0x3f46b5['message']||_0x3f46b5['data'];_0x1b6421&&this['log_'](_0x1b6421),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2c9016=>{this['handleIncomingFrame'](_0x2c9016);},this['mySock']['onerror']=_0x4a8fb6=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x22846c=_0x4a8fb6['message']||_0x4a8fb6['data'];_0x22846c&&this['log_'](_0x22846c),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3e7834=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x792150=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5f0c08=navigator['userAgent']['match'](_0x792150);_0x5f0c08&&_0x5f0c08['length']>0x1&&parseFloat(_0x5f0c08[0x1])<4.4&&(_0x3e7834=!0x0);}return!_0x3e7834&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x477c99){if(this['frames']['push'](_0x477c99),this['frames']['length']===this['totalFrames']){const _0x166552=this['frames']['join']('');this['frames']=null;const _0x46d5b9=bt(_0x166552);this['onMessage'](_0x46d5b9);}}['handleNewFrameCount_'](_0xbcd07e){this['totalFrames']=_0xbcd07e,this['frames']=[];}['extractFrameCount_'](_0x2b97a0){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2b97a0['length']<=0x6){const _0x4f9adc=Number(_0x2b97a0);if(!isNaN(_0x4f9adc))return this['handleNewFrameCount_'](_0x4f9adc),null;}return this['handleNewFrameCount_'](0x1),_0x2b97a0;}['handleIncomingFrame'](_0x3a1f80){if(this['mySock']===null)return;const _0x16bf6d=_0x3a1f80['data'];if(this['bytesReceived']+=_0x16bf6d['length'],this['stats_']['incrementCounter']('bytes_received',_0x16bf6d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x16bf6d);else{const _0x4156bb=this['extractFrameCount_'](_0x16bf6d);_0x4156bb!==null&&this['appendFrame_'](_0x4156bb);}}['send'](_0x8a8e31){this['resetKeepAlive']();const _0x46fd1f=O(_0x8a8e31);this['bytesSent']+=_0x46fd1f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x46fd1f['length']);const _0x29eb90=io(_0x46fd1f,fh);_0x29eb90['length']>0x1&&this['sendString_'](String(_0x29eb90['length']));for(let _0x381209=0x0;_0x381209<_0x29eb90['length'];_0x381209++)this['sendString_'](_0x29eb90[_0x381209]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x39a0a8){try{this['mySock']['send'](_0x39a0a8);}catch(_0x1ebabc){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1ebabc['message']||_0x1ebabc['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1cddbd){this['initTransports_'](_0x1cddbd);}['initTransports_'](_0x1d54ea){const _0x4c1c38=G&&G['isAvailable']();let _0x2d6389=_0x4c1c38&&!G['previouslyFailed']();if(_0x1d54ea['webSocketOnly']&&(_0x4c1c38||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2d6389=!0x0),_0x2d6389)this['transports_']=[G];else{const _0x40119b=this['transports_']=[];for(const _0x5487bf of At['ALL_TRANSPORTS'])_0x5487bf&&_0x5487bf['isAvailable']()&&_0x40119b['push'](_0x5487bf);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4db3e7,_0x1a1580,_0x20aeaa,_0x13eb08,_0x5d75f6,_0x10917a,_0x508039,_0x3a8219,_0x1027c9,_0x47e9de){this['id']=_0x4db3e7,this['repoInfo_']=_0x1a1580,this['applicationId_']=_0x20aeaa,this['appCheckToken_']=_0x13eb08,this['authToken_']=_0x5d75f6,this['onMessage_']=_0x10917a,this['onReady_']=_0x508039,this['onDisconnect_']=_0x3a8219,this['onKill_']=_0x1027c9,this['lastSessionId']=_0x47e9de,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x1a1580),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xce5ba7=this['transportManager_']['initialTransport']();this['conn_']=new _0xce5ba7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xce5ba7['responsesRequiredToBeHealthy']||0x0;const _0x42f629=this['connReceiver_'](this['conn_']),_0xa6372c=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x42f629,_0xa6372c);},Math['floor'](0x0));const _0x104802=_0xce5ba7['healthyTimeout']||0x0;_0x104802>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x104802)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xbe01ef){return _0x4fee63=>{_0xbe01ef===this['conn_']?this['onConnectionLost_'](_0x4fee63):_0xbe01ef===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x155748){return _0x485755=>{this['state_']!==0x2&&(_0x155748===this['rx_']?this['onPrimaryMessageReceived_'](_0x485755):_0x155748===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x485755):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x32e720){const _0x32599c={'t':'d','d':_0x32e720};this['sendData_'](_0x32599c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1dc950){if(ii in _0x1dc950){const _0x130f17=_0x1dc950[ii];_0x130f17===js?this['upgradeIfSecondaryHealthy_']():_0x130f17===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x130f17===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3c497e){const _0x42d681=pt('t',_0x3c497e),_0x3d7c99=pt('d',_0x3c497e);if(_0x42d681==='c')this['onSecondaryControl_'](_0x3d7c99);else{if(_0x42d681==='d')this['pendingDataMessages']['push'](_0x3d7c99);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x42d681);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4cc38d){const _0x3c0cc1=pt('t',_0x4cc38d),_0x3b8864=pt('d',_0x4cc38d);_0x3c0cc1==='c'?this['onControl_'](_0x3b8864):_0x3c0cc1==='d'&&this['onDataMessage_'](_0x3b8864);}['onDataMessage_'](_0x3f28e8){this['onPrimaryResponse_'](),this['onMessage_'](_0x3f28e8);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4755be){const _0x33ca79=pt(ii,_0x4755be);if(Gs in _0x4755be){const _0x3cf4a3=_0x4755be[Gs];if(_0x33ca79===Ih){const _0x1e7daa={..._0x3cf4a3};this['repoInfo_']['isUsingEmulator']&&(_0x1e7daa['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1e7daa);}else{if(_0x33ca79===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1eafd2=0x0;_0x1eafd2<this['pendingDataMessages']['length'];++_0x1eafd2)this['onDataMessage_'](this['pendingDataMessages'][_0x1eafd2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x33ca79===vh?this['onConnectionShutdown_'](_0x3cf4a3):_0x33ca79===qs?this['onReset_'](_0x3cf4a3):_0x33ca79===Eh?mi('Server\x20Error:\x20'+_0x3cf4a3):_0x33ca79===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x33ca79);}}}['onHandshake_'](_0x51e06b){const _0x2386e1=_0x51e06b['ts'],_0x199901=_0x51e06b['v'],_0x3c466c=_0x51e06b['h'];this['sessionId']=_0x51e06b['s'],this['repoInfo_']['host']=_0x3c466c,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2386e1),Vi!==_0x199901&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x43b148=this['transportManager_']['upgradeTransport']();_0x43b148&&this['startUpgrade_'](_0x43b148);}['startUpgrade_'](_0x4d0057){this['secondaryConn_']=new _0x4d0057(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4d0057['responsesRequiredToBeHealthy']||0x0;const _0x297507=this['connReceiver_'](this['secondaryConn_']),_0xb9e081=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x297507,_0xb9e081),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x59390d){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x59390d),this['repoInfo_']['host']=_0x59390d,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x32d7d2,_0x1bd034){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x32d7d2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1bd034,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4d6409=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4d6409||this['rx_']===_0x4d6409)&&this['close']();}['onConnectionLost_'](_0x2fb898){this['conn_']=null,!_0x2fb898&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x44e3ee){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x44e3ee),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4dc1c8){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4dc1c8);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x3025b5,_0x14e97c,_0x25e3af,_0x50056f){}['merge'](_0x3bf527,_0x3e85b5,_0x407b7b,_0x44cd29){}['refreshAuthToken'](_0x538a38){}['refreshAppCheckToken'](_0x3d37e3){}['onDisconnectPut'](_0x5aa1e7,_0x3c3bc1,_0xac3bc7){}['onDisconnectMerge'](_0x3f7332,_0x2c6694,_0x598957){}['onDisconnectCancel'](_0x2f968c,_0x5d9179){}['reportStats'](_0x44e136){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x30d3e9){this['allowedEvents_']=_0x30d3e9,this['listeners_']={},f(Array['isArray'](_0x30d3e9)&&_0x30d3e9['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x28bce2,..._0x296da2){if(Array['isArray'](this['listeners_'][_0x28bce2])){const _0x42d42a=[...this['listeners_'][_0x28bce2]];for(let _0x244c57=0x0;_0x244c57<_0x42d42a['length'];_0x244c57++)_0x42d42a[_0x244c57]['callback']['apply'](_0x42d42a[_0x244c57]['context'],_0x296da2);}}['on'](_0x3f0d82,_0x1384fd,_0x3aefe1){this['validateEventType_'](_0x3f0d82),this['listeners_'][_0x3f0d82]=this['listeners_'][_0x3f0d82]||[],this['listeners_'][_0x3f0d82]['push']({'callback':_0x1384fd,'context':_0x3aefe1});const _0x38de43=this['getInitialEvent'](_0x3f0d82);_0x38de43&&_0x1384fd['apply'](_0x3aefe1,_0x38de43);}['off'](_0x19ff6a,_0x35249e,_0xdba7f3){this['validateEventType_'](_0x19ff6a);const _0x4c1c83=this['listeners_'][_0x19ff6a]||[];for(let _0x138b16=0x0;_0x138b16<_0x4c1c83['length'];_0x138b16++)if(_0x4c1c83[_0x138b16]['callback']===_0x35249e&&(!_0xdba7f3||_0xdba7f3===_0x4c1c83[_0x138b16]['context'])){_0x4c1c83['splice'](_0x138b16,0x1);return;}}['validateEventType_'](_0x1ff962){f(this['allowedEvents_']['find'](_0x2133be=>_0x2133be===_0x1ff962),'Unknown\x20event:\x20'+_0x1ff962);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5db0b5){return f(_0x5db0b5==='online','Unknown\x20event\x20type:\x20'+_0x5db0b5),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x6e12b0,_0x4c5568){if(_0x4c5568===void 0x0){this['pieces_']=_0x6e12b0['split']('/');let _0x292c09=0x0;for(let _0x124ec6=0x0;_0x124ec6<this['pieces_']['length'];_0x124ec6++)this['pieces_'][_0x124ec6]['length']>0x0&&(this['pieces_'][_0x292c09]=this['pieces_'][_0x124ec6],_0x292c09++);this['pieces_']['length']=_0x292c09,this['pieceNum_']=0x0;}else this['pieces_']=_0x6e12b0,this['pieceNum_']=_0x4c5568;}['toString'](){let _0x304dcd='';for(let _0x385030=this['pieceNum_'];_0x385030<this['pieces_']['length'];_0x385030++)this['pieces_'][_0x385030]!==''&&(_0x304dcd+='/'+this['pieces_'][_0x385030]);return _0x304dcd||'/';}}function w(){return new C('');}function y(_0x3a6bd6){return _0x3a6bd6['pieceNum_']>=_0x3a6bd6['pieces_']['length']?null:_0x3a6bd6['pieces_'][_0x3a6bd6['pieceNum_']];}function we(_0x45f6d1){return _0x45f6d1['pieces_']['length']-_0x45f6d1['pieceNum_'];}function b(_0x400293){let _0x1ed2e4=_0x400293['pieceNum_'];return _0x1ed2e4<_0x400293['pieces_']['length']&&_0x1ed2e4++,new C(_0x400293['pieces_'],_0x1ed2e4);}function Gi(_0x52d3d4){return _0x52d3d4['pieceNum_']<_0x52d3d4['pieces_']['length']?_0x52d3d4['pieces_'][_0x52d3d4['pieces_']['length']-0x1]:null;}function Ch(_0x19c98f){let _0x2fc81e='';for(let _0x12d950=_0x19c98f['pieceNum_'];_0x12d950<_0x19c98f['pieces_']['length'];_0x12d950++)_0x19c98f['pieces_'][_0x12d950]!==''&&(_0x2fc81e+='/'+encodeURIComponent(String(_0x19c98f['pieces_'][_0x12d950])));return _0x2fc81e||'/';}function kt(_0x22e35b,_0x39fac7=0x0){return _0x22e35b['pieces_']['slice'](_0x22e35b['pieceNum_']+_0x39fac7);}function To(_0x3f23f3){if(_0x3f23f3['pieceNum_']>=_0x3f23f3['pieces_']['length'])return null;const _0x56f61c=[];for(let _0x3f6c90=_0x3f23f3['pieceNum_'];_0x3f6c90<_0x3f23f3['pieces_']['length']-0x1;_0x3f6c90++)_0x56f61c['push'](_0x3f23f3['pieces_'][_0x3f6c90]);return new C(_0x56f61c,0x0);}function A(_0x3bab8a,_0x717462){const _0x36b47f=[];for(let _0x52f5c3=_0x3bab8a['pieceNum_'];_0x52f5c3<_0x3bab8a['pieces_']['length'];_0x52f5c3++)_0x36b47f['push'](_0x3bab8a['pieces_'][_0x52f5c3]);if(_0x717462 instanceof C){for(let _0xb7a7=_0x717462['pieceNum_'];_0xb7a7<_0x717462['pieces_']['length'];_0xb7a7++)_0x36b47f['push'](_0x717462['pieces_'][_0xb7a7]);}else{const _0x4fafac=_0x717462['split']('/');for(let _0x18fae3=0x0;_0x18fae3<_0x4fafac['length'];_0x18fae3++)_0x4fafac[_0x18fae3]['length']>0x0&&_0x36b47f['push'](_0x4fafac[_0x18fae3]);}return new C(_0x36b47f,0x0);}function v(_0x592899){return _0x592899['pieceNum_']>=_0x592899['pieces_']['length'];}function F(_0xbb1c02,_0x8256ed){const _0x144c8e=y(_0xbb1c02),_0x5a8656=y(_0x8256ed);if(_0x144c8e===null)return _0x8256ed;if(_0x144c8e===_0x5a8656)return F(b(_0xbb1c02),b(_0x8256ed));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x8256ed+')\x20is\x20not\x20within\x20outerPath\x20('+_0xbb1c02+')');}function Th(_0x21b6ba,_0x984232){const _0x58a352=kt(_0x21b6ba,0x0),_0xd31b6b=kt(_0x984232,0x0);for(let _0x99e0f6=0x0;_0x99e0f6<_0x58a352['length']&&_0x99e0f6<_0xd31b6b['length'];_0x99e0f6++){const _0x2f09d2=He(_0x58a352[_0x99e0f6],_0xd31b6b[_0x99e0f6]);if(_0x2f09d2!==0x0)return _0x2f09d2;}return _0x58a352['length']===_0xd31b6b['length']?0x0:_0x58a352['length']<_0xd31b6b['length']?-0x1:0x1;}function qi(_0x53e3e3,_0x15e324){if(we(_0x53e3e3)!==we(_0x15e324))return!0x1;for(let _0x377830=_0x53e3e3['pieceNum_'],_0x427562=_0x15e324['pieceNum_'];_0x377830<=_0x53e3e3['pieces_']['length'];_0x377830++,_0x427562++)if(_0x53e3e3['pieces_'][_0x377830]!==_0x15e324['pieces_'][_0x427562])return!0x1;return!0x0;}function $(_0x182eaa,_0x24f255){let _0x1e9731=_0x182eaa['pieceNum_'],_0x35ee74=_0x24f255['pieceNum_'];if(we(_0x182eaa)>we(_0x24f255))return!0x1;for(;_0x1e9731<_0x182eaa['pieces_']['length'];){if(_0x182eaa['pieces_'][_0x1e9731]!==_0x24f255['pieces_'][_0x35ee74])return!0x1;++_0x1e9731,++_0x35ee74;}return!0x0;}class Sh{constructor(_0xaed67b,_0x3eab5d){this['errorPrefix_']=_0x3eab5d,this['parts_']=kt(_0xaed67b,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1b1da2=0x0;_0x1b1da2<this['parts_']['length'];_0x1b1da2++)this['byteLength_']+=Pn(this['parts_'][_0x1b1da2]);So(this);}}function bh(_0x2b7ca1,_0x59af0d){_0x2b7ca1['parts_']['length']>0x0&&(_0x2b7ca1['byteLength_']+=0x1),_0x2b7ca1['parts_']['push'](_0x59af0d),_0x2b7ca1['byteLength_']+=Pn(_0x59af0d),So(_0x2b7ca1);}function Rh(_0x502e86){const _0x141ef=_0x502e86['parts_']['pop']();_0x502e86['byteLength_']-=Pn(_0x141ef),_0x502e86['parts_']['length']>0x0&&(_0x502e86['byteLength_']-=0x1);}function So(_0x15f0b1){if(_0x15f0b1['byteLength_']>Js)throw new Error(_0x15f0b1['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x15f0b1['byteLength_']+').');if(_0x15f0b1['parts_']['length']>Qs)throw new Error(_0x15f0b1['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x15f0b1));}function Ne(_0x427271){return _0x427271['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x427271['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x3122ca,_0x3c3127;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3c3127='visibilitychange',_0x3122ca='hidden'):typeof document['mozHidden']<'u'?(_0x3c3127='mozvisibilitychange',_0x3122ca='mozHidden'):typeof document['msHidden']<'u'?(_0x3c3127='msvisibilitychange',_0x3122ca='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3c3127='webkitvisibilitychange',_0x3122ca='webkitHidden')),this['visible_']=!0x0,_0x3c3127&&document['addEventListener'](_0x3c3127,()=>{const _0x2b96a6=!document[_0x3122ca];_0x2b96a6!==this['visible_']&&(this['visible_']=_0x2b96a6,this['trigger']('visible',_0x2b96a6));},!0x1);}['getInitialEvent'](_0x4b1c2f){return f(_0x4b1c2f==='visible','Unknown\x20event\x20type:\x20'+_0x4b1c2f),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x39d098,_0x232ff3,_0x3689a9,_0x19055a,_0x117613,_0x14afb3,_0x4f485f,_0x53b8da){if(super(),this['repoInfo_']=_0x39d098,this['applicationId_']=_0x232ff3,this['onDataUpdate_']=_0x3689a9,this['onConnectStatus_']=_0x19055a,this['onServerInfoUpdate_']=_0x117613,this['authTokenProvider_']=_0x14afb3,this['appCheckTokenProvider_']=_0x4f485f,this['authOverride_']=_0x53b8da,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x53b8da)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x39d098['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4a05c7,_0x114ea8,_0x77f42c){const _0x21e51c=++this['requestNumber_'],_0x35717a={'r':_0x21e51c,'a':_0x4a05c7,'b':_0x114ea8};this['log_'](O(_0x35717a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x35717a),_0x77f42c&&(this['requestCBHash_'][_0x21e51c]=_0x77f42c);}['get'](_0x363cc7){this['initConnection_']();const _0x5cd3bd=new Ve(),_0x2070bf={'action':'g','request':{'p':_0x363cc7['_path']['toString'](),'q':_0x363cc7['_queryObject']},'onComplete':_0x5173f9=>{const _0xfe9b4f=_0x5173f9['d'];_0x5173f9['s']==='ok'?_0x5cd3bd['resolve'](_0xfe9b4f):_0x5cd3bd['reject'](_0xfe9b4f);}};this['outstandingGets_']['push'](_0x2070bf),this['outstandingGetCount_']++;const _0xaef618=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xaef618),_0x5cd3bd['promise'];}['listen'](_0xd7f2c1,_0x394f98,_0x518c18,_0x43eef5){this['initConnection_']();const _0x1fbc59=_0xd7f2c1['_queryIdentifier'],_0x293f51=_0xd7f2c1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x293f51+'\x20'+_0x1fbc59),this['listens']['has'](_0x293f51)||this['listens']['set'](_0x293f51,new Map()),f(_0xd7f2c1['_queryParams']['isDefault']()||!_0xd7f2c1['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x293f51)['has'](_0x1fbc59),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5c98a3={'onComplete':_0x43eef5,'hashFn':_0x394f98,'query':_0xd7f2c1,'tag':_0x518c18};this['listens']['get'](_0x293f51)['set'](_0x1fbc59,_0x5c98a3),this['connected_']&&this['sendListen_'](_0x5c98a3);}['sendGet_'](_0x220c23){const _0x294321=this['outstandingGets_'][_0x220c23];this['sendRequest']('g',_0x294321['request'],_0x4c194c=>{delete this['outstandingGets_'][_0x220c23],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x294321['onComplete']&&_0x294321['onComplete'](_0x4c194c);});}['sendListen_'](_0x1ae200){const _0x268f9c=_0x1ae200['query'],_0x35e509=_0x268f9c['_path']['toString'](),_0x5e77e0=_0x268f9c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x35e509+'\x20for\x20'+_0x5e77e0);const _0x16722a={'p':_0x35e509},_0x5541ab='q';_0x1ae200['tag']&&(_0x16722a['q']=_0x268f9c['_queryObject'],_0x16722a['t']=_0x1ae200['tag']),_0x16722a['h']=_0x1ae200['hashFn'](),this['sendRequest'](_0x5541ab,_0x16722a,_0x233fcc=>{const _0x56c496=_0x233fcc['d'],_0x202922=_0x233fcc['s'];ie['warnOnListenWarnings_'](_0x56c496,_0x268f9c),(this['listens']['get'](_0x35e509)&&this['listens']['get'](_0x35e509)['get'](_0x5e77e0))===_0x1ae200&&(this['log_']('listen\x20response',_0x233fcc),_0x202922!=='ok'&&this['removeListen_'](_0x35e509,_0x5e77e0),_0x1ae200['onComplete']&&_0x1ae200['onComplete'](_0x202922,_0x56c496));});}static['warnOnListenWarnings_'](_0x51ab38,_0x3eda83){if(_0x51ab38&&typeof _0x51ab38=='object'&&Y(_0x51ab38,'w')){const _0x8751ac=Oe(_0x51ab38,'w');if(Array['isArray'](_0x8751ac)&&~_0x8751ac['indexOf']('no_index')){const _0x4d1ea0='\x22.indexOn\x22:\x20\x22'+_0x3eda83['_queryParams']['getIndex']()['toString']()+'\x22',_0x7bb877=_0x3eda83['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4d1ea0+'\x20at\x20'+_0x7bb877+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xa87d93){this['authToken_']=_0xa87d93,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xa87d93);}['reduceReconnectDelayIfAdminCredential_'](_0x8a315c){(_0x8a315c&&_0x8a315c['length']===0x28||vc(_0x8a315c))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x408872){this['appCheckToken_']=_0x408872,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x18ee71=this['authToken_'],_0x228834=yc(_0x18ee71)?'auth':'gauth',_0x356b0c={'cred':_0x18ee71};this['authOverride_']===null?_0x356b0c['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x356b0c['authvar']=this['authOverride_']),this['sendRequest'](_0x228834,_0x356b0c,_0x212c75=>{const _0xe1551b=_0x212c75['s'],_0x1e3ab6=_0x212c75['d']||'error';this['authToken_']===_0x18ee71&&(_0xe1551b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0xe1551b,_0x1e3ab6));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3c2659=>{const _0x382d70=_0x3c2659['s'],_0x39fd37=_0x3c2659['d']||'error';_0x382d70==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x382d70,_0x39fd37);});}['unlisten'](_0x2e60ad,_0x47b005){const _0x166884=_0x2e60ad['_path']['toString'](),_0x230ada=_0x2e60ad['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x166884+'\x20'+_0x230ada),f(_0x2e60ad['_queryParams']['isDefault']()||!_0x2e60ad['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x166884,_0x230ada)&&this['connected_']&&this['sendUnlisten_'](_0x166884,_0x230ada,_0x2e60ad['_queryObject'],_0x47b005);}['sendUnlisten_'](_0x5e59f8,_0x3509ea,_0x1e991c,_0x27d973){this['log_']('Unlisten\x20on\x20'+_0x5e59f8+'\x20for\x20'+_0x3509ea);const _0x13e4bd={'p':_0x5e59f8},_0x50b3b1='n';_0x27d973&&(_0x13e4bd['q']=_0x1e991c,_0x13e4bd['t']=_0x27d973),this['sendRequest'](_0x50b3b1,_0x13e4bd);}['onDisconnectPut'](_0x109a09,_0x1f7e2a,_0x3f87c3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x109a09,_0x1f7e2a,_0x3f87c3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x109a09,'action':'o','data':_0x1f7e2a,'onComplete':_0x3f87c3});}['onDisconnectMerge'](_0x45f768,_0x30cde8,_0x2f8bc9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x45f768,_0x30cde8,_0x2f8bc9):this['onDisconnectRequestQueue_']['push']({'pathString':_0x45f768,'action':'om','data':_0x30cde8,'onComplete':_0x2f8bc9});}['onDisconnectCancel'](_0x2097ac,_0x5853b9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2097ac,null,_0x5853b9):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2097ac,'action':'oc','data':null,'onComplete':_0x5853b9});}['sendOnDisconnect_'](_0x2b44ee,_0x1a4518,_0x3c2718,_0x88396b){const _0x221124={'p':_0x1a4518,'d':_0x3c2718};this['log_']('onDisconnect\x20'+_0x2b44ee,_0x221124),this['sendRequest'](_0x2b44ee,_0x221124,_0x5bcfdc=>{_0x88396b&&setTimeout(()=>{_0x88396b(_0x5bcfdc['s'],_0x5bcfdc['d']);},Math['floor'](0x0));});}['put'](_0x5c927c,_0xaeebc5,_0x1cf868,_0x53d4aa){this['putInternal']('p',_0x5c927c,_0xaeebc5,_0x1cf868,_0x53d4aa);}['merge'](_0x542c86,_0x3b43b3,_0x315cf2,_0xbd6d50){this['putInternal']('m',_0x542c86,_0x3b43b3,_0x315cf2,_0xbd6d50);}['putInternal'](_0x1bf806,_0x976c27,_0x378ac6,_0x33c92e,_0x3cc56f){this['initConnection_']();const _0x5ca73e={'p':_0x976c27,'d':_0x378ac6};_0x3cc56f!==void 0x0&&(_0x5ca73e['h']=_0x3cc56f),this['outstandingPuts_']['push']({'action':_0x1bf806,'request':_0x5ca73e,'onComplete':_0x33c92e}),this['outstandingPutCount_']++;const _0x175555=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x175555):this['log_']('Buffering\x20put:\x20'+_0x976c27);}['sendPut_'](_0xdc7a73){const _0x13611d=this['outstandingPuts_'][_0xdc7a73]['action'],_0x395b00=this['outstandingPuts_'][_0xdc7a73]['request'],_0x230e71=this['outstandingPuts_'][_0xdc7a73]['onComplete'];this['outstandingPuts_'][_0xdc7a73]['queued']=this['connected_'],this['sendRequest'](_0x13611d,_0x395b00,_0x397e1b=>{this['log_'](_0x13611d+'\x20response',_0x397e1b),delete this['outstandingPuts_'][_0xdc7a73],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x230e71&&_0x230e71(_0x397e1b['s'],_0x397e1b['d']);});}['reportStats'](_0xc00ccc){if(this['connected_']){const _0x515ffa={'c':_0xc00ccc};this['log_']('reportStats',_0x515ffa),this['sendRequest']('s',_0x515ffa,_0x52f57d=>{if(_0x52f57d['s']!=='ok'){const _0x3da7d3=_0x52f57d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3da7d3);}});}}['onDataMessage_'](_0x39744c){if('r'in _0x39744c){this['log_']('from\x20server:\x20'+O(_0x39744c));const _0x5c772e=_0x39744c['r'],_0x5c3adb=this['requestCBHash_'][_0x5c772e];_0x5c3adb&&(delete this['requestCBHash_'][_0x5c772e],_0x5c3adb(_0x39744c['b']));}else{if('error'in _0x39744c)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x39744c['error'];'a'in _0x39744c&&this['onDataPush_'](_0x39744c['a'],_0x39744c['b']);}}['onDataPush_'](_0x1b8f71,_0x3bdb89){this['log_']('handleServerMessage',_0x1b8f71,_0x3bdb89),_0x1b8f71==='d'?this['onDataUpdate_'](_0x3bdb89['p'],_0x3bdb89['d'],!0x1,_0x3bdb89['t']):_0x1b8f71==='m'?this['onDataUpdate_'](_0x3bdb89['p'],_0x3bdb89['d'],!0x0,_0x3bdb89['t']):_0x1b8f71==='c'?this['onListenRevoked_'](_0x3bdb89['p'],_0x3bdb89['q']):_0x1b8f71==='ac'?this['onAuthRevoked_'](_0x3bdb89['s'],_0x3bdb89['d']):_0x1b8f71==='apc'?this['onAppCheckRevoked_'](_0x3bdb89['s'],_0x3bdb89['d']):_0x1b8f71==='sd'?this['onSecurityDebugPacket_'](_0x3bdb89):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1b8f71)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2bb6ac,_0x50384a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2bb6ac),this['lastSessionId']=_0x50384a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3aeb17){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3aeb17));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1732c4){_0x1732c4&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1732c4;}['onOnline_'](_0xa9982d){_0xa9982d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x49836e=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4d88b7=Math['max'](0x0,this['reconnectDelay_']-_0x49836e);_0x4d88b7=Math['random']()*_0x4d88b7,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4d88b7+'ms'),this['scheduleConnect_'](_0x4d88b7),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x13ca26=this['onDataMessage_']['bind'](this),_0x2dd9d0=this['onReady_']['bind'](this),_0x4abfac=this['onRealtimeDisconnect_']['bind'](this),_0xf7a126=this['id']+':'+ie['nextConnectionId_']++,_0x2e5cf4=this['lastSessionId'];let _0x5f5468=!0x1,_0x52c7e2=null;const _0x3b79b2=function(){_0x52c7e2?_0x52c7e2['close']():(_0x5f5468=!0x0,_0x4abfac());},_0x1b5b01=function(_0x3ca3fc){f(_0x52c7e2,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x52c7e2['sendRequest'](_0x3ca3fc);};this['realtime_']={'close':_0x3b79b2,'sendRequest':_0x1b5b01};const _0x5c8e4e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x4149ad,_0x357ec6]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x5c8e4e),this['appCheckTokenProvider_']['getToken'](_0x5c8e4e)]);_0x5f5468?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x4149ad&&_0x4149ad['accessToken'],this['appCheckToken_']=_0x357ec6&&_0x357ec6['token'],_0x52c7e2=new wh(_0xf7a126,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x13ca26,_0x2dd9d0,_0x4abfac,_0x5dd6d0=>{U(_0x5dd6d0+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x2e5cf4));}catch(_0x53c7cf){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x53c7cf),_0x5f5468||(this['repoInfo_']['nodeAdmin']&&U(_0x53c7cf),_0x3b79b2());}}}['interrupt'](_0x5b5773){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5b5773),this['interruptReasons_'][_0x5b5773]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x72f598){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x72f598),delete this['interruptReasons_'][_0x72f598],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3b54e9){const _0x574793=_0x3b54e9-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x574793});}['cancelSentTransactions_'](){for(let _0x3fa371=0x0;_0x3fa371<this['outstandingPuts_']['length'];_0x3fa371++){const _0xca3f4a=this['outstandingPuts_'][_0x3fa371];_0xca3f4a&&'h'in _0xca3f4a['request']&&_0xca3f4a['queued']&&(_0xca3f4a['onComplete']&&_0xca3f4a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3fa371],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x432d19,_0x24cd9d){let _0xf28317;_0x24cd9d?_0xf28317=_0x24cd9d['map'](_0x32c10d=>Bi(_0x32c10d))['join']('$'):_0xf28317='default';const _0x504aeb=this['removeListen_'](_0x432d19,_0xf28317);_0x504aeb&&_0x504aeb['onComplete']&&_0x504aeb['onComplete']('permission_denied');}['removeListen_'](_0x2a493e,_0x358581){const _0x84a2c8=new C(_0x2a493e)['toString']();let _0x145b10;if(this['listens']['has'](_0x84a2c8)){const _0x2f4bba=this['listens']['get'](_0x84a2c8);_0x145b10=_0x2f4bba['get'](_0x358581),_0x2f4bba['delete'](_0x358581),_0x2f4bba['size']===0x0&&this['listens']['delete'](_0x84a2c8);}else _0x145b10=void 0x0;return _0x145b10;}['onAuthRevoked_'](_0xee0c4f,_0x34cf3e){L('Auth\x20token\x20revoked:\x20'+_0xee0c4f+'/'+_0x34cf3e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xee0c4f==='invalid_token'||_0xee0c4f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xc1b97e,_0x17a616){L('App\x20check\x20token\x20revoked:\x20'+_0xc1b97e+'/'+_0x17a616),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xc1b97e==='invalid_token'||_0xc1b97e==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4e506d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4e506d):'msg'in _0x4e506d&&console['log']('FIREBASE:\x20'+_0x4e506d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x26a95b of this['listens']['values']())for(const _0x4413ca of _0x26a95b['values']())this['sendListen_'](_0x4413ca);for(let _0x1bbfb1=0x0;_0x1bbfb1<this['outstandingPuts_']['length'];_0x1bbfb1++)this['outstandingPuts_'][_0x1bbfb1]&&this['sendPut_'](_0x1bbfb1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x420152=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x420152['action'],_0x420152['pathString'],_0x420152['data'],_0x420152['onComplete']);}for(let _0x20b47f=0x0;_0x20b47f<this['outstandingGets_']['length'];_0x20b47f++)this['outstandingGets_'][_0x20b47f]&&this['sendGet_'](_0x20b47f);}['sendConnectStats_'](){const _0x2a81af={};let _0x178a16='js';_0x2a81af['sdk.'+_0x178a16+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x2a81af['framework.cordova']=0x1:qr()&&(_0x2a81af['framework.reactnative']=0x1),this['reportStats'](_0x2a81af);}['shouldReconnect_'](){const _0x39343a=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x39343a;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x28c3ac,_0x215102){this['name']=_0x28c3ac,this['node']=_0x215102;}static['Wrap'](_0x4fe3a8,_0x41f46f){return new E(_0x4fe3a8,_0x41f46f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xa11ab5,_0x2424d3){const _0x3ed3c4=new E(xe,_0xa11ab5),_0x1d882b=new E(xe,_0x2424d3);return this['compare'](_0x3ed3c4,_0x1d882b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x5f0d18){Xt=_0x5f0d18;}['compare'](_0x48cc53,_0x2c0f7a){return He(_0x48cc53['name'],_0x2c0f7a['name']);}['isDefinedOn'](_0x421d3e){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xcef6bd,_0x140056){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x5dfa80,_0x1cd5d6){return f(typeof _0x5dfa80=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5dfa80,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x1bbb0b,_0x6d7e7,_0x7e4a96,_0x349ac7,_0x3cc111=null){this['isReverse_']=_0x349ac7,this['resultGenerator_']=_0x3cc111,this['nodeStack_']=[];let _0x54c9f0=0x1;for(;!_0x1bbb0b['isEmpty']();)if(_0x1bbb0b=_0x1bbb0b,_0x54c9f0=_0x6d7e7?_0x7e4a96(_0x1bbb0b['key'],_0x6d7e7):0x1,_0x349ac7&&(_0x54c9f0*=-0x1),_0x54c9f0<0x0)this['isReverse_']?_0x1bbb0b=_0x1bbb0b['left']:_0x1bbb0b=_0x1bbb0b['right'];else{if(_0x54c9f0===0x0){this['nodeStack_']['push'](_0x1bbb0b);break;}else this['nodeStack_']['push'](_0x1bbb0b),this['isReverse_']?_0x1bbb0b=_0x1bbb0b['right']:_0x1bbb0b=_0x1bbb0b['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1b39af=this['nodeStack_']['pop'](),_0x482cd4;if(this['resultGenerator_']?_0x482cd4=this['resultGenerator_'](_0x1b39af['key'],_0x1b39af['value']):_0x482cd4={'key':_0x1b39af['key'],'value':_0x1b39af['value']},this['isReverse_']){for(_0x1b39af=_0x1b39af['left'];!_0x1b39af['isEmpty']();)this['nodeStack_']['push'](_0x1b39af),_0x1b39af=_0x1b39af['right'];}else{for(_0x1b39af=_0x1b39af['right'];!_0x1b39af['isEmpty']();)this['nodeStack_']['push'](_0x1b39af),_0x1b39af=_0x1b39af['left'];}return _0x482cd4;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x58bba4=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x58bba4['key'],_0x58bba4['value']):{'key':_0x58bba4['key'],'value':_0x58bba4['value']};}}class M{constructor(_0x5d608b,_0x160f38,_0x4fe0f9,_0x47876a,_0x4e56b1){this['key']=_0x5d608b,this['value']=_0x160f38,this['color']=_0x4fe0f9??M['RED'],this['left']=_0x47876a??B['EMPTY_NODE'],this['right']=_0x4e56b1??B['EMPTY_NODE'];}['copy'](_0x4f67e0,_0x3ed77e,_0x5072d8,_0x2984d9,_0x3cb310){return new M(_0x4f67e0??this['key'],_0x3ed77e??this['value'],_0x5072d8??this['color'],_0x2984d9??this['left'],_0x3cb310??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x160755){return this['left']['inorderTraversal'](_0x160755)||!!_0x160755(this['key'],this['value'])||this['right']['inorderTraversal'](_0x160755);}['reverseTraversal'](_0x32e15c){return this['right']['reverseTraversal'](_0x32e15c)||_0x32e15c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x32e15c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xa565f1,_0xa1bd59,_0x24834f){let _0x31297f=this;const _0x28f499=_0x24834f(_0xa565f1,_0x31297f['key']);return _0x28f499<0x0?_0x31297f=_0x31297f['copy'](null,null,null,_0x31297f['left']['insert'](_0xa565f1,_0xa1bd59,_0x24834f),null):_0x28f499===0x0?_0x31297f=_0x31297f['copy'](null,_0xa1bd59,null,null,null):_0x31297f=_0x31297f['copy'](null,null,null,null,_0x31297f['right']['insert'](_0xa565f1,_0xa1bd59,_0x24834f)),_0x31297f['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x40d111=this;return!_0x40d111['left']['isRed_']()&&!_0x40d111['left']['left']['isRed_']()&&(_0x40d111=_0x40d111['moveRedLeft_']()),_0x40d111=_0x40d111['copy'](null,null,null,_0x40d111['left']['removeMin_'](),null),_0x40d111['fixUp_']();}['remove'](_0x5d081b,_0x3e857c){let _0x190555,_0x2b8ba0;if(_0x190555=this,_0x3e857c(_0x5d081b,_0x190555['key'])<0x0)!_0x190555['left']['isEmpty']()&&!_0x190555['left']['isRed_']()&&!_0x190555['left']['left']['isRed_']()&&(_0x190555=_0x190555['moveRedLeft_']()),_0x190555=_0x190555['copy'](null,null,null,_0x190555['left']['remove'](_0x5d081b,_0x3e857c),null);else{if(_0x190555['left']['isRed_']()&&(_0x190555=_0x190555['rotateRight_']()),!_0x190555['right']['isEmpty']()&&!_0x190555['right']['isRed_']()&&!_0x190555['right']['left']['isRed_']()&&(_0x190555=_0x190555['moveRedRight_']()),_0x3e857c(_0x5d081b,_0x190555['key'])===0x0){if(_0x190555['right']['isEmpty']())return B['EMPTY_NODE'];_0x2b8ba0=_0x190555['right']['min_'](),_0x190555=_0x190555['copy'](_0x2b8ba0['key'],_0x2b8ba0['value'],null,null,_0x190555['right']['removeMin_']());}_0x190555=_0x190555['copy'](null,null,null,null,_0x190555['right']['remove'](_0x5d081b,_0x3e857c));}return _0x190555['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5ddff4=this;return _0x5ddff4['right']['isRed_']()&&!_0x5ddff4['left']['isRed_']()&&(_0x5ddff4=_0x5ddff4['rotateLeft_']()),_0x5ddff4['left']['isRed_']()&&_0x5ddff4['left']['left']['isRed_']()&&(_0x5ddff4=_0x5ddff4['rotateRight_']()),_0x5ddff4['left']['isRed_']()&&_0x5ddff4['right']['isRed_']()&&(_0x5ddff4=_0x5ddff4['colorFlip_']()),_0x5ddff4;}['moveRedLeft_'](){let _0x30b1a1=this['colorFlip_']();return _0x30b1a1['right']['left']['isRed_']()&&(_0x30b1a1=_0x30b1a1['copy'](null,null,null,null,_0x30b1a1['right']['rotateRight_']()),_0x30b1a1=_0x30b1a1['rotateLeft_'](),_0x30b1a1=_0x30b1a1['colorFlip_']()),_0x30b1a1;}['moveRedRight_'](){let _0x2fca19=this['colorFlip_']();return _0x2fca19['left']['left']['isRed_']()&&(_0x2fca19=_0x2fca19['rotateRight_'](),_0x2fca19=_0x2fca19['colorFlip_']()),_0x2fca19;}['rotateLeft_'](){const _0x3c9a8b=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3c9a8b,null);}['rotateRight_'](){const _0x2e34a9=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2e34a9);}['colorFlip_'](){const _0x375008=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x373685=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x375008,_0x373685);}['checkMaxDepth_'](){const _0x1508c3=this['check_']();return Math['pow'](0x2,_0x1508c3)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x579ed8=this['left']['check_']();if(_0x579ed8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x579ed8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x1ee205,_0x5ea50b,_0x445d53,_0x340695,_0x497922){return this;}['insert'](_0x305d9e,_0x15392e,_0xd58070){return new M(_0x305d9e,_0x15392e,null);}['remove'](_0x553fc3,_0x43f340){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1862ae){return!0x1;}['reverseTraversal'](_0x1f57af){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5a7872,_0x25a16a=B['EMPTY_NODE']){this['comparator_']=_0x5a7872,this['root_']=_0x25a16a;}['insert'](_0x41a2b1,_0x1b3ccb){return new B(this['comparator_'],this['root_']['insert'](_0x41a2b1,_0x1b3ccb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x36b0ec){return new B(this['comparator_'],this['root_']['remove'](_0x36b0ec,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1e8860){let _0x31fc97,_0x4eb9c2=this['root_'];for(;!_0x4eb9c2['isEmpty']();){if(_0x31fc97=this['comparator_'](_0x1e8860,_0x4eb9c2['key']),_0x31fc97===0x0)return _0x4eb9c2['value'];_0x31fc97<0x0?_0x4eb9c2=_0x4eb9c2['left']:_0x31fc97>0x0&&(_0x4eb9c2=_0x4eb9c2['right']);}return null;}['getPredecessorKey'](_0x31c3de){let _0x54dc8a,_0x50e995=this['root_'],_0x2c7882=null;for(;!_0x50e995['isEmpty']();)if(_0x54dc8a=this['comparator_'](_0x31c3de,_0x50e995['key']),_0x54dc8a===0x0){if(_0x50e995['left']['isEmpty']())return _0x2c7882?_0x2c7882['key']:null;for(_0x50e995=_0x50e995['left'];!_0x50e995['right']['isEmpty']();)_0x50e995=_0x50e995['right'];return _0x50e995['key'];}else _0x54dc8a<0x0?_0x50e995=_0x50e995['left']:_0x54dc8a>0x0&&(_0x2c7882=_0x50e995,_0x50e995=_0x50e995['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1d5008){return this['root_']['inorderTraversal'](_0x1d5008);}['reverseTraversal'](_0x524445){return this['root_']['reverseTraversal'](_0x524445);}['getIterator'](_0x4927df){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x4927df);}['getIteratorFrom'](_0x3394ba,_0x9eeb91){return new Zt(this['root_'],_0x3394ba,this['comparator_'],!0x1,_0x9eeb91);}['getReverseIteratorFrom'](_0x46a272,_0x4c4d27){return new Zt(this['root_'],_0x46a272,this['comparator_'],!0x0,_0x4c4d27);}['getReverseIterator'](_0xc8bfd1){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0xc8bfd1);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x580aa8,_0x235b0a){return He(_0x580aa8['name'],_0x235b0a['name']);}function ji(_0x18f85c,_0x12465b){return He(_0x18f85c,_0x12465b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0xcc9147){vi=_0xcc9147;}const Ro=function(_0x5c43c1){return typeof _0x5c43c1=='number'?'number:'+so(_0x5c43c1):'string:'+_0x5c43c1;},Ao=function(_0x56f2f1){if(_0x56f2f1['isLeafNode']()){const _0x473e33=_0x56f2f1['val']();f(typeof _0x473e33=='string'||typeof _0x473e33=='number'||typeof _0x473e33=='object'&&Y(_0x473e33,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x56f2f1===vi||_0x56f2f1['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x56f2f1===vi||_0x56f2f1['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3b224e){er=_0x3b224e;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2990ba,_0x637504=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2990ba,this['priorityNode_']=_0x637504,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x22a8c4){return new D(this['value_'],_0x22a8c4);}['getImmediateChild'](_0x1f0a66){return _0x1f0a66==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x43413){return v(_0x43413)?this:y(_0x43413)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x146441,_0x5dbd62){return null;}['updateImmediateChild'](_0xe6401f,_0x1d72dc){return _0xe6401f==='.priority'?this['updatePriority'](_0x1d72dc):_0x1d72dc['isEmpty']()&&_0xe6401f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xe6401f,_0x1d72dc)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x50e4b5,_0x32eed0){const _0x2344d5=y(_0x50e4b5);return _0x2344d5===null?_0x32eed0:_0x32eed0['isEmpty']()&&_0x2344d5!=='.priority'?this:(f(_0x2344d5!=='.priority'||we(_0x50e4b5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2344d5,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x50e4b5),_0x32eed0)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2fc206,_0x3e3227){return!0x1;}['val'](_0x21456c){return _0x21456c&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5446a2='';this['priorityNode_']['isEmpty']()||(_0x5446a2+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1b07c6=typeof this['value_'];_0x5446a2+=_0x1b07c6+':',_0x1b07c6==='number'?_0x5446a2+=so(this['value_']):_0x5446a2+=this['value_'],this['lazyHash_']=no(_0x5446a2);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1a86c3){return _0x1a86c3===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1a86c3 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1a86c3['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1a86c3));}['compareToLeafNode_'](_0x1caf9c){const _0x39d7e2=typeof _0x1caf9c['value_'],_0x199066=typeof this['value_'],_0x215d75=D['VALUE_TYPE_ORDER']['indexOf'](_0x39d7e2),_0x8e0095=D['VALUE_TYPE_ORDER']['indexOf'](_0x199066);return f(_0x215d75>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x39d7e2),f(_0x8e0095>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x199066),_0x215d75===_0x8e0095?_0x199066==='object'?0x0:this['value_']<_0x1caf9c['value_']?-0x1:this['value_']===_0x1caf9c['value_']?0x0:0x1:_0x8e0095-_0x215d75;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x564c64){if(_0x564c64===this)return!0x0;if(_0x564c64['isLeafNode']()){const _0x40d205=_0x564c64;return this['value_']===_0x40d205['value_']&&this['priorityNode_']['equals'](_0x40d205['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1617af){ko=_0x1617af;}function xh(_0x4da568){No=_0x4da568;}class Fh extends On{['compare'](_0x4dfef2,_0x159c9f){const _0x3eb1fe=_0x4dfef2['node']['getPriority'](),_0x1c6318=_0x159c9f['node']['getPriority'](),_0x4c9421=_0x3eb1fe['compareTo'](_0x1c6318);return _0x4c9421===0x0?He(_0x4dfef2['name'],_0x159c9f['name']):_0x4c9421;}['isDefinedOn'](_0x326584){return!_0x326584['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x46164b,_0x124e0b){return!_0x46164b['getPriority']()['equals'](_0x124e0b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x4a1571,_0x42b101){const _0x1b1255=ko(_0x4a1571);return new E(_0x42b101,new D('[PRIORITY-POST]',_0x1b1255));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x45c0c4){const _0x548105=_0x590422=>parseInt(Math['log'](_0x590422)/Uh,0xa),_0x456763=_0x233a4b=>parseInt(Array(_0x233a4b+0x1)['join']('1'),0x2);this['count']=_0x548105(_0x45c0c4+0x1),this['current_']=this['count']-0x1;const _0x368295=_0x456763(this['count']);this['bits_']=_0x45c0c4+0x1&_0x368295;}['nextBitIsOne'](){const _0x18c426=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x18c426;}}const dn=function(_0x10f46e,_0x5cddc3,_0xcfca9a,_0x35e320){_0x10f46e['sort'](_0x5cddc3);const _0x589dac=function(_0x166f1d,_0x293a15){const _0x711ef5=_0x293a15-_0x166f1d;let _0x32dbad,_0x216795;if(_0x711ef5===0x0)return null;if(_0x711ef5===0x1)return _0x32dbad=_0x10f46e[_0x166f1d],_0x216795=_0xcfca9a?_0xcfca9a(_0x32dbad):_0x32dbad,new M(_0x216795,_0x32dbad['node'],M['BLACK'],null,null);{const _0x487db8=parseInt(_0x711ef5/0x2,0xa)+_0x166f1d,_0x14d0ed=_0x589dac(_0x166f1d,_0x487db8),_0xc32024=_0x589dac(_0x487db8+0x1,_0x293a15);return _0x32dbad=_0x10f46e[_0x487db8],_0x216795=_0xcfca9a?_0xcfca9a(_0x32dbad):_0x32dbad,new M(_0x216795,_0x32dbad['node'],M['BLACK'],_0x14d0ed,_0xc32024);}},_0x5b1405=function(_0x5988fc){let _0x38d6df=null,_0x4726ad=null,_0x5aa151=_0x10f46e['length'];const _0x55f7d9=function(_0x371532,_0x11fa3c){const _0x30b4b2=_0x5aa151-_0x371532,_0x1459f3=_0x5aa151;_0x5aa151-=_0x371532;const _0x5313f4=_0x589dac(_0x30b4b2+0x1,_0x1459f3),_0x1cc132=_0x10f46e[_0x30b4b2],_0x5b3ac6=_0xcfca9a?_0xcfca9a(_0x1cc132):_0x1cc132;_0x498a37(new M(_0x5b3ac6,_0x1cc132['node'],_0x11fa3c,null,_0x5313f4));},_0x498a37=function(_0x39a82b){_0x38d6df?(_0x38d6df['left']=_0x39a82b,_0x38d6df=_0x39a82b):(_0x4726ad=_0x39a82b,_0x38d6df=_0x39a82b);};for(let _0x18c394=0x0;_0x18c394<_0x5988fc['count'];++_0x18c394){const _0x20ca33=_0x5988fc['nextBitIsOne'](),_0x269193=Math['pow'](0x2,_0x5988fc['count']-(_0x18c394+0x1));_0x20ca33?_0x55f7d9(_0x269193,M['BLACK']):(_0x55f7d9(_0x269193,M['BLACK']),_0x55f7d9(_0x269193,M['RED']));}return _0x4726ad;},_0x286b55=new Wh(_0x10f46e['length']),_0x4e6593=_0x5b1405(_0x286b55);return new B(_0x35e320||_0x5cddc3,_0x4e6593);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x40c942,_0xe592dd){this['indexes_']=_0x40c942,this['indexSet_']=_0xe592dd;}['get'](_0x2eefda){const _0x25c173=Oe(this['indexes_'],_0x2eefda);if(!_0x25c173)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2eefda);return _0x25c173 instanceof B?_0x25c173:null;}['hasIndex'](_0x8b00c){return Y(this['indexSet_'],_0x8b00c['toString']());}['addIndex'](_0x3bb923,_0x59c6c4){f(_0x3bb923!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2b0f41=[];let _0x1ee729=!0x1;const _0x26ca65=_0x59c6c4['getIterator'](E['Wrap']);let _0x16d655=_0x26ca65['getNext']();for(;_0x16d655;)_0x1ee729=_0x1ee729||_0x3bb923['isDefinedOn'](_0x16d655['node']),_0x2b0f41['push'](_0x16d655),_0x16d655=_0x26ca65['getNext']();let _0x42f04f;_0x1ee729?_0x42f04f=dn(_0x2b0f41,_0x3bb923['getCompare']()):_0x42f04f=je;const _0x5a7796=_0x3bb923['toString'](),_0x49d129={...this['indexSet_']};_0x49d129[_0x5a7796]=_0x3bb923;const _0x5870ff={...this['indexes_']};return _0x5870ff[_0x5a7796]=_0x42f04f,new ee(_0x5870ff,_0x49d129);}['addToIndexes'](_0x2f675d,_0x4b0e7b){const _0x98e8cc=ln(this['indexes_'],(_0x1b9630,_0x4f70de)=>{const _0x219fe1=Oe(this['indexSet_'],_0x4f70de);if(f(_0x219fe1,'Missing\x20index\x20implementation\x20for\x20'+_0x4f70de),_0x1b9630===je){if(_0x219fe1['isDefinedOn'](_0x2f675d['node'])){const _0x1c2528=[],_0x91339f=_0x4b0e7b['getIterator'](E['Wrap']);let _0xfce382=_0x91339f['getNext']();for(;_0xfce382;)_0xfce382['name']!==_0x2f675d['name']&&_0x1c2528['push'](_0xfce382),_0xfce382=_0x91339f['getNext']();return _0x1c2528['push'](_0x2f675d),dn(_0x1c2528,_0x219fe1['getCompare']());}else return je;}else{const _0x35ed2d=_0x4b0e7b['get'](_0x2f675d['name']);let _0x2243ef=_0x1b9630;return _0x35ed2d&&(_0x2243ef=_0x2243ef['remove'](new E(_0x2f675d['name'],_0x35ed2d))),_0x2243ef['insert'](_0x2f675d,_0x2f675d['node']);}});return new ee(_0x98e8cc,this['indexSet_']);}['removeFromIndexes'](_0x262d9b,_0x458e0b){const _0x397e05=ln(this['indexes_'],_0x11b0c2=>{if(_0x11b0c2===je)return _0x11b0c2;{const _0x135311=_0x458e0b['get'](_0x262d9b['name']);return _0x135311?_0x11b0c2['remove'](new E(_0x262d9b['name'],_0x135311)):_0x11b0c2;}});return new ee(_0x397e05,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0xf781ae,_0x3bf0d5,_0x2afaac){this['children_']=_0xf781ae,this['priorityNode_']=_0x3bf0d5,this['indexMap_']=_0x2afaac,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1a9e69){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1a9e69,this['indexMap_']);}['getImmediateChild'](_0xe4b752){if(_0xe4b752==='.priority')return this['getPriority']();{const _0x42e8f7=this['children_']['get'](_0xe4b752);return _0x42e8f7===null?gt:_0x42e8f7;}}['getChild'](_0x425710){const _0x4de437=y(_0x425710);return _0x4de437===null?this:this['getImmediateChild'](_0x4de437)['getChild'](b(_0x425710));}['hasChild'](_0x1ea806){return this['children_']['get'](_0x1ea806)!==null;}['updateImmediateChild'](_0x487709,_0x2d671f){if(f(_0x2d671f,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x487709==='.priority')return this['updatePriority'](_0x2d671f);{const _0x2df120=new E(_0x487709,_0x2d671f);let _0x2cfa3d,_0xdaacf8;_0x2d671f['isEmpty']()?(_0x2cfa3d=this['children_']['remove'](_0x487709),_0xdaacf8=this['indexMap_']['removeFromIndexes'](_0x2df120,this['children_'])):(_0x2cfa3d=this['children_']['insert'](_0x487709,_0x2d671f),_0xdaacf8=this['indexMap_']['addToIndexes'](_0x2df120,this['children_']));const _0x13b107=_0x2cfa3d['isEmpty']()?gt:this['priorityNode_'];return new g(_0x2cfa3d,_0x13b107,_0xdaacf8);}}['updateChild'](_0x4436bf,_0x4990ed){const _0x4a35cc=y(_0x4436bf);if(_0x4a35cc===null)return _0x4990ed;{f(y(_0x4436bf)!=='.priority'||we(_0x4436bf)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x343b41=this['getImmediateChild'](_0x4a35cc)['updateChild'](b(_0x4436bf),_0x4990ed);return this['updateImmediateChild'](_0x4a35cc,_0x343b41);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x576ec7){if(this['isEmpty']())return null;const _0x2645ee={};let _0x20a238=0x0,_0x56150e=0x0,_0x808c63=!0x0;if(this['forEachChild'](R,(_0x21971d,_0x2844cc)=>{_0x2645ee[_0x21971d]=_0x2844cc['val'](_0x576ec7),_0x20a238++,_0x808c63&&g['INTEGER_REGEXP_']['test'](_0x21971d)?_0x56150e=Math['max'](_0x56150e,Number(_0x21971d)):_0x808c63=!0x1;}),!_0x576ec7&&_0x808c63&&_0x56150e<0x2*_0x20a238){const _0x73dc2a=[];for(const _0xf9642a in _0x2645ee)_0x73dc2a[_0xf9642a]=_0x2645ee[_0xf9642a];return _0x73dc2a;}else return _0x576ec7&&!this['getPriority']()['isEmpty']()&&(_0x2645ee['.priority']=this['getPriority']()['val']()),_0x2645ee;}['hash'](){if(this['lazyHash_']===null){let _0x29d688='';this['getPriority']()['isEmpty']()||(_0x29d688+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x9a334a,_0x5bdacb)=>{const _0x44451e=_0x5bdacb['hash']();_0x44451e!==''&&(_0x29d688+=':'+_0x9a334a+':'+_0x44451e);}),this['lazyHash_']=_0x29d688===''?'':no(_0x29d688);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2e43a7,_0x15c8d6,_0x332bbd){const _0x1448f1=this['resolveIndex_'](_0x332bbd);if(_0x1448f1){const _0x32c73b=_0x1448f1['getPredecessorKey'](new E(_0x2e43a7,_0x15c8d6));return _0x32c73b?_0x32c73b['name']:null;}else return this['children_']['getPredecessorKey'](_0x2e43a7);}['getFirstChildName'](_0x247f22){const _0x440b3a=this['resolveIndex_'](_0x247f22);if(_0x440b3a){const _0x2f79b1=_0x440b3a['minKey']();return _0x2f79b1&&_0x2f79b1['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x536515){const _0x4d5dbe=this['getFirstChildName'](_0x536515);return _0x4d5dbe?new E(_0x4d5dbe,this['children_']['get'](_0x4d5dbe)):null;}['getLastChildName'](_0x55067b){const _0x86a3b=this['resolveIndex_'](_0x55067b);if(_0x86a3b){const _0x440b1f=_0x86a3b['maxKey']();return _0x440b1f&&_0x440b1f['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x32db0b){const _0x8d4cde=this['getLastChildName'](_0x32db0b);return _0x8d4cde?new E(_0x8d4cde,this['children_']['get'](_0x8d4cde)):null;}['forEachChild'](_0x4c8c7d,_0x3893bf){const _0x55cf59=this['resolveIndex_'](_0x4c8c7d);return _0x55cf59?_0x55cf59['inorderTraversal'](_0x376520=>_0x3893bf(_0x376520['name'],_0x376520['node'])):this['children_']['inorderTraversal'](_0x3893bf);}['getIterator'](_0xa38a60){return this['getIteratorFrom'](_0xa38a60['minPost'](),_0xa38a60);}['getIteratorFrom'](_0x47e16f,_0x3fe207){const _0x2454ad=this['resolveIndex_'](_0x3fe207);if(_0x2454ad)return _0x2454ad['getIteratorFrom'](_0x47e16f,_0x3c9ade=>_0x3c9ade);{const _0x5a612b=this['children_']['getIteratorFrom'](_0x47e16f['name'],E['Wrap']);let _0x2527cf=_0x5a612b['peek']();for(;_0x2527cf!=null&&_0x3fe207['compare'](_0x2527cf,_0x47e16f)<0x0;)_0x5a612b['getNext'](),_0x2527cf=_0x5a612b['peek']();return _0x5a612b;}}['getReverseIterator'](_0x5dc51c){return this['getReverseIteratorFrom'](_0x5dc51c['maxPost'](),_0x5dc51c);}['getReverseIteratorFrom'](_0x3a6a67,_0x5ab92b){const _0x2d68a4=this['resolveIndex_'](_0x5ab92b);if(_0x2d68a4)return _0x2d68a4['getReverseIteratorFrom'](_0x3a6a67,_0x4f2f3a=>_0x4f2f3a);{const _0x28979f=this['children_']['getReverseIteratorFrom'](_0x3a6a67['name'],E['Wrap']);let _0x22ac4d=_0x28979f['peek']();for(;_0x22ac4d!=null&&_0x5ab92b['compare'](_0x22ac4d,_0x3a6a67)>0x0;)_0x28979f['getNext'](),_0x22ac4d=_0x28979f['peek']();return _0x28979f;}}['compareTo'](_0x29906b){return this['isEmpty']()?_0x29906b['isEmpty']()?0x0:-0x1:_0x29906b['isLeafNode']()||_0x29906b['isEmpty']()?0x1:_0x29906b===Ht?-0x1:0x0;}['withIndex'](_0x1a9044){if(_0x1a9044===ye||this['indexMap_']['hasIndex'](_0x1a9044))return this;{const _0x2952f9=this['indexMap_']['addIndex'](_0x1a9044,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2952f9);}}['isIndexed'](_0x5e6d77){return _0x5e6d77===ye||this['indexMap_']['hasIndex'](_0x5e6d77);}['equals'](_0x43d38d){if(_0x43d38d===this)return!0x0;if(_0x43d38d['isLeafNode']())return!0x1;{const _0x177d73=_0x43d38d;if(this['getPriority']()['equals'](_0x177d73['getPriority']())){if(this['children_']['count']()===_0x177d73['children_']['count']()){const _0x10c767=this['getIterator'](R),_0x5b66a6=_0x177d73['getIterator'](R);let _0x1a78ef=_0x10c767['getNext'](),_0x4541e5=_0x5b66a6['getNext']();for(;_0x1a78ef&&_0x4541e5;){if(_0x1a78ef['name']!==_0x4541e5['name']||!_0x1a78ef['node']['equals'](_0x4541e5['node']))return!0x1;_0x1a78ef=_0x10c767['getNext'](),_0x4541e5=_0x5b66a6['getNext']();}return _0x1a78ef===null&&_0x4541e5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x38dadb){return _0x38dadb===ye?null:this['indexMap_']['get'](_0x38dadb['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x403e66){return _0x403e66===this?0x0:0x1;}['equals'](_0x5c6f30){return _0x5c6f30===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5e0815){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x1266de,_0xec67a1=null){if(_0x1266de===null)return g['EMPTY_NODE'];if(typeof _0x1266de=='object'&&'.priority'in _0x1266de&&(_0xec67a1=_0x1266de['.priority']),f(_0xec67a1===null||typeof _0xec67a1=='string'||typeof _0xec67a1=='number'||typeof _0xec67a1=='object'&&'.sv'in _0xec67a1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xec67a1),typeof _0x1266de=='object'&&'.value'in _0x1266de&&_0x1266de['.value']!==null&&(_0x1266de=_0x1266de['.value']),typeof _0x1266de!='object'||'.sv'in _0x1266de){const _0x12f653=_0x1266de;return new D(_0x12f653,N(_0xec67a1));}if(!(_0x1266de instanceof Array)&&Vh){const _0x5bb03b=[];let _0xa0182a=!0x1;if(x(_0x1266de,(_0x1baee5,_0x265cc1)=>{if(_0x1baee5['substring'](0x0,0x1)!=='.'){const _0x2a4679=N(_0x265cc1);_0x2a4679['isEmpty']()||(_0xa0182a=_0xa0182a||!_0x2a4679['getPriority']()['isEmpty'](),_0x5bb03b['push'](new E(_0x1baee5,_0x2a4679)));}}),_0x5bb03b['length']===0x0)return g['EMPTY_NODE'];const _0x7373b5=dn(_0x5bb03b,Dh,_0x3fcd88=>_0x3fcd88['name'],ji);if(_0xa0182a){const _0x5a74c4=dn(_0x5bb03b,R['getCompare']());return new g(_0x7373b5,N(_0xec67a1),new ee({'.priority':_0x5a74c4},{'.priority':R}));}else return new g(_0x7373b5,N(_0xec67a1),ee['Default']);}else{let _0x4d0fe7=g['EMPTY_NODE'];return x(_0x1266de,(_0x533717,_0x4ce95b)=>{if(Y(_0x1266de,_0x533717)&&_0x533717['substring'](0x0,0x1)!=='.'){const _0x270ab3=N(_0x4ce95b);(_0x270ab3['isLeafNode']()||!_0x270ab3['isEmpty']())&&(_0x4d0fe7=_0x4d0fe7['updateImmediateChild'](_0x533717,_0x270ab3));}}),_0x4d0fe7['updatePriority'](N(_0xec67a1));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2286f5){super(),this['indexPath_']=_0x2286f5,f(!v(_0x2286f5)&&y(_0x2286f5)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xb6f0ba){return _0xb6f0ba['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3443a6){return!_0x3443a6['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x36e43c,_0x1dd260){const _0xcc59dd=this['extractChild'](_0x36e43c['node']),_0x2ad36d=this['extractChild'](_0x1dd260['node']),_0x536d2e=_0xcc59dd['compareTo'](_0x2ad36d);return _0x536d2e===0x0?He(_0x36e43c['name'],_0x1dd260['name']):_0x536d2e;}['makePost'](_0x490a83,_0xd8094b){const _0x5bbf9f=N(_0x490a83),_0xccae91=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5bbf9f);return new E(_0xd8094b,_0xccae91);}['maxPost'](){const _0x48caa1=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x48caa1);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x41ef2a,_0x30c036){const _0x1da387=_0x41ef2a['node']['compareTo'](_0x30c036['node']);return _0x1da387===0x0?He(_0x41ef2a['name'],_0x30c036['name']):_0x1da387;}['isDefinedOn'](_0x3408fe){return!0x0;}['indexedValueChanged'](_0x4ae429,_0x42b1f9){return!_0x4ae429['equals'](_0x42b1f9);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xb73b1d,_0x5bf541){const _0x321334=N(_0xb73b1d);return new E(_0x5bf541,_0x321334);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x120a56){return{'type':'value','snapshotNode':_0x120a56};}function tt(_0x2ab796,_0x46a2bf){return{'type':'child_added','snapshotNode':_0x46a2bf,'childName':_0x2ab796};}function Nt(_0x4a5a96,_0x1ffd5d){return{'type':'child_removed','snapshotNode':_0x1ffd5d,'childName':_0x4a5a96};}function Pt(_0x26a594,_0x516b5e,_0x239b2c){return{'type':'child_changed','snapshotNode':_0x516b5e,'childName':_0x26a594,'oldSnap':_0x239b2c};}function $h(_0x337f5e,_0x9380d0){return{'type':'child_moved','snapshotNode':_0x9380d0,'childName':_0x337f5e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x21a6d3){this['index_']=_0x21a6d3;}['updateChild'](_0x3c8a9b,_0x2abf27,_0x5aef83,_0x14f56a,_0x3b43dd,_0x3bccea){f(_0x3c8a9b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4351f6=_0x3c8a9b['getImmediateChild'](_0x2abf27);return _0x4351f6['getChild'](_0x14f56a)['equals'](_0x5aef83['getChild'](_0x14f56a))&&_0x4351f6['isEmpty']()===_0x5aef83['isEmpty']()||(_0x3bccea!=null&&(_0x5aef83['isEmpty']()?_0x3c8a9b['hasChild'](_0x2abf27)?_0x3bccea['trackChildChange'](Nt(_0x2abf27,_0x4351f6)):f(_0x3c8a9b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4351f6['isEmpty']()?_0x3bccea['trackChildChange'](tt(_0x2abf27,_0x5aef83)):_0x3bccea['trackChildChange'](Pt(_0x2abf27,_0x5aef83,_0x4351f6))),_0x3c8a9b['isLeafNode']()&&_0x5aef83['isEmpty']())?_0x3c8a9b:_0x3c8a9b['updateImmediateChild'](_0x2abf27,_0x5aef83)['withIndex'](this['index_']);}['updateFullNode'](_0x3a5654,_0x144e47,_0x1485f7){return _0x1485f7!=null&&(_0x3a5654['isLeafNode']()||_0x3a5654['forEachChild'](R,(_0x5debe2,_0x2b447f)=>{_0x144e47['hasChild'](_0x5debe2)||_0x1485f7['trackChildChange'](Nt(_0x5debe2,_0x2b447f));}),_0x144e47['isLeafNode']()||_0x144e47['forEachChild'](R,(_0xa8ead7,_0x43a418)=>{if(_0x3a5654['hasChild'](_0xa8ead7)){const _0x45dcf7=_0x3a5654['getImmediateChild'](_0xa8ead7);_0x45dcf7['equals'](_0x43a418)||_0x1485f7['trackChildChange'](Pt(_0xa8ead7,_0x43a418,_0x45dcf7));}else _0x1485f7['trackChildChange'](tt(_0xa8ead7,_0x43a418));})),_0x144e47['withIndex'](this['index_']);}['updatePriority'](_0x17b0f5,_0x1c663c){return _0x17b0f5['isEmpty']()?g['EMPTY_NODE']:_0x17b0f5['updatePriority'](_0x1c663c);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2a4e4d){this['indexedFilter_']=new Yi(_0x2a4e4d['getIndex']()),this['index_']=_0x2a4e4d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2a4e4d),this['endPost_']=Ot['getEndPost_'](_0x2a4e4d),this['startIsInclusive_']=!_0x2a4e4d['startAfterSet_'],this['endIsInclusive_']=!_0x2a4e4d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3a8d19){const _0x2738af=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3a8d19)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3a8d19)<0x0,_0x401d62=this['endIsInclusive_']?this['index_']['compare'](_0x3a8d19,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3a8d19,this['getEndPost']())<0x0;return _0x2738af&&_0x401d62;}['updateChild'](_0x4379ba,_0x2d76bd,_0x18c84f,_0xbbd9c0,_0x555f4c,_0x3ca3f3){return this['matches'](new E(_0x2d76bd,_0x18c84f))||(_0x18c84f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4379ba,_0x2d76bd,_0x18c84f,_0xbbd9c0,_0x555f4c,_0x3ca3f3);}['updateFullNode'](_0xe3516d,_0x17bb2a,_0x46a2c5){_0x17bb2a['isLeafNode']()&&(_0x17bb2a=g['EMPTY_NODE']);let _0x5694fa=_0x17bb2a['withIndex'](this['index_']);_0x5694fa=_0x5694fa['updatePriority'](g['EMPTY_NODE']);const _0x3f133a=this;return _0x17bb2a['forEachChild'](R,(_0x4b8137,_0xfa042d)=>{_0x3f133a['matches'](new E(_0x4b8137,_0xfa042d))||(_0x5694fa=_0x5694fa['updateImmediateChild'](_0x4b8137,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xe3516d,_0x5694fa,_0x46a2c5);}['updatePriority'](_0x31e99f,_0xc7fa8){return _0x31e99f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x7780c0){if(_0x7780c0['hasStart']()){const _0x32c7ca=_0x7780c0['getIndexStartName']();return _0x7780c0['getIndex']()['makePost'](_0x7780c0['getIndexStartValue'](),_0x32c7ca);}else return _0x7780c0['getIndex']()['minPost']();}static['getEndPost_'](_0x386360){if(_0x386360['hasEnd']()){const _0x486644=_0x386360['getIndexEndName']();return _0x386360['getIndex']()['makePost'](_0x386360['getIndexEndValue'](),_0x486644);}else return _0x386360['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x2e543f){this['withinDirectionalStart']=_0x186c15=>this['reverse_']?this['withinEndPost'](_0x186c15):this['withinStartPost'](_0x186c15),this['withinDirectionalEnd']=_0x3ad269=>this['reverse_']?this['withinStartPost'](_0x3ad269):this['withinEndPost'](_0x3ad269),this['withinStartPost']=_0xabd609=>{const _0xb5c618=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xabd609);return this['startIsInclusive_']?_0xb5c618<=0x0:_0xb5c618<0x0;},this['withinEndPost']=_0x160878=>{const _0x1fde62=this['index_']['compare'](_0x160878,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1fde62<=0x0:_0x1fde62<0x0;},this['rangedFilter_']=new Ot(_0x2e543f),this['index_']=_0x2e543f['getIndex'](),this['limit_']=_0x2e543f['getLimit'](),this['reverse_']=!_0x2e543f['isViewFromLeft'](),this['startIsInclusive_']=!_0x2e543f['startAfterSet_'],this['endIsInclusive_']=!_0x2e543f['endBeforeSet_'];}['updateChild'](_0x104e5d,_0x1d19ab,_0x5541ef,_0x499c91,_0x3476f1,_0x3e1f6b){return this['rangedFilter_']['matches'](new E(_0x1d19ab,_0x5541ef))||(_0x5541ef=g['EMPTY_NODE']),_0x104e5d['getImmediateChild'](_0x1d19ab)['equals'](_0x5541ef)?_0x104e5d:_0x104e5d['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x104e5d,_0x1d19ab,_0x5541ef,_0x499c91,_0x3476f1,_0x3e1f6b):this['fullLimitUpdateChild_'](_0x104e5d,_0x1d19ab,_0x5541ef,_0x3476f1,_0x3e1f6b);}['updateFullNode'](_0x16596d,_0x27d475,_0xcbf698){let _0x58f5c3;if(_0x27d475['isLeafNode']()||_0x27d475['isEmpty']())_0x58f5c3=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x27d475['numChildren']()&&_0x27d475['isIndexed'](this['index_'])){_0x58f5c3=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4009c8;this['reverse_']?_0x4009c8=_0x27d475['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4009c8=_0x27d475['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x135eb7=0x0;for(;_0x4009c8['hasNext']()&&_0x135eb7<this['limit_'];){const _0x30afed=_0x4009c8['getNext']();if(this['withinDirectionalStart'](_0x30afed)){if(this['withinDirectionalEnd'](_0x30afed))_0x58f5c3=_0x58f5c3['updateImmediateChild'](_0x30afed['name'],_0x30afed['node']),_0x135eb7++;else break;}else continue;}}else{_0x58f5c3=_0x27d475['withIndex'](this['index_']),_0x58f5c3=_0x58f5c3['updatePriority'](g['EMPTY_NODE']);let _0x2e7e03;this['reverse_']?_0x2e7e03=_0x58f5c3['getReverseIterator'](this['index_']):_0x2e7e03=_0x58f5c3['getIterator'](this['index_']);let _0x578cbf=0x0;for(;_0x2e7e03['hasNext']();){const _0x56f9ce=_0x2e7e03['getNext']();_0x578cbf<this['limit_']&&this['withinDirectionalStart'](_0x56f9ce)&&this['withinDirectionalEnd'](_0x56f9ce)?_0x578cbf++:_0x58f5c3=_0x58f5c3['updateImmediateChild'](_0x56f9ce['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x16596d,_0x58f5c3,_0xcbf698);}['updatePriority'](_0x415861,_0x192cbc){return _0x415861;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x38ecee,_0x58c65d,_0x3ece16,_0x20595c,_0x25b68e){let _0x32aa46;if(this['reverse_']){const _0x4a8ee9=this['index_']['getCompare']();_0x32aa46=(_0x43a875,_0x4bb1a3)=>_0x4a8ee9(_0x4bb1a3,_0x43a875);}else _0x32aa46=this['index_']['getCompare']();const _0x336f37=_0x38ecee;f(_0x336f37['numChildren']()===this['limit_'],'');const _0x540ddf=new E(_0x58c65d,_0x3ece16),_0x238bf3=this['reverse_']?_0x336f37['getFirstChild'](this['index_']):_0x336f37['getLastChild'](this['index_']),_0x29101e=this['rangedFilter_']['matches'](_0x540ddf);if(_0x336f37['hasChild'](_0x58c65d)){const _0x2cb57d=_0x336f37['getImmediateChild'](_0x58c65d);let _0x319cf9=_0x20595c['getChildAfterChild'](this['index_'],_0x238bf3,this['reverse_']);for(;_0x319cf9!=null&&(_0x319cf9['name']===_0x58c65d||_0x336f37['hasChild'](_0x319cf9['name']));)_0x319cf9=_0x20595c['getChildAfterChild'](this['index_'],_0x319cf9,this['reverse_']);const _0xb972f3=_0x319cf9==null?0x1:_0x32aa46(_0x319cf9,_0x540ddf);if(_0x29101e&&!_0x3ece16['isEmpty']()&&_0xb972f3>=0x0)return _0x25b68e!=null&&_0x25b68e['trackChildChange'](Pt(_0x58c65d,_0x3ece16,_0x2cb57d)),_0x336f37['updateImmediateChild'](_0x58c65d,_0x3ece16);{_0x25b68e!=null&&_0x25b68e['trackChildChange'](Nt(_0x58c65d,_0x2cb57d));const _0x50064c=_0x336f37['updateImmediateChild'](_0x58c65d,g['EMPTY_NODE']);return _0x319cf9!=null&&this['rangedFilter_']['matches'](_0x319cf9)?(_0x25b68e!=null&&_0x25b68e['trackChildChange'](tt(_0x319cf9['name'],_0x319cf9['node'])),_0x50064c['updateImmediateChild'](_0x319cf9['name'],_0x319cf9['node'])):_0x50064c;}}else return _0x3ece16['isEmpty']()?_0x38ecee:_0x29101e&&_0x32aa46(_0x238bf3,_0x540ddf)>=0x0?(_0x25b68e!=null&&(_0x25b68e['trackChildChange'](Nt(_0x238bf3['name'],_0x238bf3['node'])),_0x25b68e['trackChildChange'](tt(_0x58c65d,_0x3ece16))),_0x336f37['updateImmediateChild'](_0x58c65d,_0x3ece16)['updateImmediateChild'](_0x238bf3['name'],g['EMPTY_NODE'])):_0x38ecee;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3d84ef=new Qi();return _0x3d84ef['limitSet_']=this['limitSet_'],_0x3d84ef['limit_']=this['limit_'],_0x3d84ef['startSet_']=this['startSet_'],_0x3d84ef['startAfterSet_']=this['startAfterSet_'],_0x3d84ef['indexStartValue_']=this['indexStartValue_'],_0x3d84ef['startNameSet_']=this['startNameSet_'],_0x3d84ef['indexStartName_']=this['indexStartName_'],_0x3d84ef['endSet_']=this['endSet_'],_0x3d84ef['endBeforeSet_']=this['endBeforeSet_'],_0x3d84ef['indexEndValue_']=this['indexEndValue_'],_0x3d84ef['endNameSet_']=this['endNameSet_'],_0x3d84ef['indexEndName_']=this['indexEndName_'],_0x3d84ef['index_']=this['index_'],_0x3d84ef['viewFrom_']=this['viewFrom_'],_0x3d84ef;}}function qh(_0x4a16f8){return _0x4a16f8['loadsAllData']()?new Yi(_0x4a16f8['getIndex']()):_0x4a16f8['hasLimit']()?new Gh(_0x4a16f8):new Ot(_0x4a16f8);}function zh(_0x116d8d,_0x5afe22){const _0x3a4f00=_0x116d8d['copy']();return _0x3a4f00['limitSet_']=!0x0,_0x3a4f00['limit_']=_0x5afe22,_0x3a4f00['viewFrom_']='l',_0x3a4f00;}function jh(_0x523f7b,_0x516743,_0x8ccb1c){const _0x63ff51=_0x523f7b['copy']();return _0x63ff51['startSet_']=!0x0,_0x516743===void 0x0&&(_0x516743=null),_0x63ff51['indexStartValue_']=_0x516743,_0x8ccb1c!=null?(_0x63ff51['startNameSet_']=!0x0,_0x63ff51['indexStartName_']=_0x8ccb1c):(_0x63ff51['startNameSet_']=!0x1,_0x63ff51['indexStartName_']=''),_0x63ff51;}function Kh(_0xc049,_0x8664f5,_0x220504){const _0x35a319=_0xc049['copy']();return _0x35a319['endSet_']=!0x0,_0x8664f5===void 0x0&&(_0x8664f5=null),_0x35a319['indexEndValue_']=_0x8664f5,_0x220504!==void 0x0?(_0x35a319['endNameSet_']=!0x0,_0x35a319['indexEndName_']=_0x220504):(_0x35a319['endNameSet_']=!0x1,_0x35a319['indexEndName_']=''),_0x35a319;}function Do(_0x2fe643,_0x4cc196){const _0xdd7f85=_0x2fe643['copy']();return _0xdd7f85['index_']=_0x4cc196,_0xdd7f85;}function tr(_0x4eefdd){const _0x4f8e64={};if(_0x4eefdd['isDefault']())return _0x4f8e64;let _0x2fc954;if(_0x4eefdd['index_']===R?_0x2fc954='$priority':_0x4eefdd['index_']===Po?_0x2fc954='$value':_0x4eefdd['index_']===ye?_0x2fc954='$key':(f(_0x4eefdd['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x2fc954=_0x4eefdd['index_']['toString']()),_0x4f8e64['orderBy']=O(_0x2fc954),_0x4eefdd['startSet_']){const _0x298b40=_0x4eefdd['startAfterSet_']?'startAfter':'startAt';_0x4f8e64[_0x298b40]=O(_0x4eefdd['indexStartValue_']),_0x4eefdd['startNameSet_']&&(_0x4f8e64[_0x298b40]+=','+O(_0x4eefdd['indexStartName_']));}if(_0x4eefdd['endSet_']){const _0x5a5d5a=_0x4eefdd['endBeforeSet_']?'endBefore':'endAt';_0x4f8e64[_0x5a5d5a]=O(_0x4eefdd['indexEndValue_']),_0x4eefdd['endNameSet_']&&(_0x4f8e64[_0x5a5d5a]+=','+O(_0x4eefdd['indexEndName_']));}return _0x4eefdd['limitSet_']&&(_0x4eefdd['isViewFromLeft']()?_0x4f8e64['limitToFirst']=_0x4eefdd['limit_']:_0x4f8e64['limitToLast']=_0x4eefdd['limit_']),_0x4f8e64;}function nr(_0x3e0f89){const _0x17e249={};if(_0x3e0f89['startSet_']&&(_0x17e249['sp']=_0x3e0f89['indexStartValue_'],_0x3e0f89['startNameSet_']&&(_0x17e249['sn']=_0x3e0f89['indexStartName_']),_0x17e249['sin']=!_0x3e0f89['startAfterSet_']),_0x3e0f89['endSet_']&&(_0x17e249['ep']=_0x3e0f89['indexEndValue_'],_0x3e0f89['endNameSet_']&&(_0x17e249['en']=_0x3e0f89['indexEndName_']),_0x17e249['ein']=!_0x3e0f89['endBeforeSet_']),_0x3e0f89['limitSet_']){_0x17e249['l']=_0x3e0f89['limit_'];let _0x30632b=_0x3e0f89['viewFrom_'];_0x30632b===''&&(_0x3e0f89['isViewFromLeft']()?_0x30632b='l':_0x30632b='r'),_0x17e249['vf']=_0x30632b;}return _0x3e0f89['index_']!==R&&(_0x17e249['i']=_0x3e0f89['index_']['toString']()),_0x17e249;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x3dd91a){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4403d1,_0x331dd4){return _0x331dd4!==void 0x0?'tag$'+_0x331dd4:(f(_0x4403d1['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4403d1['_path']['toString']());}constructor(_0x1c4740,_0x5d30e9,_0x11d361,_0x5a78db){super(),this['repoInfo_']=_0x1c4740,this['onDataUpdate_']=_0x5d30e9,this['authTokenProvider_']=_0x11d361,this['appCheckTokenProvider_']=_0x5a78db,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x54262a,_0x229014,_0x1c9663,_0x1a5ec4){const _0x325f1c=_0x54262a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x325f1c+'\x20'+_0x54262a['_queryIdentifier']);const _0x4b3666=fn['getListenId_'](_0x54262a,_0x1c9663),_0x1cc31f={};this['listens_'][_0x4b3666]=_0x1cc31f;const _0x3de092=tr(_0x54262a['_queryParams']);this['restRequest_'](_0x325f1c+'.json',_0x3de092,(_0xa25de5,_0x1d06ae)=>{let _0x419886=_0x1d06ae;if(_0xa25de5===0x194&&(_0x419886=null,_0xa25de5=null),_0xa25de5===null&&this['onDataUpdate_'](_0x325f1c,_0x419886,!0x1,_0x1c9663),Oe(this['listens_'],_0x4b3666)===_0x1cc31f){let _0x36af53;_0xa25de5?_0xa25de5===0x191?_0x36af53='permission_denied':_0x36af53='rest_error:'+_0xa25de5:_0x36af53='ok',_0x1a5ec4(_0x36af53,null);}});}['unlisten'](_0x410572,_0x2b1609){const _0x5c5adf=fn['getListenId_'](_0x410572,_0x2b1609);delete this['listens_'][_0x5c5adf];}['get'](_0x461254){const _0x39a815=tr(_0x461254['_queryParams']),_0x21cd0b=_0x461254['_path']['toString'](),_0x1b96ba=new Ve();return this['restRequest_'](_0x21cd0b+'.json',_0x39a815,(_0x124d90,_0x30a00b)=>{let _0x9446f2=_0x30a00b;_0x124d90===0x194&&(_0x9446f2=null,_0x124d90=null),_0x124d90===null?(this['onDataUpdate_'](_0x21cd0b,_0x9446f2,!0x1,null),_0x1b96ba['resolve'](_0x9446f2)):_0x1b96ba['reject'](new Error(_0x9446f2));}),_0x1b96ba['promise'];}['refreshAuthToken'](_0x1156cb){}['restRequest_'](_0x33690e,_0x63dcd1={},_0x1fa0a2){return _0x63dcd1['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4d04ea,_0x2ffb61])=>{_0x4d04ea&&_0x4d04ea['accessToken']&&(_0x63dcd1['auth']=_0x4d04ea['accessToken']),_0x2ffb61&&_0x2ffb61['token']&&(_0x63dcd1['ac']=_0x2ffb61['token']);const _0x46a25b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x33690e+'?ns='+this['repoInfo_']['namespace']+at(_0x63dcd1);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x46a25b);const _0x452a84=new XMLHttpRequest();_0x452a84['onreadystatechange']=()=>{if(_0x1fa0a2&&_0x452a84['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x46a25b+'\x20received.\x20status:',_0x452a84['status'],'response:',_0x452a84['responseText']);let _0xf3a2c7=null;if(_0x452a84['status']>=0xc8&&_0x452a84['status']<0x12c){try{_0xf3a2c7=bt(_0x452a84['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x46a25b+':\x20'+_0x452a84['responseText']);}_0x1fa0a2(null,_0xf3a2c7);}else _0x452a84['status']!==0x191&&_0x452a84['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x46a25b+'\x20Status:\x20'+_0x452a84['status']),_0x1fa0a2(_0x452a84['status']);_0x1fa0a2=null;}},_0x452a84['open']('GET',_0x46a25b,!0x0),_0x452a84['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2dfaab){return this['rootNode_']['getChild'](_0x2dfaab);}['updateSnapshot'](_0x435872,_0x1ed214){this['rootNode_']=this['rootNode_']['updateChild'](_0x435872,_0x1ed214);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x26985e,_0x5f25ca,_0x2a1a67){if(v(_0x5f25ca))_0x26985e['value']=_0x2a1a67,_0x26985e['children']['clear']();else{if(_0x26985e['value']!==null)_0x26985e['value']=_0x26985e['value']['updateChild'](_0x5f25ca,_0x2a1a67);else{const _0x426c16=y(_0x5f25ca);_0x26985e['children']['has'](_0x426c16)||_0x26985e['children']['set'](_0x426c16,pn());const _0x52b00c=_0x26985e['children']['get'](_0x426c16);_0x5f25ca=b(_0x5f25ca),Mo(_0x52b00c,_0x5f25ca,_0x2a1a67);}}}function Ei(_0x5d927c,_0x5c6938,_0x38a573){_0x5d927c['value']!==null?_0x38a573(_0x5c6938,_0x5d927c['value']):Qh(_0x5d927c,(_0x14e967,_0x1e5e1d)=>{const _0x246972=new C(_0x5c6938['toString']()+'/'+_0x14e967);Ei(_0x1e5e1d,_0x246972,_0x38a573);});}function Qh(_0x441841,_0x1c3c40){_0x441841['children']['forEach']((_0x48e9ae,_0x518948)=>{_0x1c3c40(_0x518948,_0x48e9ae);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x2e68b){this['collection_']=_0x2e68b,this['last_']=null;}['get'](){const _0x2867e9=this['collection_']['get'](),_0x5e1a76={..._0x2867e9};return this['last_']&&x(this['last_'],(_0xd3ff53,_0x3fe23f)=>{_0x5e1a76[_0xd3ff53]=_0x5e1a76[_0xd3ff53]-_0x3fe23f;}),this['last_']=_0x2867e9,_0x5e1a76;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x4d4bcf,_0x3d41e6){this['server_']=_0x3d41e6,this['statsToReport_']={},this['statsListener_']=new Jh(_0x4d4bcf);const _0x234c56=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x234c56));}['reportStats_'](){const _0x521aaf=this['statsListener_']['get'](),_0x226b3a={};let _0x25517b=!0x1;x(_0x521aaf,(_0x219891,_0x34f2a8)=>{_0x34f2a8>0x0&&Y(this['statsToReport_'],_0x219891)&&(_0x226b3a[_0x219891]=_0x34f2a8,_0x25517b=!0x0);}),_0x25517b&&this['server_']['reportStats'](_0x226b3a),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x298503){_0x298503[_0x298503['OVERWRITE']=0x0]='OVERWRITE',_0x298503[_0x298503['MERGE']=0x1]='MERGE',_0x298503[_0x298503['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x298503[_0x298503['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x766e44){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x766e44,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x4fd86e,_0x38e37d,_0x38bdaa){this['path']=_0x4fd86e,this['affectedTree']=_0x38e37d,this['revert']=_0x38bdaa,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x32c44c){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xdd8a6=this['affectedTree']['subtree'](new C(_0x32c44c));return new _n(w(),_0xdd8a6,this['revert']);}}else return f(y(this['path'])===_0x32c44c,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5b6b32,_0x2441ba){this['source']=_0x5b6b32,this['path']=_0x2441ba,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1e8037){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x581071,_0x20f878,_0x331e66){this['source']=_0x581071,this['path']=_0x20f878,this['snap']=_0x331e66,this['type']=q['OVERWRITE'];}['operationForChild'](_0x531954){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x531954)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x47c975,_0x36e16c,_0x532cbc){this['source']=_0x47c975,this['path']=_0x36e16c,this['children']=_0x532cbc,this['type']=q['MERGE'];}['operationForChild'](_0x1ce14e){if(v(this['path'])){const _0x11b008=this['children']['subtree'](new C(_0x1ce14e));return _0x11b008['isEmpty']()?null:_0x11b008['value']?new Fe(this['source'],w(),_0x11b008['value']):new nt(this['source'],w(),_0x11b008);}else return f(y(this['path'])===_0x1ce14e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x1add4f,_0xddf657,_0x53b4f8){this['node_']=_0x1add4f,this['fullyInitialized_']=_0xddf657,this['filtered_']=_0x53b4f8;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xb01bf9){if(v(_0xb01bf9))return this['isFullyInitialized']()&&!this['filtered_'];const _0x574cec=y(_0xb01bf9);return this['isCompleteForChild'](_0x574cec);}['isCompleteForChild'](_0x136b3e){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x136b3e);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x406e1f){this['query_']=_0x406e1f,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x622280,_0x1a5f57,_0xbdcf69,_0xb4c47){const _0x4b57e8=[],_0x299f39=[];return _0x1a5f57['forEach'](_0x5a7014=>{_0x5a7014['type']==='child_changed'&&_0x622280['index_']['indexedValueChanged'](_0x5a7014['oldSnap'],_0x5a7014['snapshotNode'])&&_0x299f39['push']($h(_0x5a7014['childName'],_0x5a7014['snapshotNode']));}),mt(_0x622280,_0x4b57e8,'child_removed',_0x1a5f57,_0xb4c47,_0xbdcf69),mt(_0x622280,_0x4b57e8,'child_added',_0x1a5f57,_0xb4c47,_0xbdcf69),mt(_0x622280,_0x4b57e8,'child_moved',_0x299f39,_0xb4c47,_0xbdcf69),mt(_0x622280,_0x4b57e8,'child_changed',_0x1a5f57,_0xb4c47,_0xbdcf69),mt(_0x622280,_0x4b57e8,'value',_0x1a5f57,_0xb4c47,_0xbdcf69),_0x4b57e8;}function mt(_0x502af4,_0x211fc1,_0x54e456,_0x1a7ae3,_0x26ca18,_0x19d7df){const _0x3adc0c=_0x1a7ae3['filter'](_0x5792d9=>_0x5792d9['type']===_0x54e456);_0x3adc0c['sort']((_0xe79a37,_0x3b3911)=>su(_0x502af4,_0xe79a37,_0x3b3911)),_0x3adc0c['forEach'](_0x453a4c=>{const _0x6da9b1=iu(_0x502af4,_0x453a4c,_0x19d7df);_0x26ca18['forEach'](_0x3493a1=>{_0x3493a1['respondsTo'](_0x453a4c['type'])&&_0x211fc1['push'](_0x3493a1['createEvent'](_0x6da9b1,_0x502af4['query_']));});});}function iu(_0x5732a3,_0x58cd1a,_0x3ecb12){return _0x58cd1a['type']==='value'||_0x58cd1a['type']==='child_removed'||(_0x58cd1a['prevName']=_0x3ecb12['getPredecessorChildName'](_0x58cd1a['childName'],_0x58cd1a['snapshotNode'],_0x5732a3['index_'])),_0x58cd1a;}function su(_0x14da56,_0x151d36,_0x41a678){if(_0x151d36['childName']==null||_0x41a678['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x934f43=new E(_0x151d36['childName'],_0x151d36['snapshotNode']),_0x10d51b=new E(_0x41a678['childName'],_0x41a678['snapshotNode']);return _0x14da56['index_']['compare'](_0x934f43,_0x10d51b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x58a061,_0x866cc4){return{'eventCache':_0x58a061,'serverCache':_0x866cc4};}function wt(_0x1d458c,_0x549085,_0x1c3185,_0x1b18c6){return Dn(new Ce(_0x549085,_0x1c3185,_0x1b18c6),_0x1d458c['serverCache']);}function Lo(_0x47bac1,_0x2457b3,_0x14f366,_0x13638d){return Dn(_0x47bac1['eventCache'],new Ce(_0x2457b3,_0x14f366,_0x13638d));}function gn(_0x5a9ffc){return _0x5a9ffc['eventCache']['isFullyInitialized']()?_0x5a9ffc['eventCache']['getNode']():null;}function Ue(_0x1ddbe1){return _0x1ddbe1['serverCache']['isFullyInitialized']()?_0x1ddbe1['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3bbced){let _0x166400=new S(null);return x(_0x3bbced,(_0x58b3f2,_0x72c844)=>{_0x166400=_0x166400['set'](new C(_0x58b3f2),_0x72c844);}),_0x166400;}constructor(_0x5c0ef7,_0x3eae61=ru()){this['value']=_0x5c0ef7,this['children']=_0x3eae61;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x168864,_0x16ec6f){if(this['value']!=null&&_0x16ec6f(this['value']))return{'path':w(),'value':this['value']};if(v(_0x168864))return null;{const _0x4e4989=y(_0x168864),_0x29cac4=this['children']['get'](_0x4e4989);if(_0x29cac4!==null){const _0x5366eb=_0x29cac4['findRootMostMatchingPathAndValue'](b(_0x168864),_0x16ec6f);return _0x5366eb!=null?{'path':A(new C(_0x4e4989),_0x5366eb['path']),'value':_0x5366eb['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xca83b8){return this['findRootMostMatchingPathAndValue'](_0xca83b8,()=>!0x0);}['subtree'](_0x31c47e){if(v(_0x31c47e))return this;{const _0x525e21=y(_0x31c47e),_0x2952f4=this['children']['get'](_0x525e21);return _0x2952f4!==null?_0x2952f4['subtree'](b(_0x31c47e)):new S(null);}}['set'](_0x4ca05e,_0x9aa1b7){if(v(_0x4ca05e))return new S(_0x9aa1b7,this['children']);{const _0x6d7546=y(_0x4ca05e),_0x58c013=(this['children']['get'](_0x6d7546)||new S(null))['set'](b(_0x4ca05e),_0x9aa1b7),_0x4a606c=this['children']['insert'](_0x6d7546,_0x58c013);return new S(this['value'],_0x4a606c);}}['remove'](_0x131754){if(v(_0x131754))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x53e4d9=y(_0x131754),_0x4ea90a=this['children']['get'](_0x53e4d9);if(_0x4ea90a){const _0x2edbcb=_0x4ea90a['remove'](b(_0x131754));let _0x162075;return _0x2edbcb['isEmpty']()?_0x162075=this['children']['remove'](_0x53e4d9):_0x162075=this['children']['insert'](_0x53e4d9,_0x2edbcb),this['value']===null&&_0x162075['isEmpty']()?new S(null):new S(this['value'],_0x162075);}else return this;}}['get'](_0x1e80a4){if(v(_0x1e80a4))return this['value'];{const _0x6ffdb3=y(_0x1e80a4),_0x34f732=this['children']['get'](_0x6ffdb3);return _0x34f732?_0x34f732['get'](b(_0x1e80a4)):null;}}['setTree'](_0x4885fc,_0x75d548){if(v(_0x4885fc))return _0x75d548;{const _0x4689d7=y(_0x4885fc),_0x13e6d9=(this['children']['get'](_0x4689d7)||new S(null))['setTree'](b(_0x4885fc),_0x75d548);let _0x42eb81;return _0x13e6d9['isEmpty']()?_0x42eb81=this['children']['remove'](_0x4689d7):_0x42eb81=this['children']['insert'](_0x4689d7,_0x13e6d9),new S(this['value'],_0x42eb81);}}['fold'](_0x1a866f){return this['fold_'](w(),_0x1a866f);}['fold_'](_0x74ea42,_0x4dd198){const _0x2d10b1={};return this['children']['inorderTraversal']((_0xf262b0,_0xe0bc7b)=>{_0x2d10b1[_0xf262b0]=_0xe0bc7b['fold_'](A(_0x74ea42,_0xf262b0),_0x4dd198);}),_0x4dd198(_0x74ea42,this['value'],_0x2d10b1);}['findOnPath'](_0x4bb2f9,_0xefa8a){return this['findOnPath_'](_0x4bb2f9,w(),_0xefa8a);}['findOnPath_'](_0x157976,_0x11e868,_0x1acfa2){const _0x3e2df4=this['value']?_0x1acfa2(_0x11e868,this['value']):!0x1;if(_0x3e2df4)return _0x3e2df4;if(v(_0x157976))return null;{const _0x4ccf86=y(_0x157976),_0x1e22f6=this['children']['get'](_0x4ccf86);return _0x1e22f6?_0x1e22f6['findOnPath_'](b(_0x157976),A(_0x11e868,_0x4ccf86),_0x1acfa2):null;}}['foreachOnPath'](_0x50be43,_0x2bcc26){return this['foreachOnPath_'](_0x50be43,w(),_0x2bcc26);}['foreachOnPath_'](_0x3fd72c,_0x52e195,_0x547998){if(v(_0x3fd72c))return this;{this['value']&&_0x547998(_0x52e195,this['value']);const _0x5325f7=y(_0x3fd72c),_0x22dd7c=this['children']['get'](_0x5325f7);return _0x22dd7c?_0x22dd7c['foreachOnPath_'](b(_0x3fd72c),A(_0x52e195,_0x5325f7),_0x547998):new S(null);}}['foreach'](_0x541304){this['foreach_'](w(),_0x541304);}['foreach_'](_0x30271f,_0x127532){this['children']['inorderTraversal']((_0x95f94a,_0x25dcf1)=>{_0x25dcf1['foreach_'](A(_0x30271f,_0x95f94a),_0x127532);}),this['value']&&_0x127532(_0x30271f,this['value']);}['foreachChild'](_0x10f45b){this['children']['inorderTraversal']((_0x4fb92e,_0x326551)=>{_0x326551['value']&&_0x10f45b(_0x4fb92e,_0x326551['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x3e52dc){this['writeTree_']=_0x3e52dc;}static['empty'](){return new j(new S(null));}}function Ct(_0x9b0ce1,_0x662584,_0x17b6bc){if(v(_0x662584))return new j(new S(_0x17b6bc));{const _0x2175d1=_0x9b0ce1['writeTree_']['findRootMostValueAndPath'](_0x662584);if(_0x2175d1!=null){const _0x13914f=_0x2175d1['path'];let _0x38f296=_0x2175d1['value'];const _0x22f6f2=F(_0x13914f,_0x662584);return _0x38f296=_0x38f296['updateChild'](_0x22f6f2,_0x17b6bc),new j(_0x9b0ce1['writeTree_']['set'](_0x13914f,_0x38f296));}else{const _0x12a81b=new S(_0x17b6bc),_0x321555=_0x9b0ce1['writeTree_']['setTree'](_0x662584,_0x12a81b);return new j(_0x321555);}}}function Ii(_0x5572b4,_0x3858f4,_0x22a818){let _0x1a431e=_0x5572b4;return x(_0x22a818,(_0x4f0076,_0x1c7d1c)=>{_0x1a431e=Ct(_0x1a431e,A(_0x3858f4,_0x4f0076),_0x1c7d1c);}),_0x1a431e;}function sr(_0x2d3511,_0x441430){if(v(_0x441430))return j['empty']();{const _0x598b47=_0x2d3511['writeTree_']['setTree'](_0x441430,new S(null));return new j(_0x598b47);}}function wi(_0x698597,_0x597ab8){return $e(_0x698597,_0x597ab8)!=null;}function $e(_0x34d630,_0x2cce2f){const _0x22fe75=_0x34d630['writeTree_']['findRootMostValueAndPath'](_0x2cce2f);return _0x22fe75!=null?_0x34d630['writeTree_']['get'](_0x22fe75['path'])['getChild'](F(_0x22fe75['path'],_0x2cce2f)):null;}function rr(_0x3fb829){const _0x495e20=[],_0x4220b3=_0x3fb829['writeTree_']['value'];return _0x4220b3!=null?_0x4220b3['isLeafNode']()||_0x4220b3['forEachChild'](R,(_0x5ac699,_0x3e9cab)=>{_0x495e20['push'](new E(_0x5ac699,_0x3e9cab));}):_0x3fb829['writeTree_']['children']['inorderTraversal']((_0x10c94a,_0xce5201)=>{_0xce5201['value']!=null&&_0x495e20['push'](new E(_0x10c94a,_0xce5201['value']));}),_0x495e20;}function ve(_0x32215b,_0x20fca5){if(v(_0x20fca5))return _0x32215b;{const _0x11ff3a=$e(_0x32215b,_0x20fca5);return _0x11ff3a!=null?new j(new S(_0x11ff3a)):new j(_0x32215b['writeTree_']['subtree'](_0x20fca5));}}function Ci(_0x4a6a1c){return _0x4a6a1c['writeTree_']['isEmpty']();}function it(_0x5baed1,_0x1b1cf7){return xo(w(),_0x5baed1['writeTree_'],_0x1b1cf7);}function xo(_0x3a9a94,_0x10dbfa,_0x20add5){if(_0x10dbfa['value']!=null)return _0x20add5['updateChild'](_0x3a9a94,_0x10dbfa['value']);{let _0x1655ef=null;return _0x10dbfa['children']['inorderTraversal']((_0x2493a1,_0x5f2990)=>{_0x2493a1==='.priority'?(f(_0x5f2990['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1655ef=_0x5f2990['value']):_0x20add5=xo(A(_0x3a9a94,_0x2493a1),_0x5f2990,_0x20add5);}),!_0x20add5['getChild'](_0x3a9a94)['isEmpty']()&&_0x1655ef!==null&&(_0x20add5=_0x20add5['updateChild'](A(_0x3a9a94,'.priority'),_0x1655ef)),_0x20add5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x559b98,_0x40f65b){return Bo(_0x40f65b,_0x559b98);}function ou(_0x3a959b,_0x4a2dca,_0x2982c3,_0x4d26d4,_0x1a9dba){f(_0x4d26d4>_0x3a959b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1a9dba===void 0x0&&(_0x1a9dba=!0x0),_0x3a959b['allWrites']['push']({'path':_0x4a2dca,'snap':_0x2982c3,'writeId':_0x4d26d4,'visible':_0x1a9dba}),_0x1a9dba&&(_0x3a959b['visibleWrites']=Ct(_0x3a959b['visibleWrites'],_0x4a2dca,_0x2982c3)),_0x3a959b['lastWriteId']=_0x4d26d4;}function au(_0x196347,_0x4f4553,_0xf63d2a,_0x2e8475){f(_0x2e8475>_0x196347['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x196347['allWrites']['push']({'path':_0x4f4553,'children':_0xf63d2a,'writeId':_0x2e8475,'visible':!0x0}),_0x196347['visibleWrites']=Ii(_0x196347['visibleWrites'],_0x4f4553,_0xf63d2a),_0x196347['lastWriteId']=_0x2e8475;}function cu(_0x948090,_0x598ad2){for(let _0x9be520=0x0;_0x9be520<_0x948090['allWrites']['length'];_0x9be520++){const _0x28c4a9=_0x948090['allWrites'][_0x9be520];if(_0x28c4a9['writeId']===_0x598ad2)return _0x28c4a9;}return null;}function lu(_0x56eb07,_0x5042e6){const _0x1a5e6a=_0x56eb07['allWrites']['findIndex'](_0x1751f1=>_0x1751f1['writeId']===_0x5042e6);f(_0x1a5e6a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4bfb4d=_0x56eb07['allWrites'][_0x1a5e6a];_0x56eb07['allWrites']['splice'](_0x1a5e6a,0x1);let _0x2b5ea5=_0x4bfb4d['visible'],_0x4f3a11=!0x1,_0x365305=_0x56eb07['allWrites']['length']-0x1;for(;_0x2b5ea5&&_0x365305>=0x0;){const _0x31eb10=_0x56eb07['allWrites'][_0x365305];_0x31eb10['visible']&&(_0x365305>=_0x1a5e6a&&hu(_0x31eb10,_0x4bfb4d['path'])?_0x2b5ea5=!0x1:$(_0x4bfb4d['path'],_0x31eb10['path'])&&(_0x4f3a11=!0x0)),_0x365305--;}if(_0x2b5ea5){if(_0x4f3a11)return uu(_0x56eb07),!0x0;if(_0x4bfb4d['snap'])_0x56eb07['visibleWrites']=sr(_0x56eb07['visibleWrites'],_0x4bfb4d['path']);else{const _0x596d9e=_0x4bfb4d['children'];x(_0x596d9e,_0x1cf1ec=>{_0x56eb07['visibleWrites']=sr(_0x56eb07['visibleWrites'],A(_0x4bfb4d['path'],_0x1cf1ec));});}return!0x0;}else return!0x1;}function hu(_0x4a627d,_0x1f2d7d){if(_0x4a627d['snap'])return $(_0x4a627d['path'],_0x1f2d7d);for(const _0x15160a in _0x4a627d['children'])if(_0x4a627d['children']['hasOwnProperty'](_0x15160a)&&$(A(_0x4a627d['path'],_0x15160a),_0x1f2d7d))return!0x0;return!0x1;}function uu(_0x4ad833){_0x4ad833['visibleWrites']=Fo(_0x4ad833['allWrites'],du,w()),_0x4ad833['allWrites']['length']>0x0?_0x4ad833['lastWriteId']=_0x4ad833['allWrites'][_0x4ad833['allWrites']['length']-0x1]['writeId']:_0x4ad833['lastWriteId']=-0x1;}function du(_0x542936){return _0x542936['visible'];}function Fo(_0x5d8ae0,_0x45b324,_0x23597b){let _0x1c40d3=j['empty']();for(let _0x30a649=0x0;_0x30a649<_0x5d8ae0['length'];++_0x30a649){const _0x1fdfe9=_0x5d8ae0[_0x30a649];if(_0x45b324(_0x1fdfe9)){const _0x3ab468=_0x1fdfe9['path'];let _0xaa5f59;if(_0x1fdfe9['snap'])$(_0x23597b,_0x3ab468)?(_0xaa5f59=F(_0x23597b,_0x3ab468),_0x1c40d3=Ct(_0x1c40d3,_0xaa5f59,_0x1fdfe9['snap'])):$(_0x3ab468,_0x23597b)&&(_0xaa5f59=F(_0x3ab468,_0x23597b),_0x1c40d3=Ct(_0x1c40d3,w(),_0x1fdfe9['snap']['getChild'](_0xaa5f59)));else{if(_0x1fdfe9['children']){if($(_0x23597b,_0x3ab468))_0xaa5f59=F(_0x23597b,_0x3ab468),_0x1c40d3=Ii(_0x1c40d3,_0xaa5f59,_0x1fdfe9['children']);else{if($(_0x3ab468,_0x23597b)){if(_0xaa5f59=F(_0x3ab468,_0x23597b),v(_0xaa5f59))_0x1c40d3=Ii(_0x1c40d3,w(),_0x1fdfe9['children']);else{const _0x35d6d7=Oe(_0x1fdfe9['children'],y(_0xaa5f59));if(_0x35d6d7){const _0x2b9ba5=_0x35d6d7['getChild'](b(_0xaa5f59));_0x1c40d3=Ct(_0x1c40d3,w(),_0x2b9ba5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1c40d3;}function Uo(_0x270a20,_0x5077b6,_0x25641c,_0x3bb693,_0x5cdee8){if(!_0x3bb693&&!_0x5cdee8){const _0x50176b=$e(_0x270a20['visibleWrites'],_0x5077b6);if(_0x50176b!=null)return _0x50176b;{const _0x2837d8=ve(_0x270a20['visibleWrites'],_0x5077b6);if(Ci(_0x2837d8))return _0x25641c;if(_0x25641c==null&&!wi(_0x2837d8,w()))return null;{const _0x320259=_0x25641c||g['EMPTY_NODE'];return it(_0x2837d8,_0x320259);}}}else{const _0x556145=ve(_0x270a20['visibleWrites'],_0x5077b6);if(!_0x5cdee8&&Ci(_0x556145))return _0x25641c;if(!_0x5cdee8&&_0x25641c==null&&!wi(_0x556145,w()))return null;{const _0x5ba7d9=function(_0x542553){return(_0x542553['visible']||_0x5cdee8)&&(!_0x3bb693||!~_0x3bb693['indexOf'](_0x542553['writeId']))&&($(_0x542553['path'],_0x5077b6)||$(_0x5077b6,_0x542553['path']));},_0x503db1=Fo(_0x270a20['allWrites'],_0x5ba7d9,_0x5077b6),_0x449283=_0x25641c||g['EMPTY_NODE'];return it(_0x503db1,_0x449283);}}}function fu(_0x4fad4c,_0x216ef9,_0x1952dd){let _0x1ec25e=g['EMPTY_NODE'];const _0x51a2e5=$e(_0x4fad4c['visibleWrites'],_0x216ef9);if(_0x51a2e5)return _0x51a2e5['isLeafNode']()||_0x51a2e5['forEachChild'](R,(_0x3680f5,_0x433ff5)=>{_0x1ec25e=_0x1ec25e['updateImmediateChild'](_0x3680f5,_0x433ff5);}),_0x1ec25e;if(_0x1952dd){const _0x45a47b=ve(_0x4fad4c['visibleWrites'],_0x216ef9);return _0x1952dd['forEachChild'](R,(_0x7f6fd7,_0x25eaaa)=>{const _0x5b0a04=it(ve(_0x45a47b,new C(_0x7f6fd7)),_0x25eaaa);_0x1ec25e=_0x1ec25e['updateImmediateChild'](_0x7f6fd7,_0x5b0a04);}),rr(_0x45a47b)['forEach'](_0x1a2902=>{_0x1ec25e=_0x1ec25e['updateImmediateChild'](_0x1a2902['name'],_0x1a2902['node']);}),_0x1ec25e;}else{const _0x9dd9d3=ve(_0x4fad4c['visibleWrites'],_0x216ef9);return rr(_0x9dd9d3)['forEach'](_0x29a117=>{_0x1ec25e=_0x1ec25e['updateImmediateChild'](_0x29a117['name'],_0x29a117['node']);}),_0x1ec25e;}}function pu(_0x3ee85c,_0x301a9a,_0x1d331f,_0x3a8a72,_0x49ca19){f(_0x3a8a72||_0x49ca19,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4d5123=A(_0x301a9a,_0x1d331f);if(wi(_0x3ee85c['visibleWrites'],_0x4d5123))return null;{const _0x48ce97=ve(_0x3ee85c['visibleWrites'],_0x4d5123);return Ci(_0x48ce97)?_0x49ca19['getChild'](_0x1d331f):it(_0x48ce97,_0x49ca19['getChild'](_0x1d331f));}}function _u(_0x3f0df7,_0x412bdb,_0x4c4c76,_0x37d491){const _0x4c9d77=A(_0x412bdb,_0x4c4c76),_0x18467d=$e(_0x3f0df7['visibleWrites'],_0x4c9d77);if(_0x18467d!=null)return _0x18467d;if(_0x37d491['isCompleteForChild'](_0x4c4c76)){const _0x45c04b=ve(_0x3f0df7['visibleWrites'],_0x4c9d77);return it(_0x45c04b,_0x37d491['getNode']()['getImmediateChild'](_0x4c4c76));}else return null;}function gu(_0x4fc49a,_0x32e7c5){return $e(_0x4fc49a['visibleWrites'],_0x32e7c5);}function mu(_0x2451cf,_0x5457b1,_0x318f53,_0x293937,_0x3633e3,_0x2960c6,_0x4ab316){let _0x210690;const _0x3fe337=ve(_0x2451cf['visibleWrites'],_0x5457b1),_0x2e4e46=$e(_0x3fe337,w());if(_0x2e4e46!=null)_0x210690=_0x2e4e46;else{if(_0x318f53!=null)_0x210690=it(_0x3fe337,_0x318f53);else return[];}if(_0x210690=_0x210690['withIndex'](_0x4ab316),!_0x210690['isEmpty']()&&!_0x210690['isLeafNode']()){const _0x1619ea=[],_0x5c0471=_0x4ab316['getCompare'](),_0xb5287c=_0x2960c6?_0x210690['getReverseIteratorFrom'](_0x293937,_0x4ab316):_0x210690['getIteratorFrom'](_0x293937,_0x4ab316);let _0x20af14=_0xb5287c['getNext']();for(;_0x20af14&&_0x1619ea['length']<_0x3633e3;)_0x5c0471(_0x20af14,_0x293937)!==0x0&&_0x1619ea['push'](_0x20af14),_0x20af14=_0xb5287c['getNext']();return _0x1619ea;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x47efef,_0x306a6d,_0x647940,_0x175077){return Uo(_0x47efef['writeTree'],_0x47efef['treePath'],_0x306a6d,_0x647940,_0x175077);}function es(_0x5f2fa2,_0x41f7ee){return fu(_0x5f2fa2['writeTree'],_0x5f2fa2['treePath'],_0x41f7ee);}function or(_0xf95400,_0x98db75,_0xaeaa92,_0x3c3bd2){return pu(_0xf95400['writeTree'],_0xf95400['treePath'],_0x98db75,_0xaeaa92,_0x3c3bd2);}function yn(_0x36a429,_0x35bde5){return gu(_0x36a429['writeTree'],A(_0x36a429['treePath'],_0x35bde5));}function vu(_0x18712f,_0x471b02,_0x19b0ce,_0x5e484e,_0x2a3763,_0x20cfc8){return mu(_0x18712f['writeTree'],_0x18712f['treePath'],_0x471b02,_0x19b0ce,_0x5e484e,_0x2a3763,_0x20cfc8);}function ts(_0xc43aff,_0x154950,_0x3fe9a1){return _u(_0xc43aff['writeTree'],_0xc43aff['treePath'],_0x154950,_0x3fe9a1);}function Wo(_0x4801c6,_0x45990a){return Bo(A(_0x4801c6['treePath'],_0x45990a),_0x4801c6['writeTree']);}function Bo(_0x3af6a8,_0x53213a){return{'treePath':_0x3af6a8,'writeTree':_0x53213a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xde91ca){const _0x5c3890=_0xde91ca['type'],_0x2638ed=_0xde91ca['childName'];f(_0x5c3890==='child_added'||_0x5c3890==='child_changed'||_0x5c3890==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2638ed!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5d5b64=this['changeMap']['get'](_0x2638ed);if(_0x5d5b64){const _0x153a09=_0x5d5b64['type'];if(_0x5c3890==='child_added'&&_0x153a09==='child_removed')this['changeMap']['set'](_0x2638ed,Pt(_0x2638ed,_0xde91ca['snapshotNode'],_0x5d5b64['snapshotNode']));else{if(_0x5c3890==='child_removed'&&_0x153a09==='child_added')this['changeMap']['delete'](_0x2638ed);else{if(_0x5c3890==='child_removed'&&_0x153a09==='child_changed')this['changeMap']['set'](_0x2638ed,Nt(_0x2638ed,_0x5d5b64['oldSnap']));else{if(_0x5c3890==='child_changed'&&_0x153a09==='child_added')this['changeMap']['set'](_0x2638ed,tt(_0x2638ed,_0xde91ca['snapshotNode']));else{if(_0x5c3890==='child_changed'&&_0x153a09==='child_changed')this['changeMap']['set'](_0x2638ed,Pt(_0x2638ed,_0xde91ca['snapshotNode'],_0x5d5b64['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0xde91ca+'\x20occurred\x20after\x20'+_0x5d5b64);}}}}}else this['changeMap']['set'](_0x2638ed,_0xde91ca);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x4ab59b){return null;}['getChildAfterChild'](_0x1764bc,_0x46a5e7,_0x23d6de){return null;}}const Vo=new Iu();class ns{constructor(_0x6ba5f1,_0x40c995,_0x38efe5=null){this['writes_']=_0x6ba5f1,this['viewCache_']=_0x40c995,this['optCompleteServerCache_']=_0x38efe5;}['getCompleteChild'](_0x5f28cd){const _0x28196f=this['viewCache_']['eventCache'];if(_0x28196f['isCompleteForChild'](_0x5f28cd))return _0x28196f['getNode']()['getImmediateChild'](_0x5f28cd);{const _0x57eef3=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5f28cd,_0x57eef3);}}['getChildAfterChild'](_0x2968d1,_0x538a0f,_0x39ec56){const _0x482f6e=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x72522a=vu(this['writes_'],_0x482f6e,_0x538a0f,0x1,_0x39ec56,_0x2968d1);return _0x72522a['length']===0x0?null:_0x72522a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x140bbc){return{'filter':_0x140bbc};}function Cu(_0x32c322,_0x2f405f){f(_0x2f405f['eventCache']['getNode']()['isIndexed'](_0x32c322['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x2f405f['serverCache']['getNode']()['isIndexed'](_0x32c322['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x5e164b,_0x4dc54f,_0x542217,_0x4200cf,_0x2a18bb){const _0x2029df=new Eu();let _0x32f3dd,_0x30db27;if(_0x542217['type']===q['OVERWRITE']){const _0x38f9af=_0x542217;_0x38f9af['source']['fromUser']?_0x32f3dd=Ti(_0x5e164b,_0x4dc54f,_0x38f9af['path'],_0x38f9af['snap'],_0x4200cf,_0x2a18bb,_0x2029df):(f(_0x38f9af['source']['fromServer'],'Unknown\x20source.'),_0x30db27=_0x38f9af['source']['tagged']||_0x4dc54f['serverCache']['isFiltered']()&&!v(_0x38f9af['path']),_0x32f3dd=vn(_0x5e164b,_0x4dc54f,_0x38f9af['path'],_0x38f9af['snap'],_0x4200cf,_0x2a18bb,_0x30db27,_0x2029df));}else{if(_0x542217['type']===q['MERGE']){const _0x245da5=_0x542217;_0x245da5['source']['fromUser']?_0x32f3dd=bu(_0x5e164b,_0x4dc54f,_0x245da5['path'],_0x245da5['children'],_0x4200cf,_0x2a18bb,_0x2029df):(f(_0x245da5['source']['fromServer'],'Unknown\x20source.'),_0x30db27=_0x245da5['source']['tagged']||_0x4dc54f['serverCache']['isFiltered'](),_0x32f3dd=Si(_0x5e164b,_0x4dc54f,_0x245da5['path'],_0x245da5['children'],_0x4200cf,_0x2a18bb,_0x30db27,_0x2029df));}else{if(_0x542217['type']===q['ACK_USER_WRITE']){const _0x40009f=_0x542217;_0x40009f['revert']?_0x32f3dd=ku(_0x5e164b,_0x4dc54f,_0x40009f['path'],_0x4200cf,_0x2a18bb,_0x2029df):_0x32f3dd=Ru(_0x5e164b,_0x4dc54f,_0x40009f['path'],_0x40009f['affectedTree'],_0x4200cf,_0x2a18bb,_0x2029df);}else{if(_0x542217['type']===q['LISTEN_COMPLETE'])_0x32f3dd=Au(_0x5e164b,_0x4dc54f,_0x542217['path'],_0x4200cf,_0x2029df);else throw ot('Unknown\x20operation\x20type:\x20'+_0x542217['type']);}}}const _0x5c176f=_0x2029df['getChanges']();return Su(_0x4dc54f,_0x32f3dd,_0x5c176f),{'viewCache':_0x32f3dd,'changes':_0x5c176f};}function Su(_0x1caffe,_0x5e1263,_0x327ac1){const _0x36e5e2=_0x5e1263['eventCache'];if(_0x36e5e2['isFullyInitialized']()){const _0x2ae670=_0x36e5e2['getNode']()['isLeafNode']()||_0x36e5e2['getNode']()['isEmpty'](),_0x5087db=gn(_0x1caffe);(_0x327ac1['length']>0x0||!_0x1caffe['eventCache']['isFullyInitialized']()||_0x2ae670&&!_0x36e5e2['getNode']()['equals'](_0x5087db)||!_0x36e5e2['getNode']()['getPriority']()['equals'](_0x5087db['getPriority']()))&&_0x327ac1['push'](Oo(gn(_0x5e1263)));}}function Ho(_0x684ff3,_0x2bba5c,_0x210b65,_0x5af594,_0x2924d9,_0x1f5149){const _0xcc81b0=_0x2bba5c['eventCache'];if(yn(_0x5af594,_0x210b65)!=null)return _0x2bba5c;{let _0x3a7ce9,_0x16a22b;if(v(_0x210b65)){if(f(_0x2bba5c['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2bba5c['serverCache']['isFiltered']()){const _0x15f6c4=Ue(_0x2bba5c),_0x3fda40=_0x15f6c4 instanceof g?_0x15f6c4:g['EMPTY_NODE'],_0x3b8849=es(_0x5af594,_0x3fda40);_0x3a7ce9=_0x684ff3['filter']['updateFullNode'](_0x2bba5c['eventCache']['getNode'](),_0x3b8849,_0x1f5149);}else{const _0x3888ef=mn(_0x5af594,Ue(_0x2bba5c));_0x3a7ce9=_0x684ff3['filter']['updateFullNode'](_0x2bba5c['eventCache']['getNode'](),_0x3888ef,_0x1f5149);}}else{const _0xf3f10f=y(_0x210b65);if(_0xf3f10f==='.priority'){f(we(_0x210b65)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x50d067=_0xcc81b0['getNode']();_0x16a22b=_0x2bba5c['serverCache']['getNode']();const _0x48494a=or(_0x5af594,_0x210b65,_0x50d067,_0x16a22b);_0x48494a!=null?_0x3a7ce9=_0x684ff3['filter']['updatePriority'](_0x50d067,_0x48494a):_0x3a7ce9=_0xcc81b0['getNode']();}else{const _0x3461bf=b(_0x210b65);let _0x3d90ff;if(_0xcc81b0['isCompleteForChild'](_0xf3f10f)){_0x16a22b=_0x2bba5c['serverCache']['getNode']();const _0x5d0711=or(_0x5af594,_0x210b65,_0xcc81b0['getNode'](),_0x16a22b);_0x5d0711!=null?_0x3d90ff=_0xcc81b0['getNode']()['getImmediateChild'](_0xf3f10f)['updateChild'](_0x3461bf,_0x5d0711):_0x3d90ff=_0xcc81b0['getNode']()['getImmediateChild'](_0xf3f10f);}else _0x3d90ff=ts(_0x5af594,_0xf3f10f,_0x2bba5c['serverCache']);_0x3d90ff!=null?_0x3a7ce9=_0x684ff3['filter']['updateChild'](_0xcc81b0['getNode'](),_0xf3f10f,_0x3d90ff,_0x3461bf,_0x2924d9,_0x1f5149):_0x3a7ce9=_0xcc81b0['getNode']();}}return wt(_0x2bba5c,_0x3a7ce9,_0xcc81b0['isFullyInitialized']()||v(_0x210b65),_0x684ff3['filter']['filtersNodes']());}}function vn(_0x7ae961,_0x4b017c,_0xc72999,_0x25514e,_0x1baaf0,_0x269b33,_0x3fcbf8,_0x729ae1){const _0x46c006=_0x4b017c['serverCache'];let _0x3d0ed4;const _0x20a20c=_0x3fcbf8?_0x7ae961['filter']:_0x7ae961['filter']['getIndexedFilter']();if(v(_0xc72999))_0x3d0ed4=_0x20a20c['updateFullNode'](_0x46c006['getNode'](),_0x25514e,null);else{if(_0x20a20c['filtersNodes']()&&!_0x46c006['isFiltered']()){const _0x4b1cfb=_0x46c006['getNode']()['updateChild'](_0xc72999,_0x25514e);_0x3d0ed4=_0x20a20c['updateFullNode'](_0x46c006['getNode'](),_0x4b1cfb,null);}else{const _0x209dfc=y(_0xc72999);if(!_0x46c006['isCompleteForPath'](_0xc72999)&&we(_0xc72999)>0x1)return _0x4b017c;const _0x29d1e9=b(_0xc72999),_0x29a0ff=_0x46c006['getNode']()['getImmediateChild'](_0x209dfc)['updateChild'](_0x29d1e9,_0x25514e);_0x209dfc==='.priority'?_0x3d0ed4=_0x20a20c['updatePriority'](_0x46c006['getNode'](),_0x29a0ff):_0x3d0ed4=_0x20a20c['updateChild'](_0x46c006['getNode'](),_0x209dfc,_0x29a0ff,_0x29d1e9,Vo,null);}}const _0x2a9444=Lo(_0x4b017c,_0x3d0ed4,_0x46c006['isFullyInitialized']()||v(_0xc72999),_0x20a20c['filtersNodes']()),_0x16e154=new ns(_0x1baaf0,_0x2a9444,_0x269b33);return Ho(_0x7ae961,_0x2a9444,_0xc72999,_0x1baaf0,_0x16e154,_0x729ae1);}function Ti(_0x270c90,_0x243beb,_0x36ac7a,_0x50dcf9,_0x1b26f7,_0xfe5628,_0x58f041){const _0x2c808c=_0x243beb['eventCache'];let _0x252f91,_0x1b8ba2;const _0x5b5312=new ns(_0x1b26f7,_0x243beb,_0xfe5628);if(v(_0x36ac7a))_0x1b8ba2=_0x270c90['filter']['updateFullNode'](_0x243beb['eventCache']['getNode'](),_0x50dcf9,_0x58f041),_0x252f91=wt(_0x243beb,_0x1b8ba2,!0x0,_0x270c90['filter']['filtersNodes']());else{const _0xd732c1=y(_0x36ac7a);if(_0xd732c1==='.priority')_0x1b8ba2=_0x270c90['filter']['updatePriority'](_0x243beb['eventCache']['getNode'](),_0x50dcf9),_0x252f91=wt(_0x243beb,_0x1b8ba2,_0x2c808c['isFullyInitialized'](),_0x2c808c['isFiltered']());else{const _0x54fb45=b(_0x36ac7a),_0x53d5c4=_0x2c808c['getNode']()['getImmediateChild'](_0xd732c1);let _0xee5aa8;if(v(_0x54fb45))_0xee5aa8=_0x50dcf9;else{const _0x264961=_0x5b5312['getCompleteChild'](_0xd732c1);_0x264961!=null?Gi(_0x54fb45)==='.priority'&&_0x264961['getChild'](To(_0x54fb45))['isEmpty']()?_0xee5aa8=_0x264961:_0xee5aa8=_0x264961['updateChild'](_0x54fb45,_0x50dcf9):_0xee5aa8=g['EMPTY_NODE'];}if(_0x53d5c4['equals'](_0xee5aa8))_0x252f91=_0x243beb;else{const _0x21b69c=_0x270c90['filter']['updateChild'](_0x2c808c['getNode'](),_0xd732c1,_0xee5aa8,_0x54fb45,_0x5b5312,_0x58f041);_0x252f91=wt(_0x243beb,_0x21b69c,_0x2c808c['isFullyInitialized'](),_0x270c90['filter']['filtersNodes']());}}}return _0x252f91;}function ar(_0x4557cd,_0x454960){return _0x4557cd['eventCache']['isCompleteForChild'](_0x454960);}function bu(_0x1bec1d,_0x2578e5,_0x30392f,_0x3e6cae,_0x8907a5,_0x1255a0,_0x1729c7){let _0x15e336=_0x2578e5;return _0x3e6cae['foreach']((_0x293d6c,_0x31038e)=>{const _0x54338e=A(_0x30392f,_0x293d6c);ar(_0x2578e5,y(_0x54338e))&&(_0x15e336=Ti(_0x1bec1d,_0x15e336,_0x54338e,_0x31038e,_0x8907a5,_0x1255a0,_0x1729c7));}),_0x3e6cae['foreach']((_0x4fe15e,_0x59387b)=>{const _0xa6902b=A(_0x30392f,_0x4fe15e);ar(_0x2578e5,y(_0xa6902b))||(_0x15e336=Ti(_0x1bec1d,_0x15e336,_0xa6902b,_0x59387b,_0x8907a5,_0x1255a0,_0x1729c7));}),_0x15e336;}function cr(_0x22ca48,_0x123065,_0x529300){return _0x529300['foreach']((_0x434685,_0x4c8562)=>{_0x123065=_0x123065['updateChild'](_0x434685,_0x4c8562);}),_0x123065;}function Si(_0x3377de,_0x458904,_0x5b660a,_0x112fa2,_0x6c71dd,_0x1d667c,_0x1e91b2,_0x14ce76){if(_0x458904['serverCache']['getNode']()['isEmpty']()&&!_0x458904['serverCache']['isFullyInitialized']())return _0x458904;let _0x88e1e0=_0x458904,_0x532de2;v(_0x5b660a)?_0x532de2=_0x112fa2:_0x532de2=new S(null)['setTree'](_0x5b660a,_0x112fa2);const _0x4bbf05=_0x458904['serverCache']['getNode']();return _0x532de2['children']['inorderTraversal']((_0x133d32,_0x548e3a)=>{if(_0x4bbf05['hasChild'](_0x133d32)){const _0xc42ae1=_0x458904['serverCache']['getNode']()['getImmediateChild'](_0x133d32),_0x30f359=cr(_0x3377de,_0xc42ae1,_0x548e3a);_0x88e1e0=vn(_0x3377de,_0x88e1e0,new C(_0x133d32),_0x30f359,_0x6c71dd,_0x1d667c,_0x1e91b2,_0x14ce76);}}),_0x532de2['children']['inorderTraversal']((_0x1debab,_0x93635)=>{const _0x5417eb=!_0x458904['serverCache']['isCompleteForChild'](_0x1debab)&&_0x93635['value']===null;if(!_0x4bbf05['hasChild'](_0x1debab)&&!_0x5417eb){const _0xb5448=_0x458904['serverCache']['getNode']()['getImmediateChild'](_0x1debab),_0x125b35=cr(_0x3377de,_0xb5448,_0x93635);_0x88e1e0=vn(_0x3377de,_0x88e1e0,new C(_0x1debab),_0x125b35,_0x6c71dd,_0x1d667c,_0x1e91b2,_0x14ce76);}}),_0x88e1e0;}function Ru(_0x288367,_0x341e16,_0x39de76,_0x3cc931,_0x49a746,_0x1d20c0,_0x293c0f){if(yn(_0x49a746,_0x39de76)!=null)return _0x341e16;const _0x201984=_0x341e16['serverCache']['isFiltered'](),_0x37e122=_0x341e16['serverCache'];if(_0x3cc931['value']!=null){if(v(_0x39de76)&&_0x37e122['isFullyInitialized']()||_0x37e122['isCompleteForPath'](_0x39de76))return vn(_0x288367,_0x341e16,_0x39de76,_0x37e122['getNode']()['getChild'](_0x39de76),_0x49a746,_0x1d20c0,_0x201984,_0x293c0f);if(v(_0x39de76)){let _0x2d65ed=new S(null);return _0x37e122['getNode']()['forEachChild'](ye,(_0x5798a3,_0xd0e87)=>{_0x2d65ed=_0x2d65ed['set'](new C(_0x5798a3),_0xd0e87);}),Si(_0x288367,_0x341e16,_0x39de76,_0x2d65ed,_0x49a746,_0x1d20c0,_0x201984,_0x293c0f);}else return _0x341e16;}else{let _0x571246=new S(null);return _0x3cc931['foreach']((_0x3d3b01,_0x4a681b)=>{const _0x3ecc80=A(_0x39de76,_0x3d3b01);_0x37e122['isCompleteForPath'](_0x3ecc80)&&(_0x571246=_0x571246['set'](_0x3d3b01,_0x37e122['getNode']()['getChild'](_0x3ecc80)));}),Si(_0x288367,_0x341e16,_0x39de76,_0x571246,_0x49a746,_0x1d20c0,_0x201984,_0x293c0f);}}function Au(_0x583826,_0x50085e,_0x3eccee,_0x137000,_0x3b4e1e){const _0x4b5305=_0x50085e['serverCache'],_0x505ff3=Lo(_0x50085e,_0x4b5305['getNode'](),_0x4b5305['isFullyInitialized']()||v(_0x3eccee),_0x4b5305['isFiltered']());return Ho(_0x583826,_0x505ff3,_0x3eccee,_0x137000,Vo,_0x3b4e1e);}function ku(_0x392c66,_0xe0d8a7,_0x5653a4,_0x43bc29,_0x1a102e,_0x469db5){let _0x39edb9;if(yn(_0x43bc29,_0x5653a4)!=null)return _0xe0d8a7;{const _0x9087d=new ns(_0x43bc29,_0xe0d8a7,_0x1a102e),_0x1e9f24=_0xe0d8a7['eventCache']['getNode']();let _0x14f020;if(v(_0x5653a4)||y(_0x5653a4)==='.priority'){let _0x795f2;if(_0xe0d8a7['serverCache']['isFullyInitialized']())_0x795f2=mn(_0x43bc29,Ue(_0xe0d8a7));else{const _0x262a03=_0xe0d8a7['serverCache']['getNode']();f(_0x262a03 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x795f2=es(_0x43bc29,_0x262a03);}_0x795f2=_0x795f2,_0x14f020=_0x392c66['filter']['updateFullNode'](_0x1e9f24,_0x795f2,_0x469db5);}else{const _0x18ad18=y(_0x5653a4);let _0x55cb24=ts(_0x43bc29,_0x18ad18,_0xe0d8a7['serverCache']);_0x55cb24==null&&_0xe0d8a7['serverCache']['isCompleteForChild'](_0x18ad18)&&(_0x55cb24=_0x1e9f24['getImmediateChild'](_0x18ad18)),_0x55cb24!=null?_0x14f020=_0x392c66['filter']['updateChild'](_0x1e9f24,_0x18ad18,_0x55cb24,b(_0x5653a4),_0x9087d,_0x469db5):_0xe0d8a7['eventCache']['getNode']()['hasChild'](_0x18ad18)?_0x14f020=_0x392c66['filter']['updateChild'](_0x1e9f24,_0x18ad18,g['EMPTY_NODE'],b(_0x5653a4),_0x9087d,_0x469db5):_0x14f020=_0x1e9f24,_0x14f020['isEmpty']()&&_0xe0d8a7['serverCache']['isFullyInitialized']()&&(_0x39edb9=mn(_0x43bc29,Ue(_0xe0d8a7)),_0x39edb9['isLeafNode']()&&(_0x14f020=_0x392c66['filter']['updateFullNode'](_0x14f020,_0x39edb9,_0x469db5)));}return _0x39edb9=_0xe0d8a7['serverCache']['isFullyInitialized']()||yn(_0x43bc29,w())!=null,wt(_0xe0d8a7,_0x14f020,_0x39edb9,_0x392c66['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x50ccc5,_0x177165){this['query_']=_0x50ccc5,this['eventRegistrations_']=[];const _0x21262c=this['query_']['_queryParams'],_0x434765=new Yi(_0x21262c['getIndex']()),_0x1defb5=qh(_0x21262c);this['processor_']=wu(_0x1defb5);const _0x2ba65b=_0x177165['serverCache'],_0x249b24=_0x177165['eventCache'],_0x52ca6a=_0x434765['updateFullNode'](g['EMPTY_NODE'],_0x2ba65b['getNode'](),null),_0x4c7856=_0x1defb5['updateFullNode'](g['EMPTY_NODE'],_0x249b24['getNode'](),null),_0x12c8b6=new Ce(_0x52ca6a,_0x2ba65b['isFullyInitialized'](),_0x434765['filtersNodes']()),_0x561a6f=new Ce(_0x4c7856,_0x249b24['isFullyInitialized'](),_0x1defb5['filtersNodes']());this['viewCache_']=Dn(_0x561a6f,_0x12c8b6),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x24c307){return _0x24c307['viewCache_']['serverCache']['getNode']();}function Ou(_0x332b97){return gn(_0x332b97['viewCache_']);}function Du(_0x1aa11c,_0x3e73ed){const _0x3b3020=Ue(_0x1aa11c['viewCache_']);return _0x3b3020&&(_0x1aa11c['query']['_queryParams']['loadsAllData']()||!v(_0x3e73ed)&&!_0x3b3020['getImmediateChild'](y(_0x3e73ed))['isEmpty']())?_0x3b3020['getChild'](_0x3e73ed):null;}function lr(_0x26ac29){return _0x26ac29['eventRegistrations_']['length']===0x0;}function Mu(_0x3297c0,_0x3917ca){_0x3297c0['eventRegistrations_']['push'](_0x3917ca);}function hr(_0x55ce1e,_0x3d6142,_0x3e55fb){const _0x3f8f8f=[];if(_0x3e55fb){f(_0x3d6142==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3b7686=_0x55ce1e['query']['_path'];_0x55ce1e['eventRegistrations_']['forEach'](_0x58ceb3=>{const _0x3147ea=_0x58ceb3['createCancelEvent'](_0x3e55fb,_0x3b7686);_0x3147ea&&_0x3f8f8f['push'](_0x3147ea);});}if(_0x3d6142){let _0x3d76e5=[];for(let _0x517fd2=0x0;_0x517fd2<_0x55ce1e['eventRegistrations_']['length'];++_0x517fd2){const _0x4edc1c=_0x55ce1e['eventRegistrations_'][_0x517fd2];if(!_0x4edc1c['matches'](_0x3d6142))_0x3d76e5['push'](_0x4edc1c);else{if(_0x3d6142['hasAnyCallback']()){_0x3d76e5=_0x3d76e5['concat'](_0x55ce1e['eventRegistrations_']['slice'](_0x517fd2+0x1));break;}}}_0x55ce1e['eventRegistrations_']=_0x3d76e5;}else _0x55ce1e['eventRegistrations_']=[];return _0x3f8f8f;}function ur(_0x42a9c4,_0x5787ac,_0x5e4862,_0x1472bf){_0x5787ac['type']===q['MERGE']&&_0x5787ac['source']['queryId']!==null&&(f(Ue(_0x42a9c4['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x42a9c4['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5014fe=_0x42a9c4['viewCache_'],_0x284dc8=Tu(_0x42a9c4['processor_'],_0x5014fe,_0x5787ac,_0x5e4862,_0x1472bf);return Cu(_0x42a9c4['processor_'],_0x284dc8['viewCache']),f(_0x284dc8['viewCache']['serverCache']['isFullyInitialized']()||!_0x5014fe['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x42a9c4['viewCache_']=_0x284dc8['viewCache'],$o(_0x42a9c4,_0x284dc8['changes'],_0x284dc8['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x1a767a,_0x5c2bbb){const _0x55a953=_0x1a767a['viewCache_']['eventCache'],_0x9a3541=[];return _0x55a953['getNode']()['isLeafNode']()||_0x55a953['getNode']()['forEachChild'](R,(_0x1614cf,_0x49b169)=>{_0x9a3541['push'](tt(_0x1614cf,_0x49b169));}),_0x55a953['isFullyInitialized']()&&_0x9a3541['push'](Oo(_0x55a953['getNode']())),$o(_0x1a767a,_0x9a3541,_0x55a953['getNode'](),_0x5c2bbb);}function $o(_0x439ebd,_0x29ce19,_0x51f49a,_0x10aeb6){const _0x3e65fe=_0x10aeb6?[_0x10aeb6]:_0x439ebd['eventRegistrations_'];return nu(_0x439ebd['eventGenerator_'],_0x29ce19,_0x51f49a,_0x3e65fe);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x2b5f22){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x2b5f22;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x26c8a5){return _0x26c8a5['views']['size']===0x0;}function is(_0x5e5d2b,_0x5573ab,_0x32ac01,_0x5979a4){const _0x2a8615=_0x5573ab['source']['queryId'];if(_0x2a8615!==null){const _0x327718=_0x5e5d2b['views']['get'](_0x2a8615);return f(_0x327718!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x327718,_0x5573ab,_0x32ac01,_0x5979a4);}else{let _0x50d1e0=[];for(const _0x450a35 of _0x5e5d2b['views']['values']())_0x50d1e0=_0x50d1e0['concat'](ur(_0x450a35,_0x5573ab,_0x32ac01,_0x5979a4));return _0x50d1e0;}}function qo(_0x2c7ab9,_0xb68da,_0x291b26,_0x5de819,_0x1d4258){const _0x434893=_0xb68da['_queryIdentifier'],_0x333e6d=_0x2c7ab9['views']['get'](_0x434893);if(!_0x333e6d){let _0x3b488f=mn(_0x291b26,_0x1d4258?_0x5de819:null),_0x4a2dfe=!0x1;_0x3b488f?_0x4a2dfe=!0x0:_0x5de819 instanceof g?(_0x3b488f=es(_0x291b26,_0x5de819),_0x4a2dfe=!0x1):(_0x3b488f=g['EMPTY_NODE'],_0x4a2dfe=!0x1);const _0x3584da=Dn(new Ce(_0x3b488f,_0x4a2dfe,!0x1),new Ce(_0x5de819,_0x1d4258,!0x1));return new Nu(_0xb68da,_0x3584da);}return _0x333e6d;}function Wu(_0x3b53eb,_0x41d1ad,_0x334cee,_0x15b89b,_0x30084a,_0x2503d9){const _0xd3aa12=qo(_0x3b53eb,_0x41d1ad,_0x15b89b,_0x30084a,_0x2503d9);return _0x3b53eb['views']['has'](_0x41d1ad['_queryIdentifier'])||_0x3b53eb['views']['set'](_0x41d1ad['_queryIdentifier'],_0xd3aa12),Mu(_0xd3aa12,_0x334cee),Lu(_0xd3aa12,_0x334cee);}function Bu(_0x1e4685,_0x557b34,_0x290710,_0x976d65){const _0x33859b=_0x557b34['_queryIdentifier'],_0x52c51b=[];let _0x2259c8=[];const _0x2f36da=Te(_0x1e4685);if(_0x33859b==='default'){for(const [_0x312f50,_0x8f3deb]of _0x1e4685['views']['entries']())_0x2259c8=_0x2259c8['concat'](hr(_0x8f3deb,_0x290710,_0x976d65)),lr(_0x8f3deb)&&(_0x1e4685['views']['delete'](_0x312f50),_0x8f3deb['query']['_queryParams']['loadsAllData']()||_0x52c51b['push'](_0x8f3deb['query']));}else{const _0x48c364=_0x1e4685['views']['get'](_0x33859b);_0x48c364&&(_0x2259c8=_0x2259c8['concat'](hr(_0x48c364,_0x290710,_0x976d65)),lr(_0x48c364)&&(_0x1e4685['views']['delete'](_0x33859b),_0x48c364['query']['_queryParams']['loadsAllData']()||_0x52c51b['push'](_0x48c364['query'])));}return _0x2f36da&&!Te(_0x1e4685)&&_0x52c51b['push'](new(Fu())(_0x557b34['_repo'],_0x557b34['_path'])),{'removed':_0x52c51b,'events':_0x2259c8};}function zo(_0x13baad){const _0x4f8c96=[];for(const _0x2df2b0 of _0x13baad['views']['values']())_0x2df2b0['query']['_queryParams']['loadsAllData']()||_0x4f8c96['push'](_0x2df2b0);return _0x4f8c96;}function Ee(_0x39ed5e,_0x388721){let _0x5e3a74=null;for(const _0x1beeab of _0x39ed5e['views']['values']())_0x5e3a74=_0x5e3a74||Du(_0x1beeab,_0x388721);return _0x5e3a74;}function jo(_0x543952,_0x117e1b){if(_0x117e1b['_queryParams']['loadsAllData']())return Ln(_0x543952);{const _0x5ed4a9=_0x117e1b['_queryIdentifier'];return _0x543952['views']['get'](_0x5ed4a9);}}function Ko(_0x3e696e,_0x4bf1ef){return jo(_0x3e696e,_0x4bf1ef)!=null;}function Te(_0x5fd690){return Ln(_0x5fd690)!=null;}function Ln(_0x5487a1){for(const _0x28cd45 of _0x5487a1['views']['values']())if(_0x28cd45['query']['_queryParams']['loadsAllData']())return _0x28cd45;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x21340e){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x21340e;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x46afe5){this['listenProvider_']=_0x46afe5,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x397348,_0x4b2d54,_0x43d7d4,_0x5ee1df,_0x445f07){return ou(_0x397348['pendingWriteTree_'],_0x4b2d54,_0x43d7d4,_0x5ee1df,_0x445f07),_0x445f07?ht(_0x397348,new Fe(Ji(),_0x4b2d54,_0x43d7d4)):[];}function Gu(_0x354596,_0x4e13e7,_0xbda75e,_0x4593e6){au(_0x354596['pendingWriteTree_'],_0x4e13e7,_0xbda75e,_0x4593e6);const _0x234931=S['fromObject'](_0xbda75e);return ht(_0x354596,new nt(Ji(),_0x4e13e7,_0x234931));}function pe(_0x51df63,_0x5eb647,_0x3b99b7=!0x1){const _0x550ba3=cu(_0x51df63['pendingWriteTree_'],_0x5eb647);if(lu(_0x51df63['pendingWriteTree_'],_0x5eb647)){let _0xb1db69=new S(null);return _0x550ba3['snap']!=null?_0xb1db69=_0xb1db69['set'](w(),!0x0):x(_0x550ba3['children'],_0x55671a=>{_0xb1db69=_0xb1db69['set'](new C(_0x55671a),!0x0);}),ht(_0x51df63,new _n(_0x550ba3['path'],_0xb1db69,_0x3b99b7));}else return[];}function $t(_0x2bbd55,_0xba060a,_0x277401){return ht(_0x2bbd55,new Fe(Xi(),_0xba060a,_0x277401));}function qu(_0x515a98,_0xb0487c,_0x22221c){const _0x22c85d=S['fromObject'](_0x22221c);return ht(_0x515a98,new nt(Xi(),_0xb0487c,_0x22c85d));}function zu(_0x1bde1a,_0x2754fd){return ht(_0x1bde1a,new Dt(Xi(),_0x2754fd));}function ju(_0xa3135d,_0x5c9631,_0x26bcd0){const _0x2f9735=rs(_0xa3135d,_0x26bcd0);if(_0x2f9735){const _0x4d53af=os(_0x2f9735),_0x4a2d52=_0x4d53af['path'],_0x271037=_0x4d53af['queryId'],_0x4a64c4=F(_0x4a2d52,_0x5c9631),_0x5cdd04=new Dt(Zi(_0x271037),_0x4a64c4);return as(_0xa3135d,_0x4a2d52,_0x5cdd04);}else return[];}function wn(_0x47df96,_0x34043b,_0x5a8bb8,_0x36e659,_0x211930=!0x1){const _0x6ef5ad=_0x34043b['_path'],_0x482053=_0x47df96['syncPointTree_']['get'](_0x6ef5ad);let _0x3ba784=[];if(_0x482053&&(_0x34043b['_queryIdentifier']==='default'||Ko(_0x482053,_0x34043b))){const _0x3d2781=Bu(_0x482053,_0x34043b,_0x5a8bb8,_0x36e659);Uu(_0x482053)&&(_0x47df96['syncPointTree_']=_0x47df96['syncPointTree_']['remove'](_0x6ef5ad));const _0x1e99c8=_0x3d2781['removed'];if(_0x3ba784=_0x3d2781['events'],!_0x211930){const _0x2c1261=_0x1e99c8['findIndex'](_0x525132=>_0x525132['_queryParams']['loadsAllData']())!==-0x1,_0x44539d=_0x47df96['syncPointTree_']['findOnPath'](_0x6ef5ad,(_0x54f480,_0x582dbc)=>Te(_0x582dbc));if(_0x2c1261&&!_0x44539d){const _0x3d96b1=_0x47df96['syncPointTree_']['subtree'](_0x6ef5ad);if(!_0x3d96b1['isEmpty']()){const _0x3e80a3=Qu(_0x3d96b1);for(let _0x1c5e49=0x0;_0x1c5e49<_0x3e80a3['length'];++_0x1c5e49){const _0x1f77f3=_0x3e80a3[_0x1c5e49],_0x53de82=_0x1f77f3['query'],_0x2c7460=Xo(_0x47df96,_0x1f77f3);_0x47df96['listenProvider_']['startListening'](Tt(_0x53de82),Mt(_0x47df96,_0x53de82),_0x2c7460['hashFn'],_0x2c7460['onComplete']);}}}!_0x44539d&&_0x1e99c8['length']>0x0&&!_0x36e659&&(_0x2c1261?_0x47df96['listenProvider_']['stopListening'](Tt(_0x34043b),null):_0x1e99c8['forEach'](_0x46b261=>{const _0x5d105f=_0x47df96['queryToTagMap']['get'](Fn(_0x46b261));_0x47df96['listenProvider_']['stopListening'](Tt(_0x46b261),_0x5d105f);}));}Ju(_0x47df96,_0x1e99c8);}return _0x3ba784;}function Yo(_0x182dd4,_0x26719a,_0x320726,_0x2f2550){const _0x2cee43=rs(_0x182dd4,_0x2f2550);if(_0x2cee43!=null){const _0x38ed45=os(_0x2cee43),_0x1e759c=_0x38ed45['path'],_0x74a8b1=_0x38ed45['queryId'],_0x1e3211=F(_0x1e759c,_0x26719a),_0x42ef80=new Fe(Zi(_0x74a8b1),_0x1e3211,_0x320726);return as(_0x182dd4,_0x1e759c,_0x42ef80);}else return[];}function Ku(_0x2f176f,_0x22f41f,_0x3bafff,_0x5e032c){const _0x59d012=rs(_0x2f176f,_0x5e032c);if(_0x59d012){const _0x5e2a85=os(_0x59d012),_0x427182=_0x5e2a85['path'],_0x4d7e56=_0x5e2a85['queryId'],_0x4b0ea6=F(_0x427182,_0x22f41f),_0x20bd0a=S['fromObject'](_0x3bafff),_0x2a3445=new nt(Zi(_0x4d7e56),_0x4b0ea6,_0x20bd0a);return as(_0x2f176f,_0x427182,_0x2a3445);}else return[];}function bi(_0x208a81,_0x5be602,_0xbeb4b3,_0x4eef4f=!0x1){const _0x1e9214=_0x5be602['_path'];let _0x5493cd=null,_0xadc4fd=!0x1;_0x208a81['syncPointTree_']['foreachOnPath'](_0x1e9214,(_0x35c8fb,_0x16a99c)=>{const _0x9676bc=F(_0x35c8fb,_0x1e9214);_0x5493cd=_0x5493cd||Ee(_0x16a99c,_0x9676bc),_0xadc4fd=_0xadc4fd||Te(_0x16a99c);});let _0x235438=_0x208a81['syncPointTree_']['get'](_0x1e9214);_0x235438?(_0xadc4fd=_0xadc4fd||Te(_0x235438),_0x5493cd=_0x5493cd||Ee(_0x235438,w())):(_0x235438=new Go(),_0x208a81['syncPointTree_']=_0x208a81['syncPointTree_']['set'](_0x1e9214,_0x235438));let _0x2c208b;_0x5493cd!=null?_0x2c208b=!0x0:(_0x2c208b=!0x1,_0x5493cd=g['EMPTY_NODE'],_0x208a81['syncPointTree_']['subtree'](_0x1e9214)['foreachChild']((_0x4e9bd0,_0x5bad8d)=>{const _0x31ed3a=Ee(_0x5bad8d,w());_0x31ed3a&&(_0x5493cd=_0x5493cd['updateImmediateChild'](_0x4e9bd0,_0x31ed3a));}));const _0x485c92=Ko(_0x235438,_0x5be602);if(!_0x485c92&&!_0x5be602['_queryParams']['loadsAllData']()){const _0x1127d6=Fn(_0x5be602);f(!_0x208a81['queryToTagMap']['has'](_0x1127d6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x56ed79=Xu();_0x208a81['queryToTagMap']['set'](_0x1127d6,_0x56ed79),_0x208a81['tagToQueryMap']['set'](_0x56ed79,_0x1127d6);}const _0x2f4356=Mn(_0x208a81['pendingWriteTree_'],_0x1e9214);let _0x1f3948=Wu(_0x235438,_0x5be602,_0xbeb4b3,_0x2f4356,_0x5493cd,_0x2c208b);if(!_0x485c92&&!_0xadc4fd&&!_0x4eef4f){const _0x4668d8=jo(_0x235438,_0x5be602);_0x1f3948=_0x1f3948['concat'](Zu(_0x208a81,_0x5be602,_0x4668d8));}return _0x1f3948;}function xn(_0x2895af,_0x1d8d12,_0x2e0f44){const _0x43383b=_0x2895af['pendingWriteTree_'],_0x1d26f7=_0x2895af['syncPointTree_']['findOnPath'](_0x1d8d12,(_0x206d2d,_0x581b79)=>{const _0x730521=F(_0x206d2d,_0x1d8d12),_0x7d5817=Ee(_0x581b79,_0x730521);if(_0x7d5817)return _0x7d5817;});return Uo(_0x43383b,_0x1d8d12,_0x1d26f7,_0x2e0f44,!0x0);}function Yu(_0x3f3d01,_0x462a37){const _0x36aa45=_0x462a37['_path'];let _0x44a5c0=null;_0x3f3d01['syncPointTree_']['foreachOnPath'](_0x36aa45,(_0x1f2133,_0x411f4c)=>{const _0x27d769=F(_0x1f2133,_0x36aa45);_0x44a5c0=_0x44a5c0||Ee(_0x411f4c,_0x27d769);});let _0x2d060f=_0x3f3d01['syncPointTree_']['get'](_0x36aa45);_0x2d060f?_0x44a5c0=_0x44a5c0||Ee(_0x2d060f,w()):(_0x2d060f=new Go(),_0x3f3d01['syncPointTree_']=_0x3f3d01['syncPointTree_']['set'](_0x36aa45,_0x2d060f));const _0x485d35=_0x44a5c0!=null,_0x44d7e1=_0x485d35?new Ce(_0x44a5c0,!0x0,!0x1):null,_0x315020=Mn(_0x3f3d01['pendingWriteTree_'],_0x462a37['_path']),_0x205608=qo(_0x2d060f,_0x462a37,_0x315020,_0x485d35?_0x44d7e1['getNode']():g['EMPTY_NODE'],_0x485d35);return Ou(_0x205608);}function ht(_0x32e93e,_0x4a0fbf){return Qo(_0x4a0fbf,_0x32e93e['syncPointTree_'],null,Mn(_0x32e93e['pendingWriteTree_'],w()));}function Qo(_0x298fd0,_0xf48a46,_0x55d685,_0x7c42eb){if(v(_0x298fd0['path']))return Jo(_0x298fd0,_0xf48a46,_0x55d685,_0x7c42eb);{const _0x5810be=_0xf48a46['get'](w());_0x55d685==null&&_0x5810be!=null&&(_0x55d685=Ee(_0x5810be,w()));let _0x4b63ca=[];const _0x2ba677=y(_0x298fd0['path']),_0xdf2043=_0x298fd0['operationForChild'](_0x2ba677),_0x48e679=_0xf48a46['children']['get'](_0x2ba677);if(_0x48e679&&_0xdf2043){const _0x23b715=_0x55d685?_0x55d685['getImmediateChild'](_0x2ba677):null,_0x285015=Wo(_0x7c42eb,_0x2ba677);_0x4b63ca=_0x4b63ca['concat'](Qo(_0xdf2043,_0x48e679,_0x23b715,_0x285015));}return _0x5810be&&(_0x4b63ca=_0x4b63ca['concat'](is(_0x5810be,_0x298fd0,_0x7c42eb,_0x55d685))),_0x4b63ca;}}function Jo(_0x560139,_0x2b41f9,_0x36c92f,_0x418d74){const _0x3c0858=_0x2b41f9['get'](w());_0x36c92f==null&&_0x3c0858!=null&&(_0x36c92f=Ee(_0x3c0858,w()));let _0x20d5d2=[];return _0x2b41f9['children']['inorderTraversal']((_0x448a38,_0x303b9)=>{const _0x1b85fb=_0x36c92f?_0x36c92f['getImmediateChild'](_0x448a38):null,_0x511789=Wo(_0x418d74,_0x448a38),_0x3d9172=_0x560139['operationForChild'](_0x448a38);_0x3d9172&&(_0x20d5d2=_0x20d5d2['concat'](Jo(_0x3d9172,_0x303b9,_0x1b85fb,_0x511789)));}),_0x3c0858&&(_0x20d5d2=_0x20d5d2['concat'](is(_0x3c0858,_0x560139,_0x418d74,_0x36c92f))),_0x20d5d2;}function Xo(_0x147f05,_0x4abb83){const _0x29317f=_0x4abb83['query'],_0x46d39a=Mt(_0x147f05,_0x29317f);return{'hashFn':()=>(Pu(_0x4abb83)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x18245e=>{if(_0x18245e==='ok')return _0x46d39a?ju(_0x147f05,_0x29317f['_path'],_0x46d39a):zu(_0x147f05,_0x29317f['_path']);{const _0x285f34=ql(_0x18245e,_0x29317f);return wn(_0x147f05,_0x29317f,null,_0x285f34);}}};}function Mt(_0x4b76d3,_0x7104f4){const _0xce1e5c=Fn(_0x7104f4);return _0x4b76d3['queryToTagMap']['get'](_0xce1e5c);}function Fn(_0x1e1a40){return _0x1e1a40['_path']['toString']()+'$'+_0x1e1a40['_queryIdentifier'];}function rs(_0x9974df,_0x4d4aee){return _0x9974df['tagToQueryMap']['get'](_0x4d4aee);}function os(_0x411494){const _0x13fbff=_0x411494['indexOf']('$');return f(_0x13fbff!==-0x1&&_0x13fbff<_0x411494['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x411494['substr'](_0x13fbff+0x1),'path':new C(_0x411494['substr'](0x0,_0x13fbff))};}function as(_0xde22a8,_0x1d13c8,_0x4057ee){const _0x4346a9=_0xde22a8['syncPointTree_']['get'](_0x1d13c8);f(_0x4346a9,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2904f5=Mn(_0xde22a8['pendingWriteTree_'],_0x1d13c8);return is(_0x4346a9,_0x4057ee,_0x2904f5,null);}function Qu(_0x56da7a){return _0x56da7a['fold']((_0x5a91a7,_0x54bb2d,_0x5c58da)=>{if(_0x54bb2d&&Te(_0x54bb2d))return[Ln(_0x54bb2d)];{let _0x4cd91d=[];return _0x54bb2d&&(_0x4cd91d=zo(_0x54bb2d)),x(_0x5c58da,(_0x28717d,_0x347629)=>{_0x4cd91d=_0x4cd91d['concat'](_0x347629);}),_0x4cd91d;}});}function Tt(_0x6c549c){return _0x6c549c['_queryParams']['loadsAllData']()&&!_0x6c549c['_queryParams']['isDefault']()?new(Hu())(_0x6c549c['_repo'],_0x6c549c['_path']):_0x6c549c;}function Ju(_0x301d89,_0x4461f7){for(let _0x458104=0x0;_0x458104<_0x4461f7['length'];++_0x458104){const _0x3d8934=_0x4461f7[_0x458104];if(!_0x3d8934['_queryParams']['loadsAllData']()){const _0x517360=Fn(_0x3d8934),_0xc09bb1=_0x301d89['queryToTagMap']['get'](_0x517360);_0x301d89['queryToTagMap']['delete'](_0x517360),_0x301d89['tagToQueryMap']['delete'](_0xc09bb1);}}}function Xu(){return $u++;}function Zu(_0x4ab0f8,_0xc19d91,_0x5ef763){const _0x57e909=_0xc19d91['_path'],_0x4e6bdd=Mt(_0x4ab0f8,_0xc19d91),_0x336bb7=Xo(_0x4ab0f8,_0x5ef763),_0x1ac7cd=_0x4ab0f8['listenProvider_']['startListening'](Tt(_0xc19d91),_0x4e6bdd,_0x336bb7['hashFn'],_0x336bb7['onComplete']),_0x19c058=_0x4ab0f8['syncPointTree_']['subtree'](_0x57e909);if(_0x4e6bdd)f(!Te(_0x19c058['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x12c868=_0x19c058['fold']((_0x50fd1b,_0x32ab66,_0x3ad4ce)=>{if(!v(_0x50fd1b)&&_0x32ab66&&Te(_0x32ab66))return[Ln(_0x32ab66)['query']];{let _0xbb5b7d=[];return _0x32ab66&&(_0xbb5b7d=_0xbb5b7d['concat'](zo(_0x32ab66)['map'](_0x2c0904=>_0x2c0904['query']))),x(_0x3ad4ce,(_0x5ac56e,_0x41c465)=>{_0xbb5b7d=_0xbb5b7d['concat'](_0x41c465);}),_0xbb5b7d;}});for(let _0x23018b=0x0;_0x23018b<_0x12c868['length'];++_0x23018b){const _0x5e3d18=_0x12c868[_0x23018b];_0x4ab0f8['listenProvider_']['stopListening'](Tt(_0x5e3d18),Mt(_0x4ab0f8,_0x5e3d18));}}return _0x1ac7cd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x42acc1){this['node_']=_0x42acc1;}['getImmediateChild'](_0x508d32){const _0x2c0d1f=this['node_']['getImmediateChild'](_0x508d32);return new cs(_0x2c0d1f);}['node'](){return this['node_'];}}class ls{constructor(_0x16f4fb,_0x16cd32){this['syncTree_']=_0x16f4fb,this['path_']=_0x16cd32;}['getImmediateChild'](_0x4a049a){const _0x43a458=A(this['path_'],_0x4a049a);return new ls(this['syncTree_'],_0x43a458);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x151ab1){return _0x151ab1=_0x151ab1||{},_0x151ab1['timestamp']=_0x151ab1['timestamp']||new Date()['getTime'](),_0x151ab1;},fr=function(_0x4fa7f4,_0x983b23,_0x1a93e9){if(!_0x4fa7f4||typeof _0x4fa7f4!='object')return _0x4fa7f4;if(f('.sv'in _0x4fa7f4,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4fa7f4['.sv']=='string')return td(_0x4fa7f4['.sv'],_0x983b23,_0x1a93e9);if(typeof _0x4fa7f4['.sv']=='object')return nd(_0x4fa7f4['.sv'],_0x983b23);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4fa7f4,null,0x2));},td=function(_0x42650e,_0x2b8f82,_0x4c9e1f){switch(_0x42650e){case'timestamp':return _0x4c9e1f['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x42650e);}},nd=function(_0x3621e1,_0x209780,_0x1fa84e){_0x3621e1['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3621e1,null,0x2));const _0x39095f=_0x3621e1['increment'];typeof _0x39095f!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x39095f);const _0x3da37f=_0x209780['node']();if(f(_0x3da37f!==null&&typeof _0x3da37f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3da37f['isLeafNode']())return _0x39095f;const _0x475208=_0x3da37f['getValue']();return typeof _0x475208!='number'?_0x39095f:_0x475208+_0x39095f;},Zo=function(_0x3a66e3,_0x205b53,_0x388c65,_0x49a7f3){return us(_0x205b53,new ls(_0x388c65,_0x3a66e3),_0x49a7f3);},hs=function(_0x39553c,_0x3ebb14,_0xd9eeea){return us(_0x39553c,new cs(_0x3ebb14),_0xd9eeea);};function us(_0xc7c8a0,_0x58fd21,_0x2c6570){const _0x39f3d9=_0xc7c8a0['getPriority']()['val'](),_0x5d5662=fr(_0x39f3d9,_0x58fd21['getImmediateChild']('.priority'),_0x2c6570);let _0x21a217;if(_0xc7c8a0['isLeafNode']()){const _0x59de8c=_0xc7c8a0,_0x94c81=fr(_0x59de8c['getValue'](),_0x58fd21,_0x2c6570);return _0x94c81!==_0x59de8c['getValue']()||_0x5d5662!==_0x59de8c['getPriority']()['val']()?new D(_0x94c81,N(_0x5d5662)):_0xc7c8a0;}else{const _0x2155cd=_0xc7c8a0;return _0x21a217=_0x2155cd,_0x5d5662!==_0x2155cd['getPriority']()['val']()&&(_0x21a217=_0x21a217['updatePriority'](new D(_0x5d5662))),_0x2155cd['forEachChild'](R,(_0x2b788e,_0x450bdb)=>{const _0x2ac48b=us(_0x450bdb,_0x58fd21['getImmediateChild'](_0x2b788e),_0x2c6570);_0x2ac48b!==_0x450bdb&&(_0x21a217=_0x21a217['updateImmediateChild'](_0x2b788e,_0x2ac48b));}),_0x21a217;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x49f678='',_0xd92c8b=null,_0xa51f48={'children':{},'childCount':0x0}){this['name']=_0x49f678,this['parent']=_0xd92c8b,this['node']=_0xa51f48;}}function Un(_0x5854c7,_0x248a69){let _0x17161a=_0x248a69 instanceof C?_0x248a69:new C(_0x248a69),_0x20da2d=_0x5854c7,_0x1fb6b4=y(_0x17161a);for(;_0x1fb6b4!==null;){const _0x446192=Oe(_0x20da2d['node']['children'],_0x1fb6b4)||{'children':{},'childCount':0x0};_0x20da2d=new ds(_0x1fb6b4,_0x20da2d,_0x446192),_0x17161a=b(_0x17161a),_0x1fb6b4=y(_0x17161a);}return _0x20da2d;}function Ge(_0x1af3e6){return _0x1af3e6['node']['value'];}function fs(_0x24cdb0,_0x415ac1){_0x24cdb0['node']['value']=_0x415ac1,Ri(_0x24cdb0);}function ea(_0x5b147a){return _0x5b147a['node']['childCount']>0x0;}function id(_0x1a6476){return Ge(_0x1a6476)===void 0x0&&!ea(_0x1a6476);}function Wn(_0x37bdae,_0x4fba9d){x(_0x37bdae['node']['children'],(_0x240eee,_0x7f853d)=>{_0x4fba9d(new ds(_0x240eee,_0x37bdae,_0x7f853d));});}function ta(_0xbf1ab5,_0x85275d,_0x1e66de,_0x2308f4){_0x1e66de&&_0x85275d(_0xbf1ab5),Wn(_0xbf1ab5,_0x261807=>{ta(_0x261807,_0x85275d,!0x0);});}function sd(_0x198db7,_0x471993,_0x20a308){let _0x1e7b22=_0x198db7['parent'];for(;_0x1e7b22!==null;){if(_0x471993(_0x1e7b22))return!0x0;_0x1e7b22=_0x1e7b22['parent'];}return!0x1;}function Gt(_0x59638a){return new C(_0x59638a['parent']===null?_0x59638a['name']:Gt(_0x59638a['parent'])+'/'+_0x59638a['name']);}function Ri(_0x225a01){_0x225a01['parent']!==null&&rd(_0x225a01['parent'],_0x225a01['name'],_0x225a01);}function rd(_0x34ef58,_0x92f158,_0x550b59){const _0x55bf44=id(_0x550b59),_0x7edf49=Y(_0x34ef58['node']['children'],_0x92f158);_0x55bf44&&_0x7edf49?(delete _0x34ef58['node']['children'][_0x92f158],_0x34ef58['node']['childCount']--,Ri(_0x34ef58)):!_0x55bf44&&!_0x7edf49&&(_0x34ef58['node']['children'][_0x92f158]=_0x550b59['node'],_0x34ef58['node']['childCount']++,Ri(_0x34ef58));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x4c202e){return typeof _0x4c202e=='string'&&_0x4c202e['length']!==0x0&&!od['test'](_0x4c202e);},na=function(_0x15407c){return typeof _0x15407c=='string'&&_0x15407c['length']!==0x0&&!ad['test'](_0x15407c);},cd=function(_0x4188af){return _0x4188af&&(_0x4188af=_0x4188af['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x4188af);},Cn=function(_0x544943){return _0x544943===null||typeof _0x544943=='string'||typeof _0x544943=='number'&&!Wi(_0x544943)||_0x544943&&typeof _0x544943=='object'&&Y(_0x544943,'.sv');},qt=function(_0x21f084,_0x35caa8,_0x74e7d3,_0x2ed042){_0x2ed042&&_0x35caa8===void 0x0||zt(Nn(_0x21f084,'value'),_0x35caa8,_0x74e7d3);},zt=function(_0x274e8a,_0x45dc3f,_0xeabb26){const _0x550d5d=_0xeabb26 instanceof C?new Sh(_0xeabb26,_0x274e8a):_0xeabb26;if(_0x45dc3f===void 0x0)throw new Error(_0x274e8a+'contains\x20undefined\x20'+Ne(_0x550d5d));if(typeof _0x45dc3f=='function')throw new Error(_0x274e8a+'contains\x20a\x20function\x20'+Ne(_0x550d5d)+'\x20with\x20contents\x20=\x20'+_0x45dc3f['toString']());if(Wi(_0x45dc3f))throw new Error(_0x274e8a+'contains\x20'+_0x45dc3f['toString']()+'\x20'+Ne(_0x550d5d));if(typeof _0x45dc3f=='string'&&_0x45dc3f['length']>oi/0x3&&Pn(_0x45dc3f)>oi)throw new Error(_0x274e8a+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x550d5d)+'\x20(\x27'+_0x45dc3f['substring'](0x0,0x32)+'...\x27)');if(_0x45dc3f&&typeof _0x45dc3f=='object'){let _0x2f9d28=!0x1,_0x41d507=!0x1;if(x(_0x45dc3f,(_0x241ade,_0x1dfdcf)=>{if(_0x241ade==='.value')_0x2f9d28=!0x0;else{if(_0x241ade!=='.priority'&&_0x241ade!=='.sv'&&(_0x41d507=!0x0,!ps(_0x241ade)))throw new Error(_0x274e8a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x241ade+')\x20'+Ne(_0x550d5d)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x550d5d,_0x241ade),zt(_0x274e8a,_0x1dfdcf,_0x550d5d),Rh(_0x550d5d);}),_0x2f9d28&&_0x41d507)throw new Error(_0x274e8a+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x550d5d)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x24e8d1,_0x59bfe8){let _0x492a7c,_0x225aa1;for(_0x492a7c=0x0;_0x492a7c<_0x59bfe8['length'];_0x492a7c++){_0x225aa1=_0x59bfe8[_0x492a7c];const _0x1ca492=kt(_0x225aa1);for(let _0x37fd6b=0x0;_0x37fd6b<_0x1ca492['length'];_0x37fd6b++)if(!(_0x1ca492[_0x37fd6b]==='.priority'&&_0x37fd6b===_0x1ca492['length']-0x1)){if(!ps(_0x1ca492[_0x37fd6b]))throw new Error(_0x24e8d1+'contains\x20an\x20invalid\x20key\x20('+_0x1ca492[_0x37fd6b]+')\x20in\x20path\x20'+_0x225aa1['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x59bfe8['sort'](Th);let _0x3e0d4f=null;for(_0x492a7c=0x0;_0x492a7c<_0x59bfe8['length'];_0x492a7c++){if(_0x225aa1=_0x59bfe8[_0x492a7c],_0x3e0d4f!==null&&$(_0x3e0d4f,_0x225aa1))throw new Error(_0x24e8d1+'contains\x20a\x20path\x20'+_0x3e0d4f['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x225aa1['toString']());_0x3e0d4f=_0x225aa1;}},hd=function(_0x5ad088,_0x16c8a4,_0x2412b3,_0x28e48b){const _0x4b9f94=Nn(_0x5ad088,'values');if(!(_0x16c8a4&&typeof _0x16c8a4=='object')||Array['isArray'](_0x16c8a4))throw new Error(_0x4b9f94+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4554b6=[];x(_0x16c8a4,(_0x37711a,_0x12b57f)=>{const _0x3fc814=new C(_0x37711a);if(zt(_0x4b9f94,_0x12b57f,A(_0x2412b3,_0x3fc814)),Gi(_0x3fc814)==='.priority'&&!Cn(_0x12b57f))throw new Error(_0x4b9f94+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3fc814['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4554b6['push'](_0x3fc814);}),ld(_0x4b9f94,_0x4554b6);},_s=function(_0x1ca542,_0x3b0012,_0x5a1158,_0x48227f){if(!na(_0x5a1158))throw new Error(Nn(_0x1ca542,_0x3b0012)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5a1158+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x1af869,_0x2d28f4,_0x3016af,_0xec6f0b){_0x3016af&&(_0x3016af=_0x3016af['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x1af869,_0x2d28f4,_0x3016af);},gs=function(_0x2913f7,_0xba0663){if(y(_0xba0663)==='.info')throw new Error(_0x2913f7+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x1599db,_0x140a4b){const _0x354b8b=_0x140a4b['path']['toString']();if(typeof _0x140a4b['repoInfo']['host']!='string'||_0x140a4b['repoInfo']['host']['length']===0x0||!ps(_0x140a4b['repoInfo']['namespace'])&&_0x140a4b['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x354b8b['length']!==0x0&&!cd(_0x354b8b))throw new Error(Nn(_0x1599db,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x26dfdd,_0x480739){let _0x2347a5=null;for(let _0x5d61ee=0x0;_0x5d61ee<_0x480739['length'];_0x5d61ee++){const _0x561aa5=_0x480739[_0x5d61ee],_0x5a26be=_0x561aa5['getPath']();_0x2347a5!==null&&!qi(_0x5a26be,_0x2347a5['path'])&&(_0x26dfdd['eventLists_']['push'](_0x2347a5),_0x2347a5=null),_0x2347a5===null&&(_0x2347a5={'events':[],'path':_0x5a26be}),_0x2347a5['events']['push'](_0x561aa5);}_0x2347a5&&_0x26dfdd['eventLists_']['push'](_0x2347a5);}function ia(_0x4d3e6b,_0x35fd4c,_0x2a16cd){Bn(_0x4d3e6b,_0x2a16cd),sa(_0x4d3e6b,_0x5de11a=>qi(_0x5de11a,_0x35fd4c));}function V(_0x2925f5,_0x3e3eaf,_0x111849){Bn(_0x2925f5,_0x111849),sa(_0x2925f5,_0x574575=>$(_0x574575,_0x3e3eaf)||$(_0x3e3eaf,_0x574575));}function sa(_0x23379f,_0x5f02ed){_0x23379f['recursionDepth_']++;let _0x1db414=!0x0;for(let _0x36dac8=0x0;_0x36dac8<_0x23379f['eventLists_']['length'];_0x36dac8++){const _0x526150=_0x23379f['eventLists_'][_0x36dac8];if(_0x526150){const _0x1b17e5=_0x526150['path'];_0x5f02ed(_0x1b17e5)?(pd(_0x23379f['eventLists_'][_0x36dac8]),_0x23379f['eventLists_'][_0x36dac8]=null):_0x1db414=!0x1;}}_0x1db414&&(_0x23379f['eventLists_']=[]),_0x23379f['recursionDepth_']--;}function pd(_0x10a4dc){for(let _0x48534d=0x0;_0x48534d<_0x10a4dc['events']['length'];_0x48534d++){const _0x3cdba7=_0x10a4dc['events'][_0x48534d];if(_0x3cdba7!==null){_0x10a4dc['events'][_0x48534d]=null;const _0x32d314=_0x3cdba7['getEventRunner']();Et&&L('event:\x20'+_0x3cdba7['toString']()),lt(_0x32d314);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x7b03d3,_0x32d5ea,_0x4bb375,_0x4bef8a){this['repoInfo_']=_0x7b03d3,this['forceRestClient_']=_0x32d5ea,this['authTokenProvider_']=_0x4bb375,this['appCheckProvider_']=_0x4bef8a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x3e083a,_0x187e4b,_0x583811){if(_0x3e083a['stats_']=Hi(_0x3e083a['repoInfo_']),_0x3e083a['forceRestClient_']||Yl())_0x3e083a['server_']=new fn(_0x3e083a['repoInfo_'],(_0x1fb2b5,_0x26f46a,_0x43d2bf,_0x14ed9b)=>{pr(_0x3e083a,_0x1fb2b5,_0x26f46a,_0x43d2bf,_0x14ed9b);},_0x3e083a['authTokenProvider_'],_0x3e083a['appCheckProvider_']),setTimeout(()=>_r(_0x3e083a,!0x0),0x0);else{if(typeof _0x583811<'u'&&_0x583811!==null){if(typeof _0x583811!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x583811);}catch(_0x5d0487){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5d0487);}}_0x3e083a['persistentConnection_']=new ie(_0x3e083a['repoInfo_'],_0x187e4b,(_0x51795,_0x5d9da9,_0x4e4d02,_0x411c92)=>{pr(_0x3e083a,_0x51795,_0x5d9da9,_0x4e4d02,_0x411c92);},_0x3c61f3=>{_r(_0x3e083a,_0x3c61f3);},_0x2470ed=>{yd(_0x3e083a,_0x2470ed);},_0x3e083a['authTokenProvider_'],_0x3e083a['appCheckProvider_'],_0x583811),_0x3e083a['server_']=_0x3e083a['persistentConnection_'];}_0x3e083a['authTokenProvider_']['addTokenChangeListener'](_0x2918a0=>{_0x3e083a['server_']['refreshAuthToken'](_0x2918a0);}),_0x3e083a['appCheckProvider_']['addTokenChangeListener'](_0x408627=>{_0x3e083a['server_']['refreshAppCheckToken'](_0x408627['token']);}),_0x3e083a['statsReporter_']=eh(_0x3e083a['repoInfo_'],()=>new eu(_0x3e083a['stats_'],_0x3e083a['server_'])),_0x3e083a['infoData_']=new Yh(),_0x3e083a['infoSyncTree_']=new dr({'startListening':(_0x7b828,_0x58b517,_0x2e6e54,_0x52f37e)=>{let _0x36e2c9=[];const _0x464f1c=_0x3e083a['infoData_']['getNode'](_0x7b828['_path']);return _0x464f1c['isEmpty']()||(_0x36e2c9=$t(_0x3e083a['infoSyncTree_'],_0x7b828['_path'],_0x464f1c),setTimeout(()=>{_0x52f37e('ok');},0x0)),_0x36e2c9;},'stopListening':()=>{}}),ms(_0x3e083a,'connected',!0x1),_0x3e083a['serverSyncTree_']=new dr({'startListening':(_0x36a27f,_0x32bd2d,_0x5eda71,_0x151d6c)=>(_0x3e083a['server_']['listen'](_0x36a27f,_0x5eda71,_0x32bd2d,(_0x547120,_0x30e108)=>{const _0x3fcc6c=_0x151d6c(_0x547120,_0x30e108);V(_0x3e083a['eventQueue_'],_0x36a27f['_path'],_0x3fcc6c);}),[]),'stopListening':(_0x5cc018,_0x45f579)=>{_0x3e083a['server_']['unlisten'](_0x5cc018,_0x45f579);}});}function oa(_0x3c553e){const _0x4ee4c6=_0x3c553e['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4ee4c6;}function jt(_0x27adc1){return ed({'timestamp':oa(_0x27adc1)});}function pr(_0x5c7535,_0x2012da,_0x1d76ce,_0x235b4b,_0x13c69d){_0x5c7535['dataUpdateCount']++;const _0x272864=new C(_0x2012da);_0x1d76ce=_0x5c7535['interceptServerDataCallback_']?_0x5c7535['interceptServerDataCallback_'](_0x2012da,_0x1d76ce):_0x1d76ce;let _0x4e8922=[];if(_0x13c69d){if(_0x235b4b){const _0xb80bfe=ln(_0x1d76ce,_0x2f36e7=>N(_0x2f36e7));_0x4e8922=Ku(_0x5c7535['serverSyncTree_'],_0x272864,_0xb80bfe,_0x13c69d);}else{const _0x74e2b9=N(_0x1d76ce);_0x4e8922=Yo(_0x5c7535['serverSyncTree_'],_0x272864,_0x74e2b9,_0x13c69d);}}else{if(_0x235b4b){const _0x10e704=ln(_0x1d76ce,_0x495a4e=>N(_0x495a4e));_0x4e8922=qu(_0x5c7535['serverSyncTree_'],_0x272864,_0x10e704);}else{const _0x4bc0af=N(_0x1d76ce);_0x4e8922=$t(_0x5c7535['serverSyncTree_'],_0x272864,_0x4bc0af);}}let _0x20de73=_0x272864;_0x4e8922['length']>0x0&&(_0x20de73=st(_0x5c7535,_0x272864)),V(_0x5c7535['eventQueue_'],_0x20de73,_0x4e8922);}function _r(_0x35de99,_0x5a03c7){ms(_0x35de99,'connected',_0x5a03c7),_0x5a03c7===!0x1&&wd(_0x35de99);}function yd(_0x3299f2,_0x2c8280){x(_0x2c8280,(_0x8d0274,_0x530e6b)=>{ms(_0x3299f2,_0x8d0274,_0x530e6b);});}function ms(_0x3d6640,_0x5dbf30,_0x5b431c){const _0x1767cc=new C('/.info/'+_0x5dbf30),_0x1b7a1d=N(_0x5b431c);_0x3d6640['infoData_']['updateSnapshot'](_0x1767cc,_0x1b7a1d);const _0x44c4d7=$t(_0x3d6640['infoSyncTree_'],_0x1767cc,_0x1b7a1d);V(_0x3d6640['eventQueue_'],_0x1767cc,_0x44c4d7);}function Vn(_0x237001){return _0x237001['nextWriteId_']++;}function vd(_0x5e6040,_0x5bed6f,_0x2375ef){const _0x5edad1=Yu(_0x5e6040['serverSyncTree_'],_0x5bed6f);return _0x5edad1!=null?Promise['resolve'](_0x5edad1):_0x5e6040['server_']['get'](_0x5bed6f)['then'](_0x51f055=>{const _0x602960=N(_0x51f055)['withIndex'](_0x5bed6f['_queryParams']['getIndex']());bi(_0x5e6040['serverSyncTree_'],_0x5bed6f,_0x2375ef,!0x0);let _0x16cbbd;if(_0x5bed6f['_queryParams']['loadsAllData']())_0x16cbbd=$t(_0x5e6040['serverSyncTree_'],_0x5bed6f['_path'],_0x602960);else{const _0x4af1a5=Mt(_0x5e6040['serverSyncTree_'],_0x5bed6f);_0x16cbbd=Yo(_0x5e6040['serverSyncTree_'],_0x5bed6f['_path'],_0x602960,_0x4af1a5);}return V(_0x5e6040['eventQueue_'],_0x5bed6f['_path'],_0x16cbbd),wn(_0x5e6040['serverSyncTree_'],_0x5bed6f,_0x2375ef,null,!0x0),_0x602960;},_0x40e8c2=>(ut(_0x5e6040,'get\x20for\x20query\x20'+O(_0x5bed6f)+'\x20failed:\x20'+_0x40e8c2),Promise['reject'](new Error(_0x40e8c2))));}function Ed(_0x4c0284,_0x8adbd2,_0x1f7e69,_0x313ccc,_0x304b53){ut(_0x4c0284,'set',{'path':_0x8adbd2['toString'](),'value':_0x1f7e69,'priority':_0x313ccc});const _0x40d627=jt(_0x4c0284),_0x32270e=N(_0x1f7e69,_0x313ccc),_0x461f00=xn(_0x4c0284['serverSyncTree_'],_0x8adbd2),_0x2b5074=hs(_0x32270e,_0x461f00,_0x40d627),_0x1270fd=Vn(_0x4c0284),_0x55e1cf=ss(_0x4c0284['serverSyncTree_'],_0x8adbd2,_0x2b5074,_0x1270fd,!0x0);Bn(_0x4c0284['eventQueue_'],_0x55e1cf),_0x4c0284['server_']['put'](_0x8adbd2['toString'](),_0x32270e['val'](!0x0),(_0x47a1dd,_0xe0d3cb)=>{const _0xb22fa5=_0x47a1dd==='ok';_0xb22fa5||U('set\x20at\x20'+_0x8adbd2+'\x20failed:\x20'+_0x47a1dd);const _0x58b2db=pe(_0x4c0284['serverSyncTree_'],_0x1270fd,!_0xb22fa5);V(_0x4c0284['eventQueue_'],_0x8adbd2,_0x58b2db),Ai(_0x4c0284,_0x304b53,_0x47a1dd,_0xe0d3cb);});const _0x1a3378=vs(_0x4c0284,_0x8adbd2);st(_0x4c0284,_0x1a3378),V(_0x4c0284['eventQueue_'],_0x1a3378,[]);}function Id(_0x2c3b8e,_0x46132a,_0x6f1319,_0x2a0267){ut(_0x2c3b8e,'update',{'path':_0x46132a['toString'](),'value':_0x6f1319});let _0x35c138=!0x0;const _0x490dd3=jt(_0x2c3b8e),_0x2fc92d={};if(x(_0x6f1319,(_0x55f0de,_0x226525)=>{_0x35c138=!0x1,_0x2fc92d[_0x55f0de]=Zo(A(_0x46132a,_0x55f0de),N(_0x226525),_0x2c3b8e['serverSyncTree_'],_0x490dd3);}),_0x35c138)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x2c3b8e,_0x2a0267,'ok',void 0x0);else{const _0x31efb9=Vn(_0x2c3b8e),_0x3d02dd=Gu(_0x2c3b8e['serverSyncTree_'],_0x46132a,_0x2fc92d,_0x31efb9);Bn(_0x2c3b8e['eventQueue_'],_0x3d02dd),_0x2c3b8e['server_']['merge'](_0x46132a['toString'](),_0x6f1319,(_0x2b2590,_0x409cc4)=>{const _0x2ca352=_0x2b2590==='ok';_0x2ca352||U('update\x20at\x20'+_0x46132a+'\x20failed:\x20'+_0x2b2590);const _0x1acc88=pe(_0x2c3b8e['serverSyncTree_'],_0x31efb9,!_0x2ca352),_0x39c517=_0x1acc88['length']>0x0?st(_0x2c3b8e,_0x46132a):_0x46132a;V(_0x2c3b8e['eventQueue_'],_0x39c517,_0x1acc88),Ai(_0x2c3b8e,_0x2a0267,_0x2b2590,_0x409cc4);}),x(_0x6f1319,_0x2e400c=>{const _0x54589b=vs(_0x2c3b8e,A(_0x46132a,_0x2e400c));st(_0x2c3b8e,_0x54589b);}),V(_0x2c3b8e['eventQueue_'],_0x46132a,[]);}}function wd(_0x27a149){ut(_0x27a149,'onDisconnectEvents');const _0x1b858e=jt(_0x27a149),_0x34f444=pn();Ei(_0x27a149['onDisconnect_'],w(),(_0x4cd08a,_0x3983ff)=>{const _0x2dec38=Zo(_0x4cd08a,_0x3983ff,_0x27a149['serverSyncTree_'],_0x1b858e);Mo(_0x34f444,_0x4cd08a,_0x2dec38);});let _0x3c02cc=[];Ei(_0x34f444,w(),(_0x1eb82c,_0xd12ba5)=>{_0x3c02cc=_0x3c02cc['concat']($t(_0x27a149['serverSyncTree_'],_0x1eb82c,_0xd12ba5));const _0x178853=vs(_0x27a149,_0x1eb82c);st(_0x27a149,_0x178853);}),_0x27a149['onDisconnect_']=pn(),V(_0x27a149['eventQueue_'],w(),_0x3c02cc);}function Cd(_0x13e66b,_0x166f7e,_0x2a17a0){let _0x4f5569;y(_0x166f7e['_path'])==='.info'?_0x4f5569=bi(_0x13e66b['infoSyncTree_'],_0x166f7e,_0x2a17a0):_0x4f5569=bi(_0x13e66b['serverSyncTree_'],_0x166f7e,_0x2a17a0),ia(_0x13e66b['eventQueue_'],_0x166f7e['_path'],_0x4f5569);}function Td(_0x32e4ff,_0xf30a43,_0x748ab){let _0x16ae2a;y(_0xf30a43['_path'])==='.info'?_0x16ae2a=wn(_0x32e4ff['infoSyncTree_'],_0xf30a43,_0x748ab):_0x16ae2a=wn(_0x32e4ff['serverSyncTree_'],_0xf30a43,_0x748ab),ia(_0x32e4ff['eventQueue_'],_0xf30a43['_path'],_0x16ae2a);}function aa(_0x325ed7){_0x325ed7['persistentConnection_']&&_0x325ed7['persistentConnection_']['interrupt'](ra);}function Sd(_0xbfd049){_0xbfd049['persistentConnection_']&&_0xbfd049['persistentConnection_']['resume'](ra);}function ut(_0x710834,..._0x48be6f){let _0x5b5d02='';_0x710834['persistentConnection_']&&(_0x5b5d02=_0x710834['persistentConnection_']['id']+':'),L(_0x5b5d02,..._0x48be6f);}function Ai(_0x1a7624,_0x3de583,_0x17e921,_0x28c05c){_0x3de583&&lt(()=>{if(_0x17e921==='ok')_0x3de583(null);else{const _0x59516c=(_0x17e921||'error')['toUpperCase']();let _0x3cc182=_0x59516c;_0x28c05c&&(_0x3cc182+=':\x20'+_0x28c05c);const _0x2e9f7a=new Error(_0x3cc182);_0x2e9f7a['code']=_0x59516c,_0x3de583(_0x2e9f7a);}});}function bd(_0x111a5f,_0x1ce0b0,_0x318104,_0x524676,_0x479d72,_0x446305){ut(_0x111a5f,'transaction\x20on\x20'+_0x1ce0b0);const _0x3b425c={'path':_0x1ce0b0,'update':_0x318104,'onComplete':_0x524676,'status':null,'order':to(),'applyLocally':_0x446305,'retryCount':0x0,'unwatcher':_0x479d72,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x46fb63=ys(_0x111a5f,_0x1ce0b0,void 0x0);_0x3b425c['currentInputSnapshot']=_0x46fb63;const _0x3b53da=_0x3b425c['update'](_0x46fb63['val']());if(_0x3b53da===void 0x0)_0x3b425c['unwatcher'](),_0x3b425c['currentOutputSnapshotRaw']=null,_0x3b425c['currentOutputSnapshotResolved']=null,_0x3b425c['onComplete']&&_0x3b425c['onComplete'](null,!0x1,_0x3b425c['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3b53da,_0x3b425c['path']),_0x3b425c['status']=0x0;const _0x2e8836=Un(_0x111a5f['transactionQueueTree_'],_0x1ce0b0),_0x4f75b2=Ge(_0x2e8836)||[];_0x4f75b2['push'](_0x3b425c),fs(_0x2e8836,_0x4f75b2);let _0x3e5901;typeof _0x3b53da=='object'&&_0x3b53da!==null&&Y(_0x3b53da,'.priority')?(_0x3e5901=Oe(_0x3b53da,'.priority'),f(Cn(_0x3e5901),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3e5901=(xn(_0x111a5f['serverSyncTree_'],_0x1ce0b0)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x36574e=jt(_0x111a5f),_0x20e283=N(_0x3b53da,_0x3e5901),_0x5ea9ac=hs(_0x20e283,_0x46fb63,_0x36574e);_0x3b425c['currentOutputSnapshotRaw']=_0x20e283,_0x3b425c['currentOutputSnapshotResolved']=_0x5ea9ac,_0x3b425c['currentWriteId']=Vn(_0x111a5f);const _0x1f6c19=ss(_0x111a5f['serverSyncTree_'],_0x1ce0b0,_0x5ea9ac,_0x3b425c['currentWriteId'],_0x3b425c['applyLocally']);V(_0x111a5f['eventQueue_'],_0x1ce0b0,_0x1f6c19),Hn(_0x111a5f,_0x111a5f['transactionQueueTree_']);}}function ys(_0x4b4e6f,_0x52c4f5,_0x1cc7c3){return xn(_0x4b4e6f['serverSyncTree_'],_0x52c4f5,_0x1cc7c3)||g['EMPTY_NODE'];}function Hn(_0x1946aa,_0x35c438=_0x1946aa['transactionQueueTree_']){if(_0x35c438||$n(_0x1946aa,_0x35c438),Ge(_0x35c438)){const _0xbd3327=la(_0x1946aa,_0x35c438);f(_0xbd3327['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xbd3327['every'](_0x67f161=>_0x67f161['status']===0x0)&&Rd(_0x1946aa,Gt(_0x35c438),_0xbd3327);}else ea(_0x35c438)&&Wn(_0x35c438,_0x5a3712=>{Hn(_0x1946aa,_0x5a3712);});}function Rd(_0xe0a2e1,_0x52387e,_0x2cbd0b){const _0x3f204a=_0x2cbd0b['map'](_0x291978=>_0x291978['currentWriteId']),_0x2f407d=ys(_0xe0a2e1,_0x52387e,_0x3f204a);let _0x930063=_0x2f407d;const _0x587b88=_0x2f407d['hash']();for(let _0x703f6c=0x0;_0x703f6c<_0x2cbd0b['length'];_0x703f6c++){const _0x10ccab=_0x2cbd0b[_0x703f6c];f(_0x10ccab['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x10ccab['status']=0x1,_0x10ccab['retryCount']++;const _0x1551e9=F(_0x52387e,_0x10ccab['path']);_0x930063=_0x930063['updateChild'](_0x1551e9,_0x10ccab['currentOutputSnapshotRaw']);}const _0x4502ee=_0x930063['val'](!0x0),_0xdfad54=_0x52387e;_0xe0a2e1['server_']['put'](_0xdfad54['toString'](),_0x4502ee,_0x24af5c=>{ut(_0xe0a2e1,'transaction\x20put\x20response',{'path':_0xdfad54['toString'](),'status':_0x24af5c});let _0x579afc=[];if(_0x24af5c==='ok'){const _0x263f39=[];for(let _0x5c8281=0x0;_0x5c8281<_0x2cbd0b['length'];_0x5c8281++)_0x2cbd0b[_0x5c8281]['status']=0x2,_0x579afc=_0x579afc['concat'](pe(_0xe0a2e1['serverSyncTree_'],_0x2cbd0b[_0x5c8281]['currentWriteId'])),_0x2cbd0b[_0x5c8281]['onComplete']&&_0x263f39['push'](()=>_0x2cbd0b[_0x5c8281]['onComplete'](null,!0x0,_0x2cbd0b[_0x5c8281]['currentOutputSnapshotResolved'])),_0x2cbd0b[_0x5c8281]['unwatcher']();$n(_0xe0a2e1,Un(_0xe0a2e1['transactionQueueTree_'],_0x52387e)),Hn(_0xe0a2e1,_0xe0a2e1['transactionQueueTree_']),V(_0xe0a2e1['eventQueue_'],_0x52387e,_0x579afc);for(let _0xcd11ab=0x0;_0xcd11ab<_0x263f39['length'];_0xcd11ab++)lt(_0x263f39[_0xcd11ab]);}else{if(_0x24af5c==='datastale'){for(let _0x3611c3=0x0;_0x3611c3<_0x2cbd0b['length'];_0x3611c3++)_0x2cbd0b[_0x3611c3]['status']===0x3?_0x2cbd0b[_0x3611c3]['status']=0x4:_0x2cbd0b[_0x3611c3]['status']=0x0;}else{U('transaction\x20at\x20'+_0xdfad54['toString']()+'\x20failed:\x20'+_0x24af5c);for(let _0x39dfeb=0x0;_0x39dfeb<_0x2cbd0b['length'];_0x39dfeb++)_0x2cbd0b[_0x39dfeb]['status']=0x4,_0x2cbd0b[_0x39dfeb]['abortReason']=_0x24af5c;}st(_0xe0a2e1,_0x52387e);}},_0x587b88);}function st(_0x29f88d,_0x5cd0b3){const _0x5c89ad=ca(_0x29f88d,_0x5cd0b3),_0x1c937d=Gt(_0x5c89ad),_0x22151a=la(_0x29f88d,_0x5c89ad);return Ad(_0x29f88d,_0x22151a,_0x1c937d),_0x1c937d;}function Ad(_0x381858,_0x168a84,_0x14028a){if(_0x168a84['length']===0x0)return;const _0x53855e=[];let _0x435c8f=[];const _0x1b2196=_0x168a84['filter'](_0x324431=>_0x324431['status']===0x0)['map'](_0x305daf=>_0x305daf['currentWriteId']);for(let _0x39f942=0x0;_0x39f942<_0x168a84['length'];_0x39f942++){const _0x24f87f=_0x168a84[_0x39f942],_0x392eb3=F(_0x14028a,_0x24f87f['path']);let _0x336561=!0x1,_0x288597;if(f(_0x392eb3!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x24f87f['status']===0x4)_0x336561=!0x0,_0x288597=_0x24f87f['abortReason'],_0x435c8f=_0x435c8f['concat'](pe(_0x381858['serverSyncTree_'],_0x24f87f['currentWriteId'],!0x0));else{if(_0x24f87f['status']===0x0){if(_0x24f87f['retryCount']>=_d)_0x336561=!0x0,_0x288597='maxretry',_0x435c8f=_0x435c8f['concat'](pe(_0x381858['serverSyncTree_'],_0x24f87f['currentWriteId'],!0x0));else{const _0x7823d5=ys(_0x381858,_0x24f87f['path'],_0x1b2196);_0x24f87f['currentInputSnapshot']=_0x7823d5;const _0x58a2e6=_0x168a84[_0x39f942]['update'](_0x7823d5['val']());if(_0x58a2e6!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x58a2e6,_0x24f87f['path']);let _0x3a02bb=N(_0x58a2e6);typeof _0x58a2e6=='object'&&_0x58a2e6!=null&&Y(_0x58a2e6,'.priority')||(_0x3a02bb=_0x3a02bb['updatePriority'](_0x7823d5['getPriority']()));const _0xddcdaa=_0x24f87f['currentWriteId'],_0x4933c0=jt(_0x381858),_0x327d34=hs(_0x3a02bb,_0x7823d5,_0x4933c0);_0x24f87f['currentOutputSnapshotRaw']=_0x3a02bb,_0x24f87f['currentOutputSnapshotResolved']=_0x327d34,_0x24f87f['currentWriteId']=Vn(_0x381858),_0x1b2196['splice'](_0x1b2196['indexOf'](_0xddcdaa),0x1),_0x435c8f=_0x435c8f['concat'](ss(_0x381858['serverSyncTree_'],_0x24f87f['path'],_0x327d34,_0x24f87f['currentWriteId'],_0x24f87f['applyLocally'])),_0x435c8f=_0x435c8f['concat'](pe(_0x381858['serverSyncTree_'],_0xddcdaa,!0x0));}else _0x336561=!0x0,_0x288597='nodata',_0x435c8f=_0x435c8f['concat'](pe(_0x381858['serverSyncTree_'],_0x24f87f['currentWriteId'],!0x0));}}}V(_0x381858['eventQueue_'],_0x14028a,_0x435c8f),_0x435c8f=[],_0x336561&&(_0x168a84[_0x39f942]['status']=0x2,function(_0xce62f5){setTimeout(_0xce62f5,Math['floor'](0x0));}(_0x168a84[_0x39f942]['unwatcher']),_0x168a84[_0x39f942]['onComplete']&&(_0x288597==='nodata'?_0x53855e['push'](()=>_0x168a84[_0x39f942]['onComplete'](null,!0x1,_0x168a84[_0x39f942]['currentInputSnapshot'])):_0x53855e['push'](()=>_0x168a84[_0x39f942]['onComplete'](new Error(_0x288597),!0x1,null))));}$n(_0x381858,_0x381858['transactionQueueTree_']);for(let _0x31a45b=0x0;_0x31a45b<_0x53855e['length'];_0x31a45b++)lt(_0x53855e[_0x31a45b]);Hn(_0x381858,_0x381858['transactionQueueTree_']);}function ca(_0x3d19e5,_0x4554bb){let _0x167c06,_0x470fef=_0x3d19e5['transactionQueueTree_'];for(_0x167c06=y(_0x4554bb);_0x167c06!==null&&Ge(_0x470fef)===void 0x0;)_0x470fef=Un(_0x470fef,_0x167c06),_0x4554bb=b(_0x4554bb),_0x167c06=y(_0x4554bb);return _0x470fef;}function la(_0x4efe6e,_0x3dfe9f){const _0x516d08=[];return ha(_0x4efe6e,_0x3dfe9f,_0x516d08),_0x516d08['sort']((_0x30fd6b,_0xa5e407)=>_0x30fd6b['order']-_0xa5e407['order']),_0x516d08;}function ha(_0x3d1f71,_0x3b5296,_0x2f7285){const _0x35a081=Ge(_0x3b5296);if(_0x35a081){for(let _0x5971f3=0x0;_0x5971f3<_0x35a081['length'];_0x5971f3++)_0x2f7285['push'](_0x35a081[_0x5971f3]);}Wn(_0x3b5296,_0x364388=>{ha(_0x3d1f71,_0x364388,_0x2f7285);});}function $n(_0x2bc57d,_0x5424a8){const _0xbdcff4=Ge(_0x5424a8);if(_0xbdcff4){let _0x2f0cc6=0x0;for(let _0x1391ee=0x0;_0x1391ee<_0xbdcff4['length'];_0x1391ee++)_0xbdcff4[_0x1391ee]['status']!==0x2&&(_0xbdcff4[_0x2f0cc6]=_0xbdcff4[_0x1391ee],_0x2f0cc6++);_0xbdcff4['length']=_0x2f0cc6,fs(_0x5424a8,_0xbdcff4['length']>0x0?_0xbdcff4:void 0x0);}Wn(_0x5424a8,_0x1f8c40=>{$n(_0x2bc57d,_0x1f8c40);});}function vs(_0x5ab457,_0x53dd80){const _0x521bff=Gt(ca(_0x5ab457,_0x53dd80)),_0x2f96d5=Un(_0x5ab457['transactionQueueTree_'],_0x53dd80);return sd(_0x2f96d5,_0x1eb041=>{ai(_0x5ab457,_0x1eb041);}),ai(_0x5ab457,_0x2f96d5),ta(_0x2f96d5,_0x4e0010=>{ai(_0x5ab457,_0x4e0010);}),_0x521bff;}function ai(_0x28160b,_0x5c5d43){const _0x171088=Ge(_0x5c5d43);if(_0x171088){const _0x316464=[];let _0x26b22b=[],_0x406ec7=-0x1;for(let _0x42660a=0x0;_0x42660a<_0x171088['length'];_0x42660a++)_0x171088[_0x42660a]['status']===0x3||(_0x171088[_0x42660a]['status']===0x1?(f(_0x406ec7===_0x42660a-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x406ec7=_0x42660a,_0x171088[_0x42660a]['status']=0x3,_0x171088[_0x42660a]['abortReason']='set'):(f(_0x171088[_0x42660a]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x171088[_0x42660a]['unwatcher'](),_0x26b22b=_0x26b22b['concat'](pe(_0x28160b['serverSyncTree_'],_0x171088[_0x42660a]['currentWriteId'],!0x0)),_0x171088[_0x42660a]['onComplete']&&_0x316464['push'](_0x171088[_0x42660a]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x406ec7===-0x1?fs(_0x5c5d43,void 0x0):_0x171088['length']=_0x406ec7+0x1,V(_0x28160b['eventQueue_'],Gt(_0x5c5d43),_0x26b22b);for(let _0x158d6e=0x0;_0x158d6e<_0x316464['length'];_0x158d6e++)lt(_0x316464[_0x158d6e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0xf9a98){let _0x5084fe='';const _0x2ad244=_0xf9a98['split']('/');for(let _0x39ec57=0x0;_0x39ec57<_0x2ad244['length'];_0x39ec57++)if(_0x2ad244[_0x39ec57]['length']>0x0){let _0x4970e1=_0x2ad244[_0x39ec57];try{_0x4970e1=decodeURIComponent(_0x4970e1['replace'](/\+/g,'\x20'));}catch{}_0x5084fe+='/'+_0x4970e1;}return _0x5084fe;}function Nd(_0x581f47){const _0x39bbed={};_0x581f47['charAt'](0x0)==='?'&&(_0x581f47=_0x581f47['substring'](0x1));for(const _0x52b2d8 of _0x581f47['split']('&')){if(_0x52b2d8['length']===0x0)continue;const _0x556818=_0x52b2d8['split']('=');_0x556818['length']===0x2?_0x39bbed[decodeURIComponent(_0x556818[0x0])]=decodeURIComponent(_0x556818[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x52b2d8+'\x27\x20in\x20query\x20\x27'+_0x581f47+'\x27');}return _0x39bbed;}const gr=function(_0xb29424,_0x1509c7){const _0x5ce5f1=Pd(_0xb29424),_0x15f979=_0x5ce5f1['namespace'];_0x5ce5f1['domain']==='firebase.com'&&oe(_0x5ce5f1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x15f979||_0x15f979==='undefined')&&_0x5ce5f1['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5ce5f1['secure']||Bl();const _0x26db8d=_0x5ce5f1['scheme']==='ws'||_0x5ce5f1['scheme']==='wss';return{'repoInfo':new _o(_0x5ce5f1['host'],_0x5ce5f1['secure'],_0x15f979,_0x26db8d,_0x1509c7,'',_0x15f979!==_0x5ce5f1['subdomain']),'path':new C(_0x5ce5f1['pathString'])};},Pd=function(_0x5611f5){let _0x32a2dc='',_0x2622d7='',_0x2b7600='',_0x4a932d='',_0x2b5fff='',_0x43ebcd=!0x0,_0x352db0='https',_0x106103=0x1bb;if(typeof _0x5611f5=='string'){let _0x555213=_0x5611f5['indexOf']('//');_0x555213>=0x0&&(_0x352db0=_0x5611f5['substring'](0x0,_0x555213-0x1),_0x5611f5=_0x5611f5['substring'](_0x555213+0x2));let _0x5a7839=_0x5611f5['indexOf']('/');_0x5a7839===-0x1&&(_0x5a7839=_0x5611f5['length']);let _0x1d2f9f=_0x5611f5['indexOf']('?');_0x1d2f9f===-0x1&&(_0x1d2f9f=_0x5611f5['length']),_0x32a2dc=_0x5611f5['substring'](0x0,Math['min'](_0x5a7839,_0x1d2f9f)),_0x5a7839<_0x1d2f9f&&(_0x4a932d=kd(_0x5611f5['substring'](_0x5a7839,_0x1d2f9f)));const _0x54007f=Nd(_0x5611f5['substring'](Math['min'](_0x5611f5['length'],_0x1d2f9f)));_0x555213=_0x32a2dc['indexOf'](':'),_0x555213>=0x0?(_0x43ebcd=_0x352db0==='https'||_0x352db0==='wss',_0x106103=parseInt(_0x32a2dc['substring'](_0x555213+0x1),0xa)):_0x555213=_0x32a2dc['length'];const _0x562a9f=_0x32a2dc['slice'](0x0,_0x555213);if(_0x562a9f['toLowerCase']()==='localhost')_0x2622d7='localhost';else{if(_0x562a9f['split']('.')['length']<=0x2)_0x2622d7=_0x562a9f;else{const _0x1a5202=_0x32a2dc['indexOf']('.');_0x2b7600=_0x32a2dc['substring'](0x0,_0x1a5202)['toLowerCase'](),_0x2622d7=_0x32a2dc['substring'](_0x1a5202+0x1),_0x2b5fff=_0x2b7600;}}'ns'in _0x54007f&&(_0x2b5fff=_0x54007f['ns']);}return{'host':_0x32a2dc,'port':_0x106103,'domain':_0x2622d7,'subdomain':_0x2b7600,'secure':_0x43ebcd,'scheme':_0x352db0,'pathString':_0x4a932d,'namespace':_0x2b5fff};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x57310e=0x0;const _0x118818=[];return function(_0x2df9ef){const _0x60c643=_0x2df9ef===_0x57310e;_0x57310e=_0x2df9ef;let _0x361573;const _0x1f4587=new Array(0x8);for(_0x361573=0x7;_0x361573>=0x0;_0x361573--)_0x1f4587[_0x361573]=mr['charAt'](_0x2df9ef%0x40),_0x2df9ef=Math['floor'](_0x2df9ef/0x40);f(_0x2df9ef===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x55c722=_0x1f4587['join']('');if(_0x60c643){for(_0x361573=0xb;_0x361573>=0x0&&_0x118818[_0x361573]===0x3f;_0x361573--)_0x118818[_0x361573]=0x0;_0x118818[_0x361573]++;}else{for(_0x361573=0x0;_0x361573<0xc;_0x361573++)_0x118818[_0x361573]=Math['floor'](Math['random']()*0x40);}for(_0x361573=0x0;_0x361573<0xc;_0x361573++)_0x55c722+=mr['charAt'](_0x118818[_0x361573]);return f(_0x55c722['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x55c722;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x1f5389,_0x44086d,_0x1ec570,_0x1ae02b){this['eventType']=_0x1f5389,this['eventRegistration']=_0x44086d,this['snapshot']=_0x1ec570,this['prevName']=_0x1ae02b;}['getPath'](){const _0x594b3b=this['snapshot']['ref'];return this['eventType']==='value'?_0x594b3b['_path']:_0x594b3b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x1043e0,_0x2f659a,_0xbe3894){this['eventRegistration']=_0x1043e0,this['error']=_0x2f659a,this['path']=_0xbe3894;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x4cea17,_0xb9635e){this['snapshotCallback']=_0x4cea17,this['cancelCallback']=_0xb9635e;}['onValue'](_0x1ae0ab,_0x263fd6){this['snapshotCallback']['call'](null,_0x1ae0ab,_0x263fd6);}['onCancel'](_0x2fa882){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2fa882);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x11b027){return this['snapshotCallback']===_0x11b027['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x11b027['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x11b027['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x5cd335,_0x547f17,_0x4ff177,_0x110e68){this['_repo']=_0x5cd335,this['_path']=_0x547f17,this['_queryParams']=_0x4ff177,this['_orderByCalled']=_0x110e68;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x637c73=nr(this['_queryParams']),_0x3022a6=Bi(_0x637c73);return _0x3022a6==='{}'?'default':_0x3022a6;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x1db961){if(_0x1db961=k(_0x1db961),!(_0x1db961 instanceof be))return!0x1;const _0x494b5b=this['_repo']===_0x1db961['_repo'],_0x3bf070=qi(this['_path'],_0x1db961['_path']),_0x341068=this['_queryIdentifier']===_0x1db961['_queryIdentifier'];return _0x494b5b&&_0x3bf070&&_0x341068;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x3348ba,_0x43d4bc){if(_0x3348ba['_orderByCalled']===!0x0)throw new Error(_0x43d4bc+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3b6f47){let _0x457bc5=null,_0x51dd50=null;if(_0x3b6f47['hasStart']()&&(_0x457bc5=_0x3b6f47['getIndexStartValue']()),_0x3b6f47['hasEnd']()&&(_0x51dd50=_0x3b6f47['getIndexEndValue']()),_0x3b6f47['getIndex']()===ye){const _0x3379e6='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x20e647='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3b6f47['hasStart']()){if(_0x3b6f47['getIndexStartName']()!==xe)throw new Error(_0x3379e6);if(typeof _0x457bc5!='string')throw new Error(_0x20e647);}if(_0x3b6f47['hasEnd']()){if(_0x3b6f47['getIndexEndName']()!==Ie)throw new Error(_0x3379e6);if(typeof _0x51dd50!='string')throw new Error(_0x20e647);}}else{if(_0x3b6f47['getIndex']()===R){if(_0x457bc5!=null&&!Cn(_0x457bc5)||_0x51dd50!=null&&!Cn(_0x51dd50))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3b6f47['getIndex']()instanceof Ki||_0x3b6f47['getIndex']()===Po,'unknown\x20index\x20type.'),_0x457bc5!=null&&typeof _0x457bc5=='object'||_0x51dd50!=null&&typeof _0x51dd50=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x14b6d1){if(_0x14b6d1['hasStart']()&&_0x14b6d1['hasEnd']()&&_0x14b6d1['hasLimit']()&&!_0x14b6d1['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2c14b7,_0x5aa6d4){super(_0x2c14b7,_0x5aa6d4,new Qi(),!0x1);}get['parent'](){const _0x23fec3=To(this['_path']);return _0x23fec3===null?null:new Z(this['_repo'],_0x23fec3);}get['root'](){let _0x98a85f=this;for(;_0x98a85f['parent']!==null;)_0x98a85f=_0x98a85f['parent'];return _0x98a85f;}}class rt{constructor(_0x33974d,_0x1d0680,_0x31782a){this['_node']=_0x33974d,this['ref']=_0x1d0680,this['_index']=_0x31782a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5f1f1f){const _0x129c15=new C(_0x5f1f1f),_0x2b5951=Lt(this['ref'],_0x5f1f1f);return new rt(this['_node']['getChild'](_0x129c15),_0x2b5951,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x29cc0e){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xdd2d93,_0x178114)=>_0x29cc0e(new rt(_0x178114,Lt(this['ref'],_0xdd2d93),R)));}['hasChild'](_0x2396ad){const _0x1cc9a2=new C(_0x2396ad);return!this['_node']['getChild'](_0x1cc9a2)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0xb8189,_0x5f9ad){return _0xb8189=k(_0xb8189),_0xb8189['_checkNotDeleted']('ref'),_0x5f9ad!==void 0x0?Lt(_0xb8189['_root'],_0x5f9ad):_0xb8189['_root'];}function Lt(_0x1ba1b4,_0x3f4147){return _0x1ba1b4=k(_0x1ba1b4),y(_0x1ba1b4['_path'])===null?ud('child','path',_0x3f4147):_s('child','path',_0x3f4147),new Z(_0x1ba1b4['_repo'],A(_0x1ba1b4['_path'],_0x3f4147));}function d_(_0x27722f,_0x573d0e){_0x27722f=k(_0x27722f),gs('push',_0x27722f['_path']),qt('push',_0x573d0e,_0x27722f['_path'],!0x0);const _0x2c1cdf=oa(_0x27722f['_repo']),_0x3d23cd=Od(_0x2c1cdf),_0x1045ad=Lt(_0x27722f,_0x3d23cd),_0x379681=Lt(_0x27722f,_0x3d23cd);let _0x3d4337;return _0x573d0e!=null?_0x3d4337=Ld(_0x379681,_0x573d0e)['then'](()=>_0x379681):_0x3d4337=Promise['resolve'](_0x379681),_0x1045ad['then']=_0x3d4337['then']['bind'](_0x3d4337),_0x1045ad['catch']=_0x3d4337['then']['bind'](_0x3d4337,void 0x0),_0x1045ad;}function Ld(_0x1bde19,_0x436bbd){_0x1bde19=k(_0x1bde19),gs('set',_0x1bde19['_path']),qt('set',_0x436bbd,_0x1bde19['_path'],!0x1);const _0x28b692=new Ve();return Ed(_0x1bde19['_repo'],_0x1bde19['_path'],_0x436bbd,null,_0x28b692['wrapCallback'](()=>{})),_0x28b692['promise'];}function f_(_0x7f364b,_0xb96565){hd('update',_0xb96565,_0x7f364b['_path']);const _0x5c887f=new Ve();return Id(_0x7f364b['_repo'],_0x7f364b['_path'],_0xb96565,_0x5c887f['wrapCallback'](()=>{})),_0x5c887f['promise'];}function p_(_0x503a3b){_0x503a3b=k(_0x503a3b);const _0xf9f899=new ua(()=>{}),_0x5094d2=new qn(_0xf9f899);return vd(_0x503a3b['_repo'],_0x503a3b,_0x5094d2)['then'](_0x3d55f7=>new rt(_0x3d55f7,new Z(_0x503a3b['_repo'],_0x503a3b['_path']),_0x503a3b['_queryParams']['getIndex']()));}class qn{constructor(_0x5b5d6f){this['callbackContext']=_0x5b5d6f;}['respondsTo'](_0x83343d){return _0x83343d==='value';}['createEvent'](_0x4de540,_0x2b2fdd){const _0xfc253b=_0x2b2fdd['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x4de540['snapshotNode'],new Z(_0x2b2fdd['_repo'],_0x2b2fdd['_path']),_0xfc253b));}['getEventRunner'](_0x1b0252){return _0x1b0252['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1b0252['error']):()=>this['callbackContext']['onValue'](_0x1b0252['snapshot'],null);}['createCancelEvent'](_0x1350c3,_0xd7ba58){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x1350c3,_0xd7ba58):null;}['matches'](_0x49e567){return _0x49e567 instanceof qn?!_0x49e567['callbackContext']||!this['callbackContext']?!0x0:_0x49e567['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3a323a,_0x5b66ce,_0x2dcc91,_0x284d3d,_0x35cd9b){const _0x3ce57f=new ua(_0x2dcc91,void 0x0),_0x5b46df=new qn(_0x3ce57f);return Cd(_0x3a323a['_repo'],_0x3a323a,_0x5b46df),()=>Td(_0x3a323a['_repo'],_0x3a323a,_0x5b46df);}function Fd(_0x292041,_0x2297ec,_0x2602cf,_0x4cfd90){return xd(_0x292041,'value',_0x2297ec);}class dt{}class pa extends dt{constructor(_0x5af514,_0x1a7374){super(),this['_value']=_0x5af514,this['_key']=_0x1a7374,this['type']='endAt';}['_apply'](_0x33d474){qt('endAt',this['_value'],_0x33d474['_path'],!0x0);const _0x2a15ea=Kh(_0x33d474['_queryParams'],this['_value'],this['_key']);if(fa(_0x2a15ea),Gn(_0x2a15ea),_0x33d474['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x33d474['_repo'],_0x33d474['_path'],_0x2a15ea,_0x33d474['_orderByCalled']);}}function __(_0x243ad1,_0x590fbf){return new pa(_0x243ad1,_0x590fbf);}class _a extends dt{constructor(_0x340d35,_0x498219){super(),this['_value']=_0x340d35,this['_key']=_0x498219,this['type']='startAt';}['_apply'](_0xd9076b){qt('startAt',this['_value'],_0xd9076b['_path'],!0x0);const _0x23df0e=jh(_0xd9076b['_queryParams'],this['_value'],this['_key']);if(fa(_0x23df0e),Gn(_0x23df0e),_0xd9076b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0xd9076b['_repo'],_0xd9076b['_path'],_0x23df0e,_0xd9076b['_orderByCalled']);}}function g_(_0x393b25=null,_0x567ba6){return new _a(_0x393b25,_0x567ba6);}class Ud extends dt{constructor(_0xe4b7d4){super(),this['_limit']=_0xe4b7d4,this['type']='limitToFirst';}['_apply'](_0x6abbbf){if(_0x6abbbf['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x6abbbf['_repo'],_0x6abbbf['_path'],zh(_0x6abbbf['_queryParams'],this['_limit']),_0x6abbbf['_orderByCalled']);}}function m_(_0x2e235f){if(Math['floor'](_0x2e235f)!==_0x2e235f||_0x2e235f<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x2e235f);}class Wd extends dt{constructor(_0x5f0bb4){super(),this['_path']=_0x5f0bb4,this['type']='orderByChild';}['_apply'](_0x2814aa){da(_0x2814aa,'orderByChild');const _0x2f21e4=new C(this['_path']);if(v(_0x2f21e4))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3ef25a=new Ki(_0x2f21e4),_0x4ce4de=Do(_0x2814aa['_queryParams'],_0x3ef25a);return Gn(_0x4ce4de),new be(_0x2814aa['_repo'],_0x2814aa['_path'],_0x4ce4de,!0x0);}}function y_(_0x42d09e){if(_0x42d09e==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x42d09e==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x42d09e==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x42d09e),new Wd(_0x42d09e);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4ea538){da(_0x4ea538,'orderByKey');const _0x1f3220=Do(_0x4ea538['_queryParams'],ye);return Gn(_0x1f3220),new be(_0x4ea538['_repo'],_0x4ea538['_path'],_0x1f3220,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x485889,_0x1b92c2){super(),this['_value']=_0x485889,this['_key']=_0x1b92c2,this['type']='equalTo';}['_apply'](_0x492cbb){if(qt('equalTo',this['_value'],_0x492cbb['_path'],!0x1),_0x492cbb['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x492cbb['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x492cbb));}}function E_(_0xbb9d55,_0x4c5b60){return new Vd(_0xbb9d55,_0x4c5b60);}function I_(_0x219112,..._0x501c65){let _0x45a2b5=k(_0x219112);for(const _0x5e4f79 of _0x501c65)_0x45a2b5=_0x5e4f79['_apply'](_0x45a2b5);return _0x45a2b5;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x5ecb1e,_0x8bf82c,_0x18617f,_0x8edb5){const _0x4ee210=_0x8bf82c['lastIndexOf'](':'),_0x1fe1b8=_0x8bf82c['substring'](0x0,_0x4ee210),_0x5210ce=Wt(_0x1fe1b8);_0x5ecb1e['repoInfo_']=new _o(_0x8bf82c,_0x5210ce,_0x5ecb1e['repoInfo_']['namespace'],_0x5ecb1e['repoInfo_']['webSocketOnly'],_0x5ecb1e['repoInfo_']['nodeAdmin'],_0x5ecb1e['repoInfo_']['persistenceKey'],_0x5ecb1e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x18617f),_0x8edb5&&(_0x5ecb1e['authTokenProvider_']=_0x8edb5);}function qd(_0x584485,_0x2ba3f2,_0x4dcef5,_0x4d1cc4,_0x33c93f){let _0x41cfa9=_0x4d1cc4||_0x584485['options']['databaseURL'];_0x41cfa9===void 0x0&&(_0x584485['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x584485['options']['projectId']),_0x41cfa9=_0x584485['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5480f0=gr(_0x41cfa9,_0x33c93f),_0x419d2a=_0x5480f0['repoInfo'],_0x205f68;typeof process<'u'&&Us&&(_0x205f68=Us[Hd]),_0x205f68?(_0x41cfa9='http://'+_0x205f68+'?ns='+_0x419d2a['namespace'],_0x5480f0=gr(_0x41cfa9,_0x33c93f),_0x419d2a=_0x5480f0['repoInfo']):_0x5480f0['repoInfo']['secure'];const _0x8171f9=new Jl(_0x584485['name'],_0x584485['options'],_0x2ba3f2);dd('Invalid\x20Firebase\x20Database\x20URL',_0x5480f0),v(_0x5480f0['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3434ad=jd(_0x419d2a,_0x584485,_0x8171f9,new Ql(_0x584485,_0x4dcef5));return new Kd(_0x3434ad,_0x584485);}function zd(_0x188b7e,_0x1e5a4e){const _0x3a3f58=ki[_0x1e5a4e];(!_0x3a3f58||_0x3a3f58[_0x188b7e['key']]!==_0x188b7e)&&oe('Database\x20'+_0x1e5a4e+'('+_0x188b7e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x188b7e),delete _0x3a3f58[_0x188b7e['key']];}function jd(_0x2581d1,_0x6dbda8,_0x587715,_0x460e26){let _0x435b27=ki[_0x6dbda8['name']];_0x435b27||(_0x435b27={},ki[_0x6dbda8['name']]=_0x435b27);let _0xea2494=_0x435b27[_0x2581d1['toURLString']()];return _0xea2494&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0xea2494=new gd(_0x2581d1,$d,_0x587715,_0x460e26),_0x435b27[_0x2581d1['toURLString']()]=_0xea2494,_0xea2494;}class Kd{constructor(_0x5c726f,_0x26cf97){this['_repoInternal']=_0x5c726f,this['app']=_0x26cf97,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x54109){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x54109+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x298df7=Qr(),_0x1e6fd3){const _0x5d66a6=Ui(_0x298df7,'database')['getImmediate']({'identifier':_0x1e6fd3});if(!_0x5d66a6['_instanceStarted']){const _0x21f9f2=ac('database');_0x21f9f2&&Yd(_0x5d66a6,..._0x21f9f2);}return _0x5d66a6;}function Yd(_0x4a7ce0,_0x21fad1,_0x3b409d,_0x404e49={}){_0x4a7ce0=k(_0x4a7ce0),_0x4a7ce0['_checkNotDeleted']('useEmulator');const _0xe61708=_0x21fad1+':'+_0x3b409d,_0x54bde6=_0x4a7ce0['_repoInternal'];if(_0x4a7ce0['_instanceStarted']){if(_0xe61708===_0x4a7ce0['_repoInternal']['repoInfo_']['host']&&De(_0x404e49,_0x54bde6['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x13c4d6;if(_0x54bde6['repoInfo_']['nodeAdmin'])_0x404e49['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x13c4d6=new tn(tn['OWNER']);else{if(_0x404e49['mockUserToken']){const _0x1dcaf0=typeof _0x404e49['mockUserToken']=='string'?_0x404e49['mockUserToken']:cc(_0x404e49['mockUserToken'],_0x4a7ce0['app']['options']['projectId']);_0x13c4d6=new tn(_0x1dcaf0);}}Wt(_0x21fad1)&&jr(_0x21fad1),Gd(_0x54bde6,_0xe61708,_0x404e49,_0x13c4d6);}function C_(_0x25b4f3){_0x25b4f3=k(_0x25b4f3),_0x25b4f3['_checkNotDeleted']('goOffline'),aa(_0x25b4f3['_repo']);}function T_(_0x8403f4){_0x8403f4=k(_0x8403f4),_0x8403f4['_checkNotDeleted']('goOnline'),Sd(_0x8403f4['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x3a607e){Ll(ct),et(new Me('database',(_0x47ad3a,{instanceIdentifier:_0x1671ed})=>{const _0x52a381=_0x47ad3a['getProvider']('app')['getImmediate'](),_0x10b335=_0x47ad3a['getProvider']('auth-internal'),_0x936b9=_0x47ad3a['getProvider']('app-check-internal');return qd(_0x52a381,_0x10b335,_0x936b9,_0x1671ed);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x3a607e),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x4ada1a,_0xe40a5b){this['committed']=_0x4ada1a,this['snapshot']=_0xe40a5b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x451150,_0x127de3,_0x226e8c){if(_0x451150=k(_0x451150),gs('Reference.transaction',_0x451150['_path']),_0x451150['key']==='.length'||_0x451150['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x451150['key']+'\x20is\x20a\x20read-only\x20object.';const _0x86f12c=!0x0,_0x4de626=new Ve(),_0xeabe72=(_0x45c1f6,_0x338234,_0x71cb26)=>{let _0x5b0cad=null;_0x45c1f6?_0x4de626['reject'](_0x45c1f6):(_0x5b0cad=new rt(_0x71cb26,new Z(_0x451150['_repo'],_0x451150['_path']),R),_0x4de626['resolve'](new Xd(_0x338234,_0x5b0cad)));},_0x3f17d0=Fd(_0x451150,()=>{});return bd(_0x451150['_repo'],_0x451150['_path'],_0x127de3,_0xeabe72,_0x3f17d0,_0x86f12c),_0x4de626['promise'];}ie['prototype']['simpleListen']=function(_0x164948,_0x521c4a){this['sendRequest']('q',{'p':_0x164948},_0x521c4a);},ie['prototype']['echo']=function(_0x242f25,_0x3ad2c8){this['sendRequest']('echo',{'d':_0x242f25},_0x3ad2c8);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x172ef0,..._0xda33c5){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x172ef0,..._0xda33c5);}function nn(_0x248409,..._0x1fc854){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x248409,..._0x1fc854);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5a3e62,..._0x15af93){throw Es(_0x5a3e62,..._0x15af93);}function J(_0x1ef2f4,..._0x3e9b5d){return Es(_0x1ef2f4,..._0x3e9b5d);}function ya(_0x567d56,_0x4d3700,_0xc458ed){const _0x5f00c0={...Zd(),[_0x4d3700]:_0xc458ed};return new Ut('auth','Firebase',_0x5f00c0)['create'](_0x4d3700,{'appName':_0x567d56['name']});}function se(_0x223f76){return ya(_0x223f76,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x42490e,..._0x377dc4){if(typeof _0x42490e!='string'){const _0x3461b7=_0x377dc4[0x0],_0x1e3017=[..._0x377dc4['slice'](0x1)];return _0x1e3017[0x0]&&(_0x1e3017[0x0]['appName']=_0x42490e['name']),_0x42490e['_errorFactory']['create'](_0x3461b7,..._0x1e3017);}return ma['create'](_0x42490e,..._0x377dc4);}function m(_0x1901d2,_0x459a70,..._0x5b96c9){if(!_0x1901d2)throw Es(_0x459a70,..._0x5b96c9);}function te(_0x474f2c){const _0x361b73='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x474f2c;throw nn(_0x361b73),new Error(_0x361b73);}function ae(_0x42a45a,_0x37ab7d){_0x42a45a||te(_0x37ab7d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x22e53f;return typeof self<'u'&&((_0x22e53f=self['location'])==null?void 0x0:_0x22e53f['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1b69ed;return typeof self<'u'&&((_0x1b69ed=self['location'])==null?void 0x0:_0x1b69ed['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x419a45=navigator;return _0x419a45['languages']&&_0x419a45['languages'][0x0]||_0x419a45['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x1d72b8,_0xd5ae05){this['shortDelay']=_0x1d72b8,this['longDelay']=_0xd5ae05,ae(_0xd5ae05>_0x1d72b8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x2893d4,_0xe1516e){ae(_0x2893d4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3891c1}=_0x2893d4['emulator'];return _0xe1516e?''+_0x3891c1+(_0xe1516e['startsWith']('/')?_0xe1516e['slice'](0x1):_0xe1516e):_0x3891c1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x638ba5,_0x402eb0,_0x3435a9){this['fetchImpl']=_0x638ba5,_0x402eb0&&(this['headersImpl']=_0x402eb0),_0x3435a9&&(this['responseImpl']=_0x3435a9);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0xe52885,_0x1eb07f){return _0xe52885['tenantId']&&!_0x1eb07f['tenantId']?{..._0x1eb07f,'tenantId':_0xe52885['tenantId']}:_0x1eb07f;}async function Ae(_0x1d97b2,_0x554704,_0x57c922,_0x296845,_0x41460e={}){return Ea(_0x1d97b2,_0x41460e,async()=>{let _0x394350={},_0x36f02d={};_0x296845&&(_0x554704==='GET'?_0x36f02d=_0x296845:_0x394350={'body':JSON['stringify'](_0x296845)});const _0x147a85=at({..._0x36f02d,'key':_0x1d97b2['config']['apiKey']})['slice'](0x1),_0x42d953=await _0x1d97b2['_getAdditionalHeaders']();_0x42d953['Content-Type']='application/json',_0x1d97b2['languageCode']&&(_0x42d953['X-Firebase-Locale']=_0x1d97b2['languageCode']);const _0x2dd3b7={'method':_0x554704,'headers':_0x42d953,..._0x394350};return lc()||(_0x2dd3b7['referrerPolicy']='strict-origin-when-cross-origin'),_0x1d97b2['emulatorConfig']&&Wt(_0x1d97b2['emulatorConfig']['host'])&&(_0x2dd3b7['credentials']='include'),va['fetch']()(await Ia(_0x1d97b2,_0x1d97b2['config']['apiHost'],_0x57c922,_0x147a85),_0x2dd3b7);});}async function Ea(_0x15688d,_0x97caf7,_0x13304e){_0x15688d['_canInitEmulator']=!0x1;const _0x242258={...rf,..._0x97caf7};try{const _0x4a7bcd=new lf(_0x15688d),_0x3b459a=await Promise['race']([_0x13304e(),_0x4a7bcd['promise']]);_0x4a7bcd['clearNetworkTimeout']();const _0x2be7a=await _0x3b459a['json']();if('needConfirmation'in _0x2be7a)throw en(_0x15688d,'account-exists-with-different-credential',_0x2be7a);if(_0x3b459a['ok']&&!('errorMessage'in _0x2be7a))return _0x2be7a;{const _0x1fc650=_0x3b459a['ok']?_0x2be7a['errorMessage']:_0x2be7a['error']['message'],[_0x10c975,_0x140eee]=_0x1fc650['split']('\x20:\x20');if(_0x10c975==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x15688d,'credential-already-in-use',_0x2be7a);if(_0x10c975==='EMAIL_EXISTS')throw en(_0x15688d,'email-already-in-use',_0x2be7a);if(_0x10c975==='USER_DISABLED')throw en(_0x15688d,'user-disabled',_0x2be7a);const _0x28aa87=_0x242258[_0x10c975]||_0x10c975['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x140eee)throw ya(_0x15688d,_0x28aa87,_0x140eee);K(_0x15688d,_0x28aa87);}}catch(_0x13ea60){if(_0x13ea60 instanceof Se)throw _0x13ea60;K(_0x15688d,'network-request-failed',{'message':String(_0x13ea60)});}}async function Yt(_0x5955f,_0x5bd77e,_0x3f1b49,_0xa52c60,_0x205495={}){const _0x19b78c=await Ae(_0x5955f,_0x5bd77e,_0x3f1b49,_0xa52c60,_0x205495);return'mfaPendingCredential'in _0x19b78c&&K(_0x5955f,'multi-factor-auth-required',{'_serverResponse':_0x19b78c}),_0x19b78c;}async function Ia(_0x26d2b0,_0x579106,_0x42366d,_0x393e54){const _0x478f1e=''+_0x579106+_0x42366d+'?'+_0x393e54,_0x564105=_0x26d2b0,_0x1b8fcd=_0x564105['config']['emulator']?Is(_0x26d2b0['config'],_0x478f1e):_0x26d2b0['config']['apiScheme']+'://'+_0x478f1e;return of['includes'](_0x42366d)&&(await _0x564105['_persistenceManagerAvailable'],_0x564105['_getPersistenceType']()==='COOKIE')?_0x564105['_getPersistence']()['_getFinalTarget'](_0x1b8fcd)['toString']():_0x1b8fcd;}function cf(_0x19db8c){switch(_0x19db8c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4aeca8){this['auth']=_0x4aeca8,this['timer']=null,this['promise']=new Promise((_0x9de08a,_0xba54f2)=>{this['timer']=setTimeout(()=>_0xba54f2(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0xf39dde,_0x50a818,_0x494b09){const _0x2dfb89={'appName':_0xf39dde['name']};_0x494b09['email']&&(_0x2dfb89['email']=_0x494b09['email']),_0x494b09['phoneNumber']&&(_0x2dfb89['phoneNumber']=_0x494b09['phoneNumber']);const _0x5b1fe9=J(_0xf39dde,_0x50a818,_0x2dfb89);return _0x5b1fe9['customData']['_tokenResponse']=_0x494b09,_0x5b1fe9;}function vr(_0x5710f3){return _0x5710f3!==void 0x0&&_0x5710f3['enterprise']!==void 0x0;}class hf{constructor(_0x1b0187){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x1b0187['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x1b0187['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x1b0187['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x546bb4){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1b228a of this['recaptchaEnforcementState'])if(_0x1b228a['provider']&&_0x1b228a['provider']===_0x546bb4)return cf(_0x1b228a['enforcementState']);return null;}['isProviderEnabled'](_0x30f0b8){return this['getProviderEnforcementState'](_0x30f0b8)==='ENFORCE'||this['getProviderEnforcementState'](_0x30f0b8)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x8e6491,_0x5cadd1){return Ae(_0x8e6491,'GET','/v2/recaptchaConfig',Re(_0x8e6491,_0x5cadd1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4743a5,_0x2a4244){return Ae(_0x4743a5,'POST','/v1/accounts:delete',_0x2a4244);}async function Sn(_0x467df2,_0x2f0da9){return Ae(_0x467df2,'POST','/v1/accounts:lookup',_0x2f0da9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x280d2c){if(_0x280d2c)try{const _0xd03a33=new Date(Number(_0x280d2c));if(!isNaN(_0xd03a33['getTime']()))return _0xd03a33['toUTCString']();}catch{}}async function ff(_0x111f92,_0x334d0f=!0x1){const _0x4ae606=k(_0x111f92),_0x4742e3=await _0x4ae606['getIdToken'](_0x334d0f),_0x38a486=ws(_0x4742e3);m(_0x38a486&&_0x38a486['exp']&&_0x38a486['auth_time']&&_0x38a486['iat'],_0x4ae606['auth'],'internal-error');const _0x443d1f=typeof _0x38a486['firebase']=='object'?_0x38a486['firebase']:void 0x0,_0x35ad03=_0x443d1f==null?void 0x0:_0x443d1f['sign_in_provider'];return{'claims':_0x38a486,'token':_0x4742e3,'authTime':St(ci(_0x38a486['auth_time'])),'issuedAtTime':St(ci(_0x38a486['iat'])),'expirationTime':St(ci(_0x38a486['exp'])),'signInProvider':_0x35ad03||null,'signInSecondFactor':(_0x443d1f==null?void 0x0:_0x443d1f['sign_in_second_factor'])||null};}function ci(_0x2fc4ce){return Number(_0x2fc4ce)*0x3e8;}function ws(_0x2d0bf5){const [_0x54bff5,_0x31ad31,_0xf268e5]=_0x2d0bf5['split']('.');if(_0x54bff5===void 0x0||_0x31ad31===void 0x0||_0xf268e5===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x338d71=cn(_0x31ad31);return _0x338d71?JSON['parse'](_0x338d71):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xbc3dd6){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xbc3dd6==null?void 0x0:_0xbc3dd6['toString']()),null;}}function Er(_0x10cdca){const _0x1c99c7=ws(_0x10cdca);return m(_0x1c99c7,'internal-error'),m(typeof _0x1c99c7['exp']<'u','internal-error'),m(typeof _0x1c99c7['iat']<'u','internal-error'),Number(_0x1c99c7['exp'])-Number(_0x1c99c7['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x54544c,_0x5d54b8,_0x17ef26=!0x1){if(_0x17ef26)return _0x5d54b8;try{return await _0x5d54b8;}catch(_0x3ef285){throw _0x3ef285 instanceof Se&&pf(_0x3ef285)&&_0x54544c['auth']['currentUser']===_0x54544c&&await _0x54544c['auth']['signOut'](),_0x3ef285;}}function pf({code:_0x4bb10c}){return _0x4bb10c==='auth/user-disabled'||_0x4bb10c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0xe9bd4c){this['user']=_0xe9bd4c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x29f61c){if(_0x29f61c){const _0x32155a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x32155a;}else{this['errorBackoff']=0x7530;const _0x3c13c2=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3c13c2);}}['schedule'](_0x285046=!0x1){if(!this['isRunning'])return;const _0x17dafa=this['getInterval'](_0x285046);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x17dafa);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x538214){(_0x538214==null?void 0x0:_0x538214['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x54317c,_0x1330f8){this['createdAt']=_0x54317c,this['lastLoginAt']=_0x1330f8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x23f0c3){this['createdAt']=_0x23f0c3['createdAt'],this['lastLoginAt']=_0x23f0c3['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x4bd56f){var _0x44d8f2;const _0x1ca9f5=_0x4bd56f['auth'],_0x2aedd1=await _0x4bd56f['getIdToken'](),_0x5e8ff7=await xt(_0x4bd56f,Sn(_0x1ca9f5,{'idToken':_0x2aedd1}));m(_0x5e8ff7==null?void 0x0:_0x5e8ff7['users']['length'],_0x1ca9f5,'internal-error');const _0x46867c=_0x5e8ff7['users'][0x0];_0x4bd56f['_notifyReloadListener'](_0x46867c);const _0x5a2559=(_0x44d8f2=_0x46867c['providerUserInfo'])!=null&&_0x44d8f2['length']?wa(_0x46867c['providerUserInfo']):[],_0xeea2e2=mf(_0x4bd56f['providerData'],_0x5a2559),_0x270b6d=_0x4bd56f['isAnonymous'],_0x2b6319=!(_0x4bd56f['email']&&_0x46867c['passwordHash'])&&!(_0xeea2e2!=null&&_0xeea2e2['length']),_0x3fd149=_0x270b6d?_0x2b6319:!0x1,_0x16b01f={'uid':_0x46867c['localId'],'displayName':_0x46867c['displayName']||null,'photoURL':_0x46867c['photoUrl']||null,'email':_0x46867c['email']||null,'emailVerified':_0x46867c['emailVerified']||!0x1,'phoneNumber':_0x46867c['phoneNumber']||null,'tenantId':_0x46867c['tenantId']||null,'providerData':_0xeea2e2,'metadata':new Pi(_0x46867c['createdAt'],_0x46867c['lastLoginAt']),'isAnonymous':_0x3fd149};Object['assign'](_0x4bd56f,_0x16b01f);}async function gf(_0x5d3df3){const _0xf9f87=k(_0x5d3df3);await bn(_0xf9f87),await _0xf9f87['auth']['_persistUserIfCurrent'](_0xf9f87),_0xf9f87['auth']['_notifyListenersIfCurrent'](_0xf9f87);}function mf(_0x3716ca,_0x121c3b){return[..._0x3716ca['filter'](_0x3f2587=>!_0x121c3b['some'](_0x1633cb=>_0x1633cb['providerId']===_0x3f2587['providerId'])),..._0x121c3b];}function wa(_0x497602){return _0x497602['map'](({providerId:_0x18caf5,..._0x5481b3})=>({'providerId':_0x18caf5,'uid':_0x5481b3['rawId']||'','displayName':_0x5481b3['displayName']||null,'email':_0x5481b3['email']||null,'phoneNumber':_0x5481b3['phoneNumber']||null,'photoURL':_0x5481b3['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x4c56b3,_0x2ab4af){const _0x5bad19=await Ea(_0x4c56b3,{},async()=>{const _0x2b6e4c=at({'grant_type':'refresh_token','refresh_token':_0x2ab4af})['slice'](0x1),{tokenApiHost:_0x413380,apiKey:_0x4d12b4}=_0x4c56b3['config'],_0x7b1359=await Ia(_0x4c56b3,_0x413380,'/v1/token','key='+_0x4d12b4),_0x4aba6f=await _0x4c56b3['_getAdditionalHeaders']();_0x4aba6f['Content-Type']='application/x-www-form-urlencoded';const _0x3091c4={'method':'POST','headers':_0x4aba6f,'body':_0x2b6e4c};return _0x4c56b3['emulatorConfig']&&Wt(_0x4c56b3['emulatorConfig']['host'])&&(_0x3091c4['credentials']='include'),va['fetch']()(_0x7b1359,_0x3091c4);});return{'accessToken':_0x5bad19['access_token'],'expiresIn':_0x5bad19['expires_in'],'refreshToken':_0x5bad19['refresh_token']};}async function vf(_0x46cb2b,_0x29fc3b){return Ae(_0x46cb2b,'POST','/v2/accounts:revokeToken',Re(_0x46cb2b,_0x29fc3b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x82f3){m(_0x82f3['idToken'],'internal-error'),m(typeof _0x82f3['idToken']<'u','internal-error'),m(typeof _0x82f3['refreshToken']<'u','internal-error');const _0x1a5943='expiresIn'in _0x82f3&&typeof _0x82f3['expiresIn']<'u'?Number(_0x82f3['expiresIn']):Er(_0x82f3['idToken']);this['updateTokensAndExpiration'](_0x82f3['idToken'],_0x82f3['refreshToken'],_0x1a5943);}['updateFromIdToken'](_0x2c8d5a){m(_0x2c8d5a['length']!==0x0,'internal-error');const _0x2d39f4=Er(_0x2c8d5a);this['updateTokensAndExpiration'](_0x2c8d5a,null,_0x2d39f4);}async['getToken'](_0x4fd0a5,_0x698bdf=!0x1){return!_0x698bdf&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4fd0a5,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4fd0a5,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x556076,_0x2a25ec){const {accessToken:_0x1705f4,refreshToken:_0x59f763,expiresIn:_0x3b85f3}=await yf(_0x556076,_0x2a25ec);this['updateTokensAndExpiration'](_0x1705f4,_0x59f763,Number(_0x3b85f3));}['updateTokensAndExpiration'](_0x407eca,_0x1746cc,_0x2ab326){this['refreshToken']=_0x1746cc||null,this['accessToken']=_0x407eca||null,this['expirationTime']=Date['now']()+_0x2ab326*0x3e8;}static['fromJSON'](_0x24db9b,_0x211ac1){const {refreshToken:_0x4ada98,accessToken:_0x5f48f2,expirationTime:_0x38bce1}=_0x211ac1,_0x33fa31=new Je();return _0x4ada98&&(m(typeof _0x4ada98=='string','internal-error',{'appName':_0x24db9b}),_0x33fa31['refreshToken']=_0x4ada98),_0x5f48f2&&(m(typeof _0x5f48f2=='string','internal-error',{'appName':_0x24db9b}),_0x33fa31['accessToken']=_0x5f48f2),_0x38bce1&&(m(typeof _0x38bce1=='number','internal-error',{'appName':_0x24db9b}),_0x33fa31['expirationTime']=_0x38bce1),_0x33fa31;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x406eb1){this['accessToken']=_0x406eb1['accessToken'],this['refreshToken']=_0x406eb1['refreshToken'],this['expirationTime']=_0x406eb1['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x506cea,_0x5a3d42){m(typeof _0x506cea=='string'||typeof _0x506cea>'u','internal-error',{'appName':_0x5a3d42});}class z{constructor({uid:_0x58d6b2,auth:_0x5252d8,stsTokenManager:_0x416135,..._0x23bb38}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x58d6b2,this['auth']=_0x5252d8,this['stsTokenManager']=_0x416135,this['accessToken']=_0x416135['accessToken'],this['displayName']=_0x23bb38['displayName']||null,this['email']=_0x23bb38['email']||null,this['emailVerified']=_0x23bb38['emailVerified']||!0x1,this['phoneNumber']=_0x23bb38['phoneNumber']||null,this['photoURL']=_0x23bb38['photoURL']||null,this['isAnonymous']=_0x23bb38['isAnonymous']||!0x1,this['tenantId']=_0x23bb38['tenantId']||null,this['providerData']=_0x23bb38['providerData']?[..._0x23bb38['providerData']]:[],this['metadata']=new Pi(_0x23bb38['createdAt']||void 0x0,_0x23bb38['lastLoginAt']||void 0x0);}async['getIdToken'](_0x11deee){const _0x339b0e=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x11deee));return m(_0x339b0e,this['auth'],'internal-error'),this['accessToken']!==_0x339b0e&&(this['accessToken']=_0x339b0e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x339b0e;}['getIdTokenResult'](_0x4f1d4a){return ff(this,_0x4f1d4a);}['reload'](){return gf(this);}['_assign'](_0x1616d9){this!==_0x1616d9&&(m(this['uid']===_0x1616d9['uid'],this['auth'],'internal-error'),this['displayName']=_0x1616d9['displayName'],this['photoURL']=_0x1616d9['photoURL'],this['email']=_0x1616d9['email'],this['emailVerified']=_0x1616d9['emailVerified'],this['phoneNumber']=_0x1616d9['phoneNumber'],this['isAnonymous']=_0x1616d9['isAnonymous'],this['tenantId']=_0x1616d9['tenantId'],this['providerData']=_0x1616d9['providerData']['map'](_0x54028f=>({..._0x54028f})),this['metadata']['_copy'](_0x1616d9['metadata']),this['stsTokenManager']['_assign'](_0x1616d9['stsTokenManager']));}['_clone'](_0x4e0bae){const _0x53dda0=new z({...this,'auth':_0x4e0bae,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x53dda0['metadata']['_copy'](this['metadata']),_0x53dda0;}['_onReload'](_0x13a7ef){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x13a7ef,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x39e141){this['reloadListener']?this['reloadListener'](_0x39e141):this['reloadUserInfo']=_0x39e141;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4dee3a,_0x40d716=!0x1){let _0x57102b=!0x1;_0x4dee3a['idToken']&&_0x4dee3a['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4dee3a),_0x57102b=!0x0),_0x40d716&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x57102b&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x38d237=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x38d237})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x295c93=>({..._0x295c93})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4f50ac,_0x40ccd4){const _0x20a777=_0x40ccd4['displayName']??void 0x0,_0x544cfb=_0x40ccd4['email']??void 0x0,_0x431d46=_0x40ccd4['phoneNumber']??void 0x0,_0x2efc8f=_0x40ccd4['photoURL']??void 0x0,_0x59e331=_0x40ccd4['tenantId']??void 0x0,_0xb839a8=_0x40ccd4['_redirectEventId']??void 0x0,_0x43e169=_0x40ccd4['createdAt']??void 0x0,_0x752e0b=_0x40ccd4['lastLoginAt']??void 0x0,{uid:_0x4b48e9,emailVerified:_0x4e93ec,isAnonymous:_0x5adf3f,providerData:_0x1cc979,stsTokenManager:_0x4332fe}=_0x40ccd4;m(_0x4b48e9&&_0x4332fe,_0x4f50ac,'internal-error');const _0x7f2b0b=Je['fromJSON'](this['name'],_0x4332fe);m(typeof _0x4b48e9=='string',_0x4f50ac,'internal-error'),ce(_0x20a777,_0x4f50ac['name']),ce(_0x544cfb,_0x4f50ac['name']),m(typeof _0x4e93ec=='boolean',_0x4f50ac,'internal-error'),m(typeof _0x5adf3f=='boolean',_0x4f50ac,'internal-error'),ce(_0x431d46,_0x4f50ac['name']),ce(_0x2efc8f,_0x4f50ac['name']),ce(_0x59e331,_0x4f50ac['name']),ce(_0xb839a8,_0x4f50ac['name']),ce(_0x43e169,_0x4f50ac['name']),ce(_0x752e0b,_0x4f50ac['name']);const _0x234c1a=new z({'uid':_0x4b48e9,'auth':_0x4f50ac,'email':_0x544cfb,'emailVerified':_0x4e93ec,'displayName':_0x20a777,'isAnonymous':_0x5adf3f,'photoURL':_0x2efc8f,'phoneNumber':_0x431d46,'tenantId':_0x59e331,'stsTokenManager':_0x7f2b0b,'createdAt':_0x43e169,'lastLoginAt':_0x752e0b});return _0x1cc979&&Array['isArray'](_0x1cc979)&&(_0x234c1a['providerData']=_0x1cc979['map'](_0xdeba52=>({..._0xdeba52}))),_0xb839a8&&(_0x234c1a['_redirectEventId']=_0xb839a8),_0x234c1a;}static async['_fromIdTokenResponse'](_0x197251,_0x48cc80,_0x4dfdec=!0x1){const _0x23193c=new Je();_0x23193c['updateFromServerResponse'](_0x48cc80);const _0xe496fd=new z({'uid':_0x48cc80['localId'],'auth':_0x197251,'stsTokenManager':_0x23193c,'isAnonymous':_0x4dfdec});return await bn(_0xe496fd),_0xe496fd;}static async['_fromGetAccountInfoResponse'](_0x4a9657,_0x3eb9af,_0x2bc9e5){const _0x3dccc0=_0x3eb9af['users'][0x0];m(_0x3dccc0['localId']!==void 0x0,'internal-error');const _0x3a73b3=_0x3dccc0['providerUserInfo']!==void 0x0?wa(_0x3dccc0['providerUserInfo']):[],_0x57389b=!(_0x3dccc0['email']&&_0x3dccc0['passwordHash'])&&!(_0x3a73b3!=null&&_0x3a73b3['length']),_0x4ebe32=new Je();_0x4ebe32['updateFromIdToken'](_0x2bc9e5);const _0xd98d5b=new z({'uid':_0x3dccc0['localId'],'auth':_0x4a9657,'stsTokenManager':_0x4ebe32,'isAnonymous':_0x57389b}),_0x211dd1={'uid':_0x3dccc0['localId'],'displayName':_0x3dccc0['displayName']||null,'photoURL':_0x3dccc0['photoUrl']||null,'email':_0x3dccc0['email']||null,'emailVerified':_0x3dccc0['emailVerified']||!0x1,'phoneNumber':_0x3dccc0['phoneNumber']||null,'tenantId':_0x3dccc0['tenantId']||null,'providerData':_0x3a73b3,'metadata':new Pi(_0x3dccc0['createdAt'],_0x3dccc0['lastLoginAt']),'isAnonymous':!(_0x3dccc0['email']&&_0x3dccc0['passwordHash'])&&!(_0x3a73b3!=null&&_0x3a73b3['length'])};return Object['assign'](_0xd98d5b,_0x211dd1),_0xd98d5b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x5d2913){ae(_0x5d2913 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2cc506=Ir['get'](_0x5d2913);return _0x2cc506?(ae(_0x2cc506 instanceof _0x5d2913,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2cc506):(_0x2cc506=new _0x5d2913(),Ir['set'](_0x5d2913,_0x2cc506),_0x2cc506);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x49f7be,_0x16613b){this['storage'][_0x49f7be]=_0x16613b;}async['_get'](_0x4180be){const _0xc79552=this['storage'][_0x4180be];return _0xc79552===void 0x0?null:_0xc79552;}async['_remove'](_0x5574ed){delete this['storage'][_0x5574ed];}['_addListener'](_0x96e8d,_0x3c7a6a){}['_removeListener'](_0x17b967,_0x5c695b){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0xa40e0a,_0x2d8230,_0x34f944){return'firebase:'+_0xa40e0a+':'+_0x2d8230+':'+_0x34f944;}class Xe{constructor(_0x35f82d,_0x3a345a,_0x3903f2){this['persistence']=_0x35f82d,this['auth']=_0x3a345a,this['userKey']=_0x3903f2;const {config:_0x49d27c,name:_0x1d04f5}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x49d27c['apiKey'],_0x1d04f5),this['fullPersistenceKey']=sn('persistence',_0x49d27c['apiKey'],_0x1d04f5),this['boundEventHandler']=_0x3a345a['_onStorageEvent']['bind'](_0x3a345a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3e9180){return this['persistence']['_set'](this['fullUserKey'],_0x3e9180['toJSON']());}async['getCurrentUser'](){const _0x2f5c12=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2f5c12)return null;if(typeof _0x2f5c12=='string'){const _0xa71b45=await Sn(this['auth'],{'idToken':_0x2f5c12})['catch'](()=>{});return _0xa71b45?z['_fromGetAccountInfoResponse'](this['auth'],_0xa71b45,_0x2f5c12):null;}return z['_fromJSON'](this['auth'],_0x2f5c12);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x24134c){if(this['persistence']===_0x24134c)return;const _0x52dc82=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x24134c,_0x52dc82)return this['setCurrentUser'](_0x52dc82);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1d6921,_0xe513f0,_0x23831a='authUser'){if(!_0xe513f0['length'])return new Xe(ne(wr),_0x1d6921,_0x23831a);const _0x4f5aaf=(await Promise['all'](_0xe513f0['map'](async _0xcd60ec=>{if(await _0xcd60ec['_isAvailable']())return _0xcd60ec;})))['filter'](_0x4ff425=>_0x4ff425);let _0x33856a=_0x4f5aaf[0x0]||ne(wr);const _0x390dc5=sn(_0x23831a,_0x1d6921['config']['apiKey'],_0x1d6921['name']);let _0x47dcc5=null;for(const _0x22a6fe of _0xe513f0)try{const _0x428086=await _0x22a6fe['_get'](_0x390dc5);if(_0x428086){let _0x5adad3;if(typeof _0x428086=='string'){const _0x28e125=await Sn(_0x1d6921,{'idToken':_0x428086})['catch'](()=>{});if(!_0x28e125)break;_0x5adad3=await z['_fromGetAccountInfoResponse'](_0x1d6921,_0x28e125,_0x428086);}else _0x5adad3=z['_fromJSON'](_0x1d6921,_0x428086);_0x22a6fe!==_0x33856a&&(_0x47dcc5=_0x5adad3),_0x33856a=_0x22a6fe;break;}}catch{}const _0x4c5d6b=_0x4f5aaf['filter'](_0x3bcac5=>_0x3bcac5['_shouldAllowMigration']);return!_0x33856a['_shouldAllowMigration']||!_0x4c5d6b['length']?new Xe(_0x33856a,_0x1d6921,_0x23831a):(_0x33856a=_0x4c5d6b[0x0],_0x47dcc5&&await _0x33856a['_set'](_0x390dc5,_0x47dcc5['toJSON']()),await Promise['all'](_0xe513f0['map'](async _0xae587e=>{if(_0xae587e!==_0x33856a)try{await _0xae587e['_remove'](_0x390dc5);}catch{}})),new Xe(_0x33856a,_0x1d6921,_0x23831a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x102492){const _0x505f5a=_0x102492['toLowerCase']();if(_0x505f5a['includes']('opera/')||_0x505f5a['includes']('opr/')||_0x505f5a['includes']('opios/'))return'Opera';if(Ra(_0x505f5a))return'IEMobile';if(_0x505f5a['includes']('msie')||_0x505f5a['includes']('trident/'))return'IE';if(_0x505f5a['includes']('edge/'))return'Edge';if(Ta(_0x505f5a))return'Firefox';if(_0x505f5a['includes']('silk/'))return'Silk';if(ka(_0x505f5a))return'Blackberry';if(Na(_0x505f5a))return'Webos';if(Sa(_0x505f5a))return'Safari';if((_0x505f5a['includes']('chrome/')||ba(_0x505f5a))&&!_0x505f5a['includes']('edge/'))return'Chrome';if(Aa(_0x505f5a))return'Android';{const _0xb5d325=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x19f95a=_0x102492['match'](_0xb5d325);if((_0x19f95a==null?void 0x0:_0x19f95a['length'])===0x2)return _0x19f95a[0x1];}return'Other';}function Ta(_0x39b263=W()){return/firefox\//i['test'](_0x39b263);}function Sa(_0x2d357b=W()){const _0x5c6fff=_0x2d357b['toLowerCase']();return _0x5c6fff['includes']('safari/')&&!_0x5c6fff['includes']('chrome/')&&!_0x5c6fff['includes']('crios/')&&!_0x5c6fff['includes']('android');}function ba(_0x10d25e=W()){return/crios\//i['test'](_0x10d25e);}function Ra(_0x55ea05=W()){return/iemobile/i['test'](_0x55ea05);}function Aa(_0x4be823=W()){return/android/i['test'](_0x4be823);}function ka(_0x437f89=W()){return/blackberry/i['test'](_0x437f89);}function Na(_0x4e87d6=W()){return/webos/i['test'](_0x4e87d6);}function Cs(_0x27a6e6=W()){return/iphone|ipad|ipod/i['test'](_0x27a6e6)||/macintosh/i['test'](_0x27a6e6)&&/mobile/i['test'](_0x27a6e6);}function Ef(_0x5e312f=W()){var _0x98b4f;return Cs(_0x5e312f)&&!!((_0x98b4f=window['navigator'])!=null&&_0x98b4f['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x3c6764=W()){return Cs(_0x3c6764)||Aa(_0x3c6764)||Na(_0x3c6764)||ka(_0x3c6764)||/windows phone/i['test'](_0x3c6764)||Ra(_0x3c6764);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x190384,_0x40c3a1=[]){let _0x299dea;switch(_0x190384){case'Browser':_0x299dea=Cr(W());break;case'Worker':_0x299dea=Cr(W())+'-'+_0x190384;break;default:_0x299dea=_0x190384;}const _0x545a35=_0x40c3a1['length']?_0x40c3a1['join'](','):'FirebaseCore-web';return _0x299dea+'/JsCore/'+ct+'/'+_0x545a35;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2def25){this['auth']=_0x2def25,this['queue']=[];}['pushCallback'](_0x5e2282,_0x4712e6){const _0x20c410=_0x38febc=>new Promise((_0x149bf0,_0x56a735)=>{try{const _0x2a0d75=_0x5e2282(_0x38febc);_0x149bf0(_0x2a0d75);}catch(_0x948a30){_0x56a735(_0x948a30);}});_0x20c410['onAbort']=_0x4712e6,this['queue']['push'](_0x20c410);const _0x48765a=this['queue']['length']-0x1;return()=>{this['queue'][_0x48765a]=()=>Promise['resolve']();};}async['runMiddleware'](_0x13c9ba){if(this['auth']['currentUser']===_0x13c9ba)return;const _0xc8790a=[];try{for(const _0x3099be of this['queue'])await _0x3099be(_0x13c9ba),_0x3099be['onAbort']&&_0xc8790a['push'](_0x3099be['onAbort']);}catch(_0x4e7cd6){_0xc8790a['reverse']();for(const _0x241f8c of _0xc8790a)try{_0x241f8c();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4e7cd6==null?void 0x0:_0x4e7cd6['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x592dc6,_0x9ad34b={}){return Ae(_0x592dc6,'GET','/v2/passwordPolicy',Re(_0x592dc6,_0x9ad34b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3c0101){var _0x210004;const _0x129ed7=_0x3c0101['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x129ed7['minPasswordLength']??Tf,_0x129ed7['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x129ed7['maxPasswordLength']),_0x129ed7['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x129ed7['containsLowercaseCharacter']),_0x129ed7['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x129ed7['containsUppercaseCharacter']),_0x129ed7['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x129ed7['containsNumericCharacter']),_0x129ed7['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x129ed7['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3c0101['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x210004=_0x3c0101['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x210004['join'](''))??'',this['forceUpgradeOnSignin']=_0x3c0101['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3c0101['schemaVersion'];}['validatePassword'](_0x4da09f){const _0x1b87db={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4da09f,_0x1b87db),this['validatePasswordCharacterOptions'](_0x4da09f,_0x1b87db),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['meetsMinPasswordLength']??!0x0),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['meetsMaxPasswordLength']??!0x0),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['containsLowercaseLetter']??!0x0),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['containsUppercaseLetter']??!0x0),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['containsNumericCharacter']??!0x0),_0x1b87db['isValid']&&(_0x1b87db['isValid']=_0x1b87db['containsNonAlphanumericCharacter']??!0x0),_0x1b87db;}['validatePasswordLengthOptions'](_0x3da2b2,_0x51e153){const _0x3fc7ce=this['customStrengthOptions']['minPasswordLength'],_0x285ad8=this['customStrengthOptions']['maxPasswordLength'];_0x3fc7ce&&(_0x51e153['meetsMinPasswordLength']=_0x3da2b2['length']>=_0x3fc7ce),_0x285ad8&&(_0x51e153['meetsMaxPasswordLength']=_0x3da2b2['length']<=_0x285ad8);}['validatePasswordCharacterOptions'](_0x4d0243,_0x42905a){this['updatePasswordCharacterOptionsStatuses'](_0x42905a,!0x1,!0x1,!0x1,!0x1);let _0x282ad2;for(let _0x2efe04=0x0;_0x2efe04<_0x4d0243['length'];_0x2efe04++)_0x282ad2=_0x4d0243['charAt'](_0x2efe04),this['updatePasswordCharacterOptionsStatuses'](_0x42905a,_0x282ad2>='a'&&_0x282ad2<='z',_0x282ad2>='A'&&_0x282ad2<='Z',_0x282ad2>='0'&&_0x282ad2<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x282ad2));}['updatePasswordCharacterOptionsStatuses'](_0x5593c3,_0xd43779,_0x2706b0,_0x1e4852,_0x455944){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5593c3['containsLowercaseLetter']||(_0x5593c3['containsLowercaseLetter']=_0xd43779)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5593c3['containsUppercaseLetter']||(_0x5593c3['containsUppercaseLetter']=_0x2706b0)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5593c3['containsNumericCharacter']||(_0x5593c3['containsNumericCharacter']=_0x1e4852)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5593c3['containsNonAlphanumericCharacter']||(_0x5593c3['containsNonAlphanumericCharacter']=_0x455944));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x521c4b,_0x1f3b1f,_0x5b7bde,_0x18db15){this['app']=_0x521c4b,this['heartbeatServiceProvider']=_0x1f3b1f,this['appCheckServiceProvider']=_0x5b7bde,this['config']=_0x18db15,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x521c4b['name'],this['clientVersion']=_0x18db15['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4db0d9=>this['_resolvePersistenceManagerAvailable']=_0x4db0d9);}['_initializeWithPersistence'](_0x549ab5,_0x3d47a7){return _0x3d47a7&&(this['_popupRedirectResolver']=ne(_0x3d47a7)),this['_initializationPromise']=this['queue'](async()=>{var _0x4276c9,_0x42a978,_0x1e4161;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x549ab5),(_0x4276c9=this['_resolvePersistenceManagerAvailable'])==null||_0x4276c9['call'](this),!this['_deleted'])){if((_0x42a978=this['_popupRedirectResolver'])!=null&&_0x42a978['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3d47a7),this['lastNotifiedUid']=((_0x1e4161=this['currentUser'])==null?void 0x0:_0x1e4161['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4a0139=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4a0139)){if(this['currentUser']&&_0x4a0139&&this['currentUser']['uid']===_0x4a0139['uid']){this['_currentUser']['_assign'](_0x4a0139),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4a0139,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x13d077){try{const _0x2d2a12=await Sn(this,{'idToken':_0x13d077}),_0x3eb4e3=await z['_fromGetAccountInfoResponse'](this,_0x2d2a12,_0x13d077);await this['directlySetCurrentUser'](_0x3eb4e3);}catch(_0x44b93d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x44b93d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x517d37){var _0x18ca42;if(H(this['app'])){const _0x2b8bdd=this['app']['settings']['authIdToken'];return _0x2b8bdd?new Promise(_0x352f3c=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2b8bdd)['then'](_0x352f3c,_0x352f3c));}):this['directlySetCurrentUser'](null);}const _0xa02cb2=await this['assertedPersistence']['getCurrentUser']();let _0x3116fc=_0xa02cb2,_0xb9a936=!0x1;if(_0x517d37&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x57239a=(_0x18ca42=this['redirectUser'])==null?void 0x0:_0x18ca42['_redirectEventId'],_0x5d4d51=_0x3116fc==null?void 0x0:_0x3116fc['_redirectEventId'],_0x353559=await this['tryRedirectSignIn'](_0x517d37);(!_0x57239a||_0x57239a===_0x5d4d51)&&(_0x353559!=null&&_0x353559['user'])&&(_0x3116fc=_0x353559['user'],_0xb9a936=!0x0);}if(!_0x3116fc)return this['directlySetCurrentUser'](null);if(!_0x3116fc['_redirectEventId']){if(_0xb9a936)try{await this['beforeStateQueue']['runMiddleware'](_0x3116fc);}catch(_0x4aef51){_0x3116fc=_0xa02cb2,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4aef51));}return _0x3116fc?this['reloadAndSetCurrentUserOrClear'](_0x3116fc):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3116fc['_redirectEventId']?this['directlySetCurrentUser'](_0x3116fc):this['reloadAndSetCurrentUserOrClear'](_0x3116fc);}async['tryRedirectSignIn'](_0x69de8e){let _0x4924ec=null;try{_0x4924ec=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x69de8e,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4924ec;}async['reloadAndSetCurrentUserOrClear'](_0x5e0eb0){try{await bn(_0x5e0eb0);}catch(_0x32fc6c){if((_0x32fc6c==null?void 0x0:_0x32fc6c['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5e0eb0);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x573e1e){if(H(this['app']))return Promise['reject'](se(this));const _0x46288e=_0x573e1e?k(_0x573e1e):null;return _0x46288e&&m(_0x46288e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x46288e&&_0x46288e['_clone'](this));}async['_updateCurrentUser'](_0x48ae67,_0x1a9cd8=!0x1){if(!this['_deleted'])return _0x48ae67&&m(this['tenantId']===_0x48ae67['tenantId'],this,'tenant-id-mismatch'),_0x1a9cd8||await this['beforeStateQueue']['runMiddleware'](_0x48ae67),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x48ae67),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x26d922){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x26d922));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4b31c9){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0xe26fbd=this['_getPasswordPolicyInternal']();return _0xe26fbd['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0xe26fbd['validatePassword'](_0x4b31c9);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x59d94a=await Cf(this),_0x5ee3a1=new Sf(_0x59d94a);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5ee3a1:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5ee3a1;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x237047){this['_errorFactory']=new Ut('auth','Firebase',_0x237047());}['onAuthStateChanged'](_0x3d72b2,_0x4f1c25,_0x55747c){return this['registerStateListener'](this['authStateSubscription'],_0x3d72b2,_0x4f1c25,_0x55747c);}['beforeAuthStateChanged'](_0x4c3fd1,_0x1b07a1){return this['beforeStateQueue']['pushCallback'](_0x4c3fd1,_0x1b07a1);}['onIdTokenChanged'](_0x26c5c9,_0x2e435d,_0xafd7fc){return this['registerStateListener'](this['idTokenSubscription'],_0x26c5c9,_0x2e435d,_0xafd7fc);}['authStateReady'](){return new Promise((_0x27d3d5,_0x36b223)=>{if(this['currentUser'])_0x27d3d5();else{const _0x389138=this['onAuthStateChanged'](()=>{_0x389138(),_0x27d3d5();},_0x36b223);}});}async['revokeAccessToken'](_0x1c8d03){if(this['currentUser']){const _0xcfbfce=await this['currentUser']['getIdToken'](),_0x401020={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1c8d03,'idToken':_0xcfbfce};this['tenantId']!=null&&(_0x401020['tenantId']=this['tenantId']),await vf(this,_0x401020);}}['toJSON'](){var _0x14aac3;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x14aac3=this['_currentUser'])==null?void 0x0:_0x14aac3['toJSON']()};}async['_setRedirectUser'](_0x15afd4,_0x53f334){const _0x40d327=await this['getOrInitRedirectPersistenceManager'](_0x53f334);return _0x15afd4===null?_0x40d327['removeCurrentUser']():_0x40d327['setCurrentUser'](_0x15afd4);}async['getOrInitRedirectPersistenceManager'](_0x3e1c31){if(!this['redirectPersistenceManager']){const _0xdaa614=_0x3e1c31&&ne(_0x3e1c31)||this['_popupRedirectResolver'];m(_0xdaa614,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0xdaa614['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x229c4d){var _0x3c3aac,_0x4a0998;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3c3aac=this['_currentUser'])==null?void 0x0:_0x3c3aac['_redirectEventId'])===_0x229c4d?this['_currentUser']:((_0x4a0998=this['redirectUser'])==null?void 0x0:_0x4a0998['_redirectEventId'])===_0x229c4d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1c4f16){if(_0x1c4f16===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1c4f16));}['_notifyListenersIfCurrent'](_0x5253f5){_0x5253f5===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x22abad;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4442a7=((_0x22abad=this['currentUser'])==null?void 0x0:_0x22abad['uid'])??null;this['lastNotifiedUid']!==_0x4442a7&&(this['lastNotifiedUid']=_0x4442a7,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5f48df,_0x15a711,_0x5700da,_0x3b940c){if(this['_deleted'])return()=>{};const _0x6c3e36=typeof _0x15a711=='function'?_0x15a711:_0x15a711['next']['bind'](_0x15a711);let _0x31fdf8=!0x1;const _0x4e0c2e=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4e0c2e,this,'internal-error'),_0x4e0c2e['then'](()=>{_0x31fdf8||_0x6c3e36(this['currentUser']);}),typeof _0x15a711=='function'){const _0x4b5f82=_0x5f48df['addObserver'](_0x15a711,_0x5700da,_0x3b940c);return()=>{_0x31fdf8=!0x0,_0x4b5f82();};}else{const _0x34b68d=_0x5f48df['addObserver'](_0x15a711);return()=>{_0x31fdf8=!0x0,_0x34b68d();};}}async['directlySetCurrentUser'](_0xa5871){this['currentUser']&&this['currentUser']!==_0xa5871&&this['_currentUser']['_stopProactiveRefresh'](),_0xa5871&&this['isProactiveRefreshEnabled']&&_0xa5871['_startProactiveRefresh'](),this['currentUser']=_0xa5871,_0xa5871?await this['assertedPersistence']['setCurrentUser'](_0xa5871):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2c3868){return this['operations']=this['operations']['then'](_0x2c3868,_0x2c3868),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5d248d){!_0x5d248d||this['frameworks']['includes'](_0x5d248d)||(this['frameworks']['push'](_0x5d248d),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x37c587;const _0x4b5e90={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4b5e90['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4abb77=await((_0x37c587=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x37c587['getHeartbeatsHeader']());_0x4abb77&&(_0x4b5e90['X-Firebase-Client']=_0x4abb77);const _0xbb6248=await this['_getAppCheckToken']();return _0xbb6248&&(_0x4b5e90['X-Firebase-AppCheck']=_0xbb6248),_0x4b5e90;}async['_getAppCheckToken'](){var _0x48f8c3;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3ecc55=await((_0x48f8c3=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x48f8c3['getToken']());return _0x3ecc55!=null&&_0x3ecc55['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3ecc55['error']),_0x3ecc55==null?void 0x0:_0x3ecc55['token'];}}function qe(_0x148c67){return k(_0x148c67);}class Tr{constructor(_0x464823){this['auth']=_0x464823,this['observer']=null,this['addObserver']=Ic(_0xd185ac=>this['observer']=_0xd185ac);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x375c21){zn=_0x375c21;}function Da(_0x4cdcab){return zn['loadJS'](_0x4cdcab);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x3b46fe){return'__'+_0x3b46fe+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xe312fd){_0xe312fd();}['execute'](_0x2b2528,_0x1aff01){return Promise['resolve']('token');}['render'](_0x1a3841,_0x30e0f7){return'';}}class Of{['ready'](_0x656867){_0x656867();}['execute'](_0x307f11,_0x361ab6){return Promise['resolve']('token');}['render'](_0x370d5b,_0x8691e4){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x20d940){this['type']=Df,this['auth']=qe(_0x20d940);}async['verify'](_0xe187ad='verify',_0xcd2220=!0x1){async function _0x432dcd(_0x1dda12){if(!_0xcd2220){if(_0x1dda12['tenantId']==null&&_0x1dda12['_agentRecaptchaConfig']!=null)return _0x1dda12['_agentRecaptchaConfig']['siteKey'];if(_0x1dda12['tenantId']!=null&&_0x1dda12['_tenantRecaptchaConfigs'][_0x1dda12['tenantId']]!==void 0x0)return _0x1dda12['_tenantRecaptchaConfigs'][_0x1dda12['tenantId']]['siteKey'];}return new Promise(async(_0xa8bec1,_0x134ce2)=>{uf(_0x1dda12,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x5918e7=>{if(_0x5918e7['recaptchaKey']===void 0x0)_0x134ce2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4e7365=new hf(_0x5918e7);return _0x1dda12['tenantId']==null?_0x1dda12['_agentRecaptchaConfig']=_0x4e7365:_0x1dda12['_tenantRecaptchaConfigs'][_0x1dda12['tenantId']]=_0x4e7365,_0xa8bec1(_0x4e7365['siteKey']);}})['catch'](_0x6fd3ce=>{_0x134ce2(_0x6fd3ce);});});}function _0x3a793c(_0x18d426,_0x180bca,_0xa20f40){const _0x40713d=window['grecaptcha'];vr(_0x40713d)?_0x40713d['enterprise']['ready'](()=>{_0x40713d['enterprise']['execute'](_0x18d426,{'action':_0xe187ad})['then'](_0x993e5d=>{_0x180bca(_0x993e5d);})['catch'](()=>{_0x180bca(Ma);});}):_0xa20f40(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x28e999,_0x2a5262)=>{_0x432dcd(this['auth'])['then'](async _0x5563dd=>{if(!_0xcd2220&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3a793c(_0x5563dd,_0x28e999,_0x2a5262);else{if(typeof window>'u'){_0x2a5262(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3bc0bb=Af();_0x3bc0bb['length']!==0x0&&(_0x3bc0bb+=_0x5563dd+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x4b9a21;(_0x4b9a21=le['scriptInjectionDeferred'])==null||_0x4b9a21['resolve']();},Da(_0x3bc0bb)['then'](()=>{var _0x2354fb;return(_0x2354fb=le['scriptInjectionDeferred'])==null?void 0x0:_0x2354fb['promise'];})['then'](()=>{_0x3a793c(_0x5563dd,_0x28e999,_0x2a5262);})['catch'](_0x344dc2=>{_0x2a5262(_0x344dc2);});}})['catch'](_0x50f77f=>{_0x2a5262(_0x50f77f);});});}}le['scriptInjectionDeferred']=null;async function br(_0x4705f7,_0x303a11,_0x369008,_0x54c899=!0x1,_0x390e8c=!0x1){const _0x4e1c6c=new le(_0x4705f7);let _0x3335f0;if(_0x390e8c)_0x3335f0=Ma;else try{_0x3335f0=await _0x4e1c6c['verify'](_0x369008);}catch{_0x3335f0=await _0x4e1c6c['verify'](_0x369008,!0x0);}const _0x438e26={..._0x303a11};if(_0x369008==='mfaSmsEnrollment'||_0x369008==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x438e26){const _0x2246b2=_0x438e26['phoneEnrollmentInfo']['phoneNumber'],_0x3ba958=_0x438e26['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x438e26,{'phoneEnrollmentInfo':{'phoneNumber':_0x2246b2,'recaptchaToken':_0x3ba958,'captchaResponse':_0x3335f0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x438e26){const _0x23ecde=_0x438e26['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x438e26,{'phoneSignInInfo':{'recaptchaToken':_0x23ecde,'captchaResponse':_0x3335f0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x438e26;}return _0x54c899?Object['assign'](_0x438e26,{'captchaResp':_0x3335f0}):Object['assign'](_0x438e26,{'captchaResponse':_0x3335f0}),Object['assign'](_0x438e26,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x438e26,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x438e26;}async function Oi(_0x5f170b,_0x531de2,_0x1c3a2f,_0x237615,_0x166d63){var _0x9d7b7d;if((_0x9d7b7d=_0x5f170b['_getRecaptchaConfig']())!=null&&_0x9d7b7d['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1805d4=await br(_0x5f170b,_0x531de2,_0x1c3a2f,_0x1c3a2f==='getOobCode');return _0x237615(_0x5f170b,_0x1805d4);}else return _0x237615(_0x5f170b,_0x531de2)['catch'](async _0x1de12b=>{if(_0x1de12b['code']==='auth/missing-recaptcha-token'){console['log'](_0x1c3a2f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xa66e93=await br(_0x5f170b,_0x531de2,_0x1c3a2f,_0x1c3a2f==='getOobCode');return _0x237615(_0x5f170b,_0xa66e93);}else return Promise['reject'](_0x1de12b);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x5be558,_0x4fd843){const _0x667fc=Ui(_0x5be558,'auth');if(_0x667fc['isInitialized']()){const _0x5893f6=_0x667fc['getImmediate'](),_0x3d6a48=_0x667fc['getOptions']();if(De(_0x3d6a48,_0x4fd843??{}))return _0x5893f6;K(_0x5893f6,'already-initialized');}return _0x667fc['initialize']({'options':_0x4fd843});}function Lf(_0xfde46e,_0x45083b){const _0x1da060=(_0x45083b==null?void 0x0:_0x45083b['persistence'])||[],_0x349532=(Array['isArray'](_0x1da060)?_0x1da060:[_0x1da060])['map'](ne);_0x45083b!=null&&_0x45083b['errorMap']&&_0xfde46e['_updateErrorMap'](_0x45083b['errorMap']),_0xfde46e['_initializeWithPersistence'](_0x349532,_0x45083b==null?void 0x0:_0x45083b['popupRedirectResolver']);}function xf(_0x2c811c,_0x317d9f,_0x323f2d){const _0x31ae92=qe(_0x2c811c);m(/^https?:\/\//['test'](_0x317d9f),_0x31ae92,'invalid-emulator-scheme');const _0x24034b=!0x1,_0x2b0c3f=La(_0x317d9f),{host:_0x354539,port:_0x20f532}=Ff(_0x317d9f),_0x318601=_0x20f532===null?'':':'+_0x20f532,_0x63c3c={'url':_0x2b0c3f+'//'+_0x354539+_0x318601+'/'},_0x48661f=Object['freeze']({'host':_0x354539,'port':_0x20f532,'protocol':_0x2b0c3f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x24034b})});if(!_0x31ae92['_canInitEmulator']){m(_0x31ae92['config']['emulator']&&_0x31ae92['emulatorConfig'],_0x31ae92,'emulator-config-failed'),m(De(_0x63c3c,_0x31ae92['config']['emulator'])&&De(_0x48661f,_0x31ae92['emulatorConfig']),_0x31ae92,'emulator-config-failed');return;}_0x31ae92['config']['emulator']=_0x63c3c,_0x31ae92['emulatorConfig']=_0x48661f,_0x31ae92['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x354539)?jr(_0x2b0c3f+'//'+_0x354539+_0x318601):Uf();}function La(_0x30fbbf){const _0x2a6637=_0x30fbbf['indexOf'](':');return _0x2a6637<0x0?'':_0x30fbbf['substr'](0x0,_0x2a6637+0x1);}function Ff(_0x203a8e){const _0x3acd48=La(_0x203a8e),_0x2d7627=/(\/\/)?([^?#/]+)/['exec'](_0x203a8e['substr'](_0x3acd48['length']));if(!_0x2d7627)return{'host':'','port':null};const _0x3974be=_0x2d7627[0x2]['split']('@')['pop']()||'',_0x4d8c26=/^(\[[^\]]+\])(:|$)/['exec'](_0x3974be);if(_0x4d8c26){const _0x368273=_0x4d8c26[0x1];return{'host':_0x368273,'port':Rr(_0x3974be['substr'](_0x368273['length']+0x1))};}else{const [_0x4b1f63,_0xb5f4de]=_0x3974be['split'](':');return{'host':_0x4b1f63,'port':Rr(_0xb5f4de)};}}function Rr(_0x4ae0f4){if(!_0x4ae0f4)return null;const _0x5ba670=Number(_0x4ae0f4);return isNaN(_0x5ba670)?null:_0x5ba670;}function Uf(){function _0x47f054(){const _0x1f5982=document['createElement']('p'),_0x27d0d8=_0x1f5982['style'];_0x1f5982['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x27d0d8['position']='fixed',_0x27d0d8['width']='100%',_0x27d0d8['backgroundColor']='#ffffff',_0x27d0d8['border']='.1em\x20solid\x20#000000',_0x27d0d8['color']='#b50000',_0x27d0d8['bottom']='0px',_0x27d0d8['left']='0px',_0x27d0d8['margin']='0px',_0x27d0d8['zIndex']='10000',_0x27d0d8['textAlign']='center',_0x1f5982['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1f5982);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x47f054):_0x47f054());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x36f52c,_0x18f3a1){this['providerId']=_0x36f52c,this['signInMethod']=_0x18f3a1;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0xc8e35d){return te('not\x20implemented');}['_linkToIdToken'](_0x4e1929,_0x460d07){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x2c94c5){return te('not\x20implemented');}}async function Wf(_0x54b2df,_0x5319e6){return Ae(_0x54b2df,'POST','/v1/accounts:signUp',_0x5319e6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1ff525,_0x4afaa3){return Yt(_0x1ff525,'POST','/v1/accounts:signInWithPassword',Re(_0x1ff525,_0x4afaa3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x21d6b9,_0x1332d9){return Yt(_0x21d6b9,'POST','/v1/accounts:signInWithEmailLink',Re(_0x21d6b9,_0x1332d9));}async function Hf(_0x53ef05,_0x4a9897){return Yt(_0x53ef05,'POST','/v1/accounts:signInWithEmailLink',Re(_0x53ef05,_0x4a9897));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x5a5faf,_0x573592,_0x2857fb,_0xb5db0c=null){super('password',_0x2857fb),this['_email']=_0x5a5faf,this['_password']=_0x573592,this['_tenantId']=_0xb5db0c;}static['_fromEmailAndPassword'](_0x20c34d,_0x11a0a4){return new Ft(_0x20c34d,_0x11a0a4,'password');}static['_fromEmailAndCode'](_0xe65047,_0x2a0f7e,_0x3d1ff2=null){return new Ft(_0xe65047,_0x2a0f7e,'emailLink',_0x3d1ff2);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2d2aa8){const _0x480283=typeof _0x2d2aa8=='string'?JSON['parse'](_0x2d2aa8):_0x2d2aa8;if(_0x480283!=null&&_0x480283['email']&&(_0x480283!=null&&_0x480283['password'])){if(_0x480283['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x480283['email'],_0x480283['password']);if(_0x480283['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x480283['email'],_0x480283['password'],_0x480283['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5e5c6c){switch(this['signInMethod']){case'password':const _0x305d69={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5e5c6c,_0x305d69,'signInWithPassword',Bf);case'emailLink':return Vf(_0x5e5c6c,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x5e5c6c,'internal-error');}}async['_linkToIdToken'](_0x1e3fb1,_0x5f3795){switch(this['signInMethod']){case'password':const _0x4b232d={'idToken':_0x5f3795,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1e3fb1,_0x4b232d,'signUpPassword',Wf);case'emailLink':return Hf(_0x1e3fb1,{'idToken':_0x5f3795,'email':this['_email'],'oobCode':this['_password']});default:K(_0x1e3fb1,'internal-error');}}['_getReauthenticationResolver'](_0x414706){return this['_getIdTokenResponse'](_0x414706);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x280d40,_0x34036f){return Yt(_0x280d40,'POST','/v1/accounts:signInWithIdp',Re(_0x280d40,_0x34036f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2792bd){const _0x5560d6=new We(_0x2792bd['providerId'],_0x2792bd['signInMethod']);return _0x2792bd['idToken']||_0x2792bd['accessToken']?(_0x2792bd['idToken']&&(_0x5560d6['idToken']=_0x2792bd['idToken']),_0x2792bd['accessToken']&&(_0x5560d6['accessToken']=_0x2792bd['accessToken']),_0x2792bd['nonce']&&!_0x2792bd['pendingToken']&&(_0x5560d6['nonce']=_0x2792bd['nonce']),_0x2792bd['pendingToken']&&(_0x5560d6['pendingToken']=_0x2792bd['pendingToken'])):_0x2792bd['oauthToken']&&_0x2792bd['oauthTokenSecret']?(_0x5560d6['accessToken']=_0x2792bd['oauthToken'],_0x5560d6['secret']=_0x2792bd['oauthTokenSecret']):K('argument-error'),_0x5560d6;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x41c49e){const _0x2326b2=typeof _0x41c49e=='string'?JSON['parse'](_0x41c49e):_0x41c49e,{providerId:_0x3f12f4,signInMethod:_0x5bb85d,..._0x54d1b5}=_0x2326b2;if(!_0x3f12f4||!_0x5bb85d)return null;const _0x3374e0=new We(_0x3f12f4,_0x5bb85d);return _0x3374e0['idToken']=_0x54d1b5['idToken']||void 0x0,_0x3374e0['accessToken']=_0x54d1b5['accessToken']||void 0x0,_0x3374e0['secret']=_0x54d1b5['secret'],_0x3374e0['nonce']=_0x54d1b5['nonce'],_0x3374e0['pendingToken']=_0x54d1b5['pendingToken']||null,_0x3374e0;}['_getIdTokenResponse'](_0x3f113e){const _0x190faf=this['buildRequest']();return Ze(_0x3f113e,_0x190faf);}['_linkToIdToken'](_0x593d36,_0x2211d1){const _0x2221c0=this['buildRequest']();return _0x2221c0['idToken']=_0x2211d1,Ze(_0x593d36,_0x2221c0);}['_getReauthenticationResolver'](_0x1c3659){const _0x5ba991=this['buildRequest']();return _0x5ba991['autoCreate']=!0x1,Ze(_0x1c3659,_0x5ba991);}['buildRequest'](){const _0x1079b4={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1079b4['pendingToken']=this['pendingToken'];else{const _0x160914={};this['idToken']&&(_0x160914['id_token']=this['idToken']),this['accessToken']&&(_0x160914['access_token']=this['accessToken']),this['secret']&&(_0x160914['oauth_token_secret']=this['secret']),_0x160914['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x160914['nonce']=this['nonce']),_0x1079b4['postBody']=at(_0x160914);}return _0x1079b4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x58a8b1){switch(_0x58a8b1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x5335f0){const _0x104f4c=yt(vt(_0x5335f0))['link'],_0x22eb4b=_0x104f4c?yt(vt(_0x104f4c))['deep_link_id']:null,_0x47e088=yt(vt(_0x5335f0))['deep_link_id'];return(_0x47e088?yt(vt(_0x47e088))['link']:null)||_0x47e088||_0x22eb4b||_0x104f4c||_0x5335f0;}class Ss{constructor(_0x1b38c2){const _0x38ad1d=yt(vt(_0x1b38c2)),_0x46563c=_0x38ad1d['apiKey']??null,_0x480ed4=_0x38ad1d['oobCode']??null,_0x4d8e49=Gf(_0x38ad1d['mode']??null);m(_0x46563c&&_0x480ed4&&_0x4d8e49,'argument-error'),this['apiKey']=_0x46563c,this['operation']=_0x4d8e49,this['code']=_0x480ed4,this['continueUrl']=_0x38ad1d['continueUrl']??null,this['languageCode']=_0x38ad1d['lang']??null,this['tenantId']=_0x38ad1d['tenantId']??null;}static['parseLink'](_0x2967c6){const _0x3d21f1=qf(_0x2967c6);try{return new Ss(_0x3d21f1);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x471d00,_0xcb474){return Ft['_fromEmailAndPassword'](_0x471d00,_0xcb474);}static['credentialWithLink'](_0x2b595c,_0x257847){const _0xb16df6=Ss['parseLink'](_0x257847);return m(_0xb16df6,'argument-error'),Ft['_fromEmailAndCode'](_0x2b595c,_0xb16df6['code'],_0xb16df6['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x48c055){this['providerId']=_0x48c055,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4ad943){this['defaultLanguageCode']=_0x4ad943;}['setCustomParameters'](_0x5042a8){return this['customParameters']=_0x5042a8,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x1e8f20){return this['scopes']['includes'](_0x1e8f20)||this['scopes']['push'](_0x1e8f20),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x4164ab){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4164ab});}static['credentialFromResult'](_0x126765){return he['credentialFromTaggedObject'](_0x126765);}static['credentialFromError'](_0x177636){return he['credentialFromTaggedObject'](_0x177636['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x77f295}){if(!_0x77f295||!('oauthAccessToken'in _0x77f295)||!_0x77f295['oauthAccessToken'])return null;try{return he['credential'](_0x77f295['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x4f5719,_0x1e189f){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x4f5719,'accessToken':_0x1e189f});}static['credentialFromResult'](_0x270b4b){return ue['credentialFromTaggedObject'](_0x270b4b);}static['credentialFromError'](_0x4c6205){return ue['credentialFromTaggedObject'](_0x4c6205['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3c7679}){if(!_0x3c7679)return null;const {oauthIdToken:_0x4693e6,oauthAccessToken:_0x4b5ddc}=_0x3c7679;if(!_0x4693e6&&!_0x4b5ddc)return null;try{return ue['credential'](_0x4693e6,_0x4b5ddc);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x1e7ad4){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1e7ad4});}static['credentialFromResult'](_0x3fb2fe){return de['credentialFromTaggedObject'](_0x3fb2fe);}static['credentialFromError'](_0x3604cd){return de['credentialFromTaggedObject'](_0x3604cd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5a4f60}){if(!_0x5a4f60||!('oauthAccessToken'in _0x5a4f60)||!_0x5a4f60['oauthAccessToken'])return null;try{return de['credential'](_0x5a4f60['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x425402,_0x4e4faa){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x425402,'oauthTokenSecret':_0x4e4faa});}static['credentialFromResult'](_0x4f84b9){return fe['credentialFromTaggedObject'](_0x4f84b9);}static['credentialFromError'](_0xe2c16a){return fe['credentialFromTaggedObject'](_0xe2c16a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x247505}){if(!_0x247505)return null;const {oauthAccessToken:_0x5426d6,oauthTokenSecret:_0x2271d5}=_0x247505;if(!_0x5426d6||!_0x2271d5)return null;try{return fe['credential'](_0x5426d6,_0x2271d5);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x564f51,_0x13be06){return Yt(_0x564f51,'POST','/v1/accounts:signUp',Re(_0x564f51,_0x13be06));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x47cb61){this['user']=_0x47cb61['user'],this['providerId']=_0x47cb61['providerId'],this['_tokenResponse']=_0x47cb61['_tokenResponse'],this['operationType']=_0x47cb61['operationType'];}static async['_fromIdTokenResponse'](_0x20d501,_0x2bbbdb,_0x533f21,_0x5a74a0=!0x1){const _0x18dd30=await z['_fromIdTokenResponse'](_0x20d501,_0x533f21,_0x5a74a0),_0x57703d=Ar(_0x533f21);return new Be({'user':_0x18dd30,'providerId':_0x57703d,'_tokenResponse':_0x533f21,'operationType':_0x2bbbdb});}static async['_forOperation'](_0x49e9cc,_0x3f9457,_0x10a189){await _0x49e9cc['_updateTokensIfNecessary'](_0x10a189,!0x0);const _0x56a03e=Ar(_0x10a189);return new Be({'user':_0x49e9cc,'providerId':_0x56a03e,'_tokenResponse':_0x10a189,'operationType':_0x3f9457});}}function Ar(_0x4acf6b){return _0x4acf6b['providerId']?_0x4acf6b['providerId']:'phoneNumber'in _0x4acf6b?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x1068b3,_0x3db442,_0x46aa04,_0x9c0d5b){super(_0x3db442['code'],_0x3db442['message']),this['operationType']=_0x46aa04,this['user']=_0x9c0d5b,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x1068b3['name'],'tenantId':_0x1068b3['tenantId']??void 0x0,'_serverResponse':_0x3db442['customData']['_serverResponse'],'operationType':_0x46aa04};}static['_fromErrorAndOperation'](_0x17bc18,_0x3ca489,_0x176828,_0x355cf0){return new Rn(_0x17bc18,_0x3ca489,_0x176828,_0x355cf0);}}function Fa(_0x5d26a9,_0x3616b0,_0x332ec7,_0x1fd42d){return(_0x3616b0==='reauthenticate'?_0x332ec7['_getReauthenticationResolver'](_0x5d26a9):_0x332ec7['_getIdTokenResponse'](_0x5d26a9))['catch'](_0x1b0317=>{throw _0x1b0317['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x5d26a9,_0x1b0317,_0x3616b0,_0x1fd42d):_0x1b0317;});}async function jf(_0x3a382d,_0x42d53c,_0xeec147=!0x1){const _0x3240f1=await xt(_0x3a382d,_0x42d53c['_linkToIdToken'](_0x3a382d['auth'],await _0x3a382d['getIdToken']()),_0xeec147);return Be['_forOperation'](_0x3a382d,'link',_0x3240f1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xbc808e,_0x555f64,_0x43ff3d=!0x1){const {auth:_0x2ada2c}=_0xbc808e;if(H(_0x2ada2c['app']))return Promise['reject'](se(_0x2ada2c));const _0x5ba31f='reauthenticate';try{const _0x2c653b=await xt(_0xbc808e,Fa(_0x2ada2c,_0x5ba31f,_0x555f64,_0xbc808e),_0x43ff3d);m(_0x2c653b['idToken'],_0x2ada2c,'internal-error');const _0x4862a2=ws(_0x2c653b['idToken']);m(_0x4862a2,_0x2ada2c,'internal-error');const {sub:_0x2c69e8}=_0x4862a2;return m(_0xbc808e['uid']===_0x2c69e8,_0x2ada2c,'user-mismatch'),Be['_forOperation'](_0xbc808e,_0x5ba31f,_0x2c653b);}catch(_0x12d8a9){throw(_0x12d8a9==null?void 0x0:_0x12d8a9['code'])==='auth/user-not-found'&&K(_0x2ada2c,'user-mismatch'),_0x12d8a9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4efce2,_0x10868e,_0x2359bc=!0x1){if(H(_0x4efce2['app']))return Promise['reject'](se(_0x4efce2));const _0x2d1992='signIn',_0x1251ad=await Fa(_0x4efce2,_0x2d1992,_0x10868e),_0x14af44=await Be['_fromIdTokenResponse'](_0x4efce2,_0x2d1992,_0x1251ad);return _0x2359bc||await _0x4efce2['_updateCurrentUser'](_0x14af44['user']),_0x14af44;}async function Yf(_0x213c63,_0x1ae04a){return Ua(qe(_0x213c63),_0x1ae04a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x3003aa){const _0x48432d=qe(_0x3003aa);_0x48432d['_getPasswordPolicyInternal']()&&await _0x48432d['_updatePasswordPolicy']();}async function R_(_0x2fa0fa,_0x362fbb,_0x5b61e5){if(H(_0x2fa0fa['app']))return Promise['reject'](se(_0x2fa0fa));const _0x220a28=qe(_0x2fa0fa),_0x577f01=await Oi(_0x220a28,{'returnSecureToken':!0x0,'email':_0x362fbb,'password':_0x5b61e5,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x244551=>{throw _0x244551['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2fa0fa),_0x244551;}),_0x483179=await Be['_fromIdTokenResponse'](_0x220a28,'signIn',_0x577f01);return await _0x220a28['_updateCurrentUser'](_0x483179['user']),_0x483179;}function A_(_0x19befd,_0x139cf7,_0x13ca2b){return H(_0x19befd['app'])?Promise['reject'](se(_0x19befd)):Yf(k(_0x19befd),ft['credential'](_0x139cf7,_0x13ca2b))['catch'](async _0x406cd9=>{throw _0x406cd9['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x19befd),_0x406cd9;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x14e602,_0x141410){return k(_0x14e602)['setPersistence'](_0x141410);}function Qf(_0x431629,_0x18872a,_0x580dce,_0x59c5ea){return k(_0x431629)['onIdTokenChanged'](_0x18872a,_0x580dce,_0x59c5ea);}function Jf(_0x5050b9,_0x3e672d,_0x3fec7a){return k(_0x5050b9)['beforeAuthStateChanged'](_0x3e672d,_0x3fec7a);}function N_(_0x48f286,_0x54a762,_0x32ad76,_0x12c687){return k(_0x48f286)['onAuthStateChanged'](_0x54a762,_0x32ad76,_0x12c687);}function P_(_0x127722){return k(_0x127722)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x34595e,_0x400a81){this['storageRetriever']=_0x34595e,this['type']=_0x400a81;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5276fb,_0x2380e8){return this['storage']['setItem'](_0x5276fb,JSON['stringify'](_0x2380e8)),Promise['resolve']();}['_get'](_0x3b0213){const _0x4beed4=this['storage']['getItem'](_0x3b0213);return Promise['resolve'](_0x4beed4?JSON['parse'](_0x4beed4):null);}['_remove'](_0x359788){return this['storage']['removeItem'](_0x359788),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x125065,_0x573a57)=>this['onStorageEvent'](_0x125065,_0x573a57),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4bc95d){for(const _0x4b70a9 of Object['keys'](this['listeners'])){const _0x58a762=this['storage']['getItem'](_0x4b70a9),_0x3f0d8d=this['localCache'][_0x4b70a9];_0x58a762!==_0x3f0d8d&&_0x4bc95d(_0x4b70a9,_0x3f0d8d,_0x58a762);}}['onStorageEvent'](_0x46aa6e,_0x27cc3f=!0x1){if(!_0x46aa6e['key']){this['forAllChangedKeys']((_0x4f4f77,_0x5d7d29,_0x540fca)=>{this['notifyListeners'](_0x4f4f77,_0x540fca);});return;}const _0x4aa521=_0x46aa6e['key'];_0x27cc3f?this['detachListener']():this['stopPolling']();const _0x42ebee=()=>{const _0x5d2625=this['storage']['getItem'](_0x4aa521);!_0x27cc3f&&this['localCache'][_0x4aa521]===_0x5d2625||this['notifyListeners'](_0x4aa521,_0x5d2625);},_0x40fc2e=this['storage']['getItem'](_0x4aa521);If()&&_0x40fc2e!==_0x46aa6e['newValue']&&_0x46aa6e['newValue']!==_0x46aa6e['oldValue']?setTimeout(_0x42ebee,Zf):_0x42ebee();}['notifyListeners'](_0x5ac69e,_0x47aa23){this['localCache'][_0x5ac69e]=_0x47aa23;const _0x12a86d=this['listeners'][_0x5ac69e];if(_0x12a86d){for(const _0xe9e54c of Array['from'](_0x12a86d))_0xe9e54c(_0x47aa23&&JSON['parse'](_0x47aa23));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3fa86c,_0x13c887,_0x5bf46a)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3fa86c,'oldValue':_0x13c887,'newValue':_0x5bf46a}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2f6060,_0x2ca526){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2f6060]||(this['listeners'][_0x2f6060]=new Set(),this['localCache'][_0x2f6060]=this['storage']['getItem'](_0x2f6060)),this['listeners'][_0x2f6060]['add'](_0x2ca526);}['_removeListener'](_0x1cc107,_0x499bc4){this['listeners'][_0x1cc107]&&(this['listeners'][_0x1cc107]['delete'](_0x499bc4),this['listeners'][_0x1cc107]['size']===0x0&&delete this['listeners'][_0x1cc107]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x17a4d8,_0xbc1ebc){await super['_set'](_0x17a4d8,_0xbc1ebc),this['localCache'][_0x17a4d8]=JSON['stringify'](_0xbc1ebc);}async['_get'](_0x191c3c){const _0x1e0c21=await super['_get'](_0x191c3c);return this['localCache'][_0x191c3c]=JSON['stringify'](_0x1e0c21),_0x1e0c21;}async['_remove'](_0x40d686){await super['_remove'](_0x40d686),delete this['localCache'][_0x40d686];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x14cace,_0xd5b7e1){}['_removeListener'](_0x434018,_0x44ff12){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x3905df){return Promise['all'](_0x3905df['map'](async _0x33c376=>{try{return{'fulfilled':!0x0,'value':await _0x33c376};}catch(_0x1fcd73){return{'fulfilled':!0x1,'reason':_0x1fcd73};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x13458d){this['eventTarget']=_0x13458d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x52795a){const _0x12012e=this['receivers']['find'](_0x2cd8a0=>_0x2cd8a0['isListeningto'](_0x52795a));if(_0x12012e)return _0x12012e;const _0x23e813=new jn(_0x52795a);return this['receivers']['push'](_0x23e813),_0x23e813;}['isListeningto'](_0xf2cb40){return this['eventTarget']===_0xf2cb40;}async['handleEvent'](_0x469312){const _0x11afaa=_0x469312,{eventId:_0x10728f,eventType:_0x4580fc,data:_0x37ed2a}=_0x11afaa['data'],_0x24ace5=this['handlersMap'][_0x4580fc];if(!(_0x24ace5!=null&&_0x24ace5['size']))return;_0x11afaa['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x10728f,'eventType':_0x4580fc});const _0x1b644b=Array['from'](_0x24ace5)['map'](async _0x39292e=>_0x39292e(_0x11afaa['origin'],_0x37ed2a)),_0x3bd541=await tp(_0x1b644b);_0x11afaa['ports'][0x0]['postMessage']({'status':'done','eventId':_0x10728f,'eventType':_0x4580fc,'response':_0x3bd541});}['_subscribe'](_0x5cc45d,_0x2824b5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5cc45d]||(this['handlersMap'][_0x5cc45d]=new Set()),this['handlersMap'][_0x5cc45d]['add'](_0x2824b5);}['_unsubscribe'](_0x54e0b9,_0x168eb3){this['handlersMap'][_0x54e0b9]&&_0x168eb3&&this['handlersMap'][_0x54e0b9]['delete'](_0x168eb3),(!_0x168eb3||this['handlersMap'][_0x54e0b9]['size']===0x0)&&delete this['handlersMap'][_0x54e0b9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x5ea2ff='',_0x145248=0xa){let _0x14de27='';for(let _0x229c42=0x0;_0x229c42<_0x145248;_0x229c42++)_0x14de27+=Math['floor'](Math['random']()*0xa);return _0x5ea2ff+_0x14de27;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x404adc){this['target']=_0x404adc,this['handlers']=new Set();}['removeMessageHandler'](_0x1611b3){_0x1611b3['messageChannel']&&(_0x1611b3['messageChannel']['port1']['removeEventListener']('message',_0x1611b3['onMessage']),_0x1611b3['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1611b3);}async['_send'](_0xa9ab39,_0x1be093,_0x54c8ce=0x32){const _0x3b2ec2=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3b2ec2)throw new Error('connection_unavailable');let _0x270f25,_0x626988;return new Promise((_0x356100,_0x78f256)=>{const _0x3c690a=bs('',0x14);_0x3b2ec2['port1']['start']();const _0xd9d70b=setTimeout(()=>{_0x78f256(new Error('unsupported_event'));},_0x54c8ce);_0x626988={'messageChannel':_0x3b2ec2,'onMessage'(_0x1d2031){const _0x20be57=_0x1d2031;if(_0x20be57['data']['eventId']===_0x3c690a)switch(_0x20be57['data']['status']){case'ack':clearTimeout(_0xd9d70b),_0x270f25=setTimeout(()=>{_0x78f256(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x270f25),_0x356100(_0x20be57['data']['response']);break;default:clearTimeout(_0xd9d70b),clearTimeout(_0x270f25),_0x78f256(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x626988),_0x3b2ec2['port1']['addEventListener']('message',_0x626988['onMessage']),this['target']['postMessage']({'eventType':_0xa9ab39,'eventId':_0x3c690a,'data':_0x1be093},[_0x3b2ec2['port2']]);})['finally'](()=>{_0x626988&&this['removeMessageHandler'](_0x626988);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x1411c0){X()['location']['href']=_0x1411c0;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x57f5fb;return((_0x57f5fb=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x57f5fb['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5e4b21){this['request']=_0x5e4b21;}['toPromise'](){return new Promise((_0x5901cf,_0x466a5f)=>{this['request']['addEventListener']('success',()=>{_0x5901cf(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x466a5f(this['request']['error']);});});}}function Kn(_0x39c938,_0x4ff4d9){return _0x39c938['transaction']([kn],_0x4ff4d9?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0xb53e63=indexedDB['deleteDatabase'](qa);return new Jt(_0xb53e63)['toPromise']();}function ja(){const _0x3d941c=indexedDB['open'](qa,ap);return new Promise((_0x4f17ca,_0x4b610f)=>{_0x3d941c['addEventListener']('error',()=>{_0x4b610f(_0x3d941c['error']);}),_0x3d941c['addEventListener']('upgradeneeded',()=>{const _0x210c9e=_0x3d941c['result'];try{_0x210c9e['createObjectStore'](kn,{'keyPath':za});}catch(_0x18cf8e){_0x4b610f(_0x18cf8e);}}),_0x3d941c['addEventListener']('success',async()=>{const _0x110c86=_0x3d941c['result'];_0x110c86['objectStoreNames']['contains'](kn)?_0x4f17ca(_0x110c86):(_0x110c86['close'](),await cp(),_0x4f17ca(await ja()));});});}async function kr(_0xe0c4f2,_0x1657ea,_0x576073){const _0x573ad8=Kn(_0xe0c4f2,!0x0)['put']({[za]:_0x1657ea,'value':_0x576073});return new Jt(_0x573ad8)['toPromise']();}async function lp(_0x5119e8,_0x5eb5bb){const _0x176bb2=Kn(_0x5119e8,!0x1)['get'](_0x5eb5bb),_0x2b91b4=await new Jt(_0x176bb2)['toPromise']();return _0x2b91b4===void 0x0?null:_0x2b91b4['value'];}function Nr(_0x1727ea,_0x59ddc4){const _0x436e0f=Kn(_0x1727ea,!0x0)['delete'](_0x59ddc4);return new Jt(_0x436e0f)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x40d427){let _0x5e5bf3=0x0;for(;;)try{const _0x391757=await this['_openDb']();return await _0x40d427(_0x391757);}catch(_0x57aa6c){if(_0x5e5bf3++>up)throw _0x57aa6c;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x30b797,_0x4617f5)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4617f5['key'])})),this['receiver']['_subscribe']('ping',async(_0xbe51d6,_0x509faa)=>['keyChanged']);}async['initializeSender'](){var _0x3d9163,_0x3e4303;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4d5f3f=await this['sender']['_send']('ping',{},0x320);_0x4d5f3f&&(_0x3d9163=_0x4d5f3f[0x0])!=null&&_0x3d9163['fulfilled']&&(_0x3e4303=_0x4d5f3f[0x0])!=null&&_0x3e4303['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x45ffbb){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x45ffbb},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1b223f=>{await kr(_0x1b223f,An,'1'),await Nr(_0x1b223f,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x58ea85){this['pendingWrites']++;try{await _0x58ea85();}finally{this['pendingWrites']--;}}async['_set'](_0x1096cf,_0x37d189){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4e42aa=>kr(_0x4e42aa,_0x1096cf,_0x37d189)),this['localCache'][_0x1096cf]=_0x37d189,this['notifyServiceWorker'](_0x1096cf)));}async['_get'](_0x49cbe7){const _0x299711=await this['_withRetries'](_0x512099=>lp(_0x512099,_0x49cbe7));return this['localCache'][_0x49cbe7]=_0x299711,_0x299711;}async['_remove'](_0x595b6a){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x28108d=>Nr(_0x28108d,_0x595b6a)),delete this['localCache'][_0x595b6a],this['notifyServiceWorker'](_0x595b6a)));}async['_poll'](){const _0x5e9d31=await this['_withRetries'](_0x28ac6d=>{const _0x2dd0f6=Kn(_0x28ac6d,!0x1)['getAll']();return new Jt(_0x2dd0f6)['toPromise']();});if(!_0x5e9d31)return[];if(this['pendingWrites']!==0x0)return[];const _0x4c8ed2=[],_0x5ea110=new Set();if(_0x5e9d31['length']!==0x0){for(const {fbase_key:_0x376ac6,value:_0x347c60}of _0x5e9d31)_0x5ea110['add'](_0x376ac6),JSON['stringify'](this['localCache'][_0x376ac6])!==JSON['stringify'](_0x347c60)&&(this['notifyListeners'](_0x376ac6,_0x347c60),_0x4c8ed2['push'](_0x376ac6));}for(const _0x377745 of Object['keys'](this['localCache']))this['localCache'][_0x377745]&&!_0x5ea110['has'](_0x377745)&&(this['notifyListeners'](_0x377745,null),_0x4c8ed2['push'](_0x377745));return _0x4c8ed2;}['notifyListeners'](_0x3f62c3,_0x4fd072){this['localCache'][_0x3f62c3]=_0x4fd072;const _0x487bb6=this['listeners'][_0x3f62c3];if(_0x487bb6){for(const _0x3099ad of Array['from'](_0x487bb6))_0x3099ad(_0x4fd072);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x157830,_0x3521a5){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x157830]||(this['listeners'][_0x157830]=new Set(),this['_get'](_0x157830)),this['listeners'][_0x157830]['add'](_0x3521a5);}['_removeListener'](_0x21070e,_0x4ad4ff){this['listeners'][_0x21070e]&&(this['listeners'][_0x21070e]['delete'](_0x4ad4ff),this['listeners'][_0x21070e]['size']===0x0&&delete this['listeners'][_0x21070e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x13accc,_0x50da51){return _0x50da51?ne(_0x50da51):(m(_0x13accc['_popupRedirectResolver'],_0x13accc,'argument-error'),_0x13accc['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2bb05e){super('custom','custom'),this['params']=_0x2bb05e;}['_getIdTokenResponse'](_0x56a0aa){return Ze(_0x56a0aa,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4df614,_0x50f483){return Ze(_0x4df614,this['_buildIdpRequest'](_0x50f483));}['_getReauthenticationResolver'](_0x762a60){return Ze(_0x762a60,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x44c72c){const _0xb3860f={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x44c72c&&(_0xb3860f['idToken']=_0x44c72c),_0xb3860f;}}function pp(_0x59fd51){return Ua(_0x59fd51['auth'],new Rs(_0x59fd51),_0x59fd51['bypassAuthState']);}function _p(_0x1cc55f){const {auth:_0x42dde5,user:_0x36d17f}=_0x1cc55f;return m(_0x36d17f,_0x42dde5,'internal-error'),Kf(_0x36d17f,new Rs(_0x1cc55f),_0x1cc55f['bypassAuthState']);}async function gp(_0x25456e){const {auth:_0x1f38fb,user:_0x4a47f0}=_0x25456e;return m(_0x4a47f0,_0x1f38fb,'internal-error'),jf(_0x4a47f0,new Rs(_0x25456e),_0x25456e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x698bdc,_0x13bf03,_0x469416,_0x50bf22,_0x29a3c4=!0x1){this['auth']=_0x698bdc,this['resolver']=_0x469416,this['user']=_0x50bf22,this['bypassAuthState']=_0x29a3c4,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x13bf03)?_0x13bf03:[_0x13bf03];}['execute'](){return new Promise(async(_0x192c86,_0x5f5be2)=>{this['pendingPromise']={'resolve':_0x192c86,'reject':_0x5f5be2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x48ed25){this['reject'](_0x48ed25);}});}async['onAuthEvent'](_0x4e84ce){const {urlResponse:_0x52e4e5,sessionId:_0x4c4462,postBody:_0x51d5a3,tenantId:_0x54a8fd,error:_0x331ea8,type:_0x46c9e0}=_0x4e84ce;if(_0x331ea8){this['reject'](_0x331ea8);return;}const _0x31fde1={'auth':this['auth'],'requestUri':_0x52e4e5,'sessionId':_0x4c4462,'tenantId':_0x54a8fd||void 0x0,'postBody':_0x51d5a3||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x46c9e0)(_0x31fde1));}catch(_0xc68aa8){this['reject'](_0xc68aa8);}}['onError'](_0x2bf432){this['reject'](_0x2bf432);}['getIdpTask'](_0x5bcce3){switch(_0x5bcce3){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x4f4454){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4f4454),this['unregisterAndCleanUp']();}['reject'](_0x2b7863){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2b7863),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x5841d4,_0x3e337f,_0x5a5bdc,_0x23201c,_0x548ef2){super(_0x5841d4,_0x3e337f,_0x23201c,_0x548ef2),this['provider']=_0x5a5bdc,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xfca1c=await this['execute']();return m(_0xfca1c,this['auth'],'internal-error'),_0xfca1c;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3635c7=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3635c7),this['authWindow']['associatedEvent']=_0x3635c7,this['resolver']['_originValidation'](this['auth'])['catch'](_0x766c9c=>{this['reject'](_0x766c9c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5c6c14=>{_0x5c6c14||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x343fb2;return((_0x343fb2=this['authWindow'])==null?void 0x0:_0x343fb2['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xc05db1=()=>{var _0x255b7e,_0x4357d9;if((_0x4357d9=(_0x255b7e=this['authWindow'])==null?void 0x0:_0x255b7e['window'])!=null&&_0x4357d9['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xc05db1,mp['get']());};_0xc05db1();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0xab038b,_0x3291b8,_0x1cf0d1=!0x1){super(_0xab038b,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3291b8,void 0x0,_0x1cf0d1),this['eventId']=null;}async['execute'](){let _0x42b727=rn['get'](this['auth']['_key']());if(!_0x42b727){try{const _0x16642a=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x42b727=()=>Promise['resolve'](_0x16642a);}catch(_0x57ed55){_0x42b727=()=>Promise['reject'](_0x57ed55);}rn['set'](this['auth']['_key'](),_0x42b727);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x42b727();}async['onAuthEvent'](_0x465162){if(_0x465162['type']==='signInViaRedirect')return super['onAuthEvent'](_0x465162);if(_0x465162['type']==='unknown'){this['resolve'](null);return;}if(_0x465162['eventId']){const _0x700c4f=await this['auth']['_redirectUserForId'](_0x465162['eventId']);if(_0x700c4f)return this['user']=_0x700c4f,super['onAuthEvent'](_0x465162);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xff8ecc,_0x30a64b){const _0x3d37fb=Cp(_0x30a64b),_0x543bdb=wp(_0xff8ecc);if(!await _0x543bdb['_isAvailable']())return!0x1;const _0x14e905=await _0x543bdb['_get'](_0x3d37fb)==='true';return await _0x543bdb['_remove'](_0x3d37fb),_0x14e905;}function Ip(_0x36f8b6,_0xd55e5c){rn['set'](_0x36f8b6['_key'](),_0xd55e5c);}function wp(_0x44d9bc){return ne(_0x44d9bc['_redirectPersistence']);}function Cp(_0x4e1e4c){return sn(yp,_0x4e1e4c['config']['apiKey'],_0x4e1e4c['name']);}async function Tp(_0x592767,_0x5365a6,_0x34d9d9=!0x1){if(H(_0x592767['app']))return Promise['reject'](se(_0x592767));const _0x420626=qe(_0x592767),_0x434150=fp(_0x420626,_0x5365a6),_0x169c71=await new vp(_0x420626,_0x434150,_0x34d9d9)['execute']();return _0x169c71&&!_0x34d9d9&&(delete _0x169c71['user']['_redirectEventId'],await _0x420626['_persistUserIfCurrent'](_0x169c71['user']),await _0x420626['_setRedirectUser'](null,_0x5365a6)),_0x169c71;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x9de24c){this['auth']=_0x9de24c,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x39c1b5){this['consumers']['add'](_0x39c1b5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x39c1b5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x39c1b5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4f7852){this['consumers']['delete'](_0x4f7852);}['onEvent'](_0x4f6583){if(this['hasEventBeenHandled'](_0x4f6583))return!0x1;let _0x533506=!0x1;return this['consumers']['forEach'](_0x1936ef=>{this['isEventForConsumer'](_0x4f6583,_0x1936ef)&&(_0x533506=!0x0,this['sendToConsumer'](_0x4f6583,_0x1936ef),this['saveEventToCache'](_0x4f6583));}),this['hasHandledPotentialRedirect']||!Rp(_0x4f6583)||(this['hasHandledPotentialRedirect']=!0x0,_0x533506||(this['queuedRedirectEvent']=_0x4f6583,_0x533506=!0x0)),_0x533506;}['sendToConsumer'](_0x3dc560,_0x241c3c){var _0x370e8e;if(_0x3dc560['error']&&!Qa(_0x3dc560)){const _0x556601=((_0x370e8e=_0x3dc560['error']['code'])==null?void 0x0:_0x370e8e['split']('auth/')[0x1])||'internal-error';_0x241c3c['onError'](J(this['auth'],_0x556601));}else _0x241c3c['onAuthEvent'](_0x3dc560);}['isEventForConsumer'](_0x3e98d4,_0xd8c7e2){const _0x41bf91=_0xd8c7e2['eventId']===null||!!_0x3e98d4['eventId']&&_0x3e98d4['eventId']===_0xd8c7e2['eventId'];return _0xd8c7e2['filter']['includes'](_0x3e98d4['type'])&&_0x41bf91;}['hasEventBeenHandled'](_0x54b333){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x54b333));}['saveEventToCache'](_0x9a32ef){this['cachedEventUids']['add'](Pr(_0x9a32ef)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x5c7d53){return[_0x5c7d53['type'],_0x5c7d53['eventId'],_0x5c7d53['sessionId'],_0x5c7d53['tenantId']]['filter'](_0x4f91a1=>_0x4f91a1)['join']('-');}function Qa({type:_0x1f2dd6,error:_0x222f3d}){return _0x1f2dd6==='unknown'&&(_0x222f3d==null?void 0x0:_0x222f3d['code'])==='auth/no-auth-event';}function Rp(_0xa96ae3){switch(_0xa96ae3['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0xa96ae3);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x31c4f9,_0x1bb6d4={}){return Ae(_0x31c4f9,'GET','/v1/projects',_0x1bb6d4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x3585fc){if(_0x3585fc['config']['emulator'])return;const {authorizedDomains:_0x108a4c}=await Ap(_0x3585fc);for(const _0xd105f of _0x108a4c)try{if(Op(_0xd105f))return;}catch{}K(_0x3585fc,'unauthorized-domain');}function Op(_0x355f42){const _0x58c18d=Ni(),{protocol:_0x1beb6e,hostname:_0x236b36}=new URL(_0x58c18d);if(_0x355f42['startsWith']('chrome-extension://')){const _0x5b8bfd=new URL(_0x355f42);return _0x5b8bfd['hostname']===''&&_0x236b36===''?_0x1beb6e==='chrome-extension:'&&_0x355f42['replace']('chrome-extension://','')===_0x58c18d['replace']('chrome-extension://',''):_0x1beb6e==='chrome-extension:'&&_0x5b8bfd['hostname']===_0x236b36;}if(!Np['test'](_0x1beb6e))return!0x1;if(kp['test'](_0x355f42))return _0x236b36===_0x355f42;const _0x5cdabf=_0x355f42['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5cdabf+'|'+_0x5cdabf+')$','i')['test'](_0x236b36);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x1441a1=X()['___jsl'];if(_0x1441a1!=null&&_0x1441a1['H']){for(const _0x27f322 of Object['keys'](_0x1441a1['H']))if(_0x1441a1['H'][_0x27f322]['r']=_0x1441a1['H'][_0x27f322]['r']||[],_0x1441a1['H'][_0x27f322]['L']=_0x1441a1['H'][_0x27f322]['L']||[],_0x1441a1['H'][_0x27f322]['r']=[..._0x1441a1['H'][_0x27f322]['L']],_0x1441a1['CP']){for(let _0x316cd1=0x0;_0x316cd1<_0x1441a1['CP']['length'];_0x316cd1++)_0x1441a1['CP'][_0x316cd1]=null;}}}function Mp(_0x300501){return new Promise((_0x27acf7,_0x3b9694)=>{var _0x551060,_0x4e56d9,_0x407a24;function _0x210872(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x27acf7(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x3b9694(J(_0x300501,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x4e56d9=(_0x551060=X()['gapi'])==null?void 0x0:_0x551060['iframes'])!=null&&_0x4e56d9['Iframe'])_0x27acf7(gapi['iframes']['getContext']());else{if((_0x407a24=X()['gapi'])!=null&&_0x407a24['load'])_0x210872();else{const _0x24a6f7=Nf('iframefcb');return X()[_0x24a6f7]=()=>{gapi['load']?_0x210872():_0x3b9694(J(_0x300501,'network-request-failed'));},Da(kf()+'?onload='+_0x24a6f7)['catch'](_0x654648=>_0x3b9694(_0x654648));}}})['catch'](_0x2b05ba=>{throw on=null,_0x2b05ba;});}let on=null;function Lp(_0x4fd06a){return on=on||Mp(_0x4fd06a),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x1e7200){const _0x4e400c=_0x1e7200['config'];m(_0x4e400c['authDomain'],_0x1e7200,'auth-domain-config-required');const _0x1b6306=_0x4e400c['emulator']?Is(_0x4e400c,Up):'https://'+_0x1e7200['config']['authDomain']+'/'+Fp,_0x1f91d0={'apiKey':_0x4e400c['apiKey'],'appName':_0x1e7200['name'],'v':ct},_0x18e8b0=Bp['get'](_0x1e7200['config']['apiHost']);_0x18e8b0&&(_0x1f91d0['eid']=_0x18e8b0);const _0x3fd79d=_0x1e7200['_getFrameworks']();return _0x3fd79d['length']&&(_0x1f91d0['fw']=_0x3fd79d['join'](',')),_0x1b6306+'?'+at(_0x1f91d0)['slice'](0x1);}async function Hp(_0x168ce2){const _0x5b6958=await Lp(_0x168ce2),_0x3003bc=X()['gapi'];return m(_0x3003bc,_0x168ce2,'internal-error'),_0x5b6958['open']({'where':document['body'],'url':Vp(_0x168ce2),'messageHandlersFilter':_0x3003bc['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x54fc36=>new Promise(async(_0x456ac3,_0x113233)=>{await _0x54fc36['restyle']({'setHideOnLeave':!0x1});const _0x2ec91c=J(_0x168ce2,'network-request-failed'),_0x1ffebc=X()['setTimeout'](()=>{_0x113233(_0x2ec91c);},xp['get']());function _0x4a4b77(){X()['clearTimeout'](_0x1ffebc),_0x456ac3(_0x54fc36);}_0x54fc36['ping'](_0x4a4b77)['then'](_0x4a4b77,()=>{_0x113233(_0x2ec91c);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xe85cac){this['window']=_0xe85cac,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x225044,_0x3567f0,_0x3a6495,_0x1f2884=Gp,_0x5936ea=qp){const _0x10eef9=Math['max']((window['screen']['availHeight']-_0x5936ea)/0x2,0x0)['toString'](),_0x397426=Math['max']((window['screen']['availWidth']-_0x1f2884)/0x2,0x0)['toString']();let _0x46123a='';const _0x53928c={...$p,'width':_0x1f2884['toString'](),'height':_0x5936ea['toString'](),'top':_0x10eef9,'left':_0x397426},_0x455aeb=W()['toLowerCase']();_0x3a6495&&(_0x46123a=ba(_0x455aeb)?zp:_0x3a6495),Ta(_0x455aeb)&&(_0x3567f0=_0x3567f0||jp,_0x53928c['scrollbars']='yes');const _0x19a858=Object['entries'](_0x53928c)['reduce']((_0xef23bb,[_0x37a12f,_0x335364])=>''+_0xef23bb+_0x37a12f+'='+_0x335364+',','');if(Ef(_0x455aeb)&&_0x46123a!=='_self')return Yp(_0x3567f0||'',_0x46123a),new Dr(null);const _0x336a41=window['open'](_0x3567f0||'',_0x46123a,_0x19a858);m(_0x336a41,_0x225044,'popup-blocked');try{_0x336a41['focus']();}catch{}return new Dr(_0x336a41);}function Yp(_0xf0dd7b,_0x219161){const _0x4e29ec=document['createElement']('a');_0x4e29ec['href']=_0xf0dd7b,_0x4e29ec['target']=_0x219161;const _0x4119ed=document['createEvent']('MouseEvent');_0x4119ed['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4e29ec['dispatchEvent'](_0x4119ed);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0xed2d5a,_0x3d7ab9,_0x3362b5,_0x5614dd,_0x3ee2e9,_0x33dda5){m(_0xed2d5a['config']['authDomain'],_0xed2d5a,'auth-domain-config-required'),m(_0xed2d5a['config']['apiKey'],_0xed2d5a,'invalid-api-key');const _0x13dfd5={'apiKey':_0xed2d5a['config']['apiKey'],'appName':_0xed2d5a['name'],'authType':_0x3362b5,'redirectUrl':_0x5614dd,'v':ct,'eventId':_0x3ee2e9};if(_0x3d7ab9 instanceof xa){_0x3d7ab9['setDefaultLanguage'](_0xed2d5a['languageCode']),_0x13dfd5['providerId']=_0x3d7ab9['providerId']||'',hi(_0x3d7ab9['getCustomParameters']())||(_0x13dfd5['customParameters']=JSON['stringify'](_0x3d7ab9['getCustomParameters']()));for(const [_0x1e56df,_0x47a18d]of Object['entries']({}))_0x13dfd5[_0x1e56df]=_0x47a18d;}if(_0x3d7ab9 instanceof Qt){const _0xe42588=_0x3d7ab9['getScopes']()['filter'](_0x1e3e34=>_0x1e3e34!=='');_0xe42588['length']>0x0&&(_0x13dfd5['scopes']=_0xe42588['join'](','));}_0xed2d5a['tenantId']&&(_0x13dfd5['tid']=_0xed2d5a['tenantId']);const _0x2dfc11=_0x13dfd5;for(const _0x2a7fc7 of Object['keys'](_0x2dfc11))_0x2dfc11[_0x2a7fc7]===void 0x0&&delete _0x2dfc11[_0x2a7fc7];const _0x4c136c=await _0xed2d5a['_getAppCheckToken'](),_0x41e8eb=_0x4c136c?'#'+Xp+'='+encodeURIComponent(_0x4c136c):'';return Zp(_0xed2d5a)+'?'+at(_0x2dfc11)['slice'](0x1)+_0x41e8eb;}function Zp({config:_0x57a8b1}){return _0x57a8b1['emulator']?Is(_0x57a8b1,Jp):'https://'+_0x57a8b1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x2b6dff,_0x1a67b5,_0x5c7fa2,_0x449e73){var _0x43d652;ae((_0x43d652=this['eventManagers'][_0x2b6dff['_key']()])==null?void 0x0:_0x43d652['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x440dfc=await Mr(_0x2b6dff,_0x1a67b5,_0x5c7fa2,Ni(),_0x449e73);return Kp(_0x2b6dff,_0x440dfc,bs());}async['_openRedirect'](_0x4f06d7,_0x3a7a27,_0x8ce0d2,_0x11041a){await this['_originValidation'](_0x4f06d7);const _0x11e0bb=await Mr(_0x4f06d7,_0x3a7a27,_0x8ce0d2,Ni(),_0x11041a);return ip(_0x11e0bb),new Promise(()=>{});}['_initialize'](_0x3e6766){const _0x1df29a=_0x3e6766['_key']();if(this['eventManagers'][_0x1df29a]){const {manager:_0x44746f,promise:_0x255d1f}=this['eventManagers'][_0x1df29a];return _0x44746f?Promise['resolve'](_0x44746f):(ae(_0x255d1f,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x255d1f);}const _0x5f2ea7=this['initAndGetManager'](_0x3e6766);return this['eventManagers'][_0x1df29a]={'promise':_0x5f2ea7},_0x5f2ea7['catch'](()=>{delete this['eventManagers'][_0x1df29a];}),_0x5f2ea7;}async['initAndGetManager'](_0x23878e){const _0x2ca7b8=await Hp(_0x23878e),_0x44374c=new bp(_0x23878e);return _0x2ca7b8['register']('authEvent',_0x34239c=>(m(_0x34239c==null?void 0x0:_0x34239c['authEvent'],_0x23878e,'invalid-auth-event'),{'status':_0x44374c['onEvent'](_0x34239c['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x23878e['_key']()]={'manager':_0x44374c},this['iframes'][_0x23878e['_key']()]=_0x2ca7b8,_0x44374c;}['_isIframeWebStorageSupported'](_0x1f5ed4,_0x8d0439){this['iframes'][_0x1f5ed4['_key']()]['send'](li,{'type':li},_0x1224b3=>{var _0x1f09ae;const _0x27f6dc=(_0x1f09ae=_0x1224b3==null?void 0x0:_0x1224b3[0x0])==null?void 0x0:_0x1f09ae[li];_0x27f6dc!==void 0x0&&_0x8d0439(!!_0x27f6dc),K(_0x1f5ed4,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x407265){const _0xb28df2=_0x407265['_key']();return this['originValidationPromises'][_0xb28df2]||(this['originValidationPromises'][_0xb28df2]=Pp(_0x407265)),this['originValidationPromises'][_0xb28df2];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x17f6d6){this['auth']=_0x17f6d6,this['internalListeners']=new Map();}['getUid'](){var _0x3a1e34;return this['assertAuthConfigured'](),((_0x3a1e34=this['auth']['currentUser'])==null?void 0x0:_0x3a1e34['uid'])||null;}async['getToken'](_0x38f559){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x38f559)}:null;}['addAuthTokenListener'](_0x3bbbc7){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3bbbc7))return;const _0x48af69=this['auth']['onIdTokenChanged'](_0x2ebbad=>{_0x3bbbc7((_0x2ebbad==null?void 0x0:_0x2ebbad['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3bbbc7,_0x48af69),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1302b7){this['assertAuthConfigured']();const _0x56db3a=this['internalListeners']['get'](_0x1302b7);_0x56db3a&&(this['internalListeners']['delete'](_0x1302b7),_0x56db3a(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x4ec82d){switch(_0x4ec82d){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x1df332){et(new Me('auth',(_0x315a20,{options:_0xbf3233})=>{const _0x2a9042=_0x315a20['getProvider']('app')['getImmediate'](),_0x35c848=_0x315a20['getProvider']('heartbeat'),_0x2bf599=_0x315a20['getProvider']('app-check-internal'),{apiKey:_0x40b484,authDomain:_0x49876f}=_0x2a9042['options'];m(_0x40b484&&!_0x40b484['includes'](':'),'invalid-api-key',{'appName':_0x2a9042['name']});const _0xed233={'apiKey':_0x40b484,'authDomain':_0x49876f,'clientPlatform':_0x1df332,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x1df332)},_0xae9c88=new bf(_0x2a9042,_0x35c848,_0x2bf599,_0xed233);return Lf(_0xae9c88,_0xbf3233),_0xae9c88;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x587470,_0x2382e0,_0x4c9782)=>{_0x587470['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0xc341b4=>{const _0x31f909=qe(_0xc341b4['getProvider']('auth')['getImmediate']());return(_0x165fd8=>new n_(_0x165fd8))(_0x31f909);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x1df332)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x1b6c07=>async _0x582f3e=>{const _0x530b9b=_0x582f3e&&await _0x582f3e['getIdTokenResult'](),_0x5b8733=_0x530b9b&&(new Date()['getTime']()-Date['parse'](_0x530b9b['issuedAtTime']))/0x3e8;if(_0x5b8733&&_0x5b8733>o_)return;const _0x20a8d8=_0x530b9b==null?void 0x0:_0x530b9b['token'];Fr!==_0x20a8d8&&(Fr=_0x20a8d8,await fetch(_0x1b6c07,{'method':_0x20a8d8?'POST':'DELETE','headers':_0x20a8d8?{'Authorization':'Bearer\x20'+_0x20a8d8}:{}}));};function O_(_0x335e63=Qr()){const _0x50d811=Ui(_0x335e63,'auth');if(_0x50d811['isInitialized']())return _0x50d811['getImmediate']();const _0x4ccd07=Mf(_0x335e63,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x591f95=Gr('authTokenSyncURL');if(_0x591f95&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5df029=new URL(_0x591f95,location['origin']);if(location['origin']===_0x5df029['origin']){const _0x380d8e=a_(_0x5df029['toString']());Jf(_0x4ccd07,_0x380d8e,()=>_0x380d8e(_0x4ccd07['currentUser'])),Qf(_0x4ccd07,_0x2d9b71=>_0x380d8e(_0x2d9b71));}}const _0x366258=Hr('auth');return _0x366258&&xf(_0x4ccd07,'http://'+_0x366258),_0x4ccd07;}function c_(){var _0x14a91c;return((_0x14a91c=document['getElementsByTagName']('head'))==null?void 0x0:_0x14a91c[0x0])??document;}Rf({'loadJS'(_0xd36be1){return new Promise((_0x46be87,_0x599af2)=>{const _0x13f47f=document['createElement']('script');_0x13f47f['setAttribute']('src',_0xd36be1),_0x13f47f['onload']=_0x46be87,_0x13f47f['onerror']=_0x4efe2f=>{const _0x43dcec=J('internal-error');_0x43dcec['customData']=_0x4efe2f,_0x599af2(_0x43dcec);},_0x13f47f['type']='text/javascript',_0x13f47f['charset']='UTF-8',c_()['appendChild'](_0x13f47f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};