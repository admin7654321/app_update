const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x272a53,_0x2196d3){if(!_0x272a53)throw ot(_0x2196d3);},ot=function(_0x1dbe16){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1dbe16);},Wr=function(_0x3a422a){const _0x4bbe7d=[];let _0x359c5a=0x0;for(let _0x4a48cd=0x0;_0x4a48cd<_0x3a422a['length'];_0x4a48cd++){let _0x15fdba=_0x3a422a['charCodeAt'](_0x4a48cd);_0x15fdba<0x80?_0x4bbe7d[_0x359c5a++]=_0x15fdba:_0x15fdba<0x800?(_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0x6|0xc0,_0x4bbe7d[_0x359c5a++]=_0x15fdba&0x3f|0x80):(_0x15fdba&0xfc00)===0xd800&&_0x4a48cd+0x1<_0x3a422a['length']&&(_0x3a422a['charCodeAt'](_0x4a48cd+0x1)&0xfc00)===0xdc00?(_0x15fdba=0x10000+((_0x15fdba&0x3ff)<<0xa)+(_0x3a422a['charCodeAt'](++_0x4a48cd)&0x3ff),_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0x12|0xf0,_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0xc&0x3f|0x80,_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0x6&0x3f|0x80,_0x4bbe7d[_0x359c5a++]=_0x15fdba&0x3f|0x80):(_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0xc|0xe0,_0x4bbe7d[_0x359c5a++]=_0x15fdba>>0x6&0x3f|0x80,_0x4bbe7d[_0x359c5a++]=_0x15fdba&0x3f|0x80);}return _0x4bbe7d;},Za=function(_0x319436){const _0x55748f=[];let _0x44820=0x0,_0x891bb3=0x0;for(;_0x44820<_0x319436['length'];){const _0x42a237=_0x319436[_0x44820++];if(_0x42a237<0x80)_0x55748f[_0x891bb3++]=String['fromCharCode'](_0x42a237);else{if(_0x42a237>0xbf&&_0x42a237<0xe0){const _0x47216b=_0x319436[_0x44820++];_0x55748f[_0x891bb3++]=String['fromCharCode']((_0x42a237&0x1f)<<0x6|_0x47216b&0x3f);}else{if(_0x42a237>0xef&&_0x42a237<0x16d){const _0x548d0e=_0x319436[_0x44820++],_0x48403d=_0x319436[_0x44820++],_0x33a985=_0x319436[_0x44820++],_0x5a3e06=((_0x42a237&0x7)<<0x12|(_0x548d0e&0x3f)<<0xc|(_0x48403d&0x3f)<<0x6|_0x33a985&0x3f)-0x10000;_0x55748f[_0x891bb3++]=String['fromCharCode'](0xd800+(_0x5a3e06>>0xa)),_0x55748f[_0x891bb3++]=String['fromCharCode'](0xdc00+(_0x5a3e06&0x3ff));}else{const _0x5dfbfc=_0x319436[_0x44820++],_0x133544=_0x319436[_0x44820++];_0x55748f[_0x891bb3++]=String['fromCharCode']((_0x42a237&0xf)<<0xc|(_0x5dfbfc&0x3f)<<0x6|_0x133544&0x3f);}}}}return _0x55748f['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x41b3bb,_0x13a221){if(!Array['isArray'](_0x41b3bb))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xf94abf=_0x13a221?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x6434ad=[];for(let _0xd8615d=0x0;_0xd8615d<_0x41b3bb['length'];_0xd8615d+=0x3){const _0x3d64a9=_0x41b3bb[_0xd8615d],_0xf7bb4c=_0xd8615d+0x1<_0x41b3bb['length'],_0x243a69=_0xf7bb4c?_0x41b3bb[_0xd8615d+0x1]:0x0,_0x46605c=_0xd8615d+0x2<_0x41b3bb['length'],_0x3d1273=_0x46605c?_0x41b3bb[_0xd8615d+0x2]:0x0,_0x33760d=_0x3d64a9>>0x2,_0x418809=(_0x3d64a9&0x3)<<0x4|_0x243a69>>0x4;let _0x45f19d=(_0x243a69&0xf)<<0x2|_0x3d1273>>0x6,_0x32e66b=_0x3d1273&0x3f;_0x46605c||(_0x32e66b=0x40,_0xf7bb4c||(_0x45f19d=0x40)),_0x6434ad['push'](_0xf94abf[_0x33760d],_0xf94abf[_0x418809],_0xf94abf[_0x45f19d],_0xf94abf[_0x32e66b]);}return _0x6434ad['join']('');},'encodeString'(_0x1e7d2d,_0x1361ea){return this['HAS_NATIVE_SUPPORT']&&!_0x1361ea?btoa(_0x1e7d2d):this['encodeByteArray'](Wr(_0x1e7d2d),_0x1361ea);},'decodeString'(_0xbc0ec9,_0xbeeaf1){return this['HAS_NATIVE_SUPPORT']&&!_0xbeeaf1?atob(_0xbc0ec9):Za(this['decodeStringToByteArray'](_0xbc0ec9,_0xbeeaf1));},'decodeStringToByteArray'(_0x5a75b3,_0x58ea02){this['init_']();const _0x33e385=_0x58ea02?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x21afc0=[];for(let _0x2fff37=0x0;_0x2fff37<_0x5a75b3['length'];){const _0x1478f9=_0x33e385[_0x5a75b3['charAt'](_0x2fff37++)],_0xbcd4b7=_0x2fff37<_0x5a75b3['length']?_0x33e385[_0x5a75b3['charAt'](_0x2fff37)]:0x0;++_0x2fff37;const _0xe8132f=_0x2fff37<_0x5a75b3['length']?_0x33e385[_0x5a75b3['charAt'](_0x2fff37)]:0x40;++_0x2fff37;const _0x3e597e=_0x2fff37<_0x5a75b3['length']?_0x33e385[_0x5a75b3['charAt'](_0x2fff37)]:0x40;if(++_0x2fff37,_0x1478f9==null||_0xbcd4b7==null||_0xe8132f==null||_0x3e597e==null)throw new ec();const _0x30a323=_0x1478f9<<0x2|_0xbcd4b7>>0x4;if(_0x21afc0['push'](_0x30a323),_0xe8132f!==0x40){const _0x1449e1=_0xbcd4b7<<0x4&0xf0|_0xe8132f>>0x2;if(_0x21afc0['push'](_0x1449e1),_0x3e597e!==0x40){const _0x36ad98=_0xe8132f<<0x6&0xc0|_0x3e597e;_0x21afc0['push'](_0x36ad98);}}}return _0x21afc0;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xcefda7=0x0;_0xcefda7<this['ENCODED_VALS']['length'];_0xcefda7++)this['byteToCharMap_'][_0xcefda7]=this['ENCODED_VALS']['charAt'](_0xcefda7),this['charToByteMap_'][this['byteToCharMap_'][_0xcefda7]]=_0xcefda7,this['byteToCharMapWebSafe_'][_0xcefda7]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xcefda7),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xcefda7]]=_0xcefda7,_0xcefda7>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xcefda7)]=_0xcefda7,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xcefda7)]=_0xcefda7);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x456f28){const _0x32141f=Wr(_0x456f28);return Di['encodeByteArray'](_0x32141f,!0x0);},an=function(_0x4a9f88){return Br(_0x4a9f88)['replace'](/\./g,'');},cn=function(_0x4df6ed){try{return Di['decodeString'](_0x4df6ed,!0x0);}catch(_0x2d221c){console['error']('base64Decode\x20failed:\x20',_0x2d221c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x296a5b){return Vr(void 0x0,_0x296a5b);}function Vr(_0x4cf1c5,_0x333ae9){if(!(_0x333ae9 instanceof Object))return _0x333ae9;switch(_0x333ae9['constructor']){case Date:const _0x21b8aa=_0x333ae9;return new Date(_0x21b8aa['getTime']());case Object:_0x4cf1c5===void 0x0&&(_0x4cf1c5={});break;case Array:_0x4cf1c5=[];break;default:return _0x333ae9;}for(const _0x21147e in _0x333ae9)!_0x333ae9['hasOwnProperty'](_0x21147e)||!nc(_0x21147e)||(_0x4cf1c5[_0x21147e]=Vr(_0x4cf1c5[_0x21147e],_0x333ae9[_0x21147e]));return _0x4cf1c5;}function nc(_0x4146db){return _0x4146db!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x423826=As['__FIREBASE_DEFAULTS__'];if(_0x423826)return JSON['parse'](_0x423826);},oc=()=>{if(typeof document>'u')return;let _0x1373af;try{_0x1373af=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5a0104=_0x1373af&&cn(_0x1373af[0x1]);return _0x5a0104&&JSON['parse'](_0x5a0104);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x26ca56){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x26ca56);return;}},Hr=_0x929fc9=>{var _0x796bcd,_0x2b0f7c;return(_0x2b0f7c=(_0x796bcd=Mi())==null?void 0x0:_0x796bcd['emulatorHosts'])==null?void 0x0:_0x2b0f7c[_0x929fc9];},ac=_0x24a75c=>{const _0x45477e=Hr(_0x24a75c);if(!_0x45477e)return;const _0x474fa4=_0x45477e['lastIndexOf'](':');if(_0x474fa4<=0x0||_0x474fa4+0x1===_0x45477e['length'])throw new Error('Invalid\x20host\x20'+_0x45477e+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x27c6e6=parseInt(_0x45477e['substring'](_0x474fa4+0x1),0xa);return _0x45477e[0x0]==='['?[_0x45477e['substring'](0x1,_0x474fa4-0x1),_0x27c6e6]:[_0x45477e['substring'](0x0,_0x474fa4),_0x27c6e6];},$r=()=>{var _0x1687c4;return(_0x1687c4=Mi())==null?void 0x0:_0x1687c4['config'];},Gr=_0x5a45f1=>{var _0x4e5429;return(_0x4e5429=Mi())==null?void 0x0:_0x4e5429['_'+_0x5a45f1];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x114cbb,_0x35a15a)=>{this['resolve']=_0x114cbb,this['reject']=_0x35a15a;});}['wrapCallback'](_0x1f975f){return(_0x37bcf2,_0x4073d4)=>{_0x37bcf2?this['reject'](_0x37bcf2):this['resolve'](_0x4073d4),typeof _0x1f975f=='function'&&(this['promise']['catch'](()=>{}),_0x1f975f['length']===0x1?_0x1f975f(_0x37bcf2):_0x1f975f(_0x37bcf2,_0x4073d4));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3d71a2,_0x1d376a){if(_0x3d71a2['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5c5994={'alg':'none','type':'JWT'},_0xa2cdfe=_0x1d376a||'demo-project',_0x29a34c=_0x3d71a2['iat']||0x0,_0x210229=_0x3d71a2['sub']||_0x3d71a2['user_id'];if(!_0x210229)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5a1d09={'iss':'https://securetoken.google.com/'+_0xa2cdfe,'aud':_0xa2cdfe,'iat':_0x29a34c,'exp':_0x29a34c+0xe10,'auth_time':_0x29a34c,'sub':_0x210229,'user_id':_0x210229,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3d71a2};return[an(JSON['stringify'](_0x5c5994)),an(JSON['stringify'](_0x5a1d09)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x330f23=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x330f23=='object'&&_0x330f23['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x5ca8ae=W();return _0x5ca8ae['indexOf']('MSIE\x20')>=0x0||_0x5ca8ae['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x4f4468,_0x4001cf)=>{try{let _0x4e6375=!0x0;const _0x2b62f8='validate-browser-context-for-indexeddb-analytics-module',_0x5902d5=self['indexedDB']['open'](_0x2b62f8);_0x5902d5['onsuccess']=()=>{_0x5902d5['result']['close'](),_0x4e6375||self['indexedDB']['deleteDatabase'](_0x2b62f8),_0x4f4468(!0x0);},_0x5902d5['onupgradeneeded']=()=>{_0x4e6375=!0x1;},_0x5902d5['onerror']=()=>{var _0x35edcd;_0x4001cf(((_0x35edcd=_0x5902d5['error'])==null?void 0x0:_0x35edcd['message'])||'');};}catch(_0x5549af){_0x4001cf(_0x5549af);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x5dc619,_0x4eeb0f,_0x2be6b3){super(_0x4eeb0f),this['code']=_0x5dc619,this['customData']=_0x2be6b3,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x593ae7,_0x196148,_0x10e8cf){this['service']=_0x593ae7,this['serviceName']=_0x196148,this['errors']=_0x10e8cf;}['create'](_0x373755,..._0x7ed293){const _0x3e726c=_0x7ed293[0x0]||{},_0x402b05=this['service']+'/'+_0x373755,_0x19a28f=this['errors'][_0x373755],_0x522cfc=_0x19a28f?gc(_0x19a28f,_0x3e726c):'Error',_0x1b8178=this['serviceName']+':\x20'+_0x522cfc+'\x20('+_0x402b05+').';return new Se(_0x402b05,_0x1b8178,_0x3e726c);}}function gc(_0x2d9862,_0x5df43e){return _0x2d9862['replace'](mc,(_0x2ae5de,_0x5c1471)=>{const _0x2bdeff=_0x5df43e[_0x5c1471];return _0x2bdeff!=null?String(_0x2bdeff):'<'+_0x5c1471+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x57b8a7){return JSON['parse'](_0x57b8a7);}function O(_0x4198c8){return JSON['stringify'](_0x4198c8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x44dac1){let _0x13e2dd={},_0x29090a={},_0x4ff68d={},_0x10f329='';try{const _0x59ce83=_0x44dac1['split']('.');_0x13e2dd=bt(cn(_0x59ce83[0x0])||''),_0x29090a=bt(cn(_0x59ce83[0x1])||''),_0x10f329=_0x59ce83[0x2],_0x4ff68d=_0x29090a['d']||{},delete _0x29090a['d'];}catch{}return{'header':_0x13e2dd,'claims':_0x29090a,'data':_0x4ff68d,'signature':_0x10f329};},yc=function(_0x5d37e6){const _0x5e88dd=zr(_0x5d37e6),_0x565bbe=_0x5e88dd['claims'];return!!_0x565bbe&&typeof _0x565bbe=='object'&&_0x565bbe['hasOwnProperty']('iat');},vc=function(_0x21d70d){const _0x228421=zr(_0x21d70d)['claims'];return typeof _0x228421=='object'&&_0x228421['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x14b9fc,_0xa67b16){return Object['prototype']['hasOwnProperty']['call'](_0x14b9fc,_0xa67b16);}function Oe(_0x216802,_0x7e4719){if(Object['prototype']['hasOwnProperty']['call'](_0x216802,_0x7e4719))return _0x216802[_0x7e4719];}function hi(_0x30dbce){for(const _0x34c2c8 in _0x30dbce)if(Object['prototype']['hasOwnProperty']['call'](_0x30dbce,_0x34c2c8))return!0x1;return!0x0;}function ln(_0x31d9da,_0x391b94,_0x26b7ee){const _0x2b8fd5={};for(const _0x2c2e0c in _0x31d9da)Object['prototype']['hasOwnProperty']['call'](_0x31d9da,_0x2c2e0c)&&(_0x2b8fd5[_0x2c2e0c]=_0x391b94['call'](_0x26b7ee,_0x31d9da[_0x2c2e0c],_0x2c2e0c,_0x31d9da));return _0x2b8fd5;}function De(_0x9ee0f2,_0x4e3edb){if(_0x9ee0f2===_0x4e3edb)return!0x0;const _0x42c8fa=Object['keys'](_0x9ee0f2),_0x4f9137=Object['keys'](_0x4e3edb);for(const _0x58e6fb of _0x42c8fa){if(!_0x4f9137['includes'](_0x58e6fb))return!0x1;const _0x39db37=_0x9ee0f2[_0x58e6fb],_0x157bee=_0x4e3edb[_0x58e6fb];if(ks(_0x39db37)&&ks(_0x157bee)){if(!De(_0x39db37,_0x157bee))return!0x1;}else{if(_0x39db37!==_0x157bee)return!0x1;}}for(const _0xa6d6c2 of _0x4f9137)if(!_0x42c8fa['includes'](_0xa6d6c2))return!0x1;return!0x0;}function ks(_0x1f2178){return _0x1f2178!==null&&typeof _0x1f2178=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5312be){const _0x1ab38c=[];for(const [_0x5ada20,_0x146b95]of Object['entries'](_0x5312be))Array['isArray'](_0x146b95)?_0x146b95['forEach'](_0x2265e2=>{_0x1ab38c['push'](encodeURIComponent(_0x5ada20)+'='+encodeURIComponent(_0x2265e2));}):_0x1ab38c['push'](encodeURIComponent(_0x5ada20)+'='+encodeURIComponent(_0x146b95));return _0x1ab38c['length']?'&'+_0x1ab38c['join']('&'):'';}function yt(_0x3c10e7){const _0x3cbd53={};return _0x3c10e7['replace'](/^\?/,'')['split']('&')['forEach'](_0x3e0a43=>{if(_0x3e0a43){const [_0x36f534,_0x56d04b]=_0x3e0a43['split']('=');_0x3cbd53[decodeURIComponent(_0x36f534)]=decodeURIComponent(_0x56d04b);}}),_0x3cbd53;}function vt(_0x20f4cf){const _0x14a407=_0x20f4cf['indexOf']('?');if(!_0x14a407)return'';const _0x2ee1ce=_0x20f4cf['indexOf']('#',_0x14a407);return _0x20f4cf['substring'](_0x14a407,_0x2ee1ce>0x0?_0x2ee1ce:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5b8cc2=0x1;_0x5b8cc2<this['blockSize'];++_0x5b8cc2)this['pad_'][_0x5b8cc2]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xb3f7d3,_0x1da702){_0x1da702||(_0x1da702=0x0);const _0x26df88=this['W_'];if(typeof _0xb3f7d3=='string'){for(let _0x234fb8=0x0;_0x234fb8<0x10;_0x234fb8++)_0x26df88[_0x234fb8]=_0xb3f7d3['charCodeAt'](_0x1da702)<<0x18|_0xb3f7d3['charCodeAt'](_0x1da702+0x1)<<0x10|_0xb3f7d3['charCodeAt'](_0x1da702+0x2)<<0x8|_0xb3f7d3['charCodeAt'](_0x1da702+0x3),_0x1da702+=0x4;}else{for(let _0x26a4a5=0x0;_0x26a4a5<0x10;_0x26a4a5++)_0x26df88[_0x26a4a5]=_0xb3f7d3[_0x1da702]<<0x18|_0xb3f7d3[_0x1da702+0x1]<<0x10|_0xb3f7d3[_0x1da702+0x2]<<0x8|_0xb3f7d3[_0x1da702+0x3],_0x1da702+=0x4;}for(let _0x3204fb=0x10;_0x3204fb<0x50;_0x3204fb++){const _0x219a0b=_0x26df88[_0x3204fb-0x3]^_0x26df88[_0x3204fb-0x8]^_0x26df88[_0x3204fb-0xe]^_0x26df88[_0x3204fb-0x10];_0x26df88[_0x3204fb]=(_0x219a0b<<0x1|_0x219a0b>>>0x1f)&0xffffffff;}let _0xd63d74=this['chain_'][0x0],_0x18ba6e=this['chain_'][0x1],_0x32a575=this['chain_'][0x2],_0x1a6ca9=this['chain_'][0x3],_0x40e30b=this['chain_'][0x4],_0x30d56d,_0x3c12c3;for(let _0x2c5c26=0x0;_0x2c5c26<0x50;_0x2c5c26++){_0x2c5c26<0x28?_0x2c5c26<0x14?(_0x30d56d=_0x1a6ca9^_0x18ba6e&(_0x32a575^_0x1a6ca9),_0x3c12c3=0x5a827999):(_0x30d56d=_0x18ba6e^_0x32a575^_0x1a6ca9,_0x3c12c3=0x6ed9eba1):_0x2c5c26<0x3c?(_0x30d56d=_0x18ba6e&_0x32a575|_0x1a6ca9&(_0x18ba6e|_0x32a575),_0x3c12c3=0x8f1bbcdc):(_0x30d56d=_0x18ba6e^_0x32a575^_0x1a6ca9,_0x3c12c3=0xca62c1d6);const _0x26df05=(_0xd63d74<<0x5|_0xd63d74>>>0x1b)+_0x30d56d+_0x40e30b+_0x3c12c3+_0x26df88[_0x2c5c26]&0xffffffff;_0x40e30b=_0x1a6ca9,_0x1a6ca9=_0x32a575,_0x32a575=(_0x18ba6e<<0x1e|_0x18ba6e>>>0x2)&0xffffffff,_0x18ba6e=_0xd63d74,_0xd63d74=_0x26df05;}this['chain_'][0x0]=this['chain_'][0x0]+_0xd63d74&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x18ba6e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x32a575&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1a6ca9&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x40e30b&0xffffffff;}['update'](_0x12e93d,_0x1f0dd5){if(_0x12e93d==null)return;_0x1f0dd5===void 0x0&&(_0x1f0dd5=_0x12e93d['length']);const _0x16b1a0=_0x1f0dd5-this['blockSize'];let _0x2c6a1c=0x0;const _0x41b90c=this['buf_'];let _0xfd01c9=this['inbuf_'];for(;_0x2c6a1c<_0x1f0dd5;){if(_0xfd01c9===0x0){for(;_0x2c6a1c<=_0x16b1a0;)this['compress_'](_0x12e93d,_0x2c6a1c),_0x2c6a1c+=this['blockSize'];}if(typeof _0x12e93d=='string'){for(;_0x2c6a1c<_0x1f0dd5;)if(_0x41b90c[_0xfd01c9]=_0x12e93d['charCodeAt'](_0x2c6a1c),++_0xfd01c9,++_0x2c6a1c,_0xfd01c9===this['blockSize']){this['compress_'](_0x41b90c),_0xfd01c9=0x0;break;}}else{for(;_0x2c6a1c<_0x1f0dd5;)if(_0x41b90c[_0xfd01c9]=_0x12e93d[_0x2c6a1c],++_0xfd01c9,++_0x2c6a1c,_0xfd01c9===this['blockSize']){this['compress_'](_0x41b90c),_0xfd01c9=0x0;break;}}}this['inbuf_']=_0xfd01c9,this['total_']+=_0x1f0dd5;}['digest'](){const _0x3732c0=[];let _0x3bffa=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x12a198=this['blockSize']-0x1;_0x12a198>=0x38;_0x12a198--)this['buf_'][_0x12a198]=_0x3bffa&0xff,_0x3bffa/=0x100;this['compress_'](this['buf_']);let _0x49c9d0=0x0;for(let _0x2cd15e=0x0;_0x2cd15e<0x5;_0x2cd15e++)for(let _0x5b1bed=0x18;_0x5b1bed>=0x0;_0x5b1bed-=0x8)_0x3732c0[_0x49c9d0]=this['chain_'][_0x2cd15e]>>_0x5b1bed&0xff,++_0x49c9d0;return _0x3732c0;}}function Ic(_0x2bf402,_0x3cb89b){const _0xbdcdcd=new wc(_0x2bf402,_0x3cb89b);return _0xbdcdcd['subscribe']['bind'](_0xbdcdcd);}class wc{constructor(_0x227fcf,_0x29f886){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x29f886,this['task']['then'](()=>{_0x227fcf(this);})['catch'](_0x2f4df0=>{this['error'](_0x2f4df0);});}['next'](_0x50af4b){this['forEachObserver'](_0x16ab95=>{_0x16ab95['next'](_0x50af4b);});}['error'](_0x3964d8){this['forEachObserver'](_0x12457a=>{_0x12457a['error'](_0x3964d8);}),this['close'](_0x3964d8);}['complete'](){this['forEachObserver'](_0x4c03fb=>{_0x4c03fb['complete']();}),this['close']();}['subscribe'](_0x411619,_0x11463d,_0x18bff2){let _0x3147e6;if(_0x411619===void 0x0&&_0x11463d===void 0x0&&_0x18bff2===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x411619,['next','error','complete'])?_0x3147e6=_0x411619:_0x3147e6={'next':_0x411619,'error':_0x11463d,'complete':_0x18bff2},_0x3147e6['next']===void 0x0&&(_0x3147e6['next']=Qn),_0x3147e6['error']===void 0x0&&(_0x3147e6['error']=Qn),_0x3147e6['complete']===void 0x0&&(_0x3147e6['complete']=Qn);const _0x19ef0a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3147e6['error'](this['finalError']):_0x3147e6['complete']();}catch{}}),this['observers']['push'](_0x3147e6),_0x19ef0a;}['unsubscribeOne'](_0x5b80e8){this['observers']===void 0x0||this['observers'][_0x5b80e8]===void 0x0||(delete this['observers'][_0x5b80e8],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x52da09){if(!this['finalized']){for(let _0x460ae1=0x0;_0x460ae1<this['observers']['length'];_0x460ae1++)this['sendOne'](_0x460ae1,_0x52da09);}}['sendOne'](_0x365392,_0x370a47){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x365392]!==void 0x0)try{_0x370a47(this['observers'][_0x365392]);}catch(_0x51f533){typeof console<'u'&&console['error']&&console['error'](_0x51f533);}});}['close'](_0x2bdc5d){this['finalized']||(this['finalized']=!0x0,_0x2bdc5d!==void 0x0&&(this['finalError']=_0x2bdc5d),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0xddfe7,_0x41a6ae){if(typeof _0xddfe7!='object'||_0xddfe7===null)return!0x1;for(const _0x5055f7 of _0x41a6ae)if(_0x5055f7 in _0xddfe7&&typeof _0xddfe7[_0x5055f7]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x1c61a4,_0x4401d3){return _0x1c61a4+'\x20failed:\x20'+_0x4401d3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x38ed73){const _0x38abc8=[];let _0x422620=0x0;for(let _0x2984b3=0x0;_0x2984b3<_0x38ed73['length'];_0x2984b3++){let _0x2b2a62=_0x38ed73['charCodeAt'](_0x2984b3);if(_0x2b2a62>=0xd800&&_0x2b2a62<=0xdbff){const _0x34a04e=_0x2b2a62-0xd800;_0x2984b3++,f(_0x2984b3<_0x38ed73['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5454b6=_0x38ed73['charCodeAt'](_0x2984b3)-0xdc00;_0x2b2a62=0x10000+(_0x34a04e<<0xa)+_0x5454b6;}_0x2b2a62<0x80?_0x38abc8[_0x422620++]=_0x2b2a62:_0x2b2a62<0x800?(_0x38abc8[_0x422620++]=_0x2b2a62>>0x6|0xc0,_0x38abc8[_0x422620++]=_0x2b2a62&0x3f|0x80):_0x2b2a62<0x10000?(_0x38abc8[_0x422620++]=_0x2b2a62>>0xc|0xe0,_0x38abc8[_0x422620++]=_0x2b2a62>>0x6&0x3f|0x80,_0x38abc8[_0x422620++]=_0x2b2a62&0x3f|0x80):(_0x38abc8[_0x422620++]=_0x2b2a62>>0x12|0xf0,_0x38abc8[_0x422620++]=_0x2b2a62>>0xc&0x3f|0x80,_0x38abc8[_0x422620++]=_0x2b2a62>>0x6&0x3f|0x80,_0x38abc8[_0x422620++]=_0x2b2a62&0x3f|0x80);}return _0x38abc8;},Pn=function(_0x1b42ce){let _0x1f82cd=0x0;for(let _0x13640d=0x0;_0x13640d<_0x1b42ce['length'];_0x13640d++){const _0x4c2b0=_0x1b42ce['charCodeAt'](_0x13640d);_0x4c2b0<0x80?_0x1f82cd++:_0x4c2b0<0x800?_0x1f82cd+=0x2:_0x4c2b0>=0xd800&&_0x4c2b0<=0xdbff?(_0x1f82cd+=0x4,_0x13640d++):_0x1f82cd+=0x3;}return _0x1f82cd;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x152e8e){return _0x152e8e&&_0x152e8e['_delegate']?_0x152e8e['_delegate']:_0x152e8e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x3f9d4a){try{return(_0x3f9d4a['startsWith']('http://')||_0x3f9d4a['startsWith']('https://')?new URL(_0x3f9d4a)['hostname']:_0x3f9d4a)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x4ef82d){return(await fetch(_0x4ef82d,{'credentials':'include'}))['ok'];}class Me{constructor(_0x53ba53,_0x553fa1,_0x3f3a3c){this['name']=_0x53ba53,this['instanceFactory']=_0x553fa1,this['type']=_0x3f3a3c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x41749f){return this['instantiationMode']=_0x41749f,this;}['setMultipleInstances'](_0x385ac3){return this['multipleInstances']=_0x385ac3,this;}['setServiceProps'](_0xea9abe){return this['serviceProps']=_0xea9abe,this;}['setInstanceCreatedCallback'](_0x3edbf5){return this['onInstanceCreated']=_0x3edbf5,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x1f24aa,_0x10ddab){this['name']=_0x1f24aa,this['container']=_0x10ddab,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3f6869){const _0x35193e=this['normalizeInstanceIdentifier'](_0x3f6869);if(!this['instancesDeferred']['has'](_0x35193e)){const _0x20439f=new Ve();if(this['instancesDeferred']['set'](_0x35193e,_0x20439f),this['isInitialized'](_0x35193e)||this['shouldAutoInitialize']())try{const _0x1e3090=this['getOrInitializeService']({'instanceIdentifier':_0x35193e});_0x1e3090&&_0x20439f['resolve'](_0x1e3090);}catch{}}return this['instancesDeferred']['get'](_0x35193e)['promise'];}['getImmediate'](_0x4a4bad){const _0x545516=this['normalizeInstanceIdentifier'](_0x4a4bad==null?void 0x0:_0x4a4bad['identifier']),_0x5e20b6=(_0x4a4bad==null?void 0x0:_0x4a4bad['optional'])??!0x1;if(this['isInitialized'](_0x545516)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x545516});}catch(_0x1d1c73){if(_0x5e20b6)return null;throw _0x1d1c73;}else{if(_0x5e20b6)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x13b5de){if(_0x13b5de['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x13b5de['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x13b5de,!!this['shouldAutoInitialize']()){if(Rc(_0x13b5de))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x181f2c,_0x1596ce]of this['instancesDeferred']['entries']()){const _0x2f9e3f=this['normalizeInstanceIdentifier'](_0x181f2c);try{const _0x2666e4=this['getOrInitializeService']({'instanceIdentifier':_0x2f9e3f});_0x1596ce['resolve'](_0x2666e4);}catch{}}}}['clearInstance'](_0x1fa778=ke){this['instancesDeferred']['delete'](_0x1fa778),this['instancesOptions']['delete'](_0x1fa778),this['instances']['delete'](_0x1fa778);}async['delete'](){const _0x753d2d=Array['from'](this['instances']['values']());await Promise['all']([..._0x753d2d['filter'](_0x438d0f=>'INTERNAL'in _0x438d0f)['map'](_0x1a487c=>_0x1a487c['INTERNAL']['delete']()),..._0x753d2d['filter'](_0x8ce1ae=>'_delete'in _0x8ce1ae)['map'](_0x1837d8=>_0x1837d8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x62b8ea=ke){return this['instances']['has'](_0x62b8ea);}['getOptions'](_0x4f96e4=ke){return this['instancesOptions']['get'](_0x4f96e4)||{};}['initialize'](_0x2efebb={}){const {options:_0x48fd0b={}}=_0x2efebb,_0x435d58=this['normalizeInstanceIdentifier'](_0x2efebb['instanceIdentifier']);if(this['isInitialized'](_0x435d58))throw Error(this['name']+'('+_0x435d58+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x209531=this['getOrInitializeService']({'instanceIdentifier':_0x435d58,'options':_0x48fd0b});for(const [_0xe5b95c,_0x221263]of this['instancesDeferred']['entries']()){const _0x33da72=this['normalizeInstanceIdentifier'](_0xe5b95c);_0x435d58===_0x33da72&&_0x221263['resolve'](_0x209531);}return _0x209531;}['onInit'](_0x5dffdf,_0x3eccbc){const _0x289a88=this['normalizeInstanceIdentifier'](_0x3eccbc),_0x1bb9b9=this['onInitCallbacks']['get'](_0x289a88)??new Set();_0x1bb9b9['add'](_0x5dffdf),this['onInitCallbacks']['set'](_0x289a88,_0x1bb9b9);const _0x2b2978=this['instances']['get'](_0x289a88);return _0x2b2978&&_0x5dffdf(_0x2b2978,_0x289a88),()=>{_0x1bb9b9['delete'](_0x5dffdf);};}['invokeOnInitCallbacks'](_0x29d28d,_0x4cbb9b){const _0x436817=this['onInitCallbacks']['get'](_0x4cbb9b);if(_0x436817){for(const _0x484b9e of _0x436817)try{_0x484b9e(_0x29d28d,_0x4cbb9b);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xadcdf,options:_0x10f416={}}){let _0x4dcfce=this['instances']['get'](_0xadcdf);if(!_0x4dcfce&&this['component']&&(_0x4dcfce=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xadcdf),'options':_0x10f416}),this['instances']['set'](_0xadcdf,_0x4dcfce),this['instancesOptions']['set'](_0xadcdf,_0x10f416),this['invokeOnInitCallbacks'](_0x4dcfce,_0xadcdf),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xadcdf,_0x4dcfce);}catch{}return _0x4dcfce||null;}['normalizeInstanceIdentifier'](_0x5d6368=ke){return this['component']?this['component']['multipleInstances']?_0x5d6368:ke:_0x5d6368;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x406cd7){return _0x406cd7===ke?void 0x0:_0x406cd7;}function Rc(_0x26e32e){return _0x26e32e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x23739b){this['name']=_0x23739b,this['providers']=new Map();}['addComponent'](_0x430dc4){const _0x3beb73=this['getProvider'](_0x430dc4['name']);if(_0x3beb73['isComponentSet']())throw new Error('Component\x20'+_0x430dc4['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3beb73['setComponent'](_0x430dc4);}['addOrOverwriteComponent'](_0x2391c5){this['getProvider'](_0x2391c5['name'])['isComponentSet']()&&this['providers']['delete'](_0x2391c5['name']),this['addComponent'](_0x2391c5);}['getProvider'](_0xf18386){if(this['providers']['has'](_0xf18386))return this['providers']['get'](_0xf18386);const _0x263b22=new Sc(_0xf18386,this);return this['providers']['set'](_0xf18386,_0x263b22),_0x263b22;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x39d808){_0x39d808[_0x39d808['DEBUG']=0x0]='DEBUG',_0x39d808[_0x39d808['VERBOSE']=0x1]='VERBOSE',_0x39d808[_0x39d808['INFO']=0x2]='INFO',_0x39d808[_0x39d808['WARN']=0x3]='WARN',_0x39d808[_0x39d808['ERROR']=0x4]='ERROR',_0x39d808[_0x39d808['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x5295e9,_0x119157,..._0x25cc3f)=>{if(_0x119157<_0x5295e9['logLevel'])return;const _0x5b3d70=new Date()['toISOString'](),_0x4518c0=Pc[_0x119157];if(_0x4518c0)console[_0x4518c0]('['+_0x5b3d70+']\x20\x20'+_0x5295e9['name']+':',..._0x25cc3f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x119157+')');};class xi{constructor(_0x569b13){this['name']=_0x569b13,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4f6ddd){if(!(_0x4f6ddd in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4f6ddd+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4f6ddd;}['setLogLevel'](_0x1d4031){this['_logLevel']=typeof _0x1d4031=='string'?kc[_0x1d4031]:_0x1d4031;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2dcc36){if(typeof _0x2dcc36!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2dcc36;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2b09d5){this['_userLogHandler']=_0x2b09d5;}['debug'](..._0x300152){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x300152),this['_logHandler'](this,T['DEBUG'],..._0x300152);}['log'](..._0x64d5f8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x64d5f8),this['_logHandler'](this,T['VERBOSE'],..._0x64d5f8);}['info'](..._0x5693d4){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5693d4),this['_logHandler'](this,T['INFO'],..._0x5693d4);}['warn'](..._0x128621){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x128621),this['_logHandler'](this,T['WARN'],..._0x128621);}['error'](..._0x727d67){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x727d67),this['_logHandler'](this,T['ERROR'],..._0x727d67);}}const Dc=(_0x130e90,_0x35a131)=>_0x35a131['some'](_0x2a3b8f=>_0x130e90 instanceof _0x2a3b8f);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x20f055){const _0x4673df=new Promise((_0x1507ea,_0xbd73e)=>{const _0x19b457=()=>{_0x20f055['removeEventListener']('success',_0x238849),_0x20f055['removeEventListener']('error',_0x19a30e);},_0x238849=()=>{_0x1507ea(_e(_0x20f055['result'])),_0x19b457();},_0x19a30e=()=>{_0xbd73e(_0x20f055['error']),_0x19b457();};_0x20f055['addEventListener']('success',_0x238849),_0x20f055['addEventListener']('error',_0x19a30e);});return _0x4673df['then'](_0x42fa1f=>{_0x42fa1f instanceof IDBCursor&&Kr['set'](_0x42fa1f,_0x20f055);})['catch'](()=>{}),Fi['set'](_0x4673df,_0x20f055),_0x4673df;}function Fc(_0x413b1e){if(ui['has'](_0x413b1e))return;const _0x58a469=new Promise((_0x5a4b08,_0x143b28)=>{const _0x18ff08=()=>{_0x413b1e['removeEventListener']('complete',_0x87f727),_0x413b1e['removeEventListener']('error',_0x5aad85),_0x413b1e['removeEventListener']('abort',_0x5aad85);},_0x87f727=()=>{_0x5a4b08(),_0x18ff08();},_0x5aad85=()=>{_0x143b28(_0x413b1e['error']||new DOMException('AbortError','AbortError')),_0x18ff08();};_0x413b1e['addEventListener']('complete',_0x87f727),_0x413b1e['addEventListener']('error',_0x5aad85),_0x413b1e['addEventListener']('abort',_0x5aad85);});ui['set'](_0x413b1e,_0x58a469);}let di={'get'(_0x129ea7,_0x5386a,_0x1b6d79){if(_0x129ea7 instanceof IDBTransaction){if(_0x5386a==='done')return ui['get'](_0x129ea7);if(_0x5386a==='objectStoreNames')return _0x129ea7['objectStoreNames']||Yr['get'](_0x129ea7);if(_0x5386a==='store')return _0x1b6d79['objectStoreNames'][0x1]?void 0x0:_0x1b6d79['objectStore'](_0x1b6d79['objectStoreNames'][0x0]);}return _e(_0x129ea7[_0x5386a]);},'set'(_0x489b27,_0x560472,_0x81931f){return _0x489b27[_0x560472]=_0x81931f,!0x0;},'has'(_0x106091,_0x227035){return _0x106091 instanceof IDBTransaction&&(_0x227035==='done'||_0x227035==='store')?!0x0:_0x227035 in _0x106091;}};function Uc(_0x2b44c4){di=_0x2b44c4(di);}function Wc(_0x11b8bb){return _0x11b8bb===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x11169f,..._0x217ad2){const _0x1c0f13=_0x11b8bb['call'](Xn(this),_0x11169f,..._0x217ad2);return Yr['set'](_0x1c0f13,_0x11169f['sort']?_0x11169f['sort']():[_0x11169f]),_e(_0x1c0f13);}:Lc()['includes'](_0x11b8bb)?function(..._0x4ebc6f){return _0x11b8bb['apply'](Xn(this),_0x4ebc6f),_e(Kr['get'](this));}:function(..._0x3d99fc){return _e(_0x11b8bb['apply'](Xn(this),_0x3d99fc));};}function Bc(_0x438811){return typeof _0x438811=='function'?Wc(_0x438811):(_0x438811 instanceof IDBTransaction&&Fc(_0x438811),Dc(_0x438811,Mc())?new Proxy(_0x438811,di):_0x438811);}function _e(_0xe25d50){if(_0xe25d50 instanceof IDBRequest)return xc(_0xe25d50);if(Jn['has'](_0xe25d50))return Jn['get'](_0xe25d50);const _0x5a2462=Bc(_0xe25d50);return _0x5a2462!==_0xe25d50&&(Jn['set'](_0xe25d50,_0x5a2462),Fi['set'](_0x5a2462,_0xe25d50)),_0x5a2462;}const Xn=_0x53eee9=>Fi['get'](_0x53eee9);function Vc(_0x17fc88,_0x4de9c3,{blocked:_0x578298,upgrade:_0x33ca69,blocking:_0x575b2a,terminated:_0x311435}={}){const _0x18fb1b=indexedDB['open'](_0x17fc88,_0x4de9c3),_0x287ea0=_e(_0x18fb1b);return _0x33ca69&&_0x18fb1b['addEventListener']('upgradeneeded',_0x4aaad8=>{_0x33ca69(_e(_0x18fb1b['result']),_0x4aaad8['oldVersion'],_0x4aaad8['newVersion'],_e(_0x18fb1b['transaction']),_0x4aaad8);}),_0x578298&&_0x18fb1b['addEventListener']('blocked',_0x4d84e7=>_0x578298(_0x4d84e7['oldVersion'],_0x4d84e7['newVersion'],_0x4d84e7)),_0x287ea0['then'](_0x159dd6=>{_0x311435&&_0x159dd6['addEventListener']('close',()=>_0x311435()),_0x575b2a&&_0x159dd6['addEventListener']('versionchange',_0x33e4ea=>_0x575b2a(_0x33e4ea['oldVersion'],_0x33e4ea['newVersion'],_0x33e4ea));})['catch'](()=>{}),_0x287ea0;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x4cce27,_0x1f509c){if(!(_0x4cce27 instanceof IDBDatabase&&!(_0x1f509c in _0x4cce27)&&typeof _0x1f509c=='string'))return;if(Zn['get'](_0x1f509c))return Zn['get'](_0x1f509c);const _0x45e5d3=_0x1f509c['replace'](/FromIndex$/,''),_0x4cd05a=_0x1f509c!==_0x45e5d3,_0x1a3ce0=$c['includes'](_0x45e5d3);if(!(_0x45e5d3 in(_0x4cd05a?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1a3ce0||Hc['includes'](_0x45e5d3)))return;const _0x2b74e0=async function(_0x824636,..._0x45ec5d){const _0x461701=this['transaction'](_0x824636,_0x1a3ce0?'readwrite':'readonly');let _0x11295a=_0x461701['store'];return _0x4cd05a&&(_0x11295a=_0x11295a['index'](_0x45ec5d['shift']())),(await Promise['all']([_0x11295a[_0x45e5d3](..._0x45ec5d),_0x1a3ce0&&_0x461701['done']]))[0x0];};return Zn['set'](_0x1f509c,_0x2b74e0),_0x2b74e0;}Uc(_0x5af06a=>({..._0x5af06a,'get':(_0x5f2aad,_0x583cea,_0x1e3e33)=>Os(_0x5f2aad,_0x583cea)||_0x5af06a['get'](_0x5f2aad,_0x583cea,_0x1e3e33),'has':(_0x38b310,_0xcaa7a7)=>!!Os(_0x38b310,_0xcaa7a7)||_0x5af06a['has'](_0x38b310,_0xcaa7a7)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x2e73ed){this['container']=_0x2e73ed;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5b1ff8=>{if(qc(_0x5b1ff8)){const _0x8e9ea5=_0x5b1ff8['getImmediate']();return _0x8e9ea5['library']+'/'+_0x8e9ea5['version'];}else return null;})['filter'](_0xa547b6=>_0xa547b6)['join']('\x20');}}function qc(_0x4b4883){const _0x9f4125=_0x4b4883['getComponent']();return(_0x9f4125==null?void 0x0:_0x9f4125['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x593e87,_0x49c4cc){try{_0x593e87['container']['addComponent'](_0x49c4cc);}catch(_0x642884){re['debug']('Component\x20'+_0x49c4cc['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x593e87['name'],_0x642884);}}function et(_0x3d2904){const _0xb2a00=_0x3d2904['name'];if(gi['has'](_0xb2a00))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xb2a00+'.'),!0x1;gi['set'](_0xb2a00,_0x3d2904);for(const _0x4b1ad3 of Le['values']())Ms(_0x4b1ad3,_0x3d2904);for(const _0x130c8f of _i['values']())Ms(_0x130c8f,_0x3d2904);return!0x0;}function Ui(_0x1b1ae8,_0x163e24){const _0x4f5be1=_0x1b1ae8['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4f5be1&&_0x4f5be1['triggerHeartbeat'](),_0x1b1ae8['container']['getProvider'](_0x163e24);}function H(_0x4edf1b){return _0x4edf1b==null?!0x1:_0x4edf1b['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x23126c,_0x13d8a1,_0x2b605e){this['_isDeleted']=!0x1,this['_options']={..._0x23126c},this['_config']={..._0x13d8a1},this['_name']=_0x13d8a1['name'],this['_automaticDataCollectionEnabled']=_0x13d8a1['automaticDataCollectionEnabled'],this['_container']=_0x2b605e,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x140ba9){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x140ba9;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x56c898){this['_isDeleted']=_0x56c898;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x438606,_0x2a24ee={}){let _0x5c6fc5=_0x438606;typeof _0x2a24ee!='object'&&(_0x2a24ee={'name':_0x2a24ee});const _0xb495f0={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2a24ee},_0x321e45=_0xb495f0['name'];if(typeof _0x321e45!='string'||!_0x321e45)throw ge['create']('bad-app-name',{'appName':String(_0x321e45)});if(_0x5c6fc5||(_0x5c6fc5=$r()),!_0x5c6fc5)throw ge['create']('no-options');const _0x2b03b3=Le['get'](_0x321e45);if(_0x2b03b3){if(De(_0x5c6fc5,_0x2b03b3['options'])&&De(_0xb495f0,_0x2b03b3['config']))return _0x2b03b3;throw ge['create']('duplicate-app',{'appName':_0x321e45});}const _0x42b7=new Ac(_0x321e45);for(const _0x9febe9 of gi['values']())_0x42b7['addComponent'](_0x9febe9);const _0x2dbd4b=new Il(_0x5c6fc5,_0xb495f0,_0x42b7);return Le['set'](_0x321e45,_0x2dbd4b),_0x2dbd4b;}function Qr(_0x589535=pi){const _0x32e3d5=Le['get'](_0x589535);if(!_0x32e3d5&&_0x589535===pi&&$r())return wl();if(!_0x32e3d5)throw ge['create']('no-app',{'appName':_0x589535});return _0x32e3d5;}function l_(){return Array['from'](Le['values']());}async function h_(_0x254a60){let _0x20d04f=!0x1;const _0x406565=_0x254a60['name'];Le['has'](_0x406565)?(_0x20d04f=!0x0,Le['delete'](_0x406565)):_i['has'](_0x406565)&&_0x254a60['decRefCount']()<=0x0&&(_i['delete'](_0x406565),_0x20d04f=!0x0),_0x20d04f&&(await Promise['all'](_0x254a60['container']['getProviders']()['map'](_0x8e476e=>_0x8e476e['delete']())),_0x254a60['isDeleted']=!0x0);}function me(_0x4d2345,_0x4b34ca,_0x2024da){let _0x56990a=vl[_0x4d2345]??_0x4d2345;_0x2024da&&(_0x56990a+='-'+_0x2024da);const _0x56cd80=_0x56990a['match'](/\s|\//),_0x5d833b=_0x4b34ca['match'](/\s|\//);if(_0x56cd80||_0x5d833b){const _0xa04912=['Unable\x20to\x20register\x20library\x20\x22'+_0x56990a+'\x22\x20with\x20version\x20\x22'+_0x4b34ca+'\x22:'];_0x56cd80&&_0xa04912['push']('library\x20name\x20\x22'+_0x56990a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x56cd80&&_0x5d833b&&_0xa04912['push']('and'),_0x5d833b&&_0xa04912['push']('version\x20name\x20\x22'+_0x4b34ca+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0xa04912['join']('\x20'));return;}et(new Me(_0x56990a+'-version',()=>({'library':_0x56990a,'version':_0x4b34ca}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x255fc2,_0x4e9299)=>{switch(_0x4e9299){case 0x0:try{_0x255fc2['createObjectStore'](Rt);}catch(_0x3158ff){console['warn'](_0x3158ff);}}}})['catch'](_0x20fff1=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x20fff1['message']});})),ei;}async function Sl(_0x3dc03d){try{const _0x162798=(await Jr())['transaction'](Rt),_0x1b68ec=await _0x162798['objectStore'](Rt)['get'](Xr(_0x3dc03d));return await _0x162798['done'],_0x1b68ec;}catch(_0x2a2589){if(_0x2a2589 instanceof Se)re['warn'](_0x2a2589['message']);else{const _0x363ae7=ge['create']('idb-get',{'originalErrorMessage':_0x2a2589==null?void 0x0:_0x2a2589['message']});re['warn'](_0x363ae7['message']);}}}async function Ls(_0x4401e1,_0x192daa){try{const _0x205ec1=(await Jr())['transaction'](Rt,'readwrite');await _0x205ec1['objectStore'](Rt)['put'](_0x192daa,Xr(_0x4401e1)),await _0x205ec1['done'];}catch(_0x3eccf5){if(_0x3eccf5 instanceof Se)re['warn'](_0x3eccf5['message']);else{const _0x13bc5d=ge['create']('idb-set',{'originalErrorMessage':_0x3eccf5==null?void 0x0:_0x3eccf5['message']});re['warn'](_0x13bc5d['message']);}}}function Xr(_0x4ab411){return _0x4ab411['name']+'!'+_0x4ab411['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2c22b1){this['container']=_0x2c22b1,this['_heartbeatsCache']=null;const _0x75305e=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x75305e),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x564c84=>(this['_heartbeatsCache']=_0x564c84,_0x564c84));}async['triggerHeartbeat'](){var _0xf9dee9,_0x5a98be;try{const _0x11725a=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2fa1b2=xs();if(((_0xf9dee9=this['_heartbeatsCache'])==null?void 0x0:_0xf9dee9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5a98be=this['_heartbeatsCache'])==null?void 0x0:_0x5a98be['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2fa1b2||this['_heartbeatsCache']['heartbeats']['some'](_0x1c76b1=>_0x1c76b1['date']===_0x2fa1b2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2fa1b2,'agent':_0x11725a}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x11512c=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x11512c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x49d950){re['warn'](_0x49d950);}}async['getHeartbeatsHeader'](){var _0x4df803;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4df803=this['_heartbeatsCache'])==null?void 0x0:_0x4df803['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x55b81f=xs(),{heartbeatsToSend:_0x2d4d48,unsentEntries:_0x180416}=kl(this['_heartbeatsCache']['heartbeats']),_0x530b7b=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2d4d48}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x55b81f,_0x180416['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x180416,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x530b7b;}catch(_0xd43f2d){return re['warn'](_0xd43f2d),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x36ab9c,_0x3dd36d=bl){const _0x701801=[];let _0x50e4c8=_0x36ab9c['slice']();for(const _0x13a9f9 of _0x36ab9c){const _0x17ecc2=_0x701801['find'](_0x4107bf=>_0x4107bf['agent']===_0x13a9f9['agent']);if(_0x17ecc2){if(_0x17ecc2['dates']['push'](_0x13a9f9['date']),Fs(_0x701801)>_0x3dd36d){_0x17ecc2['dates']['pop']();break;}}else{if(_0x701801['push']({'agent':_0x13a9f9['agent'],'dates':[_0x13a9f9['date']]}),Fs(_0x701801)>_0x3dd36d){_0x701801['pop']();break;}}_0x50e4c8=_0x50e4c8['slice'](0x1);}return{'heartbeatsToSend':_0x701801,'unsentEntries':_0x50e4c8};}class Nl{constructor(_0x10636f){this['app']=_0x10636f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2dc3d1=await Sl(this['app']);return _0x2dc3d1!=null&&_0x2dc3d1['heartbeats']?_0x2dc3d1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x258be7){if(await this['_canUseIndexedDBPromise']){const _0x4ca87f=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x258be7['lastSentHeartbeatDate']??_0x4ca87f['lastSentHeartbeatDate'],'heartbeats':_0x258be7['heartbeats']});}else return;}async['add'](_0x45fb9a){if(await this['_canUseIndexedDBPromise']){const _0x4a9a9a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x45fb9a['lastSentHeartbeatDate']??_0x4a9a9a['lastSentHeartbeatDate'],'heartbeats':[..._0x4a9a9a['heartbeats'],..._0x45fb9a['heartbeats']]});}else return;}}function Fs(_0x465251){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x465251}))['length'];}function Pl(_0x215413){if(_0x215413['length']===0x0)return-0x1;let _0x4f752d=0x0,_0x2bb2c9=_0x215413[0x0]['date'];for(let _0x50c9d3=0x1;_0x50c9d3<_0x215413['length'];_0x50c9d3++)_0x215413[_0x50c9d3]['date']<_0x2bb2c9&&(_0x2bb2c9=_0x215413[_0x50c9d3]['date'],_0x4f752d=_0x50c9d3);return _0x4f752d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x297e9a){et(new Me('platform-logger',_0x2dc563=>new Gc(_0x2dc563),'PRIVATE')),et(new Me('heartbeat',_0x53f620=>new Al(_0x53f620),'PRIVATE')),me(fi,Ds,_0x297e9a),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x55b2cc){Zr=_0x55b2cc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x5709a3){this['domStorage_']=_0x5709a3,this['prefix_']='firebase:';}['set'](_0x1714e8,_0x73d610){_0x73d610==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1714e8)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1714e8),O(_0x73d610));}['get'](_0x4aed4e){const _0x194c97=this['domStorage_']['getItem'](this['prefixedName_'](_0x4aed4e));return _0x194c97==null?null:bt(_0x194c97);}['remove'](_0x2c28a5){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2c28a5));}['prefixedName_'](_0x12052d){return this['prefix_']+_0x12052d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x168253,_0x413f01){_0x413f01==null?delete this['cache_'][_0x168253]:this['cache_'][_0x168253]=_0x413f01;}['get'](_0x574b26){return Y(this['cache_'],_0x574b26)?this['cache_'][_0x574b26]:null;}['remove'](_0x518f5c){delete this['cache_'][_0x518f5c];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x3eb2c2){try{if(typeof window<'u'&&typeof window[_0x3eb2c2]<'u'){const _0x2881e9=window[_0x3eb2c2];return _0x2881e9['setItem']('firebase:sentinel','cache'),_0x2881e9['removeItem']('firebase:sentinel'),new xl(_0x2881e9);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x4948fc=0x1;return function(){return _0x4948fc++;};}()),no=function(_0x3913d8){const _0x133091=Tc(_0x3913d8),_0x327c38=new Ec();_0x327c38['update'](_0x133091);const _0x4ef558=_0x327c38['digest']();return Di['encodeByteArray'](_0x4ef558);},Bt=function(..._0x44b4a5){let _0x3c8ebe='';for(let _0x4b03ac=0x0;_0x4b03ac<_0x44b4a5['length'];_0x4b03ac++){const _0x5daf08=_0x44b4a5[_0x4b03ac];Array['isArray'](_0x5daf08)||_0x5daf08&&typeof _0x5daf08=='object'&&typeof _0x5daf08['length']=='number'?_0x3c8ebe+=Bt['apply'](null,_0x5daf08):typeof _0x5daf08=='object'?_0x3c8ebe+=O(_0x5daf08):_0x3c8ebe+=_0x5daf08,_0x3c8ebe+='\x20';}return _0x3c8ebe;};let Et=null,Vs=!0x0;const Wl=function(_0x1c3619,_0x440bc8){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x77ef94){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x70d783=Bt['apply'](null,_0x77ef94);Et(_0x70d783);}},Vt=function(_0x28c2a2){return function(..._0x1f67c6){L(_0x28c2a2,..._0x1f67c6);};},mi=function(..._0x42c602){const _0xb513ee='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x42c602);Qe['error'](_0xb513ee);},oe=function(..._0x285d03){const _0x4ecc1d='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x285d03);throw Qe['error'](_0x4ecc1d),new Error(_0x4ecc1d);},U=function(..._0x12eb4c){const _0x33689f='FIREBASE\x20WARNING:\x20'+Bt(..._0x12eb4c);Qe['warn'](_0x33689f);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x55c421){return typeof _0x55c421=='number'&&(_0x55c421!==_0x55c421||_0x55c421===Number['POSITIVE_INFINITY']||_0x55c421===Number['NEGATIVE_INFINITY']);},Vl=function(_0x1bbd6f){if(document['readyState']==='complete')_0x1bbd6f();else{let _0x340f4f=!0x1;const _0x1e768b=function(){if(!document['body']){setTimeout(_0x1e768b,Math['floor'](0xa));return;}_0x340f4f||(_0x340f4f=!0x0,_0x1bbd6f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1e768b,!0x1),window['addEventListener']('load',_0x1e768b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1e768b();}),window['attachEvent']('onload',_0x1e768b));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x256f2a,_0x5ee89f){if(_0x256f2a===_0x5ee89f)return 0x0;if(_0x256f2a===xe||_0x5ee89f===Ie)return-0x1;if(_0x5ee89f===xe||_0x256f2a===Ie)return 0x1;{const _0x489354=Hs(_0x256f2a),_0x503249=Hs(_0x5ee89f);return _0x489354!==null?_0x503249!==null?_0x489354-_0x503249===0x0?_0x256f2a['length']-_0x5ee89f['length']:_0x489354-_0x503249:-0x1:_0x503249!==null?0x1:_0x256f2a<_0x5ee89f?-0x1:0x1;}},Hl=function(_0x54ecfa,_0x46984b){return _0x54ecfa===_0x46984b?0x0:_0x54ecfa<_0x46984b?-0x1:0x1;},pt=function(_0x508a19,_0x6a5c2){if(_0x6a5c2&&_0x508a19 in _0x6a5c2)return _0x6a5c2[_0x508a19];throw new Error('Missing\x20required\x20key\x20('+_0x508a19+')\x20in\x20object:\x20'+O(_0x6a5c2));},Bi=function(_0x9da830){if(typeof _0x9da830!='object'||_0x9da830===null)return O(_0x9da830);const _0x3c83e6=[];for(const _0x330bdf in _0x9da830)_0x3c83e6['push'](_0x330bdf);_0x3c83e6['sort']();let _0x2b9c54='{';for(let _0xced950=0x0;_0xced950<_0x3c83e6['length'];_0xced950++)_0xced950!==0x0&&(_0x2b9c54+=','),_0x2b9c54+=O(_0x3c83e6[_0xced950]),_0x2b9c54+=':',_0x2b9c54+=Bi(_0x9da830[_0x3c83e6[_0xced950]]);return _0x2b9c54+='}',_0x2b9c54;},io=function(_0x11681d,_0x2cf3f4){const _0xf40b07=_0x11681d['length'];if(_0xf40b07<=_0x2cf3f4)return[_0x11681d];const _0x121a59=[];for(let _0x4a545f=0x0;_0x4a545f<_0xf40b07;_0x4a545f+=_0x2cf3f4)_0x4a545f+_0x2cf3f4>_0xf40b07?_0x121a59['push'](_0x11681d['substring'](_0x4a545f,_0xf40b07)):_0x121a59['push'](_0x11681d['substring'](_0x4a545f,_0x4a545f+_0x2cf3f4));return _0x121a59;};function x(_0x26cc3b,_0x2376fc){for(const _0x580060 in _0x26cc3b)_0x26cc3b['hasOwnProperty'](_0x580060)&&_0x2376fc(_0x580060,_0x26cc3b[_0x580060]);}const so=function(_0x251aa4){f(!Wi(_0x251aa4),'Invalid\x20JSON\x20number');const _0x26f1ac=0xb,_0x3d431c=0x34,_0x2c7493=(0x1<<_0x26f1ac-0x1)-0x1;let _0x10b8b2,_0x19a3ac,_0x153036,_0x4baf44,_0x181ba1;_0x251aa4===0x0?(_0x19a3ac=0x0,_0x153036=0x0,_0x10b8b2=0x1/_0x251aa4===-0x1/0x0?0x1:0x0):(_0x10b8b2=_0x251aa4<0x0,_0x251aa4=Math['abs'](_0x251aa4),_0x251aa4>=Math['pow'](0x2,0x1-_0x2c7493)?(_0x4baf44=Math['min'](Math['floor'](Math['log'](_0x251aa4)/Math['LN2']),_0x2c7493),_0x19a3ac=_0x4baf44+_0x2c7493,_0x153036=Math['round'](_0x251aa4*Math['pow'](0x2,_0x3d431c-_0x4baf44)-Math['pow'](0x2,_0x3d431c))):(_0x19a3ac=0x0,_0x153036=Math['round'](_0x251aa4/Math['pow'](0x2,0x1-_0x2c7493-_0x3d431c))));const _0x1971dd=[];for(_0x181ba1=_0x3d431c;_0x181ba1;_0x181ba1-=0x1)_0x1971dd['push'](_0x153036%0x2?0x1:0x0),_0x153036=Math['floor'](_0x153036/0x2);for(_0x181ba1=_0x26f1ac;_0x181ba1;_0x181ba1-=0x1)_0x1971dd['push'](_0x19a3ac%0x2?0x1:0x0),_0x19a3ac=Math['floor'](_0x19a3ac/0x2);_0x1971dd['push'](_0x10b8b2?0x1:0x0),_0x1971dd['reverse']();const _0x5559c7=_0x1971dd['join']('');let _0x36f4d8='';for(_0x181ba1=0x0;_0x181ba1<0x40;_0x181ba1+=0x8){let _0x33c549=parseInt(_0x5559c7['substr'](_0x181ba1,0x8),0x2)['toString'](0x10);_0x33c549['length']===0x1&&(_0x33c549='0'+_0x33c549),_0x36f4d8=_0x36f4d8+_0x33c549;}return _0x36f4d8['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x4a6c7e,_0xbd9f88){let _0x29f444='Unknown\x20Error';_0x4a6c7e==='too_big'?_0x29f444='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4a6c7e==='permission_denied'?_0x29f444='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4a6c7e==='unavailable'&&(_0x29f444='The\x20service\x20is\x20unavailable');const _0x34ef27=new Error(_0x4a6c7e+'\x20at\x20'+_0xbd9f88['_path']['toString']()+':\x20'+_0x29f444);return _0x34ef27['code']=_0x4a6c7e['toUpperCase'](),_0x34ef27;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x5d3b87){if(zl['test'](_0x5d3b87)){const _0x39cba2=Number(_0x5d3b87);if(_0x39cba2>=jl&&_0x39cba2<=Kl)return _0x39cba2;}return null;},lt=function(_0xdb51ae){try{_0xdb51ae();}catch(_0x15cba3){setTimeout(()=>{const _0x1cc7c1=_0x15cba3['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1cc7c1),_0x15cba3;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x3e08d0,_0xc6c9e){const _0x300433=setTimeout(_0x3e08d0,_0xc6c9e);return typeof _0x300433=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x300433):typeof _0x300433=='object'&&_0x300433['unref']&&_0x300433['unref'](),_0x300433;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x483ff4,_0x157430){this['appCheckProvider']=_0x157430,this['appName']=_0x483ff4['name'],H(_0x483ff4)&&_0x483ff4['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x483ff4['settings']['appCheckToken']),this['appCheck']=_0x157430==null?void 0x0:_0x157430['getImmediate']({'optional':!0x0}),this['appCheck']||_0x157430==null||_0x157430['get']()['then'](_0x1a9a44=>this['appCheck']=_0x1a9a44);}['getToken'](_0x271a42){if(this['serverAppAppCheckToken']){if(_0x271a42)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x271a42):new Promise((_0xec6faa,_0x12a4f7)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x271a42)['then'](_0xec6faa,_0x12a4f7):_0xec6faa(null);},0x0);});}['addTokenChangeListener'](_0x143969){var _0x47f91b;(_0x47f91b=this['appCheckProvider'])==null||_0x47f91b['get']()['then'](_0x9cdf4=>_0x9cdf4['addTokenListener'](_0x143969));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1554d8,_0x54de8d,_0x40fbbf){this['appName_']=_0x1554d8,this['firebaseOptions_']=_0x54de8d,this['authProvider_']=_0x40fbbf,this['auth_']=null,this['auth_']=_0x40fbbf['getImmediate']({'optional':!0x0}),this['auth_']||_0x40fbbf['onInit'](_0xc0826f=>this['auth_']=_0xc0826f);}['getToken'](_0x578a1d){return this['auth_']?this['auth_']['getToken'](_0x578a1d)['catch'](_0x21d03d=>_0x21d03d&&_0x21d03d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x21d03d)):new Promise((_0x52312c,_0x5c4c13)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x578a1d)['then'](_0x52312c,_0x5c4c13):_0x52312c(null);},0x0);});}['addTokenChangeListener'](_0x47f80a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x47f80a):this['authProvider_']['get']()['then'](_0x216b6c=>_0x216b6c['addAuthTokenListener'](_0x47f80a));}['removeTokenChangeListener'](_0x45e92b){this['authProvider_']['get']()['then'](_0x2f74a8=>_0x2f74a8['removeAuthTokenListener'](_0x45e92b));}['notifyForInvalidToken'](){let _0x2cae20='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2cae20+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2cae20+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2cae20+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2cae20);}}class tn{constructor(_0x9c777){this['accessToken']=_0x9c777;}['getToken'](_0x2aae23){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x359231){_0x359231(this['accessToken']);}['removeTokenChangeListener'](_0x4c09f3){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x3cab49,_0x2214c7,_0x7fa594,_0x5c823b,_0x1a4120=!0x1,_0x2d543c='',_0x4c05ef=!0x1,_0x24152b=!0x1,_0x320230=null){this['secure']=_0x2214c7,this['namespace']=_0x7fa594,this['webSocketOnly']=_0x5c823b,this['nodeAdmin']=_0x1a4120,this['persistenceKey']=_0x2d543c,this['includeNamespaceInQueryParams']=_0x4c05ef,this['isUsingEmulator']=_0x24152b,this['emulatorOptions']=_0x320230,this['_host']=_0x3cab49['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x3cab49)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2367c5){_0x2367c5!==this['internalHost']&&(this['internalHost']=_0x2367c5,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x451d44=this['toURLString']();return this['persistenceKey']&&(_0x451d44+='<'+this['persistenceKey']+'>'),_0x451d44;}['toURLString'](){const _0x378709=this['secure']?'https://':'http://',_0x33fbe8=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x378709+this['host']+'/'+_0x33fbe8;}}function Xl(_0x4738f3){return _0x4738f3['host']!==_0x4738f3['internalHost']||_0x4738f3['isCustomHost']()||_0x4738f3['includeNamespaceInQueryParams'];}function go(_0x328e88,_0x2ccb86,_0x5294ba){f(typeof _0x2ccb86=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5294ba=='object','typeof\x20params\x20must\x20==\x20object');let _0x2f05a9;if(_0x2ccb86===fo)_0x2f05a9=(_0x328e88['secure']?'wss://':'ws://')+_0x328e88['internalHost']+'/.ws?';else{if(_0x2ccb86===po)_0x2f05a9=(_0x328e88['secure']?'https://':'http://')+_0x328e88['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2ccb86);}Xl(_0x328e88)&&(_0x5294ba['ns']=_0x328e88['namespace']);const _0x218432=[];return x(_0x5294ba,(_0x11e813,_0x28a8d6)=>{_0x218432['push'](_0x11e813+'='+_0x28a8d6);}),_0x2f05a9+_0x218432['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x26bd7b,_0x58dfc8=0x1){Y(this['counters_'],_0x26bd7b)||(this['counters_'][_0x26bd7b]=0x0),this['counters_'][_0x26bd7b]+=_0x58dfc8;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x23cd9f){const _0x536a3f=_0x23cd9f['toString']();return ti[_0x536a3f]||(ti[_0x536a3f]=new Zl()),ti[_0x536a3f];}function eh(_0x2f6a41,_0x47348b){const _0x39861a=_0x2f6a41['toString']();return ni[_0x39861a]||(ni[_0x39861a]=_0x47348b()),ni[_0x39861a];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x4fb019){this['onMessage_']=_0x4fb019,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x409cc1,_0x4475aa){this['closeAfterResponse']=_0x409cc1,this['onClose']=_0x4475aa,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xb15565,_0x2e6ca2){for(this['pendingResponses'][_0xb15565]=_0x2e6ca2;this['pendingResponses'][this['currentResponseNum']];){const _0x84ba27=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x555c08=0x0;_0x555c08<_0x84ba27['length'];++_0x555c08)_0x84ba27[_0x555c08]&&lt(()=>{this['onMessage_'](_0x84ba27[_0x555c08]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x539436,_0x208947,_0xf602c3,_0x44a3ab,_0x3496db,_0x4b30e5,_0x27a150){this['connId']=_0x539436,this['repoInfo']=_0x208947,this['applicationId']=_0xf602c3,this['appCheckToken']=_0x44a3ab,this['authToken']=_0x3496db,this['transportSessionId']=_0x4b30e5,this['lastSessionId']=_0x27a150,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x539436),this['stats_']=Hi(_0x208947),this['urlFn']=_0x37dd79=>(this['appCheckToken']&&(_0x37dd79[yi]=this['appCheckToken']),go(_0x208947,po,_0x37dd79));}['open'](_0x2a769f,_0x1c134d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1c134d,this['myPacketOrderer']=new th(_0x2a769f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x1054b8)=>{const [_0x5cde7e,_0x23df95,_0x1edca6,_0x9e02b7,_0x2b258f]=_0x1054b8;if(this['incrementIncomingBytes_'](_0x1054b8),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5cde7e===$s)this['id']=_0x23df95,this['password']=_0x1edca6;else{if(_0x5cde7e===nh)_0x23df95?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x23df95,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5cde7e);}}},(..._0x27587b)=>{const [_0x72d98d,_0x51074b]=_0x27587b;this['incrementIncomingBytes_'](_0x27587b),this['myPacketOrderer']['handleResponse'](_0x72d98d,_0x51074b);},()=>{this['onClosed_']();},this['urlFn']);const _0x2f71d0={};_0x2f71d0[$s]='t',_0x2f71d0[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2f71d0[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2f71d0[ro]=Vi,this['transportSessionId']&&(_0x2f71d0[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x2f71d0[ho]=this['lastSessionId']),this['applicationId']&&(_0x2f71d0[uo]=this['applicationId']),this['appCheckToken']&&(_0x2f71d0[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2f71d0[ao]=co);const _0x49689f=this['urlFn'](_0x2f71d0);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x49689f),this['scriptTagHolder']['addTag'](_0x49689f,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x26530e){const _0x4961ad=O(_0x26530e);this['bytesSent']+=_0x4961ad['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4961ad['length']);const _0x49b652=Br(_0x4961ad),_0xf24b90=io(_0x49b652,hh);for(let _0x1205bb=0x0;_0x1205bb<_0xf24b90['length'];_0x1205bb++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xf24b90['length'],_0xf24b90[_0x1205bb]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2170c9,_0x3c325e){this['myDisconnFrame']=document['createElement']('iframe');const _0x4393a9={};_0x4393a9[lh]='t',_0x4393a9[mo]=_0x2170c9,_0x4393a9[yo]=_0x3c325e,this['myDisconnFrame']['src']=this['urlFn'](_0x4393a9),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4b9878){const _0x40d3ff=O(_0x4b9878)['length'];this['bytesReceived']+=_0x40d3ff,this['stats_']['incrementCounter']('bytes_received',_0x40d3ff);}}class $i{constructor(_0x293f5d,_0x5caa56,_0x19b6b9,_0x1e61e2){this['onDisconnect']=_0x19b6b9,this['urlFn']=_0x1e61e2,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x293f5d,window[sh+this['uniqueCallbackIdentifier']]=_0x5caa56,this['myIFrame']=$i['createIFrame_']();let _0x2e1669='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2e1669='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x15b579='<html><body>'+_0x2e1669+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x15b579),this['myIFrame']['doc']['close']();}catch(_0x5c3ebb){L('frame\x20writing\x20exception'),_0x5c3ebb['stack']&&L(_0x5c3ebb['stack']),L(_0x5c3ebb);}}}static['createIFrame_'](){const _0x4e093d=document['createElement']('iframe');if(_0x4e093d['style']['display']='none',document['body']){document['body']['appendChild'](_0x4e093d);try{_0x4e093d['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3c4233=document['domain'];_0x4e093d['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3c4233+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4e093d['contentDocument']?_0x4e093d['doc']=_0x4e093d['contentDocument']:_0x4e093d['contentWindow']?_0x4e093d['doc']=_0x4e093d['contentWindow']['document']:_0x4e093d['document']&&(_0x4e093d['doc']=_0x4e093d['document']),_0x4e093d;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x476aa3=this['onDisconnect'];_0x476aa3&&(this['onDisconnect']=null,_0x476aa3());}['startLongPoll'](_0x15c348,_0x58ff72){for(this['myID']=_0x15c348,this['myPW']=_0x58ff72,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x243687={};_0x243687[mo]=this['myID'],_0x243687[yo]=this['myPW'],_0x243687[vo]=this['currentSerial'];let _0x9cd2ad=this['urlFn'](_0x243687),_0x5a92cf='',_0x37483b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5a92cf['length']<=Eo;){const _0xb78c06=this['pendingSegs']['shift']();_0x5a92cf=_0x5a92cf+'&'+oh+_0x37483b+'='+_0xb78c06['seg']+'&'+ah+_0x37483b+'='+_0xb78c06['ts']+'&'+ch+_0x37483b+'='+_0xb78c06['d'],_0x37483b++;}return _0x9cd2ad=_0x9cd2ad+_0x5a92cf,this['addLongPollTag_'](_0x9cd2ad,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xc10b3e,_0x1b8a94,_0x54ddae){this['pendingSegs']['push']({'seg':_0xc10b3e,'ts':_0x1b8a94,'d':_0x54ddae}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xb75832,_0x8b8d91){this['outstandingRequests']['add'](_0x8b8d91);const _0x4ac251=()=>{this['outstandingRequests']['delete'](_0x8b8d91),this['newRequest_']();},_0x15a761=setTimeout(_0x4ac251,Math['floor'](uh)),_0x1b5c03=()=>{clearTimeout(_0x15a761),_0x4ac251();};this['addTag'](_0xb75832,_0x1b5c03);}['addTag'](_0x5e0808,_0x5a64a2){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4a3a90=this['myIFrame']['doc']['createElement']('script');_0x4a3a90['type']='text/javascript',_0x4a3a90['async']=!0x0,_0x4a3a90['src']=_0x5e0808,_0x4a3a90['onload']=_0x4a3a90['onreadystatechange']=function(){const _0x1a8536=_0x4a3a90['readyState'];(!_0x1a8536||_0x1a8536==='loaded'||_0x1a8536==='complete')&&(_0x4a3a90['onload']=_0x4a3a90['onreadystatechange']=null,_0x4a3a90['parentNode']&&_0x4a3a90['parentNode']['removeChild'](_0x4a3a90),_0x5a64a2());},_0x4a3a90['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5e0808),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4a3a90);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x5883bd,_0x29a938,_0x423e3f,_0x9b7a95,_0x192b94,_0x8bd3c7,_0x535a45){this['connId']=_0x5883bd,this['applicationId']=_0x423e3f,this['appCheckToken']=_0x9b7a95,this['authToken']=_0x192b94,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x29a938),this['connURL']=G['connectionURL_'](_0x29a938,_0x8bd3c7,_0x535a45,_0x9b7a95,_0x423e3f),this['nodeAdmin']=_0x29a938['nodeAdmin'];}static['connectionURL_'](_0x1e6657,_0x189cf5,_0x2a388b,_0x1ac40c,_0xe64cf5){const _0x2e448a={};return _0x2e448a[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x2e448a[ao]=co),_0x189cf5&&(_0x2e448a[oo]=_0x189cf5),_0x2a388b&&(_0x2e448a[ho]=_0x2a388b),_0x1ac40c&&(_0x2e448a[yi]=_0x1ac40c),_0xe64cf5&&(_0x2e448a[uo]=_0xe64cf5),go(_0x1e6657,fo,_0x2e448a);}['open'](_0x3d35bb,_0x3714a7){this['onDisconnect']=_0x3714a7,this['onMessage']=_0x3d35bb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x23885d;dc(),this['mySock']=new hn(this['connURL'],[],_0x23885d);}catch(_0x268bbb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x553338=_0x268bbb['message']||_0x268bbb['data'];_0x553338&&this['log_'](_0x553338),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x457dc6=>{this['handleIncomingFrame'](_0x457dc6);},this['mySock']['onerror']=_0xdfe351=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x359330=_0xdfe351['message']||_0xdfe351['data'];_0x359330&&this['log_'](_0x359330),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x476d2c=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5d5e7a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x415d99=navigator['userAgent']['match'](_0x5d5e7a);_0x415d99&&_0x415d99['length']>0x1&&parseFloat(_0x415d99[0x1])<4.4&&(_0x476d2c=!0x0);}return!_0x476d2c&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x189911){if(this['frames']['push'](_0x189911),this['frames']['length']===this['totalFrames']){const _0x30e4fe=this['frames']['join']('');this['frames']=null;const _0x3b67db=bt(_0x30e4fe);this['onMessage'](_0x3b67db);}}['handleNewFrameCount_'](_0x5872fc){this['totalFrames']=_0x5872fc,this['frames']=[];}['extractFrameCount_'](_0x12f836){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x12f836['length']<=0x6){const _0x4a5459=Number(_0x12f836);if(!isNaN(_0x4a5459))return this['handleNewFrameCount_'](_0x4a5459),null;}return this['handleNewFrameCount_'](0x1),_0x12f836;}['handleIncomingFrame'](_0x517e7f){if(this['mySock']===null)return;const _0x203057=_0x517e7f['data'];if(this['bytesReceived']+=_0x203057['length'],this['stats_']['incrementCounter']('bytes_received',_0x203057['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x203057);else{const _0x397b95=this['extractFrameCount_'](_0x203057);_0x397b95!==null&&this['appendFrame_'](_0x397b95);}}['send'](_0x12e59b){this['resetKeepAlive']();const _0x2d7eef=O(_0x12e59b);this['bytesSent']+=_0x2d7eef['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2d7eef['length']);const _0x5e4965=io(_0x2d7eef,fh);_0x5e4965['length']>0x1&&this['sendString_'](String(_0x5e4965['length']));for(let _0x2d6dc2=0x0;_0x2d6dc2<_0x5e4965['length'];_0x2d6dc2++)this['sendString_'](_0x5e4965[_0x2d6dc2]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x2a552e){try{this['mySock']['send'](_0x2a552e);}catch(_0x5271f7){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5271f7['message']||_0x5271f7['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5a1a8e){this['initTransports_'](_0x5a1a8e);}['initTransports_'](_0x51fc7c){const _0x54d7bd=G&&G['isAvailable']();let _0x196e6a=_0x54d7bd&&!G['previouslyFailed']();if(_0x51fc7c['webSocketOnly']&&(_0x54d7bd||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x196e6a=!0x0),_0x196e6a)this['transports_']=[G];else{const _0x356f93=this['transports_']=[];for(const _0x5a9720 of At['ALL_TRANSPORTS'])_0x5a9720&&_0x5a9720['isAvailable']()&&_0x356f93['push'](_0x5a9720);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x1148be,_0x546b00,_0x4061bd,_0x41ad8d,_0x101d9c,_0x7e03a7,_0x25b701,_0x95f42a,_0x50ba9b,_0x2710e3){this['id']=_0x1148be,this['repoInfo_']=_0x546b00,this['applicationId_']=_0x4061bd,this['appCheckToken_']=_0x41ad8d,this['authToken_']=_0x101d9c,this['onMessage_']=_0x7e03a7,this['onReady_']=_0x25b701,this['onDisconnect_']=_0x95f42a,this['onKill_']=_0x50ba9b,this['lastSessionId']=_0x2710e3,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x546b00),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x544598=this['transportManager_']['initialTransport']();this['conn_']=new _0x544598(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x544598['responsesRequiredToBeHealthy']||0x0;const _0x193c6f=this['connReceiver_'](this['conn_']),_0xdb9c29=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x193c6f,_0xdb9c29);},Math['floor'](0x0));const _0x746f1c=_0x544598['healthyTimeout']||0x0;_0x746f1c>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x746f1c)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5ddc09){return _0x46286f=>{_0x5ddc09===this['conn_']?this['onConnectionLost_'](_0x46286f):_0x5ddc09===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x48f47d){return _0x18083f=>{this['state_']!==0x2&&(_0x48f47d===this['rx_']?this['onPrimaryMessageReceived_'](_0x18083f):_0x48f47d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x18083f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x15ab87){const _0x5837a4={'t':'d','d':_0x15ab87};this['sendData_'](_0x5837a4);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2847d3){if(ii in _0x2847d3){const _0x14b636=_0x2847d3[ii];_0x14b636===js?this['upgradeIfSecondaryHealthy_']():_0x14b636===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x14b636===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x180435){const _0x44ebe2=pt('t',_0x180435),_0x3bfd6f=pt('d',_0x180435);if(_0x44ebe2==='c')this['onSecondaryControl_'](_0x3bfd6f);else{if(_0x44ebe2==='d')this['pendingDataMessages']['push'](_0x3bfd6f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x44ebe2);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4ce541){const _0x4d1f62=pt('t',_0x4ce541),_0x482955=pt('d',_0x4ce541);_0x4d1f62==='c'?this['onControl_'](_0x482955):_0x4d1f62==='d'&&this['onDataMessage_'](_0x482955);}['onDataMessage_'](_0x197a7c){this['onPrimaryResponse_'](),this['onMessage_'](_0x197a7c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x222705){const _0x4cf343=pt(ii,_0x222705);if(Gs in _0x222705){const _0x1df618=_0x222705[Gs];if(_0x4cf343===Ih){const _0x14ac85={..._0x1df618};this['repoInfo_']['isUsingEmulator']&&(_0x14ac85['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x14ac85);}else{if(_0x4cf343===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4b60bd=0x0;_0x4b60bd<this['pendingDataMessages']['length'];++_0x4b60bd)this['onDataMessage_'](this['pendingDataMessages'][_0x4b60bd]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4cf343===vh?this['onConnectionShutdown_'](_0x1df618):_0x4cf343===qs?this['onReset_'](_0x1df618):_0x4cf343===Eh?mi('Server\x20Error:\x20'+_0x1df618):_0x4cf343===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x4cf343);}}}['onHandshake_'](_0xe85c48){const _0x177097=_0xe85c48['ts'],_0x415ac8=_0xe85c48['v'],_0x50afd3=_0xe85c48['h'];this['sessionId']=_0xe85c48['s'],this['repoInfo_']['host']=_0x50afd3,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x177097),Vi!==_0x415ac8&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2cc122=this['transportManager_']['upgradeTransport']();_0x2cc122&&this['startUpgrade_'](_0x2cc122);}['startUpgrade_'](_0x263b50){this['secondaryConn_']=new _0x263b50(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x263b50['responsesRequiredToBeHealthy']||0x0;const _0x16bff2=this['connReceiver_'](this['secondaryConn_']),_0x434002=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x16bff2,_0x434002),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x2f0300){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2f0300),this['repoInfo_']['host']=_0x2f0300,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x518e64,_0x4030a3){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x518e64,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4030a3,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x1f3460=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x1f3460||this['rx_']===_0x1f3460)&&this['close']();}['onConnectionLost_'](_0x5136e0){this['conn_']=null,!_0x5136e0&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4ce8a3){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4ce8a3),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x49804e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x49804e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x57042c,_0x2b6dce,_0x336af9,_0x66d7af){}['merge'](_0x17b69d,_0x16005f,_0x312690,_0x40078a){}['refreshAuthToken'](_0x13166b){}['refreshAppCheckToken'](_0x34376b){}['onDisconnectPut'](_0x4f3f27,_0x58da7d,_0x5c155a){}['onDisconnectMerge'](_0x3bc109,_0x41e172,_0x2ab875){}['onDisconnectCancel'](_0x36f0d6,_0x2f3d41){}['reportStats'](_0xe1175a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x409bbc){this['allowedEvents_']=_0x409bbc,this['listeners_']={},f(Array['isArray'](_0x409bbc)&&_0x409bbc['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3a798d,..._0x5eb923){if(Array['isArray'](this['listeners_'][_0x3a798d])){const _0x4fc9a9=[...this['listeners_'][_0x3a798d]];for(let _0x826331=0x0;_0x826331<_0x4fc9a9['length'];_0x826331++)_0x4fc9a9[_0x826331]['callback']['apply'](_0x4fc9a9[_0x826331]['context'],_0x5eb923);}}['on'](_0x57b104,_0xf645e5,_0x4274cc){this['validateEventType_'](_0x57b104),this['listeners_'][_0x57b104]=this['listeners_'][_0x57b104]||[],this['listeners_'][_0x57b104]['push']({'callback':_0xf645e5,'context':_0x4274cc});const _0x3c6778=this['getInitialEvent'](_0x57b104);_0x3c6778&&_0xf645e5['apply'](_0x4274cc,_0x3c6778);}['off'](_0x4cd0aa,_0x28be00,_0x16c058){this['validateEventType_'](_0x4cd0aa);const _0x7dde00=this['listeners_'][_0x4cd0aa]||[];for(let _0x45520e=0x0;_0x45520e<_0x7dde00['length'];_0x45520e++)if(_0x7dde00[_0x45520e]['callback']===_0x28be00&&(!_0x16c058||_0x16c058===_0x7dde00[_0x45520e]['context'])){_0x7dde00['splice'](_0x45520e,0x1);return;}}['validateEventType_'](_0x12c9fe){f(this['allowedEvents_']['find'](_0x4d017f=>_0x4d017f===_0x12c9fe),'Unknown\x20event:\x20'+_0x12c9fe);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xc8138c){return f(_0xc8138c==='online','Unknown\x20event\x20type:\x20'+_0xc8138c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0xf58c49,_0x41cb28){if(_0x41cb28===void 0x0){this['pieces_']=_0xf58c49['split']('/');let _0x1c4b39=0x0;for(let _0x9adbdf=0x0;_0x9adbdf<this['pieces_']['length'];_0x9adbdf++)this['pieces_'][_0x9adbdf]['length']>0x0&&(this['pieces_'][_0x1c4b39]=this['pieces_'][_0x9adbdf],_0x1c4b39++);this['pieces_']['length']=_0x1c4b39,this['pieceNum_']=0x0;}else this['pieces_']=_0xf58c49,this['pieceNum_']=_0x41cb28;}['toString'](){let _0x387b06='';for(let _0xda226c=this['pieceNum_'];_0xda226c<this['pieces_']['length'];_0xda226c++)this['pieces_'][_0xda226c]!==''&&(_0x387b06+='/'+this['pieces_'][_0xda226c]);return _0x387b06||'/';}}function w(){return new C('');}function y(_0x4e74bd){return _0x4e74bd['pieceNum_']>=_0x4e74bd['pieces_']['length']?null:_0x4e74bd['pieces_'][_0x4e74bd['pieceNum_']];}function we(_0x2469c6){return _0x2469c6['pieces_']['length']-_0x2469c6['pieceNum_'];}function b(_0x418aa7){let _0x49fd96=_0x418aa7['pieceNum_'];return _0x49fd96<_0x418aa7['pieces_']['length']&&_0x49fd96++,new C(_0x418aa7['pieces_'],_0x49fd96);}function Gi(_0xf0ca0c){return _0xf0ca0c['pieceNum_']<_0xf0ca0c['pieces_']['length']?_0xf0ca0c['pieces_'][_0xf0ca0c['pieces_']['length']-0x1]:null;}function Ch(_0x536328){let _0x1133ac='';for(let _0xad532d=_0x536328['pieceNum_'];_0xad532d<_0x536328['pieces_']['length'];_0xad532d++)_0x536328['pieces_'][_0xad532d]!==''&&(_0x1133ac+='/'+encodeURIComponent(String(_0x536328['pieces_'][_0xad532d])));return _0x1133ac||'/';}function kt(_0x5a55b3,_0x4e3b1e=0x0){return _0x5a55b3['pieces_']['slice'](_0x5a55b3['pieceNum_']+_0x4e3b1e);}function To(_0x191249){if(_0x191249['pieceNum_']>=_0x191249['pieces_']['length'])return null;const _0x3ae16a=[];for(let _0x2f17f4=_0x191249['pieceNum_'];_0x2f17f4<_0x191249['pieces_']['length']-0x1;_0x2f17f4++)_0x3ae16a['push'](_0x191249['pieces_'][_0x2f17f4]);return new C(_0x3ae16a,0x0);}function A(_0x3d4a80,_0x1f2be6){const _0x2bac0b=[];for(let _0x4e56b0=_0x3d4a80['pieceNum_'];_0x4e56b0<_0x3d4a80['pieces_']['length'];_0x4e56b0++)_0x2bac0b['push'](_0x3d4a80['pieces_'][_0x4e56b0]);if(_0x1f2be6 instanceof C){for(let _0x349f40=_0x1f2be6['pieceNum_'];_0x349f40<_0x1f2be6['pieces_']['length'];_0x349f40++)_0x2bac0b['push'](_0x1f2be6['pieces_'][_0x349f40]);}else{const _0x2dda44=_0x1f2be6['split']('/');for(let _0x500d92=0x0;_0x500d92<_0x2dda44['length'];_0x500d92++)_0x2dda44[_0x500d92]['length']>0x0&&_0x2bac0b['push'](_0x2dda44[_0x500d92]);}return new C(_0x2bac0b,0x0);}function v(_0x57a271){return _0x57a271['pieceNum_']>=_0x57a271['pieces_']['length'];}function F(_0x1d9b88,_0x5decf4){const _0x414e70=y(_0x1d9b88),_0x719b5a=y(_0x5decf4);if(_0x414e70===null)return _0x5decf4;if(_0x414e70===_0x719b5a)return F(b(_0x1d9b88),b(_0x5decf4));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5decf4+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1d9b88+')');}function Th(_0x3f06de,_0x33d989){const _0x2918da=kt(_0x3f06de,0x0),_0x2bf891=kt(_0x33d989,0x0);for(let _0x1e5767=0x0;_0x1e5767<_0x2918da['length']&&_0x1e5767<_0x2bf891['length'];_0x1e5767++){const _0x462ebe=He(_0x2918da[_0x1e5767],_0x2bf891[_0x1e5767]);if(_0x462ebe!==0x0)return _0x462ebe;}return _0x2918da['length']===_0x2bf891['length']?0x0:_0x2918da['length']<_0x2bf891['length']?-0x1:0x1;}function qi(_0x1fe52e,_0x2548b8){if(we(_0x1fe52e)!==we(_0x2548b8))return!0x1;for(let _0x4271b7=_0x1fe52e['pieceNum_'],_0x487920=_0x2548b8['pieceNum_'];_0x4271b7<=_0x1fe52e['pieces_']['length'];_0x4271b7++,_0x487920++)if(_0x1fe52e['pieces_'][_0x4271b7]!==_0x2548b8['pieces_'][_0x487920])return!0x1;return!0x0;}function $(_0x4cade7,_0x1d08c4){let _0x599c87=_0x4cade7['pieceNum_'],_0x675906=_0x1d08c4['pieceNum_'];if(we(_0x4cade7)>we(_0x1d08c4))return!0x1;for(;_0x599c87<_0x4cade7['pieces_']['length'];){if(_0x4cade7['pieces_'][_0x599c87]!==_0x1d08c4['pieces_'][_0x675906])return!0x1;++_0x599c87,++_0x675906;}return!0x0;}class Sh{constructor(_0x506357,_0x1e17f1){this['errorPrefix_']=_0x1e17f1,this['parts_']=kt(_0x506357,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x52224a=0x0;_0x52224a<this['parts_']['length'];_0x52224a++)this['byteLength_']+=Pn(this['parts_'][_0x52224a]);So(this);}}function bh(_0x49c339,_0x5294d2){_0x49c339['parts_']['length']>0x0&&(_0x49c339['byteLength_']+=0x1),_0x49c339['parts_']['push'](_0x5294d2),_0x49c339['byteLength_']+=Pn(_0x5294d2),So(_0x49c339);}function Rh(_0x5e01ea){const _0x46af31=_0x5e01ea['parts_']['pop']();_0x5e01ea['byteLength_']-=Pn(_0x46af31),_0x5e01ea['parts_']['length']>0x0&&(_0x5e01ea['byteLength_']-=0x1);}function So(_0x23c556){if(_0x23c556['byteLength_']>Js)throw new Error(_0x23c556['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x23c556['byteLength_']+').');if(_0x23c556['parts_']['length']>Qs)throw new Error(_0x23c556['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x23c556));}function Ne(_0x1b96ac){return _0x1b96ac['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1b96ac['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x33111c,_0x64cd31;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x64cd31='visibilitychange',_0x33111c='hidden'):typeof document['mozHidden']<'u'?(_0x64cd31='mozvisibilitychange',_0x33111c='mozHidden'):typeof document['msHidden']<'u'?(_0x64cd31='msvisibilitychange',_0x33111c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x64cd31='webkitvisibilitychange',_0x33111c='webkitHidden')),this['visible_']=!0x0,_0x64cd31&&document['addEventListener'](_0x64cd31,()=>{const _0x106816=!document[_0x33111c];_0x106816!==this['visible_']&&(this['visible_']=_0x106816,this['trigger']('visible',_0x106816));},!0x1);}['getInitialEvent'](_0xb6245b){return f(_0xb6245b==='visible','Unknown\x20event\x20type:\x20'+_0xb6245b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x471bce,_0x47443c,_0xfcc089,_0x21e9e1,_0x2c0774,_0x55a211,_0x135a71,_0x100bbd){if(super(),this['repoInfo_']=_0x471bce,this['applicationId_']=_0x47443c,this['onDataUpdate_']=_0xfcc089,this['onConnectStatus_']=_0x21e9e1,this['onServerInfoUpdate_']=_0x2c0774,this['authTokenProvider_']=_0x55a211,this['appCheckTokenProvider_']=_0x135a71,this['authOverride_']=_0x100bbd,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x100bbd)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x471bce['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1308c6,_0x1953d3,_0x2a728f){const _0x2a4f0a=++this['requestNumber_'],_0x2b67ba={'r':_0x2a4f0a,'a':_0x1308c6,'b':_0x1953d3};this['log_'](O(_0x2b67ba)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2b67ba),_0x2a728f&&(this['requestCBHash_'][_0x2a4f0a]=_0x2a728f);}['get'](_0x206f67){this['initConnection_']();const _0x332f49=new Ve(),_0x50aeda={'action':'g','request':{'p':_0x206f67['_path']['toString'](),'q':_0x206f67['_queryObject']},'onComplete':_0x5431d5=>{const _0xf12918=_0x5431d5['d'];_0x5431d5['s']==='ok'?_0x332f49['resolve'](_0xf12918):_0x332f49['reject'](_0xf12918);}};this['outstandingGets_']['push'](_0x50aeda),this['outstandingGetCount_']++;const _0x5d7c7e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5d7c7e),_0x332f49['promise'];}['listen'](_0x4a33a9,_0x415a53,_0x345870,_0x201d24){this['initConnection_']();const _0x1a891e=_0x4a33a9['_queryIdentifier'],_0x3d4911=_0x4a33a9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3d4911+'\x20'+_0x1a891e),this['listens']['has'](_0x3d4911)||this['listens']['set'](_0x3d4911,new Map()),f(_0x4a33a9['_queryParams']['isDefault']()||!_0x4a33a9['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3d4911)['has'](_0x1a891e),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5ef9c2={'onComplete':_0x201d24,'hashFn':_0x415a53,'query':_0x4a33a9,'tag':_0x345870};this['listens']['get'](_0x3d4911)['set'](_0x1a891e,_0x5ef9c2),this['connected_']&&this['sendListen_'](_0x5ef9c2);}['sendGet_'](_0x351a6a){const _0x3a649b=this['outstandingGets_'][_0x351a6a];this['sendRequest']('g',_0x3a649b['request'],_0xd82ba3=>{delete this['outstandingGets_'][_0x351a6a],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3a649b['onComplete']&&_0x3a649b['onComplete'](_0xd82ba3);});}['sendListen_'](_0x5b5b28){const _0x203512=_0x5b5b28['query'],_0x512516=_0x203512['_path']['toString'](),_0x5b95be=_0x203512['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x512516+'\x20for\x20'+_0x5b95be);const _0x6af139={'p':_0x512516},_0x1f3235='q';_0x5b5b28['tag']&&(_0x6af139['q']=_0x203512['_queryObject'],_0x6af139['t']=_0x5b5b28['tag']),_0x6af139['h']=_0x5b5b28['hashFn'](),this['sendRequest'](_0x1f3235,_0x6af139,_0x39b1aa=>{const _0x365b09=_0x39b1aa['d'],_0x738afe=_0x39b1aa['s'];ie['warnOnListenWarnings_'](_0x365b09,_0x203512),(this['listens']['get'](_0x512516)&&this['listens']['get'](_0x512516)['get'](_0x5b95be))===_0x5b5b28&&(this['log_']('listen\x20response',_0x39b1aa),_0x738afe!=='ok'&&this['removeListen_'](_0x512516,_0x5b95be),_0x5b5b28['onComplete']&&_0x5b5b28['onComplete'](_0x738afe,_0x365b09));});}static['warnOnListenWarnings_'](_0x465643,_0x3fa5d1){if(_0x465643&&typeof _0x465643=='object'&&Y(_0x465643,'w')){const _0x2d64e5=Oe(_0x465643,'w');if(Array['isArray'](_0x2d64e5)&&~_0x2d64e5['indexOf']('no_index')){const _0x22cb99='\x22.indexOn\x22:\x20\x22'+_0x3fa5d1['_queryParams']['getIndex']()['toString']()+'\x22',_0x32f6a9=_0x3fa5d1['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x22cb99+'\x20at\x20'+_0x32f6a9+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2eeb4f){this['authToken_']=_0x2eeb4f,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2eeb4f);}['reduceReconnectDelayIfAdminCredential_'](_0x525d9b){(_0x525d9b&&_0x525d9b['length']===0x28||vc(_0x525d9b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x34cefb){this['appCheckToken_']=_0x34cefb,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x38086f=this['authToken_'],_0x285813=yc(_0x38086f)?'auth':'gauth',_0x3438d7={'cred':_0x38086f};this['authOverride_']===null?_0x3438d7['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3438d7['authvar']=this['authOverride_']),this['sendRequest'](_0x285813,_0x3438d7,_0x38a782=>{const _0x44d41e=_0x38a782['s'],_0x5e998f=_0x38a782['d']||'error';this['authToken_']===_0x38086f&&(_0x44d41e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x44d41e,_0x5e998f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x481167=>{const _0x4b0723=_0x481167['s'],_0x47a107=_0x481167['d']||'error';_0x4b0723==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4b0723,_0x47a107);});}['unlisten'](_0x4973f2,_0x11fc1b){const _0x15b32a=_0x4973f2['_path']['toString'](),_0x50a3df=_0x4973f2['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x15b32a+'\x20'+_0x50a3df),f(_0x4973f2['_queryParams']['isDefault']()||!_0x4973f2['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x15b32a,_0x50a3df)&&this['connected_']&&this['sendUnlisten_'](_0x15b32a,_0x50a3df,_0x4973f2['_queryObject'],_0x11fc1b);}['sendUnlisten_'](_0x2abd4e,_0x9c67fb,_0x268542,_0x5e2328){this['log_']('Unlisten\x20on\x20'+_0x2abd4e+'\x20for\x20'+_0x9c67fb);const _0x2b9678={'p':_0x2abd4e},_0x344828='n';_0x5e2328&&(_0x2b9678['q']=_0x268542,_0x2b9678['t']=_0x5e2328),this['sendRequest'](_0x344828,_0x2b9678);}['onDisconnectPut'](_0x4da247,_0x121242,_0x1678c8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4da247,_0x121242,_0x1678c8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4da247,'action':'o','data':_0x121242,'onComplete':_0x1678c8});}['onDisconnectMerge'](_0xfd5a49,_0x5a24e1,_0x259e4e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xfd5a49,_0x5a24e1,_0x259e4e):this['onDisconnectRequestQueue_']['push']({'pathString':_0xfd5a49,'action':'om','data':_0x5a24e1,'onComplete':_0x259e4e});}['onDisconnectCancel'](_0x8acdd1,_0x10daba){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x8acdd1,null,_0x10daba):this['onDisconnectRequestQueue_']['push']({'pathString':_0x8acdd1,'action':'oc','data':null,'onComplete':_0x10daba});}['sendOnDisconnect_'](_0x5430a9,_0x248ffc,_0x72ba3a,_0x3917f3){const _0x3cabce={'p':_0x248ffc,'d':_0x72ba3a};this['log_']('onDisconnect\x20'+_0x5430a9,_0x3cabce),this['sendRequest'](_0x5430a9,_0x3cabce,_0x2dd582=>{_0x3917f3&&setTimeout(()=>{_0x3917f3(_0x2dd582['s'],_0x2dd582['d']);},Math['floor'](0x0));});}['put'](_0x13a498,_0x294395,_0x3c123f,_0x464fb6){this['putInternal']('p',_0x13a498,_0x294395,_0x3c123f,_0x464fb6);}['merge'](_0x389719,_0x44b9b2,_0x136525,_0x1fe2f6){this['putInternal']('m',_0x389719,_0x44b9b2,_0x136525,_0x1fe2f6);}['putInternal'](_0x23e031,_0x34223a,_0x412460,_0x18b940,_0x7930d2){this['initConnection_']();const _0x395155={'p':_0x34223a,'d':_0x412460};_0x7930d2!==void 0x0&&(_0x395155['h']=_0x7930d2),this['outstandingPuts_']['push']({'action':_0x23e031,'request':_0x395155,'onComplete':_0x18b940}),this['outstandingPutCount_']++;const _0x4f69a4=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4f69a4):this['log_']('Buffering\x20put:\x20'+_0x34223a);}['sendPut_'](_0x18ef0d){const _0x317712=this['outstandingPuts_'][_0x18ef0d]['action'],_0x2a4b6f=this['outstandingPuts_'][_0x18ef0d]['request'],_0x3ae0bd=this['outstandingPuts_'][_0x18ef0d]['onComplete'];this['outstandingPuts_'][_0x18ef0d]['queued']=this['connected_'],this['sendRequest'](_0x317712,_0x2a4b6f,_0x582816=>{this['log_'](_0x317712+'\x20response',_0x582816),delete this['outstandingPuts_'][_0x18ef0d],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3ae0bd&&_0x3ae0bd(_0x582816['s'],_0x582816['d']);});}['reportStats'](_0x3f0c61){if(this['connected_']){const _0x255e0d={'c':_0x3f0c61};this['log_']('reportStats',_0x255e0d),this['sendRequest']('s',_0x255e0d,_0x454aaa=>{if(_0x454aaa['s']!=='ok'){const _0x45a2a1=_0x454aaa['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x45a2a1);}});}}['onDataMessage_'](_0x857f31){if('r'in _0x857f31){this['log_']('from\x20server:\x20'+O(_0x857f31));const _0x1c2c82=_0x857f31['r'],_0x5e7f65=this['requestCBHash_'][_0x1c2c82];_0x5e7f65&&(delete this['requestCBHash_'][_0x1c2c82],_0x5e7f65(_0x857f31['b']));}else{if('error'in _0x857f31)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x857f31['error'];'a'in _0x857f31&&this['onDataPush_'](_0x857f31['a'],_0x857f31['b']);}}['onDataPush_'](_0x2f8ff0,_0x431407){this['log_']('handleServerMessage',_0x2f8ff0,_0x431407),_0x2f8ff0==='d'?this['onDataUpdate_'](_0x431407['p'],_0x431407['d'],!0x1,_0x431407['t']):_0x2f8ff0==='m'?this['onDataUpdate_'](_0x431407['p'],_0x431407['d'],!0x0,_0x431407['t']):_0x2f8ff0==='c'?this['onListenRevoked_'](_0x431407['p'],_0x431407['q']):_0x2f8ff0==='ac'?this['onAuthRevoked_'](_0x431407['s'],_0x431407['d']):_0x2f8ff0==='apc'?this['onAppCheckRevoked_'](_0x431407['s'],_0x431407['d']):_0x2f8ff0==='sd'?this['onSecurityDebugPacket_'](_0x431407):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2f8ff0)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3dc40c,_0x509f8a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3dc40c),this['lastSessionId']=_0x509f8a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4d961f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4d961f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x38330d){_0x38330d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x38330d;}['onOnline_'](_0x2c44e0){_0x2c44e0?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x46d571=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x385895=Math['max'](0x0,this['reconnectDelay_']-_0x46d571);_0x385895=Math['random']()*_0x385895,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x385895+'ms'),this['scheduleConnect_'](_0x385895),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x31bccd=this['onDataMessage_']['bind'](this),_0x6e3d4=this['onReady_']['bind'](this),_0x47860e=this['onRealtimeDisconnect_']['bind'](this),_0x4668c1=this['id']+':'+ie['nextConnectionId_']++,_0x145fd3=this['lastSessionId'];let _0x57d38c=!0x1,_0x3dcfbe=null;const _0x3a92f7=function(){_0x3dcfbe?_0x3dcfbe['close']():(_0x57d38c=!0x0,_0x47860e());},_0x143eee=function(_0x120a2c){f(_0x3dcfbe,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3dcfbe['sendRequest'](_0x120a2c);};this['realtime_']={'close':_0x3a92f7,'sendRequest':_0x143eee};const _0x3f434c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x41ef77,_0x305922]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3f434c),this['appCheckTokenProvider_']['getToken'](_0x3f434c)]);_0x57d38c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x41ef77&&_0x41ef77['accessToken'],this['appCheckToken_']=_0x305922&&_0x305922['token'],_0x3dcfbe=new wh(_0x4668c1,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x31bccd,_0x6e3d4,_0x47860e,_0x154b26=>{U(_0x154b26+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x145fd3));}catch(_0x7bfb37){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x7bfb37),_0x57d38c||(this['repoInfo_']['nodeAdmin']&&U(_0x7bfb37),_0x3a92f7());}}}['interrupt'](_0x333d18){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x333d18),this['interruptReasons_'][_0x333d18]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x16e2e7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x16e2e7),delete this['interruptReasons_'][_0x16e2e7],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x18c5d0){const _0x35ebe6=_0x18c5d0-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x35ebe6});}['cancelSentTransactions_'](){for(let _0x5d5e4a=0x0;_0x5d5e4a<this['outstandingPuts_']['length'];_0x5d5e4a++){const _0x222cbf=this['outstandingPuts_'][_0x5d5e4a];_0x222cbf&&'h'in _0x222cbf['request']&&_0x222cbf['queued']&&(_0x222cbf['onComplete']&&_0x222cbf['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5d5e4a],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1211fe,_0x2b1594){let _0xb481ca;_0x2b1594?_0xb481ca=_0x2b1594['map'](_0x298856=>Bi(_0x298856))['join']('$'):_0xb481ca='default';const _0x329e4f=this['removeListen_'](_0x1211fe,_0xb481ca);_0x329e4f&&_0x329e4f['onComplete']&&_0x329e4f['onComplete']('permission_denied');}['removeListen_'](_0x4c62fe,_0x32667b){const _0x30da9b=new C(_0x4c62fe)['toString']();let _0x45a4f1;if(this['listens']['has'](_0x30da9b)){const _0x24b06c=this['listens']['get'](_0x30da9b);_0x45a4f1=_0x24b06c['get'](_0x32667b),_0x24b06c['delete'](_0x32667b),_0x24b06c['size']===0x0&&this['listens']['delete'](_0x30da9b);}else _0x45a4f1=void 0x0;return _0x45a4f1;}['onAuthRevoked_'](_0x5536ef,_0x233a2a){L('Auth\x20token\x20revoked:\x20'+_0x5536ef+'/'+_0x233a2a),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5536ef==='invalid_token'||_0x5536ef==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xb5b35d,_0x527fdc){L('App\x20check\x20token\x20revoked:\x20'+_0xb5b35d+'/'+_0x527fdc),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xb5b35d==='invalid_token'||_0xb5b35d==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x189fcf){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x189fcf):'msg'in _0x189fcf&&console['log']('FIREBASE:\x20'+_0x189fcf['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xe03ea1 of this['listens']['values']())for(const _0x3e2c21 of _0xe03ea1['values']())this['sendListen_'](_0x3e2c21);for(let _0x245c45=0x0;_0x245c45<this['outstandingPuts_']['length'];_0x245c45++)this['outstandingPuts_'][_0x245c45]&&this['sendPut_'](_0x245c45);for(;this['onDisconnectRequestQueue_']['length'];){const _0x43521a=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x43521a['action'],_0x43521a['pathString'],_0x43521a['data'],_0x43521a['onComplete']);}for(let _0x27ad3a=0x0;_0x27ad3a<this['outstandingGets_']['length'];_0x27ad3a++)this['outstandingGets_'][_0x27ad3a]&&this['sendGet_'](_0x27ad3a);}['sendConnectStats_'](){const _0x907532={};let _0x326758='js';_0x907532['sdk.'+_0x326758+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x907532['framework.cordova']=0x1:qr()&&(_0x907532['framework.reactnative']=0x1),this['reportStats'](_0x907532);}['shouldReconnect_'](){const _0x289bba=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x289bba;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xb7670c,_0x16869b){this['name']=_0xb7670c,this['node']=_0x16869b;}static['Wrap'](_0x46a829,_0x4a7172){return new E(_0x46a829,_0x4a7172);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3dc914,_0x5603d5){const _0x358000=new E(xe,_0x3dc914),_0x2234c4=new E(xe,_0x5603d5);return this['compare'](_0x358000,_0x2234c4)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x162ea7){Xt=_0x162ea7;}['compare'](_0x4a874e,_0x41b0f3){return He(_0x4a874e['name'],_0x41b0f3['name']);}['isDefinedOn'](_0x4db7de){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x280c9a,_0x5dc875){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x1f66e6,_0x384121){return f(typeof _0x1f66e6=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1f66e6,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x430173,_0x567f6c,_0x1127f3,_0x4cbb6b,_0x14119c=null){this['isReverse_']=_0x4cbb6b,this['resultGenerator_']=_0x14119c,this['nodeStack_']=[];let _0x46a32a=0x1;for(;!_0x430173['isEmpty']();)if(_0x430173=_0x430173,_0x46a32a=_0x567f6c?_0x1127f3(_0x430173['key'],_0x567f6c):0x1,_0x4cbb6b&&(_0x46a32a*=-0x1),_0x46a32a<0x0)this['isReverse_']?_0x430173=_0x430173['left']:_0x430173=_0x430173['right'];else{if(_0x46a32a===0x0){this['nodeStack_']['push'](_0x430173);break;}else this['nodeStack_']['push'](_0x430173),this['isReverse_']?_0x430173=_0x430173['right']:_0x430173=_0x430173['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x123c14=this['nodeStack_']['pop'](),_0xd4bc45;if(this['resultGenerator_']?_0xd4bc45=this['resultGenerator_'](_0x123c14['key'],_0x123c14['value']):_0xd4bc45={'key':_0x123c14['key'],'value':_0x123c14['value']},this['isReverse_']){for(_0x123c14=_0x123c14['left'];!_0x123c14['isEmpty']();)this['nodeStack_']['push'](_0x123c14),_0x123c14=_0x123c14['right'];}else{for(_0x123c14=_0x123c14['right'];!_0x123c14['isEmpty']();)this['nodeStack_']['push'](_0x123c14),_0x123c14=_0x123c14['left'];}return _0xd4bc45;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x41cd6f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x41cd6f['key'],_0x41cd6f['value']):{'key':_0x41cd6f['key'],'value':_0x41cd6f['value']};}}class M{constructor(_0x13e468,_0x325e4e,_0x312e37,_0x3d095f,_0x2e1720){this['key']=_0x13e468,this['value']=_0x325e4e,this['color']=_0x312e37??M['RED'],this['left']=_0x3d095f??B['EMPTY_NODE'],this['right']=_0x2e1720??B['EMPTY_NODE'];}['copy'](_0x4f5179,_0x1de953,_0x198cc7,_0x1ac673,_0x4206c9){return new M(_0x4f5179??this['key'],_0x1de953??this['value'],_0x198cc7??this['color'],_0x1ac673??this['left'],_0x4206c9??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3b37bd){return this['left']['inorderTraversal'](_0x3b37bd)||!!_0x3b37bd(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3b37bd);}['reverseTraversal'](_0x5ce26e){return this['right']['reverseTraversal'](_0x5ce26e)||_0x5ce26e(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5ce26e);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2e0796,_0x489e51,_0x1ae6e5){let _0x27b6a4=this;const _0x40ce07=_0x1ae6e5(_0x2e0796,_0x27b6a4['key']);return _0x40ce07<0x0?_0x27b6a4=_0x27b6a4['copy'](null,null,null,_0x27b6a4['left']['insert'](_0x2e0796,_0x489e51,_0x1ae6e5),null):_0x40ce07===0x0?_0x27b6a4=_0x27b6a4['copy'](null,_0x489e51,null,null,null):_0x27b6a4=_0x27b6a4['copy'](null,null,null,null,_0x27b6a4['right']['insert'](_0x2e0796,_0x489e51,_0x1ae6e5)),_0x27b6a4['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x550002=this;return!_0x550002['left']['isRed_']()&&!_0x550002['left']['left']['isRed_']()&&(_0x550002=_0x550002['moveRedLeft_']()),_0x550002=_0x550002['copy'](null,null,null,_0x550002['left']['removeMin_'](),null),_0x550002['fixUp_']();}['remove'](_0x170db8,_0x4bac24){let _0x403456,_0xe7d117;if(_0x403456=this,_0x4bac24(_0x170db8,_0x403456['key'])<0x0)!_0x403456['left']['isEmpty']()&&!_0x403456['left']['isRed_']()&&!_0x403456['left']['left']['isRed_']()&&(_0x403456=_0x403456['moveRedLeft_']()),_0x403456=_0x403456['copy'](null,null,null,_0x403456['left']['remove'](_0x170db8,_0x4bac24),null);else{if(_0x403456['left']['isRed_']()&&(_0x403456=_0x403456['rotateRight_']()),!_0x403456['right']['isEmpty']()&&!_0x403456['right']['isRed_']()&&!_0x403456['right']['left']['isRed_']()&&(_0x403456=_0x403456['moveRedRight_']()),_0x4bac24(_0x170db8,_0x403456['key'])===0x0){if(_0x403456['right']['isEmpty']())return B['EMPTY_NODE'];_0xe7d117=_0x403456['right']['min_'](),_0x403456=_0x403456['copy'](_0xe7d117['key'],_0xe7d117['value'],null,null,_0x403456['right']['removeMin_']());}_0x403456=_0x403456['copy'](null,null,null,null,_0x403456['right']['remove'](_0x170db8,_0x4bac24));}return _0x403456['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x35d6ab=this;return _0x35d6ab['right']['isRed_']()&&!_0x35d6ab['left']['isRed_']()&&(_0x35d6ab=_0x35d6ab['rotateLeft_']()),_0x35d6ab['left']['isRed_']()&&_0x35d6ab['left']['left']['isRed_']()&&(_0x35d6ab=_0x35d6ab['rotateRight_']()),_0x35d6ab['left']['isRed_']()&&_0x35d6ab['right']['isRed_']()&&(_0x35d6ab=_0x35d6ab['colorFlip_']()),_0x35d6ab;}['moveRedLeft_'](){let _0xd46732=this['colorFlip_']();return _0xd46732['right']['left']['isRed_']()&&(_0xd46732=_0xd46732['copy'](null,null,null,null,_0xd46732['right']['rotateRight_']()),_0xd46732=_0xd46732['rotateLeft_'](),_0xd46732=_0xd46732['colorFlip_']()),_0xd46732;}['moveRedRight_'](){let _0x43ceab=this['colorFlip_']();return _0x43ceab['left']['left']['isRed_']()&&(_0x43ceab=_0x43ceab['rotateRight_'](),_0x43ceab=_0x43ceab['colorFlip_']()),_0x43ceab;}['rotateLeft_'](){const _0x301b1d=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x301b1d,null);}['rotateRight_'](){const _0x59451a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x59451a);}['colorFlip_'](){const _0x5bae7e=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x47d9fb=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5bae7e,_0x47d9fb);}['checkMaxDepth_'](){const _0x5460c2=this['check_']();return Math['pow'](0x2,_0x5460c2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x494e15=this['left']['check_']();if(_0x494e15!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x494e15+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x7f420b,_0x48984c,_0xfb2ceb,_0x2b861f,_0x5b5911){return this;}['insert'](_0x2b4a15,_0x2437d8,_0xdf9d6f){return new M(_0x2b4a15,_0x2437d8,null);}['remove'](_0x1f6da1,_0x75a437){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x200f09){return!0x1;}['reverseTraversal'](_0x5a8a1b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x36859e,_0x536b34=B['EMPTY_NODE']){this['comparator_']=_0x36859e,this['root_']=_0x536b34;}['insert'](_0x1add70,_0x5541c8){return new B(this['comparator_'],this['root_']['insert'](_0x1add70,_0x5541c8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x566a78){return new B(this['comparator_'],this['root_']['remove'](_0x566a78,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x5bbba6){let _0x145394,_0x4bebbc=this['root_'];for(;!_0x4bebbc['isEmpty']();){if(_0x145394=this['comparator_'](_0x5bbba6,_0x4bebbc['key']),_0x145394===0x0)return _0x4bebbc['value'];_0x145394<0x0?_0x4bebbc=_0x4bebbc['left']:_0x145394>0x0&&(_0x4bebbc=_0x4bebbc['right']);}return null;}['getPredecessorKey'](_0x55e9ae){let _0x12a70f,_0x2b6940=this['root_'],_0x5c7a40=null;for(;!_0x2b6940['isEmpty']();)if(_0x12a70f=this['comparator_'](_0x55e9ae,_0x2b6940['key']),_0x12a70f===0x0){if(_0x2b6940['left']['isEmpty']())return _0x5c7a40?_0x5c7a40['key']:null;for(_0x2b6940=_0x2b6940['left'];!_0x2b6940['right']['isEmpty']();)_0x2b6940=_0x2b6940['right'];return _0x2b6940['key'];}else _0x12a70f<0x0?_0x2b6940=_0x2b6940['left']:_0x12a70f>0x0&&(_0x5c7a40=_0x2b6940,_0x2b6940=_0x2b6940['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x8b3d53){return this['root_']['inorderTraversal'](_0x8b3d53);}['reverseTraversal'](_0x4aa4dd){return this['root_']['reverseTraversal'](_0x4aa4dd);}['getIterator'](_0x35b381){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x35b381);}['getIteratorFrom'](_0x30835d,_0x44c242){return new Zt(this['root_'],_0x30835d,this['comparator_'],!0x1,_0x44c242);}['getReverseIteratorFrom'](_0x36699c,_0x1597b6){return new Zt(this['root_'],_0x36699c,this['comparator_'],!0x0,_0x1597b6);}['getReverseIterator'](_0x53b761){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x53b761);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x24d31c,_0x1874ca){return He(_0x24d31c['name'],_0x1874ca['name']);}function ji(_0x806263,_0x332c18){return He(_0x806263,_0x332c18);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x503983){vi=_0x503983;}const Ro=function(_0xdfe13a){return typeof _0xdfe13a=='number'?'number:'+so(_0xdfe13a):'string:'+_0xdfe13a;},Ao=function(_0x3ee3ba){if(_0x3ee3ba['isLeafNode']()){const _0x490a73=_0x3ee3ba['val']();f(typeof _0x490a73=='string'||typeof _0x490a73=='number'||typeof _0x490a73=='object'&&Y(_0x490a73,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3ee3ba===vi||_0x3ee3ba['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3ee3ba===vi||_0x3ee3ba['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x12d541){er=_0x12d541;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x42bf19,_0x59355c=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x42bf19,this['priorityNode_']=_0x59355c,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x2962e6){return new D(this['value_'],_0x2962e6);}['getImmediateChild'](_0x51152f){return _0x51152f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4a7132){return v(_0x4a7132)?this:y(_0x4a7132)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x27e6fa,_0x432246){return null;}['updateImmediateChild'](_0x2bfc99,_0x3aef6d){return _0x2bfc99==='.priority'?this['updatePriority'](_0x3aef6d):_0x3aef6d['isEmpty']()&&_0x2bfc99!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2bfc99,_0x3aef6d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5bf773,_0x4289f7){const _0x298dd1=y(_0x5bf773);return _0x298dd1===null?_0x4289f7:_0x4289f7['isEmpty']()&&_0x298dd1!=='.priority'?this:(f(_0x298dd1!=='.priority'||we(_0x5bf773)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x298dd1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x5bf773),_0x4289f7)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x520f0d,_0x20ef60){return!0x1;}['val'](_0x2cb9ea){return _0x2cb9ea&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x34786f='';this['priorityNode_']['isEmpty']()||(_0x34786f+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1acdf2=typeof this['value_'];_0x34786f+=_0x1acdf2+':',_0x1acdf2==='number'?_0x34786f+=so(this['value_']):_0x34786f+=this['value_'],this['lazyHash_']=no(_0x34786f);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xdf0247){return _0xdf0247===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xdf0247 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xdf0247['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xdf0247));}['compareToLeafNode_'](_0x38c858){const _0x19ced7=typeof _0x38c858['value_'],_0x21e23e=typeof this['value_'],_0x548d00=D['VALUE_TYPE_ORDER']['indexOf'](_0x19ced7),_0x11cec5=D['VALUE_TYPE_ORDER']['indexOf'](_0x21e23e);return f(_0x548d00>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x19ced7),f(_0x11cec5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x21e23e),_0x548d00===_0x11cec5?_0x21e23e==='object'?0x0:this['value_']<_0x38c858['value_']?-0x1:this['value_']===_0x38c858['value_']?0x0:0x1:_0x11cec5-_0x548d00;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1b356b){if(_0x1b356b===this)return!0x0;if(_0x1b356b['isLeafNode']()){const _0x261c95=_0x1b356b;return this['value_']===_0x261c95['value_']&&this['priorityNode_']['equals'](_0x261c95['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x28c0c){ko=_0x28c0c;}function xh(_0x9ed121){No=_0x9ed121;}class Fh extends On{['compare'](_0x55c9f8,_0xb1973c){const _0x4c2807=_0x55c9f8['node']['getPriority'](),_0x510635=_0xb1973c['node']['getPriority'](),_0x2a31ef=_0x4c2807['compareTo'](_0x510635);return _0x2a31ef===0x0?He(_0x55c9f8['name'],_0xb1973c['name']):_0x2a31ef;}['isDefinedOn'](_0x443ca8){return!_0x443ca8['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xd2ef0a,_0x1c11c7){return!_0xd2ef0a['getPriority']()['equals'](_0x1c11c7['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x22b389,_0x477188){const _0x2eb553=ko(_0x22b389);return new E(_0x477188,new D('[PRIORITY-POST]',_0x2eb553));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0xd52ebd){const _0x541a0b=_0x24c387=>parseInt(Math['log'](_0x24c387)/Uh,0xa),_0x20ddd7=_0x3dba9c=>parseInt(Array(_0x3dba9c+0x1)['join']('1'),0x2);this['count']=_0x541a0b(_0xd52ebd+0x1),this['current_']=this['count']-0x1;const _0x3c1a52=_0x20ddd7(this['count']);this['bits_']=_0xd52ebd+0x1&_0x3c1a52;}['nextBitIsOne'](){const _0xe43325=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xe43325;}}const dn=function(_0x2bc930,_0x1dd008,_0x40bbb2,_0x96faf1){_0x2bc930['sort'](_0x1dd008);const _0x3802f8=function(_0x4d0179,_0x200ade){const _0x669ab2=_0x200ade-_0x4d0179;let _0x5dc7bf,_0x3f8c5f;if(_0x669ab2===0x0)return null;if(_0x669ab2===0x1)return _0x5dc7bf=_0x2bc930[_0x4d0179],_0x3f8c5f=_0x40bbb2?_0x40bbb2(_0x5dc7bf):_0x5dc7bf,new M(_0x3f8c5f,_0x5dc7bf['node'],M['BLACK'],null,null);{const _0x3525a6=parseInt(_0x669ab2/0x2,0xa)+_0x4d0179,_0x34fe33=_0x3802f8(_0x4d0179,_0x3525a6),_0x1882e8=_0x3802f8(_0x3525a6+0x1,_0x200ade);return _0x5dc7bf=_0x2bc930[_0x3525a6],_0x3f8c5f=_0x40bbb2?_0x40bbb2(_0x5dc7bf):_0x5dc7bf,new M(_0x3f8c5f,_0x5dc7bf['node'],M['BLACK'],_0x34fe33,_0x1882e8);}},_0x565ec9=function(_0x359340){let _0xfd6274=null,_0x5ca90f=null,_0xc1a6c7=_0x2bc930['length'];const _0xa6710d=function(_0x3641ca,_0xc387f9){const _0x5e4432=_0xc1a6c7-_0x3641ca,_0x4736b7=_0xc1a6c7;_0xc1a6c7-=_0x3641ca;const _0x1268f7=_0x3802f8(_0x5e4432+0x1,_0x4736b7),_0x2bba7d=_0x2bc930[_0x5e4432],_0x274420=_0x40bbb2?_0x40bbb2(_0x2bba7d):_0x2bba7d;_0x2d3ed9(new M(_0x274420,_0x2bba7d['node'],_0xc387f9,null,_0x1268f7));},_0x2d3ed9=function(_0x402894){_0xfd6274?(_0xfd6274['left']=_0x402894,_0xfd6274=_0x402894):(_0x5ca90f=_0x402894,_0xfd6274=_0x402894);};for(let _0x169857=0x0;_0x169857<_0x359340['count'];++_0x169857){const _0xccb74=_0x359340['nextBitIsOne'](),_0x464ba5=Math['pow'](0x2,_0x359340['count']-(_0x169857+0x1));_0xccb74?_0xa6710d(_0x464ba5,M['BLACK']):(_0xa6710d(_0x464ba5,M['BLACK']),_0xa6710d(_0x464ba5,M['RED']));}return _0x5ca90f;},_0x49b54c=new Wh(_0x2bc930['length']),_0xae8855=_0x565ec9(_0x49b54c);return new B(_0x96faf1||_0x1dd008,_0xae8855);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x72bdba,_0x5a2052){this['indexes_']=_0x72bdba,this['indexSet_']=_0x5a2052;}['get'](_0x4f1a47){const _0x4728d7=Oe(this['indexes_'],_0x4f1a47);if(!_0x4728d7)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4f1a47);return _0x4728d7 instanceof B?_0x4728d7:null;}['hasIndex'](_0x4fdb4d){return Y(this['indexSet_'],_0x4fdb4d['toString']());}['addIndex'](_0x273192,_0xda423d){f(_0x273192!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x46d74c=[];let _0x2a07b6=!0x1;const _0x1cc0d9=_0xda423d['getIterator'](E['Wrap']);let _0x5a6cee=_0x1cc0d9['getNext']();for(;_0x5a6cee;)_0x2a07b6=_0x2a07b6||_0x273192['isDefinedOn'](_0x5a6cee['node']),_0x46d74c['push'](_0x5a6cee),_0x5a6cee=_0x1cc0d9['getNext']();let _0x2b45e9;_0x2a07b6?_0x2b45e9=dn(_0x46d74c,_0x273192['getCompare']()):_0x2b45e9=je;const _0xb38deb=_0x273192['toString'](),_0x190cd5={...this['indexSet_']};_0x190cd5[_0xb38deb]=_0x273192;const _0x56455d={...this['indexes_']};return _0x56455d[_0xb38deb]=_0x2b45e9,new ee(_0x56455d,_0x190cd5);}['addToIndexes'](_0x4d5deb,_0x3e8c5e){const _0x5abe5d=ln(this['indexes_'],(_0x4de760,_0x3f9b97)=>{const _0x67d093=Oe(this['indexSet_'],_0x3f9b97);if(f(_0x67d093,'Missing\x20index\x20implementation\x20for\x20'+_0x3f9b97),_0x4de760===je){if(_0x67d093['isDefinedOn'](_0x4d5deb['node'])){const _0x51ddf9=[],_0x23febd=_0x3e8c5e['getIterator'](E['Wrap']);let _0x1c5a65=_0x23febd['getNext']();for(;_0x1c5a65;)_0x1c5a65['name']!==_0x4d5deb['name']&&_0x51ddf9['push'](_0x1c5a65),_0x1c5a65=_0x23febd['getNext']();return _0x51ddf9['push'](_0x4d5deb),dn(_0x51ddf9,_0x67d093['getCompare']());}else return je;}else{const _0x4f4400=_0x3e8c5e['get'](_0x4d5deb['name']);let _0x226f17=_0x4de760;return _0x4f4400&&(_0x226f17=_0x226f17['remove'](new E(_0x4d5deb['name'],_0x4f4400))),_0x226f17['insert'](_0x4d5deb,_0x4d5deb['node']);}});return new ee(_0x5abe5d,this['indexSet_']);}['removeFromIndexes'](_0x5bcdd5,_0x184f1b){const _0x4630f9=ln(this['indexes_'],_0x10a1f1=>{if(_0x10a1f1===je)return _0x10a1f1;{const _0x4beb0a=_0x184f1b['get'](_0x5bcdd5['name']);return _0x4beb0a?_0x10a1f1['remove'](new E(_0x5bcdd5['name'],_0x4beb0a)):_0x10a1f1;}});return new ee(_0x4630f9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x1e0005,_0x1f545c,_0x3b2a90){this['children_']=_0x1e0005,this['priorityNode_']=_0x1f545c,this['indexMap_']=_0x3b2a90,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x11fa10){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x11fa10,this['indexMap_']);}['getImmediateChild'](_0x2b06f8){if(_0x2b06f8==='.priority')return this['getPriority']();{const _0x3c04b6=this['children_']['get'](_0x2b06f8);return _0x3c04b6===null?gt:_0x3c04b6;}}['getChild'](_0x27dc9d){const _0x341bb9=y(_0x27dc9d);return _0x341bb9===null?this:this['getImmediateChild'](_0x341bb9)['getChild'](b(_0x27dc9d));}['hasChild'](_0x5b943b){return this['children_']['get'](_0x5b943b)!==null;}['updateImmediateChild'](_0x2895ec,_0x43f3bf){if(f(_0x43f3bf,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2895ec==='.priority')return this['updatePriority'](_0x43f3bf);{const _0x1fa9af=new E(_0x2895ec,_0x43f3bf);let _0x2ea257,_0xa205fa;_0x43f3bf['isEmpty']()?(_0x2ea257=this['children_']['remove'](_0x2895ec),_0xa205fa=this['indexMap_']['removeFromIndexes'](_0x1fa9af,this['children_'])):(_0x2ea257=this['children_']['insert'](_0x2895ec,_0x43f3bf),_0xa205fa=this['indexMap_']['addToIndexes'](_0x1fa9af,this['children_']));const _0x184491=_0x2ea257['isEmpty']()?gt:this['priorityNode_'];return new g(_0x2ea257,_0x184491,_0xa205fa);}}['updateChild'](_0x5327b9,_0x24a3e1){const _0x7b16cc=y(_0x5327b9);if(_0x7b16cc===null)return _0x24a3e1;{f(y(_0x5327b9)!=='.priority'||we(_0x5327b9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1a15dd=this['getImmediateChild'](_0x7b16cc)['updateChild'](b(_0x5327b9),_0x24a3e1);return this['updateImmediateChild'](_0x7b16cc,_0x1a15dd);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x453009){if(this['isEmpty']())return null;const _0x5b1a2d={};let _0x1a84d4=0x0,_0x2e3cba=0x0,_0x51577a=!0x0;if(this['forEachChild'](R,(_0x5915cb,_0x12a2d0)=>{_0x5b1a2d[_0x5915cb]=_0x12a2d0['val'](_0x453009),_0x1a84d4++,_0x51577a&&g['INTEGER_REGEXP_']['test'](_0x5915cb)?_0x2e3cba=Math['max'](_0x2e3cba,Number(_0x5915cb)):_0x51577a=!0x1;}),!_0x453009&&_0x51577a&&_0x2e3cba<0x2*_0x1a84d4){const _0x19d724=[];for(const _0x352177 in _0x5b1a2d)_0x19d724[_0x352177]=_0x5b1a2d[_0x352177];return _0x19d724;}else return _0x453009&&!this['getPriority']()['isEmpty']()&&(_0x5b1a2d['.priority']=this['getPriority']()['val']()),_0x5b1a2d;}['hash'](){if(this['lazyHash_']===null){let _0x42951a='';this['getPriority']()['isEmpty']()||(_0x42951a+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x25370f,_0x5083d7)=>{const _0x3ea942=_0x5083d7['hash']();_0x3ea942!==''&&(_0x42951a+=':'+_0x25370f+':'+_0x3ea942);}),this['lazyHash_']=_0x42951a===''?'':no(_0x42951a);}return this['lazyHash_'];}['getPredecessorChildName'](_0x565b57,_0x3d3905,_0x24a627){const _0x83f9d1=this['resolveIndex_'](_0x24a627);if(_0x83f9d1){const _0x37cb9a=_0x83f9d1['getPredecessorKey'](new E(_0x565b57,_0x3d3905));return _0x37cb9a?_0x37cb9a['name']:null;}else return this['children_']['getPredecessorKey'](_0x565b57);}['getFirstChildName'](_0x3cec9c){const _0xdd82f5=this['resolveIndex_'](_0x3cec9c);if(_0xdd82f5){const _0x6fb7b=_0xdd82f5['minKey']();return _0x6fb7b&&_0x6fb7b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x461d49){const _0x4f6e6f=this['getFirstChildName'](_0x461d49);return _0x4f6e6f?new E(_0x4f6e6f,this['children_']['get'](_0x4f6e6f)):null;}['getLastChildName'](_0x30f16d){const _0x612874=this['resolveIndex_'](_0x30f16d);if(_0x612874){const _0x2f7f43=_0x612874['maxKey']();return _0x2f7f43&&_0x2f7f43['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4ae9ac){const _0x5d75e3=this['getLastChildName'](_0x4ae9ac);return _0x5d75e3?new E(_0x5d75e3,this['children_']['get'](_0x5d75e3)):null;}['forEachChild'](_0x27e546,_0x3bc22f){const _0x491a88=this['resolveIndex_'](_0x27e546);return _0x491a88?_0x491a88['inorderTraversal'](_0x12ceda=>_0x3bc22f(_0x12ceda['name'],_0x12ceda['node'])):this['children_']['inorderTraversal'](_0x3bc22f);}['getIterator'](_0x4eb24f){return this['getIteratorFrom'](_0x4eb24f['minPost'](),_0x4eb24f);}['getIteratorFrom'](_0x2d3303,_0x909f13){const _0x4a050b=this['resolveIndex_'](_0x909f13);if(_0x4a050b)return _0x4a050b['getIteratorFrom'](_0x2d3303,_0x470a26=>_0x470a26);{const _0x4391cb=this['children_']['getIteratorFrom'](_0x2d3303['name'],E['Wrap']);let _0x4c7d14=_0x4391cb['peek']();for(;_0x4c7d14!=null&&_0x909f13['compare'](_0x4c7d14,_0x2d3303)<0x0;)_0x4391cb['getNext'](),_0x4c7d14=_0x4391cb['peek']();return _0x4391cb;}}['getReverseIterator'](_0x510dbe){return this['getReverseIteratorFrom'](_0x510dbe['maxPost'](),_0x510dbe);}['getReverseIteratorFrom'](_0x278257,_0x51336e){const _0x323bf6=this['resolveIndex_'](_0x51336e);if(_0x323bf6)return _0x323bf6['getReverseIteratorFrom'](_0x278257,_0x26ee88=>_0x26ee88);{const _0x16a395=this['children_']['getReverseIteratorFrom'](_0x278257['name'],E['Wrap']);let _0x126d9a=_0x16a395['peek']();for(;_0x126d9a!=null&&_0x51336e['compare'](_0x126d9a,_0x278257)>0x0;)_0x16a395['getNext'](),_0x126d9a=_0x16a395['peek']();return _0x16a395;}}['compareTo'](_0x32eb4e){return this['isEmpty']()?_0x32eb4e['isEmpty']()?0x0:-0x1:_0x32eb4e['isLeafNode']()||_0x32eb4e['isEmpty']()?0x1:_0x32eb4e===Ht?-0x1:0x0;}['withIndex'](_0x56a9b0){if(_0x56a9b0===ye||this['indexMap_']['hasIndex'](_0x56a9b0))return this;{const _0x150d4f=this['indexMap_']['addIndex'](_0x56a9b0,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x150d4f);}}['isIndexed'](_0x1fda3f){return _0x1fda3f===ye||this['indexMap_']['hasIndex'](_0x1fda3f);}['equals'](_0x5c1ea7){if(_0x5c1ea7===this)return!0x0;if(_0x5c1ea7['isLeafNode']())return!0x1;{const _0xbbfe2=_0x5c1ea7;if(this['getPriority']()['equals'](_0xbbfe2['getPriority']())){if(this['children_']['count']()===_0xbbfe2['children_']['count']()){const _0x3762a1=this['getIterator'](R),_0x5a690b=_0xbbfe2['getIterator'](R);let _0x46dc9b=_0x3762a1['getNext'](),_0x2d6288=_0x5a690b['getNext']();for(;_0x46dc9b&&_0x2d6288;){if(_0x46dc9b['name']!==_0x2d6288['name']||!_0x46dc9b['node']['equals'](_0x2d6288['node']))return!0x1;_0x46dc9b=_0x3762a1['getNext'](),_0x2d6288=_0x5a690b['getNext']();}return _0x46dc9b===null&&_0x2d6288===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x36fbc3){return _0x36fbc3===ye?null:this['indexMap_']['get'](_0x36fbc3['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x270f1a){return _0x270f1a===this?0x0:0x1;}['equals'](_0x40e61c){return _0x40e61c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5d5fe4){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x15d834,_0x5bff73=null){if(_0x15d834===null)return g['EMPTY_NODE'];if(typeof _0x15d834=='object'&&'.priority'in _0x15d834&&(_0x5bff73=_0x15d834['.priority']),f(_0x5bff73===null||typeof _0x5bff73=='string'||typeof _0x5bff73=='number'||typeof _0x5bff73=='object'&&'.sv'in _0x5bff73,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5bff73),typeof _0x15d834=='object'&&'.value'in _0x15d834&&_0x15d834['.value']!==null&&(_0x15d834=_0x15d834['.value']),typeof _0x15d834!='object'||'.sv'in _0x15d834){const _0x3902d0=_0x15d834;return new D(_0x3902d0,N(_0x5bff73));}if(!(_0x15d834 instanceof Array)&&Vh){const _0x1d45b4=[];let _0x49bbdd=!0x1;if(x(_0x15d834,(_0x25dee9,_0x13a757)=>{if(_0x25dee9['substring'](0x0,0x1)!=='.'){const _0x355cb7=N(_0x13a757);_0x355cb7['isEmpty']()||(_0x49bbdd=_0x49bbdd||!_0x355cb7['getPriority']()['isEmpty'](),_0x1d45b4['push'](new E(_0x25dee9,_0x355cb7)));}}),_0x1d45b4['length']===0x0)return g['EMPTY_NODE'];const _0x252475=dn(_0x1d45b4,Dh,_0x11b710=>_0x11b710['name'],ji);if(_0x49bbdd){const _0x4ab966=dn(_0x1d45b4,R['getCompare']());return new g(_0x252475,N(_0x5bff73),new ee({'.priority':_0x4ab966},{'.priority':R}));}else return new g(_0x252475,N(_0x5bff73),ee['Default']);}else{let _0x112d6c=g['EMPTY_NODE'];return x(_0x15d834,(_0x4b32e3,_0x1c85bf)=>{if(Y(_0x15d834,_0x4b32e3)&&_0x4b32e3['substring'](0x0,0x1)!=='.'){const _0x299e5b=N(_0x1c85bf);(_0x299e5b['isLeafNode']()||!_0x299e5b['isEmpty']())&&(_0x112d6c=_0x112d6c['updateImmediateChild'](_0x4b32e3,_0x299e5b));}}),_0x112d6c['updatePriority'](N(_0x5bff73));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3f69b6){super(),this['indexPath_']=_0x3f69b6,f(!v(_0x3f69b6)&&y(_0x3f69b6)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x48d70b){return _0x48d70b['getChild'](this['indexPath_']);}['isDefinedOn'](_0x38d577){return!_0x38d577['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4dee22,_0x3a01aa){const _0x5c68a3=this['extractChild'](_0x4dee22['node']),_0x26ff1b=this['extractChild'](_0x3a01aa['node']),_0x27d857=_0x5c68a3['compareTo'](_0x26ff1b);return _0x27d857===0x0?He(_0x4dee22['name'],_0x3a01aa['name']):_0x27d857;}['makePost'](_0x5ea08,_0xbd2014){const _0x49468a=N(_0x5ea08),_0x568339=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x49468a);return new E(_0xbd2014,_0x568339);}['maxPost'](){const _0x260a84=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x260a84);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x14d77e,_0x1914e3){const _0x4e99bd=_0x14d77e['node']['compareTo'](_0x1914e3['node']);return _0x4e99bd===0x0?He(_0x14d77e['name'],_0x1914e3['name']):_0x4e99bd;}['isDefinedOn'](_0x32fc1d){return!0x0;}['indexedValueChanged'](_0x2d993d,_0x338ec3){return!_0x2d993d['equals'](_0x338ec3);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x30a6b3,_0x38566b){const _0x39da44=N(_0x30a6b3);return new E(_0x38566b,_0x39da44);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x14cc49){return{'type':'value','snapshotNode':_0x14cc49};}function tt(_0x575eb9,_0x181671){return{'type':'child_added','snapshotNode':_0x181671,'childName':_0x575eb9};}function Nt(_0x39700c,_0x37a61f){return{'type':'child_removed','snapshotNode':_0x37a61f,'childName':_0x39700c};}function Pt(_0x523ffa,_0x51f6b1,_0x2b2538){return{'type':'child_changed','snapshotNode':_0x51f6b1,'childName':_0x523ffa,'oldSnap':_0x2b2538};}function $h(_0x5c4b23,_0x54dbfb){return{'type':'child_moved','snapshotNode':_0x54dbfb,'childName':_0x5c4b23};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x5b3545){this['index_']=_0x5b3545;}['updateChild'](_0x4f514c,_0x45e159,_0x5574af,_0x4617b7,_0x437d97,_0x242fe5){f(_0x4f514c['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x204ee6=_0x4f514c['getImmediateChild'](_0x45e159);return _0x204ee6['getChild'](_0x4617b7)['equals'](_0x5574af['getChild'](_0x4617b7))&&_0x204ee6['isEmpty']()===_0x5574af['isEmpty']()||(_0x242fe5!=null&&(_0x5574af['isEmpty']()?_0x4f514c['hasChild'](_0x45e159)?_0x242fe5['trackChildChange'](Nt(_0x45e159,_0x204ee6)):f(_0x4f514c['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x204ee6['isEmpty']()?_0x242fe5['trackChildChange'](tt(_0x45e159,_0x5574af)):_0x242fe5['trackChildChange'](Pt(_0x45e159,_0x5574af,_0x204ee6))),_0x4f514c['isLeafNode']()&&_0x5574af['isEmpty']())?_0x4f514c:_0x4f514c['updateImmediateChild'](_0x45e159,_0x5574af)['withIndex'](this['index_']);}['updateFullNode'](_0x4a3761,_0x3511e1,_0x43b873){return _0x43b873!=null&&(_0x4a3761['isLeafNode']()||_0x4a3761['forEachChild'](R,(_0x53e7e9,_0x147f9c)=>{_0x3511e1['hasChild'](_0x53e7e9)||_0x43b873['trackChildChange'](Nt(_0x53e7e9,_0x147f9c));}),_0x3511e1['isLeafNode']()||_0x3511e1['forEachChild'](R,(_0x1fb819,_0x2aa179)=>{if(_0x4a3761['hasChild'](_0x1fb819)){const _0x70cd2f=_0x4a3761['getImmediateChild'](_0x1fb819);_0x70cd2f['equals'](_0x2aa179)||_0x43b873['trackChildChange'](Pt(_0x1fb819,_0x2aa179,_0x70cd2f));}else _0x43b873['trackChildChange'](tt(_0x1fb819,_0x2aa179));})),_0x3511e1['withIndex'](this['index_']);}['updatePriority'](_0x42364f,_0x111c26){return _0x42364f['isEmpty']()?g['EMPTY_NODE']:_0x42364f['updatePriority'](_0x111c26);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x2e9eec){this['indexedFilter_']=new Yi(_0x2e9eec['getIndex']()),this['index_']=_0x2e9eec['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x2e9eec),this['endPost_']=Ot['getEndPost_'](_0x2e9eec),this['startIsInclusive_']=!_0x2e9eec['startAfterSet_'],this['endIsInclusive_']=!_0x2e9eec['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x32b134){const _0x348667=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x32b134)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x32b134)<0x0,_0x10321f=this['endIsInclusive_']?this['index_']['compare'](_0x32b134,this['getEndPost']())<=0x0:this['index_']['compare'](_0x32b134,this['getEndPost']())<0x0;return _0x348667&&_0x10321f;}['updateChild'](_0x5d09ba,_0x129b9c,_0x2711d5,_0x336c15,_0x280b2c,_0x51c653){return this['matches'](new E(_0x129b9c,_0x2711d5))||(_0x2711d5=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5d09ba,_0x129b9c,_0x2711d5,_0x336c15,_0x280b2c,_0x51c653);}['updateFullNode'](_0x31fb46,_0x5e8747,_0xb0135b){_0x5e8747['isLeafNode']()&&(_0x5e8747=g['EMPTY_NODE']);let _0xb04bcb=_0x5e8747['withIndex'](this['index_']);_0xb04bcb=_0xb04bcb['updatePriority'](g['EMPTY_NODE']);const _0x3a7db7=this;return _0x5e8747['forEachChild'](R,(_0x350ac0,_0x498335)=>{_0x3a7db7['matches'](new E(_0x350ac0,_0x498335))||(_0xb04bcb=_0xb04bcb['updateImmediateChild'](_0x350ac0,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x31fb46,_0xb04bcb,_0xb0135b);}['updatePriority'](_0x181180,_0x4a5092){return _0x181180;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x32183f){if(_0x32183f['hasStart']()){const _0x2bf1ee=_0x32183f['getIndexStartName']();return _0x32183f['getIndex']()['makePost'](_0x32183f['getIndexStartValue'](),_0x2bf1ee);}else return _0x32183f['getIndex']()['minPost']();}static['getEndPost_'](_0x116210){if(_0x116210['hasEnd']()){const _0xf7cbac=_0x116210['getIndexEndName']();return _0x116210['getIndex']()['makePost'](_0x116210['getIndexEndValue'](),_0xf7cbac);}else return _0x116210['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x249c7e){this['withinDirectionalStart']=_0x2f258e=>this['reverse_']?this['withinEndPost'](_0x2f258e):this['withinStartPost'](_0x2f258e),this['withinDirectionalEnd']=_0x2b2132=>this['reverse_']?this['withinStartPost'](_0x2b2132):this['withinEndPost'](_0x2b2132),this['withinStartPost']=_0x438e05=>{const _0x22dcf5=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x438e05);return this['startIsInclusive_']?_0x22dcf5<=0x0:_0x22dcf5<0x0;},this['withinEndPost']=_0x5226d7=>{const _0x34649a=this['index_']['compare'](_0x5226d7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x34649a<=0x0:_0x34649a<0x0;},this['rangedFilter_']=new Ot(_0x249c7e),this['index_']=_0x249c7e['getIndex'](),this['limit_']=_0x249c7e['getLimit'](),this['reverse_']=!_0x249c7e['isViewFromLeft'](),this['startIsInclusive_']=!_0x249c7e['startAfterSet_'],this['endIsInclusive_']=!_0x249c7e['endBeforeSet_'];}['updateChild'](_0x23d3a7,_0x277998,_0x506c53,_0x20c1a9,_0x5e7dd0,_0x433d07){return this['rangedFilter_']['matches'](new E(_0x277998,_0x506c53))||(_0x506c53=g['EMPTY_NODE']),_0x23d3a7['getImmediateChild'](_0x277998)['equals'](_0x506c53)?_0x23d3a7:_0x23d3a7['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x23d3a7,_0x277998,_0x506c53,_0x20c1a9,_0x5e7dd0,_0x433d07):this['fullLimitUpdateChild_'](_0x23d3a7,_0x277998,_0x506c53,_0x5e7dd0,_0x433d07);}['updateFullNode'](_0x4a840e,_0x59ec5c,_0x5f38a1){let _0x39ad62;if(_0x59ec5c['isLeafNode']()||_0x59ec5c['isEmpty']())_0x39ad62=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x59ec5c['numChildren']()&&_0x59ec5c['isIndexed'](this['index_'])){_0x39ad62=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x21367e;this['reverse_']?_0x21367e=_0x59ec5c['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x21367e=_0x59ec5c['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5a6a09=0x0;for(;_0x21367e['hasNext']()&&_0x5a6a09<this['limit_'];){const _0x32f370=_0x21367e['getNext']();if(this['withinDirectionalStart'](_0x32f370)){if(this['withinDirectionalEnd'](_0x32f370))_0x39ad62=_0x39ad62['updateImmediateChild'](_0x32f370['name'],_0x32f370['node']),_0x5a6a09++;else break;}else continue;}}else{_0x39ad62=_0x59ec5c['withIndex'](this['index_']),_0x39ad62=_0x39ad62['updatePriority'](g['EMPTY_NODE']);let _0x455c77;this['reverse_']?_0x455c77=_0x39ad62['getReverseIterator'](this['index_']):_0x455c77=_0x39ad62['getIterator'](this['index_']);let _0x2888d4=0x0;for(;_0x455c77['hasNext']();){const _0x431250=_0x455c77['getNext']();_0x2888d4<this['limit_']&&this['withinDirectionalStart'](_0x431250)&&this['withinDirectionalEnd'](_0x431250)?_0x2888d4++:_0x39ad62=_0x39ad62['updateImmediateChild'](_0x431250['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4a840e,_0x39ad62,_0x5f38a1);}['updatePriority'](_0x58b8b4,_0x22cc24){return _0x58b8b4;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1fed0a,_0x53d29f,_0x51bebd,_0x12bf4b,_0x5856df){let _0x5ca2d7;if(this['reverse_']){const _0x1a6a1=this['index_']['getCompare']();_0x5ca2d7=(_0x4cf1f5,_0x43208f)=>_0x1a6a1(_0x43208f,_0x4cf1f5);}else _0x5ca2d7=this['index_']['getCompare']();const _0x2871f6=_0x1fed0a;f(_0x2871f6['numChildren']()===this['limit_'],'');const _0x319c3b=new E(_0x53d29f,_0x51bebd),_0x73b9c6=this['reverse_']?_0x2871f6['getFirstChild'](this['index_']):_0x2871f6['getLastChild'](this['index_']),_0x1ec9d9=this['rangedFilter_']['matches'](_0x319c3b);if(_0x2871f6['hasChild'](_0x53d29f)){const _0x161118=_0x2871f6['getImmediateChild'](_0x53d29f);let _0x1f1b84=_0x12bf4b['getChildAfterChild'](this['index_'],_0x73b9c6,this['reverse_']);for(;_0x1f1b84!=null&&(_0x1f1b84['name']===_0x53d29f||_0x2871f6['hasChild'](_0x1f1b84['name']));)_0x1f1b84=_0x12bf4b['getChildAfterChild'](this['index_'],_0x1f1b84,this['reverse_']);const _0x64894d=_0x1f1b84==null?0x1:_0x5ca2d7(_0x1f1b84,_0x319c3b);if(_0x1ec9d9&&!_0x51bebd['isEmpty']()&&_0x64894d>=0x0)return _0x5856df!=null&&_0x5856df['trackChildChange'](Pt(_0x53d29f,_0x51bebd,_0x161118)),_0x2871f6['updateImmediateChild'](_0x53d29f,_0x51bebd);{_0x5856df!=null&&_0x5856df['trackChildChange'](Nt(_0x53d29f,_0x161118));const _0x3e954e=_0x2871f6['updateImmediateChild'](_0x53d29f,g['EMPTY_NODE']);return _0x1f1b84!=null&&this['rangedFilter_']['matches'](_0x1f1b84)?(_0x5856df!=null&&_0x5856df['trackChildChange'](tt(_0x1f1b84['name'],_0x1f1b84['node'])),_0x3e954e['updateImmediateChild'](_0x1f1b84['name'],_0x1f1b84['node'])):_0x3e954e;}}else return _0x51bebd['isEmpty']()?_0x1fed0a:_0x1ec9d9&&_0x5ca2d7(_0x73b9c6,_0x319c3b)>=0x0?(_0x5856df!=null&&(_0x5856df['trackChildChange'](Nt(_0x73b9c6['name'],_0x73b9c6['node'])),_0x5856df['trackChildChange'](tt(_0x53d29f,_0x51bebd))),_0x2871f6['updateImmediateChild'](_0x53d29f,_0x51bebd)['updateImmediateChild'](_0x73b9c6['name'],g['EMPTY_NODE'])):_0x1fed0a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x42ef70=new Qi();return _0x42ef70['limitSet_']=this['limitSet_'],_0x42ef70['limit_']=this['limit_'],_0x42ef70['startSet_']=this['startSet_'],_0x42ef70['startAfterSet_']=this['startAfterSet_'],_0x42ef70['indexStartValue_']=this['indexStartValue_'],_0x42ef70['startNameSet_']=this['startNameSet_'],_0x42ef70['indexStartName_']=this['indexStartName_'],_0x42ef70['endSet_']=this['endSet_'],_0x42ef70['endBeforeSet_']=this['endBeforeSet_'],_0x42ef70['indexEndValue_']=this['indexEndValue_'],_0x42ef70['endNameSet_']=this['endNameSet_'],_0x42ef70['indexEndName_']=this['indexEndName_'],_0x42ef70['index_']=this['index_'],_0x42ef70['viewFrom_']=this['viewFrom_'],_0x42ef70;}}function qh(_0x3eb20e){return _0x3eb20e['loadsAllData']()?new Yi(_0x3eb20e['getIndex']()):_0x3eb20e['hasLimit']()?new Gh(_0x3eb20e):new Ot(_0x3eb20e);}function zh(_0x5afdbb,_0x4dc2e6){const _0x107be8=_0x5afdbb['copy']();return _0x107be8['limitSet_']=!0x0,_0x107be8['limit_']=_0x4dc2e6,_0x107be8['viewFrom_']='l',_0x107be8;}function jh(_0x2ac9bd,_0x460a56,_0xcda4b0){const _0x41dfdb=_0x2ac9bd['copy']();return _0x41dfdb['startSet_']=!0x0,_0x460a56===void 0x0&&(_0x460a56=null),_0x41dfdb['indexStartValue_']=_0x460a56,_0xcda4b0!=null?(_0x41dfdb['startNameSet_']=!0x0,_0x41dfdb['indexStartName_']=_0xcda4b0):(_0x41dfdb['startNameSet_']=!0x1,_0x41dfdb['indexStartName_']=''),_0x41dfdb;}function Kh(_0x48b788,_0x2b4b57,_0x81e1aa){const _0x145f37=_0x48b788['copy']();return _0x145f37['endSet_']=!0x0,_0x2b4b57===void 0x0&&(_0x2b4b57=null),_0x145f37['indexEndValue_']=_0x2b4b57,_0x81e1aa!==void 0x0?(_0x145f37['endNameSet_']=!0x0,_0x145f37['indexEndName_']=_0x81e1aa):(_0x145f37['endNameSet_']=!0x1,_0x145f37['indexEndName_']=''),_0x145f37;}function Do(_0x2308b7,_0x498e8b){const _0x32e3bf=_0x2308b7['copy']();return _0x32e3bf['index_']=_0x498e8b,_0x32e3bf;}function tr(_0x2e50e4){const _0x486f09={};if(_0x2e50e4['isDefault']())return _0x486f09;let _0x3c0c4e;if(_0x2e50e4['index_']===R?_0x3c0c4e='$priority':_0x2e50e4['index_']===Po?_0x3c0c4e='$value':_0x2e50e4['index_']===ye?_0x3c0c4e='$key':(f(_0x2e50e4['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x3c0c4e=_0x2e50e4['index_']['toString']()),_0x486f09['orderBy']=O(_0x3c0c4e),_0x2e50e4['startSet_']){const _0x2c76ce=_0x2e50e4['startAfterSet_']?'startAfter':'startAt';_0x486f09[_0x2c76ce]=O(_0x2e50e4['indexStartValue_']),_0x2e50e4['startNameSet_']&&(_0x486f09[_0x2c76ce]+=','+O(_0x2e50e4['indexStartName_']));}if(_0x2e50e4['endSet_']){const _0x10867e=_0x2e50e4['endBeforeSet_']?'endBefore':'endAt';_0x486f09[_0x10867e]=O(_0x2e50e4['indexEndValue_']),_0x2e50e4['endNameSet_']&&(_0x486f09[_0x10867e]+=','+O(_0x2e50e4['indexEndName_']));}return _0x2e50e4['limitSet_']&&(_0x2e50e4['isViewFromLeft']()?_0x486f09['limitToFirst']=_0x2e50e4['limit_']:_0x486f09['limitToLast']=_0x2e50e4['limit_']),_0x486f09;}function nr(_0xedcae6){const _0x25a9a0={};if(_0xedcae6['startSet_']&&(_0x25a9a0['sp']=_0xedcae6['indexStartValue_'],_0xedcae6['startNameSet_']&&(_0x25a9a0['sn']=_0xedcae6['indexStartName_']),_0x25a9a0['sin']=!_0xedcae6['startAfterSet_']),_0xedcae6['endSet_']&&(_0x25a9a0['ep']=_0xedcae6['indexEndValue_'],_0xedcae6['endNameSet_']&&(_0x25a9a0['en']=_0xedcae6['indexEndName_']),_0x25a9a0['ein']=!_0xedcae6['endBeforeSet_']),_0xedcae6['limitSet_']){_0x25a9a0['l']=_0xedcae6['limit_'];let _0x29861e=_0xedcae6['viewFrom_'];_0x29861e===''&&(_0xedcae6['isViewFromLeft']()?_0x29861e='l':_0x29861e='r'),_0x25a9a0['vf']=_0x29861e;}return _0xedcae6['index_']!==R&&(_0x25a9a0['i']=_0xedcae6['index_']['toString']()),_0x25a9a0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1fb1cf){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4a4559,_0x4d88ac){return _0x4d88ac!==void 0x0?'tag$'+_0x4d88ac:(f(_0x4a4559['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4a4559['_path']['toString']());}constructor(_0x167b27,_0x5193ac,_0x32341a,_0x1ae7c6){super(),this['repoInfo_']=_0x167b27,this['onDataUpdate_']=_0x5193ac,this['authTokenProvider_']=_0x32341a,this['appCheckTokenProvider_']=_0x1ae7c6,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x2c4421,_0x5968c8,_0x23d75d,_0x128b6e){const _0x48f95d=_0x2c4421['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x48f95d+'\x20'+_0x2c4421['_queryIdentifier']);const _0x2ee30c=fn['getListenId_'](_0x2c4421,_0x23d75d),_0x56da60={};this['listens_'][_0x2ee30c]=_0x56da60;const _0x55ed60=tr(_0x2c4421['_queryParams']);this['restRequest_'](_0x48f95d+'.json',_0x55ed60,(_0x19e286,_0x3def17)=>{let _0x5be653=_0x3def17;if(_0x19e286===0x194&&(_0x5be653=null,_0x19e286=null),_0x19e286===null&&this['onDataUpdate_'](_0x48f95d,_0x5be653,!0x1,_0x23d75d),Oe(this['listens_'],_0x2ee30c)===_0x56da60){let _0x3272d5;_0x19e286?_0x19e286===0x191?_0x3272d5='permission_denied':_0x3272d5='rest_error:'+_0x19e286:_0x3272d5='ok',_0x128b6e(_0x3272d5,null);}});}['unlisten'](_0x2809cd,_0x3b58a3){const _0x1c8703=fn['getListenId_'](_0x2809cd,_0x3b58a3);delete this['listens_'][_0x1c8703];}['get'](_0x4925df){const _0x499696=tr(_0x4925df['_queryParams']),_0x31e352=_0x4925df['_path']['toString'](),_0x1647e2=new Ve();return this['restRequest_'](_0x31e352+'.json',_0x499696,(_0x39a6f9,_0x479ac8)=>{let _0x2a1e07=_0x479ac8;_0x39a6f9===0x194&&(_0x2a1e07=null,_0x39a6f9=null),_0x39a6f9===null?(this['onDataUpdate_'](_0x31e352,_0x2a1e07,!0x1,null),_0x1647e2['resolve'](_0x2a1e07)):_0x1647e2['reject'](new Error(_0x2a1e07));}),_0x1647e2['promise'];}['refreshAuthToken'](_0x4006d4){}['restRequest_'](_0x346583,_0x2e4f0f={},_0x12b99f){return _0x2e4f0f['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1b18ec,_0x33a0fd])=>{_0x1b18ec&&_0x1b18ec['accessToken']&&(_0x2e4f0f['auth']=_0x1b18ec['accessToken']),_0x33a0fd&&_0x33a0fd['token']&&(_0x2e4f0f['ac']=_0x33a0fd['token']);const _0x1ed6cd=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x346583+'?ns='+this['repoInfo_']['namespace']+at(_0x2e4f0f);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1ed6cd);const _0x3afeb2=new XMLHttpRequest();_0x3afeb2['onreadystatechange']=()=>{if(_0x12b99f&&_0x3afeb2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1ed6cd+'\x20received.\x20status:',_0x3afeb2['status'],'response:',_0x3afeb2['responseText']);let _0x3ddea0=null;if(_0x3afeb2['status']>=0xc8&&_0x3afeb2['status']<0x12c){try{_0x3ddea0=bt(_0x3afeb2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1ed6cd+':\x20'+_0x3afeb2['responseText']);}_0x12b99f(null,_0x3ddea0);}else _0x3afeb2['status']!==0x191&&_0x3afeb2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1ed6cd+'\x20Status:\x20'+_0x3afeb2['status']),_0x12b99f(_0x3afeb2['status']);_0x12b99f=null;}},_0x3afeb2['open']('GET',_0x1ed6cd,!0x0),_0x3afeb2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5d8d38){return this['rootNode_']['getChild'](_0x5d8d38);}['updateSnapshot'](_0x40c0b7,_0x6d0ec4){this['rootNode_']=this['rootNode_']['updateChild'](_0x40c0b7,_0x6d0ec4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x416e87,_0x465489,_0x5755c2){if(v(_0x465489))_0x416e87['value']=_0x5755c2,_0x416e87['children']['clear']();else{if(_0x416e87['value']!==null)_0x416e87['value']=_0x416e87['value']['updateChild'](_0x465489,_0x5755c2);else{const _0x5b658=y(_0x465489);_0x416e87['children']['has'](_0x5b658)||_0x416e87['children']['set'](_0x5b658,pn());const _0x4664a7=_0x416e87['children']['get'](_0x5b658);_0x465489=b(_0x465489),Mo(_0x4664a7,_0x465489,_0x5755c2);}}}function Ei(_0x41224f,_0x4afc93,_0x175361){_0x41224f['value']!==null?_0x175361(_0x4afc93,_0x41224f['value']):Qh(_0x41224f,(_0x560941,_0x427389)=>{const _0x2c114a=new C(_0x4afc93['toString']()+'/'+_0x560941);Ei(_0x427389,_0x2c114a,_0x175361);});}function Qh(_0x566193,_0x1f448c){_0x566193['children']['forEach']((_0x2f209d,_0x587e9e)=>{_0x1f448c(_0x587e9e,_0x2f209d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x1edbf3){this['collection_']=_0x1edbf3,this['last_']=null;}['get'](){const _0x307677=this['collection_']['get'](),_0x1c3548={..._0x307677};return this['last_']&&x(this['last_'],(_0x4af7ab,_0x26c190)=>{_0x1c3548[_0x4af7ab]=_0x1c3548[_0x4af7ab]-_0x26c190;}),this['last_']=_0x307677,_0x1c3548;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x5e4e2c,_0x33ab9d){this['server_']=_0x33ab9d,this['statsToReport_']={},this['statsListener_']=new Jh(_0x5e4e2c);const _0x4c030a=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x4c030a));}['reportStats_'](){const _0x1ee4e0=this['statsListener_']['get'](),_0x5be47d={};let _0x3dd350=!0x1;x(_0x1ee4e0,(_0x528557,_0x178d34)=>{_0x178d34>0x0&&Y(this['statsToReport_'],_0x528557)&&(_0x5be47d[_0x528557]=_0x178d34,_0x3dd350=!0x0);}),_0x3dd350&&this['server_']['reportStats'](_0x5be47d),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x17a3c5){_0x17a3c5[_0x17a3c5['OVERWRITE']=0x0]='OVERWRITE',_0x17a3c5[_0x17a3c5['MERGE']=0x1]='MERGE',_0x17a3c5[_0x17a3c5['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x17a3c5[_0x17a3c5['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x3b4e53){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3b4e53,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x33f351,_0x596a69,_0x25454a){this['path']=_0x33f351,this['affectedTree']=_0x596a69,this['revert']=_0x25454a,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x36713f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xd6c519=this['affectedTree']['subtree'](new C(_0x36713f));return new _n(w(),_0xd6c519,this['revert']);}}else return f(y(this['path'])===_0x36713f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x296a28,_0x2ba36c){this['source']=_0x296a28,this['path']=_0x2ba36c,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4b7bd5){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x4fea8a,_0x24cfa2,_0x20c63a){this['source']=_0x4fea8a,this['path']=_0x24cfa2,this['snap']=_0x20c63a,this['type']=q['OVERWRITE'];}['operationForChild'](_0x251a3a){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x251a3a)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x28b5ba,_0x36298d,_0x223475){this['source']=_0x28b5ba,this['path']=_0x36298d,this['children']=_0x223475,this['type']=q['MERGE'];}['operationForChild'](_0x452336){if(v(this['path'])){const _0x319306=this['children']['subtree'](new C(_0x452336));return _0x319306['isEmpty']()?null:_0x319306['value']?new Fe(this['source'],w(),_0x319306['value']):new nt(this['source'],w(),_0x319306);}else return f(y(this['path'])===_0x452336,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x34738a,_0x4322a6,_0x1518bd){this['node_']=_0x34738a,this['fullyInitialized_']=_0x4322a6,this['filtered_']=_0x1518bd;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x31d457){if(v(_0x31d457))return this['isFullyInitialized']()&&!this['filtered_'];const _0x43cb64=y(_0x31d457);return this['isCompleteForChild'](_0x43cb64);}['isCompleteForChild'](_0x24b39d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x24b39d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x144a73){this['query_']=_0x144a73,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x10767e,_0x5616d4,_0x2a2839,_0x3c7902){const _0x53341c=[],_0x56ca8b=[];return _0x5616d4['forEach'](_0xde4753=>{_0xde4753['type']==='child_changed'&&_0x10767e['index_']['indexedValueChanged'](_0xde4753['oldSnap'],_0xde4753['snapshotNode'])&&_0x56ca8b['push']($h(_0xde4753['childName'],_0xde4753['snapshotNode']));}),mt(_0x10767e,_0x53341c,'child_removed',_0x5616d4,_0x3c7902,_0x2a2839),mt(_0x10767e,_0x53341c,'child_added',_0x5616d4,_0x3c7902,_0x2a2839),mt(_0x10767e,_0x53341c,'child_moved',_0x56ca8b,_0x3c7902,_0x2a2839),mt(_0x10767e,_0x53341c,'child_changed',_0x5616d4,_0x3c7902,_0x2a2839),mt(_0x10767e,_0x53341c,'value',_0x5616d4,_0x3c7902,_0x2a2839),_0x53341c;}function mt(_0x5e48a3,_0xa35aeb,_0x365fa2,_0x1fce78,_0x24d430,_0x4f83ed){const _0x589ac6=_0x1fce78['filter'](_0x16fcff=>_0x16fcff['type']===_0x365fa2);_0x589ac6['sort']((_0xfa838c,_0x16c46f)=>su(_0x5e48a3,_0xfa838c,_0x16c46f)),_0x589ac6['forEach'](_0x20f950=>{const _0x5a592d=iu(_0x5e48a3,_0x20f950,_0x4f83ed);_0x24d430['forEach'](_0x5139c6=>{_0x5139c6['respondsTo'](_0x20f950['type'])&&_0xa35aeb['push'](_0x5139c6['createEvent'](_0x5a592d,_0x5e48a3['query_']));});});}function iu(_0x22567a,_0x4b86a5,_0x5f59e5){return _0x4b86a5['type']==='value'||_0x4b86a5['type']==='child_removed'||(_0x4b86a5['prevName']=_0x5f59e5['getPredecessorChildName'](_0x4b86a5['childName'],_0x4b86a5['snapshotNode'],_0x22567a['index_'])),_0x4b86a5;}function su(_0x544326,_0x5da58,_0x31feb7){if(_0x5da58['childName']==null||_0x31feb7['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x437746=new E(_0x5da58['childName'],_0x5da58['snapshotNode']),_0x1f304a=new E(_0x31feb7['childName'],_0x31feb7['snapshotNode']);return _0x544326['index_']['compare'](_0x437746,_0x1f304a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4a5c4b,_0x36682b){return{'eventCache':_0x4a5c4b,'serverCache':_0x36682b};}function wt(_0x24a796,_0x1eef97,_0x5c4645,_0x1eabe2){return Dn(new Ce(_0x1eef97,_0x5c4645,_0x1eabe2),_0x24a796['serverCache']);}function Lo(_0x4de092,_0x3e721a,_0x414192,_0x4658bf){return Dn(_0x4de092['eventCache'],new Ce(_0x3e721a,_0x414192,_0x4658bf));}function gn(_0x38c3cd){return _0x38c3cd['eventCache']['isFullyInitialized']()?_0x38c3cd['eventCache']['getNode']():null;}function Ue(_0x68f7dc){return _0x68f7dc['serverCache']['isFullyInitialized']()?_0x68f7dc['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x38eb99){let _0x542c2e=new S(null);return x(_0x38eb99,(_0x214ba2,_0x5c14eb)=>{_0x542c2e=_0x542c2e['set'](new C(_0x214ba2),_0x5c14eb);}),_0x542c2e;}constructor(_0x595cae,_0xf0ccac=ru()){this['value']=_0x595cae,this['children']=_0xf0ccac;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5b66b0,_0x1b45bf){if(this['value']!=null&&_0x1b45bf(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5b66b0))return null;{const _0x411f02=y(_0x5b66b0),_0x39c549=this['children']['get'](_0x411f02);if(_0x39c549!==null){const _0x3cb639=_0x39c549['findRootMostMatchingPathAndValue'](b(_0x5b66b0),_0x1b45bf);return _0x3cb639!=null?{'path':A(new C(_0x411f02),_0x3cb639['path']),'value':_0x3cb639['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xecf392){return this['findRootMostMatchingPathAndValue'](_0xecf392,()=>!0x0);}['subtree'](_0x14b625){if(v(_0x14b625))return this;{const _0x344b72=y(_0x14b625),_0x540194=this['children']['get'](_0x344b72);return _0x540194!==null?_0x540194['subtree'](b(_0x14b625)):new S(null);}}['set'](_0x2f6f1b,_0x5672a5){if(v(_0x2f6f1b))return new S(_0x5672a5,this['children']);{const _0x296c12=y(_0x2f6f1b),_0xd037f3=(this['children']['get'](_0x296c12)||new S(null))['set'](b(_0x2f6f1b),_0x5672a5),_0x2a7c58=this['children']['insert'](_0x296c12,_0xd037f3);return new S(this['value'],_0x2a7c58);}}['remove'](_0x518b6e){if(v(_0x518b6e))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x47bfa4=y(_0x518b6e),_0x27bd44=this['children']['get'](_0x47bfa4);if(_0x27bd44){const _0x1afadc=_0x27bd44['remove'](b(_0x518b6e));let _0x56c5b4;return _0x1afadc['isEmpty']()?_0x56c5b4=this['children']['remove'](_0x47bfa4):_0x56c5b4=this['children']['insert'](_0x47bfa4,_0x1afadc),this['value']===null&&_0x56c5b4['isEmpty']()?new S(null):new S(this['value'],_0x56c5b4);}else return this;}}['get'](_0x33da7b){if(v(_0x33da7b))return this['value'];{const _0x141c31=y(_0x33da7b),_0x584b9c=this['children']['get'](_0x141c31);return _0x584b9c?_0x584b9c['get'](b(_0x33da7b)):null;}}['setTree'](_0x17e7db,_0x2a846f){if(v(_0x17e7db))return _0x2a846f;{const _0x154619=y(_0x17e7db),_0x44b97b=(this['children']['get'](_0x154619)||new S(null))['setTree'](b(_0x17e7db),_0x2a846f);let _0x28d0c9;return _0x44b97b['isEmpty']()?_0x28d0c9=this['children']['remove'](_0x154619):_0x28d0c9=this['children']['insert'](_0x154619,_0x44b97b),new S(this['value'],_0x28d0c9);}}['fold'](_0x382f38){return this['fold_'](w(),_0x382f38);}['fold_'](_0x1dd74a,_0x2cb95a){const _0x4f488d={};return this['children']['inorderTraversal']((_0x58ef9c,_0x257d10)=>{_0x4f488d[_0x58ef9c]=_0x257d10['fold_'](A(_0x1dd74a,_0x58ef9c),_0x2cb95a);}),_0x2cb95a(_0x1dd74a,this['value'],_0x4f488d);}['findOnPath'](_0xb67782,_0xc0b6fd){return this['findOnPath_'](_0xb67782,w(),_0xc0b6fd);}['findOnPath_'](_0x4de0ca,_0x498c83,_0x505e6e){const _0x37df20=this['value']?_0x505e6e(_0x498c83,this['value']):!0x1;if(_0x37df20)return _0x37df20;if(v(_0x4de0ca))return null;{const _0x58fc08=y(_0x4de0ca),_0x2f62e5=this['children']['get'](_0x58fc08);return _0x2f62e5?_0x2f62e5['findOnPath_'](b(_0x4de0ca),A(_0x498c83,_0x58fc08),_0x505e6e):null;}}['foreachOnPath'](_0x3e298d,_0x371b5e){return this['foreachOnPath_'](_0x3e298d,w(),_0x371b5e);}['foreachOnPath_'](_0x5e25e1,_0x177e12,_0x2a5076){if(v(_0x5e25e1))return this;{this['value']&&_0x2a5076(_0x177e12,this['value']);const _0x250e19=y(_0x5e25e1),_0x89902e=this['children']['get'](_0x250e19);return _0x89902e?_0x89902e['foreachOnPath_'](b(_0x5e25e1),A(_0x177e12,_0x250e19),_0x2a5076):new S(null);}}['foreach'](_0x5fa3ea){this['foreach_'](w(),_0x5fa3ea);}['foreach_'](_0x287468,_0x454554){this['children']['inorderTraversal']((_0x535631,_0x50f40d)=>{_0x50f40d['foreach_'](A(_0x287468,_0x535631),_0x454554);}),this['value']&&_0x454554(_0x287468,this['value']);}['foreachChild'](_0x516e32){this['children']['inorderTraversal']((_0x4e5860,_0x3934a0)=>{_0x3934a0['value']&&_0x516e32(_0x4e5860,_0x3934a0['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x1d0c40){this['writeTree_']=_0x1d0c40;}static['empty'](){return new j(new S(null));}}function Ct(_0x38a0d7,_0x2fd902,_0x364c2f){if(v(_0x2fd902))return new j(new S(_0x364c2f));{const _0x1923d4=_0x38a0d7['writeTree_']['findRootMostValueAndPath'](_0x2fd902);if(_0x1923d4!=null){const _0x26f76f=_0x1923d4['path'];let _0x3c551=_0x1923d4['value'];const _0x21b06b=F(_0x26f76f,_0x2fd902);return _0x3c551=_0x3c551['updateChild'](_0x21b06b,_0x364c2f),new j(_0x38a0d7['writeTree_']['set'](_0x26f76f,_0x3c551));}else{const _0x46bbc9=new S(_0x364c2f),_0x22406b=_0x38a0d7['writeTree_']['setTree'](_0x2fd902,_0x46bbc9);return new j(_0x22406b);}}}function Ii(_0x5931f1,_0x1c0449,_0xa6403f){let _0x2e1b83=_0x5931f1;return x(_0xa6403f,(_0xf6efb,_0x859b17)=>{_0x2e1b83=Ct(_0x2e1b83,A(_0x1c0449,_0xf6efb),_0x859b17);}),_0x2e1b83;}function sr(_0x5b683b,_0x3faa11){if(v(_0x3faa11))return j['empty']();{const _0x53fc79=_0x5b683b['writeTree_']['setTree'](_0x3faa11,new S(null));return new j(_0x53fc79);}}function wi(_0x4d09a1,_0x360b7c){return $e(_0x4d09a1,_0x360b7c)!=null;}function $e(_0x451e9d,_0x333705){const _0x2079b4=_0x451e9d['writeTree_']['findRootMostValueAndPath'](_0x333705);return _0x2079b4!=null?_0x451e9d['writeTree_']['get'](_0x2079b4['path'])['getChild'](F(_0x2079b4['path'],_0x333705)):null;}function rr(_0x15d291){const _0x1e99e3=[],_0x3b4670=_0x15d291['writeTree_']['value'];return _0x3b4670!=null?_0x3b4670['isLeafNode']()||_0x3b4670['forEachChild'](R,(_0x4c753c,_0x164691)=>{_0x1e99e3['push'](new E(_0x4c753c,_0x164691));}):_0x15d291['writeTree_']['children']['inorderTraversal']((_0x5a0ef6,_0x1dfdfb)=>{_0x1dfdfb['value']!=null&&_0x1e99e3['push'](new E(_0x5a0ef6,_0x1dfdfb['value']));}),_0x1e99e3;}function ve(_0x4122b2,_0x6fc1bc){if(v(_0x6fc1bc))return _0x4122b2;{const _0x2f9250=$e(_0x4122b2,_0x6fc1bc);return _0x2f9250!=null?new j(new S(_0x2f9250)):new j(_0x4122b2['writeTree_']['subtree'](_0x6fc1bc));}}function Ci(_0x51f4e1){return _0x51f4e1['writeTree_']['isEmpty']();}function it(_0xce4d15,_0x6f4b26){return xo(w(),_0xce4d15['writeTree_'],_0x6f4b26);}function xo(_0x17e50e,_0x45f6ad,_0x6a9cd7){if(_0x45f6ad['value']!=null)return _0x6a9cd7['updateChild'](_0x17e50e,_0x45f6ad['value']);{let _0x2a4930=null;return _0x45f6ad['children']['inorderTraversal']((_0x3319d2,_0x3ec012)=>{_0x3319d2==='.priority'?(f(_0x3ec012['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2a4930=_0x3ec012['value']):_0x6a9cd7=xo(A(_0x17e50e,_0x3319d2),_0x3ec012,_0x6a9cd7);}),!_0x6a9cd7['getChild'](_0x17e50e)['isEmpty']()&&_0x2a4930!==null&&(_0x6a9cd7=_0x6a9cd7['updateChild'](A(_0x17e50e,'.priority'),_0x2a4930)),_0x6a9cd7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3911a7,_0x137ad4){return Bo(_0x137ad4,_0x3911a7);}function ou(_0x3e2e6f,_0x2bc50f,_0x23c5a4,_0x1d5ec4,_0x15ddc2){f(_0x1d5ec4>_0x3e2e6f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x15ddc2===void 0x0&&(_0x15ddc2=!0x0),_0x3e2e6f['allWrites']['push']({'path':_0x2bc50f,'snap':_0x23c5a4,'writeId':_0x1d5ec4,'visible':_0x15ddc2}),_0x15ddc2&&(_0x3e2e6f['visibleWrites']=Ct(_0x3e2e6f['visibleWrites'],_0x2bc50f,_0x23c5a4)),_0x3e2e6f['lastWriteId']=_0x1d5ec4;}function au(_0x27a572,_0x37e92f,_0x438f2b,_0x2dfa81){f(_0x2dfa81>_0x27a572['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x27a572['allWrites']['push']({'path':_0x37e92f,'children':_0x438f2b,'writeId':_0x2dfa81,'visible':!0x0}),_0x27a572['visibleWrites']=Ii(_0x27a572['visibleWrites'],_0x37e92f,_0x438f2b),_0x27a572['lastWriteId']=_0x2dfa81;}function cu(_0x4a1cef,_0x179268){for(let _0x5b0bff=0x0;_0x5b0bff<_0x4a1cef['allWrites']['length'];_0x5b0bff++){const _0x303868=_0x4a1cef['allWrites'][_0x5b0bff];if(_0x303868['writeId']===_0x179268)return _0x303868;}return null;}function lu(_0x4b8292,_0x5b71b1){const _0x2c6475=_0x4b8292['allWrites']['findIndex'](_0x453db7=>_0x453db7['writeId']===_0x5b71b1);f(_0x2c6475>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x11728d=_0x4b8292['allWrites'][_0x2c6475];_0x4b8292['allWrites']['splice'](_0x2c6475,0x1);let _0x47bf07=_0x11728d['visible'],_0x3f0f66=!0x1,_0x25dc7e=_0x4b8292['allWrites']['length']-0x1;for(;_0x47bf07&&_0x25dc7e>=0x0;){const _0x3c5d4d=_0x4b8292['allWrites'][_0x25dc7e];_0x3c5d4d['visible']&&(_0x25dc7e>=_0x2c6475&&hu(_0x3c5d4d,_0x11728d['path'])?_0x47bf07=!0x1:$(_0x11728d['path'],_0x3c5d4d['path'])&&(_0x3f0f66=!0x0)),_0x25dc7e--;}if(_0x47bf07){if(_0x3f0f66)return uu(_0x4b8292),!0x0;if(_0x11728d['snap'])_0x4b8292['visibleWrites']=sr(_0x4b8292['visibleWrites'],_0x11728d['path']);else{const _0x11d738=_0x11728d['children'];x(_0x11d738,_0x4162ec=>{_0x4b8292['visibleWrites']=sr(_0x4b8292['visibleWrites'],A(_0x11728d['path'],_0x4162ec));});}return!0x0;}else return!0x1;}function hu(_0x40eb62,_0xb3caa3){if(_0x40eb62['snap'])return $(_0x40eb62['path'],_0xb3caa3);for(const _0xe993e2 in _0x40eb62['children'])if(_0x40eb62['children']['hasOwnProperty'](_0xe993e2)&&$(A(_0x40eb62['path'],_0xe993e2),_0xb3caa3))return!0x0;return!0x1;}function uu(_0x232eea){_0x232eea['visibleWrites']=Fo(_0x232eea['allWrites'],du,w()),_0x232eea['allWrites']['length']>0x0?_0x232eea['lastWriteId']=_0x232eea['allWrites'][_0x232eea['allWrites']['length']-0x1]['writeId']:_0x232eea['lastWriteId']=-0x1;}function du(_0x4b94b3){return _0x4b94b3['visible'];}function Fo(_0x275add,_0x1a0d0c,_0xad5d53){let _0x820de2=j['empty']();for(let _0xf75e91=0x0;_0xf75e91<_0x275add['length'];++_0xf75e91){const _0x19e80d=_0x275add[_0xf75e91];if(_0x1a0d0c(_0x19e80d)){const _0x432ba4=_0x19e80d['path'];let _0x581d7c;if(_0x19e80d['snap'])$(_0xad5d53,_0x432ba4)?(_0x581d7c=F(_0xad5d53,_0x432ba4),_0x820de2=Ct(_0x820de2,_0x581d7c,_0x19e80d['snap'])):$(_0x432ba4,_0xad5d53)&&(_0x581d7c=F(_0x432ba4,_0xad5d53),_0x820de2=Ct(_0x820de2,w(),_0x19e80d['snap']['getChild'](_0x581d7c)));else{if(_0x19e80d['children']){if($(_0xad5d53,_0x432ba4))_0x581d7c=F(_0xad5d53,_0x432ba4),_0x820de2=Ii(_0x820de2,_0x581d7c,_0x19e80d['children']);else{if($(_0x432ba4,_0xad5d53)){if(_0x581d7c=F(_0x432ba4,_0xad5d53),v(_0x581d7c))_0x820de2=Ii(_0x820de2,w(),_0x19e80d['children']);else{const _0x1d3175=Oe(_0x19e80d['children'],y(_0x581d7c));if(_0x1d3175){const _0x535583=_0x1d3175['getChild'](b(_0x581d7c));_0x820de2=Ct(_0x820de2,w(),_0x535583);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x820de2;}function Uo(_0x4c695c,_0x1d5555,_0x274001,_0x1b0c50,_0x2be79b){if(!_0x1b0c50&&!_0x2be79b){const _0x48d957=$e(_0x4c695c['visibleWrites'],_0x1d5555);if(_0x48d957!=null)return _0x48d957;{const _0x5ba1ba=ve(_0x4c695c['visibleWrites'],_0x1d5555);if(Ci(_0x5ba1ba))return _0x274001;if(_0x274001==null&&!wi(_0x5ba1ba,w()))return null;{const _0x248c29=_0x274001||g['EMPTY_NODE'];return it(_0x5ba1ba,_0x248c29);}}}else{const _0x8187d5=ve(_0x4c695c['visibleWrites'],_0x1d5555);if(!_0x2be79b&&Ci(_0x8187d5))return _0x274001;if(!_0x2be79b&&_0x274001==null&&!wi(_0x8187d5,w()))return null;{const _0x585c51=function(_0xb8bbda){return(_0xb8bbda['visible']||_0x2be79b)&&(!_0x1b0c50||!~_0x1b0c50['indexOf'](_0xb8bbda['writeId']))&&($(_0xb8bbda['path'],_0x1d5555)||$(_0x1d5555,_0xb8bbda['path']));},_0x507c60=Fo(_0x4c695c['allWrites'],_0x585c51,_0x1d5555),_0x3eca19=_0x274001||g['EMPTY_NODE'];return it(_0x507c60,_0x3eca19);}}}function fu(_0x148447,_0x18477c,_0x215532){let _0x2acb59=g['EMPTY_NODE'];const _0x54ccb3=$e(_0x148447['visibleWrites'],_0x18477c);if(_0x54ccb3)return _0x54ccb3['isLeafNode']()||_0x54ccb3['forEachChild'](R,(_0xaaeaac,_0x250ba7)=>{_0x2acb59=_0x2acb59['updateImmediateChild'](_0xaaeaac,_0x250ba7);}),_0x2acb59;if(_0x215532){const _0x4ef3b1=ve(_0x148447['visibleWrites'],_0x18477c);return _0x215532['forEachChild'](R,(_0x49208c,_0x2e3486)=>{const _0x454f21=it(ve(_0x4ef3b1,new C(_0x49208c)),_0x2e3486);_0x2acb59=_0x2acb59['updateImmediateChild'](_0x49208c,_0x454f21);}),rr(_0x4ef3b1)['forEach'](_0x4bca83=>{_0x2acb59=_0x2acb59['updateImmediateChild'](_0x4bca83['name'],_0x4bca83['node']);}),_0x2acb59;}else{const _0xf1ca28=ve(_0x148447['visibleWrites'],_0x18477c);return rr(_0xf1ca28)['forEach'](_0x4b586b=>{_0x2acb59=_0x2acb59['updateImmediateChild'](_0x4b586b['name'],_0x4b586b['node']);}),_0x2acb59;}}function pu(_0x4d3765,_0x12e67c,_0x52c59f,_0x345f02,_0x59395e){f(_0x345f02||_0x59395e,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1bc04a=A(_0x12e67c,_0x52c59f);if(wi(_0x4d3765['visibleWrites'],_0x1bc04a))return null;{const _0x526331=ve(_0x4d3765['visibleWrites'],_0x1bc04a);return Ci(_0x526331)?_0x59395e['getChild'](_0x52c59f):it(_0x526331,_0x59395e['getChild'](_0x52c59f));}}function _u(_0x452d19,_0x5421fb,_0x187539,_0x4e09e4){const _0xeb886e=A(_0x5421fb,_0x187539),_0x4e97da=$e(_0x452d19['visibleWrites'],_0xeb886e);if(_0x4e97da!=null)return _0x4e97da;if(_0x4e09e4['isCompleteForChild'](_0x187539)){const _0x2287b0=ve(_0x452d19['visibleWrites'],_0xeb886e);return it(_0x2287b0,_0x4e09e4['getNode']()['getImmediateChild'](_0x187539));}else return null;}function gu(_0x1184e0,_0x38ca9f){return $e(_0x1184e0['visibleWrites'],_0x38ca9f);}function mu(_0x37e576,_0x3b1e6a,_0x58bfc9,_0x19fa56,_0x38bce3,_0x2c28e5,_0x3bfe2d){let _0x34ef40;const _0x21b482=ve(_0x37e576['visibleWrites'],_0x3b1e6a),_0x5eecaa=$e(_0x21b482,w());if(_0x5eecaa!=null)_0x34ef40=_0x5eecaa;else{if(_0x58bfc9!=null)_0x34ef40=it(_0x21b482,_0x58bfc9);else return[];}if(_0x34ef40=_0x34ef40['withIndex'](_0x3bfe2d),!_0x34ef40['isEmpty']()&&!_0x34ef40['isLeafNode']()){const _0x40485f=[],_0xdfb0f8=_0x3bfe2d['getCompare'](),_0x583848=_0x2c28e5?_0x34ef40['getReverseIteratorFrom'](_0x19fa56,_0x3bfe2d):_0x34ef40['getIteratorFrom'](_0x19fa56,_0x3bfe2d);let _0xc45662=_0x583848['getNext']();for(;_0xc45662&&_0x40485f['length']<_0x38bce3;)_0xdfb0f8(_0xc45662,_0x19fa56)!==0x0&&_0x40485f['push'](_0xc45662),_0xc45662=_0x583848['getNext']();return _0x40485f;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0xcfde89,_0x117b4a,_0x2ad7a9,_0x1ca24e){return Uo(_0xcfde89['writeTree'],_0xcfde89['treePath'],_0x117b4a,_0x2ad7a9,_0x1ca24e);}function es(_0x3ba125,_0x5c9b2c){return fu(_0x3ba125['writeTree'],_0x3ba125['treePath'],_0x5c9b2c);}function or(_0x16e4fd,_0x401558,_0x36e7d3,_0xf39d70){return pu(_0x16e4fd['writeTree'],_0x16e4fd['treePath'],_0x401558,_0x36e7d3,_0xf39d70);}function yn(_0xe21628,_0xc63227){return gu(_0xe21628['writeTree'],A(_0xe21628['treePath'],_0xc63227));}function vu(_0x2f2f72,_0x517cf6,_0x58d867,_0xfccd16,_0x1b84ce,_0x2d8f92){return mu(_0x2f2f72['writeTree'],_0x2f2f72['treePath'],_0x517cf6,_0x58d867,_0xfccd16,_0x1b84ce,_0x2d8f92);}function ts(_0x3fc9a3,_0x5b94e2,_0x4788e4){return _u(_0x3fc9a3['writeTree'],_0x3fc9a3['treePath'],_0x5b94e2,_0x4788e4);}function Wo(_0x240909,_0x302105){return Bo(A(_0x240909['treePath'],_0x302105),_0x240909['writeTree']);}function Bo(_0x137425,_0x26eba7){return{'treePath':_0x137425,'writeTree':_0x26eba7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x49d6b0){const _0x3e9e36=_0x49d6b0['type'],_0x123304=_0x49d6b0['childName'];f(_0x3e9e36==='child_added'||_0x3e9e36==='child_changed'||_0x3e9e36==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x123304!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x571265=this['changeMap']['get'](_0x123304);if(_0x571265){const _0xc859f9=_0x571265['type'];if(_0x3e9e36==='child_added'&&_0xc859f9==='child_removed')this['changeMap']['set'](_0x123304,Pt(_0x123304,_0x49d6b0['snapshotNode'],_0x571265['snapshotNode']));else{if(_0x3e9e36==='child_removed'&&_0xc859f9==='child_added')this['changeMap']['delete'](_0x123304);else{if(_0x3e9e36==='child_removed'&&_0xc859f9==='child_changed')this['changeMap']['set'](_0x123304,Nt(_0x123304,_0x571265['oldSnap']));else{if(_0x3e9e36==='child_changed'&&_0xc859f9==='child_added')this['changeMap']['set'](_0x123304,tt(_0x123304,_0x49d6b0['snapshotNode']));else{if(_0x3e9e36==='child_changed'&&_0xc859f9==='child_changed')this['changeMap']['set'](_0x123304,Pt(_0x123304,_0x49d6b0['snapshotNode'],_0x571265['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x49d6b0+'\x20occurred\x20after\x20'+_0x571265);}}}}}else this['changeMap']['set'](_0x123304,_0x49d6b0);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x32ee1d){return null;}['getChildAfterChild'](_0x3a3833,_0x15f885,_0x5bda3b){return null;}}const Vo=new Iu();class ns{constructor(_0x1ed343,_0x1606ac,_0x4e7fe0=null){this['writes_']=_0x1ed343,this['viewCache_']=_0x1606ac,this['optCompleteServerCache_']=_0x4e7fe0;}['getCompleteChild'](_0x5d87a7){const _0x3ef599=this['viewCache_']['eventCache'];if(_0x3ef599['isCompleteForChild'](_0x5d87a7))return _0x3ef599['getNode']()['getImmediateChild'](_0x5d87a7);{const _0x7f932c=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x5d87a7,_0x7f932c);}}['getChildAfterChild'](_0x4f1876,_0x30bac1,_0x219ace){const _0x2c96af=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x3fa16c=vu(this['writes_'],_0x2c96af,_0x30bac1,0x1,_0x219ace,_0x4f1876);return _0x3fa16c['length']===0x0?null:_0x3fa16c[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x41497c){return{'filter':_0x41497c};}function Cu(_0x48e681,_0x115bc2){f(_0x115bc2['eventCache']['getNode']()['isIndexed'](_0x48e681['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x115bc2['serverCache']['getNode']()['isIndexed'](_0x48e681['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x107d88,_0x33f405,_0x33519d,_0x5ce407,_0x43ec12){const _0x5072ed=new Eu();let _0x57d0b0,_0x40bb9e;if(_0x33519d['type']===q['OVERWRITE']){const _0x58f004=_0x33519d;_0x58f004['source']['fromUser']?_0x57d0b0=Ti(_0x107d88,_0x33f405,_0x58f004['path'],_0x58f004['snap'],_0x5ce407,_0x43ec12,_0x5072ed):(f(_0x58f004['source']['fromServer'],'Unknown\x20source.'),_0x40bb9e=_0x58f004['source']['tagged']||_0x33f405['serverCache']['isFiltered']()&&!v(_0x58f004['path']),_0x57d0b0=vn(_0x107d88,_0x33f405,_0x58f004['path'],_0x58f004['snap'],_0x5ce407,_0x43ec12,_0x40bb9e,_0x5072ed));}else{if(_0x33519d['type']===q['MERGE']){const _0x117aed=_0x33519d;_0x117aed['source']['fromUser']?_0x57d0b0=bu(_0x107d88,_0x33f405,_0x117aed['path'],_0x117aed['children'],_0x5ce407,_0x43ec12,_0x5072ed):(f(_0x117aed['source']['fromServer'],'Unknown\x20source.'),_0x40bb9e=_0x117aed['source']['tagged']||_0x33f405['serverCache']['isFiltered'](),_0x57d0b0=Si(_0x107d88,_0x33f405,_0x117aed['path'],_0x117aed['children'],_0x5ce407,_0x43ec12,_0x40bb9e,_0x5072ed));}else{if(_0x33519d['type']===q['ACK_USER_WRITE']){const _0x3f8b1a=_0x33519d;_0x3f8b1a['revert']?_0x57d0b0=ku(_0x107d88,_0x33f405,_0x3f8b1a['path'],_0x5ce407,_0x43ec12,_0x5072ed):_0x57d0b0=Ru(_0x107d88,_0x33f405,_0x3f8b1a['path'],_0x3f8b1a['affectedTree'],_0x5ce407,_0x43ec12,_0x5072ed);}else{if(_0x33519d['type']===q['LISTEN_COMPLETE'])_0x57d0b0=Au(_0x107d88,_0x33f405,_0x33519d['path'],_0x5ce407,_0x5072ed);else throw ot('Unknown\x20operation\x20type:\x20'+_0x33519d['type']);}}}const _0x585154=_0x5072ed['getChanges']();return Su(_0x33f405,_0x57d0b0,_0x585154),{'viewCache':_0x57d0b0,'changes':_0x585154};}function Su(_0x2fc23b,_0x3d9fd8,_0x4ab31c){const _0x3dc2d5=_0x3d9fd8['eventCache'];if(_0x3dc2d5['isFullyInitialized']()){const _0x2c8fd2=_0x3dc2d5['getNode']()['isLeafNode']()||_0x3dc2d5['getNode']()['isEmpty'](),_0xba53ac=gn(_0x2fc23b);(_0x4ab31c['length']>0x0||!_0x2fc23b['eventCache']['isFullyInitialized']()||_0x2c8fd2&&!_0x3dc2d5['getNode']()['equals'](_0xba53ac)||!_0x3dc2d5['getNode']()['getPriority']()['equals'](_0xba53ac['getPriority']()))&&_0x4ab31c['push'](Oo(gn(_0x3d9fd8)));}}function Ho(_0x470676,_0x485b53,_0x2e28ca,_0x539787,_0x539626,_0x244837){const _0x58d871=_0x485b53['eventCache'];if(yn(_0x539787,_0x2e28ca)!=null)return _0x485b53;{let _0x349c78,_0x4845ed;if(v(_0x2e28ca)){if(f(_0x485b53['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x485b53['serverCache']['isFiltered']()){const _0x391d0d=Ue(_0x485b53),_0x589a9f=_0x391d0d instanceof g?_0x391d0d:g['EMPTY_NODE'],_0x2e644c=es(_0x539787,_0x589a9f);_0x349c78=_0x470676['filter']['updateFullNode'](_0x485b53['eventCache']['getNode'](),_0x2e644c,_0x244837);}else{const _0x21c539=mn(_0x539787,Ue(_0x485b53));_0x349c78=_0x470676['filter']['updateFullNode'](_0x485b53['eventCache']['getNode'](),_0x21c539,_0x244837);}}else{const _0x362c49=y(_0x2e28ca);if(_0x362c49==='.priority'){f(we(_0x2e28ca)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x195ee7=_0x58d871['getNode']();_0x4845ed=_0x485b53['serverCache']['getNode']();const _0x156740=or(_0x539787,_0x2e28ca,_0x195ee7,_0x4845ed);_0x156740!=null?_0x349c78=_0x470676['filter']['updatePriority'](_0x195ee7,_0x156740):_0x349c78=_0x58d871['getNode']();}else{const _0x1f76a1=b(_0x2e28ca);let _0x35f13a;if(_0x58d871['isCompleteForChild'](_0x362c49)){_0x4845ed=_0x485b53['serverCache']['getNode']();const _0x52f63b=or(_0x539787,_0x2e28ca,_0x58d871['getNode'](),_0x4845ed);_0x52f63b!=null?_0x35f13a=_0x58d871['getNode']()['getImmediateChild'](_0x362c49)['updateChild'](_0x1f76a1,_0x52f63b):_0x35f13a=_0x58d871['getNode']()['getImmediateChild'](_0x362c49);}else _0x35f13a=ts(_0x539787,_0x362c49,_0x485b53['serverCache']);_0x35f13a!=null?_0x349c78=_0x470676['filter']['updateChild'](_0x58d871['getNode'](),_0x362c49,_0x35f13a,_0x1f76a1,_0x539626,_0x244837):_0x349c78=_0x58d871['getNode']();}}return wt(_0x485b53,_0x349c78,_0x58d871['isFullyInitialized']()||v(_0x2e28ca),_0x470676['filter']['filtersNodes']());}}function vn(_0x4338e7,_0x59361f,_0x54da86,_0x152805,_0x3aa285,_0x27a4aa,_0x301c08,_0x69d35a){const _0x59bf60=_0x59361f['serverCache'];let _0x3a49d3;const _0x330e47=_0x301c08?_0x4338e7['filter']:_0x4338e7['filter']['getIndexedFilter']();if(v(_0x54da86))_0x3a49d3=_0x330e47['updateFullNode'](_0x59bf60['getNode'](),_0x152805,null);else{if(_0x330e47['filtersNodes']()&&!_0x59bf60['isFiltered']()){const _0x57f6b7=_0x59bf60['getNode']()['updateChild'](_0x54da86,_0x152805);_0x3a49d3=_0x330e47['updateFullNode'](_0x59bf60['getNode'](),_0x57f6b7,null);}else{const _0x4b98fd=y(_0x54da86);if(!_0x59bf60['isCompleteForPath'](_0x54da86)&&we(_0x54da86)>0x1)return _0x59361f;const _0x629ce9=b(_0x54da86),_0x4b1cc9=_0x59bf60['getNode']()['getImmediateChild'](_0x4b98fd)['updateChild'](_0x629ce9,_0x152805);_0x4b98fd==='.priority'?_0x3a49d3=_0x330e47['updatePriority'](_0x59bf60['getNode'](),_0x4b1cc9):_0x3a49d3=_0x330e47['updateChild'](_0x59bf60['getNode'](),_0x4b98fd,_0x4b1cc9,_0x629ce9,Vo,null);}}const _0x1a7e55=Lo(_0x59361f,_0x3a49d3,_0x59bf60['isFullyInitialized']()||v(_0x54da86),_0x330e47['filtersNodes']()),_0x1fdd99=new ns(_0x3aa285,_0x1a7e55,_0x27a4aa);return Ho(_0x4338e7,_0x1a7e55,_0x54da86,_0x3aa285,_0x1fdd99,_0x69d35a);}function Ti(_0x21d300,_0x41faec,_0x3d948f,_0x1a7091,_0x1e53ac,_0x82009e,_0x1be34e){const _0x8d5f0a=_0x41faec['eventCache'];let _0x1e0e6f,_0x51f379;const _0x27f228=new ns(_0x1e53ac,_0x41faec,_0x82009e);if(v(_0x3d948f))_0x51f379=_0x21d300['filter']['updateFullNode'](_0x41faec['eventCache']['getNode'](),_0x1a7091,_0x1be34e),_0x1e0e6f=wt(_0x41faec,_0x51f379,!0x0,_0x21d300['filter']['filtersNodes']());else{const _0x35e157=y(_0x3d948f);if(_0x35e157==='.priority')_0x51f379=_0x21d300['filter']['updatePriority'](_0x41faec['eventCache']['getNode'](),_0x1a7091),_0x1e0e6f=wt(_0x41faec,_0x51f379,_0x8d5f0a['isFullyInitialized'](),_0x8d5f0a['isFiltered']());else{const _0x519af4=b(_0x3d948f),_0x29dd75=_0x8d5f0a['getNode']()['getImmediateChild'](_0x35e157);let _0x2dc3fe;if(v(_0x519af4))_0x2dc3fe=_0x1a7091;else{const _0x5537f3=_0x27f228['getCompleteChild'](_0x35e157);_0x5537f3!=null?Gi(_0x519af4)==='.priority'&&_0x5537f3['getChild'](To(_0x519af4))['isEmpty']()?_0x2dc3fe=_0x5537f3:_0x2dc3fe=_0x5537f3['updateChild'](_0x519af4,_0x1a7091):_0x2dc3fe=g['EMPTY_NODE'];}if(_0x29dd75['equals'](_0x2dc3fe))_0x1e0e6f=_0x41faec;else{const _0x103535=_0x21d300['filter']['updateChild'](_0x8d5f0a['getNode'](),_0x35e157,_0x2dc3fe,_0x519af4,_0x27f228,_0x1be34e);_0x1e0e6f=wt(_0x41faec,_0x103535,_0x8d5f0a['isFullyInitialized'](),_0x21d300['filter']['filtersNodes']());}}}return _0x1e0e6f;}function ar(_0x1d9d00,_0x4d2fc9){return _0x1d9d00['eventCache']['isCompleteForChild'](_0x4d2fc9);}function bu(_0x2b6dc1,_0x28072b,_0x2b5907,_0x476c57,_0x2059f8,_0x3dda95,_0x269565){let _0x3b7e6b=_0x28072b;return _0x476c57['foreach']((_0x57d4ef,_0x4cfdfd)=>{const _0x1d1c4a=A(_0x2b5907,_0x57d4ef);ar(_0x28072b,y(_0x1d1c4a))&&(_0x3b7e6b=Ti(_0x2b6dc1,_0x3b7e6b,_0x1d1c4a,_0x4cfdfd,_0x2059f8,_0x3dda95,_0x269565));}),_0x476c57['foreach']((_0x43076c,_0x597976)=>{const _0x174ad6=A(_0x2b5907,_0x43076c);ar(_0x28072b,y(_0x174ad6))||(_0x3b7e6b=Ti(_0x2b6dc1,_0x3b7e6b,_0x174ad6,_0x597976,_0x2059f8,_0x3dda95,_0x269565));}),_0x3b7e6b;}function cr(_0x1e19e0,_0x224add,_0x38f0d8){return _0x38f0d8['foreach']((_0x4bcb68,_0x534fdc)=>{_0x224add=_0x224add['updateChild'](_0x4bcb68,_0x534fdc);}),_0x224add;}function Si(_0x42cec7,_0x599f24,_0x1dfb67,_0xe37c7b,_0x39b57a,_0x3cc750,_0x5050d9,_0x15da15){if(_0x599f24['serverCache']['getNode']()['isEmpty']()&&!_0x599f24['serverCache']['isFullyInitialized']())return _0x599f24;let _0x448562=_0x599f24,_0x59187e;v(_0x1dfb67)?_0x59187e=_0xe37c7b:_0x59187e=new S(null)['setTree'](_0x1dfb67,_0xe37c7b);const _0x24b5b2=_0x599f24['serverCache']['getNode']();return _0x59187e['children']['inorderTraversal']((_0x4002db,_0x44931d)=>{if(_0x24b5b2['hasChild'](_0x4002db)){const _0x2cce29=_0x599f24['serverCache']['getNode']()['getImmediateChild'](_0x4002db),_0x25d443=cr(_0x42cec7,_0x2cce29,_0x44931d);_0x448562=vn(_0x42cec7,_0x448562,new C(_0x4002db),_0x25d443,_0x39b57a,_0x3cc750,_0x5050d9,_0x15da15);}}),_0x59187e['children']['inorderTraversal']((_0x444d01,_0xbdb136)=>{const _0x4b9d59=!_0x599f24['serverCache']['isCompleteForChild'](_0x444d01)&&_0xbdb136['value']===null;if(!_0x24b5b2['hasChild'](_0x444d01)&&!_0x4b9d59){const _0x342fa1=_0x599f24['serverCache']['getNode']()['getImmediateChild'](_0x444d01),_0x17acaa=cr(_0x42cec7,_0x342fa1,_0xbdb136);_0x448562=vn(_0x42cec7,_0x448562,new C(_0x444d01),_0x17acaa,_0x39b57a,_0x3cc750,_0x5050d9,_0x15da15);}}),_0x448562;}function Ru(_0x3eb2de,_0x5f43b1,_0x3c062b,_0x2b335e,_0x5207a3,_0x3d1484,_0x104a07){if(yn(_0x5207a3,_0x3c062b)!=null)return _0x5f43b1;const _0xd9a03f=_0x5f43b1['serverCache']['isFiltered'](),_0x55da09=_0x5f43b1['serverCache'];if(_0x2b335e['value']!=null){if(v(_0x3c062b)&&_0x55da09['isFullyInitialized']()||_0x55da09['isCompleteForPath'](_0x3c062b))return vn(_0x3eb2de,_0x5f43b1,_0x3c062b,_0x55da09['getNode']()['getChild'](_0x3c062b),_0x5207a3,_0x3d1484,_0xd9a03f,_0x104a07);if(v(_0x3c062b)){let _0x80af03=new S(null);return _0x55da09['getNode']()['forEachChild'](ye,(_0x38ca31,_0x19cb3b)=>{_0x80af03=_0x80af03['set'](new C(_0x38ca31),_0x19cb3b);}),Si(_0x3eb2de,_0x5f43b1,_0x3c062b,_0x80af03,_0x5207a3,_0x3d1484,_0xd9a03f,_0x104a07);}else return _0x5f43b1;}else{let _0xcec71d=new S(null);return _0x2b335e['foreach']((_0x2a39ba,_0x2f2a6f)=>{const _0x29b34f=A(_0x3c062b,_0x2a39ba);_0x55da09['isCompleteForPath'](_0x29b34f)&&(_0xcec71d=_0xcec71d['set'](_0x2a39ba,_0x55da09['getNode']()['getChild'](_0x29b34f)));}),Si(_0x3eb2de,_0x5f43b1,_0x3c062b,_0xcec71d,_0x5207a3,_0x3d1484,_0xd9a03f,_0x104a07);}}function Au(_0x3c82a5,_0x1e37d5,_0x274526,_0x2a4863,_0x32dd0b){const _0x4b7470=_0x1e37d5['serverCache'],_0x22a6c5=Lo(_0x1e37d5,_0x4b7470['getNode'](),_0x4b7470['isFullyInitialized']()||v(_0x274526),_0x4b7470['isFiltered']());return Ho(_0x3c82a5,_0x22a6c5,_0x274526,_0x2a4863,Vo,_0x32dd0b);}function ku(_0x5c3025,_0x25d09f,_0xb109f4,_0xe039b4,_0x30aadc,_0x4305f6){let _0xb54d32;if(yn(_0xe039b4,_0xb109f4)!=null)return _0x25d09f;{const _0x369f3e=new ns(_0xe039b4,_0x25d09f,_0x30aadc),_0x21f0ce=_0x25d09f['eventCache']['getNode']();let _0x4a4294;if(v(_0xb109f4)||y(_0xb109f4)==='.priority'){let _0xae2ae;if(_0x25d09f['serverCache']['isFullyInitialized']())_0xae2ae=mn(_0xe039b4,Ue(_0x25d09f));else{const _0x3a2707=_0x25d09f['serverCache']['getNode']();f(_0x3a2707 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xae2ae=es(_0xe039b4,_0x3a2707);}_0xae2ae=_0xae2ae,_0x4a4294=_0x5c3025['filter']['updateFullNode'](_0x21f0ce,_0xae2ae,_0x4305f6);}else{const _0x338d46=y(_0xb109f4);let _0x4be758=ts(_0xe039b4,_0x338d46,_0x25d09f['serverCache']);_0x4be758==null&&_0x25d09f['serverCache']['isCompleteForChild'](_0x338d46)&&(_0x4be758=_0x21f0ce['getImmediateChild'](_0x338d46)),_0x4be758!=null?_0x4a4294=_0x5c3025['filter']['updateChild'](_0x21f0ce,_0x338d46,_0x4be758,b(_0xb109f4),_0x369f3e,_0x4305f6):_0x25d09f['eventCache']['getNode']()['hasChild'](_0x338d46)?_0x4a4294=_0x5c3025['filter']['updateChild'](_0x21f0ce,_0x338d46,g['EMPTY_NODE'],b(_0xb109f4),_0x369f3e,_0x4305f6):_0x4a4294=_0x21f0ce,_0x4a4294['isEmpty']()&&_0x25d09f['serverCache']['isFullyInitialized']()&&(_0xb54d32=mn(_0xe039b4,Ue(_0x25d09f)),_0xb54d32['isLeafNode']()&&(_0x4a4294=_0x5c3025['filter']['updateFullNode'](_0x4a4294,_0xb54d32,_0x4305f6)));}return _0xb54d32=_0x25d09f['serverCache']['isFullyInitialized']()||yn(_0xe039b4,w())!=null,wt(_0x25d09f,_0x4a4294,_0xb54d32,_0x5c3025['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x15dc02,_0x4c5ec1){this['query_']=_0x15dc02,this['eventRegistrations_']=[];const _0x5f2652=this['query_']['_queryParams'],_0x465a01=new Yi(_0x5f2652['getIndex']()),_0x37bf7b=qh(_0x5f2652);this['processor_']=wu(_0x37bf7b);const _0xb8618d=_0x4c5ec1['serverCache'],_0x37203b=_0x4c5ec1['eventCache'],_0x4b53e3=_0x465a01['updateFullNode'](g['EMPTY_NODE'],_0xb8618d['getNode'](),null),_0x3e2fa2=_0x37bf7b['updateFullNode'](g['EMPTY_NODE'],_0x37203b['getNode'](),null),_0x40399a=new Ce(_0x4b53e3,_0xb8618d['isFullyInitialized'](),_0x465a01['filtersNodes']()),_0x58a101=new Ce(_0x3e2fa2,_0x37203b['isFullyInitialized'](),_0x37bf7b['filtersNodes']());this['viewCache_']=Dn(_0x58a101,_0x40399a),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x5c3565){return _0x5c3565['viewCache_']['serverCache']['getNode']();}function Ou(_0x1a002a){return gn(_0x1a002a['viewCache_']);}function Du(_0x3a1a29,_0x58f0a3){const _0x1cee21=Ue(_0x3a1a29['viewCache_']);return _0x1cee21&&(_0x3a1a29['query']['_queryParams']['loadsAllData']()||!v(_0x58f0a3)&&!_0x1cee21['getImmediateChild'](y(_0x58f0a3))['isEmpty']())?_0x1cee21['getChild'](_0x58f0a3):null;}function lr(_0x2d3ede){return _0x2d3ede['eventRegistrations_']['length']===0x0;}function Mu(_0x419bb2,_0x2e2448){_0x419bb2['eventRegistrations_']['push'](_0x2e2448);}function hr(_0x2a9a0b,_0xc466f8,_0x546dfc){const _0xf42bbb=[];if(_0x546dfc){f(_0xc466f8==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x9cd091=_0x2a9a0b['query']['_path'];_0x2a9a0b['eventRegistrations_']['forEach'](_0x2e3559=>{const _0x4e556b=_0x2e3559['createCancelEvent'](_0x546dfc,_0x9cd091);_0x4e556b&&_0xf42bbb['push'](_0x4e556b);});}if(_0xc466f8){let _0x40c053=[];for(let _0x419510=0x0;_0x419510<_0x2a9a0b['eventRegistrations_']['length'];++_0x419510){const _0x14555d=_0x2a9a0b['eventRegistrations_'][_0x419510];if(!_0x14555d['matches'](_0xc466f8))_0x40c053['push'](_0x14555d);else{if(_0xc466f8['hasAnyCallback']()){_0x40c053=_0x40c053['concat'](_0x2a9a0b['eventRegistrations_']['slice'](_0x419510+0x1));break;}}}_0x2a9a0b['eventRegistrations_']=_0x40c053;}else _0x2a9a0b['eventRegistrations_']=[];return _0xf42bbb;}function ur(_0x3ff9e8,_0x46b25b,_0x2a45ed,_0x2a2eab){_0x46b25b['type']===q['MERGE']&&_0x46b25b['source']['queryId']!==null&&(f(Ue(_0x3ff9e8['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x3ff9e8['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3a85d9=_0x3ff9e8['viewCache_'],_0x3a663c=Tu(_0x3ff9e8['processor_'],_0x3a85d9,_0x46b25b,_0x2a45ed,_0x2a2eab);return Cu(_0x3ff9e8['processor_'],_0x3a663c['viewCache']),f(_0x3a663c['viewCache']['serverCache']['isFullyInitialized']()||!_0x3a85d9['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x3ff9e8['viewCache_']=_0x3a663c['viewCache'],$o(_0x3ff9e8,_0x3a663c['changes'],_0x3a663c['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x3c70d6,_0x442982){const _0x23e31d=_0x3c70d6['viewCache_']['eventCache'],_0x2e0eac=[];return _0x23e31d['getNode']()['isLeafNode']()||_0x23e31d['getNode']()['forEachChild'](R,(_0x5d7276,_0x2aed30)=>{_0x2e0eac['push'](tt(_0x5d7276,_0x2aed30));}),_0x23e31d['isFullyInitialized']()&&_0x2e0eac['push'](Oo(_0x23e31d['getNode']())),$o(_0x3c70d6,_0x2e0eac,_0x23e31d['getNode'](),_0x442982);}function $o(_0x68518c,_0x4ff717,_0x3a8aef,_0x371e27){const _0x3f1347=_0x371e27?[_0x371e27]:_0x68518c['eventRegistrations_'];return nu(_0x68518c['eventGenerator_'],_0x4ff717,_0x3a8aef,_0x3f1347);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x30ff0a){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x30ff0a;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x146392){return _0x146392['views']['size']===0x0;}function is(_0x1e75d6,_0x13bf4c,_0x3485a6,_0x4f6fa3){const _0x3c0a7e=_0x13bf4c['source']['queryId'];if(_0x3c0a7e!==null){const _0x41e626=_0x1e75d6['views']['get'](_0x3c0a7e);return f(_0x41e626!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x41e626,_0x13bf4c,_0x3485a6,_0x4f6fa3);}else{let _0x5771b2=[];for(const _0x31611b of _0x1e75d6['views']['values']())_0x5771b2=_0x5771b2['concat'](ur(_0x31611b,_0x13bf4c,_0x3485a6,_0x4f6fa3));return _0x5771b2;}}function qo(_0x26d4b8,_0x131e9d,_0x40e096,_0x221748,_0x36cdad){const _0x6d004e=_0x131e9d['_queryIdentifier'],_0x293ef8=_0x26d4b8['views']['get'](_0x6d004e);if(!_0x293ef8){let _0x2f353a=mn(_0x40e096,_0x36cdad?_0x221748:null),_0x15a8f5=!0x1;_0x2f353a?_0x15a8f5=!0x0:_0x221748 instanceof g?(_0x2f353a=es(_0x40e096,_0x221748),_0x15a8f5=!0x1):(_0x2f353a=g['EMPTY_NODE'],_0x15a8f5=!0x1);const _0x19f814=Dn(new Ce(_0x2f353a,_0x15a8f5,!0x1),new Ce(_0x221748,_0x36cdad,!0x1));return new Nu(_0x131e9d,_0x19f814);}return _0x293ef8;}function Wu(_0xd3d3ff,_0xca67de,_0xf7482c,_0x446a77,_0x1756e7,_0x1de56d){const _0x40a7c5=qo(_0xd3d3ff,_0xca67de,_0x446a77,_0x1756e7,_0x1de56d);return _0xd3d3ff['views']['has'](_0xca67de['_queryIdentifier'])||_0xd3d3ff['views']['set'](_0xca67de['_queryIdentifier'],_0x40a7c5),Mu(_0x40a7c5,_0xf7482c),Lu(_0x40a7c5,_0xf7482c);}function Bu(_0x3e9d11,_0x1a9480,_0x5019e4,_0x505f59){const _0x4e721a=_0x1a9480['_queryIdentifier'],_0x39f9c5=[];let _0x231ea2=[];const _0x3c5a80=Te(_0x3e9d11);if(_0x4e721a==='default'){for(const [_0x5647d0,_0xcfd3fb]of _0x3e9d11['views']['entries']())_0x231ea2=_0x231ea2['concat'](hr(_0xcfd3fb,_0x5019e4,_0x505f59)),lr(_0xcfd3fb)&&(_0x3e9d11['views']['delete'](_0x5647d0),_0xcfd3fb['query']['_queryParams']['loadsAllData']()||_0x39f9c5['push'](_0xcfd3fb['query']));}else{const _0x168858=_0x3e9d11['views']['get'](_0x4e721a);_0x168858&&(_0x231ea2=_0x231ea2['concat'](hr(_0x168858,_0x5019e4,_0x505f59)),lr(_0x168858)&&(_0x3e9d11['views']['delete'](_0x4e721a),_0x168858['query']['_queryParams']['loadsAllData']()||_0x39f9c5['push'](_0x168858['query'])));}return _0x3c5a80&&!Te(_0x3e9d11)&&_0x39f9c5['push'](new(Fu())(_0x1a9480['_repo'],_0x1a9480['_path'])),{'removed':_0x39f9c5,'events':_0x231ea2};}function zo(_0x149b09){const _0x2dec4a=[];for(const _0x4706c0 of _0x149b09['views']['values']())_0x4706c0['query']['_queryParams']['loadsAllData']()||_0x2dec4a['push'](_0x4706c0);return _0x2dec4a;}function Ee(_0x319950,_0x283740){let _0x51e254=null;for(const _0x1fb13d of _0x319950['views']['values']())_0x51e254=_0x51e254||Du(_0x1fb13d,_0x283740);return _0x51e254;}function jo(_0x1ef299,_0x22221c){if(_0x22221c['_queryParams']['loadsAllData']())return Ln(_0x1ef299);{const _0x387c9d=_0x22221c['_queryIdentifier'];return _0x1ef299['views']['get'](_0x387c9d);}}function Ko(_0x2630ac,_0x25217b){return jo(_0x2630ac,_0x25217b)!=null;}function Te(_0x5eb2a3){return Ln(_0x5eb2a3)!=null;}function Ln(_0x3b8fa0){for(const _0x1132aa of _0x3b8fa0['views']['values']())if(_0x1132aa['query']['_queryParams']['loadsAllData']())return _0x1132aa;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1bad26){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1bad26;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1950ce){this['listenProvider_']=_0x1950ce,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x4cfad5,_0x599bd9,_0xc209f1,_0x513ee0,_0x33eb3d){return ou(_0x4cfad5['pendingWriteTree_'],_0x599bd9,_0xc209f1,_0x513ee0,_0x33eb3d),_0x33eb3d?ht(_0x4cfad5,new Fe(Ji(),_0x599bd9,_0xc209f1)):[];}function Gu(_0x254346,_0x22f9be,_0x55be43,_0x42992f){au(_0x254346['pendingWriteTree_'],_0x22f9be,_0x55be43,_0x42992f);const _0x5ef7fb=S['fromObject'](_0x55be43);return ht(_0x254346,new nt(Ji(),_0x22f9be,_0x5ef7fb));}function pe(_0x23a00a,_0xcdc9f3,_0x3e263f=!0x1){const _0x4f5552=cu(_0x23a00a['pendingWriteTree_'],_0xcdc9f3);if(lu(_0x23a00a['pendingWriteTree_'],_0xcdc9f3)){let _0x1cbfcd=new S(null);return _0x4f5552['snap']!=null?_0x1cbfcd=_0x1cbfcd['set'](w(),!0x0):x(_0x4f5552['children'],_0x15aa98=>{_0x1cbfcd=_0x1cbfcd['set'](new C(_0x15aa98),!0x0);}),ht(_0x23a00a,new _n(_0x4f5552['path'],_0x1cbfcd,_0x3e263f));}else return[];}function $t(_0x3db8d9,_0x27deb1,_0x52ecc2){return ht(_0x3db8d9,new Fe(Xi(),_0x27deb1,_0x52ecc2));}function qu(_0x42e024,_0x45d9c4,_0x11b3e9){const _0x9ad2b6=S['fromObject'](_0x11b3e9);return ht(_0x42e024,new nt(Xi(),_0x45d9c4,_0x9ad2b6));}function zu(_0x17c285,_0x488ad3){return ht(_0x17c285,new Dt(Xi(),_0x488ad3));}function ju(_0x78b19d,_0x572762,_0x47a507){const _0x2f17ea=rs(_0x78b19d,_0x47a507);if(_0x2f17ea){const _0x4cad0e=os(_0x2f17ea),_0x33e8c3=_0x4cad0e['path'],_0x6ae154=_0x4cad0e['queryId'],_0x23a07d=F(_0x33e8c3,_0x572762),_0x371444=new Dt(Zi(_0x6ae154),_0x23a07d);return as(_0x78b19d,_0x33e8c3,_0x371444);}else return[];}function wn(_0x1fd8bb,_0x4c097e,_0x2aa968,_0x1c44f7,_0x247a28=!0x1){const _0x2551f7=_0x4c097e['_path'],_0x6468df=_0x1fd8bb['syncPointTree_']['get'](_0x2551f7);let _0xac3866=[];if(_0x6468df&&(_0x4c097e['_queryIdentifier']==='default'||Ko(_0x6468df,_0x4c097e))){const _0x5d069f=Bu(_0x6468df,_0x4c097e,_0x2aa968,_0x1c44f7);Uu(_0x6468df)&&(_0x1fd8bb['syncPointTree_']=_0x1fd8bb['syncPointTree_']['remove'](_0x2551f7));const _0x24f88c=_0x5d069f['removed'];if(_0xac3866=_0x5d069f['events'],!_0x247a28){const _0x25f0b7=_0x24f88c['findIndex'](_0x419955=>_0x419955['_queryParams']['loadsAllData']())!==-0x1,_0x5c32cf=_0x1fd8bb['syncPointTree_']['findOnPath'](_0x2551f7,(_0x3c1e9f,_0x846e7f)=>Te(_0x846e7f));if(_0x25f0b7&&!_0x5c32cf){const _0x6231e0=_0x1fd8bb['syncPointTree_']['subtree'](_0x2551f7);if(!_0x6231e0['isEmpty']()){const _0x1d4abb=Qu(_0x6231e0);for(let _0x27aed9=0x0;_0x27aed9<_0x1d4abb['length'];++_0x27aed9){const _0x2827f5=_0x1d4abb[_0x27aed9],_0x318c8f=_0x2827f5['query'],_0x2e84b9=Xo(_0x1fd8bb,_0x2827f5);_0x1fd8bb['listenProvider_']['startListening'](Tt(_0x318c8f),Mt(_0x1fd8bb,_0x318c8f),_0x2e84b9['hashFn'],_0x2e84b9['onComplete']);}}}!_0x5c32cf&&_0x24f88c['length']>0x0&&!_0x1c44f7&&(_0x25f0b7?_0x1fd8bb['listenProvider_']['stopListening'](Tt(_0x4c097e),null):_0x24f88c['forEach'](_0x5e89bf=>{const _0x284b7e=_0x1fd8bb['queryToTagMap']['get'](Fn(_0x5e89bf));_0x1fd8bb['listenProvider_']['stopListening'](Tt(_0x5e89bf),_0x284b7e);}));}Ju(_0x1fd8bb,_0x24f88c);}return _0xac3866;}function Yo(_0x5a3005,_0x38d016,_0x4e2ad5,_0x1028cf){const _0x4be04f=rs(_0x5a3005,_0x1028cf);if(_0x4be04f!=null){const _0x2105d2=os(_0x4be04f),_0x17a5a1=_0x2105d2['path'],_0x276b6c=_0x2105d2['queryId'],_0x34d4c6=F(_0x17a5a1,_0x38d016),_0x147196=new Fe(Zi(_0x276b6c),_0x34d4c6,_0x4e2ad5);return as(_0x5a3005,_0x17a5a1,_0x147196);}else return[];}function Ku(_0x5079df,_0x3fc86b,_0x4eec0a,_0x32bef7){const _0x4058e9=rs(_0x5079df,_0x32bef7);if(_0x4058e9){const _0x3f4c59=os(_0x4058e9),_0x27b39b=_0x3f4c59['path'],_0x19ac25=_0x3f4c59['queryId'],_0x3922bc=F(_0x27b39b,_0x3fc86b),_0x152e2a=S['fromObject'](_0x4eec0a),_0x27b2a0=new nt(Zi(_0x19ac25),_0x3922bc,_0x152e2a);return as(_0x5079df,_0x27b39b,_0x27b2a0);}else return[];}function bi(_0x33afcc,_0x3df835,_0x4a191b,_0x46795c=!0x1){const _0x21105b=_0x3df835['_path'];let _0x250902=null,_0x448f51=!0x1;_0x33afcc['syncPointTree_']['foreachOnPath'](_0x21105b,(_0x218fa8,_0x4e5a6a)=>{const _0x3926ed=F(_0x218fa8,_0x21105b);_0x250902=_0x250902||Ee(_0x4e5a6a,_0x3926ed),_0x448f51=_0x448f51||Te(_0x4e5a6a);});let _0x4716e4=_0x33afcc['syncPointTree_']['get'](_0x21105b);_0x4716e4?(_0x448f51=_0x448f51||Te(_0x4716e4),_0x250902=_0x250902||Ee(_0x4716e4,w())):(_0x4716e4=new Go(),_0x33afcc['syncPointTree_']=_0x33afcc['syncPointTree_']['set'](_0x21105b,_0x4716e4));let _0x147877;_0x250902!=null?_0x147877=!0x0:(_0x147877=!0x1,_0x250902=g['EMPTY_NODE'],_0x33afcc['syncPointTree_']['subtree'](_0x21105b)['foreachChild']((_0x2bcd14,_0x556c93)=>{const _0x20ba32=Ee(_0x556c93,w());_0x20ba32&&(_0x250902=_0x250902['updateImmediateChild'](_0x2bcd14,_0x20ba32));}));const _0x45ae61=Ko(_0x4716e4,_0x3df835);if(!_0x45ae61&&!_0x3df835['_queryParams']['loadsAllData']()){const _0x47e046=Fn(_0x3df835);f(!_0x33afcc['queryToTagMap']['has'](_0x47e046),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x13b845=Xu();_0x33afcc['queryToTagMap']['set'](_0x47e046,_0x13b845),_0x33afcc['tagToQueryMap']['set'](_0x13b845,_0x47e046);}const _0x54ac1c=Mn(_0x33afcc['pendingWriteTree_'],_0x21105b);let _0x48edc7=Wu(_0x4716e4,_0x3df835,_0x4a191b,_0x54ac1c,_0x250902,_0x147877);if(!_0x45ae61&&!_0x448f51&&!_0x46795c){const _0x31bb75=jo(_0x4716e4,_0x3df835);_0x48edc7=_0x48edc7['concat'](Zu(_0x33afcc,_0x3df835,_0x31bb75));}return _0x48edc7;}function xn(_0x5fde5b,_0x3b6143,_0x17fab8){const _0x14b456=_0x5fde5b['pendingWriteTree_'],_0x1075fb=_0x5fde5b['syncPointTree_']['findOnPath'](_0x3b6143,(_0x12d750,_0x44f134)=>{const _0x83c40f=F(_0x12d750,_0x3b6143),_0x339c2b=Ee(_0x44f134,_0x83c40f);if(_0x339c2b)return _0x339c2b;});return Uo(_0x14b456,_0x3b6143,_0x1075fb,_0x17fab8,!0x0);}function Yu(_0x224d5e,_0x38269a){const _0x514e0b=_0x38269a['_path'];let _0x2fb965=null;_0x224d5e['syncPointTree_']['foreachOnPath'](_0x514e0b,(_0x27b1c6,_0x50370d)=>{const _0x2013b0=F(_0x27b1c6,_0x514e0b);_0x2fb965=_0x2fb965||Ee(_0x50370d,_0x2013b0);});let _0x3cf1ca=_0x224d5e['syncPointTree_']['get'](_0x514e0b);_0x3cf1ca?_0x2fb965=_0x2fb965||Ee(_0x3cf1ca,w()):(_0x3cf1ca=new Go(),_0x224d5e['syncPointTree_']=_0x224d5e['syncPointTree_']['set'](_0x514e0b,_0x3cf1ca));const _0x555813=_0x2fb965!=null,_0x15077d=_0x555813?new Ce(_0x2fb965,!0x0,!0x1):null,_0x59180a=Mn(_0x224d5e['pendingWriteTree_'],_0x38269a['_path']),_0x41d1e7=qo(_0x3cf1ca,_0x38269a,_0x59180a,_0x555813?_0x15077d['getNode']():g['EMPTY_NODE'],_0x555813);return Ou(_0x41d1e7);}function ht(_0x39e511,_0x59217f){return Qo(_0x59217f,_0x39e511['syncPointTree_'],null,Mn(_0x39e511['pendingWriteTree_'],w()));}function Qo(_0x496fd2,_0x3aab6b,_0xcdfb26,_0x861563){if(v(_0x496fd2['path']))return Jo(_0x496fd2,_0x3aab6b,_0xcdfb26,_0x861563);{const _0xc90581=_0x3aab6b['get'](w());_0xcdfb26==null&&_0xc90581!=null&&(_0xcdfb26=Ee(_0xc90581,w()));let _0x385661=[];const _0x25309d=y(_0x496fd2['path']),_0x534fc7=_0x496fd2['operationForChild'](_0x25309d),_0x4154df=_0x3aab6b['children']['get'](_0x25309d);if(_0x4154df&&_0x534fc7){const _0x6bd67=_0xcdfb26?_0xcdfb26['getImmediateChild'](_0x25309d):null,_0x9e8d91=Wo(_0x861563,_0x25309d);_0x385661=_0x385661['concat'](Qo(_0x534fc7,_0x4154df,_0x6bd67,_0x9e8d91));}return _0xc90581&&(_0x385661=_0x385661['concat'](is(_0xc90581,_0x496fd2,_0x861563,_0xcdfb26))),_0x385661;}}function Jo(_0x4f7657,_0x4ed09c,_0x29f3bb,_0x3b14d1){const _0x31fce6=_0x4ed09c['get'](w());_0x29f3bb==null&&_0x31fce6!=null&&(_0x29f3bb=Ee(_0x31fce6,w()));let _0x2ae94e=[];return _0x4ed09c['children']['inorderTraversal']((_0xb905af,_0x2ea14e)=>{const _0x437ecc=_0x29f3bb?_0x29f3bb['getImmediateChild'](_0xb905af):null,_0x2a04a6=Wo(_0x3b14d1,_0xb905af),_0x34b48f=_0x4f7657['operationForChild'](_0xb905af);_0x34b48f&&(_0x2ae94e=_0x2ae94e['concat'](Jo(_0x34b48f,_0x2ea14e,_0x437ecc,_0x2a04a6)));}),_0x31fce6&&(_0x2ae94e=_0x2ae94e['concat'](is(_0x31fce6,_0x4f7657,_0x3b14d1,_0x29f3bb))),_0x2ae94e;}function Xo(_0x3bcfdd,_0x5d8684){const _0x288d12=_0x5d8684['query'],_0x3942bb=Mt(_0x3bcfdd,_0x288d12);return{'hashFn':()=>(Pu(_0x5d8684)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x258644=>{if(_0x258644==='ok')return _0x3942bb?ju(_0x3bcfdd,_0x288d12['_path'],_0x3942bb):zu(_0x3bcfdd,_0x288d12['_path']);{const _0xb87faa=ql(_0x258644,_0x288d12);return wn(_0x3bcfdd,_0x288d12,null,_0xb87faa);}}};}function Mt(_0x544d10,_0x2f0d08){const _0x4200d2=Fn(_0x2f0d08);return _0x544d10['queryToTagMap']['get'](_0x4200d2);}function Fn(_0x4da12c){return _0x4da12c['_path']['toString']()+'$'+_0x4da12c['_queryIdentifier'];}function rs(_0x882e51,_0x46e73c){return _0x882e51['tagToQueryMap']['get'](_0x46e73c);}function os(_0x33b337){const _0x5b83c0=_0x33b337['indexOf']('$');return f(_0x5b83c0!==-0x1&&_0x5b83c0<_0x33b337['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x33b337['substr'](_0x5b83c0+0x1),'path':new C(_0x33b337['substr'](0x0,_0x5b83c0))};}function as(_0x113c17,_0x8e7be7,_0x12a7b2){const _0x32a2dc=_0x113c17['syncPointTree_']['get'](_0x8e7be7);f(_0x32a2dc,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1de287=Mn(_0x113c17['pendingWriteTree_'],_0x8e7be7);return is(_0x32a2dc,_0x12a7b2,_0x1de287,null);}function Qu(_0x51da0c){return _0x51da0c['fold']((_0x353301,_0xe640f4,_0x572108)=>{if(_0xe640f4&&Te(_0xe640f4))return[Ln(_0xe640f4)];{let _0xedde7c=[];return _0xe640f4&&(_0xedde7c=zo(_0xe640f4)),x(_0x572108,(_0x361c61,_0xa0b3b4)=>{_0xedde7c=_0xedde7c['concat'](_0xa0b3b4);}),_0xedde7c;}});}function Tt(_0x4db56a){return _0x4db56a['_queryParams']['loadsAllData']()&&!_0x4db56a['_queryParams']['isDefault']()?new(Hu())(_0x4db56a['_repo'],_0x4db56a['_path']):_0x4db56a;}function Ju(_0x2f027e,_0x46f111){for(let _0x4edb7f=0x0;_0x4edb7f<_0x46f111['length'];++_0x4edb7f){const _0x2124d8=_0x46f111[_0x4edb7f];if(!_0x2124d8['_queryParams']['loadsAllData']()){const _0x42d564=Fn(_0x2124d8),_0x5ac8dc=_0x2f027e['queryToTagMap']['get'](_0x42d564);_0x2f027e['queryToTagMap']['delete'](_0x42d564),_0x2f027e['tagToQueryMap']['delete'](_0x5ac8dc);}}}function Xu(){return $u++;}function Zu(_0x4dbda1,_0x2a9dee,_0x4b3d46){const _0x19b6a5=_0x2a9dee['_path'],_0x85db4a=Mt(_0x4dbda1,_0x2a9dee),_0x417291=Xo(_0x4dbda1,_0x4b3d46),_0x2f2b38=_0x4dbda1['listenProvider_']['startListening'](Tt(_0x2a9dee),_0x85db4a,_0x417291['hashFn'],_0x417291['onComplete']),_0x156f1a=_0x4dbda1['syncPointTree_']['subtree'](_0x19b6a5);if(_0x85db4a)f(!Te(_0x156f1a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2aaf96=_0x156f1a['fold']((_0x45860d,_0x4d5916,_0x2914d2)=>{if(!v(_0x45860d)&&_0x4d5916&&Te(_0x4d5916))return[Ln(_0x4d5916)['query']];{let _0x40dc0b=[];return _0x4d5916&&(_0x40dc0b=_0x40dc0b['concat'](zo(_0x4d5916)['map'](_0x4fd7e2=>_0x4fd7e2['query']))),x(_0x2914d2,(_0x27ea23,_0x3d10bf)=>{_0x40dc0b=_0x40dc0b['concat'](_0x3d10bf);}),_0x40dc0b;}});for(let _0x2d4517=0x0;_0x2d4517<_0x2aaf96['length'];++_0x2d4517){const _0x55e121=_0x2aaf96[_0x2d4517];_0x4dbda1['listenProvider_']['stopListening'](Tt(_0x55e121),Mt(_0x4dbda1,_0x55e121));}}return _0x2f2b38;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x3dc965){this['node_']=_0x3dc965;}['getImmediateChild'](_0x595734){const _0x33f546=this['node_']['getImmediateChild'](_0x595734);return new cs(_0x33f546);}['node'](){return this['node_'];}}class ls{constructor(_0x281f87,_0x194d02){this['syncTree_']=_0x281f87,this['path_']=_0x194d02;}['getImmediateChild'](_0x5be508){const _0x53cac5=A(this['path_'],_0x5be508);return new ls(this['syncTree_'],_0x53cac5);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x3ab7b2){return _0x3ab7b2=_0x3ab7b2||{},_0x3ab7b2['timestamp']=_0x3ab7b2['timestamp']||new Date()['getTime'](),_0x3ab7b2;},fr=function(_0x4dc635,_0x1084d1,_0x1d20c6){if(!_0x4dc635||typeof _0x4dc635!='object')return _0x4dc635;if(f('.sv'in _0x4dc635,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4dc635['.sv']=='string')return td(_0x4dc635['.sv'],_0x1084d1,_0x1d20c6);if(typeof _0x4dc635['.sv']=='object')return nd(_0x4dc635['.sv'],_0x1084d1);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4dc635,null,0x2));},td=function(_0x72f176,_0x18ce7a,_0x336929){switch(_0x72f176){case'timestamp':return _0x336929['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x72f176);}},nd=function(_0x5dbfae,_0x4dd210,_0x3effca){_0x5dbfae['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5dbfae,null,0x2));const _0x218d6a=_0x5dbfae['increment'];typeof _0x218d6a!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x218d6a);const _0x47f09c=_0x4dd210['node']();if(f(_0x47f09c!==null&&typeof _0x47f09c<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x47f09c['isLeafNode']())return _0x218d6a;const _0xfeae41=_0x47f09c['getValue']();return typeof _0xfeae41!='number'?_0x218d6a:_0xfeae41+_0x218d6a;},Zo=function(_0x3b082f,_0x2490db,_0x3fa079,_0x422697){return us(_0x2490db,new ls(_0x3fa079,_0x3b082f),_0x422697);},hs=function(_0x4829a9,_0x264984,_0x2dc629){return us(_0x4829a9,new cs(_0x264984),_0x2dc629);};function us(_0x2f294c,_0x370aff,_0x306dee){const _0x12a235=_0x2f294c['getPriority']()['val'](),_0x715c85=fr(_0x12a235,_0x370aff['getImmediateChild']('.priority'),_0x306dee);let _0x352cc6;if(_0x2f294c['isLeafNode']()){const _0xe81b26=_0x2f294c,_0x57d854=fr(_0xe81b26['getValue'](),_0x370aff,_0x306dee);return _0x57d854!==_0xe81b26['getValue']()||_0x715c85!==_0xe81b26['getPriority']()['val']()?new D(_0x57d854,N(_0x715c85)):_0x2f294c;}else{const _0x396c71=_0x2f294c;return _0x352cc6=_0x396c71,_0x715c85!==_0x396c71['getPriority']()['val']()&&(_0x352cc6=_0x352cc6['updatePriority'](new D(_0x715c85))),_0x396c71['forEachChild'](R,(_0x8d8405,_0x4a2056)=>{const _0x5843fa=us(_0x4a2056,_0x370aff['getImmediateChild'](_0x8d8405),_0x306dee);_0x5843fa!==_0x4a2056&&(_0x352cc6=_0x352cc6['updateImmediateChild'](_0x8d8405,_0x5843fa));}),_0x352cc6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x2b6815='',_0x2d7f05=null,_0xae37={'children':{},'childCount':0x0}){this['name']=_0x2b6815,this['parent']=_0x2d7f05,this['node']=_0xae37;}}function Un(_0x439d27,_0x5dcc1c){let _0xd0e705=_0x5dcc1c instanceof C?_0x5dcc1c:new C(_0x5dcc1c),_0xe2a1e5=_0x439d27,_0x587a67=y(_0xd0e705);for(;_0x587a67!==null;){const _0x408419=Oe(_0xe2a1e5['node']['children'],_0x587a67)||{'children':{},'childCount':0x0};_0xe2a1e5=new ds(_0x587a67,_0xe2a1e5,_0x408419),_0xd0e705=b(_0xd0e705),_0x587a67=y(_0xd0e705);}return _0xe2a1e5;}function Ge(_0x265f54){return _0x265f54['node']['value'];}function fs(_0x5e77e0,_0x482315){_0x5e77e0['node']['value']=_0x482315,Ri(_0x5e77e0);}function ea(_0x1aa18b){return _0x1aa18b['node']['childCount']>0x0;}function id(_0x5de0f0){return Ge(_0x5de0f0)===void 0x0&&!ea(_0x5de0f0);}function Wn(_0x62b5ff,_0x39f857){x(_0x62b5ff['node']['children'],(_0x2cb882,_0x244764)=>{_0x39f857(new ds(_0x2cb882,_0x62b5ff,_0x244764));});}function ta(_0x90bfe7,_0x23df43,_0x642f0a,_0x45992d){_0x642f0a&&_0x23df43(_0x90bfe7),Wn(_0x90bfe7,_0x1a31d9=>{ta(_0x1a31d9,_0x23df43,!0x0);});}function sd(_0x3bcb2e,_0x271d0a,_0x102165){let _0x5ec2bf=_0x3bcb2e['parent'];for(;_0x5ec2bf!==null;){if(_0x271d0a(_0x5ec2bf))return!0x0;_0x5ec2bf=_0x5ec2bf['parent'];}return!0x1;}function Gt(_0x2290d2){return new C(_0x2290d2['parent']===null?_0x2290d2['name']:Gt(_0x2290d2['parent'])+'/'+_0x2290d2['name']);}function Ri(_0xeffced){_0xeffced['parent']!==null&&rd(_0xeffced['parent'],_0xeffced['name'],_0xeffced);}function rd(_0x55aef2,_0x396398,_0x4ac960){const _0x574ab3=id(_0x4ac960),_0x552a8f=Y(_0x55aef2['node']['children'],_0x396398);_0x574ab3&&_0x552a8f?(delete _0x55aef2['node']['children'][_0x396398],_0x55aef2['node']['childCount']--,Ri(_0x55aef2)):!_0x574ab3&&!_0x552a8f&&(_0x55aef2['node']['children'][_0x396398]=_0x4ac960['node'],_0x55aef2['node']['childCount']++,Ri(_0x55aef2));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x10bd84){return typeof _0x10bd84=='string'&&_0x10bd84['length']!==0x0&&!od['test'](_0x10bd84);},na=function(_0x5d6693){return typeof _0x5d6693=='string'&&_0x5d6693['length']!==0x0&&!ad['test'](_0x5d6693);},cd=function(_0x45858c){return _0x45858c&&(_0x45858c=_0x45858c['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x45858c);},Cn=function(_0x4cf04d){return _0x4cf04d===null||typeof _0x4cf04d=='string'||typeof _0x4cf04d=='number'&&!Wi(_0x4cf04d)||_0x4cf04d&&typeof _0x4cf04d=='object'&&Y(_0x4cf04d,'.sv');},qt=function(_0x5b9060,_0x2ece90,_0x2b0665,_0x16c8ad){_0x16c8ad&&_0x2ece90===void 0x0||zt(Nn(_0x5b9060,'value'),_0x2ece90,_0x2b0665);},zt=function(_0x2c8b80,_0x300857,_0x3e758d){const _0x178786=_0x3e758d instanceof C?new Sh(_0x3e758d,_0x2c8b80):_0x3e758d;if(_0x300857===void 0x0)throw new Error(_0x2c8b80+'contains\x20undefined\x20'+Ne(_0x178786));if(typeof _0x300857=='function')throw new Error(_0x2c8b80+'contains\x20a\x20function\x20'+Ne(_0x178786)+'\x20with\x20contents\x20=\x20'+_0x300857['toString']());if(Wi(_0x300857))throw new Error(_0x2c8b80+'contains\x20'+_0x300857['toString']()+'\x20'+Ne(_0x178786));if(typeof _0x300857=='string'&&_0x300857['length']>oi/0x3&&Pn(_0x300857)>oi)throw new Error(_0x2c8b80+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x178786)+'\x20(\x27'+_0x300857['substring'](0x0,0x32)+'...\x27)');if(_0x300857&&typeof _0x300857=='object'){let _0x4063a7=!0x1,_0x4cce56=!0x1;if(x(_0x300857,(_0x507b33,_0x388ec5)=>{if(_0x507b33==='.value')_0x4063a7=!0x0;else{if(_0x507b33!=='.priority'&&_0x507b33!=='.sv'&&(_0x4cce56=!0x0,!ps(_0x507b33)))throw new Error(_0x2c8b80+'\x20contains\x20an\x20invalid\x20key\x20('+_0x507b33+')\x20'+Ne(_0x178786)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x178786,_0x507b33),zt(_0x2c8b80,_0x388ec5,_0x178786),Rh(_0x178786);}),_0x4063a7&&_0x4cce56)throw new Error(_0x2c8b80+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x178786)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x44e669,_0x59749b){let _0x5ede0a,_0x2cb63a;for(_0x5ede0a=0x0;_0x5ede0a<_0x59749b['length'];_0x5ede0a++){_0x2cb63a=_0x59749b[_0x5ede0a];const _0x13b40b=kt(_0x2cb63a);for(let _0x2f750a=0x0;_0x2f750a<_0x13b40b['length'];_0x2f750a++)if(!(_0x13b40b[_0x2f750a]==='.priority'&&_0x2f750a===_0x13b40b['length']-0x1)){if(!ps(_0x13b40b[_0x2f750a]))throw new Error(_0x44e669+'contains\x20an\x20invalid\x20key\x20('+_0x13b40b[_0x2f750a]+')\x20in\x20path\x20'+_0x2cb63a['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x59749b['sort'](Th);let _0x6066c8=null;for(_0x5ede0a=0x0;_0x5ede0a<_0x59749b['length'];_0x5ede0a++){if(_0x2cb63a=_0x59749b[_0x5ede0a],_0x6066c8!==null&&$(_0x6066c8,_0x2cb63a))throw new Error(_0x44e669+'contains\x20a\x20path\x20'+_0x6066c8['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2cb63a['toString']());_0x6066c8=_0x2cb63a;}},hd=function(_0x2acd82,_0x5e6c80,_0x17bf7e,_0x487a9d){const _0x445215=Nn(_0x2acd82,'values');if(!(_0x5e6c80&&typeof _0x5e6c80=='object')||Array['isArray'](_0x5e6c80))throw new Error(_0x445215+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x399317=[];x(_0x5e6c80,(_0x148760,_0xdbe9ca)=>{const _0x5c32a8=new C(_0x148760);if(zt(_0x445215,_0xdbe9ca,A(_0x17bf7e,_0x5c32a8)),Gi(_0x5c32a8)==='.priority'&&!Cn(_0xdbe9ca))throw new Error(_0x445215+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5c32a8['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x399317['push'](_0x5c32a8);}),ld(_0x445215,_0x399317);},_s=function(_0x3da9d3,_0x5c0f77,_0x1142b5,_0x5d83a1){if(!na(_0x1142b5))throw new Error(Nn(_0x3da9d3,_0x5c0f77)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1142b5+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x3cc051,_0x200c0f,_0x3eea4e,_0x57aec8){_0x3eea4e&&(_0x3eea4e=_0x3eea4e['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x3cc051,_0x200c0f,_0x3eea4e);},gs=function(_0x2671af,_0x4d80bb){if(y(_0x4d80bb)==='.info')throw new Error(_0x2671af+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x444f4d,_0x53debb){const _0x746e3e=_0x53debb['path']['toString']();if(typeof _0x53debb['repoInfo']['host']!='string'||_0x53debb['repoInfo']['host']['length']===0x0||!ps(_0x53debb['repoInfo']['namespace'])&&_0x53debb['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x746e3e['length']!==0x0&&!cd(_0x746e3e))throw new Error(Nn(_0x444f4d,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5b3683,_0x658c58){let _0x5b8699=null;for(let _0x16d71b=0x0;_0x16d71b<_0x658c58['length'];_0x16d71b++){const _0x318eb0=_0x658c58[_0x16d71b],_0x62d3fa=_0x318eb0['getPath']();_0x5b8699!==null&&!qi(_0x62d3fa,_0x5b8699['path'])&&(_0x5b3683['eventLists_']['push'](_0x5b8699),_0x5b8699=null),_0x5b8699===null&&(_0x5b8699={'events':[],'path':_0x62d3fa}),_0x5b8699['events']['push'](_0x318eb0);}_0x5b8699&&_0x5b3683['eventLists_']['push'](_0x5b8699);}function ia(_0x2cb18b,_0x39a241,_0x16ef43){Bn(_0x2cb18b,_0x16ef43),sa(_0x2cb18b,_0x4a248b=>qi(_0x4a248b,_0x39a241));}function V(_0x563888,_0x1b696a,_0x13f2a0){Bn(_0x563888,_0x13f2a0),sa(_0x563888,_0x49b202=>$(_0x49b202,_0x1b696a)||$(_0x1b696a,_0x49b202));}function sa(_0x6a7bd5,_0x5c8570){_0x6a7bd5['recursionDepth_']++;let _0x1ae4ea=!0x0;for(let _0x7982ed=0x0;_0x7982ed<_0x6a7bd5['eventLists_']['length'];_0x7982ed++){const _0x130ca1=_0x6a7bd5['eventLists_'][_0x7982ed];if(_0x130ca1){const _0x1ccdad=_0x130ca1['path'];_0x5c8570(_0x1ccdad)?(pd(_0x6a7bd5['eventLists_'][_0x7982ed]),_0x6a7bd5['eventLists_'][_0x7982ed]=null):_0x1ae4ea=!0x1;}}_0x1ae4ea&&(_0x6a7bd5['eventLists_']=[]),_0x6a7bd5['recursionDepth_']--;}function pd(_0x33c123){for(let _0x39064e=0x0;_0x39064e<_0x33c123['events']['length'];_0x39064e++){const _0x5a26ae=_0x33c123['events'][_0x39064e];if(_0x5a26ae!==null){_0x33c123['events'][_0x39064e]=null;const _0x3f7242=_0x5a26ae['getEventRunner']();Et&&L('event:\x20'+_0x5a26ae['toString']()),lt(_0x3f7242);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x16e5b6,_0x5ec155,_0x2711f2,_0x9c4c09){this['repoInfo_']=_0x16e5b6,this['forceRestClient_']=_0x5ec155,this['authTokenProvider_']=_0x2711f2,this['appCheckProvider_']=_0x9c4c09,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x340f3e,_0x3ee9cb,_0x28322d){if(_0x340f3e['stats_']=Hi(_0x340f3e['repoInfo_']),_0x340f3e['forceRestClient_']||Yl())_0x340f3e['server_']=new fn(_0x340f3e['repoInfo_'],(_0x494ce5,_0x3e13a6,_0x310538,_0x549276)=>{pr(_0x340f3e,_0x494ce5,_0x3e13a6,_0x310538,_0x549276);},_0x340f3e['authTokenProvider_'],_0x340f3e['appCheckProvider_']),setTimeout(()=>_r(_0x340f3e,!0x0),0x0);else{if(typeof _0x28322d<'u'&&_0x28322d!==null){if(typeof _0x28322d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x28322d);}catch(_0x2a6136){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2a6136);}}_0x340f3e['persistentConnection_']=new ie(_0x340f3e['repoInfo_'],_0x3ee9cb,(_0xa51bc,_0xbdf01c,_0x2d6186,_0x57bcf7)=>{pr(_0x340f3e,_0xa51bc,_0xbdf01c,_0x2d6186,_0x57bcf7);},_0x3e6b11=>{_r(_0x340f3e,_0x3e6b11);},_0x3ddffe=>{yd(_0x340f3e,_0x3ddffe);},_0x340f3e['authTokenProvider_'],_0x340f3e['appCheckProvider_'],_0x28322d),_0x340f3e['server_']=_0x340f3e['persistentConnection_'];}_0x340f3e['authTokenProvider_']['addTokenChangeListener'](_0x34dd1b=>{_0x340f3e['server_']['refreshAuthToken'](_0x34dd1b);}),_0x340f3e['appCheckProvider_']['addTokenChangeListener'](_0x259897=>{_0x340f3e['server_']['refreshAppCheckToken'](_0x259897['token']);}),_0x340f3e['statsReporter_']=eh(_0x340f3e['repoInfo_'],()=>new eu(_0x340f3e['stats_'],_0x340f3e['server_'])),_0x340f3e['infoData_']=new Yh(),_0x340f3e['infoSyncTree_']=new dr({'startListening':(_0x651928,_0x4b4694,_0x33c0cd,_0x5279f4)=>{let _0xdcc6aa=[];const _0x3672e2=_0x340f3e['infoData_']['getNode'](_0x651928['_path']);return _0x3672e2['isEmpty']()||(_0xdcc6aa=$t(_0x340f3e['infoSyncTree_'],_0x651928['_path'],_0x3672e2),setTimeout(()=>{_0x5279f4('ok');},0x0)),_0xdcc6aa;},'stopListening':()=>{}}),ms(_0x340f3e,'connected',!0x1),_0x340f3e['serverSyncTree_']=new dr({'startListening':(_0x15cf5b,_0xf65b6,_0x3fb4fb,_0x5bbf2f)=>(_0x340f3e['server_']['listen'](_0x15cf5b,_0x3fb4fb,_0xf65b6,(_0x5602b6,_0x4681dc)=>{const _0x146801=_0x5bbf2f(_0x5602b6,_0x4681dc);V(_0x340f3e['eventQueue_'],_0x15cf5b['_path'],_0x146801);}),[]),'stopListening':(_0x82513f,_0x947106)=>{_0x340f3e['server_']['unlisten'](_0x82513f,_0x947106);}});}function oa(_0x5a3841){const _0x324c58=_0x5a3841['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x324c58;}function jt(_0x148aba){return ed({'timestamp':oa(_0x148aba)});}function pr(_0x4cc2b7,_0x5e7d7f,_0xbabdfb,_0x3de83e,_0x23a1b4){_0x4cc2b7['dataUpdateCount']++;const _0x5e679b=new C(_0x5e7d7f);_0xbabdfb=_0x4cc2b7['interceptServerDataCallback_']?_0x4cc2b7['interceptServerDataCallback_'](_0x5e7d7f,_0xbabdfb):_0xbabdfb;let _0x4c8ff5=[];if(_0x23a1b4){if(_0x3de83e){const _0x5b3a24=ln(_0xbabdfb,_0x26183a=>N(_0x26183a));_0x4c8ff5=Ku(_0x4cc2b7['serverSyncTree_'],_0x5e679b,_0x5b3a24,_0x23a1b4);}else{const _0x3a4a67=N(_0xbabdfb);_0x4c8ff5=Yo(_0x4cc2b7['serverSyncTree_'],_0x5e679b,_0x3a4a67,_0x23a1b4);}}else{if(_0x3de83e){const _0x12c3a8=ln(_0xbabdfb,_0x238cc0=>N(_0x238cc0));_0x4c8ff5=qu(_0x4cc2b7['serverSyncTree_'],_0x5e679b,_0x12c3a8);}else{const _0x3f5b37=N(_0xbabdfb);_0x4c8ff5=$t(_0x4cc2b7['serverSyncTree_'],_0x5e679b,_0x3f5b37);}}let _0x35d2fb=_0x5e679b;_0x4c8ff5['length']>0x0&&(_0x35d2fb=st(_0x4cc2b7,_0x5e679b)),V(_0x4cc2b7['eventQueue_'],_0x35d2fb,_0x4c8ff5);}function _r(_0x14bb30,_0x166bf3){ms(_0x14bb30,'connected',_0x166bf3),_0x166bf3===!0x1&&wd(_0x14bb30);}function yd(_0x50c2d5,_0x4d8b1f){x(_0x4d8b1f,(_0x5f149f,_0x215153)=>{ms(_0x50c2d5,_0x5f149f,_0x215153);});}function ms(_0x44adca,_0x39fb86,_0x2c2784){const _0x4eed96=new C('/.info/'+_0x39fb86),_0x348da5=N(_0x2c2784);_0x44adca['infoData_']['updateSnapshot'](_0x4eed96,_0x348da5);const _0x5614cd=$t(_0x44adca['infoSyncTree_'],_0x4eed96,_0x348da5);V(_0x44adca['eventQueue_'],_0x4eed96,_0x5614cd);}function Vn(_0x4485e0){return _0x4485e0['nextWriteId_']++;}function vd(_0x5f3cec,_0x5335e6,_0x1b14f9){const _0x1ccd10=Yu(_0x5f3cec['serverSyncTree_'],_0x5335e6);return _0x1ccd10!=null?Promise['resolve'](_0x1ccd10):_0x5f3cec['server_']['get'](_0x5335e6)['then'](_0x42b808=>{const _0x277061=N(_0x42b808)['withIndex'](_0x5335e6['_queryParams']['getIndex']());bi(_0x5f3cec['serverSyncTree_'],_0x5335e6,_0x1b14f9,!0x0);let _0x3d081c;if(_0x5335e6['_queryParams']['loadsAllData']())_0x3d081c=$t(_0x5f3cec['serverSyncTree_'],_0x5335e6['_path'],_0x277061);else{const _0x4b1373=Mt(_0x5f3cec['serverSyncTree_'],_0x5335e6);_0x3d081c=Yo(_0x5f3cec['serverSyncTree_'],_0x5335e6['_path'],_0x277061,_0x4b1373);}return V(_0x5f3cec['eventQueue_'],_0x5335e6['_path'],_0x3d081c),wn(_0x5f3cec['serverSyncTree_'],_0x5335e6,_0x1b14f9,null,!0x0),_0x277061;},_0x571732=>(ut(_0x5f3cec,'get\x20for\x20query\x20'+O(_0x5335e6)+'\x20failed:\x20'+_0x571732),Promise['reject'](new Error(_0x571732))));}function Ed(_0xa9e89f,_0x59c7b6,_0x5bcf38,_0x40fbe0,_0xd17586){ut(_0xa9e89f,'set',{'path':_0x59c7b6['toString'](),'value':_0x5bcf38,'priority':_0x40fbe0});const _0x30f3e1=jt(_0xa9e89f),_0x5e42a3=N(_0x5bcf38,_0x40fbe0),_0x3962ba=xn(_0xa9e89f['serverSyncTree_'],_0x59c7b6),_0x12ca02=hs(_0x5e42a3,_0x3962ba,_0x30f3e1),_0x58ec36=Vn(_0xa9e89f),_0x5bea10=ss(_0xa9e89f['serverSyncTree_'],_0x59c7b6,_0x12ca02,_0x58ec36,!0x0);Bn(_0xa9e89f['eventQueue_'],_0x5bea10),_0xa9e89f['server_']['put'](_0x59c7b6['toString'](),_0x5e42a3['val'](!0x0),(_0x3153d5,_0x4144c9)=>{const _0x7cec22=_0x3153d5==='ok';_0x7cec22||U('set\x20at\x20'+_0x59c7b6+'\x20failed:\x20'+_0x3153d5);const _0x46f259=pe(_0xa9e89f['serverSyncTree_'],_0x58ec36,!_0x7cec22);V(_0xa9e89f['eventQueue_'],_0x59c7b6,_0x46f259),Ai(_0xa9e89f,_0xd17586,_0x3153d5,_0x4144c9);});const _0x1ca3c0=vs(_0xa9e89f,_0x59c7b6);st(_0xa9e89f,_0x1ca3c0),V(_0xa9e89f['eventQueue_'],_0x1ca3c0,[]);}function Id(_0xc823e1,_0x35144f,_0x9649b7,_0x2e7095){ut(_0xc823e1,'update',{'path':_0x35144f['toString'](),'value':_0x9649b7});let _0x176a69=!0x0;const _0x28d5ad=jt(_0xc823e1),_0x533eb0={};if(x(_0x9649b7,(_0x132e4c,_0x2cb35a)=>{_0x176a69=!0x1,_0x533eb0[_0x132e4c]=Zo(A(_0x35144f,_0x132e4c),N(_0x2cb35a),_0xc823e1['serverSyncTree_'],_0x28d5ad);}),_0x176a69)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0xc823e1,_0x2e7095,'ok',void 0x0);else{const _0x1bf528=Vn(_0xc823e1),_0x38f06d=Gu(_0xc823e1['serverSyncTree_'],_0x35144f,_0x533eb0,_0x1bf528);Bn(_0xc823e1['eventQueue_'],_0x38f06d),_0xc823e1['server_']['merge'](_0x35144f['toString'](),_0x9649b7,(_0x5a5f44,_0x4fa331)=>{const _0x29871a=_0x5a5f44==='ok';_0x29871a||U('update\x20at\x20'+_0x35144f+'\x20failed:\x20'+_0x5a5f44);const _0x37c523=pe(_0xc823e1['serverSyncTree_'],_0x1bf528,!_0x29871a),_0x59554b=_0x37c523['length']>0x0?st(_0xc823e1,_0x35144f):_0x35144f;V(_0xc823e1['eventQueue_'],_0x59554b,_0x37c523),Ai(_0xc823e1,_0x2e7095,_0x5a5f44,_0x4fa331);}),x(_0x9649b7,_0x146fae=>{const _0x5cc5b1=vs(_0xc823e1,A(_0x35144f,_0x146fae));st(_0xc823e1,_0x5cc5b1);}),V(_0xc823e1['eventQueue_'],_0x35144f,[]);}}function wd(_0xc15317){ut(_0xc15317,'onDisconnectEvents');const _0xd283b1=jt(_0xc15317),_0x1e1b3e=pn();Ei(_0xc15317['onDisconnect_'],w(),(_0x8ce4c8,_0x16bc01)=>{const _0x568313=Zo(_0x8ce4c8,_0x16bc01,_0xc15317['serverSyncTree_'],_0xd283b1);Mo(_0x1e1b3e,_0x8ce4c8,_0x568313);});let _0x5159b4=[];Ei(_0x1e1b3e,w(),(_0xd3ae98,_0xd98d93)=>{_0x5159b4=_0x5159b4['concat']($t(_0xc15317['serverSyncTree_'],_0xd3ae98,_0xd98d93));const _0x4d3c2d=vs(_0xc15317,_0xd3ae98);st(_0xc15317,_0x4d3c2d);}),_0xc15317['onDisconnect_']=pn(),V(_0xc15317['eventQueue_'],w(),_0x5159b4);}function Cd(_0x57a757,_0x3f2a91,_0x1f861e){let _0x5161b9;y(_0x3f2a91['_path'])==='.info'?_0x5161b9=bi(_0x57a757['infoSyncTree_'],_0x3f2a91,_0x1f861e):_0x5161b9=bi(_0x57a757['serverSyncTree_'],_0x3f2a91,_0x1f861e),ia(_0x57a757['eventQueue_'],_0x3f2a91['_path'],_0x5161b9);}function Td(_0x12eb5b,_0x259b43,_0x5973fa){let _0x3429fe;y(_0x259b43['_path'])==='.info'?_0x3429fe=wn(_0x12eb5b['infoSyncTree_'],_0x259b43,_0x5973fa):_0x3429fe=wn(_0x12eb5b['serverSyncTree_'],_0x259b43,_0x5973fa),ia(_0x12eb5b['eventQueue_'],_0x259b43['_path'],_0x3429fe);}function aa(_0x49b810){_0x49b810['persistentConnection_']&&_0x49b810['persistentConnection_']['interrupt'](ra);}function Sd(_0xe13eb5){_0xe13eb5['persistentConnection_']&&_0xe13eb5['persistentConnection_']['resume'](ra);}function ut(_0xc28d62,..._0x17f9fe){let _0x481bae='';_0xc28d62['persistentConnection_']&&(_0x481bae=_0xc28d62['persistentConnection_']['id']+':'),L(_0x481bae,..._0x17f9fe);}function Ai(_0x4f3479,_0x3dafe2,_0x343775,_0x3ad750){_0x3dafe2&&lt(()=>{if(_0x343775==='ok')_0x3dafe2(null);else{const _0x54e5dc=(_0x343775||'error')['toUpperCase']();let _0x4ca523=_0x54e5dc;_0x3ad750&&(_0x4ca523+=':\x20'+_0x3ad750);const _0x314a37=new Error(_0x4ca523);_0x314a37['code']=_0x54e5dc,_0x3dafe2(_0x314a37);}});}function bd(_0xc5e77d,_0x3d7fd8,_0x2963b7,_0x2759bb,_0x26e709,_0x3499e7){ut(_0xc5e77d,'transaction\x20on\x20'+_0x3d7fd8);const _0x4380a2={'path':_0x3d7fd8,'update':_0x2963b7,'onComplete':_0x2759bb,'status':null,'order':to(),'applyLocally':_0x3499e7,'retryCount':0x0,'unwatcher':_0x26e709,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2eedbb=ys(_0xc5e77d,_0x3d7fd8,void 0x0);_0x4380a2['currentInputSnapshot']=_0x2eedbb;const _0x3471d4=_0x4380a2['update'](_0x2eedbb['val']());if(_0x3471d4===void 0x0)_0x4380a2['unwatcher'](),_0x4380a2['currentOutputSnapshotRaw']=null,_0x4380a2['currentOutputSnapshotResolved']=null,_0x4380a2['onComplete']&&_0x4380a2['onComplete'](null,!0x1,_0x4380a2['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x3471d4,_0x4380a2['path']),_0x4380a2['status']=0x0;const _0x20da85=Un(_0xc5e77d['transactionQueueTree_'],_0x3d7fd8),_0x406f99=Ge(_0x20da85)||[];_0x406f99['push'](_0x4380a2),fs(_0x20da85,_0x406f99);let _0x234f72;typeof _0x3471d4=='object'&&_0x3471d4!==null&&Y(_0x3471d4,'.priority')?(_0x234f72=Oe(_0x3471d4,'.priority'),f(Cn(_0x234f72),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x234f72=(xn(_0xc5e77d['serverSyncTree_'],_0x3d7fd8)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5ac965=jt(_0xc5e77d),_0x364ef3=N(_0x3471d4,_0x234f72),_0x27a1dd=hs(_0x364ef3,_0x2eedbb,_0x5ac965);_0x4380a2['currentOutputSnapshotRaw']=_0x364ef3,_0x4380a2['currentOutputSnapshotResolved']=_0x27a1dd,_0x4380a2['currentWriteId']=Vn(_0xc5e77d);const _0x18919c=ss(_0xc5e77d['serverSyncTree_'],_0x3d7fd8,_0x27a1dd,_0x4380a2['currentWriteId'],_0x4380a2['applyLocally']);V(_0xc5e77d['eventQueue_'],_0x3d7fd8,_0x18919c),Hn(_0xc5e77d,_0xc5e77d['transactionQueueTree_']);}}function ys(_0x5dcfb1,_0x1214f4,_0x3a0a62){return xn(_0x5dcfb1['serverSyncTree_'],_0x1214f4,_0x3a0a62)||g['EMPTY_NODE'];}function Hn(_0x4b8291,_0x2fe413=_0x4b8291['transactionQueueTree_']){if(_0x2fe413||$n(_0x4b8291,_0x2fe413),Ge(_0x2fe413)){const _0x4f5335=la(_0x4b8291,_0x2fe413);f(_0x4f5335['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4f5335['every'](_0x2db673=>_0x2db673['status']===0x0)&&Rd(_0x4b8291,Gt(_0x2fe413),_0x4f5335);}else ea(_0x2fe413)&&Wn(_0x2fe413,_0x57cb1f=>{Hn(_0x4b8291,_0x57cb1f);});}function Rd(_0x4161c6,_0x2cebaa,_0x200446){const _0x21aaea=_0x200446['map'](_0x4d21c0=>_0x4d21c0['currentWriteId']),_0x1db2f9=ys(_0x4161c6,_0x2cebaa,_0x21aaea);let _0x21d923=_0x1db2f9;const _0x2d92c4=_0x1db2f9['hash']();for(let _0x1a6ffe=0x0;_0x1a6ffe<_0x200446['length'];_0x1a6ffe++){const _0x3f29e2=_0x200446[_0x1a6ffe];f(_0x3f29e2['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3f29e2['status']=0x1,_0x3f29e2['retryCount']++;const _0x5bc6a2=F(_0x2cebaa,_0x3f29e2['path']);_0x21d923=_0x21d923['updateChild'](_0x5bc6a2,_0x3f29e2['currentOutputSnapshotRaw']);}const _0xf3161=_0x21d923['val'](!0x0),_0x37cf40=_0x2cebaa;_0x4161c6['server_']['put'](_0x37cf40['toString'](),_0xf3161,_0x5cf893=>{ut(_0x4161c6,'transaction\x20put\x20response',{'path':_0x37cf40['toString'](),'status':_0x5cf893});let _0x48b5b2=[];if(_0x5cf893==='ok'){const _0x32dbd3=[];for(let _0x5cf362=0x0;_0x5cf362<_0x200446['length'];_0x5cf362++)_0x200446[_0x5cf362]['status']=0x2,_0x48b5b2=_0x48b5b2['concat'](pe(_0x4161c6['serverSyncTree_'],_0x200446[_0x5cf362]['currentWriteId'])),_0x200446[_0x5cf362]['onComplete']&&_0x32dbd3['push'](()=>_0x200446[_0x5cf362]['onComplete'](null,!0x0,_0x200446[_0x5cf362]['currentOutputSnapshotResolved'])),_0x200446[_0x5cf362]['unwatcher']();$n(_0x4161c6,Un(_0x4161c6['transactionQueueTree_'],_0x2cebaa)),Hn(_0x4161c6,_0x4161c6['transactionQueueTree_']),V(_0x4161c6['eventQueue_'],_0x2cebaa,_0x48b5b2);for(let _0x29461a=0x0;_0x29461a<_0x32dbd3['length'];_0x29461a++)lt(_0x32dbd3[_0x29461a]);}else{if(_0x5cf893==='datastale'){for(let _0x3e1c38=0x0;_0x3e1c38<_0x200446['length'];_0x3e1c38++)_0x200446[_0x3e1c38]['status']===0x3?_0x200446[_0x3e1c38]['status']=0x4:_0x200446[_0x3e1c38]['status']=0x0;}else{U('transaction\x20at\x20'+_0x37cf40['toString']()+'\x20failed:\x20'+_0x5cf893);for(let _0x2a0932=0x0;_0x2a0932<_0x200446['length'];_0x2a0932++)_0x200446[_0x2a0932]['status']=0x4,_0x200446[_0x2a0932]['abortReason']=_0x5cf893;}st(_0x4161c6,_0x2cebaa);}},_0x2d92c4);}function st(_0x5e52f8,_0x1a7686){const _0x4404b8=ca(_0x5e52f8,_0x1a7686),_0x226a8d=Gt(_0x4404b8),_0x5351ec=la(_0x5e52f8,_0x4404b8);return Ad(_0x5e52f8,_0x5351ec,_0x226a8d),_0x226a8d;}function Ad(_0x2366a6,_0x49142,_0x538beb){if(_0x49142['length']===0x0)return;const _0x53d21f=[];let _0x3e2f0e=[];const _0xb0c6ae=_0x49142['filter'](_0x703ecb=>_0x703ecb['status']===0x0)['map'](_0x3e114f=>_0x3e114f['currentWriteId']);for(let _0x47aa5c=0x0;_0x47aa5c<_0x49142['length'];_0x47aa5c++){const _0x5d5bf9=_0x49142[_0x47aa5c],_0x5218e3=F(_0x538beb,_0x5d5bf9['path']);let _0x57cc13=!0x1,_0xf7efde;if(f(_0x5218e3!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5d5bf9['status']===0x4)_0x57cc13=!0x0,_0xf7efde=_0x5d5bf9['abortReason'],_0x3e2f0e=_0x3e2f0e['concat'](pe(_0x2366a6['serverSyncTree_'],_0x5d5bf9['currentWriteId'],!0x0));else{if(_0x5d5bf9['status']===0x0){if(_0x5d5bf9['retryCount']>=_d)_0x57cc13=!0x0,_0xf7efde='maxretry',_0x3e2f0e=_0x3e2f0e['concat'](pe(_0x2366a6['serverSyncTree_'],_0x5d5bf9['currentWriteId'],!0x0));else{const _0x110a21=ys(_0x2366a6,_0x5d5bf9['path'],_0xb0c6ae);_0x5d5bf9['currentInputSnapshot']=_0x110a21;const _0x40aab5=_0x49142[_0x47aa5c]['update'](_0x110a21['val']());if(_0x40aab5!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x40aab5,_0x5d5bf9['path']);let _0x5ab3f7=N(_0x40aab5);typeof _0x40aab5=='object'&&_0x40aab5!=null&&Y(_0x40aab5,'.priority')||(_0x5ab3f7=_0x5ab3f7['updatePriority'](_0x110a21['getPriority']()));const _0x188342=_0x5d5bf9['currentWriteId'],_0x489ae5=jt(_0x2366a6),_0x297615=hs(_0x5ab3f7,_0x110a21,_0x489ae5);_0x5d5bf9['currentOutputSnapshotRaw']=_0x5ab3f7,_0x5d5bf9['currentOutputSnapshotResolved']=_0x297615,_0x5d5bf9['currentWriteId']=Vn(_0x2366a6),_0xb0c6ae['splice'](_0xb0c6ae['indexOf'](_0x188342),0x1),_0x3e2f0e=_0x3e2f0e['concat'](ss(_0x2366a6['serverSyncTree_'],_0x5d5bf9['path'],_0x297615,_0x5d5bf9['currentWriteId'],_0x5d5bf9['applyLocally'])),_0x3e2f0e=_0x3e2f0e['concat'](pe(_0x2366a6['serverSyncTree_'],_0x188342,!0x0));}else _0x57cc13=!0x0,_0xf7efde='nodata',_0x3e2f0e=_0x3e2f0e['concat'](pe(_0x2366a6['serverSyncTree_'],_0x5d5bf9['currentWriteId'],!0x0));}}}V(_0x2366a6['eventQueue_'],_0x538beb,_0x3e2f0e),_0x3e2f0e=[],_0x57cc13&&(_0x49142[_0x47aa5c]['status']=0x2,function(_0x5f0331){setTimeout(_0x5f0331,Math['floor'](0x0));}(_0x49142[_0x47aa5c]['unwatcher']),_0x49142[_0x47aa5c]['onComplete']&&(_0xf7efde==='nodata'?_0x53d21f['push'](()=>_0x49142[_0x47aa5c]['onComplete'](null,!0x1,_0x49142[_0x47aa5c]['currentInputSnapshot'])):_0x53d21f['push'](()=>_0x49142[_0x47aa5c]['onComplete'](new Error(_0xf7efde),!0x1,null))));}$n(_0x2366a6,_0x2366a6['transactionQueueTree_']);for(let _0x235157=0x0;_0x235157<_0x53d21f['length'];_0x235157++)lt(_0x53d21f[_0x235157]);Hn(_0x2366a6,_0x2366a6['transactionQueueTree_']);}function ca(_0x244840,_0xe16bb2){let _0x1d307d,_0x27ff63=_0x244840['transactionQueueTree_'];for(_0x1d307d=y(_0xe16bb2);_0x1d307d!==null&&Ge(_0x27ff63)===void 0x0;)_0x27ff63=Un(_0x27ff63,_0x1d307d),_0xe16bb2=b(_0xe16bb2),_0x1d307d=y(_0xe16bb2);return _0x27ff63;}function la(_0x31f836,_0x9b9227){const _0x4b5265=[];return ha(_0x31f836,_0x9b9227,_0x4b5265),_0x4b5265['sort']((_0xf3f6a,_0xba0940)=>_0xf3f6a['order']-_0xba0940['order']),_0x4b5265;}function ha(_0x72068c,_0x260f6e,_0x5987ab){const _0x38b2b1=Ge(_0x260f6e);if(_0x38b2b1){for(let _0x16d7dc=0x0;_0x16d7dc<_0x38b2b1['length'];_0x16d7dc++)_0x5987ab['push'](_0x38b2b1[_0x16d7dc]);}Wn(_0x260f6e,_0x543618=>{ha(_0x72068c,_0x543618,_0x5987ab);});}function $n(_0x4e4e9c,_0x116489){const _0x2e29da=Ge(_0x116489);if(_0x2e29da){let _0xa365d5=0x0;for(let _0x4ed558=0x0;_0x4ed558<_0x2e29da['length'];_0x4ed558++)_0x2e29da[_0x4ed558]['status']!==0x2&&(_0x2e29da[_0xa365d5]=_0x2e29da[_0x4ed558],_0xa365d5++);_0x2e29da['length']=_0xa365d5,fs(_0x116489,_0x2e29da['length']>0x0?_0x2e29da:void 0x0);}Wn(_0x116489,_0x2377f0=>{$n(_0x4e4e9c,_0x2377f0);});}function vs(_0x5b184a,_0xd3d947){const _0x1d73ec=Gt(ca(_0x5b184a,_0xd3d947)),_0x5d6364=Un(_0x5b184a['transactionQueueTree_'],_0xd3d947);return sd(_0x5d6364,_0x65ee21=>{ai(_0x5b184a,_0x65ee21);}),ai(_0x5b184a,_0x5d6364),ta(_0x5d6364,_0x161182=>{ai(_0x5b184a,_0x161182);}),_0x1d73ec;}function ai(_0x51ad28,_0x1f8894){const _0x325045=Ge(_0x1f8894);if(_0x325045){const _0x253b40=[];let _0x275170=[],_0x1f8ba7=-0x1;for(let _0x486041=0x0;_0x486041<_0x325045['length'];_0x486041++)_0x325045[_0x486041]['status']===0x3||(_0x325045[_0x486041]['status']===0x1?(f(_0x1f8ba7===_0x486041-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1f8ba7=_0x486041,_0x325045[_0x486041]['status']=0x3,_0x325045[_0x486041]['abortReason']='set'):(f(_0x325045[_0x486041]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x325045[_0x486041]['unwatcher'](),_0x275170=_0x275170['concat'](pe(_0x51ad28['serverSyncTree_'],_0x325045[_0x486041]['currentWriteId'],!0x0)),_0x325045[_0x486041]['onComplete']&&_0x253b40['push'](_0x325045[_0x486041]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1f8ba7===-0x1?fs(_0x1f8894,void 0x0):_0x325045['length']=_0x1f8ba7+0x1,V(_0x51ad28['eventQueue_'],Gt(_0x1f8894),_0x275170);for(let _0x509eef=0x0;_0x509eef<_0x253b40['length'];_0x509eef++)lt(_0x253b40[_0x509eef]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x12f303){let _0x2390d6='';const _0x10dbf1=_0x12f303['split']('/');for(let _0x20badd=0x0;_0x20badd<_0x10dbf1['length'];_0x20badd++)if(_0x10dbf1[_0x20badd]['length']>0x0){let _0x593fbf=_0x10dbf1[_0x20badd];try{_0x593fbf=decodeURIComponent(_0x593fbf['replace'](/\+/g,'\x20'));}catch{}_0x2390d6+='/'+_0x593fbf;}return _0x2390d6;}function Nd(_0x9c818f){const _0x42947e={};_0x9c818f['charAt'](0x0)==='?'&&(_0x9c818f=_0x9c818f['substring'](0x1));for(const _0x116f5f of _0x9c818f['split']('&')){if(_0x116f5f['length']===0x0)continue;const _0x14ff5a=_0x116f5f['split']('=');_0x14ff5a['length']===0x2?_0x42947e[decodeURIComponent(_0x14ff5a[0x0])]=decodeURIComponent(_0x14ff5a[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x116f5f+'\x27\x20in\x20query\x20\x27'+_0x9c818f+'\x27');}return _0x42947e;}const gr=function(_0x2c0b64,_0x1b075c){const _0x29b244=Pd(_0x2c0b64),_0x345149=_0x29b244['namespace'];_0x29b244['domain']==='firebase.com'&&oe(_0x29b244['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x345149||_0x345149==='undefined')&&_0x29b244['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x29b244['secure']||Bl();const _0x220603=_0x29b244['scheme']==='ws'||_0x29b244['scheme']==='wss';return{'repoInfo':new _o(_0x29b244['host'],_0x29b244['secure'],_0x345149,_0x220603,_0x1b075c,'',_0x345149!==_0x29b244['subdomain']),'path':new C(_0x29b244['pathString'])};},Pd=function(_0x14f382){let _0x17fda2='',_0x3062b1='',_0x4f3942='',_0x2c23e3='',_0xe8632e='',_0x2a06fc=!0x0,_0xc3997b='https',_0x3c66e0=0x1bb;if(typeof _0x14f382=='string'){let _0x215cd0=_0x14f382['indexOf']('//');_0x215cd0>=0x0&&(_0xc3997b=_0x14f382['substring'](0x0,_0x215cd0-0x1),_0x14f382=_0x14f382['substring'](_0x215cd0+0x2));let _0x3b5720=_0x14f382['indexOf']('/');_0x3b5720===-0x1&&(_0x3b5720=_0x14f382['length']);let _0x20186b=_0x14f382['indexOf']('?');_0x20186b===-0x1&&(_0x20186b=_0x14f382['length']),_0x17fda2=_0x14f382['substring'](0x0,Math['min'](_0x3b5720,_0x20186b)),_0x3b5720<_0x20186b&&(_0x2c23e3=kd(_0x14f382['substring'](_0x3b5720,_0x20186b)));const _0x32ff2b=Nd(_0x14f382['substring'](Math['min'](_0x14f382['length'],_0x20186b)));_0x215cd0=_0x17fda2['indexOf'](':'),_0x215cd0>=0x0?(_0x2a06fc=_0xc3997b==='https'||_0xc3997b==='wss',_0x3c66e0=parseInt(_0x17fda2['substring'](_0x215cd0+0x1),0xa)):_0x215cd0=_0x17fda2['length'];const _0xd0836d=_0x17fda2['slice'](0x0,_0x215cd0);if(_0xd0836d['toLowerCase']()==='localhost')_0x3062b1='localhost';else{if(_0xd0836d['split']('.')['length']<=0x2)_0x3062b1=_0xd0836d;else{const _0x320cfd=_0x17fda2['indexOf']('.');_0x4f3942=_0x17fda2['substring'](0x0,_0x320cfd)['toLowerCase'](),_0x3062b1=_0x17fda2['substring'](_0x320cfd+0x1),_0xe8632e=_0x4f3942;}}'ns'in _0x32ff2b&&(_0xe8632e=_0x32ff2b['ns']);}return{'host':_0x17fda2,'port':_0x3c66e0,'domain':_0x3062b1,'subdomain':_0x4f3942,'secure':_0x2a06fc,'scheme':_0xc3997b,'pathString':_0x2c23e3,'namespace':_0xe8632e};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x530b24=0x0;const _0x330e14=[];return function(_0x4abc2f){const _0x57fdb1=_0x4abc2f===_0x530b24;_0x530b24=_0x4abc2f;let _0x2a613d;const _0x134e6c=new Array(0x8);for(_0x2a613d=0x7;_0x2a613d>=0x0;_0x2a613d--)_0x134e6c[_0x2a613d]=mr['charAt'](_0x4abc2f%0x40),_0x4abc2f=Math['floor'](_0x4abc2f/0x40);f(_0x4abc2f===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x470b8f=_0x134e6c['join']('');if(_0x57fdb1){for(_0x2a613d=0xb;_0x2a613d>=0x0&&_0x330e14[_0x2a613d]===0x3f;_0x2a613d--)_0x330e14[_0x2a613d]=0x0;_0x330e14[_0x2a613d]++;}else{for(_0x2a613d=0x0;_0x2a613d<0xc;_0x2a613d++)_0x330e14[_0x2a613d]=Math['floor'](Math['random']()*0x40);}for(_0x2a613d=0x0;_0x2a613d<0xc;_0x2a613d++)_0x470b8f+=mr['charAt'](_0x330e14[_0x2a613d]);return f(_0x470b8f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x470b8f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x2c47f9,_0x4b7dda,_0x2b0dd7,_0x148231){this['eventType']=_0x2c47f9,this['eventRegistration']=_0x4b7dda,this['snapshot']=_0x2b0dd7,this['prevName']=_0x148231;}['getPath'](){const _0x32984b=this['snapshot']['ref'];return this['eventType']==='value'?_0x32984b['_path']:_0x32984b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x323fdd,_0x1e839c,_0xdb2a1a){this['eventRegistration']=_0x323fdd,this['error']=_0x1e839c,this['path']=_0xdb2a1a;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x57ddcc,_0x1f582e){this['snapshotCallback']=_0x57ddcc,this['cancelCallback']=_0x1f582e;}['onValue'](_0x5b0a7e,_0x43849e){this['snapshotCallback']['call'](null,_0x5b0a7e,_0x43849e);}['onCancel'](_0x5f5b8c){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x5f5b8c);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1ff142){return this['snapshotCallback']===_0x1ff142['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1ff142['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1ff142['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x10d354,_0x166135,_0x30b6a3,_0x373f54){this['_repo']=_0x10d354,this['_path']=_0x166135,this['_queryParams']=_0x30b6a3,this['_orderByCalled']=_0x373f54;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5847ac=nr(this['_queryParams']),_0x50e313=Bi(_0x5847ac);return _0x50e313==='{}'?'default':_0x50e313;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4ae056){if(_0x4ae056=k(_0x4ae056),!(_0x4ae056 instanceof be))return!0x1;const _0x2a6714=this['_repo']===_0x4ae056['_repo'],_0x41dad5=qi(this['_path'],_0x4ae056['_path']),_0x57b6be=this['_queryIdentifier']===_0x4ae056['_queryIdentifier'];return _0x2a6714&&_0x41dad5&&_0x57b6be;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x435a86,_0x3656a2){if(_0x435a86['_orderByCalled']===!0x0)throw new Error(_0x3656a2+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x59b595){let _0x4dd15f=null,_0x54b045=null;if(_0x59b595['hasStart']()&&(_0x4dd15f=_0x59b595['getIndexStartValue']()),_0x59b595['hasEnd']()&&(_0x54b045=_0x59b595['getIndexEndValue']()),_0x59b595['getIndex']()===ye){const _0x41ed8d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3b2dde='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x59b595['hasStart']()){if(_0x59b595['getIndexStartName']()!==xe)throw new Error(_0x41ed8d);if(typeof _0x4dd15f!='string')throw new Error(_0x3b2dde);}if(_0x59b595['hasEnd']()){if(_0x59b595['getIndexEndName']()!==Ie)throw new Error(_0x41ed8d);if(typeof _0x54b045!='string')throw new Error(_0x3b2dde);}}else{if(_0x59b595['getIndex']()===R){if(_0x4dd15f!=null&&!Cn(_0x4dd15f)||_0x54b045!=null&&!Cn(_0x54b045))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x59b595['getIndex']()instanceof Ki||_0x59b595['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4dd15f!=null&&typeof _0x4dd15f=='object'||_0x54b045!=null&&typeof _0x54b045=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0xa01363){if(_0xa01363['hasStart']()&&_0xa01363['hasEnd']()&&_0xa01363['hasLimit']()&&!_0xa01363['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x464447,_0x51497b){super(_0x464447,_0x51497b,new Qi(),!0x1);}get['parent'](){const _0x452d92=To(this['_path']);return _0x452d92===null?null:new Z(this['_repo'],_0x452d92);}get['root'](){let _0x5b43ec=this;for(;_0x5b43ec['parent']!==null;)_0x5b43ec=_0x5b43ec['parent'];return _0x5b43ec;}}class rt{constructor(_0x3685bd,_0x10f0da,_0x3e20d9){this['_node']=_0x3685bd,this['ref']=_0x10f0da,this['_index']=_0x3e20d9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4bc860){const _0x5cff78=new C(_0x4bc860),_0x52b1c9=Lt(this['ref'],_0x4bc860);return new rt(this['_node']['getChild'](_0x5cff78),_0x52b1c9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5ca082){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x130448,_0x581490)=>_0x5ca082(new rt(_0x581490,Lt(this['ref'],_0x130448),R)));}['hasChild'](_0x4ced75){const _0x3ae0f8=new C(_0x4ced75);return!this['_node']['getChild'](_0x3ae0f8)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x455a73,_0x472010){return _0x455a73=k(_0x455a73),_0x455a73['_checkNotDeleted']('ref'),_0x472010!==void 0x0?Lt(_0x455a73['_root'],_0x472010):_0x455a73['_root'];}function Lt(_0x39103f,_0x49d669){return _0x39103f=k(_0x39103f),y(_0x39103f['_path'])===null?ud('child','path',_0x49d669):_s('child','path',_0x49d669),new Z(_0x39103f['_repo'],A(_0x39103f['_path'],_0x49d669));}function d_(_0x1354aa,_0x20debf){_0x1354aa=k(_0x1354aa),gs('push',_0x1354aa['_path']),qt('push',_0x20debf,_0x1354aa['_path'],!0x0);const _0x33f4c9=oa(_0x1354aa['_repo']),_0x554e5b=Od(_0x33f4c9),_0x2f9462=Lt(_0x1354aa,_0x554e5b),_0x3abd10=Lt(_0x1354aa,_0x554e5b);let _0x4317c4;return _0x20debf!=null?_0x4317c4=Ld(_0x3abd10,_0x20debf)['then'](()=>_0x3abd10):_0x4317c4=Promise['resolve'](_0x3abd10),_0x2f9462['then']=_0x4317c4['then']['bind'](_0x4317c4),_0x2f9462['catch']=_0x4317c4['then']['bind'](_0x4317c4,void 0x0),_0x2f9462;}function Ld(_0x582fbd,_0x2f9138){_0x582fbd=k(_0x582fbd),gs('set',_0x582fbd['_path']),qt('set',_0x2f9138,_0x582fbd['_path'],!0x1);const _0x43fb8c=new Ve();return Ed(_0x582fbd['_repo'],_0x582fbd['_path'],_0x2f9138,null,_0x43fb8c['wrapCallback'](()=>{})),_0x43fb8c['promise'];}function f_(_0x12425a,_0x39afc6){hd('update',_0x39afc6,_0x12425a['_path']);const _0x5af604=new Ve();return Id(_0x12425a['_repo'],_0x12425a['_path'],_0x39afc6,_0x5af604['wrapCallback'](()=>{})),_0x5af604['promise'];}function p_(_0x27f729){_0x27f729=k(_0x27f729);const _0x5a6441=new ua(()=>{}),_0xc351af=new qn(_0x5a6441);return vd(_0x27f729['_repo'],_0x27f729,_0xc351af)['then'](_0x17b4ca=>new rt(_0x17b4ca,new Z(_0x27f729['_repo'],_0x27f729['_path']),_0x27f729['_queryParams']['getIndex']()));}class qn{constructor(_0x567d93){this['callbackContext']=_0x567d93;}['respondsTo'](_0x4fb4bb){return _0x4fb4bb==='value';}['createEvent'](_0x47e7ed,_0x38cb1f){const _0x3df514=_0x38cb1f['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x47e7ed['snapshotNode'],new Z(_0x38cb1f['_repo'],_0x38cb1f['_path']),_0x3df514));}['getEventRunner'](_0x50d6bc){return _0x50d6bc['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x50d6bc['error']):()=>this['callbackContext']['onValue'](_0x50d6bc['snapshot'],null);}['createCancelEvent'](_0x49c5ab,_0x48f2fd){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x49c5ab,_0x48f2fd):null;}['matches'](_0x4ee320){return _0x4ee320 instanceof qn?!_0x4ee320['callbackContext']||!this['callbackContext']?!0x0:_0x4ee320['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x159371,_0x308c45,_0x39e852,_0x155f32,_0x2bb55c){const _0x55970e=new ua(_0x39e852,void 0x0),_0x3e3e1e=new qn(_0x55970e);return Cd(_0x159371['_repo'],_0x159371,_0x3e3e1e),()=>Td(_0x159371['_repo'],_0x159371,_0x3e3e1e);}function Fd(_0x100f88,_0x58d2d3,_0x1f5773,_0x197672){return xd(_0x100f88,'value',_0x58d2d3);}class dt{}class pa extends dt{constructor(_0x56eab1,_0x58e258){super(),this['_value']=_0x56eab1,this['_key']=_0x58e258,this['type']='endAt';}['_apply'](_0x1f4cb6){qt('endAt',this['_value'],_0x1f4cb6['_path'],!0x0);const _0x5c3b31=Kh(_0x1f4cb6['_queryParams'],this['_value'],this['_key']);if(fa(_0x5c3b31),Gn(_0x5c3b31),_0x1f4cb6['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x1f4cb6['_repo'],_0x1f4cb6['_path'],_0x5c3b31,_0x1f4cb6['_orderByCalled']);}}function __(_0x2f9167,_0x51a01a){return new pa(_0x2f9167,_0x51a01a);}class _a extends dt{constructor(_0xf4b283,_0x28bf62){super(),this['_value']=_0xf4b283,this['_key']=_0x28bf62,this['type']='startAt';}['_apply'](_0x31b015){qt('startAt',this['_value'],_0x31b015['_path'],!0x0);const _0x223bee=jh(_0x31b015['_queryParams'],this['_value'],this['_key']);if(fa(_0x223bee),Gn(_0x223bee),_0x31b015['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x31b015['_repo'],_0x31b015['_path'],_0x223bee,_0x31b015['_orderByCalled']);}}function g_(_0x527587=null,_0x330b90){return new _a(_0x527587,_0x330b90);}class Ud extends dt{constructor(_0x48f752){super(),this['_limit']=_0x48f752,this['type']='limitToFirst';}['_apply'](_0x57f0e4){if(_0x57f0e4['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x57f0e4['_repo'],_0x57f0e4['_path'],zh(_0x57f0e4['_queryParams'],this['_limit']),_0x57f0e4['_orderByCalled']);}}function m_(_0x2793b1){if(Math['floor'](_0x2793b1)!==_0x2793b1||_0x2793b1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x2793b1);}class Wd extends dt{constructor(_0xdf9826){super(),this['_path']=_0xdf9826,this['type']='orderByChild';}['_apply'](_0x1e8d0d){da(_0x1e8d0d,'orderByChild');const _0xea471a=new C(this['_path']);if(v(_0xea471a))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x82f8a1=new Ki(_0xea471a),_0x653711=Do(_0x1e8d0d['_queryParams'],_0x82f8a1);return Gn(_0x653711),new be(_0x1e8d0d['_repo'],_0x1e8d0d['_path'],_0x653711,!0x0);}}function y_(_0x4aea11){if(_0x4aea11==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4aea11==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4aea11==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x4aea11),new Wd(_0x4aea11);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x256d2c){da(_0x256d2c,'orderByKey');const _0x592bf5=Do(_0x256d2c['_queryParams'],ye);return Gn(_0x592bf5),new be(_0x256d2c['_repo'],_0x256d2c['_path'],_0x592bf5,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x52dea3,_0x11de8c){super(),this['_value']=_0x52dea3,this['_key']=_0x11de8c,this['type']='equalTo';}['_apply'](_0x2aaf1b){if(qt('equalTo',this['_value'],_0x2aaf1b['_path'],!0x1),_0x2aaf1b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2aaf1b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2aaf1b));}}function E_(_0x4629e8,_0xb53431){return new Vd(_0x4629e8,_0xb53431);}function I_(_0x46ac0e,..._0x6f8fb0){let _0x1b6262=k(_0x46ac0e);for(const _0x1a16c5 of _0x6f8fb0)_0x1b6262=_0x1a16c5['_apply'](_0x1b6262);return _0x1b6262;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x2b424a,_0x14fe9e,_0x3b2bc9,_0x2cbf27){const _0x35148d=_0x14fe9e['lastIndexOf'](':'),_0x38528b=_0x14fe9e['substring'](0x0,_0x35148d),_0x4a445f=Wt(_0x38528b);_0x2b424a['repoInfo_']=new _o(_0x14fe9e,_0x4a445f,_0x2b424a['repoInfo_']['namespace'],_0x2b424a['repoInfo_']['webSocketOnly'],_0x2b424a['repoInfo_']['nodeAdmin'],_0x2b424a['repoInfo_']['persistenceKey'],_0x2b424a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3b2bc9),_0x2cbf27&&(_0x2b424a['authTokenProvider_']=_0x2cbf27);}function qd(_0x51bea0,_0x1c1656,_0x42f741,_0x138cde,_0x5c8106){let _0x42e7ea=_0x138cde||_0x51bea0['options']['databaseURL'];_0x42e7ea===void 0x0&&(_0x51bea0['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x51bea0['options']['projectId']),_0x42e7ea=_0x51bea0['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x157cd7=gr(_0x42e7ea,_0x5c8106),_0x1a90e6=_0x157cd7['repoInfo'],_0x247c93;typeof process<'u'&&Us&&(_0x247c93=Us[Hd]),_0x247c93?(_0x42e7ea='http://'+_0x247c93+'?ns='+_0x1a90e6['namespace'],_0x157cd7=gr(_0x42e7ea,_0x5c8106),_0x1a90e6=_0x157cd7['repoInfo']):_0x157cd7['repoInfo']['secure'];const _0x1dbcce=new Jl(_0x51bea0['name'],_0x51bea0['options'],_0x1c1656);dd('Invalid\x20Firebase\x20Database\x20URL',_0x157cd7),v(_0x157cd7['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xcbb1a8=jd(_0x1a90e6,_0x51bea0,_0x1dbcce,new Ql(_0x51bea0,_0x42f741));return new Kd(_0xcbb1a8,_0x51bea0);}function zd(_0x3f3cf0,_0x5e7cda){const _0x2bdfb5=ki[_0x5e7cda];(!_0x2bdfb5||_0x2bdfb5[_0x3f3cf0['key']]!==_0x3f3cf0)&&oe('Database\x20'+_0x5e7cda+'('+_0x3f3cf0['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x3f3cf0),delete _0x2bdfb5[_0x3f3cf0['key']];}function jd(_0x5ee3ac,_0x465f5a,_0x15cee9,_0x3761d7){let _0x4368e2=ki[_0x465f5a['name']];_0x4368e2||(_0x4368e2={},ki[_0x465f5a['name']]=_0x4368e2);let _0x491a9c=_0x4368e2[_0x5ee3ac['toURLString']()];return _0x491a9c&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x491a9c=new gd(_0x5ee3ac,$d,_0x15cee9,_0x3761d7),_0x4368e2[_0x5ee3ac['toURLString']()]=_0x491a9c,_0x491a9c;}class Kd{constructor(_0xf3e637,_0x52d1b7){this['_repoInternal']=_0xf3e637,this['app']=_0x52d1b7,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x292864){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x292864+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x4effbf=Qr(),_0x437f56){const _0x57bac6=Ui(_0x4effbf,'database')['getImmediate']({'identifier':_0x437f56});if(!_0x57bac6['_instanceStarted']){const _0x218b83=ac('database');_0x218b83&&Yd(_0x57bac6,..._0x218b83);}return _0x57bac6;}function Yd(_0x35248b,_0x505440,_0x5526be,_0x3b2584={}){_0x35248b=k(_0x35248b),_0x35248b['_checkNotDeleted']('useEmulator');const _0x548ae6=_0x505440+':'+_0x5526be,_0xf20baf=_0x35248b['_repoInternal'];if(_0x35248b['_instanceStarted']){if(_0x548ae6===_0x35248b['_repoInternal']['repoInfo_']['host']&&De(_0x3b2584,_0xf20baf['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3d433a;if(_0xf20baf['repoInfo_']['nodeAdmin'])_0x3b2584['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3d433a=new tn(tn['OWNER']);else{if(_0x3b2584['mockUserToken']){const _0x3a2224=typeof _0x3b2584['mockUserToken']=='string'?_0x3b2584['mockUserToken']:cc(_0x3b2584['mockUserToken'],_0x35248b['app']['options']['projectId']);_0x3d433a=new tn(_0x3a2224);}}Wt(_0x505440)&&jr(_0x505440),Gd(_0xf20baf,_0x548ae6,_0x3b2584,_0x3d433a);}function C_(_0x40cf15){_0x40cf15=k(_0x40cf15),_0x40cf15['_checkNotDeleted']('goOffline'),aa(_0x40cf15['_repo']);}function T_(_0x52a7cd){_0x52a7cd=k(_0x52a7cd),_0x52a7cd['_checkNotDeleted']('goOnline'),Sd(_0x52a7cd['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x4cbbfe){Ll(ct),et(new Me('database',(_0x345868,{instanceIdentifier:_0x3fc5a0})=>{const _0x419051=_0x345868['getProvider']('app')['getImmediate'](),_0x7b7f1b=_0x345868['getProvider']('auth-internal'),_0x5aea94=_0x345868['getProvider']('app-check-internal');return qd(_0x419051,_0x7b7f1b,_0x5aea94,_0x3fc5a0);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x4cbbfe),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1a7239,_0x35dff2){this['committed']=_0x1a7239,this['snapshot']=_0x35dff2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x24260e,_0x283697,_0x5af444){if(_0x24260e=k(_0x24260e),gs('Reference.transaction',_0x24260e['_path']),_0x24260e['key']==='.length'||_0x24260e['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x24260e['key']+'\x20is\x20a\x20read-only\x20object.';const _0x411e29=!0x0,_0x52e6a5=new Ve(),_0x3f678f=(_0x5bd3be,_0x5ef83a,_0x3ecad1)=>{let _0x29bbbc=null;_0x5bd3be?_0x52e6a5['reject'](_0x5bd3be):(_0x29bbbc=new rt(_0x3ecad1,new Z(_0x24260e['_repo'],_0x24260e['_path']),R),_0x52e6a5['resolve'](new Xd(_0x5ef83a,_0x29bbbc)));},_0x3ebff1=Fd(_0x24260e,()=>{});return bd(_0x24260e['_repo'],_0x24260e['_path'],_0x283697,_0x3f678f,_0x3ebff1,_0x411e29),_0x52e6a5['promise'];}ie['prototype']['simpleListen']=function(_0x29e178,_0x4b1809){this['sendRequest']('q',{'p':_0x29e178},_0x4b1809);},ie['prototype']['echo']=function(_0x513e2b,_0x56ddf4){this['sendRequest']('echo',{'d':_0x513e2b},_0x56ddf4);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x8f3503,..._0x1bd9ef){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x8f3503,..._0x1bd9ef);}function nn(_0x250e11,..._0x19fb23){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x250e11,..._0x19fb23);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x464140,..._0x47fdab){throw Es(_0x464140,..._0x47fdab);}function J(_0xf83da6,..._0x23fef5){return Es(_0xf83da6,..._0x23fef5);}function ya(_0x5b9fd1,_0x133458,_0xcb8401){const _0x4ad5c4={...Zd(),[_0x133458]:_0xcb8401};return new Ut('auth','Firebase',_0x4ad5c4)['create'](_0x133458,{'appName':_0x5b9fd1['name']});}function se(_0x3f9d5f){return ya(_0x3f9d5f,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x544cbe,..._0x4ed864){if(typeof _0x544cbe!='string'){const _0x4760dc=_0x4ed864[0x0],_0x3ef87a=[..._0x4ed864['slice'](0x1)];return _0x3ef87a[0x0]&&(_0x3ef87a[0x0]['appName']=_0x544cbe['name']),_0x544cbe['_errorFactory']['create'](_0x4760dc,..._0x3ef87a);}return ma['create'](_0x544cbe,..._0x4ed864);}function m(_0xcf0e2c,_0x5b6636,..._0x479dfe){if(!_0xcf0e2c)throw Es(_0x5b6636,..._0x479dfe);}function te(_0x4d9be9){const _0x1298e5='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4d9be9;throw nn(_0x1298e5),new Error(_0x1298e5);}function ae(_0x302c3f,_0x42c095){_0x302c3f||te(_0x42c095);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x271e90;return typeof self<'u'&&((_0x271e90=self['location'])==null?void 0x0:_0x271e90['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x28b25e;return typeof self<'u'&&((_0x28b25e=self['location'])==null?void 0x0:_0x28b25e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0xe4b3de=navigator;return _0xe4b3de['languages']&&_0xe4b3de['languages'][0x0]||_0xe4b3de['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3b935a,_0x76a8fc){this['shortDelay']=_0x3b935a,this['longDelay']=_0x76a8fc,ae(_0x76a8fc>_0x3b935a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x401ea5,_0x714f56){ae(_0x401ea5['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xf4ddee}=_0x401ea5['emulator'];return _0x714f56?''+_0xf4ddee+(_0x714f56['startsWith']('/')?_0x714f56['slice'](0x1):_0x714f56):_0xf4ddee;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x46a366,_0x29946d,_0x65033f){this['fetchImpl']=_0x46a366,_0x29946d&&(this['headersImpl']=_0x29946d),_0x65033f&&(this['responseImpl']=_0x65033f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x162958,_0x431314){return _0x162958['tenantId']&&!_0x431314['tenantId']?{..._0x431314,'tenantId':_0x162958['tenantId']}:_0x431314;}async function Ae(_0x3b1550,_0x31339,_0x1ba894,_0xe07b51,_0x5defc7={}){return Ea(_0x3b1550,_0x5defc7,async()=>{let _0x4ac645={},_0x302b54={};_0xe07b51&&(_0x31339==='GET'?_0x302b54=_0xe07b51:_0x4ac645={'body':JSON['stringify'](_0xe07b51)});const _0x4ac0c6=at({..._0x302b54,'key':_0x3b1550['config']['apiKey']})['slice'](0x1),_0x560cd5=await _0x3b1550['_getAdditionalHeaders']();_0x560cd5['Content-Type']='application/json',_0x3b1550['languageCode']&&(_0x560cd5['X-Firebase-Locale']=_0x3b1550['languageCode']);const _0x2524d3={'method':_0x31339,'headers':_0x560cd5,..._0x4ac645};return lc()||(_0x2524d3['referrerPolicy']='strict-origin-when-cross-origin'),_0x3b1550['emulatorConfig']&&Wt(_0x3b1550['emulatorConfig']['host'])&&(_0x2524d3['credentials']='include'),va['fetch']()(await Ia(_0x3b1550,_0x3b1550['config']['apiHost'],_0x1ba894,_0x4ac0c6),_0x2524d3);});}async function Ea(_0x554a68,_0x157850,_0x5787bf){_0x554a68['_canInitEmulator']=!0x1;const _0x1cad8b={...rf,..._0x157850};try{const _0x58e481=new lf(_0x554a68),_0x316207=await Promise['race']([_0x5787bf(),_0x58e481['promise']]);_0x58e481['clearNetworkTimeout']();const _0x1a618a=await _0x316207['json']();if('needConfirmation'in _0x1a618a)throw en(_0x554a68,'account-exists-with-different-credential',_0x1a618a);if(_0x316207['ok']&&!('errorMessage'in _0x1a618a))return _0x1a618a;{const _0x1dfa01=_0x316207['ok']?_0x1a618a['errorMessage']:_0x1a618a['error']['message'],[_0x4ef51e,_0x3a1cae]=_0x1dfa01['split']('\x20:\x20');if(_0x4ef51e==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x554a68,'credential-already-in-use',_0x1a618a);if(_0x4ef51e==='EMAIL_EXISTS')throw en(_0x554a68,'email-already-in-use',_0x1a618a);if(_0x4ef51e==='USER_DISABLED')throw en(_0x554a68,'user-disabled',_0x1a618a);const _0x522e47=_0x1cad8b[_0x4ef51e]||_0x4ef51e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3a1cae)throw ya(_0x554a68,_0x522e47,_0x3a1cae);K(_0x554a68,_0x522e47);}}catch(_0x465893){if(_0x465893 instanceof Se)throw _0x465893;K(_0x554a68,'network-request-failed',{'message':String(_0x465893)});}}async function Yt(_0x57cff7,_0x19eb17,_0x4c6319,_0x45ddf1,_0xe64c0c={}){const _0x4fbe70=await Ae(_0x57cff7,_0x19eb17,_0x4c6319,_0x45ddf1,_0xe64c0c);return'mfaPendingCredential'in _0x4fbe70&&K(_0x57cff7,'multi-factor-auth-required',{'_serverResponse':_0x4fbe70}),_0x4fbe70;}async function Ia(_0x533391,_0x5dfcbc,_0x353cdd,_0x410228){const _0x178d0d=''+_0x5dfcbc+_0x353cdd+'?'+_0x410228,_0x49e2e8=_0x533391,_0x526248=_0x49e2e8['config']['emulator']?Is(_0x533391['config'],_0x178d0d):_0x533391['config']['apiScheme']+'://'+_0x178d0d;return of['includes'](_0x353cdd)&&(await _0x49e2e8['_persistenceManagerAvailable'],_0x49e2e8['_getPersistenceType']()==='COOKIE')?_0x49e2e8['_getPersistence']()['_getFinalTarget'](_0x526248)['toString']():_0x526248;}function cf(_0x3c1f6b){switch(_0x3c1f6b){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4cd9d6){this['auth']=_0x4cd9d6,this['timer']=null,this['promise']=new Promise((_0x277e37,_0x548ac1)=>{this['timer']=setTimeout(()=>_0x548ac1(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x5f5d5b,_0x1d528f,_0xee3b6c){const _0x3ac35c={'appName':_0x5f5d5b['name']};_0xee3b6c['email']&&(_0x3ac35c['email']=_0xee3b6c['email']),_0xee3b6c['phoneNumber']&&(_0x3ac35c['phoneNumber']=_0xee3b6c['phoneNumber']);const _0x32f9e7=J(_0x5f5d5b,_0x1d528f,_0x3ac35c);return _0x32f9e7['customData']['_tokenResponse']=_0xee3b6c,_0x32f9e7;}function vr(_0x33178b){return _0x33178b!==void 0x0&&_0x33178b['enterprise']!==void 0x0;}class hf{constructor(_0x43f9e2){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x43f9e2['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x43f9e2['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x43f9e2['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x404d79){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x463cf8 of this['recaptchaEnforcementState'])if(_0x463cf8['provider']&&_0x463cf8['provider']===_0x404d79)return cf(_0x463cf8['enforcementState']);return null;}['isProviderEnabled'](_0x12229c){return this['getProviderEnforcementState'](_0x12229c)==='ENFORCE'||this['getProviderEnforcementState'](_0x12229c)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x5e04cb,_0x16bc3a){return Ae(_0x5e04cb,'GET','/v2/recaptchaConfig',Re(_0x5e04cb,_0x16bc3a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x1e63a4,_0x3110fe){return Ae(_0x1e63a4,'POST','/v1/accounts:delete',_0x3110fe);}async function Sn(_0x227791,_0x267977){return Ae(_0x227791,'POST','/v1/accounts:lookup',_0x267977);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x29ace7){if(_0x29ace7)try{const _0x223d74=new Date(Number(_0x29ace7));if(!isNaN(_0x223d74['getTime']()))return _0x223d74['toUTCString']();}catch{}}async function ff(_0x213e03,_0x588c29=!0x1){const _0x43147f=k(_0x213e03),_0x367783=await _0x43147f['getIdToken'](_0x588c29),_0x2d882c=ws(_0x367783);m(_0x2d882c&&_0x2d882c['exp']&&_0x2d882c['auth_time']&&_0x2d882c['iat'],_0x43147f['auth'],'internal-error');const _0x1f043a=typeof _0x2d882c['firebase']=='object'?_0x2d882c['firebase']:void 0x0,_0x5f177b=_0x1f043a==null?void 0x0:_0x1f043a['sign_in_provider'];return{'claims':_0x2d882c,'token':_0x367783,'authTime':St(ci(_0x2d882c['auth_time'])),'issuedAtTime':St(ci(_0x2d882c['iat'])),'expirationTime':St(ci(_0x2d882c['exp'])),'signInProvider':_0x5f177b||null,'signInSecondFactor':(_0x1f043a==null?void 0x0:_0x1f043a['sign_in_second_factor'])||null};}function ci(_0x2c548c){return Number(_0x2c548c)*0x3e8;}function ws(_0x59cca6){const [_0x3120f7,_0x45314f,_0x86ac3f]=_0x59cca6['split']('.');if(_0x3120f7===void 0x0||_0x45314f===void 0x0||_0x86ac3f===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x344458=cn(_0x45314f);return _0x344458?JSON['parse'](_0x344458):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x58e2a3){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x58e2a3==null?void 0x0:_0x58e2a3['toString']()),null;}}function Er(_0x4bec8e){const _0x586cc8=ws(_0x4bec8e);return m(_0x586cc8,'internal-error'),m(typeof _0x586cc8['exp']<'u','internal-error'),m(typeof _0x586cc8['iat']<'u','internal-error'),Number(_0x586cc8['exp'])-Number(_0x586cc8['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x477295,_0x2aaf17,_0x2b4f5c=!0x1){if(_0x2b4f5c)return _0x2aaf17;try{return await _0x2aaf17;}catch(_0x6712be){throw _0x6712be instanceof Se&&pf(_0x6712be)&&_0x477295['auth']['currentUser']===_0x477295&&await _0x477295['auth']['signOut'](),_0x6712be;}}function pf({code:_0x1fe8b7}){return _0x1fe8b7==='auth/user-disabled'||_0x1fe8b7==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x97cc75){this['user']=_0x97cc75,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x569bc0){if(_0x569bc0){const _0x2c0aea=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2c0aea;}else{this['errorBackoff']=0x7530;const _0x1f2b1a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1f2b1a);}}['schedule'](_0x1ecb84=!0x1){if(!this['isRunning'])return;const _0x168f90=this['getInterval'](_0x1ecb84);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x168f90);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x21722d){(_0x21722d==null?void 0x0:_0x21722d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x35b9e1,_0x4887d9){this['createdAt']=_0x35b9e1,this['lastLoginAt']=_0x4887d9,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4c15ea){this['createdAt']=_0x4c15ea['createdAt'],this['lastLoginAt']=_0x4c15ea['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x5e9d71){var _0x174fcf;const _0x2c8d22=_0x5e9d71['auth'],_0x19d079=await _0x5e9d71['getIdToken'](),_0x54d927=await xt(_0x5e9d71,Sn(_0x2c8d22,{'idToken':_0x19d079}));m(_0x54d927==null?void 0x0:_0x54d927['users']['length'],_0x2c8d22,'internal-error');const _0x300eb2=_0x54d927['users'][0x0];_0x5e9d71['_notifyReloadListener'](_0x300eb2);const _0x622e0=(_0x174fcf=_0x300eb2['providerUserInfo'])!=null&&_0x174fcf['length']?wa(_0x300eb2['providerUserInfo']):[],_0x19bfb9=mf(_0x5e9d71['providerData'],_0x622e0),_0x56066d=_0x5e9d71['isAnonymous'],_0x4d682e=!(_0x5e9d71['email']&&_0x300eb2['passwordHash'])&&!(_0x19bfb9!=null&&_0x19bfb9['length']),_0x1a8bbc=_0x56066d?_0x4d682e:!0x1,_0x2edcee={'uid':_0x300eb2['localId'],'displayName':_0x300eb2['displayName']||null,'photoURL':_0x300eb2['photoUrl']||null,'email':_0x300eb2['email']||null,'emailVerified':_0x300eb2['emailVerified']||!0x1,'phoneNumber':_0x300eb2['phoneNumber']||null,'tenantId':_0x300eb2['tenantId']||null,'providerData':_0x19bfb9,'metadata':new Pi(_0x300eb2['createdAt'],_0x300eb2['lastLoginAt']),'isAnonymous':_0x1a8bbc};Object['assign'](_0x5e9d71,_0x2edcee);}async function gf(_0x5461fb){const _0x328746=k(_0x5461fb);await bn(_0x328746),await _0x328746['auth']['_persistUserIfCurrent'](_0x328746),_0x328746['auth']['_notifyListenersIfCurrent'](_0x328746);}function mf(_0x1356b0,_0x195f58){return[..._0x1356b0['filter'](_0x1068bb=>!_0x195f58['some'](_0x3b0fe5=>_0x3b0fe5['providerId']===_0x1068bb['providerId'])),..._0x195f58];}function wa(_0x5e40ff){return _0x5e40ff['map'](({providerId:_0x1469d4,..._0x10d69d})=>({'providerId':_0x1469d4,'uid':_0x10d69d['rawId']||'','displayName':_0x10d69d['displayName']||null,'email':_0x10d69d['email']||null,'phoneNumber':_0x10d69d['phoneNumber']||null,'photoURL':_0x10d69d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x5078bc,_0x3eafae){const _0x5c9ea1=await Ea(_0x5078bc,{},async()=>{const _0x1a48c5=at({'grant_type':'refresh_token','refresh_token':_0x3eafae})['slice'](0x1),{tokenApiHost:_0x183ae5,apiKey:_0x428dae}=_0x5078bc['config'],_0xac7819=await Ia(_0x5078bc,_0x183ae5,'/v1/token','key='+_0x428dae),_0x5063c2=await _0x5078bc['_getAdditionalHeaders']();_0x5063c2['Content-Type']='application/x-www-form-urlencoded';const _0x3a149e={'method':'POST','headers':_0x5063c2,'body':_0x1a48c5};return _0x5078bc['emulatorConfig']&&Wt(_0x5078bc['emulatorConfig']['host'])&&(_0x3a149e['credentials']='include'),va['fetch']()(_0xac7819,_0x3a149e);});return{'accessToken':_0x5c9ea1['access_token'],'expiresIn':_0x5c9ea1['expires_in'],'refreshToken':_0x5c9ea1['refresh_token']};}async function vf(_0x1ac829,_0x7f797d){return Ae(_0x1ac829,'POST','/v2/accounts:revokeToken',Re(_0x1ac829,_0x7f797d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2e7120){m(_0x2e7120['idToken'],'internal-error'),m(typeof _0x2e7120['idToken']<'u','internal-error'),m(typeof _0x2e7120['refreshToken']<'u','internal-error');const _0x11e912='expiresIn'in _0x2e7120&&typeof _0x2e7120['expiresIn']<'u'?Number(_0x2e7120['expiresIn']):Er(_0x2e7120['idToken']);this['updateTokensAndExpiration'](_0x2e7120['idToken'],_0x2e7120['refreshToken'],_0x11e912);}['updateFromIdToken'](_0x519e8f){m(_0x519e8f['length']!==0x0,'internal-error');const _0x273891=Er(_0x519e8f);this['updateTokensAndExpiration'](_0x519e8f,null,_0x273891);}async['getToken'](_0x283a13,_0x507dbc=!0x1){return!_0x507dbc&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x283a13,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x283a13,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x177be8,_0x35cfd9){const {accessToken:_0x1a1c1a,refreshToken:_0x18be69,expiresIn:_0x2c007b}=await yf(_0x177be8,_0x35cfd9);this['updateTokensAndExpiration'](_0x1a1c1a,_0x18be69,Number(_0x2c007b));}['updateTokensAndExpiration'](_0x849b,_0x58ee42,_0x16653b){this['refreshToken']=_0x58ee42||null,this['accessToken']=_0x849b||null,this['expirationTime']=Date['now']()+_0x16653b*0x3e8;}static['fromJSON'](_0x3363e3,_0x476dc1){const {refreshToken:_0x3f7145,accessToken:_0xa7b811,expirationTime:_0x3d5f0d}=_0x476dc1,_0x59c317=new Je();return _0x3f7145&&(m(typeof _0x3f7145=='string','internal-error',{'appName':_0x3363e3}),_0x59c317['refreshToken']=_0x3f7145),_0xa7b811&&(m(typeof _0xa7b811=='string','internal-error',{'appName':_0x3363e3}),_0x59c317['accessToken']=_0xa7b811),_0x3d5f0d&&(m(typeof _0x3d5f0d=='number','internal-error',{'appName':_0x3363e3}),_0x59c317['expirationTime']=_0x3d5f0d),_0x59c317;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x59195b){this['accessToken']=_0x59195b['accessToken'],this['refreshToken']=_0x59195b['refreshToken'],this['expirationTime']=_0x59195b['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x535e1c,_0x67c0d4){m(typeof _0x535e1c=='string'||typeof _0x535e1c>'u','internal-error',{'appName':_0x67c0d4});}class z{constructor({uid:_0x2d08ba,auth:_0x69fb78,stsTokenManager:_0x5a95fc,..._0x4ab170}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2d08ba,this['auth']=_0x69fb78,this['stsTokenManager']=_0x5a95fc,this['accessToken']=_0x5a95fc['accessToken'],this['displayName']=_0x4ab170['displayName']||null,this['email']=_0x4ab170['email']||null,this['emailVerified']=_0x4ab170['emailVerified']||!0x1,this['phoneNumber']=_0x4ab170['phoneNumber']||null,this['photoURL']=_0x4ab170['photoURL']||null,this['isAnonymous']=_0x4ab170['isAnonymous']||!0x1,this['tenantId']=_0x4ab170['tenantId']||null,this['providerData']=_0x4ab170['providerData']?[..._0x4ab170['providerData']]:[],this['metadata']=new Pi(_0x4ab170['createdAt']||void 0x0,_0x4ab170['lastLoginAt']||void 0x0);}async['getIdToken'](_0x58a76d){const _0x377c1f=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x58a76d));return m(_0x377c1f,this['auth'],'internal-error'),this['accessToken']!==_0x377c1f&&(this['accessToken']=_0x377c1f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x377c1f;}['getIdTokenResult'](_0x4595d5){return ff(this,_0x4595d5);}['reload'](){return gf(this);}['_assign'](_0x2d92bb){this!==_0x2d92bb&&(m(this['uid']===_0x2d92bb['uid'],this['auth'],'internal-error'),this['displayName']=_0x2d92bb['displayName'],this['photoURL']=_0x2d92bb['photoURL'],this['email']=_0x2d92bb['email'],this['emailVerified']=_0x2d92bb['emailVerified'],this['phoneNumber']=_0x2d92bb['phoneNumber'],this['isAnonymous']=_0x2d92bb['isAnonymous'],this['tenantId']=_0x2d92bb['tenantId'],this['providerData']=_0x2d92bb['providerData']['map'](_0x41b178=>({..._0x41b178})),this['metadata']['_copy'](_0x2d92bb['metadata']),this['stsTokenManager']['_assign'](_0x2d92bb['stsTokenManager']));}['_clone'](_0x36f35e){const _0x22fedb=new z({...this,'auth':_0x36f35e,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x22fedb['metadata']['_copy'](this['metadata']),_0x22fedb;}['_onReload'](_0x1d022a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1d022a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x17106f){this['reloadListener']?this['reloadListener'](_0x17106f):this['reloadUserInfo']=_0x17106f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x41d0c4,_0x59aa70=!0x1){let _0x16017d=!0x1;_0x41d0c4['idToken']&&_0x41d0c4['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x41d0c4),_0x16017d=!0x0),_0x59aa70&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x16017d&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1f6e22=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1f6e22})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1704d9=>({..._0x1704d9})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1389dd,_0x5722fc){const _0x555ec8=_0x5722fc['displayName']??void 0x0,_0x5d82eb=_0x5722fc['email']??void 0x0,_0x2aa9be=_0x5722fc['phoneNumber']??void 0x0,_0x4c17a5=_0x5722fc['photoURL']??void 0x0,_0x4e472c=_0x5722fc['tenantId']??void 0x0,_0x17bb01=_0x5722fc['_redirectEventId']??void 0x0,_0xc70a50=_0x5722fc['createdAt']??void 0x0,_0x3bd228=_0x5722fc['lastLoginAt']??void 0x0,{uid:_0x4d9564,emailVerified:_0x226626,isAnonymous:_0x194ee2,providerData:_0x5405ea,stsTokenManager:_0x2acc35}=_0x5722fc;m(_0x4d9564&&_0x2acc35,_0x1389dd,'internal-error');const _0xa1b4e5=Je['fromJSON'](this['name'],_0x2acc35);m(typeof _0x4d9564=='string',_0x1389dd,'internal-error'),ce(_0x555ec8,_0x1389dd['name']),ce(_0x5d82eb,_0x1389dd['name']),m(typeof _0x226626=='boolean',_0x1389dd,'internal-error'),m(typeof _0x194ee2=='boolean',_0x1389dd,'internal-error'),ce(_0x2aa9be,_0x1389dd['name']),ce(_0x4c17a5,_0x1389dd['name']),ce(_0x4e472c,_0x1389dd['name']),ce(_0x17bb01,_0x1389dd['name']),ce(_0xc70a50,_0x1389dd['name']),ce(_0x3bd228,_0x1389dd['name']);const _0x1576f4=new z({'uid':_0x4d9564,'auth':_0x1389dd,'email':_0x5d82eb,'emailVerified':_0x226626,'displayName':_0x555ec8,'isAnonymous':_0x194ee2,'photoURL':_0x4c17a5,'phoneNumber':_0x2aa9be,'tenantId':_0x4e472c,'stsTokenManager':_0xa1b4e5,'createdAt':_0xc70a50,'lastLoginAt':_0x3bd228});return _0x5405ea&&Array['isArray'](_0x5405ea)&&(_0x1576f4['providerData']=_0x5405ea['map'](_0x59d873=>({..._0x59d873}))),_0x17bb01&&(_0x1576f4['_redirectEventId']=_0x17bb01),_0x1576f4;}static async['_fromIdTokenResponse'](_0x16167d,_0x4d2b58,_0x4f4519=!0x1){const _0x1ee7c5=new Je();_0x1ee7c5['updateFromServerResponse'](_0x4d2b58);const _0x2ce77c=new z({'uid':_0x4d2b58['localId'],'auth':_0x16167d,'stsTokenManager':_0x1ee7c5,'isAnonymous':_0x4f4519});return await bn(_0x2ce77c),_0x2ce77c;}static async['_fromGetAccountInfoResponse'](_0xc08388,_0x4e50a6,_0x1b2753){const _0x1ee678=_0x4e50a6['users'][0x0];m(_0x1ee678['localId']!==void 0x0,'internal-error');const _0x19af60=_0x1ee678['providerUserInfo']!==void 0x0?wa(_0x1ee678['providerUserInfo']):[],_0x1728a0=!(_0x1ee678['email']&&_0x1ee678['passwordHash'])&&!(_0x19af60!=null&&_0x19af60['length']),_0x175a1a=new Je();_0x175a1a['updateFromIdToken'](_0x1b2753);const _0x3a4b0c=new z({'uid':_0x1ee678['localId'],'auth':_0xc08388,'stsTokenManager':_0x175a1a,'isAnonymous':_0x1728a0}),_0x4bc3c4={'uid':_0x1ee678['localId'],'displayName':_0x1ee678['displayName']||null,'photoURL':_0x1ee678['photoUrl']||null,'email':_0x1ee678['email']||null,'emailVerified':_0x1ee678['emailVerified']||!0x1,'phoneNumber':_0x1ee678['phoneNumber']||null,'tenantId':_0x1ee678['tenantId']||null,'providerData':_0x19af60,'metadata':new Pi(_0x1ee678['createdAt'],_0x1ee678['lastLoginAt']),'isAnonymous':!(_0x1ee678['email']&&_0x1ee678['passwordHash'])&&!(_0x19af60!=null&&_0x19af60['length'])};return Object['assign'](_0x3a4b0c,_0x4bc3c4),_0x3a4b0c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x1d56a3){ae(_0x1d56a3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xafa1d9=Ir['get'](_0x1d56a3);return _0xafa1d9?(ae(_0xafa1d9 instanceof _0x1d56a3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xafa1d9):(_0xafa1d9=new _0x1d56a3(),Ir['set'](_0x1d56a3,_0xafa1d9),_0xafa1d9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x14d9a5,_0x278c54){this['storage'][_0x14d9a5]=_0x278c54;}async['_get'](_0xe79f6e){const _0x88e32a=this['storage'][_0xe79f6e];return _0x88e32a===void 0x0?null:_0x88e32a;}async['_remove'](_0x28d756){delete this['storage'][_0x28d756];}['_addListener'](_0x4f0394,_0x2addf2){}['_removeListener'](_0x451685,_0x3e7d0f){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x235d5b,_0x575587,_0x3240d4){return'firebase:'+_0x235d5b+':'+_0x575587+':'+_0x3240d4;}class Xe{constructor(_0x244ba0,_0x527825,_0x53df21){this['persistence']=_0x244ba0,this['auth']=_0x527825,this['userKey']=_0x53df21;const {config:_0x2c9ac6,name:_0x539c82}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x2c9ac6['apiKey'],_0x539c82),this['fullPersistenceKey']=sn('persistence',_0x2c9ac6['apiKey'],_0x539c82),this['boundEventHandler']=_0x527825['_onStorageEvent']['bind'](_0x527825),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x44aa90){return this['persistence']['_set'](this['fullUserKey'],_0x44aa90['toJSON']());}async['getCurrentUser'](){const _0x10f593=await this['persistence']['_get'](this['fullUserKey']);if(!_0x10f593)return null;if(typeof _0x10f593=='string'){const _0x4dc831=await Sn(this['auth'],{'idToken':_0x10f593})['catch'](()=>{});return _0x4dc831?z['_fromGetAccountInfoResponse'](this['auth'],_0x4dc831,_0x10f593):null;}return z['_fromJSON'](this['auth'],_0x10f593);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x67c3d9){if(this['persistence']===_0x67c3d9)return;const _0x42df97=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x67c3d9,_0x42df97)return this['setCurrentUser'](_0x42df97);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x591819,_0x102f45,_0x5c54e7='authUser'){if(!_0x102f45['length'])return new Xe(ne(wr),_0x591819,_0x5c54e7);const _0x1bb3b3=(await Promise['all'](_0x102f45['map'](async _0x16a8da=>{if(await _0x16a8da['_isAvailable']())return _0x16a8da;})))['filter'](_0x597d0a=>_0x597d0a);let _0x35d229=_0x1bb3b3[0x0]||ne(wr);const _0x10e8ba=sn(_0x5c54e7,_0x591819['config']['apiKey'],_0x591819['name']);let _0x4125fa=null;for(const _0xf56b1d of _0x102f45)try{const _0x3be4e6=await _0xf56b1d['_get'](_0x10e8ba);if(_0x3be4e6){let _0x1c6a25;if(typeof _0x3be4e6=='string'){const _0x107cf4=await Sn(_0x591819,{'idToken':_0x3be4e6})['catch'](()=>{});if(!_0x107cf4)break;_0x1c6a25=await z['_fromGetAccountInfoResponse'](_0x591819,_0x107cf4,_0x3be4e6);}else _0x1c6a25=z['_fromJSON'](_0x591819,_0x3be4e6);_0xf56b1d!==_0x35d229&&(_0x4125fa=_0x1c6a25),_0x35d229=_0xf56b1d;break;}}catch{}const _0x333076=_0x1bb3b3['filter'](_0xfd138=>_0xfd138['_shouldAllowMigration']);return!_0x35d229['_shouldAllowMigration']||!_0x333076['length']?new Xe(_0x35d229,_0x591819,_0x5c54e7):(_0x35d229=_0x333076[0x0],_0x4125fa&&await _0x35d229['_set'](_0x10e8ba,_0x4125fa['toJSON']()),await Promise['all'](_0x102f45['map'](async _0x356388=>{if(_0x356388!==_0x35d229)try{await _0x356388['_remove'](_0x10e8ba);}catch{}})),new Xe(_0x35d229,_0x591819,_0x5c54e7));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4a3b44){const _0x45c65d=_0x4a3b44['toLowerCase']();if(_0x45c65d['includes']('opera/')||_0x45c65d['includes']('opr/')||_0x45c65d['includes']('opios/'))return'Opera';if(Ra(_0x45c65d))return'IEMobile';if(_0x45c65d['includes']('msie')||_0x45c65d['includes']('trident/'))return'IE';if(_0x45c65d['includes']('edge/'))return'Edge';if(Ta(_0x45c65d))return'Firefox';if(_0x45c65d['includes']('silk/'))return'Silk';if(ka(_0x45c65d))return'Blackberry';if(Na(_0x45c65d))return'Webos';if(Sa(_0x45c65d))return'Safari';if((_0x45c65d['includes']('chrome/')||ba(_0x45c65d))&&!_0x45c65d['includes']('edge/'))return'Chrome';if(Aa(_0x45c65d))return'Android';{const _0xf0da9c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x422109=_0x4a3b44['match'](_0xf0da9c);if((_0x422109==null?void 0x0:_0x422109['length'])===0x2)return _0x422109[0x1];}return'Other';}function Ta(_0x426dad=W()){return/firefox\//i['test'](_0x426dad);}function Sa(_0x7e1af6=W()){const _0x389be0=_0x7e1af6['toLowerCase']();return _0x389be0['includes']('safari/')&&!_0x389be0['includes']('chrome/')&&!_0x389be0['includes']('crios/')&&!_0x389be0['includes']('android');}function ba(_0xa4616d=W()){return/crios\//i['test'](_0xa4616d);}function Ra(_0x1d82f2=W()){return/iemobile/i['test'](_0x1d82f2);}function Aa(_0x2a45a0=W()){return/android/i['test'](_0x2a45a0);}function ka(_0xe41071=W()){return/blackberry/i['test'](_0xe41071);}function Na(_0x17eb4d=W()){return/webos/i['test'](_0x17eb4d);}function Cs(_0x41348c=W()){return/iphone|ipad|ipod/i['test'](_0x41348c)||/macintosh/i['test'](_0x41348c)&&/mobile/i['test'](_0x41348c);}function Ef(_0x5b6bad=W()){var _0x30fe34;return Cs(_0x5b6bad)&&!!((_0x30fe34=window['navigator'])!=null&&_0x30fe34['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x47eccf=W()){return Cs(_0x47eccf)||Aa(_0x47eccf)||Na(_0x47eccf)||ka(_0x47eccf)||/windows phone/i['test'](_0x47eccf)||Ra(_0x47eccf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x3e8ba1,_0x164f5c=[]){let _0x4bde1c;switch(_0x3e8ba1){case'Browser':_0x4bde1c=Cr(W());break;case'Worker':_0x4bde1c=Cr(W())+'-'+_0x3e8ba1;break;default:_0x4bde1c=_0x3e8ba1;}const _0x3838b9=_0x164f5c['length']?_0x164f5c['join'](','):'FirebaseCore-web';return _0x4bde1c+'/JsCore/'+ct+'/'+_0x3838b9;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x380492){this['auth']=_0x380492,this['queue']=[];}['pushCallback'](_0x2cf0de,_0x1fc52f){const _0x5ad4c6=_0x316f1d=>new Promise((_0x21ff5d,_0x3e8a56)=>{try{const _0x3ea612=_0x2cf0de(_0x316f1d);_0x21ff5d(_0x3ea612);}catch(_0x1eec4f){_0x3e8a56(_0x1eec4f);}});_0x5ad4c6['onAbort']=_0x1fc52f,this['queue']['push'](_0x5ad4c6);const _0x3a8347=this['queue']['length']-0x1;return()=>{this['queue'][_0x3a8347]=()=>Promise['resolve']();};}async['runMiddleware'](_0x284230){if(this['auth']['currentUser']===_0x284230)return;const _0x10fbc6=[];try{for(const _0x33bf49 of this['queue'])await _0x33bf49(_0x284230),_0x33bf49['onAbort']&&_0x10fbc6['push'](_0x33bf49['onAbort']);}catch(_0x14ada0){_0x10fbc6['reverse']();for(const _0x1f1845 of _0x10fbc6)try{_0x1f1845();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x14ada0==null?void 0x0:_0x14ada0['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5ede84,_0xb2e111={}){return Ae(_0x5ede84,'GET','/v2/passwordPolicy',Re(_0x5ede84,_0xb2e111));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x4a3d00){var _0xc83799;const _0x4af0a4=_0x4a3d00['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4af0a4['minPasswordLength']??Tf,_0x4af0a4['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4af0a4['maxPasswordLength']),_0x4af0a4['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4af0a4['containsLowercaseCharacter']),_0x4af0a4['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4af0a4['containsUppercaseCharacter']),_0x4af0a4['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4af0a4['containsNumericCharacter']),_0x4af0a4['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4af0a4['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4a3d00['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xc83799=_0x4a3d00['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xc83799['join'](''))??'',this['forceUpgradeOnSignin']=_0x4a3d00['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4a3d00['schemaVersion'];}['validatePassword'](_0x4632a9){const _0xdab47d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4632a9,_0xdab47d),this['validatePasswordCharacterOptions'](_0x4632a9,_0xdab47d),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['meetsMinPasswordLength']??!0x0),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['meetsMaxPasswordLength']??!0x0),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['containsLowercaseLetter']??!0x0),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['containsUppercaseLetter']??!0x0),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['containsNumericCharacter']??!0x0),_0xdab47d['isValid']&&(_0xdab47d['isValid']=_0xdab47d['containsNonAlphanumericCharacter']??!0x0),_0xdab47d;}['validatePasswordLengthOptions'](_0xaac305,_0x375f42){const _0x5c724b=this['customStrengthOptions']['minPasswordLength'],_0x364af3=this['customStrengthOptions']['maxPasswordLength'];_0x5c724b&&(_0x375f42['meetsMinPasswordLength']=_0xaac305['length']>=_0x5c724b),_0x364af3&&(_0x375f42['meetsMaxPasswordLength']=_0xaac305['length']<=_0x364af3);}['validatePasswordCharacterOptions'](_0x548e8a,_0x1685ca){this['updatePasswordCharacterOptionsStatuses'](_0x1685ca,!0x1,!0x1,!0x1,!0x1);let _0x3fe199;for(let _0x9341dd=0x0;_0x9341dd<_0x548e8a['length'];_0x9341dd++)_0x3fe199=_0x548e8a['charAt'](_0x9341dd),this['updatePasswordCharacterOptionsStatuses'](_0x1685ca,_0x3fe199>='a'&&_0x3fe199<='z',_0x3fe199>='A'&&_0x3fe199<='Z',_0x3fe199>='0'&&_0x3fe199<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3fe199));}['updatePasswordCharacterOptionsStatuses'](_0x4ffea6,_0x291d38,_0x5b004f,_0x3fcbf4,_0x583fdf){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4ffea6['containsLowercaseLetter']||(_0x4ffea6['containsLowercaseLetter']=_0x291d38)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4ffea6['containsUppercaseLetter']||(_0x4ffea6['containsUppercaseLetter']=_0x5b004f)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4ffea6['containsNumericCharacter']||(_0x4ffea6['containsNumericCharacter']=_0x3fcbf4)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4ffea6['containsNonAlphanumericCharacter']||(_0x4ffea6['containsNonAlphanumericCharacter']=_0x583fdf));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x208470,_0x1b0726,_0x4d2f05,_0x57949c){this['app']=_0x208470,this['heartbeatServiceProvider']=_0x1b0726,this['appCheckServiceProvider']=_0x4d2f05,this['config']=_0x57949c,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x208470['name'],this['clientVersion']=_0x57949c['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1a2b59=>this['_resolvePersistenceManagerAvailable']=_0x1a2b59);}['_initializeWithPersistence'](_0xab4d0,_0x31cd38){return _0x31cd38&&(this['_popupRedirectResolver']=ne(_0x31cd38)),this['_initializationPromise']=this['queue'](async()=>{var _0x3df4cd,_0x1c8120,_0x1516eb;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0xab4d0),(_0x3df4cd=this['_resolvePersistenceManagerAvailable'])==null||_0x3df4cd['call'](this),!this['_deleted'])){if((_0x1c8120=this['_popupRedirectResolver'])!=null&&_0x1c8120['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x31cd38),this['lastNotifiedUid']=((_0x1516eb=this['currentUser'])==null?void 0x0:_0x1516eb['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2ac7be=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2ac7be)){if(this['currentUser']&&_0x2ac7be&&this['currentUser']['uid']===_0x2ac7be['uid']){this['_currentUser']['_assign'](_0x2ac7be),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2ac7be,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x379b98){try{const _0x21e25c=await Sn(this,{'idToken':_0x379b98}),_0x4bfd11=await z['_fromGetAccountInfoResponse'](this,_0x21e25c,_0x379b98);await this['directlySetCurrentUser'](_0x4bfd11);}catch(_0x1f88ea){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1f88ea),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1a5f0c){var _0x126758;if(H(this['app'])){const _0x2bc669=this['app']['settings']['authIdToken'];return _0x2bc669?new Promise(_0xe057fe=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2bc669)['then'](_0xe057fe,_0xe057fe));}):this['directlySetCurrentUser'](null);}const _0x4b403c=await this['assertedPersistence']['getCurrentUser']();let _0x95ca8a=_0x4b403c,_0x3e2d98=!0x1;if(_0x1a5f0c&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x46e92d=(_0x126758=this['redirectUser'])==null?void 0x0:_0x126758['_redirectEventId'],_0x2f3993=_0x95ca8a==null?void 0x0:_0x95ca8a['_redirectEventId'],_0x44ab4f=await this['tryRedirectSignIn'](_0x1a5f0c);(!_0x46e92d||_0x46e92d===_0x2f3993)&&(_0x44ab4f!=null&&_0x44ab4f['user'])&&(_0x95ca8a=_0x44ab4f['user'],_0x3e2d98=!0x0);}if(!_0x95ca8a)return this['directlySetCurrentUser'](null);if(!_0x95ca8a['_redirectEventId']){if(_0x3e2d98)try{await this['beforeStateQueue']['runMiddleware'](_0x95ca8a);}catch(_0x4087ed){_0x95ca8a=_0x4b403c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4087ed));}return _0x95ca8a?this['reloadAndSetCurrentUserOrClear'](_0x95ca8a):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x95ca8a['_redirectEventId']?this['directlySetCurrentUser'](_0x95ca8a):this['reloadAndSetCurrentUserOrClear'](_0x95ca8a);}async['tryRedirectSignIn'](_0x887295){let _0x154059=null;try{_0x154059=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x887295,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x154059;}async['reloadAndSetCurrentUserOrClear'](_0x12c217){try{await bn(_0x12c217);}catch(_0x4540e2){if((_0x4540e2==null?void 0x0:_0x4540e2['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x12c217);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3a6eff){if(H(this['app']))return Promise['reject'](se(this));const _0x2046d6=_0x3a6eff?k(_0x3a6eff):null;return _0x2046d6&&m(_0x2046d6['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2046d6&&_0x2046d6['_clone'](this));}async['_updateCurrentUser'](_0x1f952d,_0x5a4218=!0x1){if(!this['_deleted'])return _0x1f952d&&m(this['tenantId']===_0x1f952d['tenantId'],this,'tenant-id-mismatch'),_0x5a4218||await this['beforeStateQueue']['runMiddleware'](_0x1f952d),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1f952d),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xd86cfd){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xd86cfd));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x22a2f4){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4e510e=this['_getPasswordPolicyInternal']();return _0x4e510e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4e510e['validatePassword'](_0x22a2f4);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x469080=await Cf(this),_0x41da9e=new Sf(_0x469080);this['tenantId']===null?this['_projectPasswordPolicy']=_0x41da9e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x41da9e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x598c62){this['_errorFactory']=new Ut('auth','Firebase',_0x598c62());}['onAuthStateChanged'](_0x4b3133,_0x2e90ef,_0x3ba46e){return this['registerStateListener'](this['authStateSubscription'],_0x4b3133,_0x2e90ef,_0x3ba46e);}['beforeAuthStateChanged'](_0x768acf,_0x296137){return this['beforeStateQueue']['pushCallback'](_0x768acf,_0x296137);}['onIdTokenChanged'](_0x53dba2,_0x1cb837,_0x301a3f){return this['registerStateListener'](this['idTokenSubscription'],_0x53dba2,_0x1cb837,_0x301a3f);}['authStateReady'](){return new Promise((_0x5e5f07,_0x4ed8d2)=>{if(this['currentUser'])_0x5e5f07();else{const _0x19bc17=this['onAuthStateChanged'](()=>{_0x19bc17(),_0x5e5f07();},_0x4ed8d2);}});}async['revokeAccessToken'](_0x37d153){if(this['currentUser']){const _0x1e9513=await this['currentUser']['getIdToken'](),_0x5ac142={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x37d153,'idToken':_0x1e9513};this['tenantId']!=null&&(_0x5ac142['tenantId']=this['tenantId']),await vf(this,_0x5ac142);}}['toJSON'](){var _0x25730c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x25730c=this['_currentUser'])==null?void 0x0:_0x25730c['toJSON']()};}async['_setRedirectUser'](_0x3f296e,_0x430cdf){const _0x4f091d=await this['getOrInitRedirectPersistenceManager'](_0x430cdf);return _0x3f296e===null?_0x4f091d['removeCurrentUser']():_0x4f091d['setCurrentUser'](_0x3f296e);}async['getOrInitRedirectPersistenceManager'](_0x52237b){if(!this['redirectPersistenceManager']){const _0x28c4ca=_0x52237b&&ne(_0x52237b)||this['_popupRedirectResolver'];m(_0x28c4ca,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x28c4ca['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x41cefa){var _0x55b1d2,_0xca083;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x55b1d2=this['_currentUser'])==null?void 0x0:_0x55b1d2['_redirectEventId'])===_0x41cefa?this['_currentUser']:((_0xca083=this['redirectUser'])==null?void 0x0:_0xca083['_redirectEventId'])===_0x41cefa?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x349a2c){if(_0x349a2c===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x349a2c));}['_notifyListenersIfCurrent'](_0x3ce518){_0x3ce518===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5f09d6;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x226469=((_0x5f09d6=this['currentUser'])==null?void 0x0:_0x5f09d6['uid'])??null;this['lastNotifiedUid']!==_0x226469&&(this['lastNotifiedUid']=_0x226469,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1b28f1,_0x281e27,_0x13f27a,_0x1c60e8){if(this['_deleted'])return()=>{};const _0x15a930=typeof _0x281e27=='function'?_0x281e27:_0x281e27['next']['bind'](_0x281e27);let _0x248d74=!0x1;const _0xd9ad0c=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xd9ad0c,this,'internal-error'),_0xd9ad0c['then'](()=>{_0x248d74||_0x15a930(this['currentUser']);}),typeof _0x281e27=='function'){const _0x3b45f7=_0x1b28f1['addObserver'](_0x281e27,_0x13f27a,_0x1c60e8);return()=>{_0x248d74=!0x0,_0x3b45f7();};}else{const _0x1ed6b3=_0x1b28f1['addObserver'](_0x281e27);return()=>{_0x248d74=!0x0,_0x1ed6b3();};}}async['directlySetCurrentUser'](_0x5c811b){this['currentUser']&&this['currentUser']!==_0x5c811b&&this['_currentUser']['_stopProactiveRefresh'](),_0x5c811b&&this['isProactiveRefreshEnabled']&&_0x5c811b['_startProactiveRefresh'](),this['currentUser']=_0x5c811b,_0x5c811b?await this['assertedPersistence']['setCurrentUser'](_0x5c811b):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1bd913){return this['operations']=this['operations']['then'](_0x1bd913,_0x1bd913),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4a459c){!_0x4a459c||this['frameworks']['includes'](_0x4a459c)||(this['frameworks']['push'](_0x4a459c),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2d5e67;const _0x23e30d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x23e30d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4468dc=await((_0x2d5e67=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2d5e67['getHeartbeatsHeader']());_0x4468dc&&(_0x23e30d['X-Firebase-Client']=_0x4468dc);const _0x5d725e=await this['_getAppCheckToken']();return _0x5d725e&&(_0x23e30d['X-Firebase-AppCheck']=_0x5d725e),_0x23e30d;}async['_getAppCheckToken'](){var _0x5c23ee;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2084e6=await((_0x5c23ee=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5c23ee['getToken']());return _0x2084e6!=null&&_0x2084e6['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2084e6['error']),_0x2084e6==null?void 0x0:_0x2084e6['token'];}}function qe(_0x4525de){return k(_0x4525de);}class Tr{constructor(_0x3f23ef){this['auth']=_0x3f23ef,this['observer']=null,this['addObserver']=Ic(_0x29eccd=>this['observer']=_0x29eccd);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x4c54c5){zn=_0x4c54c5;}function Da(_0x1416a9){return zn['loadJS'](_0x1416a9);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x139a91){return'__'+_0x139a91+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x352948){_0x352948();}['execute'](_0x1ae802,_0x5da43a){return Promise['resolve']('token');}['render'](_0x22b9e8,_0x1f6081){return'';}}class Of{['ready'](_0x21c4ff){_0x21c4ff();}['execute'](_0x48985d,_0x3b4eac){return Promise['resolve']('token');}['render'](_0x540edb,_0xa9a744){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x3cab73){this['type']=Df,this['auth']=qe(_0x3cab73);}async['verify'](_0x394fb3='verify',_0x3f35c4=!0x1){async function _0x4c4fcc(_0x4650c3){if(!_0x3f35c4){if(_0x4650c3['tenantId']==null&&_0x4650c3['_agentRecaptchaConfig']!=null)return _0x4650c3['_agentRecaptchaConfig']['siteKey'];if(_0x4650c3['tenantId']!=null&&_0x4650c3['_tenantRecaptchaConfigs'][_0x4650c3['tenantId']]!==void 0x0)return _0x4650c3['_tenantRecaptchaConfigs'][_0x4650c3['tenantId']]['siteKey'];}return new Promise(async(_0x48c3a4,_0x259ea0)=>{uf(_0x4650c3,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x379131=>{if(_0x379131['recaptchaKey']===void 0x0)_0x259ea0(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x50aba0=new hf(_0x379131);return _0x4650c3['tenantId']==null?_0x4650c3['_agentRecaptchaConfig']=_0x50aba0:_0x4650c3['_tenantRecaptchaConfigs'][_0x4650c3['tenantId']]=_0x50aba0,_0x48c3a4(_0x50aba0['siteKey']);}})['catch'](_0x3a08a3=>{_0x259ea0(_0x3a08a3);});});}function _0x744a4d(_0x3507ac,_0x182d8c,_0x5d4ff5){const _0x1e318d=window['grecaptcha'];vr(_0x1e318d)?_0x1e318d['enterprise']['ready'](()=>{_0x1e318d['enterprise']['execute'](_0x3507ac,{'action':_0x394fb3})['then'](_0x409245=>{_0x182d8c(_0x409245);})['catch'](()=>{_0x182d8c(Ma);});}):_0x5d4ff5(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3772a4,_0x100034)=>{_0x4c4fcc(this['auth'])['then'](async _0x21212f=>{if(!_0x3f35c4&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x744a4d(_0x21212f,_0x3772a4,_0x100034);else{if(typeof window>'u'){_0x100034(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x47fec4=Af();_0x47fec4['length']!==0x0&&(_0x47fec4+=_0x21212f+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x48e972;(_0x48e972=le['scriptInjectionDeferred'])==null||_0x48e972['resolve']();},Da(_0x47fec4)['then'](()=>{var _0x3f92b1;return(_0x3f92b1=le['scriptInjectionDeferred'])==null?void 0x0:_0x3f92b1['promise'];})['then'](()=>{_0x744a4d(_0x21212f,_0x3772a4,_0x100034);})['catch'](_0x1477cf=>{_0x100034(_0x1477cf);});}})['catch'](_0x3881b1=>{_0x100034(_0x3881b1);});});}}le['scriptInjectionDeferred']=null;async function br(_0x24ba2a,_0x565c52,_0x147ba5,_0x38f606=!0x1,_0x41b832=!0x1){const _0x56dd13=new le(_0x24ba2a);let _0x1a5ce6;if(_0x41b832)_0x1a5ce6=Ma;else try{_0x1a5ce6=await _0x56dd13['verify'](_0x147ba5);}catch{_0x1a5ce6=await _0x56dd13['verify'](_0x147ba5,!0x0);}const _0x518b2f={..._0x565c52};if(_0x147ba5==='mfaSmsEnrollment'||_0x147ba5==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x518b2f){const _0x89c9f3=_0x518b2f['phoneEnrollmentInfo']['phoneNumber'],_0x18f79a=_0x518b2f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x518b2f,{'phoneEnrollmentInfo':{'phoneNumber':_0x89c9f3,'recaptchaToken':_0x18f79a,'captchaResponse':_0x1a5ce6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x518b2f){const _0x2d19ad=_0x518b2f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x518b2f,{'phoneSignInInfo':{'recaptchaToken':_0x2d19ad,'captchaResponse':_0x1a5ce6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x518b2f;}return _0x38f606?Object['assign'](_0x518b2f,{'captchaResp':_0x1a5ce6}):Object['assign'](_0x518b2f,{'captchaResponse':_0x1a5ce6}),Object['assign'](_0x518b2f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x518b2f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x518b2f;}async function Oi(_0x1554a5,_0x243f51,_0x4d72be,_0x1c670b,_0x3104a){var _0x2432d1;if((_0x2432d1=_0x1554a5['_getRecaptchaConfig']())!=null&&_0x2432d1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4abc42=await br(_0x1554a5,_0x243f51,_0x4d72be,_0x4d72be==='getOobCode');return _0x1c670b(_0x1554a5,_0x4abc42);}else return _0x1c670b(_0x1554a5,_0x243f51)['catch'](async _0x2f4363=>{if(_0x2f4363['code']==='auth/missing-recaptcha-token'){console['log'](_0x4d72be+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2d8276=await br(_0x1554a5,_0x243f51,_0x4d72be,_0x4d72be==='getOobCode');return _0x1c670b(_0x1554a5,_0x2d8276);}else return Promise['reject'](_0x2f4363);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x28ffcb,_0x37efcc){const _0x99eeec=Ui(_0x28ffcb,'auth');if(_0x99eeec['isInitialized']()){const _0x3b2616=_0x99eeec['getImmediate'](),_0x114b0d=_0x99eeec['getOptions']();if(De(_0x114b0d,_0x37efcc??{}))return _0x3b2616;K(_0x3b2616,'already-initialized');}return _0x99eeec['initialize']({'options':_0x37efcc});}function Lf(_0x237977,_0x34b777){const _0x1bd94d=(_0x34b777==null?void 0x0:_0x34b777['persistence'])||[],_0x34492c=(Array['isArray'](_0x1bd94d)?_0x1bd94d:[_0x1bd94d])['map'](ne);_0x34b777!=null&&_0x34b777['errorMap']&&_0x237977['_updateErrorMap'](_0x34b777['errorMap']),_0x237977['_initializeWithPersistence'](_0x34492c,_0x34b777==null?void 0x0:_0x34b777['popupRedirectResolver']);}function xf(_0x4565ba,_0x4e2bbc,_0x35678f){const _0x2cc886=qe(_0x4565ba);m(/^https?:\/\//['test'](_0x4e2bbc),_0x2cc886,'invalid-emulator-scheme');const _0x14825f=!0x1,_0x5042cb=La(_0x4e2bbc),{host:_0x41950,port:_0x199793}=Ff(_0x4e2bbc),_0x2e3597=_0x199793===null?'':':'+_0x199793,_0x8228e8={'url':_0x5042cb+'//'+_0x41950+_0x2e3597+'/'},_0x120b53=Object['freeze']({'host':_0x41950,'port':_0x199793,'protocol':_0x5042cb['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x14825f})});if(!_0x2cc886['_canInitEmulator']){m(_0x2cc886['config']['emulator']&&_0x2cc886['emulatorConfig'],_0x2cc886,'emulator-config-failed'),m(De(_0x8228e8,_0x2cc886['config']['emulator'])&&De(_0x120b53,_0x2cc886['emulatorConfig']),_0x2cc886,'emulator-config-failed');return;}_0x2cc886['config']['emulator']=_0x8228e8,_0x2cc886['emulatorConfig']=_0x120b53,_0x2cc886['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x41950)?jr(_0x5042cb+'//'+_0x41950+_0x2e3597):Uf();}function La(_0xf57ef1){const _0x3095b6=_0xf57ef1['indexOf'](':');return _0x3095b6<0x0?'':_0xf57ef1['substr'](0x0,_0x3095b6+0x1);}function Ff(_0x6cd5ec){const _0x39172a=La(_0x6cd5ec),_0x12d948=/(\/\/)?([^?#/]+)/['exec'](_0x6cd5ec['substr'](_0x39172a['length']));if(!_0x12d948)return{'host':'','port':null};const _0x1fa0d1=_0x12d948[0x2]['split']('@')['pop']()||'',_0x17bbb0=/^(\[[^\]]+\])(:|$)/['exec'](_0x1fa0d1);if(_0x17bbb0){const _0x4a917d=_0x17bbb0[0x1];return{'host':_0x4a917d,'port':Rr(_0x1fa0d1['substr'](_0x4a917d['length']+0x1))};}else{const [_0x5d449b,_0x9ebc7a]=_0x1fa0d1['split'](':');return{'host':_0x5d449b,'port':Rr(_0x9ebc7a)};}}function Rr(_0x519efe){if(!_0x519efe)return null;const _0x397c06=Number(_0x519efe);return isNaN(_0x397c06)?null:_0x397c06;}function Uf(){function _0x58b4f1(){const _0x525805=document['createElement']('p'),_0x334f90=_0x525805['style'];_0x525805['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x334f90['position']='fixed',_0x334f90['width']='100%',_0x334f90['backgroundColor']='#ffffff',_0x334f90['border']='.1em\x20solid\x20#000000',_0x334f90['color']='#b50000',_0x334f90['bottom']='0px',_0x334f90['left']='0px',_0x334f90['margin']='0px',_0x334f90['zIndex']='10000',_0x334f90['textAlign']='center',_0x525805['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x525805);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x58b4f1):_0x58b4f1());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x42fae3,_0xc9fe2){this['providerId']=_0x42fae3,this['signInMethod']=_0xc9fe2;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x428a2f){return te('not\x20implemented');}['_linkToIdToken'](_0x2cfd00,_0x3dfcb3){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1a6a2e){return te('not\x20implemented');}}async function Wf(_0x27f8e2,_0x4183c3){return Ae(_0x27f8e2,'POST','/v1/accounts:signUp',_0x4183c3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x4500ab,_0x1f267a){return Yt(_0x4500ab,'POST','/v1/accounts:signInWithPassword',Re(_0x4500ab,_0x1f267a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x5eb5b2,_0x36edfb){return Yt(_0x5eb5b2,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5eb5b2,_0x36edfb));}async function Hf(_0x1007ca,_0xb2dbb8){return Yt(_0x1007ca,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1007ca,_0xb2dbb8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x52ac82,_0x59d77d,_0x4d383d,_0x52969b=null){super('password',_0x4d383d),this['_email']=_0x52ac82,this['_password']=_0x59d77d,this['_tenantId']=_0x52969b;}static['_fromEmailAndPassword'](_0x127588,_0x43aba3){return new Ft(_0x127588,_0x43aba3,'password');}static['_fromEmailAndCode'](_0x503aed,_0x474c51,_0x930152=null){return new Ft(_0x503aed,_0x474c51,'emailLink',_0x930152);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2af86b){const _0x9afdfc=typeof _0x2af86b=='string'?JSON['parse'](_0x2af86b):_0x2af86b;if(_0x9afdfc!=null&&_0x9afdfc['email']&&(_0x9afdfc!=null&&_0x9afdfc['password'])){if(_0x9afdfc['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x9afdfc['email'],_0x9afdfc['password']);if(_0x9afdfc['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x9afdfc['email'],_0x9afdfc['password'],_0x9afdfc['tenantId']);}return null;}async['_getIdTokenResponse'](_0x133aa3){switch(this['signInMethod']){case'password':const _0x1f27bb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x133aa3,_0x1f27bb,'signInWithPassword',Bf);case'emailLink':return Vf(_0x133aa3,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x133aa3,'internal-error');}}async['_linkToIdToken'](_0x329db2,_0xa8f5fc){switch(this['signInMethod']){case'password':const _0x3c4f8c={'idToken':_0xa8f5fc,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x329db2,_0x3c4f8c,'signUpPassword',Wf);case'emailLink':return Hf(_0x329db2,{'idToken':_0xa8f5fc,'email':this['_email'],'oobCode':this['_password']});default:K(_0x329db2,'internal-error');}}['_getReauthenticationResolver'](_0x263a9c){return this['_getIdTokenResponse'](_0x263a9c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x19445a,_0x5c25f1){return Yt(_0x19445a,'POST','/v1/accounts:signInWithIdp',Re(_0x19445a,_0x5c25f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x243652){const _0x4b00e8=new We(_0x243652['providerId'],_0x243652['signInMethod']);return _0x243652['idToken']||_0x243652['accessToken']?(_0x243652['idToken']&&(_0x4b00e8['idToken']=_0x243652['idToken']),_0x243652['accessToken']&&(_0x4b00e8['accessToken']=_0x243652['accessToken']),_0x243652['nonce']&&!_0x243652['pendingToken']&&(_0x4b00e8['nonce']=_0x243652['nonce']),_0x243652['pendingToken']&&(_0x4b00e8['pendingToken']=_0x243652['pendingToken'])):_0x243652['oauthToken']&&_0x243652['oauthTokenSecret']?(_0x4b00e8['accessToken']=_0x243652['oauthToken'],_0x4b00e8['secret']=_0x243652['oauthTokenSecret']):K('argument-error'),_0x4b00e8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5141bc){const _0x25cf38=typeof _0x5141bc=='string'?JSON['parse'](_0x5141bc):_0x5141bc,{providerId:_0x874e44,signInMethod:_0x21b963,..._0x1149f9}=_0x25cf38;if(!_0x874e44||!_0x21b963)return null;const _0xf710c1=new We(_0x874e44,_0x21b963);return _0xf710c1['idToken']=_0x1149f9['idToken']||void 0x0,_0xf710c1['accessToken']=_0x1149f9['accessToken']||void 0x0,_0xf710c1['secret']=_0x1149f9['secret'],_0xf710c1['nonce']=_0x1149f9['nonce'],_0xf710c1['pendingToken']=_0x1149f9['pendingToken']||null,_0xf710c1;}['_getIdTokenResponse'](_0x2a59e2){const _0xc2ce6a=this['buildRequest']();return Ze(_0x2a59e2,_0xc2ce6a);}['_linkToIdToken'](_0x242c8e,_0x4f4fe2){const _0x316be1=this['buildRequest']();return _0x316be1['idToken']=_0x4f4fe2,Ze(_0x242c8e,_0x316be1);}['_getReauthenticationResolver'](_0x354737){const _0x4f2c45=this['buildRequest']();return _0x4f2c45['autoCreate']=!0x1,Ze(_0x354737,_0x4f2c45);}['buildRequest'](){const _0x341e97={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x341e97['pendingToken']=this['pendingToken'];else{const _0xa8cb2b={};this['idToken']&&(_0xa8cb2b['id_token']=this['idToken']),this['accessToken']&&(_0xa8cb2b['access_token']=this['accessToken']),this['secret']&&(_0xa8cb2b['oauth_token_secret']=this['secret']),_0xa8cb2b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xa8cb2b['nonce']=this['nonce']),_0x341e97['postBody']=at(_0xa8cb2b);}return _0x341e97;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x32b13a){switch(_0x32b13a){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x4a2255){const _0x4c64df=yt(vt(_0x4a2255))['link'],_0x2eb767=_0x4c64df?yt(vt(_0x4c64df))['deep_link_id']:null,_0x2fa26d=yt(vt(_0x4a2255))['deep_link_id'];return(_0x2fa26d?yt(vt(_0x2fa26d))['link']:null)||_0x2fa26d||_0x2eb767||_0x4c64df||_0x4a2255;}class Ss{constructor(_0x5a3d01){const _0x29f67c=yt(vt(_0x5a3d01)),_0x454dab=_0x29f67c['apiKey']??null,_0xb13a05=_0x29f67c['oobCode']??null,_0x582e4e=Gf(_0x29f67c['mode']??null);m(_0x454dab&&_0xb13a05&&_0x582e4e,'argument-error'),this['apiKey']=_0x454dab,this['operation']=_0x582e4e,this['code']=_0xb13a05,this['continueUrl']=_0x29f67c['continueUrl']??null,this['languageCode']=_0x29f67c['lang']??null,this['tenantId']=_0x29f67c['tenantId']??null;}static['parseLink'](_0x6c0e93){const _0x505b02=qf(_0x6c0e93);try{return new Ss(_0x505b02);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x2d8e39,_0x4f82c9){return Ft['_fromEmailAndPassword'](_0x2d8e39,_0x4f82c9);}static['credentialWithLink'](_0x3d7878,_0xd02d8e){const _0x385bc9=Ss['parseLink'](_0xd02d8e);return m(_0x385bc9,'argument-error'),Ft['_fromEmailAndCode'](_0x3d7878,_0x385bc9['code'],_0x385bc9['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x10ad46){this['providerId']=_0x10ad46,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3cefca){this['defaultLanguageCode']=_0x3cefca;}['setCustomParameters'](_0xc3b65b){return this['customParameters']=_0xc3b65b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x496d0c){return this['scopes']['includes'](_0x496d0c)||this['scopes']['push'](_0x496d0c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x47b4b8){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x47b4b8});}static['credentialFromResult'](_0x307a37){return he['credentialFromTaggedObject'](_0x307a37);}static['credentialFromError'](_0x4a11c8){return he['credentialFromTaggedObject'](_0x4a11c8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x143d45}){if(!_0x143d45||!('oauthAccessToken'in _0x143d45)||!_0x143d45['oauthAccessToken'])return null;try{return he['credential'](_0x143d45['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3112d7,_0x22bb81){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3112d7,'accessToken':_0x22bb81});}static['credentialFromResult'](_0x54f3d9){return ue['credentialFromTaggedObject'](_0x54f3d9);}static['credentialFromError'](_0x4c3e4d){return ue['credentialFromTaggedObject'](_0x4c3e4d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4c08c0}){if(!_0x4c08c0)return null;const {oauthIdToken:_0x447acb,oauthAccessToken:_0x1c30b5}=_0x4c08c0;if(!_0x447acb&&!_0x1c30b5)return null;try{return ue['credential'](_0x447acb,_0x1c30b5);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x4c0ec0){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4c0ec0});}static['credentialFromResult'](_0xc1f89c){return de['credentialFromTaggedObject'](_0xc1f89c);}static['credentialFromError'](_0x453ac6){return de['credentialFromTaggedObject'](_0x453ac6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ab02c}){if(!_0x1ab02c||!('oauthAccessToken'in _0x1ab02c)||!_0x1ab02c['oauthAccessToken'])return null;try{return de['credential'](_0x1ab02c['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4a29d1,_0x216896){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4a29d1,'oauthTokenSecret':_0x216896});}static['credentialFromResult'](_0xa65b9f){return fe['credentialFromTaggedObject'](_0xa65b9f);}static['credentialFromError'](_0x17b331){return fe['credentialFromTaggedObject'](_0x17b331['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22b140}){if(!_0x22b140)return null;const {oauthAccessToken:_0x5e7d86,oauthTokenSecret:_0x176ee5}=_0x22b140;if(!_0x5e7d86||!_0x176ee5)return null;try{return fe['credential'](_0x5e7d86,_0x176ee5);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x5a990a,_0x3d7741){return Yt(_0x5a990a,'POST','/v1/accounts:signUp',Re(_0x5a990a,_0x3d7741));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x258dad){this['user']=_0x258dad['user'],this['providerId']=_0x258dad['providerId'],this['_tokenResponse']=_0x258dad['_tokenResponse'],this['operationType']=_0x258dad['operationType'];}static async['_fromIdTokenResponse'](_0x54f47d,_0x5f079d,_0xb192f0,_0x3433ca=!0x1){const _0x419613=await z['_fromIdTokenResponse'](_0x54f47d,_0xb192f0,_0x3433ca),_0x35ae1b=Ar(_0xb192f0);return new Be({'user':_0x419613,'providerId':_0x35ae1b,'_tokenResponse':_0xb192f0,'operationType':_0x5f079d});}static async['_forOperation'](_0x528dff,_0x54bbd1,_0x4a3abb){await _0x528dff['_updateTokensIfNecessary'](_0x4a3abb,!0x0);const _0x431c22=Ar(_0x4a3abb);return new Be({'user':_0x528dff,'providerId':_0x431c22,'_tokenResponse':_0x4a3abb,'operationType':_0x54bbd1});}}function Ar(_0x91a1e1){return _0x91a1e1['providerId']?_0x91a1e1['providerId']:'phoneNumber'in _0x91a1e1?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0xacf8a3,_0x2494e9,_0x1a91dd,_0x2e134d){super(_0x2494e9['code'],_0x2494e9['message']),this['operationType']=_0x1a91dd,this['user']=_0x2e134d,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0xacf8a3['name'],'tenantId':_0xacf8a3['tenantId']??void 0x0,'_serverResponse':_0x2494e9['customData']['_serverResponse'],'operationType':_0x1a91dd};}static['_fromErrorAndOperation'](_0x2ea5e9,_0x4dd88b,_0x4a0adc,_0x2b2c34){return new Rn(_0x2ea5e9,_0x4dd88b,_0x4a0adc,_0x2b2c34);}}function Fa(_0x2e2e4d,_0x4a9894,_0x3ca79b,_0x21bfad){return(_0x4a9894==='reauthenticate'?_0x3ca79b['_getReauthenticationResolver'](_0x2e2e4d):_0x3ca79b['_getIdTokenResponse'](_0x2e2e4d))['catch'](_0x4452fe=>{throw _0x4452fe['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x2e2e4d,_0x4452fe,_0x4a9894,_0x21bfad):_0x4452fe;});}async function jf(_0x38b474,_0x49a94f,_0x4786ee=!0x1){const _0x193b8b=await xt(_0x38b474,_0x49a94f['_linkToIdToken'](_0x38b474['auth'],await _0x38b474['getIdToken']()),_0x4786ee);return Be['_forOperation'](_0x38b474,'link',_0x193b8b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2d7efd,_0x2720da,_0x461e91=!0x1){const {auth:_0xef6163}=_0x2d7efd;if(H(_0xef6163['app']))return Promise['reject'](se(_0xef6163));const _0x3c72c3='reauthenticate';try{const _0xa354cb=await xt(_0x2d7efd,Fa(_0xef6163,_0x3c72c3,_0x2720da,_0x2d7efd),_0x461e91);m(_0xa354cb['idToken'],_0xef6163,'internal-error');const _0x141aac=ws(_0xa354cb['idToken']);m(_0x141aac,_0xef6163,'internal-error');const {sub:_0x6d8cf1}=_0x141aac;return m(_0x2d7efd['uid']===_0x6d8cf1,_0xef6163,'user-mismatch'),Be['_forOperation'](_0x2d7efd,_0x3c72c3,_0xa354cb);}catch(_0x58355f){throw(_0x58355f==null?void 0x0:_0x58355f['code'])==='auth/user-not-found'&&K(_0xef6163,'user-mismatch'),_0x58355f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0xe1ad3d,_0x27f4e2,_0x587391=!0x1){if(H(_0xe1ad3d['app']))return Promise['reject'](se(_0xe1ad3d));const _0xf9865='signIn',_0x110e75=await Fa(_0xe1ad3d,_0xf9865,_0x27f4e2),_0x491dd4=await Be['_fromIdTokenResponse'](_0xe1ad3d,_0xf9865,_0x110e75);return _0x587391||await _0xe1ad3d['_updateCurrentUser'](_0x491dd4['user']),_0x491dd4;}async function Yf(_0x335b98,_0x92150e){return Ua(qe(_0x335b98),_0x92150e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x31e6b1){const _0x53d929=qe(_0x31e6b1);_0x53d929['_getPasswordPolicyInternal']()&&await _0x53d929['_updatePasswordPolicy']();}async function R_(_0x1f9d5c,_0x6a66b1,_0x23cede){if(H(_0x1f9d5c['app']))return Promise['reject'](se(_0x1f9d5c));const _0x1d94cd=qe(_0x1f9d5c),_0x3421f5=await Oi(_0x1d94cd,{'returnSecureToken':!0x0,'email':_0x6a66b1,'password':_0x23cede,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x4f29bc=>{throw _0x4f29bc['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x1f9d5c),_0x4f29bc;}),_0x51462f=await Be['_fromIdTokenResponse'](_0x1d94cd,'signIn',_0x3421f5);return await _0x1d94cd['_updateCurrentUser'](_0x51462f['user']),_0x51462f;}function A_(_0x27a223,_0x148fb1,_0x36444a){return H(_0x27a223['app'])?Promise['reject'](se(_0x27a223)):Yf(k(_0x27a223),ft['credential'](_0x148fb1,_0x36444a))['catch'](async _0x108ed2=>{throw _0x108ed2['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x27a223),_0x108ed2;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x1cdfce,_0x21e291){return k(_0x1cdfce)['setPersistence'](_0x21e291);}function Qf(_0x10b5c5,_0x33201c,_0x31c55f,_0x3a06b2){return k(_0x10b5c5)['onIdTokenChanged'](_0x33201c,_0x31c55f,_0x3a06b2);}function Jf(_0x520fee,_0x44bf15,_0x59f950){return k(_0x520fee)['beforeAuthStateChanged'](_0x44bf15,_0x59f950);}function N_(_0x4d7452,_0x17a5fd,_0x2e6eac,_0x52989e){return k(_0x4d7452)['onAuthStateChanged'](_0x17a5fd,_0x2e6eac,_0x52989e);}function P_(_0x134e1d){return k(_0x134e1d)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x170320,_0x560bec){this['storageRetriever']=_0x170320,this['type']=_0x560bec;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x504d70,_0x11bcac){return this['storage']['setItem'](_0x504d70,JSON['stringify'](_0x11bcac)),Promise['resolve']();}['_get'](_0x9b2ed2){const _0x5f0336=this['storage']['getItem'](_0x9b2ed2);return Promise['resolve'](_0x5f0336?JSON['parse'](_0x5f0336):null);}['_remove'](_0x49ff4b){return this['storage']['removeItem'](_0x49ff4b),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2fecc1,_0x165823)=>this['onStorageEvent'](_0x2fecc1,_0x165823),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4ebab7){for(const _0x278049 of Object['keys'](this['listeners'])){const _0x15c45d=this['storage']['getItem'](_0x278049),_0x44d93f=this['localCache'][_0x278049];_0x15c45d!==_0x44d93f&&_0x4ebab7(_0x278049,_0x44d93f,_0x15c45d);}}['onStorageEvent'](_0x1f9410,_0x4fbdb3=!0x1){if(!_0x1f9410['key']){this['forAllChangedKeys']((_0x4f5657,_0xc0a854,_0x1e898b)=>{this['notifyListeners'](_0x4f5657,_0x1e898b);});return;}const _0x3c034a=_0x1f9410['key'];_0x4fbdb3?this['detachListener']():this['stopPolling']();const _0x53c269=()=>{const _0x2c2753=this['storage']['getItem'](_0x3c034a);!_0x4fbdb3&&this['localCache'][_0x3c034a]===_0x2c2753||this['notifyListeners'](_0x3c034a,_0x2c2753);},_0x5da611=this['storage']['getItem'](_0x3c034a);If()&&_0x5da611!==_0x1f9410['newValue']&&_0x1f9410['newValue']!==_0x1f9410['oldValue']?setTimeout(_0x53c269,Zf):_0x53c269();}['notifyListeners'](_0x7f3eaa,_0x15b4ca){this['localCache'][_0x7f3eaa]=_0x15b4ca;const _0x3c7578=this['listeners'][_0x7f3eaa];if(_0x3c7578){for(const _0x53a04d of Array['from'](_0x3c7578))_0x53a04d(_0x15b4ca&&JSON['parse'](_0x15b4ca));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4f16cf,_0x23ba9e,_0x5b3c1a)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4f16cf,'oldValue':_0x23ba9e,'newValue':_0x5b3c1a}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x302afb,_0x5e37cc){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x302afb]||(this['listeners'][_0x302afb]=new Set(),this['localCache'][_0x302afb]=this['storage']['getItem'](_0x302afb)),this['listeners'][_0x302afb]['add'](_0x5e37cc);}['_removeListener'](_0x1f7b09,_0x363408){this['listeners'][_0x1f7b09]&&(this['listeners'][_0x1f7b09]['delete'](_0x363408),this['listeners'][_0x1f7b09]['size']===0x0&&delete this['listeners'][_0x1f7b09]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2a6d39,_0x496703){await super['_set'](_0x2a6d39,_0x496703),this['localCache'][_0x2a6d39]=JSON['stringify'](_0x496703);}async['_get'](_0x4c84c6){const _0x59490e=await super['_get'](_0x4c84c6);return this['localCache'][_0x4c84c6]=JSON['stringify'](_0x59490e),_0x59490e;}async['_remove'](_0x251d84){await super['_remove'](_0x251d84),delete this['localCache'][_0x251d84];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5499d1,_0xae35ef){}['_removeListener'](_0x6d78be,_0x513f45){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x44c2a4){return Promise['all'](_0x44c2a4['map'](async _0x92d2b0=>{try{return{'fulfilled':!0x0,'value':await _0x92d2b0};}catch(_0x3dd5c9){return{'fulfilled':!0x1,'reason':_0x3dd5c9};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x3dab4f){this['eventTarget']=_0x3dab4f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x28b56e){const _0x3b0d09=this['receivers']['find'](_0x156ea5=>_0x156ea5['isListeningto'](_0x28b56e));if(_0x3b0d09)return _0x3b0d09;const _0x470656=new jn(_0x28b56e);return this['receivers']['push'](_0x470656),_0x470656;}['isListeningto'](_0x166708){return this['eventTarget']===_0x166708;}async['handleEvent'](_0x10283d){const _0x521ae0=_0x10283d,{eventId:_0x11b916,eventType:_0x5bf2ac,data:_0xded263}=_0x521ae0['data'],_0x152bab=this['handlersMap'][_0x5bf2ac];if(!(_0x152bab!=null&&_0x152bab['size']))return;_0x521ae0['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x11b916,'eventType':_0x5bf2ac});const _0x580ccc=Array['from'](_0x152bab)['map'](async _0x2c52fb=>_0x2c52fb(_0x521ae0['origin'],_0xded263)),_0x5477d8=await tp(_0x580ccc);_0x521ae0['ports'][0x0]['postMessage']({'status':'done','eventId':_0x11b916,'eventType':_0x5bf2ac,'response':_0x5477d8});}['_subscribe'](_0x35846f,_0xcc85ad){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x35846f]||(this['handlersMap'][_0x35846f]=new Set()),this['handlersMap'][_0x35846f]['add'](_0xcc85ad);}['_unsubscribe'](_0x2d430f,_0x521333){this['handlersMap'][_0x2d430f]&&_0x521333&&this['handlersMap'][_0x2d430f]['delete'](_0x521333),(!_0x521333||this['handlersMap'][_0x2d430f]['size']===0x0)&&delete this['handlersMap'][_0x2d430f],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0xa1b35d='',_0x2a1b9d=0xa){let _0x704dc2='';for(let _0x49f1dc=0x0;_0x49f1dc<_0x2a1b9d;_0x49f1dc++)_0x704dc2+=Math['floor'](Math['random']()*0xa);return _0xa1b35d+_0x704dc2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x4f77df){this['target']=_0x4f77df,this['handlers']=new Set();}['removeMessageHandler'](_0x3ce358){_0x3ce358['messageChannel']&&(_0x3ce358['messageChannel']['port1']['removeEventListener']('message',_0x3ce358['onMessage']),_0x3ce358['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3ce358);}async['_send'](_0x1dbd24,_0xe52ae6,_0x63fe6f=0x32){const _0x8b25e7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x8b25e7)throw new Error('connection_unavailable');let _0x4b3288,_0x5e7e57;return new Promise((_0x486fa1,_0x200620)=>{const _0x55e365=bs('',0x14);_0x8b25e7['port1']['start']();const _0x15430b=setTimeout(()=>{_0x200620(new Error('unsupported_event'));},_0x63fe6f);_0x5e7e57={'messageChannel':_0x8b25e7,'onMessage'(_0x33f50a){const _0xc4e155=_0x33f50a;if(_0xc4e155['data']['eventId']===_0x55e365)switch(_0xc4e155['data']['status']){case'ack':clearTimeout(_0x15430b),_0x4b3288=setTimeout(()=>{_0x200620(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4b3288),_0x486fa1(_0xc4e155['data']['response']);break;default:clearTimeout(_0x15430b),clearTimeout(_0x4b3288),_0x200620(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x5e7e57),_0x8b25e7['port1']['addEventListener']('message',_0x5e7e57['onMessage']),this['target']['postMessage']({'eventType':_0x1dbd24,'eventId':_0x55e365,'data':_0xe52ae6},[_0x8b25e7['port2']]);})['finally'](()=>{_0x5e7e57&&this['removeMessageHandler'](_0x5e7e57);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x6d1c72){X()['location']['href']=_0x6d1c72;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x550d97;return((_0x550d97=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x550d97['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x3985bf){this['request']=_0x3985bf;}['toPromise'](){return new Promise((_0x31f82d,_0x5c4bd1)=>{this['request']['addEventListener']('success',()=>{_0x31f82d(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x5c4bd1(this['request']['error']);});});}}function Kn(_0x291b1b,_0x3615aa){return _0x291b1b['transaction']([kn],_0x3615aa?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x39dfe7=indexedDB['deleteDatabase'](qa);return new Jt(_0x39dfe7)['toPromise']();}function ja(){const _0x5ccf96=indexedDB['open'](qa,ap);return new Promise((_0x16428a,_0x3e3cff)=>{_0x5ccf96['addEventListener']('error',()=>{_0x3e3cff(_0x5ccf96['error']);}),_0x5ccf96['addEventListener']('upgradeneeded',()=>{const _0x5a387c=_0x5ccf96['result'];try{_0x5a387c['createObjectStore'](kn,{'keyPath':za});}catch(_0x206f4c){_0x3e3cff(_0x206f4c);}}),_0x5ccf96['addEventListener']('success',async()=>{const _0x136409=_0x5ccf96['result'];_0x136409['objectStoreNames']['contains'](kn)?_0x16428a(_0x136409):(_0x136409['close'](),await cp(),_0x16428a(await ja()));});});}async function kr(_0x3eca30,_0x22aaf5,_0x2edd10){const _0x15538b=Kn(_0x3eca30,!0x0)['put']({[za]:_0x22aaf5,'value':_0x2edd10});return new Jt(_0x15538b)['toPromise']();}async function lp(_0x4e73bf,_0x5be4c9){const _0x35c2ba=Kn(_0x4e73bf,!0x1)['get'](_0x5be4c9),_0x30e708=await new Jt(_0x35c2ba)['toPromise']();return _0x30e708===void 0x0?null:_0x30e708['value'];}function Nr(_0x4ee32a,_0x1175bb){const _0x154969=Kn(_0x4ee32a,!0x0)['delete'](_0x1175bb);return new Jt(_0x154969)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5c8329){let _0x59274e=0x0;for(;;)try{const _0x3fe4de=await this['_openDb']();return await _0x5c8329(_0x3fe4de);}catch(_0x1320c4){if(_0x59274e++>up)throw _0x1320c4;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x18e601,_0x44b102)=>({'keyProcessed':(await this['_poll']())['includes'](_0x44b102['key'])})),this['receiver']['_subscribe']('ping',async(_0x3b858e,_0x2c96a3)=>['keyChanged']);}async['initializeSender'](){var _0x4d8f58,_0x14b6a8;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x219dfc=await this['sender']['_send']('ping',{},0x320);_0x219dfc&&(_0x4d8f58=_0x219dfc[0x0])!=null&&_0x4d8f58['fulfilled']&&(_0x14b6a8=_0x219dfc[0x0])!=null&&_0x14b6a8['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5498f1){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5498f1},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x269550=>{await kr(_0x269550,An,'1'),await Nr(_0x269550,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x1913b1){this['pendingWrites']++;try{await _0x1913b1();}finally{this['pendingWrites']--;}}async['_set'](_0x1376ee,_0x5df9f1){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4eae61=>kr(_0x4eae61,_0x1376ee,_0x5df9f1)),this['localCache'][_0x1376ee]=_0x5df9f1,this['notifyServiceWorker'](_0x1376ee)));}async['_get'](_0x27eb1f){const _0x189df9=await this['_withRetries'](_0x325b1a=>lp(_0x325b1a,_0x27eb1f));return this['localCache'][_0x27eb1f]=_0x189df9,_0x189df9;}async['_remove'](_0x4ad9d9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1eb3f2=>Nr(_0x1eb3f2,_0x4ad9d9)),delete this['localCache'][_0x4ad9d9],this['notifyServiceWorker'](_0x4ad9d9)));}async['_poll'](){const _0x1b715c=await this['_withRetries'](_0x111188=>{const _0x493570=Kn(_0x111188,!0x1)['getAll']();return new Jt(_0x493570)['toPromise']();});if(!_0x1b715c)return[];if(this['pendingWrites']!==0x0)return[];const _0x5b0a48=[],_0x34157c=new Set();if(_0x1b715c['length']!==0x0){for(const {fbase_key:_0x2a39a7,value:_0x55bd95}of _0x1b715c)_0x34157c['add'](_0x2a39a7),JSON['stringify'](this['localCache'][_0x2a39a7])!==JSON['stringify'](_0x55bd95)&&(this['notifyListeners'](_0x2a39a7,_0x55bd95),_0x5b0a48['push'](_0x2a39a7));}for(const _0x281a6f of Object['keys'](this['localCache']))this['localCache'][_0x281a6f]&&!_0x34157c['has'](_0x281a6f)&&(this['notifyListeners'](_0x281a6f,null),_0x5b0a48['push'](_0x281a6f));return _0x5b0a48;}['notifyListeners'](_0x10d09e,_0x4fcda3){this['localCache'][_0x10d09e]=_0x4fcda3;const _0x54ee0c=this['listeners'][_0x10d09e];if(_0x54ee0c){for(const _0x33d386 of Array['from'](_0x54ee0c))_0x33d386(_0x4fcda3);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x243d37,_0x1637a7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x243d37]||(this['listeners'][_0x243d37]=new Set(),this['_get'](_0x243d37)),this['listeners'][_0x243d37]['add'](_0x1637a7);}['_removeListener'](_0x2d3d16,_0x2825e8){this['listeners'][_0x2d3d16]&&(this['listeners'][_0x2d3d16]['delete'](_0x2825e8),this['listeners'][_0x2d3d16]['size']===0x0&&delete this['listeners'][_0x2d3d16]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x45be94,_0xce26c3){return _0xce26c3?ne(_0xce26c3):(m(_0x45be94['_popupRedirectResolver'],_0x45be94,'argument-error'),_0x45be94['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x42fa10){super('custom','custom'),this['params']=_0x42fa10;}['_getIdTokenResponse'](_0x3126b1){return Ze(_0x3126b1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x39b366,_0x5f2443){return Ze(_0x39b366,this['_buildIdpRequest'](_0x5f2443));}['_getReauthenticationResolver'](_0x436d7b){return Ze(_0x436d7b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3013e6){const _0x3b8baa={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3013e6&&(_0x3b8baa['idToken']=_0x3013e6),_0x3b8baa;}}function pp(_0x20da56){return Ua(_0x20da56['auth'],new Rs(_0x20da56),_0x20da56['bypassAuthState']);}function _p(_0x239efb){const {auth:_0x35425d,user:_0x403da9}=_0x239efb;return m(_0x403da9,_0x35425d,'internal-error'),Kf(_0x403da9,new Rs(_0x239efb),_0x239efb['bypassAuthState']);}async function gp(_0x5c29c9){const {auth:_0x1c1ece,user:_0x23d79c}=_0x5c29c9;return m(_0x23d79c,_0x1c1ece,'internal-error'),jf(_0x23d79c,new Rs(_0x5c29c9),_0x5c29c9['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5babbd,_0x3ef822,_0x388404,_0x2a96e9,_0x120c4a=!0x1){this['auth']=_0x5babbd,this['resolver']=_0x388404,this['user']=_0x2a96e9,this['bypassAuthState']=_0x120c4a,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3ef822)?_0x3ef822:[_0x3ef822];}['execute'](){return new Promise(async(_0x49a242,_0x15cf9d)=>{this['pendingPromise']={'resolve':_0x49a242,'reject':_0x15cf9d};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x278375){this['reject'](_0x278375);}});}async['onAuthEvent'](_0x11f017){const {urlResponse:_0x477ca2,sessionId:_0x342287,postBody:_0x2e2598,tenantId:_0x526c57,error:_0xe61f61,type:_0x4555df}=_0x11f017;if(_0xe61f61){this['reject'](_0xe61f61);return;}const _0x47acdc={'auth':this['auth'],'requestUri':_0x477ca2,'sessionId':_0x342287,'tenantId':_0x526c57||void 0x0,'postBody':_0x2e2598||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4555df)(_0x47acdc));}catch(_0x2a3212){this['reject'](_0x2a3212);}}['onError'](_0x5c2a36){this['reject'](_0x5c2a36);}['getIdpTask'](_0x37ba1c){switch(_0x37ba1c){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0xd6956){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xd6956),this['unregisterAndCleanUp']();}['reject'](_0x5aa2fc){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5aa2fc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x23aeff,_0x167418,_0x3ba9e9,_0x21cb8b,_0x1ede59){super(_0x23aeff,_0x167418,_0x21cb8b,_0x1ede59),this['provider']=_0x3ba9e9,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x20a495=await this['execute']();return m(_0x20a495,this['auth'],'internal-error'),_0x20a495;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4adbb2=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4adbb2),this['authWindow']['associatedEvent']=_0x4adbb2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x243dd4=>{this['reject'](_0x243dd4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x241369=>{_0x241369||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3ee678;return((_0x3ee678=this['authWindow'])==null?void 0x0:_0x3ee678['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xbfbb95=()=>{var _0x4e78b8,_0x2b76b7;if((_0x2b76b7=(_0x4e78b8=this['authWindow'])==null?void 0x0:_0x4e78b8['window'])!=null&&_0x2b76b7['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xbfbb95,mp['get']());};_0xbfbb95();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x5d5a67,_0x34fd82,_0x30231f=!0x1){super(_0x5d5a67,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x34fd82,void 0x0,_0x30231f),this['eventId']=null;}async['execute'](){let _0x3199c9=rn['get'](this['auth']['_key']());if(!_0x3199c9){try{const _0x56071c=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3199c9=()=>Promise['resolve'](_0x56071c);}catch(_0x562e6d){_0x3199c9=()=>Promise['reject'](_0x562e6d);}rn['set'](this['auth']['_key'](),_0x3199c9);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3199c9();}async['onAuthEvent'](_0x234acb){if(_0x234acb['type']==='signInViaRedirect')return super['onAuthEvent'](_0x234acb);if(_0x234acb['type']==='unknown'){this['resolve'](null);return;}if(_0x234acb['eventId']){const _0x39bde6=await this['auth']['_redirectUserForId'](_0x234acb['eventId']);if(_0x39bde6)return this['user']=_0x39bde6,super['onAuthEvent'](_0x234acb);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x482b59,_0x4c6fe0){const _0x3c78a1=Cp(_0x4c6fe0),_0x3afeae=wp(_0x482b59);if(!await _0x3afeae['_isAvailable']())return!0x1;const _0x4fc387=await _0x3afeae['_get'](_0x3c78a1)==='true';return await _0x3afeae['_remove'](_0x3c78a1),_0x4fc387;}function Ip(_0x588a10,_0x28e9a5){rn['set'](_0x588a10['_key'](),_0x28e9a5);}function wp(_0x26f416){return ne(_0x26f416['_redirectPersistence']);}function Cp(_0x1d2bd8){return sn(yp,_0x1d2bd8['config']['apiKey'],_0x1d2bd8['name']);}async function Tp(_0x74d129,_0x156d79,_0x1b76e6=!0x1){if(H(_0x74d129['app']))return Promise['reject'](se(_0x74d129));const _0x36c2c8=qe(_0x74d129),_0x47f2b4=fp(_0x36c2c8,_0x156d79),_0xa5aaf8=await new vp(_0x36c2c8,_0x47f2b4,_0x1b76e6)['execute']();return _0xa5aaf8&&!_0x1b76e6&&(delete _0xa5aaf8['user']['_redirectEventId'],await _0x36c2c8['_persistUserIfCurrent'](_0xa5aaf8['user']),await _0x36c2c8['_setRedirectUser'](null,_0x156d79)),_0xa5aaf8;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0xb21b73){this['auth']=_0xb21b73,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3d25cb){this['consumers']['add'](_0x3d25cb),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3d25cb)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3d25cb),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x212d3b){this['consumers']['delete'](_0x212d3b);}['onEvent'](_0x1c7ad2){if(this['hasEventBeenHandled'](_0x1c7ad2))return!0x1;let _0x42fe9d=!0x1;return this['consumers']['forEach'](_0x55f704=>{this['isEventForConsumer'](_0x1c7ad2,_0x55f704)&&(_0x42fe9d=!0x0,this['sendToConsumer'](_0x1c7ad2,_0x55f704),this['saveEventToCache'](_0x1c7ad2));}),this['hasHandledPotentialRedirect']||!Rp(_0x1c7ad2)||(this['hasHandledPotentialRedirect']=!0x0,_0x42fe9d||(this['queuedRedirectEvent']=_0x1c7ad2,_0x42fe9d=!0x0)),_0x42fe9d;}['sendToConsumer'](_0x429e96,_0x5238f5){var _0x2dfad5;if(_0x429e96['error']&&!Qa(_0x429e96)){const _0x7ec789=((_0x2dfad5=_0x429e96['error']['code'])==null?void 0x0:_0x2dfad5['split']('auth/')[0x1])||'internal-error';_0x5238f5['onError'](J(this['auth'],_0x7ec789));}else _0x5238f5['onAuthEvent'](_0x429e96);}['isEventForConsumer'](_0x2ee817,_0x3b3dce){const _0x430e5e=_0x3b3dce['eventId']===null||!!_0x2ee817['eventId']&&_0x2ee817['eventId']===_0x3b3dce['eventId'];return _0x3b3dce['filter']['includes'](_0x2ee817['type'])&&_0x430e5e;}['hasEventBeenHandled'](_0x450c10){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x450c10));}['saveEventToCache'](_0xc9f2fe){this['cachedEventUids']['add'](Pr(_0xc9f2fe)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x4f0fbb){return[_0x4f0fbb['type'],_0x4f0fbb['eventId'],_0x4f0fbb['sessionId'],_0x4f0fbb['tenantId']]['filter'](_0x1b52ea=>_0x1b52ea)['join']('-');}function Qa({type:_0x39cceb,error:_0x2d0dfc}){return _0x39cceb==='unknown'&&(_0x2d0dfc==null?void 0x0:_0x2d0dfc['code'])==='auth/no-auth-event';}function Rp(_0x45f282){switch(_0x45f282['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x45f282);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x43b25f,_0x47ad43={}){return Ae(_0x43b25f,'GET','/v1/projects',_0x47ad43);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x17d388){if(_0x17d388['config']['emulator'])return;const {authorizedDomains:_0x254764}=await Ap(_0x17d388);for(const _0x30c51f of _0x254764)try{if(Op(_0x30c51f))return;}catch{}K(_0x17d388,'unauthorized-domain');}function Op(_0x5aa0d2){const _0x37adac=Ni(),{protocol:_0x2234a1,hostname:_0x212366}=new URL(_0x37adac);if(_0x5aa0d2['startsWith']('chrome-extension://')){const _0x6eda3d=new URL(_0x5aa0d2);return _0x6eda3d['hostname']===''&&_0x212366===''?_0x2234a1==='chrome-extension:'&&_0x5aa0d2['replace']('chrome-extension://','')===_0x37adac['replace']('chrome-extension://',''):_0x2234a1==='chrome-extension:'&&_0x6eda3d['hostname']===_0x212366;}if(!Np['test'](_0x2234a1))return!0x1;if(kp['test'](_0x5aa0d2))return _0x212366===_0x5aa0d2;const _0x576902=_0x5aa0d2['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x576902+'|'+_0x576902+')$','i')['test'](_0x212366);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x108f1b=X()['___jsl'];if(_0x108f1b!=null&&_0x108f1b['H']){for(const _0x186050 of Object['keys'](_0x108f1b['H']))if(_0x108f1b['H'][_0x186050]['r']=_0x108f1b['H'][_0x186050]['r']||[],_0x108f1b['H'][_0x186050]['L']=_0x108f1b['H'][_0x186050]['L']||[],_0x108f1b['H'][_0x186050]['r']=[..._0x108f1b['H'][_0x186050]['L']],_0x108f1b['CP']){for(let _0x486d5d=0x0;_0x486d5d<_0x108f1b['CP']['length'];_0x486d5d++)_0x108f1b['CP'][_0x486d5d]=null;}}}function Mp(_0x37f541){return new Promise((_0x38f503,_0x2b1aaf)=>{var _0x4d347b,_0x2bd568,_0x21b20;function _0x5538d6(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x38f503(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x2b1aaf(J(_0x37f541,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x2bd568=(_0x4d347b=X()['gapi'])==null?void 0x0:_0x4d347b['iframes'])!=null&&_0x2bd568['Iframe'])_0x38f503(gapi['iframes']['getContext']());else{if((_0x21b20=X()['gapi'])!=null&&_0x21b20['load'])_0x5538d6();else{const _0x518b25=Nf('iframefcb');return X()[_0x518b25]=()=>{gapi['load']?_0x5538d6():_0x2b1aaf(J(_0x37f541,'network-request-failed'));},Da(kf()+'?onload='+_0x518b25)['catch'](_0x2b5677=>_0x2b1aaf(_0x2b5677));}}})['catch'](_0x192d0b=>{throw on=null,_0x192d0b;});}let on=null;function Lp(_0x4520fa){return on=on||Mp(_0x4520fa),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x1c7905){const _0x10ff62=_0x1c7905['config'];m(_0x10ff62['authDomain'],_0x1c7905,'auth-domain-config-required');const _0x23b4dd=_0x10ff62['emulator']?Is(_0x10ff62,Up):'https://'+_0x1c7905['config']['authDomain']+'/'+Fp,_0x56794f={'apiKey':_0x10ff62['apiKey'],'appName':_0x1c7905['name'],'v':ct},_0x15b982=Bp['get'](_0x1c7905['config']['apiHost']);_0x15b982&&(_0x56794f['eid']=_0x15b982);const _0x3f5484=_0x1c7905['_getFrameworks']();return _0x3f5484['length']&&(_0x56794f['fw']=_0x3f5484['join'](',')),_0x23b4dd+'?'+at(_0x56794f)['slice'](0x1);}async function Hp(_0x5129f0){const _0x280f45=await Lp(_0x5129f0),_0x138bb2=X()['gapi'];return m(_0x138bb2,_0x5129f0,'internal-error'),_0x280f45['open']({'where':document['body'],'url':Vp(_0x5129f0),'messageHandlersFilter':_0x138bb2['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x4ac4df=>new Promise(async(_0x4675e0,_0x38418a)=>{await _0x4ac4df['restyle']({'setHideOnLeave':!0x1});const _0x34631a=J(_0x5129f0,'network-request-failed'),_0x56d608=X()['setTimeout'](()=>{_0x38418a(_0x34631a);},xp['get']());function _0x3e2095(){X()['clearTimeout'](_0x56d608),_0x4675e0(_0x4ac4df);}_0x4ac4df['ping'](_0x3e2095)['then'](_0x3e2095,()=>{_0x38418a(_0x34631a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x371e68){this['window']=_0x371e68,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x266391,_0x5f1a71,_0x406cbf,_0x4474cc=Gp,_0x43da95=qp){const _0x9efbe5=Math['max']((window['screen']['availHeight']-_0x43da95)/0x2,0x0)['toString'](),_0x508659=Math['max']((window['screen']['availWidth']-_0x4474cc)/0x2,0x0)['toString']();let _0x34a460='';const _0x571024={...$p,'width':_0x4474cc['toString'](),'height':_0x43da95['toString'](),'top':_0x9efbe5,'left':_0x508659},_0x518427=W()['toLowerCase']();_0x406cbf&&(_0x34a460=ba(_0x518427)?zp:_0x406cbf),Ta(_0x518427)&&(_0x5f1a71=_0x5f1a71||jp,_0x571024['scrollbars']='yes');const _0x32e37c=Object['entries'](_0x571024)['reduce']((_0x5ebbea,[_0x35b888,_0x3f8042])=>''+_0x5ebbea+_0x35b888+'='+_0x3f8042+',','');if(Ef(_0x518427)&&_0x34a460!=='_self')return Yp(_0x5f1a71||'',_0x34a460),new Dr(null);const _0x5f09c6=window['open'](_0x5f1a71||'',_0x34a460,_0x32e37c);m(_0x5f09c6,_0x266391,'popup-blocked');try{_0x5f09c6['focus']();}catch{}return new Dr(_0x5f09c6);}function Yp(_0x41e57d,_0x1a2c52){const _0x2e3384=document['createElement']('a');_0x2e3384['href']=_0x41e57d,_0x2e3384['target']=_0x1a2c52;const _0x46ea16=document['createEvent']('MouseEvent');_0x46ea16['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2e3384['dispatchEvent'](_0x46ea16);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2757bc,_0x27f4fc,_0x3b6545,_0x9572f1,_0x531926,_0x1afb82){m(_0x2757bc['config']['authDomain'],_0x2757bc,'auth-domain-config-required'),m(_0x2757bc['config']['apiKey'],_0x2757bc,'invalid-api-key');const _0x588fab={'apiKey':_0x2757bc['config']['apiKey'],'appName':_0x2757bc['name'],'authType':_0x3b6545,'redirectUrl':_0x9572f1,'v':ct,'eventId':_0x531926};if(_0x27f4fc instanceof xa){_0x27f4fc['setDefaultLanguage'](_0x2757bc['languageCode']),_0x588fab['providerId']=_0x27f4fc['providerId']||'',hi(_0x27f4fc['getCustomParameters']())||(_0x588fab['customParameters']=JSON['stringify'](_0x27f4fc['getCustomParameters']()));for(const [_0x4501b6,_0x57eb7f]of Object['entries']({}))_0x588fab[_0x4501b6]=_0x57eb7f;}if(_0x27f4fc instanceof Qt){const _0x2725b3=_0x27f4fc['getScopes']()['filter'](_0x45c722=>_0x45c722!=='');_0x2725b3['length']>0x0&&(_0x588fab['scopes']=_0x2725b3['join'](','));}_0x2757bc['tenantId']&&(_0x588fab['tid']=_0x2757bc['tenantId']);const _0x27f62a=_0x588fab;for(const _0x16ab48 of Object['keys'](_0x27f62a))_0x27f62a[_0x16ab48]===void 0x0&&delete _0x27f62a[_0x16ab48];const _0xeb2c35=await _0x2757bc['_getAppCheckToken'](),_0x58b448=_0xeb2c35?'#'+Xp+'='+encodeURIComponent(_0xeb2c35):'';return Zp(_0x2757bc)+'?'+at(_0x27f62a)['slice'](0x1)+_0x58b448;}function Zp({config:_0x3e1621}){return _0x3e1621['emulator']?Is(_0x3e1621,Jp):'https://'+_0x3e1621['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x264e4b,_0x639cca,_0x5659a5,_0x4493b7){var _0x579d34;ae((_0x579d34=this['eventManagers'][_0x264e4b['_key']()])==null?void 0x0:_0x579d34['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x281be6=await Mr(_0x264e4b,_0x639cca,_0x5659a5,Ni(),_0x4493b7);return Kp(_0x264e4b,_0x281be6,bs());}async['_openRedirect'](_0x3db5b3,_0x12cbc4,_0x5beaa2,_0x334209){await this['_originValidation'](_0x3db5b3);const _0x5971d2=await Mr(_0x3db5b3,_0x12cbc4,_0x5beaa2,Ni(),_0x334209);return ip(_0x5971d2),new Promise(()=>{});}['_initialize'](_0x67dabb){const _0x3ab6ed=_0x67dabb['_key']();if(this['eventManagers'][_0x3ab6ed]){const {manager:_0x123d34,promise:_0x1d7fe1}=this['eventManagers'][_0x3ab6ed];return _0x123d34?Promise['resolve'](_0x123d34):(ae(_0x1d7fe1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1d7fe1);}const _0x2f8744=this['initAndGetManager'](_0x67dabb);return this['eventManagers'][_0x3ab6ed]={'promise':_0x2f8744},_0x2f8744['catch'](()=>{delete this['eventManagers'][_0x3ab6ed];}),_0x2f8744;}async['initAndGetManager'](_0x36af30){const _0x46763b=await Hp(_0x36af30),_0x11ae73=new bp(_0x36af30);return _0x46763b['register']('authEvent',_0x11457d=>(m(_0x11457d==null?void 0x0:_0x11457d['authEvent'],_0x36af30,'invalid-auth-event'),{'status':_0x11ae73['onEvent'](_0x11457d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x36af30['_key']()]={'manager':_0x11ae73},this['iframes'][_0x36af30['_key']()]=_0x46763b,_0x11ae73;}['_isIframeWebStorageSupported'](_0x20bb2c,_0x3a8b57){this['iframes'][_0x20bb2c['_key']()]['send'](li,{'type':li},_0x5803b1=>{var _0x3bb4ac;const _0x19d38b=(_0x3bb4ac=_0x5803b1==null?void 0x0:_0x5803b1[0x0])==null?void 0x0:_0x3bb4ac[li];_0x19d38b!==void 0x0&&_0x3a8b57(!!_0x19d38b),K(_0x20bb2c,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x587527){const _0xe08ce1=_0x587527['_key']();return this['originValidationPromises'][_0xe08ce1]||(this['originValidationPromises'][_0xe08ce1]=Pp(_0x587527)),this['originValidationPromises'][_0xe08ce1];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x5ca6f9){this['auth']=_0x5ca6f9,this['internalListeners']=new Map();}['getUid'](){var _0x21612c;return this['assertAuthConfigured'](),((_0x21612c=this['auth']['currentUser'])==null?void 0x0:_0x21612c['uid'])||null;}async['getToken'](_0x4ba0a2){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4ba0a2)}:null;}['addAuthTokenListener'](_0x3cb2fa){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3cb2fa))return;const _0x47f4e2=this['auth']['onIdTokenChanged'](_0x114ab4=>{_0x3cb2fa((_0x114ab4==null?void 0x0:_0x114ab4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3cb2fa,_0x47f4e2),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3c492e){this['assertAuthConfigured']();const _0x1b63cc=this['internalListeners']['get'](_0x3c492e);_0x1b63cc&&(this['internalListeners']['delete'](_0x3c492e),_0x1b63cc(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5d7205){switch(_0x5d7205){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x97c2fb){et(new Me('auth',(_0x256700,{options:_0x176f55})=>{const _0x35cb45=_0x256700['getProvider']('app')['getImmediate'](),_0xb2d4ab=_0x256700['getProvider']('heartbeat'),_0x3c0e66=_0x256700['getProvider']('app-check-internal'),{apiKey:_0x1e3f06,authDomain:_0x2c7f0c}=_0x35cb45['options'];m(_0x1e3f06&&!_0x1e3f06['includes'](':'),'invalid-api-key',{'appName':_0x35cb45['name']});const _0x29e0a2={'apiKey':_0x1e3f06,'authDomain':_0x2c7f0c,'clientPlatform':_0x97c2fb,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x97c2fb)},_0xe689b8=new bf(_0x35cb45,_0xb2d4ab,_0x3c0e66,_0x29e0a2);return Lf(_0xe689b8,_0x176f55),_0xe689b8;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x290248,_0x161854,_0x302c4a)=>{_0x290248['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x5d9669=>{const _0x50a6c5=qe(_0x5d9669['getProvider']('auth')['getImmediate']());return(_0x54c426=>new n_(_0x54c426))(_0x50a6c5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x97c2fb)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2bd05c=>async _0x40c7c5=>{const _0x2ecd60=_0x40c7c5&&await _0x40c7c5['getIdTokenResult'](),_0x3e23bc=_0x2ecd60&&(new Date()['getTime']()-Date['parse'](_0x2ecd60['issuedAtTime']))/0x3e8;if(_0x3e23bc&&_0x3e23bc>o_)return;const _0xa6c6c2=_0x2ecd60==null?void 0x0:_0x2ecd60['token'];Fr!==_0xa6c6c2&&(Fr=_0xa6c6c2,await fetch(_0x2bd05c,{'method':_0xa6c6c2?'POST':'DELETE','headers':_0xa6c6c2?{'Authorization':'Bearer\x20'+_0xa6c6c2}:{}}));};function O_(_0x52df75=Qr()){const _0x3fec90=Ui(_0x52df75,'auth');if(_0x3fec90['isInitialized']())return _0x3fec90['getImmediate']();const _0x3a2aca=Mf(_0x52df75,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4ed378=Gr('authTokenSyncURL');if(_0x4ed378&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x9bbf8d=new URL(_0x4ed378,location['origin']);if(location['origin']===_0x9bbf8d['origin']){const _0x401dfd=a_(_0x9bbf8d['toString']());Jf(_0x3a2aca,_0x401dfd,()=>_0x401dfd(_0x3a2aca['currentUser'])),Qf(_0x3a2aca,_0x45e989=>_0x401dfd(_0x45e989));}}const _0x23c012=Hr('auth');return _0x23c012&&xf(_0x3a2aca,'http://'+_0x23c012),_0x3a2aca;}function c_(){var _0x5392f6;return((_0x5392f6=document['getElementsByTagName']('head'))==null?void 0x0:_0x5392f6[0x0])??document;}Rf({'loadJS'(_0x484cc8){return new Promise((_0x2ac6d0,_0x555519)=>{const _0x77ee2=document['createElement']('script');_0x77ee2['setAttribute']('src',_0x484cc8),_0x77ee2['onload']=_0x2ac6d0,_0x77ee2['onerror']=_0x183d15=>{const _0x25e624=J('internal-error');_0x25e624['customData']=_0x183d15,_0x555519(_0x25e624);},_0x77ee2['type']='text/javascript',_0x77ee2['charset']='UTF-8',c_()['appendChild'](_0x77ee2);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};