const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2a43b7,_0x3b6d02){if(!_0x2a43b7)throw ot(_0x3b6d02);},ot=function(_0x5543e7){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5543e7);},Wr=function(_0x56e72a){const _0x2f5830=[];let _0x199f62=0x0;for(let _0x1b271a=0x0;_0x1b271a<_0x56e72a['length'];_0x1b271a++){let _0x42e32b=_0x56e72a['charCodeAt'](_0x1b271a);_0x42e32b<0x80?_0x2f5830[_0x199f62++]=_0x42e32b:_0x42e32b<0x800?(_0x2f5830[_0x199f62++]=_0x42e32b>>0x6|0xc0,_0x2f5830[_0x199f62++]=_0x42e32b&0x3f|0x80):(_0x42e32b&0xfc00)===0xd800&&_0x1b271a+0x1<_0x56e72a['length']&&(_0x56e72a['charCodeAt'](_0x1b271a+0x1)&0xfc00)===0xdc00?(_0x42e32b=0x10000+((_0x42e32b&0x3ff)<<0xa)+(_0x56e72a['charCodeAt'](++_0x1b271a)&0x3ff),_0x2f5830[_0x199f62++]=_0x42e32b>>0x12|0xf0,_0x2f5830[_0x199f62++]=_0x42e32b>>0xc&0x3f|0x80,_0x2f5830[_0x199f62++]=_0x42e32b>>0x6&0x3f|0x80,_0x2f5830[_0x199f62++]=_0x42e32b&0x3f|0x80):(_0x2f5830[_0x199f62++]=_0x42e32b>>0xc|0xe0,_0x2f5830[_0x199f62++]=_0x42e32b>>0x6&0x3f|0x80,_0x2f5830[_0x199f62++]=_0x42e32b&0x3f|0x80);}return _0x2f5830;},Za=function(_0x677fb5){const _0x1f91e6=[];let _0x4c8db5=0x0,_0x8f50ec=0x0;for(;_0x4c8db5<_0x677fb5['length'];){const _0x57175a=_0x677fb5[_0x4c8db5++];if(_0x57175a<0x80)_0x1f91e6[_0x8f50ec++]=String['fromCharCode'](_0x57175a);else{if(_0x57175a>0xbf&&_0x57175a<0xe0){const _0x5a1f26=_0x677fb5[_0x4c8db5++];_0x1f91e6[_0x8f50ec++]=String['fromCharCode']((_0x57175a&0x1f)<<0x6|_0x5a1f26&0x3f);}else{if(_0x57175a>0xef&&_0x57175a<0x16d){const _0x1fc7fa=_0x677fb5[_0x4c8db5++],_0x1f5945=_0x677fb5[_0x4c8db5++],_0x4f6cb3=_0x677fb5[_0x4c8db5++],_0xad9903=((_0x57175a&0x7)<<0x12|(_0x1fc7fa&0x3f)<<0xc|(_0x1f5945&0x3f)<<0x6|_0x4f6cb3&0x3f)-0x10000;_0x1f91e6[_0x8f50ec++]=String['fromCharCode'](0xd800+(_0xad9903>>0xa)),_0x1f91e6[_0x8f50ec++]=String['fromCharCode'](0xdc00+(_0xad9903&0x3ff));}else{const _0x399351=_0x677fb5[_0x4c8db5++],_0x3d7f8a=_0x677fb5[_0x4c8db5++];_0x1f91e6[_0x8f50ec++]=String['fromCharCode']((_0x57175a&0xf)<<0xc|(_0x399351&0x3f)<<0x6|_0x3d7f8a&0x3f);}}}}return _0x1f91e6['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x263d9f,_0x258a65){if(!Array['isArray'](_0x263d9f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x285969=_0x258a65?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x14dbd6=[];for(let _0x49219b=0x0;_0x49219b<_0x263d9f['length'];_0x49219b+=0x3){const _0x39f48a=_0x263d9f[_0x49219b],_0x5c7f4a=_0x49219b+0x1<_0x263d9f['length'],_0xc5774e=_0x5c7f4a?_0x263d9f[_0x49219b+0x1]:0x0,_0x18851b=_0x49219b+0x2<_0x263d9f['length'],_0x4d6089=_0x18851b?_0x263d9f[_0x49219b+0x2]:0x0,_0x16cc57=_0x39f48a>>0x2,_0x23a491=(_0x39f48a&0x3)<<0x4|_0xc5774e>>0x4;let _0x4e20ba=(_0xc5774e&0xf)<<0x2|_0x4d6089>>0x6,_0x179b97=_0x4d6089&0x3f;_0x18851b||(_0x179b97=0x40,_0x5c7f4a||(_0x4e20ba=0x40)),_0x14dbd6['push'](_0x285969[_0x16cc57],_0x285969[_0x23a491],_0x285969[_0x4e20ba],_0x285969[_0x179b97]);}return _0x14dbd6['join']('');},'encodeString'(_0x17c644,_0x4bfdfc){return this['HAS_NATIVE_SUPPORT']&&!_0x4bfdfc?btoa(_0x17c644):this['encodeByteArray'](Wr(_0x17c644),_0x4bfdfc);},'decodeString'(_0x54c162,_0x1cca1e){return this['HAS_NATIVE_SUPPORT']&&!_0x1cca1e?atob(_0x54c162):Za(this['decodeStringToByteArray'](_0x54c162,_0x1cca1e));},'decodeStringToByteArray'(_0x58daf5,_0x4fbe70){this['init_']();const _0x3d303d=_0x4fbe70?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x41186c=[];for(let _0x4b04d1=0x0;_0x4b04d1<_0x58daf5['length'];){const _0x167346=_0x3d303d[_0x58daf5['charAt'](_0x4b04d1++)],_0x33e7e0=_0x4b04d1<_0x58daf5['length']?_0x3d303d[_0x58daf5['charAt'](_0x4b04d1)]:0x0;++_0x4b04d1;const _0x15cd5a=_0x4b04d1<_0x58daf5['length']?_0x3d303d[_0x58daf5['charAt'](_0x4b04d1)]:0x40;++_0x4b04d1;const _0x5ae800=_0x4b04d1<_0x58daf5['length']?_0x3d303d[_0x58daf5['charAt'](_0x4b04d1)]:0x40;if(++_0x4b04d1,_0x167346==null||_0x33e7e0==null||_0x15cd5a==null||_0x5ae800==null)throw new ec();const _0x42f67b=_0x167346<<0x2|_0x33e7e0>>0x4;if(_0x41186c['push'](_0x42f67b),_0x15cd5a!==0x40){const _0x48ee2f=_0x33e7e0<<0x4&0xf0|_0x15cd5a>>0x2;if(_0x41186c['push'](_0x48ee2f),_0x5ae800!==0x40){const _0x2b9a90=_0x15cd5a<<0x6&0xc0|_0x5ae800;_0x41186c['push'](_0x2b9a90);}}}return _0x41186c;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x243726=0x0;_0x243726<this['ENCODED_VALS']['length'];_0x243726++)this['byteToCharMap_'][_0x243726]=this['ENCODED_VALS']['charAt'](_0x243726),this['charToByteMap_'][this['byteToCharMap_'][_0x243726]]=_0x243726,this['byteToCharMapWebSafe_'][_0x243726]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x243726),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x243726]]=_0x243726,_0x243726>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x243726)]=_0x243726,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x243726)]=_0x243726);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x1c44e5){const _0x3c3df0=Wr(_0x1c44e5);return Di['encodeByteArray'](_0x3c3df0,!0x0);},an=function(_0x114978){return Br(_0x114978)['replace'](/\./g,'');},cn=function(_0x3ea58f){try{return Di['decodeString'](_0x3ea58f,!0x0);}catch(_0x5c1286){console['error']('base64Decode\x20failed:\x20',_0x5c1286);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x447461){return Vr(void 0x0,_0x447461);}function Vr(_0xf8a5db,_0x327a1c){if(!(_0x327a1c instanceof Object))return _0x327a1c;switch(_0x327a1c['constructor']){case Date:const _0x32d93b=_0x327a1c;return new Date(_0x32d93b['getTime']());case Object:_0xf8a5db===void 0x0&&(_0xf8a5db={});break;case Array:_0xf8a5db=[];break;default:return _0x327a1c;}for(const _0x579096 in _0x327a1c)!_0x327a1c['hasOwnProperty'](_0x579096)||!nc(_0x579096)||(_0xf8a5db[_0x579096]=Vr(_0xf8a5db[_0x579096],_0x327a1c[_0x579096]));return _0xf8a5db;}function nc(_0x7e0504){return _0x7e0504!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x522d73=As['__FIREBASE_DEFAULTS__'];if(_0x522d73)return JSON['parse'](_0x522d73);},oc=()=>{if(typeof document>'u')return;let _0x48ae91;try{_0x48ae91=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x43b79d=_0x48ae91&&cn(_0x48ae91[0x1]);return _0x43b79d&&JSON['parse'](_0x43b79d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4511a1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4511a1);return;}},Hr=_0x2ab9b7=>{var _0x143afd,_0x317e65;return(_0x317e65=(_0x143afd=Mi())==null?void 0x0:_0x143afd['emulatorHosts'])==null?void 0x0:_0x317e65[_0x2ab9b7];},ac=_0x224d5b=>{const _0x3fb1fc=Hr(_0x224d5b);if(!_0x3fb1fc)return;const _0x36efd8=_0x3fb1fc['lastIndexOf'](':');if(_0x36efd8<=0x0||_0x36efd8+0x1===_0x3fb1fc['length'])throw new Error('Invalid\x20host\x20'+_0x3fb1fc+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x559da6=parseInt(_0x3fb1fc['substring'](_0x36efd8+0x1),0xa);return _0x3fb1fc[0x0]==='['?[_0x3fb1fc['substring'](0x1,_0x36efd8-0x1),_0x559da6]:[_0x3fb1fc['substring'](0x0,_0x36efd8),_0x559da6];},$r=()=>{var _0xc1ad00;return(_0xc1ad00=Mi())==null?void 0x0:_0xc1ad00['config'];},Gr=_0x32e76a=>{var _0x206a79;return(_0x206a79=Mi())==null?void 0x0:_0x206a79['_'+_0x32e76a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5702f2,_0x56a83b)=>{this['resolve']=_0x5702f2,this['reject']=_0x56a83b;});}['wrapCallback'](_0x1bdff1){return(_0x267e87,_0x576cd6)=>{_0x267e87?this['reject'](_0x267e87):this['resolve'](_0x576cd6),typeof _0x1bdff1=='function'&&(this['promise']['catch'](()=>{}),_0x1bdff1['length']===0x1?_0x1bdff1(_0x267e87):_0x1bdff1(_0x267e87,_0x576cd6));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x12857c,_0x543bbe){if(_0x12857c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x472c63={'alg':'none','type':'JWT'},_0x2ce3fc=_0x543bbe||'demo-project',_0x566c9b=_0x12857c['iat']||0x0,_0x5567c1=_0x12857c['sub']||_0x12857c['user_id'];if(!_0x5567c1)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x794cd={'iss':'https://securetoken.google.com/'+_0x2ce3fc,'aud':_0x2ce3fc,'iat':_0x566c9b,'exp':_0x566c9b+0xe10,'auth_time':_0x566c9b,'sub':_0x5567c1,'user_id':_0x5567c1,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x12857c};return[an(JSON['stringify'](_0x472c63)),an(JSON['stringify'](_0x794cd)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x990eb7=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x990eb7=='object'&&_0x990eb7['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x56507c=W();return _0x56507c['indexOf']('MSIE\x20')>=0x0||_0x56507c['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x5e0cef,_0x41b365)=>{try{let _0xc043c6=!0x0;const _0x311ac5='validate-browser-context-for-indexeddb-analytics-module',_0x3015b3=self['indexedDB']['open'](_0x311ac5);_0x3015b3['onsuccess']=()=>{_0x3015b3['result']['close'](),_0xc043c6||self['indexedDB']['deleteDatabase'](_0x311ac5),_0x5e0cef(!0x0);},_0x3015b3['onupgradeneeded']=()=>{_0xc043c6=!0x1;},_0x3015b3['onerror']=()=>{var _0x5aa732;_0x41b365(((_0x5aa732=_0x3015b3['error'])==null?void 0x0:_0x5aa732['message'])||'');};}catch(_0x53e60c){_0x41b365(_0x53e60c);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xb2b927,_0x1b7680,_0x1b5d93){super(_0x1b7680),this['code']=_0xb2b927,this['customData']=_0x1b5d93,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4639cf,_0x266fe6,_0x1be491){this['service']=_0x4639cf,this['serviceName']=_0x266fe6,this['errors']=_0x1be491;}['create'](_0x100334,..._0x2e04ee){const _0x1b97cf=_0x2e04ee[0x0]||{},_0x31ea54=this['service']+'/'+_0x100334,_0x38f7cc=this['errors'][_0x100334],_0x3ce3e7=_0x38f7cc?gc(_0x38f7cc,_0x1b97cf):'Error',_0x10a8fb=this['serviceName']+':\x20'+_0x3ce3e7+'\x20('+_0x31ea54+').';return new Se(_0x31ea54,_0x10a8fb,_0x1b97cf);}}function gc(_0x3d2eb5,_0x462d42){return _0x3d2eb5['replace'](mc,(_0x2ec401,_0x76e555)=>{const _0xbaeb51=_0x462d42[_0x76e555];return _0xbaeb51!=null?String(_0xbaeb51):'<'+_0x76e555+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x4389cb){return JSON['parse'](_0x4389cb);}function O(_0x1cfedf){return JSON['stringify'](_0x1cfedf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x522c60){let _0xa43d73={},_0x91ae43={},_0x36cbf5={},_0x36f6c2='';try{const _0x312360=_0x522c60['split']('.');_0xa43d73=bt(cn(_0x312360[0x0])||''),_0x91ae43=bt(cn(_0x312360[0x1])||''),_0x36f6c2=_0x312360[0x2],_0x36cbf5=_0x91ae43['d']||{},delete _0x91ae43['d'];}catch{}return{'header':_0xa43d73,'claims':_0x91ae43,'data':_0x36cbf5,'signature':_0x36f6c2};},yc=function(_0x1a9fbb){const _0x7d60f0=zr(_0x1a9fbb),_0x1c9644=_0x7d60f0['claims'];return!!_0x1c9644&&typeof _0x1c9644=='object'&&_0x1c9644['hasOwnProperty']('iat');},vc=function(_0xd4883d){const _0x158012=zr(_0xd4883d)['claims'];return typeof _0x158012=='object'&&_0x158012['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x41ff4f,_0x528e99){return Object['prototype']['hasOwnProperty']['call'](_0x41ff4f,_0x528e99);}function Oe(_0x4f7bf5,_0x4d14a3){if(Object['prototype']['hasOwnProperty']['call'](_0x4f7bf5,_0x4d14a3))return _0x4f7bf5[_0x4d14a3];}function hi(_0x109a6e){for(const _0x4a6700 in _0x109a6e)if(Object['prototype']['hasOwnProperty']['call'](_0x109a6e,_0x4a6700))return!0x1;return!0x0;}function ln(_0x286004,_0x31dc8d,_0xca7728){const _0x3ee54f={};for(const _0x50341c in _0x286004)Object['prototype']['hasOwnProperty']['call'](_0x286004,_0x50341c)&&(_0x3ee54f[_0x50341c]=_0x31dc8d['call'](_0xca7728,_0x286004[_0x50341c],_0x50341c,_0x286004));return _0x3ee54f;}function De(_0x34d4f2,_0x3beff0){if(_0x34d4f2===_0x3beff0)return!0x0;const _0x45e158=Object['keys'](_0x34d4f2),_0x3b2ba7=Object['keys'](_0x3beff0);for(const _0x5380d3 of _0x45e158){if(!_0x3b2ba7['includes'](_0x5380d3))return!0x1;const _0x1d10e8=_0x34d4f2[_0x5380d3],_0x46f976=_0x3beff0[_0x5380d3];if(ks(_0x1d10e8)&&ks(_0x46f976)){if(!De(_0x1d10e8,_0x46f976))return!0x1;}else{if(_0x1d10e8!==_0x46f976)return!0x1;}}for(const _0x2b2fbe of _0x3b2ba7)if(!_0x45e158['includes'](_0x2b2fbe))return!0x1;return!0x0;}function ks(_0x138c02){return _0x138c02!==null&&typeof _0x138c02=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0xc389ed){const _0x39dfb5=[];for(const [_0x1bbb61,_0x57a5d8]of Object['entries'](_0xc389ed))Array['isArray'](_0x57a5d8)?_0x57a5d8['forEach'](_0x36f11c=>{_0x39dfb5['push'](encodeURIComponent(_0x1bbb61)+'='+encodeURIComponent(_0x36f11c));}):_0x39dfb5['push'](encodeURIComponent(_0x1bbb61)+'='+encodeURIComponent(_0x57a5d8));return _0x39dfb5['length']?'&'+_0x39dfb5['join']('&'):'';}function yt(_0x1d9d70){const _0xbbd9b7={};return _0x1d9d70['replace'](/^\?/,'')['split']('&')['forEach'](_0x5a474a=>{if(_0x5a474a){const [_0x11a0da,_0x5c8d3a]=_0x5a474a['split']('=');_0xbbd9b7[decodeURIComponent(_0x11a0da)]=decodeURIComponent(_0x5c8d3a);}}),_0xbbd9b7;}function vt(_0x13fe9c){const _0x5c193d=_0x13fe9c['indexOf']('?');if(!_0x5c193d)return'';const _0x140dd0=_0x13fe9c['indexOf']('#',_0x5c193d);return _0x13fe9c['substring'](_0x5c193d,_0x140dd0>0x0?_0x140dd0:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2910a3=0x1;_0x2910a3<this['blockSize'];++_0x2910a3)this['pad_'][_0x2910a3]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x20db11,_0x33b65a){_0x33b65a||(_0x33b65a=0x0);const _0x3d7c4e=this['W_'];if(typeof _0x20db11=='string'){for(let _0x1a6065=0x0;_0x1a6065<0x10;_0x1a6065++)_0x3d7c4e[_0x1a6065]=_0x20db11['charCodeAt'](_0x33b65a)<<0x18|_0x20db11['charCodeAt'](_0x33b65a+0x1)<<0x10|_0x20db11['charCodeAt'](_0x33b65a+0x2)<<0x8|_0x20db11['charCodeAt'](_0x33b65a+0x3),_0x33b65a+=0x4;}else{for(let _0x198a3=0x0;_0x198a3<0x10;_0x198a3++)_0x3d7c4e[_0x198a3]=_0x20db11[_0x33b65a]<<0x18|_0x20db11[_0x33b65a+0x1]<<0x10|_0x20db11[_0x33b65a+0x2]<<0x8|_0x20db11[_0x33b65a+0x3],_0x33b65a+=0x4;}for(let _0x310fda=0x10;_0x310fda<0x50;_0x310fda++){const _0xa1d7d1=_0x3d7c4e[_0x310fda-0x3]^_0x3d7c4e[_0x310fda-0x8]^_0x3d7c4e[_0x310fda-0xe]^_0x3d7c4e[_0x310fda-0x10];_0x3d7c4e[_0x310fda]=(_0xa1d7d1<<0x1|_0xa1d7d1>>>0x1f)&0xffffffff;}let _0x364492=this['chain_'][0x0],_0x2ed292=this['chain_'][0x1],_0x3b3301=this['chain_'][0x2],_0x349b69=this['chain_'][0x3],_0x5dcc7c=this['chain_'][0x4],_0x147310,_0x4b14e0;for(let _0x5505fa=0x0;_0x5505fa<0x50;_0x5505fa++){_0x5505fa<0x28?_0x5505fa<0x14?(_0x147310=_0x349b69^_0x2ed292&(_0x3b3301^_0x349b69),_0x4b14e0=0x5a827999):(_0x147310=_0x2ed292^_0x3b3301^_0x349b69,_0x4b14e0=0x6ed9eba1):_0x5505fa<0x3c?(_0x147310=_0x2ed292&_0x3b3301|_0x349b69&(_0x2ed292|_0x3b3301),_0x4b14e0=0x8f1bbcdc):(_0x147310=_0x2ed292^_0x3b3301^_0x349b69,_0x4b14e0=0xca62c1d6);const _0x15f595=(_0x364492<<0x5|_0x364492>>>0x1b)+_0x147310+_0x5dcc7c+_0x4b14e0+_0x3d7c4e[_0x5505fa]&0xffffffff;_0x5dcc7c=_0x349b69,_0x349b69=_0x3b3301,_0x3b3301=(_0x2ed292<<0x1e|_0x2ed292>>>0x2)&0xffffffff,_0x2ed292=_0x364492,_0x364492=_0x15f595;}this['chain_'][0x0]=this['chain_'][0x0]+_0x364492&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2ed292&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3b3301&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x349b69&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5dcc7c&0xffffffff;}['update'](_0x3aacb3,_0x2dbec6){if(_0x3aacb3==null)return;_0x2dbec6===void 0x0&&(_0x2dbec6=_0x3aacb3['length']);const _0x194541=_0x2dbec6-this['blockSize'];let _0x4e765e=0x0;const _0x531c8d=this['buf_'];let _0x18d135=this['inbuf_'];for(;_0x4e765e<_0x2dbec6;){if(_0x18d135===0x0){for(;_0x4e765e<=_0x194541;)this['compress_'](_0x3aacb3,_0x4e765e),_0x4e765e+=this['blockSize'];}if(typeof _0x3aacb3=='string'){for(;_0x4e765e<_0x2dbec6;)if(_0x531c8d[_0x18d135]=_0x3aacb3['charCodeAt'](_0x4e765e),++_0x18d135,++_0x4e765e,_0x18d135===this['blockSize']){this['compress_'](_0x531c8d),_0x18d135=0x0;break;}}else{for(;_0x4e765e<_0x2dbec6;)if(_0x531c8d[_0x18d135]=_0x3aacb3[_0x4e765e],++_0x18d135,++_0x4e765e,_0x18d135===this['blockSize']){this['compress_'](_0x531c8d),_0x18d135=0x0;break;}}}this['inbuf_']=_0x18d135,this['total_']+=_0x2dbec6;}['digest'](){const _0xe1e64e=[];let _0x4d745e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x44402d=this['blockSize']-0x1;_0x44402d>=0x38;_0x44402d--)this['buf_'][_0x44402d]=_0x4d745e&0xff,_0x4d745e/=0x100;this['compress_'](this['buf_']);let _0x1e51a2=0x0;for(let _0x4dd800=0x0;_0x4dd800<0x5;_0x4dd800++)for(let _0x4a05cc=0x18;_0x4a05cc>=0x0;_0x4a05cc-=0x8)_0xe1e64e[_0x1e51a2]=this['chain_'][_0x4dd800]>>_0x4a05cc&0xff,++_0x1e51a2;return _0xe1e64e;}}function Ic(_0x5e6e70,_0x4e3519){const _0x1b613a=new wc(_0x5e6e70,_0x4e3519);return _0x1b613a['subscribe']['bind'](_0x1b613a);}class wc{constructor(_0x3b8eaf,_0x324cce){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x324cce,this['task']['then'](()=>{_0x3b8eaf(this);})['catch'](_0x1f764e=>{this['error'](_0x1f764e);});}['next'](_0xa182f2){this['forEachObserver'](_0x47a23b=>{_0x47a23b['next'](_0xa182f2);});}['error'](_0x2b9455){this['forEachObserver'](_0x3274f4=>{_0x3274f4['error'](_0x2b9455);}),this['close'](_0x2b9455);}['complete'](){this['forEachObserver'](_0x2a74a5=>{_0x2a74a5['complete']();}),this['close']();}['subscribe'](_0x2aec9b,_0x29d954,_0x107128){let _0x212842;if(_0x2aec9b===void 0x0&&_0x29d954===void 0x0&&_0x107128===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x2aec9b,['next','error','complete'])?_0x212842=_0x2aec9b:_0x212842={'next':_0x2aec9b,'error':_0x29d954,'complete':_0x107128},_0x212842['next']===void 0x0&&(_0x212842['next']=Qn),_0x212842['error']===void 0x0&&(_0x212842['error']=Qn),_0x212842['complete']===void 0x0&&(_0x212842['complete']=Qn);const _0x4cb6b7=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x212842['error'](this['finalError']):_0x212842['complete']();}catch{}}),this['observers']['push'](_0x212842),_0x4cb6b7;}['unsubscribeOne'](_0x166062){this['observers']===void 0x0||this['observers'][_0x166062]===void 0x0||(delete this['observers'][_0x166062],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x194db0){if(!this['finalized']){for(let _0x5c9b97=0x0;_0x5c9b97<this['observers']['length'];_0x5c9b97++)this['sendOne'](_0x5c9b97,_0x194db0);}}['sendOne'](_0x26041f,_0x125676){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x26041f]!==void 0x0)try{_0x125676(this['observers'][_0x26041f]);}catch(_0x518274){typeof console<'u'&&console['error']&&console['error'](_0x518274);}});}['close'](_0x27cacf){this['finalized']||(this['finalized']=!0x0,_0x27cacf!==void 0x0&&(this['finalError']=_0x27cacf),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x567701,_0x2102ba){if(typeof _0x567701!='object'||_0x567701===null)return!0x1;for(const _0x56aa35 of _0x2102ba)if(_0x56aa35 in _0x567701&&typeof _0x567701[_0x56aa35]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x245b47,_0x137811){return _0x245b47+'\x20failed:\x20'+_0x137811+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x55ad78){const _0x288757=[];let _0x39229=0x0;for(let _0x3d91f4=0x0;_0x3d91f4<_0x55ad78['length'];_0x3d91f4++){let _0x1ad6df=_0x55ad78['charCodeAt'](_0x3d91f4);if(_0x1ad6df>=0xd800&&_0x1ad6df<=0xdbff){const _0x3294b9=_0x1ad6df-0xd800;_0x3d91f4++,f(_0x3d91f4<_0x55ad78['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5be034=_0x55ad78['charCodeAt'](_0x3d91f4)-0xdc00;_0x1ad6df=0x10000+(_0x3294b9<<0xa)+_0x5be034;}_0x1ad6df<0x80?_0x288757[_0x39229++]=_0x1ad6df:_0x1ad6df<0x800?(_0x288757[_0x39229++]=_0x1ad6df>>0x6|0xc0,_0x288757[_0x39229++]=_0x1ad6df&0x3f|0x80):_0x1ad6df<0x10000?(_0x288757[_0x39229++]=_0x1ad6df>>0xc|0xe0,_0x288757[_0x39229++]=_0x1ad6df>>0x6&0x3f|0x80,_0x288757[_0x39229++]=_0x1ad6df&0x3f|0x80):(_0x288757[_0x39229++]=_0x1ad6df>>0x12|0xf0,_0x288757[_0x39229++]=_0x1ad6df>>0xc&0x3f|0x80,_0x288757[_0x39229++]=_0x1ad6df>>0x6&0x3f|0x80,_0x288757[_0x39229++]=_0x1ad6df&0x3f|0x80);}return _0x288757;},Pn=function(_0xe6eb50){let _0xe2670e=0x0;for(let _0x2099c8=0x0;_0x2099c8<_0xe6eb50['length'];_0x2099c8++){const _0x382529=_0xe6eb50['charCodeAt'](_0x2099c8);_0x382529<0x80?_0xe2670e++:_0x382529<0x800?_0xe2670e+=0x2:_0x382529>=0xd800&&_0x382529<=0xdbff?(_0xe2670e+=0x4,_0x2099c8++):_0xe2670e+=0x3;}return _0xe2670e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x5433cb){return _0x5433cb&&_0x5433cb['_delegate']?_0x5433cb['_delegate']:_0x5433cb;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x363690){try{return(_0x363690['startsWith']('http://')||_0x363690['startsWith']('https://')?new URL(_0x363690)['hostname']:_0x363690)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x10960b){return(await fetch(_0x10960b,{'credentials':'include'}))['ok'];}class Me{constructor(_0x1cac82,_0x1b89c6,_0x128f66){this['name']=_0x1cac82,this['instanceFactory']=_0x1b89c6,this['type']=_0x128f66,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x511c5b){return this['instantiationMode']=_0x511c5b,this;}['setMultipleInstances'](_0x56bbbf){return this['multipleInstances']=_0x56bbbf,this;}['setServiceProps'](_0x5a7caf){return this['serviceProps']=_0x5a7caf,this;}['setInstanceCreatedCallback'](_0x5c8af2){return this['onInstanceCreated']=_0x5c8af2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x500b8a,_0xc040fd){this['name']=_0x500b8a,this['container']=_0xc040fd,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x28378d){const _0x32ed8d=this['normalizeInstanceIdentifier'](_0x28378d);if(!this['instancesDeferred']['has'](_0x32ed8d)){const _0x3aa2f8=new Ve();if(this['instancesDeferred']['set'](_0x32ed8d,_0x3aa2f8),this['isInitialized'](_0x32ed8d)||this['shouldAutoInitialize']())try{const _0x147084=this['getOrInitializeService']({'instanceIdentifier':_0x32ed8d});_0x147084&&_0x3aa2f8['resolve'](_0x147084);}catch{}}return this['instancesDeferred']['get'](_0x32ed8d)['promise'];}['getImmediate'](_0x2840c5){const _0x342e72=this['normalizeInstanceIdentifier'](_0x2840c5==null?void 0x0:_0x2840c5['identifier']),_0x4fc0af=(_0x2840c5==null?void 0x0:_0x2840c5['optional'])??!0x1;if(this['isInitialized'](_0x342e72)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x342e72});}catch(_0x770c18){if(_0x4fc0af)return null;throw _0x770c18;}else{if(_0x4fc0af)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xbbc6fa){if(_0xbbc6fa['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xbbc6fa['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xbbc6fa,!!this['shouldAutoInitialize']()){if(Rc(_0xbbc6fa))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5de344,_0xa3d0d2]of this['instancesDeferred']['entries']()){const _0xe26cb2=this['normalizeInstanceIdentifier'](_0x5de344);try{const _0x58cb94=this['getOrInitializeService']({'instanceIdentifier':_0xe26cb2});_0xa3d0d2['resolve'](_0x58cb94);}catch{}}}}['clearInstance'](_0x144c35=ke){this['instancesDeferred']['delete'](_0x144c35),this['instancesOptions']['delete'](_0x144c35),this['instances']['delete'](_0x144c35);}async['delete'](){const _0x50f973=Array['from'](this['instances']['values']());await Promise['all']([..._0x50f973['filter'](_0x140ba1=>'INTERNAL'in _0x140ba1)['map'](_0x258564=>_0x258564['INTERNAL']['delete']()),..._0x50f973['filter'](_0x24af2c=>'_delete'in _0x24af2c)['map'](_0x122078=>_0x122078['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1207a1=ke){return this['instances']['has'](_0x1207a1);}['getOptions'](_0xa18aee=ke){return this['instancesOptions']['get'](_0xa18aee)||{};}['initialize'](_0x1bd6a8={}){const {options:_0x5083f4={}}=_0x1bd6a8,_0x35edd2=this['normalizeInstanceIdentifier'](_0x1bd6a8['instanceIdentifier']);if(this['isInitialized'](_0x35edd2))throw Error(this['name']+'('+_0x35edd2+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0xf93801=this['getOrInitializeService']({'instanceIdentifier':_0x35edd2,'options':_0x5083f4});for(const [_0x51dfaa,_0x1ad03e]of this['instancesDeferred']['entries']()){const _0x5d2560=this['normalizeInstanceIdentifier'](_0x51dfaa);_0x35edd2===_0x5d2560&&_0x1ad03e['resolve'](_0xf93801);}return _0xf93801;}['onInit'](_0x5662f1,_0x5f313e){const _0x1fb5b7=this['normalizeInstanceIdentifier'](_0x5f313e),_0x5b9dcf=this['onInitCallbacks']['get'](_0x1fb5b7)??new Set();_0x5b9dcf['add'](_0x5662f1),this['onInitCallbacks']['set'](_0x1fb5b7,_0x5b9dcf);const _0x2391e4=this['instances']['get'](_0x1fb5b7);return _0x2391e4&&_0x5662f1(_0x2391e4,_0x1fb5b7),()=>{_0x5b9dcf['delete'](_0x5662f1);};}['invokeOnInitCallbacks'](_0x422f62,_0x5f5c8c){const _0xcccb3e=this['onInitCallbacks']['get'](_0x5f5c8c);if(_0xcccb3e){for(const _0x5bef7a of _0xcccb3e)try{_0x5bef7a(_0x422f62,_0x5f5c8c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xf5e4a2,options:_0x1f3375={}}){let _0x1cdc7d=this['instances']['get'](_0xf5e4a2);if(!_0x1cdc7d&&this['component']&&(_0x1cdc7d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xf5e4a2),'options':_0x1f3375}),this['instances']['set'](_0xf5e4a2,_0x1cdc7d),this['instancesOptions']['set'](_0xf5e4a2,_0x1f3375),this['invokeOnInitCallbacks'](_0x1cdc7d,_0xf5e4a2),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xf5e4a2,_0x1cdc7d);}catch{}return _0x1cdc7d||null;}['normalizeInstanceIdentifier'](_0x4c74cc=ke){return this['component']?this['component']['multipleInstances']?_0x4c74cc:ke:_0x4c74cc;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x5ed41d){return _0x5ed41d===ke?void 0x0:_0x5ed41d;}function Rc(_0x5604c4){return _0x5604c4['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x8fe232){this['name']=_0x8fe232,this['providers']=new Map();}['addComponent'](_0x43dadf){const _0x35015c=this['getProvider'](_0x43dadf['name']);if(_0x35015c['isComponentSet']())throw new Error('Component\x20'+_0x43dadf['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x35015c['setComponent'](_0x43dadf);}['addOrOverwriteComponent'](_0x399e83){this['getProvider'](_0x399e83['name'])['isComponentSet']()&&this['providers']['delete'](_0x399e83['name']),this['addComponent'](_0x399e83);}['getProvider'](_0x235064){if(this['providers']['has'](_0x235064))return this['providers']['get'](_0x235064);const _0x42552d=new Sc(_0x235064,this);return this['providers']['set'](_0x235064,_0x42552d),_0x42552d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x6ba7){_0x6ba7[_0x6ba7['DEBUG']=0x0]='DEBUG',_0x6ba7[_0x6ba7['VERBOSE']=0x1]='VERBOSE',_0x6ba7[_0x6ba7['INFO']=0x2]='INFO',_0x6ba7[_0x6ba7['WARN']=0x3]='WARN',_0x6ba7[_0x6ba7['ERROR']=0x4]='ERROR',_0x6ba7[_0x6ba7['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x3903c8,_0x46c55f,..._0x2eac88)=>{if(_0x46c55f<_0x3903c8['logLevel'])return;const _0x1fb8bb=new Date()['toISOString'](),_0x5c6d77=Pc[_0x46c55f];if(_0x5c6d77)console[_0x5c6d77]('['+_0x1fb8bb+']\x20\x20'+_0x3903c8['name']+':',..._0x2eac88);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x46c55f+')');};class xi{constructor(_0x5a164e){this['name']=_0x5a164e,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x282643){if(!(_0x282643 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x282643+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x282643;}['setLogLevel'](_0x1aca3f){this['_logLevel']=typeof _0x1aca3f=='string'?kc[_0x1aca3f]:_0x1aca3f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4977f4){if(typeof _0x4977f4!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4977f4;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x22760d){this['_userLogHandler']=_0x22760d;}['debug'](..._0x84f42c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x84f42c),this['_logHandler'](this,T['DEBUG'],..._0x84f42c);}['log'](..._0x2fb3ec){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2fb3ec),this['_logHandler'](this,T['VERBOSE'],..._0x2fb3ec);}['info'](..._0x50e91d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x50e91d),this['_logHandler'](this,T['INFO'],..._0x50e91d);}['warn'](..._0x3fa7bd){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3fa7bd),this['_logHandler'](this,T['WARN'],..._0x3fa7bd);}['error'](..._0x4c6474){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4c6474),this['_logHandler'](this,T['ERROR'],..._0x4c6474);}}const Dc=(_0x1c93c2,_0x475eb4)=>_0x475eb4['some'](_0x1baa3d=>_0x1c93c2 instanceof _0x1baa3d);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x45d709){const _0x2c0aa8=new Promise((_0x190395,_0x48ef6d)=>{const _0x51487d=()=>{_0x45d709['removeEventListener']('success',_0x4bbe46),_0x45d709['removeEventListener']('error',_0x774eed);},_0x4bbe46=()=>{_0x190395(_e(_0x45d709['result'])),_0x51487d();},_0x774eed=()=>{_0x48ef6d(_0x45d709['error']),_0x51487d();};_0x45d709['addEventListener']('success',_0x4bbe46),_0x45d709['addEventListener']('error',_0x774eed);});return _0x2c0aa8['then'](_0x5d11da=>{_0x5d11da instanceof IDBCursor&&Kr['set'](_0x5d11da,_0x45d709);})['catch'](()=>{}),Fi['set'](_0x2c0aa8,_0x45d709),_0x2c0aa8;}function Fc(_0x59ef31){if(ui['has'](_0x59ef31))return;const _0x12019f=new Promise((_0x2bf593,_0x30fc07)=>{const _0x5d818d=()=>{_0x59ef31['removeEventListener']('complete',_0x53003f),_0x59ef31['removeEventListener']('error',_0x2f3040),_0x59ef31['removeEventListener']('abort',_0x2f3040);},_0x53003f=()=>{_0x2bf593(),_0x5d818d();},_0x2f3040=()=>{_0x30fc07(_0x59ef31['error']||new DOMException('AbortError','AbortError')),_0x5d818d();};_0x59ef31['addEventListener']('complete',_0x53003f),_0x59ef31['addEventListener']('error',_0x2f3040),_0x59ef31['addEventListener']('abort',_0x2f3040);});ui['set'](_0x59ef31,_0x12019f);}let di={'get'(_0x585961,_0x3c2a7b,_0x3465f4){if(_0x585961 instanceof IDBTransaction){if(_0x3c2a7b==='done')return ui['get'](_0x585961);if(_0x3c2a7b==='objectStoreNames')return _0x585961['objectStoreNames']||Yr['get'](_0x585961);if(_0x3c2a7b==='store')return _0x3465f4['objectStoreNames'][0x1]?void 0x0:_0x3465f4['objectStore'](_0x3465f4['objectStoreNames'][0x0]);}return _e(_0x585961[_0x3c2a7b]);},'set'(_0x574a03,_0x441f85,_0x2fec45){return _0x574a03[_0x441f85]=_0x2fec45,!0x0;},'has'(_0xa829f7,_0x52e82a){return _0xa829f7 instanceof IDBTransaction&&(_0x52e82a==='done'||_0x52e82a==='store')?!0x0:_0x52e82a in _0xa829f7;}};function Uc(_0x321778){di=_0x321778(di);}function Wc(_0x36d85d){return _0x36d85d===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5afc83,..._0x1aab5f){const _0x3b3bda=_0x36d85d['call'](Xn(this),_0x5afc83,..._0x1aab5f);return Yr['set'](_0x3b3bda,_0x5afc83['sort']?_0x5afc83['sort']():[_0x5afc83]),_e(_0x3b3bda);}:Lc()['includes'](_0x36d85d)?function(..._0x2462a8){return _0x36d85d['apply'](Xn(this),_0x2462a8),_e(Kr['get'](this));}:function(..._0x481d58){return _e(_0x36d85d['apply'](Xn(this),_0x481d58));};}function Bc(_0x14d7c4){return typeof _0x14d7c4=='function'?Wc(_0x14d7c4):(_0x14d7c4 instanceof IDBTransaction&&Fc(_0x14d7c4),Dc(_0x14d7c4,Mc())?new Proxy(_0x14d7c4,di):_0x14d7c4);}function _e(_0x5ddc81){if(_0x5ddc81 instanceof IDBRequest)return xc(_0x5ddc81);if(Jn['has'](_0x5ddc81))return Jn['get'](_0x5ddc81);const _0x288f4e=Bc(_0x5ddc81);return _0x288f4e!==_0x5ddc81&&(Jn['set'](_0x5ddc81,_0x288f4e),Fi['set'](_0x288f4e,_0x5ddc81)),_0x288f4e;}const Xn=_0x43daf4=>Fi['get'](_0x43daf4);function Vc(_0x3a2b77,_0x5d39f7,{blocked:_0x1afe20,upgrade:_0x5dc405,blocking:_0x41a433,terminated:_0x8cc5ad}={}){const _0x474ba6=indexedDB['open'](_0x3a2b77,_0x5d39f7),_0x251e48=_e(_0x474ba6);return _0x5dc405&&_0x474ba6['addEventListener']('upgradeneeded',_0x282374=>{_0x5dc405(_e(_0x474ba6['result']),_0x282374['oldVersion'],_0x282374['newVersion'],_e(_0x474ba6['transaction']),_0x282374);}),_0x1afe20&&_0x474ba6['addEventListener']('blocked',_0x1f0258=>_0x1afe20(_0x1f0258['oldVersion'],_0x1f0258['newVersion'],_0x1f0258)),_0x251e48['then'](_0x49ade8=>{_0x8cc5ad&&_0x49ade8['addEventListener']('close',()=>_0x8cc5ad()),_0x41a433&&_0x49ade8['addEventListener']('versionchange',_0x314411=>_0x41a433(_0x314411['oldVersion'],_0x314411['newVersion'],_0x314411));})['catch'](()=>{}),_0x251e48;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0xc9481a,_0x2f4e0a){if(!(_0xc9481a instanceof IDBDatabase&&!(_0x2f4e0a in _0xc9481a)&&typeof _0x2f4e0a=='string'))return;if(Zn['get'](_0x2f4e0a))return Zn['get'](_0x2f4e0a);const _0xfeccf9=_0x2f4e0a['replace'](/FromIndex$/,''),_0xdf635d=_0x2f4e0a!==_0xfeccf9,_0x3f7910=$c['includes'](_0xfeccf9);if(!(_0xfeccf9 in(_0xdf635d?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3f7910||Hc['includes'](_0xfeccf9)))return;const _0x57f40c=async function(_0x42830e,..._0x5c8a32){const _0x3cb6e9=this['transaction'](_0x42830e,_0x3f7910?'readwrite':'readonly');let _0x1045a9=_0x3cb6e9['store'];return _0xdf635d&&(_0x1045a9=_0x1045a9['index'](_0x5c8a32['shift']())),(await Promise['all']([_0x1045a9[_0xfeccf9](..._0x5c8a32),_0x3f7910&&_0x3cb6e9['done']]))[0x0];};return Zn['set'](_0x2f4e0a,_0x57f40c),_0x57f40c;}Uc(_0x4f3819=>({..._0x4f3819,'get':(_0x5db1ff,_0x7c2721,_0x368921)=>Os(_0x5db1ff,_0x7c2721)||_0x4f3819['get'](_0x5db1ff,_0x7c2721,_0x368921),'has':(_0xcd3ad2,_0x5421a1)=>!!Os(_0xcd3ad2,_0x5421a1)||_0x4f3819['has'](_0xcd3ad2,_0x5421a1)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x261b2c){this['container']=_0x261b2c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x314231=>{if(qc(_0x314231)){const _0x196c89=_0x314231['getImmediate']();return _0x196c89['library']+'/'+_0x196c89['version'];}else return null;})['filter'](_0xc06572=>_0xc06572)['join']('\x20');}}function qc(_0x16e64a){const _0x5704a6=_0x16e64a['getComponent']();return(_0x5704a6==null?void 0x0:_0x5704a6['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0xb2d9fb,_0x5e3c12){try{_0xb2d9fb['container']['addComponent'](_0x5e3c12);}catch(_0xec68cf){re['debug']('Component\x20'+_0x5e3c12['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xb2d9fb['name'],_0xec68cf);}}function et(_0x57857e){const _0xd162c1=_0x57857e['name'];if(gi['has'](_0xd162c1))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xd162c1+'.'),!0x1;gi['set'](_0xd162c1,_0x57857e);for(const _0xc1b2ff of Le['values']())Ms(_0xc1b2ff,_0x57857e);for(const _0x14a96d of _i['values']())Ms(_0x14a96d,_0x57857e);return!0x0;}function Ui(_0x51e748,_0x596c18){const _0xf84ab6=_0x51e748['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xf84ab6&&_0xf84ab6['triggerHeartbeat'](),_0x51e748['container']['getProvider'](_0x596c18);}function H(_0x537d05){return _0x537d05==null?!0x1:_0x537d05['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x2f5bb4,_0x34b065,_0x423d41){this['_isDeleted']=!0x1,this['_options']={..._0x2f5bb4},this['_config']={..._0x34b065},this['_name']=_0x34b065['name'],this['_automaticDataCollectionEnabled']=_0x34b065['automaticDataCollectionEnabled'],this['_container']=_0x423d41,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2729d2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2729d2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x267f01){this['_isDeleted']=_0x267f01;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x1a6552,_0x1ea5d0={}){let _0x48fd39=_0x1a6552;typeof _0x1ea5d0!='object'&&(_0x1ea5d0={'name':_0x1ea5d0});const _0x210f44={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1ea5d0},_0x458c93=_0x210f44['name'];if(typeof _0x458c93!='string'||!_0x458c93)throw ge['create']('bad-app-name',{'appName':String(_0x458c93)});if(_0x48fd39||(_0x48fd39=$r()),!_0x48fd39)throw ge['create']('no-options');const _0x1a18b8=Le['get'](_0x458c93);if(_0x1a18b8){if(De(_0x48fd39,_0x1a18b8['options'])&&De(_0x210f44,_0x1a18b8['config']))return _0x1a18b8;throw ge['create']('duplicate-app',{'appName':_0x458c93});}const _0x1da617=new Ac(_0x458c93);for(const _0x21fe71 of gi['values']())_0x1da617['addComponent'](_0x21fe71);const _0x310cfe=new Il(_0x48fd39,_0x210f44,_0x1da617);return Le['set'](_0x458c93,_0x310cfe),_0x310cfe;}function Qr(_0x1d0100=pi){const _0x49fbaa=Le['get'](_0x1d0100);if(!_0x49fbaa&&_0x1d0100===pi&&$r())return wl();if(!_0x49fbaa)throw ge['create']('no-app',{'appName':_0x1d0100});return _0x49fbaa;}function l_(){return Array['from'](Le['values']());}async function h_(_0x3b1919){let _0x5b37d2=!0x1;const _0xd368d6=_0x3b1919['name'];Le['has'](_0xd368d6)?(_0x5b37d2=!0x0,Le['delete'](_0xd368d6)):_i['has'](_0xd368d6)&&_0x3b1919['decRefCount']()<=0x0&&(_i['delete'](_0xd368d6),_0x5b37d2=!0x0),_0x5b37d2&&(await Promise['all'](_0x3b1919['container']['getProviders']()['map'](_0x295e16=>_0x295e16['delete']())),_0x3b1919['isDeleted']=!0x0);}function me(_0x509a15,_0x371533,_0x52650c){let _0x39db95=vl[_0x509a15]??_0x509a15;_0x52650c&&(_0x39db95+='-'+_0x52650c);const _0x40daeb=_0x39db95['match'](/\s|\//),_0x56283c=_0x371533['match'](/\s|\//);if(_0x40daeb||_0x56283c){const _0x5a5016=['Unable\x20to\x20register\x20library\x20\x22'+_0x39db95+'\x22\x20with\x20version\x20\x22'+_0x371533+'\x22:'];_0x40daeb&&_0x5a5016['push']('library\x20name\x20\x22'+_0x39db95+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x40daeb&&_0x56283c&&_0x5a5016['push']('and'),_0x56283c&&_0x5a5016['push']('version\x20name\x20\x22'+_0x371533+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5a5016['join']('\x20'));return;}et(new Me(_0x39db95+'-version',()=>({'library':_0x39db95,'version':_0x371533}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x8eb9ef,_0x29e2d6)=>{switch(_0x29e2d6){case 0x0:try{_0x8eb9ef['createObjectStore'](Rt);}catch(_0x547564){console['warn'](_0x547564);}}}})['catch'](_0xafe9ed=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xafe9ed['message']});})),ei;}async function Sl(_0x22fc7d){try{const _0x58b2b0=(await Jr())['transaction'](Rt),_0x379fe5=await _0x58b2b0['objectStore'](Rt)['get'](Xr(_0x22fc7d));return await _0x58b2b0['done'],_0x379fe5;}catch(_0x172bbf){if(_0x172bbf instanceof Se)re['warn'](_0x172bbf['message']);else{const _0x4f8aff=ge['create']('idb-get',{'originalErrorMessage':_0x172bbf==null?void 0x0:_0x172bbf['message']});re['warn'](_0x4f8aff['message']);}}}async function Ls(_0x366617,_0x2f1fc4){try{const _0x1b7feb=(await Jr())['transaction'](Rt,'readwrite');await _0x1b7feb['objectStore'](Rt)['put'](_0x2f1fc4,Xr(_0x366617)),await _0x1b7feb['done'];}catch(_0x46d4e2){if(_0x46d4e2 instanceof Se)re['warn'](_0x46d4e2['message']);else{const _0xad0547=ge['create']('idb-set',{'originalErrorMessage':_0x46d4e2==null?void 0x0:_0x46d4e2['message']});re['warn'](_0xad0547['message']);}}}function Xr(_0x11ca2b){return _0x11ca2b['name']+'!'+_0x11ca2b['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x58ba63){this['container']=_0x58ba63,this['_heartbeatsCache']=null;const _0x2bf8a3=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2bf8a3),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2f2fdf=>(this['_heartbeatsCache']=_0x2f2fdf,_0x2f2fdf));}async['triggerHeartbeat'](){var _0x164ee9,_0x1d76c5;try{const _0x630a30=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x41ff7e=xs();if(((_0x164ee9=this['_heartbeatsCache'])==null?void 0x0:_0x164ee9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1d76c5=this['_heartbeatsCache'])==null?void 0x0:_0x1d76c5['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x41ff7e||this['_heartbeatsCache']['heartbeats']['some'](_0x1dd50f=>_0x1dd50f['date']===_0x41ff7e))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x41ff7e,'agent':_0x630a30}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1ad7ef=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1ad7ef,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4c11b5){re['warn'](_0x4c11b5);}}async['getHeartbeatsHeader'](){var _0x4fa3f9;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4fa3f9=this['_heartbeatsCache'])==null?void 0x0:_0x4fa3f9['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x42c034=xs(),{heartbeatsToSend:_0x14b343,unsentEntries:_0x3817e4}=kl(this['_heartbeatsCache']['heartbeats']),_0x488b6e=an(JSON['stringify']({'version':0x2,'heartbeats':_0x14b343}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x42c034,_0x3817e4['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3817e4,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x488b6e;}catch(_0x138315){return re['warn'](_0x138315),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x3f491e,_0x260340=bl){const _0x3c784f=[];let _0x4997da=_0x3f491e['slice']();for(const _0x46ce15 of _0x3f491e){const _0x3ce184=_0x3c784f['find'](_0x2ecda2=>_0x2ecda2['agent']===_0x46ce15['agent']);if(_0x3ce184){if(_0x3ce184['dates']['push'](_0x46ce15['date']),Fs(_0x3c784f)>_0x260340){_0x3ce184['dates']['pop']();break;}}else{if(_0x3c784f['push']({'agent':_0x46ce15['agent'],'dates':[_0x46ce15['date']]}),Fs(_0x3c784f)>_0x260340){_0x3c784f['pop']();break;}}_0x4997da=_0x4997da['slice'](0x1);}return{'heartbeatsToSend':_0x3c784f,'unsentEntries':_0x4997da};}class Nl{constructor(_0x5e301e){this['app']=_0x5e301e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x54ed61=await Sl(this['app']);return _0x54ed61!=null&&_0x54ed61['heartbeats']?_0x54ed61:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x508530){if(await this['_canUseIndexedDBPromise']){const _0x5014a8=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x508530['lastSentHeartbeatDate']??_0x5014a8['lastSentHeartbeatDate'],'heartbeats':_0x508530['heartbeats']});}else return;}async['add'](_0x32f4ca){if(await this['_canUseIndexedDBPromise']){const _0x49175a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x32f4ca['lastSentHeartbeatDate']??_0x49175a['lastSentHeartbeatDate'],'heartbeats':[..._0x49175a['heartbeats'],..._0x32f4ca['heartbeats']]});}else return;}}function Fs(_0x5fc247){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x5fc247}))['length'];}function Pl(_0x300893){if(_0x300893['length']===0x0)return-0x1;let _0xee5dbc=0x0,_0x36cead=_0x300893[0x0]['date'];for(let _0x3dc938=0x1;_0x3dc938<_0x300893['length'];_0x3dc938++)_0x300893[_0x3dc938]['date']<_0x36cead&&(_0x36cead=_0x300893[_0x3dc938]['date'],_0xee5dbc=_0x3dc938);return _0xee5dbc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4559c6){et(new Me('platform-logger',_0x220f98=>new Gc(_0x220f98),'PRIVATE')),et(new Me('heartbeat',_0x36e1e5=>new Al(_0x36e1e5),'PRIVATE')),me(fi,Ds,_0x4559c6),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x27a539){Zr=_0x27a539;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x427ec3){this['domStorage_']=_0x427ec3,this['prefix_']='firebase:';}['set'](_0x15bba1,_0x12e952){_0x12e952==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x15bba1)):this['domStorage_']['setItem'](this['prefixedName_'](_0x15bba1),O(_0x12e952));}['get'](_0x3f4e87){const _0x35a1e6=this['domStorage_']['getItem'](this['prefixedName_'](_0x3f4e87));return _0x35a1e6==null?null:bt(_0x35a1e6);}['remove'](_0x411092){this['domStorage_']['removeItem'](this['prefixedName_'](_0x411092));}['prefixedName_'](_0x157cb6){return this['prefix_']+_0x157cb6;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4a7d58,_0x219b0b){_0x219b0b==null?delete this['cache_'][_0x4a7d58]:this['cache_'][_0x4a7d58]=_0x219b0b;}['get'](_0x7031fa){return Y(this['cache_'],_0x7031fa)?this['cache_'][_0x7031fa]:null;}['remove'](_0x507da1){delete this['cache_'][_0x507da1];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x334ab6){try{if(typeof window<'u'&&typeof window[_0x334ab6]<'u'){const _0x1d1ca6=window[_0x334ab6];return _0x1d1ca6['setItem']('firebase:sentinel','cache'),_0x1d1ca6['removeItem']('firebase:sentinel'),new xl(_0x1d1ca6);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x49a30a=0x1;return function(){return _0x49a30a++;};}()),no=function(_0x5b4f95){const _0x641315=Tc(_0x5b4f95),_0x1f9b65=new Ec();_0x1f9b65['update'](_0x641315);const _0x593a03=_0x1f9b65['digest']();return Di['encodeByteArray'](_0x593a03);},Bt=function(..._0x3ee7dc){let _0x2a6ef5='';for(let _0xf1d27c=0x0;_0xf1d27c<_0x3ee7dc['length'];_0xf1d27c++){const _0x3b38ed=_0x3ee7dc[_0xf1d27c];Array['isArray'](_0x3b38ed)||_0x3b38ed&&typeof _0x3b38ed=='object'&&typeof _0x3b38ed['length']=='number'?_0x2a6ef5+=Bt['apply'](null,_0x3b38ed):typeof _0x3b38ed=='object'?_0x2a6ef5+=O(_0x3b38ed):_0x2a6ef5+=_0x3b38ed,_0x2a6ef5+='\x20';}return _0x2a6ef5;};let Et=null,Vs=!0x0;const Wl=function(_0x31b5cf,_0x3a7fcb){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x310775){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x123c9c=Bt['apply'](null,_0x310775);Et(_0x123c9c);}},Vt=function(_0x155410){return function(..._0x46e4a7){L(_0x155410,..._0x46e4a7);};},mi=function(..._0x211693){const _0x1f8852='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x211693);Qe['error'](_0x1f8852);},oe=function(..._0x3ffcf0){const _0x49b2f5='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x3ffcf0);throw Qe['error'](_0x49b2f5),new Error(_0x49b2f5);},U=function(..._0x50ad79){const _0x29743d='FIREBASE\x20WARNING:\x20'+Bt(..._0x50ad79);Qe['warn'](_0x29743d);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x5481b1){return typeof _0x5481b1=='number'&&(_0x5481b1!==_0x5481b1||_0x5481b1===Number['POSITIVE_INFINITY']||_0x5481b1===Number['NEGATIVE_INFINITY']);},Vl=function(_0x35c66c){if(document['readyState']==='complete')_0x35c66c();else{let _0x4d5cf1=!0x1;const _0x3d218b=function(){if(!document['body']){setTimeout(_0x3d218b,Math['floor'](0xa));return;}_0x4d5cf1||(_0x4d5cf1=!0x0,_0x35c66c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3d218b,!0x1),window['addEventListener']('load',_0x3d218b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3d218b();}),window['attachEvent']('onload',_0x3d218b));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x40aa24,_0x30e07e){if(_0x40aa24===_0x30e07e)return 0x0;if(_0x40aa24===xe||_0x30e07e===Ie)return-0x1;if(_0x30e07e===xe||_0x40aa24===Ie)return 0x1;{const _0x420ecb=Hs(_0x40aa24),_0x5496f5=Hs(_0x30e07e);return _0x420ecb!==null?_0x5496f5!==null?_0x420ecb-_0x5496f5===0x0?_0x40aa24['length']-_0x30e07e['length']:_0x420ecb-_0x5496f5:-0x1:_0x5496f5!==null?0x1:_0x40aa24<_0x30e07e?-0x1:0x1;}},Hl=function(_0x59d18f,_0x53e0f3){return _0x59d18f===_0x53e0f3?0x0:_0x59d18f<_0x53e0f3?-0x1:0x1;},pt=function(_0x35d390,_0xf5b9f9){if(_0xf5b9f9&&_0x35d390 in _0xf5b9f9)return _0xf5b9f9[_0x35d390];throw new Error('Missing\x20required\x20key\x20('+_0x35d390+')\x20in\x20object:\x20'+O(_0xf5b9f9));},Bi=function(_0x2a3403){if(typeof _0x2a3403!='object'||_0x2a3403===null)return O(_0x2a3403);const _0x928c91=[];for(const _0x2f3f28 in _0x2a3403)_0x928c91['push'](_0x2f3f28);_0x928c91['sort']();let _0x3a0c63='{';for(let _0x49b208=0x0;_0x49b208<_0x928c91['length'];_0x49b208++)_0x49b208!==0x0&&(_0x3a0c63+=','),_0x3a0c63+=O(_0x928c91[_0x49b208]),_0x3a0c63+=':',_0x3a0c63+=Bi(_0x2a3403[_0x928c91[_0x49b208]]);return _0x3a0c63+='}',_0x3a0c63;},io=function(_0x39cdff,_0x43f626){const _0x3a9a34=_0x39cdff['length'];if(_0x3a9a34<=_0x43f626)return[_0x39cdff];const _0x4c30ca=[];for(let _0x1fd4a1=0x0;_0x1fd4a1<_0x3a9a34;_0x1fd4a1+=_0x43f626)_0x1fd4a1+_0x43f626>_0x3a9a34?_0x4c30ca['push'](_0x39cdff['substring'](_0x1fd4a1,_0x3a9a34)):_0x4c30ca['push'](_0x39cdff['substring'](_0x1fd4a1,_0x1fd4a1+_0x43f626));return _0x4c30ca;};function x(_0x2f5364,_0xa75f2f){for(const _0x2da419 in _0x2f5364)_0x2f5364['hasOwnProperty'](_0x2da419)&&_0xa75f2f(_0x2da419,_0x2f5364[_0x2da419]);}const so=function(_0x1f3217){f(!Wi(_0x1f3217),'Invalid\x20JSON\x20number');const _0x1e60ae=0xb,_0x411eb2=0x34,_0x513c56=(0x1<<_0x1e60ae-0x1)-0x1;let _0x3d6416,_0x42cabe,_0x7059e8,_0x473484,_0x18702f;_0x1f3217===0x0?(_0x42cabe=0x0,_0x7059e8=0x0,_0x3d6416=0x1/_0x1f3217===-0x1/0x0?0x1:0x0):(_0x3d6416=_0x1f3217<0x0,_0x1f3217=Math['abs'](_0x1f3217),_0x1f3217>=Math['pow'](0x2,0x1-_0x513c56)?(_0x473484=Math['min'](Math['floor'](Math['log'](_0x1f3217)/Math['LN2']),_0x513c56),_0x42cabe=_0x473484+_0x513c56,_0x7059e8=Math['round'](_0x1f3217*Math['pow'](0x2,_0x411eb2-_0x473484)-Math['pow'](0x2,_0x411eb2))):(_0x42cabe=0x0,_0x7059e8=Math['round'](_0x1f3217/Math['pow'](0x2,0x1-_0x513c56-_0x411eb2))));const _0x23a48c=[];for(_0x18702f=_0x411eb2;_0x18702f;_0x18702f-=0x1)_0x23a48c['push'](_0x7059e8%0x2?0x1:0x0),_0x7059e8=Math['floor'](_0x7059e8/0x2);for(_0x18702f=_0x1e60ae;_0x18702f;_0x18702f-=0x1)_0x23a48c['push'](_0x42cabe%0x2?0x1:0x0),_0x42cabe=Math['floor'](_0x42cabe/0x2);_0x23a48c['push'](_0x3d6416?0x1:0x0),_0x23a48c['reverse']();const _0x25db03=_0x23a48c['join']('');let _0x43c740='';for(_0x18702f=0x0;_0x18702f<0x40;_0x18702f+=0x8){let _0x6319ea=parseInt(_0x25db03['substr'](_0x18702f,0x8),0x2)['toString'](0x10);_0x6319ea['length']===0x1&&(_0x6319ea='0'+_0x6319ea),_0x43c740=_0x43c740+_0x6319ea;}return _0x43c740['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x50d63e,_0x4cc541){let _0x3d028e='Unknown\x20Error';_0x50d63e==='too_big'?_0x3d028e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x50d63e==='permission_denied'?_0x3d028e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x50d63e==='unavailable'&&(_0x3d028e='The\x20service\x20is\x20unavailable');const _0x5537db=new Error(_0x50d63e+'\x20at\x20'+_0x4cc541['_path']['toString']()+':\x20'+_0x3d028e);return _0x5537db['code']=_0x50d63e['toUpperCase'](),_0x5537db;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x4469c0){if(zl['test'](_0x4469c0)){const _0x4e87c4=Number(_0x4469c0);if(_0x4e87c4>=jl&&_0x4e87c4<=Kl)return _0x4e87c4;}return null;},lt=function(_0x5ae351){try{_0x5ae351();}catch(_0x2a6b6e){setTimeout(()=>{const _0x2e9fc3=_0x2a6b6e['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2e9fc3),_0x2a6b6e;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x301d6b,_0x4164a4){const _0xf39251=setTimeout(_0x301d6b,_0x4164a4);return typeof _0xf39251=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xf39251):typeof _0xf39251=='object'&&_0xf39251['unref']&&_0xf39251['unref'](),_0xf39251;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x35f82f,_0x19b78d){this['appCheckProvider']=_0x19b78d,this['appName']=_0x35f82f['name'],H(_0x35f82f)&&_0x35f82f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x35f82f['settings']['appCheckToken']),this['appCheck']=_0x19b78d==null?void 0x0:_0x19b78d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x19b78d==null||_0x19b78d['get']()['then'](_0x425cb8=>this['appCheck']=_0x425cb8);}['getToken'](_0x5504b3){if(this['serverAppAppCheckToken']){if(_0x5504b3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5504b3):new Promise((_0x274af8,_0x408e1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5504b3)['then'](_0x274af8,_0x408e1):_0x274af8(null);},0x0);});}['addTokenChangeListener'](_0x44539b){var _0x1bb86a;(_0x1bb86a=this['appCheckProvider'])==null||_0x1bb86a['get']()['then'](_0x1e5c20=>_0x1e5c20['addTokenListener'](_0x44539b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1800c3,_0x573754,_0x17bccd){this['appName_']=_0x1800c3,this['firebaseOptions_']=_0x573754,this['authProvider_']=_0x17bccd,this['auth_']=null,this['auth_']=_0x17bccd['getImmediate']({'optional':!0x0}),this['auth_']||_0x17bccd['onInit'](_0xb1b299=>this['auth_']=_0xb1b299);}['getToken'](_0x492b83){return this['auth_']?this['auth_']['getToken'](_0x492b83)['catch'](_0x40751d=>_0x40751d&&_0x40751d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x40751d)):new Promise((_0x53d801,_0x353402)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x492b83)['then'](_0x53d801,_0x353402):_0x53d801(null);},0x0);});}['addTokenChangeListener'](_0x766125){this['auth_']?this['auth_']['addAuthTokenListener'](_0x766125):this['authProvider_']['get']()['then'](_0x29bf87=>_0x29bf87['addAuthTokenListener'](_0x766125));}['removeTokenChangeListener'](_0x597055){this['authProvider_']['get']()['then'](_0x1f75f5=>_0x1f75f5['removeAuthTokenListener'](_0x597055));}['notifyForInvalidToken'](){let _0x3ef191='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3ef191+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3ef191+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3ef191+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3ef191);}}class tn{constructor(_0x2bba72){this['accessToken']=_0x2bba72;}['getToken'](_0x30987e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x56b42b){_0x56b42b(this['accessToken']);}['removeTokenChangeListener'](_0x5d77d4){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x26b011,_0x1d1082,_0x204de8,_0x57bd38,_0x15fb6b=!0x1,_0x400115='',_0x6aab8e=!0x1,_0x424f60=!0x1,_0x46ec9f=null){this['secure']=_0x1d1082,this['namespace']=_0x204de8,this['webSocketOnly']=_0x57bd38,this['nodeAdmin']=_0x15fb6b,this['persistenceKey']=_0x400115,this['includeNamespaceInQueryParams']=_0x6aab8e,this['isUsingEmulator']=_0x424f60,this['emulatorOptions']=_0x46ec9f,this['_host']=_0x26b011['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x26b011)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xb4c7ba){_0xb4c7ba!==this['internalHost']&&(this['internalHost']=_0xb4c7ba,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x23084b=this['toURLString']();return this['persistenceKey']&&(_0x23084b+='<'+this['persistenceKey']+'>'),_0x23084b;}['toURLString'](){const _0x428cd3=this['secure']?'https://':'http://',_0x45175b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x428cd3+this['host']+'/'+_0x45175b;}}function Xl(_0x59c011){return _0x59c011['host']!==_0x59c011['internalHost']||_0x59c011['isCustomHost']()||_0x59c011['includeNamespaceInQueryParams'];}function go(_0x4ebc04,_0x35a614,_0x4939a0){f(typeof _0x35a614=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4939a0=='object','typeof\x20params\x20must\x20==\x20object');let _0x402978;if(_0x35a614===fo)_0x402978=(_0x4ebc04['secure']?'wss://':'ws://')+_0x4ebc04['internalHost']+'/.ws?';else{if(_0x35a614===po)_0x402978=(_0x4ebc04['secure']?'https://':'http://')+_0x4ebc04['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x35a614);}Xl(_0x4ebc04)&&(_0x4939a0['ns']=_0x4ebc04['namespace']);const _0x3c1efb=[];return x(_0x4939a0,(_0xb9682b,_0x1170bd)=>{_0x3c1efb['push'](_0xb9682b+'='+_0x1170bd);}),_0x402978+_0x3c1efb['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x119a7b,_0x2a5aa9=0x1){Y(this['counters_'],_0x119a7b)||(this['counters_'][_0x119a7b]=0x0),this['counters_'][_0x119a7b]+=_0x2a5aa9;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5ad1f2){const _0x49830c=_0x5ad1f2['toString']();return ti[_0x49830c]||(ti[_0x49830c]=new Zl()),ti[_0x49830c];}function eh(_0x38f892,_0x14ea85){const _0x39bb7b=_0x38f892['toString']();return ni[_0x39bb7b]||(ni[_0x39bb7b]=_0x14ea85()),ni[_0x39bb7b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2ef26a){this['onMessage_']=_0x2ef26a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x41a521,_0x39f318){this['closeAfterResponse']=_0x41a521,this['onClose']=_0x39f318,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x10de6b,_0x5ed11a){for(this['pendingResponses'][_0x10de6b]=_0x5ed11a;this['pendingResponses'][this['currentResponseNum']];){const _0x383720=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x465488=0x0;_0x465488<_0x383720['length'];++_0x465488)_0x383720[_0x465488]&&lt(()=>{this['onMessage_'](_0x383720[_0x465488]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2af708,_0x42e9ab,_0x1c2c99,_0xeb9e2f,_0xb0edb2,_0x221ae7,_0x4f11fb){this['connId']=_0x2af708,this['repoInfo']=_0x42e9ab,this['applicationId']=_0x1c2c99,this['appCheckToken']=_0xeb9e2f,this['authToken']=_0xb0edb2,this['transportSessionId']=_0x221ae7,this['lastSessionId']=_0x4f11fb,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2af708),this['stats_']=Hi(_0x42e9ab),this['urlFn']=_0x5a8335=>(this['appCheckToken']&&(_0x5a8335[yi]=this['appCheckToken']),go(_0x42e9ab,po,_0x5a8335));}['open'](_0x33a029,_0x24444f){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x24444f,this['myPacketOrderer']=new th(_0x33a029),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x3f0be9)=>{const [_0x53e35a,_0x1082ed,_0x258d96,_0x16c233,_0x19ff8d]=_0x3f0be9;if(this['incrementIncomingBytes_'](_0x3f0be9),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x53e35a===$s)this['id']=_0x1082ed,this['password']=_0x258d96;else{if(_0x53e35a===nh)_0x1082ed?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1082ed,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x53e35a);}}},(..._0x31b6e1)=>{const [_0x15e54f,_0x4a00a3]=_0x31b6e1;this['incrementIncomingBytes_'](_0x31b6e1),this['myPacketOrderer']['handleResponse'](_0x15e54f,_0x4a00a3);},()=>{this['onClosed_']();},this['urlFn']);const _0x49df5b={};_0x49df5b[$s]='t',_0x49df5b[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x49df5b[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x49df5b[ro]=Vi,this['transportSessionId']&&(_0x49df5b[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x49df5b[ho]=this['lastSessionId']),this['applicationId']&&(_0x49df5b[uo]=this['applicationId']),this['appCheckToken']&&(_0x49df5b[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x49df5b[ao]=co);const _0x62749f=this['urlFn'](_0x49df5b);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x62749f),this['scriptTagHolder']['addTag'](_0x62749f,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xcfb211){const _0x4ffff9=O(_0xcfb211);this['bytesSent']+=_0x4ffff9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4ffff9['length']);const _0x95520a=Br(_0x4ffff9),_0x13a5c0=io(_0x95520a,hh);for(let _0x109b0d=0x0;_0x109b0d<_0x13a5c0['length'];_0x109b0d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x13a5c0['length'],_0x13a5c0[_0x109b0d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x23de1d,_0x5aaf77){this['myDisconnFrame']=document['createElement']('iframe');const _0x49edac={};_0x49edac[lh]='t',_0x49edac[mo]=_0x23de1d,_0x49edac[yo]=_0x5aaf77,this['myDisconnFrame']['src']=this['urlFn'](_0x49edac),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x45e183){const _0x500a5c=O(_0x45e183)['length'];this['bytesReceived']+=_0x500a5c,this['stats_']['incrementCounter']('bytes_received',_0x500a5c);}}class $i{constructor(_0x431fe0,_0x5f053f,_0x1b9f52,_0x4b9c12){this['onDisconnect']=_0x1b9f52,this['urlFn']=_0x4b9c12,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x431fe0,window[sh+this['uniqueCallbackIdentifier']]=_0x5f053f,this['myIFrame']=$i['createIFrame_']();let _0x2abd0f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2abd0f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x37fe6a='<html><body>'+_0x2abd0f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x37fe6a),this['myIFrame']['doc']['close']();}catch(_0x1a8fd3){L('frame\x20writing\x20exception'),_0x1a8fd3['stack']&&L(_0x1a8fd3['stack']),L(_0x1a8fd3);}}}static['createIFrame_'](){const _0x3fd4f9=document['createElement']('iframe');if(_0x3fd4f9['style']['display']='none',document['body']){document['body']['appendChild'](_0x3fd4f9);try{_0x3fd4f9['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x25e3e6=document['domain'];_0x3fd4f9['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x25e3e6+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3fd4f9['contentDocument']?_0x3fd4f9['doc']=_0x3fd4f9['contentDocument']:_0x3fd4f9['contentWindow']?_0x3fd4f9['doc']=_0x3fd4f9['contentWindow']['document']:_0x3fd4f9['document']&&(_0x3fd4f9['doc']=_0x3fd4f9['document']),_0x3fd4f9;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5b894a=this['onDisconnect'];_0x5b894a&&(this['onDisconnect']=null,_0x5b894a());}['startLongPoll'](_0x5aac7d,_0x2e9d36){for(this['myID']=_0x5aac7d,this['myPW']=_0x2e9d36,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5527c1={};_0x5527c1[mo]=this['myID'],_0x5527c1[yo]=this['myPW'],_0x5527c1[vo]=this['currentSerial'];let _0x5f3e08=this['urlFn'](_0x5527c1),_0x31ad61='',_0x29a6e6=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x31ad61['length']<=Eo;){const _0x20fe83=this['pendingSegs']['shift']();_0x31ad61=_0x31ad61+'&'+oh+_0x29a6e6+'='+_0x20fe83['seg']+'&'+ah+_0x29a6e6+'='+_0x20fe83['ts']+'&'+ch+_0x29a6e6+'='+_0x20fe83['d'],_0x29a6e6++;}return _0x5f3e08=_0x5f3e08+_0x31ad61,this['addLongPollTag_'](_0x5f3e08,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2fa000,_0x5c79e4,_0x3428c8){this['pendingSegs']['push']({'seg':_0x2fa000,'ts':_0x5c79e4,'d':_0x3428c8}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1ed536,_0x1a3469){this['outstandingRequests']['add'](_0x1a3469);const _0x306e05=()=>{this['outstandingRequests']['delete'](_0x1a3469),this['newRequest_']();},_0x23c10d=setTimeout(_0x306e05,Math['floor'](uh)),_0x3d1bdb=()=>{clearTimeout(_0x23c10d),_0x306e05();};this['addTag'](_0x1ed536,_0x3d1bdb);}['addTag'](_0x1b9016,_0x57c9de){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4bda45=this['myIFrame']['doc']['createElement']('script');_0x4bda45['type']='text/javascript',_0x4bda45['async']=!0x0,_0x4bda45['src']=_0x1b9016,_0x4bda45['onload']=_0x4bda45['onreadystatechange']=function(){const _0x3edde3=_0x4bda45['readyState'];(!_0x3edde3||_0x3edde3==='loaded'||_0x3edde3==='complete')&&(_0x4bda45['onload']=_0x4bda45['onreadystatechange']=null,_0x4bda45['parentNode']&&_0x4bda45['parentNode']['removeChild'](_0x4bda45),_0x57c9de());},_0x4bda45['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x1b9016),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4bda45);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x55ab34,_0x4d4a54,_0x201935,_0x3be36c,_0x1092e5,_0x39c06a,_0x3ee48c){this['connId']=_0x55ab34,this['applicationId']=_0x201935,this['appCheckToken']=_0x3be36c,this['authToken']=_0x1092e5,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x4d4a54),this['connURL']=G['connectionURL_'](_0x4d4a54,_0x39c06a,_0x3ee48c,_0x3be36c,_0x201935),this['nodeAdmin']=_0x4d4a54['nodeAdmin'];}static['connectionURL_'](_0x41e48d,_0x37ac52,_0x2d17cc,_0x41dbcf,_0x3eed94){const _0x3491ff={};return _0x3491ff[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3491ff[ao]=co),_0x37ac52&&(_0x3491ff[oo]=_0x37ac52),_0x2d17cc&&(_0x3491ff[ho]=_0x2d17cc),_0x41dbcf&&(_0x3491ff[yi]=_0x41dbcf),_0x3eed94&&(_0x3491ff[uo]=_0x3eed94),go(_0x41e48d,fo,_0x3491ff);}['open'](_0x5605f5,_0x57cf72){this['onDisconnect']=_0x57cf72,this['onMessage']=_0x5605f5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x50443b;dc(),this['mySock']=new hn(this['connURL'],[],_0x50443b);}catch(_0x27b90e){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x439881=_0x27b90e['message']||_0x27b90e['data'];_0x439881&&this['log_'](_0x439881),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xac98c6=>{this['handleIncomingFrame'](_0xac98c6);},this['mySock']['onerror']=_0x4a1751=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5975d4=_0x4a1751['message']||_0x4a1751['data'];_0x5975d4&&this['log_'](_0x5975d4),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x29f89b=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x390e76=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3c7f95=navigator['userAgent']['match'](_0x390e76);_0x3c7f95&&_0x3c7f95['length']>0x1&&parseFloat(_0x3c7f95[0x1])<4.4&&(_0x29f89b=!0x0);}return!_0x29f89b&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3dca30){if(this['frames']['push'](_0x3dca30),this['frames']['length']===this['totalFrames']){const _0x7378c9=this['frames']['join']('');this['frames']=null;const _0x2816c5=bt(_0x7378c9);this['onMessage'](_0x2816c5);}}['handleNewFrameCount_'](_0x7fb0b7){this['totalFrames']=_0x7fb0b7,this['frames']=[];}['extractFrameCount_'](_0x27fb7b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x27fb7b['length']<=0x6){const _0x48c6a8=Number(_0x27fb7b);if(!isNaN(_0x48c6a8))return this['handleNewFrameCount_'](_0x48c6a8),null;}return this['handleNewFrameCount_'](0x1),_0x27fb7b;}['handleIncomingFrame'](_0x5b21f2){if(this['mySock']===null)return;const _0x2e6a3a=_0x5b21f2['data'];if(this['bytesReceived']+=_0x2e6a3a['length'],this['stats_']['incrementCounter']('bytes_received',_0x2e6a3a['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2e6a3a);else{const _0x4d4f2a=this['extractFrameCount_'](_0x2e6a3a);_0x4d4f2a!==null&&this['appendFrame_'](_0x4d4f2a);}}['send'](_0x345941){this['resetKeepAlive']();const _0x255e4c=O(_0x345941);this['bytesSent']+=_0x255e4c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x255e4c['length']);const _0x24f49d=io(_0x255e4c,fh);_0x24f49d['length']>0x1&&this['sendString_'](String(_0x24f49d['length']));for(let _0x5aabc9=0x0;_0x5aabc9<_0x24f49d['length'];_0x5aabc9++)this['sendString_'](_0x24f49d[_0x5aabc9]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x41cb22){try{this['mySock']['send'](_0x41cb22);}catch(_0x281f05){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x281f05['message']||_0x281f05['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x41a843){this['initTransports_'](_0x41a843);}['initTransports_'](_0xfbba48){const _0x1499eb=G&&G['isAvailable']();let _0x4506fe=_0x1499eb&&!G['previouslyFailed']();if(_0xfbba48['webSocketOnly']&&(_0x1499eb||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4506fe=!0x0),_0x4506fe)this['transports_']=[G];else{const _0x144a48=this['transports_']=[];for(const _0x419384 of At['ALL_TRANSPORTS'])_0x419384&&_0x419384['isAvailable']()&&_0x144a48['push'](_0x419384);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4cd57,_0x28694d,_0x50a546,_0x2af9ee,_0x1ab7d5,_0x321949,_0x1c86b9,_0x1bd2a0,_0x4361d7,_0x4fe26a){this['id']=_0x4cd57,this['repoInfo_']=_0x28694d,this['applicationId_']=_0x50a546,this['appCheckToken_']=_0x2af9ee,this['authToken_']=_0x1ab7d5,this['onMessage_']=_0x321949,this['onReady_']=_0x1c86b9,this['onDisconnect_']=_0x1bd2a0,this['onKill_']=_0x4361d7,this['lastSessionId']=_0x4fe26a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x28694d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5a39de=this['transportManager_']['initialTransport']();this['conn_']=new _0x5a39de(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5a39de['responsesRequiredToBeHealthy']||0x0;const _0x5b90cc=this['connReceiver_'](this['conn_']),_0xc9a2c8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5b90cc,_0xc9a2c8);},Math['floor'](0x0));const _0x43a2c2=_0x5a39de['healthyTimeout']||0x0;_0x43a2c2>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x43a2c2)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1a27b5){return _0x5c9bc8=>{_0x1a27b5===this['conn_']?this['onConnectionLost_'](_0x5c9bc8):_0x1a27b5===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x41dd7f){return _0x20d154=>{this['state_']!==0x2&&(_0x41dd7f===this['rx_']?this['onPrimaryMessageReceived_'](_0x20d154):_0x41dd7f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x20d154):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4241fc){const _0x2edcfb={'t':'d','d':_0x4241fc};this['sendData_'](_0x2edcfb);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x465a11){if(ii in _0x465a11){const _0x155926=_0x465a11[ii];_0x155926===js?this['upgradeIfSecondaryHealthy_']():_0x155926===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x155926===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x214447){const _0x309476=pt('t',_0x214447),_0x7f7ef0=pt('d',_0x214447);if(_0x309476==='c')this['onSecondaryControl_'](_0x7f7ef0);else{if(_0x309476==='d')this['pendingDataMessages']['push'](_0x7f7ef0);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x309476);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x573dcb){const _0x29ab34=pt('t',_0x573dcb),_0x52f45c=pt('d',_0x573dcb);_0x29ab34==='c'?this['onControl_'](_0x52f45c):_0x29ab34==='d'&&this['onDataMessage_'](_0x52f45c);}['onDataMessage_'](_0x5b37d9){this['onPrimaryResponse_'](),this['onMessage_'](_0x5b37d9);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4ed2fc){const _0x31fcb7=pt(ii,_0x4ed2fc);if(Gs in _0x4ed2fc){const _0x478372=_0x4ed2fc[Gs];if(_0x31fcb7===Ih){const _0x51abb0={..._0x478372};this['repoInfo_']['isUsingEmulator']&&(_0x51abb0['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x51abb0);}else{if(_0x31fcb7===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x55a82e=0x0;_0x55a82e<this['pendingDataMessages']['length'];++_0x55a82e)this['onDataMessage_'](this['pendingDataMessages'][_0x55a82e]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x31fcb7===vh?this['onConnectionShutdown_'](_0x478372):_0x31fcb7===qs?this['onReset_'](_0x478372):_0x31fcb7===Eh?mi('Server\x20Error:\x20'+_0x478372):_0x31fcb7===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x31fcb7);}}}['onHandshake_'](_0x115b42){const _0x5441fd=_0x115b42['ts'],_0x5c81fe=_0x115b42['v'],_0x1ff8f1=_0x115b42['h'];this['sessionId']=_0x115b42['s'],this['repoInfo_']['host']=_0x1ff8f1,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5441fd),Vi!==_0x5c81fe&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2d9bc7=this['transportManager_']['upgradeTransport']();_0x2d9bc7&&this['startUpgrade_'](_0x2d9bc7);}['startUpgrade_'](_0x3aa8a4){this['secondaryConn_']=new _0x3aa8a4(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x3aa8a4['responsesRequiredToBeHealthy']||0x0;const _0x1579dd=this['connReceiver_'](this['secondaryConn_']),_0x12cebd=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1579dd,_0x12cebd),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x3964c2){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3964c2),this['repoInfo_']['host']=_0x3964c2,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0xb7331a,_0x5bd9de){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0xb7331a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5bd9de,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5a215d=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5a215d||this['rx_']===_0x5a215d)&&this['close']();}['onConnectionLost_'](_0x40abea){this['conn_']=null,!_0x40abea&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2a3280){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2a3280),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x450fcb){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x450fcb);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x26195c,_0x5a2d6f,_0x5ca132,_0x33e35a){}['merge'](_0x57d9d2,_0x779d43,_0x599007,_0x29ec58){}['refreshAuthToken'](_0x301f2c){}['refreshAppCheckToken'](_0x517c04){}['onDisconnectPut'](_0x244101,_0x22db9f,_0x457bdb){}['onDisconnectMerge'](_0x3237c8,_0x11b6fd,_0xd11424){}['onDisconnectCancel'](_0x98a35d,_0x27580b){}['reportStats'](_0x5ab5d5){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0xd893c0){this['allowedEvents_']=_0xd893c0,this['listeners_']={},f(Array['isArray'](_0xd893c0)&&_0xd893c0['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x48d4b9,..._0x2a8630){if(Array['isArray'](this['listeners_'][_0x48d4b9])){const _0x24d79f=[...this['listeners_'][_0x48d4b9]];for(let _0x4576fb=0x0;_0x4576fb<_0x24d79f['length'];_0x4576fb++)_0x24d79f[_0x4576fb]['callback']['apply'](_0x24d79f[_0x4576fb]['context'],_0x2a8630);}}['on'](_0x32559c,_0x5148df,_0x13bb60){this['validateEventType_'](_0x32559c),this['listeners_'][_0x32559c]=this['listeners_'][_0x32559c]||[],this['listeners_'][_0x32559c]['push']({'callback':_0x5148df,'context':_0x13bb60});const _0x2f5467=this['getInitialEvent'](_0x32559c);_0x2f5467&&_0x5148df['apply'](_0x13bb60,_0x2f5467);}['off'](_0x2ac096,_0x546f5b,_0x57db85){this['validateEventType_'](_0x2ac096);const _0x12b92e=this['listeners_'][_0x2ac096]||[];for(let _0x2379eb=0x0;_0x2379eb<_0x12b92e['length'];_0x2379eb++)if(_0x12b92e[_0x2379eb]['callback']===_0x546f5b&&(!_0x57db85||_0x57db85===_0x12b92e[_0x2379eb]['context'])){_0x12b92e['splice'](_0x2379eb,0x1);return;}}['validateEventType_'](_0x5e105d){f(this['allowedEvents_']['find'](_0x3b53d3=>_0x3b53d3===_0x5e105d),'Unknown\x20event:\x20'+_0x5e105d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x304ab4){return f(_0x304ab4==='online','Unknown\x20event\x20type:\x20'+_0x304ab4),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x13e957,_0x288f22){if(_0x288f22===void 0x0){this['pieces_']=_0x13e957['split']('/');let _0x3996ae=0x0;for(let _0xa67ec1=0x0;_0xa67ec1<this['pieces_']['length'];_0xa67ec1++)this['pieces_'][_0xa67ec1]['length']>0x0&&(this['pieces_'][_0x3996ae]=this['pieces_'][_0xa67ec1],_0x3996ae++);this['pieces_']['length']=_0x3996ae,this['pieceNum_']=0x0;}else this['pieces_']=_0x13e957,this['pieceNum_']=_0x288f22;}['toString'](){let _0x5c153e='';for(let _0x2159e6=this['pieceNum_'];_0x2159e6<this['pieces_']['length'];_0x2159e6++)this['pieces_'][_0x2159e6]!==''&&(_0x5c153e+='/'+this['pieces_'][_0x2159e6]);return _0x5c153e||'/';}}function w(){return new C('');}function y(_0x41692a){return _0x41692a['pieceNum_']>=_0x41692a['pieces_']['length']?null:_0x41692a['pieces_'][_0x41692a['pieceNum_']];}function we(_0x489870){return _0x489870['pieces_']['length']-_0x489870['pieceNum_'];}function b(_0x4caa33){let _0x450b83=_0x4caa33['pieceNum_'];return _0x450b83<_0x4caa33['pieces_']['length']&&_0x450b83++,new C(_0x4caa33['pieces_'],_0x450b83);}function Gi(_0x9e9217){return _0x9e9217['pieceNum_']<_0x9e9217['pieces_']['length']?_0x9e9217['pieces_'][_0x9e9217['pieces_']['length']-0x1]:null;}function Ch(_0x25641d){let _0x469b68='';for(let _0x4fedc1=_0x25641d['pieceNum_'];_0x4fedc1<_0x25641d['pieces_']['length'];_0x4fedc1++)_0x25641d['pieces_'][_0x4fedc1]!==''&&(_0x469b68+='/'+encodeURIComponent(String(_0x25641d['pieces_'][_0x4fedc1])));return _0x469b68||'/';}function kt(_0x8a0100,_0x19e57a=0x0){return _0x8a0100['pieces_']['slice'](_0x8a0100['pieceNum_']+_0x19e57a);}function To(_0x1e2779){if(_0x1e2779['pieceNum_']>=_0x1e2779['pieces_']['length'])return null;const _0x246471=[];for(let _0x14c35b=_0x1e2779['pieceNum_'];_0x14c35b<_0x1e2779['pieces_']['length']-0x1;_0x14c35b++)_0x246471['push'](_0x1e2779['pieces_'][_0x14c35b]);return new C(_0x246471,0x0);}function A(_0x1a5fae,_0x5e58c6){const _0x31eb9c=[];for(let _0x45cebd=_0x1a5fae['pieceNum_'];_0x45cebd<_0x1a5fae['pieces_']['length'];_0x45cebd++)_0x31eb9c['push'](_0x1a5fae['pieces_'][_0x45cebd]);if(_0x5e58c6 instanceof C){for(let _0x790ff=_0x5e58c6['pieceNum_'];_0x790ff<_0x5e58c6['pieces_']['length'];_0x790ff++)_0x31eb9c['push'](_0x5e58c6['pieces_'][_0x790ff]);}else{const _0x30e4a2=_0x5e58c6['split']('/');for(let _0x2edcce=0x0;_0x2edcce<_0x30e4a2['length'];_0x2edcce++)_0x30e4a2[_0x2edcce]['length']>0x0&&_0x31eb9c['push'](_0x30e4a2[_0x2edcce]);}return new C(_0x31eb9c,0x0);}function v(_0x2277e6){return _0x2277e6['pieceNum_']>=_0x2277e6['pieces_']['length'];}function F(_0x39ea5e,_0x4b50de){const _0xfb4939=y(_0x39ea5e),_0x508509=y(_0x4b50de);if(_0xfb4939===null)return _0x4b50de;if(_0xfb4939===_0x508509)return F(b(_0x39ea5e),b(_0x4b50de));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4b50de+')\x20is\x20not\x20within\x20outerPath\x20('+_0x39ea5e+')');}function Th(_0x609ab5,_0x54ab50){const _0x5eef6a=kt(_0x609ab5,0x0),_0x5ba624=kt(_0x54ab50,0x0);for(let _0x24d1c9=0x0;_0x24d1c9<_0x5eef6a['length']&&_0x24d1c9<_0x5ba624['length'];_0x24d1c9++){const _0x167b30=He(_0x5eef6a[_0x24d1c9],_0x5ba624[_0x24d1c9]);if(_0x167b30!==0x0)return _0x167b30;}return _0x5eef6a['length']===_0x5ba624['length']?0x0:_0x5eef6a['length']<_0x5ba624['length']?-0x1:0x1;}function qi(_0x522018,_0x92c4c0){if(we(_0x522018)!==we(_0x92c4c0))return!0x1;for(let _0x7a7cf9=_0x522018['pieceNum_'],_0x4ff061=_0x92c4c0['pieceNum_'];_0x7a7cf9<=_0x522018['pieces_']['length'];_0x7a7cf9++,_0x4ff061++)if(_0x522018['pieces_'][_0x7a7cf9]!==_0x92c4c0['pieces_'][_0x4ff061])return!0x1;return!0x0;}function $(_0x1babf3,_0x3d0305){let _0x57e45f=_0x1babf3['pieceNum_'],_0xb0e874=_0x3d0305['pieceNum_'];if(we(_0x1babf3)>we(_0x3d0305))return!0x1;for(;_0x57e45f<_0x1babf3['pieces_']['length'];){if(_0x1babf3['pieces_'][_0x57e45f]!==_0x3d0305['pieces_'][_0xb0e874])return!0x1;++_0x57e45f,++_0xb0e874;}return!0x0;}class Sh{constructor(_0x2047ea,_0x377598){this['errorPrefix_']=_0x377598,this['parts_']=kt(_0x2047ea,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xda5a23=0x0;_0xda5a23<this['parts_']['length'];_0xda5a23++)this['byteLength_']+=Pn(this['parts_'][_0xda5a23]);So(this);}}function bh(_0x3b5a7e,_0x128ba4){_0x3b5a7e['parts_']['length']>0x0&&(_0x3b5a7e['byteLength_']+=0x1),_0x3b5a7e['parts_']['push'](_0x128ba4),_0x3b5a7e['byteLength_']+=Pn(_0x128ba4),So(_0x3b5a7e);}function Rh(_0x30b4e7){const _0x55ed54=_0x30b4e7['parts_']['pop']();_0x30b4e7['byteLength_']-=Pn(_0x55ed54),_0x30b4e7['parts_']['length']>0x0&&(_0x30b4e7['byteLength_']-=0x1);}function So(_0x4d4336){if(_0x4d4336['byteLength_']>Js)throw new Error(_0x4d4336['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4d4336['byteLength_']+').');if(_0x4d4336['parts_']['length']>Qs)throw new Error(_0x4d4336['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4d4336));}function Ne(_0x1a347e){return _0x1a347e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1a347e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0xe26009,_0x1c521c;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1c521c='visibilitychange',_0xe26009='hidden'):typeof document['mozHidden']<'u'?(_0x1c521c='mozvisibilitychange',_0xe26009='mozHidden'):typeof document['msHidden']<'u'?(_0x1c521c='msvisibilitychange',_0xe26009='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1c521c='webkitvisibilitychange',_0xe26009='webkitHidden')),this['visible_']=!0x0,_0x1c521c&&document['addEventListener'](_0x1c521c,()=>{const _0x25f9a9=!document[_0xe26009];_0x25f9a9!==this['visible_']&&(this['visible_']=_0x25f9a9,this['trigger']('visible',_0x25f9a9));},!0x1);}['getInitialEvent'](_0x37d993){return f(_0x37d993==='visible','Unknown\x20event\x20type:\x20'+_0x37d993),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x25a4d9,_0x520206,_0x1f1684,_0x325d2c,_0x573f21,_0x2e2e55,_0x8cfe7b,_0x5411a4){if(super(),this['repoInfo_']=_0x25a4d9,this['applicationId_']=_0x520206,this['onDataUpdate_']=_0x1f1684,this['onConnectStatus_']=_0x325d2c,this['onServerInfoUpdate_']=_0x573f21,this['authTokenProvider_']=_0x2e2e55,this['appCheckTokenProvider_']=_0x8cfe7b,this['authOverride_']=_0x5411a4,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x5411a4)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x25a4d9['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3cca2a,_0x145f82,_0x1a16d8){const _0x460f5a=++this['requestNumber_'],_0x2711f7={'r':_0x460f5a,'a':_0x3cca2a,'b':_0x145f82};this['log_'](O(_0x2711f7)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2711f7),_0x1a16d8&&(this['requestCBHash_'][_0x460f5a]=_0x1a16d8);}['get'](_0x2bb6dd){this['initConnection_']();const _0x4f0f1e=new Ve(),_0x58b161={'action':'g','request':{'p':_0x2bb6dd['_path']['toString'](),'q':_0x2bb6dd['_queryObject']},'onComplete':_0x1dd687=>{const _0x4b7d25=_0x1dd687['d'];_0x1dd687['s']==='ok'?_0x4f0f1e['resolve'](_0x4b7d25):_0x4f0f1e['reject'](_0x4b7d25);}};this['outstandingGets_']['push'](_0x58b161),this['outstandingGetCount_']++;const _0x5baefc=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5baefc),_0x4f0f1e['promise'];}['listen'](_0x3048e3,_0x1c5557,_0x315106,_0x42f1c9){this['initConnection_']();const _0x569203=_0x3048e3['_queryIdentifier'],_0x244611=_0x3048e3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x244611+'\x20'+_0x569203),this['listens']['has'](_0x244611)||this['listens']['set'](_0x244611,new Map()),f(_0x3048e3['_queryParams']['isDefault']()||!_0x3048e3['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x244611)['has'](_0x569203),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x553b6a={'onComplete':_0x42f1c9,'hashFn':_0x1c5557,'query':_0x3048e3,'tag':_0x315106};this['listens']['get'](_0x244611)['set'](_0x569203,_0x553b6a),this['connected_']&&this['sendListen_'](_0x553b6a);}['sendGet_'](_0x1a0392){const _0x235169=this['outstandingGets_'][_0x1a0392];this['sendRequest']('g',_0x235169['request'],_0x464223=>{delete this['outstandingGets_'][_0x1a0392],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x235169['onComplete']&&_0x235169['onComplete'](_0x464223);});}['sendListen_'](_0xd63f26){const _0x2ab8f4=_0xd63f26['query'],_0x1270ca=_0x2ab8f4['_path']['toString'](),_0x705c73=_0x2ab8f4['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1270ca+'\x20for\x20'+_0x705c73);const _0x391039={'p':_0x1270ca},_0x43b4e0='q';_0xd63f26['tag']&&(_0x391039['q']=_0x2ab8f4['_queryObject'],_0x391039['t']=_0xd63f26['tag']),_0x391039['h']=_0xd63f26['hashFn'](),this['sendRequest'](_0x43b4e0,_0x391039,_0x108a6a=>{const _0x451815=_0x108a6a['d'],_0xabca8f=_0x108a6a['s'];ie['warnOnListenWarnings_'](_0x451815,_0x2ab8f4),(this['listens']['get'](_0x1270ca)&&this['listens']['get'](_0x1270ca)['get'](_0x705c73))===_0xd63f26&&(this['log_']('listen\x20response',_0x108a6a),_0xabca8f!=='ok'&&this['removeListen_'](_0x1270ca,_0x705c73),_0xd63f26['onComplete']&&_0xd63f26['onComplete'](_0xabca8f,_0x451815));});}static['warnOnListenWarnings_'](_0x5da81e,_0x402d01){if(_0x5da81e&&typeof _0x5da81e=='object'&&Y(_0x5da81e,'w')){const _0x3c1160=Oe(_0x5da81e,'w');if(Array['isArray'](_0x3c1160)&&~_0x3c1160['indexOf']('no_index')){const _0x2a36b2='\x22.indexOn\x22:\x20\x22'+_0x402d01['_queryParams']['getIndex']()['toString']()+'\x22',_0x140e45=_0x402d01['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2a36b2+'\x20at\x20'+_0x140e45+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xd56467){this['authToken_']=_0xd56467,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xd56467);}['reduceReconnectDelayIfAdminCredential_'](_0x5c3f9f){(_0x5c3f9f&&_0x5c3f9f['length']===0x28||vc(_0x5c3f9f))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x20290b){this['appCheckToken_']=_0x20290b,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4b5c62=this['authToken_'],_0x4a55d5=yc(_0x4b5c62)?'auth':'gauth',_0xcb4b48={'cred':_0x4b5c62};this['authOverride_']===null?_0xcb4b48['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xcb4b48['authvar']=this['authOverride_']),this['sendRequest'](_0x4a55d5,_0xcb4b48,_0xccda86=>{const _0x30cdcc=_0xccda86['s'],_0x43f5b5=_0xccda86['d']||'error';this['authToken_']===_0x4b5c62&&(_0x30cdcc==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x30cdcc,_0x43f5b5));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4078e3=>{const _0x31e512=_0x4078e3['s'],_0xaf29c6=_0x4078e3['d']||'error';_0x31e512==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x31e512,_0xaf29c6);});}['unlisten'](_0x27462b,_0x2d1356){const _0x7fc95=_0x27462b['_path']['toString'](),_0x5a474f=_0x27462b['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x7fc95+'\x20'+_0x5a474f),f(_0x27462b['_queryParams']['isDefault']()||!_0x27462b['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x7fc95,_0x5a474f)&&this['connected_']&&this['sendUnlisten_'](_0x7fc95,_0x5a474f,_0x27462b['_queryObject'],_0x2d1356);}['sendUnlisten_'](_0x1d726e,_0x10b743,_0x4a2f38,_0x296136){this['log_']('Unlisten\x20on\x20'+_0x1d726e+'\x20for\x20'+_0x10b743);const _0x467fc9={'p':_0x1d726e},_0x3a288b='n';_0x296136&&(_0x467fc9['q']=_0x4a2f38,_0x467fc9['t']=_0x296136),this['sendRequest'](_0x3a288b,_0x467fc9);}['onDisconnectPut'](_0x5c65f5,_0x542989,_0x5ee2fb){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5c65f5,_0x542989,_0x5ee2fb):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c65f5,'action':'o','data':_0x542989,'onComplete':_0x5ee2fb});}['onDisconnectMerge'](_0x27a3b9,_0x31a9da,_0x1cf130){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x27a3b9,_0x31a9da,_0x1cf130):this['onDisconnectRequestQueue_']['push']({'pathString':_0x27a3b9,'action':'om','data':_0x31a9da,'onComplete':_0x1cf130});}['onDisconnectCancel'](_0x41a37c,_0x5405d2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x41a37c,null,_0x5405d2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x41a37c,'action':'oc','data':null,'onComplete':_0x5405d2});}['sendOnDisconnect_'](_0x100516,_0x42d43f,_0x3213ae,_0x22e5f5){const _0x226c18={'p':_0x42d43f,'d':_0x3213ae};this['log_']('onDisconnect\x20'+_0x100516,_0x226c18),this['sendRequest'](_0x100516,_0x226c18,_0x2ae774=>{_0x22e5f5&&setTimeout(()=>{_0x22e5f5(_0x2ae774['s'],_0x2ae774['d']);},Math['floor'](0x0));});}['put'](_0x1143f5,_0x3dc604,_0x535043,_0x490bf5){this['putInternal']('p',_0x1143f5,_0x3dc604,_0x535043,_0x490bf5);}['merge'](_0x2142ba,_0x35588a,_0x57c14f,_0x22c57a){this['putInternal']('m',_0x2142ba,_0x35588a,_0x57c14f,_0x22c57a);}['putInternal'](_0x796bc6,_0x42e222,_0x2d63bc,_0x43aa0c,_0x4d77e8){this['initConnection_']();const _0x11cb39={'p':_0x42e222,'d':_0x2d63bc};_0x4d77e8!==void 0x0&&(_0x11cb39['h']=_0x4d77e8),this['outstandingPuts_']['push']({'action':_0x796bc6,'request':_0x11cb39,'onComplete':_0x43aa0c}),this['outstandingPutCount_']++;const _0x3f218d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3f218d):this['log_']('Buffering\x20put:\x20'+_0x42e222);}['sendPut_'](_0x229a16){const _0xc3ac78=this['outstandingPuts_'][_0x229a16]['action'],_0x4222d7=this['outstandingPuts_'][_0x229a16]['request'],_0x5aa07b=this['outstandingPuts_'][_0x229a16]['onComplete'];this['outstandingPuts_'][_0x229a16]['queued']=this['connected_'],this['sendRequest'](_0xc3ac78,_0x4222d7,_0x108dce=>{this['log_'](_0xc3ac78+'\x20response',_0x108dce),delete this['outstandingPuts_'][_0x229a16],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5aa07b&&_0x5aa07b(_0x108dce['s'],_0x108dce['d']);});}['reportStats'](_0x4fc35b){if(this['connected_']){const _0x2d3e43={'c':_0x4fc35b};this['log_']('reportStats',_0x2d3e43),this['sendRequest']('s',_0x2d3e43,_0x336be8=>{if(_0x336be8['s']!=='ok'){const _0xfc3598=_0x336be8['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xfc3598);}});}}['onDataMessage_'](_0x3db771){if('r'in _0x3db771){this['log_']('from\x20server:\x20'+O(_0x3db771));const _0x234063=_0x3db771['r'],_0x505ded=this['requestCBHash_'][_0x234063];_0x505ded&&(delete this['requestCBHash_'][_0x234063],_0x505ded(_0x3db771['b']));}else{if('error'in _0x3db771)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x3db771['error'];'a'in _0x3db771&&this['onDataPush_'](_0x3db771['a'],_0x3db771['b']);}}['onDataPush_'](_0xaadddd,_0x2b227a){this['log_']('handleServerMessage',_0xaadddd,_0x2b227a),_0xaadddd==='d'?this['onDataUpdate_'](_0x2b227a['p'],_0x2b227a['d'],!0x1,_0x2b227a['t']):_0xaadddd==='m'?this['onDataUpdate_'](_0x2b227a['p'],_0x2b227a['d'],!0x0,_0x2b227a['t']):_0xaadddd==='c'?this['onListenRevoked_'](_0x2b227a['p'],_0x2b227a['q']):_0xaadddd==='ac'?this['onAuthRevoked_'](_0x2b227a['s'],_0x2b227a['d']):_0xaadddd==='apc'?this['onAppCheckRevoked_'](_0x2b227a['s'],_0x2b227a['d']):_0xaadddd==='sd'?this['onSecurityDebugPacket_'](_0x2b227a):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xaadddd)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1de3ec,_0xceb411){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1de3ec),this['lastSessionId']=_0xceb411,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5d317c){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5d317c));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x402492){_0x402492&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x402492;}['onOnline_'](_0x1286d3){_0x1286d3?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x39646b=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2a8bde=Math['max'](0x0,this['reconnectDelay_']-_0x39646b);_0x2a8bde=Math['random']()*_0x2a8bde,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2a8bde+'ms'),this['scheduleConnect_'](_0x2a8bde),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x10e38a=this['onDataMessage_']['bind'](this),_0x55b531=this['onReady_']['bind'](this),_0x2f85b2=this['onRealtimeDisconnect_']['bind'](this),_0x52cca4=this['id']+':'+ie['nextConnectionId_']++,_0x31615f=this['lastSessionId'];let _0x33b19d=!0x1,_0x1b07ed=null;const _0x3d31f4=function(){_0x1b07ed?_0x1b07ed['close']():(_0x33b19d=!0x0,_0x2f85b2());},_0x413aca=function(_0x1afd29){f(_0x1b07ed,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1b07ed['sendRequest'](_0x1afd29);};this['realtime_']={'close':_0x3d31f4,'sendRequest':_0x413aca};const _0x3feb6f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x72be48,_0x55f90a]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3feb6f),this['appCheckTokenProvider_']['getToken'](_0x3feb6f)]);_0x33b19d?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x72be48&&_0x72be48['accessToken'],this['appCheckToken_']=_0x55f90a&&_0x55f90a['token'],_0x1b07ed=new wh(_0x52cca4,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x10e38a,_0x55b531,_0x2f85b2,_0x121d25=>{U(_0x121d25+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x31615f));}catch(_0x573856){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x573856),_0x33b19d||(this['repoInfo_']['nodeAdmin']&&U(_0x573856),_0x3d31f4());}}}['interrupt'](_0x3a82cf){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3a82cf),this['interruptReasons_'][_0x3a82cf]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xfb8e58){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xfb8e58),delete this['interruptReasons_'][_0xfb8e58],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5eacd4){const _0x1870d0=_0x5eacd4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1870d0});}['cancelSentTransactions_'](){for(let _0x5c9d88=0x0;_0x5c9d88<this['outstandingPuts_']['length'];_0x5c9d88++){const _0x51fb52=this['outstandingPuts_'][_0x5c9d88];_0x51fb52&&'h'in _0x51fb52['request']&&_0x51fb52['queued']&&(_0x51fb52['onComplete']&&_0x51fb52['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5c9d88],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xb1a1e5,_0x20c3e7){let _0x3c701d;_0x20c3e7?_0x3c701d=_0x20c3e7['map'](_0x2bd114=>Bi(_0x2bd114))['join']('$'):_0x3c701d='default';const _0x40f4c0=this['removeListen_'](_0xb1a1e5,_0x3c701d);_0x40f4c0&&_0x40f4c0['onComplete']&&_0x40f4c0['onComplete']('permission_denied');}['removeListen_'](_0x18d3a5,_0x13ec5f){const _0x4f2202=new C(_0x18d3a5)['toString']();let _0x40d32d;if(this['listens']['has'](_0x4f2202)){const _0x88f75d=this['listens']['get'](_0x4f2202);_0x40d32d=_0x88f75d['get'](_0x13ec5f),_0x88f75d['delete'](_0x13ec5f),_0x88f75d['size']===0x0&&this['listens']['delete'](_0x4f2202);}else _0x40d32d=void 0x0;return _0x40d32d;}['onAuthRevoked_'](_0x30edfb,_0x588b12){L('Auth\x20token\x20revoked:\x20'+_0x30edfb+'/'+_0x588b12),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x30edfb==='invalid_token'||_0x30edfb==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xabbf4b,_0x36181b){L('App\x20check\x20token\x20revoked:\x20'+_0xabbf4b+'/'+_0x36181b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xabbf4b==='invalid_token'||_0xabbf4b==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x208359){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x208359):'msg'in _0x208359&&console['log']('FIREBASE:\x20'+_0x208359['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1de3ee of this['listens']['values']())for(const _0x2f476a of _0x1de3ee['values']())this['sendListen_'](_0x2f476a);for(let _0x1b63d4=0x0;_0x1b63d4<this['outstandingPuts_']['length'];_0x1b63d4++)this['outstandingPuts_'][_0x1b63d4]&&this['sendPut_'](_0x1b63d4);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1e035e=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1e035e['action'],_0x1e035e['pathString'],_0x1e035e['data'],_0x1e035e['onComplete']);}for(let _0x2a283b=0x0;_0x2a283b<this['outstandingGets_']['length'];_0x2a283b++)this['outstandingGets_'][_0x2a283b]&&this['sendGet_'](_0x2a283b);}['sendConnectStats_'](){const _0x3fe4a8={};let _0x1e2642='js';_0x3fe4a8['sdk.'+_0x1e2642+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x3fe4a8['framework.cordova']=0x1:qr()&&(_0x3fe4a8['framework.reactnative']=0x1),this['reportStats'](_0x3fe4a8);}['shouldReconnect_'](){const _0x1ea9f8=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x1ea9f8;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x127918,_0x2c25bd){this['name']=_0x127918,this['node']=_0x2c25bd;}static['Wrap'](_0x3658b6,_0x13cc8e){return new E(_0x3658b6,_0x13cc8e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x48e85e,_0x2e43bf){const _0x92c719=new E(xe,_0x48e85e),_0x30cb28=new E(xe,_0x2e43bf);return this['compare'](_0x92c719,_0x30cb28)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x19b613){Xt=_0x19b613;}['compare'](_0x77161a,_0x2c120a){return He(_0x77161a['name'],_0x2c120a['name']);}['isDefinedOn'](_0x2f4f8c){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1c2763,_0x40210d){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x25752c,_0x2ae7ed){return f(typeof _0x25752c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x25752c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x1edfa6,_0x3d6709,_0xe1b0,_0x3f5696,_0x39b606=null){this['isReverse_']=_0x3f5696,this['resultGenerator_']=_0x39b606,this['nodeStack_']=[];let _0x3d24e7=0x1;for(;!_0x1edfa6['isEmpty']();)if(_0x1edfa6=_0x1edfa6,_0x3d24e7=_0x3d6709?_0xe1b0(_0x1edfa6['key'],_0x3d6709):0x1,_0x3f5696&&(_0x3d24e7*=-0x1),_0x3d24e7<0x0)this['isReverse_']?_0x1edfa6=_0x1edfa6['left']:_0x1edfa6=_0x1edfa6['right'];else{if(_0x3d24e7===0x0){this['nodeStack_']['push'](_0x1edfa6);break;}else this['nodeStack_']['push'](_0x1edfa6),this['isReverse_']?_0x1edfa6=_0x1edfa6['right']:_0x1edfa6=_0x1edfa6['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1dcb6b=this['nodeStack_']['pop'](),_0xbf6896;if(this['resultGenerator_']?_0xbf6896=this['resultGenerator_'](_0x1dcb6b['key'],_0x1dcb6b['value']):_0xbf6896={'key':_0x1dcb6b['key'],'value':_0x1dcb6b['value']},this['isReverse_']){for(_0x1dcb6b=_0x1dcb6b['left'];!_0x1dcb6b['isEmpty']();)this['nodeStack_']['push'](_0x1dcb6b),_0x1dcb6b=_0x1dcb6b['right'];}else{for(_0x1dcb6b=_0x1dcb6b['right'];!_0x1dcb6b['isEmpty']();)this['nodeStack_']['push'](_0x1dcb6b),_0x1dcb6b=_0x1dcb6b['left'];}return _0xbf6896;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x393926=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x393926['key'],_0x393926['value']):{'key':_0x393926['key'],'value':_0x393926['value']};}}class M{constructor(_0x2e6473,_0x458c7f,_0x2d4b13,_0x221f2c,_0x3b12d1){this['key']=_0x2e6473,this['value']=_0x458c7f,this['color']=_0x2d4b13??M['RED'],this['left']=_0x221f2c??B['EMPTY_NODE'],this['right']=_0x3b12d1??B['EMPTY_NODE'];}['copy'](_0x41ce6e,_0x5afbcf,_0x2b61c5,_0x3551cb,_0x55d95f){return new M(_0x41ce6e??this['key'],_0x5afbcf??this['value'],_0x2b61c5??this['color'],_0x3551cb??this['left'],_0x55d95f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x561b61){return this['left']['inorderTraversal'](_0x561b61)||!!_0x561b61(this['key'],this['value'])||this['right']['inorderTraversal'](_0x561b61);}['reverseTraversal'](_0x30d7f2){return this['right']['reverseTraversal'](_0x30d7f2)||_0x30d7f2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x30d7f2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x130f76,_0x218f09,_0x1b443d){let _0x4d7592=this;const _0x572444=_0x1b443d(_0x130f76,_0x4d7592['key']);return _0x572444<0x0?_0x4d7592=_0x4d7592['copy'](null,null,null,_0x4d7592['left']['insert'](_0x130f76,_0x218f09,_0x1b443d),null):_0x572444===0x0?_0x4d7592=_0x4d7592['copy'](null,_0x218f09,null,null,null):_0x4d7592=_0x4d7592['copy'](null,null,null,null,_0x4d7592['right']['insert'](_0x130f76,_0x218f09,_0x1b443d)),_0x4d7592['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x934ad0=this;return!_0x934ad0['left']['isRed_']()&&!_0x934ad0['left']['left']['isRed_']()&&(_0x934ad0=_0x934ad0['moveRedLeft_']()),_0x934ad0=_0x934ad0['copy'](null,null,null,_0x934ad0['left']['removeMin_'](),null),_0x934ad0['fixUp_']();}['remove'](_0x5da171,_0x483601){let _0x20fa8f,_0x35d16a;if(_0x20fa8f=this,_0x483601(_0x5da171,_0x20fa8f['key'])<0x0)!_0x20fa8f['left']['isEmpty']()&&!_0x20fa8f['left']['isRed_']()&&!_0x20fa8f['left']['left']['isRed_']()&&(_0x20fa8f=_0x20fa8f['moveRedLeft_']()),_0x20fa8f=_0x20fa8f['copy'](null,null,null,_0x20fa8f['left']['remove'](_0x5da171,_0x483601),null);else{if(_0x20fa8f['left']['isRed_']()&&(_0x20fa8f=_0x20fa8f['rotateRight_']()),!_0x20fa8f['right']['isEmpty']()&&!_0x20fa8f['right']['isRed_']()&&!_0x20fa8f['right']['left']['isRed_']()&&(_0x20fa8f=_0x20fa8f['moveRedRight_']()),_0x483601(_0x5da171,_0x20fa8f['key'])===0x0){if(_0x20fa8f['right']['isEmpty']())return B['EMPTY_NODE'];_0x35d16a=_0x20fa8f['right']['min_'](),_0x20fa8f=_0x20fa8f['copy'](_0x35d16a['key'],_0x35d16a['value'],null,null,_0x20fa8f['right']['removeMin_']());}_0x20fa8f=_0x20fa8f['copy'](null,null,null,null,_0x20fa8f['right']['remove'](_0x5da171,_0x483601));}return _0x20fa8f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4501f5=this;return _0x4501f5['right']['isRed_']()&&!_0x4501f5['left']['isRed_']()&&(_0x4501f5=_0x4501f5['rotateLeft_']()),_0x4501f5['left']['isRed_']()&&_0x4501f5['left']['left']['isRed_']()&&(_0x4501f5=_0x4501f5['rotateRight_']()),_0x4501f5['left']['isRed_']()&&_0x4501f5['right']['isRed_']()&&(_0x4501f5=_0x4501f5['colorFlip_']()),_0x4501f5;}['moveRedLeft_'](){let _0x4355ff=this['colorFlip_']();return _0x4355ff['right']['left']['isRed_']()&&(_0x4355ff=_0x4355ff['copy'](null,null,null,null,_0x4355ff['right']['rotateRight_']()),_0x4355ff=_0x4355ff['rotateLeft_'](),_0x4355ff=_0x4355ff['colorFlip_']()),_0x4355ff;}['moveRedRight_'](){let _0x36b482=this['colorFlip_']();return _0x36b482['left']['left']['isRed_']()&&(_0x36b482=_0x36b482['rotateRight_'](),_0x36b482=_0x36b482['colorFlip_']()),_0x36b482;}['rotateLeft_'](){const _0x53b3fe=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x53b3fe,null);}['rotateRight_'](){const _0x345fe5=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x345fe5);}['colorFlip_'](){const _0x3f3274=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4ae2fb=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3f3274,_0x4ae2fb);}['checkMaxDepth_'](){const _0x31fca6=this['check_']();return Math['pow'](0x2,_0x31fca6)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x894bda=this['left']['check_']();if(_0x894bda!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x894bda+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x594796,_0x260ef1,_0x2dc810,_0xd04037,_0x2c654a){return this;}['insert'](_0x2960a0,_0x4617f9,_0x15291d){return new M(_0x2960a0,_0x4617f9,null);}['remove'](_0x75e6d2,_0x2c02ec){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x181194){return!0x1;}['reverseTraversal'](_0x462e17){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1d22e5,_0x3b3742=B['EMPTY_NODE']){this['comparator_']=_0x1d22e5,this['root_']=_0x3b3742;}['insert'](_0xbdc618,_0x5726e0){return new B(this['comparator_'],this['root_']['insert'](_0xbdc618,_0x5726e0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x13bebc){return new B(this['comparator_'],this['root_']['remove'](_0x13bebc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x35a026){let _0x339940,_0x2b5b78=this['root_'];for(;!_0x2b5b78['isEmpty']();){if(_0x339940=this['comparator_'](_0x35a026,_0x2b5b78['key']),_0x339940===0x0)return _0x2b5b78['value'];_0x339940<0x0?_0x2b5b78=_0x2b5b78['left']:_0x339940>0x0&&(_0x2b5b78=_0x2b5b78['right']);}return null;}['getPredecessorKey'](_0x448f6e){let _0x1abf90,_0x5b27f3=this['root_'],_0x474e80=null;for(;!_0x5b27f3['isEmpty']();)if(_0x1abf90=this['comparator_'](_0x448f6e,_0x5b27f3['key']),_0x1abf90===0x0){if(_0x5b27f3['left']['isEmpty']())return _0x474e80?_0x474e80['key']:null;for(_0x5b27f3=_0x5b27f3['left'];!_0x5b27f3['right']['isEmpty']();)_0x5b27f3=_0x5b27f3['right'];return _0x5b27f3['key'];}else _0x1abf90<0x0?_0x5b27f3=_0x5b27f3['left']:_0x1abf90>0x0&&(_0x474e80=_0x5b27f3,_0x5b27f3=_0x5b27f3['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1cf7be){return this['root_']['inorderTraversal'](_0x1cf7be);}['reverseTraversal'](_0x49bdd0){return this['root_']['reverseTraversal'](_0x49bdd0);}['getIterator'](_0x4a39bd){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x4a39bd);}['getIteratorFrom'](_0x416651,_0x355c50){return new Zt(this['root_'],_0x416651,this['comparator_'],!0x1,_0x355c50);}['getReverseIteratorFrom'](_0xf1d5bf,_0x3014ae){return new Zt(this['root_'],_0xf1d5bf,this['comparator_'],!0x0,_0x3014ae);}['getReverseIterator'](_0x22186b){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x22186b);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x18fea1,_0x4f0b3e){return He(_0x18fea1['name'],_0x4f0b3e['name']);}function ji(_0x297ab5,_0x3d49ee){return He(_0x297ab5,_0x3d49ee);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x5560db){vi=_0x5560db;}const Ro=function(_0x46b00a){return typeof _0x46b00a=='number'?'number:'+so(_0x46b00a):'string:'+_0x46b00a;},Ao=function(_0x334d5e){if(_0x334d5e['isLeafNode']()){const _0x2b06b3=_0x334d5e['val']();f(typeof _0x2b06b3=='string'||typeof _0x2b06b3=='number'||typeof _0x2b06b3=='object'&&Y(_0x2b06b3,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x334d5e===vi||_0x334d5e['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x334d5e===vi||_0x334d5e['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x543072){er=_0x543072;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4cffea,_0x17afbf=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4cffea,this['priorityNode_']=_0x17afbf,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xb13180){return new D(this['value_'],_0xb13180);}['getImmediateChild'](_0x1357f3){return _0x1357f3==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x119bd7){return v(_0x119bd7)?this:y(_0x119bd7)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1cba8a,_0x1b49b3){return null;}['updateImmediateChild'](_0x5107aa,_0x1f4066){return _0x5107aa==='.priority'?this['updatePriority'](_0x1f4066):_0x1f4066['isEmpty']()&&_0x5107aa!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5107aa,_0x1f4066)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x283474,_0x2181cd){const _0x2c1ef0=y(_0x283474);return _0x2c1ef0===null?_0x2181cd:_0x2181cd['isEmpty']()&&_0x2c1ef0!=='.priority'?this:(f(_0x2c1ef0!=='.priority'||we(_0x283474)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2c1ef0,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x283474),_0x2181cd)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xde9f28,_0x81ad1d){return!0x1;}['val'](_0x407ba2){return _0x407ba2&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5b60da='';this['priorityNode_']['isEmpty']()||(_0x5b60da+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x37e59a=typeof this['value_'];_0x5b60da+=_0x37e59a+':',_0x37e59a==='number'?_0x5b60da+=so(this['value_']):_0x5b60da+=this['value_'],this['lazyHash_']=no(_0x5b60da);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xe6cbf9){return _0xe6cbf9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xe6cbf9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xe6cbf9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xe6cbf9));}['compareToLeafNode_'](_0x4292a7){const _0x173831=typeof _0x4292a7['value_'],_0x49a3bd=typeof this['value_'],_0x7f6db4=D['VALUE_TYPE_ORDER']['indexOf'](_0x173831),_0x424313=D['VALUE_TYPE_ORDER']['indexOf'](_0x49a3bd);return f(_0x7f6db4>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x173831),f(_0x424313>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x49a3bd),_0x7f6db4===_0x424313?_0x49a3bd==='object'?0x0:this['value_']<_0x4292a7['value_']?-0x1:this['value_']===_0x4292a7['value_']?0x0:0x1:_0x424313-_0x7f6db4;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5b746b){if(_0x5b746b===this)return!0x0;if(_0x5b746b['isLeafNode']()){const _0x44a2e1=_0x5b746b;return this['value_']===_0x44a2e1['value_']&&this['priorityNode_']['equals'](_0x44a2e1['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x40a42f){ko=_0x40a42f;}function xh(_0x43fca9){No=_0x43fca9;}class Fh extends On{['compare'](_0x1e0f66,_0x5a06f4){const _0x20be11=_0x1e0f66['node']['getPriority'](),_0x53f55c=_0x5a06f4['node']['getPriority'](),_0x3b54d3=_0x20be11['compareTo'](_0x53f55c);return _0x3b54d3===0x0?He(_0x1e0f66['name'],_0x5a06f4['name']):_0x3b54d3;}['isDefinedOn'](_0x2ce270){return!_0x2ce270['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5a0693,_0x62cbbe){return!_0x5a0693['getPriority']()['equals'](_0x62cbbe['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x35b11c,_0x2ff67e){const _0x55c109=ko(_0x35b11c);return new E(_0x2ff67e,new D('[PRIORITY-POST]',_0x55c109));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x3ffe9b){const _0x4c882e=_0x465420=>parseInt(Math['log'](_0x465420)/Uh,0xa),_0x4ccc7c=_0x34a1d6=>parseInt(Array(_0x34a1d6+0x1)['join']('1'),0x2);this['count']=_0x4c882e(_0x3ffe9b+0x1),this['current_']=this['count']-0x1;const _0x43c9c0=_0x4ccc7c(this['count']);this['bits_']=_0x3ffe9b+0x1&_0x43c9c0;}['nextBitIsOne'](){const _0x4f59b1=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4f59b1;}}const dn=function(_0xe2bd0f,_0x1b8bf3,_0x19c8e4,_0x3fd702){_0xe2bd0f['sort'](_0x1b8bf3);const _0x3f1e13=function(_0x3799f2,_0xe458c1){const _0x46758e=_0xe458c1-_0x3799f2;let _0x36d738,_0x44cf66;if(_0x46758e===0x0)return null;if(_0x46758e===0x1)return _0x36d738=_0xe2bd0f[_0x3799f2],_0x44cf66=_0x19c8e4?_0x19c8e4(_0x36d738):_0x36d738,new M(_0x44cf66,_0x36d738['node'],M['BLACK'],null,null);{const _0x4bbbe9=parseInt(_0x46758e/0x2,0xa)+_0x3799f2,_0xa8239f=_0x3f1e13(_0x3799f2,_0x4bbbe9),_0x223de8=_0x3f1e13(_0x4bbbe9+0x1,_0xe458c1);return _0x36d738=_0xe2bd0f[_0x4bbbe9],_0x44cf66=_0x19c8e4?_0x19c8e4(_0x36d738):_0x36d738,new M(_0x44cf66,_0x36d738['node'],M['BLACK'],_0xa8239f,_0x223de8);}},_0x583f97=function(_0x80e8ad){let _0x7e559a=null,_0x34beb9=null,_0x3b2ea4=_0xe2bd0f['length'];const _0x55e957=function(_0x5a3a1b,_0x1fdb40){const _0x356fcb=_0x3b2ea4-_0x5a3a1b,_0x12db83=_0x3b2ea4;_0x3b2ea4-=_0x5a3a1b;const _0x272c78=_0x3f1e13(_0x356fcb+0x1,_0x12db83),_0x2b64ba=_0xe2bd0f[_0x356fcb],_0x45c00c=_0x19c8e4?_0x19c8e4(_0x2b64ba):_0x2b64ba;_0xcb51bf(new M(_0x45c00c,_0x2b64ba['node'],_0x1fdb40,null,_0x272c78));},_0xcb51bf=function(_0x17939a){_0x7e559a?(_0x7e559a['left']=_0x17939a,_0x7e559a=_0x17939a):(_0x34beb9=_0x17939a,_0x7e559a=_0x17939a);};for(let _0x44f512=0x0;_0x44f512<_0x80e8ad['count'];++_0x44f512){const _0x26a9c5=_0x80e8ad['nextBitIsOne'](),_0x556498=Math['pow'](0x2,_0x80e8ad['count']-(_0x44f512+0x1));_0x26a9c5?_0x55e957(_0x556498,M['BLACK']):(_0x55e957(_0x556498,M['BLACK']),_0x55e957(_0x556498,M['RED']));}return _0x34beb9;},_0x5cd45a=new Wh(_0xe2bd0f['length']),_0xc319fe=_0x583f97(_0x5cd45a);return new B(_0x3fd702||_0x1b8bf3,_0xc319fe);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x34db7d,_0x2d3a5e){this['indexes_']=_0x34db7d,this['indexSet_']=_0x2d3a5e;}['get'](_0x5bdec0){const _0x17ab46=Oe(this['indexes_'],_0x5bdec0);if(!_0x17ab46)throw new Error('No\x20index\x20defined\x20for\x20'+_0x5bdec0);return _0x17ab46 instanceof B?_0x17ab46:null;}['hasIndex'](_0x51c897){return Y(this['indexSet_'],_0x51c897['toString']());}['addIndex'](_0x901b70,_0x3612e0){f(_0x901b70!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x547aa8=[];let _0x24d1ab=!0x1;const _0x2a1d4c=_0x3612e0['getIterator'](E['Wrap']);let _0x10c65d=_0x2a1d4c['getNext']();for(;_0x10c65d;)_0x24d1ab=_0x24d1ab||_0x901b70['isDefinedOn'](_0x10c65d['node']),_0x547aa8['push'](_0x10c65d),_0x10c65d=_0x2a1d4c['getNext']();let _0x51b4e4;_0x24d1ab?_0x51b4e4=dn(_0x547aa8,_0x901b70['getCompare']()):_0x51b4e4=je;const _0x1a7434=_0x901b70['toString'](),_0x3f82c9={...this['indexSet_']};_0x3f82c9[_0x1a7434]=_0x901b70;const _0x4a7e1b={...this['indexes_']};return _0x4a7e1b[_0x1a7434]=_0x51b4e4,new ee(_0x4a7e1b,_0x3f82c9);}['addToIndexes'](_0x2de407,_0x49873a){const _0x44a736=ln(this['indexes_'],(_0x301222,_0x3d8a2d)=>{const _0x5b18b6=Oe(this['indexSet_'],_0x3d8a2d);if(f(_0x5b18b6,'Missing\x20index\x20implementation\x20for\x20'+_0x3d8a2d),_0x301222===je){if(_0x5b18b6['isDefinedOn'](_0x2de407['node'])){const _0x5f9ee5=[],_0x35803a=_0x49873a['getIterator'](E['Wrap']);let _0x2eae4a=_0x35803a['getNext']();for(;_0x2eae4a;)_0x2eae4a['name']!==_0x2de407['name']&&_0x5f9ee5['push'](_0x2eae4a),_0x2eae4a=_0x35803a['getNext']();return _0x5f9ee5['push'](_0x2de407),dn(_0x5f9ee5,_0x5b18b6['getCompare']());}else return je;}else{const _0xd8ca53=_0x49873a['get'](_0x2de407['name']);let _0x4678c4=_0x301222;return _0xd8ca53&&(_0x4678c4=_0x4678c4['remove'](new E(_0x2de407['name'],_0xd8ca53))),_0x4678c4['insert'](_0x2de407,_0x2de407['node']);}});return new ee(_0x44a736,this['indexSet_']);}['removeFromIndexes'](_0x40d90f,_0x593fae){const _0x3623a9=ln(this['indexes_'],_0x22abde=>{if(_0x22abde===je)return _0x22abde;{const _0x3113bf=_0x593fae['get'](_0x40d90f['name']);return _0x3113bf?_0x22abde['remove'](new E(_0x40d90f['name'],_0x3113bf)):_0x22abde;}});return new ee(_0x3623a9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2d5c3b,_0x4845e0,_0x218d29){this['children_']=_0x2d5c3b,this['priorityNode_']=_0x4845e0,this['indexMap_']=_0x218d29,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x45888c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x45888c,this['indexMap_']);}['getImmediateChild'](_0x5b605a){if(_0x5b605a==='.priority')return this['getPriority']();{const _0x2a7b95=this['children_']['get'](_0x5b605a);return _0x2a7b95===null?gt:_0x2a7b95;}}['getChild'](_0x3595da){const _0x3dabac=y(_0x3595da);return _0x3dabac===null?this:this['getImmediateChild'](_0x3dabac)['getChild'](b(_0x3595da));}['hasChild'](_0xee6280){return this['children_']['get'](_0xee6280)!==null;}['updateImmediateChild'](_0x439f49,_0x1f2a14){if(f(_0x1f2a14,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x439f49==='.priority')return this['updatePriority'](_0x1f2a14);{const _0x94d946=new E(_0x439f49,_0x1f2a14);let _0x4a98d0,_0x2b3e2f;_0x1f2a14['isEmpty']()?(_0x4a98d0=this['children_']['remove'](_0x439f49),_0x2b3e2f=this['indexMap_']['removeFromIndexes'](_0x94d946,this['children_'])):(_0x4a98d0=this['children_']['insert'](_0x439f49,_0x1f2a14),_0x2b3e2f=this['indexMap_']['addToIndexes'](_0x94d946,this['children_']));const _0x1dde7f=_0x4a98d0['isEmpty']()?gt:this['priorityNode_'];return new g(_0x4a98d0,_0x1dde7f,_0x2b3e2f);}}['updateChild'](_0xf56341,_0x1fab64){const _0x1c6600=y(_0xf56341);if(_0x1c6600===null)return _0x1fab64;{f(y(_0xf56341)!=='.priority'||we(_0xf56341)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x47afab=this['getImmediateChild'](_0x1c6600)['updateChild'](b(_0xf56341),_0x1fab64);return this['updateImmediateChild'](_0x1c6600,_0x47afab);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x493cee){if(this['isEmpty']())return null;const _0x3e0f0e={};let _0x49485a=0x0,_0x5158ec=0x0,_0x1566d4=!0x0;if(this['forEachChild'](R,(_0x495897,_0x5f5aea)=>{_0x3e0f0e[_0x495897]=_0x5f5aea['val'](_0x493cee),_0x49485a++,_0x1566d4&&g['INTEGER_REGEXP_']['test'](_0x495897)?_0x5158ec=Math['max'](_0x5158ec,Number(_0x495897)):_0x1566d4=!0x1;}),!_0x493cee&&_0x1566d4&&_0x5158ec<0x2*_0x49485a){const _0x3f5a28=[];for(const _0x5d3b82 in _0x3e0f0e)_0x3f5a28[_0x5d3b82]=_0x3e0f0e[_0x5d3b82];return _0x3f5a28;}else return _0x493cee&&!this['getPriority']()['isEmpty']()&&(_0x3e0f0e['.priority']=this['getPriority']()['val']()),_0x3e0f0e;}['hash'](){if(this['lazyHash_']===null){let _0x527b13='';this['getPriority']()['isEmpty']()||(_0x527b13+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1689b5,_0x3693a1)=>{const _0x49f7f4=_0x3693a1['hash']();_0x49f7f4!==''&&(_0x527b13+=':'+_0x1689b5+':'+_0x49f7f4);}),this['lazyHash_']=_0x527b13===''?'':no(_0x527b13);}return this['lazyHash_'];}['getPredecessorChildName'](_0x245be4,_0x3f7068,_0x5ea086){const _0x150cdd=this['resolveIndex_'](_0x5ea086);if(_0x150cdd){const _0x496d5b=_0x150cdd['getPredecessorKey'](new E(_0x245be4,_0x3f7068));return _0x496d5b?_0x496d5b['name']:null;}else return this['children_']['getPredecessorKey'](_0x245be4);}['getFirstChildName'](_0x5ce2c0){const _0x401765=this['resolveIndex_'](_0x5ce2c0);if(_0x401765){const _0x225c30=_0x401765['minKey']();return _0x225c30&&_0x225c30['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x570f17){const _0x424ca7=this['getFirstChildName'](_0x570f17);return _0x424ca7?new E(_0x424ca7,this['children_']['get'](_0x424ca7)):null;}['getLastChildName'](_0x730a96){const _0x52f9ea=this['resolveIndex_'](_0x730a96);if(_0x52f9ea){const _0x5ceffd=_0x52f9ea['maxKey']();return _0x5ceffd&&_0x5ceffd['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xfc8fc0){const _0x329590=this['getLastChildName'](_0xfc8fc0);return _0x329590?new E(_0x329590,this['children_']['get'](_0x329590)):null;}['forEachChild'](_0x1f549c,_0x46b861){const _0x2a3cb8=this['resolveIndex_'](_0x1f549c);return _0x2a3cb8?_0x2a3cb8['inorderTraversal'](_0x24bc13=>_0x46b861(_0x24bc13['name'],_0x24bc13['node'])):this['children_']['inorderTraversal'](_0x46b861);}['getIterator'](_0x3303b9){return this['getIteratorFrom'](_0x3303b9['minPost'](),_0x3303b9);}['getIteratorFrom'](_0xd80fcd,_0x257ead){const _0x11537e=this['resolveIndex_'](_0x257ead);if(_0x11537e)return _0x11537e['getIteratorFrom'](_0xd80fcd,_0x366dcc=>_0x366dcc);{const _0x1d48d6=this['children_']['getIteratorFrom'](_0xd80fcd['name'],E['Wrap']);let _0x337839=_0x1d48d6['peek']();for(;_0x337839!=null&&_0x257ead['compare'](_0x337839,_0xd80fcd)<0x0;)_0x1d48d6['getNext'](),_0x337839=_0x1d48d6['peek']();return _0x1d48d6;}}['getReverseIterator'](_0x237dc3){return this['getReverseIteratorFrom'](_0x237dc3['maxPost'](),_0x237dc3);}['getReverseIteratorFrom'](_0x120e94,_0x763071){const _0x42d55c=this['resolveIndex_'](_0x763071);if(_0x42d55c)return _0x42d55c['getReverseIteratorFrom'](_0x120e94,_0x4d4cde=>_0x4d4cde);{const _0x53def0=this['children_']['getReverseIteratorFrom'](_0x120e94['name'],E['Wrap']);let _0x50c810=_0x53def0['peek']();for(;_0x50c810!=null&&_0x763071['compare'](_0x50c810,_0x120e94)>0x0;)_0x53def0['getNext'](),_0x50c810=_0x53def0['peek']();return _0x53def0;}}['compareTo'](_0x15e814){return this['isEmpty']()?_0x15e814['isEmpty']()?0x0:-0x1:_0x15e814['isLeafNode']()||_0x15e814['isEmpty']()?0x1:_0x15e814===Ht?-0x1:0x0;}['withIndex'](_0x2ec7df){if(_0x2ec7df===ye||this['indexMap_']['hasIndex'](_0x2ec7df))return this;{const _0xe1af4=this['indexMap_']['addIndex'](_0x2ec7df,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xe1af4);}}['isIndexed'](_0x492d55){return _0x492d55===ye||this['indexMap_']['hasIndex'](_0x492d55);}['equals'](_0x1a10d7){if(_0x1a10d7===this)return!0x0;if(_0x1a10d7['isLeafNode']())return!0x1;{const _0x373a51=_0x1a10d7;if(this['getPriority']()['equals'](_0x373a51['getPriority']())){if(this['children_']['count']()===_0x373a51['children_']['count']()){const _0x5bf2b4=this['getIterator'](R),_0x5f2355=_0x373a51['getIterator'](R);let _0x42653d=_0x5bf2b4['getNext'](),_0x5a858d=_0x5f2355['getNext']();for(;_0x42653d&&_0x5a858d;){if(_0x42653d['name']!==_0x5a858d['name']||!_0x42653d['node']['equals'](_0x5a858d['node']))return!0x1;_0x42653d=_0x5bf2b4['getNext'](),_0x5a858d=_0x5f2355['getNext']();}return _0x42653d===null&&_0x5a858d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5c4d2d){return _0x5c4d2d===ye?null:this['indexMap_']['get'](_0x5c4d2d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x3fdc8c){return _0x3fdc8c===this?0x0:0x1;}['equals'](_0xd6d6ce){return _0xd6d6ce===this;}['getPriority'](){return this;}['getImmediateChild'](_0x72cfd5){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x105786,_0x13a82e=null){if(_0x105786===null)return g['EMPTY_NODE'];if(typeof _0x105786=='object'&&'.priority'in _0x105786&&(_0x13a82e=_0x105786['.priority']),f(_0x13a82e===null||typeof _0x13a82e=='string'||typeof _0x13a82e=='number'||typeof _0x13a82e=='object'&&'.sv'in _0x13a82e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x13a82e),typeof _0x105786=='object'&&'.value'in _0x105786&&_0x105786['.value']!==null&&(_0x105786=_0x105786['.value']),typeof _0x105786!='object'||'.sv'in _0x105786){const _0x30ee78=_0x105786;return new D(_0x30ee78,N(_0x13a82e));}if(!(_0x105786 instanceof Array)&&Vh){const _0x356674=[];let _0x504dad=!0x1;if(x(_0x105786,(_0x292b54,_0x3056fa)=>{if(_0x292b54['substring'](0x0,0x1)!=='.'){const _0x590df3=N(_0x3056fa);_0x590df3['isEmpty']()||(_0x504dad=_0x504dad||!_0x590df3['getPriority']()['isEmpty'](),_0x356674['push'](new E(_0x292b54,_0x590df3)));}}),_0x356674['length']===0x0)return g['EMPTY_NODE'];const _0x42211f=dn(_0x356674,Dh,_0x5ddc3b=>_0x5ddc3b['name'],ji);if(_0x504dad){const _0x2b5c81=dn(_0x356674,R['getCompare']());return new g(_0x42211f,N(_0x13a82e),new ee({'.priority':_0x2b5c81},{'.priority':R}));}else return new g(_0x42211f,N(_0x13a82e),ee['Default']);}else{let _0xda8992=g['EMPTY_NODE'];return x(_0x105786,(_0x835cc4,_0x547c9f)=>{if(Y(_0x105786,_0x835cc4)&&_0x835cc4['substring'](0x0,0x1)!=='.'){const _0x4e2345=N(_0x547c9f);(_0x4e2345['isLeafNode']()||!_0x4e2345['isEmpty']())&&(_0xda8992=_0xda8992['updateImmediateChild'](_0x835cc4,_0x4e2345));}}),_0xda8992['updatePriority'](N(_0x13a82e));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x264259){super(),this['indexPath_']=_0x264259,f(!v(_0x264259)&&y(_0x264259)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x44249f){return _0x44249f['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1fabce){return!_0x1fabce['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x55f27d,_0x61da7b){const _0x188805=this['extractChild'](_0x55f27d['node']),_0x130ec1=this['extractChild'](_0x61da7b['node']),_0x8e7e=_0x188805['compareTo'](_0x130ec1);return _0x8e7e===0x0?He(_0x55f27d['name'],_0x61da7b['name']):_0x8e7e;}['makePost'](_0x55c92b,_0xb58315){const _0xb9e27e=N(_0x55c92b),_0x161b74=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xb9e27e);return new E(_0xb58315,_0x161b74);}['maxPost'](){const _0x53ebcf=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x53ebcf);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x24dd81,_0x43f869){const _0x58c921=_0x24dd81['node']['compareTo'](_0x43f869['node']);return _0x58c921===0x0?He(_0x24dd81['name'],_0x43f869['name']):_0x58c921;}['isDefinedOn'](_0x3cb13a){return!0x0;}['indexedValueChanged'](_0x3fa495,_0xb69233){return!_0x3fa495['equals'](_0xb69233);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2439e0,_0x1ba8b4){const _0x3f91aa=N(_0x2439e0);return new E(_0x1ba8b4,_0x3f91aa);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x2809d0){return{'type':'value','snapshotNode':_0x2809d0};}function tt(_0x2c146b,_0x2dbafd){return{'type':'child_added','snapshotNode':_0x2dbafd,'childName':_0x2c146b};}function Nt(_0x10c1d0,_0x34ce3d){return{'type':'child_removed','snapshotNode':_0x34ce3d,'childName':_0x10c1d0};}function Pt(_0x3c2b87,_0x5ec502,_0x1490a7){return{'type':'child_changed','snapshotNode':_0x5ec502,'childName':_0x3c2b87,'oldSnap':_0x1490a7};}function $h(_0x3e8eae,_0x5a6579){return{'type':'child_moved','snapshotNode':_0x5a6579,'childName':_0x3e8eae};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x1ae073){this['index_']=_0x1ae073;}['updateChild'](_0x277f31,_0x7f08a1,_0x2bcc6e,_0x3e369a,_0x235664,_0x495445){f(_0x277f31['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x487881=_0x277f31['getImmediateChild'](_0x7f08a1);return _0x487881['getChild'](_0x3e369a)['equals'](_0x2bcc6e['getChild'](_0x3e369a))&&_0x487881['isEmpty']()===_0x2bcc6e['isEmpty']()||(_0x495445!=null&&(_0x2bcc6e['isEmpty']()?_0x277f31['hasChild'](_0x7f08a1)?_0x495445['trackChildChange'](Nt(_0x7f08a1,_0x487881)):f(_0x277f31['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x487881['isEmpty']()?_0x495445['trackChildChange'](tt(_0x7f08a1,_0x2bcc6e)):_0x495445['trackChildChange'](Pt(_0x7f08a1,_0x2bcc6e,_0x487881))),_0x277f31['isLeafNode']()&&_0x2bcc6e['isEmpty']())?_0x277f31:_0x277f31['updateImmediateChild'](_0x7f08a1,_0x2bcc6e)['withIndex'](this['index_']);}['updateFullNode'](_0x54c724,_0xaa747,_0xd6b5b7){return _0xd6b5b7!=null&&(_0x54c724['isLeafNode']()||_0x54c724['forEachChild'](R,(_0x435384,_0x5c4aba)=>{_0xaa747['hasChild'](_0x435384)||_0xd6b5b7['trackChildChange'](Nt(_0x435384,_0x5c4aba));}),_0xaa747['isLeafNode']()||_0xaa747['forEachChild'](R,(_0xe290,_0x176bad)=>{if(_0x54c724['hasChild'](_0xe290)){const _0x371f12=_0x54c724['getImmediateChild'](_0xe290);_0x371f12['equals'](_0x176bad)||_0xd6b5b7['trackChildChange'](Pt(_0xe290,_0x176bad,_0x371f12));}else _0xd6b5b7['trackChildChange'](tt(_0xe290,_0x176bad));})),_0xaa747['withIndex'](this['index_']);}['updatePriority'](_0x428319,_0x2b1753){return _0x428319['isEmpty']()?g['EMPTY_NODE']:_0x428319['updatePriority'](_0x2b1753);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x487bca){this['indexedFilter_']=new Yi(_0x487bca['getIndex']()),this['index_']=_0x487bca['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x487bca),this['endPost_']=Ot['getEndPost_'](_0x487bca),this['startIsInclusive_']=!_0x487bca['startAfterSet_'],this['endIsInclusive_']=!_0x487bca['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xba5cb4){const _0x55b3b7=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xba5cb4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xba5cb4)<0x0,_0x336648=this['endIsInclusive_']?this['index_']['compare'](_0xba5cb4,this['getEndPost']())<=0x0:this['index_']['compare'](_0xba5cb4,this['getEndPost']())<0x0;return _0x55b3b7&&_0x336648;}['updateChild'](_0x19124b,_0x5dd01c,_0x500514,_0x1c50fa,_0x48adb2,_0x502647){return this['matches'](new E(_0x5dd01c,_0x500514))||(_0x500514=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x19124b,_0x5dd01c,_0x500514,_0x1c50fa,_0x48adb2,_0x502647);}['updateFullNode'](_0x51a0d0,_0x5742f2,_0x5aa558){_0x5742f2['isLeafNode']()&&(_0x5742f2=g['EMPTY_NODE']);let _0x2b2d8e=_0x5742f2['withIndex'](this['index_']);_0x2b2d8e=_0x2b2d8e['updatePriority'](g['EMPTY_NODE']);const _0x3bcf3e=this;return _0x5742f2['forEachChild'](R,(_0x248025,_0x5a7c09)=>{_0x3bcf3e['matches'](new E(_0x248025,_0x5a7c09))||(_0x2b2d8e=_0x2b2d8e['updateImmediateChild'](_0x248025,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x51a0d0,_0x2b2d8e,_0x5aa558);}['updatePriority'](_0x9b2488,_0x32677f){return _0x9b2488;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x23de0a){if(_0x23de0a['hasStart']()){const _0x1acdb7=_0x23de0a['getIndexStartName']();return _0x23de0a['getIndex']()['makePost'](_0x23de0a['getIndexStartValue'](),_0x1acdb7);}else return _0x23de0a['getIndex']()['minPost']();}static['getEndPost_'](_0x15a487){if(_0x15a487['hasEnd']()){const _0x47cf2f=_0x15a487['getIndexEndName']();return _0x15a487['getIndex']()['makePost'](_0x15a487['getIndexEndValue'](),_0x47cf2f);}else return _0x15a487['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xf5698d){this['withinDirectionalStart']=_0x98e20e=>this['reverse_']?this['withinEndPost'](_0x98e20e):this['withinStartPost'](_0x98e20e),this['withinDirectionalEnd']=_0x3a07f1=>this['reverse_']?this['withinStartPost'](_0x3a07f1):this['withinEndPost'](_0x3a07f1),this['withinStartPost']=_0xcfe490=>{const _0x186feb=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xcfe490);return this['startIsInclusive_']?_0x186feb<=0x0:_0x186feb<0x0;},this['withinEndPost']=_0x3278c7=>{const _0x307117=this['index_']['compare'](_0x3278c7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x307117<=0x0:_0x307117<0x0;},this['rangedFilter_']=new Ot(_0xf5698d),this['index_']=_0xf5698d['getIndex'](),this['limit_']=_0xf5698d['getLimit'](),this['reverse_']=!_0xf5698d['isViewFromLeft'](),this['startIsInclusive_']=!_0xf5698d['startAfterSet_'],this['endIsInclusive_']=!_0xf5698d['endBeforeSet_'];}['updateChild'](_0x49ae44,_0x7df9fa,_0x5e6caa,_0x1b87fd,_0x39b4de,_0x2165e7){return this['rangedFilter_']['matches'](new E(_0x7df9fa,_0x5e6caa))||(_0x5e6caa=g['EMPTY_NODE']),_0x49ae44['getImmediateChild'](_0x7df9fa)['equals'](_0x5e6caa)?_0x49ae44:_0x49ae44['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x49ae44,_0x7df9fa,_0x5e6caa,_0x1b87fd,_0x39b4de,_0x2165e7):this['fullLimitUpdateChild_'](_0x49ae44,_0x7df9fa,_0x5e6caa,_0x39b4de,_0x2165e7);}['updateFullNode'](_0x2d188a,_0x2925d5,_0x1cb09c){let _0x32aef6;if(_0x2925d5['isLeafNode']()||_0x2925d5['isEmpty']())_0x32aef6=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2925d5['numChildren']()&&_0x2925d5['isIndexed'](this['index_'])){_0x32aef6=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x14a075;this['reverse_']?_0x14a075=_0x2925d5['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x14a075=_0x2925d5['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x322bc6=0x0;for(;_0x14a075['hasNext']()&&_0x322bc6<this['limit_'];){const _0xa7356e=_0x14a075['getNext']();if(this['withinDirectionalStart'](_0xa7356e)){if(this['withinDirectionalEnd'](_0xa7356e))_0x32aef6=_0x32aef6['updateImmediateChild'](_0xa7356e['name'],_0xa7356e['node']),_0x322bc6++;else break;}else continue;}}else{_0x32aef6=_0x2925d5['withIndex'](this['index_']),_0x32aef6=_0x32aef6['updatePriority'](g['EMPTY_NODE']);let _0x3a20e8;this['reverse_']?_0x3a20e8=_0x32aef6['getReverseIterator'](this['index_']):_0x3a20e8=_0x32aef6['getIterator'](this['index_']);let _0x110d2d=0x0;for(;_0x3a20e8['hasNext']();){const _0x2ac746=_0x3a20e8['getNext']();_0x110d2d<this['limit_']&&this['withinDirectionalStart'](_0x2ac746)&&this['withinDirectionalEnd'](_0x2ac746)?_0x110d2d++:_0x32aef6=_0x32aef6['updateImmediateChild'](_0x2ac746['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2d188a,_0x32aef6,_0x1cb09c);}['updatePriority'](_0x5cc6ec,_0x22c311){return _0x5cc6ec;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x58a968,_0x3fbb82,_0x3b9165,_0x3a380f,_0x5b5977){let _0x208a48;if(this['reverse_']){const _0x955c47=this['index_']['getCompare']();_0x208a48=(_0x5122f9,_0x4c2cd7)=>_0x955c47(_0x4c2cd7,_0x5122f9);}else _0x208a48=this['index_']['getCompare']();const _0x3b1753=_0x58a968;f(_0x3b1753['numChildren']()===this['limit_'],'');const _0x2687b1=new E(_0x3fbb82,_0x3b9165),_0x2f3b75=this['reverse_']?_0x3b1753['getFirstChild'](this['index_']):_0x3b1753['getLastChild'](this['index_']),_0x4256a8=this['rangedFilter_']['matches'](_0x2687b1);if(_0x3b1753['hasChild'](_0x3fbb82)){const _0x3548e2=_0x3b1753['getImmediateChild'](_0x3fbb82);let _0x4623bc=_0x3a380f['getChildAfterChild'](this['index_'],_0x2f3b75,this['reverse_']);for(;_0x4623bc!=null&&(_0x4623bc['name']===_0x3fbb82||_0x3b1753['hasChild'](_0x4623bc['name']));)_0x4623bc=_0x3a380f['getChildAfterChild'](this['index_'],_0x4623bc,this['reverse_']);const _0x511154=_0x4623bc==null?0x1:_0x208a48(_0x4623bc,_0x2687b1);if(_0x4256a8&&!_0x3b9165['isEmpty']()&&_0x511154>=0x0)return _0x5b5977!=null&&_0x5b5977['trackChildChange'](Pt(_0x3fbb82,_0x3b9165,_0x3548e2)),_0x3b1753['updateImmediateChild'](_0x3fbb82,_0x3b9165);{_0x5b5977!=null&&_0x5b5977['trackChildChange'](Nt(_0x3fbb82,_0x3548e2));const _0x5958dd=_0x3b1753['updateImmediateChild'](_0x3fbb82,g['EMPTY_NODE']);return _0x4623bc!=null&&this['rangedFilter_']['matches'](_0x4623bc)?(_0x5b5977!=null&&_0x5b5977['trackChildChange'](tt(_0x4623bc['name'],_0x4623bc['node'])),_0x5958dd['updateImmediateChild'](_0x4623bc['name'],_0x4623bc['node'])):_0x5958dd;}}else return _0x3b9165['isEmpty']()?_0x58a968:_0x4256a8&&_0x208a48(_0x2f3b75,_0x2687b1)>=0x0?(_0x5b5977!=null&&(_0x5b5977['trackChildChange'](Nt(_0x2f3b75['name'],_0x2f3b75['node'])),_0x5b5977['trackChildChange'](tt(_0x3fbb82,_0x3b9165))),_0x3b1753['updateImmediateChild'](_0x3fbb82,_0x3b9165)['updateImmediateChild'](_0x2f3b75['name'],g['EMPTY_NODE'])):_0x58a968;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5ae3ea=new Qi();return _0x5ae3ea['limitSet_']=this['limitSet_'],_0x5ae3ea['limit_']=this['limit_'],_0x5ae3ea['startSet_']=this['startSet_'],_0x5ae3ea['startAfterSet_']=this['startAfterSet_'],_0x5ae3ea['indexStartValue_']=this['indexStartValue_'],_0x5ae3ea['startNameSet_']=this['startNameSet_'],_0x5ae3ea['indexStartName_']=this['indexStartName_'],_0x5ae3ea['endSet_']=this['endSet_'],_0x5ae3ea['endBeforeSet_']=this['endBeforeSet_'],_0x5ae3ea['indexEndValue_']=this['indexEndValue_'],_0x5ae3ea['endNameSet_']=this['endNameSet_'],_0x5ae3ea['indexEndName_']=this['indexEndName_'],_0x5ae3ea['index_']=this['index_'],_0x5ae3ea['viewFrom_']=this['viewFrom_'],_0x5ae3ea;}}function qh(_0x2cf186){return _0x2cf186['loadsAllData']()?new Yi(_0x2cf186['getIndex']()):_0x2cf186['hasLimit']()?new Gh(_0x2cf186):new Ot(_0x2cf186);}function zh(_0x46205e,_0x2712b8){const _0x56b2de=_0x46205e['copy']();return _0x56b2de['limitSet_']=!0x0,_0x56b2de['limit_']=_0x2712b8,_0x56b2de['viewFrom_']='l',_0x56b2de;}function jh(_0x2f225d,_0x6993fa,_0x5682f1){const _0x9e2013=_0x2f225d['copy']();return _0x9e2013['startSet_']=!0x0,_0x6993fa===void 0x0&&(_0x6993fa=null),_0x9e2013['indexStartValue_']=_0x6993fa,_0x5682f1!=null?(_0x9e2013['startNameSet_']=!0x0,_0x9e2013['indexStartName_']=_0x5682f1):(_0x9e2013['startNameSet_']=!0x1,_0x9e2013['indexStartName_']=''),_0x9e2013;}function Kh(_0x25f6a7,_0x1b13e4,_0x49bc6d){const _0x530d7d=_0x25f6a7['copy']();return _0x530d7d['endSet_']=!0x0,_0x1b13e4===void 0x0&&(_0x1b13e4=null),_0x530d7d['indexEndValue_']=_0x1b13e4,_0x49bc6d!==void 0x0?(_0x530d7d['endNameSet_']=!0x0,_0x530d7d['indexEndName_']=_0x49bc6d):(_0x530d7d['endNameSet_']=!0x1,_0x530d7d['indexEndName_']=''),_0x530d7d;}function Do(_0x3d860d,_0x3dca90){const _0x1c8b64=_0x3d860d['copy']();return _0x1c8b64['index_']=_0x3dca90,_0x1c8b64;}function tr(_0x515e9c){const _0x1e9b6e={};if(_0x515e9c['isDefault']())return _0x1e9b6e;let _0xe01247;if(_0x515e9c['index_']===R?_0xe01247='$priority':_0x515e9c['index_']===Po?_0xe01247='$value':_0x515e9c['index_']===ye?_0xe01247='$key':(f(_0x515e9c['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0xe01247=_0x515e9c['index_']['toString']()),_0x1e9b6e['orderBy']=O(_0xe01247),_0x515e9c['startSet_']){const _0x4a8346=_0x515e9c['startAfterSet_']?'startAfter':'startAt';_0x1e9b6e[_0x4a8346]=O(_0x515e9c['indexStartValue_']),_0x515e9c['startNameSet_']&&(_0x1e9b6e[_0x4a8346]+=','+O(_0x515e9c['indexStartName_']));}if(_0x515e9c['endSet_']){const _0xb4dc6a=_0x515e9c['endBeforeSet_']?'endBefore':'endAt';_0x1e9b6e[_0xb4dc6a]=O(_0x515e9c['indexEndValue_']),_0x515e9c['endNameSet_']&&(_0x1e9b6e[_0xb4dc6a]+=','+O(_0x515e9c['indexEndName_']));}return _0x515e9c['limitSet_']&&(_0x515e9c['isViewFromLeft']()?_0x1e9b6e['limitToFirst']=_0x515e9c['limit_']:_0x1e9b6e['limitToLast']=_0x515e9c['limit_']),_0x1e9b6e;}function nr(_0x181803){const _0x259ec4={};if(_0x181803['startSet_']&&(_0x259ec4['sp']=_0x181803['indexStartValue_'],_0x181803['startNameSet_']&&(_0x259ec4['sn']=_0x181803['indexStartName_']),_0x259ec4['sin']=!_0x181803['startAfterSet_']),_0x181803['endSet_']&&(_0x259ec4['ep']=_0x181803['indexEndValue_'],_0x181803['endNameSet_']&&(_0x259ec4['en']=_0x181803['indexEndName_']),_0x259ec4['ein']=!_0x181803['endBeforeSet_']),_0x181803['limitSet_']){_0x259ec4['l']=_0x181803['limit_'];let _0x34d3e5=_0x181803['viewFrom_'];_0x34d3e5===''&&(_0x181803['isViewFromLeft']()?_0x34d3e5='l':_0x34d3e5='r'),_0x259ec4['vf']=_0x34d3e5;}return _0x181803['index_']!==R&&(_0x259ec4['i']=_0x181803['index_']['toString']()),_0x259ec4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x11e875){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x28ac5e,_0x55808e){return _0x55808e!==void 0x0?'tag$'+_0x55808e:(f(_0x28ac5e['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x28ac5e['_path']['toString']());}constructor(_0x18f6e7,_0x31fade,_0x483eb8,_0x3cb43d){super(),this['repoInfo_']=_0x18f6e7,this['onDataUpdate_']=_0x31fade,this['authTokenProvider_']=_0x483eb8,this['appCheckTokenProvider_']=_0x3cb43d,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x3b4e2f,_0x47f579,_0x29391b,_0x36970b){const _0x526eb0=_0x3b4e2f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x526eb0+'\x20'+_0x3b4e2f['_queryIdentifier']);const _0x3e8f5e=fn['getListenId_'](_0x3b4e2f,_0x29391b),_0x4bdd3d={};this['listens_'][_0x3e8f5e]=_0x4bdd3d;const _0x1d041b=tr(_0x3b4e2f['_queryParams']);this['restRequest_'](_0x526eb0+'.json',_0x1d041b,(_0xad1357,_0x3dc7a8)=>{let _0xff36f6=_0x3dc7a8;if(_0xad1357===0x194&&(_0xff36f6=null,_0xad1357=null),_0xad1357===null&&this['onDataUpdate_'](_0x526eb0,_0xff36f6,!0x1,_0x29391b),Oe(this['listens_'],_0x3e8f5e)===_0x4bdd3d){let _0x2d9a38;_0xad1357?_0xad1357===0x191?_0x2d9a38='permission_denied':_0x2d9a38='rest_error:'+_0xad1357:_0x2d9a38='ok',_0x36970b(_0x2d9a38,null);}});}['unlisten'](_0x44cb17,_0x52f4e6){const _0x539b12=fn['getListenId_'](_0x44cb17,_0x52f4e6);delete this['listens_'][_0x539b12];}['get'](_0x5c260a){const _0x17bc80=tr(_0x5c260a['_queryParams']),_0x366703=_0x5c260a['_path']['toString'](),_0x477d61=new Ve();return this['restRequest_'](_0x366703+'.json',_0x17bc80,(_0x559a0f,_0xdac071)=>{let _0x19dbd9=_0xdac071;_0x559a0f===0x194&&(_0x19dbd9=null,_0x559a0f=null),_0x559a0f===null?(this['onDataUpdate_'](_0x366703,_0x19dbd9,!0x1,null),_0x477d61['resolve'](_0x19dbd9)):_0x477d61['reject'](new Error(_0x19dbd9));}),_0x477d61['promise'];}['refreshAuthToken'](_0x392ace){}['restRequest_'](_0x5e3b86,_0x7d9fb1={},_0x2852c4){return _0x7d9fb1['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x771bf5,_0x4af94c])=>{_0x771bf5&&_0x771bf5['accessToken']&&(_0x7d9fb1['auth']=_0x771bf5['accessToken']),_0x4af94c&&_0x4af94c['token']&&(_0x7d9fb1['ac']=_0x4af94c['token']);const _0x20adfd=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5e3b86+'?ns='+this['repoInfo_']['namespace']+at(_0x7d9fb1);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x20adfd);const _0x2e287a=new XMLHttpRequest();_0x2e287a['onreadystatechange']=()=>{if(_0x2852c4&&_0x2e287a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x20adfd+'\x20received.\x20status:',_0x2e287a['status'],'response:',_0x2e287a['responseText']);let _0x3aafd7=null;if(_0x2e287a['status']>=0xc8&&_0x2e287a['status']<0x12c){try{_0x3aafd7=bt(_0x2e287a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x20adfd+':\x20'+_0x2e287a['responseText']);}_0x2852c4(null,_0x3aafd7);}else _0x2e287a['status']!==0x191&&_0x2e287a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x20adfd+'\x20Status:\x20'+_0x2e287a['status']),_0x2852c4(_0x2e287a['status']);_0x2852c4=null;}},_0x2e287a['open']('GET',_0x20adfd,!0x0),_0x2e287a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x18140b){return this['rootNode_']['getChild'](_0x18140b);}['updateSnapshot'](_0x166942,_0x62d1bc){this['rootNode_']=this['rootNode_']['updateChild'](_0x166942,_0x62d1bc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x431c90,_0x1d78cf,_0x24837a){if(v(_0x1d78cf))_0x431c90['value']=_0x24837a,_0x431c90['children']['clear']();else{if(_0x431c90['value']!==null)_0x431c90['value']=_0x431c90['value']['updateChild'](_0x1d78cf,_0x24837a);else{const _0x917b4b=y(_0x1d78cf);_0x431c90['children']['has'](_0x917b4b)||_0x431c90['children']['set'](_0x917b4b,pn());const _0x368d3c=_0x431c90['children']['get'](_0x917b4b);_0x1d78cf=b(_0x1d78cf),Mo(_0x368d3c,_0x1d78cf,_0x24837a);}}}function Ei(_0x32cbcb,_0x33651c,_0x40053c){_0x32cbcb['value']!==null?_0x40053c(_0x33651c,_0x32cbcb['value']):Qh(_0x32cbcb,(_0x227ca8,_0x46b99e)=>{const _0x1d377f=new C(_0x33651c['toString']()+'/'+_0x227ca8);Ei(_0x46b99e,_0x1d377f,_0x40053c);});}function Qh(_0x16e13d,_0x4af69e){_0x16e13d['children']['forEach']((_0x3e956b,_0x3fd677)=>{_0x4af69e(_0x3fd677,_0x3e956b);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x1209ad){this['collection_']=_0x1209ad,this['last_']=null;}['get'](){const _0x8836bf=this['collection_']['get'](),_0x142c0d={..._0x8836bf};return this['last_']&&x(this['last_'],(_0x3daaf1,_0xecd64c)=>{_0x142c0d[_0x3daaf1]=_0x142c0d[_0x3daaf1]-_0xecd64c;}),this['last_']=_0x8836bf,_0x142c0d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x58512a,_0x46b385){this['server_']=_0x46b385,this['statsToReport_']={},this['statsListener_']=new Jh(_0x58512a);const _0xdf2bf0=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0xdf2bf0));}['reportStats_'](){const _0x110809=this['statsListener_']['get'](),_0x1fae13={};let _0x1034e0=!0x1;x(_0x110809,(_0x3d1f4e,_0x1dd566)=>{_0x1dd566>0x0&&Y(this['statsToReport_'],_0x3d1f4e)&&(_0x1fae13[_0x3d1f4e]=_0x1dd566,_0x1034e0=!0x0);}),_0x1034e0&&this['server_']['reportStats'](_0x1fae13),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x58583d){_0x58583d[_0x58583d['OVERWRITE']=0x0]='OVERWRITE',_0x58583d[_0x58583d['MERGE']=0x1]='MERGE',_0x58583d[_0x58583d['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x58583d[_0x58583d['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x309b50){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x309b50,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x28c34d,_0x174c0b,_0x1ed088){this['path']=_0x28c34d,this['affectedTree']=_0x174c0b,this['revert']=_0x1ed088,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x313e35){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xbb9a38=this['affectedTree']['subtree'](new C(_0x313e35));return new _n(w(),_0xbb9a38,this['revert']);}}else return f(y(this['path'])===_0x313e35,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x224ff8,_0x2a8037){this['source']=_0x224ff8,this['path']=_0x2a8037,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x5ab5a9){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2337f4,_0x3c7968,_0x382525){this['source']=_0x2337f4,this['path']=_0x3c7968,this['snap']=_0x382525,this['type']=q['OVERWRITE'];}['operationForChild'](_0x2fbf28){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x2fbf28)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x48ba0d,_0x21a4b8,_0x572ad3){this['source']=_0x48ba0d,this['path']=_0x21a4b8,this['children']=_0x572ad3,this['type']=q['MERGE'];}['operationForChild'](_0x16595e){if(v(this['path'])){const _0x3deb15=this['children']['subtree'](new C(_0x16595e));return _0x3deb15['isEmpty']()?null:_0x3deb15['value']?new Fe(this['source'],w(),_0x3deb15['value']):new nt(this['source'],w(),_0x3deb15);}else return f(y(this['path'])===_0x16595e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x10a846,_0x4eb457,_0x3ff331){this['node_']=_0x10a846,this['fullyInitialized_']=_0x4eb457,this['filtered_']=_0x3ff331;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x55188c){if(v(_0x55188c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x306461=y(_0x55188c);return this['isCompleteForChild'](_0x306461);}['isCompleteForChild'](_0x3d46b8){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3d46b8);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2ea475){this['query_']=_0x2ea475,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x2e4505,_0x3cafde,_0x3aff92,_0x460079){const _0x11f41c=[],_0xd5bda7=[];return _0x3cafde['forEach'](_0x1cc609=>{_0x1cc609['type']==='child_changed'&&_0x2e4505['index_']['indexedValueChanged'](_0x1cc609['oldSnap'],_0x1cc609['snapshotNode'])&&_0xd5bda7['push']($h(_0x1cc609['childName'],_0x1cc609['snapshotNode']));}),mt(_0x2e4505,_0x11f41c,'child_removed',_0x3cafde,_0x460079,_0x3aff92),mt(_0x2e4505,_0x11f41c,'child_added',_0x3cafde,_0x460079,_0x3aff92),mt(_0x2e4505,_0x11f41c,'child_moved',_0xd5bda7,_0x460079,_0x3aff92),mt(_0x2e4505,_0x11f41c,'child_changed',_0x3cafde,_0x460079,_0x3aff92),mt(_0x2e4505,_0x11f41c,'value',_0x3cafde,_0x460079,_0x3aff92),_0x11f41c;}function mt(_0x289d5b,_0x733102,_0x115857,_0x32dd78,_0x1527f9,_0x599a96){const _0x12892a=_0x32dd78['filter'](_0x492c11=>_0x492c11['type']===_0x115857);_0x12892a['sort']((_0x4d1b17,_0x3fc07a)=>su(_0x289d5b,_0x4d1b17,_0x3fc07a)),_0x12892a['forEach'](_0x6beb29=>{const _0x501c05=iu(_0x289d5b,_0x6beb29,_0x599a96);_0x1527f9['forEach'](_0x900452=>{_0x900452['respondsTo'](_0x6beb29['type'])&&_0x733102['push'](_0x900452['createEvent'](_0x501c05,_0x289d5b['query_']));});});}function iu(_0x2608a3,_0x19ded5,_0x31ef05){return _0x19ded5['type']==='value'||_0x19ded5['type']==='child_removed'||(_0x19ded5['prevName']=_0x31ef05['getPredecessorChildName'](_0x19ded5['childName'],_0x19ded5['snapshotNode'],_0x2608a3['index_'])),_0x19ded5;}function su(_0x27e977,_0x3d8348,_0x500851){if(_0x3d8348['childName']==null||_0x500851['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x3b6817=new E(_0x3d8348['childName'],_0x3d8348['snapshotNode']),_0x21c7d2=new E(_0x500851['childName'],_0x500851['snapshotNode']);return _0x27e977['index_']['compare'](_0x3b6817,_0x21c7d2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x4724d8,_0x47876d){return{'eventCache':_0x4724d8,'serverCache':_0x47876d};}function wt(_0x555720,_0x5c3bba,_0x675998,_0x257b28){return Dn(new Ce(_0x5c3bba,_0x675998,_0x257b28),_0x555720['serverCache']);}function Lo(_0x4ec47d,_0x3f1a79,_0x2061c7,_0x423206){return Dn(_0x4ec47d['eventCache'],new Ce(_0x3f1a79,_0x2061c7,_0x423206));}function gn(_0x2cb85e){return _0x2cb85e['eventCache']['isFullyInitialized']()?_0x2cb85e['eventCache']['getNode']():null;}function Ue(_0x1ee4e5){return _0x1ee4e5['serverCache']['isFullyInitialized']()?_0x1ee4e5['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x295864){let _0x984876=new S(null);return x(_0x295864,(_0x5798c9,_0x246eae)=>{_0x984876=_0x984876['set'](new C(_0x5798c9),_0x246eae);}),_0x984876;}constructor(_0x1db5c5,_0x3c1f15=ru()){this['value']=_0x1db5c5,this['children']=_0x3c1f15;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3a3d91,_0x500420){if(this['value']!=null&&_0x500420(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3a3d91))return null;{const _0x252427=y(_0x3a3d91),_0x262f31=this['children']['get'](_0x252427);if(_0x262f31!==null){const _0x347158=_0x262f31['findRootMostMatchingPathAndValue'](b(_0x3a3d91),_0x500420);return _0x347158!=null?{'path':A(new C(_0x252427),_0x347158['path']),'value':_0x347158['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3b3ccc){return this['findRootMostMatchingPathAndValue'](_0x3b3ccc,()=>!0x0);}['subtree'](_0x2ab8b4){if(v(_0x2ab8b4))return this;{const _0x46513d=y(_0x2ab8b4),_0x2164a7=this['children']['get'](_0x46513d);return _0x2164a7!==null?_0x2164a7['subtree'](b(_0x2ab8b4)):new S(null);}}['set'](_0x38bc54,_0x5899b0){if(v(_0x38bc54))return new S(_0x5899b0,this['children']);{const _0x220c1e=y(_0x38bc54),_0x45c824=(this['children']['get'](_0x220c1e)||new S(null))['set'](b(_0x38bc54),_0x5899b0),_0x2c5074=this['children']['insert'](_0x220c1e,_0x45c824);return new S(this['value'],_0x2c5074);}}['remove'](_0x1c0de4){if(v(_0x1c0de4))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x11d318=y(_0x1c0de4),_0x2a5dc1=this['children']['get'](_0x11d318);if(_0x2a5dc1){const _0x53a480=_0x2a5dc1['remove'](b(_0x1c0de4));let _0xab2e5c;return _0x53a480['isEmpty']()?_0xab2e5c=this['children']['remove'](_0x11d318):_0xab2e5c=this['children']['insert'](_0x11d318,_0x53a480),this['value']===null&&_0xab2e5c['isEmpty']()?new S(null):new S(this['value'],_0xab2e5c);}else return this;}}['get'](_0x7bdf0e){if(v(_0x7bdf0e))return this['value'];{const _0x42e39f=y(_0x7bdf0e),_0x3dfdd9=this['children']['get'](_0x42e39f);return _0x3dfdd9?_0x3dfdd9['get'](b(_0x7bdf0e)):null;}}['setTree'](_0x1c39a8,_0x446fb){if(v(_0x1c39a8))return _0x446fb;{const _0x209cca=y(_0x1c39a8),_0x4c3bf6=(this['children']['get'](_0x209cca)||new S(null))['setTree'](b(_0x1c39a8),_0x446fb);let _0x202824;return _0x4c3bf6['isEmpty']()?_0x202824=this['children']['remove'](_0x209cca):_0x202824=this['children']['insert'](_0x209cca,_0x4c3bf6),new S(this['value'],_0x202824);}}['fold'](_0x19c4e3){return this['fold_'](w(),_0x19c4e3);}['fold_'](_0x37507d,_0x321b42){const _0x551c43={};return this['children']['inorderTraversal']((_0x386ad1,_0x4e5838)=>{_0x551c43[_0x386ad1]=_0x4e5838['fold_'](A(_0x37507d,_0x386ad1),_0x321b42);}),_0x321b42(_0x37507d,this['value'],_0x551c43);}['findOnPath'](_0x40084f,_0x17ac05){return this['findOnPath_'](_0x40084f,w(),_0x17ac05);}['findOnPath_'](_0x3d262f,_0xea9e92,_0x5d7e9e){const _0x503bbd=this['value']?_0x5d7e9e(_0xea9e92,this['value']):!0x1;if(_0x503bbd)return _0x503bbd;if(v(_0x3d262f))return null;{const _0x46a646=y(_0x3d262f),_0x49fcd7=this['children']['get'](_0x46a646);return _0x49fcd7?_0x49fcd7['findOnPath_'](b(_0x3d262f),A(_0xea9e92,_0x46a646),_0x5d7e9e):null;}}['foreachOnPath'](_0x1ff9b1,_0x240b50){return this['foreachOnPath_'](_0x1ff9b1,w(),_0x240b50);}['foreachOnPath_'](_0x1755f2,_0x1d32f6,_0x2548fc){if(v(_0x1755f2))return this;{this['value']&&_0x2548fc(_0x1d32f6,this['value']);const _0x36df8a=y(_0x1755f2),_0x5b1682=this['children']['get'](_0x36df8a);return _0x5b1682?_0x5b1682['foreachOnPath_'](b(_0x1755f2),A(_0x1d32f6,_0x36df8a),_0x2548fc):new S(null);}}['foreach'](_0x2c5141){this['foreach_'](w(),_0x2c5141);}['foreach_'](_0x132103,_0x2510d2){this['children']['inorderTraversal']((_0x51fe2b,_0x5ce1a5)=>{_0x5ce1a5['foreach_'](A(_0x132103,_0x51fe2b),_0x2510d2);}),this['value']&&_0x2510d2(_0x132103,this['value']);}['foreachChild'](_0x185525){this['children']['inorderTraversal']((_0x378ab3,_0x7e31fb)=>{_0x7e31fb['value']&&_0x185525(_0x378ab3,_0x7e31fb['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0xe85460){this['writeTree_']=_0xe85460;}static['empty'](){return new j(new S(null));}}function Ct(_0x35ca12,_0x5d49cd,_0x4357fd){if(v(_0x5d49cd))return new j(new S(_0x4357fd));{const _0x2c7739=_0x35ca12['writeTree_']['findRootMostValueAndPath'](_0x5d49cd);if(_0x2c7739!=null){const _0x3a9c62=_0x2c7739['path'];let _0x226d34=_0x2c7739['value'];const _0x55d393=F(_0x3a9c62,_0x5d49cd);return _0x226d34=_0x226d34['updateChild'](_0x55d393,_0x4357fd),new j(_0x35ca12['writeTree_']['set'](_0x3a9c62,_0x226d34));}else{const _0xf1b6df=new S(_0x4357fd),_0x7d2a84=_0x35ca12['writeTree_']['setTree'](_0x5d49cd,_0xf1b6df);return new j(_0x7d2a84);}}}function Ii(_0x435af3,_0x95e076,_0x31d45f){let _0x51effe=_0x435af3;return x(_0x31d45f,(_0x4d7cc0,_0x188a34)=>{_0x51effe=Ct(_0x51effe,A(_0x95e076,_0x4d7cc0),_0x188a34);}),_0x51effe;}function sr(_0x526fc9,_0x4a8d4f){if(v(_0x4a8d4f))return j['empty']();{const _0x4441fc=_0x526fc9['writeTree_']['setTree'](_0x4a8d4f,new S(null));return new j(_0x4441fc);}}function wi(_0x575f7e,_0x40a4a8){return $e(_0x575f7e,_0x40a4a8)!=null;}function $e(_0x288173,_0x41572c){const _0x129de=_0x288173['writeTree_']['findRootMostValueAndPath'](_0x41572c);return _0x129de!=null?_0x288173['writeTree_']['get'](_0x129de['path'])['getChild'](F(_0x129de['path'],_0x41572c)):null;}function rr(_0x5b3c8a){const _0x5b15fb=[],_0x16f3fc=_0x5b3c8a['writeTree_']['value'];return _0x16f3fc!=null?_0x16f3fc['isLeafNode']()||_0x16f3fc['forEachChild'](R,(_0x228ff5,_0x5f413d)=>{_0x5b15fb['push'](new E(_0x228ff5,_0x5f413d));}):_0x5b3c8a['writeTree_']['children']['inorderTraversal']((_0x3c8b5f,_0x1b304d)=>{_0x1b304d['value']!=null&&_0x5b15fb['push'](new E(_0x3c8b5f,_0x1b304d['value']));}),_0x5b15fb;}function ve(_0x5edf8b,_0x3875aa){if(v(_0x3875aa))return _0x5edf8b;{const _0x3c43f6=$e(_0x5edf8b,_0x3875aa);return _0x3c43f6!=null?new j(new S(_0x3c43f6)):new j(_0x5edf8b['writeTree_']['subtree'](_0x3875aa));}}function Ci(_0xe5d385){return _0xe5d385['writeTree_']['isEmpty']();}function it(_0x25e75c,_0x126f54){return xo(w(),_0x25e75c['writeTree_'],_0x126f54);}function xo(_0x3c713a,_0x5b71d6,_0x35047d){if(_0x5b71d6['value']!=null)return _0x35047d['updateChild'](_0x3c713a,_0x5b71d6['value']);{let _0x521e4d=null;return _0x5b71d6['children']['inorderTraversal']((_0x1f3433,_0x150f31)=>{_0x1f3433==='.priority'?(f(_0x150f31['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x521e4d=_0x150f31['value']):_0x35047d=xo(A(_0x3c713a,_0x1f3433),_0x150f31,_0x35047d);}),!_0x35047d['getChild'](_0x3c713a)['isEmpty']()&&_0x521e4d!==null&&(_0x35047d=_0x35047d['updateChild'](A(_0x3c713a,'.priority'),_0x521e4d)),_0x35047d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x313300,_0x1b6f0d){return Bo(_0x1b6f0d,_0x313300);}function ou(_0x351006,_0x2afc2f,_0x38fc3d,_0x1bfa8d,_0x33599a){f(_0x1bfa8d>_0x351006['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x33599a===void 0x0&&(_0x33599a=!0x0),_0x351006['allWrites']['push']({'path':_0x2afc2f,'snap':_0x38fc3d,'writeId':_0x1bfa8d,'visible':_0x33599a}),_0x33599a&&(_0x351006['visibleWrites']=Ct(_0x351006['visibleWrites'],_0x2afc2f,_0x38fc3d)),_0x351006['lastWriteId']=_0x1bfa8d;}function au(_0x5367a9,_0x331232,_0x4b5c23,_0x4b78f0){f(_0x4b78f0>_0x5367a9['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5367a9['allWrites']['push']({'path':_0x331232,'children':_0x4b5c23,'writeId':_0x4b78f0,'visible':!0x0}),_0x5367a9['visibleWrites']=Ii(_0x5367a9['visibleWrites'],_0x331232,_0x4b5c23),_0x5367a9['lastWriteId']=_0x4b78f0;}function cu(_0x35162c,_0x1aa633){for(let _0x1ac352=0x0;_0x1ac352<_0x35162c['allWrites']['length'];_0x1ac352++){const _0x50bacd=_0x35162c['allWrites'][_0x1ac352];if(_0x50bacd['writeId']===_0x1aa633)return _0x50bacd;}return null;}function lu(_0x4f43f7,_0xa714af){const _0x150008=_0x4f43f7['allWrites']['findIndex'](_0x290a32=>_0x290a32['writeId']===_0xa714af);f(_0x150008>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x15fdb8=_0x4f43f7['allWrites'][_0x150008];_0x4f43f7['allWrites']['splice'](_0x150008,0x1);let _0x53b00e=_0x15fdb8['visible'],_0x45c60a=!0x1,_0x18da0b=_0x4f43f7['allWrites']['length']-0x1;for(;_0x53b00e&&_0x18da0b>=0x0;){const _0x7c4ba=_0x4f43f7['allWrites'][_0x18da0b];_0x7c4ba['visible']&&(_0x18da0b>=_0x150008&&hu(_0x7c4ba,_0x15fdb8['path'])?_0x53b00e=!0x1:$(_0x15fdb8['path'],_0x7c4ba['path'])&&(_0x45c60a=!0x0)),_0x18da0b--;}if(_0x53b00e){if(_0x45c60a)return uu(_0x4f43f7),!0x0;if(_0x15fdb8['snap'])_0x4f43f7['visibleWrites']=sr(_0x4f43f7['visibleWrites'],_0x15fdb8['path']);else{const _0x415fe9=_0x15fdb8['children'];x(_0x415fe9,_0x558482=>{_0x4f43f7['visibleWrites']=sr(_0x4f43f7['visibleWrites'],A(_0x15fdb8['path'],_0x558482));});}return!0x0;}else return!0x1;}function hu(_0x20a81d,_0x1eee5a){if(_0x20a81d['snap'])return $(_0x20a81d['path'],_0x1eee5a);for(const _0x1ccd25 in _0x20a81d['children'])if(_0x20a81d['children']['hasOwnProperty'](_0x1ccd25)&&$(A(_0x20a81d['path'],_0x1ccd25),_0x1eee5a))return!0x0;return!0x1;}function uu(_0x2ead93){_0x2ead93['visibleWrites']=Fo(_0x2ead93['allWrites'],du,w()),_0x2ead93['allWrites']['length']>0x0?_0x2ead93['lastWriteId']=_0x2ead93['allWrites'][_0x2ead93['allWrites']['length']-0x1]['writeId']:_0x2ead93['lastWriteId']=-0x1;}function du(_0x3a2e70){return _0x3a2e70['visible'];}function Fo(_0x267596,_0x1243e8,_0x45cb29){let _0x355495=j['empty']();for(let _0x5954c9=0x0;_0x5954c9<_0x267596['length'];++_0x5954c9){const _0x5cba1f=_0x267596[_0x5954c9];if(_0x1243e8(_0x5cba1f)){const _0x58a5eb=_0x5cba1f['path'];let _0x12f3a1;if(_0x5cba1f['snap'])$(_0x45cb29,_0x58a5eb)?(_0x12f3a1=F(_0x45cb29,_0x58a5eb),_0x355495=Ct(_0x355495,_0x12f3a1,_0x5cba1f['snap'])):$(_0x58a5eb,_0x45cb29)&&(_0x12f3a1=F(_0x58a5eb,_0x45cb29),_0x355495=Ct(_0x355495,w(),_0x5cba1f['snap']['getChild'](_0x12f3a1)));else{if(_0x5cba1f['children']){if($(_0x45cb29,_0x58a5eb))_0x12f3a1=F(_0x45cb29,_0x58a5eb),_0x355495=Ii(_0x355495,_0x12f3a1,_0x5cba1f['children']);else{if($(_0x58a5eb,_0x45cb29)){if(_0x12f3a1=F(_0x58a5eb,_0x45cb29),v(_0x12f3a1))_0x355495=Ii(_0x355495,w(),_0x5cba1f['children']);else{const _0x562760=Oe(_0x5cba1f['children'],y(_0x12f3a1));if(_0x562760){const _0x5c4ea4=_0x562760['getChild'](b(_0x12f3a1));_0x355495=Ct(_0x355495,w(),_0x5c4ea4);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x355495;}function Uo(_0x38f8da,_0xd43d0f,_0x30655d,_0x42212c,_0x3ef8ae){if(!_0x42212c&&!_0x3ef8ae){const _0x13a6d1=$e(_0x38f8da['visibleWrites'],_0xd43d0f);if(_0x13a6d1!=null)return _0x13a6d1;{const _0x3e4429=ve(_0x38f8da['visibleWrites'],_0xd43d0f);if(Ci(_0x3e4429))return _0x30655d;if(_0x30655d==null&&!wi(_0x3e4429,w()))return null;{const _0x4722b9=_0x30655d||g['EMPTY_NODE'];return it(_0x3e4429,_0x4722b9);}}}else{const _0x2013a6=ve(_0x38f8da['visibleWrites'],_0xd43d0f);if(!_0x3ef8ae&&Ci(_0x2013a6))return _0x30655d;if(!_0x3ef8ae&&_0x30655d==null&&!wi(_0x2013a6,w()))return null;{const _0x652f8b=function(_0x208038){return(_0x208038['visible']||_0x3ef8ae)&&(!_0x42212c||!~_0x42212c['indexOf'](_0x208038['writeId']))&&($(_0x208038['path'],_0xd43d0f)||$(_0xd43d0f,_0x208038['path']));},_0x10213f=Fo(_0x38f8da['allWrites'],_0x652f8b,_0xd43d0f),_0x2b6b25=_0x30655d||g['EMPTY_NODE'];return it(_0x10213f,_0x2b6b25);}}}function fu(_0x317cdb,_0x2596e0,_0x446ea1){let _0x197468=g['EMPTY_NODE'];const _0x103c15=$e(_0x317cdb['visibleWrites'],_0x2596e0);if(_0x103c15)return _0x103c15['isLeafNode']()||_0x103c15['forEachChild'](R,(_0xcfc6b8,_0x389e5e)=>{_0x197468=_0x197468['updateImmediateChild'](_0xcfc6b8,_0x389e5e);}),_0x197468;if(_0x446ea1){const _0x20fdcc=ve(_0x317cdb['visibleWrites'],_0x2596e0);return _0x446ea1['forEachChild'](R,(_0xfe7e19,_0x16dd0f)=>{const _0x5da610=it(ve(_0x20fdcc,new C(_0xfe7e19)),_0x16dd0f);_0x197468=_0x197468['updateImmediateChild'](_0xfe7e19,_0x5da610);}),rr(_0x20fdcc)['forEach'](_0x3dadc0=>{_0x197468=_0x197468['updateImmediateChild'](_0x3dadc0['name'],_0x3dadc0['node']);}),_0x197468;}else{const _0x4cf80d=ve(_0x317cdb['visibleWrites'],_0x2596e0);return rr(_0x4cf80d)['forEach'](_0x339569=>{_0x197468=_0x197468['updateImmediateChild'](_0x339569['name'],_0x339569['node']);}),_0x197468;}}function pu(_0x5efe57,_0x113a3d,_0x5853b6,_0x214f85,_0x4853d4){f(_0x214f85||_0x4853d4,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x78acc3=A(_0x113a3d,_0x5853b6);if(wi(_0x5efe57['visibleWrites'],_0x78acc3))return null;{const _0x29456b=ve(_0x5efe57['visibleWrites'],_0x78acc3);return Ci(_0x29456b)?_0x4853d4['getChild'](_0x5853b6):it(_0x29456b,_0x4853d4['getChild'](_0x5853b6));}}function _u(_0x242beb,_0x53fe83,_0x1ef57e,_0x604e21){const _0x51e2dc=A(_0x53fe83,_0x1ef57e),_0x20b1e1=$e(_0x242beb['visibleWrites'],_0x51e2dc);if(_0x20b1e1!=null)return _0x20b1e1;if(_0x604e21['isCompleteForChild'](_0x1ef57e)){const _0x4cf9d9=ve(_0x242beb['visibleWrites'],_0x51e2dc);return it(_0x4cf9d9,_0x604e21['getNode']()['getImmediateChild'](_0x1ef57e));}else return null;}function gu(_0x122658,_0x5d1c6b){return $e(_0x122658['visibleWrites'],_0x5d1c6b);}function mu(_0x236f54,_0x3fbf90,_0x49af82,_0x4a46b5,_0x3f7ee1,_0x4b1830,_0x13b13c){let _0x3cfbd2;const _0x522f27=ve(_0x236f54['visibleWrites'],_0x3fbf90),_0x259461=$e(_0x522f27,w());if(_0x259461!=null)_0x3cfbd2=_0x259461;else{if(_0x49af82!=null)_0x3cfbd2=it(_0x522f27,_0x49af82);else return[];}if(_0x3cfbd2=_0x3cfbd2['withIndex'](_0x13b13c),!_0x3cfbd2['isEmpty']()&&!_0x3cfbd2['isLeafNode']()){const _0x564b23=[],_0x52c1c6=_0x13b13c['getCompare'](),_0xfe31e6=_0x4b1830?_0x3cfbd2['getReverseIteratorFrom'](_0x4a46b5,_0x13b13c):_0x3cfbd2['getIteratorFrom'](_0x4a46b5,_0x13b13c);let _0x53c349=_0xfe31e6['getNext']();for(;_0x53c349&&_0x564b23['length']<_0x3f7ee1;)_0x52c1c6(_0x53c349,_0x4a46b5)!==0x0&&_0x564b23['push'](_0x53c349),_0x53c349=_0xfe31e6['getNext']();return _0x564b23;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x4fb4f6,_0x425648,_0xad7dd9,_0x184ee8){return Uo(_0x4fb4f6['writeTree'],_0x4fb4f6['treePath'],_0x425648,_0xad7dd9,_0x184ee8);}function es(_0x22888c,_0x4174d2){return fu(_0x22888c['writeTree'],_0x22888c['treePath'],_0x4174d2);}function or(_0x35966f,_0x51d743,_0x50a31f,_0x4e1316){return pu(_0x35966f['writeTree'],_0x35966f['treePath'],_0x51d743,_0x50a31f,_0x4e1316);}function yn(_0xf6e1c0,_0x269652){return gu(_0xf6e1c0['writeTree'],A(_0xf6e1c0['treePath'],_0x269652));}function vu(_0x214f7b,_0x41a6c7,_0x3d55ce,_0x127eba,_0x29e72b,_0x151e33){return mu(_0x214f7b['writeTree'],_0x214f7b['treePath'],_0x41a6c7,_0x3d55ce,_0x127eba,_0x29e72b,_0x151e33);}function ts(_0x34bee0,_0x1241c9,_0x5584dc){return _u(_0x34bee0['writeTree'],_0x34bee0['treePath'],_0x1241c9,_0x5584dc);}function Wo(_0x53ab70,_0x1a87e5){return Bo(A(_0x53ab70['treePath'],_0x1a87e5),_0x53ab70['writeTree']);}function Bo(_0x2676c0,_0x31c867){return{'treePath':_0x2676c0,'writeTree':_0x31c867};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x7852e3){const _0x53f492=_0x7852e3['type'],_0x1c2ae4=_0x7852e3['childName'];f(_0x53f492==='child_added'||_0x53f492==='child_changed'||_0x53f492==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1c2ae4!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0xf5d7e1=this['changeMap']['get'](_0x1c2ae4);if(_0xf5d7e1){const _0x41db7f=_0xf5d7e1['type'];if(_0x53f492==='child_added'&&_0x41db7f==='child_removed')this['changeMap']['set'](_0x1c2ae4,Pt(_0x1c2ae4,_0x7852e3['snapshotNode'],_0xf5d7e1['snapshotNode']));else{if(_0x53f492==='child_removed'&&_0x41db7f==='child_added')this['changeMap']['delete'](_0x1c2ae4);else{if(_0x53f492==='child_removed'&&_0x41db7f==='child_changed')this['changeMap']['set'](_0x1c2ae4,Nt(_0x1c2ae4,_0xf5d7e1['oldSnap']));else{if(_0x53f492==='child_changed'&&_0x41db7f==='child_added')this['changeMap']['set'](_0x1c2ae4,tt(_0x1c2ae4,_0x7852e3['snapshotNode']));else{if(_0x53f492==='child_changed'&&_0x41db7f==='child_changed')this['changeMap']['set'](_0x1c2ae4,Pt(_0x1c2ae4,_0x7852e3['snapshotNode'],_0xf5d7e1['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x7852e3+'\x20occurred\x20after\x20'+_0xf5d7e1);}}}}}else this['changeMap']['set'](_0x1c2ae4,_0x7852e3);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x18c2a5){return null;}['getChildAfterChild'](_0x57def2,_0x41b185,_0x1e8fd9){return null;}}const Vo=new Iu();class ns{constructor(_0xfd935c,_0x208504,_0x2b4565=null){this['writes_']=_0xfd935c,this['viewCache_']=_0x208504,this['optCompleteServerCache_']=_0x2b4565;}['getCompleteChild'](_0x3fb027){const _0x350210=this['viewCache_']['eventCache'];if(_0x350210['isCompleteForChild'](_0x3fb027))return _0x350210['getNode']()['getImmediateChild'](_0x3fb027);{const _0x5e9dfe=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x3fb027,_0x5e9dfe);}}['getChildAfterChild'](_0x505b5c,_0xd1bdae,_0x17fa1f){const _0x23e163=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x39f8d1=vu(this['writes_'],_0x23e163,_0xd1bdae,0x1,_0x17fa1f,_0x505b5c);return _0x39f8d1['length']===0x0?null:_0x39f8d1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3eb0cd){return{'filter':_0x3eb0cd};}function Cu(_0x413251,_0x29f293){f(_0x29f293['eventCache']['getNode']()['isIndexed'](_0x413251['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x29f293['serverCache']['getNode']()['isIndexed'](_0x413251['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0xf4d2d0,_0x6864b6,_0x525410,_0x3d00c9,_0x59d39c){const _0x520885=new Eu();let _0x55d017,_0x1dd350;if(_0x525410['type']===q['OVERWRITE']){const _0x239d4d=_0x525410;_0x239d4d['source']['fromUser']?_0x55d017=Ti(_0xf4d2d0,_0x6864b6,_0x239d4d['path'],_0x239d4d['snap'],_0x3d00c9,_0x59d39c,_0x520885):(f(_0x239d4d['source']['fromServer'],'Unknown\x20source.'),_0x1dd350=_0x239d4d['source']['tagged']||_0x6864b6['serverCache']['isFiltered']()&&!v(_0x239d4d['path']),_0x55d017=vn(_0xf4d2d0,_0x6864b6,_0x239d4d['path'],_0x239d4d['snap'],_0x3d00c9,_0x59d39c,_0x1dd350,_0x520885));}else{if(_0x525410['type']===q['MERGE']){const _0x15e76a=_0x525410;_0x15e76a['source']['fromUser']?_0x55d017=bu(_0xf4d2d0,_0x6864b6,_0x15e76a['path'],_0x15e76a['children'],_0x3d00c9,_0x59d39c,_0x520885):(f(_0x15e76a['source']['fromServer'],'Unknown\x20source.'),_0x1dd350=_0x15e76a['source']['tagged']||_0x6864b6['serverCache']['isFiltered'](),_0x55d017=Si(_0xf4d2d0,_0x6864b6,_0x15e76a['path'],_0x15e76a['children'],_0x3d00c9,_0x59d39c,_0x1dd350,_0x520885));}else{if(_0x525410['type']===q['ACK_USER_WRITE']){const _0x193ebd=_0x525410;_0x193ebd['revert']?_0x55d017=ku(_0xf4d2d0,_0x6864b6,_0x193ebd['path'],_0x3d00c9,_0x59d39c,_0x520885):_0x55d017=Ru(_0xf4d2d0,_0x6864b6,_0x193ebd['path'],_0x193ebd['affectedTree'],_0x3d00c9,_0x59d39c,_0x520885);}else{if(_0x525410['type']===q['LISTEN_COMPLETE'])_0x55d017=Au(_0xf4d2d0,_0x6864b6,_0x525410['path'],_0x3d00c9,_0x520885);else throw ot('Unknown\x20operation\x20type:\x20'+_0x525410['type']);}}}const _0x538754=_0x520885['getChanges']();return Su(_0x6864b6,_0x55d017,_0x538754),{'viewCache':_0x55d017,'changes':_0x538754};}function Su(_0x27ef7c,_0x5a9699,_0x28e075){const _0x3fc39c=_0x5a9699['eventCache'];if(_0x3fc39c['isFullyInitialized']()){const _0x51645f=_0x3fc39c['getNode']()['isLeafNode']()||_0x3fc39c['getNode']()['isEmpty'](),_0x3f9d7b=gn(_0x27ef7c);(_0x28e075['length']>0x0||!_0x27ef7c['eventCache']['isFullyInitialized']()||_0x51645f&&!_0x3fc39c['getNode']()['equals'](_0x3f9d7b)||!_0x3fc39c['getNode']()['getPriority']()['equals'](_0x3f9d7b['getPriority']()))&&_0x28e075['push'](Oo(gn(_0x5a9699)));}}function Ho(_0x379b58,_0x222985,_0x528058,_0x3c8e24,_0x5294be,_0x4f23bd){const _0x51149b=_0x222985['eventCache'];if(yn(_0x3c8e24,_0x528058)!=null)return _0x222985;{let _0x594760,_0x4e4009;if(v(_0x528058)){if(f(_0x222985['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x222985['serverCache']['isFiltered']()){const _0x377dda=Ue(_0x222985),_0x35ee88=_0x377dda instanceof g?_0x377dda:g['EMPTY_NODE'],_0x561101=es(_0x3c8e24,_0x35ee88);_0x594760=_0x379b58['filter']['updateFullNode'](_0x222985['eventCache']['getNode'](),_0x561101,_0x4f23bd);}else{const _0x25a4fd=mn(_0x3c8e24,Ue(_0x222985));_0x594760=_0x379b58['filter']['updateFullNode'](_0x222985['eventCache']['getNode'](),_0x25a4fd,_0x4f23bd);}}else{const _0x5ba0fb=y(_0x528058);if(_0x5ba0fb==='.priority'){f(we(_0x528058)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1e07c9=_0x51149b['getNode']();_0x4e4009=_0x222985['serverCache']['getNode']();const _0x512f2e=or(_0x3c8e24,_0x528058,_0x1e07c9,_0x4e4009);_0x512f2e!=null?_0x594760=_0x379b58['filter']['updatePriority'](_0x1e07c9,_0x512f2e):_0x594760=_0x51149b['getNode']();}else{const _0x15cc71=b(_0x528058);let _0x5034f9;if(_0x51149b['isCompleteForChild'](_0x5ba0fb)){_0x4e4009=_0x222985['serverCache']['getNode']();const _0x2e7f00=or(_0x3c8e24,_0x528058,_0x51149b['getNode'](),_0x4e4009);_0x2e7f00!=null?_0x5034f9=_0x51149b['getNode']()['getImmediateChild'](_0x5ba0fb)['updateChild'](_0x15cc71,_0x2e7f00):_0x5034f9=_0x51149b['getNode']()['getImmediateChild'](_0x5ba0fb);}else _0x5034f9=ts(_0x3c8e24,_0x5ba0fb,_0x222985['serverCache']);_0x5034f9!=null?_0x594760=_0x379b58['filter']['updateChild'](_0x51149b['getNode'](),_0x5ba0fb,_0x5034f9,_0x15cc71,_0x5294be,_0x4f23bd):_0x594760=_0x51149b['getNode']();}}return wt(_0x222985,_0x594760,_0x51149b['isFullyInitialized']()||v(_0x528058),_0x379b58['filter']['filtersNodes']());}}function vn(_0x3d6916,_0x35a471,_0x1cd0e3,_0x3f3d0a,_0x435725,_0x4a8baa,_0x34089a,_0x4ec65f){const _0x2ed6be=_0x35a471['serverCache'];let _0x42bb06;const _0x1277c0=_0x34089a?_0x3d6916['filter']:_0x3d6916['filter']['getIndexedFilter']();if(v(_0x1cd0e3))_0x42bb06=_0x1277c0['updateFullNode'](_0x2ed6be['getNode'](),_0x3f3d0a,null);else{if(_0x1277c0['filtersNodes']()&&!_0x2ed6be['isFiltered']()){const _0x4cb45b=_0x2ed6be['getNode']()['updateChild'](_0x1cd0e3,_0x3f3d0a);_0x42bb06=_0x1277c0['updateFullNode'](_0x2ed6be['getNode'](),_0x4cb45b,null);}else{const _0x35f9a8=y(_0x1cd0e3);if(!_0x2ed6be['isCompleteForPath'](_0x1cd0e3)&&we(_0x1cd0e3)>0x1)return _0x35a471;const _0x2d01cb=b(_0x1cd0e3),_0x19e879=_0x2ed6be['getNode']()['getImmediateChild'](_0x35f9a8)['updateChild'](_0x2d01cb,_0x3f3d0a);_0x35f9a8==='.priority'?_0x42bb06=_0x1277c0['updatePriority'](_0x2ed6be['getNode'](),_0x19e879):_0x42bb06=_0x1277c0['updateChild'](_0x2ed6be['getNode'](),_0x35f9a8,_0x19e879,_0x2d01cb,Vo,null);}}const _0x413a31=Lo(_0x35a471,_0x42bb06,_0x2ed6be['isFullyInitialized']()||v(_0x1cd0e3),_0x1277c0['filtersNodes']()),_0x120c6b=new ns(_0x435725,_0x413a31,_0x4a8baa);return Ho(_0x3d6916,_0x413a31,_0x1cd0e3,_0x435725,_0x120c6b,_0x4ec65f);}function Ti(_0x513f73,_0x50855c,_0x39b5c2,_0xeed8e4,_0x3d12c1,_0x43c59d,_0xb5a3c9){const _0x31a049=_0x50855c['eventCache'];let _0x5ad724,_0x303fbe;const _0x48bed6=new ns(_0x3d12c1,_0x50855c,_0x43c59d);if(v(_0x39b5c2))_0x303fbe=_0x513f73['filter']['updateFullNode'](_0x50855c['eventCache']['getNode'](),_0xeed8e4,_0xb5a3c9),_0x5ad724=wt(_0x50855c,_0x303fbe,!0x0,_0x513f73['filter']['filtersNodes']());else{const _0x5371c0=y(_0x39b5c2);if(_0x5371c0==='.priority')_0x303fbe=_0x513f73['filter']['updatePriority'](_0x50855c['eventCache']['getNode'](),_0xeed8e4),_0x5ad724=wt(_0x50855c,_0x303fbe,_0x31a049['isFullyInitialized'](),_0x31a049['isFiltered']());else{const _0x1ad998=b(_0x39b5c2),_0x1de373=_0x31a049['getNode']()['getImmediateChild'](_0x5371c0);let _0x1b6958;if(v(_0x1ad998))_0x1b6958=_0xeed8e4;else{const _0x2463d8=_0x48bed6['getCompleteChild'](_0x5371c0);_0x2463d8!=null?Gi(_0x1ad998)==='.priority'&&_0x2463d8['getChild'](To(_0x1ad998))['isEmpty']()?_0x1b6958=_0x2463d8:_0x1b6958=_0x2463d8['updateChild'](_0x1ad998,_0xeed8e4):_0x1b6958=g['EMPTY_NODE'];}if(_0x1de373['equals'](_0x1b6958))_0x5ad724=_0x50855c;else{const _0x5f12de=_0x513f73['filter']['updateChild'](_0x31a049['getNode'](),_0x5371c0,_0x1b6958,_0x1ad998,_0x48bed6,_0xb5a3c9);_0x5ad724=wt(_0x50855c,_0x5f12de,_0x31a049['isFullyInitialized'](),_0x513f73['filter']['filtersNodes']());}}}return _0x5ad724;}function ar(_0x1debda,_0x14f53e){return _0x1debda['eventCache']['isCompleteForChild'](_0x14f53e);}function bu(_0xd478a4,_0x204aa9,_0x59afd5,_0x3fc951,_0xd6bdf7,_0x85f75c,_0x466096){let _0x54caf0=_0x204aa9;return _0x3fc951['foreach']((_0xafade8,_0x555106)=>{const _0x35b220=A(_0x59afd5,_0xafade8);ar(_0x204aa9,y(_0x35b220))&&(_0x54caf0=Ti(_0xd478a4,_0x54caf0,_0x35b220,_0x555106,_0xd6bdf7,_0x85f75c,_0x466096));}),_0x3fc951['foreach']((_0xe1c8c7,_0x118167)=>{const _0x4da943=A(_0x59afd5,_0xe1c8c7);ar(_0x204aa9,y(_0x4da943))||(_0x54caf0=Ti(_0xd478a4,_0x54caf0,_0x4da943,_0x118167,_0xd6bdf7,_0x85f75c,_0x466096));}),_0x54caf0;}function cr(_0x5e0008,_0x102aab,_0x1ab1eb){return _0x1ab1eb['foreach']((_0x2ad89f,_0x261329)=>{_0x102aab=_0x102aab['updateChild'](_0x2ad89f,_0x261329);}),_0x102aab;}function Si(_0x474a3a,_0x3a5faa,_0xe79b1f,_0x554981,_0x1f95b1,_0x4fcaeb,_0x5c5723,_0xed40e0){if(_0x3a5faa['serverCache']['getNode']()['isEmpty']()&&!_0x3a5faa['serverCache']['isFullyInitialized']())return _0x3a5faa;let _0x28c477=_0x3a5faa,_0x6859c1;v(_0xe79b1f)?_0x6859c1=_0x554981:_0x6859c1=new S(null)['setTree'](_0xe79b1f,_0x554981);const _0x213294=_0x3a5faa['serverCache']['getNode']();return _0x6859c1['children']['inorderTraversal']((_0x242d7d,_0x5f0386)=>{if(_0x213294['hasChild'](_0x242d7d)){const _0x51ce3e=_0x3a5faa['serverCache']['getNode']()['getImmediateChild'](_0x242d7d),_0x372a75=cr(_0x474a3a,_0x51ce3e,_0x5f0386);_0x28c477=vn(_0x474a3a,_0x28c477,new C(_0x242d7d),_0x372a75,_0x1f95b1,_0x4fcaeb,_0x5c5723,_0xed40e0);}}),_0x6859c1['children']['inorderTraversal']((_0x191726,_0xe25d8f)=>{const _0x4a7402=!_0x3a5faa['serverCache']['isCompleteForChild'](_0x191726)&&_0xe25d8f['value']===null;if(!_0x213294['hasChild'](_0x191726)&&!_0x4a7402){const _0x4a7d93=_0x3a5faa['serverCache']['getNode']()['getImmediateChild'](_0x191726),_0x2f7dcd=cr(_0x474a3a,_0x4a7d93,_0xe25d8f);_0x28c477=vn(_0x474a3a,_0x28c477,new C(_0x191726),_0x2f7dcd,_0x1f95b1,_0x4fcaeb,_0x5c5723,_0xed40e0);}}),_0x28c477;}function Ru(_0x1416fa,_0x4e8292,_0x439cae,_0x4ff00d,_0x2fff13,_0xce12ce,_0x882712){if(yn(_0x2fff13,_0x439cae)!=null)return _0x4e8292;const _0x26e546=_0x4e8292['serverCache']['isFiltered'](),_0x48d5a2=_0x4e8292['serverCache'];if(_0x4ff00d['value']!=null){if(v(_0x439cae)&&_0x48d5a2['isFullyInitialized']()||_0x48d5a2['isCompleteForPath'](_0x439cae))return vn(_0x1416fa,_0x4e8292,_0x439cae,_0x48d5a2['getNode']()['getChild'](_0x439cae),_0x2fff13,_0xce12ce,_0x26e546,_0x882712);if(v(_0x439cae)){let _0x3ba10e=new S(null);return _0x48d5a2['getNode']()['forEachChild'](ye,(_0x4c3b3a,_0x14a377)=>{_0x3ba10e=_0x3ba10e['set'](new C(_0x4c3b3a),_0x14a377);}),Si(_0x1416fa,_0x4e8292,_0x439cae,_0x3ba10e,_0x2fff13,_0xce12ce,_0x26e546,_0x882712);}else return _0x4e8292;}else{let _0x4dd464=new S(null);return _0x4ff00d['foreach']((_0x39bfb0,_0x2a1a85)=>{const _0x278249=A(_0x439cae,_0x39bfb0);_0x48d5a2['isCompleteForPath'](_0x278249)&&(_0x4dd464=_0x4dd464['set'](_0x39bfb0,_0x48d5a2['getNode']()['getChild'](_0x278249)));}),Si(_0x1416fa,_0x4e8292,_0x439cae,_0x4dd464,_0x2fff13,_0xce12ce,_0x26e546,_0x882712);}}function Au(_0x586257,_0x44200e,_0x520cf4,_0x3e0d96,_0x90233b){const _0x1e9ce7=_0x44200e['serverCache'],_0x51f7f9=Lo(_0x44200e,_0x1e9ce7['getNode'](),_0x1e9ce7['isFullyInitialized']()||v(_0x520cf4),_0x1e9ce7['isFiltered']());return Ho(_0x586257,_0x51f7f9,_0x520cf4,_0x3e0d96,Vo,_0x90233b);}function ku(_0x4cd193,_0x548d39,_0x45e264,_0x3fa3ed,_0x47d1b3,_0xd62e68){let _0xe563d1;if(yn(_0x3fa3ed,_0x45e264)!=null)return _0x548d39;{const _0x20b536=new ns(_0x3fa3ed,_0x548d39,_0x47d1b3),_0x4b4902=_0x548d39['eventCache']['getNode']();let _0x3574d1;if(v(_0x45e264)||y(_0x45e264)==='.priority'){let _0x2b6a88;if(_0x548d39['serverCache']['isFullyInitialized']())_0x2b6a88=mn(_0x3fa3ed,Ue(_0x548d39));else{const _0x1677d7=_0x548d39['serverCache']['getNode']();f(_0x1677d7 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2b6a88=es(_0x3fa3ed,_0x1677d7);}_0x2b6a88=_0x2b6a88,_0x3574d1=_0x4cd193['filter']['updateFullNode'](_0x4b4902,_0x2b6a88,_0xd62e68);}else{const _0x441a9f=y(_0x45e264);let _0x3abc00=ts(_0x3fa3ed,_0x441a9f,_0x548d39['serverCache']);_0x3abc00==null&&_0x548d39['serverCache']['isCompleteForChild'](_0x441a9f)&&(_0x3abc00=_0x4b4902['getImmediateChild'](_0x441a9f)),_0x3abc00!=null?_0x3574d1=_0x4cd193['filter']['updateChild'](_0x4b4902,_0x441a9f,_0x3abc00,b(_0x45e264),_0x20b536,_0xd62e68):_0x548d39['eventCache']['getNode']()['hasChild'](_0x441a9f)?_0x3574d1=_0x4cd193['filter']['updateChild'](_0x4b4902,_0x441a9f,g['EMPTY_NODE'],b(_0x45e264),_0x20b536,_0xd62e68):_0x3574d1=_0x4b4902,_0x3574d1['isEmpty']()&&_0x548d39['serverCache']['isFullyInitialized']()&&(_0xe563d1=mn(_0x3fa3ed,Ue(_0x548d39)),_0xe563d1['isLeafNode']()&&(_0x3574d1=_0x4cd193['filter']['updateFullNode'](_0x3574d1,_0xe563d1,_0xd62e68)));}return _0xe563d1=_0x548d39['serverCache']['isFullyInitialized']()||yn(_0x3fa3ed,w())!=null,wt(_0x548d39,_0x3574d1,_0xe563d1,_0x4cd193['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x292cdb,_0x52ccc9){this['query_']=_0x292cdb,this['eventRegistrations_']=[];const _0x101497=this['query_']['_queryParams'],_0x10f241=new Yi(_0x101497['getIndex']()),_0x42d2aa=qh(_0x101497);this['processor_']=wu(_0x42d2aa);const _0x4a8039=_0x52ccc9['serverCache'],_0x3f0c02=_0x52ccc9['eventCache'],_0x1d2774=_0x10f241['updateFullNode'](g['EMPTY_NODE'],_0x4a8039['getNode'](),null),_0x38f569=_0x42d2aa['updateFullNode'](g['EMPTY_NODE'],_0x3f0c02['getNode'](),null),_0x425746=new Ce(_0x1d2774,_0x4a8039['isFullyInitialized'](),_0x10f241['filtersNodes']()),_0x5b8a7f=new Ce(_0x38f569,_0x3f0c02['isFullyInitialized'](),_0x42d2aa['filtersNodes']());this['viewCache_']=Dn(_0x5b8a7f,_0x425746),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4d84ed){return _0x4d84ed['viewCache_']['serverCache']['getNode']();}function Ou(_0x2e13d1){return gn(_0x2e13d1['viewCache_']);}function Du(_0x4ed865,_0x7c5684){const _0x38c58f=Ue(_0x4ed865['viewCache_']);return _0x38c58f&&(_0x4ed865['query']['_queryParams']['loadsAllData']()||!v(_0x7c5684)&&!_0x38c58f['getImmediateChild'](y(_0x7c5684))['isEmpty']())?_0x38c58f['getChild'](_0x7c5684):null;}function lr(_0x5ed141){return _0x5ed141['eventRegistrations_']['length']===0x0;}function Mu(_0x56fccf,_0x949c19){_0x56fccf['eventRegistrations_']['push'](_0x949c19);}function hr(_0x5e4d4d,_0x342d3e,_0x119c5d){const _0x4d9803=[];if(_0x119c5d){f(_0x342d3e==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x908479=_0x5e4d4d['query']['_path'];_0x5e4d4d['eventRegistrations_']['forEach'](_0x1f6d1d=>{const _0x120caf=_0x1f6d1d['createCancelEvent'](_0x119c5d,_0x908479);_0x120caf&&_0x4d9803['push'](_0x120caf);});}if(_0x342d3e){let _0x2c3b49=[];for(let _0x5edf33=0x0;_0x5edf33<_0x5e4d4d['eventRegistrations_']['length'];++_0x5edf33){const _0xdb6ee8=_0x5e4d4d['eventRegistrations_'][_0x5edf33];if(!_0xdb6ee8['matches'](_0x342d3e))_0x2c3b49['push'](_0xdb6ee8);else{if(_0x342d3e['hasAnyCallback']()){_0x2c3b49=_0x2c3b49['concat'](_0x5e4d4d['eventRegistrations_']['slice'](_0x5edf33+0x1));break;}}}_0x5e4d4d['eventRegistrations_']=_0x2c3b49;}else _0x5e4d4d['eventRegistrations_']=[];return _0x4d9803;}function ur(_0x352428,_0x57ba85,_0x23c403,_0xa9a729){_0x57ba85['type']===q['MERGE']&&_0x57ba85['source']['queryId']!==null&&(f(Ue(_0x352428['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x352428['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3ecda6=_0x352428['viewCache_'],_0x4a2389=Tu(_0x352428['processor_'],_0x3ecda6,_0x57ba85,_0x23c403,_0xa9a729);return Cu(_0x352428['processor_'],_0x4a2389['viewCache']),f(_0x4a2389['viewCache']['serverCache']['isFullyInitialized']()||!_0x3ecda6['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x352428['viewCache_']=_0x4a2389['viewCache'],$o(_0x352428,_0x4a2389['changes'],_0x4a2389['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x47bb53,_0x40a2fb){const _0x2c8cf5=_0x47bb53['viewCache_']['eventCache'],_0x451aef=[];return _0x2c8cf5['getNode']()['isLeafNode']()||_0x2c8cf5['getNode']()['forEachChild'](R,(_0x12c310,_0x543c52)=>{_0x451aef['push'](tt(_0x12c310,_0x543c52));}),_0x2c8cf5['isFullyInitialized']()&&_0x451aef['push'](Oo(_0x2c8cf5['getNode']())),$o(_0x47bb53,_0x451aef,_0x2c8cf5['getNode'](),_0x40a2fb);}function $o(_0x2a79f4,_0x4ccb6f,_0x8fec8b,_0x44d7f7){const _0x4dd201=_0x44d7f7?[_0x44d7f7]:_0x2a79f4['eventRegistrations_'];return nu(_0x2a79f4['eventGenerator_'],_0x4ccb6f,_0x8fec8b,_0x4dd201);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x4ff7e6){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x4ff7e6;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x41cde1){return _0x41cde1['views']['size']===0x0;}function is(_0x59e0fe,_0x2f2e4f,_0x20bf1b,_0x542cb6){const _0x3e18ea=_0x2f2e4f['source']['queryId'];if(_0x3e18ea!==null){const _0x3a6f36=_0x59e0fe['views']['get'](_0x3e18ea);return f(_0x3a6f36!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x3a6f36,_0x2f2e4f,_0x20bf1b,_0x542cb6);}else{let _0x5838ab=[];for(const _0x12758b of _0x59e0fe['views']['values']())_0x5838ab=_0x5838ab['concat'](ur(_0x12758b,_0x2f2e4f,_0x20bf1b,_0x542cb6));return _0x5838ab;}}function qo(_0x4b4ae4,_0x104bdf,_0x12c49a,_0xa6e988,_0x26dc2f){const _0x975449=_0x104bdf['_queryIdentifier'],_0x4fc0c5=_0x4b4ae4['views']['get'](_0x975449);if(!_0x4fc0c5){let _0x57a5f2=mn(_0x12c49a,_0x26dc2f?_0xa6e988:null),_0x18d1db=!0x1;_0x57a5f2?_0x18d1db=!0x0:_0xa6e988 instanceof g?(_0x57a5f2=es(_0x12c49a,_0xa6e988),_0x18d1db=!0x1):(_0x57a5f2=g['EMPTY_NODE'],_0x18d1db=!0x1);const _0xfdc474=Dn(new Ce(_0x57a5f2,_0x18d1db,!0x1),new Ce(_0xa6e988,_0x26dc2f,!0x1));return new Nu(_0x104bdf,_0xfdc474);}return _0x4fc0c5;}function Wu(_0x54b0b7,_0x5ac311,_0x3ee2f5,_0x41006c,_0x404620,_0x246fbf){const _0xfe2e2c=qo(_0x54b0b7,_0x5ac311,_0x41006c,_0x404620,_0x246fbf);return _0x54b0b7['views']['has'](_0x5ac311['_queryIdentifier'])||_0x54b0b7['views']['set'](_0x5ac311['_queryIdentifier'],_0xfe2e2c),Mu(_0xfe2e2c,_0x3ee2f5),Lu(_0xfe2e2c,_0x3ee2f5);}function Bu(_0x322559,_0x26a342,_0x417ac7,_0x414357){const _0x508015=_0x26a342['_queryIdentifier'],_0x47f5c9=[];let _0x230723=[];const _0x94ed73=Te(_0x322559);if(_0x508015==='default'){for(const [_0x29c6cf,_0x132e5a]of _0x322559['views']['entries']())_0x230723=_0x230723['concat'](hr(_0x132e5a,_0x417ac7,_0x414357)),lr(_0x132e5a)&&(_0x322559['views']['delete'](_0x29c6cf),_0x132e5a['query']['_queryParams']['loadsAllData']()||_0x47f5c9['push'](_0x132e5a['query']));}else{const _0x40227b=_0x322559['views']['get'](_0x508015);_0x40227b&&(_0x230723=_0x230723['concat'](hr(_0x40227b,_0x417ac7,_0x414357)),lr(_0x40227b)&&(_0x322559['views']['delete'](_0x508015),_0x40227b['query']['_queryParams']['loadsAllData']()||_0x47f5c9['push'](_0x40227b['query'])));}return _0x94ed73&&!Te(_0x322559)&&_0x47f5c9['push'](new(Fu())(_0x26a342['_repo'],_0x26a342['_path'])),{'removed':_0x47f5c9,'events':_0x230723};}function zo(_0x51158b){const _0x48d7fa=[];for(const _0x207075 of _0x51158b['views']['values']())_0x207075['query']['_queryParams']['loadsAllData']()||_0x48d7fa['push'](_0x207075);return _0x48d7fa;}function Ee(_0x2f72bb,_0x2b0c75){let _0x260632=null;for(const _0x4207ca of _0x2f72bb['views']['values']())_0x260632=_0x260632||Du(_0x4207ca,_0x2b0c75);return _0x260632;}function jo(_0xd9f00f,_0x16c81f){if(_0x16c81f['_queryParams']['loadsAllData']())return Ln(_0xd9f00f);{const _0x22a771=_0x16c81f['_queryIdentifier'];return _0xd9f00f['views']['get'](_0x22a771);}}function Ko(_0x41e791,_0x35488c){return jo(_0x41e791,_0x35488c)!=null;}function Te(_0x509ad){return Ln(_0x509ad)!=null;}function Ln(_0x4ce4ba){for(const _0x50388b of _0x4ce4ba['views']['values']())if(_0x50388b['query']['_queryParams']['loadsAllData']())return _0x50388b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xa20d4b){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xa20d4b;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x37061f){this['listenProvider_']=_0x37061f,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x42a6c9,_0x40e586,_0x42a223,_0x3cab39,_0x466a89){return ou(_0x42a6c9['pendingWriteTree_'],_0x40e586,_0x42a223,_0x3cab39,_0x466a89),_0x466a89?ht(_0x42a6c9,new Fe(Ji(),_0x40e586,_0x42a223)):[];}function Gu(_0x3007e7,_0x5c3a9f,_0x136469,_0x54de6e){au(_0x3007e7['pendingWriteTree_'],_0x5c3a9f,_0x136469,_0x54de6e);const _0x53c21f=S['fromObject'](_0x136469);return ht(_0x3007e7,new nt(Ji(),_0x5c3a9f,_0x53c21f));}function pe(_0x2a1cf6,_0xb00630,_0xeb433d=!0x1){const _0x349b8a=cu(_0x2a1cf6['pendingWriteTree_'],_0xb00630);if(lu(_0x2a1cf6['pendingWriteTree_'],_0xb00630)){let _0x95504f=new S(null);return _0x349b8a['snap']!=null?_0x95504f=_0x95504f['set'](w(),!0x0):x(_0x349b8a['children'],_0x2240b6=>{_0x95504f=_0x95504f['set'](new C(_0x2240b6),!0x0);}),ht(_0x2a1cf6,new _n(_0x349b8a['path'],_0x95504f,_0xeb433d));}else return[];}function $t(_0x20c211,_0x26b59d,_0x3d364d){return ht(_0x20c211,new Fe(Xi(),_0x26b59d,_0x3d364d));}function qu(_0x3ed99f,_0x309f60,_0x31a564){const _0x52bac7=S['fromObject'](_0x31a564);return ht(_0x3ed99f,new nt(Xi(),_0x309f60,_0x52bac7));}function zu(_0x27dcee,_0x53ab92){return ht(_0x27dcee,new Dt(Xi(),_0x53ab92));}function ju(_0x533d90,_0x163a2c,_0x444294){const _0x43f599=rs(_0x533d90,_0x444294);if(_0x43f599){const _0x542281=os(_0x43f599),_0x443798=_0x542281['path'],_0x211c04=_0x542281['queryId'],_0x3a1f45=F(_0x443798,_0x163a2c),_0x4a9868=new Dt(Zi(_0x211c04),_0x3a1f45);return as(_0x533d90,_0x443798,_0x4a9868);}else return[];}function wn(_0xf56f93,_0x56ac05,_0x36fcee,_0x392fb3,_0x6737ad=!0x1){const _0x4eb025=_0x56ac05['_path'],_0x36b69c=_0xf56f93['syncPointTree_']['get'](_0x4eb025);let _0x225ba9=[];if(_0x36b69c&&(_0x56ac05['_queryIdentifier']==='default'||Ko(_0x36b69c,_0x56ac05))){const _0x3eaf5d=Bu(_0x36b69c,_0x56ac05,_0x36fcee,_0x392fb3);Uu(_0x36b69c)&&(_0xf56f93['syncPointTree_']=_0xf56f93['syncPointTree_']['remove'](_0x4eb025));const _0x13fc91=_0x3eaf5d['removed'];if(_0x225ba9=_0x3eaf5d['events'],!_0x6737ad){const _0x1d1744=_0x13fc91['findIndex'](_0x417394=>_0x417394['_queryParams']['loadsAllData']())!==-0x1,_0x40cfe6=_0xf56f93['syncPointTree_']['findOnPath'](_0x4eb025,(_0x5092bb,_0x363fb)=>Te(_0x363fb));if(_0x1d1744&&!_0x40cfe6){const _0x15fa5b=_0xf56f93['syncPointTree_']['subtree'](_0x4eb025);if(!_0x15fa5b['isEmpty']()){const _0x13feb7=Qu(_0x15fa5b);for(let _0x93d585=0x0;_0x93d585<_0x13feb7['length'];++_0x93d585){const _0x288c6d=_0x13feb7[_0x93d585],_0xf522ec=_0x288c6d['query'],_0x4c7e6e=Xo(_0xf56f93,_0x288c6d);_0xf56f93['listenProvider_']['startListening'](Tt(_0xf522ec),Mt(_0xf56f93,_0xf522ec),_0x4c7e6e['hashFn'],_0x4c7e6e['onComplete']);}}}!_0x40cfe6&&_0x13fc91['length']>0x0&&!_0x392fb3&&(_0x1d1744?_0xf56f93['listenProvider_']['stopListening'](Tt(_0x56ac05),null):_0x13fc91['forEach'](_0x18d95f=>{const _0x40d489=_0xf56f93['queryToTagMap']['get'](Fn(_0x18d95f));_0xf56f93['listenProvider_']['stopListening'](Tt(_0x18d95f),_0x40d489);}));}Ju(_0xf56f93,_0x13fc91);}return _0x225ba9;}function Yo(_0x29554,_0xa494fc,_0x538397,_0x29006f){const _0x557e65=rs(_0x29554,_0x29006f);if(_0x557e65!=null){const _0x2bda95=os(_0x557e65),_0x19b398=_0x2bda95['path'],_0x1a35ad=_0x2bda95['queryId'],_0x4d17bd=F(_0x19b398,_0xa494fc),_0x2492dc=new Fe(Zi(_0x1a35ad),_0x4d17bd,_0x538397);return as(_0x29554,_0x19b398,_0x2492dc);}else return[];}function Ku(_0x189cda,_0x2454eb,_0x27c606,_0x56f5d3){const _0x204ff4=rs(_0x189cda,_0x56f5d3);if(_0x204ff4){const _0x1e76d6=os(_0x204ff4),_0x5d2cc2=_0x1e76d6['path'],_0x18fdbd=_0x1e76d6['queryId'],_0x23e835=F(_0x5d2cc2,_0x2454eb),_0x3bd811=S['fromObject'](_0x27c606),_0x289be2=new nt(Zi(_0x18fdbd),_0x23e835,_0x3bd811);return as(_0x189cda,_0x5d2cc2,_0x289be2);}else return[];}function bi(_0x31cff0,_0x2c931e,_0x2a594a,_0x29acca=!0x1){const _0x2c7804=_0x2c931e['_path'];let _0x5240b5=null,_0x31a291=!0x1;_0x31cff0['syncPointTree_']['foreachOnPath'](_0x2c7804,(_0x576bb9,_0x37623b)=>{const _0x3610c0=F(_0x576bb9,_0x2c7804);_0x5240b5=_0x5240b5||Ee(_0x37623b,_0x3610c0),_0x31a291=_0x31a291||Te(_0x37623b);});let _0x3eceef=_0x31cff0['syncPointTree_']['get'](_0x2c7804);_0x3eceef?(_0x31a291=_0x31a291||Te(_0x3eceef),_0x5240b5=_0x5240b5||Ee(_0x3eceef,w())):(_0x3eceef=new Go(),_0x31cff0['syncPointTree_']=_0x31cff0['syncPointTree_']['set'](_0x2c7804,_0x3eceef));let _0x1b7407;_0x5240b5!=null?_0x1b7407=!0x0:(_0x1b7407=!0x1,_0x5240b5=g['EMPTY_NODE'],_0x31cff0['syncPointTree_']['subtree'](_0x2c7804)['foreachChild']((_0x1e4d25,_0x21caa4)=>{const _0x27508b=Ee(_0x21caa4,w());_0x27508b&&(_0x5240b5=_0x5240b5['updateImmediateChild'](_0x1e4d25,_0x27508b));}));const _0x5c7418=Ko(_0x3eceef,_0x2c931e);if(!_0x5c7418&&!_0x2c931e['_queryParams']['loadsAllData']()){const _0x3ace88=Fn(_0x2c931e);f(!_0x31cff0['queryToTagMap']['has'](_0x3ace88),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x434d84=Xu();_0x31cff0['queryToTagMap']['set'](_0x3ace88,_0x434d84),_0x31cff0['tagToQueryMap']['set'](_0x434d84,_0x3ace88);}const _0x180f79=Mn(_0x31cff0['pendingWriteTree_'],_0x2c7804);let _0x43b0da=Wu(_0x3eceef,_0x2c931e,_0x2a594a,_0x180f79,_0x5240b5,_0x1b7407);if(!_0x5c7418&&!_0x31a291&&!_0x29acca){const _0x160e6b=jo(_0x3eceef,_0x2c931e);_0x43b0da=_0x43b0da['concat'](Zu(_0x31cff0,_0x2c931e,_0x160e6b));}return _0x43b0da;}function xn(_0x5759e6,_0x44e42e,_0x537baf){const _0x65737e=_0x5759e6['pendingWriteTree_'],_0x10906f=_0x5759e6['syncPointTree_']['findOnPath'](_0x44e42e,(_0x49ce85,_0x461baf)=>{const _0x3caddd=F(_0x49ce85,_0x44e42e),_0x415dfb=Ee(_0x461baf,_0x3caddd);if(_0x415dfb)return _0x415dfb;});return Uo(_0x65737e,_0x44e42e,_0x10906f,_0x537baf,!0x0);}function Yu(_0x3acf22,_0x4a58b0){const _0x375a2d=_0x4a58b0['_path'];let _0x29b876=null;_0x3acf22['syncPointTree_']['foreachOnPath'](_0x375a2d,(_0x33007a,_0x316227)=>{const _0x11ce3e=F(_0x33007a,_0x375a2d);_0x29b876=_0x29b876||Ee(_0x316227,_0x11ce3e);});let _0x3fcbd9=_0x3acf22['syncPointTree_']['get'](_0x375a2d);_0x3fcbd9?_0x29b876=_0x29b876||Ee(_0x3fcbd9,w()):(_0x3fcbd9=new Go(),_0x3acf22['syncPointTree_']=_0x3acf22['syncPointTree_']['set'](_0x375a2d,_0x3fcbd9));const _0x2f7dfc=_0x29b876!=null,_0x2b4cb0=_0x2f7dfc?new Ce(_0x29b876,!0x0,!0x1):null,_0x5d52b5=Mn(_0x3acf22['pendingWriteTree_'],_0x4a58b0['_path']),_0x3ade55=qo(_0x3fcbd9,_0x4a58b0,_0x5d52b5,_0x2f7dfc?_0x2b4cb0['getNode']():g['EMPTY_NODE'],_0x2f7dfc);return Ou(_0x3ade55);}function ht(_0x3cac7a,_0xea4b87){return Qo(_0xea4b87,_0x3cac7a['syncPointTree_'],null,Mn(_0x3cac7a['pendingWriteTree_'],w()));}function Qo(_0x68725e,_0x19d630,_0x4a46dd,_0x5f4d72){if(v(_0x68725e['path']))return Jo(_0x68725e,_0x19d630,_0x4a46dd,_0x5f4d72);{const _0x4a0868=_0x19d630['get'](w());_0x4a46dd==null&&_0x4a0868!=null&&(_0x4a46dd=Ee(_0x4a0868,w()));let _0x5c2316=[];const _0x2e2575=y(_0x68725e['path']),_0x5de95e=_0x68725e['operationForChild'](_0x2e2575),_0x550469=_0x19d630['children']['get'](_0x2e2575);if(_0x550469&&_0x5de95e){const _0x10d43a=_0x4a46dd?_0x4a46dd['getImmediateChild'](_0x2e2575):null,_0x5e33b1=Wo(_0x5f4d72,_0x2e2575);_0x5c2316=_0x5c2316['concat'](Qo(_0x5de95e,_0x550469,_0x10d43a,_0x5e33b1));}return _0x4a0868&&(_0x5c2316=_0x5c2316['concat'](is(_0x4a0868,_0x68725e,_0x5f4d72,_0x4a46dd))),_0x5c2316;}}function Jo(_0x45e5db,_0x10b400,_0x23e61b,_0x58d12c){const _0x249815=_0x10b400['get'](w());_0x23e61b==null&&_0x249815!=null&&(_0x23e61b=Ee(_0x249815,w()));let _0x36141e=[];return _0x10b400['children']['inorderTraversal']((_0x3a9dac,_0x41070d)=>{const _0x1251f6=_0x23e61b?_0x23e61b['getImmediateChild'](_0x3a9dac):null,_0x4bbbb9=Wo(_0x58d12c,_0x3a9dac),_0x517e96=_0x45e5db['operationForChild'](_0x3a9dac);_0x517e96&&(_0x36141e=_0x36141e['concat'](Jo(_0x517e96,_0x41070d,_0x1251f6,_0x4bbbb9)));}),_0x249815&&(_0x36141e=_0x36141e['concat'](is(_0x249815,_0x45e5db,_0x58d12c,_0x23e61b))),_0x36141e;}function Xo(_0x420b4f,_0x46a49a){const _0x1b0314=_0x46a49a['query'],_0x2224a=Mt(_0x420b4f,_0x1b0314);return{'hashFn':()=>(Pu(_0x46a49a)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x27d1ef=>{if(_0x27d1ef==='ok')return _0x2224a?ju(_0x420b4f,_0x1b0314['_path'],_0x2224a):zu(_0x420b4f,_0x1b0314['_path']);{const _0x43c087=ql(_0x27d1ef,_0x1b0314);return wn(_0x420b4f,_0x1b0314,null,_0x43c087);}}};}function Mt(_0x199836,_0x54e2a4){const _0x11b429=Fn(_0x54e2a4);return _0x199836['queryToTagMap']['get'](_0x11b429);}function Fn(_0x18b8bd){return _0x18b8bd['_path']['toString']()+'$'+_0x18b8bd['_queryIdentifier'];}function rs(_0x57535c,_0x4b189a){return _0x57535c['tagToQueryMap']['get'](_0x4b189a);}function os(_0x1d47df){const _0x147567=_0x1d47df['indexOf']('$');return f(_0x147567!==-0x1&&_0x147567<_0x1d47df['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1d47df['substr'](_0x147567+0x1),'path':new C(_0x1d47df['substr'](0x0,_0x147567))};}function as(_0x4897c3,_0x45dce8,_0x362c3e){const _0x1b0cda=_0x4897c3['syncPointTree_']['get'](_0x45dce8);f(_0x1b0cda,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4f4d69=Mn(_0x4897c3['pendingWriteTree_'],_0x45dce8);return is(_0x1b0cda,_0x362c3e,_0x4f4d69,null);}function Qu(_0x5672d0){return _0x5672d0['fold']((_0x334af5,_0x5f2313,_0x3b0904)=>{if(_0x5f2313&&Te(_0x5f2313))return[Ln(_0x5f2313)];{let _0x5ec08b=[];return _0x5f2313&&(_0x5ec08b=zo(_0x5f2313)),x(_0x3b0904,(_0x1e6ba8,_0x47c5f2)=>{_0x5ec08b=_0x5ec08b['concat'](_0x47c5f2);}),_0x5ec08b;}});}function Tt(_0x575424){return _0x575424['_queryParams']['loadsAllData']()&&!_0x575424['_queryParams']['isDefault']()?new(Hu())(_0x575424['_repo'],_0x575424['_path']):_0x575424;}function Ju(_0x6137f2,_0x1133af){for(let _0x26bae0=0x0;_0x26bae0<_0x1133af['length'];++_0x26bae0){const _0x41f9de=_0x1133af[_0x26bae0];if(!_0x41f9de['_queryParams']['loadsAllData']()){const _0x5e2132=Fn(_0x41f9de),_0x4e8fbf=_0x6137f2['queryToTagMap']['get'](_0x5e2132);_0x6137f2['queryToTagMap']['delete'](_0x5e2132),_0x6137f2['tagToQueryMap']['delete'](_0x4e8fbf);}}}function Xu(){return $u++;}function Zu(_0x925678,_0xeebe25,_0x27737b){const _0x507991=_0xeebe25['_path'],_0x1eb5a5=Mt(_0x925678,_0xeebe25),_0x3efe2b=Xo(_0x925678,_0x27737b),_0x297f88=_0x925678['listenProvider_']['startListening'](Tt(_0xeebe25),_0x1eb5a5,_0x3efe2b['hashFn'],_0x3efe2b['onComplete']),_0x109ac0=_0x925678['syncPointTree_']['subtree'](_0x507991);if(_0x1eb5a5)f(!Te(_0x109ac0['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x264b5f=_0x109ac0['fold']((_0xb4348e,_0x7b2cce,_0x5b60c2)=>{if(!v(_0xb4348e)&&_0x7b2cce&&Te(_0x7b2cce))return[Ln(_0x7b2cce)['query']];{let _0x898386=[];return _0x7b2cce&&(_0x898386=_0x898386['concat'](zo(_0x7b2cce)['map'](_0x24b37c=>_0x24b37c['query']))),x(_0x5b60c2,(_0x4135e7,_0x55c9a4)=>{_0x898386=_0x898386['concat'](_0x55c9a4);}),_0x898386;}});for(let _0x1599c5=0x0;_0x1599c5<_0x264b5f['length'];++_0x1599c5){const _0x222b5c=_0x264b5f[_0x1599c5];_0x925678['listenProvider_']['stopListening'](Tt(_0x222b5c),Mt(_0x925678,_0x222b5c));}}return _0x297f88;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x5acefe){this['node_']=_0x5acefe;}['getImmediateChild'](_0x3531a0){const _0x15c23b=this['node_']['getImmediateChild'](_0x3531a0);return new cs(_0x15c23b);}['node'](){return this['node_'];}}class ls{constructor(_0x561b37,_0x118023){this['syncTree_']=_0x561b37,this['path_']=_0x118023;}['getImmediateChild'](_0x2da9d2){const _0x3aff9d=A(this['path_'],_0x2da9d2);return new ls(this['syncTree_'],_0x3aff9d);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x3dff9e){return _0x3dff9e=_0x3dff9e||{},_0x3dff9e['timestamp']=_0x3dff9e['timestamp']||new Date()['getTime'](),_0x3dff9e;},fr=function(_0x5c8912,_0x73ce45,_0x4eb904){if(!_0x5c8912||typeof _0x5c8912!='object')return _0x5c8912;if(f('.sv'in _0x5c8912,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5c8912['.sv']=='string')return td(_0x5c8912['.sv'],_0x73ce45,_0x4eb904);if(typeof _0x5c8912['.sv']=='object')return nd(_0x5c8912['.sv'],_0x73ce45);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5c8912,null,0x2));},td=function(_0x39c238,_0x252de6,_0x38dc67){switch(_0x39c238){case'timestamp':return _0x38dc67['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x39c238);}},nd=function(_0xf4d815,_0x3bb612,_0x5bd457){_0xf4d815['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xf4d815,null,0x2));const _0x176d5f=_0xf4d815['increment'];typeof _0x176d5f!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x176d5f);const _0x78961f=_0x3bb612['node']();if(f(_0x78961f!==null&&typeof _0x78961f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x78961f['isLeafNode']())return _0x176d5f;const _0x1bada3=_0x78961f['getValue']();return typeof _0x1bada3!='number'?_0x176d5f:_0x1bada3+_0x176d5f;},Zo=function(_0x9f24c5,_0x1d30e7,_0x452c1c,_0x330a4d){return us(_0x1d30e7,new ls(_0x452c1c,_0x9f24c5),_0x330a4d);},hs=function(_0x34a630,_0x1a9427,_0x50022a){return us(_0x34a630,new cs(_0x1a9427),_0x50022a);};function us(_0x4b0db1,_0xf9a4ff,_0x57fce0){const _0x277585=_0x4b0db1['getPriority']()['val'](),_0x464712=fr(_0x277585,_0xf9a4ff['getImmediateChild']('.priority'),_0x57fce0);let _0x1430bd;if(_0x4b0db1['isLeafNode']()){const _0x2e6dab=_0x4b0db1,_0x3617a1=fr(_0x2e6dab['getValue'](),_0xf9a4ff,_0x57fce0);return _0x3617a1!==_0x2e6dab['getValue']()||_0x464712!==_0x2e6dab['getPriority']()['val']()?new D(_0x3617a1,N(_0x464712)):_0x4b0db1;}else{const _0x46dbfa=_0x4b0db1;return _0x1430bd=_0x46dbfa,_0x464712!==_0x46dbfa['getPriority']()['val']()&&(_0x1430bd=_0x1430bd['updatePriority'](new D(_0x464712))),_0x46dbfa['forEachChild'](R,(_0x5d252c,_0x187f76)=>{const _0x3b798b=us(_0x187f76,_0xf9a4ff['getImmediateChild'](_0x5d252c),_0x57fce0);_0x3b798b!==_0x187f76&&(_0x1430bd=_0x1430bd['updateImmediateChild'](_0x5d252c,_0x3b798b));}),_0x1430bd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x59cf1f='',_0x1bfd6e=null,_0x4b15e7={'children':{},'childCount':0x0}){this['name']=_0x59cf1f,this['parent']=_0x1bfd6e,this['node']=_0x4b15e7;}}function Un(_0x3c3531,_0x142e76){let _0x135062=_0x142e76 instanceof C?_0x142e76:new C(_0x142e76),_0xf92a91=_0x3c3531,_0x3ab22d=y(_0x135062);for(;_0x3ab22d!==null;){const _0x1f3ef5=Oe(_0xf92a91['node']['children'],_0x3ab22d)||{'children':{},'childCount':0x0};_0xf92a91=new ds(_0x3ab22d,_0xf92a91,_0x1f3ef5),_0x135062=b(_0x135062),_0x3ab22d=y(_0x135062);}return _0xf92a91;}function Ge(_0x1e4b67){return _0x1e4b67['node']['value'];}function fs(_0x294da4,_0x4f6e3f){_0x294da4['node']['value']=_0x4f6e3f,Ri(_0x294da4);}function ea(_0x37be41){return _0x37be41['node']['childCount']>0x0;}function id(_0x5c61dc){return Ge(_0x5c61dc)===void 0x0&&!ea(_0x5c61dc);}function Wn(_0x3141b7,_0x2bfa42){x(_0x3141b7['node']['children'],(_0xc210d0,_0x271818)=>{_0x2bfa42(new ds(_0xc210d0,_0x3141b7,_0x271818));});}function ta(_0xc8233b,_0x288b86,_0x277044,_0x2733fa){_0x277044&&_0x288b86(_0xc8233b),Wn(_0xc8233b,_0x4fc0c3=>{ta(_0x4fc0c3,_0x288b86,!0x0);});}function sd(_0x4195c1,_0x5d0eec,_0x124c63){let _0x24ab1b=_0x4195c1['parent'];for(;_0x24ab1b!==null;){if(_0x5d0eec(_0x24ab1b))return!0x0;_0x24ab1b=_0x24ab1b['parent'];}return!0x1;}function Gt(_0x345c34){return new C(_0x345c34['parent']===null?_0x345c34['name']:Gt(_0x345c34['parent'])+'/'+_0x345c34['name']);}function Ri(_0x108710){_0x108710['parent']!==null&&rd(_0x108710['parent'],_0x108710['name'],_0x108710);}function rd(_0x103a0c,_0x3b3ffe,_0x2ab13e){const _0x2da81e=id(_0x2ab13e),_0x2c7f00=Y(_0x103a0c['node']['children'],_0x3b3ffe);_0x2da81e&&_0x2c7f00?(delete _0x103a0c['node']['children'][_0x3b3ffe],_0x103a0c['node']['childCount']--,Ri(_0x103a0c)):!_0x2da81e&&!_0x2c7f00&&(_0x103a0c['node']['children'][_0x3b3ffe]=_0x2ab13e['node'],_0x103a0c['node']['childCount']++,Ri(_0x103a0c));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x529faa){return typeof _0x529faa=='string'&&_0x529faa['length']!==0x0&&!od['test'](_0x529faa);},na=function(_0x1ffb53){return typeof _0x1ffb53=='string'&&_0x1ffb53['length']!==0x0&&!ad['test'](_0x1ffb53);},cd=function(_0x31bfd9){return _0x31bfd9&&(_0x31bfd9=_0x31bfd9['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x31bfd9);},Cn=function(_0x20213d){return _0x20213d===null||typeof _0x20213d=='string'||typeof _0x20213d=='number'&&!Wi(_0x20213d)||_0x20213d&&typeof _0x20213d=='object'&&Y(_0x20213d,'.sv');},qt=function(_0x177838,_0x415e79,_0x537460,_0x370218){_0x370218&&_0x415e79===void 0x0||zt(Nn(_0x177838,'value'),_0x415e79,_0x537460);},zt=function(_0x5b0f76,_0xd116e9,_0x22b8e3){const _0x20524b=_0x22b8e3 instanceof C?new Sh(_0x22b8e3,_0x5b0f76):_0x22b8e3;if(_0xd116e9===void 0x0)throw new Error(_0x5b0f76+'contains\x20undefined\x20'+Ne(_0x20524b));if(typeof _0xd116e9=='function')throw new Error(_0x5b0f76+'contains\x20a\x20function\x20'+Ne(_0x20524b)+'\x20with\x20contents\x20=\x20'+_0xd116e9['toString']());if(Wi(_0xd116e9))throw new Error(_0x5b0f76+'contains\x20'+_0xd116e9['toString']()+'\x20'+Ne(_0x20524b));if(typeof _0xd116e9=='string'&&_0xd116e9['length']>oi/0x3&&Pn(_0xd116e9)>oi)throw new Error(_0x5b0f76+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x20524b)+'\x20(\x27'+_0xd116e9['substring'](0x0,0x32)+'...\x27)');if(_0xd116e9&&typeof _0xd116e9=='object'){let _0x448d58=!0x1,_0x586dfc=!0x1;if(x(_0xd116e9,(_0x2288c4,_0x5d6462)=>{if(_0x2288c4==='.value')_0x448d58=!0x0;else{if(_0x2288c4!=='.priority'&&_0x2288c4!=='.sv'&&(_0x586dfc=!0x0,!ps(_0x2288c4)))throw new Error(_0x5b0f76+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2288c4+')\x20'+Ne(_0x20524b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x20524b,_0x2288c4),zt(_0x5b0f76,_0x5d6462,_0x20524b),Rh(_0x20524b);}),_0x448d58&&_0x586dfc)throw new Error(_0x5b0f76+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x20524b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x5f02ed,_0x36cf58){let _0x3c483e,_0x88f264;for(_0x3c483e=0x0;_0x3c483e<_0x36cf58['length'];_0x3c483e++){_0x88f264=_0x36cf58[_0x3c483e];const _0x109309=kt(_0x88f264);for(let _0x45317b=0x0;_0x45317b<_0x109309['length'];_0x45317b++)if(!(_0x109309[_0x45317b]==='.priority'&&_0x45317b===_0x109309['length']-0x1)){if(!ps(_0x109309[_0x45317b]))throw new Error(_0x5f02ed+'contains\x20an\x20invalid\x20key\x20('+_0x109309[_0x45317b]+')\x20in\x20path\x20'+_0x88f264['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x36cf58['sort'](Th);let _0x11217a=null;for(_0x3c483e=0x0;_0x3c483e<_0x36cf58['length'];_0x3c483e++){if(_0x88f264=_0x36cf58[_0x3c483e],_0x11217a!==null&&$(_0x11217a,_0x88f264))throw new Error(_0x5f02ed+'contains\x20a\x20path\x20'+_0x11217a['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x88f264['toString']());_0x11217a=_0x88f264;}},hd=function(_0x193f54,_0x2d393b,_0x27a716,_0x1014f0){const _0xc3d0c0=Nn(_0x193f54,'values');if(!(_0x2d393b&&typeof _0x2d393b=='object')||Array['isArray'](_0x2d393b))throw new Error(_0xc3d0c0+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xb7b540=[];x(_0x2d393b,(_0x21d9ca,_0x4e7274)=>{const _0x3196fb=new C(_0x21d9ca);if(zt(_0xc3d0c0,_0x4e7274,A(_0x27a716,_0x3196fb)),Gi(_0x3196fb)==='.priority'&&!Cn(_0x4e7274))throw new Error(_0xc3d0c0+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3196fb['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xb7b540['push'](_0x3196fb);}),ld(_0xc3d0c0,_0xb7b540);},_s=function(_0x4929cf,_0x4b67c6,_0xd6dc8d,_0x5b27d9){if(!na(_0xd6dc8d))throw new Error(Nn(_0x4929cf,_0x4b67c6)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0xd6dc8d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x13dc7d,_0x1435df,_0x3e1b9f,_0x56b81d){_0x3e1b9f&&(_0x3e1b9f=_0x3e1b9f['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x13dc7d,_0x1435df,_0x3e1b9f);},gs=function(_0x18d196,_0x2e3ad2){if(y(_0x2e3ad2)==='.info')throw new Error(_0x18d196+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x505ec1,_0x86ef3c){const _0x23c259=_0x86ef3c['path']['toString']();if(typeof _0x86ef3c['repoInfo']['host']!='string'||_0x86ef3c['repoInfo']['host']['length']===0x0||!ps(_0x86ef3c['repoInfo']['namespace'])&&_0x86ef3c['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x23c259['length']!==0x0&&!cd(_0x23c259))throw new Error(Nn(_0x505ec1,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x20ad85,_0x4dbc8d){let _0x857615=null;for(let _0x55a4a8=0x0;_0x55a4a8<_0x4dbc8d['length'];_0x55a4a8++){const _0x43d2e0=_0x4dbc8d[_0x55a4a8],_0xc3860a=_0x43d2e0['getPath']();_0x857615!==null&&!qi(_0xc3860a,_0x857615['path'])&&(_0x20ad85['eventLists_']['push'](_0x857615),_0x857615=null),_0x857615===null&&(_0x857615={'events':[],'path':_0xc3860a}),_0x857615['events']['push'](_0x43d2e0);}_0x857615&&_0x20ad85['eventLists_']['push'](_0x857615);}function ia(_0x18cbe0,_0x747220,_0x38d96c){Bn(_0x18cbe0,_0x38d96c),sa(_0x18cbe0,_0x4ec034=>qi(_0x4ec034,_0x747220));}function V(_0x3ab711,_0x572d37,_0x708fd2){Bn(_0x3ab711,_0x708fd2),sa(_0x3ab711,_0x547d13=>$(_0x547d13,_0x572d37)||$(_0x572d37,_0x547d13));}function sa(_0x494395,_0x284a71){_0x494395['recursionDepth_']++;let _0x233219=!0x0;for(let _0xb1c0f5=0x0;_0xb1c0f5<_0x494395['eventLists_']['length'];_0xb1c0f5++){const _0x31bb20=_0x494395['eventLists_'][_0xb1c0f5];if(_0x31bb20){const _0x41ad8a=_0x31bb20['path'];_0x284a71(_0x41ad8a)?(pd(_0x494395['eventLists_'][_0xb1c0f5]),_0x494395['eventLists_'][_0xb1c0f5]=null):_0x233219=!0x1;}}_0x233219&&(_0x494395['eventLists_']=[]),_0x494395['recursionDepth_']--;}function pd(_0x24836e){for(let _0x522a78=0x0;_0x522a78<_0x24836e['events']['length'];_0x522a78++){const _0x1de5c4=_0x24836e['events'][_0x522a78];if(_0x1de5c4!==null){_0x24836e['events'][_0x522a78]=null;const _0x3f1764=_0x1de5c4['getEventRunner']();Et&&L('event:\x20'+_0x1de5c4['toString']()),lt(_0x3f1764);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x2364c4,_0x58657b,_0x53ede6,_0x299c32){this['repoInfo_']=_0x2364c4,this['forceRestClient_']=_0x58657b,this['authTokenProvider_']=_0x53ede6,this['appCheckProvider_']=_0x299c32,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x45f2ab,_0x3d2dc3,_0x242d5a){if(_0x45f2ab['stats_']=Hi(_0x45f2ab['repoInfo_']),_0x45f2ab['forceRestClient_']||Yl())_0x45f2ab['server_']=new fn(_0x45f2ab['repoInfo_'],(_0x52838b,_0x513495,_0x146407,_0x572daf)=>{pr(_0x45f2ab,_0x52838b,_0x513495,_0x146407,_0x572daf);},_0x45f2ab['authTokenProvider_'],_0x45f2ab['appCheckProvider_']),setTimeout(()=>_r(_0x45f2ab,!0x0),0x0);else{if(typeof _0x242d5a<'u'&&_0x242d5a!==null){if(typeof _0x242d5a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x242d5a);}catch(_0x448ffd){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x448ffd);}}_0x45f2ab['persistentConnection_']=new ie(_0x45f2ab['repoInfo_'],_0x3d2dc3,(_0x3c7a8c,_0x4e855a,_0x51f9e4,_0x2e88a2)=>{pr(_0x45f2ab,_0x3c7a8c,_0x4e855a,_0x51f9e4,_0x2e88a2);},_0x1baf89=>{_r(_0x45f2ab,_0x1baf89);},_0x49894e=>{yd(_0x45f2ab,_0x49894e);},_0x45f2ab['authTokenProvider_'],_0x45f2ab['appCheckProvider_'],_0x242d5a),_0x45f2ab['server_']=_0x45f2ab['persistentConnection_'];}_0x45f2ab['authTokenProvider_']['addTokenChangeListener'](_0xf7800e=>{_0x45f2ab['server_']['refreshAuthToken'](_0xf7800e);}),_0x45f2ab['appCheckProvider_']['addTokenChangeListener'](_0x36e64e=>{_0x45f2ab['server_']['refreshAppCheckToken'](_0x36e64e['token']);}),_0x45f2ab['statsReporter_']=eh(_0x45f2ab['repoInfo_'],()=>new eu(_0x45f2ab['stats_'],_0x45f2ab['server_'])),_0x45f2ab['infoData_']=new Yh(),_0x45f2ab['infoSyncTree_']=new dr({'startListening':(_0x2d497a,_0x19ef48,_0x17240a,_0x3344c8)=>{let _0x2cb127=[];const _0x1d2555=_0x45f2ab['infoData_']['getNode'](_0x2d497a['_path']);return _0x1d2555['isEmpty']()||(_0x2cb127=$t(_0x45f2ab['infoSyncTree_'],_0x2d497a['_path'],_0x1d2555),setTimeout(()=>{_0x3344c8('ok');},0x0)),_0x2cb127;},'stopListening':()=>{}}),ms(_0x45f2ab,'connected',!0x1),_0x45f2ab['serverSyncTree_']=new dr({'startListening':(_0x187da9,_0x2a1211,_0x16ebbc,_0x3a426c)=>(_0x45f2ab['server_']['listen'](_0x187da9,_0x16ebbc,_0x2a1211,(_0x8e3565,_0x46d383)=>{const _0x7f0c12=_0x3a426c(_0x8e3565,_0x46d383);V(_0x45f2ab['eventQueue_'],_0x187da9['_path'],_0x7f0c12);}),[]),'stopListening':(_0x4231af,_0xfc9ade)=>{_0x45f2ab['server_']['unlisten'](_0x4231af,_0xfc9ade);}});}function oa(_0xa07639){const _0x131dfa=_0xa07639['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x131dfa;}function jt(_0xee1669){return ed({'timestamp':oa(_0xee1669)});}function pr(_0xde8540,_0x269144,_0x3afcf6,_0x1fa682,_0x493fb2){_0xde8540['dataUpdateCount']++;const _0x21c746=new C(_0x269144);_0x3afcf6=_0xde8540['interceptServerDataCallback_']?_0xde8540['interceptServerDataCallback_'](_0x269144,_0x3afcf6):_0x3afcf6;let _0x58b2a1=[];if(_0x493fb2){if(_0x1fa682){const _0x4a6840=ln(_0x3afcf6,_0x32d2d4=>N(_0x32d2d4));_0x58b2a1=Ku(_0xde8540['serverSyncTree_'],_0x21c746,_0x4a6840,_0x493fb2);}else{const _0x933890=N(_0x3afcf6);_0x58b2a1=Yo(_0xde8540['serverSyncTree_'],_0x21c746,_0x933890,_0x493fb2);}}else{if(_0x1fa682){const _0x54abef=ln(_0x3afcf6,_0x1d1ac8=>N(_0x1d1ac8));_0x58b2a1=qu(_0xde8540['serverSyncTree_'],_0x21c746,_0x54abef);}else{const _0x49965c=N(_0x3afcf6);_0x58b2a1=$t(_0xde8540['serverSyncTree_'],_0x21c746,_0x49965c);}}let _0x3cd596=_0x21c746;_0x58b2a1['length']>0x0&&(_0x3cd596=st(_0xde8540,_0x21c746)),V(_0xde8540['eventQueue_'],_0x3cd596,_0x58b2a1);}function _r(_0x4be973,_0x4caf9c){ms(_0x4be973,'connected',_0x4caf9c),_0x4caf9c===!0x1&&wd(_0x4be973);}function yd(_0x47788b,_0x264286){x(_0x264286,(_0x425e2e,_0x23fbb1)=>{ms(_0x47788b,_0x425e2e,_0x23fbb1);});}function ms(_0x38feac,_0x733089,_0x5aa2b6){const _0x4dc9f7=new C('/.info/'+_0x733089),_0x4a8442=N(_0x5aa2b6);_0x38feac['infoData_']['updateSnapshot'](_0x4dc9f7,_0x4a8442);const _0x5c1db7=$t(_0x38feac['infoSyncTree_'],_0x4dc9f7,_0x4a8442);V(_0x38feac['eventQueue_'],_0x4dc9f7,_0x5c1db7);}function Vn(_0x1a1059){return _0x1a1059['nextWriteId_']++;}function vd(_0x51457f,_0x16d7ca,_0x13809b){const _0x3dbdc7=Yu(_0x51457f['serverSyncTree_'],_0x16d7ca);return _0x3dbdc7!=null?Promise['resolve'](_0x3dbdc7):_0x51457f['server_']['get'](_0x16d7ca)['then'](_0x55b130=>{const _0x18c12e=N(_0x55b130)['withIndex'](_0x16d7ca['_queryParams']['getIndex']());bi(_0x51457f['serverSyncTree_'],_0x16d7ca,_0x13809b,!0x0);let _0x393076;if(_0x16d7ca['_queryParams']['loadsAllData']())_0x393076=$t(_0x51457f['serverSyncTree_'],_0x16d7ca['_path'],_0x18c12e);else{const _0x1ff2a3=Mt(_0x51457f['serverSyncTree_'],_0x16d7ca);_0x393076=Yo(_0x51457f['serverSyncTree_'],_0x16d7ca['_path'],_0x18c12e,_0x1ff2a3);}return V(_0x51457f['eventQueue_'],_0x16d7ca['_path'],_0x393076),wn(_0x51457f['serverSyncTree_'],_0x16d7ca,_0x13809b,null,!0x0),_0x18c12e;},_0xb03b3=>(ut(_0x51457f,'get\x20for\x20query\x20'+O(_0x16d7ca)+'\x20failed:\x20'+_0xb03b3),Promise['reject'](new Error(_0xb03b3))));}function Ed(_0x5ae963,_0x3cb28d,_0x558fb5,_0x329c82,_0x4acd9d){ut(_0x5ae963,'set',{'path':_0x3cb28d['toString'](),'value':_0x558fb5,'priority':_0x329c82});const _0x536e25=jt(_0x5ae963),_0x123a6e=N(_0x558fb5,_0x329c82),_0x1ac4ed=xn(_0x5ae963['serverSyncTree_'],_0x3cb28d),_0x2e4b2e=hs(_0x123a6e,_0x1ac4ed,_0x536e25),_0x3a5c72=Vn(_0x5ae963),_0x3dc385=ss(_0x5ae963['serverSyncTree_'],_0x3cb28d,_0x2e4b2e,_0x3a5c72,!0x0);Bn(_0x5ae963['eventQueue_'],_0x3dc385),_0x5ae963['server_']['put'](_0x3cb28d['toString'](),_0x123a6e['val'](!0x0),(_0x289df2,_0x425b00)=>{const _0xed7533=_0x289df2==='ok';_0xed7533||U('set\x20at\x20'+_0x3cb28d+'\x20failed:\x20'+_0x289df2);const _0x10041c=pe(_0x5ae963['serverSyncTree_'],_0x3a5c72,!_0xed7533);V(_0x5ae963['eventQueue_'],_0x3cb28d,_0x10041c),Ai(_0x5ae963,_0x4acd9d,_0x289df2,_0x425b00);});const _0x17b349=vs(_0x5ae963,_0x3cb28d);st(_0x5ae963,_0x17b349),V(_0x5ae963['eventQueue_'],_0x17b349,[]);}function Id(_0x3bb061,_0x5336fd,_0x503eb0,_0x443755){ut(_0x3bb061,'update',{'path':_0x5336fd['toString'](),'value':_0x503eb0});let _0x3e8f49=!0x0;const _0x43095f=jt(_0x3bb061),_0x427828={};if(x(_0x503eb0,(_0x5435e8,_0x191fcb)=>{_0x3e8f49=!0x1,_0x427828[_0x5435e8]=Zo(A(_0x5336fd,_0x5435e8),N(_0x191fcb),_0x3bb061['serverSyncTree_'],_0x43095f);}),_0x3e8f49)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x3bb061,_0x443755,'ok',void 0x0);else{const _0x2cdc6b=Vn(_0x3bb061),_0x59982c=Gu(_0x3bb061['serverSyncTree_'],_0x5336fd,_0x427828,_0x2cdc6b);Bn(_0x3bb061['eventQueue_'],_0x59982c),_0x3bb061['server_']['merge'](_0x5336fd['toString'](),_0x503eb0,(_0x51d0a4,_0x1d14fc)=>{const _0x39143c=_0x51d0a4==='ok';_0x39143c||U('update\x20at\x20'+_0x5336fd+'\x20failed:\x20'+_0x51d0a4);const _0xf78545=pe(_0x3bb061['serverSyncTree_'],_0x2cdc6b,!_0x39143c),_0x97bf70=_0xf78545['length']>0x0?st(_0x3bb061,_0x5336fd):_0x5336fd;V(_0x3bb061['eventQueue_'],_0x97bf70,_0xf78545),Ai(_0x3bb061,_0x443755,_0x51d0a4,_0x1d14fc);}),x(_0x503eb0,_0xd6a96=>{const _0xb06f2d=vs(_0x3bb061,A(_0x5336fd,_0xd6a96));st(_0x3bb061,_0xb06f2d);}),V(_0x3bb061['eventQueue_'],_0x5336fd,[]);}}function wd(_0x2200f7){ut(_0x2200f7,'onDisconnectEvents');const _0x44802e=jt(_0x2200f7),_0x17a086=pn();Ei(_0x2200f7['onDisconnect_'],w(),(_0x3c689e,_0x4fee90)=>{const _0x36eac4=Zo(_0x3c689e,_0x4fee90,_0x2200f7['serverSyncTree_'],_0x44802e);Mo(_0x17a086,_0x3c689e,_0x36eac4);});let _0x3ff278=[];Ei(_0x17a086,w(),(_0x1fc83b,_0x4238cd)=>{_0x3ff278=_0x3ff278['concat']($t(_0x2200f7['serverSyncTree_'],_0x1fc83b,_0x4238cd));const _0x165887=vs(_0x2200f7,_0x1fc83b);st(_0x2200f7,_0x165887);}),_0x2200f7['onDisconnect_']=pn(),V(_0x2200f7['eventQueue_'],w(),_0x3ff278);}function Cd(_0x3bc9ea,_0x131dd8,_0xd09a48){let _0x15a9d0;y(_0x131dd8['_path'])==='.info'?_0x15a9d0=bi(_0x3bc9ea['infoSyncTree_'],_0x131dd8,_0xd09a48):_0x15a9d0=bi(_0x3bc9ea['serverSyncTree_'],_0x131dd8,_0xd09a48),ia(_0x3bc9ea['eventQueue_'],_0x131dd8['_path'],_0x15a9d0);}function Td(_0xfea7a5,_0x5e9e22,_0x397f9f){let _0x2cd9b0;y(_0x5e9e22['_path'])==='.info'?_0x2cd9b0=wn(_0xfea7a5['infoSyncTree_'],_0x5e9e22,_0x397f9f):_0x2cd9b0=wn(_0xfea7a5['serverSyncTree_'],_0x5e9e22,_0x397f9f),ia(_0xfea7a5['eventQueue_'],_0x5e9e22['_path'],_0x2cd9b0);}function aa(_0xb5a98d){_0xb5a98d['persistentConnection_']&&_0xb5a98d['persistentConnection_']['interrupt'](ra);}function Sd(_0x31d0cb){_0x31d0cb['persistentConnection_']&&_0x31d0cb['persistentConnection_']['resume'](ra);}function ut(_0x2a9d73,..._0x5a0441){let _0x378fa6='';_0x2a9d73['persistentConnection_']&&(_0x378fa6=_0x2a9d73['persistentConnection_']['id']+':'),L(_0x378fa6,..._0x5a0441);}function Ai(_0x577e39,_0x9020c4,_0x142804,_0x42c72c){_0x9020c4&&lt(()=>{if(_0x142804==='ok')_0x9020c4(null);else{const _0x325151=(_0x142804||'error')['toUpperCase']();let _0x771b64=_0x325151;_0x42c72c&&(_0x771b64+=':\x20'+_0x42c72c);const _0x465bff=new Error(_0x771b64);_0x465bff['code']=_0x325151,_0x9020c4(_0x465bff);}});}function bd(_0x56bf87,_0x38a1c3,_0x2ae8b4,_0x312eb8,_0x2a41ba,_0x285c06){ut(_0x56bf87,'transaction\x20on\x20'+_0x38a1c3);const _0x3a3d1b={'path':_0x38a1c3,'update':_0x2ae8b4,'onComplete':_0x312eb8,'status':null,'order':to(),'applyLocally':_0x285c06,'retryCount':0x0,'unwatcher':_0x2a41ba,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x13efac=ys(_0x56bf87,_0x38a1c3,void 0x0);_0x3a3d1b['currentInputSnapshot']=_0x13efac;const _0x36f641=_0x3a3d1b['update'](_0x13efac['val']());if(_0x36f641===void 0x0)_0x3a3d1b['unwatcher'](),_0x3a3d1b['currentOutputSnapshotRaw']=null,_0x3a3d1b['currentOutputSnapshotResolved']=null,_0x3a3d1b['onComplete']&&_0x3a3d1b['onComplete'](null,!0x1,_0x3a3d1b['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x36f641,_0x3a3d1b['path']),_0x3a3d1b['status']=0x0;const _0x30ab46=Un(_0x56bf87['transactionQueueTree_'],_0x38a1c3),_0x15e8ae=Ge(_0x30ab46)||[];_0x15e8ae['push'](_0x3a3d1b),fs(_0x30ab46,_0x15e8ae);let _0x4c0623;typeof _0x36f641=='object'&&_0x36f641!==null&&Y(_0x36f641,'.priority')?(_0x4c0623=Oe(_0x36f641,'.priority'),f(Cn(_0x4c0623),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4c0623=(xn(_0x56bf87['serverSyncTree_'],_0x38a1c3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x416756=jt(_0x56bf87),_0x472b38=N(_0x36f641,_0x4c0623),_0x58797a=hs(_0x472b38,_0x13efac,_0x416756);_0x3a3d1b['currentOutputSnapshotRaw']=_0x472b38,_0x3a3d1b['currentOutputSnapshotResolved']=_0x58797a,_0x3a3d1b['currentWriteId']=Vn(_0x56bf87);const _0x5f477e=ss(_0x56bf87['serverSyncTree_'],_0x38a1c3,_0x58797a,_0x3a3d1b['currentWriteId'],_0x3a3d1b['applyLocally']);V(_0x56bf87['eventQueue_'],_0x38a1c3,_0x5f477e),Hn(_0x56bf87,_0x56bf87['transactionQueueTree_']);}}function ys(_0x278559,_0x177010,_0x5237f4){return xn(_0x278559['serverSyncTree_'],_0x177010,_0x5237f4)||g['EMPTY_NODE'];}function Hn(_0x1b8303,_0x5d5ffe=_0x1b8303['transactionQueueTree_']){if(_0x5d5ffe||$n(_0x1b8303,_0x5d5ffe),Ge(_0x5d5ffe)){const _0x4e1e23=la(_0x1b8303,_0x5d5ffe);f(_0x4e1e23['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4e1e23['every'](_0x10d571=>_0x10d571['status']===0x0)&&Rd(_0x1b8303,Gt(_0x5d5ffe),_0x4e1e23);}else ea(_0x5d5ffe)&&Wn(_0x5d5ffe,_0x5ea1c4=>{Hn(_0x1b8303,_0x5ea1c4);});}function Rd(_0x5d0a5a,_0x9a4d6d,_0x304b84){const _0x11a12a=_0x304b84['map'](_0x2ab681=>_0x2ab681['currentWriteId']),_0x44988f=ys(_0x5d0a5a,_0x9a4d6d,_0x11a12a);let _0x12bdd5=_0x44988f;const _0x4f5018=_0x44988f['hash']();for(let _0x1ef2ea=0x0;_0x1ef2ea<_0x304b84['length'];_0x1ef2ea++){const _0x1e561b=_0x304b84[_0x1ef2ea];f(_0x1e561b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1e561b['status']=0x1,_0x1e561b['retryCount']++;const _0x19b76d=F(_0x9a4d6d,_0x1e561b['path']);_0x12bdd5=_0x12bdd5['updateChild'](_0x19b76d,_0x1e561b['currentOutputSnapshotRaw']);}const _0x4234ce=_0x12bdd5['val'](!0x0),_0x568020=_0x9a4d6d;_0x5d0a5a['server_']['put'](_0x568020['toString'](),_0x4234ce,_0x5dcab0=>{ut(_0x5d0a5a,'transaction\x20put\x20response',{'path':_0x568020['toString'](),'status':_0x5dcab0});let _0x1a1143=[];if(_0x5dcab0==='ok'){const _0x1dd253=[];for(let _0x315b1d=0x0;_0x315b1d<_0x304b84['length'];_0x315b1d++)_0x304b84[_0x315b1d]['status']=0x2,_0x1a1143=_0x1a1143['concat'](pe(_0x5d0a5a['serverSyncTree_'],_0x304b84[_0x315b1d]['currentWriteId'])),_0x304b84[_0x315b1d]['onComplete']&&_0x1dd253['push'](()=>_0x304b84[_0x315b1d]['onComplete'](null,!0x0,_0x304b84[_0x315b1d]['currentOutputSnapshotResolved'])),_0x304b84[_0x315b1d]['unwatcher']();$n(_0x5d0a5a,Un(_0x5d0a5a['transactionQueueTree_'],_0x9a4d6d)),Hn(_0x5d0a5a,_0x5d0a5a['transactionQueueTree_']),V(_0x5d0a5a['eventQueue_'],_0x9a4d6d,_0x1a1143);for(let _0x4a8a12=0x0;_0x4a8a12<_0x1dd253['length'];_0x4a8a12++)lt(_0x1dd253[_0x4a8a12]);}else{if(_0x5dcab0==='datastale'){for(let _0x2471cb=0x0;_0x2471cb<_0x304b84['length'];_0x2471cb++)_0x304b84[_0x2471cb]['status']===0x3?_0x304b84[_0x2471cb]['status']=0x4:_0x304b84[_0x2471cb]['status']=0x0;}else{U('transaction\x20at\x20'+_0x568020['toString']()+'\x20failed:\x20'+_0x5dcab0);for(let _0x5c1d9d=0x0;_0x5c1d9d<_0x304b84['length'];_0x5c1d9d++)_0x304b84[_0x5c1d9d]['status']=0x4,_0x304b84[_0x5c1d9d]['abortReason']=_0x5dcab0;}st(_0x5d0a5a,_0x9a4d6d);}},_0x4f5018);}function st(_0x885107,_0x3e2d51){const _0x1831a9=ca(_0x885107,_0x3e2d51),_0x80099d=Gt(_0x1831a9),_0x42885f=la(_0x885107,_0x1831a9);return Ad(_0x885107,_0x42885f,_0x80099d),_0x80099d;}function Ad(_0x1318af,_0x1af4b0,_0x13f2f0){if(_0x1af4b0['length']===0x0)return;const _0x6d29de=[];let _0x4f111c=[];const _0x1e1124=_0x1af4b0['filter'](_0x321d9f=>_0x321d9f['status']===0x0)['map'](_0xdecaa9=>_0xdecaa9['currentWriteId']);for(let _0x56b9fe=0x0;_0x56b9fe<_0x1af4b0['length'];_0x56b9fe++){const _0x4d1f47=_0x1af4b0[_0x56b9fe],_0x35e9ca=F(_0x13f2f0,_0x4d1f47['path']);let _0x123fd5=!0x1,_0x42fdc9;if(f(_0x35e9ca!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4d1f47['status']===0x4)_0x123fd5=!0x0,_0x42fdc9=_0x4d1f47['abortReason'],_0x4f111c=_0x4f111c['concat'](pe(_0x1318af['serverSyncTree_'],_0x4d1f47['currentWriteId'],!0x0));else{if(_0x4d1f47['status']===0x0){if(_0x4d1f47['retryCount']>=_d)_0x123fd5=!0x0,_0x42fdc9='maxretry',_0x4f111c=_0x4f111c['concat'](pe(_0x1318af['serverSyncTree_'],_0x4d1f47['currentWriteId'],!0x0));else{const _0x51c834=ys(_0x1318af,_0x4d1f47['path'],_0x1e1124);_0x4d1f47['currentInputSnapshot']=_0x51c834;const _0x293866=_0x1af4b0[_0x56b9fe]['update'](_0x51c834['val']());if(_0x293866!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x293866,_0x4d1f47['path']);let _0x33906f=N(_0x293866);typeof _0x293866=='object'&&_0x293866!=null&&Y(_0x293866,'.priority')||(_0x33906f=_0x33906f['updatePriority'](_0x51c834['getPriority']()));const _0x298c20=_0x4d1f47['currentWriteId'],_0x5ecdb6=jt(_0x1318af),_0x157eb0=hs(_0x33906f,_0x51c834,_0x5ecdb6);_0x4d1f47['currentOutputSnapshotRaw']=_0x33906f,_0x4d1f47['currentOutputSnapshotResolved']=_0x157eb0,_0x4d1f47['currentWriteId']=Vn(_0x1318af),_0x1e1124['splice'](_0x1e1124['indexOf'](_0x298c20),0x1),_0x4f111c=_0x4f111c['concat'](ss(_0x1318af['serverSyncTree_'],_0x4d1f47['path'],_0x157eb0,_0x4d1f47['currentWriteId'],_0x4d1f47['applyLocally'])),_0x4f111c=_0x4f111c['concat'](pe(_0x1318af['serverSyncTree_'],_0x298c20,!0x0));}else _0x123fd5=!0x0,_0x42fdc9='nodata',_0x4f111c=_0x4f111c['concat'](pe(_0x1318af['serverSyncTree_'],_0x4d1f47['currentWriteId'],!0x0));}}}V(_0x1318af['eventQueue_'],_0x13f2f0,_0x4f111c),_0x4f111c=[],_0x123fd5&&(_0x1af4b0[_0x56b9fe]['status']=0x2,function(_0x2487c8){setTimeout(_0x2487c8,Math['floor'](0x0));}(_0x1af4b0[_0x56b9fe]['unwatcher']),_0x1af4b0[_0x56b9fe]['onComplete']&&(_0x42fdc9==='nodata'?_0x6d29de['push'](()=>_0x1af4b0[_0x56b9fe]['onComplete'](null,!0x1,_0x1af4b0[_0x56b9fe]['currentInputSnapshot'])):_0x6d29de['push'](()=>_0x1af4b0[_0x56b9fe]['onComplete'](new Error(_0x42fdc9),!0x1,null))));}$n(_0x1318af,_0x1318af['transactionQueueTree_']);for(let _0x344ff7=0x0;_0x344ff7<_0x6d29de['length'];_0x344ff7++)lt(_0x6d29de[_0x344ff7]);Hn(_0x1318af,_0x1318af['transactionQueueTree_']);}function ca(_0x2e9030,_0xf6a34){let _0x276717,_0x4d6d1b=_0x2e9030['transactionQueueTree_'];for(_0x276717=y(_0xf6a34);_0x276717!==null&&Ge(_0x4d6d1b)===void 0x0;)_0x4d6d1b=Un(_0x4d6d1b,_0x276717),_0xf6a34=b(_0xf6a34),_0x276717=y(_0xf6a34);return _0x4d6d1b;}function la(_0x2d21ff,_0x382edf){const _0x365e1=[];return ha(_0x2d21ff,_0x382edf,_0x365e1),_0x365e1['sort']((_0x5c40ff,_0x14a7a0)=>_0x5c40ff['order']-_0x14a7a0['order']),_0x365e1;}function ha(_0x5e2893,_0x4afcec,_0x32401f){const _0x48d424=Ge(_0x4afcec);if(_0x48d424){for(let _0x2b34a5=0x0;_0x2b34a5<_0x48d424['length'];_0x2b34a5++)_0x32401f['push'](_0x48d424[_0x2b34a5]);}Wn(_0x4afcec,_0x475ec7=>{ha(_0x5e2893,_0x475ec7,_0x32401f);});}function $n(_0x3d0121,_0x452737){const _0x53a69e=Ge(_0x452737);if(_0x53a69e){let _0x59f511=0x0;for(let _0xac3e25=0x0;_0xac3e25<_0x53a69e['length'];_0xac3e25++)_0x53a69e[_0xac3e25]['status']!==0x2&&(_0x53a69e[_0x59f511]=_0x53a69e[_0xac3e25],_0x59f511++);_0x53a69e['length']=_0x59f511,fs(_0x452737,_0x53a69e['length']>0x0?_0x53a69e:void 0x0);}Wn(_0x452737,_0x5109ad=>{$n(_0x3d0121,_0x5109ad);});}function vs(_0x525b87,_0x3ef397){const _0x58a987=Gt(ca(_0x525b87,_0x3ef397)),_0x294192=Un(_0x525b87['transactionQueueTree_'],_0x3ef397);return sd(_0x294192,_0x196c2e=>{ai(_0x525b87,_0x196c2e);}),ai(_0x525b87,_0x294192),ta(_0x294192,_0x2cffb5=>{ai(_0x525b87,_0x2cffb5);}),_0x58a987;}function ai(_0x2a39f6,_0x1a2765){const _0x551d1b=Ge(_0x1a2765);if(_0x551d1b){const _0x55b892=[];let _0x14215d=[],_0x497069=-0x1;for(let _0x5d8b95=0x0;_0x5d8b95<_0x551d1b['length'];_0x5d8b95++)_0x551d1b[_0x5d8b95]['status']===0x3||(_0x551d1b[_0x5d8b95]['status']===0x1?(f(_0x497069===_0x5d8b95-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x497069=_0x5d8b95,_0x551d1b[_0x5d8b95]['status']=0x3,_0x551d1b[_0x5d8b95]['abortReason']='set'):(f(_0x551d1b[_0x5d8b95]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x551d1b[_0x5d8b95]['unwatcher'](),_0x14215d=_0x14215d['concat'](pe(_0x2a39f6['serverSyncTree_'],_0x551d1b[_0x5d8b95]['currentWriteId'],!0x0)),_0x551d1b[_0x5d8b95]['onComplete']&&_0x55b892['push'](_0x551d1b[_0x5d8b95]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x497069===-0x1?fs(_0x1a2765,void 0x0):_0x551d1b['length']=_0x497069+0x1,V(_0x2a39f6['eventQueue_'],Gt(_0x1a2765),_0x14215d);for(let _0x47c2ca=0x0;_0x47c2ca<_0x55b892['length'];_0x47c2ca++)lt(_0x55b892[_0x47c2ca]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x15c26b){let _0x5d2627='';const _0x2e6e9c=_0x15c26b['split']('/');for(let _0x4af936=0x0;_0x4af936<_0x2e6e9c['length'];_0x4af936++)if(_0x2e6e9c[_0x4af936]['length']>0x0){let _0x5cd7df=_0x2e6e9c[_0x4af936];try{_0x5cd7df=decodeURIComponent(_0x5cd7df['replace'](/\+/g,'\x20'));}catch{}_0x5d2627+='/'+_0x5cd7df;}return _0x5d2627;}function Nd(_0x1a198e){const _0x21f886={};_0x1a198e['charAt'](0x0)==='?'&&(_0x1a198e=_0x1a198e['substring'](0x1));for(const _0x14d068 of _0x1a198e['split']('&')){if(_0x14d068['length']===0x0)continue;const _0x49573d=_0x14d068['split']('=');_0x49573d['length']===0x2?_0x21f886[decodeURIComponent(_0x49573d[0x0])]=decodeURIComponent(_0x49573d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x14d068+'\x27\x20in\x20query\x20\x27'+_0x1a198e+'\x27');}return _0x21f886;}const gr=function(_0x3d54ee,_0x334536){const _0x55341f=Pd(_0x3d54ee),_0x1a8a87=_0x55341f['namespace'];_0x55341f['domain']==='firebase.com'&&oe(_0x55341f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x1a8a87||_0x1a8a87==='undefined')&&_0x55341f['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x55341f['secure']||Bl();const _0x146143=_0x55341f['scheme']==='ws'||_0x55341f['scheme']==='wss';return{'repoInfo':new _o(_0x55341f['host'],_0x55341f['secure'],_0x1a8a87,_0x146143,_0x334536,'',_0x1a8a87!==_0x55341f['subdomain']),'path':new C(_0x55341f['pathString'])};},Pd=function(_0x71acd3){let _0x64e390='',_0x375199='',_0x22db32='',_0x1f82ef='',_0x48de3f='',_0x1cb7b8=!0x0,_0x1a27d0='https',_0x283e95=0x1bb;if(typeof _0x71acd3=='string'){let _0x2f406a=_0x71acd3['indexOf']('//');_0x2f406a>=0x0&&(_0x1a27d0=_0x71acd3['substring'](0x0,_0x2f406a-0x1),_0x71acd3=_0x71acd3['substring'](_0x2f406a+0x2));let _0x22d0d9=_0x71acd3['indexOf']('/');_0x22d0d9===-0x1&&(_0x22d0d9=_0x71acd3['length']);let _0x5f0068=_0x71acd3['indexOf']('?');_0x5f0068===-0x1&&(_0x5f0068=_0x71acd3['length']),_0x64e390=_0x71acd3['substring'](0x0,Math['min'](_0x22d0d9,_0x5f0068)),_0x22d0d9<_0x5f0068&&(_0x1f82ef=kd(_0x71acd3['substring'](_0x22d0d9,_0x5f0068)));const _0x56146f=Nd(_0x71acd3['substring'](Math['min'](_0x71acd3['length'],_0x5f0068)));_0x2f406a=_0x64e390['indexOf'](':'),_0x2f406a>=0x0?(_0x1cb7b8=_0x1a27d0==='https'||_0x1a27d0==='wss',_0x283e95=parseInt(_0x64e390['substring'](_0x2f406a+0x1),0xa)):_0x2f406a=_0x64e390['length'];const _0x5dc397=_0x64e390['slice'](0x0,_0x2f406a);if(_0x5dc397['toLowerCase']()==='localhost')_0x375199='localhost';else{if(_0x5dc397['split']('.')['length']<=0x2)_0x375199=_0x5dc397;else{const _0x49cb1f=_0x64e390['indexOf']('.');_0x22db32=_0x64e390['substring'](0x0,_0x49cb1f)['toLowerCase'](),_0x375199=_0x64e390['substring'](_0x49cb1f+0x1),_0x48de3f=_0x22db32;}}'ns'in _0x56146f&&(_0x48de3f=_0x56146f['ns']);}return{'host':_0x64e390,'port':_0x283e95,'domain':_0x375199,'subdomain':_0x22db32,'secure':_0x1cb7b8,'scheme':_0x1a27d0,'pathString':_0x1f82ef,'namespace':_0x48de3f};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x414079=0x0;const _0xe1af1a=[];return function(_0x364197){const _0x24d640=_0x364197===_0x414079;_0x414079=_0x364197;let _0x38fb3b;const _0x346cbe=new Array(0x8);for(_0x38fb3b=0x7;_0x38fb3b>=0x0;_0x38fb3b--)_0x346cbe[_0x38fb3b]=mr['charAt'](_0x364197%0x40),_0x364197=Math['floor'](_0x364197/0x40);f(_0x364197===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x174e0e=_0x346cbe['join']('');if(_0x24d640){for(_0x38fb3b=0xb;_0x38fb3b>=0x0&&_0xe1af1a[_0x38fb3b]===0x3f;_0x38fb3b--)_0xe1af1a[_0x38fb3b]=0x0;_0xe1af1a[_0x38fb3b]++;}else{for(_0x38fb3b=0x0;_0x38fb3b<0xc;_0x38fb3b++)_0xe1af1a[_0x38fb3b]=Math['floor'](Math['random']()*0x40);}for(_0x38fb3b=0x0;_0x38fb3b<0xc;_0x38fb3b++)_0x174e0e+=mr['charAt'](_0xe1af1a[_0x38fb3b]);return f(_0x174e0e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x174e0e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0xb0d90a,_0x2cd996,_0x969c67,_0x31e6fb){this['eventType']=_0xb0d90a,this['eventRegistration']=_0x2cd996,this['snapshot']=_0x969c67,this['prevName']=_0x31e6fb;}['getPath'](){const _0x3c6c47=this['snapshot']['ref'];return this['eventType']==='value'?_0x3c6c47['_path']:_0x3c6c47['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x19cc4e,_0x1442d7,_0x71290){this['eventRegistration']=_0x19cc4e,this['error']=_0x1442d7,this['path']=_0x71290;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x8d9867,_0x39c91e){this['snapshotCallback']=_0x8d9867,this['cancelCallback']=_0x39c91e;}['onValue'](_0x93a13,_0xd4920c){this['snapshotCallback']['call'](null,_0x93a13,_0xd4920c);}['onCancel'](_0x39f557){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x39f557);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4c3f62){return this['snapshotCallback']===_0x4c3f62['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4c3f62['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4c3f62['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x164ebc,_0x3bf266,_0x2bc80b,_0x338e67){this['_repo']=_0x164ebc,this['_path']=_0x3bf266,this['_queryParams']=_0x2bc80b,this['_orderByCalled']=_0x338e67;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x15eb52=nr(this['_queryParams']),_0x54a661=Bi(_0x15eb52);return _0x54a661==='{}'?'default':_0x54a661;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x2e136c){if(_0x2e136c=k(_0x2e136c),!(_0x2e136c instanceof be))return!0x1;const _0x2d52c1=this['_repo']===_0x2e136c['_repo'],_0x4102e8=qi(this['_path'],_0x2e136c['_path']),_0x33c03d=this['_queryIdentifier']===_0x2e136c['_queryIdentifier'];return _0x2d52c1&&_0x4102e8&&_0x33c03d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x452251,_0x19526f){if(_0x452251['_orderByCalled']===!0x0)throw new Error(_0x19526f+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x19966f){let _0x55bcf4=null,_0x1282bb=null;if(_0x19966f['hasStart']()&&(_0x55bcf4=_0x19966f['getIndexStartValue']()),_0x19966f['hasEnd']()&&(_0x1282bb=_0x19966f['getIndexEndValue']()),_0x19966f['getIndex']()===ye){const _0x27a9f4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x41c2f9='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x19966f['hasStart']()){if(_0x19966f['getIndexStartName']()!==xe)throw new Error(_0x27a9f4);if(typeof _0x55bcf4!='string')throw new Error(_0x41c2f9);}if(_0x19966f['hasEnd']()){if(_0x19966f['getIndexEndName']()!==Ie)throw new Error(_0x27a9f4);if(typeof _0x1282bb!='string')throw new Error(_0x41c2f9);}}else{if(_0x19966f['getIndex']()===R){if(_0x55bcf4!=null&&!Cn(_0x55bcf4)||_0x1282bb!=null&&!Cn(_0x1282bb))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x19966f['getIndex']()instanceof Ki||_0x19966f['getIndex']()===Po,'unknown\x20index\x20type.'),_0x55bcf4!=null&&typeof _0x55bcf4=='object'||_0x1282bb!=null&&typeof _0x1282bb=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0xb086a3){if(_0xb086a3['hasStart']()&&_0xb086a3['hasEnd']()&&_0xb086a3['hasLimit']()&&!_0xb086a3['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x331697,_0x50994b){super(_0x331697,_0x50994b,new Qi(),!0x1);}get['parent'](){const _0x5ddc04=To(this['_path']);return _0x5ddc04===null?null:new Z(this['_repo'],_0x5ddc04);}get['root'](){let _0x574d6b=this;for(;_0x574d6b['parent']!==null;)_0x574d6b=_0x574d6b['parent'];return _0x574d6b;}}class rt{constructor(_0x47b4f9,_0x4cd2d9,_0x24270b){this['_node']=_0x47b4f9,this['ref']=_0x4cd2d9,this['_index']=_0x24270b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4f975a){const _0x2b6831=new C(_0x4f975a),_0x1f7eca=Lt(this['ref'],_0x4f975a);return new rt(this['_node']['getChild'](_0x2b6831),_0x1f7eca,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1f7c92){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3a8410,_0x9a012)=>_0x1f7c92(new rt(_0x9a012,Lt(this['ref'],_0x3a8410),R)));}['hasChild'](_0x34c68e){const _0x4223e3=new C(_0x34c68e);return!this['_node']['getChild'](_0x4223e3)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x27907b,_0x25c149){return _0x27907b=k(_0x27907b),_0x27907b['_checkNotDeleted']('ref'),_0x25c149!==void 0x0?Lt(_0x27907b['_root'],_0x25c149):_0x27907b['_root'];}function Lt(_0x25b605,_0x2a7b89){return _0x25b605=k(_0x25b605),y(_0x25b605['_path'])===null?ud('child','path',_0x2a7b89):_s('child','path',_0x2a7b89),new Z(_0x25b605['_repo'],A(_0x25b605['_path'],_0x2a7b89));}function d_(_0x2a25d9,_0x14b284){_0x2a25d9=k(_0x2a25d9),gs('push',_0x2a25d9['_path']),qt('push',_0x14b284,_0x2a25d9['_path'],!0x0);const _0x442cf4=oa(_0x2a25d9['_repo']),_0x6128c=Od(_0x442cf4),_0x4cb174=Lt(_0x2a25d9,_0x6128c),_0x57d766=Lt(_0x2a25d9,_0x6128c);let _0x40ef85;return _0x14b284!=null?_0x40ef85=Ld(_0x57d766,_0x14b284)['then'](()=>_0x57d766):_0x40ef85=Promise['resolve'](_0x57d766),_0x4cb174['then']=_0x40ef85['then']['bind'](_0x40ef85),_0x4cb174['catch']=_0x40ef85['then']['bind'](_0x40ef85,void 0x0),_0x4cb174;}function Ld(_0x4267a4,_0x2e29ca){_0x4267a4=k(_0x4267a4),gs('set',_0x4267a4['_path']),qt('set',_0x2e29ca,_0x4267a4['_path'],!0x1);const _0x25a0e6=new Ve();return Ed(_0x4267a4['_repo'],_0x4267a4['_path'],_0x2e29ca,null,_0x25a0e6['wrapCallback'](()=>{})),_0x25a0e6['promise'];}function f_(_0x313cd5,_0x518158){hd('update',_0x518158,_0x313cd5['_path']);const _0x33e59b=new Ve();return Id(_0x313cd5['_repo'],_0x313cd5['_path'],_0x518158,_0x33e59b['wrapCallback'](()=>{})),_0x33e59b['promise'];}function p_(_0x263475){_0x263475=k(_0x263475);const _0x413ec3=new ua(()=>{}),_0x37a01c=new qn(_0x413ec3);return vd(_0x263475['_repo'],_0x263475,_0x37a01c)['then'](_0x2fda92=>new rt(_0x2fda92,new Z(_0x263475['_repo'],_0x263475['_path']),_0x263475['_queryParams']['getIndex']()));}class qn{constructor(_0x347717){this['callbackContext']=_0x347717;}['respondsTo'](_0x28043c){return _0x28043c==='value';}['createEvent'](_0x5b0dde,_0x1c21cd){const _0x259e24=_0x1c21cd['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x5b0dde['snapshotNode'],new Z(_0x1c21cd['_repo'],_0x1c21cd['_path']),_0x259e24));}['getEventRunner'](_0x9aa728){return _0x9aa728['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x9aa728['error']):()=>this['callbackContext']['onValue'](_0x9aa728['snapshot'],null);}['createCancelEvent'](_0x2badf7,_0x11b8ad){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x2badf7,_0x11b8ad):null;}['matches'](_0x296259){return _0x296259 instanceof qn?!_0x296259['callbackContext']||!this['callbackContext']?!0x0:_0x296259['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x5e1103,_0x37e10f,_0x4bc0b0,_0x42b396,_0x275e59){const _0x362a07=new ua(_0x4bc0b0,void 0x0),_0x5cd94b=new qn(_0x362a07);return Cd(_0x5e1103['_repo'],_0x5e1103,_0x5cd94b),()=>Td(_0x5e1103['_repo'],_0x5e1103,_0x5cd94b);}function Fd(_0x168c04,_0x52db32,_0x3adc89,_0x5a76ac){return xd(_0x168c04,'value',_0x52db32);}class dt{}class pa extends dt{constructor(_0x2188e8,_0x41ed02){super(),this['_value']=_0x2188e8,this['_key']=_0x41ed02,this['type']='endAt';}['_apply'](_0x850a93){qt('endAt',this['_value'],_0x850a93['_path'],!0x0);const _0x38299c=Kh(_0x850a93['_queryParams'],this['_value'],this['_key']);if(fa(_0x38299c),Gn(_0x38299c),_0x850a93['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x850a93['_repo'],_0x850a93['_path'],_0x38299c,_0x850a93['_orderByCalled']);}}function __(_0x174d67,_0x384d44){return new pa(_0x174d67,_0x384d44);}class _a extends dt{constructor(_0x22b880,_0xd433da){super(),this['_value']=_0x22b880,this['_key']=_0xd433da,this['type']='startAt';}['_apply'](_0xec4351){qt('startAt',this['_value'],_0xec4351['_path'],!0x0);const _0x1d22bd=jh(_0xec4351['_queryParams'],this['_value'],this['_key']);if(fa(_0x1d22bd),Gn(_0x1d22bd),_0xec4351['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0xec4351['_repo'],_0xec4351['_path'],_0x1d22bd,_0xec4351['_orderByCalled']);}}function g_(_0x2c07cf=null,_0xea2185){return new _a(_0x2c07cf,_0xea2185);}class Ud extends dt{constructor(_0x1ccffb){super(),this['_limit']=_0x1ccffb,this['type']='limitToFirst';}['_apply'](_0x5bcae6){if(_0x5bcae6['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x5bcae6['_repo'],_0x5bcae6['_path'],zh(_0x5bcae6['_queryParams'],this['_limit']),_0x5bcae6['_orderByCalled']);}}function m_(_0x1e84a1){if(Math['floor'](_0x1e84a1)!==_0x1e84a1||_0x1e84a1<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x1e84a1);}class Wd extends dt{constructor(_0x322f27){super(),this['_path']=_0x322f27,this['type']='orderByChild';}['_apply'](_0xf45229){da(_0xf45229,'orderByChild');const _0x43fdff=new C(this['_path']);if(v(_0x43fdff))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4e2c14=new Ki(_0x43fdff),_0x360c6d=Do(_0xf45229['_queryParams'],_0x4e2c14);return Gn(_0x360c6d),new be(_0xf45229['_repo'],_0xf45229['_path'],_0x360c6d,!0x0);}}function y_(_0x44f2b4){if(_0x44f2b4==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x44f2b4==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x44f2b4==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x44f2b4),new Wd(_0x44f2b4);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2beab0){da(_0x2beab0,'orderByKey');const _0x3ab668=Do(_0x2beab0['_queryParams'],ye);return Gn(_0x3ab668),new be(_0x2beab0['_repo'],_0x2beab0['_path'],_0x3ab668,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x3f2b30,_0x45aa69){super(),this['_value']=_0x3f2b30,this['_key']=_0x45aa69,this['type']='equalTo';}['_apply'](_0x21495e){if(qt('equalTo',this['_value'],_0x21495e['_path'],!0x1),_0x21495e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x21495e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x21495e));}}function E_(_0xcc8682,_0x10606c){return new Vd(_0xcc8682,_0x10606c);}function I_(_0xea7858,..._0x45db60){let _0x42f21c=k(_0xea7858);for(const _0x38a683 of _0x45db60)_0x42f21c=_0x38a683['_apply'](_0x42f21c);return _0x42f21c;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x6d1ca9,_0x1ba7aa,_0x543c51,_0x11a380){const _0x37930d=_0x1ba7aa['lastIndexOf'](':'),_0x6367c8=_0x1ba7aa['substring'](0x0,_0x37930d),_0x524a8f=Wt(_0x6367c8);_0x6d1ca9['repoInfo_']=new _o(_0x1ba7aa,_0x524a8f,_0x6d1ca9['repoInfo_']['namespace'],_0x6d1ca9['repoInfo_']['webSocketOnly'],_0x6d1ca9['repoInfo_']['nodeAdmin'],_0x6d1ca9['repoInfo_']['persistenceKey'],_0x6d1ca9['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x543c51),_0x11a380&&(_0x6d1ca9['authTokenProvider_']=_0x11a380);}function qd(_0x58a732,_0x6cc615,_0x4d97e9,_0x13efdf,_0x872a54){let _0x4f8865=_0x13efdf||_0x58a732['options']['databaseURL'];_0x4f8865===void 0x0&&(_0x58a732['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x58a732['options']['projectId']),_0x4f8865=_0x58a732['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x24cc49=gr(_0x4f8865,_0x872a54),_0x330698=_0x24cc49['repoInfo'],_0x1c50c3;typeof process<'u'&&Us&&(_0x1c50c3=Us[Hd]),_0x1c50c3?(_0x4f8865='http://'+_0x1c50c3+'?ns='+_0x330698['namespace'],_0x24cc49=gr(_0x4f8865,_0x872a54),_0x330698=_0x24cc49['repoInfo']):_0x24cc49['repoInfo']['secure'];const _0x4b2fe2=new Jl(_0x58a732['name'],_0x58a732['options'],_0x6cc615);dd('Invalid\x20Firebase\x20Database\x20URL',_0x24cc49),v(_0x24cc49['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x577c52=jd(_0x330698,_0x58a732,_0x4b2fe2,new Ql(_0x58a732,_0x4d97e9));return new Kd(_0x577c52,_0x58a732);}function zd(_0xcd5117,_0x36194f){const _0x278e27=ki[_0x36194f];(!_0x278e27||_0x278e27[_0xcd5117['key']]!==_0xcd5117)&&oe('Database\x20'+_0x36194f+'('+_0xcd5117['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0xcd5117),delete _0x278e27[_0xcd5117['key']];}function jd(_0x1001b4,_0x20f802,_0x653c54,_0x2f88cd){let _0x229d97=ki[_0x20f802['name']];_0x229d97||(_0x229d97={},ki[_0x20f802['name']]=_0x229d97);let _0xc722c5=_0x229d97[_0x1001b4['toURLString']()];return _0xc722c5&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0xc722c5=new gd(_0x1001b4,$d,_0x653c54,_0x2f88cd),_0x229d97[_0x1001b4['toURLString']()]=_0xc722c5,_0xc722c5;}class Kd{constructor(_0x11551e,_0x3878f8){this['_repoInternal']=_0x11551e,this['app']=_0x3878f8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3527ee){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x3527ee+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x111a77=Qr(),_0x2fb04f){const _0x37d6ba=Ui(_0x111a77,'database')['getImmediate']({'identifier':_0x2fb04f});if(!_0x37d6ba['_instanceStarted']){const _0x32794f=ac('database');_0x32794f&&Yd(_0x37d6ba,..._0x32794f);}return _0x37d6ba;}function Yd(_0x5337f6,_0x2802e6,_0x571e20,_0x204a14={}){_0x5337f6=k(_0x5337f6),_0x5337f6['_checkNotDeleted']('useEmulator');const _0x8ad8b6=_0x2802e6+':'+_0x571e20,_0x5ad2d8=_0x5337f6['_repoInternal'];if(_0x5337f6['_instanceStarted']){if(_0x8ad8b6===_0x5337f6['_repoInternal']['repoInfo_']['host']&&De(_0x204a14,_0x5ad2d8['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x41c6c7;if(_0x5ad2d8['repoInfo_']['nodeAdmin'])_0x204a14['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x41c6c7=new tn(tn['OWNER']);else{if(_0x204a14['mockUserToken']){const _0x5399c1=typeof _0x204a14['mockUserToken']=='string'?_0x204a14['mockUserToken']:cc(_0x204a14['mockUserToken'],_0x5337f6['app']['options']['projectId']);_0x41c6c7=new tn(_0x5399c1);}}Wt(_0x2802e6)&&jr(_0x2802e6),Gd(_0x5ad2d8,_0x8ad8b6,_0x204a14,_0x41c6c7);}function C_(_0xda3e6e){_0xda3e6e=k(_0xda3e6e),_0xda3e6e['_checkNotDeleted']('goOffline'),aa(_0xda3e6e['_repo']);}function T_(_0x18084a){_0x18084a=k(_0x18084a),_0x18084a['_checkNotDeleted']('goOnline'),Sd(_0x18084a['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x5e9f7f){Ll(ct),et(new Me('database',(_0x4acfa6,{instanceIdentifier:_0x4b9460})=>{const _0x43a62f=_0x4acfa6['getProvider']('app')['getImmediate'](),_0x4bf1b3=_0x4acfa6['getProvider']('auth-internal'),_0x42d7e5=_0x4acfa6['getProvider']('app-check-internal');return qd(_0x43a62f,_0x4bf1b3,_0x42d7e5,_0x4b9460);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x5e9f7f),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x20ae0a,_0x56bca2){this['committed']=_0x20ae0a,this['snapshot']=_0x56bca2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x11aa03,_0x3c98a6,_0x2caad3){if(_0x11aa03=k(_0x11aa03),gs('Reference.transaction',_0x11aa03['_path']),_0x11aa03['key']==='.length'||_0x11aa03['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x11aa03['key']+'\x20is\x20a\x20read-only\x20object.';const _0xa0c648=!0x0,_0x431298=new Ve(),_0x3ed7ce=(_0x29d6ed,_0x333d7c,_0x3db975)=>{let _0x371553=null;_0x29d6ed?_0x431298['reject'](_0x29d6ed):(_0x371553=new rt(_0x3db975,new Z(_0x11aa03['_repo'],_0x11aa03['_path']),R),_0x431298['resolve'](new Xd(_0x333d7c,_0x371553)));},_0x105220=Fd(_0x11aa03,()=>{});return bd(_0x11aa03['_repo'],_0x11aa03['_path'],_0x3c98a6,_0x3ed7ce,_0x105220,_0xa0c648),_0x431298['promise'];}ie['prototype']['simpleListen']=function(_0x108b02,_0x19bdab){this['sendRequest']('q',{'p':_0x108b02},_0x19bdab);},ie['prototype']['echo']=function(_0x5c4766,_0x32be8e){this['sendRequest']('echo',{'d':_0x5c4766},_0x32be8e);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x6bdae0,..._0x86444f){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x6bdae0,..._0x86444f);}function nn(_0x3ed41d,..._0x1c443f){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x3ed41d,..._0x1c443f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x22c19e,..._0x16bc2f){throw Es(_0x22c19e,..._0x16bc2f);}function J(_0x4cb343,..._0x667776){return Es(_0x4cb343,..._0x667776);}function ya(_0x223f5e,_0x278b6a,_0x37a231){const _0x5c8a27={...Zd(),[_0x278b6a]:_0x37a231};return new Ut('auth','Firebase',_0x5c8a27)['create'](_0x278b6a,{'appName':_0x223f5e['name']});}function se(_0x5def53){return ya(_0x5def53,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x207506,..._0x4a0845){if(typeof _0x207506!='string'){const _0x937190=_0x4a0845[0x0],_0x9902b6=[..._0x4a0845['slice'](0x1)];return _0x9902b6[0x0]&&(_0x9902b6[0x0]['appName']=_0x207506['name']),_0x207506['_errorFactory']['create'](_0x937190,..._0x9902b6);}return ma['create'](_0x207506,..._0x4a0845);}function m(_0x4e5351,_0x3193af,..._0x1060a2){if(!_0x4e5351)throw Es(_0x3193af,..._0x1060a2);}function te(_0x5a6338){const _0x310f63='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5a6338;throw nn(_0x310f63),new Error(_0x310f63);}function ae(_0x5bd137,_0x2614d5){_0x5bd137||te(_0x2614d5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x5cd218;return typeof self<'u'&&((_0x5cd218=self['location'])==null?void 0x0:_0x5cd218['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x2d9724;return typeof self<'u'&&((_0x2d9724=self['location'])==null?void 0x0:_0x2d9724['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x2cac31=navigator;return _0x2cac31['languages']&&_0x2cac31['languages'][0x0]||_0x2cac31['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x45c80c,_0x12660b){this['shortDelay']=_0x45c80c,this['longDelay']=_0x12660b,ae(_0x12660b>_0x45c80c,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x4b7afa,_0x1f18e6){ae(_0x4b7afa['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x57a4a0}=_0x4b7afa['emulator'];return _0x1f18e6?''+_0x57a4a0+(_0x1f18e6['startsWith']('/')?_0x1f18e6['slice'](0x1):_0x1f18e6):_0x57a4a0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x548af5,_0x434f2d,_0x309f6d){this['fetchImpl']=_0x548af5,_0x434f2d&&(this['headersImpl']=_0x434f2d),_0x309f6d&&(this['responseImpl']=_0x309f6d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x3d72f2,_0x2f1475){return _0x3d72f2['tenantId']&&!_0x2f1475['tenantId']?{..._0x2f1475,'tenantId':_0x3d72f2['tenantId']}:_0x2f1475;}async function Ae(_0x83e94e,_0x27deba,_0x4e07c0,_0x3b0dcc,_0x17137a={}){return Ea(_0x83e94e,_0x17137a,async()=>{let _0x5b1aa9={},_0x38f7e0={};_0x3b0dcc&&(_0x27deba==='GET'?_0x38f7e0=_0x3b0dcc:_0x5b1aa9={'body':JSON['stringify'](_0x3b0dcc)});const _0x5d73e8=at({..._0x38f7e0,'key':_0x83e94e['config']['apiKey']})['slice'](0x1),_0x3ecd27=await _0x83e94e['_getAdditionalHeaders']();_0x3ecd27['Content-Type']='application/json',_0x83e94e['languageCode']&&(_0x3ecd27['X-Firebase-Locale']=_0x83e94e['languageCode']);const _0x2e9ddd={'method':_0x27deba,'headers':_0x3ecd27,..._0x5b1aa9};return lc()||(_0x2e9ddd['referrerPolicy']='strict-origin-when-cross-origin'),_0x83e94e['emulatorConfig']&&Wt(_0x83e94e['emulatorConfig']['host'])&&(_0x2e9ddd['credentials']='include'),va['fetch']()(await Ia(_0x83e94e,_0x83e94e['config']['apiHost'],_0x4e07c0,_0x5d73e8),_0x2e9ddd);});}async function Ea(_0x2bed70,_0x31a8de,_0x23b4c0){_0x2bed70['_canInitEmulator']=!0x1;const _0x4271b2={...rf,..._0x31a8de};try{const _0x73ce65=new lf(_0x2bed70),_0x257a44=await Promise['race']([_0x23b4c0(),_0x73ce65['promise']]);_0x73ce65['clearNetworkTimeout']();const _0x39d6a2=await _0x257a44['json']();if('needConfirmation'in _0x39d6a2)throw en(_0x2bed70,'account-exists-with-different-credential',_0x39d6a2);if(_0x257a44['ok']&&!('errorMessage'in _0x39d6a2))return _0x39d6a2;{const _0x4378dd=_0x257a44['ok']?_0x39d6a2['errorMessage']:_0x39d6a2['error']['message'],[_0x34f652,_0x345e1f]=_0x4378dd['split']('\x20:\x20');if(_0x34f652==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x2bed70,'credential-already-in-use',_0x39d6a2);if(_0x34f652==='EMAIL_EXISTS')throw en(_0x2bed70,'email-already-in-use',_0x39d6a2);if(_0x34f652==='USER_DISABLED')throw en(_0x2bed70,'user-disabled',_0x39d6a2);const _0x3fc6e1=_0x4271b2[_0x34f652]||_0x34f652['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x345e1f)throw ya(_0x2bed70,_0x3fc6e1,_0x345e1f);K(_0x2bed70,_0x3fc6e1);}}catch(_0x137ad4){if(_0x137ad4 instanceof Se)throw _0x137ad4;K(_0x2bed70,'network-request-failed',{'message':String(_0x137ad4)});}}async function Yt(_0x1d4145,_0x3312ca,_0x20f148,_0x279e85,_0x3c6d16={}){const _0x90efa8=await Ae(_0x1d4145,_0x3312ca,_0x20f148,_0x279e85,_0x3c6d16);return'mfaPendingCredential'in _0x90efa8&&K(_0x1d4145,'multi-factor-auth-required',{'_serverResponse':_0x90efa8}),_0x90efa8;}async function Ia(_0x3e1e93,_0x5b0cd8,_0x2b4436,_0x9ca6c5){const _0x3f429c=''+_0x5b0cd8+_0x2b4436+'?'+_0x9ca6c5,_0x145548=_0x3e1e93,_0x34d42c=_0x145548['config']['emulator']?Is(_0x3e1e93['config'],_0x3f429c):_0x3e1e93['config']['apiScheme']+'://'+_0x3f429c;return of['includes'](_0x2b4436)&&(await _0x145548['_persistenceManagerAvailable'],_0x145548['_getPersistenceType']()==='COOKIE')?_0x145548['_getPersistence']()['_getFinalTarget'](_0x34d42c)['toString']():_0x34d42c;}function cf(_0x1ccf06){switch(_0x1ccf06){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4fecda){this['auth']=_0x4fecda,this['timer']=null,this['promise']=new Promise((_0x297390,_0x35a690)=>{this['timer']=setTimeout(()=>_0x35a690(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x3f9fb7,_0x5a5d70,_0x543664){const _0x1b2cb4={'appName':_0x3f9fb7['name']};_0x543664['email']&&(_0x1b2cb4['email']=_0x543664['email']),_0x543664['phoneNumber']&&(_0x1b2cb4['phoneNumber']=_0x543664['phoneNumber']);const _0x591b3c=J(_0x3f9fb7,_0x5a5d70,_0x1b2cb4);return _0x591b3c['customData']['_tokenResponse']=_0x543664,_0x591b3c;}function vr(_0x3a53f1){return _0x3a53f1!==void 0x0&&_0x3a53f1['enterprise']!==void 0x0;}class hf{constructor(_0x144d27){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x144d27['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x144d27['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x144d27['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3bb6a7){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x506a35 of this['recaptchaEnforcementState'])if(_0x506a35['provider']&&_0x506a35['provider']===_0x3bb6a7)return cf(_0x506a35['enforcementState']);return null;}['isProviderEnabled'](_0x1d9c36){return this['getProviderEnforcementState'](_0x1d9c36)==='ENFORCE'||this['getProviderEnforcementState'](_0x1d9c36)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x49b66d,_0x1ba28a){return Ae(_0x49b66d,'GET','/v2/recaptchaConfig',Re(_0x49b66d,_0x1ba28a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x17a9e8,_0x3f8cd9){return Ae(_0x17a9e8,'POST','/v1/accounts:delete',_0x3f8cd9);}async function Sn(_0x38e4c8,_0xb91f99){return Ae(_0x38e4c8,'POST','/v1/accounts:lookup',_0xb91f99);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x26ab89){if(_0x26ab89)try{const _0x5c7a1d=new Date(Number(_0x26ab89));if(!isNaN(_0x5c7a1d['getTime']()))return _0x5c7a1d['toUTCString']();}catch{}}async function ff(_0x21a073,_0x39ede8=!0x1){const _0x1dd525=k(_0x21a073),_0x32676c=await _0x1dd525['getIdToken'](_0x39ede8),_0x9bb6bd=ws(_0x32676c);m(_0x9bb6bd&&_0x9bb6bd['exp']&&_0x9bb6bd['auth_time']&&_0x9bb6bd['iat'],_0x1dd525['auth'],'internal-error');const _0x5eedb9=typeof _0x9bb6bd['firebase']=='object'?_0x9bb6bd['firebase']:void 0x0,_0x4f8002=_0x5eedb9==null?void 0x0:_0x5eedb9['sign_in_provider'];return{'claims':_0x9bb6bd,'token':_0x32676c,'authTime':St(ci(_0x9bb6bd['auth_time'])),'issuedAtTime':St(ci(_0x9bb6bd['iat'])),'expirationTime':St(ci(_0x9bb6bd['exp'])),'signInProvider':_0x4f8002||null,'signInSecondFactor':(_0x5eedb9==null?void 0x0:_0x5eedb9['sign_in_second_factor'])||null};}function ci(_0x4fa887){return Number(_0x4fa887)*0x3e8;}function ws(_0x1bdb1c){const [_0x5aacde,_0x2cc364,_0x4add7d]=_0x1bdb1c['split']('.');if(_0x5aacde===void 0x0||_0x2cc364===void 0x0||_0x4add7d===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x455931=cn(_0x2cc364);return _0x455931?JSON['parse'](_0x455931):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5110fc){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5110fc==null?void 0x0:_0x5110fc['toString']()),null;}}function Er(_0x43b7e3){const _0xc75a94=ws(_0x43b7e3);return m(_0xc75a94,'internal-error'),m(typeof _0xc75a94['exp']<'u','internal-error'),m(typeof _0xc75a94['iat']<'u','internal-error'),Number(_0xc75a94['exp'])-Number(_0xc75a94['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x6e0b48,_0x21a078,_0x5d5886=!0x1){if(_0x5d5886)return _0x21a078;try{return await _0x21a078;}catch(_0x53fece){throw _0x53fece instanceof Se&&pf(_0x53fece)&&_0x6e0b48['auth']['currentUser']===_0x6e0b48&&await _0x6e0b48['auth']['signOut'](),_0x53fece;}}function pf({code:_0x524859}){return _0x524859==='auth/user-disabled'||_0x524859==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x37e246){this['user']=_0x37e246,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2dd463){if(_0x2dd463){const _0x24bf39=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x24bf39;}else{this['errorBackoff']=0x7530;const _0x563214=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x563214);}}['schedule'](_0x1823a3=!0x1){if(!this['isRunning'])return;const _0x55ead7=this['getInterval'](_0x1823a3);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x55ead7);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x33a76c){(_0x33a76c==null?void 0x0:_0x33a76c['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0xc5d475,_0x45c10e){this['createdAt']=_0xc5d475,this['lastLoginAt']=_0x45c10e,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x3d6084){this['createdAt']=_0x3d6084['createdAt'],this['lastLoginAt']=_0x3d6084['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x29fab0){var _0x45773f;const _0x5288af=_0x29fab0['auth'],_0x335369=await _0x29fab0['getIdToken'](),_0x4c845b=await xt(_0x29fab0,Sn(_0x5288af,{'idToken':_0x335369}));m(_0x4c845b==null?void 0x0:_0x4c845b['users']['length'],_0x5288af,'internal-error');const _0x5ed6ff=_0x4c845b['users'][0x0];_0x29fab0['_notifyReloadListener'](_0x5ed6ff);const _0xdc78e=(_0x45773f=_0x5ed6ff['providerUserInfo'])!=null&&_0x45773f['length']?wa(_0x5ed6ff['providerUserInfo']):[],_0x1f155e=mf(_0x29fab0['providerData'],_0xdc78e),_0x5d980a=_0x29fab0['isAnonymous'],_0x7f3e35=!(_0x29fab0['email']&&_0x5ed6ff['passwordHash'])&&!(_0x1f155e!=null&&_0x1f155e['length']),_0x24e3b6=_0x5d980a?_0x7f3e35:!0x1,_0x5893e2={'uid':_0x5ed6ff['localId'],'displayName':_0x5ed6ff['displayName']||null,'photoURL':_0x5ed6ff['photoUrl']||null,'email':_0x5ed6ff['email']||null,'emailVerified':_0x5ed6ff['emailVerified']||!0x1,'phoneNumber':_0x5ed6ff['phoneNumber']||null,'tenantId':_0x5ed6ff['tenantId']||null,'providerData':_0x1f155e,'metadata':new Pi(_0x5ed6ff['createdAt'],_0x5ed6ff['lastLoginAt']),'isAnonymous':_0x24e3b6};Object['assign'](_0x29fab0,_0x5893e2);}async function gf(_0x2472c9){const _0x3774d5=k(_0x2472c9);await bn(_0x3774d5),await _0x3774d5['auth']['_persistUserIfCurrent'](_0x3774d5),_0x3774d5['auth']['_notifyListenersIfCurrent'](_0x3774d5);}function mf(_0x34b869,_0xbe2652){return[..._0x34b869['filter'](_0x12619f=>!_0xbe2652['some'](_0x3c9441=>_0x3c9441['providerId']===_0x12619f['providerId'])),..._0xbe2652];}function wa(_0xae6d09){return _0xae6d09['map'](({providerId:_0x3950f3,..._0xacb9b9})=>({'providerId':_0x3950f3,'uid':_0xacb9b9['rawId']||'','displayName':_0xacb9b9['displayName']||null,'email':_0xacb9b9['email']||null,'phoneNumber':_0xacb9b9['phoneNumber']||null,'photoURL':_0xacb9b9['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x378d08,_0x1d3175){const _0x536722=await Ea(_0x378d08,{},async()=>{const _0x4e9d88=at({'grant_type':'refresh_token','refresh_token':_0x1d3175})['slice'](0x1),{tokenApiHost:_0x29ce63,apiKey:_0x2f7bf9}=_0x378d08['config'],_0x586c93=await Ia(_0x378d08,_0x29ce63,'/v1/token','key='+_0x2f7bf9),_0x33ec64=await _0x378d08['_getAdditionalHeaders']();_0x33ec64['Content-Type']='application/x-www-form-urlencoded';const _0x258eb6={'method':'POST','headers':_0x33ec64,'body':_0x4e9d88};return _0x378d08['emulatorConfig']&&Wt(_0x378d08['emulatorConfig']['host'])&&(_0x258eb6['credentials']='include'),va['fetch']()(_0x586c93,_0x258eb6);});return{'accessToken':_0x536722['access_token'],'expiresIn':_0x536722['expires_in'],'refreshToken':_0x536722['refresh_token']};}async function vf(_0x3bff2e,_0x57712f){return Ae(_0x3bff2e,'POST','/v2/accounts:revokeToken',Re(_0x3bff2e,_0x57712f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x32b11d){m(_0x32b11d['idToken'],'internal-error'),m(typeof _0x32b11d['idToken']<'u','internal-error'),m(typeof _0x32b11d['refreshToken']<'u','internal-error');const _0x3c4c87='expiresIn'in _0x32b11d&&typeof _0x32b11d['expiresIn']<'u'?Number(_0x32b11d['expiresIn']):Er(_0x32b11d['idToken']);this['updateTokensAndExpiration'](_0x32b11d['idToken'],_0x32b11d['refreshToken'],_0x3c4c87);}['updateFromIdToken'](_0x5cadfd){m(_0x5cadfd['length']!==0x0,'internal-error');const _0x173708=Er(_0x5cadfd);this['updateTokensAndExpiration'](_0x5cadfd,null,_0x173708);}async['getToken'](_0x50e585,_0xa90769=!0x1){return!_0xa90769&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x50e585,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x50e585,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x10a15e,_0x128b42){const {accessToken:_0x493b1d,refreshToken:_0x13ebea,expiresIn:_0x3a76a9}=await yf(_0x10a15e,_0x128b42);this['updateTokensAndExpiration'](_0x493b1d,_0x13ebea,Number(_0x3a76a9));}['updateTokensAndExpiration'](_0x3f2691,_0x585471,_0xddaf50){this['refreshToken']=_0x585471||null,this['accessToken']=_0x3f2691||null,this['expirationTime']=Date['now']()+_0xddaf50*0x3e8;}static['fromJSON'](_0x1910ba,_0x1381c0){const {refreshToken:_0x14e99b,accessToken:_0x5cdeed,expirationTime:_0x5032d2}=_0x1381c0,_0x41bceb=new Je();return _0x14e99b&&(m(typeof _0x14e99b=='string','internal-error',{'appName':_0x1910ba}),_0x41bceb['refreshToken']=_0x14e99b),_0x5cdeed&&(m(typeof _0x5cdeed=='string','internal-error',{'appName':_0x1910ba}),_0x41bceb['accessToken']=_0x5cdeed),_0x5032d2&&(m(typeof _0x5032d2=='number','internal-error',{'appName':_0x1910ba}),_0x41bceb['expirationTime']=_0x5032d2),_0x41bceb;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x57acf7){this['accessToken']=_0x57acf7['accessToken'],this['refreshToken']=_0x57acf7['refreshToken'],this['expirationTime']=_0x57acf7['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x2ee67c,_0x187d78){m(typeof _0x2ee67c=='string'||typeof _0x2ee67c>'u','internal-error',{'appName':_0x187d78});}class z{constructor({uid:_0x4ff794,auth:_0x472be8,stsTokenManager:_0x4258f9,..._0x398d76}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4ff794,this['auth']=_0x472be8,this['stsTokenManager']=_0x4258f9,this['accessToken']=_0x4258f9['accessToken'],this['displayName']=_0x398d76['displayName']||null,this['email']=_0x398d76['email']||null,this['emailVerified']=_0x398d76['emailVerified']||!0x1,this['phoneNumber']=_0x398d76['phoneNumber']||null,this['photoURL']=_0x398d76['photoURL']||null,this['isAnonymous']=_0x398d76['isAnonymous']||!0x1,this['tenantId']=_0x398d76['tenantId']||null,this['providerData']=_0x398d76['providerData']?[..._0x398d76['providerData']]:[],this['metadata']=new Pi(_0x398d76['createdAt']||void 0x0,_0x398d76['lastLoginAt']||void 0x0);}async['getIdToken'](_0x400dcd){const _0x41fd52=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x400dcd));return m(_0x41fd52,this['auth'],'internal-error'),this['accessToken']!==_0x41fd52&&(this['accessToken']=_0x41fd52,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x41fd52;}['getIdTokenResult'](_0x75c0c5){return ff(this,_0x75c0c5);}['reload'](){return gf(this);}['_assign'](_0x1dfc11){this!==_0x1dfc11&&(m(this['uid']===_0x1dfc11['uid'],this['auth'],'internal-error'),this['displayName']=_0x1dfc11['displayName'],this['photoURL']=_0x1dfc11['photoURL'],this['email']=_0x1dfc11['email'],this['emailVerified']=_0x1dfc11['emailVerified'],this['phoneNumber']=_0x1dfc11['phoneNumber'],this['isAnonymous']=_0x1dfc11['isAnonymous'],this['tenantId']=_0x1dfc11['tenantId'],this['providerData']=_0x1dfc11['providerData']['map'](_0x2a4832=>({..._0x2a4832})),this['metadata']['_copy'](_0x1dfc11['metadata']),this['stsTokenManager']['_assign'](_0x1dfc11['stsTokenManager']));}['_clone'](_0x337c91){const _0x4b91cb=new z({...this,'auth':_0x337c91,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4b91cb['metadata']['_copy'](this['metadata']),_0x4b91cb;}['_onReload'](_0x52ed8d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x52ed8d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5350ef){this['reloadListener']?this['reloadListener'](_0x5350ef):this['reloadUserInfo']=_0x5350ef;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x37b0cc,_0x2ad232=!0x1){let _0x2c10c8=!0x1;_0x37b0cc['idToken']&&_0x37b0cc['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x37b0cc),_0x2c10c8=!0x0),_0x2ad232&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x2c10c8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x438ec1=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x438ec1})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x6717b1=>({..._0x6717b1})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0xc2ec50,_0x29b75f){const _0x16877d=_0x29b75f['displayName']??void 0x0,_0x981bc8=_0x29b75f['email']??void 0x0,_0x5b61d6=_0x29b75f['phoneNumber']??void 0x0,_0x4c9635=_0x29b75f['photoURL']??void 0x0,_0x2473e8=_0x29b75f['tenantId']??void 0x0,_0xa77488=_0x29b75f['_redirectEventId']??void 0x0,_0x216184=_0x29b75f['createdAt']??void 0x0,_0x6b3b66=_0x29b75f['lastLoginAt']??void 0x0,{uid:_0x2c6ae6,emailVerified:_0x51ef3e,isAnonymous:_0x134b00,providerData:_0x33d675,stsTokenManager:_0xb67cb6}=_0x29b75f;m(_0x2c6ae6&&_0xb67cb6,_0xc2ec50,'internal-error');const _0x2029eb=Je['fromJSON'](this['name'],_0xb67cb6);m(typeof _0x2c6ae6=='string',_0xc2ec50,'internal-error'),ce(_0x16877d,_0xc2ec50['name']),ce(_0x981bc8,_0xc2ec50['name']),m(typeof _0x51ef3e=='boolean',_0xc2ec50,'internal-error'),m(typeof _0x134b00=='boolean',_0xc2ec50,'internal-error'),ce(_0x5b61d6,_0xc2ec50['name']),ce(_0x4c9635,_0xc2ec50['name']),ce(_0x2473e8,_0xc2ec50['name']),ce(_0xa77488,_0xc2ec50['name']),ce(_0x216184,_0xc2ec50['name']),ce(_0x6b3b66,_0xc2ec50['name']);const _0x311376=new z({'uid':_0x2c6ae6,'auth':_0xc2ec50,'email':_0x981bc8,'emailVerified':_0x51ef3e,'displayName':_0x16877d,'isAnonymous':_0x134b00,'photoURL':_0x4c9635,'phoneNumber':_0x5b61d6,'tenantId':_0x2473e8,'stsTokenManager':_0x2029eb,'createdAt':_0x216184,'lastLoginAt':_0x6b3b66});return _0x33d675&&Array['isArray'](_0x33d675)&&(_0x311376['providerData']=_0x33d675['map'](_0x59f77c=>({..._0x59f77c}))),_0xa77488&&(_0x311376['_redirectEventId']=_0xa77488),_0x311376;}static async['_fromIdTokenResponse'](_0x3c70cc,_0x307b5e,_0x5af4b5=!0x1){const _0x4d8972=new Je();_0x4d8972['updateFromServerResponse'](_0x307b5e);const _0x5b7516=new z({'uid':_0x307b5e['localId'],'auth':_0x3c70cc,'stsTokenManager':_0x4d8972,'isAnonymous':_0x5af4b5});return await bn(_0x5b7516),_0x5b7516;}static async['_fromGetAccountInfoResponse'](_0x5d15ce,_0x3243d4,_0x2956f4){const _0x4d3643=_0x3243d4['users'][0x0];m(_0x4d3643['localId']!==void 0x0,'internal-error');const _0x187f81=_0x4d3643['providerUserInfo']!==void 0x0?wa(_0x4d3643['providerUserInfo']):[],_0x1812df=!(_0x4d3643['email']&&_0x4d3643['passwordHash'])&&!(_0x187f81!=null&&_0x187f81['length']),_0x36b843=new Je();_0x36b843['updateFromIdToken'](_0x2956f4);const _0x178956=new z({'uid':_0x4d3643['localId'],'auth':_0x5d15ce,'stsTokenManager':_0x36b843,'isAnonymous':_0x1812df}),_0xd7205e={'uid':_0x4d3643['localId'],'displayName':_0x4d3643['displayName']||null,'photoURL':_0x4d3643['photoUrl']||null,'email':_0x4d3643['email']||null,'emailVerified':_0x4d3643['emailVerified']||!0x1,'phoneNumber':_0x4d3643['phoneNumber']||null,'tenantId':_0x4d3643['tenantId']||null,'providerData':_0x187f81,'metadata':new Pi(_0x4d3643['createdAt'],_0x4d3643['lastLoginAt']),'isAnonymous':!(_0x4d3643['email']&&_0x4d3643['passwordHash'])&&!(_0x187f81!=null&&_0x187f81['length'])};return Object['assign'](_0x178956,_0xd7205e),_0x178956;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x2f2cc5){ae(_0x2f2cc5 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x38e1bc=Ir['get'](_0x2f2cc5);return _0x38e1bc?(ae(_0x38e1bc instanceof _0x2f2cc5,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x38e1bc):(_0x38e1bc=new _0x2f2cc5(),Ir['set'](_0x2f2cc5,_0x38e1bc),_0x38e1bc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x754c93,_0x4bfa80){this['storage'][_0x754c93]=_0x4bfa80;}async['_get'](_0x5d08df){const _0x433410=this['storage'][_0x5d08df];return _0x433410===void 0x0?null:_0x433410;}async['_remove'](_0x120bc9){delete this['storage'][_0x120bc9];}['_addListener'](_0x178c75,_0x45be5c){}['_removeListener'](_0x356518,_0x341fc8){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x3c4cc5,_0x245f38,_0x6b508e){return'firebase:'+_0x3c4cc5+':'+_0x245f38+':'+_0x6b508e;}class Xe{constructor(_0x5d75b2,_0x522bb3,_0x435748){this['persistence']=_0x5d75b2,this['auth']=_0x522bb3,this['userKey']=_0x435748;const {config:_0xf49b8a,name:_0x23b1d4}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0xf49b8a['apiKey'],_0x23b1d4),this['fullPersistenceKey']=sn('persistence',_0xf49b8a['apiKey'],_0x23b1d4),this['boundEventHandler']=_0x522bb3['_onStorageEvent']['bind'](_0x522bb3),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x844807){return this['persistence']['_set'](this['fullUserKey'],_0x844807['toJSON']());}async['getCurrentUser'](){const _0x362aee=await this['persistence']['_get'](this['fullUserKey']);if(!_0x362aee)return null;if(typeof _0x362aee=='string'){const _0x10fa4f=await Sn(this['auth'],{'idToken':_0x362aee})['catch'](()=>{});return _0x10fa4f?z['_fromGetAccountInfoResponse'](this['auth'],_0x10fa4f,_0x362aee):null;}return z['_fromJSON'](this['auth'],_0x362aee);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x35d0f7){if(this['persistence']===_0x35d0f7)return;const _0x4e1663=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x35d0f7,_0x4e1663)return this['setCurrentUser'](_0x4e1663);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x40c516,_0x480e43,_0x300c06='authUser'){if(!_0x480e43['length'])return new Xe(ne(wr),_0x40c516,_0x300c06);const _0x58e429=(await Promise['all'](_0x480e43['map'](async _0x1b1d78=>{if(await _0x1b1d78['_isAvailable']())return _0x1b1d78;})))['filter'](_0x5b3561=>_0x5b3561);let _0x38963d=_0x58e429[0x0]||ne(wr);const _0x201259=sn(_0x300c06,_0x40c516['config']['apiKey'],_0x40c516['name']);let _0x4e0664=null;for(const _0xad7be3 of _0x480e43)try{const _0x5a392d=await _0xad7be3['_get'](_0x201259);if(_0x5a392d){let _0x2aa6c6;if(typeof _0x5a392d=='string'){const _0x5a4f66=await Sn(_0x40c516,{'idToken':_0x5a392d})['catch'](()=>{});if(!_0x5a4f66)break;_0x2aa6c6=await z['_fromGetAccountInfoResponse'](_0x40c516,_0x5a4f66,_0x5a392d);}else _0x2aa6c6=z['_fromJSON'](_0x40c516,_0x5a392d);_0xad7be3!==_0x38963d&&(_0x4e0664=_0x2aa6c6),_0x38963d=_0xad7be3;break;}}catch{}const _0x160f7a=_0x58e429['filter'](_0x4dd10a=>_0x4dd10a['_shouldAllowMigration']);return!_0x38963d['_shouldAllowMigration']||!_0x160f7a['length']?new Xe(_0x38963d,_0x40c516,_0x300c06):(_0x38963d=_0x160f7a[0x0],_0x4e0664&&await _0x38963d['_set'](_0x201259,_0x4e0664['toJSON']()),await Promise['all'](_0x480e43['map'](async _0xdb134e=>{if(_0xdb134e!==_0x38963d)try{await _0xdb134e['_remove'](_0x201259);}catch{}})),new Xe(_0x38963d,_0x40c516,_0x300c06));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x5176bc){const _0x5c5507=_0x5176bc['toLowerCase']();if(_0x5c5507['includes']('opera/')||_0x5c5507['includes']('opr/')||_0x5c5507['includes']('opios/'))return'Opera';if(Ra(_0x5c5507))return'IEMobile';if(_0x5c5507['includes']('msie')||_0x5c5507['includes']('trident/'))return'IE';if(_0x5c5507['includes']('edge/'))return'Edge';if(Ta(_0x5c5507))return'Firefox';if(_0x5c5507['includes']('silk/'))return'Silk';if(ka(_0x5c5507))return'Blackberry';if(Na(_0x5c5507))return'Webos';if(Sa(_0x5c5507))return'Safari';if((_0x5c5507['includes']('chrome/')||ba(_0x5c5507))&&!_0x5c5507['includes']('edge/'))return'Chrome';if(Aa(_0x5c5507))return'Android';{const _0x395297=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x462fe6=_0x5176bc['match'](_0x395297);if((_0x462fe6==null?void 0x0:_0x462fe6['length'])===0x2)return _0x462fe6[0x1];}return'Other';}function Ta(_0x12dcff=W()){return/firefox\//i['test'](_0x12dcff);}function Sa(_0x3f1a5a=W()){const _0x1a1231=_0x3f1a5a['toLowerCase']();return _0x1a1231['includes']('safari/')&&!_0x1a1231['includes']('chrome/')&&!_0x1a1231['includes']('crios/')&&!_0x1a1231['includes']('android');}function ba(_0x144cc5=W()){return/crios\//i['test'](_0x144cc5);}function Ra(_0x1a9967=W()){return/iemobile/i['test'](_0x1a9967);}function Aa(_0x44eedc=W()){return/android/i['test'](_0x44eedc);}function ka(_0xa8f095=W()){return/blackberry/i['test'](_0xa8f095);}function Na(_0x13b7d4=W()){return/webos/i['test'](_0x13b7d4);}function Cs(_0x22269b=W()){return/iphone|ipad|ipod/i['test'](_0x22269b)||/macintosh/i['test'](_0x22269b)&&/mobile/i['test'](_0x22269b);}function Ef(_0x52d8d0=W()){var _0x3dd1e4;return Cs(_0x52d8d0)&&!!((_0x3dd1e4=window['navigator'])!=null&&_0x3dd1e4['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x45f9e4=W()){return Cs(_0x45f9e4)||Aa(_0x45f9e4)||Na(_0x45f9e4)||ka(_0x45f9e4)||/windows phone/i['test'](_0x45f9e4)||Ra(_0x45f9e4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x42a398,_0x4a89a9=[]){let _0xcfd1dc;switch(_0x42a398){case'Browser':_0xcfd1dc=Cr(W());break;case'Worker':_0xcfd1dc=Cr(W())+'-'+_0x42a398;break;default:_0xcfd1dc=_0x42a398;}const _0x4fb7ca=_0x4a89a9['length']?_0x4a89a9['join'](','):'FirebaseCore-web';return _0xcfd1dc+'/JsCore/'+ct+'/'+_0x4fb7ca;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x24ac04){this['auth']=_0x24ac04,this['queue']=[];}['pushCallback'](_0x1ee9f7,_0x5daf2d){const _0x1a2f80=_0x2cb6ef=>new Promise((_0x3a71c5,_0x2d12b0)=>{try{const _0x1a19e3=_0x1ee9f7(_0x2cb6ef);_0x3a71c5(_0x1a19e3);}catch(_0x50cd6d){_0x2d12b0(_0x50cd6d);}});_0x1a2f80['onAbort']=_0x5daf2d,this['queue']['push'](_0x1a2f80);const _0x16c9a1=this['queue']['length']-0x1;return()=>{this['queue'][_0x16c9a1]=()=>Promise['resolve']();};}async['runMiddleware'](_0x56b52c){if(this['auth']['currentUser']===_0x56b52c)return;const _0x338bea=[];try{for(const _0x57e5c2 of this['queue'])await _0x57e5c2(_0x56b52c),_0x57e5c2['onAbort']&&_0x338bea['push'](_0x57e5c2['onAbort']);}catch(_0x35aafd){_0x338bea['reverse']();for(const _0x35d435 of _0x338bea)try{_0x35d435();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x35aafd==null?void 0x0:_0x35aafd['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x1a037d,_0x2bd177={}){return Ae(_0x1a037d,'GET','/v2/passwordPolicy',Re(_0x1a037d,_0x2bd177));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x37f232){var _0x51a849;const _0x54f78a=_0x37f232['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x54f78a['minPasswordLength']??Tf,_0x54f78a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x54f78a['maxPasswordLength']),_0x54f78a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x54f78a['containsLowercaseCharacter']),_0x54f78a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x54f78a['containsUppercaseCharacter']),_0x54f78a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x54f78a['containsNumericCharacter']),_0x54f78a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x54f78a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x37f232['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x51a849=_0x37f232['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x51a849['join'](''))??'',this['forceUpgradeOnSignin']=_0x37f232['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x37f232['schemaVersion'];}['validatePassword'](_0x43ff8a){const _0x4a6e57={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x43ff8a,_0x4a6e57),this['validatePasswordCharacterOptions'](_0x43ff8a,_0x4a6e57),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['meetsMinPasswordLength']??!0x0),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['meetsMaxPasswordLength']??!0x0),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['containsLowercaseLetter']??!0x0),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['containsUppercaseLetter']??!0x0),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['containsNumericCharacter']??!0x0),_0x4a6e57['isValid']&&(_0x4a6e57['isValid']=_0x4a6e57['containsNonAlphanumericCharacter']??!0x0),_0x4a6e57;}['validatePasswordLengthOptions'](_0x5257d1,_0x29fe73){const _0x43706a=this['customStrengthOptions']['minPasswordLength'],_0x1694ff=this['customStrengthOptions']['maxPasswordLength'];_0x43706a&&(_0x29fe73['meetsMinPasswordLength']=_0x5257d1['length']>=_0x43706a),_0x1694ff&&(_0x29fe73['meetsMaxPasswordLength']=_0x5257d1['length']<=_0x1694ff);}['validatePasswordCharacterOptions'](_0x341cf1,_0x486eaa){this['updatePasswordCharacterOptionsStatuses'](_0x486eaa,!0x1,!0x1,!0x1,!0x1);let _0x12dd38;for(let _0x3187dc=0x0;_0x3187dc<_0x341cf1['length'];_0x3187dc++)_0x12dd38=_0x341cf1['charAt'](_0x3187dc),this['updatePasswordCharacterOptionsStatuses'](_0x486eaa,_0x12dd38>='a'&&_0x12dd38<='z',_0x12dd38>='A'&&_0x12dd38<='Z',_0x12dd38>='0'&&_0x12dd38<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x12dd38));}['updatePasswordCharacterOptionsStatuses'](_0x50c268,_0x277086,_0x5363d4,_0x35898d,_0x4f0202){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x50c268['containsLowercaseLetter']||(_0x50c268['containsLowercaseLetter']=_0x277086)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x50c268['containsUppercaseLetter']||(_0x50c268['containsUppercaseLetter']=_0x5363d4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x50c268['containsNumericCharacter']||(_0x50c268['containsNumericCharacter']=_0x35898d)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x50c268['containsNonAlphanumericCharacter']||(_0x50c268['containsNonAlphanumericCharacter']=_0x4f0202));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x47bee6,_0x3d3cb6,_0x4bf897,_0x4d0670){this['app']=_0x47bee6,this['heartbeatServiceProvider']=_0x3d3cb6,this['appCheckServiceProvider']=_0x4bf897,this['config']=_0x4d0670,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x47bee6['name'],this['clientVersion']=_0x4d0670['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5a4c37=>this['_resolvePersistenceManagerAvailable']=_0x5a4c37);}['_initializeWithPersistence'](_0x26c72b,_0x5b6255){return _0x5b6255&&(this['_popupRedirectResolver']=ne(_0x5b6255)),this['_initializationPromise']=this['queue'](async()=>{var _0x1dbf39,_0x1bd01c,_0x38f8db;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x26c72b),(_0x1dbf39=this['_resolvePersistenceManagerAvailable'])==null||_0x1dbf39['call'](this),!this['_deleted'])){if((_0x1bd01c=this['_popupRedirectResolver'])!=null&&_0x1bd01c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5b6255),this['lastNotifiedUid']=((_0x38f8db=this['currentUser'])==null?void 0x0:_0x38f8db['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3cbbd3=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3cbbd3)){if(this['currentUser']&&_0x3cbbd3&&this['currentUser']['uid']===_0x3cbbd3['uid']){this['_currentUser']['_assign'](_0x3cbbd3),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3cbbd3,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x25ff3b){try{const _0x71d8f3=await Sn(this,{'idToken':_0x25ff3b}),_0x5a76e3=await z['_fromGetAccountInfoResponse'](this,_0x71d8f3,_0x25ff3b);await this['directlySetCurrentUser'](_0x5a76e3);}catch(_0x18d443){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x18d443),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x23d87e){var _0x2cc88a;if(H(this['app'])){const _0x53d836=this['app']['settings']['authIdToken'];return _0x53d836?new Promise(_0x2e52a6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x53d836)['then'](_0x2e52a6,_0x2e52a6));}):this['directlySetCurrentUser'](null);}const _0x42a2be=await this['assertedPersistence']['getCurrentUser']();let _0x512ec0=_0x42a2be,_0xf72cc9=!0x1;if(_0x23d87e&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1c9306=(_0x2cc88a=this['redirectUser'])==null?void 0x0:_0x2cc88a['_redirectEventId'],_0x1a352a=_0x512ec0==null?void 0x0:_0x512ec0['_redirectEventId'],_0x470069=await this['tryRedirectSignIn'](_0x23d87e);(!_0x1c9306||_0x1c9306===_0x1a352a)&&(_0x470069!=null&&_0x470069['user'])&&(_0x512ec0=_0x470069['user'],_0xf72cc9=!0x0);}if(!_0x512ec0)return this['directlySetCurrentUser'](null);if(!_0x512ec0['_redirectEventId']){if(_0xf72cc9)try{await this['beforeStateQueue']['runMiddleware'](_0x512ec0);}catch(_0x53cf14){_0x512ec0=_0x42a2be,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x53cf14));}return _0x512ec0?this['reloadAndSetCurrentUserOrClear'](_0x512ec0):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x512ec0['_redirectEventId']?this['directlySetCurrentUser'](_0x512ec0):this['reloadAndSetCurrentUserOrClear'](_0x512ec0);}async['tryRedirectSignIn'](_0x55f8ea){let _0x5e976c=null;try{_0x5e976c=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x55f8ea,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5e976c;}async['reloadAndSetCurrentUserOrClear'](_0x3df98b){try{await bn(_0x3df98b);}catch(_0xe5792f){if((_0xe5792f==null?void 0x0:_0xe5792f['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3df98b);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x21d2a9){if(H(this['app']))return Promise['reject'](se(this));const _0x276d71=_0x21d2a9?k(_0x21d2a9):null;return _0x276d71&&m(_0x276d71['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x276d71&&_0x276d71['_clone'](this));}async['_updateCurrentUser'](_0x3abc21,_0x44ace5=!0x1){if(!this['_deleted'])return _0x3abc21&&m(this['tenantId']===_0x3abc21['tenantId'],this,'tenant-id-mismatch'),_0x44ace5||await this['beforeStateQueue']['runMiddleware'](_0x3abc21),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3abc21),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x455b57){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x455b57));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x119fa0){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x165f49=this['_getPasswordPolicyInternal']();return _0x165f49['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x165f49['validatePassword'](_0x119fa0);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x16994f=await Cf(this),_0x3128fe=new Sf(_0x16994f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3128fe:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3128fe;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2c4b8a){this['_errorFactory']=new Ut('auth','Firebase',_0x2c4b8a());}['onAuthStateChanged'](_0x14548f,_0x22e647,_0x5e65d7){return this['registerStateListener'](this['authStateSubscription'],_0x14548f,_0x22e647,_0x5e65d7);}['beforeAuthStateChanged'](_0x2cd110,_0x5d4216){return this['beforeStateQueue']['pushCallback'](_0x2cd110,_0x5d4216);}['onIdTokenChanged'](_0x4799d8,_0x533c08,_0x5a4154){return this['registerStateListener'](this['idTokenSubscription'],_0x4799d8,_0x533c08,_0x5a4154);}['authStateReady'](){return new Promise((_0x1fe1c7,_0x526bb4)=>{if(this['currentUser'])_0x1fe1c7();else{const _0x17f45e=this['onAuthStateChanged'](()=>{_0x17f45e(),_0x1fe1c7();},_0x526bb4);}});}async['revokeAccessToken'](_0x2a3d2e){if(this['currentUser']){const _0x140723=await this['currentUser']['getIdToken'](),_0x2c1d40={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2a3d2e,'idToken':_0x140723};this['tenantId']!=null&&(_0x2c1d40['tenantId']=this['tenantId']),await vf(this,_0x2c1d40);}}['toJSON'](){var _0x3b2e47;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3b2e47=this['_currentUser'])==null?void 0x0:_0x3b2e47['toJSON']()};}async['_setRedirectUser'](_0x39e73c,_0x1894ad){const _0x1098bd=await this['getOrInitRedirectPersistenceManager'](_0x1894ad);return _0x39e73c===null?_0x1098bd['removeCurrentUser']():_0x1098bd['setCurrentUser'](_0x39e73c);}async['getOrInitRedirectPersistenceManager'](_0x4924ef){if(!this['redirectPersistenceManager']){const _0x31a211=_0x4924ef&&ne(_0x4924ef)||this['_popupRedirectResolver'];m(_0x31a211,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x31a211['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3e6bbc){var _0x1df9cf,_0x54074b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x1df9cf=this['_currentUser'])==null?void 0x0:_0x1df9cf['_redirectEventId'])===_0x3e6bbc?this['_currentUser']:((_0x54074b=this['redirectUser'])==null?void 0x0:_0x54074b['_redirectEventId'])===_0x3e6bbc?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x325ceb){if(_0x325ceb===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x325ceb));}['_notifyListenersIfCurrent'](_0x5d9496){_0x5d9496===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x4900fc;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x322193=((_0x4900fc=this['currentUser'])==null?void 0x0:_0x4900fc['uid'])??null;this['lastNotifiedUid']!==_0x322193&&(this['lastNotifiedUid']=_0x322193,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x64496a,_0xb7ffa,_0x6492da,_0x3e31b7){if(this['_deleted'])return()=>{};const _0x33e5f2=typeof _0xb7ffa=='function'?_0xb7ffa:_0xb7ffa['next']['bind'](_0xb7ffa);let _0x88b85b=!0x1;const _0x87f1e7=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x87f1e7,this,'internal-error'),_0x87f1e7['then'](()=>{_0x88b85b||_0x33e5f2(this['currentUser']);}),typeof _0xb7ffa=='function'){const _0x2c59fc=_0x64496a['addObserver'](_0xb7ffa,_0x6492da,_0x3e31b7);return()=>{_0x88b85b=!0x0,_0x2c59fc();};}else{const _0x2e38af=_0x64496a['addObserver'](_0xb7ffa);return()=>{_0x88b85b=!0x0,_0x2e38af();};}}async['directlySetCurrentUser'](_0x168ffb){this['currentUser']&&this['currentUser']!==_0x168ffb&&this['_currentUser']['_stopProactiveRefresh'](),_0x168ffb&&this['isProactiveRefreshEnabled']&&_0x168ffb['_startProactiveRefresh'](),this['currentUser']=_0x168ffb,_0x168ffb?await this['assertedPersistence']['setCurrentUser'](_0x168ffb):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x117088){return this['operations']=this['operations']['then'](_0x117088,_0x117088),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x53afb1){!_0x53afb1||this['frameworks']['includes'](_0x53afb1)||(this['frameworks']['push'](_0x53afb1),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5a5056;const _0x314e20={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x314e20['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1fda05=await((_0x5a5056=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5a5056['getHeartbeatsHeader']());_0x1fda05&&(_0x314e20['X-Firebase-Client']=_0x1fda05);const _0xd267b9=await this['_getAppCheckToken']();return _0xd267b9&&(_0x314e20['X-Firebase-AppCheck']=_0xd267b9),_0x314e20;}async['_getAppCheckToken'](){var _0x35312b;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4880c6=await((_0x35312b=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x35312b['getToken']());return _0x4880c6!=null&&_0x4880c6['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4880c6['error']),_0x4880c6==null?void 0x0:_0x4880c6['token'];}}function qe(_0x168971){return k(_0x168971);}class Tr{constructor(_0x17fb55){this['auth']=_0x17fb55,this['observer']=null,this['addObserver']=Ic(_0x5cef98=>this['observer']=_0x5cef98);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x5198a3){zn=_0x5198a3;}function Da(_0x2bb347){return zn['loadJS'](_0x2bb347);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x43747d){return'__'+_0x43747d+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0xb5193e){_0xb5193e();}['execute'](_0x53facf,_0x58b8e2){return Promise['resolve']('token');}['render'](_0x429ba9,_0x45725f){return'';}}class Of{['ready'](_0x3fc4ec){_0x3fc4ec();}['execute'](_0x1fe632,_0x1d2a8c){return Promise['resolve']('token');}['render'](_0x4c77b8,_0x3cd155){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2100da){this['type']=Df,this['auth']=qe(_0x2100da);}async['verify'](_0x4f1491='verify',_0x331143=!0x1){async function _0x454568(_0x4add5a){if(!_0x331143){if(_0x4add5a['tenantId']==null&&_0x4add5a['_agentRecaptchaConfig']!=null)return _0x4add5a['_agentRecaptchaConfig']['siteKey'];if(_0x4add5a['tenantId']!=null&&_0x4add5a['_tenantRecaptchaConfigs'][_0x4add5a['tenantId']]!==void 0x0)return _0x4add5a['_tenantRecaptchaConfigs'][_0x4add5a['tenantId']]['siteKey'];}return new Promise(async(_0x28e71f,_0x39bdc6)=>{uf(_0x4add5a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x25bca6=>{if(_0x25bca6['recaptchaKey']===void 0x0)_0x39bdc6(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3422c1=new hf(_0x25bca6);return _0x4add5a['tenantId']==null?_0x4add5a['_agentRecaptchaConfig']=_0x3422c1:_0x4add5a['_tenantRecaptchaConfigs'][_0x4add5a['tenantId']]=_0x3422c1,_0x28e71f(_0x3422c1['siteKey']);}})['catch'](_0x42c738=>{_0x39bdc6(_0x42c738);});});}function _0x5efe20(_0x567f3c,_0x1c1d67,_0x572ecf){const _0x25bdfb=window['grecaptcha'];vr(_0x25bdfb)?_0x25bdfb['enterprise']['ready'](()=>{_0x25bdfb['enterprise']['execute'](_0x567f3c,{'action':_0x4f1491})['then'](_0xf5c30=>{_0x1c1d67(_0xf5c30);})['catch'](()=>{_0x1c1d67(Ma);});}):_0x572ecf(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1d9023,_0x18daa5)=>{_0x454568(this['auth'])['then'](async _0x692c94=>{if(!_0x331143&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x5efe20(_0x692c94,_0x1d9023,_0x18daa5);else{if(typeof window>'u'){_0x18daa5(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5dc39c=Af();_0x5dc39c['length']!==0x0&&(_0x5dc39c+=_0x692c94+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x267442;(_0x267442=le['scriptInjectionDeferred'])==null||_0x267442['resolve']();},Da(_0x5dc39c)['then'](()=>{var _0x3c98c0;return(_0x3c98c0=le['scriptInjectionDeferred'])==null?void 0x0:_0x3c98c0['promise'];})['then'](()=>{_0x5efe20(_0x692c94,_0x1d9023,_0x18daa5);})['catch'](_0x24fc26=>{_0x18daa5(_0x24fc26);});}})['catch'](_0x221461=>{_0x18daa5(_0x221461);});});}}le['scriptInjectionDeferred']=null;async function br(_0x11fcdd,_0x1bf318,_0x45b2db,_0x4039ca=!0x1,_0x5a30da=!0x1){const _0x1f300b=new le(_0x11fcdd);let _0x7acfa5;if(_0x5a30da)_0x7acfa5=Ma;else try{_0x7acfa5=await _0x1f300b['verify'](_0x45b2db);}catch{_0x7acfa5=await _0x1f300b['verify'](_0x45b2db,!0x0);}const _0x58b289={..._0x1bf318};if(_0x45b2db==='mfaSmsEnrollment'||_0x45b2db==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x58b289){const _0x23085e=_0x58b289['phoneEnrollmentInfo']['phoneNumber'],_0x2de1b8=_0x58b289['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x58b289,{'phoneEnrollmentInfo':{'phoneNumber':_0x23085e,'recaptchaToken':_0x2de1b8,'captchaResponse':_0x7acfa5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x58b289){const _0x5a6aba=_0x58b289['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x58b289,{'phoneSignInInfo':{'recaptchaToken':_0x5a6aba,'captchaResponse':_0x7acfa5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x58b289;}return _0x4039ca?Object['assign'](_0x58b289,{'captchaResp':_0x7acfa5}):Object['assign'](_0x58b289,{'captchaResponse':_0x7acfa5}),Object['assign'](_0x58b289,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x58b289,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x58b289;}async function Oi(_0x479b45,_0x1fc895,_0x484e2b,_0x479cda,_0x5f528b){var _0x4768cf;if((_0x4768cf=_0x479b45['_getRecaptchaConfig']())!=null&&_0x4768cf['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3df20b=await br(_0x479b45,_0x1fc895,_0x484e2b,_0x484e2b==='getOobCode');return _0x479cda(_0x479b45,_0x3df20b);}else return _0x479cda(_0x479b45,_0x1fc895)['catch'](async _0xec00ce=>{if(_0xec00ce['code']==='auth/missing-recaptcha-token'){console['log'](_0x484e2b+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x106c24=await br(_0x479b45,_0x1fc895,_0x484e2b,_0x484e2b==='getOobCode');return _0x479cda(_0x479b45,_0x106c24);}else return Promise['reject'](_0xec00ce);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x574314,_0x5b7a1c){const _0x16ba51=Ui(_0x574314,'auth');if(_0x16ba51['isInitialized']()){const _0x3427d7=_0x16ba51['getImmediate'](),_0x5b866c=_0x16ba51['getOptions']();if(De(_0x5b866c,_0x5b7a1c??{}))return _0x3427d7;K(_0x3427d7,'already-initialized');}return _0x16ba51['initialize']({'options':_0x5b7a1c});}function Lf(_0x1bd962,_0x2585d2){const _0x39a149=(_0x2585d2==null?void 0x0:_0x2585d2['persistence'])||[],_0x2868a5=(Array['isArray'](_0x39a149)?_0x39a149:[_0x39a149])['map'](ne);_0x2585d2!=null&&_0x2585d2['errorMap']&&_0x1bd962['_updateErrorMap'](_0x2585d2['errorMap']),_0x1bd962['_initializeWithPersistence'](_0x2868a5,_0x2585d2==null?void 0x0:_0x2585d2['popupRedirectResolver']);}function xf(_0x2c86b0,_0x320603,_0x1b3756){const _0x58972a=qe(_0x2c86b0);m(/^https?:\/\//['test'](_0x320603),_0x58972a,'invalid-emulator-scheme');const _0x1fe0e1=!0x1,_0x5c3be9=La(_0x320603),{host:_0x3db64b,port:_0x21f3d9}=Ff(_0x320603),_0x3ef0bc=_0x21f3d9===null?'':':'+_0x21f3d9,_0x4d12d4={'url':_0x5c3be9+'//'+_0x3db64b+_0x3ef0bc+'/'},_0x246ce3=Object['freeze']({'host':_0x3db64b,'port':_0x21f3d9,'protocol':_0x5c3be9['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1fe0e1})});if(!_0x58972a['_canInitEmulator']){m(_0x58972a['config']['emulator']&&_0x58972a['emulatorConfig'],_0x58972a,'emulator-config-failed'),m(De(_0x4d12d4,_0x58972a['config']['emulator'])&&De(_0x246ce3,_0x58972a['emulatorConfig']),_0x58972a,'emulator-config-failed');return;}_0x58972a['config']['emulator']=_0x4d12d4,_0x58972a['emulatorConfig']=_0x246ce3,_0x58972a['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3db64b)?jr(_0x5c3be9+'//'+_0x3db64b+_0x3ef0bc):Uf();}function La(_0x344337){const _0x4e73cd=_0x344337['indexOf'](':');return _0x4e73cd<0x0?'':_0x344337['substr'](0x0,_0x4e73cd+0x1);}function Ff(_0x4658e5){const _0x3c9ae1=La(_0x4658e5),_0x15d028=/(\/\/)?([^?#/]+)/['exec'](_0x4658e5['substr'](_0x3c9ae1['length']));if(!_0x15d028)return{'host':'','port':null};const _0x30c460=_0x15d028[0x2]['split']('@')['pop']()||'',_0x58a2ae=/^(\[[^\]]+\])(:|$)/['exec'](_0x30c460);if(_0x58a2ae){const _0x402c40=_0x58a2ae[0x1];return{'host':_0x402c40,'port':Rr(_0x30c460['substr'](_0x402c40['length']+0x1))};}else{const [_0x548644,_0xa421dd]=_0x30c460['split'](':');return{'host':_0x548644,'port':Rr(_0xa421dd)};}}function Rr(_0x14fdfe){if(!_0x14fdfe)return null;const _0x5821d3=Number(_0x14fdfe);return isNaN(_0x5821d3)?null:_0x5821d3;}function Uf(){function _0x4c279b(){const _0x1b7ced=document['createElement']('p'),_0x47cfb7=_0x1b7ced['style'];_0x1b7ced['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x47cfb7['position']='fixed',_0x47cfb7['width']='100%',_0x47cfb7['backgroundColor']='#ffffff',_0x47cfb7['border']='.1em\x20solid\x20#000000',_0x47cfb7['color']='#b50000',_0x47cfb7['bottom']='0px',_0x47cfb7['left']='0px',_0x47cfb7['margin']='0px',_0x47cfb7['zIndex']='10000',_0x47cfb7['textAlign']='center',_0x1b7ced['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1b7ced);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4c279b):_0x4c279b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x1f64f0,_0x282ef9){this['providerId']=_0x1f64f0,this['signInMethod']=_0x282ef9;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3ef0e4){return te('not\x20implemented');}['_linkToIdToken'](_0x4021a4,_0x2cd886){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x242c4d){return te('not\x20implemented');}}async function Wf(_0x333abf,_0x3df785){return Ae(_0x333abf,'POST','/v1/accounts:signUp',_0x3df785);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x5c132b,_0x2088ff){return Yt(_0x5c132b,'POST','/v1/accounts:signInWithPassword',Re(_0x5c132b,_0x2088ff));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x1c69ff,_0x543137){return Yt(_0x1c69ff,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c69ff,_0x543137));}async function Hf(_0x1c0b70,_0x346fc1){return Yt(_0x1c0b70,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c0b70,_0x346fc1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x38099c,_0x2317d3,_0xee0162,_0x37c0d1=null){super('password',_0xee0162),this['_email']=_0x38099c,this['_password']=_0x2317d3,this['_tenantId']=_0x37c0d1;}static['_fromEmailAndPassword'](_0x283ad4,_0x566ffe){return new Ft(_0x283ad4,_0x566ffe,'password');}static['_fromEmailAndCode'](_0x43c908,_0x1fa598,_0x1eb53e=null){return new Ft(_0x43c908,_0x1fa598,'emailLink',_0x1eb53e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x27ba7f){const _0xf13c48=typeof _0x27ba7f=='string'?JSON['parse'](_0x27ba7f):_0x27ba7f;if(_0xf13c48!=null&&_0xf13c48['email']&&(_0xf13c48!=null&&_0xf13c48['password'])){if(_0xf13c48['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xf13c48['email'],_0xf13c48['password']);if(_0xf13c48['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xf13c48['email'],_0xf13c48['password'],_0xf13c48['tenantId']);}return null;}async['_getIdTokenResponse'](_0xb0720b){switch(this['signInMethod']){case'password':const _0xd5c96e={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0xb0720b,_0xd5c96e,'signInWithPassword',Bf);case'emailLink':return Vf(_0xb0720b,{'email':this['_email'],'oobCode':this['_password']});default:K(_0xb0720b,'internal-error');}}async['_linkToIdToken'](_0x5172c8,_0x5c5899){switch(this['signInMethod']){case'password':const _0x24245b={'idToken':_0x5c5899,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5172c8,_0x24245b,'signUpPassword',Wf);case'emailLink':return Hf(_0x5172c8,{'idToken':_0x5c5899,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5172c8,'internal-error');}}['_getReauthenticationResolver'](_0x5110e9){return this['_getIdTokenResponse'](_0x5110e9);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x3d250d,_0x28f962){return Yt(_0x3d250d,'POST','/v1/accounts:signInWithIdp',Re(_0x3d250d,_0x28f962));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1c067b){const _0x470117=new We(_0x1c067b['providerId'],_0x1c067b['signInMethod']);return _0x1c067b['idToken']||_0x1c067b['accessToken']?(_0x1c067b['idToken']&&(_0x470117['idToken']=_0x1c067b['idToken']),_0x1c067b['accessToken']&&(_0x470117['accessToken']=_0x1c067b['accessToken']),_0x1c067b['nonce']&&!_0x1c067b['pendingToken']&&(_0x470117['nonce']=_0x1c067b['nonce']),_0x1c067b['pendingToken']&&(_0x470117['pendingToken']=_0x1c067b['pendingToken'])):_0x1c067b['oauthToken']&&_0x1c067b['oauthTokenSecret']?(_0x470117['accessToken']=_0x1c067b['oauthToken'],_0x470117['secret']=_0x1c067b['oauthTokenSecret']):K('argument-error'),_0x470117;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1335f0){const _0x271be4=typeof _0x1335f0=='string'?JSON['parse'](_0x1335f0):_0x1335f0,{providerId:_0x244642,signInMethod:_0x3c1976,..._0x53da0d}=_0x271be4;if(!_0x244642||!_0x3c1976)return null;const _0x1c9a3d=new We(_0x244642,_0x3c1976);return _0x1c9a3d['idToken']=_0x53da0d['idToken']||void 0x0,_0x1c9a3d['accessToken']=_0x53da0d['accessToken']||void 0x0,_0x1c9a3d['secret']=_0x53da0d['secret'],_0x1c9a3d['nonce']=_0x53da0d['nonce'],_0x1c9a3d['pendingToken']=_0x53da0d['pendingToken']||null,_0x1c9a3d;}['_getIdTokenResponse'](_0x3d3888){const _0x47260a=this['buildRequest']();return Ze(_0x3d3888,_0x47260a);}['_linkToIdToken'](_0x25dc36,_0x31aecf){const _0x54b5ca=this['buildRequest']();return _0x54b5ca['idToken']=_0x31aecf,Ze(_0x25dc36,_0x54b5ca);}['_getReauthenticationResolver'](_0x370e2b){const _0x1174af=this['buildRequest']();return _0x1174af['autoCreate']=!0x1,Ze(_0x370e2b,_0x1174af);}['buildRequest'](){const _0x45b84d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x45b84d['pendingToken']=this['pendingToken'];else{const _0x24f4c7={};this['idToken']&&(_0x24f4c7['id_token']=this['idToken']),this['accessToken']&&(_0x24f4c7['access_token']=this['accessToken']),this['secret']&&(_0x24f4c7['oauth_token_secret']=this['secret']),_0x24f4c7['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x24f4c7['nonce']=this['nonce']),_0x45b84d['postBody']=at(_0x24f4c7);}return _0x45b84d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0xfc7ca8){switch(_0xfc7ca8){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x388e44){const _0x5c2eb4=yt(vt(_0x388e44))['link'],_0x39c8cb=_0x5c2eb4?yt(vt(_0x5c2eb4))['deep_link_id']:null,_0x5a3b51=yt(vt(_0x388e44))['deep_link_id'];return(_0x5a3b51?yt(vt(_0x5a3b51))['link']:null)||_0x5a3b51||_0x39c8cb||_0x5c2eb4||_0x388e44;}class Ss{constructor(_0x2d6e24){const _0x569766=yt(vt(_0x2d6e24)),_0x193ec3=_0x569766['apiKey']??null,_0x4feee9=_0x569766['oobCode']??null,_0x295512=Gf(_0x569766['mode']??null);m(_0x193ec3&&_0x4feee9&&_0x295512,'argument-error'),this['apiKey']=_0x193ec3,this['operation']=_0x295512,this['code']=_0x4feee9,this['continueUrl']=_0x569766['continueUrl']??null,this['languageCode']=_0x569766['lang']??null,this['tenantId']=_0x569766['tenantId']??null;}static['parseLink'](_0x2791b3){const _0x58b1c1=qf(_0x2791b3);try{return new Ss(_0x58b1c1);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x3d5424,_0x379642){return Ft['_fromEmailAndPassword'](_0x3d5424,_0x379642);}static['credentialWithLink'](_0x4537c8,_0x3e462c){const _0x13df26=Ss['parseLink'](_0x3e462c);return m(_0x13df26,'argument-error'),Ft['_fromEmailAndCode'](_0x4537c8,_0x13df26['code'],_0x13df26['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5b58ca){this['providerId']=_0x5b58ca,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x54be8d){this['defaultLanguageCode']=_0x54be8d;}['setCustomParameters'](_0x57814e){return this['customParameters']=_0x57814e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xb43ca3){return this['scopes']['includes'](_0xb43ca3)||this['scopes']['push'](_0xb43ca3),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x2fe80f){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2fe80f});}static['credentialFromResult'](_0x54d4c4){return he['credentialFromTaggedObject'](_0x54d4c4);}static['credentialFromError'](_0x42b37f){return he['credentialFromTaggedObject'](_0x42b37f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4020a7}){if(!_0x4020a7||!('oauthAccessToken'in _0x4020a7)||!_0x4020a7['oauthAccessToken'])return null;try{return he['credential'](_0x4020a7['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1829ca,_0x3276fa){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1829ca,'accessToken':_0x3276fa});}static['credentialFromResult'](_0x2e95e6){return ue['credentialFromTaggedObject'](_0x2e95e6);}static['credentialFromError'](_0x152354){return ue['credentialFromTaggedObject'](_0x152354['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x549701}){if(!_0x549701)return null;const {oauthIdToken:_0x574b49,oauthAccessToken:_0x21269d}=_0x549701;if(!_0x574b49&&!_0x21269d)return null;try{return ue['credential'](_0x574b49,_0x21269d);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xec7b04){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xec7b04});}static['credentialFromResult'](_0x35fdce){return de['credentialFromTaggedObject'](_0x35fdce);}static['credentialFromError'](_0x54101f){return de['credentialFromTaggedObject'](_0x54101f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5fe1ca}){if(!_0x5fe1ca||!('oauthAccessToken'in _0x5fe1ca)||!_0x5fe1ca['oauthAccessToken'])return null;try{return de['credential'](_0x5fe1ca['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x439787,_0x4cb63c){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x439787,'oauthTokenSecret':_0x4cb63c});}static['credentialFromResult'](_0x3a29e2){return fe['credentialFromTaggedObject'](_0x3a29e2);}static['credentialFromError'](_0x36375c){return fe['credentialFromTaggedObject'](_0x36375c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4251ad}){if(!_0x4251ad)return null;const {oauthAccessToken:_0x59cef5,oauthTokenSecret:_0x5f4762}=_0x4251ad;if(!_0x59cef5||!_0x5f4762)return null;try{return fe['credential'](_0x59cef5,_0x5f4762);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x8410fb,_0x14a6c6){return Yt(_0x8410fb,'POST','/v1/accounts:signUp',Re(_0x8410fb,_0x14a6c6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xe8d3d3){this['user']=_0xe8d3d3['user'],this['providerId']=_0xe8d3d3['providerId'],this['_tokenResponse']=_0xe8d3d3['_tokenResponse'],this['operationType']=_0xe8d3d3['operationType'];}static async['_fromIdTokenResponse'](_0x1c27de,_0x165af2,_0xa3b0a8,_0x3a5d03=!0x1){const _0x875dcd=await z['_fromIdTokenResponse'](_0x1c27de,_0xa3b0a8,_0x3a5d03),_0x2a3a2c=Ar(_0xa3b0a8);return new Be({'user':_0x875dcd,'providerId':_0x2a3a2c,'_tokenResponse':_0xa3b0a8,'operationType':_0x165af2});}static async['_forOperation'](_0x1d6e7,_0x3b40ed,_0x192778){await _0x1d6e7['_updateTokensIfNecessary'](_0x192778,!0x0);const _0x1b10dc=Ar(_0x192778);return new Be({'user':_0x1d6e7,'providerId':_0x1b10dc,'_tokenResponse':_0x192778,'operationType':_0x3b40ed});}}function Ar(_0x4066e8){return _0x4066e8['providerId']?_0x4066e8['providerId']:'phoneNumber'in _0x4066e8?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5c48f1,_0x398cd8,_0x4b1d28,_0x2d08b2){super(_0x398cd8['code'],_0x398cd8['message']),this['operationType']=_0x4b1d28,this['user']=_0x2d08b2,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5c48f1['name'],'tenantId':_0x5c48f1['tenantId']??void 0x0,'_serverResponse':_0x398cd8['customData']['_serverResponse'],'operationType':_0x4b1d28};}static['_fromErrorAndOperation'](_0x22035f,_0x18b3fc,_0x23fbf5,_0x2aa7df){return new Rn(_0x22035f,_0x18b3fc,_0x23fbf5,_0x2aa7df);}}function Fa(_0x53501b,_0x2cf895,_0x202f35,_0x46147c){return(_0x2cf895==='reauthenticate'?_0x202f35['_getReauthenticationResolver'](_0x53501b):_0x202f35['_getIdTokenResponse'](_0x53501b))['catch'](_0x1b2e23=>{throw _0x1b2e23['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x53501b,_0x1b2e23,_0x2cf895,_0x46147c):_0x1b2e23;});}async function jf(_0x5a2f11,_0x3b9dae,_0x241fa1=!0x1){const _0x201af3=await xt(_0x5a2f11,_0x3b9dae['_linkToIdToken'](_0x5a2f11['auth'],await _0x5a2f11['getIdToken']()),_0x241fa1);return Be['_forOperation'](_0x5a2f11,'link',_0x201af3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1ca188,_0x54fb39,_0x5cdeda=!0x1){const {auth:_0x4e2e88}=_0x1ca188;if(H(_0x4e2e88['app']))return Promise['reject'](se(_0x4e2e88));const _0x4ea701='reauthenticate';try{const _0x183547=await xt(_0x1ca188,Fa(_0x4e2e88,_0x4ea701,_0x54fb39,_0x1ca188),_0x5cdeda);m(_0x183547['idToken'],_0x4e2e88,'internal-error');const _0x2e0b1d=ws(_0x183547['idToken']);m(_0x2e0b1d,_0x4e2e88,'internal-error');const {sub:_0x1f9726}=_0x2e0b1d;return m(_0x1ca188['uid']===_0x1f9726,_0x4e2e88,'user-mismatch'),Be['_forOperation'](_0x1ca188,_0x4ea701,_0x183547);}catch(_0x438005){throw(_0x438005==null?void 0x0:_0x438005['code'])==='auth/user-not-found'&&K(_0x4e2e88,'user-mismatch'),_0x438005;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x2f88ca,_0x3d9f13,_0x1cd55d=!0x1){if(H(_0x2f88ca['app']))return Promise['reject'](se(_0x2f88ca));const _0x38cc83='signIn',_0x71b50b=await Fa(_0x2f88ca,_0x38cc83,_0x3d9f13),_0x34d0a5=await Be['_fromIdTokenResponse'](_0x2f88ca,_0x38cc83,_0x71b50b);return _0x1cd55d||await _0x2f88ca['_updateCurrentUser'](_0x34d0a5['user']),_0x34d0a5;}async function Yf(_0x9d15c5,_0x4e5070){return Ua(qe(_0x9d15c5),_0x4e5070);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x470373){const _0x4bc788=qe(_0x470373);_0x4bc788['_getPasswordPolicyInternal']()&&await _0x4bc788['_updatePasswordPolicy']();}async function R_(_0x13d86d,_0x31a6ae,_0x35a853){if(H(_0x13d86d['app']))return Promise['reject'](se(_0x13d86d));const _0x1fe914=qe(_0x13d86d),_0x823122=await Oi(_0x1fe914,{'returnSecureToken':!0x0,'email':_0x31a6ae,'password':_0x35a853,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x2a82e7=>{throw _0x2a82e7['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x13d86d),_0x2a82e7;}),_0x3e9bb5=await Be['_fromIdTokenResponse'](_0x1fe914,'signIn',_0x823122);return await _0x1fe914['_updateCurrentUser'](_0x3e9bb5['user']),_0x3e9bb5;}function A_(_0x2e582f,_0x5456f6,_0x3ef33c){return H(_0x2e582f['app'])?Promise['reject'](se(_0x2e582f)):Yf(k(_0x2e582f),ft['credential'](_0x5456f6,_0x3ef33c))['catch'](async _0xcd8b19=>{throw _0xcd8b19['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x2e582f),_0xcd8b19;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5d10bf,_0xa8d90e){return k(_0x5d10bf)['setPersistence'](_0xa8d90e);}function Qf(_0x163058,_0x43cd1b,_0x4816ad,_0x570749){return k(_0x163058)['onIdTokenChanged'](_0x43cd1b,_0x4816ad,_0x570749);}function Jf(_0x536809,_0x4d45a6,_0x291367){return k(_0x536809)['beforeAuthStateChanged'](_0x4d45a6,_0x291367);}function N_(_0x3ba036,_0x56c4b8,_0x8d1846,_0xb4a4c8){return k(_0x3ba036)['onAuthStateChanged'](_0x56c4b8,_0x8d1846,_0xb4a4c8);}function P_(_0x4ecf6e){return k(_0x4ecf6e)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x18e9ed,_0x44d9ac){this['storageRetriever']=_0x18e9ed,this['type']=_0x44d9ac;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x71b3bc,_0x35206d){return this['storage']['setItem'](_0x71b3bc,JSON['stringify'](_0x35206d)),Promise['resolve']();}['_get'](_0x847cd9){const _0x3ded32=this['storage']['getItem'](_0x847cd9);return Promise['resolve'](_0x3ded32?JSON['parse'](_0x3ded32):null);}['_remove'](_0x570d5a){return this['storage']['removeItem'](_0x570d5a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x238326,_0xc0e4cf)=>this['onStorageEvent'](_0x238326,_0xc0e4cf),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3845ac){for(const _0x5c5145 of Object['keys'](this['listeners'])){const _0x5d05f2=this['storage']['getItem'](_0x5c5145),_0x168f0a=this['localCache'][_0x5c5145];_0x5d05f2!==_0x168f0a&&_0x3845ac(_0x5c5145,_0x168f0a,_0x5d05f2);}}['onStorageEvent'](_0x45e5c3,_0xb9c1bb=!0x1){if(!_0x45e5c3['key']){this['forAllChangedKeys']((_0x406f49,_0x1b5bb0,_0x344364)=>{this['notifyListeners'](_0x406f49,_0x344364);});return;}const _0x34efde=_0x45e5c3['key'];_0xb9c1bb?this['detachListener']():this['stopPolling']();const _0x4bec48=()=>{const _0x266a3e=this['storage']['getItem'](_0x34efde);!_0xb9c1bb&&this['localCache'][_0x34efde]===_0x266a3e||this['notifyListeners'](_0x34efde,_0x266a3e);},_0x2227fc=this['storage']['getItem'](_0x34efde);If()&&_0x2227fc!==_0x45e5c3['newValue']&&_0x45e5c3['newValue']!==_0x45e5c3['oldValue']?setTimeout(_0x4bec48,Zf):_0x4bec48();}['notifyListeners'](_0x2794fd,_0x3be6fc){this['localCache'][_0x2794fd]=_0x3be6fc;const _0x4d04eb=this['listeners'][_0x2794fd];if(_0x4d04eb){for(const _0x387ff7 of Array['from'](_0x4d04eb))_0x387ff7(_0x3be6fc&&JSON['parse'](_0x3be6fc));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2b3b81,_0x38d48b,_0x3c7f1a)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2b3b81,'oldValue':_0x38d48b,'newValue':_0x3c7f1a}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x517a80,_0x2b11ad){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x517a80]||(this['listeners'][_0x517a80]=new Set(),this['localCache'][_0x517a80]=this['storage']['getItem'](_0x517a80)),this['listeners'][_0x517a80]['add'](_0x2b11ad);}['_removeListener'](_0xa305de,_0x5c7101){this['listeners'][_0xa305de]&&(this['listeners'][_0xa305de]['delete'](_0x5c7101),this['listeners'][_0xa305de]['size']===0x0&&delete this['listeners'][_0xa305de]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1f373a,_0x52f158){await super['_set'](_0x1f373a,_0x52f158),this['localCache'][_0x1f373a]=JSON['stringify'](_0x52f158);}async['_get'](_0x83c142){const _0x192531=await super['_get'](_0x83c142);return this['localCache'][_0x83c142]=JSON['stringify'](_0x192531),_0x192531;}async['_remove'](_0x4b5fc0){await super['_remove'](_0x4b5fc0),delete this['localCache'][_0x4b5fc0];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2dee91,_0x1439cd){}['_removeListener'](_0x3beae7,_0x177f08){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x2aec2d){return Promise['all'](_0x2aec2d['map'](async _0x70d2d6=>{try{return{'fulfilled':!0x0,'value':await _0x70d2d6};}catch(_0x279260){return{'fulfilled':!0x1,'reason':_0x279260};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x5c1149){this['eventTarget']=_0x5c1149,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x406408){const _0x851ab5=this['receivers']['find'](_0x5507ec=>_0x5507ec['isListeningto'](_0x406408));if(_0x851ab5)return _0x851ab5;const _0x55eb8e=new jn(_0x406408);return this['receivers']['push'](_0x55eb8e),_0x55eb8e;}['isListeningto'](_0xbd9714){return this['eventTarget']===_0xbd9714;}async['handleEvent'](_0x31154b){const _0x4f0caa=_0x31154b,{eventId:_0x3f00b5,eventType:_0x5b64ca,data:_0x21aaf1}=_0x4f0caa['data'],_0x6ba684=this['handlersMap'][_0x5b64ca];if(!(_0x6ba684!=null&&_0x6ba684['size']))return;_0x4f0caa['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3f00b5,'eventType':_0x5b64ca});const _0x548e41=Array['from'](_0x6ba684)['map'](async _0x3ff5a5=>_0x3ff5a5(_0x4f0caa['origin'],_0x21aaf1)),_0x44e77d=await tp(_0x548e41);_0x4f0caa['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3f00b5,'eventType':_0x5b64ca,'response':_0x44e77d});}['_subscribe'](_0x1f8a80,_0x16a02d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1f8a80]||(this['handlersMap'][_0x1f8a80]=new Set()),this['handlersMap'][_0x1f8a80]['add'](_0x16a02d);}['_unsubscribe'](_0x1c55de,_0x57975c){this['handlersMap'][_0x1c55de]&&_0x57975c&&this['handlersMap'][_0x1c55de]['delete'](_0x57975c),(!_0x57975c||this['handlersMap'][_0x1c55de]['size']===0x0)&&delete this['handlersMap'][_0x1c55de],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x598ef0='',_0x43c085=0xa){let _0x5a9750='';for(let _0x209d0e=0x0;_0x209d0e<_0x43c085;_0x209d0e++)_0x5a9750+=Math['floor'](Math['random']()*0xa);return _0x598ef0+_0x5a9750;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x102761){this['target']=_0x102761,this['handlers']=new Set();}['removeMessageHandler'](_0x3e99b9){_0x3e99b9['messageChannel']&&(_0x3e99b9['messageChannel']['port1']['removeEventListener']('message',_0x3e99b9['onMessage']),_0x3e99b9['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3e99b9);}async['_send'](_0x53b862,_0x48ee2b,_0x2e9ade=0x32){const _0x3b0fcb=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3b0fcb)throw new Error('connection_unavailable');let _0x4a6595,_0x3c6147;return new Promise((_0x3d89e1,_0x40369a)=>{const _0x2a2b76=bs('',0x14);_0x3b0fcb['port1']['start']();const _0x59f57d=setTimeout(()=>{_0x40369a(new Error('unsupported_event'));},_0x2e9ade);_0x3c6147={'messageChannel':_0x3b0fcb,'onMessage'(_0x18e639){const _0x110fdc=_0x18e639;if(_0x110fdc['data']['eventId']===_0x2a2b76)switch(_0x110fdc['data']['status']){case'ack':clearTimeout(_0x59f57d),_0x4a6595=setTimeout(()=>{_0x40369a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4a6595),_0x3d89e1(_0x110fdc['data']['response']);break;default:clearTimeout(_0x59f57d),clearTimeout(_0x4a6595),_0x40369a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3c6147),_0x3b0fcb['port1']['addEventListener']('message',_0x3c6147['onMessage']),this['target']['postMessage']({'eventType':_0x53b862,'eventId':_0x2a2b76,'data':_0x48ee2b},[_0x3b0fcb['port2']]);})['finally'](()=>{_0x3c6147&&this['removeMessageHandler'](_0x3c6147);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x5449a4){X()['location']['href']=_0x5449a4;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x5c6da3;return((_0x5c6da3=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5c6da3['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0xb6abf9){this['request']=_0xb6abf9;}['toPromise'](){return new Promise((_0x2cb21a,_0x3d72ff)=>{this['request']['addEventListener']('success',()=>{_0x2cb21a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3d72ff(this['request']['error']);});});}}function Kn(_0x209421,_0x4204fa){return _0x209421['transaction']([kn],_0x4204fa?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x49584e=indexedDB['deleteDatabase'](qa);return new Jt(_0x49584e)['toPromise']();}function ja(){const _0x380206=indexedDB['open'](qa,ap);return new Promise((_0x326842,_0x34aaf7)=>{_0x380206['addEventListener']('error',()=>{_0x34aaf7(_0x380206['error']);}),_0x380206['addEventListener']('upgradeneeded',()=>{const _0x3249eb=_0x380206['result'];try{_0x3249eb['createObjectStore'](kn,{'keyPath':za});}catch(_0x3d2241){_0x34aaf7(_0x3d2241);}}),_0x380206['addEventListener']('success',async()=>{const _0x161fb4=_0x380206['result'];_0x161fb4['objectStoreNames']['contains'](kn)?_0x326842(_0x161fb4):(_0x161fb4['close'](),await cp(),_0x326842(await ja()));});});}async function kr(_0xc610e6,_0x114232,_0x720259){const _0xae7c27=Kn(_0xc610e6,!0x0)['put']({[za]:_0x114232,'value':_0x720259});return new Jt(_0xae7c27)['toPromise']();}async function lp(_0x3b0f44,_0x165237){const _0x298131=Kn(_0x3b0f44,!0x1)['get'](_0x165237),_0x933f86=await new Jt(_0x298131)['toPromise']();return _0x933f86===void 0x0?null:_0x933f86['value'];}function Nr(_0x2e5353,_0x1b5c25){const _0x2ddeb7=Kn(_0x2e5353,!0x0)['delete'](_0x1b5c25);return new Jt(_0x2ddeb7)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x29a0fb){let _0x529945=0x0;for(;;)try{const _0x2d97c5=await this['_openDb']();return await _0x29a0fb(_0x2d97c5);}catch(_0x3d7ece){if(_0x529945++>up)throw _0x3d7ece;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1c5e1b,_0x51510f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x51510f['key'])})),this['receiver']['_subscribe']('ping',async(_0x22d004,_0xe7178f)=>['keyChanged']);}async['initializeSender'](){var _0x38f787,_0x2894ad;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x562b3d=await this['sender']['_send']('ping',{},0x320);_0x562b3d&&(_0x38f787=_0x562b3d[0x0])!=null&&_0x38f787['fulfilled']&&(_0x2894ad=_0x562b3d[0x0])!=null&&_0x2894ad['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1c6fd9){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1c6fd9},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5caa90=>{await kr(_0x5caa90,An,'1'),await Nr(_0x5caa90,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x214085){this['pendingWrites']++;try{await _0x214085();}finally{this['pendingWrites']--;}}async['_set'](_0x15a128,_0x2a50a1){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x521bd6=>kr(_0x521bd6,_0x15a128,_0x2a50a1)),this['localCache'][_0x15a128]=_0x2a50a1,this['notifyServiceWorker'](_0x15a128)));}async['_get'](_0x389f02){const _0x54dee8=await this['_withRetries'](_0x2af99c=>lp(_0x2af99c,_0x389f02));return this['localCache'][_0x389f02]=_0x54dee8,_0x54dee8;}async['_remove'](_0x46d766){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x51e156=>Nr(_0x51e156,_0x46d766)),delete this['localCache'][_0x46d766],this['notifyServiceWorker'](_0x46d766)));}async['_poll'](){const _0x39d246=await this['_withRetries'](_0x5f517e=>{const _0x1279df=Kn(_0x5f517e,!0x1)['getAll']();return new Jt(_0x1279df)['toPromise']();});if(!_0x39d246)return[];if(this['pendingWrites']!==0x0)return[];const _0xee2422=[],_0x4fad90=new Set();if(_0x39d246['length']!==0x0){for(const {fbase_key:_0x24f024,value:_0x5df407}of _0x39d246)_0x4fad90['add'](_0x24f024),JSON['stringify'](this['localCache'][_0x24f024])!==JSON['stringify'](_0x5df407)&&(this['notifyListeners'](_0x24f024,_0x5df407),_0xee2422['push'](_0x24f024));}for(const _0x46b20a of Object['keys'](this['localCache']))this['localCache'][_0x46b20a]&&!_0x4fad90['has'](_0x46b20a)&&(this['notifyListeners'](_0x46b20a,null),_0xee2422['push'](_0x46b20a));return _0xee2422;}['notifyListeners'](_0x43b54f,_0x50c5bf){this['localCache'][_0x43b54f]=_0x50c5bf;const _0x140b08=this['listeners'][_0x43b54f];if(_0x140b08){for(const _0x2e01e2 of Array['from'](_0x140b08))_0x2e01e2(_0x50c5bf);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4cabdf,_0x56fe96){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4cabdf]||(this['listeners'][_0x4cabdf]=new Set(),this['_get'](_0x4cabdf)),this['listeners'][_0x4cabdf]['add'](_0x56fe96);}['_removeListener'](_0x130376,_0x5b2559){this['listeners'][_0x130376]&&(this['listeners'][_0x130376]['delete'](_0x5b2559),this['listeners'][_0x130376]['size']===0x0&&delete this['listeners'][_0x130376]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x119da5,_0x314439){return _0x314439?ne(_0x314439):(m(_0x119da5['_popupRedirectResolver'],_0x119da5,'argument-error'),_0x119da5['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x3024f0){super('custom','custom'),this['params']=_0x3024f0;}['_getIdTokenResponse'](_0x3d5baf){return Ze(_0x3d5baf,this['_buildIdpRequest']());}['_linkToIdToken'](_0x411c1a,_0x2bc97a){return Ze(_0x411c1a,this['_buildIdpRequest'](_0x2bc97a));}['_getReauthenticationResolver'](_0xae4d1c){return Ze(_0xae4d1c,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xc2f546){const _0x233c80={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xc2f546&&(_0x233c80['idToken']=_0xc2f546),_0x233c80;}}function pp(_0x1e3491){return Ua(_0x1e3491['auth'],new Rs(_0x1e3491),_0x1e3491['bypassAuthState']);}function _p(_0x2fbc7f){const {auth:_0x77e5bb,user:_0x184aa6}=_0x2fbc7f;return m(_0x184aa6,_0x77e5bb,'internal-error'),Kf(_0x184aa6,new Rs(_0x2fbc7f),_0x2fbc7f['bypassAuthState']);}async function gp(_0x107300){const {auth:_0x2c8ab8,user:_0x2f4e9f}=_0x107300;return m(_0x2f4e9f,_0x2c8ab8,'internal-error'),jf(_0x2f4e9f,new Rs(_0x107300),_0x107300['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2d1185,_0x5a73bb,_0x33a0c1,_0x4920e9,_0x21d39b=!0x1){this['auth']=_0x2d1185,this['resolver']=_0x33a0c1,this['user']=_0x4920e9,this['bypassAuthState']=_0x21d39b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5a73bb)?_0x5a73bb:[_0x5a73bb];}['execute'](){return new Promise(async(_0x533fb4,_0x2fe4a2)=>{this['pendingPromise']={'resolve':_0x533fb4,'reject':_0x2fe4a2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x52bca6){this['reject'](_0x52bca6);}});}async['onAuthEvent'](_0x4ab023){const {urlResponse:_0x2889df,sessionId:_0x2a0901,postBody:_0xb334ec,tenantId:_0xb020ed,error:_0x5a3b88,type:_0xc36388}=_0x4ab023;if(_0x5a3b88){this['reject'](_0x5a3b88);return;}const _0x1390bd={'auth':this['auth'],'requestUri':_0x2889df,'sessionId':_0x2a0901,'tenantId':_0xb020ed||void 0x0,'postBody':_0xb334ec||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0xc36388)(_0x1390bd));}catch(_0x48a257){this['reject'](_0x48a257);}}['onError'](_0x15ef36){this['reject'](_0x15ef36);}['getIdpTask'](_0x1a74de){switch(_0x1a74de){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x1b3acf){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1b3acf),this['unregisterAndCleanUp']();}['reject'](_0x1e337a){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1e337a),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1bb4d0,_0x1070da,_0x1a0f58,_0x5c07d3,_0xdd661c){super(_0x1bb4d0,_0x1070da,_0x5c07d3,_0xdd661c),this['provider']=_0x1a0f58,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x4f5d0b=await this['execute']();return m(_0x4f5d0b,this['auth'],'internal-error'),_0x4f5d0b;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1319a3=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1319a3),this['authWindow']['associatedEvent']=_0x1319a3,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4665d0=>{this['reject'](_0x4665d0);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x15aa82=>{_0x15aa82||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x106a15;return((_0x106a15=this['authWindow'])==null?void 0x0:_0x106a15['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3ed9ad=()=>{var _0xec058f,_0x35679a;if((_0x35679a=(_0xec058f=this['authWindow'])==null?void 0x0:_0xec058f['window'])!=null&&_0x35679a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3ed9ad,mp['get']());};_0x3ed9ad();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x12335e,_0x3244e9,_0x187d34=!0x1){super(_0x12335e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3244e9,void 0x0,_0x187d34),this['eventId']=null;}async['execute'](){let _0x3d197f=rn['get'](this['auth']['_key']());if(!_0x3d197f){try{const _0xecda33=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x3d197f=()=>Promise['resolve'](_0xecda33);}catch(_0x5b0754){_0x3d197f=()=>Promise['reject'](_0x5b0754);}rn['set'](this['auth']['_key'](),_0x3d197f);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3d197f();}async['onAuthEvent'](_0x3fbd35){if(_0x3fbd35['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3fbd35);if(_0x3fbd35['type']==='unknown'){this['resolve'](null);return;}if(_0x3fbd35['eventId']){const _0x3e089b=await this['auth']['_redirectUserForId'](_0x3fbd35['eventId']);if(_0x3e089b)return this['user']=_0x3e089b,super['onAuthEvent'](_0x3fbd35);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x33baeb,_0xcd3381){const _0x2e050e=Cp(_0xcd3381),_0x3ddd63=wp(_0x33baeb);if(!await _0x3ddd63['_isAvailable']())return!0x1;const _0x5b7be6=await _0x3ddd63['_get'](_0x2e050e)==='true';return await _0x3ddd63['_remove'](_0x2e050e),_0x5b7be6;}function Ip(_0xdcedad,_0x5655df){rn['set'](_0xdcedad['_key'](),_0x5655df);}function wp(_0x57881e){return ne(_0x57881e['_redirectPersistence']);}function Cp(_0x32255a){return sn(yp,_0x32255a['config']['apiKey'],_0x32255a['name']);}async function Tp(_0x597ee7,_0x168053,_0x311825=!0x1){if(H(_0x597ee7['app']))return Promise['reject'](se(_0x597ee7));const _0xf8f4cb=qe(_0x597ee7),_0xda2907=fp(_0xf8f4cb,_0x168053),_0x5a0555=await new vp(_0xf8f4cb,_0xda2907,_0x311825)['execute']();return _0x5a0555&&!_0x311825&&(delete _0x5a0555['user']['_redirectEventId'],await _0xf8f4cb['_persistUserIfCurrent'](_0x5a0555['user']),await _0xf8f4cb['_setRedirectUser'](null,_0x168053)),_0x5a0555;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4d56ec){this['auth']=_0x4d56ec,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1c33a8){this['consumers']['add'](_0x1c33a8),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1c33a8)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1c33a8),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x34dfe7){this['consumers']['delete'](_0x34dfe7);}['onEvent'](_0x3c83ec){if(this['hasEventBeenHandled'](_0x3c83ec))return!0x1;let _0xad8f12=!0x1;return this['consumers']['forEach'](_0x13e132=>{this['isEventForConsumer'](_0x3c83ec,_0x13e132)&&(_0xad8f12=!0x0,this['sendToConsumer'](_0x3c83ec,_0x13e132),this['saveEventToCache'](_0x3c83ec));}),this['hasHandledPotentialRedirect']||!Rp(_0x3c83ec)||(this['hasHandledPotentialRedirect']=!0x0,_0xad8f12||(this['queuedRedirectEvent']=_0x3c83ec,_0xad8f12=!0x0)),_0xad8f12;}['sendToConsumer'](_0x412079,_0x153977){var _0x20fbde;if(_0x412079['error']&&!Qa(_0x412079)){const _0x4c45ae=((_0x20fbde=_0x412079['error']['code'])==null?void 0x0:_0x20fbde['split']('auth/')[0x1])||'internal-error';_0x153977['onError'](J(this['auth'],_0x4c45ae));}else _0x153977['onAuthEvent'](_0x412079);}['isEventForConsumer'](_0x4369cd,_0x38ecd8){const _0x2cdc36=_0x38ecd8['eventId']===null||!!_0x4369cd['eventId']&&_0x4369cd['eventId']===_0x38ecd8['eventId'];return _0x38ecd8['filter']['includes'](_0x4369cd['type'])&&_0x2cdc36;}['hasEventBeenHandled'](_0x2bc01a){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2bc01a));}['saveEventToCache'](_0x1bfa77){this['cachedEventUids']['add'](Pr(_0x1bfa77)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x5d884f){return[_0x5d884f['type'],_0x5d884f['eventId'],_0x5d884f['sessionId'],_0x5d884f['tenantId']]['filter'](_0x7db28a=>_0x7db28a)['join']('-');}function Qa({type:_0x574058,error:_0x12746c}){return _0x574058==='unknown'&&(_0x12746c==null?void 0x0:_0x12746c['code'])==='auth/no-auth-event';}function Rp(_0x2e3882){switch(_0x2e3882['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x2e3882);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x23e09a,_0x13d25e={}){return Ae(_0x23e09a,'GET','/v1/projects',_0x13d25e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x51ad89){if(_0x51ad89['config']['emulator'])return;const {authorizedDomains:_0x16aadc}=await Ap(_0x51ad89);for(const _0x1f4a0b of _0x16aadc)try{if(Op(_0x1f4a0b))return;}catch{}K(_0x51ad89,'unauthorized-domain');}function Op(_0x330781){const _0x59cccf=Ni(),{protocol:_0x4fba5a,hostname:_0x35adfe}=new URL(_0x59cccf);if(_0x330781['startsWith']('chrome-extension://')){const _0x5d2a63=new URL(_0x330781);return _0x5d2a63['hostname']===''&&_0x35adfe===''?_0x4fba5a==='chrome-extension:'&&_0x330781['replace']('chrome-extension://','')===_0x59cccf['replace']('chrome-extension://',''):_0x4fba5a==='chrome-extension:'&&_0x5d2a63['hostname']===_0x35adfe;}if(!Np['test'](_0x4fba5a))return!0x1;if(kp['test'](_0x330781))return _0x35adfe===_0x330781;const _0x3a056b=_0x330781['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3a056b+'|'+_0x3a056b+')$','i')['test'](_0x35adfe);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x5f7a6d=X()['___jsl'];if(_0x5f7a6d!=null&&_0x5f7a6d['H']){for(const _0x39b71d of Object['keys'](_0x5f7a6d['H']))if(_0x5f7a6d['H'][_0x39b71d]['r']=_0x5f7a6d['H'][_0x39b71d]['r']||[],_0x5f7a6d['H'][_0x39b71d]['L']=_0x5f7a6d['H'][_0x39b71d]['L']||[],_0x5f7a6d['H'][_0x39b71d]['r']=[..._0x5f7a6d['H'][_0x39b71d]['L']],_0x5f7a6d['CP']){for(let _0x1e7bbd=0x0;_0x1e7bbd<_0x5f7a6d['CP']['length'];_0x1e7bbd++)_0x5f7a6d['CP'][_0x1e7bbd]=null;}}}function Mp(_0x1b3f49){return new Promise((_0x5770fa,_0x4cdf16)=>{var _0x52039a,_0x27c4cb,_0x42a7c3;function _0x51f583(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5770fa(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x4cdf16(J(_0x1b3f49,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x27c4cb=(_0x52039a=X()['gapi'])==null?void 0x0:_0x52039a['iframes'])!=null&&_0x27c4cb['Iframe'])_0x5770fa(gapi['iframes']['getContext']());else{if((_0x42a7c3=X()['gapi'])!=null&&_0x42a7c3['load'])_0x51f583();else{const _0x4027e5=Nf('iframefcb');return X()[_0x4027e5]=()=>{gapi['load']?_0x51f583():_0x4cdf16(J(_0x1b3f49,'network-request-failed'));},Da(kf()+'?onload='+_0x4027e5)['catch'](_0x32a5a1=>_0x4cdf16(_0x32a5a1));}}})['catch'](_0x38f86e=>{throw on=null,_0x38f86e;});}let on=null;function Lp(_0x5dd494){return on=on||Mp(_0x5dd494),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x37594d){const _0xf0825a=_0x37594d['config'];m(_0xf0825a['authDomain'],_0x37594d,'auth-domain-config-required');const _0x3424b5=_0xf0825a['emulator']?Is(_0xf0825a,Up):'https://'+_0x37594d['config']['authDomain']+'/'+Fp,_0x31ee5f={'apiKey':_0xf0825a['apiKey'],'appName':_0x37594d['name'],'v':ct},_0xe9475a=Bp['get'](_0x37594d['config']['apiHost']);_0xe9475a&&(_0x31ee5f['eid']=_0xe9475a);const _0x12e71d=_0x37594d['_getFrameworks']();return _0x12e71d['length']&&(_0x31ee5f['fw']=_0x12e71d['join'](',')),_0x3424b5+'?'+at(_0x31ee5f)['slice'](0x1);}async function Hp(_0x52d411){const _0x8bc09a=await Lp(_0x52d411),_0x5e5276=X()['gapi'];return m(_0x5e5276,_0x52d411,'internal-error'),_0x8bc09a['open']({'where':document['body'],'url':Vp(_0x52d411),'messageHandlersFilter':_0x5e5276['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x3ed53f=>new Promise(async(_0x40191a,_0x106664)=>{await _0x3ed53f['restyle']({'setHideOnLeave':!0x1});const _0x3f86b7=J(_0x52d411,'network-request-failed'),_0x30d5d8=X()['setTimeout'](()=>{_0x106664(_0x3f86b7);},xp['get']());function _0x4969c3(){X()['clearTimeout'](_0x30d5d8),_0x40191a(_0x3ed53f);}_0x3ed53f['ping'](_0x4969c3)['then'](_0x4969c3,()=>{_0x106664(_0x3f86b7);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x5d0d5e){this['window']=_0x5d0d5e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x35512b,_0x2201aa,_0x3416ee,_0x268b84=Gp,_0x1b38d0=qp){const _0x4a3707=Math['max']((window['screen']['availHeight']-_0x1b38d0)/0x2,0x0)['toString'](),_0x1387d0=Math['max']((window['screen']['availWidth']-_0x268b84)/0x2,0x0)['toString']();let _0xdbb298='';const _0x2401d7={...$p,'width':_0x268b84['toString'](),'height':_0x1b38d0['toString'](),'top':_0x4a3707,'left':_0x1387d0},_0x394b6c=W()['toLowerCase']();_0x3416ee&&(_0xdbb298=ba(_0x394b6c)?zp:_0x3416ee),Ta(_0x394b6c)&&(_0x2201aa=_0x2201aa||jp,_0x2401d7['scrollbars']='yes');const _0x21dd54=Object['entries'](_0x2401d7)['reduce']((_0x50dbd2,[_0x3b6ec1,_0x321e19])=>''+_0x50dbd2+_0x3b6ec1+'='+_0x321e19+',','');if(Ef(_0x394b6c)&&_0xdbb298!=='_self')return Yp(_0x2201aa||'',_0xdbb298),new Dr(null);const _0x3af64a=window['open'](_0x2201aa||'',_0xdbb298,_0x21dd54);m(_0x3af64a,_0x35512b,'popup-blocked');try{_0x3af64a['focus']();}catch{}return new Dr(_0x3af64a);}function Yp(_0x49239a,_0x37d0a9){const _0xf8ee6c=document['createElement']('a');_0xf8ee6c['href']=_0x49239a,_0xf8ee6c['target']=_0x37d0a9;const _0x5dc9ad=document['createEvent']('MouseEvent');_0x5dc9ad['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xf8ee6c['dispatchEvent'](_0x5dc9ad);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x5951ae,_0x5d1568,_0x2ac383,_0x391359,_0x25060a,_0x4b01f2){m(_0x5951ae['config']['authDomain'],_0x5951ae,'auth-domain-config-required'),m(_0x5951ae['config']['apiKey'],_0x5951ae,'invalid-api-key');const _0x5f450a={'apiKey':_0x5951ae['config']['apiKey'],'appName':_0x5951ae['name'],'authType':_0x2ac383,'redirectUrl':_0x391359,'v':ct,'eventId':_0x25060a};if(_0x5d1568 instanceof xa){_0x5d1568['setDefaultLanguage'](_0x5951ae['languageCode']),_0x5f450a['providerId']=_0x5d1568['providerId']||'',hi(_0x5d1568['getCustomParameters']())||(_0x5f450a['customParameters']=JSON['stringify'](_0x5d1568['getCustomParameters']()));for(const [_0x33827f,_0x4320ce]of Object['entries']({}))_0x5f450a[_0x33827f]=_0x4320ce;}if(_0x5d1568 instanceof Qt){const _0x28e7c1=_0x5d1568['getScopes']()['filter'](_0x3c35ed=>_0x3c35ed!=='');_0x28e7c1['length']>0x0&&(_0x5f450a['scopes']=_0x28e7c1['join'](','));}_0x5951ae['tenantId']&&(_0x5f450a['tid']=_0x5951ae['tenantId']);const _0x4779cf=_0x5f450a;for(const _0xe08ad8 of Object['keys'](_0x4779cf))_0x4779cf[_0xe08ad8]===void 0x0&&delete _0x4779cf[_0xe08ad8];const _0x1419ea=await _0x5951ae['_getAppCheckToken'](),_0x254f3c=_0x1419ea?'#'+Xp+'='+encodeURIComponent(_0x1419ea):'';return Zp(_0x5951ae)+'?'+at(_0x4779cf)['slice'](0x1)+_0x254f3c;}function Zp({config:_0x4b6f19}){return _0x4b6f19['emulator']?Is(_0x4b6f19,Jp):'https://'+_0x4b6f19['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0xde50c6,_0x2c03f2,_0x3a0e45,_0x5928ff){var _0x5aeb09;ae((_0x5aeb09=this['eventManagers'][_0xde50c6['_key']()])==null?void 0x0:_0x5aeb09['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x875f84=await Mr(_0xde50c6,_0x2c03f2,_0x3a0e45,Ni(),_0x5928ff);return Kp(_0xde50c6,_0x875f84,bs());}async['_openRedirect'](_0x460691,_0x4004b9,_0x28a080,_0x32ae04){await this['_originValidation'](_0x460691);const _0x449ff7=await Mr(_0x460691,_0x4004b9,_0x28a080,Ni(),_0x32ae04);return ip(_0x449ff7),new Promise(()=>{});}['_initialize'](_0x204623){const _0x2a6d28=_0x204623['_key']();if(this['eventManagers'][_0x2a6d28]){const {manager:_0x40796c,promise:_0x3064b3}=this['eventManagers'][_0x2a6d28];return _0x40796c?Promise['resolve'](_0x40796c):(ae(_0x3064b3,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3064b3);}const _0x1842fa=this['initAndGetManager'](_0x204623);return this['eventManagers'][_0x2a6d28]={'promise':_0x1842fa},_0x1842fa['catch'](()=>{delete this['eventManagers'][_0x2a6d28];}),_0x1842fa;}async['initAndGetManager'](_0x58e394){const _0x2412f8=await Hp(_0x58e394),_0x8c041a=new bp(_0x58e394);return _0x2412f8['register']('authEvent',_0x45a42f=>(m(_0x45a42f==null?void 0x0:_0x45a42f['authEvent'],_0x58e394,'invalid-auth-event'),{'status':_0x8c041a['onEvent'](_0x45a42f['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x58e394['_key']()]={'manager':_0x8c041a},this['iframes'][_0x58e394['_key']()]=_0x2412f8,_0x8c041a;}['_isIframeWebStorageSupported'](_0x4f6d3b,_0x287255){this['iframes'][_0x4f6d3b['_key']()]['send'](li,{'type':li},_0x635d8f=>{var _0x30a964;const _0x4b18dd=(_0x30a964=_0x635d8f==null?void 0x0:_0x635d8f[0x0])==null?void 0x0:_0x30a964[li];_0x4b18dd!==void 0x0&&_0x287255(!!_0x4b18dd),K(_0x4f6d3b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x336b3f){const _0x5bac45=_0x336b3f['_key']();return this['originValidationPromises'][_0x5bac45]||(this['originValidationPromises'][_0x5bac45]=Pp(_0x336b3f)),this['originValidationPromises'][_0x5bac45];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x1a9ca5){this['auth']=_0x1a9ca5,this['internalListeners']=new Map();}['getUid'](){var _0x50f1c4;return this['assertAuthConfigured'](),((_0x50f1c4=this['auth']['currentUser'])==null?void 0x0:_0x50f1c4['uid'])||null;}async['getToken'](_0x5309e9){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5309e9)}:null;}['addAuthTokenListener'](_0x406425){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x406425))return;const _0x4db5ec=this['auth']['onIdTokenChanged'](_0x1c551c=>{_0x406425((_0x1c551c==null?void 0x0:_0x1c551c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x406425,_0x4db5ec),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x184915){this['assertAuthConfigured']();const _0x1782fb=this['internalListeners']['get'](_0x184915);_0x1782fb&&(this['internalListeners']['delete'](_0x184915),_0x1782fb(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0xdc631c){switch(_0xdc631c){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x36e140){et(new Me('auth',(_0x4ef720,{options:_0x1f2bde})=>{const _0x2b25c7=_0x4ef720['getProvider']('app')['getImmediate'](),_0x4ec4a7=_0x4ef720['getProvider']('heartbeat'),_0x579b5f=_0x4ef720['getProvider']('app-check-internal'),{apiKey:_0x2d4fd4,authDomain:_0x5838c4}=_0x2b25c7['options'];m(_0x2d4fd4&&!_0x2d4fd4['includes'](':'),'invalid-api-key',{'appName':_0x2b25c7['name']});const _0x130020={'apiKey':_0x2d4fd4,'authDomain':_0x5838c4,'clientPlatform':_0x36e140,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x36e140)},_0x3685f1=new bf(_0x2b25c7,_0x4ec4a7,_0x579b5f,_0x130020);return Lf(_0x3685f1,_0x1f2bde),_0x3685f1;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x6b8c7,_0x554405,_0xbd9386)=>{_0x6b8c7['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x29bb90=>{const _0x5a2cf4=qe(_0x29bb90['getProvider']('auth')['getImmediate']());return(_0x4ec759=>new n_(_0x4ec759))(_0x5a2cf4);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x36e140)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2206c2=>async _0x569c52=>{const _0x203d7d=_0x569c52&&await _0x569c52['getIdTokenResult'](),_0x295914=_0x203d7d&&(new Date()['getTime']()-Date['parse'](_0x203d7d['issuedAtTime']))/0x3e8;if(_0x295914&&_0x295914>o_)return;const _0x7cd611=_0x203d7d==null?void 0x0:_0x203d7d['token'];Fr!==_0x7cd611&&(Fr=_0x7cd611,await fetch(_0x2206c2,{'method':_0x7cd611?'POST':'DELETE','headers':_0x7cd611?{'Authorization':'Bearer\x20'+_0x7cd611}:{}}));};function O_(_0x4a0ada=Qr()){const _0xdc51ca=Ui(_0x4a0ada,'auth');if(_0xdc51ca['isInitialized']())return _0xdc51ca['getImmediate']();const _0x451b21=Mf(_0x4a0ada,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2a7d60=Gr('authTokenSyncURL');if(_0x2a7d60&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x32f318=new URL(_0x2a7d60,location['origin']);if(location['origin']===_0x32f318['origin']){const _0x64610b=a_(_0x32f318['toString']());Jf(_0x451b21,_0x64610b,()=>_0x64610b(_0x451b21['currentUser'])),Qf(_0x451b21,_0x1b73eb=>_0x64610b(_0x1b73eb));}}const _0x2108fb=Hr('auth');return _0x2108fb&&xf(_0x451b21,'http://'+_0x2108fb),_0x451b21;}function c_(){var _0x5205d3;return((_0x5205d3=document['getElementsByTagName']('head'))==null?void 0x0:_0x5205d3[0x0])??document;}Rf({'loadJS'(_0x1f53c0){return new Promise((_0x452f35,_0x219c08)=>{const _0x1224e5=document['createElement']('script');_0x1224e5['setAttribute']('src',_0x1f53c0),_0x1224e5['onload']=_0x452f35,_0x1224e5['onerror']=_0x1cb90c=>{const _0x2853c3=J('internal-error');_0x2853c3['customData']=_0x1cb90c,_0x219c08(_0x2853c3);},_0x1224e5['type']='text/javascript',_0x1224e5['charset']='UTF-8',c_()['appendChild'](_0x1224e5);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};