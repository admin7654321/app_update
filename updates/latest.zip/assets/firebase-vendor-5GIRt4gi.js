const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x8e9301,_0x48fede){if(!_0x8e9301)throw ot(_0x48fede);},ot=function(_0x15f3b9){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x15f3b9);},Wr=function(_0x4b1dc3){const _0x14dbf1=[];let _0x252021=0x0;for(let _0x3024b1=0x0;_0x3024b1<_0x4b1dc3['length'];_0x3024b1++){let _0x9ddde8=_0x4b1dc3['charCodeAt'](_0x3024b1);_0x9ddde8<0x80?_0x14dbf1[_0x252021++]=_0x9ddde8:_0x9ddde8<0x800?(_0x14dbf1[_0x252021++]=_0x9ddde8>>0x6|0xc0,_0x14dbf1[_0x252021++]=_0x9ddde8&0x3f|0x80):(_0x9ddde8&0xfc00)===0xd800&&_0x3024b1+0x1<_0x4b1dc3['length']&&(_0x4b1dc3['charCodeAt'](_0x3024b1+0x1)&0xfc00)===0xdc00?(_0x9ddde8=0x10000+((_0x9ddde8&0x3ff)<<0xa)+(_0x4b1dc3['charCodeAt'](++_0x3024b1)&0x3ff),_0x14dbf1[_0x252021++]=_0x9ddde8>>0x12|0xf0,_0x14dbf1[_0x252021++]=_0x9ddde8>>0xc&0x3f|0x80,_0x14dbf1[_0x252021++]=_0x9ddde8>>0x6&0x3f|0x80,_0x14dbf1[_0x252021++]=_0x9ddde8&0x3f|0x80):(_0x14dbf1[_0x252021++]=_0x9ddde8>>0xc|0xe0,_0x14dbf1[_0x252021++]=_0x9ddde8>>0x6&0x3f|0x80,_0x14dbf1[_0x252021++]=_0x9ddde8&0x3f|0x80);}return _0x14dbf1;},Za=function(_0x1efa15){const _0x4829b7=[];let _0x169b3=0x0,_0x431ecf=0x0;for(;_0x169b3<_0x1efa15['length'];){const _0x57e59a=_0x1efa15[_0x169b3++];if(_0x57e59a<0x80)_0x4829b7[_0x431ecf++]=String['fromCharCode'](_0x57e59a);else{if(_0x57e59a>0xbf&&_0x57e59a<0xe0){const _0x4852ae=_0x1efa15[_0x169b3++];_0x4829b7[_0x431ecf++]=String['fromCharCode']((_0x57e59a&0x1f)<<0x6|_0x4852ae&0x3f);}else{if(_0x57e59a>0xef&&_0x57e59a<0x16d){const _0x1dcd10=_0x1efa15[_0x169b3++],_0x182c61=_0x1efa15[_0x169b3++],_0x292a19=_0x1efa15[_0x169b3++],_0x3993ec=((_0x57e59a&0x7)<<0x12|(_0x1dcd10&0x3f)<<0xc|(_0x182c61&0x3f)<<0x6|_0x292a19&0x3f)-0x10000;_0x4829b7[_0x431ecf++]=String['fromCharCode'](0xd800+(_0x3993ec>>0xa)),_0x4829b7[_0x431ecf++]=String['fromCharCode'](0xdc00+(_0x3993ec&0x3ff));}else{const _0x4e964e=_0x1efa15[_0x169b3++],_0x488fac=_0x1efa15[_0x169b3++];_0x4829b7[_0x431ecf++]=String['fromCharCode']((_0x57e59a&0xf)<<0xc|(_0x4e964e&0x3f)<<0x6|_0x488fac&0x3f);}}}}return _0x4829b7['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x309d27,_0x26920e){if(!Array['isArray'](_0x309d27))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xf17662=_0x26920e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x36e863=[];for(let _0x15cc53=0x0;_0x15cc53<_0x309d27['length'];_0x15cc53+=0x3){const _0x10c428=_0x309d27[_0x15cc53],_0x1c3413=_0x15cc53+0x1<_0x309d27['length'],_0x4a1410=_0x1c3413?_0x309d27[_0x15cc53+0x1]:0x0,_0x227965=_0x15cc53+0x2<_0x309d27['length'],_0x40c2d0=_0x227965?_0x309d27[_0x15cc53+0x2]:0x0,_0x5c51df=_0x10c428>>0x2,_0xc8e6bb=(_0x10c428&0x3)<<0x4|_0x4a1410>>0x4;let _0xad0a89=(_0x4a1410&0xf)<<0x2|_0x40c2d0>>0x6,_0x3f38ec=_0x40c2d0&0x3f;_0x227965||(_0x3f38ec=0x40,_0x1c3413||(_0xad0a89=0x40)),_0x36e863['push'](_0xf17662[_0x5c51df],_0xf17662[_0xc8e6bb],_0xf17662[_0xad0a89],_0xf17662[_0x3f38ec]);}return _0x36e863['join']('');},'encodeString'(_0x3b74d3,_0x422356){return this['HAS_NATIVE_SUPPORT']&&!_0x422356?btoa(_0x3b74d3):this['encodeByteArray'](Wr(_0x3b74d3),_0x422356);},'decodeString'(_0x1f0985,_0x4dbb2f){return this['HAS_NATIVE_SUPPORT']&&!_0x4dbb2f?atob(_0x1f0985):Za(this['decodeStringToByteArray'](_0x1f0985,_0x4dbb2f));},'decodeStringToByteArray'(_0x487396,_0x4759d5){this['init_']();const _0xb98007=_0x4759d5?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x308ee7=[];for(let _0x204ac8=0x0;_0x204ac8<_0x487396['length'];){const _0xce9aa7=_0xb98007[_0x487396['charAt'](_0x204ac8++)],_0x43c1d8=_0x204ac8<_0x487396['length']?_0xb98007[_0x487396['charAt'](_0x204ac8)]:0x0;++_0x204ac8;const _0x57e28a=_0x204ac8<_0x487396['length']?_0xb98007[_0x487396['charAt'](_0x204ac8)]:0x40;++_0x204ac8;const _0x389819=_0x204ac8<_0x487396['length']?_0xb98007[_0x487396['charAt'](_0x204ac8)]:0x40;if(++_0x204ac8,_0xce9aa7==null||_0x43c1d8==null||_0x57e28a==null||_0x389819==null)throw new ec();const _0x541f79=_0xce9aa7<<0x2|_0x43c1d8>>0x4;if(_0x308ee7['push'](_0x541f79),_0x57e28a!==0x40){const _0x5435bc=_0x43c1d8<<0x4&0xf0|_0x57e28a>>0x2;if(_0x308ee7['push'](_0x5435bc),_0x389819!==0x40){const _0x46925a=_0x57e28a<<0x6&0xc0|_0x389819;_0x308ee7['push'](_0x46925a);}}}return _0x308ee7;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x59ba67=0x0;_0x59ba67<this['ENCODED_VALS']['length'];_0x59ba67++)this['byteToCharMap_'][_0x59ba67]=this['ENCODED_VALS']['charAt'](_0x59ba67),this['charToByteMap_'][this['byteToCharMap_'][_0x59ba67]]=_0x59ba67,this['byteToCharMapWebSafe_'][_0x59ba67]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x59ba67),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x59ba67]]=_0x59ba67,_0x59ba67>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x59ba67)]=_0x59ba67,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x59ba67)]=_0x59ba67);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x195fb7){const _0x45a62b=Wr(_0x195fb7);return Di['encodeByteArray'](_0x45a62b,!0x0);},an=function(_0x19185c){return Br(_0x19185c)['replace'](/\./g,'');},cn=function(_0x398423){try{return Di['decodeString'](_0x398423,!0x0);}catch(_0x64c7f6){console['error']('base64Decode\x20failed:\x20',_0x64c7f6);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x5abb81){return Vr(void 0x0,_0x5abb81);}function Vr(_0x587dfa,_0x1a6bee){if(!(_0x1a6bee instanceof Object))return _0x1a6bee;switch(_0x1a6bee['constructor']){case Date:const _0x1e1ebb=_0x1a6bee;return new Date(_0x1e1ebb['getTime']());case Object:_0x587dfa===void 0x0&&(_0x587dfa={});break;case Array:_0x587dfa=[];break;default:return _0x1a6bee;}for(const _0x1f3e8f in _0x1a6bee)!_0x1a6bee['hasOwnProperty'](_0x1f3e8f)||!nc(_0x1f3e8f)||(_0x587dfa[_0x1f3e8f]=Vr(_0x587dfa[_0x1f3e8f],_0x1a6bee[_0x1f3e8f]));return _0x587dfa;}function nc(_0x3eb2a8){return _0x3eb2a8!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x480530=As['__FIREBASE_DEFAULTS__'];if(_0x480530)return JSON['parse'](_0x480530);},oc=()=>{if(typeof document>'u')return;let _0x94ef9e;try{_0x94ef9e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x584c3f=_0x94ef9e&&cn(_0x94ef9e[0x1]);return _0x584c3f&&JSON['parse'](_0x584c3f);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x19dba0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x19dba0);return;}},Hr=_0x19dce5=>{var _0x5e1c9b,_0x1c6080;return(_0x1c6080=(_0x5e1c9b=Mi())==null?void 0x0:_0x5e1c9b['emulatorHosts'])==null?void 0x0:_0x1c6080[_0x19dce5];},ac=_0x39b20a=>{const _0x4dcf67=Hr(_0x39b20a);if(!_0x4dcf67)return;const _0x7c8995=_0x4dcf67['lastIndexOf'](':');if(_0x7c8995<=0x0||_0x7c8995+0x1===_0x4dcf67['length'])throw new Error('Invalid\x20host\x20'+_0x4dcf67+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x431c9a=parseInt(_0x4dcf67['substring'](_0x7c8995+0x1),0xa);return _0x4dcf67[0x0]==='['?[_0x4dcf67['substring'](0x1,_0x7c8995-0x1),_0x431c9a]:[_0x4dcf67['substring'](0x0,_0x7c8995),_0x431c9a];},$r=()=>{var _0x5a418e;return(_0x5a418e=Mi())==null?void 0x0:_0x5a418e['config'];},Gr=_0x5a0b6e=>{var _0x3dc876;return(_0x3dc876=Mi())==null?void 0x0:_0x3dc876['_'+_0x5a0b6e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x431584,_0x226a9f)=>{this['resolve']=_0x431584,this['reject']=_0x226a9f;});}['wrapCallback'](_0x5a2f80){return(_0x5a9dcf,_0x398a9e)=>{_0x5a9dcf?this['reject'](_0x5a9dcf):this['resolve'](_0x398a9e),typeof _0x5a2f80=='function'&&(this['promise']['catch'](()=>{}),_0x5a2f80['length']===0x1?_0x5a2f80(_0x5a9dcf):_0x5a2f80(_0x5a9dcf,_0x398a9e));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3defc9,_0x5f228e){if(_0x3defc9['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x146629={'alg':'none','type':'JWT'},_0xe6f9f6=_0x5f228e||'demo-project',_0x1630b0=_0x3defc9['iat']||0x0,_0x59f044=_0x3defc9['sub']||_0x3defc9['user_id'];if(!_0x59f044)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3e2a45={'iss':'https://securetoken.google.com/'+_0xe6f9f6,'aud':_0xe6f9f6,'iat':_0x1630b0,'exp':_0x1630b0+0xe10,'auth_time':_0x1630b0,'sub':_0x59f044,'user_id':_0x59f044,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3defc9};return[an(JSON['stringify'](_0x146629)),an(JSON['stringify'](_0x3e2a45)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4ffba3=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4ffba3=='object'&&_0x4ffba3['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x59f03b=W();return _0x59f03b['indexOf']('MSIE\x20')>=0x0||_0x59f03b['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0xc26149,_0x2c1ce1)=>{try{let _0x39d8a7=!0x0;const _0x52e67b='validate-browser-context-for-indexeddb-analytics-module',_0x21f549=self['indexedDB']['open'](_0x52e67b);_0x21f549['onsuccess']=()=>{_0x21f549['result']['close'](),_0x39d8a7||self['indexedDB']['deleteDatabase'](_0x52e67b),_0xc26149(!0x0);},_0x21f549['onupgradeneeded']=()=>{_0x39d8a7=!0x1;},_0x21f549['onerror']=()=>{var _0x3ec608;_0x2c1ce1(((_0x3ec608=_0x21f549['error'])==null?void 0x0:_0x3ec608['message'])||'');};}catch(_0x52b4ce){_0x2c1ce1(_0x52b4ce);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xeeafe0,_0x674213,_0x285ca2){super(_0x674213),this['code']=_0xeeafe0,this['customData']=_0x285ca2,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x5e98d8,_0x35eb2a,_0x45cb2a){this['service']=_0x5e98d8,this['serviceName']=_0x35eb2a,this['errors']=_0x45cb2a;}['create'](_0x1f4a5e,..._0x39c476){const _0x1808cc=_0x39c476[0x0]||{},_0x878525=this['service']+'/'+_0x1f4a5e,_0x4946e8=this['errors'][_0x1f4a5e],_0x43a8ed=_0x4946e8?gc(_0x4946e8,_0x1808cc):'Error',_0x8cc221=this['serviceName']+':\x20'+_0x43a8ed+'\x20('+_0x878525+').';return new Se(_0x878525,_0x8cc221,_0x1808cc);}}function gc(_0x58fd18,_0x733082){return _0x58fd18['replace'](mc,(_0xe06212,_0x8dde65)=>{const _0x58bca1=_0x733082[_0x8dde65];return _0x58bca1!=null?String(_0x58bca1):'<'+_0x8dde65+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x50e1a7){return JSON['parse'](_0x50e1a7);}function O(_0x2927b4){return JSON['stringify'](_0x2927b4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x3e0806){let _0xaff172={},_0x23d583={},_0x3b6ba2={},_0x3e6933='';try{const _0x2f9592=_0x3e0806['split']('.');_0xaff172=bt(cn(_0x2f9592[0x0])||''),_0x23d583=bt(cn(_0x2f9592[0x1])||''),_0x3e6933=_0x2f9592[0x2],_0x3b6ba2=_0x23d583['d']||{},delete _0x23d583['d'];}catch{}return{'header':_0xaff172,'claims':_0x23d583,'data':_0x3b6ba2,'signature':_0x3e6933};},yc=function(_0x1d7492){const _0x50fbe0=zr(_0x1d7492),_0x501558=_0x50fbe0['claims'];return!!_0x501558&&typeof _0x501558=='object'&&_0x501558['hasOwnProperty']('iat');},vc=function(_0x254283){const _0xefc94e=zr(_0x254283)['claims'];return typeof _0xefc94e=='object'&&_0xefc94e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3be747,_0x2d4d3d){return Object['prototype']['hasOwnProperty']['call'](_0x3be747,_0x2d4d3d);}function Oe(_0x256a7f,_0x574540){if(Object['prototype']['hasOwnProperty']['call'](_0x256a7f,_0x574540))return _0x256a7f[_0x574540];}function hi(_0x8fc616){for(const _0x327501 in _0x8fc616)if(Object['prototype']['hasOwnProperty']['call'](_0x8fc616,_0x327501))return!0x1;return!0x0;}function ln(_0x3bd65f,_0x3ca299,_0x2f1e2b){const _0xe3a429={};for(const _0x2e6a5d in _0x3bd65f)Object['prototype']['hasOwnProperty']['call'](_0x3bd65f,_0x2e6a5d)&&(_0xe3a429[_0x2e6a5d]=_0x3ca299['call'](_0x2f1e2b,_0x3bd65f[_0x2e6a5d],_0x2e6a5d,_0x3bd65f));return _0xe3a429;}function De(_0x2acb7f,_0x1c60aa){if(_0x2acb7f===_0x1c60aa)return!0x0;const _0x47b5e8=Object['keys'](_0x2acb7f),_0x27decc=Object['keys'](_0x1c60aa);for(const _0x90d60e of _0x47b5e8){if(!_0x27decc['includes'](_0x90d60e))return!0x1;const _0x5c281e=_0x2acb7f[_0x90d60e],_0x447a7c=_0x1c60aa[_0x90d60e];if(ks(_0x5c281e)&&ks(_0x447a7c)){if(!De(_0x5c281e,_0x447a7c))return!0x1;}else{if(_0x5c281e!==_0x447a7c)return!0x1;}}for(const _0x3311a3 of _0x27decc)if(!_0x47b5e8['includes'](_0x3311a3))return!0x1;return!0x0;}function ks(_0x243188){return _0x243188!==null&&typeof _0x243188=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4554eb){const _0x29fe96=[];for(const [_0x9596f4,_0x154df4]of Object['entries'](_0x4554eb))Array['isArray'](_0x154df4)?_0x154df4['forEach'](_0x8ecc8b=>{_0x29fe96['push'](encodeURIComponent(_0x9596f4)+'='+encodeURIComponent(_0x8ecc8b));}):_0x29fe96['push'](encodeURIComponent(_0x9596f4)+'='+encodeURIComponent(_0x154df4));return _0x29fe96['length']?'&'+_0x29fe96['join']('&'):'';}function yt(_0x1d4edd){const _0x37854a={};return _0x1d4edd['replace'](/^\?/,'')['split']('&')['forEach'](_0x2cfbaf=>{if(_0x2cfbaf){const [_0x243031,_0x357460]=_0x2cfbaf['split']('=');_0x37854a[decodeURIComponent(_0x243031)]=decodeURIComponent(_0x357460);}}),_0x37854a;}function vt(_0x1dee54){const _0x2a8e41=_0x1dee54['indexOf']('?');if(!_0x2a8e41)return'';const _0x442774=_0x1dee54['indexOf']('#',_0x2a8e41);return _0x1dee54['substring'](_0x2a8e41,_0x442774>0x0?_0x442774:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x204de4=0x1;_0x204de4<this['blockSize'];++_0x204de4)this['pad_'][_0x204de4]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5a4b22,_0x33a90b){_0x33a90b||(_0x33a90b=0x0);const _0x465ee0=this['W_'];if(typeof _0x5a4b22=='string'){for(let _0x3dcaca=0x0;_0x3dcaca<0x10;_0x3dcaca++)_0x465ee0[_0x3dcaca]=_0x5a4b22['charCodeAt'](_0x33a90b)<<0x18|_0x5a4b22['charCodeAt'](_0x33a90b+0x1)<<0x10|_0x5a4b22['charCodeAt'](_0x33a90b+0x2)<<0x8|_0x5a4b22['charCodeAt'](_0x33a90b+0x3),_0x33a90b+=0x4;}else{for(let _0x1f0f20=0x0;_0x1f0f20<0x10;_0x1f0f20++)_0x465ee0[_0x1f0f20]=_0x5a4b22[_0x33a90b]<<0x18|_0x5a4b22[_0x33a90b+0x1]<<0x10|_0x5a4b22[_0x33a90b+0x2]<<0x8|_0x5a4b22[_0x33a90b+0x3],_0x33a90b+=0x4;}for(let _0x52b134=0x10;_0x52b134<0x50;_0x52b134++){const _0x173a3c=_0x465ee0[_0x52b134-0x3]^_0x465ee0[_0x52b134-0x8]^_0x465ee0[_0x52b134-0xe]^_0x465ee0[_0x52b134-0x10];_0x465ee0[_0x52b134]=(_0x173a3c<<0x1|_0x173a3c>>>0x1f)&0xffffffff;}let _0x1c50c0=this['chain_'][0x0],_0x31a007=this['chain_'][0x1],_0x4e16ff=this['chain_'][0x2],_0x3e917f=this['chain_'][0x3],_0x451005=this['chain_'][0x4],_0x2b164e,_0x53f5f6;for(let _0x23374c=0x0;_0x23374c<0x50;_0x23374c++){_0x23374c<0x28?_0x23374c<0x14?(_0x2b164e=_0x3e917f^_0x31a007&(_0x4e16ff^_0x3e917f),_0x53f5f6=0x5a827999):(_0x2b164e=_0x31a007^_0x4e16ff^_0x3e917f,_0x53f5f6=0x6ed9eba1):_0x23374c<0x3c?(_0x2b164e=_0x31a007&_0x4e16ff|_0x3e917f&(_0x31a007|_0x4e16ff),_0x53f5f6=0x8f1bbcdc):(_0x2b164e=_0x31a007^_0x4e16ff^_0x3e917f,_0x53f5f6=0xca62c1d6);const _0x4774fc=(_0x1c50c0<<0x5|_0x1c50c0>>>0x1b)+_0x2b164e+_0x451005+_0x53f5f6+_0x465ee0[_0x23374c]&0xffffffff;_0x451005=_0x3e917f,_0x3e917f=_0x4e16ff,_0x4e16ff=(_0x31a007<<0x1e|_0x31a007>>>0x2)&0xffffffff,_0x31a007=_0x1c50c0,_0x1c50c0=_0x4774fc;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1c50c0&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x31a007&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4e16ff&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3e917f&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x451005&0xffffffff;}['update'](_0x45ff51,_0x5cb04f){if(_0x45ff51==null)return;_0x5cb04f===void 0x0&&(_0x5cb04f=_0x45ff51['length']);const _0x543ed3=_0x5cb04f-this['blockSize'];let _0x5b1691=0x0;const _0x454189=this['buf_'];let _0x341385=this['inbuf_'];for(;_0x5b1691<_0x5cb04f;){if(_0x341385===0x0){for(;_0x5b1691<=_0x543ed3;)this['compress_'](_0x45ff51,_0x5b1691),_0x5b1691+=this['blockSize'];}if(typeof _0x45ff51=='string'){for(;_0x5b1691<_0x5cb04f;)if(_0x454189[_0x341385]=_0x45ff51['charCodeAt'](_0x5b1691),++_0x341385,++_0x5b1691,_0x341385===this['blockSize']){this['compress_'](_0x454189),_0x341385=0x0;break;}}else{for(;_0x5b1691<_0x5cb04f;)if(_0x454189[_0x341385]=_0x45ff51[_0x5b1691],++_0x341385,++_0x5b1691,_0x341385===this['blockSize']){this['compress_'](_0x454189),_0x341385=0x0;break;}}}this['inbuf_']=_0x341385,this['total_']+=_0x5cb04f;}['digest'](){const _0x632e85=[];let _0x53fee6=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3595e5=this['blockSize']-0x1;_0x3595e5>=0x38;_0x3595e5--)this['buf_'][_0x3595e5]=_0x53fee6&0xff,_0x53fee6/=0x100;this['compress_'](this['buf_']);let _0x151f46=0x0;for(let _0x33344a=0x0;_0x33344a<0x5;_0x33344a++)for(let _0x20800d=0x18;_0x20800d>=0x0;_0x20800d-=0x8)_0x632e85[_0x151f46]=this['chain_'][_0x33344a]>>_0x20800d&0xff,++_0x151f46;return _0x632e85;}}function Ic(_0x4d3d5a,_0x1cad6e){const _0x28fff9=new wc(_0x4d3d5a,_0x1cad6e);return _0x28fff9['subscribe']['bind'](_0x28fff9);}class wc{constructor(_0x28f962,_0x20088b){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x20088b,this['task']['then'](()=>{_0x28f962(this);})['catch'](_0x530449=>{this['error'](_0x530449);});}['next'](_0x116418){this['forEachObserver'](_0x205f4c=>{_0x205f4c['next'](_0x116418);});}['error'](_0x2dfd1f){this['forEachObserver'](_0x7861dc=>{_0x7861dc['error'](_0x2dfd1f);}),this['close'](_0x2dfd1f);}['complete'](){this['forEachObserver'](_0x7e809f=>{_0x7e809f['complete']();}),this['close']();}['subscribe'](_0x3411f8,_0x57aa91,_0x282872){let _0x4eec2d;if(_0x3411f8===void 0x0&&_0x57aa91===void 0x0&&_0x282872===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x3411f8,['next','error','complete'])?_0x4eec2d=_0x3411f8:_0x4eec2d={'next':_0x3411f8,'error':_0x57aa91,'complete':_0x282872},_0x4eec2d['next']===void 0x0&&(_0x4eec2d['next']=Qn),_0x4eec2d['error']===void 0x0&&(_0x4eec2d['error']=Qn),_0x4eec2d['complete']===void 0x0&&(_0x4eec2d['complete']=Qn);const _0x5288b6=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4eec2d['error'](this['finalError']):_0x4eec2d['complete']();}catch{}}),this['observers']['push'](_0x4eec2d),_0x5288b6;}['unsubscribeOne'](_0x331c69){this['observers']===void 0x0||this['observers'][_0x331c69]===void 0x0||(delete this['observers'][_0x331c69],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x456812){if(!this['finalized']){for(let _0x398ffd=0x0;_0x398ffd<this['observers']['length'];_0x398ffd++)this['sendOne'](_0x398ffd,_0x456812);}}['sendOne'](_0x253bd7,_0x5815e0){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x253bd7]!==void 0x0)try{_0x5815e0(this['observers'][_0x253bd7]);}catch(_0x203189){typeof console<'u'&&console['error']&&console['error'](_0x203189);}});}['close'](_0xe023b6){this['finalized']||(this['finalized']=!0x0,_0xe023b6!==void 0x0&&(this['finalError']=_0xe023b6),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x1cf1fc,_0x5b229b){if(typeof _0x1cf1fc!='object'||_0x1cf1fc===null)return!0x1;for(const _0x2a03c2 of _0x5b229b)if(_0x2a03c2 in _0x1cf1fc&&typeof _0x1cf1fc[_0x2a03c2]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0xab83d7,_0x4aa0c3){return _0xab83d7+'\x20failed:\x20'+_0x4aa0c3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0xbf24cb){const _0xdef1a4=[];let _0x4c9f7c=0x0;for(let _0x344da8=0x0;_0x344da8<_0xbf24cb['length'];_0x344da8++){let _0x41310f=_0xbf24cb['charCodeAt'](_0x344da8);if(_0x41310f>=0xd800&&_0x41310f<=0xdbff){const _0x13a682=_0x41310f-0xd800;_0x344da8++,f(_0x344da8<_0xbf24cb['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4cf69a=_0xbf24cb['charCodeAt'](_0x344da8)-0xdc00;_0x41310f=0x10000+(_0x13a682<<0xa)+_0x4cf69a;}_0x41310f<0x80?_0xdef1a4[_0x4c9f7c++]=_0x41310f:_0x41310f<0x800?(_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0x6|0xc0,_0xdef1a4[_0x4c9f7c++]=_0x41310f&0x3f|0x80):_0x41310f<0x10000?(_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0xc|0xe0,_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0x6&0x3f|0x80,_0xdef1a4[_0x4c9f7c++]=_0x41310f&0x3f|0x80):(_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0x12|0xf0,_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0xc&0x3f|0x80,_0xdef1a4[_0x4c9f7c++]=_0x41310f>>0x6&0x3f|0x80,_0xdef1a4[_0x4c9f7c++]=_0x41310f&0x3f|0x80);}return _0xdef1a4;},Pn=function(_0x2bfeb3){let _0x3d8287=0x0;for(let _0x4ec395=0x0;_0x4ec395<_0x2bfeb3['length'];_0x4ec395++){const _0x5e5c39=_0x2bfeb3['charCodeAt'](_0x4ec395);_0x5e5c39<0x80?_0x3d8287++:_0x5e5c39<0x800?_0x3d8287+=0x2:_0x5e5c39>=0xd800&&_0x5e5c39<=0xdbff?(_0x3d8287+=0x4,_0x4ec395++):_0x3d8287+=0x3;}return _0x3d8287;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x1edad9){return _0x1edad9&&_0x1edad9['_delegate']?_0x1edad9['_delegate']:_0x1edad9;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x3871f1){try{return(_0x3871f1['startsWith']('http://')||_0x3871f1['startsWith']('https://')?new URL(_0x3871f1)['hostname']:_0x3871f1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1f1f6b){return(await fetch(_0x1f1f6b,{'credentials':'include'}))['ok'];}class Me{constructor(_0x2b2638,_0x124c41,_0x1b827c){this['name']=_0x2b2638,this['instanceFactory']=_0x124c41,this['type']=_0x1b827c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2f5248){return this['instantiationMode']=_0x2f5248,this;}['setMultipleInstances'](_0x57d048){return this['multipleInstances']=_0x57d048,this;}['setServiceProps'](_0x3b12f5){return this['serviceProps']=_0x3b12f5,this;}['setInstanceCreatedCallback'](_0xe6e94a){return this['onInstanceCreated']=_0xe6e94a,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x26a5f6,_0x1c72fd){this['name']=_0x26a5f6,this['container']=_0x1c72fd,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x15b602){const _0x160576=this['normalizeInstanceIdentifier'](_0x15b602);if(!this['instancesDeferred']['has'](_0x160576)){const _0x1118c5=new Ve();if(this['instancesDeferred']['set'](_0x160576,_0x1118c5),this['isInitialized'](_0x160576)||this['shouldAutoInitialize']())try{const _0x1b6964=this['getOrInitializeService']({'instanceIdentifier':_0x160576});_0x1b6964&&_0x1118c5['resolve'](_0x1b6964);}catch{}}return this['instancesDeferred']['get'](_0x160576)['promise'];}['getImmediate'](_0x5e6328){const _0x282ffb=this['normalizeInstanceIdentifier'](_0x5e6328==null?void 0x0:_0x5e6328['identifier']),_0xf24cf9=(_0x5e6328==null?void 0x0:_0x5e6328['optional'])??!0x1;if(this['isInitialized'](_0x282ffb)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x282ffb});}catch(_0x178cf2){if(_0xf24cf9)return null;throw _0x178cf2;}else{if(_0xf24cf9)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x5125b2){if(_0x5125b2['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x5125b2['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x5125b2,!!this['shouldAutoInitialize']()){if(Rc(_0x5125b2))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x28ee19,_0xed5719]of this['instancesDeferred']['entries']()){const _0x2059a9=this['normalizeInstanceIdentifier'](_0x28ee19);try{const _0x368d12=this['getOrInitializeService']({'instanceIdentifier':_0x2059a9});_0xed5719['resolve'](_0x368d12);}catch{}}}}['clearInstance'](_0x397461=ke){this['instancesDeferred']['delete'](_0x397461),this['instancesOptions']['delete'](_0x397461),this['instances']['delete'](_0x397461);}async['delete'](){const _0x4a5b31=Array['from'](this['instances']['values']());await Promise['all']([..._0x4a5b31['filter'](_0x3151ce=>'INTERNAL'in _0x3151ce)['map'](_0x2e7f1c=>_0x2e7f1c['INTERNAL']['delete']()),..._0x4a5b31['filter'](_0x1608e6=>'_delete'in _0x1608e6)['map'](_0x37d28c=>_0x37d28c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x49c7cf=ke){return this['instances']['has'](_0x49c7cf);}['getOptions'](_0x39af69=ke){return this['instancesOptions']['get'](_0x39af69)||{};}['initialize'](_0x2bb30d={}){const {options:_0x5c88ce={}}=_0x2bb30d,_0x4d6b04=this['normalizeInstanceIdentifier'](_0x2bb30d['instanceIdentifier']);if(this['isInitialized'](_0x4d6b04))throw Error(this['name']+'('+_0x4d6b04+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x39636a=this['getOrInitializeService']({'instanceIdentifier':_0x4d6b04,'options':_0x5c88ce});for(const [_0x5cd7dc,_0x17c457]of this['instancesDeferred']['entries']()){const _0x7936a7=this['normalizeInstanceIdentifier'](_0x5cd7dc);_0x4d6b04===_0x7936a7&&_0x17c457['resolve'](_0x39636a);}return _0x39636a;}['onInit'](_0x3525c2,_0x121d3b){const _0x3f42ac=this['normalizeInstanceIdentifier'](_0x121d3b),_0x3d89b6=this['onInitCallbacks']['get'](_0x3f42ac)??new Set();_0x3d89b6['add'](_0x3525c2),this['onInitCallbacks']['set'](_0x3f42ac,_0x3d89b6);const _0x2ec825=this['instances']['get'](_0x3f42ac);return _0x2ec825&&_0x3525c2(_0x2ec825,_0x3f42ac),()=>{_0x3d89b6['delete'](_0x3525c2);};}['invokeOnInitCallbacks'](_0x1e2a35,_0x60cbda){const _0x1dc6a7=this['onInitCallbacks']['get'](_0x60cbda);if(_0x1dc6a7){for(const _0x1dae75 of _0x1dc6a7)try{_0x1dae75(_0x1e2a35,_0x60cbda);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x138184,options:_0x587932={}}){let _0x3ad3c6=this['instances']['get'](_0x138184);if(!_0x3ad3c6&&this['component']&&(_0x3ad3c6=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x138184),'options':_0x587932}),this['instances']['set'](_0x138184,_0x3ad3c6),this['instancesOptions']['set'](_0x138184,_0x587932),this['invokeOnInitCallbacks'](_0x3ad3c6,_0x138184),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x138184,_0x3ad3c6);}catch{}return _0x3ad3c6||null;}['normalizeInstanceIdentifier'](_0x9c1687=ke){return this['component']?this['component']['multipleInstances']?_0x9c1687:ke:_0x9c1687;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x11a85e){return _0x11a85e===ke?void 0x0:_0x11a85e;}function Rc(_0x13a725){return _0x13a725['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x53657f){this['name']=_0x53657f,this['providers']=new Map();}['addComponent'](_0x48a03a){const _0x3d364f=this['getProvider'](_0x48a03a['name']);if(_0x3d364f['isComponentSet']())throw new Error('Component\x20'+_0x48a03a['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3d364f['setComponent'](_0x48a03a);}['addOrOverwriteComponent'](_0x4cc7d6){this['getProvider'](_0x4cc7d6['name'])['isComponentSet']()&&this['providers']['delete'](_0x4cc7d6['name']),this['addComponent'](_0x4cc7d6);}['getProvider'](_0x33293e){if(this['providers']['has'](_0x33293e))return this['providers']['get'](_0x33293e);const _0x211fab=new Sc(_0x33293e,this);return this['providers']['set'](_0x33293e,_0x211fab),_0x211fab;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1a7e84){_0x1a7e84[_0x1a7e84['DEBUG']=0x0]='DEBUG',_0x1a7e84[_0x1a7e84['VERBOSE']=0x1]='VERBOSE',_0x1a7e84[_0x1a7e84['INFO']=0x2]='INFO',_0x1a7e84[_0x1a7e84['WARN']=0x3]='WARN',_0x1a7e84[_0x1a7e84['ERROR']=0x4]='ERROR',_0x1a7e84[_0x1a7e84['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x275dd5,_0x14c7c3,..._0x129f8a)=>{if(_0x14c7c3<_0x275dd5['logLevel'])return;const _0x453269=new Date()['toISOString'](),_0x4be1bc=Pc[_0x14c7c3];if(_0x4be1bc)console[_0x4be1bc]('['+_0x453269+']\x20\x20'+_0x275dd5['name']+':',..._0x129f8a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x14c7c3+')');};class xi{constructor(_0x184031){this['name']=_0x184031,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x51dba4){if(!(_0x51dba4 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x51dba4+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x51dba4;}['setLogLevel'](_0x34f71f){this['_logLevel']=typeof _0x34f71f=='string'?kc[_0x34f71f]:_0x34f71f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4a706f){if(typeof _0x4a706f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4a706f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x459fdd){this['_userLogHandler']=_0x459fdd;}['debug'](..._0x1c5aed){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1c5aed),this['_logHandler'](this,T['DEBUG'],..._0x1c5aed);}['log'](..._0x58fcfb){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x58fcfb),this['_logHandler'](this,T['VERBOSE'],..._0x58fcfb);}['info'](..._0x1decb3){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1decb3),this['_logHandler'](this,T['INFO'],..._0x1decb3);}['warn'](..._0x4007ad){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4007ad),this['_logHandler'](this,T['WARN'],..._0x4007ad);}['error'](..._0x4e912f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4e912f),this['_logHandler'](this,T['ERROR'],..._0x4e912f);}}const Dc=(_0x67c0e3,_0x15e794)=>_0x15e794['some'](_0x52b312=>_0x67c0e3 instanceof _0x52b312);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x50277d){const _0x128cc1=new Promise((_0x368d8c,_0x387f5f)=>{const _0x499e8e=()=>{_0x50277d['removeEventListener']('success',_0xa1bd15),_0x50277d['removeEventListener']('error',_0x231c04);},_0xa1bd15=()=>{_0x368d8c(_e(_0x50277d['result'])),_0x499e8e();},_0x231c04=()=>{_0x387f5f(_0x50277d['error']),_0x499e8e();};_0x50277d['addEventListener']('success',_0xa1bd15),_0x50277d['addEventListener']('error',_0x231c04);});return _0x128cc1['then'](_0x109970=>{_0x109970 instanceof IDBCursor&&Kr['set'](_0x109970,_0x50277d);})['catch'](()=>{}),Fi['set'](_0x128cc1,_0x50277d),_0x128cc1;}function Fc(_0x1f7e0b){if(ui['has'](_0x1f7e0b))return;const _0x5aabdf=new Promise((_0x35fe1e,_0x2bcdc1)=>{const _0x6852b2=()=>{_0x1f7e0b['removeEventListener']('complete',_0x308f6f),_0x1f7e0b['removeEventListener']('error',_0x5c4cd5),_0x1f7e0b['removeEventListener']('abort',_0x5c4cd5);},_0x308f6f=()=>{_0x35fe1e(),_0x6852b2();},_0x5c4cd5=()=>{_0x2bcdc1(_0x1f7e0b['error']||new DOMException('AbortError','AbortError')),_0x6852b2();};_0x1f7e0b['addEventListener']('complete',_0x308f6f),_0x1f7e0b['addEventListener']('error',_0x5c4cd5),_0x1f7e0b['addEventListener']('abort',_0x5c4cd5);});ui['set'](_0x1f7e0b,_0x5aabdf);}let di={'get'(_0x212cd4,_0x315bac,_0x47c3db){if(_0x212cd4 instanceof IDBTransaction){if(_0x315bac==='done')return ui['get'](_0x212cd4);if(_0x315bac==='objectStoreNames')return _0x212cd4['objectStoreNames']||Yr['get'](_0x212cd4);if(_0x315bac==='store')return _0x47c3db['objectStoreNames'][0x1]?void 0x0:_0x47c3db['objectStore'](_0x47c3db['objectStoreNames'][0x0]);}return _e(_0x212cd4[_0x315bac]);},'set'(_0x3229b1,_0x289724,_0x297ec6){return _0x3229b1[_0x289724]=_0x297ec6,!0x0;},'has'(_0x21f23e,_0x8d5b15){return _0x21f23e instanceof IDBTransaction&&(_0x8d5b15==='done'||_0x8d5b15==='store')?!0x0:_0x8d5b15 in _0x21f23e;}};function Uc(_0x4ae346){di=_0x4ae346(di);}function Wc(_0x30fa0c){return _0x30fa0c===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3b0235,..._0x5ebb94){const _0x549c85=_0x30fa0c['call'](Xn(this),_0x3b0235,..._0x5ebb94);return Yr['set'](_0x549c85,_0x3b0235['sort']?_0x3b0235['sort']():[_0x3b0235]),_e(_0x549c85);}:Lc()['includes'](_0x30fa0c)?function(..._0x4a0c39){return _0x30fa0c['apply'](Xn(this),_0x4a0c39),_e(Kr['get'](this));}:function(..._0xc7655){return _e(_0x30fa0c['apply'](Xn(this),_0xc7655));};}function Bc(_0x58eccc){return typeof _0x58eccc=='function'?Wc(_0x58eccc):(_0x58eccc instanceof IDBTransaction&&Fc(_0x58eccc),Dc(_0x58eccc,Mc())?new Proxy(_0x58eccc,di):_0x58eccc);}function _e(_0x19e2d8){if(_0x19e2d8 instanceof IDBRequest)return xc(_0x19e2d8);if(Jn['has'](_0x19e2d8))return Jn['get'](_0x19e2d8);const _0x5042ad=Bc(_0x19e2d8);return _0x5042ad!==_0x19e2d8&&(Jn['set'](_0x19e2d8,_0x5042ad),Fi['set'](_0x5042ad,_0x19e2d8)),_0x5042ad;}const Xn=_0x192d49=>Fi['get'](_0x192d49);function Vc(_0x1c254a,_0x4634a5,{blocked:_0x29034e,upgrade:_0x51bd5d,blocking:_0x3dc950,terminated:_0x1f152e}={}){const _0x3d4eb7=indexedDB['open'](_0x1c254a,_0x4634a5),_0x579da7=_e(_0x3d4eb7);return _0x51bd5d&&_0x3d4eb7['addEventListener']('upgradeneeded',_0x22b802=>{_0x51bd5d(_e(_0x3d4eb7['result']),_0x22b802['oldVersion'],_0x22b802['newVersion'],_e(_0x3d4eb7['transaction']),_0x22b802);}),_0x29034e&&_0x3d4eb7['addEventListener']('blocked',_0x44c3ec=>_0x29034e(_0x44c3ec['oldVersion'],_0x44c3ec['newVersion'],_0x44c3ec)),_0x579da7['then'](_0x4e8106=>{_0x1f152e&&_0x4e8106['addEventListener']('close',()=>_0x1f152e()),_0x3dc950&&_0x4e8106['addEventListener']('versionchange',_0x27ca58=>_0x3dc950(_0x27ca58['oldVersion'],_0x27ca58['newVersion'],_0x27ca58));})['catch'](()=>{}),_0x579da7;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1dcbc3,_0x5976af){if(!(_0x1dcbc3 instanceof IDBDatabase&&!(_0x5976af in _0x1dcbc3)&&typeof _0x5976af=='string'))return;if(Zn['get'](_0x5976af))return Zn['get'](_0x5976af);const _0x1ca0ec=_0x5976af['replace'](/FromIndex$/,''),_0x100844=_0x5976af!==_0x1ca0ec,_0x25000c=$c['includes'](_0x1ca0ec);if(!(_0x1ca0ec in(_0x100844?IDBIndex:IDBObjectStore)['prototype'])||!(_0x25000c||Hc['includes'](_0x1ca0ec)))return;const _0xea25d=async function(_0x47fd30,..._0x3a8eb9){const _0xee3adf=this['transaction'](_0x47fd30,_0x25000c?'readwrite':'readonly');let _0x512e18=_0xee3adf['store'];return _0x100844&&(_0x512e18=_0x512e18['index'](_0x3a8eb9['shift']())),(await Promise['all']([_0x512e18[_0x1ca0ec](..._0x3a8eb9),_0x25000c&&_0xee3adf['done']]))[0x0];};return Zn['set'](_0x5976af,_0xea25d),_0xea25d;}Uc(_0x431770=>({..._0x431770,'get':(_0x39033b,_0x3c39f5,_0x5b922a)=>Os(_0x39033b,_0x3c39f5)||_0x431770['get'](_0x39033b,_0x3c39f5,_0x5b922a),'has':(_0x566f5d,_0x54f2f3)=>!!Os(_0x566f5d,_0x54f2f3)||_0x431770['has'](_0x566f5d,_0x54f2f3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x36744f){this['container']=_0x36744f;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3a0237=>{if(qc(_0x3a0237)){const _0x2ebd14=_0x3a0237['getImmediate']();return _0x2ebd14['library']+'/'+_0x2ebd14['version'];}else return null;})['filter'](_0x1569de=>_0x1569de)['join']('\x20');}}function qc(_0x5e60b3){const _0x1c3e2b=_0x5e60b3['getComponent']();return(_0x1c3e2b==null?void 0x0:_0x1c3e2b['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0xc4a70c,_0x133b3f){try{_0xc4a70c['container']['addComponent'](_0x133b3f);}catch(_0x57e440){re['debug']('Component\x20'+_0x133b3f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xc4a70c['name'],_0x57e440);}}function et(_0x585706){const _0x26d184=_0x585706['name'];if(gi['has'](_0x26d184))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x26d184+'.'),!0x1;gi['set'](_0x26d184,_0x585706);for(const _0x47911c of Le['values']())Ms(_0x47911c,_0x585706);for(const _0x2ed228 of _i['values']())Ms(_0x2ed228,_0x585706);return!0x0;}function Ui(_0x14875c,_0x1dba67){const _0x15848f=_0x14875c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x15848f&&_0x15848f['triggerHeartbeat'](),_0x14875c['container']['getProvider'](_0x1dba67);}function H(_0x298175){return _0x298175==null?!0x1:_0x298175['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x58059,_0x5183c3,_0x2e4509){this['_isDeleted']=!0x1,this['_options']={..._0x58059},this['_config']={..._0x5183c3},this['_name']=_0x5183c3['name'],this['_automaticDataCollectionEnabled']=_0x5183c3['automaticDataCollectionEnabled'],this['_container']=_0x2e4509,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x249085){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x249085;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0xc47542){this['_isDeleted']=_0xc47542;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4ca1e4,_0x1f3d0e={}){let _0x30fa2a=_0x4ca1e4;typeof _0x1f3d0e!='object'&&(_0x1f3d0e={'name':_0x1f3d0e});const _0x8b27fa={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x1f3d0e},_0x108734=_0x8b27fa['name'];if(typeof _0x108734!='string'||!_0x108734)throw ge['create']('bad-app-name',{'appName':String(_0x108734)});if(_0x30fa2a||(_0x30fa2a=$r()),!_0x30fa2a)throw ge['create']('no-options');const _0x54d6b7=Le['get'](_0x108734);if(_0x54d6b7){if(De(_0x30fa2a,_0x54d6b7['options'])&&De(_0x8b27fa,_0x54d6b7['config']))return _0x54d6b7;throw ge['create']('duplicate-app',{'appName':_0x108734});}const _0x4e4a00=new Ac(_0x108734);for(const _0x4d4613 of gi['values']())_0x4e4a00['addComponent'](_0x4d4613);const _0x31ac58=new Il(_0x30fa2a,_0x8b27fa,_0x4e4a00);return Le['set'](_0x108734,_0x31ac58),_0x31ac58;}function Qr(_0x5453c6=pi){const _0x207b36=Le['get'](_0x5453c6);if(!_0x207b36&&_0x5453c6===pi&&$r())return wl();if(!_0x207b36)throw ge['create']('no-app',{'appName':_0x5453c6});return _0x207b36;}function l_(){return Array['from'](Le['values']());}async function h_(_0x314686){let _0x14c4fb=!0x1;const _0x316076=_0x314686['name'];Le['has'](_0x316076)?(_0x14c4fb=!0x0,Le['delete'](_0x316076)):_i['has'](_0x316076)&&_0x314686['decRefCount']()<=0x0&&(_i['delete'](_0x316076),_0x14c4fb=!0x0),_0x14c4fb&&(await Promise['all'](_0x314686['container']['getProviders']()['map'](_0x17a40c=>_0x17a40c['delete']())),_0x314686['isDeleted']=!0x0);}function me(_0x33cd9b,_0x43d7df,_0x40ab4c){let _0x27d554=vl[_0x33cd9b]??_0x33cd9b;_0x40ab4c&&(_0x27d554+='-'+_0x40ab4c);const _0x25a4f0=_0x27d554['match'](/\s|\//),_0x516499=_0x43d7df['match'](/\s|\//);if(_0x25a4f0||_0x516499){const _0x5a5ad=['Unable\x20to\x20register\x20library\x20\x22'+_0x27d554+'\x22\x20with\x20version\x20\x22'+_0x43d7df+'\x22:'];_0x25a4f0&&_0x5a5ad['push']('library\x20name\x20\x22'+_0x27d554+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x25a4f0&&_0x516499&&_0x5a5ad['push']('and'),_0x516499&&_0x5a5ad['push']('version\x20name\x20\x22'+_0x43d7df+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x5a5ad['join']('\x20'));return;}et(new Me(_0x27d554+'-version',()=>({'library':_0x27d554,'version':_0x43d7df}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4c1a29,_0x35fb7c)=>{switch(_0x35fb7c){case 0x0:try{_0x4c1a29['createObjectStore'](Rt);}catch(_0x1df838){console['warn'](_0x1df838);}}}})['catch'](_0x485818=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x485818['message']});})),ei;}async function Sl(_0x2bcdfc){try{const _0x440ac8=(await Jr())['transaction'](Rt),_0x40488e=await _0x440ac8['objectStore'](Rt)['get'](Xr(_0x2bcdfc));return await _0x440ac8['done'],_0x40488e;}catch(_0x1ef9af){if(_0x1ef9af instanceof Se)re['warn'](_0x1ef9af['message']);else{const _0x1adcf9=ge['create']('idb-get',{'originalErrorMessage':_0x1ef9af==null?void 0x0:_0x1ef9af['message']});re['warn'](_0x1adcf9['message']);}}}async function Ls(_0x46cda7,_0x4742b3){try{const _0x576330=(await Jr())['transaction'](Rt,'readwrite');await _0x576330['objectStore'](Rt)['put'](_0x4742b3,Xr(_0x46cda7)),await _0x576330['done'];}catch(_0x3845eb){if(_0x3845eb instanceof Se)re['warn'](_0x3845eb['message']);else{const _0x2d3676=ge['create']('idb-set',{'originalErrorMessage':_0x3845eb==null?void 0x0:_0x3845eb['message']});re['warn'](_0x2d3676['message']);}}}function Xr(_0x115ccf){return _0x115ccf['name']+'!'+_0x115ccf['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x4cf5a2){this['container']=_0x4cf5a2,this['_heartbeatsCache']=null;const _0x5675d5=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x5675d5),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3a5319=>(this['_heartbeatsCache']=_0x3a5319,_0x3a5319));}async['triggerHeartbeat'](){var _0x45a61d,_0x335c81;try{const _0x73f8c=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5e862a=xs();if(((_0x45a61d=this['_heartbeatsCache'])==null?void 0x0:_0x45a61d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x335c81=this['_heartbeatsCache'])==null?void 0x0:_0x335c81['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5e862a||this['_heartbeatsCache']['heartbeats']['some'](_0x57d6c2=>_0x57d6c2['date']===_0x5e862a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5e862a,'agent':_0x73f8c}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x1a8eb5=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x1a8eb5,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x109346){re['warn'](_0x109346);}}async['getHeartbeatsHeader'](){var _0x3f0bc7;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3f0bc7=this['_heartbeatsCache'])==null?void 0x0:_0x3f0bc7['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x264080=xs(),{heartbeatsToSend:_0x23ae8d,unsentEntries:_0x55e5cc}=kl(this['_heartbeatsCache']['heartbeats']),_0x5ad610=an(JSON['stringify']({'version':0x2,'heartbeats':_0x23ae8d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x264080,_0x55e5cc['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x55e5cc,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5ad610;}catch(_0xab773a){return re['warn'](_0xab773a),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x2f2910,_0x57cefe=bl){const _0x437cd7=[];let _0x54e632=_0x2f2910['slice']();for(const _0x3d61de of _0x2f2910){const _0x2f5f46=_0x437cd7['find'](_0x84681c=>_0x84681c['agent']===_0x3d61de['agent']);if(_0x2f5f46){if(_0x2f5f46['dates']['push'](_0x3d61de['date']),Fs(_0x437cd7)>_0x57cefe){_0x2f5f46['dates']['pop']();break;}}else{if(_0x437cd7['push']({'agent':_0x3d61de['agent'],'dates':[_0x3d61de['date']]}),Fs(_0x437cd7)>_0x57cefe){_0x437cd7['pop']();break;}}_0x54e632=_0x54e632['slice'](0x1);}return{'heartbeatsToSend':_0x437cd7,'unsentEntries':_0x54e632};}class Nl{constructor(_0x17a2a2){this['app']=_0x17a2a2,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1156be=await Sl(this['app']);return _0x1156be!=null&&_0x1156be['heartbeats']?_0x1156be:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x6326f5){if(await this['_canUseIndexedDBPromise']){const _0x3db244=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x6326f5['lastSentHeartbeatDate']??_0x3db244['lastSentHeartbeatDate'],'heartbeats':_0x6326f5['heartbeats']});}else return;}async['add'](_0x35e133){if(await this['_canUseIndexedDBPromise']){const _0x415b3d=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x35e133['lastSentHeartbeatDate']??_0x415b3d['lastSentHeartbeatDate'],'heartbeats':[..._0x415b3d['heartbeats'],..._0x35e133['heartbeats']]});}else return;}}function Fs(_0x135678){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x135678}))['length'];}function Pl(_0xd8d6c){if(_0xd8d6c['length']===0x0)return-0x1;let _0x3e96b8=0x0,_0x3e7cd2=_0xd8d6c[0x0]['date'];for(let _0x27f435=0x1;_0x27f435<_0xd8d6c['length'];_0x27f435++)_0xd8d6c[_0x27f435]['date']<_0x3e7cd2&&(_0x3e7cd2=_0xd8d6c[_0x27f435]['date'],_0x3e96b8=_0x27f435);return _0x3e96b8;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0xbdc9f3){et(new Me('platform-logger',_0x36ef4d=>new Gc(_0x36ef4d),'PRIVATE')),et(new Me('heartbeat',_0x4d894e=>new Al(_0x4d894e),'PRIVATE')),me(fi,Ds,_0xbdc9f3),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x36ae62){Zr=_0x36ae62;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x5360e0){this['domStorage_']=_0x5360e0,this['prefix_']='firebase:';}['set'](_0x49e68f,_0x1ad5ca){_0x1ad5ca==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x49e68f)):this['domStorage_']['setItem'](this['prefixedName_'](_0x49e68f),O(_0x1ad5ca));}['get'](_0x37a4d6){const _0x29ead0=this['domStorage_']['getItem'](this['prefixedName_'](_0x37a4d6));return _0x29ead0==null?null:bt(_0x29ead0);}['remove'](_0x5c2f1e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5c2f1e));}['prefixedName_'](_0x5bf185){return this['prefix_']+_0x5bf185;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x252ae1,_0x52984c){_0x52984c==null?delete this['cache_'][_0x252ae1]:this['cache_'][_0x252ae1]=_0x52984c;}['get'](_0x5508d4){return Y(this['cache_'],_0x5508d4)?this['cache_'][_0x5508d4]:null;}['remove'](_0x2b7907){delete this['cache_'][_0x2b7907];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x2e0e8b){try{if(typeof window<'u'&&typeof window[_0x2e0e8b]<'u'){const _0x4bbc70=window[_0x2e0e8b];return _0x4bbc70['setItem']('firebase:sentinel','cache'),_0x4bbc70['removeItem']('firebase:sentinel'),new xl(_0x4bbc70);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x572f79=0x1;return function(){return _0x572f79++;};}()),no=function(_0x2f42d8){const _0x41298d=Tc(_0x2f42d8),_0x298923=new Ec();_0x298923['update'](_0x41298d);const _0x3a881e=_0x298923['digest']();return Di['encodeByteArray'](_0x3a881e);},Bt=function(..._0xeddc25){let _0x31ce30='';for(let _0x390d67=0x0;_0x390d67<_0xeddc25['length'];_0x390d67++){const _0x10007d=_0xeddc25[_0x390d67];Array['isArray'](_0x10007d)||_0x10007d&&typeof _0x10007d=='object'&&typeof _0x10007d['length']=='number'?_0x31ce30+=Bt['apply'](null,_0x10007d):typeof _0x10007d=='object'?_0x31ce30+=O(_0x10007d):_0x31ce30+=_0x10007d,_0x31ce30+='\x20';}return _0x31ce30;};let Et=null,Vs=!0x0;const Wl=function(_0x2d2d02,_0x1ed2f6){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x4bb94e){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x39e8fe=Bt['apply'](null,_0x4bb94e);Et(_0x39e8fe);}},Vt=function(_0x50c850){return function(..._0x104787){L(_0x50c850,..._0x104787);};},mi=function(..._0x2ff6e5){const _0x455f2e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x2ff6e5);Qe['error'](_0x455f2e);},oe=function(..._0x152db6){const _0x2a5cac='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x152db6);throw Qe['error'](_0x2a5cac),new Error(_0x2a5cac);},U=function(..._0x4ae564){const _0x631f0='FIREBASE\x20WARNING:\x20'+Bt(..._0x4ae564);Qe['warn'](_0x631f0);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x4f556c){return typeof _0x4f556c=='number'&&(_0x4f556c!==_0x4f556c||_0x4f556c===Number['POSITIVE_INFINITY']||_0x4f556c===Number['NEGATIVE_INFINITY']);},Vl=function(_0x29ef06){if(document['readyState']==='complete')_0x29ef06();else{let _0x4711ba=!0x1;const _0x2c3ecd=function(){if(!document['body']){setTimeout(_0x2c3ecd,Math['floor'](0xa));return;}_0x4711ba||(_0x4711ba=!0x0,_0x29ef06());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2c3ecd,!0x1),window['addEventListener']('load',_0x2c3ecd,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2c3ecd();}),window['attachEvent']('onload',_0x2c3ecd));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x34fabd,_0x5c84c8){if(_0x34fabd===_0x5c84c8)return 0x0;if(_0x34fabd===xe||_0x5c84c8===Ie)return-0x1;if(_0x5c84c8===xe||_0x34fabd===Ie)return 0x1;{const _0x404d9f=Hs(_0x34fabd),_0x318d70=Hs(_0x5c84c8);return _0x404d9f!==null?_0x318d70!==null?_0x404d9f-_0x318d70===0x0?_0x34fabd['length']-_0x5c84c8['length']:_0x404d9f-_0x318d70:-0x1:_0x318d70!==null?0x1:_0x34fabd<_0x5c84c8?-0x1:0x1;}},Hl=function(_0x44888d,_0x501382){return _0x44888d===_0x501382?0x0:_0x44888d<_0x501382?-0x1:0x1;},pt=function(_0x1f0577,_0xdd3b80){if(_0xdd3b80&&_0x1f0577 in _0xdd3b80)return _0xdd3b80[_0x1f0577];throw new Error('Missing\x20required\x20key\x20('+_0x1f0577+')\x20in\x20object:\x20'+O(_0xdd3b80));},Bi=function(_0x3a3e5e){if(typeof _0x3a3e5e!='object'||_0x3a3e5e===null)return O(_0x3a3e5e);const _0x3cfe0d=[];for(const _0x1e2438 in _0x3a3e5e)_0x3cfe0d['push'](_0x1e2438);_0x3cfe0d['sort']();let _0x2f4669='{';for(let _0x14ac3e=0x0;_0x14ac3e<_0x3cfe0d['length'];_0x14ac3e++)_0x14ac3e!==0x0&&(_0x2f4669+=','),_0x2f4669+=O(_0x3cfe0d[_0x14ac3e]),_0x2f4669+=':',_0x2f4669+=Bi(_0x3a3e5e[_0x3cfe0d[_0x14ac3e]]);return _0x2f4669+='}',_0x2f4669;},io=function(_0x38670d,_0x215bf3){const _0x54056f=_0x38670d['length'];if(_0x54056f<=_0x215bf3)return[_0x38670d];const _0x3bcc5c=[];for(let _0x2b8154=0x0;_0x2b8154<_0x54056f;_0x2b8154+=_0x215bf3)_0x2b8154+_0x215bf3>_0x54056f?_0x3bcc5c['push'](_0x38670d['substring'](_0x2b8154,_0x54056f)):_0x3bcc5c['push'](_0x38670d['substring'](_0x2b8154,_0x2b8154+_0x215bf3));return _0x3bcc5c;};function x(_0x88359c,_0x514686){for(const _0x381ec8 in _0x88359c)_0x88359c['hasOwnProperty'](_0x381ec8)&&_0x514686(_0x381ec8,_0x88359c[_0x381ec8]);}const so=function(_0x343c0f){f(!Wi(_0x343c0f),'Invalid\x20JSON\x20number');const _0x32a1cf=0xb,_0xdc7a55=0x34,_0x461639=(0x1<<_0x32a1cf-0x1)-0x1;let _0x2e098d,_0x1cca1c,_0x5553f0,_0x106d12,_0x5586cc;_0x343c0f===0x0?(_0x1cca1c=0x0,_0x5553f0=0x0,_0x2e098d=0x1/_0x343c0f===-0x1/0x0?0x1:0x0):(_0x2e098d=_0x343c0f<0x0,_0x343c0f=Math['abs'](_0x343c0f),_0x343c0f>=Math['pow'](0x2,0x1-_0x461639)?(_0x106d12=Math['min'](Math['floor'](Math['log'](_0x343c0f)/Math['LN2']),_0x461639),_0x1cca1c=_0x106d12+_0x461639,_0x5553f0=Math['round'](_0x343c0f*Math['pow'](0x2,_0xdc7a55-_0x106d12)-Math['pow'](0x2,_0xdc7a55))):(_0x1cca1c=0x0,_0x5553f0=Math['round'](_0x343c0f/Math['pow'](0x2,0x1-_0x461639-_0xdc7a55))));const _0x4c0434=[];for(_0x5586cc=_0xdc7a55;_0x5586cc;_0x5586cc-=0x1)_0x4c0434['push'](_0x5553f0%0x2?0x1:0x0),_0x5553f0=Math['floor'](_0x5553f0/0x2);for(_0x5586cc=_0x32a1cf;_0x5586cc;_0x5586cc-=0x1)_0x4c0434['push'](_0x1cca1c%0x2?0x1:0x0),_0x1cca1c=Math['floor'](_0x1cca1c/0x2);_0x4c0434['push'](_0x2e098d?0x1:0x0),_0x4c0434['reverse']();const _0x5a244e=_0x4c0434['join']('');let _0x525410='';for(_0x5586cc=0x0;_0x5586cc<0x40;_0x5586cc+=0x8){let _0xd32538=parseInt(_0x5a244e['substr'](_0x5586cc,0x8),0x2)['toString'](0x10);_0xd32538['length']===0x1&&(_0xd32538='0'+_0xd32538),_0x525410=_0x525410+_0xd32538;}return _0x525410['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x11178d,_0x334bd6){let _0x656ab2='Unknown\x20Error';_0x11178d==='too_big'?_0x656ab2='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x11178d==='permission_denied'?_0x656ab2='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x11178d==='unavailable'&&(_0x656ab2='The\x20service\x20is\x20unavailable');const _0x5736e8=new Error(_0x11178d+'\x20at\x20'+_0x334bd6['_path']['toString']()+':\x20'+_0x656ab2);return _0x5736e8['code']=_0x11178d['toUpperCase'](),_0x5736e8;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x4bcdb9){if(zl['test'](_0x4bcdb9)){const _0x5a2aaa=Number(_0x4bcdb9);if(_0x5a2aaa>=jl&&_0x5a2aaa<=Kl)return _0x5a2aaa;}return null;},lt=function(_0x456ef6){try{_0x456ef6();}catch(_0x189e44){setTimeout(()=>{const _0xebfe78=_0x189e44['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xebfe78),_0x189e44;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0xcddf9f,_0x567308){const _0x4edfa5=setTimeout(_0xcddf9f,_0x567308);return typeof _0x4edfa5=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4edfa5):typeof _0x4edfa5=='object'&&_0x4edfa5['unref']&&_0x4edfa5['unref'](),_0x4edfa5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x39ac83,_0x216d8b){this['appCheckProvider']=_0x216d8b,this['appName']=_0x39ac83['name'],H(_0x39ac83)&&_0x39ac83['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x39ac83['settings']['appCheckToken']),this['appCheck']=_0x216d8b==null?void 0x0:_0x216d8b['getImmediate']({'optional':!0x0}),this['appCheck']||_0x216d8b==null||_0x216d8b['get']()['then'](_0x130a03=>this['appCheck']=_0x130a03);}['getToken'](_0x15f2e6){if(this['serverAppAppCheckToken']){if(_0x15f2e6)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x15f2e6):new Promise((_0x2a63c5,_0x432eeb)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x15f2e6)['then'](_0x2a63c5,_0x432eeb):_0x2a63c5(null);},0x0);});}['addTokenChangeListener'](_0x487f2b){var _0x28a2f5;(_0x28a2f5=this['appCheckProvider'])==null||_0x28a2f5['get']()['then'](_0x29b117=>_0x29b117['addTokenListener'](_0x487f2b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4150bc,_0x26734e,_0x257abe){this['appName_']=_0x4150bc,this['firebaseOptions_']=_0x26734e,this['authProvider_']=_0x257abe,this['auth_']=null,this['auth_']=_0x257abe['getImmediate']({'optional':!0x0}),this['auth_']||_0x257abe['onInit'](_0x59419a=>this['auth_']=_0x59419a);}['getToken'](_0x5dd147){return this['auth_']?this['auth_']['getToken'](_0x5dd147)['catch'](_0xb7726e=>_0xb7726e&&_0xb7726e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xb7726e)):new Promise((_0x7525f5,_0x23744d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x5dd147)['then'](_0x7525f5,_0x23744d):_0x7525f5(null);},0x0);});}['addTokenChangeListener'](_0x158883){this['auth_']?this['auth_']['addAuthTokenListener'](_0x158883):this['authProvider_']['get']()['then'](_0x31ec04=>_0x31ec04['addAuthTokenListener'](_0x158883));}['removeTokenChangeListener'](_0xcdf144){this['authProvider_']['get']()['then'](_0xa270fc=>_0xa270fc['removeAuthTokenListener'](_0xcdf144));}['notifyForInvalidToken'](){let _0x4eb0f6='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4eb0f6+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4eb0f6+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4eb0f6+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4eb0f6);}}class tn{constructor(_0x14c237){this['accessToken']=_0x14c237;}['getToken'](_0x48860f){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x168e01){_0x168e01(this['accessToken']);}['removeTokenChangeListener'](_0x3ac27f){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x532dea,_0x27a404,_0xb8ecd7,_0x257c21,_0x2daaf4=!0x1,_0x5d4991='',_0x223769=!0x1,_0xd15c00=!0x1,_0x2b5178=null){this['secure']=_0x27a404,this['namespace']=_0xb8ecd7,this['webSocketOnly']=_0x257c21,this['nodeAdmin']=_0x2daaf4,this['persistenceKey']=_0x5d4991,this['includeNamespaceInQueryParams']=_0x223769,this['isUsingEmulator']=_0xd15c00,this['emulatorOptions']=_0x2b5178,this['_host']=_0x532dea['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x532dea)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x596c41){_0x596c41!==this['internalHost']&&(this['internalHost']=_0x596c41,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5c7e64=this['toURLString']();return this['persistenceKey']&&(_0x5c7e64+='<'+this['persistenceKey']+'>'),_0x5c7e64;}['toURLString'](){const _0x290b42=this['secure']?'https://':'http://',_0x265568=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x290b42+this['host']+'/'+_0x265568;}}function Xl(_0x52fb6f){return _0x52fb6f['host']!==_0x52fb6f['internalHost']||_0x52fb6f['isCustomHost']()||_0x52fb6f['includeNamespaceInQueryParams'];}function go(_0x58833,_0x45e329,_0x22dfcd){f(typeof _0x45e329=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x22dfcd=='object','typeof\x20params\x20must\x20==\x20object');let _0x5eea42;if(_0x45e329===fo)_0x5eea42=(_0x58833['secure']?'wss://':'ws://')+_0x58833['internalHost']+'/.ws?';else{if(_0x45e329===po)_0x5eea42=(_0x58833['secure']?'https://':'http://')+_0x58833['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x45e329);}Xl(_0x58833)&&(_0x22dfcd['ns']=_0x58833['namespace']);const _0x341f20=[];return x(_0x22dfcd,(_0x31406a,_0x276524)=>{_0x341f20['push'](_0x31406a+'='+_0x276524);}),_0x5eea42+_0x341f20['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x141f4b,_0x33e479=0x1){Y(this['counters_'],_0x141f4b)||(this['counters_'][_0x141f4b]=0x0),this['counters_'][_0x141f4b]+=_0x33e479;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x411a75){const _0x38c4bb=_0x411a75['toString']();return ti[_0x38c4bb]||(ti[_0x38c4bb]=new Zl()),ti[_0x38c4bb];}function eh(_0x3fb59e,_0x2adf88){const _0x37d0c6=_0x3fb59e['toString']();return ni[_0x37d0c6]||(ni[_0x37d0c6]=_0x2adf88()),ni[_0x37d0c6];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x494a63){this['onMessage_']=_0x494a63,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1c511c,_0x172c4e){this['closeAfterResponse']=_0x1c511c,this['onClose']=_0x172c4e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1cf80f,_0x3329f7){for(this['pendingResponses'][_0x1cf80f]=_0x3329f7;this['pendingResponses'][this['currentResponseNum']];){const _0x5da878=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1950f5=0x0;_0x1950f5<_0x5da878['length'];++_0x1950f5)_0x5da878[_0x1950f5]&&lt(()=>{this['onMessage_'](_0x5da878[_0x1950f5]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0xa416e7,_0x191cda,_0x57057b,_0x14a25d,_0x564677,_0x20a1a8,_0x13e02e){this['connId']=_0xa416e7,this['repoInfo']=_0x191cda,this['applicationId']=_0x57057b,this['appCheckToken']=_0x14a25d,this['authToken']=_0x564677,this['transportSessionId']=_0x20a1a8,this['lastSessionId']=_0x13e02e,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0xa416e7),this['stats_']=Hi(_0x191cda),this['urlFn']=_0x11b1cb=>(this['appCheckToken']&&(_0x11b1cb[yi]=this['appCheckToken']),go(_0x191cda,po,_0x11b1cb));}['open'](_0xdb853c,_0x2e265f){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2e265f,this['myPacketOrderer']=new th(_0xdb853c),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x1cceb6)=>{const [_0x3eaefa,_0x590418,_0x302e3d,_0x5bdae5,_0x452730]=_0x1cceb6;if(this['incrementIncomingBytes_'](_0x1cceb6),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3eaefa===$s)this['id']=_0x590418,this['password']=_0x302e3d;else{if(_0x3eaefa===nh)_0x590418?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x590418,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3eaefa);}}},(..._0x2262d6)=>{const [_0x151f1a,_0x26a3ef]=_0x2262d6;this['incrementIncomingBytes_'](_0x2262d6),this['myPacketOrderer']['handleResponse'](_0x151f1a,_0x26a3ef);},()=>{this['onClosed_']();},this['urlFn']);const _0x5179e9={};_0x5179e9[$s]='t',_0x5179e9[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5179e9[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5179e9[ro]=Vi,this['transportSessionId']&&(_0x5179e9[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x5179e9[ho]=this['lastSessionId']),this['applicationId']&&(_0x5179e9[uo]=this['applicationId']),this['appCheckToken']&&(_0x5179e9[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x5179e9[ao]=co);const _0x5f14b9=this['urlFn'](_0x5179e9);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5f14b9),this['scriptTagHolder']['addTag'](_0x5f14b9,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1ff4da){const _0x529f8e=O(_0x1ff4da);this['bytesSent']+=_0x529f8e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x529f8e['length']);const _0x531c42=Br(_0x529f8e),_0x3409c7=io(_0x531c42,hh);for(let _0xce6b0f=0x0;_0xce6b0f<_0x3409c7['length'];_0xce6b0f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3409c7['length'],_0x3409c7[_0xce6b0f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x80a004,_0x2755e3){this['myDisconnFrame']=document['createElement']('iframe');const _0x184f98={};_0x184f98[lh]='t',_0x184f98[mo]=_0x80a004,_0x184f98[yo]=_0x2755e3,this['myDisconnFrame']['src']=this['urlFn'](_0x184f98),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x273687){const _0x4fc7ba=O(_0x273687)['length'];this['bytesReceived']+=_0x4fc7ba,this['stats_']['incrementCounter']('bytes_received',_0x4fc7ba);}}class $i{constructor(_0x564644,_0x5360a9,_0x45937f,_0x3d9fa6){this['onDisconnect']=_0x45937f,this['urlFn']=_0x3d9fa6,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x564644,window[sh+this['uniqueCallbackIdentifier']]=_0x5360a9,this['myIFrame']=$i['createIFrame_']();let _0x4c489d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4c489d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x375e1e='<html><body>'+_0x4c489d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x375e1e),this['myIFrame']['doc']['close']();}catch(_0x1f017c){L('frame\x20writing\x20exception'),_0x1f017c['stack']&&L(_0x1f017c['stack']),L(_0x1f017c);}}}static['createIFrame_'](){const _0x3ad63c=document['createElement']('iframe');if(_0x3ad63c['style']['display']='none',document['body']){document['body']['appendChild'](_0x3ad63c);try{_0x3ad63c['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x56cb88=document['domain'];_0x3ad63c['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x56cb88+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3ad63c['contentDocument']?_0x3ad63c['doc']=_0x3ad63c['contentDocument']:_0x3ad63c['contentWindow']?_0x3ad63c['doc']=_0x3ad63c['contentWindow']['document']:_0x3ad63c['document']&&(_0x3ad63c['doc']=_0x3ad63c['document']),_0x3ad63c;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x21c1e7=this['onDisconnect'];_0x21c1e7&&(this['onDisconnect']=null,_0x21c1e7());}['startLongPoll'](_0x745bf8,_0x3324d8){for(this['myID']=_0x745bf8,this['myPW']=_0x3324d8,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x36d8f7={};_0x36d8f7[mo]=this['myID'],_0x36d8f7[yo]=this['myPW'],_0x36d8f7[vo]=this['currentSerial'];let _0x397163=this['urlFn'](_0x36d8f7),_0xb7375='',_0x4ddf6e=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0xb7375['length']<=Eo;){const _0x24f897=this['pendingSegs']['shift']();_0xb7375=_0xb7375+'&'+oh+_0x4ddf6e+'='+_0x24f897['seg']+'&'+ah+_0x4ddf6e+'='+_0x24f897['ts']+'&'+ch+_0x4ddf6e+'='+_0x24f897['d'],_0x4ddf6e++;}return _0x397163=_0x397163+_0xb7375,this['addLongPollTag_'](_0x397163,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4d523c,_0x4a991b,_0x3239e9){this['pendingSegs']['push']({'seg':_0x4d523c,'ts':_0x4a991b,'d':_0x3239e9}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5790f3,_0x475d77){this['outstandingRequests']['add'](_0x475d77);const _0x1a03da=()=>{this['outstandingRequests']['delete'](_0x475d77),this['newRequest_']();},_0xe23ea2=setTimeout(_0x1a03da,Math['floor'](uh)),_0x2dcc34=()=>{clearTimeout(_0xe23ea2),_0x1a03da();};this['addTag'](_0x5790f3,_0x2dcc34);}['addTag'](_0x5e7244,_0x23839a){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5ba6a8=this['myIFrame']['doc']['createElement']('script');_0x5ba6a8['type']='text/javascript',_0x5ba6a8['async']=!0x0,_0x5ba6a8['src']=_0x5e7244,_0x5ba6a8['onload']=_0x5ba6a8['onreadystatechange']=function(){const _0x110453=_0x5ba6a8['readyState'];(!_0x110453||_0x110453==='loaded'||_0x110453==='complete')&&(_0x5ba6a8['onload']=_0x5ba6a8['onreadystatechange']=null,_0x5ba6a8['parentNode']&&_0x5ba6a8['parentNode']['removeChild'](_0x5ba6a8),_0x23839a());},_0x5ba6a8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5e7244),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5ba6a8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x3a52d2,_0x627532,_0x1f373b,_0x1e8074,_0x2fb40f,_0x215624,_0x5bcf97){this['connId']=_0x3a52d2,this['applicationId']=_0x1f373b,this['appCheckToken']=_0x1e8074,this['authToken']=_0x2fb40f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x627532),this['connURL']=G['connectionURL_'](_0x627532,_0x215624,_0x5bcf97,_0x1e8074,_0x1f373b),this['nodeAdmin']=_0x627532['nodeAdmin'];}static['connectionURL_'](_0x2cf139,_0x49f19a,_0x5262d2,_0xe05dd,_0x2a73e8){const _0x401d44={};return _0x401d44[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x401d44[ao]=co),_0x49f19a&&(_0x401d44[oo]=_0x49f19a),_0x5262d2&&(_0x401d44[ho]=_0x5262d2),_0xe05dd&&(_0x401d44[yi]=_0xe05dd),_0x2a73e8&&(_0x401d44[uo]=_0x2a73e8),go(_0x2cf139,fo,_0x401d44);}['open'](_0x4dce1e,_0x2a54c0){this['onDisconnect']=_0x2a54c0,this['onMessage']=_0x4dce1e,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x1fa464;dc(),this['mySock']=new hn(this['connURL'],[],_0x1fa464);}catch(_0x2d744f){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1d0bfe=_0x2d744f['message']||_0x2d744f['data'];_0x1d0bfe&&this['log_'](_0x1d0bfe),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1924e2=>{this['handleIncomingFrame'](_0x1924e2);},this['mySock']['onerror']=_0x5a2944=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x21ed39=_0x5a2944['message']||_0x5a2944['data'];_0x21ed39&&this['log_'](_0x21ed39),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3f1db6=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x57000c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5905b0=navigator['userAgent']['match'](_0x57000c);_0x5905b0&&_0x5905b0['length']>0x1&&parseFloat(_0x5905b0[0x1])<4.4&&(_0x3f1db6=!0x0);}return!_0x3f1db6&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5e4d7e){if(this['frames']['push'](_0x5e4d7e),this['frames']['length']===this['totalFrames']){const _0x43ee28=this['frames']['join']('');this['frames']=null;const _0x4aae2c=bt(_0x43ee28);this['onMessage'](_0x4aae2c);}}['handleNewFrameCount_'](_0x3604db){this['totalFrames']=_0x3604db,this['frames']=[];}['extractFrameCount_'](_0x3b54c1){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3b54c1['length']<=0x6){const _0x4924d5=Number(_0x3b54c1);if(!isNaN(_0x4924d5))return this['handleNewFrameCount_'](_0x4924d5),null;}return this['handleNewFrameCount_'](0x1),_0x3b54c1;}['handleIncomingFrame'](_0x44828f){if(this['mySock']===null)return;const _0xef1e2d=_0x44828f['data'];if(this['bytesReceived']+=_0xef1e2d['length'],this['stats_']['incrementCounter']('bytes_received',_0xef1e2d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xef1e2d);else{const _0x107e50=this['extractFrameCount_'](_0xef1e2d);_0x107e50!==null&&this['appendFrame_'](_0x107e50);}}['send'](_0x2eb2b0){this['resetKeepAlive']();const _0x4eccae=O(_0x2eb2b0);this['bytesSent']+=_0x4eccae['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4eccae['length']);const _0x217d04=io(_0x4eccae,fh);_0x217d04['length']>0x1&&this['sendString_'](String(_0x217d04['length']));for(let _0x5f22a6=0x0;_0x5f22a6<_0x217d04['length'];_0x5f22a6++)this['sendString_'](_0x217d04[_0x5f22a6]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x3e9139){try{this['mySock']['send'](_0x3e9139);}catch(_0x35d2e5){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x35d2e5['message']||_0x35d2e5['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x268c90){this['initTransports_'](_0x268c90);}['initTransports_'](_0x462fbd){const _0x54bce3=G&&G['isAvailable']();let _0x1c3f53=_0x54bce3&&!G['previouslyFailed']();if(_0x462fbd['webSocketOnly']&&(_0x54bce3||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1c3f53=!0x0),_0x1c3f53)this['transports_']=[G];else{const _0x3592dd=this['transports_']=[];for(const _0x86f4d1 of At['ALL_TRANSPORTS'])_0x86f4d1&&_0x86f4d1['isAvailable']()&&_0x3592dd['push'](_0x86f4d1);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x5aace7,_0x599697,_0x3517ca,_0x42324b,_0x2095f6,_0x421e09,_0x47f89f,_0x21f739,_0x24dab6,_0x563119){this['id']=_0x5aace7,this['repoInfo_']=_0x599697,this['applicationId_']=_0x3517ca,this['appCheckToken_']=_0x42324b,this['authToken_']=_0x2095f6,this['onMessage_']=_0x421e09,this['onReady_']=_0x47f89f,this['onDisconnect_']=_0x21f739,this['onKill_']=_0x24dab6,this['lastSessionId']=_0x563119,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x599697),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4d1b0e=this['transportManager_']['initialTransport']();this['conn_']=new _0x4d1b0e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4d1b0e['responsesRequiredToBeHealthy']||0x0;const _0x3d2a7b=this['connReceiver_'](this['conn_']),_0x29f7b4=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3d2a7b,_0x29f7b4);},Math['floor'](0x0));const _0x3f2641=_0x4d1b0e['healthyTimeout']||0x0;_0x3f2641>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3f2641)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3c8f6a){return _0xe1fa4=>{_0x3c8f6a===this['conn_']?this['onConnectionLost_'](_0xe1fa4):_0x3c8f6a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1655d1){return _0x344fea=>{this['state_']!==0x2&&(_0x1655d1===this['rx_']?this['onPrimaryMessageReceived_'](_0x344fea):_0x1655d1===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x344fea):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3a20b7){const _0x4f36f0={'t':'d','d':_0x3a20b7};this['sendData_'](_0x4f36f0);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1e73e4){if(ii in _0x1e73e4){const _0x589d3=_0x1e73e4[ii];_0x589d3===js?this['upgradeIfSecondaryHealthy_']():_0x589d3===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x589d3===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x2fc3c4){const _0x3f298c=pt('t',_0x2fc3c4),_0x429358=pt('d',_0x2fc3c4);if(_0x3f298c==='c')this['onSecondaryControl_'](_0x429358);else{if(_0x3f298c==='d')this['pendingDataMessages']['push'](_0x429358);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3f298c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x209923){const _0x2a447b=pt('t',_0x209923),_0x4e3613=pt('d',_0x209923);_0x2a447b==='c'?this['onControl_'](_0x4e3613):_0x2a447b==='d'&&this['onDataMessage_'](_0x4e3613);}['onDataMessage_'](_0x7d0872){this['onPrimaryResponse_'](),this['onMessage_'](_0x7d0872);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x296b1f){const _0x453bc8=pt(ii,_0x296b1f);if(Gs in _0x296b1f){const _0x44d88c=_0x296b1f[Gs];if(_0x453bc8===Ih){const _0x3201dd={..._0x44d88c};this['repoInfo_']['isUsingEmulator']&&(_0x3201dd['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3201dd);}else{if(_0x453bc8===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2b82b7=0x0;_0x2b82b7<this['pendingDataMessages']['length'];++_0x2b82b7)this['onDataMessage_'](this['pendingDataMessages'][_0x2b82b7]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x453bc8===vh?this['onConnectionShutdown_'](_0x44d88c):_0x453bc8===qs?this['onReset_'](_0x44d88c):_0x453bc8===Eh?mi('Server\x20Error:\x20'+_0x44d88c):_0x453bc8===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x453bc8);}}}['onHandshake_'](_0x4bbb1d){const _0x57239a=_0x4bbb1d['ts'],_0x21d18c=_0x4bbb1d['v'],_0x1ce59e=_0x4bbb1d['h'];this['sessionId']=_0x4bbb1d['s'],this['repoInfo_']['host']=_0x1ce59e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x57239a),Vi!==_0x21d18c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x151b66=this['transportManager_']['upgradeTransport']();_0x151b66&&this['startUpgrade_'](_0x151b66);}['startUpgrade_'](_0x14725c){this['secondaryConn_']=new _0x14725c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x14725c['responsesRequiredToBeHealthy']||0x0;const _0x407d87=this['connReceiver_'](this['secondaryConn_']),_0x242794=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x407d87,_0x242794),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x365f5e){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x365f5e),this['repoInfo_']['host']=_0x365f5e,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5d1ea5,_0xf01b9c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5d1ea5,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xf01b9c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2e1959=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2e1959||this['rx_']===_0x2e1959)&&this['close']();}['onConnectionLost_'](_0x5d59d1){this['conn_']=null,!_0x5d59d1&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x142d50){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x142d50),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1cfe74){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1cfe74);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x344c30,_0x328d44,_0x2cad4c,_0x50f7f2){}['merge'](_0x4b8495,_0x46eb46,_0x27e050,_0x1c6c27){}['refreshAuthToken'](_0x272b15){}['refreshAppCheckToken'](_0xa417a1){}['onDisconnectPut'](_0x5b7208,_0x141cab,_0x3be9fc){}['onDisconnectMerge'](_0x3d3d29,_0x4a0705,_0xa2aa3a){}['onDisconnectCancel'](_0x298bcb,_0x5b6bc4){}['reportStats'](_0x1597cb){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x13a0c8){this['allowedEvents_']=_0x13a0c8,this['listeners_']={},f(Array['isArray'](_0x13a0c8)&&_0x13a0c8['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1d4e0c,..._0x470e5a){if(Array['isArray'](this['listeners_'][_0x1d4e0c])){const _0x426ca1=[...this['listeners_'][_0x1d4e0c]];for(let _0x33b49e=0x0;_0x33b49e<_0x426ca1['length'];_0x33b49e++)_0x426ca1[_0x33b49e]['callback']['apply'](_0x426ca1[_0x33b49e]['context'],_0x470e5a);}}['on'](_0x1b24f5,_0x258c2c,_0x3e10a4){this['validateEventType_'](_0x1b24f5),this['listeners_'][_0x1b24f5]=this['listeners_'][_0x1b24f5]||[],this['listeners_'][_0x1b24f5]['push']({'callback':_0x258c2c,'context':_0x3e10a4});const _0x3ca08b=this['getInitialEvent'](_0x1b24f5);_0x3ca08b&&_0x258c2c['apply'](_0x3e10a4,_0x3ca08b);}['off'](_0x1cf14e,_0xd6e595,_0x288985){this['validateEventType_'](_0x1cf14e);const _0x2ab8e5=this['listeners_'][_0x1cf14e]||[];for(let _0x4c20d2=0x0;_0x4c20d2<_0x2ab8e5['length'];_0x4c20d2++)if(_0x2ab8e5[_0x4c20d2]['callback']===_0xd6e595&&(!_0x288985||_0x288985===_0x2ab8e5[_0x4c20d2]['context'])){_0x2ab8e5['splice'](_0x4c20d2,0x1);return;}}['validateEventType_'](_0x2d731c){f(this['allowedEvents_']['find'](_0x5e9b1e=>_0x5e9b1e===_0x2d731c),'Unknown\x20event:\x20'+_0x2d731c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x33c288){return f(_0x33c288==='online','Unknown\x20event\x20type:\x20'+_0x33c288),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x279c81,_0x1ff171){if(_0x1ff171===void 0x0){this['pieces_']=_0x279c81['split']('/');let _0x430392=0x0;for(let _0x1d0a16=0x0;_0x1d0a16<this['pieces_']['length'];_0x1d0a16++)this['pieces_'][_0x1d0a16]['length']>0x0&&(this['pieces_'][_0x430392]=this['pieces_'][_0x1d0a16],_0x430392++);this['pieces_']['length']=_0x430392,this['pieceNum_']=0x0;}else this['pieces_']=_0x279c81,this['pieceNum_']=_0x1ff171;}['toString'](){let _0x23df4f='';for(let _0x2d8208=this['pieceNum_'];_0x2d8208<this['pieces_']['length'];_0x2d8208++)this['pieces_'][_0x2d8208]!==''&&(_0x23df4f+='/'+this['pieces_'][_0x2d8208]);return _0x23df4f||'/';}}function w(){return new C('');}function y(_0x2d9608){return _0x2d9608['pieceNum_']>=_0x2d9608['pieces_']['length']?null:_0x2d9608['pieces_'][_0x2d9608['pieceNum_']];}function we(_0x56578d){return _0x56578d['pieces_']['length']-_0x56578d['pieceNum_'];}function b(_0x4e871a){let _0x396ff7=_0x4e871a['pieceNum_'];return _0x396ff7<_0x4e871a['pieces_']['length']&&_0x396ff7++,new C(_0x4e871a['pieces_'],_0x396ff7);}function Gi(_0x812014){return _0x812014['pieceNum_']<_0x812014['pieces_']['length']?_0x812014['pieces_'][_0x812014['pieces_']['length']-0x1]:null;}function Ch(_0x5694b8){let _0x5c5975='';for(let _0xe949c0=_0x5694b8['pieceNum_'];_0xe949c0<_0x5694b8['pieces_']['length'];_0xe949c0++)_0x5694b8['pieces_'][_0xe949c0]!==''&&(_0x5c5975+='/'+encodeURIComponent(String(_0x5694b8['pieces_'][_0xe949c0])));return _0x5c5975||'/';}function kt(_0xe90d3f,_0x4a4bd9=0x0){return _0xe90d3f['pieces_']['slice'](_0xe90d3f['pieceNum_']+_0x4a4bd9);}function To(_0x118683){if(_0x118683['pieceNum_']>=_0x118683['pieces_']['length'])return null;const _0xb4027=[];for(let _0x45a3f7=_0x118683['pieceNum_'];_0x45a3f7<_0x118683['pieces_']['length']-0x1;_0x45a3f7++)_0xb4027['push'](_0x118683['pieces_'][_0x45a3f7]);return new C(_0xb4027,0x0);}function A(_0x5be2c7,_0xe07f29){const _0x1b7896=[];for(let _0x4c4e1d=_0x5be2c7['pieceNum_'];_0x4c4e1d<_0x5be2c7['pieces_']['length'];_0x4c4e1d++)_0x1b7896['push'](_0x5be2c7['pieces_'][_0x4c4e1d]);if(_0xe07f29 instanceof C){for(let _0x27e5d1=_0xe07f29['pieceNum_'];_0x27e5d1<_0xe07f29['pieces_']['length'];_0x27e5d1++)_0x1b7896['push'](_0xe07f29['pieces_'][_0x27e5d1]);}else{const _0x578352=_0xe07f29['split']('/');for(let _0xe46558=0x0;_0xe46558<_0x578352['length'];_0xe46558++)_0x578352[_0xe46558]['length']>0x0&&_0x1b7896['push'](_0x578352[_0xe46558]);}return new C(_0x1b7896,0x0);}function v(_0x329429){return _0x329429['pieceNum_']>=_0x329429['pieces_']['length'];}function F(_0x2a655b,_0x3b8f40){const _0x103c20=y(_0x2a655b),_0x393ecc=y(_0x3b8f40);if(_0x103c20===null)return _0x3b8f40;if(_0x103c20===_0x393ecc)return F(b(_0x2a655b),b(_0x3b8f40));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3b8f40+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2a655b+')');}function Th(_0x1e89b7,_0x17a43f){const _0x32f8cf=kt(_0x1e89b7,0x0),_0x51519b=kt(_0x17a43f,0x0);for(let _0x443f94=0x0;_0x443f94<_0x32f8cf['length']&&_0x443f94<_0x51519b['length'];_0x443f94++){const _0x5b9d33=He(_0x32f8cf[_0x443f94],_0x51519b[_0x443f94]);if(_0x5b9d33!==0x0)return _0x5b9d33;}return _0x32f8cf['length']===_0x51519b['length']?0x0:_0x32f8cf['length']<_0x51519b['length']?-0x1:0x1;}function qi(_0x215dd5,_0x5dd620){if(we(_0x215dd5)!==we(_0x5dd620))return!0x1;for(let _0x3abf91=_0x215dd5['pieceNum_'],_0x210726=_0x5dd620['pieceNum_'];_0x3abf91<=_0x215dd5['pieces_']['length'];_0x3abf91++,_0x210726++)if(_0x215dd5['pieces_'][_0x3abf91]!==_0x5dd620['pieces_'][_0x210726])return!0x1;return!0x0;}function $(_0x1baa56,_0x14aed1){let _0x5b6da3=_0x1baa56['pieceNum_'],_0xce5d7b=_0x14aed1['pieceNum_'];if(we(_0x1baa56)>we(_0x14aed1))return!0x1;for(;_0x5b6da3<_0x1baa56['pieces_']['length'];){if(_0x1baa56['pieces_'][_0x5b6da3]!==_0x14aed1['pieces_'][_0xce5d7b])return!0x1;++_0x5b6da3,++_0xce5d7b;}return!0x0;}class Sh{constructor(_0x254f7f,_0x2b3ed0){this['errorPrefix_']=_0x2b3ed0,this['parts_']=kt(_0x254f7f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x38d6fa=0x0;_0x38d6fa<this['parts_']['length'];_0x38d6fa++)this['byteLength_']+=Pn(this['parts_'][_0x38d6fa]);So(this);}}function bh(_0xf5c7c7,_0x2048fb){_0xf5c7c7['parts_']['length']>0x0&&(_0xf5c7c7['byteLength_']+=0x1),_0xf5c7c7['parts_']['push'](_0x2048fb),_0xf5c7c7['byteLength_']+=Pn(_0x2048fb),So(_0xf5c7c7);}function Rh(_0x1fe0ed){const _0x26dcd5=_0x1fe0ed['parts_']['pop']();_0x1fe0ed['byteLength_']-=Pn(_0x26dcd5),_0x1fe0ed['parts_']['length']>0x0&&(_0x1fe0ed['byteLength_']-=0x1);}function So(_0xddae50){if(_0xddae50['byteLength_']>Js)throw new Error(_0xddae50['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0xddae50['byteLength_']+').');if(_0xddae50['parts_']['length']>Qs)throw new Error(_0xddae50['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0xddae50));}function Ne(_0x1e4538){return _0x1e4538['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1e4538['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x1c0ff3,_0x136196;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x136196='visibilitychange',_0x1c0ff3='hidden'):typeof document['mozHidden']<'u'?(_0x136196='mozvisibilitychange',_0x1c0ff3='mozHidden'):typeof document['msHidden']<'u'?(_0x136196='msvisibilitychange',_0x1c0ff3='msHidden'):typeof document['webkitHidden']<'u'&&(_0x136196='webkitvisibilitychange',_0x1c0ff3='webkitHidden')),this['visible_']=!0x0,_0x136196&&document['addEventListener'](_0x136196,()=>{const _0x2172e8=!document[_0x1c0ff3];_0x2172e8!==this['visible_']&&(this['visible_']=_0x2172e8,this['trigger']('visible',_0x2172e8));},!0x1);}['getInitialEvent'](_0x3dcdb8){return f(_0x3dcdb8==='visible','Unknown\x20event\x20type:\x20'+_0x3dcdb8),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x264a2b,_0x30dd45,_0x1ed795,_0x209007,_0x176583,_0x22ceaf,_0x4b34bf,_0x37894b){if(super(),this['repoInfo_']=_0x264a2b,this['applicationId_']=_0x30dd45,this['onDataUpdate_']=_0x1ed795,this['onConnectStatus_']=_0x209007,this['onServerInfoUpdate_']=_0x176583,this['authTokenProvider_']=_0x22ceaf,this['appCheckTokenProvider_']=_0x4b34bf,this['authOverride_']=_0x37894b,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x37894b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x264a2b['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x26d2ed,_0x4ea3e1,_0x5ecf97){const _0x3af199=++this['requestNumber_'],_0x3e299b={'r':_0x3af199,'a':_0x26d2ed,'b':_0x4ea3e1};this['log_'](O(_0x3e299b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3e299b),_0x5ecf97&&(this['requestCBHash_'][_0x3af199]=_0x5ecf97);}['get'](_0x4c21b8){this['initConnection_']();const _0x55d8dd=new Ve(),_0x5b3a45={'action':'g','request':{'p':_0x4c21b8['_path']['toString'](),'q':_0x4c21b8['_queryObject']},'onComplete':_0x187235=>{const _0x8bf525=_0x187235['d'];_0x187235['s']==='ok'?_0x55d8dd['resolve'](_0x8bf525):_0x55d8dd['reject'](_0x8bf525);}};this['outstandingGets_']['push'](_0x5b3a45),this['outstandingGetCount_']++;const _0x389ab1=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x389ab1),_0x55d8dd['promise'];}['listen'](_0x10b526,_0x38cb8d,_0x5227fe,_0x14a76a){this['initConnection_']();const _0x2ec21d=_0x10b526['_queryIdentifier'],_0x3fbc6c=_0x10b526['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3fbc6c+'\x20'+_0x2ec21d),this['listens']['has'](_0x3fbc6c)||this['listens']['set'](_0x3fbc6c,new Map()),f(_0x10b526['_queryParams']['isDefault']()||!_0x10b526['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3fbc6c)['has'](_0x2ec21d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x43a33a={'onComplete':_0x14a76a,'hashFn':_0x38cb8d,'query':_0x10b526,'tag':_0x5227fe};this['listens']['get'](_0x3fbc6c)['set'](_0x2ec21d,_0x43a33a),this['connected_']&&this['sendListen_'](_0x43a33a);}['sendGet_'](_0x200015){const _0x25eb10=this['outstandingGets_'][_0x200015];this['sendRequest']('g',_0x25eb10['request'],_0x54087c=>{delete this['outstandingGets_'][_0x200015],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x25eb10['onComplete']&&_0x25eb10['onComplete'](_0x54087c);});}['sendListen_'](_0x14d501){const _0x10dda1=_0x14d501['query'],_0x44a651=_0x10dda1['_path']['toString'](),_0x35f457=_0x10dda1['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x44a651+'\x20for\x20'+_0x35f457);const _0x56e3fd={'p':_0x44a651},_0x2b633e='q';_0x14d501['tag']&&(_0x56e3fd['q']=_0x10dda1['_queryObject'],_0x56e3fd['t']=_0x14d501['tag']),_0x56e3fd['h']=_0x14d501['hashFn'](),this['sendRequest'](_0x2b633e,_0x56e3fd,_0x20918b=>{const _0x338673=_0x20918b['d'],_0x28164c=_0x20918b['s'];ie['warnOnListenWarnings_'](_0x338673,_0x10dda1),(this['listens']['get'](_0x44a651)&&this['listens']['get'](_0x44a651)['get'](_0x35f457))===_0x14d501&&(this['log_']('listen\x20response',_0x20918b),_0x28164c!=='ok'&&this['removeListen_'](_0x44a651,_0x35f457),_0x14d501['onComplete']&&_0x14d501['onComplete'](_0x28164c,_0x338673));});}static['warnOnListenWarnings_'](_0x22f538,_0x4c784b){if(_0x22f538&&typeof _0x22f538=='object'&&Y(_0x22f538,'w')){const _0x3e2e61=Oe(_0x22f538,'w');if(Array['isArray'](_0x3e2e61)&&~_0x3e2e61['indexOf']('no_index')){const _0x163f34='\x22.indexOn\x22:\x20\x22'+_0x4c784b['_queryParams']['getIndex']()['toString']()+'\x22',_0xb47674=_0x4c784b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x163f34+'\x20at\x20'+_0xb47674+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x571472){this['authToken_']=_0x571472,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x571472);}['reduceReconnectDelayIfAdminCredential_'](_0x1dafd9){(_0x1dafd9&&_0x1dafd9['length']===0x28||vc(_0x1dafd9))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x59a512){this['appCheckToken_']=_0x59a512,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5d7325=this['authToken_'],_0x13e3b3=yc(_0x5d7325)?'auth':'gauth',_0x46e672={'cred':_0x5d7325};this['authOverride_']===null?_0x46e672['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x46e672['authvar']=this['authOverride_']),this['sendRequest'](_0x13e3b3,_0x46e672,_0x5cf3fa=>{const _0x16e990=_0x5cf3fa['s'],_0x488e1f=_0x5cf3fa['d']||'error';this['authToken_']===_0x5d7325&&(_0x16e990==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x16e990,_0x488e1f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x24ab52=>{const _0x519451=_0x24ab52['s'],_0x3fa077=_0x24ab52['d']||'error';_0x519451==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x519451,_0x3fa077);});}['unlisten'](_0x19b1f3,_0x492c51){const _0xe27849=_0x19b1f3['_path']['toString'](),_0x7a1a7f=_0x19b1f3['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xe27849+'\x20'+_0x7a1a7f),f(_0x19b1f3['_queryParams']['isDefault']()||!_0x19b1f3['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xe27849,_0x7a1a7f)&&this['connected_']&&this['sendUnlisten_'](_0xe27849,_0x7a1a7f,_0x19b1f3['_queryObject'],_0x492c51);}['sendUnlisten_'](_0x12d4f4,_0x339593,_0x131953,_0x2f5fbf){this['log_']('Unlisten\x20on\x20'+_0x12d4f4+'\x20for\x20'+_0x339593);const _0x183c83={'p':_0x12d4f4},_0x42f349='n';_0x2f5fbf&&(_0x183c83['q']=_0x131953,_0x183c83['t']=_0x2f5fbf),this['sendRequest'](_0x42f349,_0x183c83);}['onDisconnectPut'](_0x523adc,_0x1bdc03,_0x1cdee1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x523adc,_0x1bdc03,_0x1cdee1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x523adc,'action':'o','data':_0x1bdc03,'onComplete':_0x1cdee1});}['onDisconnectMerge'](_0x39f7e8,_0x1009e2,_0x2929d0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x39f7e8,_0x1009e2,_0x2929d0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x39f7e8,'action':'om','data':_0x1009e2,'onComplete':_0x2929d0});}['onDisconnectCancel'](_0xde2a27,_0x3f91f7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xde2a27,null,_0x3f91f7):this['onDisconnectRequestQueue_']['push']({'pathString':_0xde2a27,'action':'oc','data':null,'onComplete':_0x3f91f7});}['sendOnDisconnect_'](_0x5a4a2a,_0x5b65ea,_0x238ef4,_0x35900e){const _0x3e6d32={'p':_0x5b65ea,'d':_0x238ef4};this['log_']('onDisconnect\x20'+_0x5a4a2a,_0x3e6d32),this['sendRequest'](_0x5a4a2a,_0x3e6d32,_0x1bba32=>{_0x35900e&&setTimeout(()=>{_0x35900e(_0x1bba32['s'],_0x1bba32['d']);},Math['floor'](0x0));});}['put'](_0x578459,_0x13a5d8,_0x290181,_0x211637){this['putInternal']('p',_0x578459,_0x13a5d8,_0x290181,_0x211637);}['merge'](_0xbfb425,_0x37fa05,_0x11aa88,_0x1e1a24){this['putInternal']('m',_0xbfb425,_0x37fa05,_0x11aa88,_0x1e1a24);}['putInternal'](_0x5a2170,_0x2497e6,_0x3167c8,_0x59c626,_0x5f2467){this['initConnection_']();const _0x5597a2={'p':_0x2497e6,'d':_0x3167c8};_0x5f2467!==void 0x0&&(_0x5597a2['h']=_0x5f2467),this['outstandingPuts_']['push']({'action':_0x5a2170,'request':_0x5597a2,'onComplete':_0x59c626}),this['outstandingPutCount_']++;const _0x279dfd=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x279dfd):this['log_']('Buffering\x20put:\x20'+_0x2497e6);}['sendPut_'](_0x35fcba){const _0x4cec5a=this['outstandingPuts_'][_0x35fcba]['action'],_0x3b04ba=this['outstandingPuts_'][_0x35fcba]['request'],_0x1db9a8=this['outstandingPuts_'][_0x35fcba]['onComplete'];this['outstandingPuts_'][_0x35fcba]['queued']=this['connected_'],this['sendRequest'](_0x4cec5a,_0x3b04ba,_0xa21e7b=>{this['log_'](_0x4cec5a+'\x20response',_0xa21e7b),delete this['outstandingPuts_'][_0x35fcba],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1db9a8&&_0x1db9a8(_0xa21e7b['s'],_0xa21e7b['d']);});}['reportStats'](_0x364aa8){if(this['connected_']){const _0x37bba7={'c':_0x364aa8};this['log_']('reportStats',_0x37bba7),this['sendRequest']('s',_0x37bba7,_0x29a60d=>{if(_0x29a60d['s']!=='ok'){const _0xf87ab5=_0x29a60d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xf87ab5);}});}}['onDataMessage_'](_0x18cb13){if('r'in _0x18cb13){this['log_']('from\x20server:\x20'+O(_0x18cb13));const _0x8ab9d5=_0x18cb13['r'],_0x35e59f=this['requestCBHash_'][_0x8ab9d5];_0x35e59f&&(delete this['requestCBHash_'][_0x8ab9d5],_0x35e59f(_0x18cb13['b']));}else{if('error'in _0x18cb13)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x18cb13['error'];'a'in _0x18cb13&&this['onDataPush_'](_0x18cb13['a'],_0x18cb13['b']);}}['onDataPush_'](_0x7ea0a7,_0x27e854){this['log_']('handleServerMessage',_0x7ea0a7,_0x27e854),_0x7ea0a7==='d'?this['onDataUpdate_'](_0x27e854['p'],_0x27e854['d'],!0x1,_0x27e854['t']):_0x7ea0a7==='m'?this['onDataUpdate_'](_0x27e854['p'],_0x27e854['d'],!0x0,_0x27e854['t']):_0x7ea0a7==='c'?this['onListenRevoked_'](_0x27e854['p'],_0x27e854['q']):_0x7ea0a7==='ac'?this['onAuthRevoked_'](_0x27e854['s'],_0x27e854['d']):_0x7ea0a7==='apc'?this['onAppCheckRevoked_'](_0x27e854['s'],_0x27e854['d']):_0x7ea0a7==='sd'?this['onSecurityDebugPacket_'](_0x27e854):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x7ea0a7)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3b9524,_0x3bfbff){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3b9524),this['lastSessionId']=_0x3bfbff,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5be737){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5be737));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2675ba){_0x2675ba&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2675ba;}['onOnline_'](_0x4a9ce8){_0x4a9ce8?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2ba7fa=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x33506c=Math['max'](0x0,this['reconnectDelay_']-_0x2ba7fa);_0x33506c=Math['random']()*_0x33506c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x33506c+'ms'),this['scheduleConnect_'](_0x33506c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2be011=this['onDataMessage_']['bind'](this),_0x5235fe=this['onReady_']['bind'](this),_0x2a512d=this['onRealtimeDisconnect_']['bind'](this),_0x200f61=this['id']+':'+ie['nextConnectionId_']++,_0x50065f=this['lastSessionId'];let _0x230101=!0x1,_0x1b46c4=null;const _0x2823d9=function(){_0x1b46c4?_0x1b46c4['close']():(_0x230101=!0x0,_0x2a512d());},_0x5c08e4=function(_0x141d69){f(_0x1b46c4,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1b46c4['sendRequest'](_0x141d69);};this['realtime_']={'close':_0x2823d9,'sendRequest':_0x5c08e4};const _0x2463b1=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x206eb6,_0x5f5413]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x2463b1),this['appCheckTokenProvider_']['getToken'](_0x2463b1)]);_0x230101?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x206eb6&&_0x206eb6['accessToken'],this['appCheckToken_']=_0x5f5413&&_0x5f5413['token'],_0x1b46c4=new wh(_0x200f61,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2be011,_0x5235fe,_0x2a512d,_0x353133=>{U(_0x353133+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x50065f));}catch(_0x50371f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x50371f),_0x230101||(this['repoInfo_']['nodeAdmin']&&U(_0x50371f),_0x2823d9());}}}['interrupt'](_0x3d25a1){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3d25a1),this['interruptReasons_'][_0x3d25a1]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x49f9d7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x49f9d7),delete this['interruptReasons_'][_0x49f9d7],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x48dc4b){const _0x2374d4=_0x48dc4b-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2374d4});}['cancelSentTransactions_'](){for(let _0x1b2b10=0x0;_0x1b2b10<this['outstandingPuts_']['length'];_0x1b2b10++){const _0x217660=this['outstandingPuts_'][_0x1b2b10];_0x217660&&'h'in _0x217660['request']&&_0x217660['queued']&&(_0x217660['onComplete']&&_0x217660['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1b2b10],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1dc42a,_0x4481ce){let _0x5c8db2;_0x4481ce?_0x5c8db2=_0x4481ce['map'](_0x1e227a=>Bi(_0x1e227a))['join']('$'):_0x5c8db2='default';const _0x435a95=this['removeListen_'](_0x1dc42a,_0x5c8db2);_0x435a95&&_0x435a95['onComplete']&&_0x435a95['onComplete']('permission_denied');}['removeListen_'](_0x4ac626,_0xfc8cec){const _0x4f35b2=new C(_0x4ac626)['toString']();let _0x59bc8b;if(this['listens']['has'](_0x4f35b2)){const _0x4e6390=this['listens']['get'](_0x4f35b2);_0x59bc8b=_0x4e6390['get'](_0xfc8cec),_0x4e6390['delete'](_0xfc8cec),_0x4e6390['size']===0x0&&this['listens']['delete'](_0x4f35b2);}else _0x59bc8b=void 0x0;return _0x59bc8b;}['onAuthRevoked_'](_0xf614da,_0x2f9c95){L('Auth\x20token\x20revoked:\x20'+_0xf614da+'/'+_0x2f9c95),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xf614da==='invalid_token'||_0xf614da==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xc760eb,_0x17322f){L('App\x20check\x20token\x20revoked:\x20'+_0xc760eb+'/'+_0x17322f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xc760eb==='invalid_token'||_0xc760eb==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5c8d6f){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5c8d6f):'msg'in _0x5c8d6f&&console['log']('FIREBASE:\x20'+_0x5c8d6f['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4b15ef of this['listens']['values']())for(const _0x266898 of _0x4b15ef['values']())this['sendListen_'](_0x266898);for(let _0x33c16a=0x0;_0x33c16a<this['outstandingPuts_']['length'];_0x33c16a++)this['outstandingPuts_'][_0x33c16a]&&this['sendPut_'](_0x33c16a);for(;this['onDisconnectRequestQueue_']['length'];){const _0x24a2cf=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x24a2cf['action'],_0x24a2cf['pathString'],_0x24a2cf['data'],_0x24a2cf['onComplete']);}for(let _0x5bd340=0x0;_0x5bd340<this['outstandingGets_']['length'];_0x5bd340++)this['outstandingGets_'][_0x5bd340]&&this['sendGet_'](_0x5bd340);}['sendConnectStats_'](){const _0x44dfa3={};let _0x53334b='js';_0x44dfa3['sdk.'+_0x53334b+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x44dfa3['framework.cordova']=0x1:qr()&&(_0x44dfa3['framework.reactnative']=0x1),this['reportStats'](_0x44dfa3);}['shouldReconnect_'](){const _0x4600c5=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x4600c5;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x158207,_0x2f1fbb){this['name']=_0x158207,this['node']=_0x2f1fbb;}static['Wrap'](_0x3c0044,_0x2708b7){return new E(_0x3c0044,_0x2708b7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1ccbea,_0x1a9e4a){const _0x396d0c=new E(xe,_0x1ccbea),_0x2c7610=new E(xe,_0x1a9e4a);return this['compare'](_0x396d0c,_0x2c7610)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x35a9ef){Xt=_0x35a9ef;}['compare'](_0x5e8566,_0x25232f){return He(_0x5e8566['name'],_0x25232f['name']);}['isDefinedOn'](_0x48f179){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x116513,_0x4abf99){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x37d4c9,_0x2aa88b){return f(typeof _0x37d4c9=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x37d4c9,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4e158b,_0x3236a8,_0x4aa031,_0xf81e02,_0x5b0556=null){this['isReverse_']=_0xf81e02,this['resultGenerator_']=_0x5b0556,this['nodeStack_']=[];let _0x48bc56=0x1;for(;!_0x4e158b['isEmpty']();)if(_0x4e158b=_0x4e158b,_0x48bc56=_0x3236a8?_0x4aa031(_0x4e158b['key'],_0x3236a8):0x1,_0xf81e02&&(_0x48bc56*=-0x1),_0x48bc56<0x0)this['isReverse_']?_0x4e158b=_0x4e158b['left']:_0x4e158b=_0x4e158b['right'];else{if(_0x48bc56===0x0){this['nodeStack_']['push'](_0x4e158b);break;}else this['nodeStack_']['push'](_0x4e158b),this['isReverse_']?_0x4e158b=_0x4e158b['right']:_0x4e158b=_0x4e158b['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x39ab5d=this['nodeStack_']['pop'](),_0x8284f2;if(this['resultGenerator_']?_0x8284f2=this['resultGenerator_'](_0x39ab5d['key'],_0x39ab5d['value']):_0x8284f2={'key':_0x39ab5d['key'],'value':_0x39ab5d['value']},this['isReverse_']){for(_0x39ab5d=_0x39ab5d['left'];!_0x39ab5d['isEmpty']();)this['nodeStack_']['push'](_0x39ab5d),_0x39ab5d=_0x39ab5d['right'];}else{for(_0x39ab5d=_0x39ab5d['right'];!_0x39ab5d['isEmpty']();)this['nodeStack_']['push'](_0x39ab5d),_0x39ab5d=_0x39ab5d['left'];}return _0x8284f2;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xacfa4c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xacfa4c['key'],_0xacfa4c['value']):{'key':_0xacfa4c['key'],'value':_0xacfa4c['value']};}}class M{constructor(_0x315ef1,_0xc54bb6,_0x3b2d6d,_0x251908,_0x1c1367){this['key']=_0x315ef1,this['value']=_0xc54bb6,this['color']=_0x3b2d6d??M['RED'],this['left']=_0x251908??B['EMPTY_NODE'],this['right']=_0x1c1367??B['EMPTY_NODE'];}['copy'](_0x478dfb,_0x189eb9,_0x428202,_0x28a42b,_0x4be8d5){return new M(_0x478dfb??this['key'],_0x189eb9??this['value'],_0x428202??this['color'],_0x28a42b??this['left'],_0x4be8d5??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x189336){return this['left']['inorderTraversal'](_0x189336)||!!_0x189336(this['key'],this['value'])||this['right']['inorderTraversal'](_0x189336);}['reverseTraversal'](_0x530e7b){return this['right']['reverseTraversal'](_0x530e7b)||_0x530e7b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x530e7b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xd9302d,_0x454e54,_0x166f05){let _0x52b775=this;const _0x101483=_0x166f05(_0xd9302d,_0x52b775['key']);return _0x101483<0x0?_0x52b775=_0x52b775['copy'](null,null,null,_0x52b775['left']['insert'](_0xd9302d,_0x454e54,_0x166f05),null):_0x101483===0x0?_0x52b775=_0x52b775['copy'](null,_0x454e54,null,null,null):_0x52b775=_0x52b775['copy'](null,null,null,null,_0x52b775['right']['insert'](_0xd9302d,_0x454e54,_0x166f05)),_0x52b775['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4f3e24=this;return!_0x4f3e24['left']['isRed_']()&&!_0x4f3e24['left']['left']['isRed_']()&&(_0x4f3e24=_0x4f3e24['moveRedLeft_']()),_0x4f3e24=_0x4f3e24['copy'](null,null,null,_0x4f3e24['left']['removeMin_'](),null),_0x4f3e24['fixUp_']();}['remove'](_0x250c43,_0x9c666d){let _0x5e3312,_0x39c4c7;if(_0x5e3312=this,_0x9c666d(_0x250c43,_0x5e3312['key'])<0x0)!_0x5e3312['left']['isEmpty']()&&!_0x5e3312['left']['isRed_']()&&!_0x5e3312['left']['left']['isRed_']()&&(_0x5e3312=_0x5e3312['moveRedLeft_']()),_0x5e3312=_0x5e3312['copy'](null,null,null,_0x5e3312['left']['remove'](_0x250c43,_0x9c666d),null);else{if(_0x5e3312['left']['isRed_']()&&(_0x5e3312=_0x5e3312['rotateRight_']()),!_0x5e3312['right']['isEmpty']()&&!_0x5e3312['right']['isRed_']()&&!_0x5e3312['right']['left']['isRed_']()&&(_0x5e3312=_0x5e3312['moveRedRight_']()),_0x9c666d(_0x250c43,_0x5e3312['key'])===0x0){if(_0x5e3312['right']['isEmpty']())return B['EMPTY_NODE'];_0x39c4c7=_0x5e3312['right']['min_'](),_0x5e3312=_0x5e3312['copy'](_0x39c4c7['key'],_0x39c4c7['value'],null,null,_0x5e3312['right']['removeMin_']());}_0x5e3312=_0x5e3312['copy'](null,null,null,null,_0x5e3312['right']['remove'](_0x250c43,_0x9c666d));}return _0x5e3312['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4abf25=this;return _0x4abf25['right']['isRed_']()&&!_0x4abf25['left']['isRed_']()&&(_0x4abf25=_0x4abf25['rotateLeft_']()),_0x4abf25['left']['isRed_']()&&_0x4abf25['left']['left']['isRed_']()&&(_0x4abf25=_0x4abf25['rotateRight_']()),_0x4abf25['left']['isRed_']()&&_0x4abf25['right']['isRed_']()&&(_0x4abf25=_0x4abf25['colorFlip_']()),_0x4abf25;}['moveRedLeft_'](){let _0x263bd0=this['colorFlip_']();return _0x263bd0['right']['left']['isRed_']()&&(_0x263bd0=_0x263bd0['copy'](null,null,null,null,_0x263bd0['right']['rotateRight_']()),_0x263bd0=_0x263bd0['rotateLeft_'](),_0x263bd0=_0x263bd0['colorFlip_']()),_0x263bd0;}['moveRedRight_'](){let _0x20198e=this['colorFlip_']();return _0x20198e['left']['left']['isRed_']()&&(_0x20198e=_0x20198e['rotateRight_'](),_0x20198e=_0x20198e['colorFlip_']()),_0x20198e;}['rotateLeft_'](){const _0x3fdbac=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3fdbac,null);}['rotateRight_'](){const _0x1e4a7e=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1e4a7e);}['colorFlip_'](){const _0x1ef3c9=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x20b03d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1ef3c9,_0x20b03d);}['checkMaxDepth_'](){const _0x34bb9c=this['check_']();return Math['pow'](0x2,_0x34bb9c)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xc7e8c8=this['left']['check_']();if(_0xc7e8c8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xc7e8c8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x3803a8,_0x2227e6,_0x5267d6,_0x576c58,_0x256d96){return this;}['insert'](_0x50c58a,_0xd35d14,_0x4ba51b){return new M(_0x50c58a,_0xd35d14,null);}['remove'](_0x49cd81,_0x2aa83f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x368741){return!0x1;}['reverseTraversal'](_0xe34e36){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x21fd2e,_0x36f3ba=B['EMPTY_NODE']){this['comparator_']=_0x21fd2e,this['root_']=_0x36f3ba;}['insert'](_0x189dce,_0x569cae){return new B(this['comparator_'],this['root_']['insert'](_0x189dce,_0x569cae,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x374f7e){return new B(this['comparator_'],this['root_']['remove'](_0x374f7e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x51644a){let _0x32b1cb,_0x403651=this['root_'];for(;!_0x403651['isEmpty']();){if(_0x32b1cb=this['comparator_'](_0x51644a,_0x403651['key']),_0x32b1cb===0x0)return _0x403651['value'];_0x32b1cb<0x0?_0x403651=_0x403651['left']:_0x32b1cb>0x0&&(_0x403651=_0x403651['right']);}return null;}['getPredecessorKey'](_0x6cf1e5){let _0x592eac,_0x186dd3=this['root_'],_0x5b4829=null;for(;!_0x186dd3['isEmpty']();)if(_0x592eac=this['comparator_'](_0x6cf1e5,_0x186dd3['key']),_0x592eac===0x0){if(_0x186dd3['left']['isEmpty']())return _0x5b4829?_0x5b4829['key']:null;for(_0x186dd3=_0x186dd3['left'];!_0x186dd3['right']['isEmpty']();)_0x186dd3=_0x186dd3['right'];return _0x186dd3['key'];}else _0x592eac<0x0?_0x186dd3=_0x186dd3['left']:_0x592eac>0x0&&(_0x5b4829=_0x186dd3,_0x186dd3=_0x186dd3['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x59ba38){return this['root_']['inorderTraversal'](_0x59ba38);}['reverseTraversal'](_0x398409){return this['root_']['reverseTraversal'](_0x398409);}['getIterator'](_0x52d28a){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x52d28a);}['getIteratorFrom'](_0x5dbd43,_0x100834){return new Zt(this['root_'],_0x5dbd43,this['comparator_'],!0x1,_0x100834);}['getReverseIteratorFrom'](_0x25eaf5,_0x89baea){return new Zt(this['root_'],_0x25eaf5,this['comparator_'],!0x0,_0x89baea);}['getReverseIterator'](_0x49f8b3){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x49f8b3);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x107ad8,_0x407da5){return He(_0x107ad8['name'],_0x407da5['name']);}function ji(_0x3a5127,_0x5b3947){return He(_0x3a5127,_0x5b3947);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x132885){vi=_0x132885;}const Ro=function(_0x269e85){return typeof _0x269e85=='number'?'number:'+so(_0x269e85):'string:'+_0x269e85;},Ao=function(_0x2e2717){if(_0x2e2717['isLeafNode']()){const _0x3323d2=_0x2e2717['val']();f(typeof _0x3323d2=='string'||typeof _0x3323d2=='number'||typeof _0x3323d2=='object'&&Y(_0x3323d2,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2e2717===vi||_0x2e2717['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2e2717===vi||_0x2e2717['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x500143){er=_0x500143;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4d940b,_0x501c52=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4d940b,this['priorityNode_']=_0x501c52,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x47524f){return new D(this['value_'],_0x47524f);}['getImmediateChild'](_0x8471f1){return _0x8471f1==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x29ff66){return v(_0x29ff66)?this:y(_0x29ff66)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x53d8a4,_0x306cc8){return null;}['updateImmediateChild'](_0x28760e,_0x3bdf0b){return _0x28760e==='.priority'?this['updatePriority'](_0x3bdf0b):_0x3bdf0b['isEmpty']()&&_0x28760e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x28760e,_0x3bdf0b)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x15fb0e,_0x2ac9fe){const _0x1f20cc=y(_0x15fb0e);return _0x1f20cc===null?_0x2ac9fe:_0x2ac9fe['isEmpty']()&&_0x1f20cc!=='.priority'?this:(f(_0x1f20cc!=='.priority'||we(_0x15fb0e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1f20cc,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x15fb0e),_0x2ac9fe)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1878a4,_0x59c7eb){return!0x1;}['val'](_0x1d6bf4){return _0x1d6bf4&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x505532='';this['priorityNode_']['isEmpty']()||(_0x505532+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x1c9c94=typeof this['value_'];_0x505532+=_0x1c9c94+':',_0x1c9c94==='number'?_0x505532+=so(this['value_']):_0x505532+=this['value_'],this['lazyHash_']=no(_0x505532);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x114dbe){return _0x114dbe===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x114dbe instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x114dbe['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x114dbe));}['compareToLeafNode_'](_0x29fab9){const _0xc94aa3=typeof _0x29fab9['value_'],_0x477ddc=typeof this['value_'],_0x215f54=D['VALUE_TYPE_ORDER']['indexOf'](_0xc94aa3),_0x2b0823=D['VALUE_TYPE_ORDER']['indexOf'](_0x477ddc);return f(_0x215f54>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xc94aa3),f(_0x2b0823>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x477ddc),_0x215f54===_0x2b0823?_0x477ddc==='object'?0x0:this['value_']<_0x29fab9['value_']?-0x1:this['value_']===_0x29fab9['value_']?0x0:0x1:_0x2b0823-_0x215f54;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3ae977){if(_0x3ae977===this)return!0x0;if(_0x3ae977['isLeafNode']()){const _0xe5063=_0x3ae977;return this['value_']===_0xe5063['value_']&&this['priorityNode_']['equals'](_0xe5063['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x4a843d){ko=_0x4a843d;}function xh(_0x3c8775){No=_0x3c8775;}class Fh extends On{['compare'](_0x1364a2,_0x2ffaf7){const _0x3945c4=_0x1364a2['node']['getPriority'](),_0x3e3c3b=_0x2ffaf7['node']['getPriority'](),_0x3f77b4=_0x3945c4['compareTo'](_0x3e3c3b);return _0x3f77b4===0x0?He(_0x1364a2['name'],_0x2ffaf7['name']):_0x3f77b4;}['isDefinedOn'](_0x292260){return!_0x292260['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x21485f,_0x57b44b){return!_0x21485f['getPriority']()['equals'](_0x57b44b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2c9655,_0x2345bc){const _0x2e77cb=ko(_0x2c9655);return new E(_0x2345bc,new D('[PRIORITY-POST]',_0x2e77cb));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0xa0289){const _0x74c935=_0x58905b=>parseInt(Math['log'](_0x58905b)/Uh,0xa),_0x15230e=_0x4d58c5=>parseInt(Array(_0x4d58c5+0x1)['join']('1'),0x2);this['count']=_0x74c935(_0xa0289+0x1),this['current_']=this['count']-0x1;const _0x2421c3=_0x15230e(this['count']);this['bits_']=_0xa0289+0x1&_0x2421c3;}['nextBitIsOne'](){const _0x5dbf38=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5dbf38;}}const dn=function(_0x322a23,_0x348d14,_0x5d13c2,_0xf45ee1){_0x322a23['sort'](_0x348d14);const _0x1c5523=function(_0x3f798a,_0x32dc2e){const _0x1ed541=_0x32dc2e-_0x3f798a;let _0x26afdf,_0x4419ef;if(_0x1ed541===0x0)return null;if(_0x1ed541===0x1)return _0x26afdf=_0x322a23[_0x3f798a],_0x4419ef=_0x5d13c2?_0x5d13c2(_0x26afdf):_0x26afdf,new M(_0x4419ef,_0x26afdf['node'],M['BLACK'],null,null);{const _0x59af22=parseInt(_0x1ed541/0x2,0xa)+_0x3f798a,_0x28af94=_0x1c5523(_0x3f798a,_0x59af22),_0x5f2a2e=_0x1c5523(_0x59af22+0x1,_0x32dc2e);return _0x26afdf=_0x322a23[_0x59af22],_0x4419ef=_0x5d13c2?_0x5d13c2(_0x26afdf):_0x26afdf,new M(_0x4419ef,_0x26afdf['node'],M['BLACK'],_0x28af94,_0x5f2a2e);}},_0x44108e=function(_0x3f86fc){let _0x20b25a=null,_0x5b9aee=null,_0x34bbf4=_0x322a23['length'];const _0x46f547=function(_0xe97de7,_0xd711e3){const _0x44f618=_0x34bbf4-_0xe97de7,_0x55d76c=_0x34bbf4;_0x34bbf4-=_0xe97de7;const _0x26bb7a=_0x1c5523(_0x44f618+0x1,_0x55d76c),_0x107405=_0x322a23[_0x44f618],_0x55f2c1=_0x5d13c2?_0x5d13c2(_0x107405):_0x107405;_0x1e15f3(new M(_0x55f2c1,_0x107405['node'],_0xd711e3,null,_0x26bb7a));},_0x1e15f3=function(_0x1ecc18){_0x20b25a?(_0x20b25a['left']=_0x1ecc18,_0x20b25a=_0x1ecc18):(_0x5b9aee=_0x1ecc18,_0x20b25a=_0x1ecc18);};for(let _0x12b120=0x0;_0x12b120<_0x3f86fc['count'];++_0x12b120){const _0x3517ef=_0x3f86fc['nextBitIsOne'](),_0x325b4a=Math['pow'](0x2,_0x3f86fc['count']-(_0x12b120+0x1));_0x3517ef?_0x46f547(_0x325b4a,M['BLACK']):(_0x46f547(_0x325b4a,M['BLACK']),_0x46f547(_0x325b4a,M['RED']));}return _0x5b9aee;},_0x4025f4=new Wh(_0x322a23['length']),_0x3487d5=_0x44108e(_0x4025f4);return new B(_0xf45ee1||_0x348d14,_0x3487d5);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x10cffa,_0x5deb2a){this['indexes_']=_0x10cffa,this['indexSet_']=_0x5deb2a;}['get'](_0x1e7f39){const _0x33ab68=Oe(this['indexes_'],_0x1e7f39);if(!_0x33ab68)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1e7f39);return _0x33ab68 instanceof B?_0x33ab68:null;}['hasIndex'](_0x5ed355){return Y(this['indexSet_'],_0x5ed355['toString']());}['addIndex'](_0x1d36a5,_0x328332){f(_0x1d36a5!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x159a51=[];let _0x101f73=!0x1;const _0x5b7a17=_0x328332['getIterator'](E['Wrap']);let _0x2c9919=_0x5b7a17['getNext']();for(;_0x2c9919;)_0x101f73=_0x101f73||_0x1d36a5['isDefinedOn'](_0x2c9919['node']),_0x159a51['push'](_0x2c9919),_0x2c9919=_0x5b7a17['getNext']();let _0x53238f;_0x101f73?_0x53238f=dn(_0x159a51,_0x1d36a5['getCompare']()):_0x53238f=je;const _0x52b52b=_0x1d36a5['toString'](),_0x39c5e7={...this['indexSet_']};_0x39c5e7[_0x52b52b]=_0x1d36a5;const _0x12abdd={...this['indexes_']};return _0x12abdd[_0x52b52b]=_0x53238f,new ee(_0x12abdd,_0x39c5e7);}['addToIndexes'](_0x5d1691,_0x352323){const _0xa39ebf=ln(this['indexes_'],(_0x4a05e7,_0x35c4a7)=>{const _0x3bf28f=Oe(this['indexSet_'],_0x35c4a7);if(f(_0x3bf28f,'Missing\x20index\x20implementation\x20for\x20'+_0x35c4a7),_0x4a05e7===je){if(_0x3bf28f['isDefinedOn'](_0x5d1691['node'])){const _0xd6e546=[],_0x17dd6d=_0x352323['getIterator'](E['Wrap']);let _0x33d0b2=_0x17dd6d['getNext']();for(;_0x33d0b2;)_0x33d0b2['name']!==_0x5d1691['name']&&_0xd6e546['push'](_0x33d0b2),_0x33d0b2=_0x17dd6d['getNext']();return _0xd6e546['push'](_0x5d1691),dn(_0xd6e546,_0x3bf28f['getCompare']());}else return je;}else{const _0x554c87=_0x352323['get'](_0x5d1691['name']);let _0x12fc2d=_0x4a05e7;return _0x554c87&&(_0x12fc2d=_0x12fc2d['remove'](new E(_0x5d1691['name'],_0x554c87))),_0x12fc2d['insert'](_0x5d1691,_0x5d1691['node']);}});return new ee(_0xa39ebf,this['indexSet_']);}['removeFromIndexes'](_0x3bc7fa,_0x53c9d5){const _0xc52e4c=ln(this['indexes_'],_0x4526bf=>{if(_0x4526bf===je)return _0x4526bf;{const _0x37aa45=_0x53c9d5['get'](_0x3bc7fa['name']);return _0x37aa45?_0x4526bf['remove'](new E(_0x3bc7fa['name'],_0x37aa45)):_0x4526bf;}});return new ee(_0xc52e4c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2292e1,_0x3638c3,_0x3c3978){this['children_']=_0x2292e1,this['priorityNode_']=_0x3638c3,this['indexMap_']=_0x3c3978,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x56eff1){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x56eff1,this['indexMap_']);}['getImmediateChild'](_0x24f89c){if(_0x24f89c==='.priority')return this['getPriority']();{const _0x18853a=this['children_']['get'](_0x24f89c);return _0x18853a===null?gt:_0x18853a;}}['getChild'](_0x22bfa5){const _0x5784fa=y(_0x22bfa5);return _0x5784fa===null?this:this['getImmediateChild'](_0x5784fa)['getChild'](b(_0x22bfa5));}['hasChild'](_0x50aa12){return this['children_']['get'](_0x50aa12)!==null;}['updateImmediateChild'](_0x3cb908,_0xeff66c){if(f(_0xeff66c,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3cb908==='.priority')return this['updatePriority'](_0xeff66c);{const _0x37f953=new E(_0x3cb908,_0xeff66c);let _0x25b90c,_0x19cb5b;_0xeff66c['isEmpty']()?(_0x25b90c=this['children_']['remove'](_0x3cb908),_0x19cb5b=this['indexMap_']['removeFromIndexes'](_0x37f953,this['children_'])):(_0x25b90c=this['children_']['insert'](_0x3cb908,_0xeff66c),_0x19cb5b=this['indexMap_']['addToIndexes'](_0x37f953,this['children_']));const _0x58882b=_0x25b90c['isEmpty']()?gt:this['priorityNode_'];return new g(_0x25b90c,_0x58882b,_0x19cb5b);}}['updateChild'](_0x2f39b5,_0x3d6917){const _0x487fb4=y(_0x2f39b5);if(_0x487fb4===null)return _0x3d6917;{f(y(_0x2f39b5)!=='.priority'||we(_0x2f39b5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xe5f0bc=this['getImmediateChild'](_0x487fb4)['updateChild'](b(_0x2f39b5),_0x3d6917);return this['updateImmediateChild'](_0x487fb4,_0xe5f0bc);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2df22c){if(this['isEmpty']())return null;const _0x2f152f={};let _0xfa9259=0x0,_0x1dce1a=0x0,_0x1511c0=!0x0;if(this['forEachChild'](R,(_0x5539a8,_0x14b08c)=>{_0x2f152f[_0x5539a8]=_0x14b08c['val'](_0x2df22c),_0xfa9259++,_0x1511c0&&g['INTEGER_REGEXP_']['test'](_0x5539a8)?_0x1dce1a=Math['max'](_0x1dce1a,Number(_0x5539a8)):_0x1511c0=!0x1;}),!_0x2df22c&&_0x1511c0&&_0x1dce1a<0x2*_0xfa9259){const _0x32da4f=[];for(const _0x434b3d in _0x2f152f)_0x32da4f[_0x434b3d]=_0x2f152f[_0x434b3d];return _0x32da4f;}else return _0x2df22c&&!this['getPriority']()['isEmpty']()&&(_0x2f152f['.priority']=this['getPriority']()['val']()),_0x2f152f;}['hash'](){if(this['lazyHash_']===null){let _0x53636f='';this['getPriority']()['isEmpty']()||(_0x53636f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3bac9e,_0x2f864a)=>{const _0x14ebc0=_0x2f864a['hash']();_0x14ebc0!==''&&(_0x53636f+=':'+_0x3bac9e+':'+_0x14ebc0);}),this['lazyHash_']=_0x53636f===''?'':no(_0x53636f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x11d40f,_0x4bcda5,_0x214511){const _0x5060cb=this['resolveIndex_'](_0x214511);if(_0x5060cb){const _0x387e3b=_0x5060cb['getPredecessorKey'](new E(_0x11d40f,_0x4bcda5));return _0x387e3b?_0x387e3b['name']:null;}else return this['children_']['getPredecessorKey'](_0x11d40f);}['getFirstChildName'](_0x24fc2e){const _0x246018=this['resolveIndex_'](_0x24fc2e);if(_0x246018){const _0x377b7a=_0x246018['minKey']();return _0x377b7a&&_0x377b7a['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x558ac6){const _0x5a809b=this['getFirstChildName'](_0x558ac6);return _0x5a809b?new E(_0x5a809b,this['children_']['get'](_0x5a809b)):null;}['getLastChildName'](_0xa788cc){const _0xa181d6=this['resolveIndex_'](_0xa788cc);if(_0xa181d6){const _0x3645b0=_0xa181d6['maxKey']();return _0x3645b0&&_0x3645b0['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x365262){const _0x166ef1=this['getLastChildName'](_0x365262);return _0x166ef1?new E(_0x166ef1,this['children_']['get'](_0x166ef1)):null;}['forEachChild'](_0x444b1c,_0x1e2dbc){const _0x1e0db3=this['resolveIndex_'](_0x444b1c);return _0x1e0db3?_0x1e0db3['inorderTraversal'](_0x8ee227=>_0x1e2dbc(_0x8ee227['name'],_0x8ee227['node'])):this['children_']['inorderTraversal'](_0x1e2dbc);}['getIterator'](_0x4ca7e8){return this['getIteratorFrom'](_0x4ca7e8['minPost'](),_0x4ca7e8);}['getIteratorFrom'](_0x7cd90,_0x187fe9){const _0x563f6b=this['resolveIndex_'](_0x187fe9);if(_0x563f6b)return _0x563f6b['getIteratorFrom'](_0x7cd90,_0x18e1a0=>_0x18e1a0);{const _0x3caf03=this['children_']['getIteratorFrom'](_0x7cd90['name'],E['Wrap']);let _0x26ec92=_0x3caf03['peek']();for(;_0x26ec92!=null&&_0x187fe9['compare'](_0x26ec92,_0x7cd90)<0x0;)_0x3caf03['getNext'](),_0x26ec92=_0x3caf03['peek']();return _0x3caf03;}}['getReverseIterator'](_0x254f88){return this['getReverseIteratorFrom'](_0x254f88['maxPost'](),_0x254f88);}['getReverseIteratorFrom'](_0x14a1e4,_0x229278){const _0x38002e=this['resolveIndex_'](_0x229278);if(_0x38002e)return _0x38002e['getReverseIteratorFrom'](_0x14a1e4,_0x12aa3a=>_0x12aa3a);{const _0x466cfc=this['children_']['getReverseIteratorFrom'](_0x14a1e4['name'],E['Wrap']);let _0x3f7cb8=_0x466cfc['peek']();for(;_0x3f7cb8!=null&&_0x229278['compare'](_0x3f7cb8,_0x14a1e4)>0x0;)_0x466cfc['getNext'](),_0x3f7cb8=_0x466cfc['peek']();return _0x466cfc;}}['compareTo'](_0x6c5942){return this['isEmpty']()?_0x6c5942['isEmpty']()?0x0:-0x1:_0x6c5942['isLeafNode']()||_0x6c5942['isEmpty']()?0x1:_0x6c5942===Ht?-0x1:0x0;}['withIndex'](_0x51ea0e){if(_0x51ea0e===ye||this['indexMap_']['hasIndex'](_0x51ea0e))return this;{const _0x805e8=this['indexMap_']['addIndex'](_0x51ea0e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x805e8);}}['isIndexed'](_0x54e855){return _0x54e855===ye||this['indexMap_']['hasIndex'](_0x54e855);}['equals'](_0x31f213){if(_0x31f213===this)return!0x0;if(_0x31f213['isLeafNode']())return!0x1;{const _0x566f2d=_0x31f213;if(this['getPriority']()['equals'](_0x566f2d['getPriority']())){if(this['children_']['count']()===_0x566f2d['children_']['count']()){const _0x551af2=this['getIterator'](R),_0x16b3b4=_0x566f2d['getIterator'](R);let _0x189b6c=_0x551af2['getNext'](),_0x1a79c1=_0x16b3b4['getNext']();for(;_0x189b6c&&_0x1a79c1;){if(_0x189b6c['name']!==_0x1a79c1['name']||!_0x189b6c['node']['equals'](_0x1a79c1['node']))return!0x1;_0x189b6c=_0x551af2['getNext'](),_0x1a79c1=_0x16b3b4['getNext']();}return _0x189b6c===null&&_0x1a79c1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x36cc72){return _0x36cc72===ye?null:this['indexMap_']['get'](_0x36cc72['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x354a33){return _0x354a33===this?0x0:0x1;}['equals'](_0x5e47fe){return _0x5e47fe===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3d6f5f){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x213c23,_0xaf1942=null){if(_0x213c23===null)return g['EMPTY_NODE'];if(typeof _0x213c23=='object'&&'.priority'in _0x213c23&&(_0xaf1942=_0x213c23['.priority']),f(_0xaf1942===null||typeof _0xaf1942=='string'||typeof _0xaf1942=='number'||typeof _0xaf1942=='object'&&'.sv'in _0xaf1942,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xaf1942),typeof _0x213c23=='object'&&'.value'in _0x213c23&&_0x213c23['.value']!==null&&(_0x213c23=_0x213c23['.value']),typeof _0x213c23!='object'||'.sv'in _0x213c23){const _0x528f43=_0x213c23;return new D(_0x528f43,N(_0xaf1942));}if(!(_0x213c23 instanceof Array)&&Vh){const _0x134489=[];let _0x483bee=!0x1;if(x(_0x213c23,(_0x2c2cea,_0x5c8f30)=>{if(_0x2c2cea['substring'](0x0,0x1)!=='.'){const _0xa926ea=N(_0x5c8f30);_0xa926ea['isEmpty']()||(_0x483bee=_0x483bee||!_0xa926ea['getPriority']()['isEmpty'](),_0x134489['push'](new E(_0x2c2cea,_0xa926ea)));}}),_0x134489['length']===0x0)return g['EMPTY_NODE'];const _0x5462cf=dn(_0x134489,Dh,_0x37eee0=>_0x37eee0['name'],ji);if(_0x483bee){const _0x101a39=dn(_0x134489,R['getCompare']());return new g(_0x5462cf,N(_0xaf1942),new ee({'.priority':_0x101a39},{'.priority':R}));}else return new g(_0x5462cf,N(_0xaf1942),ee['Default']);}else{let _0x5f0953=g['EMPTY_NODE'];return x(_0x213c23,(_0xdfbd69,_0x17de01)=>{if(Y(_0x213c23,_0xdfbd69)&&_0xdfbd69['substring'](0x0,0x1)!=='.'){const _0x1bd7ad=N(_0x17de01);(_0x1bd7ad['isLeafNode']()||!_0x1bd7ad['isEmpty']())&&(_0x5f0953=_0x5f0953['updateImmediateChild'](_0xdfbd69,_0x1bd7ad));}}),_0x5f0953['updatePriority'](N(_0xaf1942));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x20a771){super(),this['indexPath_']=_0x20a771,f(!v(_0x20a771)&&y(_0x20a771)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4728cf){return _0x4728cf['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2b0d23){return!_0x2b0d23['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2ec11f,_0x4124fa){const _0x4b423c=this['extractChild'](_0x2ec11f['node']),_0x169e8a=this['extractChild'](_0x4124fa['node']),_0x253afe=_0x4b423c['compareTo'](_0x169e8a);return _0x253afe===0x0?He(_0x2ec11f['name'],_0x4124fa['name']):_0x253afe;}['makePost'](_0x1d4c25,_0x27b95d){const _0x1bc53f=N(_0x1d4c25),_0xe6285d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1bc53f);return new E(_0x27b95d,_0xe6285d);}['maxPost'](){const _0x49ebdd=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x49ebdd);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x5c27d3,_0x269fbb){const _0x49a61b=_0x5c27d3['node']['compareTo'](_0x269fbb['node']);return _0x49a61b===0x0?He(_0x5c27d3['name'],_0x269fbb['name']):_0x49a61b;}['isDefinedOn'](_0x39d384){return!0x0;}['indexedValueChanged'](_0x1ca780,_0x4a8fb7){return!_0x1ca780['equals'](_0x4a8fb7);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2c267e,_0x4f0a21){const _0xed1743=N(_0x2c267e);return new E(_0x4f0a21,_0xed1743);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x2b9878){return{'type':'value','snapshotNode':_0x2b9878};}function tt(_0x423c2b,_0x16db31){return{'type':'child_added','snapshotNode':_0x16db31,'childName':_0x423c2b};}function Nt(_0x3a29fc,_0x6f54b){return{'type':'child_removed','snapshotNode':_0x6f54b,'childName':_0x3a29fc};}function Pt(_0x43398d,_0x2173d0,_0x527d46){return{'type':'child_changed','snapshotNode':_0x2173d0,'childName':_0x43398d,'oldSnap':_0x527d46};}function $h(_0x158f94,_0x5dca48){return{'type':'child_moved','snapshotNode':_0x5dca48,'childName':_0x158f94};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0xfe2c8f){this['index_']=_0xfe2c8f;}['updateChild'](_0x2ac5d8,_0x21daf7,_0x1ee2b9,_0x51ac8e,_0x2ad409,_0x5e9b09){f(_0x2ac5d8['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x535167=_0x2ac5d8['getImmediateChild'](_0x21daf7);return _0x535167['getChild'](_0x51ac8e)['equals'](_0x1ee2b9['getChild'](_0x51ac8e))&&_0x535167['isEmpty']()===_0x1ee2b9['isEmpty']()||(_0x5e9b09!=null&&(_0x1ee2b9['isEmpty']()?_0x2ac5d8['hasChild'](_0x21daf7)?_0x5e9b09['trackChildChange'](Nt(_0x21daf7,_0x535167)):f(_0x2ac5d8['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x535167['isEmpty']()?_0x5e9b09['trackChildChange'](tt(_0x21daf7,_0x1ee2b9)):_0x5e9b09['trackChildChange'](Pt(_0x21daf7,_0x1ee2b9,_0x535167))),_0x2ac5d8['isLeafNode']()&&_0x1ee2b9['isEmpty']())?_0x2ac5d8:_0x2ac5d8['updateImmediateChild'](_0x21daf7,_0x1ee2b9)['withIndex'](this['index_']);}['updateFullNode'](_0x16a77f,_0x2f7bb2,_0xaeef75){return _0xaeef75!=null&&(_0x16a77f['isLeafNode']()||_0x16a77f['forEachChild'](R,(_0x4dc451,_0x31585c)=>{_0x2f7bb2['hasChild'](_0x4dc451)||_0xaeef75['trackChildChange'](Nt(_0x4dc451,_0x31585c));}),_0x2f7bb2['isLeafNode']()||_0x2f7bb2['forEachChild'](R,(_0x4ff26e,_0x4d5911)=>{if(_0x16a77f['hasChild'](_0x4ff26e)){const _0x240722=_0x16a77f['getImmediateChild'](_0x4ff26e);_0x240722['equals'](_0x4d5911)||_0xaeef75['trackChildChange'](Pt(_0x4ff26e,_0x4d5911,_0x240722));}else _0xaeef75['trackChildChange'](tt(_0x4ff26e,_0x4d5911));})),_0x2f7bb2['withIndex'](this['index_']);}['updatePriority'](_0x12dd83,_0x5bdddf){return _0x12dd83['isEmpty']()?g['EMPTY_NODE']:_0x12dd83['updatePriority'](_0x5bdddf);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x3468a8){this['indexedFilter_']=new Yi(_0x3468a8['getIndex']()),this['index_']=_0x3468a8['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x3468a8),this['endPost_']=Ot['getEndPost_'](_0x3468a8),this['startIsInclusive_']=!_0x3468a8['startAfterSet_'],this['endIsInclusive_']=!_0x3468a8['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x426445){const _0x1e4781=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x426445)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x426445)<0x0,_0x59d8cb=this['endIsInclusive_']?this['index_']['compare'](_0x426445,this['getEndPost']())<=0x0:this['index_']['compare'](_0x426445,this['getEndPost']())<0x0;return _0x1e4781&&_0x59d8cb;}['updateChild'](_0xeee7a3,_0x25fa55,_0x2bd50a,_0x94c783,_0x46c66e,_0x120f5b){return this['matches'](new E(_0x25fa55,_0x2bd50a))||(_0x2bd50a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xeee7a3,_0x25fa55,_0x2bd50a,_0x94c783,_0x46c66e,_0x120f5b);}['updateFullNode'](_0x1a2eb,_0x45a78d,_0x5cab3f){_0x45a78d['isLeafNode']()&&(_0x45a78d=g['EMPTY_NODE']);let _0x88732a=_0x45a78d['withIndex'](this['index_']);_0x88732a=_0x88732a['updatePriority'](g['EMPTY_NODE']);const _0x4d7adb=this;return _0x45a78d['forEachChild'](R,(_0x3c9c8e,_0x42dfd4)=>{_0x4d7adb['matches'](new E(_0x3c9c8e,_0x42dfd4))||(_0x88732a=_0x88732a['updateImmediateChild'](_0x3c9c8e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1a2eb,_0x88732a,_0x5cab3f);}['updatePriority'](_0x4648dd,_0x180d7e){return _0x4648dd;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4eaf4e){if(_0x4eaf4e['hasStart']()){const _0x2e8138=_0x4eaf4e['getIndexStartName']();return _0x4eaf4e['getIndex']()['makePost'](_0x4eaf4e['getIndexStartValue'](),_0x2e8138);}else return _0x4eaf4e['getIndex']()['minPost']();}static['getEndPost_'](_0x3bd7c0){if(_0x3bd7c0['hasEnd']()){const _0x1c54d0=_0x3bd7c0['getIndexEndName']();return _0x3bd7c0['getIndex']()['makePost'](_0x3bd7c0['getIndexEndValue'](),_0x1c54d0);}else return _0x3bd7c0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x6581c7){this['withinDirectionalStart']=_0x516375=>this['reverse_']?this['withinEndPost'](_0x516375):this['withinStartPost'](_0x516375),this['withinDirectionalEnd']=_0x23da54=>this['reverse_']?this['withinStartPost'](_0x23da54):this['withinEndPost'](_0x23da54),this['withinStartPost']=_0x45c2f6=>{const _0x56c792=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x45c2f6);return this['startIsInclusive_']?_0x56c792<=0x0:_0x56c792<0x0;},this['withinEndPost']=_0x330a6c=>{const _0x44c356=this['index_']['compare'](_0x330a6c,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x44c356<=0x0:_0x44c356<0x0;},this['rangedFilter_']=new Ot(_0x6581c7),this['index_']=_0x6581c7['getIndex'](),this['limit_']=_0x6581c7['getLimit'](),this['reverse_']=!_0x6581c7['isViewFromLeft'](),this['startIsInclusive_']=!_0x6581c7['startAfterSet_'],this['endIsInclusive_']=!_0x6581c7['endBeforeSet_'];}['updateChild'](_0x31d281,_0x11da61,_0x464e27,_0x51965b,_0x221a46,_0x5adc4f){return this['rangedFilter_']['matches'](new E(_0x11da61,_0x464e27))||(_0x464e27=g['EMPTY_NODE']),_0x31d281['getImmediateChild'](_0x11da61)['equals'](_0x464e27)?_0x31d281:_0x31d281['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x31d281,_0x11da61,_0x464e27,_0x51965b,_0x221a46,_0x5adc4f):this['fullLimitUpdateChild_'](_0x31d281,_0x11da61,_0x464e27,_0x221a46,_0x5adc4f);}['updateFullNode'](_0x1c2e22,_0x4e3dd6,_0x55cdd3){let _0x31225e;if(_0x4e3dd6['isLeafNode']()||_0x4e3dd6['isEmpty']())_0x31225e=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4e3dd6['numChildren']()&&_0x4e3dd6['isIndexed'](this['index_'])){_0x31225e=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x3e7e95;this['reverse_']?_0x3e7e95=_0x4e3dd6['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x3e7e95=_0x4e3dd6['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x302f2f=0x0;for(;_0x3e7e95['hasNext']()&&_0x302f2f<this['limit_'];){const _0x191945=_0x3e7e95['getNext']();if(this['withinDirectionalStart'](_0x191945)){if(this['withinDirectionalEnd'](_0x191945))_0x31225e=_0x31225e['updateImmediateChild'](_0x191945['name'],_0x191945['node']),_0x302f2f++;else break;}else continue;}}else{_0x31225e=_0x4e3dd6['withIndex'](this['index_']),_0x31225e=_0x31225e['updatePriority'](g['EMPTY_NODE']);let _0x1017ad;this['reverse_']?_0x1017ad=_0x31225e['getReverseIterator'](this['index_']):_0x1017ad=_0x31225e['getIterator'](this['index_']);let _0x9f1ca0=0x0;for(;_0x1017ad['hasNext']();){const _0x28f65f=_0x1017ad['getNext']();_0x9f1ca0<this['limit_']&&this['withinDirectionalStart'](_0x28f65f)&&this['withinDirectionalEnd'](_0x28f65f)?_0x9f1ca0++:_0x31225e=_0x31225e['updateImmediateChild'](_0x28f65f['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1c2e22,_0x31225e,_0x55cdd3);}['updatePriority'](_0x438b51,_0x28918c){return _0x438b51;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x196a40,_0x315de6,_0x5737fe,_0x4e204c,_0x35c11e){let _0x233f64;if(this['reverse_']){const _0xb1ed0=this['index_']['getCompare']();_0x233f64=(_0xed41c7,_0x282419)=>_0xb1ed0(_0x282419,_0xed41c7);}else _0x233f64=this['index_']['getCompare']();const _0x1d954d=_0x196a40;f(_0x1d954d['numChildren']()===this['limit_'],'');const _0x95d935=new E(_0x315de6,_0x5737fe),_0x6f9185=this['reverse_']?_0x1d954d['getFirstChild'](this['index_']):_0x1d954d['getLastChild'](this['index_']),_0x2a200b=this['rangedFilter_']['matches'](_0x95d935);if(_0x1d954d['hasChild'](_0x315de6)){const _0x152d5f=_0x1d954d['getImmediateChild'](_0x315de6);let _0x3a29b8=_0x4e204c['getChildAfterChild'](this['index_'],_0x6f9185,this['reverse_']);for(;_0x3a29b8!=null&&(_0x3a29b8['name']===_0x315de6||_0x1d954d['hasChild'](_0x3a29b8['name']));)_0x3a29b8=_0x4e204c['getChildAfterChild'](this['index_'],_0x3a29b8,this['reverse_']);const _0x5bb124=_0x3a29b8==null?0x1:_0x233f64(_0x3a29b8,_0x95d935);if(_0x2a200b&&!_0x5737fe['isEmpty']()&&_0x5bb124>=0x0)return _0x35c11e!=null&&_0x35c11e['trackChildChange'](Pt(_0x315de6,_0x5737fe,_0x152d5f)),_0x1d954d['updateImmediateChild'](_0x315de6,_0x5737fe);{_0x35c11e!=null&&_0x35c11e['trackChildChange'](Nt(_0x315de6,_0x152d5f));const _0x5272b1=_0x1d954d['updateImmediateChild'](_0x315de6,g['EMPTY_NODE']);return _0x3a29b8!=null&&this['rangedFilter_']['matches'](_0x3a29b8)?(_0x35c11e!=null&&_0x35c11e['trackChildChange'](tt(_0x3a29b8['name'],_0x3a29b8['node'])),_0x5272b1['updateImmediateChild'](_0x3a29b8['name'],_0x3a29b8['node'])):_0x5272b1;}}else return _0x5737fe['isEmpty']()?_0x196a40:_0x2a200b&&_0x233f64(_0x6f9185,_0x95d935)>=0x0?(_0x35c11e!=null&&(_0x35c11e['trackChildChange'](Nt(_0x6f9185['name'],_0x6f9185['node'])),_0x35c11e['trackChildChange'](tt(_0x315de6,_0x5737fe))),_0x1d954d['updateImmediateChild'](_0x315de6,_0x5737fe)['updateImmediateChild'](_0x6f9185['name'],g['EMPTY_NODE'])):_0x196a40;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3f8cd0=new Qi();return _0x3f8cd0['limitSet_']=this['limitSet_'],_0x3f8cd0['limit_']=this['limit_'],_0x3f8cd0['startSet_']=this['startSet_'],_0x3f8cd0['startAfterSet_']=this['startAfterSet_'],_0x3f8cd0['indexStartValue_']=this['indexStartValue_'],_0x3f8cd0['startNameSet_']=this['startNameSet_'],_0x3f8cd0['indexStartName_']=this['indexStartName_'],_0x3f8cd0['endSet_']=this['endSet_'],_0x3f8cd0['endBeforeSet_']=this['endBeforeSet_'],_0x3f8cd0['indexEndValue_']=this['indexEndValue_'],_0x3f8cd0['endNameSet_']=this['endNameSet_'],_0x3f8cd0['indexEndName_']=this['indexEndName_'],_0x3f8cd0['index_']=this['index_'],_0x3f8cd0['viewFrom_']=this['viewFrom_'],_0x3f8cd0;}}function qh(_0x456758){return _0x456758['loadsAllData']()?new Yi(_0x456758['getIndex']()):_0x456758['hasLimit']()?new Gh(_0x456758):new Ot(_0x456758);}function zh(_0x5cbcb6,_0x7abe1a){const _0x5d24d9=_0x5cbcb6['copy']();return _0x5d24d9['limitSet_']=!0x0,_0x5d24d9['limit_']=_0x7abe1a,_0x5d24d9['viewFrom_']='l',_0x5d24d9;}function jh(_0x3c293d,_0x1cf3a7,_0x360a17){const _0x2ac7fd=_0x3c293d['copy']();return _0x2ac7fd['startSet_']=!0x0,_0x1cf3a7===void 0x0&&(_0x1cf3a7=null),_0x2ac7fd['indexStartValue_']=_0x1cf3a7,_0x360a17!=null?(_0x2ac7fd['startNameSet_']=!0x0,_0x2ac7fd['indexStartName_']=_0x360a17):(_0x2ac7fd['startNameSet_']=!0x1,_0x2ac7fd['indexStartName_']=''),_0x2ac7fd;}function Kh(_0x56677b,_0x2c6683,_0x4f7cbd){const _0x99bca=_0x56677b['copy']();return _0x99bca['endSet_']=!0x0,_0x2c6683===void 0x0&&(_0x2c6683=null),_0x99bca['indexEndValue_']=_0x2c6683,_0x4f7cbd!==void 0x0?(_0x99bca['endNameSet_']=!0x0,_0x99bca['indexEndName_']=_0x4f7cbd):(_0x99bca['endNameSet_']=!0x1,_0x99bca['indexEndName_']=''),_0x99bca;}function Do(_0x17fca8,_0x4546f7){const _0x544785=_0x17fca8['copy']();return _0x544785['index_']=_0x4546f7,_0x544785;}function tr(_0x50fde1){const _0x53e21e={};if(_0x50fde1['isDefault']())return _0x53e21e;let _0x5ab0a2;if(_0x50fde1['index_']===R?_0x5ab0a2='$priority':_0x50fde1['index_']===Po?_0x5ab0a2='$value':_0x50fde1['index_']===ye?_0x5ab0a2='$key':(f(_0x50fde1['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5ab0a2=_0x50fde1['index_']['toString']()),_0x53e21e['orderBy']=O(_0x5ab0a2),_0x50fde1['startSet_']){const _0x239e6c=_0x50fde1['startAfterSet_']?'startAfter':'startAt';_0x53e21e[_0x239e6c]=O(_0x50fde1['indexStartValue_']),_0x50fde1['startNameSet_']&&(_0x53e21e[_0x239e6c]+=','+O(_0x50fde1['indexStartName_']));}if(_0x50fde1['endSet_']){const _0x3b2157=_0x50fde1['endBeforeSet_']?'endBefore':'endAt';_0x53e21e[_0x3b2157]=O(_0x50fde1['indexEndValue_']),_0x50fde1['endNameSet_']&&(_0x53e21e[_0x3b2157]+=','+O(_0x50fde1['indexEndName_']));}return _0x50fde1['limitSet_']&&(_0x50fde1['isViewFromLeft']()?_0x53e21e['limitToFirst']=_0x50fde1['limit_']:_0x53e21e['limitToLast']=_0x50fde1['limit_']),_0x53e21e;}function nr(_0x37df37){const _0x526a53={};if(_0x37df37['startSet_']&&(_0x526a53['sp']=_0x37df37['indexStartValue_'],_0x37df37['startNameSet_']&&(_0x526a53['sn']=_0x37df37['indexStartName_']),_0x526a53['sin']=!_0x37df37['startAfterSet_']),_0x37df37['endSet_']&&(_0x526a53['ep']=_0x37df37['indexEndValue_'],_0x37df37['endNameSet_']&&(_0x526a53['en']=_0x37df37['indexEndName_']),_0x526a53['ein']=!_0x37df37['endBeforeSet_']),_0x37df37['limitSet_']){_0x526a53['l']=_0x37df37['limit_'];let _0x23df11=_0x37df37['viewFrom_'];_0x23df11===''&&(_0x37df37['isViewFromLeft']()?_0x23df11='l':_0x23df11='r'),_0x526a53['vf']=_0x23df11;}return _0x37df37['index_']!==R&&(_0x526a53['i']=_0x37df37['index_']['toString']()),_0x526a53;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x104a6f){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x21d159,_0x397f7a){return _0x397f7a!==void 0x0?'tag$'+_0x397f7a:(f(_0x21d159['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x21d159['_path']['toString']());}constructor(_0x25f4b2,_0x5a71f5,_0x39b5d6,_0x3c28bd){super(),this['repoInfo_']=_0x25f4b2,this['onDataUpdate_']=_0x5a71f5,this['authTokenProvider_']=_0x39b5d6,this['appCheckTokenProvider_']=_0x3c28bd,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x4808a8,_0x318051,_0x55b094,_0x234c3e){const _0x38c8ad=_0x4808a8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x38c8ad+'\x20'+_0x4808a8['_queryIdentifier']);const _0x2c3152=fn['getListenId_'](_0x4808a8,_0x55b094),_0x44bfc5={};this['listens_'][_0x2c3152]=_0x44bfc5;const _0x44f863=tr(_0x4808a8['_queryParams']);this['restRequest_'](_0x38c8ad+'.json',_0x44f863,(_0x352748,_0x3c5390)=>{let _0x23ca7d=_0x3c5390;if(_0x352748===0x194&&(_0x23ca7d=null,_0x352748=null),_0x352748===null&&this['onDataUpdate_'](_0x38c8ad,_0x23ca7d,!0x1,_0x55b094),Oe(this['listens_'],_0x2c3152)===_0x44bfc5){let _0x3253ca;_0x352748?_0x352748===0x191?_0x3253ca='permission_denied':_0x3253ca='rest_error:'+_0x352748:_0x3253ca='ok',_0x234c3e(_0x3253ca,null);}});}['unlisten'](_0xe20d6d,_0x14cf49){const _0x12cd41=fn['getListenId_'](_0xe20d6d,_0x14cf49);delete this['listens_'][_0x12cd41];}['get'](_0x41a23b){const _0x48d080=tr(_0x41a23b['_queryParams']),_0x3db6c7=_0x41a23b['_path']['toString'](),_0x350ed7=new Ve();return this['restRequest_'](_0x3db6c7+'.json',_0x48d080,(_0x58ad58,_0x2526d1)=>{let _0x243f1a=_0x2526d1;_0x58ad58===0x194&&(_0x243f1a=null,_0x58ad58=null),_0x58ad58===null?(this['onDataUpdate_'](_0x3db6c7,_0x243f1a,!0x1,null),_0x350ed7['resolve'](_0x243f1a)):_0x350ed7['reject'](new Error(_0x243f1a));}),_0x350ed7['promise'];}['refreshAuthToken'](_0x5dc6c0){}['restRequest_'](_0x1b9106,_0x5c134={},_0x5ef925){return _0x5c134['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2ce68f,_0x519b15])=>{_0x2ce68f&&_0x2ce68f['accessToken']&&(_0x5c134['auth']=_0x2ce68f['accessToken']),_0x519b15&&_0x519b15['token']&&(_0x5c134['ac']=_0x519b15['token']);const _0x27cb73=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1b9106+'?ns='+this['repoInfo_']['namespace']+at(_0x5c134);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x27cb73);const _0x135bf4=new XMLHttpRequest();_0x135bf4['onreadystatechange']=()=>{if(_0x5ef925&&_0x135bf4['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x27cb73+'\x20received.\x20status:',_0x135bf4['status'],'response:',_0x135bf4['responseText']);let _0x3416b2=null;if(_0x135bf4['status']>=0xc8&&_0x135bf4['status']<0x12c){try{_0x3416b2=bt(_0x135bf4['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x27cb73+':\x20'+_0x135bf4['responseText']);}_0x5ef925(null,_0x3416b2);}else _0x135bf4['status']!==0x191&&_0x135bf4['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x27cb73+'\x20Status:\x20'+_0x135bf4['status']),_0x5ef925(_0x135bf4['status']);_0x5ef925=null;}},_0x135bf4['open']('GET',_0x27cb73,!0x0),_0x135bf4['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x469402){return this['rootNode_']['getChild'](_0x469402);}['updateSnapshot'](_0x29bcbb,_0x3e2f16){this['rootNode_']=this['rootNode_']['updateChild'](_0x29bcbb,_0x3e2f16);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x312d12,_0x297348,_0x496348){if(v(_0x297348))_0x312d12['value']=_0x496348,_0x312d12['children']['clear']();else{if(_0x312d12['value']!==null)_0x312d12['value']=_0x312d12['value']['updateChild'](_0x297348,_0x496348);else{const _0x4a4f0c=y(_0x297348);_0x312d12['children']['has'](_0x4a4f0c)||_0x312d12['children']['set'](_0x4a4f0c,pn());const _0x45f100=_0x312d12['children']['get'](_0x4a4f0c);_0x297348=b(_0x297348),Mo(_0x45f100,_0x297348,_0x496348);}}}function Ei(_0x530a6a,_0x3d6035,_0x530376){_0x530a6a['value']!==null?_0x530376(_0x3d6035,_0x530a6a['value']):Qh(_0x530a6a,(_0x1fc5a3,_0x1cab24)=>{const _0x264e58=new C(_0x3d6035['toString']()+'/'+_0x1fc5a3);Ei(_0x1cab24,_0x264e58,_0x530376);});}function Qh(_0xb1e726,_0x1f8d9a){_0xb1e726['children']['forEach']((_0x228ff7,_0x20fd51)=>{_0x1f8d9a(_0x20fd51,_0x228ff7);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x49c068){this['collection_']=_0x49c068,this['last_']=null;}['get'](){const _0x269253=this['collection_']['get'](),_0x38301f={..._0x269253};return this['last_']&&x(this['last_'],(_0x49ef4c,_0xc0046d)=>{_0x38301f[_0x49ef4c]=_0x38301f[_0x49ef4c]-_0xc0046d;}),this['last_']=_0x269253,_0x38301f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x121a46,_0x25d10c){this['server_']=_0x25d10c,this['statsToReport_']={},this['statsListener_']=new Jh(_0x121a46);const _0x508fa2=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x508fa2));}['reportStats_'](){const _0x9c4cab=this['statsListener_']['get'](),_0x365d8b={};let _0x9e266c=!0x1;x(_0x9c4cab,(_0x4d22fb,_0x1bb39e)=>{_0x1bb39e>0x0&&Y(this['statsToReport_'],_0x4d22fb)&&(_0x365d8b[_0x4d22fb]=_0x1bb39e,_0x9e266c=!0x0);}),_0x9e266c&&this['server_']['reportStats'](_0x365d8b),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0xa617e5){_0xa617e5[_0xa617e5['OVERWRITE']=0x0]='OVERWRITE',_0xa617e5[_0xa617e5['MERGE']=0x1]='MERGE',_0xa617e5[_0xa617e5['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xa617e5[_0xa617e5['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x1fc1c0){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1fc1c0,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x24b9f0,_0x561848,_0x18d251){this['path']=_0x24b9f0,this['affectedTree']=_0x561848,this['revert']=_0x18d251,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5c51ff){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x774e48=this['affectedTree']['subtree'](new C(_0x5c51ff));return new _n(w(),_0x774e48,this['revert']);}}else return f(y(this['path'])===_0x5c51ff,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x5ee347,_0x31937b){this['source']=_0x5ee347,this['path']=_0x31937b,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x2de703){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2803a5,_0x37326f,_0x17da3b){this['source']=_0x2803a5,this['path']=_0x37326f,this['snap']=_0x17da3b,this['type']=q['OVERWRITE'];}['operationForChild'](_0x14ec61){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x14ec61)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x3646b4,_0x544745,_0x2156f6){this['source']=_0x3646b4,this['path']=_0x544745,this['children']=_0x2156f6,this['type']=q['MERGE'];}['operationForChild'](_0x3f99c1){if(v(this['path'])){const _0x1b0178=this['children']['subtree'](new C(_0x3f99c1));return _0x1b0178['isEmpty']()?null:_0x1b0178['value']?new Fe(this['source'],w(),_0x1b0178['value']):new nt(this['source'],w(),_0x1b0178);}else return f(y(this['path'])===_0x3f99c1,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2fadc8,_0x5d5f22,_0x352287){this['node_']=_0x2fadc8,this['fullyInitialized_']=_0x5d5f22,this['filtered_']=_0x352287;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3a426d){if(v(_0x3a426d))return this['isFullyInitialized']()&&!this['filtered_'];const _0x341193=y(_0x3a426d);return this['isCompleteForChild'](_0x341193);}['isCompleteForChild'](_0x4b4813){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x4b4813);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x21a296){this['query_']=_0x21a296,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3bc7b5,_0x5577fc,_0xc7ca37,_0x24de9d){const _0x2a97bd=[],_0x141192=[];return _0x5577fc['forEach'](_0x1aa24a=>{_0x1aa24a['type']==='child_changed'&&_0x3bc7b5['index_']['indexedValueChanged'](_0x1aa24a['oldSnap'],_0x1aa24a['snapshotNode'])&&_0x141192['push']($h(_0x1aa24a['childName'],_0x1aa24a['snapshotNode']));}),mt(_0x3bc7b5,_0x2a97bd,'child_removed',_0x5577fc,_0x24de9d,_0xc7ca37),mt(_0x3bc7b5,_0x2a97bd,'child_added',_0x5577fc,_0x24de9d,_0xc7ca37),mt(_0x3bc7b5,_0x2a97bd,'child_moved',_0x141192,_0x24de9d,_0xc7ca37),mt(_0x3bc7b5,_0x2a97bd,'child_changed',_0x5577fc,_0x24de9d,_0xc7ca37),mt(_0x3bc7b5,_0x2a97bd,'value',_0x5577fc,_0x24de9d,_0xc7ca37),_0x2a97bd;}function mt(_0x2e6bab,_0x3c49b6,_0x4b4a36,_0xbf0f9c,_0x22b8d6,_0x367785){const _0x1d7b50=_0xbf0f9c['filter'](_0x4f40c9=>_0x4f40c9['type']===_0x4b4a36);_0x1d7b50['sort']((_0x14613d,_0x36c53b)=>su(_0x2e6bab,_0x14613d,_0x36c53b)),_0x1d7b50['forEach'](_0x450749=>{const _0x25e213=iu(_0x2e6bab,_0x450749,_0x367785);_0x22b8d6['forEach'](_0x56d81=>{_0x56d81['respondsTo'](_0x450749['type'])&&_0x3c49b6['push'](_0x56d81['createEvent'](_0x25e213,_0x2e6bab['query_']));});});}function iu(_0x14a313,_0x33cf7e,_0x2fe896){return _0x33cf7e['type']==='value'||_0x33cf7e['type']==='child_removed'||(_0x33cf7e['prevName']=_0x2fe896['getPredecessorChildName'](_0x33cf7e['childName'],_0x33cf7e['snapshotNode'],_0x14a313['index_'])),_0x33cf7e;}function su(_0x51f809,_0x100461,_0x328fa8){if(_0x100461['childName']==null||_0x328fa8['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x413121=new E(_0x100461['childName'],_0x100461['snapshotNode']),_0x301ea0=new E(_0x328fa8['childName'],_0x328fa8['snapshotNode']);return _0x51f809['index_']['compare'](_0x413121,_0x301ea0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x56abd2,_0x4d8c2e){return{'eventCache':_0x56abd2,'serverCache':_0x4d8c2e};}function wt(_0x4423ae,_0x2df005,_0xf1293a,_0x68f9f3){return Dn(new Ce(_0x2df005,_0xf1293a,_0x68f9f3),_0x4423ae['serverCache']);}function Lo(_0x143223,_0x29cc18,_0x3afd01,_0xd267f7){return Dn(_0x143223['eventCache'],new Ce(_0x29cc18,_0x3afd01,_0xd267f7));}function gn(_0x5b002e){return _0x5b002e['eventCache']['isFullyInitialized']()?_0x5b002e['eventCache']['getNode']():null;}function Ue(_0x5ef681){return _0x5ef681['serverCache']['isFullyInitialized']()?_0x5ef681['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x1fbe5b){let _0x4e5c62=new S(null);return x(_0x1fbe5b,(_0x5b6da8,_0x97aaa)=>{_0x4e5c62=_0x4e5c62['set'](new C(_0x5b6da8),_0x97aaa);}),_0x4e5c62;}constructor(_0x4bdf7b,_0x1a4718=ru()){this['value']=_0x4bdf7b,this['children']=_0x1a4718;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x559f5f,_0x448195){if(this['value']!=null&&_0x448195(this['value']))return{'path':w(),'value':this['value']};if(v(_0x559f5f))return null;{const _0x1b9f2e=y(_0x559f5f),_0xda6149=this['children']['get'](_0x1b9f2e);if(_0xda6149!==null){const _0xc929e8=_0xda6149['findRootMostMatchingPathAndValue'](b(_0x559f5f),_0x448195);return _0xc929e8!=null?{'path':A(new C(_0x1b9f2e),_0xc929e8['path']),'value':_0xc929e8['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x222296){return this['findRootMostMatchingPathAndValue'](_0x222296,()=>!0x0);}['subtree'](_0x54e843){if(v(_0x54e843))return this;{const _0x31af30=y(_0x54e843),_0xfba091=this['children']['get'](_0x31af30);return _0xfba091!==null?_0xfba091['subtree'](b(_0x54e843)):new S(null);}}['set'](_0x295024,_0x295250){if(v(_0x295024))return new S(_0x295250,this['children']);{const _0x3cc323=y(_0x295024),_0x49462f=(this['children']['get'](_0x3cc323)||new S(null))['set'](b(_0x295024),_0x295250),_0x1226e8=this['children']['insert'](_0x3cc323,_0x49462f);return new S(this['value'],_0x1226e8);}}['remove'](_0x83e39f){if(v(_0x83e39f))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x49f7bd=y(_0x83e39f),_0x449de6=this['children']['get'](_0x49f7bd);if(_0x449de6){const _0x16531f=_0x449de6['remove'](b(_0x83e39f));let _0x15b115;return _0x16531f['isEmpty']()?_0x15b115=this['children']['remove'](_0x49f7bd):_0x15b115=this['children']['insert'](_0x49f7bd,_0x16531f),this['value']===null&&_0x15b115['isEmpty']()?new S(null):new S(this['value'],_0x15b115);}else return this;}}['get'](_0x3079fb){if(v(_0x3079fb))return this['value'];{const _0xd9a20=y(_0x3079fb),_0x1e49af=this['children']['get'](_0xd9a20);return _0x1e49af?_0x1e49af['get'](b(_0x3079fb)):null;}}['setTree'](_0x372382,_0xaa13ff){if(v(_0x372382))return _0xaa13ff;{const _0x217e14=y(_0x372382),_0x32d6b1=(this['children']['get'](_0x217e14)||new S(null))['setTree'](b(_0x372382),_0xaa13ff);let _0x45190d;return _0x32d6b1['isEmpty']()?_0x45190d=this['children']['remove'](_0x217e14):_0x45190d=this['children']['insert'](_0x217e14,_0x32d6b1),new S(this['value'],_0x45190d);}}['fold'](_0x588d69){return this['fold_'](w(),_0x588d69);}['fold_'](_0x225c50,_0x517ddf){const _0x41d863={};return this['children']['inorderTraversal']((_0x309ea6,_0x15d1be)=>{_0x41d863[_0x309ea6]=_0x15d1be['fold_'](A(_0x225c50,_0x309ea6),_0x517ddf);}),_0x517ddf(_0x225c50,this['value'],_0x41d863);}['findOnPath'](_0x32a6ec,_0x1a3b0c){return this['findOnPath_'](_0x32a6ec,w(),_0x1a3b0c);}['findOnPath_'](_0x357c30,_0x1914f6,_0x453356){const _0xc3c97e=this['value']?_0x453356(_0x1914f6,this['value']):!0x1;if(_0xc3c97e)return _0xc3c97e;if(v(_0x357c30))return null;{const _0x407c63=y(_0x357c30),_0x41a4ec=this['children']['get'](_0x407c63);return _0x41a4ec?_0x41a4ec['findOnPath_'](b(_0x357c30),A(_0x1914f6,_0x407c63),_0x453356):null;}}['foreachOnPath'](_0x5e48a9,_0x5a24b1){return this['foreachOnPath_'](_0x5e48a9,w(),_0x5a24b1);}['foreachOnPath_'](_0x11ded2,_0x2d7294,_0x88bbd2){if(v(_0x11ded2))return this;{this['value']&&_0x88bbd2(_0x2d7294,this['value']);const _0x5787f5=y(_0x11ded2),_0x242d41=this['children']['get'](_0x5787f5);return _0x242d41?_0x242d41['foreachOnPath_'](b(_0x11ded2),A(_0x2d7294,_0x5787f5),_0x88bbd2):new S(null);}}['foreach'](_0x1d0905){this['foreach_'](w(),_0x1d0905);}['foreach_'](_0x2c37f0,_0x4b2f1a){this['children']['inorderTraversal']((_0x52f856,_0x140178)=>{_0x140178['foreach_'](A(_0x2c37f0,_0x52f856),_0x4b2f1a);}),this['value']&&_0x4b2f1a(_0x2c37f0,this['value']);}['foreachChild'](_0x38ef3d){this['children']['inorderTraversal']((_0x3ade7f,_0x31d9da)=>{_0x31d9da['value']&&_0x38ef3d(_0x3ade7f,_0x31d9da['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x4acdff){this['writeTree_']=_0x4acdff;}static['empty'](){return new j(new S(null));}}function Ct(_0x2b3c58,_0x104356,_0x457b88){if(v(_0x104356))return new j(new S(_0x457b88));{const _0xc3174d=_0x2b3c58['writeTree_']['findRootMostValueAndPath'](_0x104356);if(_0xc3174d!=null){const _0x51adb4=_0xc3174d['path'];let _0x3d726a=_0xc3174d['value'];const _0x40ef2d=F(_0x51adb4,_0x104356);return _0x3d726a=_0x3d726a['updateChild'](_0x40ef2d,_0x457b88),new j(_0x2b3c58['writeTree_']['set'](_0x51adb4,_0x3d726a));}else{const _0x4c0eaf=new S(_0x457b88),_0x64125f=_0x2b3c58['writeTree_']['setTree'](_0x104356,_0x4c0eaf);return new j(_0x64125f);}}}function Ii(_0x4853cc,_0x4bd930,_0x9e2d3f){let _0xf1645c=_0x4853cc;return x(_0x9e2d3f,(_0x47b0e4,_0x1b68d5)=>{_0xf1645c=Ct(_0xf1645c,A(_0x4bd930,_0x47b0e4),_0x1b68d5);}),_0xf1645c;}function sr(_0x380333,_0x4142b3){if(v(_0x4142b3))return j['empty']();{const _0x4b8ab8=_0x380333['writeTree_']['setTree'](_0x4142b3,new S(null));return new j(_0x4b8ab8);}}function wi(_0x1bfd70,_0x502763){return $e(_0x1bfd70,_0x502763)!=null;}function $e(_0x3c053b,_0x24784c){const _0x1572f0=_0x3c053b['writeTree_']['findRootMostValueAndPath'](_0x24784c);return _0x1572f0!=null?_0x3c053b['writeTree_']['get'](_0x1572f0['path'])['getChild'](F(_0x1572f0['path'],_0x24784c)):null;}function rr(_0x556713){const _0x5a64e0=[],_0x138ec3=_0x556713['writeTree_']['value'];return _0x138ec3!=null?_0x138ec3['isLeafNode']()||_0x138ec3['forEachChild'](R,(_0x3cb8a0,_0x1b06e8)=>{_0x5a64e0['push'](new E(_0x3cb8a0,_0x1b06e8));}):_0x556713['writeTree_']['children']['inorderTraversal']((_0x20137f,_0xbe95ec)=>{_0xbe95ec['value']!=null&&_0x5a64e0['push'](new E(_0x20137f,_0xbe95ec['value']));}),_0x5a64e0;}function ve(_0x5c1312,_0x16606e){if(v(_0x16606e))return _0x5c1312;{const _0x310fbd=$e(_0x5c1312,_0x16606e);return _0x310fbd!=null?new j(new S(_0x310fbd)):new j(_0x5c1312['writeTree_']['subtree'](_0x16606e));}}function Ci(_0x106bc5){return _0x106bc5['writeTree_']['isEmpty']();}function it(_0x49d289,_0x1130f4){return xo(w(),_0x49d289['writeTree_'],_0x1130f4);}function xo(_0x1eb50a,_0x407dc7,_0x40c8e3){if(_0x407dc7['value']!=null)return _0x40c8e3['updateChild'](_0x1eb50a,_0x407dc7['value']);{let _0x440b63=null;return _0x407dc7['children']['inorderTraversal']((_0x21055d,_0x182182)=>{_0x21055d==='.priority'?(f(_0x182182['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x440b63=_0x182182['value']):_0x40c8e3=xo(A(_0x1eb50a,_0x21055d),_0x182182,_0x40c8e3);}),!_0x40c8e3['getChild'](_0x1eb50a)['isEmpty']()&&_0x440b63!==null&&(_0x40c8e3=_0x40c8e3['updateChild'](A(_0x1eb50a,'.priority'),_0x440b63)),_0x40c8e3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1249c6,_0x36249f){return Bo(_0x36249f,_0x1249c6);}function ou(_0x568587,_0x306169,_0x3b1059,_0x570a05,_0x38489c){f(_0x570a05>_0x568587['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x38489c===void 0x0&&(_0x38489c=!0x0),_0x568587['allWrites']['push']({'path':_0x306169,'snap':_0x3b1059,'writeId':_0x570a05,'visible':_0x38489c}),_0x38489c&&(_0x568587['visibleWrites']=Ct(_0x568587['visibleWrites'],_0x306169,_0x3b1059)),_0x568587['lastWriteId']=_0x570a05;}function au(_0x2be017,_0x21f75f,_0x139048,_0x1b6622){f(_0x1b6622>_0x2be017['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2be017['allWrites']['push']({'path':_0x21f75f,'children':_0x139048,'writeId':_0x1b6622,'visible':!0x0}),_0x2be017['visibleWrites']=Ii(_0x2be017['visibleWrites'],_0x21f75f,_0x139048),_0x2be017['lastWriteId']=_0x1b6622;}function cu(_0x18139c,_0x5e5ae3){for(let _0x35da89=0x0;_0x35da89<_0x18139c['allWrites']['length'];_0x35da89++){const _0x1cf788=_0x18139c['allWrites'][_0x35da89];if(_0x1cf788['writeId']===_0x5e5ae3)return _0x1cf788;}return null;}function lu(_0x3692c0,_0x115d96){const _0x1244a3=_0x3692c0['allWrites']['findIndex'](_0x29b8f3=>_0x29b8f3['writeId']===_0x115d96);f(_0x1244a3>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3f991d=_0x3692c0['allWrites'][_0x1244a3];_0x3692c0['allWrites']['splice'](_0x1244a3,0x1);let _0x278f89=_0x3f991d['visible'],_0x1cee06=!0x1,_0x331cdc=_0x3692c0['allWrites']['length']-0x1;for(;_0x278f89&&_0x331cdc>=0x0;){const _0x24b5a3=_0x3692c0['allWrites'][_0x331cdc];_0x24b5a3['visible']&&(_0x331cdc>=_0x1244a3&&hu(_0x24b5a3,_0x3f991d['path'])?_0x278f89=!0x1:$(_0x3f991d['path'],_0x24b5a3['path'])&&(_0x1cee06=!0x0)),_0x331cdc--;}if(_0x278f89){if(_0x1cee06)return uu(_0x3692c0),!0x0;if(_0x3f991d['snap'])_0x3692c0['visibleWrites']=sr(_0x3692c0['visibleWrites'],_0x3f991d['path']);else{const _0x40a67d=_0x3f991d['children'];x(_0x40a67d,_0x35bab6=>{_0x3692c0['visibleWrites']=sr(_0x3692c0['visibleWrites'],A(_0x3f991d['path'],_0x35bab6));});}return!0x0;}else return!0x1;}function hu(_0x58144e,_0x152f1f){if(_0x58144e['snap'])return $(_0x58144e['path'],_0x152f1f);for(const _0x1cd232 in _0x58144e['children'])if(_0x58144e['children']['hasOwnProperty'](_0x1cd232)&&$(A(_0x58144e['path'],_0x1cd232),_0x152f1f))return!0x0;return!0x1;}function uu(_0x20c035){_0x20c035['visibleWrites']=Fo(_0x20c035['allWrites'],du,w()),_0x20c035['allWrites']['length']>0x0?_0x20c035['lastWriteId']=_0x20c035['allWrites'][_0x20c035['allWrites']['length']-0x1]['writeId']:_0x20c035['lastWriteId']=-0x1;}function du(_0x1a5852){return _0x1a5852['visible'];}function Fo(_0xfe2e5a,_0xf3f081,_0x44a867){let _0x21e0dd=j['empty']();for(let _0x5adc4e=0x0;_0x5adc4e<_0xfe2e5a['length'];++_0x5adc4e){const _0x2e89bc=_0xfe2e5a[_0x5adc4e];if(_0xf3f081(_0x2e89bc)){const _0x7d3b3e=_0x2e89bc['path'];let _0x58eeff;if(_0x2e89bc['snap'])$(_0x44a867,_0x7d3b3e)?(_0x58eeff=F(_0x44a867,_0x7d3b3e),_0x21e0dd=Ct(_0x21e0dd,_0x58eeff,_0x2e89bc['snap'])):$(_0x7d3b3e,_0x44a867)&&(_0x58eeff=F(_0x7d3b3e,_0x44a867),_0x21e0dd=Ct(_0x21e0dd,w(),_0x2e89bc['snap']['getChild'](_0x58eeff)));else{if(_0x2e89bc['children']){if($(_0x44a867,_0x7d3b3e))_0x58eeff=F(_0x44a867,_0x7d3b3e),_0x21e0dd=Ii(_0x21e0dd,_0x58eeff,_0x2e89bc['children']);else{if($(_0x7d3b3e,_0x44a867)){if(_0x58eeff=F(_0x7d3b3e,_0x44a867),v(_0x58eeff))_0x21e0dd=Ii(_0x21e0dd,w(),_0x2e89bc['children']);else{const _0x514211=Oe(_0x2e89bc['children'],y(_0x58eeff));if(_0x514211){const _0x5a247d=_0x514211['getChild'](b(_0x58eeff));_0x21e0dd=Ct(_0x21e0dd,w(),_0x5a247d);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x21e0dd;}function Uo(_0x333118,_0x33db91,_0x138163,_0x95a3d7,_0x1a02f8){if(!_0x95a3d7&&!_0x1a02f8){const _0x5313a0=$e(_0x333118['visibleWrites'],_0x33db91);if(_0x5313a0!=null)return _0x5313a0;{const _0x1f52e2=ve(_0x333118['visibleWrites'],_0x33db91);if(Ci(_0x1f52e2))return _0x138163;if(_0x138163==null&&!wi(_0x1f52e2,w()))return null;{const _0x224ae7=_0x138163||g['EMPTY_NODE'];return it(_0x1f52e2,_0x224ae7);}}}else{const _0x15b3ee=ve(_0x333118['visibleWrites'],_0x33db91);if(!_0x1a02f8&&Ci(_0x15b3ee))return _0x138163;if(!_0x1a02f8&&_0x138163==null&&!wi(_0x15b3ee,w()))return null;{const _0xc7b267=function(_0x89a40c){return(_0x89a40c['visible']||_0x1a02f8)&&(!_0x95a3d7||!~_0x95a3d7['indexOf'](_0x89a40c['writeId']))&&($(_0x89a40c['path'],_0x33db91)||$(_0x33db91,_0x89a40c['path']));},_0x29321d=Fo(_0x333118['allWrites'],_0xc7b267,_0x33db91),_0x97f99b=_0x138163||g['EMPTY_NODE'];return it(_0x29321d,_0x97f99b);}}}function fu(_0x417e04,_0x27c7fd,_0x3114c3){let _0x4577dd=g['EMPTY_NODE'];const _0x1ecc36=$e(_0x417e04['visibleWrites'],_0x27c7fd);if(_0x1ecc36)return _0x1ecc36['isLeafNode']()||_0x1ecc36['forEachChild'](R,(_0x340581,_0x55e936)=>{_0x4577dd=_0x4577dd['updateImmediateChild'](_0x340581,_0x55e936);}),_0x4577dd;if(_0x3114c3){const _0xb39dcc=ve(_0x417e04['visibleWrites'],_0x27c7fd);return _0x3114c3['forEachChild'](R,(_0x41a746,_0x123d51)=>{const _0x192c52=it(ve(_0xb39dcc,new C(_0x41a746)),_0x123d51);_0x4577dd=_0x4577dd['updateImmediateChild'](_0x41a746,_0x192c52);}),rr(_0xb39dcc)['forEach'](_0x4ffdc5=>{_0x4577dd=_0x4577dd['updateImmediateChild'](_0x4ffdc5['name'],_0x4ffdc5['node']);}),_0x4577dd;}else{const _0x2fde15=ve(_0x417e04['visibleWrites'],_0x27c7fd);return rr(_0x2fde15)['forEach'](_0x2ef92b=>{_0x4577dd=_0x4577dd['updateImmediateChild'](_0x2ef92b['name'],_0x2ef92b['node']);}),_0x4577dd;}}function pu(_0x105ee5,_0x3bc754,_0x5f3e21,_0x263cb1,_0x1003a0){f(_0x263cb1||_0x1003a0,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xb15bbc=A(_0x3bc754,_0x5f3e21);if(wi(_0x105ee5['visibleWrites'],_0xb15bbc))return null;{const _0x50e0d9=ve(_0x105ee5['visibleWrites'],_0xb15bbc);return Ci(_0x50e0d9)?_0x1003a0['getChild'](_0x5f3e21):it(_0x50e0d9,_0x1003a0['getChild'](_0x5f3e21));}}function _u(_0x27fc2d,_0x429bb0,_0x554e92,_0x1eece1){const _0x2e6b50=A(_0x429bb0,_0x554e92),_0x2a15d3=$e(_0x27fc2d['visibleWrites'],_0x2e6b50);if(_0x2a15d3!=null)return _0x2a15d3;if(_0x1eece1['isCompleteForChild'](_0x554e92)){const _0x22b874=ve(_0x27fc2d['visibleWrites'],_0x2e6b50);return it(_0x22b874,_0x1eece1['getNode']()['getImmediateChild'](_0x554e92));}else return null;}function gu(_0x175a66,_0x437788){return $e(_0x175a66['visibleWrites'],_0x437788);}function mu(_0x21c632,_0x2b6f0b,_0x5d97b1,_0x20cac6,_0x1da763,_0x49422a,_0x240765){let _0x2db9aa;const _0x105201=ve(_0x21c632['visibleWrites'],_0x2b6f0b),_0x10a0b5=$e(_0x105201,w());if(_0x10a0b5!=null)_0x2db9aa=_0x10a0b5;else{if(_0x5d97b1!=null)_0x2db9aa=it(_0x105201,_0x5d97b1);else return[];}if(_0x2db9aa=_0x2db9aa['withIndex'](_0x240765),!_0x2db9aa['isEmpty']()&&!_0x2db9aa['isLeafNode']()){const _0x70ee38=[],_0xe9e8ca=_0x240765['getCompare'](),_0x9c1376=_0x49422a?_0x2db9aa['getReverseIteratorFrom'](_0x20cac6,_0x240765):_0x2db9aa['getIteratorFrom'](_0x20cac6,_0x240765);let _0x7a258e=_0x9c1376['getNext']();for(;_0x7a258e&&_0x70ee38['length']<_0x1da763;)_0xe9e8ca(_0x7a258e,_0x20cac6)!==0x0&&_0x70ee38['push'](_0x7a258e),_0x7a258e=_0x9c1376['getNext']();return _0x70ee38;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x1ff652,_0x2509eb,_0x2c662c,_0x273547){return Uo(_0x1ff652['writeTree'],_0x1ff652['treePath'],_0x2509eb,_0x2c662c,_0x273547);}function es(_0x332b03,_0x43f225){return fu(_0x332b03['writeTree'],_0x332b03['treePath'],_0x43f225);}function or(_0x1c34d7,_0x112166,_0x1a52a9,_0x3c608f){return pu(_0x1c34d7['writeTree'],_0x1c34d7['treePath'],_0x112166,_0x1a52a9,_0x3c608f);}function yn(_0x21e649,_0x105e56){return gu(_0x21e649['writeTree'],A(_0x21e649['treePath'],_0x105e56));}function vu(_0x1a66b2,_0x180e0a,_0x5b3c06,_0x42d6ad,_0x456f6c,_0x4f4d5e){return mu(_0x1a66b2['writeTree'],_0x1a66b2['treePath'],_0x180e0a,_0x5b3c06,_0x42d6ad,_0x456f6c,_0x4f4d5e);}function ts(_0x4ef686,_0x5d9492,_0x545909){return _u(_0x4ef686['writeTree'],_0x4ef686['treePath'],_0x5d9492,_0x545909);}function Wo(_0x3e7b13,_0x2ee787){return Bo(A(_0x3e7b13['treePath'],_0x2ee787),_0x3e7b13['writeTree']);}function Bo(_0x518396,_0xdece69){return{'treePath':_0x518396,'writeTree':_0xdece69};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x237b10){const _0xb24f82=_0x237b10['type'],_0x2e1b01=_0x237b10['childName'];f(_0xb24f82==='child_added'||_0xb24f82==='child_changed'||_0xb24f82==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2e1b01!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4e54ee=this['changeMap']['get'](_0x2e1b01);if(_0x4e54ee){const _0x3dc4d8=_0x4e54ee['type'];if(_0xb24f82==='child_added'&&_0x3dc4d8==='child_removed')this['changeMap']['set'](_0x2e1b01,Pt(_0x2e1b01,_0x237b10['snapshotNode'],_0x4e54ee['snapshotNode']));else{if(_0xb24f82==='child_removed'&&_0x3dc4d8==='child_added')this['changeMap']['delete'](_0x2e1b01);else{if(_0xb24f82==='child_removed'&&_0x3dc4d8==='child_changed')this['changeMap']['set'](_0x2e1b01,Nt(_0x2e1b01,_0x4e54ee['oldSnap']));else{if(_0xb24f82==='child_changed'&&_0x3dc4d8==='child_added')this['changeMap']['set'](_0x2e1b01,tt(_0x2e1b01,_0x237b10['snapshotNode']));else{if(_0xb24f82==='child_changed'&&_0x3dc4d8==='child_changed')this['changeMap']['set'](_0x2e1b01,Pt(_0x2e1b01,_0x237b10['snapshotNode'],_0x4e54ee['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x237b10+'\x20occurred\x20after\x20'+_0x4e54ee);}}}}}else this['changeMap']['set'](_0x2e1b01,_0x237b10);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x154e58){return null;}['getChildAfterChild'](_0x26d381,_0x1035d3,_0x232986){return null;}}const Vo=new Iu();class ns{constructor(_0x3ff2a8,_0x56c3d5,_0x596ad2=null){this['writes_']=_0x3ff2a8,this['viewCache_']=_0x56c3d5,this['optCompleteServerCache_']=_0x596ad2;}['getCompleteChild'](_0x20e990){const _0x662468=this['viewCache_']['eventCache'];if(_0x662468['isCompleteForChild'](_0x20e990))return _0x662468['getNode']()['getImmediateChild'](_0x20e990);{const _0x493b3d=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x20e990,_0x493b3d);}}['getChildAfterChild'](_0x3c01d2,_0x4ce82f,_0x27ac11){const _0x132784=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x49b851=vu(this['writes_'],_0x132784,_0x4ce82f,0x1,_0x27ac11,_0x3c01d2);return _0x49b851['length']===0x0?null:_0x49b851[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x406343){return{'filter':_0x406343};}function Cu(_0x487407,_0x5d4b5b){f(_0x5d4b5b['eventCache']['getNode']()['isIndexed'](_0x487407['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5d4b5b['serverCache']['getNode']()['isIndexed'](_0x487407['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x143308,_0x160001,_0x1e655c,_0x14e737,_0x1821c4){const _0x267cfe=new Eu();let _0x3341bf,_0x49ea45;if(_0x1e655c['type']===q['OVERWRITE']){const _0xbc4ad7=_0x1e655c;_0xbc4ad7['source']['fromUser']?_0x3341bf=Ti(_0x143308,_0x160001,_0xbc4ad7['path'],_0xbc4ad7['snap'],_0x14e737,_0x1821c4,_0x267cfe):(f(_0xbc4ad7['source']['fromServer'],'Unknown\x20source.'),_0x49ea45=_0xbc4ad7['source']['tagged']||_0x160001['serverCache']['isFiltered']()&&!v(_0xbc4ad7['path']),_0x3341bf=vn(_0x143308,_0x160001,_0xbc4ad7['path'],_0xbc4ad7['snap'],_0x14e737,_0x1821c4,_0x49ea45,_0x267cfe));}else{if(_0x1e655c['type']===q['MERGE']){const _0x13f718=_0x1e655c;_0x13f718['source']['fromUser']?_0x3341bf=bu(_0x143308,_0x160001,_0x13f718['path'],_0x13f718['children'],_0x14e737,_0x1821c4,_0x267cfe):(f(_0x13f718['source']['fromServer'],'Unknown\x20source.'),_0x49ea45=_0x13f718['source']['tagged']||_0x160001['serverCache']['isFiltered'](),_0x3341bf=Si(_0x143308,_0x160001,_0x13f718['path'],_0x13f718['children'],_0x14e737,_0x1821c4,_0x49ea45,_0x267cfe));}else{if(_0x1e655c['type']===q['ACK_USER_WRITE']){const _0x43a20a=_0x1e655c;_0x43a20a['revert']?_0x3341bf=ku(_0x143308,_0x160001,_0x43a20a['path'],_0x14e737,_0x1821c4,_0x267cfe):_0x3341bf=Ru(_0x143308,_0x160001,_0x43a20a['path'],_0x43a20a['affectedTree'],_0x14e737,_0x1821c4,_0x267cfe);}else{if(_0x1e655c['type']===q['LISTEN_COMPLETE'])_0x3341bf=Au(_0x143308,_0x160001,_0x1e655c['path'],_0x14e737,_0x267cfe);else throw ot('Unknown\x20operation\x20type:\x20'+_0x1e655c['type']);}}}const _0x21632a=_0x267cfe['getChanges']();return Su(_0x160001,_0x3341bf,_0x21632a),{'viewCache':_0x3341bf,'changes':_0x21632a};}function Su(_0x49bc66,_0x2b8b4c,_0x76e708){const _0x312aa6=_0x2b8b4c['eventCache'];if(_0x312aa6['isFullyInitialized']()){const _0xcd9d71=_0x312aa6['getNode']()['isLeafNode']()||_0x312aa6['getNode']()['isEmpty'](),_0x4c81c6=gn(_0x49bc66);(_0x76e708['length']>0x0||!_0x49bc66['eventCache']['isFullyInitialized']()||_0xcd9d71&&!_0x312aa6['getNode']()['equals'](_0x4c81c6)||!_0x312aa6['getNode']()['getPriority']()['equals'](_0x4c81c6['getPriority']()))&&_0x76e708['push'](Oo(gn(_0x2b8b4c)));}}function Ho(_0x3ae0ba,_0x410b18,_0x57cdc5,_0x1a52d8,_0x1a0043,_0x373bcd){const _0xa63081=_0x410b18['eventCache'];if(yn(_0x1a52d8,_0x57cdc5)!=null)return _0x410b18;{let _0x5f4937,_0x4c8281;if(v(_0x57cdc5)){if(f(_0x410b18['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x410b18['serverCache']['isFiltered']()){const _0x5cce4f=Ue(_0x410b18),_0x1291ec=_0x5cce4f instanceof g?_0x5cce4f:g['EMPTY_NODE'],_0x34b378=es(_0x1a52d8,_0x1291ec);_0x5f4937=_0x3ae0ba['filter']['updateFullNode'](_0x410b18['eventCache']['getNode'](),_0x34b378,_0x373bcd);}else{const _0x3bf278=mn(_0x1a52d8,Ue(_0x410b18));_0x5f4937=_0x3ae0ba['filter']['updateFullNode'](_0x410b18['eventCache']['getNode'](),_0x3bf278,_0x373bcd);}}else{const _0x3375e7=y(_0x57cdc5);if(_0x3375e7==='.priority'){f(we(_0x57cdc5)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xb599e4=_0xa63081['getNode']();_0x4c8281=_0x410b18['serverCache']['getNode']();const _0x275655=or(_0x1a52d8,_0x57cdc5,_0xb599e4,_0x4c8281);_0x275655!=null?_0x5f4937=_0x3ae0ba['filter']['updatePriority'](_0xb599e4,_0x275655):_0x5f4937=_0xa63081['getNode']();}else{const _0x190bc5=b(_0x57cdc5);let _0x56c89d;if(_0xa63081['isCompleteForChild'](_0x3375e7)){_0x4c8281=_0x410b18['serverCache']['getNode']();const _0x19d7ab=or(_0x1a52d8,_0x57cdc5,_0xa63081['getNode'](),_0x4c8281);_0x19d7ab!=null?_0x56c89d=_0xa63081['getNode']()['getImmediateChild'](_0x3375e7)['updateChild'](_0x190bc5,_0x19d7ab):_0x56c89d=_0xa63081['getNode']()['getImmediateChild'](_0x3375e7);}else _0x56c89d=ts(_0x1a52d8,_0x3375e7,_0x410b18['serverCache']);_0x56c89d!=null?_0x5f4937=_0x3ae0ba['filter']['updateChild'](_0xa63081['getNode'](),_0x3375e7,_0x56c89d,_0x190bc5,_0x1a0043,_0x373bcd):_0x5f4937=_0xa63081['getNode']();}}return wt(_0x410b18,_0x5f4937,_0xa63081['isFullyInitialized']()||v(_0x57cdc5),_0x3ae0ba['filter']['filtersNodes']());}}function vn(_0x1b957b,_0x804efb,_0x5e4fdd,_0x10e84c,_0x47d53f,_0xfa773f,_0x4f5536,_0x312dde){const _0x1ffa6f=_0x804efb['serverCache'];let _0xc09f4e;const _0x3ef28b=_0x4f5536?_0x1b957b['filter']:_0x1b957b['filter']['getIndexedFilter']();if(v(_0x5e4fdd))_0xc09f4e=_0x3ef28b['updateFullNode'](_0x1ffa6f['getNode'](),_0x10e84c,null);else{if(_0x3ef28b['filtersNodes']()&&!_0x1ffa6f['isFiltered']()){const _0x4dc580=_0x1ffa6f['getNode']()['updateChild'](_0x5e4fdd,_0x10e84c);_0xc09f4e=_0x3ef28b['updateFullNode'](_0x1ffa6f['getNode'](),_0x4dc580,null);}else{const _0x3f6cd0=y(_0x5e4fdd);if(!_0x1ffa6f['isCompleteForPath'](_0x5e4fdd)&&we(_0x5e4fdd)>0x1)return _0x804efb;const _0x2acbf6=b(_0x5e4fdd),_0x3dead=_0x1ffa6f['getNode']()['getImmediateChild'](_0x3f6cd0)['updateChild'](_0x2acbf6,_0x10e84c);_0x3f6cd0==='.priority'?_0xc09f4e=_0x3ef28b['updatePriority'](_0x1ffa6f['getNode'](),_0x3dead):_0xc09f4e=_0x3ef28b['updateChild'](_0x1ffa6f['getNode'](),_0x3f6cd0,_0x3dead,_0x2acbf6,Vo,null);}}const _0x1aec9c=Lo(_0x804efb,_0xc09f4e,_0x1ffa6f['isFullyInitialized']()||v(_0x5e4fdd),_0x3ef28b['filtersNodes']()),_0x517521=new ns(_0x47d53f,_0x1aec9c,_0xfa773f);return Ho(_0x1b957b,_0x1aec9c,_0x5e4fdd,_0x47d53f,_0x517521,_0x312dde);}function Ti(_0x14ea53,_0x4737e9,_0x45af7d,_0x25ccd6,_0x2e5456,_0x170ecd,_0x39853d){const _0x60df42=_0x4737e9['eventCache'];let _0x389217,_0x46ba9f;const _0x2f94e2=new ns(_0x2e5456,_0x4737e9,_0x170ecd);if(v(_0x45af7d))_0x46ba9f=_0x14ea53['filter']['updateFullNode'](_0x4737e9['eventCache']['getNode'](),_0x25ccd6,_0x39853d),_0x389217=wt(_0x4737e9,_0x46ba9f,!0x0,_0x14ea53['filter']['filtersNodes']());else{const _0xe7230a=y(_0x45af7d);if(_0xe7230a==='.priority')_0x46ba9f=_0x14ea53['filter']['updatePriority'](_0x4737e9['eventCache']['getNode'](),_0x25ccd6),_0x389217=wt(_0x4737e9,_0x46ba9f,_0x60df42['isFullyInitialized'](),_0x60df42['isFiltered']());else{const _0x248ecf=b(_0x45af7d),_0x12e325=_0x60df42['getNode']()['getImmediateChild'](_0xe7230a);let _0x3fae1e;if(v(_0x248ecf))_0x3fae1e=_0x25ccd6;else{const _0xd27723=_0x2f94e2['getCompleteChild'](_0xe7230a);_0xd27723!=null?Gi(_0x248ecf)==='.priority'&&_0xd27723['getChild'](To(_0x248ecf))['isEmpty']()?_0x3fae1e=_0xd27723:_0x3fae1e=_0xd27723['updateChild'](_0x248ecf,_0x25ccd6):_0x3fae1e=g['EMPTY_NODE'];}if(_0x12e325['equals'](_0x3fae1e))_0x389217=_0x4737e9;else{const _0xf57840=_0x14ea53['filter']['updateChild'](_0x60df42['getNode'](),_0xe7230a,_0x3fae1e,_0x248ecf,_0x2f94e2,_0x39853d);_0x389217=wt(_0x4737e9,_0xf57840,_0x60df42['isFullyInitialized'](),_0x14ea53['filter']['filtersNodes']());}}}return _0x389217;}function ar(_0x1f19e6,_0x16e5cf){return _0x1f19e6['eventCache']['isCompleteForChild'](_0x16e5cf);}function bu(_0x271c80,_0x1fcd19,_0x4db375,_0x23d6df,_0x5336cb,_0x287ff6,_0x2c84ba){let _0x1d3b4d=_0x1fcd19;return _0x23d6df['foreach']((_0x7fb007,_0x4113af)=>{const _0x4b8981=A(_0x4db375,_0x7fb007);ar(_0x1fcd19,y(_0x4b8981))&&(_0x1d3b4d=Ti(_0x271c80,_0x1d3b4d,_0x4b8981,_0x4113af,_0x5336cb,_0x287ff6,_0x2c84ba));}),_0x23d6df['foreach']((_0x265736,_0x195d48)=>{const _0x4d0c14=A(_0x4db375,_0x265736);ar(_0x1fcd19,y(_0x4d0c14))||(_0x1d3b4d=Ti(_0x271c80,_0x1d3b4d,_0x4d0c14,_0x195d48,_0x5336cb,_0x287ff6,_0x2c84ba));}),_0x1d3b4d;}function cr(_0x3cee89,_0x569a1e,_0x5ed348){return _0x5ed348['foreach']((_0x31f63f,_0x312ced)=>{_0x569a1e=_0x569a1e['updateChild'](_0x31f63f,_0x312ced);}),_0x569a1e;}function Si(_0x574c46,_0x2af2dd,_0x190e2f,_0x5957ef,_0x4a8481,_0x5109e6,_0x463a2d,_0x664774){if(_0x2af2dd['serverCache']['getNode']()['isEmpty']()&&!_0x2af2dd['serverCache']['isFullyInitialized']())return _0x2af2dd;let _0x275378=_0x2af2dd,_0x1f5468;v(_0x190e2f)?_0x1f5468=_0x5957ef:_0x1f5468=new S(null)['setTree'](_0x190e2f,_0x5957ef);const _0x12b57b=_0x2af2dd['serverCache']['getNode']();return _0x1f5468['children']['inorderTraversal']((_0xa094ec,_0x2fbd81)=>{if(_0x12b57b['hasChild'](_0xa094ec)){const _0x2b0fa5=_0x2af2dd['serverCache']['getNode']()['getImmediateChild'](_0xa094ec),_0x157b7b=cr(_0x574c46,_0x2b0fa5,_0x2fbd81);_0x275378=vn(_0x574c46,_0x275378,new C(_0xa094ec),_0x157b7b,_0x4a8481,_0x5109e6,_0x463a2d,_0x664774);}}),_0x1f5468['children']['inorderTraversal']((_0x30c8c1,_0x301bdd)=>{const _0x567f0f=!_0x2af2dd['serverCache']['isCompleteForChild'](_0x30c8c1)&&_0x301bdd['value']===null;if(!_0x12b57b['hasChild'](_0x30c8c1)&&!_0x567f0f){const _0x210f94=_0x2af2dd['serverCache']['getNode']()['getImmediateChild'](_0x30c8c1),_0x577e54=cr(_0x574c46,_0x210f94,_0x301bdd);_0x275378=vn(_0x574c46,_0x275378,new C(_0x30c8c1),_0x577e54,_0x4a8481,_0x5109e6,_0x463a2d,_0x664774);}}),_0x275378;}function Ru(_0x245c60,_0x3b2a78,_0x943ec6,_0xe16b76,_0x4f36a5,_0x1342e6,_0x101a67){if(yn(_0x4f36a5,_0x943ec6)!=null)return _0x3b2a78;const _0x509034=_0x3b2a78['serverCache']['isFiltered'](),_0x1901c4=_0x3b2a78['serverCache'];if(_0xe16b76['value']!=null){if(v(_0x943ec6)&&_0x1901c4['isFullyInitialized']()||_0x1901c4['isCompleteForPath'](_0x943ec6))return vn(_0x245c60,_0x3b2a78,_0x943ec6,_0x1901c4['getNode']()['getChild'](_0x943ec6),_0x4f36a5,_0x1342e6,_0x509034,_0x101a67);if(v(_0x943ec6)){let _0x33b7ca=new S(null);return _0x1901c4['getNode']()['forEachChild'](ye,(_0xe223a8,_0x3f62b6)=>{_0x33b7ca=_0x33b7ca['set'](new C(_0xe223a8),_0x3f62b6);}),Si(_0x245c60,_0x3b2a78,_0x943ec6,_0x33b7ca,_0x4f36a5,_0x1342e6,_0x509034,_0x101a67);}else return _0x3b2a78;}else{let _0x4149b3=new S(null);return _0xe16b76['foreach']((_0x46b6f3,_0x39f16d)=>{const _0x6d120f=A(_0x943ec6,_0x46b6f3);_0x1901c4['isCompleteForPath'](_0x6d120f)&&(_0x4149b3=_0x4149b3['set'](_0x46b6f3,_0x1901c4['getNode']()['getChild'](_0x6d120f)));}),Si(_0x245c60,_0x3b2a78,_0x943ec6,_0x4149b3,_0x4f36a5,_0x1342e6,_0x509034,_0x101a67);}}function Au(_0x23f91d,_0x1638b4,_0xf8c1d9,_0x11148c,_0x46834f){const _0x4e2bd0=_0x1638b4['serverCache'],_0x30a93b=Lo(_0x1638b4,_0x4e2bd0['getNode'](),_0x4e2bd0['isFullyInitialized']()||v(_0xf8c1d9),_0x4e2bd0['isFiltered']());return Ho(_0x23f91d,_0x30a93b,_0xf8c1d9,_0x11148c,Vo,_0x46834f);}function ku(_0x430f57,_0x1f9ee5,_0x2a49be,_0x261f0c,_0x1f8376,_0x1e28e5){let _0x2b62f9;if(yn(_0x261f0c,_0x2a49be)!=null)return _0x1f9ee5;{const _0x46c236=new ns(_0x261f0c,_0x1f9ee5,_0x1f8376),_0x206eb2=_0x1f9ee5['eventCache']['getNode']();let _0x22a423;if(v(_0x2a49be)||y(_0x2a49be)==='.priority'){let _0x7d879c;if(_0x1f9ee5['serverCache']['isFullyInitialized']())_0x7d879c=mn(_0x261f0c,Ue(_0x1f9ee5));else{const _0x12371f=_0x1f9ee5['serverCache']['getNode']();f(_0x12371f instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x7d879c=es(_0x261f0c,_0x12371f);}_0x7d879c=_0x7d879c,_0x22a423=_0x430f57['filter']['updateFullNode'](_0x206eb2,_0x7d879c,_0x1e28e5);}else{const _0x16f9df=y(_0x2a49be);let _0x48d37b=ts(_0x261f0c,_0x16f9df,_0x1f9ee5['serverCache']);_0x48d37b==null&&_0x1f9ee5['serverCache']['isCompleteForChild'](_0x16f9df)&&(_0x48d37b=_0x206eb2['getImmediateChild'](_0x16f9df)),_0x48d37b!=null?_0x22a423=_0x430f57['filter']['updateChild'](_0x206eb2,_0x16f9df,_0x48d37b,b(_0x2a49be),_0x46c236,_0x1e28e5):_0x1f9ee5['eventCache']['getNode']()['hasChild'](_0x16f9df)?_0x22a423=_0x430f57['filter']['updateChild'](_0x206eb2,_0x16f9df,g['EMPTY_NODE'],b(_0x2a49be),_0x46c236,_0x1e28e5):_0x22a423=_0x206eb2,_0x22a423['isEmpty']()&&_0x1f9ee5['serverCache']['isFullyInitialized']()&&(_0x2b62f9=mn(_0x261f0c,Ue(_0x1f9ee5)),_0x2b62f9['isLeafNode']()&&(_0x22a423=_0x430f57['filter']['updateFullNode'](_0x22a423,_0x2b62f9,_0x1e28e5)));}return _0x2b62f9=_0x1f9ee5['serverCache']['isFullyInitialized']()||yn(_0x261f0c,w())!=null,wt(_0x1f9ee5,_0x22a423,_0x2b62f9,_0x430f57['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x1fe4b2,_0x297b2a){this['query_']=_0x1fe4b2,this['eventRegistrations_']=[];const _0x2a11d7=this['query_']['_queryParams'],_0x2cf89b=new Yi(_0x2a11d7['getIndex']()),_0x998f1e=qh(_0x2a11d7);this['processor_']=wu(_0x998f1e);const _0x7429b4=_0x297b2a['serverCache'],_0x499968=_0x297b2a['eventCache'],_0x4aa06f=_0x2cf89b['updateFullNode'](g['EMPTY_NODE'],_0x7429b4['getNode'](),null),_0x46395f=_0x998f1e['updateFullNode'](g['EMPTY_NODE'],_0x499968['getNode'](),null),_0x3cdaa1=new Ce(_0x4aa06f,_0x7429b4['isFullyInitialized'](),_0x2cf89b['filtersNodes']()),_0xd23a18=new Ce(_0x46395f,_0x499968['isFullyInitialized'](),_0x998f1e['filtersNodes']());this['viewCache_']=Dn(_0xd23a18,_0x3cdaa1),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x4be566){return _0x4be566['viewCache_']['serverCache']['getNode']();}function Ou(_0x1e311a){return gn(_0x1e311a['viewCache_']);}function Du(_0x6b7e3c,_0x15bcff){const _0x76877e=Ue(_0x6b7e3c['viewCache_']);return _0x76877e&&(_0x6b7e3c['query']['_queryParams']['loadsAllData']()||!v(_0x15bcff)&&!_0x76877e['getImmediateChild'](y(_0x15bcff))['isEmpty']())?_0x76877e['getChild'](_0x15bcff):null;}function lr(_0x11fffa){return _0x11fffa['eventRegistrations_']['length']===0x0;}function Mu(_0x28bb64,_0x49fbeb){_0x28bb64['eventRegistrations_']['push'](_0x49fbeb);}function hr(_0x44bcdc,_0x25273d,_0x56923e){const _0x579cfa=[];if(_0x56923e){f(_0x25273d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x4d6fd2=_0x44bcdc['query']['_path'];_0x44bcdc['eventRegistrations_']['forEach'](_0x1be7e7=>{const _0x30b1ce=_0x1be7e7['createCancelEvent'](_0x56923e,_0x4d6fd2);_0x30b1ce&&_0x579cfa['push'](_0x30b1ce);});}if(_0x25273d){let _0x5c98a8=[];for(let _0x107b30=0x0;_0x107b30<_0x44bcdc['eventRegistrations_']['length'];++_0x107b30){const _0x56e4de=_0x44bcdc['eventRegistrations_'][_0x107b30];if(!_0x56e4de['matches'](_0x25273d))_0x5c98a8['push'](_0x56e4de);else{if(_0x25273d['hasAnyCallback']()){_0x5c98a8=_0x5c98a8['concat'](_0x44bcdc['eventRegistrations_']['slice'](_0x107b30+0x1));break;}}}_0x44bcdc['eventRegistrations_']=_0x5c98a8;}else _0x44bcdc['eventRegistrations_']=[];return _0x579cfa;}function ur(_0x36c65f,_0x487e38,_0x5a9829,_0x5bdf89){_0x487e38['type']===q['MERGE']&&_0x487e38['source']['queryId']!==null&&(f(Ue(_0x36c65f['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x36c65f['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3e5e43=_0x36c65f['viewCache_'],_0x57ea63=Tu(_0x36c65f['processor_'],_0x3e5e43,_0x487e38,_0x5a9829,_0x5bdf89);return Cu(_0x36c65f['processor_'],_0x57ea63['viewCache']),f(_0x57ea63['viewCache']['serverCache']['isFullyInitialized']()||!_0x3e5e43['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x36c65f['viewCache_']=_0x57ea63['viewCache'],$o(_0x36c65f,_0x57ea63['changes'],_0x57ea63['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x459706,_0x1c20d3){const _0x29283d=_0x459706['viewCache_']['eventCache'],_0x260968=[];return _0x29283d['getNode']()['isLeafNode']()||_0x29283d['getNode']()['forEachChild'](R,(_0x521e85,_0x308ea4)=>{_0x260968['push'](tt(_0x521e85,_0x308ea4));}),_0x29283d['isFullyInitialized']()&&_0x260968['push'](Oo(_0x29283d['getNode']())),$o(_0x459706,_0x260968,_0x29283d['getNode'](),_0x1c20d3);}function $o(_0x4535b2,_0x58b6a8,_0x1691a7,_0x25060e){const _0x372698=_0x25060e?[_0x25060e]:_0x4535b2['eventRegistrations_'];return nu(_0x4535b2['eventGenerator_'],_0x58b6a8,_0x1691a7,_0x372698);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x270bf8){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x270bf8;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x3c35d8){return _0x3c35d8['views']['size']===0x0;}function is(_0x14aed3,_0x57b11c,_0x1f26fc,_0x29dfb4){const _0x44a8a9=_0x57b11c['source']['queryId'];if(_0x44a8a9!==null){const _0x2ab711=_0x14aed3['views']['get'](_0x44a8a9);return f(_0x2ab711!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x2ab711,_0x57b11c,_0x1f26fc,_0x29dfb4);}else{let _0x590edb=[];for(const _0x5ef041 of _0x14aed3['views']['values']())_0x590edb=_0x590edb['concat'](ur(_0x5ef041,_0x57b11c,_0x1f26fc,_0x29dfb4));return _0x590edb;}}function qo(_0x189a20,_0x22b6ea,_0x33e1bb,_0xb01f95,_0x1e03e7){const _0x5dfaf9=_0x22b6ea['_queryIdentifier'],_0x34e16f=_0x189a20['views']['get'](_0x5dfaf9);if(!_0x34e16f){let _0x191748=mn(_0x33e1bb,_0x1e03e7?_0xb01f95:null),_0xedcce5=!0x1;_0x191748?_0xedcce5=!0x0:_0xb01f95 instanceof g?(_0x191748=es(_0x33e1bb,_0xb01f95),_0xedcce5=!0x1):(_0x191748=g['EMPTY_NODE'],_0xedcce5=!0x1);const _0x371a9a=Dn(new Ce(_0x191748,_0xedcce5,!0x1),new Ce(_0xb01f95,_0x1e03e7,!0x1));return new Nu(_0x22b6ea,_0x371a9a);}return _0x34e16f;}function Wu(_0x87ac7c,_0x30c41e,_0x111ba6,_0x392b67,_0x4db5da,_0x3db532){const _0x2fb23c=qo(_0x87ac7c,_0x30c41e,_0x392b67,_0x4db5da,_0x3db532);return _0x87ac7c['views']['has'](_0x30c41e['_queryIdentifier'])||_0x87ac7c['views']['set'](_0x30c41e['_queryIdentifier'],_0x2fb23c),Mu(_0x2fb23c,_0x111ba6),Lu(_0x2fb23c,_0x111ba6);}function Bu(_0x1bc078,_0x528ced,_0x2cd1be,_0x2f0a60){const _0x550535=_0x528ced['_queryIdentifier'],_0x45bb04=[];let _0x367529=[];const _0x5e2c35=Te(_0x1bc078);if(_0x550535==='default'){for(const [_0x1d6159,_0x2e163c]of _0x1bc078['views']['entries']())_0x367529=_0x367529['concat'](hr(_0x2e163c,_0x2cd1be,_0x2f0a60)),lr(_0x2e163c)&&(_0x1bc078['views']['delete'](_0x1d6159),_0x2e163c['query']['_queryParams']['loadsAllData']()||_0x45bb04['push'](_0x2e163c['query']));}else{const _0x582379=_0x1bc078['views']['get'](_0x550535);_0x582379&&(_0x367529=_0x367529['concat'](hr(_0x582379,_0x2cd1be,_0x2f0a60)),lr(_0x582379)&&(_0x1bc078['views']['delete'](_0x550535),_0x582379['query']['_queryParams']['loadsAllData']()||_0x45bb04['push'](_0x582379['query'])));}return _0x5e2c35&&!Te(_0x1bc078)&&_0x45bb04['push'](new(Fu())(_0x528ced['_repo'],_0x528ced['_path'])),{'removed':_0x45bb04,'events':_0x367529};}function zo(_0x4e3c56){const _0xceb826=[];for(const _0x1e6a6f of _0x4e3c56['views']['values']())_0x1e6a6f['query']['_queryParams']['loadsAllData']()||_0xceb826['push'](_0x1e6a6f);return _0xceb826;}function Ee(_0x29fd1a,_0x454afd){let _0x3dfdc3=null;for(const _0x1a0b03 of _0x29fd1a['views']['values']())_0x3dfdc3=_0x3dfdc3||Du(_0x1a0b03,_0x454afd);return _0x3dfdc3;}function jo(_0x5c80e8,_0x157818){if(_0x157818['_queryParams']['loadsAllData']())return Ln(_0x5c80e8);{const _0x46a321=_0x157818['_queryIdentifier'];return _0x5c80e8['views']['get'](_0x46a321);}}function Ko(_0x21a68d,_0x37a648){return jo(_0x21a68d,_0x37a648)!=null;}function Te(_0x1c894e){return Ln(_0x1c894e)!=null;}function Ln(_0x4c6e5e){for(const _0x49f808 of _0x4c6e5e['views']['values']())if(_0x49f808['query']['_queryParams']['loadsAllData']())return _0x49f808;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x59b7b5){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x59b7b5;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x1e8645){this['listenProvider_']=_0x1e8645,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x4296ed,_0x4fffc4,_0x4e5ed4,_0x3bf4b1,_0x167174){return ou(_0x4296ed['pendingWriteTree_'],_0x4fffc4,_0x4e5ed4,_0x3bf4b1,_0x167174),_0x167174?ht(_0x4296ed,new Fe(Ji(),_0x4fffc4,_0x4e5ed4)):[];}function Gu(_0x37aff4,_0x1a8381,_0x56b6aa,_0x561dd4){au(_0x37aff4['pendingWriteTree_'],_0x1a8381,_0x56b6aa,_0x561dd4);const _0x4c70a1=S['fromObject'](_0x56b6aa);return ht(_0x37aff4,new nt(Ji(),_0x1a8381,_0x4c70a1));}function pe(_0x29c9d9,_0x219886,_0x2136f6=!0x1){const _0x5d6af4=cu(_0x29c9d9['pendingWriteTree_'],_0x219886);if(lu(_0x29c9d9['pendingWriteTree_'],_0x219886)){let _0x5b7fd=new S(null);return _0x5d6af4['snap']!=null?_0x5b7fd=_0x5b7fd['set'](w(),!0x0):x(_0x5d6af4['children'],_0x2968db=>{_0x5b7fd=_0x5b7fd['set'](new C(_0x2968db),!0x0);}),ht(_0x29c9d9,new _n(_0x5d6af4['path'],_0x5b7fd,_0x2136f6));}else return[];}function $t(_0x56abc3,_0x1cf099,_0x3c03b4){return ht(_0x56abc3,new Fe(Xi(),_0x1cf099,_0x3c03b4));}function qu(_0x37a55f,_0x159b26,_0x47a186){const _0x46f261=S['fromObject'](_0x47a186);return ht(_0x37a55f,new nt(Xi(),_0x159b26,_0x46f261));}function zu(_0x27d4b6,_0x1fa350){return ht(_0x27d4b6,new Dt(Xi(),_0x1fa350));}function ju(_0x5b5e8f,_0x1dbc2b,_0x3b8c90){const _0x43bedf=rs(_0x5b5e8f,_0x3b8c90);if(_0x43bedf){const _0x15a0fe=os(_0x43bedf),_0x484424=_0x15a0fe['path'],_0x14220b=_0x15a0fe['queryId'],_0x31dacd=F(_0x484424,_0x1dbc2b),_0x530058=new Dt(Zi(_0x14220b),_0x31dacd);return as(_0x5b5e8f,_0x484424,_0x530058);}else return[];}function wn(_0x1aba47,_0x1e072a,_0x1025ab,_0x50744d,_0x305475=!0x1){const _0x300581=_0x1e072a['_path'],_0x1b6a35=_0x1aba47['syncPointTree_']['get'](_0x300581);let _0x2800f9=[];if(_0x1b6a35&&(_0x1e072a['_queryIdentifier']==='default'||Ko(_0x1b6a35,_0x1e072a))){const _0x3fe42b=Bu(_0x1b6a35,_0x1e072a,_0x1025ab,_0x50744d);Uu(_0x1b6a35)&&(_0x1aba47['syncPointTree_']=_0x1aba47['syncPointTree_']['remove'](_0x300581));const _0x131d7e=_0x3fe42b['removed'];if(_0x2800f9=_0x3fe42b['events'],!_0x305475){const _0x1f4469=_0x131d7e['findIndex'](_0x323d8e=>_0x323d8e['_queryParams']['loadsAllData']())!==-0x1,_0x175a40=_0x1aba47['syncPointTree_']['findOnPath'](_0x300581,(_0x1155d1,_0x3a2853)=>Te(_0x3a2853));if(_0x1f4469&&!_0x175a40){const _0x3e8be9=_0x1aba47['syncPointTree_']['subtree'](_0x300581);if(!_0x3e8be9['isEmpty']()){const _0x373224=Qu(_0x3e8be9);for(let _0x396dc7=0x0;_0x396dc7<_0x373224['length'];++_0x396dc7){const _0x81a03d=_0x373224[_0x396dc7],_0x2990c4=_0x81a03d['query'],_0x1c9742=Xo(_0x1aba47,_0x81a03d);_0x1aba47['listenProvider_']['startListening'](Tt(_0x2990c4),Mt(_0x1aba47,_0x2990c4),_0x1c9742['hashFn'],_0x1c9742['onComplete']);}}}!_0x175a40&&_0x131d7e['length']>0x0&&!_0x50744d&&(_0x1f4469?_0x1aba47['listenProvider_']['stopListening'](Tt(_0x1e072a),null):_0x131d7e['forEach'](_0x3534d1=>{const _0x10d147=_0x1aba47['queryToTagMap']['get'](Fn(_0x3534d1));_0x1aba47['listenProvider_']['stopListening'](Tt(_0x3534d1),_0x10d147);}));}Ju(_0x1aba47,_0x131d7e);}return _0x2800f9;}function Yo(_0xc03944,_0x4ee831,_0x15d5ad,_0x22df5e){const _0x3367ef=rs(_0xc03944,_0x22df5e);if(_0x3367ef!=null){const _0x13938e=os(_0x3367ef),_0x1a14a9=_0x13938e['path'],_0x37bf07=_0x13938e['queryId'],_0x1182fc=F(_0x1a14a9,_0x4ee831),_0x19f4c2=new Fe(Zi(_0x37bf07),_0x1182fc,_0x15d5ad);return as(_0xc03944,_0x1a14a9,_0x19f4c2);}else return[];}function Ku(_0x797a36,_0x12f1db,_0x178df7,_0x41a774){const _0x5c0fbf=rs(_0x797a36,_0x41a774);if(_0x5c0fbf){const _0x247cc2=os(_0x5c0fbf),_0x4116f6=_0x247cc2['path'],_0x40a641=_0x247cc2['queryId'],_0x3b0090=F(_0x4116f6,_0x12f1db),_0x5da8a3=S['fromObject'](_0x178df7),_0x1c43e7=new nt(Zi(_0x40a641),_0x3b0090,_0x5da8a3);return as(_0x797a36,_0x4116f6,_0x1c43e7);}else return[];}function bi(_0x120632,_0x462b63,_0x23ee76,_0x432145=!0x1){const _0x549340=_0x462b63['_path'];let _0x5bbcde=null,_0xe5a6dd=!0x1;_0x120632['syncPointTree_']['foreachOnPath'](_0x549340,(_0x110ef4,_0x426a9e)=>{const _0x393faf=F(_0x110ef4,_0x549340);_0x5bbcde=_0x5bbcde||Ee(_0x426a9e,_0x393faf),_0xe5a6dd=_0xe5a6dd||Te(_0x426a9e);});let _0x31c6e0=_0x120632['syncPointTree_']['get'](_0x549340);_0x31c6e0?(_0xe5a6dd=_0xe5a6dd||Te(_0x31c6e0),_0x5bbcde=_0x5bbcde||Ee(_0x31c6e0,w())):(_0x31c6e0=new Go(),_0x120632['syncPointTree_']=_0x120632['syncPointTree_']['set'](_0x549340,_0x31c6e0));let _0x30b347;_0x5bbcde!=null?_0x30b347=!0x0:(_0x30b347=!0x1,_0x5bbcde=g['EMPTY_NODE'],_0x120632['syncPointTree_']['subtree'](_0x549340)['foreachChild']((_0x44293c,_0x47413b)=>{const _0x3a88db=Ee(_0x47413b,w());_0x3a88db&&(_0x5bbcde=_0x5bbcde['updateImmediateChild'](_0x44293c,_0x3a88db));}));const _0x489331=Ko(_0x31c6e0,_0x462b63);if(!_0x489331&&!_0x462b63['_queryParams']['loadsAllData']()){const _0x1b0c15=Fn(_0x462b63);f(!_0x120632['queryToTagMap']['has'](_0x1b0c15),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3f6f4c=Xu();_0x120632['queryToTagMap']['set'](_0x1b0c15,_0x3f6f4c),_0x120632['tagToQueryMap']['set'](_0x3f6f4c,_0x1b0c15);}const _0x2a5326=Mn(_0x120632['pendingWriteTree_'],_0x549340);let _0x2007c5=Wu(_0x31c6e0,_0x462b63,_0x23ee76,_0x2a5326,_0x5bbcde,_0x30b347);if(!_0x489331&&!_0xe5a6dd&&!_0x432145){const _0x50b5eb=jo(_0x31c6e0,_0x462b63);_0x2007c5=_0x2007c5['concat'](Zu(_0x120632,_0x462b63,_0x50b5eb));}return _0x2007c5;}function xn(_0x39b9cd,_0x53e45e,_0x5421b0){const _0x3cc1d7=_0x39b9cd['pendingWriteTree_'],_0x410694=_0x39b9cd['syncPointTree_']['findOnPath'](_0x53e45e,(_0x26852f,_0x3888ab)=>{const _0x262d65=F(_0x26852f,_0x53e45e),_0x78df97=Ee(_0x3888ab,_0x262d65);if(_0x78df97)return _0x78df97;});return Uo(_0x3cc1d7,_0x53e45e,_0x410694,_0x5421b0,!0x0);}function Yu(_0x3ad528,_0x1a62a9){const _0x197f31=_0x1a62a9['_path'];let _0x5bedf0=null;_0x3ad528['syncPointTree_']['foreachOnPath'](_0x197f31,(_0x12ddf1,_0x3d3c6f)=>{const _0x174b7a=F(_0x12ddf1,_0x197f31);_0x5bedf0=_0x5bedf0||Ee(_0x3d3c6f,_0x174b7a);});let _0x4f3d8d=_0x3ad528['syncPointTree_']['get'](_0x197f31);_0x4f3d8d?_0x5bedf0=_0x5bedf0||Ee(_0x4f3d8d,w()):(_0x4f3d8d=new Go(),_0x3ad528['syncPointTree_']=_0x3ad528['syncPointTree_']['set'](_0x197f31,_0x4f3d8d));const _0x18a816=_0x5bedf0!=null,_0xb65d7=_0x18a816?new Ce(_0x5bedf0,!0x0,!0x1):null,_0x5478f1=Mn(_0x3ad528['pendingWriteTree_'],_0x1a62a9['_path']),_0x3e72f3=qo(_0x4f3d8d,_0x1a62a9,_0x5478f1,_0x18a816?_0xb65d7['getNode']():g['EMPTY_NODE'],_0x18a816);return Ou(_0x3e72f3);}function ht(_0x3ad5fc,_0x2a1c28){return Qo(_0x2a1c28,_0x3ad5fc['syncPointTree_'],null,Mn(_0x3ad5fc['pendingWriteTree_'],w()));}function Qo(_0x1eacd3,_0x105468,_0x15b87b,_0x587028){if(v(_0x1eacd3['path']))return Jo(_0x1eacd3,_0x105468,_0x15b87b,_0x587028);{const _0x549b33=_0x105468['get'](w());_0x15b87b==null&&_0x549b33!=null&&(_0x15b87b=Ee(_0x549b33,w()));let _0x8680ed=[];const _0x3b93e3=y(_0x1eacd3['path']),_0x2bc3d1=_0x1eacd3['operationForChild'](_0x3b93e3),_0x581713=_0x105468['children']['get'](_0x3b93e3);if(_0x581713&&_0x2bc3d1){const _0x28a41d=_0x15b87b?_0x15b87b['getImmediateChild'](_0x3b93e3):null,_0x38cdf8=Wo(_0x587028,_0x3b93e3);_0x8680ed=_0x8680ed['concat'](Qo(_0x2bc3d1,_0x581713,_0x28a41d,_0x38cdf8));}return _0x549b33&&(_0x8680ed=_0x8680ed['concat'](is(_0x549b33,_0x1eacd3,_0x587028,_0x15b87b))),_0x8680ed;}}function Jo(_0x2b5ee7,_0x4d8411,_0x1cc6d3,_0x566599){const _0x453123=_0x4d8411['get'](w());_0x1cc6d3==null&&_0x453123!=null&&(_0x1cc6d3=Ee(_0x453123,w()));let _0xf4d5a3=[];return _0x4d8411['children']['inorderTraversal']((_0x39a2ab,_0x339291)=>{const _0x4a67ed=_0x1cc6d3?_0x1cc6d3['getImmediateChild'](_0x39a2ab):null,_0x5d203a=Wo(_0x566599,_0x39a2ab),_0x584d49=_0x2b5ee7['operationForChild'](_0x39a2ab);_0x584d49&&(_0xf4d5a3=_0xf4d5a3['concat'](Jo(_0x584d49,_0x339291,_0x4a67ed,_0x5d203a)));}),_0x453123&&(_0xf4d5a3=_0xf4d5a3['concat'](is(_0x453123,_0x2b5ee7,_0x566599,_0x1cc6d3))),_0xf4d5a3;}function Xo(_0x3b4eb3,_0xf3f75d){const _0x1efb48=_0xf3f75d['query'],_0x786037=Mt(_0x3b4eb3,_0x1efb48);return{'hashFn':()=>(Pu(_0xf3f75d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3f4858=>{if(_0x3f4858==='ok')return _0x786037?ju(_0x3b4eb3,_0x1efb48['_path'],_0x786037):zu(_0x3b4eb3,_0x1efb48['_path']);{const _0x42c3c8=ql(_0x3f4858,_0x1efb48);return wn(_0x3b4eb3,_0x1efb48,null,_0x42c3c8);}}};}function Mt(_0x1c2973,_0x479a9d){const _0x159a48=Fn(_0x479a9d);return _0x1c2973['queryToTagMap']['get'](_0x159a48);}function Fn(_0x4f8934){return _0x4f8934['_path']['toString']()+'$'+_0x4f8934['_queryIdentifier'];}function rs(_0x4e1190,_0x1acf8c){return _0x4e1190['tagToQueryMap']['get'](_0x1acf8c);}function os(_0x3deca0){const _0xabe730=_0x3deca0['indexOf']('$');return f(_0xabe730!==-0x1&&_0xabe730<_0x3deca0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3deca0['substr'](_0xabe730+0x1),'path':new C(_0x3deca0['substr'](0x0,_0xabe730))};}function as(_0x441164,_0x27098e,_0x4a5d61){const _0x140f4c=_0x441164['syncPointTree_']['get'](_0x27098e);f(_0x140f4c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x33d7a3=Mn(_0x441164['pendingWriteTree_'],_0x27098e);return is(_0x140f4c,_0x4a5d61,_0x33d7a3,null);}function Qu(_0x101b87){return _0x101b87['fold']((_0x3f9d7b,_0x3ccd21,_0x4293fa)=>{if(_0x3ccd21&&Te(_0x3ccd21))return[Ln(_0x3ccd21)];{let _0x134c4f=[];return _0x3ccd21&&(_0x134c4f=zo(_0x3ccd21)),x(_0x4293fa,(_0x588328,_0x2ac3a3)=>{_0x134c4f=_0x134c4f['concat'](_0x2ac3a3);}),_0x134c4f;}});}function Tt(_0x4411ba){return _0x4411ba['_queryParams']['loadsAllData']()&&!_0x4411ba['_queryParams']['isDefault']()?new(Hu())(_0x4411ba['_repo'],_0x4411ba['_path']):_0x4411ba;}function Ju(_0x2c22d1,_0x428288){for(let _0x39a552=0x0;_0x39a552<_0x428288['length'];++_0x39a552){const _0x2931ca=_0x428288[_0x39a552];if(!_0x2931ca['_queryParams']['loadsAllData']()){const _0x304864=Fn(_0x2931ca),_0x2ccb2d=_0x2c22d1['queryToTagMap']['get'](_0x304864);_0x2c22d1['queryToTagMap']['delete'](_0x304864),_0x2c22d1['tagToQueryMap']['delete'](_0x2ccb2d);}}}function Xu(){return $u++;}function Zu(_0x1aef57,_0x2c1398,_0x525974){const _0x282073=_0x2c1398['_path'],_0x14f011=Mt(_0x1aef57,_0x2c1398),_0x25bfc0=Xo(_0x1aef57,_0x525974),_0x160fee=_0x1aef57['listenProvider_']['startListening'](Tt(_0x2c1398),_0x14f011,_0x25bfc0['hashFn'],_0x25bfc0['onComplete']),_0x1c2a57=_0x1aef57['syncPointTree_']['subtree'](_0x282073);if(_0x14f011)f(!Te(_0x1c2a57['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3422cf=_0x1c2a57['fold']((_0x108590,_0x380a14,_0x542899)=>{if(!v(_0x108590)&&_0x380a14&&Te(_0x380a14))return[Ln(_0x380a14)['query']];{let _0x5d448e=[];return _0x380a14&&(_0x5d448e=_0x5d448e['concat'](zo(_0x380a14)['map'](_0x15c6f6=>_0x15c6f6['query']))),x(_0x542899,(_0x224397,_0x4cacb5)=>{_0x5d448e=_0x5d448e['concat'](_0x4cacb5);}),_0x5d448e;}});for(let _0x214b4e=0x0;_0x214b4e<_0x3422cf['length'];++_0x214b4e){const _0x54eb22=_0x3422cf[_0x214b4e];_0x1aef57['listenProvider_']['stopListening'](Tt(_0x54eb22),Mt(_0x1aef57,_0x54eb22));}}return _0x160fee;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x4d92b7){this['node_']=_0x4d92b7;}['getImmediateChild'](_0x212036){const _0x133a1d=this['node_']['getImmediateChild'](_0x212036);return new cs(_0x133a1d);}['node'](){return this['node_'];}}class ls{constructor(_0x5b30a3,_0x91339){this['syncTree_']=_0x5b30a3,this['path_']=_0x91339;}['getImmediateChild'](_0x437e99){const _0x55cb02=A(this['path_'],_0x437e99);return new ls(this['syncTree_'],_0x55cb02);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x55daba){return _0x55daba=_0x55daba||{},_0x55daba['timestamp']=_0x55daba['timestamp']||new Date()['getTime'](),_0x55daba;},fr=function(_0x3a441c,_0x5a343b,_0x3dd62a){if(!_0x3a441c||typeof _0x3a441c!='object')return _0x3a441c;if(f('.sv'in _0x3a441c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3a441c['.sv']=='string')return td(_0x3a441c['.sv'],_0x5a343b,_0x3dd62a);if(typeof _0x3a441c['.sv']=='object')return nd(_0x3a441c['.sv'],_0x5a343b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3a441c,null,0x2));},td=function(_0x17bb15,_0x5ef9fc,_0x185aa1){switch(_0x17bb15){case'timestamp':return _0x185aa1['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x17bb15);}},nd=function(_0x28da2d,_0x437520,_0x42cb86){_0x28da2d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x28da2d,null,0x2));const _0x1ac51c=_0x28da2d['increment'];typeof _0x1ac51c!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1ac51c);const _0x5a38e5=_0x437520['node']();if(f(_0x5a38e5!==null&&typeof _0x5a38e5<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5a38e5['isLeafNode']())return _0x1ac51c;const _0x56f96d=_0x5a38e5['getValue']();return typeof _0x56f96d!='number'?_0x1ac51c:_0x56f96d+_0x1ac51c;},Zo=function(_0x58992b,_0x190ddd,_0x56ce02,_0x1f5b22){return us(_0x190ddd,new ls(_0x56ce02,_0x58992b),_0x1f5b22);},hs=function(_0x167270,_0x36e370,_0x50ac55){return us(_0x167270,new cs(_0x36e370),_0x50ac55);};function us(_0x52d9e9,_0x245d9a,_0x43de2b){const _0x5bd661=_0x52d9e9['getPriority']()['val'](),_0x522680=fr(_0x5bd661,_0x245d9a['getImmediateChild']('.priority'),_0x43de2b);let _0x344b25;if(_0x52d9e9['isLeafNode']()){const _0x4268b2=_0x52d9e9,_0x1e293f=fr(_0x4268b2['getValue'](),_0x245d9a,_0x43de2b);return _0x1e293f!==_0x4268b2['getValue']()||_0x522680!==_0x4268b2['getPriority']()['val']()?new D(_0x1e293f,N(_0x522680)):_0x52d9e9;}else{const _0x7cdfd2=_0x52d9e9;return _0x344b25=_0x7cdfd2,_0x522680!==_0x7cdfd2['getPriority']()['val']()&&(_0x344b25=_0x344b25['updatePriority'](new D(_0x522680))),_0x7cdfd2['forEachChild'](R,(_0x35d2d0,_0x27ee0e)=>{const _0x218a14=us(_0x27ee0e,_0x245d9a['getImmediateChild'](_0x35d2d0),_0x43de2b);_0x218a14!==_0x27ee0e&&(_0x344b25=_0x344b25['updateImmediateChild'](_0x35d2d0,_0x218a14));}),_0x344b25;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x4c1653='',_0x32ea41=null,_0xc836d6={'children':{},'childCount':0x0}){this['name']=_0x4c1653,this['parent']=_0x32ea41,this['node']=_0xc836d6;}}function Un(_0x4ce00c,_0x54c3b8){let _0x5925ba=_0x54c3b8 instanceof C?_0x54c3b8:new C(_0x54c3b8),_0x556e58=_0x4ce00c,_0x804951=y(_0x5925ba);for(;_0x804951!==null;){const _0x5bc340=Oe(_0x556e58['node']['children'],_0x804951)||{'children':{},'childCount':0x0};_0x556e58=new ds(_0x804951,_0x556e58,_0x5bc340),_0x5925ba=b(_0x5925ba),_0x804951=y(_0x5925ba);}return _0x556e58;}function Ge(_0x52368b){return _0x52368b['node']['value'];}function fs(_0x1e84e3,_0x1b4ce1){_0x1e84e3['node']['value']=_0x1b4ce1,Ri(_0x1e84e3);}function ea(_0x3bee52){return _0x3bee52['node']['childCount']>0x0;}function id(_0x77dbe3){return Ge(_0x77dbe3)===void 0x0&&!ea(_0x77dbe3);}function Wn(_0x2c2f58,_0x1e51f0){x(_0x2c2f58['node']['children'],(_0x43b4c7,_0x358711)=>{_0x1e51f0(new ds(_0x43b4c7,_0x2c2f58,_0x358711));});}function ta(_0x58bb20,_0xb032d3,_0x1431de,_0x304753){_0x1431de&&_0xb032d3(_0x58bb20),Wn(_0x58bb20,_0x14326d=>{ta(_0x14326d,_0xb032d3,!0x0);});}function sd(_0x293d1b,_0x29ec59,_0x227ebe){let _0x5e48da=_0x293d1b['parent'];for(;_0x5e48da!==null;){if(_0x29ec59(_0x5e48da))return!0x0;_0x5e48da=_0x5e48da['parent'];}return!0x1;}function Gt(_0x50c436){return new C(_0x50c436['parent']===null?_0x50c436['name']:Gt(_0x50c436['parent'])+'/'+_0x50c436['name']);}function Ri(_0x565057){_0x565057['parent']!==null&&rd(_0x565057['parent'],_0x565057['name'],_0x565057);}function rd(_0x4e4b53,_0x522e6a,_0x3642df){const _0xfd7761=id(_0x3642df),_0x178449=Y(_0x4e4b53['node']['children'],_0x522e6a);_0xfd7761&&_0x178449?(delete _0x4e4b53['node']['children'][_0x522e6a],_0x4e4b53['node']['childCount']--,Ri(_0x4e4b53)):!_0xfd7761&&!_0x178449&&(_0x4e4b53['node']['children'][_0x522e6a]=_0x3642df['node'],_0x4e4b53['node']['childCount']++,Ri(_0x4e4b53));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x674fd8){return typeof _0x674fd8=='string'&&_0x674fd8['length']!==0x0&&!od['test'](_0x674fd8);},na=function(_0x5ca76b){return typeof _0x5ca76b=='string'&&_0x5ca76b['length']!==0x0&&!ad['test'](_0x5ca76b);},cd=function(_0x50d525){return _0x50d525&&(_0x50d525=_0x50d525['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x50d525);},Cn=function(_0x2e26c5){return _0x2e26c5===null||typeof _0x2e26c5=='string'||typeof _0x2e26c5=='number'&&!Wi(_0x2e26c5)||_0x2e26c5&&typeof _0x2e26c5=='object'&&Y(_0x2e26c5,'.sv');},qt=function(_0x43da44,_0x1472d3,_0x94bf7b,_0x4aea63){_0x4aea63&&_0x1472d3===void 0x0||zt(Nn(_0x43da44,'value'),_0x1472d3,_0x94bf7b);},zt=function(_0x237f2b,_0x5315e9,_0x4723dc){const _0x28708a=_0x4723dc instanceof C?new Sh(_0x4723dc,_0x237f2b):_0x4723dc;if(_0x5315e9===void 0x0)throw new Error(_0x237f2b+'contains\x20undefined\x20'+Ne(_0x28708a));if(typeof _0x5315e9=='function')throw new Error(_0x237f2b+'contains\x20a\x20function\x20'+Ne(_0x28708a)+'\x20with\x20contents\x20=\x20'+_0x5315e9['toString']());if(Wi(_0x5315e9))throw new Error(_0x237f2b+'contains\x20'+_0x5315e9['toString']()+'\x20'+Ne(_0x28708a));if(typeof _0x5315e9=='string'&&_0x5315e9['length']>oi/0x3&&Pn(_0x5315e9)>oi)throw new Error(_0x237f2b+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x28708a)+'\x20(\x27'+_0x5315e9['substring'](0x0,0x32)+'...\x27)');if(_0x5315e9&&typeof _0x5315e9=='object'){let _0xec06c4=!0x1,_0x2d8d66=!0x1;if(x(_0x5315e9,(_0x417884,_0x372a18)=>{if(_0x417884==='.value')_0xec06c4=!0x0;else{if(_0x417884!=='.priority'&&_0x417884!=='.sv'&&(_0x2d8d66=!0x0,!ps(_0x417884)))throw new Error(_0x237f2b+'\x20contains\x20an\x20invalid\x20key\x20('+_0x417884+')\x20'+Ne(_0x28708a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x28708a,_0x417884),zt(_0x237f2b,_0x372a18,_0x28708a),Rh(_0x28708a);}),_0xec06c4&&_0x2d8d66)throw new Error(_0x237f2b+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x28708a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x383645,_0x317324){let _0x25d2ac,_0x266c84;for(_0x25d2ac=0x0;_0x25d2ac<_0x317324['length'];_0x25d2ac++){_0x266c84=_0x317324[_0x25d2ac];const _0x2df07e=kt(_0x266c84);for(let _0x5c6707=0x0;_0x5c6707<_0x2df07e['length'];_0x5c6707++)if(!(_0x2df07e[_0x5c6707]==='.priority'&&_0x5c6707===_0x2df07e['length']-0x1)){if(!ps(_0x2df07e[_0x5c6707]))throw new Error(_0x383645+'contains\x20an\x20invalid\x20key\x20('+_0x2df07e[_0x5c6707]+')\x20in\x20path\x20'+_0x266c84['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x317324['sort'](Th);let _0xa8b4fb=null;for(_0x25d2ac=0x0;_0x25d2ac<_0x317324['length'];_0x25d2ac++){if(_0x266c84=_0x317324[_0x25d2ac],_0xa8b4fb!==null&&$(_0xa8b4fb,_0x266c84))throw new Error(_0x383645+'contains\x20a\x20path\x20'+_0xa8b4fb['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x266c84['toString']());_0xa8b4fb=_0x266c84;}},hd=function(_0x14d3a2,_0x52a268,_0x128630,_0x1eca5d){const _0x47b027=Nn(_0x14d3a2,'values');if(!(_0x52a268&&typeof _0x52a268=='object')||Array['isArray'](_0x52a268))throw new Error(_0x47b027+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x52b315=[];x(_0x52a268,(_0x2be345,_0x379fc9)=>{const _0x2d51be=new C(_0x2be345);if(zt(_0x47b027,_0x379fc9,A(_0x128630,_0x2d51be)),Gi(_0x2d51be)==='.priority'&&!Cn(_0x379fc9))throw new Error(_0x47b027+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2d51be['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x52b315['push'](_0x2d51be);}),ld(_0x47b027,_0x52b315);},_s=function(_0x538021,_0x499aee,_0x53ee90,_0x3eed52){if(!na(_0x53ee90))throw new Error(Nn(_0x538021,_0x499aee)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x53ee90+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x4e236a,_0x157f7b,_0x74c25c,_0x4deb42){_0x74c25c&&(_0x74c25c=_0x74c25c['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x4e236a,_0x157f7b,_0x74c25c);},gs=function(_0x378d6a,_0x3c5313){if(y(_0x3c5313)==='.info')throw new Error(_0x378d6a+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x3a60c8,_0x1077f0){const _0x8789e0=_0x1077f0['path']['toString']();if(typeof _0x1077f0['repoInfo']['host']!='string'||_0x1077f0['repoInfo']['host']['length']===0x0||!ps(_0x1077f0['repoInfo']['namespace'])&&_0x1077f0['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x8789e0['length']!==0x0&&!cd(_0x8789e0))throw new Error(Nn(_0x3a60c8,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x2035be,_0x4c16e9){let _0x90316c=null;for(let _0x140d92=0x0;_0x140d92<_0x4c16e9['length'];_0x140d92++){const _0x57792a=_0x4c16e9[_0x140d92],_0x211baa=_0x57792a['getPath']();_0x90316c!==null&&!qi(_0x211baa,_0x90316c['path'])&&(_0x2035be['eventLists_']['push'](_0x90316c),_0x90316c=null),_0x90316c===null&&(_0x90316c={'events':[],'path':_0x211baa}),_0x90316c['events']['push'](_0x57792a);}_0x90316c&&_0x2035be['eventLists_']['push'](_0x90316c);}function ia(_0x30a74d,_0xa5f4c6,_0x473d86){Bn(_0x30a74d,_0x473d86),sa(_0x30a74d,_0x1e247b=>qi(_0x1e247b,_0xa5f4c6));}function V(_0x58404d,_0x363a41,_0x17cdd1){Bn(_0x58404d,_0x17cdd1),sa(_0x58404d,_0x24b1b6=>$(_0x24b1b6,_0x363a41)||$(_0x363a41,_0x24b1b6));}function sa(_0x205f34,_0x116598){_0x205f34['recursionDepth_']++;let _0x3bdf3d=!0x0;for(let _0xa057ad=0x0;_0xa057ad<_0x205f34['eventLists_']['length'];_0xa057ad++){const _0x273753=_0x205f34['eventLists_'][_0xa057ad];if(_0x273753){const _0x44ce4a=_0x273753['path'];_0x116598(_0x44ce4a)?(pd(_0x205f34['eventLists_'][_0xa057ad]),_0x205f34['eventLists_'][_0xa057ad]=null):_0x3bdf3d=!0x1;}}_0x3bdf3d&&(_0x205f34['eventLists_']=[]),_0x205f34['recursionDepth_']--;}function pd(_0x3e204e){for(let _0x21325b=0x0;_0x21325b<_0x3e204e['events']['length'];_0x21325b++){const _0x4ee130=_0x3e204e['events'][_0x21325b];if(_0x4ee130!==null){_0x3e204e['events'][_0x21325b]=null;const _0x3acd71=_0x4ee130['getEventRunner']();Et&&L('event:\x20'+_0x4ee130['toString']()),lt(_0x3acd71);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x24f734,_0x1cb91f,_0x2c02c1,_0x12e0de){this['repoInfo_']=_0x24f734,this['forceRestClient_']=_0x1cb91f,this['authTokenProvider_']=_0x2c02c1,this['appCheckProvider_']=_0x12e0de,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x20e5ff,_0x4a2283,_0x59403d){if(_0x20e5ff['stats_']=Hi(_0x20e5ff['repoInfo_']),_0x20e5ff['forceRestClient_']||Yl())_0x20e5ff['server_']=new fn(_0x20e5ff['repoInfo_'],(_0x3773dd,_0x5a2294,_0x1c3f27,_0xeb6b11)=>{pr(_0x20e5ff,_0x3773dd,_0x5a2294,_0x1c3f27,_0xeb6b11);},_0x20e5ff['authTokenProvider_'],_0x20e5ff['appCheckProvider_']),setTimeout(()=>_r(_0x20e5ff,!0x0),0x0);else{if(typeof _0x59403d<'u'&&_0x59403d!==null){if(typeof _0x59403d!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x59403d);}catch(_0x19896d){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x19896d);}}_0x20e5ff['persistentConnection_']=new ie(_0x20e5ff['repoInfo_'],_0x4a2283,(_0x22e0e5,_0x5b0555,_0x3437a2,_0x1c609c)=>{pr(_0x20e5ff,_0x22e0e5,_0x5b0555,_0x3437a2,_0x1c609c);},_0xe21caf=>{_r(_0x20e5ff,_0xe21caf);},_0x4bba5d=>{yd(_0x20e5ff,_0x4bba5d);},_0x20e5ff['authTokenProvider_'],_0x20e5ff['appCheckProvider_'],_0x59403d),_0x20e5ff['server_']=_0x20e5ff['persistentConnection_'];}_0x20e5ff['authTokenProvider_']['addTokenChangeListener'](_0x1d4e6f=>{_0x20e5ff['server_']['refreshAuthToken'](_0x1d4e6f);}),_0x20e5ff['appCheckProvider_']['addTokenChangeListener'](_0x521a58=>{_0x20e5ff['server_']['refreshAppCheckToken'](_0x521a58['token']);}),_0x20e5ff['statsReporter_']=eh(_0x20e5ff['repoInfo_'],()=>new eu(_0x20e5ff['stats_'],_0x20e5ff['server_'])),_0x20e5ff['infoData_']=new Yh(),_0x20e5ff['infoSyncTree_']=new dr({'startListening':(_0x1c6fbf,_0x2d8e16,_0x22980d,_0x45332f)=>{let _0x2ca513=[];const _0x56d9c9=_0x20e5ff['infoData_']['getNode'](_0x1c6fbf['_path']);return _0x56d9c9['isEmpty']()||(_0x2ca513=$t(_0x20e5ff['infoSyncTree_'],_0x1c6fbf['_path'],_0x56d9c9),setTimeout(()=>{_0x45332f('ok');},0x0)),_0x2ca513;},'stopListening':()=>{}}),ms(_0x20e5ff,'connected',!0x1),_0x20e5ff['serverSyncTree_']=new dr({'startListening':(_0x33d683,_0x2bfa3a,_0x4730c0,_0x1f4c2e)=>(_0x20e5ff['server_']['listen'](_0x33d683,_0x4730c0,_0x2bfa3a,(_0x46f504,_0x1229f6)=>{const _0x15197a=_0x1f4c2e(_0x46f504,_0x1229f6);V(_0x20e5ff['eventQueue_'],_0x33d683['_path'],_0x15197a);}),[]),'stopListening':(_0x3ad5c8,_0x601aa0)=>{_0x20e5ff['server_']['unlisten'](_0x3ad5c8,_0x601aa0);}});}function oa(_0x19db8f){const _0x57a300=_0x19db8f['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x57a300;}function jt(_0x35e766){return ed({'timestamp':oa(_0x35e766)});}function pr(_0x3a106f,_0x459107,_0x471dfa,_0x2abb64,_0x2a1dff){_0x3a106f['dataUpdateCount']++;const _0x598378=new C(_0x459107);_0x471dfa=_0x3a106f['interceptServerDataCallback_']?_0x3a106f['interceptServerDataCallback_'](_0x459107,_0x471dfa):_0x471dfa;let _0x431478=[];if(_0x2a1dff){if(_0x2abb64){const _0x27fb05=ln(_0x471dfa,_0x304a15=>N(_0x304a15));_0x431478=Ku(_0x3a106f['serverSyncTree_'],_0x598378,_0x27fb05,_0x2a1dff);}else{const _0x46e0f9=N(_0x471dfa);_0x431478=Yo(_0x3a106f['serverSyncTree_'],_0x598378,_0x46e0f9,_0x2a1dff);}}else{if(_0x2abb64){const _0x363f1e=ln(_0x471dfa,_0x5da783=>N(_0x5da783));_0x431478=qu(_0x3a106f['serverSyncTree_'],_0x598378,_0x363f1e);}else{const _0x2097f8=N(_0x471dfa);_0x431478=$t(_0x3a106f['serverSyncTree_'],_0x598378,_0x2097f8);}}let _0x66a23d=_0x598378;_0x431478['length']>0x0&&(_0x66a23d=st(_0x3a106f,_0x598378)),V(_0x3a106f['eventQueue_'],_0x66a23d,_0x431478);}function _r(_0x38e437,_0x4db249){ms(_0x38e437,'connected',_0x4db249),_0x4db249===!0x1&&wd(_0x38e437);}function yd(_0x3a58c4,_0x4e569e){x(_0x4e569e,(_0x837048,_0x1f0fab)=>{ms(_0x3a58c4,_0x837048,_0x1f0fab);});}function ms(_0x59bc9c,_0xe19b0a,_0x51f497){const _0x341df9=new C('/.info/'+_0xe19b0a),_0x4f6119=N(_0x51f497);_0x59bc9c['infoData_']['updateSnapshot'](_0x341df9,_0x4f6119);const _0x35731e=$t(_0x59bc9c['infoSyncTree_'],_0x341df9,_0x4f6119);V(_0x59bc9c['eventQueue_'],_0x341df9,_0x35731e);}function Vn(_0xa388b3){return _0xa388b3['nextWriteId_']++;}function vd(_0x190446,_0x119455,_0x308370){const _0x11ad5f=Yu(_0x190446['serverSyncTree_'],_0x119455);return _0x11ad5f!=null?Promise['resolve'](_0x11ad5f):_0x190446['server_']['get'](_0x119455)['then'](_0x4a7ce7=>{const _0x4df879=N(_0x4a7ce7)['withIndex'](_0x119455['_queryParams']['getIndex']());bi(_0x190446['serverSyncTree_'],_0x119455,_0x308370,!0x0);let _0x5df1f7;if(_0x119455['_queryParams']['loadsAllData']())_0x5df1f7=$t(_0x190446['serverSyncTree_'],_0x119455['_path'],_0x4df879);else{const _0x15c489=Mt(_0x190446['serverSyncTree_'],_0x119455);_0x5df1f7=Yo(_0x190446['serverSyncTree_'],_0x119455['_path'],_0x4df879,_0x15c489);}return V(_0x190446['eventQueue_'],_0x119455['_path'],_0x5df1f7),wn(_0x190446['serverSyncTree_'],_0x119455,_0x308370,null,!0x0),_0x4df879;},_0x43ecb9=>(ut(_0x190446,'get\x20for\x20query\x20'+O(_0x119455)+'\x20failed:\x20'+_0x43ecb9),Promise['reject'](new Error(_0x43ecb9))));}function Ed(_0x121078,_0x23cc68,_0x14e4db,_0x22a445,_0x452a66){ut(_0x121078,'set',{'path':_0x23cc68['toString'](),'value':_0x14e4db,'priority':_0x22a445});const _0x4ead64=jt(_0x121078),_0x3fa72a=N(_0x14e4db,_0x22a445),_0x5a3122=xn(_0x121078['serverSyncTree_'],_0x23cc68),_0x589ddb=hs(_0x3fa72a,_0x5a3122,_0x4ead64),_0x5657ab=Vn(_0x121078),_0x4c0d10=ss(_0x121078['serverSyncTree_'],_0x23cc68,_0x589ddb,_0x5657ab,!0x0);Bn(_0x121078['eventQueue_'],_0x4c0d10),_0x121078['server_']['put'](_0x23cc68['toString'](),_0x3fa72a['val'](!0x0),(_0x5aab43,_0x163190)=>{const _0x4afc38=_0x5aab43==='ok';_0x4afc38||U('set\x20at\x20'+_0x23cc68+'\x20failed:\x20'+_0x5aab43);const _0x496ff4=pe(_0x121078['serverSyncTree_'],_0x5657ab,!_0x4afc38);V(_0x121078['eventQueue_'],_0x23cc68,_0x496ff4),Ai(_0x121078,_0x452a66,_0x5aab43,_0x163190);});const _0xac34c1=vs(_0x121078,_0x23cc68);st(_0x121078,_0xac34c1),V(_0x121078['eventQueue_'],_0xac34c1,[]);}function Id(_0x22dfdc,_0x19779c,_0x5ab466,_0x107ef4){ut(_0x22dfdc,'update',{'path':_0x19779c['toString'](),'value':_0x5ab466});let _0x11e7a1=!0x0;const _0x9ff719=jt(_0x22dfdc),_0x38fced={};if(x(_0x5ab466,(_0x345c77,_0x3564fc)=>{_0x11e7a1=!0x1,_0x38fced[_0x345c77]=Zo(A(_0x19779c,_0x345c77),N(_0x3564fc),_0x22dfdc['serverSyncTree_'],_0x9ff719);}),_0x11e7a1)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x22dfdc,_0x107ef4,'ok',void 0x0);else{const _0x5d1e88=Vn(_0x22dfdc),_0x207bca=Gu(_0x22dfdc['serverSyncTree_'],_0x19779c,_0x38fced,_0x5d1e88);Bn(_0x22dfdc['eventQueue_'],_0x207bca),_0x22dfdc['server_']['merge'](_0x19779c['toString'](),_0x5ab466,(_0x64ccd5,_0xdad2db)=>{const _0x2a7e28=_0x64ccd5==='ok';_0x2a7e28||U('update\x20at\x20'+_0x19779c+'\x20failed:\x20'+_0x64ccd5);const _0x39cf09=pe(_0x22dfdc['serverSyncTree_'],_0x5d1e88,!_0x2a7e28),_0x37afc=_0x39cf09['length']>0x0?st(_0x22dfdc,_0x19779c):_0x19779c;V(_0x22dfdc['eventQueue_'],_0x37afc,_0x39cf09),Ai(_0x22dfdc,_0x107ef4,_0x64ccd5,_0xdad2db);}),x(_0x5ab466,_0x5eca42=>{const _0x3415ec=vs(_0x22dfdc,A(_0x19779c,_0x5eca42));st(_0x22dfdc,_0x3415ec);}),V(_0x22dfdc['eventQueue_'],_0x19779c,[]);}}function wd(_0x448c1e){ut(_0x448c1e,'onDisconnectEvents');const _0x589cf6=jt(_0x448c1e),_0x4345ee=pn();Ei(_0x448c1e['onDisconnect_'],w(),(_0x1aef10,_0x214d24)=>{const _0x385b7c=Zo(_0x1aef10,_0x214d24,_0x448c1e['serverSyncTree_'],_0x589cf6);Mo(_0x4345ee,_0x1aef10,_0x385b7c);});let _0x4fea07=[];Ei(_0x4345ee,w(),(_0xe9f66f,_0xd0e889)=>{_0x4fea07=_0x4fea07['concat']($t(_0x448c1e['serverSyncTree_'],_0xe9f66f,_0xd0e889));const _0x26e170=vs(_0x448c1e,_0xe9f66f);st(_0x448c1e,_0x26e170);}),_0x448c1e['onDisconnect_']=pn(),V(_0x448c1e['eventQueue_'],w(),_0x4fea07);}function Cd(_0x122f94,_0x1c7916,_0x30157c){let _0x1d6324;y(_0x1c7916['_path'])==='.info'?_0x1d6324=bi(_0x122f94['infoSyncTree_'],_0x1c7916,_0x30157c):_0x1d6324=bi(_0x122f94['serverSyncTree_'],_0x1c7916,_0x30157c),ia(_0x122f94['eventQueue_'],_0x1c7916['_path'],_0x1d6324);}function Td(_0x235c20,_0x2cdf6b,_0x5b5d60){let _0x5a6993;y(_0x2cdf6b['_path'])==='.info'?_0x5a6993=wn(_0x235c20['infoSyncTree_'],_0x2cdf6b,_0x5b5d60):_0x5a6993=wn(_0x235c20['serverSyncTree_'],_0x2cdf6b,_0x5b5d60),ia(_0x235c20['eventQueue_'],_0x2cdf6b['_path'],_0x5a6993);}function aa(_0x149a10){_0x149a10['persistentConnection_']&&_0x149a10['persistentConnection_']['interrupt'](ra);}function Sd(_0x1e90a4){_0x1e90a4['persistentConnection_']&&_0x1e90a4['persistentConnection_']['resume'](ra);}function ut(_0x3fe8c1,..._0x53cb73){let _0x50bf21='';_0x3fe8c1['persistentConnection_']&&(_0x50bf21=_0x3fe8c1['persistentConnection_']['id']+':'),L(_0x50bf21,..._0x53cb73);}function Ai(_0x24bddd,_0x474186,_0x11b987,_0x36e2a2){_0x474186&&lt(()=>{if(_0x11b987==='ok')_0x474186(null);else{const _0x4ef3a3=(_0x11b987||'error')['toUpperCase']();let _0x54fe90=_0x4ef3a3;_0x36e2a2&&(_0x54fe90+=':\x20'+_0x36e2a2);const _0x2a8072=new Error(_0x54fe90);_0x2a8072['code']=_0x4ef3a3,_0x474186(_0x2a8072);}});}function bd(_0x1d5cd0,_0x412d10,_0x2ab787,_0x4976f8,_0x49585f,_0x26e10d){ut(_0x1d5cd0,'transaction\x20on\x20'+_0x412d10);const _0x57dad1={'path':_0x412d10,'update':_0x2ab787,'onComplete':_0x4976f8,'status':null,'order':to(),'applyLocally':_0x26e10d,'retryCount':0x0,'unwatcher':_0x49585f,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3da3c8=ys(_0x1d5cd0,_0x412d10,void 0x0);_0x57dad1['currentInputSnapshot']=_0x3da3c8;const _0x218030=_0x57dad1['update'](_0x3da3c8['val']());if(_0x218030===void 0x0)_0x57dad1['unwatcher'](),_0x57dad1['currentOutputSnapshotRaw']=null,_0x57dad1['currentOutputSnapshotResolved']=null,_0x57dad1['onComplete']&&_0x57dad1['onComplete'](null,!0x1,_0x57dad1['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x218030,_0x57dad1['path']),_0x57dad1['status']=0x0;const _0x566278=Un(_0x1d5cd0['transactionQueueTree_'],_0x412d10),_0x5aec42=Ge(_0x566278)||[];_0x5aec42['push'](_0x57dad1),fs(_0x566278,_0x5aec42);let _0x435ff1;typeof _0x218030=='object'&&_0x218030!==null&&Y(_0x218030,'.priority')?(_0x435ff1=Oe(_0x218030,'.priority'),f(Cn(_0x435ff1),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x435ff1=(xn(_0x1d5cd0['serverSyncTree_'],_0x412d10)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x493e34=jt(_0x1d5cd0),_0x3ba6ef=N(_0x218030,_0x435ff1),_0xdeb0b6=hs(_0x3ba6ef,_0x3da3c8,_0x493e34);_0x57dad1['currentOutputSnapshotRaw']=_0x3ba6ef,_0x57dad1['currentOutputSnapshotResolved']=_0xdeb0b6,_0x57dad1['currentWriteId']=Vn(_0x1d5cd0);const _0x28e5dc=ss(_0x1d5cd0['serverSyncTree_'],_0x412d10,_0xdeb0b6,_0x57dad1['currentWriteId'],_0x57dad1['applyLocally']);V(_0x1d5cd0['eventQueue_'],_0x412d10,_0x28e5dc),Hn(_0x1d5cd0,_0x1d5cd0['transactionQueueTree_']);}}function ys(_0x3ad5a9,_0x2545c0,_0x2abaf8){return xn(_0x3ad5a9['serverSyncTree_'],_0x2545c0,_0x2abaf8)||g['EMPTY_NODE'];}function Hn(_0x3d91e5,_0x37bc8c=_0x3d91e5['transactionQueueTree_']){if(_0x37bc8c||$n(_0x3d91e5,_0x37bc8c),Ge(_0x37bc8c)){const _0x11f4ff=la(_0x3d91e5,_0x37bc8c);f(_0x11f4ff['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x11f4ff['every'](_0x418420=>_0x418420['status']===0x0)&&Rd(_0x3d91e5,Gt(_0x37bc8c),_0x11f4ff);}else ea(_0x37bc8c)&&Wn(_0x37bc8c,_0x48aa96=>{Hn(_0x3d91e5,_0x48aa96);});}function Rd(_0x32619c,_0x1294ab,_0x6f7eb2){const _0xd96451=_0x6f7eb2['map'](_0x372a8e=>_0x372a8e['currentWriteId']),_0x1929dd=ys(_0x32619c,_0x1294ab,_0xd96451);let _0x1c9a4b=_0x1929dd;const _0x26d65b=_0x1929dd['hash']();for(let _0x80a709=0x0;_0x80a709<_0x6f7eb2['length'];_0x80a709++){const _0x558eac=_0x6f7eb2[_0x80a709];f(_0x558eac['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x558eac['status']=0x1,_0x558eac['retryCount']++;const _0x1fbd3a=F(_0x1294ab,_0x558eac['path']);_0x1c9a4b=_0x1c9a4b['updateChild'](_0x1fbd3a,_0x558eac['currentOutputSnapshotRaw']);}const _0x5e2112=_0x1c9a4b['val'](!0x0),_0x195fd2=_0x1294ab;_0x32619c['server_']['put'](_0x195fd2['toString'](),_0x5e2112,_0x5d9bd9=>{ut(_0x32619c,'transaction\x20put\x20response',{'path':_0x195fd2['toString'](),'status':_0x5d9bd9});let _0x3271b7=[];if(_0x5d9bd9==='ok'){const _0x47527a=[];for(let _0x277939=0x0;_0x277939<_0x6f7eb2['length'];_0x277939++)_0x6f7eb2[_0x277939]['status']=0x2,_0x3271b7=_0x3271b7['concat'](pe(_0x32619c['serverSyncTree_'],_0x6f7eb2[_0x277939]['currentWriteId'])),_0x6f7eb2[_0x277939]['onComplete']&&_0x47527a['push'](()=>_0x6f7eb2[_0x277939]['onComplete'](null,!0x0,_0x6f7eb2[_0x277939]['currentOutputSnapshotResolved'])),_0x6f7eb2[_0x277939]['unwatcher']();$n(_0x32619c,Un(_0x32619c['transactionQueueTree_'],_0x1294ab)),Hn(_0x32619c,_0x32619c['transactionQueueTree_']),V(_0x32619c['eventQueue_'],_0x1294ab,_0x3271b7);for(let _0x2927ca=0x0;_0x2927ca<_0x47527a['length'];_0x2927ca++)lt(_0x47527a[_0x2927ca]);}else{if(_0x5d9bd9==='datastale'){for(let _0xd3650d=0x0;_0xd3650d<_0x6f7eb2['length'];_0xd3650d++)_0x6f7eb2[_0xd3650d]['status']===0x3?_0x6f7eb2[_0xd3650d]['status']=0x4:_0x6f7eb2[_0xd3650d]['status']=0x0;}else{U('transaction\x20at\x20'+_0x195fd2['toString']()+'\x20failed:\x20'+_0x5d9bd9);for(let _0x41ef9d=0x0;_0x41ef9d<_0x6f7eb2['length'];_0x41ef9d++)_0x6f7eb2[_0x41ef9d]['status']=0x4,_0x6f7eb2[_0x41ef9d]['abortReason']=_0x5d9bd9;}st(_0x32619c,_0x1294ab);}},_0x26d65b);}function st(_0x5c3271,_0x1c3c40){const _0x197609=ca(_0x5c3271,_0x1c3c40),_0x129c2a=Gt(_0x197609),_0x2cad6e=la(_0x5c3271,_0x197609);return Ad(_0x5c3271,_0x2cad6e,_0x129c2a),_0x129c2a;}function Ad(_0x1c1e92,_0x331c97,_0x3418bb){if(_0x331c97['length']===0x0)return;const _0x59896b=[];let _0x43f9e0=[];const _0x372e4c=_0x331c97['filter'](_0xeef806=>_0xeef806['status']===0x0)['map'](_0x43eb7d=>_0x43eb7d['currentWriteId']);for(let _0x40c194=0x0;_0x40c194<_0x331c97['length'];_0x40c194++){const _0x17aa49=_0x331c97[_0x40c194],_0x35bfe6=F(_0x3418bb,_0x17aa49['path']);let _0x2a5f0d=!0x1,_0x2e6810;if(f(_0x35bfe6!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x17aa49['status']===0x4)_0x2a5f0d=!0x0,_0x2e6810=_0x17aa49['abortReason'],_0x43f9e0=_0x43f9e0['concat'](pe(_0x1c1e92['serverSyncTree_'],_0x17aa49['currentWriteId'],!0x0));else{if(_0x17aa49['status']===0x0){if(_0x17aa49['retryCount']>=_d)_0x2a5f0d=!0x0,_0x2e6810='maxretry',_0x43f9e0=_0x43f9e0['concat'](pe(_0x1c1e92['serverSyncTree_'],_0x17aa49['currentWriteId'],!0x0));else{const _0x268f80=ys(_0x1c1e92,_0x17aa49['path'],_0x372e4c);_0x17aa49['currentInputSnapshot']=_0x268f80;const _0x1ca9a9=_0x331c97[_0x40c194]['update'](_0x268f80['val']());if(_0x1ca9a9!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x1ca9a9,_0x17aa49['path']);let _0x17e1fa=N(_0x1ca9a9);typeof _0x1ca9a9=='object'&&_0x1ca9a9!=null&&Y(_0x1ca9a9,'.priority')||(_0x17e1fa=_0x17e1fa['updatePriority'](_0x268f80['getPriority']()));const _0x207d41=_0x17aa49['currentWriteId'],_0x8040bf=jt(_0x1c1e92),_0x11c6be=hs(_0x17e1fa,_0x268f80,_0x8040bf);_0x17aa49['currentOutputSnapshotRaw']=_0x17e1fa,_0x17aa49['currentOutputSnapshotResolved']=_0x11c6be,_0x17aa49['currentWriteId']=Vn(_0x1c1e92),_0x372e4c['splice'](_0x372e4c['indexOf'](_0x207d41),0x1),_0x43f9e0=_0x43f9e0['concat'](ss(_0x1c1e92['serverSyncTree_'],_0x17aa49['path'],_0x11c6be,_0x17aa49['currentWriteId'],_0x17aa49['applyLocally'])),_0x43f9e0=_0x43f9e0['concat'](pe(_0x1c1e92['serverSyncTree_'],_0x207d41,!0x0));}else _0x2a5f0d=!0x0,_0x2e6810='nodata',_0x43f9e0=_0x43f9e0['concat'](pe(_0x1c1e92['serverSyncTree_'],_0x17aa49['currentWriteId'],!0x0));}}}V(_0x1c1e92['eventQueue_'],_0x3418bb,_0x43f9e0),_0x43f9e0=[],_0x2a5f0d&&(_0x331c97[_0x40c194]['status']=0x2,function(_0x29fe8d){setTimeout(_0x29fe8d,Math['floor'](0x0));}(_0x331c97[_0x40c194]['unwatcher']),_0x331c97[_0x40c194]['onComplete']&&(_0x2e6810==='nodata'?_0x59896b['push'](()=>_0x331c97[_0x40c194]['onComplete'](null,!0x1,_0x331c97[_0x40c194]['currentInputSnapshot'])):_0x59896b['push'](()=>_0x331c97[_0x40c194]['onComplete'](new Error(_0x2e6810),!0x1,null))));}$n(_0x1c1e92,_0x1c1e92['transactionQueueTree_']);for(let _0x1713e9=0x0;_0x1713e9<_0x59896b['length'];_0x1713e9++)lt(_0x59896b[_0x1713e9]);Hn(_0x1c1e92,_0x1c1e92['transactionQueueTree_']);}function ca(_0x6d4699,_0x40c0d7){let _0x2e0b9d,_0x564359=_0x6d4699['transactionQueueTree_'];for(_0x2e0b9d=y(_0x40c0d7);_0x2e0b9d!==null&&Ge(_0x564359)===void 0x0;)_0x564359=Un(_0x564359,_0x2e0b9d),_0x40c0d7=b(_0x40c0d7),_0x2e0b9d=y(_0x40c0d7);return _0x564359;}function la(_0x483cda,_0x530795){const _0x2e4156=[];return ha(_0x483cda,_0x530795,_0x2e4156),_0x2e4156['sort']((_0x9b0a25,_0x35eb6c)=>_0x9b0a25['order']-_0x35eb6c['order']),_0x2e4156;}function ha(_0x27bf09,_0x2be724,_0xaa85de){const _0x1cce35=Ge(_0x2be724);if(_0x1cce35){for(let _0x38bf59=0x0;_0x38bf59<_0x1cce35['length'];_0x38bf59++)_0xaa85de['push'](_0x1cce35[_0x38bf59]);}Wn(_0x2be724,_0x30c6eb=>{ha(_0x27bf09,_0x30c6eb,_0xaa85de);});}function $n(_0x401911,_0x5b5b5c){const _0x4f40ba=Ge(_0x5b5b5c);if(_0x4f40ba){let _0x34fd7f=0x0;for(let _0x2b1c33=0x0;_0x2b1c33<_0x4f40ba['length'];_0x2b1c33++)_0x4f40ba[_0x2b1c33]['status']!==0x2&&(_0x4f40ba[_0x34fd7f]=_0x4f40ba[_0x2b1c33],_0x34fd7f++);_0x4f40ba['length']=_0x34fd7f,fs(_0x5b5b5c,_0x4f40ba['length']>0x0?_0x4f40ba:void 0x0);}Wn(_0x5b5b5c,_0x555ad6=>{$n(_0x401911,_0x555ad6);});}function vs(_0x163332,_0x9e73ed){const _0x299b21=Gt(ca(_0x163332,_0x9e73ed)),_0x68ba54=Un(_0x163332['transactionQueueTree_'],_0x9e73ed);return sd(_0x68ba54,_0x1dbfa2=>{ai(_0x163332,_0x1dbfa2);}),ai(_0x163332,_0x68ba54),ta(_0x68ba54,_0x10bacf=>{ai(_0x163332,_0x10bacf);}),_0x299b21;}function ai(_0x20f15a,_0x4c4ada){const _0x4dcb34=Ge(_0x4c4ada);if(_0x4dcb34){const _0x5b31d0=[];let _0x4c3495=[],_0x4ca3f0=-0x1;for(let _0x52df8d=0x0;_0x52df8d<_0x4dcb34['length'];_0x52df8d++)_0x4dcb34[_0x52df8d]['status']===0x3||(_0x4dcb34[_0x52df8d]['status']===0x1?(f(_0x4ca3f0===_0x52df8d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4ca3f0=_0x52df8d,_0x4dcb34[_0x52df8d]['status']=0x3,_0x4dcb34[_0x52df8d]['abortReason']='set'):(f(_0x4dcb34[_0x52df8d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4dcb34[_0x52df8d]['unwatcher'](),_0x4c3495=_0x4c3495['concat'](pe(_0x20f15a['serverSyncTree_'],_0x4dcb34[_0x52df8d]['currentWriteId'],!0x0)),_0x4dcb34[_0x52df8d]['onComplete']&&_0x5b31d0['push'](_0x4dcb34[_0x52df8d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4ca3f0===-0x1?fs(_0x4c4ada,void 0x0):_0x4dcb34['length']=_0x4ca3f0+0x1,V(_0x20f15a['eventQueue_'],Gt(_0x4c4ada),_0x4c3495);for(let _0x4afb73=0x0;_0x4afb73<_0x5b31d0['length'];_0x4afb73++)lt(_0x5b31d0[_0x4afb73]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x4ff60c){let _0x3a9dee='';const _0x46a3b7=_0x4ff60c['split']('/');for(let _0x3648c0=0x0;_0x3648c0<_0x46a3b7['length'];_0x3648c0++)if(_0x46a3b7[_0x3648c0]['length']>0x0){let _0x18b654=_0x46a3b7[_0x3648c0];try{_0x18b654=decodeURIComponent(_0x18b654['replace'](/\+/g,'\x20'));}catch{}_0x3a9dee+='/'+_0x18b654;}return _0x3a9dee;}function Nd(_0xd94a39){const _0x2c3ada={};_0xd94a39['charAt'](0x0)==='?'&&(_0xd94a39=_0xd94a39['substring'](0x1));for(const _0x489d54 of _0xd94a39['split']('&')){if(_0x489d54['length']===0x0)continue;const _0x15c816=_0x489d54['split']('=');_0x15c816['length']===0x2?_0x2c3ada[decodeURIComponent(_0x15c816[0x0])]=decodeURIComponent(_0x15c816[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x489d54+'\x27\x20in\x20query\x20\x27'+_0xd94a39+'\x27');}return _0x2c3ada;}const gr=function(_0x39745c,_0x138c7d){const _0x4ab04a=Pd(_0x39745c),_0x472035=_0x4ab04a['namespace'];_0x4ab04a['domain']==='firebase.com'&&oe(_0x4ab04a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x472035||_0x472035==='undefined')&&_0x4ab04a['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4ab04a['secure']||Bl();const _0x332d08=_0x4ab04a['scheme']==='ws'||_0x4ab04a['scheme']==='wss';return{'repoInfo':new _o(_0x4ab04a['host'],_0x4ab04a['secure'],_0x472035,_0x332d08,_0x138c7d,'',_0x472035!==_0x4ab04a['subdomain']),'path':new C(_0x4ab04a['pathString'])};},Pd=function(_0x3bf282){let _0x381ef6='',_0x3edeb8='',_0x3b62d8='',_0x4be57e='',_0x543cea='',_0x3d5ba1=!0x0,_0x598b76='https',_0xbed6bb=0x1bb;if(typeof _0x3bf282=='string'){let _0xde4f26=_0x3bf282['indexOf']('//');_0xde4f26>=0x0&&(_0x598b76=_0x3bf282['substring'](0x0,_0xde4f26-0x1),_0x3bf282=_0x3bf282['substring'](_0xde4f26+0x2));let _0x5227d5=_0x3bf282['indexOf']('/');_0x5227d5===-0x1&&(_0x5227d5=_0x3bf282['length']);let _0xaeb8e9=_0x3bf282['indexOf']('?');_0xaeb8e9===-0x1&&(_0xaeb8e9=_0x3bf282['length']),_0x381ef6=_0x3bf282['substring'](0x0,Math['min'](_0x5227d5,_0xaeb8e9)),_0x5227d5<_0xaeb8e9&&(_0x4be57e=kd(_0x3bf282['substring'](_0x5227d5,_0xaeb8e9)));const _0x133ff8=Nd(_0x3bf282['substring'](Math['min'](_0x3bf282['length'],_0xaeb8e9)));_0xde4f26=_0x381ef6['indexOf'](':'),_0xde4f26>=0x0?(_0x3d5ba1=_0x598b76==='https'||_0x598b76==='wss',_0xbed6bb=parseInt(_0x381ef6['substring'](_0xde4f26+0x1),0xa)):_0xde4f26=_0x381ef6['length'];const _0x34c462=_0x381ef6['slice'](0x0,_0xde4f26);if(_0x34c462['toLowerCase']()==='localhost')_0x3edeb8='localhost';else{if(_0x34c462['split']('.')['length']<=0x2)_0x3edeb8=_0x34c462;else{const _0x5e6bc0=_0x381ef6['indexOf']('.');_0x3b62d8=_0x381ef6['substring'](0x0,_0x5e6bc0)['toLowerCase'](),_0x3edeb8=_0x381ef6['substring'](_0x5e6bc0+0x1),_0x543cea=_0x3b62d8;}}'ns'in _0x133ff8&&(_0x543cea=_0x133ff8['ns']);}return{'host':_0x381ef6,'port':_0xbed6bb,'domain':_0x3edeb8,'subdomain':_0x3b62d8,'secure':_0x3d5ba1,'scheme':_0x598b76,'pathString':_0x4be57e,'namespace':_0x543cea};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x47f4d5=0x0;const _0xe96944=[];return function(_0x54e861){const _0x2e8874=_0x54e861===_0x47f4d5;_0x47f4d5=_0x54e861;let _0x18d40e;const _0xf1e5e=new Array(0x8);for(_0x18d40e=0x7;_0x18d40e>=0x0;_0x18d40e--)_0xf1e5e[_0x18d40e]=mr['charAt'](_0x54e861%0x40),_0x54e861=Math['floor'](_0x54e861/0x40);f(_0x54e861===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x715645=_0xf1e5e['join']('');if(_0x2e8874){for(_0x18d40e=0xb;_0x18d40e>=0x0&&_0xe96944[_0x18d40e]===0x3f;_0x18d40e--)_0xe96944[_0x18d40e]=0x0;_0xe96944[_0x18d40e]++;}else{for(_0x18d40e=0x0;_0x18d40e<0xc;_0x18d40e++)_0xe96944[_0x18d40e]=Math['floor'](Math['random']()*0x40);}for(_0x18d40e=0x0;_0x18d40e<0xc;_0x18d40e++)_0x715645+=mr['charAt'](_0xe96944[_0x18d40e]);return f(_0x715645['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x715645;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x5ed5b3,_0x4ce982,_0x33fa55,_0x260503){this['eventType']=_0x5ed5b3,this['eventRegistration']=_0x4ce982,this['snapshot']=_0x33fa55,this['prevName']=_0x260503;}['getPath'](){const _0x36f04d=this['snapshot']['ref'];return this['eventType']==='value'?_0x36f04d['_path']:_0x36f04d['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x11a51f,_0x25543b,_0x77d924){this['eventRegistration']=_0x11a51f,this['error']=_0x25543b,this['path']=_0x77d924;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x6b0de7,_0x14d25d){this['snapshotCallback']=_0x6b0de7,this['cancelCallback']=_0x14d25d;}['onValue'](_0xc64128,_0x2938b3){this['snapshotCallback']['call'](null,_0xc64128,_0x2938b3);}['onCancel'](_0x34aba9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x34aba9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1188cc){return this['snapshotCallback']===_0x1188cc['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1188cc['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1188cc['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4b67e4,_0x16abbc,_0x18af57,_0x4e80c5){this['_repo']=_0x4b67e4,this['_path']=_0x16abbc,this['_queryParams']=_0x18af57,this['_orderByCalled']=_0x4e80c5;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3760d3=nr(this['_queryParams']),_0x5c535f=Bi(_0x3760d3);return _0x5c535f==='{}'?'default':_0x5c535f;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x47d2c9){if(_0x47d2c9=k(_0x47d2c9),!(_0x47d2c9 instanceof be))return!0x1;const _0xd5265b=this['_repo']===_0x47d2c9['_repo'],_0x4773e8=qi(this['_path'],_0x47d2c9['_path']),_0x51be99=this['_queryIdentifier']===_0x47d2c9['_queryIdentifier'];return _0xd5265b&&_0x4773e8&&_0x51be99;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x406f87,_0x3d1070){if(_0x406f87['_orderByCalled']===!0x0)throw new Error(_0x3d1070+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x2b01f7){let _0x4052df=null,_0xe2f8c9=null;if(_0x2b01f7['hasStart']()&&(_0x4052df=_0x2b01f7['getIndexStartValue']()),_0x2b01f7['hasEnd']()&&(_0xe2f8c9=_0x2b01f7['getIndexEndValue']()),_0x2b01f7['getIndex']()===ye){const _0x4562f6='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1bd2a4='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2b01f7['hasStart']()){if(_0x2b01f7['getIndexStartName']()!==xe)throw new Error(_0x4562f6);if(typeof _0x4052df!='string')throw new Error(_0x1bd2a4);}if(_0x2b01f7['hasEnd']()){if(_0x2b01f7['getIndexEndName']()!==Ie)throw new Error(_0x4562f6);if(typeof _0xe2f8c9!='string')throw new Error(_0x1bd2a4);}}else{if(_0x2b01f7['getIndex']()===R){if(_0x4052df!=null&&!Cn(_0x4052df)||_0xe2f8c9!=null&&!Cn(_0xe2f8c9))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2b01f7['getIndex']()instanceof Ki||_0x2b01f7['getIndex']()===Po,'unknown\x20index\x20type.'),_0x4052df!=null&&typeof _0x4052df=='object'||_0xe2f8c9!=null&&typeof _0xe2f8c9=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x56bdd2){if(_0x56bdd2['hasStart']()&&_0x56bdd2['hasEnd']()&&_0x56bdd2['hasLimit']()&&!_0x56bdd2['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x233c92,_0x482555){super(_0x233c92,_0x482555,new Qi(),!0x1);}get['parent'](){const _0x299479=To(this['_path']);return _0x299479===null?null:new Z(this['_repo'],_0x299479);}get['root'](){let _0x2cd002=this;for(;_0x2cd002['parent']!==null;)_0x2cd002=_0x2cd002['parent'];return _0x2cd002;}}class rt{constructor(_0x5476c5,_0xffccce,_0x583194){this['_node']=_0x5476c5,this['ref']=_0xffccce,this['_index']=_0x583194;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x53fd0a){const _0x2b8a56=new C(_0x53fd0a),_0x43cfde=Lt(this['ref'],_0x53fd0a);return new rt(this['_node']['getChild'](_0x2b8a56),_0x43cfde,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x197b57){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x382583,_0x235b0a)=>_0x197b57(new rt(_0x235b0a,Lt(this['ref'],_0x382583),R)));}['hasChild'](_0x9fcbfd){const _0xd1580c=new C(_0x9fcbfd);return!this['_node']['getChild'](_0xd1580c)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x3c1d1d,_0x36b31f){return _0x3c1d1d=k(_0x3c1d1d),_0x3c1d1d['_checkNotDeleted']('ref'),_0x36b31f!==void 0x0?Lt(_0x3c1d1d['_root'],_0x36b31f):_0x3c1d1d['_root'];}function Lt(_0x3c22f6,_0x3ba38e){return _0x3c22f6=k(_0x3c22f6),y(_0x3c22f6['_path'])===null?ud('child','path',_0x3ba38e):_s('child','path',_0x3ba38e),new Z(_0x3c22f6['_repo'],A(_0x3c22f6['_path'],_0x3ba38e));}function d_(_0x35aca4,_0x1a0db3){_0x35aca4=k(_0x35aca4),gs('push',_0x35aca4['_path']),qt('push',_0x1a0db3,_0x35aca4['_path'],!0x0);const _0x3178f3=oa(_0x35aca4['_repo']),_0x11bbf3=Od(_0x3178f3),_0x8a3169=Lt(_0x35aca4,_0x11bbf3),_0x12270f=Lt(_0x35aca4,_0x11bbf3);let _0x2f92ff;return _0x1a0db3!=null?_0x2f92ff=Ld(_0x12270f,_0x1a0db3)['then'](()=>_0x12270f):_0x2f92ff=Promise['resolve'](_0x12270f),_0x8a3169['then']=_0x2f92ff['then']['bind'](_0x2f92ff),_0x8a3169['catch']=_0x2f92ff['then']['bind'](_0x2f92ff,void 0x0),_0x8a3169;}function Ld(_0x59ab85,_0x4c9df5){_0x59ab85=k(_0x59ab85),gs('set',_0x59ab85['_path']),qt('set',_0x4c9df5,_0x59ab85['_path'],!0x1);const _0x22ab69=new Ve();return Ed(_0x59ab85['_repo'],_0x59ab85['_path'],_0x4c9df5,null,_0x22ab69['wrapCallback'](()=>{})),_0x22ab69['promise'];}function f_(_0x5e20df,_0xc665aa){hd('update',_0xc665aa,_0x5e20df['_path']);const _0x37ff67=new Ve();return Id(_0x5e20df['_repo'],_0x5e20df['_path'],_0xc665aa,_0x37ff67['wrapCallback'](()=>{})),_0x37ff67['promise'];}function p_(_0x284157){_0x284157=k(_0x284157);const _0x5ea51e=new ua(()=>{}),_0x5b05db=new qn(_0x5ea51e);return vd(_0x284157['_repo'],_0x284157,_0x5b05db)['then'](_0x50e43c=>new rt(_0x50e43c,new Z(_0x284157['_repo'],_0x284157['_path']),_0x284157['_queryParams']['getIndex']()));}class qn{constructor(_0x3302af){this['callbackContext']=_0x3302af;}['respondsTo'](_0x5dc92a){return _0x5dc92a==='value';}['createEvent'](_0x358c3f,_0x120559){const _0x47c245=_0x120559['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x358c3f['snapshotNode'],new Z(_0x120559['_repo'],_0x120559['_path']),_0x47c245));}['getEventRunner'](_0x3430a3){return _0x3430a3['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3430a3['error']):()=>this['callbackContext']['onValue'](_0x3430a3['snapshot'],null);}['createCancelEvent'](_0x51ae69,_0x1a6274){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x51ae69,_0x1a6274):null;}['matches'](_0x3b65d2){return _0x3b65d2 instanceof qn?!_0x3b65d2['callbackContext']||!this['callbackContext']?!0x0:_0x3b65d2['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4c772b,_0x23592e,_0x45af97,_0xfbcbad,_0x2bce27){const _0x16aff1=new ua(_0x45af97,void 0x0),_0xd4ab83=new qn(_0x16aff1);return Cd(_0x4c772b['_repo'],_0x4c772b,_0xd4ab83),()=>Td(_0x4c772b['_repo'],_0x4c772b,_0xd4ab83);}function Fd(_0x2286d5,_0x529de7,_0x33ed39,_0x5c8b77){return xd(_0x2286d5,'value',_0x529de7);}class dt{}class pa extends dt{constructor(_0xb91abc,_0x9ddc6c){super(),this['_value']=_0xb91abc,this['_key']=_0x9ddc6c,this['type']='endAt';}['_apply'](_0x332a69){qt('endAt',this['_value'],_0x332a69['_path'],!0x0);const _0x40b94c=Kh(_0x332a69['_queryParams'],this['_value'],this['_key']);if(fa(_0x40b94c),Gn(_0x40b94c),_0x332a69['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x332a69['_repo'],_0x332a69['_path'],_0x40b94c,_0x332a69['_orderByCalled']);}}function __(_0x6df04e,_0x3731c0){return new pa(_0x6df04e,_0x3731c0);}class _a extends dt{constructor(_0x332240,_0x163d26){super(),this['_value']=_0x332240,this['_key']=_0x163d26,this['type']='startAt';}['_apply'](_0x32eb0a){qt('startAt',this['_value'],_0x32eb0a['_path'],!0x0);const _0x2407bb=jh(_0x32eb0a['_queryParams'],this['_value'],this['_key']);if(fa(_0x2407bb),Gn(_0x2407bb),_0x32eb0a['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x32eb0a['_repo'],_0x32eb0a['_path'],_0x2407bb,_0x32eb0a['_orderByCalled']);}}function g_(_0x22e8e8=null,_0x5a7ced){return new _a(_0x22e8e8,_0x5a7ced);}class Ud extends dt{constructor(_0xb9d717){super(),this['_limit']=_0xb9d717,this['type']='limitToFirst';}['_apply'](_0x49812a){if(_0x49812a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x49812a['_repo'],_0x49812a['_path'],zh(_0x49812a['_queryParams'],this['_limit']),_0x49812a['_orderByCalled']);}}function m_(_0x23ebbc){if(Math['floor'](_0x23ebbc)!==_0x23ebbc||_0x23ebbc<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x23ebbc);}class Wd extends dt{constructor(_0x8693a6){super(),this['_path']=_0x8693a6,this['type']='orderByChild';}['_apply'](_0x282227){da(_0x282227,'orderByChild');const _0x568227=new C(this['_path']);if(v(_0x568227))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4d1654=new Ki(_0x568227),_0x661c6f=Do(_0x282227['_queryParams'],_0x4d1654);return Gn(_0x661c6f),new be(_0x282227['_repo'],_0x282227['_path'],_0x661c6f,!0x0);}}function y_(_0x2281a7){if(_0x2281a7==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2281a7==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2281a7==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x2281a7),new Wd(_0x2281a7);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2c398c){da(_0x2c398c,'orderByKey');const _0x11d2fe=Do(_0x2c398c['_queryParams'],ye);return Gn(_0x11d2fe),new be(_0x2c398c['_repo'],_0x2c398c['_path'],_0x11d2fe,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x9534ef,_0x44be29){super(),this['_value']=_0x9534ef,this['_key']=_0x44be29,this['type']='equalTo';}['_apply'](_0x6cb32){if(qt('equalTo',this['_value'],_0x6cb32['_path'],!0x1),_0x6cb32['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x6cb32['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x6cb32));}}function E_(_0x556fb6,_0x4911f5){return new Vd(_0x556fb6,_0x4911f5);}function I_(_0x27ff75,..._0x53c7b8){let _0x3b128d=k(_0x27ff75);for(const _0x1be512 of _0x53c7b8)_0x3b128d=_0x1be512['_apply'](_0x3b128d);return _0x3b128d;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x438fd3,_0x259928,_0x9661fa,_0x1b60be){const _0x406a78=_0x259928['lastIndexOf'](':'),_0xc8d3af=_0x259928['substring'](0x0,_0x406a78),_0x17f477=Wt(_0xc8d3af);_0x438fd3['repoInfo_']=new _o(_0x259928,_0x17f477,_0x438fd3['repoInfo_']['namespace'],_0x438fd3['repoInfo_']['webSocketOnly'],_0x438fd3['repoInfo_']['nodeAdmin'],_0x438fd3['repoInfo_']['persistenceKey'],_0x438fd3['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x9661fa),_0x1b60be&&(_0x438fd3['authTokenProvider_']=_0x1b60be);}function qd(_0x392dcf,_0x263c5b,_0x5ca5be,_0x24ac05,_0x1b3e91){let _0x44cfc4=_0x24ac05||_0x392dcf['options']['databaseURL'];_0x44cfc4===void 0x0&&(_0x392dcf['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x392dcf['options']['projectId']),_0x44cfc4=_0x392dcf['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x43d093=gr(_0x44cfc4,_0x1b3e91),_0x42bc17=_0x43d093['repoInfo'],_0x545bdb;typeof process<'u'&&Us&&(_0x545bdb=Us[Hd]),_0x545bdb?(_0x44cfc4='http://'+_0x545bdb+'?ns='+_0x42bc17['namespace'],_0x43d093=gr(_0x44cfc4,_0x1b3e91),_0x42bc17=_0x43d093['repoInfo']):_0x43d093['repoInfo']['secure'];const _0x2ccf7c=new Jl(_0x392dcf['name'],_0x392dcf['options'],_0x263c5b);dd('Invalid\x20Firebase\x20Database\x20URL',_0x43d093),v(_0x43d093['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xaf5afe=jd(_0x42bc17,_0x392dcf,_0x2ccf7c,new Ql(_0x392dcf,_0x5ca5be));return new Kd(_0xaf5afe,_0x392dcf);}function zd(_0x5d6cbe,_0x48fcf7){const _0x20e947=ki[_0x48fcf7];(!_0x20e947||_0x20e947[_0x5d6cbe['key']]!==_0x5d6cbe)&&oe('Database\x20'+_0x48fcf7+'('+_0x5d6cbe['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5d6cbe),delete _0x20e947[_0x5d6cbe['key']];}function jd(_0x1b1956,_0x1f1c7a,_0x2114a3,_0x1b1780){let _0x5d1f08=ki[_0x1f1c7a['name']];_0x5d1f08||(_0x5d1f08={},ki[_0x1f1c7a['name']]=_0x5d1f08);let _0x1b62ab=_0x5d1f08[_0x1b1956['toURLString']()];return _0x1b62ab&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1b62ab=new gd(_0x1b1956,$d,_0x2114a3,_0x1b1780),_0x5d1f08[_0x1b1956['toURLString']()]=_0x1b62ab,_0x1b62ab;}class Kd{constructor(_0x10c6fc,_0x506b40){this['_repoInternal']=_0x10c6fc,this['app']=_0x506b40,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5da88d){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5da88d+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x3189cf=Qr(),_0x586ca2){const _0x5ce557=Ui(_0x3189cf,'database')['getImmediate']({'identifier':_0x586ca2});if(!_0x5ce557['_instanceStarted']){const _0xfbe1cb=ac('database');_0xfbe1cb&&Yd(_0x5ce557,..._0xfbe1cb);}return _0x5ce557;}function Yd(_0xab805,_0x59a263,_0x3b82a8,_0x41b633={}){_0xab805=k(_0xab805),_0xab805['_checkNotDeleted']('useEmulator');const _0x11c85b=_0x59a263+':'+_0x3b82a8,_0x321c23=_0xab805['_repoInternal'];if(_0xab805['_instanceStarted']){if(_0x11c85b===_0xab805['_repoInternal']['repoInfo_']['host']&&De(_0x41b633,_0x321c23['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x212912;if(_0x321c23['repoInfo_']['nodeAdmin'])_0x41b633['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x212912=new tn(tn['OWNER']);else{if(_0x41b633['mockUserToken']){const _0x36b90e=typeof _0x41b633['mockUserToken']=='string'?_0x41b633['mockUserToken']:cc(_0x41b633['mockUserToken'],_0xab805['app']['options']['projectId']);_0x212912=new tn(_0x36b90e);}}Wt(_0x59a263)&&jr(_0x59a263),Gd(_0x321c23,_0x11c85b,_0x41b633,_0x212912);}function C_(_0x581d07){_0x581d07=k(_0x581d07),_0x581d07['_checkNotDeleted']('goOffline'),aa(_0x581d07['_repo']);}function T_(_0x1b5afc){_0x1b5afc=k(_0x1b5afc),_0x1b5afc['_checkNotDeleted']('goOnline'),Sd(_0x1b5afc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x1caa48){Ll(ct),et(new Me('database',(_0x1e7f0f,{instanceIdentifier:_0x4a5955})=>{const _0x35b998=_0x1e7f0f['getProvider']('app')['getImmediate'](),_0x46e44d=_0x1e7f0f['getProvider']('auth-internal'),_0x27a451=_0x1e7f0f['getProvider']('app-check-internal');return qd(_0x35b998,_0x46e44d,_0x27a451,_0x4a5955);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x1caa48),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x43f3fa,_0x32faab){this['committed']=_0x43f3fa,this['snapshot']=_0x32faab;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x4dbb4d,_0x57ce5a,_0x174f1c){if(_0x4dbb4d=k(_0x4dbb4d),gs('Reference.transaction',_0x4dbb4d['_path']),_0x4dbb4d['key']==='.length'||_0x4dbb4d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4dbb4d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x342578=!0x0,_0x3b406b=new Ve(),_0x2d5fbd=(_0x1a9988,_0x4a7ea4,_0x5107b8)=>{let _0x4aa565=null;_0x1a9988?_0x3b406b['reject'](_0x1a9988):(_0x4aa565=new rt(_0x5107b8,new Z(_0x4dbb4d['_repo'],_0x4dbb4d['_path']),R),_0x3b406b['resolve'](new Xd(_0x4a7ea4,_0x4aa565)));},_0x49568f=Fd(_0x4dbb4d,()=>{});return bd(_0x4dbb4d['_repo'],_0x4dbb4d['_path'],_0x57ce5a,_0x2d5fbd,_0x49568f,_0x342578),_0x3b406b['promise'];}ie['prototype']['simpleListen']=function(_0x532d5f,_0x4994eb){this['sendRequest']('q',{'p':_0x532d5f},_0x4994eb);},ie['prototype']['echo']=function(_0x39e386,_0x7d648a){this['sendRequest']('echo',{'d':_0x39e386},_0x7d648a);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x495f49,..._0x5ab527){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x495f49,..._0x5ab527);}function nn(_0x3bbdea,..._0x34c84b){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x3bbdea,..._0x34c84b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x68b2fb,..._0x910d8e){throw Es(_0x68b2fb,..._0x910d8e);}function J(_0x4f3829,..._0x43adbd){return Es(_0x4f3829,..._0x43adbd);}function ya(_0x211ea0,_0x2ce547,_0x5a02f2){const _0x24b374={...Zd(),[_0x2ce547]:_0x5a02f2};return new Ut('auth','Firebase',_0x24b374)['create'](_0x2ce547,{'appName':_0x211ea0['name']});}function se(_0x5309d8){return ya(_0x5309d8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x32d0cb,..._0x36ce6c){if(typeof _0x32d0cb!='string'){const _0x3702b3=_0x36ce6c[0x0],_0x10b3dc=[..._0x36ce6c['slice'](0x1)];return _0x10b3dc[0x0]&&(_0x10b3dc[0x0]['appName']=_0x32d0cb['name']),_0x32d0cb['_errorFactory']['create'](_0x3702b3,..._0x10b3dc);}return ma['create'](_0x32d0cb,..._0x36ce6c);}function m(_0x54cf7c,_0x1d7d8a,..._0xc32b19){if(!_0x54cf7c)throw Es(_0x1d7d8a,..._0xc32b19);}function te(_0x1fbd93){const _0x259b86='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1fbd93;throw nn(_0x259b86),new Error(_0x259b86);}function ae(_0x4a2912,_0x22c934){_0x4a2912||te(_0x22c934);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x2fe3ed;return typeof self<'u'&&((_0x2fe3ed=self['location'])==null?void 0x0:_0x2fe3ed['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x15dac4;return typeof self<'u'&&((_0x15dac4=self['location'])==null?void 0x0:_0x15dac4['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x4deace=navigator;return _0x4deace['languages']&&_0x4deace['languages'][0x0]||_0x4deace['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x477b5a,_0x4d6338){this['shortDelay']=_0x477b5a,this['longDelay']=_0x4d6338,ae(_0x4d6338>_0x477b5a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x5b5294,_0x5a8e45){ae(_0x5b5294['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x364c76}=_0x5b5294['emulator'];return _0x5a8e45?''+_0x364c76+(_0x5a8e45['startsWith']('/')?_0x5a8e45['slice'](0x1):_0x5a8e45):_0x364c76;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5763ba,_0x1f0b16,_0x32fae0){this['fetchImpl']=_0x5763ba,_0x1f0b16&&(this['headersImpl']=_0x1f0b16),_0x32fae0&&(this['responseImpl']=_0x32fae0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x50d5d7,_0x25d159){return _0x50d5d7['tenantId']&&!_0x25d159['tenantId']?{..._0x25d159,'tenantId':_0x50d5d7['tenantId']}:_0x25d159;}async function Ae(_0x2d3240,_0x378328,_0x1b047f,_0x201e09,_0x540284={}){return Ea(_0x2d3240,_0x540284,async()=>{let _0x58e7f7={},_0x436f8d={};_0x201e09&&(_0x378328==='GET'?_0x436f8d=_0x201e09:_0x58e7f7={'body':JSON['stringify'](_0x201e09)});const _0x179e73=at({..._0x436f8d,'key':_0x2d3240['config']['apiKey']})['slice'](0x1),_0x23fd0c=await _0x2d3240['_getAdditionalHeaders']();_0x23fd0c['Content-Type']='application/json',_0x2d3240['languageCode']&&(_0x23fd0c['X-Firebase-Locale']=_0x2d3240['languageCode']);const _0x4ba7b6={'method':_0x378328,'headers':_0x23fd0c,..._0x58e7f7};return lc()||(_0x4ba7b6['referrerPolicy']='strict-origin-when-cross-origin'),_0x2d3240['emulatorConfig']&&Wt(_0x2d3240['emulatorConfig']['host'])&&(_0x4ba7b6['credentials']='include'),va['fetch']()(await Ia(_0x2d3240,_0x2d3240['config']['apiHost'],_0x1b047f,_0x179e73),_0x4ba7b6);});}async function Ea(_0x5118e6,_0x4fc6a6,_0xb51363){_0x5118e6['_canInitEmulator']=!0x1;const _0x60d4c3={...rf,..._0x4fc6a6};try{const _0x9a1c6d=new lf(_0x5118e6),_0x3da91e=await Promise['race']([_0xb51363(),_0x9a1c6d['promise']]);_0x9a1c6d['clearNetworkTimeout']();const _0x335b48=await _0x3da91e['json']();if('needConfirmation'in _0x335b48)throw en(_0x5118e6,'account-exists-with-different-credential',_0x335b48);if(_0x3da91e['ok']&&!('errorMessage'in _0x335b48))return _0x335b48;{const _0x2f0826=_0x3da91e['ok']?_0x335b48['errorMessage']:_0x335b48['error']['message'],[_0x57be17,_0x20ffea]=_0x2f0826['split']('\x20:\x20');if(_0x57be17==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x5118e6,'credential-already-in-use',_0x335b48);if(_0x57be17==='EMAIL_EXISTS')throw en(_0x5118e6,'email-already-in-use',_0x335b48);if(_0x57be17==='USER_DISABLED')throw en(_0x5118e6,'user-disabled',_0x335b48);const _0x1e5b58=_0x60d4c3[_0x57be17]||_0x57be17['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x20ffea)throw ya(_0x5118e6,_0x1e5b58,_0x20ffea);K(_0x5118e6,_0x1e5b58);}}catch(_0x34fec6){if(_0x34fec6 instanceof Se)throw _0x34fec6;K(_0x5118e6,'network-request-failed',{'message':String(_0x34fec6)});}}async function Yt(_0xc2b556,_0x17292d,_0x24c6ec,_0x36ca1a,_0x308f17={}){const _0x52cd1b=await Ae(_0xc2b556,_0x17292d,_0x24c6ec,_0x36ca1a,_0x308f17);return'mfaPendingCredential'in _0x52cd1b&&K(_0xc2b556,'multi-factor-auth-required',{'_serverResponse':_0x52cd1b}),_0x52cd1b;}async function Ia(_0x2dfcab,_0x321369,_0x4d5c34,_0x21f1ad){const _0x1fdbac=''+_0x321369+_0x4d5c34+'?'+_0x21f1ad,_0x30f3ce=_0x2dfcab,_0x342c0f=_0x30f3ce['config']['emulator']?Is(_0x2dfcab['config'],_0x1fdbac):_0x2dfcab['config']['apiScheme']+'://'+_0x1fdbac;return of['includes'](_0x4d5c34)&&(await _0x30f3ce['_persistenceManagerAvailable'],_0x30f3ce['_getPersistenceType']()==='COOKIE')?_0x30f3ce['_getPersistence']()['_getFinalTarget'](_0x342c0f)['toString']():_0x342c0f;}function cf(_0x4cd850){switch(_0x4cd850){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3fe901){this['auth']=_0x3fe901,this['timer']=null,this['promise']=new Promise((_0x99325b,_0x5f18df)=>{this['timer']=setTimeout(()=>_0x5f18df(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x5c7180,_0x44690d,_0xe77e96){const _0x5c4b6e={'appName':_0x5c7180['name']};_0xe77e96['email']&&(_0x5c4b6e['email']=_0xe77e96['email']),_0xe77e96['phoneNumber']&&(_0x5c4b6e['phoneNumber']=_0xe77e96['phoneNumber']);const _0x2c4b72=J(_0x5c7180,_0x44690d,_0x5c4b6e);return _0x2c4b72['customData']['_tokenResponse']=_0xe77e96,_0x2c4b72;}function vr(_0x572f88){return _0x572f88!==void 0x0&&_0x572f88['enterprise']!==void 0x0;}class hf{constructor(_0x272b1d){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x272b1d['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x272b1d['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x272b1d['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x13e165){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5dbc6a of this['recaptchaEnforcementState'])if(_0x5dbc6a['provider']&&_0x5dbc6a['provider']===_0x13e165)return cf(_0x5dbc6a['enforcementState']);return null;}['isProviderEnabled'](_0xa1cf0f){return this['getProviderEnforcementState'](_0xa1cf0f)==='ENFORCE'||this['getProviderEnforcementState'](_0xa1cf0f)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x395c97,_0x56a9e3){return Ae(_0x395c97,'GET','/v2/recaptchaConfig',Re(_0x395c97,_0x56a9e3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x16cd73,_0x4313cd){return Ae(_0x16cd73,'POST','/v1/accounts:delete',_0x4313cd);}async function Sn(_0x1fdc74,_0x11be3c){return Ae(_0x1fdc74,'POST','/v1/accounts:lookup',_0x11be3c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x45d2b1){if(_0x45d2b1)try{const _0x3de3cb=new Date(Number(_0x45d2b1));if(!isNaN(_0x3de3cb['getTime']()))return _0x3de3cb['toUTCString']();}catch{}}async function ff(_0x478d02,_0xf93264=!0x1){const _0x73b63d=k(_0x478d02),_0x4dc278=await _0x73b63d['getIdToken'](_0xf93264),_0x4f71ee=ws(_0x4dc278);m(_0x4f71ee&&_0x4f71ee['exp']&&_0x4f71ee['auth_time']&&_0x4f71ee['iat'],_0x73b63d['auth'],'internal-error');const _0x318ed2=typeof _0x4f71ee['firebase']=='object'?_0x4f71ee['firebase']:void 0x0,_0x252dfb=_0x318ed2==null?void 0x0:_0x318ed2['sign_in_provider'];return{'claims':_0x4f71ee,'token':_0x4dc278,'authTime':St(ci(_0x4f71ee['auth_time'])),'issuedAtTime':St(ci(_0x4f71ee['iat'])),'expirationTime':St(ci(_0x4f71ee['exp'])),'signInProvider':_0x252dfb||null,'signInSecondFactor':(_0x318ed2==null?void 0x0:_0x318ed2['sign_in_second_factor'])||null};}function ci(_0x5034f7){return Number(_0x5034f7)*0x3e8;}function ws(_0xc58e48){const [_0x677aaf,_0x5b10cd,_0x511c19]=_0xc58e48['split']('.');if(_0x677aaf===void 0x0||_0x5b10cd===void 0x0||_0x511c19===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4b0461=cn(_0x5b10cd);return _0x4b0461?JSON['parse'](_0x4b0461):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xcc5204){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xcc5204==null?void 0x0:_0xcc5204['toString']()),null;}}function Er(_0x45e2c5){const _0xb1c4a6=ws(_0x45e2c5);return m(_0xb1c4a6,'internal-error'),m(typeof _0xb1c4a6['exp']<'u','internal-error'),m(typeof _0xb1c4a6['iat']<'u','internal-error'),Number(_0xb1c4a6['exp'])-Number(_0xb1c4a6['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x1d86a2,_0x5e91ba,_0x268771=!0x1){if(_0x268771)return _0x5e91ba;try{return await _0x5e91ba;}catch(_0x4f4029){throw _0x4f4029 instanceof Se&&pf(_0x4f4029)&&_0x1d86a2['auth']['currentUser']===_0x1d86a2&&await _0x1d86a2['auth']['signOut'](),_0x4f4029;}}function pf({code:_0x30829c}){return _0x30829c==='auth/user-disabled'||_0x30829c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x59fedc){this['user']=_0x59fedc,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x21ef38){if(_0x21ef38){const _0x50b735=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x50b735;}else{this['errorBackoff']=0x7530;const _0x4d5233=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4d5233);}}['schedule'](_0x2962db=!0x1){if(!this['isRunning'])return;const _0xd59ba0=this['getInterval'](_0x2962db);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xd59ba0);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xb31963){(_0xb31963==null?void 0x0:_0xb31963['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x9acaa9,_0x32fb39){this['createdAt']=_0x9acaa9,this['lastLoginAt']=_0x32fb39,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x24bcd5){this['createdAt']=_0x24bcd5['createdAt'],this['lastLoginAt']=_0x24bcd5['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x12b765){var _0x3c1747;const _0x43e428=_0x12b765['auth'],_0x7d8243=await _0x12b765['getIdToken'](),_0x373a7d=await xt(_0x12b765,Sn(_0x43e428,{'idToken':_0x7d8243}));m(_0x373a7d==null?void 0x0:_0x373a7d['users']['length'],_0x43e428,'internal-error');const _0x85e273=_0x373a7d['users'][0x0];_0x12b765['_notifyReloadListener'](_0x85e273);const _0xaf9b88=(_0x3c1747=_0x85e273['providerUserInfo'])!=null&&_0x3c1747['length']?wa(_0x85e273['providerUserInfo']):[],_0x13ed64=mf(_0x12b765['providerData'],_0xaf9b88),_0x2b227b=_0x12b765['isAnonymous'],_0x1b3826=!(_0x12b765['email']&&_0x85e273['passwordHash'])&&!(_0x13ed64!=null&&_0x13ed64['length']),_0x136e63=_0x2b227b?_0x1b3826:!0x1,_0x565eb6={'uid':_0x85e273['localId'],'displayName':_0x85e273['displayName']||null,'photoURL':_0x85e273['photoUrl']||null,'email':_0x85e273['email']||null,'emailVerified':_0x85e273['emailVerified']||!0x1,'phoneNumber':_0x85e273['phoneNumber']||null,'tenantId':_0x85e273['tenantId']||null,'providerData':_0x13ed64,'metadata':new Pi(_0x85e273['createdAt'],_0x85e273['lastLoginAt']),'isAnonymous':_0x136e63};Object['assign'](_0x12b765,_0x565eb6);}async function gf(_0x1ff262){const _0x4f380e=k(_0x1ff262);await bn(_0x4f380e),await _0x4f380e['auth']['_persistUserIfCurrent'](_0x4f380e),_0x4f380e['auth']['_notifyListenersIfCurrent'](_0x4f380e);}function mf(_0x2daedc,_0x2f388d){return[..._0x2daedc['filter'](_0x4e0a96=>!_0x2f388d['some'](_0x566426=>_0x566426['providerId']===_0x4e0a96['providerId'])),..._0x2f388d];}function wa(_0x24e2e5){return _0x24e2e5['map'](({providerId:_0x64a7c7,..._0x9755c7})=>({'providerId':_0x64a7c7,'uid':_0x9755c7['rawId']||'','displayName':_0x9755c7['displayName']||null,'email':_0x9755c7['email']||null,'phoneNumber':_0x9755c7['phoneNumber']||null,'photoURL':_0x9755c7['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x282d45,_0x4863c6){const _0x1c6df9=await Ea(_0x282d45,{},async()=>{const _0x150037=at({'grant_type':'refresh_token','refresh_token':_0x4863c6})['slice'](0x1),{tokenApiHost:_0x20eda0,apiKey:_0x59d0c0}=_0x282d45['config'],_0x30c9b5=await Ia(_0x282d45,_0x20eda0,'/v1/token','key='+_0x59d0c0),_0x1466a6=await _0x282d45['_getAdditionalHeaders']();_0x1466a6['Content-Type']='application/x-www-form-urlencoded';const _0x4f22f8={'method':'POST','headers':_0x1466a6,'body':_0x150037};return _0x282d45['emulatorConfig']&&Wt(_0x282d45['emulatorConfig']['host'])&&(_0x4f22f8['credentials']='include'),va['fetch']()(_0x30c9b5,_0x4f22f8);});return{'accessToken':_0x1c6df9['access_token'],'expiresIn':_0x1c6df9['expires_in'],'refreshToken':_0x1c6df9['refresh_token']};}async function vf(_0x58138e,_0x5da252){return Ae(_0x58138e,'POST','/v2/accounts:revokeToken',Re(_0x58138e,_0x5da252));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x461b3a){m(_0x461b3a['idToken'],'internal-error'),m(typeof _0x461b3a['idToken']<'u','internal-error'),m(typeof _0x461b3a['refreshToken']<'u','internal-error');const _0x4a4fe2='expiresIn'in _0x461b3a&&typeof _0x461b3a['expiresIn']<'u'?Number(_0x461b3a['expiresIn']):Er(_0x461b3a['idToken']);this['updateTokensAndExpiration'](_0x461b3a['idToken'],_0x461b3a['refreshToken'],_0x4a4fe2);}['updateFromIdToken'](_0x516f67){m(_0x516f67['length']!==0x0,'internal-error');const _0x3f400b=Er(_0x516f67);this['updateTokensAndExpiration'](_0x516f67,null,_0x3f400b);}async['getToken'](_0x4d1f60,_0x205348=!0x1){return!_0x205348&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4d1f60,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4d1f60,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x50c2ff,_0x1f6aee){const {accessToken:_0x54ca34,refreshToken:_0x14d7a9,expiresIn:_0x9f0eaa}=await yf(_0x50c2ff,_0x1f6aee);this['updateTokensAndExpiration'](_0x54ca34,_0x14d7a9,Number(_0x9f0eaa));}['updateTokensAndExpiration'](_0x354864,_0x2b2333,_0x278e21){this['refreshToken']=_0x2b2333||null,this['accessToken']=_0x354864||null,this['expirationTime']=Date['now']()+_0x278e21*0x3e8;}static['fromJSON'](_0x270858,_0x537067){const {refreshToken:_0x109c92,accessToken:_0x114fb0,expirationTime:_0x833bfb}=_0x537067,_0x336c36=new Je();return _0x109c92&&(m(typeof _0x109c92=='string','internal-error',{'appName':_0x270858}),_0x336c36['refreshToken']=_0x109c92),_0x114fb0&&(m(typeof _0x114fb0=='string','internal-error',{'appName':_0x270858}),_0x336c36['accessToken']=_0x114fb0),_0x833bfb&&(m(typeof _0x833bfb=='number','internal-error',{'appName':_0x270858}),_0x336c36['expirationTime']=_0x833bfb),_0x336c36;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xb9dada){this['accessToken']=_0xb9dada['accessToken'],this['refreshToken']=_0xb9dada['refreshToken'],this['expirationTime']=_0xb9dada['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x3d016,_0x35bea1){m(typeof _0x3d016=='string'||typeof _0x3d016>'u','internal-error',{'appName':_0x35bea1});}class z{constructor({uid:_0xbffc3d,auth:_0x7649d2,stsTokenManager:_0xb470ef,..._0x4899cd}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xbffc3d,this['auth']=_0x7649d2,this['stsTokenManager']=_0xb470ef,this['accessToken']=_0xb470ef['accessToken'],this['displayName']=_0x4899cd['displayName']||null,this['email']=_0x4899cd['email']||null,this['emailVerified']=_0x4899cd['emailVerified']||!0x1,this['phoneNumber']=_0x4899cd['phoneNumber']||null,this['photoURL']=_0x4899cd['photoURL']||null,this['isAnonymous']=_0x4899cd['isAnonymous']||!0x1,this['tenantId']=_0x4899cd['tenantId']||null,this['providerData']=_0x4899cd['providerData']?[..._0x4899cd['providerData']]:[],this['metadata']=new Pi(_0x4899cd['createdAt']||void 0x0,_0x4899cd['lastLoginAt']||void 0x0);}async['getIdToken'](_0xccd553){const _0x30e4b5=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0xccd553));return m(_0x30e4b5,this['auth'],'internal-error'),this['accessToken']!==_0x30e4b5&&(this['accessToken']=_0x30e4b5,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x30e4b5;}['getIdTokenResult'](_0x1eabcc){return ff(this,_0x1eabcc);}['reload'](){return gf(this);}['_assign'](_0x26d29a){this!==_0x26d29a&&(m(this['uid']===_0x26d29a['uid'],this['auth'],'internal-error'),this['displayName']=_0x26d29a['displayName'],this['photoURL']=_0x26d29a['photoURL'],this['email']=_0x26d29a['email'],this['emailVerified']=_0x26d29a['emailVerified'],this['phoneNumber']=_0x26d29a['phoneNumber'],this['isAnonymous']=_0x26d29a['isAnonymous'],this['tenantId']=_0x26d29a['tenantId'],this['providerData']=_0x26d29a['providerData']['map'](_0x2867df=>({..._0x2867df})),this['metadata']['_copy'](_0x26d29a['metadata']),this['stsTokenManager']['_assign'](_0x26d29a['stsTokenManager']));}['_clone'](_0x1c79bb){const _0x2844a4=new z({...this,'auth':_0x1c79bb,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2844a4['metadata']['_copy'](this['metadata']),_0x2844a4;}['_onReload'](_0x63b9fb){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x63b9fb,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x13dd56){this['reloadListener']?this['reloadListener'](_0x13dd56):this['reloadUserInfo']=_0x13dd56;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2e5b5d,_0x51a16b=!0x1){let _0x5ec8bc=!0x1;_0x2e5b5d['idToken']&&_0x2e5b5d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2e5b5d),_0x5ec8bc=!0x0),_0x51a16b&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5ec8bc&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0xde1809=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0xde1809})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x35896c=>({..._0x35896c})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x14edc0,_0x246350){const _0x1c06e7=_0x246350['displayName']??void 0x0,_0x5797b6=_0x246350['email']??void 0x0,_0x1f1b68=_0x246350['phoneNumber']??void 0x0,_0x4fdc53=_0x246350['photoURL']??void 0x0,_0x388260=_0x246350['tenantId']??void 0x0,_0x130a61=_0x246350['_redirectEventId']??void 0x0,_0x4aba5e=_0x246350['createdAt']??void 0x0,_0x4e168c=_0x246350['lastLoginAt']??void 0x0,{uid:_0x1c2de7,emailVerified:_0x46bcf9,isAnonymous:_0x5431e2,providerData:_0x1e73c4,stsTokenManager:_0x27f96f}=_0x246350;m(_0x1c2de7&&_0x27f96f,_0x14edc0,'internal-error');const _0x27e0ff=Je['fromJSON'](this['name'],_0x27f96f);m(typeof _0x1c2de7=='string',_0x14edc0,'internal-error'),ce(_0x1c06e7,_0x14edc0['name']),ce(_0x5797b6,_0x14edc0['name']),m(typeof _0x46bcf9=='boolean',_0x14edc0,'internal-error'),m(typeof _0x5431e2=='boolean',_0x14edc0,'internal-error'),ce(_0x1f1b68,_0x14edc0['name']),ce(_0x4fdc53,_0x14edc0['name']),ce(_0x388260,_0x14edc0['name']),ce(_0x130a61,_0x14edc0['name']),ce(_0x4aba5e,_0x14edc0['name']),ce(_0x4e168c,_0x14edc0['name']);const _0xcad51f=new z({'uid':_0x1c2de7,'auth':_0x14edc0,'email':_0x5797b6,'emailVerified':_0x46bcf9,'displayName':_0x1c06e7,'isAnonymous':_0x5431e2,'photoURL':_0x4fdc53,'phoneNumber':_0x1f1b68,'tenantId':_0x388260,'stsTokenManager':_0x27e0ff,'createdAt':_0x4aba5e,'lastLoginAt':_0x4e168c});return _0x1e73c4&&Array['isArray'](_0x1e73c4)&&(_0xcad51f['providerData']=_0x1e73c4['map'](_0x29dd6b=>({..._0x29dd6b}))),_0x130a61&&(_0xcad51f['_redirectEventId']=_0x130a61),_0xcad51f;}static async['_fromIdTokenResponse'](_0x3062f,_0x3093cc,_0x2a292b=!0x1){const _0x4f0458=new Je();_0x4f0458['updateFromServerResponse'](_0x3093cc);const _0x59538c=new z({'uid':_0x3093cc['localId'],'auth':_0x3062f,'stsTokenManager':_0x4f0458,'isAnonymous':_0x2a292b});return await bn(_0x59538c),_0x59538c;}static async['_fromGetAccountInfoResponse'](_0x5400e7,_0x33312d,_0x1241a0){const _0x15866a=_0x33312d['users'][0x0];m(_0x15866a['localId']!==void 0x0,'internal-error');const _0xd0bd1f=_0x15866a['providerUserInfo']!==void 0x0?wa(_0x15866a['providerUserInfo']):[],_0x3c1cd5=!(_0x15866a['email']&&_0x15866a['passwordHash'])&&!(_0xd0bd1f!=null&&_0xd0bd1f['length']),_0x2dbbe4=new Je();_0x2dbbe4['updateFromIdToken'](_0x1241a0);const _0x86337=new z({'uid':_0x15866a['localId'],'auth':_0x5400e7,'stsTokenManager':_0x2dbbe4,'isAnonymous':_0x3c1cd5}),_0x574b2b={'uid':_0x15866a['localId'],'displayName':_0x15866a['displayName']||null,'photoURL':_0x15866a['photoUrl']||null,'email':_0x15866a['email']||null,'emailVerified':_0x15866a['emailVerified']||!0x1,'phoneNumber':_0x15866a['phoneNumber']||null,'tenantId':_0x15866a['tenantId']||null,'providerData':_0xd0bd1f,'metadata':new Pi(_0x15866a['createdAt'],_0x15866a['lastLoginAt']),'isAnonymous':!(_0x15866a['email']&&_0x15866a['passwordHash'])&&!(_0xd0bd1f!=null&&_0xd0bd1f['length'])};return Object['assign'](_0x86337,_0x574b2b),_0x86337;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x4f3eac){ae(_0x4f3eac instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2ce40b=Ir['get'](_0x4f3eac);return _0x2ce40b?(ae(_0x2ce40b instanceof _0x4f3eac,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2ce40b):(_0x2ce40b=new _0x4f3eac(),Ir['set'](_0x4f3eac,_0x2ce40b),_0x2ce40b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x142274,_0x52c040){this['storage'][_0x142274]=_0x52c040;}async['_get'](_0x4d2355){const _0x5e7691=this['storage'][_0x4d2355];return _0x5e7691===void 0x0?null:_0x5e7691;}async['_remove'](_0x417869){delete this['storage'][_0x417869];}['_addListener'](_0xf9fd45,_0x513d9f){}['_removeListener'](_0x246921,_0x125720){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x4e2bb2,_0x8f3ce7,_0xe8f603){return'firebase:'+_0x4e2bb2+':'+_0x8f3ce7+':'+_0xe8f603;}class Xe{constructor(_0x1de11c,_0x3fb536,_0x4aacc0){this['persistence']=_0x1de11c,this['auth']=_0x3fb536,this['userKey']=_0x4aacc0;const {config:_0x3b8f2b,name:_0x1629ce}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3b8f2b['apiKey'],_0x1629ce),this['fullPersistenceKey']=sn('persistence',_0x3b8f2b['apiKey'],_0x1629ce),this['boundEventHandler']=_0x3fb536['_onStorageEvent']['bind'](_0x3fb536),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4ed3b7){return this['persistence']['_set'](this['fullUserKey'],_0x4ed3b7['toJSON']());}async['getCurrentUser'](){const _0x3c7af6=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3c7af6)return null;if(typeof _0x3c7af6=='string'){const _0xcd0f24=await Sn(this['auth'],{'idToken':_0x3c7af6})['catch'](()=>{});return _0xcd0f24?z['_fromGetAccountInfoResponse'](this['auth'],_0xcd0f24,_0x3c7af6):null;}return z['_fromJSON'](this['auth'],_0x3c7af6);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5e8ddc){if(this['persistence']===_0x5e8ddc)return;const _0x5ac653=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5e8ddc,_0x5ac653)return this['setCurrentUser'](_0x5ac653);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1d2737,_0x3b052e,_0xb2aff9='authUser'){if(!_0x3b052e['length'])return new Xe(ne(wr),_0x1d2737,_0xb2aff9);const _0x535216=(await Promise['all'](_0x3b052e['map'](async _0x3b21e6=>{if(await _0x3b21e6['_isAvailable']())return _0x3b21e6;})))['filter'](_0x3454b0=>_0x3454b0);let _0x5ed6b5=_0x535216[0x0]||ne(wr);const _0x31d20a=sn(_0xb2aff9,_0x1d2737['config']['apiKey'],_0x1d2737['name']);let _0x4050d6=null;for(const _0x3f6917 of _0x3b052e)try{const _0x102e82=await _0x3f6917['_get'](_0x31d20a);if(_0x102e82){let _0x4ee7a2;if(typeof _0x102e82=='string'){const _0x1b79b4=await Sn(_0x1d2737,{'idToken':_0x102e82})['catch'](()=>{});if(!_0x1b79b4)break;_0x4ee7a2=await z['_fromGetAccountInfoResponse'](_0x1d2737,_0x1b79b4,_0x102e82);}else _0x4ee7a2=z['_fromJSON'](_0x1d2737,_0x102e82);_0x3f6917!==_0x5ed6b5&&(_0x4050d6=_0x4ee7a2),_0x5ed6b5=_0x3f6917;break;}}catch{}const _0x3a8ce7=_0x535216['filter'](_0x33f327=>_0x33f327['_shouldAllowMigration']);return!_0x5ed6b5['_shouldAllowMigration']||!_0x3a8ce7['length']?new Xe(_0x5ed6b5,_0x1d2737,_0xb2aff9):(_0x5ed6b5=_0x3a8ce7[0x0],_0x4050d6&&await _0x5ed6b5['_set'](_0x31d20a,_0x4050d6['toJSON']()),await Promise['all'](_0x3b052e['map'](async _0x3f991c=>{if(_0x3f991c!==_0x5ed6b5)try{await _0x3f991c['_remove'](_0x31d20a);}catch{}})),new Xe(_0x5ed6b5,_0x1d2737,_0xb2aff9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x1bf10b){const _0x175c3b=_0x1bf10b['toLowerCase']();if(_0x175c3b['includes']('opera/')||_0x175c3b['includes']('opr/')||_0x175c3b['includes']('opios/'))return'Opera';if(Ra(_0x175c3b))return'IEMobile';if(_0x175c3b['includes']('msie')||_0x175c3b['includes']('trident/'))return'IE';if(_0x175c3b['includes']('edge/'))return'Edge';if(Ta(_0x175c3b))return'Firefox';if(_0x175c3b['includes']('silk/'))return'Silk';if(ka(_0x175c3b))return'Blackberry';if(Na(_0x175c3b))return'Webos';if(Sa(_0x175c3b))return'Safari';if((_0x175c3b['includes']('chrome/')||ba(_0x175c3b))&&!_0x175c3b['includes']('edge/'))return'Chrome';if(Aa(_0x175c3b))return'Android';{const _0x42895d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2ba1d6=_0x1bf10b['match'](_0x42895d);if((_0x2ba1d6==null?void 0x0:_0x2ba1d6['length'])===0x2)return _0x2ba1d6[0x1];}return'Other';}function Ta(_0x21afa3=W()){return/firefox\//i['test'](_0x21afa3);}function Sa(_0x3fcd77=W()){const _0x3b7cec=_0x3fcd77['toLowerCase']();return _0x3b7cec['includes']('safari/')&&!_0x3b7cec['includes']('chrome/')&&!_0x3b7cec['includes']('crios/')&&!_0x3b7cec['includes']('android');}function ba(_0x5bd5d7=W()){return/crios\//i['test'](_0x5bd5d7);}function Ra(_0x55d9fc=W()){return/iemobile/i['test'](_0x55d9fc);}function Aa(_0x4a241c=W()){return/android/i['test'](_0x4a241c);}function ka(_0x225b3e=W()){return/blackberry/i['test'](_0x225b3e);}function Na(_0x134ca9=W()){return/webos/i['test'](_0x134ca9);}function Cs(_0x24a0f6=W()){return/iphone|ipad|ipod/i['test'](_0x24a0f6)||/macintosh/i['test'](_0x24a0f6)&&/mobile/i['test'](_0x24a0f6);}function Ef(_0x15f0b0=W()){var _0x32e897;return Cs(_0x15f0b0)&&!!((_0x32e897=window['navigator'])!=null&&_0x32e897['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x381d81=W()){return Cs(_0x381d81)||Aa(_0x381d81)||Na(_0x381d81)||ka(_0x381d81)||/windows phone/i['test'](_0x381d81)||Ra(_0x381d81);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x2fafa5,_0x1730af=[]){let _0x37336e;switch(_0x2fafa5){case'Browser':_0x37336e=Cr(W());break;case'Worker':_0x37336e=Cr(W())+'-'+_0x2fafa5;break;default:_0x37336e=_0x2fafa5;}const _0x41d4d3=_0x1730af['length']?_0x1730af['join'](','):'FirebaseCore-web';return _0x37336e+'/JsCore/'+ct+'/'+_0x41d4d3;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x397911){this['auth']=_0x397911,this['queue']=[];}['pushCallback'](_0x5d9e48,_0x5485fe){const _0x5e36fe=_0x42ff35=>new Promise((_0x4ccbf4,_0x14df7c)=>{try{const _0x19fb79=_0x5d9e48(_0x42ff35);_0x4ccbf4(_0x19fb79);}catch(_0xfbf778){_0x14df7c(_0xfbf778);}});_0x5e36fe['onAbort']=_0x5485fe,this['queue']['push'](_0x5e36fe);const _0x181327=this['queue']['length']-0x1;return()=>{this['queue'][_0x181327]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5c047c){if(this['auth']['currentUser']===_0x5c047c)return;const _0x15bfbf=[];try{for(const _0x4f985b of this['queue'])await _0x4f985b(_0x5c047c),_0x4f985b['onAbort']&&_0x15bfbf['push'](_0x4f985b['onAbort']);}catch(_0x45f271){_0x15bfbf['reverse']();for(const _0x636267 of _0x15bfbf)try{_0x636267();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x45f271==null?void 0x0:_0x45f271['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5dd981,_0xc47a4f={}){return Ae(_0x5dd981,'GET','/v2/passwordPolicy',Re(_0x5dd981,_0xc47a4f));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3144b1){var _0x54fa3e;const _0x1d196b=_0x3144b1['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1d196b['minPasswordLength']??Tf,_0x1d196b['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1d196b['maxPasswordLength']),_0x1d196b['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1d196b['containsLowercaseCharacter']),_0x1d196b['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1d196b['containsUppercaseCharacter']),_0x1d196b['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1d196b['containsNumericCharacter']),_0x1d196b['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1d196b['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3144b1['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x54fa3e=_0x3144b1['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x54fa3e['join'](''))??'',this['forceUpgradeOnSignin']=_0x3144b1['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3144b1['schemaVersion'];}['validatePassword'](_0x11ba09){const _0x1f1187={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x11ba09,_0x1f1187),this['validatePasswordCharacterOptions'](_0x11ba09,_0x1f1187),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['meetsMinPasswordLength']??!0x0),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['meetsMaxPasswordLength']??!0x0),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['containsLowercaseLetter']??!0x0),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['containsUppercaseLetter']??!0x0),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['containsNumericCharacter']??!0x0),_0x1f1187['isValid']&&(_0x1f1187['isValid']=_0x1f1187['containsNonAlphanumericCharacter']??!0x0),_0x1f1187;}['validatePasswordLengthOptions'](_0x448765,_0x3f9df4){const _0x3c03b0=this['customStrengthOptions']['minPasswordLength'],_0x25a6fc=this['customStrengthOptions']['maxPasswordLength'];_0x3c03b0&&(_0x3f9df4['meetsMinPasswordLength']=_0x448765['length']>=_0x3c03b0),_0x25a6fc&&(_0x3f9df4['meetsMaxPasswordLength']=_0x448765['length']<=_0x25a6fc);}['validatePasswordCharacterOptions'](_0x39d0b4,_0x2baf99){this['updatePasswordCharacterOptionsStatuses'](_0x2baf99,!0x1,!0x1,!0x1,!0x1);let _0xec54eb;for(let _0x9651f=0x0;_0x9651f<_0x39d0b4['length'];_0x9651f++)_0xec54eb=_0x39d0b4['charAt'](_0x9651f),this['updatePasswordCharacterOptionsStatuses'](_0x2baf99,_0xec54eb>='a'&&_0xec54eb<='z',_0xec54eb>='A'&&_0xec54eb<='Z',_0xec54eb>='0'&&_0xec54eb<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xec54eb));}['updatePasswordCharacterOptionsStatuses'](_0x1fb109,_0xeed3f5,_0x5555ad,_0x24e368,_0x267e48){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1fb109['containsLowercaseLetter']||(_0x1fb109['containsLowercaseLetter']=_0xeed3f5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1fb109['containsUppercaseLetter']||(_0x1fb109['containsUppercaseLetter']=_0x5555ad)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1fb109['containsNumericCharacter']||(_0x1fb109['containsNumericCharacter']=_0x24e368)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1fb109['containsNonAlphanumericCharacter']||(_0x1fb109['containsNonAlphanumericCharacter']=_0x267e48));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x2fa10f,_0x218a2f,_0x2798f1,_0xc8a78a){this['app']=_0x2fa10f,this['heartbeatServiceProvider']=_0x218a2f,this['appCheckServiceProvider']=_0x2798f1,this['config']=_0xc8a78a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x2fa10f['name'],this['clientVersion']=_0xc8a78a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x10557d=>this['_resolvePersistenceManagerAvailable']=_0x10557d);}['_initializeWithPersistence'](_0x1465ab,_0x42d1a5){return _0x42d1a5&&(this['_popupRedirectResolver']=ne(_0x42d1a5)),this['_initializationPromise']=this['queue'](async()=>{var _0x240c17,_0x4f79f5,_0x508b16;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x1465ab),(_0x240c17=this['_resolvePersistenceManagerAvailable'])==null||_0x240c17['call'](this),!this['_deleted'])){if((_0x4f79f5=this['_popupRedirectResolver'])!=null&&_0x4f79f5['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x42d1a5),this['lastNotifiedUid']=((_0x508b16=this['currentUser'])==null?void 0x0:_0x508b16['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x132b83=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x132b83)){if(this['currentUser']&&_0x132b83&&this['currentUser']['uid']===_0x132b83['uid']){this['_currentUser']['_assign'](_0x132b83),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x132b83,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3891cc){try{const _0x4ee3c4=await Sn(this,{'idToken':_0x3891cc}),_0x2f8fdd=await z['_fromGetAccountInfoResponse'](this,_0x4ee3c4,_0x3891cc);await this['directlySetCurrentUser'](_0x2f8fdd);}catch(_0x4f170d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4f170d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2f3ade){var _0x411be1;if(H(this['app'])){const _0x4de249=this['app']['settings']['authIdToken'];return _0x4de249?new Promise(_0x17bd68=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4de249)['then'](_0x17bd68,_0x17bd68));}):this['directlySetCurrentUser'](null);}const _0x56079a=await this['assertedPersistence']['getCurrentUser']();let _0x379dbe=_0x56079a,_0x27323a=!0x1;if(_0x2f3ade&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x53ee6d=(_0x411be1=this['redirectUser'])==null?void 0x0:_0x411be1['_redirectEventId'],_0x4198dc=_0x379dbe==null?void 0x0:_0x379dbe['_redirectEventId'],_0x1d447f=await this['tryRedirectSignIn'](_0x2f3ade);(!_0x53ee6d||_0x53ee6d===_0x4198dc)&&(_0x1d447f!=null&&_0x1d447f['user'])&&(_0x379dbe=_0x1d447f['user'],_0x27323a=!0x0);}if(!_0x379dbe)return this['directlySetCurrentUser'](null);if(!_0x379dbe['_redirectEventId']){if(_0x27323a)try{await this['beforeStateQueue']['runMiddleware'](_0x379dbe);}catch(_0x472898){_0x379dbe=_0x56079a,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x472898));}return _0x379dbe?this['reloadAndSetCurrentUserOrClear'](_0x379dbe):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x379dbe['_redirectEventId']?this['directlySetCurrentUser'](_0x379dbe):this['reloadAndSetCurrentUserOrClear'](_0x379dbe);}async['tryRedirectSignIn'](_0x57254f){let _0x50a561=null;try{_0x50a561=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x57254f,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x50a561;}async['reloadAndSetCurrentUserOrClear'](_0x28ce71){try{await bn(_0x28ce71);}catch(_0x17ee59){if((_0x17ee59==null?void 0x0:_0x17ee59['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x28ce71);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x9d612c){if(H(this['app']))return Promise['reject'](se(this));const _0x47d6b0=_0x9d612c?k(_0x9d612c):null;return _0x47d6b0&&m(_0x47d6b0['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x47d6b0&&_0x47d6b0['_clone'](this));}async['_updateCurrentUser'](_0x36f6a6,_0x54a43b=!0x1){if(!this['_deleted'])return _0x36f6a6&&m(this['tenantId']===_0x36f6a6['tenantId'],this,'tenant-id-mismatch'),_0x54a43b||await this['beforeStateQueue']['runMiddleware'](_0x36f6a6),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x36f6a6),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x990047){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x990047));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5eda45){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x466917=this['_getPasswordPolicyInternal']();return _0x466917['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x466917['validatePassword'](_0x5eda45);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x48e5c3=await Cf(this),_0xe4794e=new Sf(_0x48e5c3);this['tenantId']===null?this['_projectPasswordPolicy']=_0xe4794e:this['_tenantPasswordPolicies'][this['tenantId']]=_0xe4794e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x264fa3){this['_errorFactory']=new Ut('auth','Firebase',_0x264fa3());}['onAuthStateChanged'](_0x5b3976,_0x27e98c,_0x6d76ce){return this['registerStateListener'](this['authStateSubscription'],_0x5b3976,_0x27e98c,_0x6d76ce);}['beforeAuthStateChanged'](_0x102ce1,_0x5c27f5){return this['beforeStateQueue']['pushCallback'](_0x102ce1,_0x5c27f5);}['onIdTokenChanged'](_0x245d63,_0x530178,_0x39d5f5){return this['registerStateListener'](this['idTokenSubscription'],_0x245d63,_0x530178,_0x39d5f5);}['authStateReady'](){return new Promise((_0x180e04,_0x32ef01)=>{if(this['currentUser'])_0x180e04();else{const _0xfab3a5=this['onAuthStateChanged'](()=>{_0xfab3a5(),_0x180e04();},_0x32ef01);}});}async['revokeAccessToken'](_0x1d7690){if(this['currentUser']){const _0x34db64=await this['currentUser']['getIdToken'](),_0x241367={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1d7690,'idToken':_0x34db64};this['tenantId']!=null&&(_0x241367['tenantId']=this['tenantId']),await vf(this,_0x241367);}}['toJSON'](){var _0xedf710;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0xedf710=this['_currentUser'])==null?void 0x0:_0xedf710['toJSON']()};}async['_setRedirectUser'](_0x28c758,_0x4c6439){const _0x914c29=await this['getOrInitRedirectPersistenceManager'](_0x4c6439);return _0x28c758===null?_0x914c29['removeCurrentUser']():_0x914c29['setCurrentUser'](_0x28c758);}async['getOrInitRedirectPersistenceManager'](_0x58d1c7){if(!this['redirectPersistenceManager']){const _0x4baefb=_0x58d1c7&&ne(_0x58d1c7)||this['_popupRedirectResolver'];m(_0x4baefb,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x4baefb['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1f09fc){var _0x28b4d2,_0x429554;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x28b4d2=this['_currentUser'])==null?void 0x0:_0x28b4d2['_redirectEventId'])===_0x1f09fc?this['_currentUser']:((_0x429554=this['redirectUser'])==null?void 0x0:_0x429554['_redirectEventId'])===_0x1f09fc?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2978ac){if(_0x2978ac===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2978ac));}['_notifyListenersIfCurrent'](_0x16e27c){_0x16e27c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x4cca54;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3f0c36=((_0x4cca54=this['currentUser'])==null?void 0x0:_0x4cca54['uid'])??null;this['lastNotifiedUid']!==_0x3f0c36&&(this['lastNotifiedUid']=_0x3f0c36,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2acdbd,_0x23824b,_0x44cd9a,_0xef8630){if(this['_deleted'])return()=>{};const _0x294f9d=typeof _0x23824b=='function'?_0x23824b:_0x23824b['next']['bind'](_0x23824b);let _0x56dd6f=!0x1;const _0x2b522c=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2b522c,this,'internal-error'),_0x2b522c['then'](()=>{_0x56dd6f||_0x294f9d(this['currentUser']);}),typeof _0x23824b=='function'){const _0x2ae88b=_0x2acdbd['addObserver'](_0x23824b,_0x44cd9a,_0xef8630);return()=>{_0x56dd6f=!0x0,_0x2ae88b();};}else{const _0x2ac582=_0x2acdbd['addObserver'](_0x23824b);return()=>{_0x56dd6f=!0x0,_0x2ac582();};}}async['directlySetCurrentUser'](_0x401e9d){this['currentUser']&&this['currentUser']!==_0x401e9d&&this['_currentUser']['_stopProactiveRefresh'](),_0x401e9d&&this['isProactiveRefreshEnabled']&&_0x401e9d['_startProactiveRefresh'](),this['currentUser']=_0x401e9d,_0x401e9d?await this['assertedPersistence']['setCurrentUser'](_0x401e9d):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x40b436){return this['operations']=this['operations']['then'](_0x40b436,_0x40b436),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x113902){!_0x113902||this['frameworks']['includes'](_0x113902)||(this['frameworks']['push'](_0x113902),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5092b4;const _0x520f5f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x520f5f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x28e3d1=await((_0x5092b4=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5092b4['getHeartbeatsHeader']());_0x28e3d1&&(_0x520f5f['X-Firebase-Client']=_0x28e3d1);const _0x1fbd0c=await this['_getAppCheckToken']();return _0x1fbd0c&&(_0x520f5f['X-Firebase-AppCheck']=_0x1fbd0c),_0x520f5f;}async['_getAppCheckToken'](){var _0x1acc1d;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x137838=await((_0x1acc1d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1acc1d['getToken']());return _0x137838!=null&&_0x137838['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x137838['error']),_0x137838==null?void 0x0:_0x137838['token'];}}function qe(_0x15d0b4){return k(_0x15d0b4);}class Tr{constructor(_0x5b3d8b){this['auth']=_0x5b3d8b,this['observer']=null,this['addObserver']=Ic(_0x27c024=>this['observer']=_0x27c024);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x2b89c1){zn=_0x2b89c1;}function Da(_0x3b17b5){return zn['loadJS'](_0x3b17b5);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1486db){return'__'+_0x1486db+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x1c3b38){_0x1c3b38();}['execute'](_0x53196c,_0x4b78bc){return Promise['resolve']('token');}['render'](_0x1b65e7,_0xac67b3){return'';}}class Of{['ready'](_0x582fe6){_0x582fe6();}['execute'](_0x147975,_0x347b8c){return Promise['resolve']('token');}['render'](_0x1fa603,_0xc3ac29){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x5e4685){this['type']=Df,this['auth']=qe(_0x5e4685);}async['verify'](_0x141f0c='verify',_0x516e68=!0x1){async function _0x51b4e5(_0x2f35ed){if(!_0x516e68){if(_0x2f35ed['tenantId']==null&&_0x2f35ed['_agentRecaptchaConfig']!=null)return _0x2f35ed['_agentRecaptchaConfig']['siteKey'];if(_0x2f35ed['tenantId']!=null&&_0x2f35ed['_tenantRecaptchaConfigs'][_0x2f35ed['tenantId']]!==void 0x0)return _0x2f35ed['_tenantRecaptchaConfigs'][_0x2f35ed['tenantId']]['siteKey'];}return new Promise(async(_0x187c2a,_0x337a0d)=>{uf(_0x2f35ed,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3eb0d2=>{if(_0x3eb0d2['recaptchaKey']===void 0x0)_0x337a0d(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5d3334=new hf(_0x3eb0d2);return _0x2f35ed['tenantId']==null?_0x2f35ed['_agentRecaptchaConfig']=_0x5d3334:_0x2f35ed['_tenantRecaptchaConfigs'][_0x2f35ed['tenantId']]=_0x5d3334,_0x187c2a(_0x5d3334['siteKey']);}})['catch'](_0x4eb0b4=>{_0x337a0d(_0x4eb0b4);});});}function _0x53fa95(_0x6cf421,_0x2d1384,_0x58cc41){const _0x821d31=window['grecaptcha'];vr(_0x821d31)?_0x821d31['enterprise']['ready'](()=>{_0x821d31['enterprise']['execute'](_0x6cf421,{'action':_0x141f0c})['then'](_0x579734=>{_0x2d1384(_0x579734);})['catch'](()=>{_0x2d1384(Ma);});}):_0x58cc41(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x37e78d,_0x35f15e)=>{_0x51b4e5(this['auth'])['then'](async _0x4aee73=>{if(!_0x516e68&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x53fa95(_0x4aee73,_0x37e78d,_0x35f15e);else{if(typeof window>'u'){_0x35f15e(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3198eb=Af();_0x3198eb['length']!==0x0&&(_0x3198eb+=_0x4aee73+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x105b66;(_0x105b66=le['scriptInjectionDeferred'])==null||_0x105b66['resolve']();},Da(_0x3198eb)['then'](()=>{var _0x1443e5;return(_0x1443e5=le['scriptInjectionDeferred'])==null?void 0x0:_0x1443e5['promise'];})['then'](()=>{_0x53fa95(_0x4aee73,_0x37e78d,_0x35f15e);})['catch'](_0x2d0a7f=>{_0x35f15e(_0x2d0a7f);});}})['catch'](_0x434e13=>{_0x35f15e(_0x434e13);});});}}le['scriptInjectionDeferred']=null;async function br(_0x3422f0,_0x39db75,_0x45d3b0,_0x5210e7=!0x1,_0x57ef78=!0x1){const _0x2f98ed=new le(_0x3422f0);let _0x1c7f25;if(_0x57ef78)_0x1c7f25=Ma;else try{_0x1c7f25=await _0x2f98ed['verify'](_0x45d3b0);}catch{_0x1c7f25=await _0x2f98ed['verify'](_0x45d3b0,!0x0);}const _0x1e7396={..._0x39db75};if(_0x45d3b0==='mfaSmsEnrollment'||_0x45d3b0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1e7396){const _0x3fd97c=_0x1e7396['phoneEnrollmentInfo']['phoneNumber'],_0x575ff0=_0x1e7396['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1e7396,{'phoneEnrollmentInfo':{'phoneNumber':_0x3fd97c,'recaptchaToken':_0x575ff0,'captchaResponse':_0x1c7f25,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1e7396){const _0x3e8c91=_0x1e7396['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1e7396,{'phoneSignInInfo':{'recaptchaToken':_0x3e8c91,'captchaResponse':_0x1c7f25,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1e7396;}return _0x5210e7?Object['assign'](_0x1e7396,{'captchaResp':_0x1c7f25}):Object['assign'](_0x1e7396,{'captchaResponse':_0x1c7f25}),Object['assign'](_0x1e7396,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1e7396,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1e7396;}async function Oi(_0x10132e,_0x3e63d6,_0x4672ce,_0x144980,_0x132531){var _0xab56bf;if((_0xab56bf=_0x10132e['_getRecaptchaConfig']())!=null&&_0xab56bf['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xe7a5b4=await br(_0x10132e,_0x3e63d6,_0x4672ce,_0x4672ce==='getOobCode');return _0x144980(_0x10132e,_0xe7a5b4);}else return _0x144980(_0x10132e,_0x3e63d6)['catch'](async _0x45d8d6=>{if(_0x45d8d6['code']==='auth/missing-recaptcha-token'){console['log'](_0x4672ce+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x21f013=await br(_0x10132e,_0x3e63d6,_0x4672ce,_0x4672ce==='getOobCode');return _0x144980(_0x10132e,_0x21f013);}else return Promise['reject'](_0x45d8d6);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x3c182b,_0x4e9c1b){const _0x2633e7=Ui(_0x3c182b,'auth');if(_0x2633e7['isInitialized']()){const _0x3ed451=_0x2633e7['getImmediate'](),_0x4ba2d8=_0x2633e7['getOptions']();if(De(_0x4ba2d8,_0x4e9c1b??{}))return _0x3ed451;K(_0x3ed451,'already-initialized');}return _0x2633e7['initialize']({'options':_0x4e9c1b});}function Lf(_0x1aca32,_0x1076b3){const _0x599be8=(_0x1076b3==null?void 0x0:_0x1076b3['persistence'])||[],_0x508c9d=(Array['isArray'](_0x599be8)?_0x599be8:[_0x599be8])['map'](ne);_0x1076b3!=null&&_0x1076b3['errorMap']&&_0x1aca32['_updateErrorMap'](_0x1076b3['errorMap']),_0x1aca32['_initializeWithPersistence'](_0x508c9d,_0x1076b3==null?void 0x0:_0x1076b3['popupRedirectResolver']);}function xf(_0x1acb52,_0x38a314,_0x471307){const _0x14bef3=qe(_0x1acb52);m(/^https?:\/\//['test'](_0x38a314),_0x14bef3,'invalid-emulator-scheme');const _0x5c39ab=!0x1,_0x31b242=La(_0x38a314),{host:_0x177718,port:_0x4491a9}=Ff(_0x38a314),_0x35b9d8=_0x4491a9===null?'':':'+_0x4491a9,_0x782367={'url':_0x31b242+'//'+_0x177718+_0x35b9d8+'/'},_0x40a01b=Object['freeze']({'host':_0x177718,'port':_0x4491a9,'protocol':_0x31b242['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5c39ab})});if(!_0x14bef3['_canInitEmulator']){m(_0x14bef3['config']['emulator']&&_0x14bef3['emulatorConfig'],_0x14bef3,'emulator-config-failed'),m(De(_0x782367,_0x14bef3['config']['emulator'])&&De(_0x40a01b,_0x14bef3['emulatorConfig']),_0x14bef3,'emulator-config-failed');return;}_0x14bef3['config']['emulator']=_0x782367,_0x14bef3['emulatorConfig']=_0x40a01b,_0x14bef3['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x177718)?jr(_0x31b242+'//'+_0x177718+_0x35b9d8):Uf();}function La(_0x3ef680){const _0x2a8472=_0x3ef680['indexOf'](':');return _0x2a8472<0x0?'':_0x3ef680['substr'](0x0,_0x2a8472+0x1);}function Ff(_0x2acab4){const _0x3240c3=La(_0x2acab4),_0x42d9f2=/(\/\/)?([^?#/]+)/['exec'](_0x2acab4['substr'](_0x3240c3['length']));if(!_0x42d9f2)return{'host':'','port':null};const _0x4181e3=_0x42d9f2[0x2]['split']('@')['pop']()||'',_0x4fb656=/^(\[[^\]]+\])(:|$)/['exec'](_0x4181e3);if(_0x4fb656){const _0x4fcaae=_0x4fb656[0x1];return{'host':_0x4fcaae,'port':Rr(_0x4181e3['substr'](_0x4fcaae['length']+0x1))};}else{const [_0x57535e,_0x1cbbad]=_0x4181e3['split'](':');return{'host':_0x57535e,'port':Rr(_0x1cbbad)};}}function Rr(_0x37d5d0){if(!_0x37d5d0)return null;const _0x1ceade=Number(_0x37d5d0);return isNaN(_0x1ceade)?null:_0x1ceade;}function Uf(){function _0x572158(){const _0x198bde=document['createElement']('p'),_0x4956df=_0x198bde['style'];_0x198bde['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4956df['position']='fixed',_0x4956df['width']='100%',_0x4956df['backgroundColor']='#ffffff',_0x4956df['border']='.1em\x20solid\x20#000000',_0x4956df['color']='#b50000',_0x4956df['bottom']='0px',_0x4956df['left']='0px',_0x4956df['margin']='0px',_0x4956df['zIndex']='10000',_0x4956df['textAlign']='center',_0x198bde['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x198bde);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x572158):_0x572158());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x562325,_0x516074){this['providerId']=_0x562325,this['signInMethod']=_0x516074;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3c8eaf){return te('not\x20implemented');}['_linkToIdToken'](_0x2dfce9,_0x151be0){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x218ffa){return te('not\x20implemented');}}async function Wf(_0x304e12,_0x24b1b9){return Ae(_0x304e12,'POST','/v1/accounts:signUp',_0x24b1b9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x2c54f8,_0xc14118){return Yt(_0x2c54f8,'POST','/v1/accounts:signInWithPassword',Re(_0x2c54f8,_0xc14118));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x468ac2,_0x28a72d){return Yt(_0x468ac2,'POST','/v1/accounts:signInWithEmailLink',Re(_0x468ac2,_0x28a72d));}async function Hf(_0x187aa4,_0xda5b0f){return Yt(_0x187aa4,'POST','/v1/accounts:signInWithEmailLink',Re(_0x187aa4,_0xda5b0f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x28d4a4,_0x2899f3,_0x453eb3,_0x2a2105=null){super('password',_0x453eb3),this['_email']=_0x28d4a4,this['_password']=_0x2899f3,this['_tenantId']=_0x2a2105;}static['_fromEmailAndPassword'](_0x2f8135,_0x39ffa5){return new Ft(_0x2f8135,_0x39ffa5,'password');}static['_fromEmailAndCode'](_0x15825d,_0x49057e,_0x282111=null){return new Ft(_0x15825d,_0x49057e,'emailLink',_0x282111);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5de27b){const _0x3f1a7a=typeof _0x5de27b=='string'?JSON['parse'](_0x5de27b):_0x5de27b;if(_0x3f1a7a!=null&&_0x3f1a7a['email']&&(_0x3f1a7a!=null&&_0x3f1a7a['password'])){if(_0x3f1a7a['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3f1a7a['email'],_0x3f1a7a['password']);if(_0x3f1a7a['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3f1a7a['email'],_0x3f1a7a['password'],_0x3f1a7a['tenantId']);}return null;}async['_getIdTokenResponse'](_0x58ae69){switch(this['signInMethod']){case'password':const _0x39f14f={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x58ae69,_0x39f14f,'signInWithPassword',Bf);case'emailLink':return Vf(_0x58ae69,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x58ae69,'internal-error');}}async['_linkToIdToken'](_0x476577,_0x419d29){switch(this['signInMethod']){case'password':const _0x24bce2={'idToken':_0x419d29,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x476577,_0x24bce2,'signUpPassword',Wf);case'emailLink':return Hf(_0x476577,{'idToken':_0x419d29,'email':this['_email'],'oobCode':this['_password']});default:K(_0x476577,'internal-error');}}['_getReauthenticationResolver'](_0x3c2935){return this['_getIdTokenResponse'](_0x3c2935);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x243177,_0x3fafde){return Yt(_0x243177,'POST','/v1/accounts:signInWithIdp',Re(_0x243177,_0x3fafde));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5a0db){const _0x6fff22=new We(_0x5a0db['providerId'],_0x5a0db['signInMethod']);return _0x5a0db['idToken']||_0x5a0db['accessToken']?(_0x5a0db['idToken']&&(_0x6fff22['idToken']=_0x5a0db['idToken']),_0x5a0db['accessToken']&&(_0x6fff22['accessToken']=_0x5a0db['accessToken']),_0x5a0db['nonce']&&!_0x5a0db['pendingToken']&&(_0x6fff22['nonce']=_0x5a0db['nonce']),_0x5a0db['pendingToken']&&(_0x6fff22['pendingToken']=_0x5a0db['pendingToken'])):_0x5a0db['oauthToken']&&_0x5a0db['oauthTokenSecret']?(_0x6fff22['accessToken']=_0x5a0db['oauthToken'],_0x6fff22['secret']=_0x5a0db['oauthTokenSecret']):K('argument-error'),_0x6fff22;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5aee6a){const _0x177388=typeof _0x5aee6a=='string'?JSON['parse'](_0x5aee6a):_0x5aee6a,{providerId:_0x1d5f85,signInMethod:_0x28ac41,..._0x474f01}=_0x177388;if(!_0x1d5f85||!_0x28ac41)return null;const _0x1e48f2=new We(_0x1d5f85,_0x28ac41);return _0x1e48f2['idToken']=_0x474f01['idToken']||void 0x0,_0x1e48f2['accessToken']=_0x474f01['accessToken']||void 0x0,_0x1e48f2['secret']=_0x474f01['secret'],_0x1e48f2['nonce']=_0x474f01['nonce'],_0x1e48f2['pendingToken']=_0x474f01['pendingToken']||null,_0x1e48f2;}['_getIdTokenResponse'](_0xebda03){const _0x1d7545=this['buildRequest']();return Ze(_0xebda03,_0x1d7545);}['_linkToIdToken'](_0xbe127d,_0x2bbbd0){const _0x29b966=this['buildRequest']();return _0x29b966['idToken']=_0x2bbbd0,Ze(_0xbe127d,_0x29b966);}['_getReauthenticationResolver'](_0x264f19){const _0x4c0af9=this['buildRequest']();return _0x4c0af9['autoCreate']=!0x1,Ze(_0x264f19,_0x4c0af9);}['buildRequest'](){const _0x2e2d81={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2e2d81['pendingToken']=this['pendingToken'];else{const _0x54a619={};this['idToken']&&(_0x54a619['id_token']=this['idToken']),this['accessToken']&&(_0x54a619['access_token']=this['accessToken']),this['secret']&&(_0x54a619['oauth_token_secret']=this['secret']),_0x54a619['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x54a619['nonce']=this['nonce']),_0x2e2d81['postBody']=at(_0x54a619);}return _0x2e2d81;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x23b78f){switch(_0x23b78f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x37b20a){const _0x2f5428=yt(vt(_0x37b20a))['link'],_0x14458e=_0x2f5428?yt(vt(_0x2f5428))['deep_link_id']:null,_0x30176d=yt(vt(_0x37b20a))['deep_link_id'];return(_0x30176d?yt(vt(_0x30176d))['link']:null)||_0x30176d||_0x14458e||_0x2f5428||_0x37b20a;}class Ss{constructor(_0x1b9503){const _0x292f90=yt(vt(_0x1b9503)),_0x9309ba=_0x292f90['apiKey']??null,_0x3f61c1=_0x292f90['oobCode']??null,_0x179ab5=Gf(_0x292f90['mode']??null);m(_0x9309ba&&_0x3f61c1&&_0x179ab5,'argument-error'),this['apiKey']=_0x9309ba,this['operation']=_0x179ab5,this['code']=_0x3f61c1,this['continueUrl']=_0x292f90['continueUrl']??null,this['languageCode']=_0x292f90['lang']??null,this['tenantId']=_0x292f90['tenantId']??null;}static['parseLink'](_0x435b20){const _0x282592=qf(_0x435b20);try{return new Ss(_0x282592);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x4bbfc8,_0x426876){return Ft['_fromEmailAndPassword'](_0x4bbfc8,_0x426876);}static['credentialWithLink'](_0x754679,_0x430342){const _0xe1b22e=Ss['parseLink'](_0x430342);return m(_0xe1b22e,'argument-error'),Ft['_fromEmailAndCode'](_0x754679,_0xe1b22e['code'],_0xe1b22e['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0xd30547){this['providerId']=_0xd30547,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x346862){this['defaultLanguageCode']=_0x346862;}['setCustomParameters'](_0x4c13f4){return this['customParameters']=_0x4c13f4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5d6ef5){return this['scopes']['includes'](_0x5d6ef5)||this['scopes']['push'](_0x5d6ef5),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x2071be){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2071be});}static['credentialFromResult'](_0x5a53a0){return he['credentialFromTaggedObject'](_0x5a53a0);}static['credentialFromError'](_0xd43de4){return he['credentialFromTaggedObject'](_0xd43de4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x14e6a4}){if(!_0x14e6a4||!('oauthAccessToken'in _0x14e6a4)||!_0x14e6a4['oauthAccessToken'])return null;try{return he['credential'](_0x14e6a4['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xeaa091,_0x1087b4){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xeaa091,'accessToken':_0x1087b4});}static['credentialFromResult'](_0x46e79b){return ue['credentialFromTaggedObject'](_0x46e79b);}static['credentialFromError'](_0x51aba2){return ue['credentialFromTaggedObject'](_0x51aba2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x51753b}){if(!_0x51753b)return null;const {oauthIdToken:_0x189627,oauthAccessToken:_0xf7e2ab}=_0x51753b;if(!_0x189627&&!_0xf7e2ab)return null;try{return ue['credential'](_0x189627,_0xf7e2ab);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x3dabe3){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3dabe3});}static['credentialFromResult'](_0x3eb895){return de['credentialFromTaggedObject'](_0x3eb895);}static['credentialFromError'](_0x34b609){return de['credentialFromTaggedObject'](_0x34b609['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x19c9a3}){if(!_0x19c9a3||!('oauthAccessToken'in _0x19c9a3)||!_0x19c9a3['oauthAccessToken'])return null;try{return de['credential'](_0x19c9a3['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x4e331a,_0x14ed56){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4e331a,'oauthTokenSecret':_0x14ed56});}static['credentialFromResult'](_0x4722ca){return fe['credentialFromTaggedObject'](_0x4722ca);}static['credentialFromError'](_0x3c26b6){return fe['credentialFromTaggedObject'](_0x3c26b6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4af4ed}){if(!_0x4af4ed)return null;const {oauthAccessToken:_0x1551d2,oauthTokenSecret:_0xf13cda}=_0x4af4ed;if(!_0x1551d2||!_0xf13cda)return null;try{return fe['credential'](_0x1551d2,_0xf13cda);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3b7904,_0x4bc96a){return Yt(_0x3b7904,'POST','/v1/accounts:signUp',Re(_0x3b7904,_0x4bc96a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x540361){this['user']=_0x540361['user'],this['providerId']=_0x540361['providerId'],this['_tokenResponse']=_0x540361['_tokenResponse'],this['operationType']=_0x540361['operationType'];}static async['_fromIdTokenResponse'](_0x58b36a,_0x1d0ab2,_0x234845,_0x58e926=!0x1){const _0x352841=await z['_fromIdTokenResponse'](_0x58b36a,_0x234845,_0x58e926),_0x40723b=Ar(_0x234845);return new Be({'user':_0x352841,'providerId':_0x40723b,'_tokenResponse':_0x234845,'operationType':_0x1d0ab2});}static async['_forOperation'](_0x4f2c42,_0xd50ad3,_0x2a5efd){await _0x4f2c42['_updateTokensIfNecessary'](_0x2a5efd,!0x0);const _0x51dddc=Ar(_0x2a5efd);return new Be({'user':_0x4f2c42,'providerId':_0x51dddc,'_tokenResponse':_0x2a5efd,'operationType':_0xd50ad3});}}function Ar(_0x3a6f4f){return _0x3a6f4f['providerId']?_0x3a6f4f['providerId']:'phoneNumber'in _0x3a6f4f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x3093dc,_0x14de57,_0x3f6802,_0x48cc69){super(_0x14de57['code'],_0x14de57['message']),this['operationType']=_0x3f6802,this['user']=_0x48cc69,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x3093dc['name'],'tenantId':_0x3093dc['tenantId']??void 0x0,'_serverResponse':_0x14de57['customData']['_serverResponse'],'operationType':_0x3f6802};}static['_fromErrorAndOperation'](_0x478a25,_0x55c86a,_0x330ae3,_0x4c89d1){return new Rn(_0x478a25,_0x55c86a,_0x330ae3,_0x4c89d1);}}function Fa(_0x168d8f,_0x22be5f,_0x322fc2,_0x521b5a){return(_0x22be5f==='reauthenticate'?_0x322fc2['_getReauthenticationResolver'](_0x168d8f):_0x322fc2['_getIdTokenResponse'](_0x168d8f))['catch'](_0xaa6ed6=>{throw _0xaa6ed6['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x168d8f,_0xaa6ed6,_0x22be5f,_0x521b5a):_0xaa6ed6;});}async function jf(_0x3351b2,_0x8eaaa,_0x1dd05e=!0x1){const _0x46ba31=await xt(_0x3351b2,_0x8eaaa['_linkToIdToken'](_0x3351b2['auth'],await _0x3351b2['getIdToken']()),_0x1dd05e);return Be['_forOperation'](_0x3351b2,'link',_0x46ba31);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x53a5ef,_0x2ba312,_0x5bfd7e=!0x1){const {auth:_0x2936e6}=_0x53a5ef;if(H(_0x2936e6['app']))return Promise['reject'](se(_0x2936e6));const _0x40ec05='reauthenticate';try{const _0x2d9f6e=await xt(_0x53a5ef,Fa(_0x2936e6,_0x40ec05,_0x2ba312,_0x53a5ef),_0x5bfd7e);m(_0x2d9f6e['idToken'],_0x2936e6,'internal-error');const _0x447f15=ws(_0x2d9f6e['idToken']);m(_0x447f15,_0x2936e6,'internal-error');const {sub:_0x19be41}=_0x447f15;return m(_0x53a5ef['uid']===_0x19be41,_0x2936e6,'user-mismatch'),Be['_forOperation'](_0x53a5ef,_0x40ec05,_0x2d9f6e);}catch(_0x54b189){throw(_0x54b189==null?void 0x0:_0x54b189['code'])==='auth/user-not-found'&&K(_0x2936e6,'user-mismatch'),_0x54b189;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x482d09,_0x6aaca4,_0x1f0a67=!0x1){if(H(_0x482d09['app']))return Promise['reject'](se(_0x482d09));const _0x81c090='signIn',_0x2e2ce1=await Fa(_0x482d09,_0x81c090,_0x6aaca4),_0x1e3b04=await Be['_fromIdTokenResponse'](_0x482d09,_0x81c090,_0x2e2ce1);return _0x1f0a67||await _0x482d09['_updateCurrentUser'](_0x1e3b04['user']),_0x1e3b04;}async function Yf(_0x10a4ed,_0x5c1fc0){return Ua(qe(_0x10a4ed),_0x5c1fc0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2ef79f){const _0x509750=qe(_0x2ef79f);_0x509750['_getPasswordPolicyInternal']()&&await _0x509750['_updatePasswordPolicy']();}async function R_(_0x30d7ca,_0x513fa5,_0x2a4c90){if(H(_0x30d7ca['app']))return Promise['reject'](se(_0x30d7ca));const _0x2e2e54=qe(_0x30d7ca),_0x26e966=await Oi(_0x2e2e54,{'returnSecureToken':!0x0,'email':_0x513fa5,'password':_0x2a4c90,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x12c30a=>{throw _0x12c30a['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x30d7ca),_0x12c30a;}),_0x46e6f0=await Be['_fromIdTokenResponse'](_0x2e2e54,'signIn',_0x26e966);return await _0x2e2e54['_updateCurrentUser'](_0x46e6f0['user']),_0x46e6f0;}function A_(_0x553e24,_0xa6e3f6,_0x340f8f){return H(_0x553e24['app'])?Promise['reject'](se(_0x553e24)):Yf(k(_0x553e24),ft['credential'](_0xa6e3f6,_0x340f8f))['catch'](async _0x2136da=>{throw _0x2136da['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x553e24),_0x2136da;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x8a900b,_0x2a4790){return k(_0x8a900b)['setPersistence'](_0x2a4790);}function Qf(_0x4e83cd,_0x27c471,_0x394a81,_0xcdc935){return k(_0x4e83cd)['onIdTokenChanged'](_0x27c471,_0x394a81,_0xcdc935);}function Jf(_0x17896b,_0x4dc524,_0x1f7203){return k(_0x17896b)['beforeAuthStateChanged'](_0x4dc524,_0x1f7203);}function N_(_0x330188,_0x551ae4,_0x187df1,_0x30784a){return k(_0x330188)['onAuthStateChanged'](_0x551ae4,_0x187df1,_0x30784a);}function P_(_0x4c09dc){return k(_0x4c09dc)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x298173,_0x53ac23){this['storageRetriever']=_0x298173,this['type']=_0x53ac23;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2087ec,_0x3a69e7){return this['storage']['setItem'](_0x2087ec,JSON['stringify'](_0x3a69e7)),Promise['resolve']();}['_get'](_0x10bfd5){const _0x5baf65=this['storage']['getItem'](_0x10bfd5);return Promise['resolve'](_0x5baf65?JSON['parse'](_0x5baf65):null);}['_remove'](_0x437f4f){return this['storage']['removeItem'](_0x437f4f),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x511687,_0xeafe87)=>this['onStorageEvent'](_0x511687,_0xeafe87),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4ef5f7){for(const _0x3ea65e of Object['keys'](this['listeners'])){const _0x41ca0b=this['storage']['getItem'](_0x3ea65e),_0x3d77ab=this['localCache'][_0x3ea65e];_0x41ca0b!==_0x3d77ab&&_0x4ef5f7(_0x3ea65e,_0x3d77ab,_0x41ca0b);}}['onStorageEvent'](_0x44a3e5,_0x441c40=!0x1){if(!_0x44a3e5['key']){this['forAllChangedKeys']((_0x54660b,_0x5e9b55,_0x18f4ee)=>{this['notifyListeners'](_0x54660b,_0x18f4ee);});return;}const _0x53c416=_0x44a3e5['key'];_0x441c40?this['detachListener']():this['stopPolling']();const _0x1dc8dc=()=>{const _0x441e80=this['storage']['getItem'](_0x53c416);!_0x441c40&&this['localCache'][_0x53c416]===_0x441e80||this['notifyListeners'](_0x53c416,_0x441e80);},_0x5ee643=this['storage']['getItem'](_0x53c416);If()&&_0x5ee643!==_0x44a3e5['newValue']&&_0x44a3e5['newValue']!==_0x44a3e5['oldValue']?setTimeout(_0x1dc8dc,Zf):_0x1dc8dc();}['notifyListeners'](_0x5bc12d,_0x474cb4){this['localCache'][_0x5bc12d]=_0x474cb4;const _0x4c7118=this['listeners'][_0x5bc12d];if(_0x4c7118){for(const _0x29ce45 of Array['from'](_0x4c7118))_0x29ce45(_0x474cb4&&JSON['parse'](_0x474cb4));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x475e99,_0x25357f,_0x2c5197)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x475e99,'oldValue':_0x25357f,'newValue':_0x2c5197}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x785bbc,_0x3565ec){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x785bbc]||(this['listeners'][_0x785bbc]=new Set(),this['localCache'][_0x785bbc]=this['storage']['getItem'](_0x785bbc)),this['listeners'][_0x785bbc]['add'](_0x3565ec);}['_removeListener'](_0x360084,_0x3d8e4c){this['listeners'][_0x360084]&&(this['listeners'][_0x360084]['delete'](_0x3d8e4c),this['listeners'][_0x360084]['size']===0x0&&delete this['listeners'][_0x360084]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x517c6b,_0x1ab527){await super['_set'](_0x517c6b,_0x1ab527),this['localCache'][_0x517c6b]=JSON['stringify'](_0x1ab527);}async['_get'](_0x221343){const _0xfee990=await super['_get'](_0x221343);return this['localCache'][_0x221343]=JSON['stringify'](_0xfee990),_0xfee990;}async['_remove'](_0x42144f){await super['_remove'](_0x42144f),delete this['localCache'][_0x42144f];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x569344,_0x24372d){}['_removeListener'](_0x19197e,_0x2afdc2){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x3c45c0){return Promise['all'](_0x3c45c0['map'](async _0x36e977=>{try{return{'fulfilled':!0x0,'value':await _0x36e977};}catch(_0x73f27a){return{'fulfilled':!0x1,'reason':_0x73f27a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x36e911){this['eventTarget']=_0x36e911,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xad53d1){const _0x1d837a=this['receivers']['find'](_0x24c89f=>_0x24c89f['isListeningto'](_0xad53d1));if(_0x1d837a)return _0x1d837a;const _0xaea93a=new jn(_0xad53d1);return this['receivers']['push'](_0xaea93a),_0xaea93a;}['isListeningto'](_0x31e8d7){return this['eventTarget']===_0x31e8d7;}async['handleEvent'](_0x47aa86){const _0x58731c=_0x47aa86,{eventId:_0x4aed8e,eventType:_0x5970ed,data:_0x59f218}=_0x58731c['data'],_0xdb3ed2=this['handlersMap'][_0x5970ed];if(!(_0xdb3ed2!=null&&_0xdb3ed2['size']))return;_0x58731c['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4aed8e,'eventType':_0x5970ed});const _0x20f692=Array['from'](_0xdb3ed2)['map'](async _0x1f4ebf=>_0x1f4ebf(_0x58731c['origin'],_0x59f218)),_0x2b197c=await tp(_0x20f692);_0x58731c['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4aed8e,'eventType':_0x5970ed,'response':_0x2b197c});}['_subscribe'](_0x2776ac,_0x4ea5dd){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2776ac]||(this['handlersMap'][_0x2776ac]=new Set()),this['handlersMap'][_0x2776ac]['add'](_0x4ea5dd);}['_unsubscribe'](_0x1ccfb2,_0x11b173){this['handlersMap'][_0x1ccfb2]&&_0x11b173&&this['handlersMap'][_0x1ccfb2]['delete'](_0x11b173),(!_0x11b173||this['handlersMap'][_0x1ccfb2]['size']===0x0)&&delete this['handlersMap'][_0x1ccfb2],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4f88f8='',_0x1b7071=0xa){let _0x253f6c='';for(let _0xaea581=0x0;_0xaea581<_0x1b7071;_0xaea581++)_0x253f6c+=Math['floor'](Math['random']()*0xa);return _0x4f88f8+_0x253f6c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x2c1065){this['target']=_0x2c1065,this['handlers']=new Set();}['removeMessageHandler'](_0x32c7ab){_0x32c7ab['messageChannel']&&(_0x32c7ab['messageChannel']['port1']['removeEventListener']('message',_0x32c7ab['onMessage']),_0x32c7ab['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x32c7ab);}async['_send'](_0x492111,_0x4cdb9d,_0x4b5f04=0x32){const _0x30820a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x30820a)throw new Error('connection_unavailable');let _0x2777e8,_0x47fe73;return new Promise((_0x5ecfe3,_0x3e32ab)=>{const _0x5bc83a=bs('',0x14);_0x30820a['port1']['start']();const _0x4c385c=setTimeout(()=>{_0x3e32ab(new Error('unsupported_event'));},_0x4b5f04);_0x47fe73={'messageChannel':_0x30820a,'onMessage'(_0x17ec77){const _0x368fc2=_0x17ec77;if(_0x368fc2['data']['eventId']===_0x5bc83a)switch(_0x368fc2['data']['status']){case'ack':clearTimeout(_0x4c385c),_0x2777e8=setTimeout(()=>{_0x3e32ab(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2777e8),_0x5ecfe3(_0x368fc2['data']['response']);break;default:clearTimeout(_0x4c385c),clearTimeout(_0x2777e8),_0x3e32ab(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x47fe73),_0x30820a['port1']['addEventListener']('message',_0x47fe73['onMessage']),this['target']['postMessage']({'eventType':_0x492111,'eventId':_0x5bc83a,'data':_0x4cdb9d},[_0x30820a['port2']]);})['finally'](()=>{_0x47fe73&&this['removeMessageHandler'](_0x47fe73);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x7546c4){X()['location']['href']=_0x7546c4;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x5b26e6;return((_0x5b26e6=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5b26e6['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x21f943){this['request']=_0x21f943;}['toPromise'](){return new Promise((_0x4e6d2a,_0xa637db)=>{this['request']['addEventListener']('success',()=>{_0x4e6d2a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xa637db(this['request']['error']);});});}}function Kn(_0x5dff3e,_0x23fc92){return _0x5dff3e['transaction']([kn],_0x23fc92?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3742c6=indexedDB['deleteDatabase'](qa);return new Jt(_0x3742c6)['toPromise']();}function ja(){const _0x132704=indexedDB['open'](qa,ap);return new Promise((_0x2a6c1d,_0x34f4e0)=>{_0x132704['addEventListener']('error',()=>{_0x34f4e0(_0x132704['error']);}),_0x132704['addEventListener']('upgradeneeded',()=>{const _0x4cb87d=_0x132704['result'];try{_0x4cb87d['createObjectStore'](kn,{'keyPath':za});}catch(_0x5cde9e){_0x34f4e0(_0x5cde9e);}}),_0x132704['addEventListener']('success',async()=>{const _0x25393c=_0x132704['result'];_0x25393c['objectStoreNames']['contains'](kn)?_0x2a6c1d(_0x25393c):(_0x25393c['close'](),await cp(),_0x2a6c1d(await ja()));});});}async function kr(_0x2acc4d,_0x4b59cf,_0x48c8c7){const _0xe253aa=Kn(_0x2acc4d,!0x0)['put']({[za]:_0x4b59cf,'value':_0x48c8c7});return new Jt(_0xe253aa)['toPromise']();}async function lp(_0x3757b5,_0x477b87){const _0x1a310f=Kn(_0x3757b5,!0x1)['get'](_0x477b87),_0x264b5c=await new Jt(_0x1a310f)['toPromise']();return _0x264b5c===void 0x0?null:_0x264b5c['value'];}function Nr(_0x34ef68,_0x3347bc){const _0x5b26cd=Kn(_0x34ef68,!0x0)['delete'](_0x3347bc);return new Jt(_0x5b26cd)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x50d422){let _0x171f46=0x0;for(;;)try{const _0x244702=await this['_openDb']();return await _0x50d422(_0x244702);}catch(_0x2b5ae7){if(_0x171f46++>up)throw _0x2b5ae7;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x3833e5,_0x3c84dc)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3c84dc['key'])})),this['receiver']['_subscribe']('ping',async(_0x13ffb3,_0xd31b0)=>['keyChanged']);}async['initializeSender'](){var _0x83f452,_0x38f6c2;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x45d8cc=await this['sender']['_send']('ping',{},0x320);_0x45d8cc&&(_0x83f452=_0x45d8cc[0x0])!=null&&_0x83f452['fulfilled']&&(_0x38f6c2=_0x45d8cc[0x0])!=null&&_0x38f6c2['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x328806){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x328806},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x43096d=>{await kr(_0x43096d,An,'1'),await Nr(_0x43096d,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5b1746){this['pendingWrites']++;try{await _0x5b1746();}finally{this['pendingWrites']--;}}async['_set'](_0x239b96,_0x393d35){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3e33a1=>kr(_0x3e33a1,_0x239b96,_0x393d35)),this['localCache'][_0x239b96]=_0x393d35,this['notifyServiceWorker'](_0x239b96)));}async['_get'](_0x4bce96){const _0xf513af=await this['_withRetries'](_0x376902=>lp(_0x376902,_0x4bce96));return this['localCache'][_0x4bce96]=_0xf513af,_0xf513af;}async['_remove'](_0x53dbd2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x210a10=>Nr(_0x210a10,_0x53dbd2)),delete this['localCache'][_0x53dbd2],this['notifyServiceWorker'](_0x53dbd2)));}async['_poll'](){const _0x39779d=await this['_withRetries'](_0x43b4ab=>{const _0x1e1920=Kn(_0x43b4ab,!0x1)['getAll']();return new Jt(_0x1e1920)['toPromise']();});if(!_0x39779d)return[];if(this['pendingWrites']!==0x0)return[];const _0x50800e=[],_0x14ea3e=new Set();if(_0x39779d['length']!==0x0){for(const {fbase_key:_0x4d78dd,value:_0x54d942}of _0x39779d)_0x14ea3e['add'](_0x4d78dd),JSON['stringify'](this['localCache'][_0x4d78dd])!==JSON['stringify'](_0x54d942)&&(this['notifyListeners'](_0x4d78dd,_0x54d942),_0x50800e['push'](_0x4d78dd));}for(const _0x233a58 of Object['keys'](this['localCache']))this['localCache'][_0x233a58]&&!_0x14ea3e['has'](_0x233a58)&&(this['notifyListeners'](_0x233a58,null),_0x50800e['push'](_0x233a58));return _0x50800e;}['notifyListeners'](_0x1377f5,_0x54ca36){this['localCache'][_0x1377f5]=_0x54ca36;const _0xb44e19=this['listeners'][_0x1377f5];if(_0xb44e19){for(const _0x2bda80 of Array['from'](_0xb44e19))_0x2bda80(_0x54ca36);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x37a013,_0x286388){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x37a013]||(this['listeners'][_0x37a013]=new Set(),this['_get'](_0x37a013)),this['listeners'][_0x37a013]['add'](_0x286388);}['_removeListener'](_0x26dc99,_0x46ac57){this['listeners'][_0x26dc99]&&(this['listeners'][_0x26dc99]['delete'](_0x46ac57),this['listeners'][_0x26dc99]['size']===0x0&&delete this['listeners'][_0x26dc99]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x3ea36c,_0x19ecf4){return _0x19ecf4?ne(_0x19ecf4):(m(_0x3ea36c['_popupRedirectResolver'],_0x3ea36c,'argument-error'),_0x3ea36c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x2798ad){super('custom','custom'),this['params']=_0x2798ad;}['_getIdTokenResponse'](_0x17d643){return Ze(_0x17d643,this['_buildIdpRequest']());}['_linkToIdToken'](_0x255f57,_0x55fc70){return Ze(_0x255f57,this['_buildIdpRequest'](_0x55fc70));}['_getReauthenticationResolver'](_0x3e3a93){return Ze(_0x3e3a93,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3c5dc2){const _0x475ab1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3c5dc2&&(_0x475ab1['idToken']=_0x3c5dc2),_0x475ab1;}}function pp(_0x45f1c6){return Ua(_0x45f1c6['auth'],new Rs(_0x45f1c6),_0x45f1c6['bypassAuthState']);}function _p(_0x183797){const {auth:_0x150ed6,user:_0x41a74e}=_0x183797;return m(_0x41a74e,_0x150ed6,'internal-error'),Kf(_0x41a74e,new Rs(_0x183797),_0x183797['bypassAuthState']);}async function gp(_0x3fe82d){const {auth:_0x2eb959,user:_0x43ba3a}=_0x3fe82d;return m(_0x43ba3a,_0x2eb959,'internal-error'),jf(_0x43ba3a,new Rs(_0x3fe82d),_0x3fe82d['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x57f403,_0x48c717,_0x296f7f,_0x433207,_0x43a3a5=!0x1){this['auth']=_0x57f403,this['resolver']=_0x296f7f,this['user']=_0x433207,this['bypassAuthState']=_0x43a3a5,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x48c717)?_0x48c717:[_0x48c717];}['execute'](){return new Promise(async(_0x2924f1,_0x3fa931)=>{this['pendingPromise']={'resolve':_0x2924f1,'reject':_0x3fa931};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4d5314){this['reject'](_0x4d5314);}});}async['onAuthEvent'](_0xaa0ec8){const {urlResponse:_0x5d8f51,sessionId:_0x36c372,postBody:_0xe8b161,tenantId:_0x48f6ae,error:_0xddd218,type:_0x21ca70}=_0xaa0ec8;if(_0xddd218){this['reject'](_0xddd218);return;}const _0x3fb9f6={'auth':this['auth'],'requestUri':_0x5d8f51,'sessionId':_0x36c372,'tenantId':_0x48f6ae||void 0x0,'postBody':_0xe8b161||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x21ca70)(_0x3fb9f6));}catch(_0x1e7e17){this['reject'](_0x1e7e17);}}['onError'](_0x1bdd04){this['reject'](_0x1bdd04);}['getIdpTask'](_0x2d6ab9){switch(_0x2d6ab9){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x29474c){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x29474c),this['unregisterAndCleanUp']();}['reject'](_0x337b96){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x337b96),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1b4d4a,_0x1deaa1,_0x1d0bde,_0x4bf243,_0x2d1751){super(_0x1b4d4a,_0x1deaa1,_0x4bf243,_0x2d1751),this['provider']=_0x1d0bde,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x530668=await this['execute']();return m(_0x530668,this['auth'],'internal-error'),_0x530668;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4b8b28=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4b8b28),this['authWindow']['associatedEvent']=_0x4b8b28,this['resolver']['_originValidation'](this['auth'])['catch'](_0x170556=>{this['reject'](_0x170556);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0xf5aa52=>{_0xf5aa52||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x411193;return((_0x411193=this['authWindow'])==null?void 0x0:_0x411193['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0xf38abd=()=>{var _0x123439,_0x354cd1;if((_0x354cd1=(_0x123439=this['authWindow'])==null?void 0x0:_0x123439['window'])!=null&&_0x354cd1['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xf38abd,mp['get']());};_0xf38abd();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x3daf0a,_0x4895f5,_0x135db8=!0x1){super(_0x3daf0a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4895f5,void 0x0,_0x135db8),this['eventId']=null;}async['execute'](){let _0x1ae652=rn['get'](this['auth']['_key']());if(!_0x1ae652){try{const _0x4af36a=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x1ae652=()=>Promise['resolve'](_0x4af36a);}catch(_0xa9d371){_0x1ae652=()=>Promise['reject'](_0xa9d371);}rn['set'](this['auth']['_key'](),_0x1ae652);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1ae652();}async['onAuthEvent'](_0x2817b0){if(_0x2817b0['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2817b0);if(_0x2817b0['type']==='unknown'){this['resolve'](null);return;}if(_0x2817b0['eventId']){const _0x14b226=await this['auth']['_redirectUserForId'](_0x2817b0['eventId']);if(_0x14b226)return this['user']=_0x14b226,super['onAuthEvent'](_0x2817b0);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x3db1db,_0xf82869){const _0x1b35f3=Cp(_0xf82869),_0x219655=wp(_0x3db1db);if(!await _0x219655['_isAvailable']())return!0x1;const _0x596b12=await _0x219655['_get'](_0x1b35f3)==='true';return await _0x219655['_remove'](_0x1b35f3),_0x596b12;}function Ip(_0x4b2bf5,_0x1889c8){rn['set'](_0x4b2bf5['_key'](),_0x1889c8);}function wp(_0x4558c1){return ne(_0x4558c1['_redirectPersistence']);}function Cp(_0x5405f8){return sn(yp,_0x5405f8['config']['apiKey'],_0x5405f8['name']);}async function Tp(_0x4a4035,_0x4d23bd,_0x14d7ff=!0x1){if(H(_0x4a4035['app']))return Promise['reject'](se(_0x4a4035));const _0x4dcbb6=qe(_0x4a4035),_0x2889d4=fp(_0x4dcbb6,_0x4d23bd),_0x5dd9fe=await new vp(_0x4dcbb6,_0x2889d4,_0x14d7ff)['execute']();return _0x5dd9fe&&!_0x14d7ff&&(delete _0x5dd9fe['user']['_redirectEventId'],await _0x4dcbb6['_persistUserIfCurrent'](_0x5dd9fe['user']),await _0x4dcbb6['_setRedirectUser'](null,_0x4d23bd)),_0x5dd9fe;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x22c5ee){this['auth']=_0x22c5ee,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x19ba7c){this['consumers']['add'](_0x19ba7c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x19ba7c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x19ba7c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x282ce6){this['consumers']['delete'](_0x282ce6);}['onEvent'](_0x5817eb){if(this['hasEventBeenHandled'](_0x5817eb))return!0x1;let _0x3b02ce=!0x1;return this['consumers']['forEach'](_0x6e5a60=>{this['isEventForConsumer'](_0x5817eb,_0x6e5a60)&&(_0x3b02ce=!0x0,this['sendToConsumer'](_0x5817eb,_0x6e5a60),this['saveEventToCache'](_0x5817eb));}),this['hasHandledPotentialRedirect']||!Rp(_0x5817eb)||(this['hasHandledPotentialRedirect']=!0x0,_0x3b02ce||(this['queuedRedirectEvent']=_0x5817eb,_0x3b02ce=!0x0)),_0x3b02ce;}['sendToConsumer'](_0x5dd8a1,_0x17afd6){var _0x27faa8;if(_0x5dd8a1['error']&&!Qa(_0x5dd8a1)){const _0x3d8ecb=((_0x27faa8=_0x5dd8a1['error']['code'])==null?void 0x0:_0x27faa8['split']('auth/')[0x1])||'internal-error';_0x17afd6['onError'](J(this['auth'],_0x3d8ecb));}else _0x17afd6['onAuthEvent'](_0x5dd8a1);}['isEventForConsumer'](_0x3b15bf,_0x3cf484){const _0x2edfde=_0x3cf484['eventId']===null||!!_0x3b15bf['eventId']&&_0x3b15bf['eventId']===_0x3cf484['eventId'];return _0x3cf484['filter']['includes'](_0x3b15bf['type'])&&_0x2edfde;}['hasEventBeenHandled'](_0x415a00){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x415a00));}['saveEventToCache'](_0x570e6c){this['cachedEventUids']['add'](Pr(_0x570e6c)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0xb986ca){return[_0xb986ca['type'],_0xb986ca['eventId'],_0xb986ca['sessionId'],_0xb986ca['tenantId']]['filter'](_0xb8f15a=>_0xb8f15a)['join']('-');}function Qa({type:_0x5034c1,error:_0x1de71d}){return _0x5034c1==='unknown'&&(_0x1de71d==null?void 0x0:_0x1de71d['code'])==='auth/no-auth-event';}function Rp(_0x3740e2){switch(_0x3740e2['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3740e2);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2af1af,_0x22ec53={}){return Ae(_0x2af1af,'GET','/v1/projects',_0x22ec53);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x4e7bde){if(_0x4e7bde['config']['emulator'])return;const {authorizedDomains:_0x433efb}=await Ap(_0x4e7bde);for(const _0x4bdee1 of _0x433efb)try{if(Op(_0x4bdee1))return;}catch{}K(_0x4e7bde,'unauthorized-domain');}function Op(_0x2ea43f){const _0x57a86c=Ni(),{protocol:_0x47806e,hostname:_0x49745b}=new URL(_0x57a86c);if(_0x2ea43f['startsWith']('chrome-extension://')){const _0xb17b71=new URL(_0x2ea43f);return _0xb17b71['hostname']===''&&_0x49745b===''?_0x47806e==='chrome-extension:'&&_0x2ea43f['replace']('chrome-extension://','')===_0x57a86c['replace']('chrome-extension://',''):_0x47806e==='chrome-extension:'&&_0xb17b71['hostname']===_0x49745b;}if(!Np['test'](_0x47806e))return!0x1;if(kp['test'](_0x2ea43f))return _0x49745b===_0x2ea43f;const _0x5a9a7a=_0x2ea43f['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5a9a7a+'|'+_0x5a9a7a+')$','i')['test'](_0x49745b);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x4a6e3e=X()['___jsl'];if(_0x4a6e3e!=null&&_0x4a6e3e['H']){for(const _0x1791d7 of Object['keys'](_0x4a6e3e['H']))if(_0x4a6e3e['H'][_0x1791d7]['r']=_0x4a6e3e['H'][_0x1791d7]['r']||[],_0x4a6e3e['H'][_0x1791d7]['L']=_0x4a6e3e['H'][_0x1791d7]['L']||[],_0x4a6e3e['H'][_0x1791d7]['r']=[..._0x4a6e3e['H'][_0x1791d7]['L']],_0x4a6e3e['CP']){for(let _0x453f52=0x0;_0x453f52<_0x4a6e3e['CP']['length'];_0x453f52++)_0x4a6e3e['CP'][_0x453f52]=null;}}}function Mp(_0x17a119){return new Promise((_0x38e50f,_0x46d3e7)=>{var _0x1f0634,_0x4b06ac,_0x14b7d2;function _0x2be890(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x38e50f(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x46d3e7(J(_0x17a119,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x4b06ac=(_0x1f0634=X()['gapi'])==null?void 0x0:_0x1f0634['iframes'])!=null&&_0x4b06ac['Iframe'])_0x38e50f(gapi['iframes']['getContext']());else{if((_0x14b7d2=X()['gapi'])!=null&&_0x14b7d2['load'])_0x2be890();else{const _0x4c77a5=Nf('iframefcb');return X()[_0x4c77a5]=()=>{gapi['load']?_0x2be890():_0x46d3e7(J(_0x17a119,'network-request-failed'));},Da(kf()+'?onload='+_0x4c77a5)['catch'](_0x227ba8=>_0x46d3e7(_0x227ba8));}}})['catch'](_0x4ed546=>{throw on=null,_0x4ed546;});}let on=null;function Lp(_0x1ee3b4){return on=on||Mp(_0x1ee3b4),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x59262c){const _0x2fffce=_0x59262c['config'];m(_0x2fffce['authDomain'],_0x59262c,'auth-domain-config-required');const _0xb71646=_0x2fffce['emulator']?Is(_0x2fffce,Up):'https://'+_0x59262c['config']['authDomain']+'/'+Fp,_0x3e8715={'apiKey':_0x2fffce['apiKey'],'appName':_0x59262c['name'],'v':ct},_0x1d1897=Bp['get'](_0x59262c['config']['apiHost']);_0x1d1897&&(_0x3e8715['eid']=_0x1d1897);const _0xe908f7=_0x59262c['_getFrameworks']();return _0xe908f7['length']&&(_0x3e8715['fw']=_0xe908f7['join'](',')),_0xb71646+'?'+at(_0x3e8715)['slice'](0x1);}async function Hp(_0x3207c7){const _0x1e4c5c=await Lp(_0x3207c7),_0x15b8f5=X()['gapi'];return m(_0x15b8f5,_0x3207c7,'internal-error'),_0x1e4c5c['open']({'where':document['body'],'url':Vp(_0x3207c7),'messageHandlersFilter':_0x15b8f5['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x22d537=>new Promise(async(_0x2f9c08,_0x1593bd)=>{await _0x22d537['restyle']({'setHideOnLeave':!0x1});const _0x406c91=J(_0x3207c7,'network-request-failed'),_0x5ee004=X()['setTimeout'](()=>{_0x1593bd(_0x406c91);},xp['get']());function _0x5c083d(){X()['clearTimeout'](_0x5ee004),_0x2f9c08(_0x22d537);}_0x22d537['ping'](_0x5c083d)['then'](_0x5c083d,()=>{_0x1593bd(_0x406c91);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x1b4b20){this['window']=_0x1b4b20,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x502edf,_0x1f871b,_0x23a29b,_0x41aa41=Gp,_0x5eecc4=qp){const _0x3f1dfe=Math['max']((window['screen']['availHeight']-_0x5eecc4)/0x2,0x0)['toString'](),_0x29b59c=Math['max']((window['screen']['availWidth']-_0x41aa41)/0x2,0x0)['toString']();let _0x25468d='';const _0x99a10={...$p,'width':_0x41aa41['toString'](),'height':_0x5eecc4['toString'](),'top':_0x3f1dfe,'left':_0x29b59c},_0x3318b6=W()['toLowerCase']();_0x23a29b&&(_0x25468d=ba(_0x3318b6)?zp:_0x23a29b),Ta(_0x3318b6)&&(_0x1f871b=_0x1f871b||jp,_0x99a10['scrollbars']='yes');const _0x31ee85=Object['entries'](_0x99a10)['reduce']((_0xa196b2,[_0x656562,_0xd02429])=>''+_0xa196b2+_0x656562+'='+_0xd02429+',','');if(Ef(_0x3318b6)&&_0x25468d!=='_self')return Yp(_0x1f871b||'',_0x25468d),new Dr(null);const _0x2a5459=window['open'](_0x1f871b||'',_0x25468d,_0x31ee85);m(_0x2a5459,_0x502edf,'popup-blocked');try{_0x2a5459['focus']();}catch{}return new Dr(_0x2a5459);}function Yp(_0x338f5a,_0x16e551){const _0x56faf5=document['createElement']('a');_0x56faf5['href']=_0x338f5a,_0x56faf5['target']=_0x16e551;const _0x69d9ae=document['createEvent']('MouseEvent');_0x69d9ae['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x56faf5['dispatchEvent'](_0x69d9ae);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2b2238,_0x59c2b1,_0x1be8ca,_0x5e8118,_0x38b12a,_0x3f2fb6){m(_0x2b2238['config']['authDomain'],_0x2b2238,'auth-domain-config-required'),m(_0x2b2238['config']['apiKey'],_0x2b2238,'invalid-api-key');const _0x43778b={'apiKey':_0x2b2238['config']['apiKey'],'appName':_0x2b2238['name'],'authType':_0x1be8ca,'redirectUrl':_0x5e8118,'v':ct,'eventId':_0x38b12a};if(_0x59c2b1 instanceof xa){_0x59c2b1['setDefaultLanguage'](_0x2b2238['languageCode']),_0x43778b['providerId']=_0x59c2b1['providerId']||'',hi(_0x59c2b1['getCustomParameters']())||(_0x43778b['customParameters']=JSON['stringify'](_0x59c2b1['getCustomParameters']()));for(const [_0x109d83,_0x3fd878]of Object['entries']({}))_0x43778b[_0x109d83]=_0x3fd878;}if(_0x59c2b1 instanceof Qt){const _0x2b4237=_0x59c2b1['getScopes']()['filter'](_0x3d150b=>_0x3d150b!=='');_0x2b4237['length']>0x0&&(_0x43778b['scopes']=_0x2b4237['join'](','));}_0x2b2238['tenantId']&&(_0x43778b['tid']=_0x2b2238['tenantId']);const _0x5d5ace=_0x43778b;for(const _0xed4b1e of Object['keys'](_0x5d5ace))_0x5d5ace[_0xed4b1e]===void 0x0&&delete _0x5d5ace[_0xed4b1e];const _0xf87db1=await _0x2b2238['_getAppCheckToken'](),_0x33d8ab=_0xf87db1?'#'+Xp+'='+encodeURIComponent(_0xf87db1):'';return Zp(_0x2b2238)+'?'+at(_0x5d5ace)['slice'](0x1)+_0x33d8ab;}function Zp({config:_0x466348}){return _0x466348['emulator']?Is(_0x466348,Jp):'https://'+_0x466348['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x25f6e1,_0x462201,_0x26f6b4,_0x5c39c0){var _0x2ef56d;ae((_0x2ef56d=this['eventManagers'][_0x25f6e1['_key']()])==null?void 0x0:_0x2ef56d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3a846a=await Mr(_0x25f6e1,_0x462201,_0x26f6b4,Ni(),_0x5c39c0);return Kp(_0x25f6e1,_0x3a846a,bs());}async['_openRedirect'](_0x5c050a,_0x6c52ee,_0x5c48f1,_0x252ac9){await this['_originValidation'](_0x5c050a);const _0x13345a=await Mr(_0x5c050a,_0x6c52ee,_0x5c48f1,Ni(),_0x252ac9);return ip(_0x13345a),new Promise(()=>{});}['_initialize'](_0x4f89d5){const _0x553a43=_0x4f89d5['_key']();if(this['eventManagers'][_0x553a43]){const {manager:_0x3955d4,promise:_0x3b474a}=this['eventManagers'][_0x553a43];return _0x3955d4?Promise['resolve'](_0x3955d4):(ae(_0x3b474a,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3b474a);}const _0x18a489=this['initAndGetManager'](_0x4f89d5);return this['eventManagers'][_0x553a43]={'promise':_0x18a489},_0x18a489['catch'](()=>{delete this['eventManagers'][_0x553a43];}),_0x18a489;}async['initAndGetManager'](_0x369c5e){const _0x443eb7=await Hp(_0x369c5e),_0x4dfb15=new bp(_0x369c5e);return _0x443eb7['register']('authEvent',_0x1ee256=>(m(_0x1ee256==null?void 0x0:_0x1ee256['authEvent'],_0x369c5e,'invalid-auth-event'),{'status':_0x4dfb15['onEvent'](_0x1ee256['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x369c5e['_key']()]={'manager':_0x4dfb15},this['iframes'][_0x369c5e['_key']()]=_0x443eb7,_0x4dfb15;}['_isIframeWebStorageSupported'](_0x3a146f,_0x11d1f1){this['iframes'][_0x3a146f['_key']()]['send'](li,{'type':li},_0x188aae=>{var _0x5cff1f;const _0x588403=(_0x5cff1f=_0x188aae==null?void 0x0:_0x188aae[0x0])==null?void 0x0:_0x5cff1f[li];_0x588403!==void 0x0&&_0x11d1f1(!!_0x588403),K(_0x3a146f,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x445f4b){const _0x4f4c7b=_0x445f4b['_key']();return this['originValidationPromises'][_0x4f4c7b]||(this['originValidationPromises'][_0x4f4c7b]=Pp(_0x445f4b)),this['originValidationPromises'][_0x4f4c7b];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x4a5e71){this['auth']=_0x4a5e71,this['internalListeners']=new Map();}['getUid'](){var _0xad5b09;return this['assertAuthConfigured'](),((_0xad5b09=this['auth']['currentUser'])==null?void 0x0:_0xad5b09['uid'])||null;}async['getToken'](_0x409910){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x409910)}:null;}['addAuthTokenListener'](_0x151e23){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x151e23))return;const _0x193d14=this['auth']['onIdTokenChanged'](_0x25a68a=>{_0x151e23((_0x25a68a==null?void 0x0:_0x25a68a['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x151e23,_0x193d14),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x45ab06){this['assertAuthConfigured']();const _0x5404c1=this['internalListeners']['get'](_0x45ab06);_0x5404c1&&(this['internalListeners']['delete'](_0x45ab06),_0x5404c1(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x30b020){switch(_0x30b020){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x13dd68){et(new Me('auth',(_0x42ee7f,{options:_0x561cc3})=>{const _0x5f29d9=_0x42ee7f['getProvider']('app')['getImmediate'](),_0x3a5c71=_0x42ee7f['getProvider']('heartbeat'),_0x1536f7=_0x42ee7f['getProvider']('app-check-internal'),{apiKey:_0xd79e86,authDomain:_0x45a3fe}=_0x5f29d9['options'];m(_0xd79e86&&!_0xd79e86['includes'](':'),'invalid-api-key',{'appName':_0x5f29d9['name']});const _0xe434c4={'apiKey':_0xd79e86,'authDomain':_0x45a3fe,'clientPlatform':_0x13dd68,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x13dd68)},_0x4fc097=new bf(_0x5f29d9,_0x3a5c71,_0x1536f7,_0xe434c4);return Lf(_0x4fc097,_0x561cc3),_0x4fc097;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x4c8467,_0x57d508,_0x31bb4a)=>{_0x4c8467['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x4eeee0=>{const _0x1e4d55=qe(_0x4eeee0['getProvider']('auth')['getImmediate']());return(_0x1464f2=>new n_(_0x1464f2))(_0x1e4d55);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x13dd68)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x542692=>async _0x5f1d0b=>{const _0x361d6c=_0x5f1d0b&&await _0x5f1d0b['getIdTokenResult'](),_0x274680=_0x361d6c&&(new Date()['getTime']()-Date['parse'](_0x361d6c['issuedAtTime']))/0x3e8;if(_0x274680&&_0x274680>o_)return;const _0x15f154=_0x361d6c==null?void 0x0:_0x361d6c['token'];Fr!==_0x15f154&&(Fr=_0x15f154,await fetch(_0x542692,{'method':_0x15f154?'POST':'DELETE','headers':_0x15f154?{'Authorization':'Bearer\x20'+_0x15f154}:{}}));};function O_(_0x2077b6=Qr()){const _0xf08093=Ui(_0x2077b6,'auth');if(_0xf08093['isInitialized']())return _0xf08093['getImmediate']();const _0x22232d=Mf(_0x2077b6,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x3dac0a=Gr('authTokenSyncURL');if(_0x3dac0a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x34abd7=new URL(_0x3dac0a,location['origin']);if(location['origin']===_0x34abd7['origin']){const _0x4940dc=a_(_0x34abd7['toString']());Jf(_0x22232d,_0x4940dc,()=>_0x4940dc(_0x22232d['currentUser'])),Qf(_0x22232d,_0xa73a6c=>_0x4940dc(_0xa73a6c));}}const _0x43ce5a=Hr('auth');return _0x43ce5a&&xf(_0x22232d,'http://'+_0x43ce5a),_0x22232d;}function c_(){var _0x201516;return((_0x201516=document['getElementsByTagName']('head'))==null?void 0x0:_0x201516[0x0])??document;}Rf({'loadJS'(_0x182d59){return new Promise((_0xeed3af,_0x19ee7c)=>{const _0x327e04=document['createElement']('script');_0x327e04['setAttribute']('src',_0x182d59),_0x327e04['onload']=_0xeed3af,_0x327e04['onerror']=_0x5a1150=>{const _0x2c0b8f=J('internal-error');_0x2c0b8f['customData']=_0x5a1150,_0x19ee7c(_0x2c0b8f);},_0x327e04['type']='text/javascript',_0x327e04['charset']='UTF-8',c_()['appendChild'](_0x327e04);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};