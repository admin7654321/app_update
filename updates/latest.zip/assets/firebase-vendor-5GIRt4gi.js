const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x7ca791,_0x1577d9){if(!_0x7ca791)throw ot(_0x1577d9);},ot=function(_0x41c9c6){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x41c9c6);},Wr=function(_0x132195){const _0x13b042=[];let _0x4ad0ae=0x0;for(let _0x228f3f=0x0;_0x228f3f<_0x132195['length'];_0x228f3f++){let _0x42240d=_0x132195['charCodeAt'](_0x228f3f);_0x42240d<0x80?_0x13b042[_0x4ad0ae++]=_0x42240d:_0x42240d<0x800?(_0x13b042[_0x4ad0ae++]=_0x42240d>>0x6|0xc0,_0x13b042[_0x4ad0ae++]=_0x42240d&0x3f|0x80):(_0x42240d&0xfc00)===0xd800&&_0x228f3f+0x1<_0x132195['length']&&(_0x132195['charCodeAt'](_0x228f3f+0x1)&0xfc00)===0xdc00?(_0x42240d=0x10000+((_0x42240d&0x3ff)<<0xa)+(_0x132195['charCodeAt'](++_0x228f3f)&0x3ff),_0x13b042[_0x4ad0ae++]=_0x42240d>>0x12|0xf0,_0x13b042[_0x4ad0ae++]=_0x42240d>>0xc&0x3f|0x80,_0x13b042[_0x4ad0ae++]=_0x42240d>>0x6&0x3f|0x80,_0x13b042[_0x4ad0ae++]=_0x42240d&0x3f|0x80):(_0x13b042[_0x4ad0ae++]=_0x42240d>>0xc|0xe0,_0x13b042[_0x4ad0ae++]=_0x42240d>>0x6&0x3f|0x80,_0x13b042[_0x4ad0ae++]=_0x42240d&0x3f|0x80);}return _0x13b042;},Za=function(_0x7edcf9){const _0x2b74f4=[];let _0x39f8d7=0x0,_0x41b69a=0x0;for(;_0x39f8d7<_0x7edcf9['length'];){const _0xd2f141=_0x7edcf9[_0x39f8d7++];if(_0xd2f141<0x80)_0x2b74f4[_0x41b69a++]=String['fromCharCode'](_0xd2f141);else{if(_0xd2f141>0xbf&&_0xd2f141<0xe0){const _0x35b57f=_0x7edcf9[_0x39f8d7++];_0x2b74f4[_0x41b69a++]=String['fromCharCode']((_0xd2f141&0x1f)<<0x6|_0x35b57f&0x3f);}else{if(_0xd2f141>0xef&&_0xd2f141<0x16d){const _0x669e30=_0x7edcf9[_0x39f8d7++],_0x2fb509=_0x7edcf9[_0x39f8d7++],_0x457623=_0x7edcf9[_0x39f8d7++],_0x42a994=((_0xd2f141&0x7)<<0x12|(_0x669e30&0x3f)<<0xc|(_0x2fb509&0x3f)<<0x6|_0x457623&0x3f)-0x10000;_0x2b74f4[_0x41b69a++]=String['fromCharCode'](0xd800+(_0x42a994>>0xa)),_0x2b74f4[_0x41b69a++]=String['fromCharCode'](0xdc00+(_0x42a994&0x3ff));}else{const _0x41c1c6=_0x7edcf9[_0x39f8d7++],_0x527739=_0x7edcf9[_0x39f8d7++];_0x2b74f4[_0x41b69a++]=String['fromCharCode']((_0xd2f141&0xf)<<0xc|(_0x41c1c6&0x3f)<<0x6|_0x527739&0x3f);}}}}return _0x2b74f4['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x418eca,_0x135f17){if(!Array['isArray'](_0x418eca))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x530b55=_0x135f17?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3e8c74=[];for(let _0x38c184=0x0;_0x38c184<_0x418eca['length'];_0x38c184+=0x3){const _0x595500=_0x418eca[_0x38c184],_0x5c3899=_0x38c184+0x1<_0x418eca['length'],_0x369369=_0x5c3899?_0x418eca[_0x38c184+0x1]:0x0,_0xb140bd=_0x38c184+0x2<_0x418eca['length'],_0x4594e9=_0xb140bd?_0x418eca[_0x38c184+0x2]:0x0,_0x5dacf6=_0x595500>>0x2,_0x2dc768=(_0x595500&0x3)<<0x4|_0x369369>>0x4;let _0x574765=(_0x369369&0xf)<<0x2|_0x4594e9>>0x6,_0x2e93bc=_0x4594e9&0x3f;_0xb140bd||(_0x2e93bc=0x40,_0x5c3899||(_0x574765=0x40)),_0x3e8c74['push'](_0x530b55[_0x5dacf6],_0x530b55[_0x2dc768],_0x530b55[_0x574765],_0x530b55[_0x2e93bc]);}return _0x3e8c74['join']('');},'encodeString'(_0x48b1b4,_0x5b6748){return this['HAS_NATIVE_SUPPORT']&&!_0x5b6748?btoa(_0x48b1b4):this['encodeByteArray'](Wr(_0x48b1b4),_0x5b6748);},'decodeString'(_0x465c38,_0x2c0cca){return this['HAS_NATIVE_SUPPORT']&&!_0x2c0cca?atob(_0x465c38):Za(this['decodeStringToByteArray'](_0x465c38,_0x2c0cca));},'decodeStringToByteArray'(_0x3bafef,_0x4784cc){this['init_']();const _0x45a68d=_0x4784cc?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3b2b78=[];for(let _0x3c51bf=0x0;_0x3c51bf<_0x3bafef['length'];){const _0x3bff17=_0x45a68d[_0x3bafef['charAt'](_0x3c51bf++)],_0xdf2c5e=_0x3c51bf<_0x3bafef['length']?_0x45a68d[_0x3bafef['charAt'](_0x3c51bf)]:0x0;++_0x3c51bf;const _0xcbb8ad=_0x3c51bf<_0x3bafef['length']?_0x45a68d[_0x3bafef['charAt'](_0x3c51bf)]:0x40;++_0x3c51bf;const _0xa81bc7=_0x3c51bf<_0x3bafef['length']?_0x45a68d[_0x3bafef['charAt'](_0x3c51bf)]:0x40;if(++_0x3c51bf,_0x3bff17==null||_0xdf2c5e==null||_0xcbb8ad==null||_0xa81bc7==null)throw new ec();const _0x517008=_0x3bff17<<0x2|_0xdf2c5e>>0x4;if(_0x3b2b78['push'](_0x517008),_0xcbb8ad!==0x40){const _0xb54b1b=_0xdf2c5e<<0x4&0xf0|_0xcbb8ad>>0x2;if(_0x3b2b78['push'](_0xb54b1b),_0xa81bc7!==0x40){const _0x185e24=_0xcbb8ad<<0x6&0xc0|_0xa81bc7;_0x3b2b78['push'](_0x185e24);}}}return _0x3b2b78;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x415525=0x0;_0x415525<this['ENCODED_VALS']['length'];_0x415525++)this['byteToCharMap_'][_0x415525]=this['ENCODED_VALS']['charAt'](_0x415525),this['charToByteMap_'][this['byteToCharMap_'][_0x415525]]=_0x415525,this['byteToCharMapWebSafe_'][_0x415525]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x415525),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x415525]]=_0x415525,_0x415525>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x415525)]=_0x415525,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x415525)]=_0x415525);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x15c57f){const _0x894404=Wr(_0x15c57f);return Di['encodeByteArray'](_0x894404,!0x0);},an=function(_0x333578){return Br(_0x333578)['replace'](/\./g,'');},cn=function(_0x37a6ea){try{return Di['decodeString'](_0x37a6ea,!0x0);}catch(_0x3e4e7f){console['error']('base64Decode\x20failed:\x20',_0x3e4e7f);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x99b9e8){return Vr(void 0x0,_0x99b9e8);}function Vr(_0x342e95,_0x4b14ae){if(!(_0x4b14ae instanceof Object))return _0x4b14ae;switch(_0x4b14ae['constructor']){case Date:const _0x2c21a4=_0x4b14ae;return new Date(_0x2c21a4['getTime']());case Object:_0x342e95===void 0x0&&(_0x342e95={});break;case Array:_0x342e95=[];break;default:return _0x4b14ae;}for(const _0x59a8ab in _0x4b14ae)!_0x4b14ae['hasOwnProperty'](_0x59a8ab)||!nc(_0x59a8ab)||(_0x342e95[_0x59a8ab]=Vr(_0x342e95[_0x59a8ab],_0x4b14ae[_0x59a8ab]));return _0x342e95;}function nc(_0x8425cb){return _0x8425cb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x36ca7f=As['__FIREBASE_DEFAULTS__'];if(_0x36ca7f)return JSON['parse'](_0x36ca7f);},oc=()=>{if(typeof document>'u')return;let _0x4a07be;try{_0x4a07be=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x597f6e=_0x4a07be&&cn(_0x4a07be[0x1]);return _0x597f6e&&JSON['parse'](_0x597f6e);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0xb77bd0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xb77bd0);return;}},Hr=_0x58dae2=>{var _0x418996,_0x49f51d;return(_0x49f51d=(_0x418996=Mi())==null?void 0x0:_0x418996['emulatorHosts'])==null?void 0x0:_0x49f51d[_0x58dae2];},ac=_0x273183=>{const _0x422747=Hr(_0x273183);if(!_0x422747)return;const _0x4cf309=_0x422747['lastIndexOf'](':');if(_0x4cf309<=0x0||_0x4cf309+0x1===_0x422747['length'])throw new Error('Invalid\x20host\x20'+_0x422747+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x44c367=parseInt(_0x422747['substring'](_0x4cf309+0x1),0xa);return _0x422747[0x0]==='['?[_0x422747['substring'](0x1,_0x4cf309-0x1),_0x44c367]:[_0x422747['substring'](0x0,_0x4cf309),_0x44c367];},$r=()=>{var _0x232467;return(_0x232467=Mi())==null?void 0x0:_0x232467['config'];},Gr=_0xb45b87=>{var _0x3351a1;return(_0x3351a1=Mi())==null?void 0x0:_0x3351a1['_'+_0xb45b87];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x12597d,_0x1d4178)=>{this['resolve']=_0x12597d,this['reject']=_0x1d4178;});}['wrapCallback'](_0x2259f9){return(_0x15044b,_0xc2ba3e)=>{_0x15044b?this['reject'](_0x15044b):this['resolve'](_0xc2ba3e),typeof _0x2259f9=='function'&&(this['promise']['catch'](()=>{}),_0x2259f9['length']===0x1?_0x2259f9(_0x15044b):_0x2259f9(_0x15044b,_0xc2ba3e));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x4d1b5e,_0x52a741){if(_0x4d1b5e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xca1370={'alg':'none','type':'JWT'},_0x548134=_0x52a741||'demo-project',_0x5a54fa=_0x4d1b5e['iat']||0x0,_0x15f661=_0x4d1b5e['sub']||_0x4d1b5e['user_id'];if(!_0x15f661)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x23be83={'iss':'https://securetoken.google.com/'+_0x548134,'aud':_0x548134,'iat':_0x5a54fa,'exp':_0x5a54fa+0xe10,'auth_time':_0x5a54fa,'sub':_0x15f661,'user_id':_0x15f661,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4d1b5e};return[an(JSON['stringify'](_0xca1370)),an(JSON['stringify'](_0x23be83)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x5b5bdf=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5b5bdf=='object'&&_0x5b5bdf['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x5d8b23=W();return _0x5d8b23['indexOf']('MSIE\x20')>=0x0||_0x5d8b23['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x55b775,_0xd2d051)=>{try{let _0xd3a350=!0x0;const _0x7e2c8a='validate-browser-context-for-indexeddb-analytics-module',_0x5c22b5=self['indexedDB']['open'](_0x7e2c8a);_0x5c22b5['onsuccess']=()=>{_0x5c22b5['result']['close'](),_0xd3a350||self['indexedDB']['deleteDatabase'](_0x7e2c8a),_0x55b775(!0x0);},_0x5c22b5['onupgradeneeded']=()=>{_0xd3a350=!0x1;},_0x5c22b5['onerror']=()=>{var _0x2d22b5;_0xd2d051(((_0x2d22b5=_0x5c22b5['error'])==null?void 0x0:_0x2d22b5['message'])||'');};}catch(_0x1fc18e){_0xd2d051(_0x1fc18e);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x10febc,_0x488b02,_0x9147c2){super(_0x488b02),this['code']=_0x10febc,this['customData']=_0x9147c2,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x168846,_0x1d7d16,_0x2b40cf){this['service']=_0x168846,this['serviceName']=_0x1d7d16,this['errors']=_0x2b40cf;}['create'](_0x47f715,..._0x68d7b4){const _0x40035c=_0x68d7b4[0x0]||{},_0xd251e=this['service']+'/'+_0x47f715,_0x5b7654=this['errors'][_0x47f715],_0x3c67f2=_0x5b7654?gc(_0x5b7654,_0x40035c):'Error',_0x71ebee=this['serviceName']+':\x20'+_0x3c67f2+'\x20('+_0xd251e+').';return new Se(_0xd251e,_0x71ebee,_0x40035c);}}function gc(_0x5551f4,_0x2cc58c){return _0x5551f4['replace'](mc,(_0x310046,_0xc3b226)=>{const _0x57805a=_0x2cc58c[_0xc3b226];return _0x57805a!=null?String(_0x57805a):'<'+_0xc3b226+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x3accb1){return JSON['parse'](_0x3accb1);}function O(_0x34c874){return JSON['stringify'](_0x34c874);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x1ff5d8){let _0x21c00d={},_0x111905={},_0xceee26={},_0x1a272c='';try{const _0x283a4a=_0x1ff5d8['split']('.');_0x21c00d=bt(cn(_0x283a4a[0x0])||''),_0x111905=bt(cn(_0x283a4a[0x1])||''),_0x1a272c=_0x283a4a[0x2],_0xceee26=_0x111905['d']||{},delete _0x111905['d'];}catch{}return{'header':_0x21c00d,'claims':_0x111905,'data':_0xceee26,'signature':_0x1a272c};},yc=function(_0x14a52f){const _0x5a6a16=zr(_0x14a52f),_0x401183=_0x5a6a16['claims'];return!!_0x401183&&typeof _0x401183=='object'&&_0x401183['hasOwnProperty']('iat');},vc=function(_0x39cf94){const _0x1bcce6=zr(_0x39cf94)['claims'];return typeof _0x1bcce6=='object'&&_0x1bcce6['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1ecd51,_0x35eda0){return Object['prototype']['hasOwnProperty']['call'](_0x1ecd51,_0x35eda0);}function Oe(_0x303cdc,_0x224f8f){if(Object['prototype']['hasOwnProperty']['call'](_0x303cdc,_0x224f8f))return _0x303cdc[_0x224f8f];}function hi(_0x3a3240){for(const _0x558574 in _0x3a3240)if(Object['prototype']['hasOwnProperty']['call'](_0x3a3240,_0x558574))return!0x1;return!0x0;}function ln(_0x1875cb,_0x4a775c,_0x19cbf6){const _0x2b6f34={};for(const _0x1aa825 in _0x1875cb)Object['prototype']['hasOwnProperty']['call'](_0x1875cb,_0x1aa825)&&(_0x2b6f34[_0x1aa825]=_0x4a775c['call'](_0x19cbf6,_0x1875cb[_0x1aa825],_0x1aa825,_0x1875cb));return _0x2b6f34;}function De(_0x4002d8,_0x41e1a1){if(_0x4002d8===_0x41e1a1)return!0x0;const _0x4a1ec8=Object['keys'](_0x4002d8),_0x14c472=Object['keys'](_0x41e1a1);for(const _0xac35f7 of _0x4a1ec8){if(!_0x14c472['includes'](_0xac35f7))return!0x1;const _0x599e2e=_0x4002d8[_0xac35f7],_0x46de38=_0x41e1a1[_0xac35f7];if(ks(_0x599e2e)&&ks(_0x46de38)){if(!De(_0x599e2e,_0x46de38))return!0x1;}else{if(_0x599e2e!==_0x46de38)return!0x1;}}for(const _0x551fb5 of _0x14c472)if(!_0x4a1ec8['includes'](_0x551fb5))return!0x1;return!0x0;}function ks(_0x4ef57a){return _0x4ef57a!==null&&typeof _0x4ef57a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5a18de){const _0xcfab58=[];for(const [_0x399e43,_0x3d435d]of Object['entries'](_0x5a18de))Array['isArray'](_0x3d435d)?_0x3d435d['forEach'](_0x28b30f=>{_0xcfab58['push'](encodeURIComponent(_0x399e43)+'='+encodeURIComponent(_0x28b30f));}):_0xcfab58['push'](encodeURIComponent(_0x399e43)+'='+encodeURIComponent(_0x3d435d));return _0xcfab58['length']?'&'+_0xcfab58['join']('&'):'';}function yt(_0x54b559){const _0xd7307b={};return _0x54b559['replace'](/^\?/,'')['split']('&')['forEach'](_0x1e0f2b=>{if(_0x1e0f2b){const [_0x331f9b,_0x3f8af1]=_0x1e0f2b['split']('=');_0xd7307b[decodeURIComponent(_0x331f9b)]=decodeURIComponent(_0x3f8af1);}}),_0xd7307b;}function vt(_0x2f7c41){const _0x47723d=_0x2f7c41['indexOf']('?');if(!_0x47723d)return'';const _0xa347f0=_0x2f7c41['indexOf']('#',_0x47723d);return _0x2f7c41['substring'](_0x47723d,_0xa347f0>0x0?_0xa347f0:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x55be00=0x1;_0x55be00<this['blockSize'];++_0x55be00)this['pad_'][_0x55be00]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1c6c50,_0x53a7a6){_0x53a7a6||(_0x53a7a6=0x0);const _0x10bde0=this['W_'];if(typeof _0x1c6c50=='string'){for(let _0x1876b9=0x0;_0x1876b9<0x10;_0x1876b9++)_0x10bde0[_0x1876b9]=_0x1c6c50['charCodeAt'](_0x53a7a6)<<0x18|_0x1c6c50['charCodeAt'](_0x53a7a6+0x1)<<0x10|_0x1c6c50['charCodeAt'](_0x53a7a6+0x2)<<0x8|_0x1c6c50['charCodeAt'](_0x53a7a6+0x3),_0x53a7a6+=0x4;}else{for(let _0x4d81e7=0x0;_0x4d81e7<0x10;_0x4d81e7++)_0x10bde0[_0x4d81e7]=_0x1c6c50[_0x53a7a6]<<0x18|_0x1c6c50[_0x53a7a6+0x1]<<0x10|_0x1c6c50[_0x53a7a6+0x2]<<0x8|_0x1c6c50[_0x53a7a6+0x3],_0x53a7a6+=0x4;}for(let _0x311248=0x10;_0x311248<0x50;_0x311248++){const _0x25f4f6=_0x10bde0[_0x311248-0x3]^_0x10bde0[_0x311248-0x8]^_0x10bde0[_0x311248-0xe]^_0x10bde0[_0x311248-0x10];_0x10bde0[_0x311248]=(_0x25f4f6<<0x1|_0x25f4f6>>>0x1f)&0xffffffff;}let _0x5879fb=this['chain_'][0x0],_0x2fe158=this['chain_'][0x1],_0x52cd62=this['chain_'][0x2],_0x1e24c6=this['chain_'][0x3],_0x4f4e52=this['chain_'][0x4],_0x26e0a2,_0x5005e7;for(let _0x2eb559=0x0;_0x2eb559<0x50;_0x2eb559++){_0x2eb559<0x28?_0x2eb559<0x14?(_0x26e0a2=_0x1e24c6^_0x2fe158&(_0x52cd62^_0x1e24c6),_0x5005e7=0x5a827999):(_0x26e0a2=_0x2fe158^_0x52cd62^_0x1e24c6,_0x5005e7=0x6ed9eba1):_0x2eb559<0x3c?(_0x26e0a2=_0x2fe158&_0x52cd62|_0x1e24c6&(_0x2fe158|_0x52cd62),_0x5005e7=0x8f1bbcdc):(_0x26e0a2=_0x2fe158^_0x52cd62^_0x1e24c6,_0x5005e7=0xca62c1d6);const _0x331b79=(_0x5879fb<<0x5|_0x5879fb>>>0x1b)+_0x26e0a2+_0x4f4e52+_0x5005e7+_0x10bde0[_0x2eb559]&0xffffffff;_0x4f4e52=_0x1e24c6,_0x1e24c6=_0x52cd62,_0x52cd62=(_0x2fe158<<0x1e|_0x2fe158>>>0x2)&0xffffffff,_0x2fe158=_0x5879fb,_0x5879fb=_0x331b79;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5879fb&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2fe158&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52cd62&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1e24c6&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4f4e52&0xffffffff;}['update'](_0x4c59da,_0x58e08c){if(_0x4c59da==null)return;_0x58e08c===void 0x0&&(_0x58e08c=_0x4c59da['length']);const _0x274864=_0x58e08c-this['blockSize'];let _0x28d0f7=0x0;const _0x140e53=this['buf_'];let _0x58de87=this['inbuf_'];for(;_0x28d0f7<_0x58e08c;){if(_0x58de87===0x0){for(;_0x28d0f7<=_0x274864;)this['compress_'](_0x4c59da,_0x28d0f7),_0x28d0f7+=this['blockSize'];}if(typeof _0x4c59da=='string'){for(;_0x28d0f7<_0x58e08c;)if(_0x140e53[_0x58de87]=_0x4c59da['charCodeAt'](_0x28d0f7),++_0x58de87,++_0x28d0f7,_0x58de87===this['blockSize']){this['compress_'](_0x140e53),_0x58de87=0x0;break;}}else{for(;_0x28d0f7<_0x58e08c;)if(_0x140e53[_0x58de87]=_0x4c59da[_0x28d0f7],++_0x58de87,++_0x28d0f7,_0x58de87===this['blockSize']){this['compress_'](_0x140e53),_0x58de87=0x0;break;}}}this['inbuf_']=_0x58de87,this['total_']+=_0x58e08c;}['digest'](){const _0x233734=[];let _0x57c14a=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x473cd6=this['blockSize']-0x1;_0x473cd6>=0x38;_0x473cd6--)this['buf_'][_0x473cd6]=_0x57c14a&0xff,_0x57c14a/=0x100;this['compress_'](this['buf_']);let _0x42d171=0x0;for(let _0x1ec239=0x0;_0x1ec239<0x5;_0x1ec239++)for(let _0x1242b9=0x18;_0x1242b9>=0x0;_0x1242b9-=0x8)_0x233734[_0x42d171]=this['chain_'][_0x1ec239]>>_0x1242b9&0xff,++_0x42d171;return _0x233734;}}function Ic(_0xed91a,_0x28b6fd){const _0x59594d=new wc(_0xed91a,_0x28b6fd);return _0x59594d['subscribe']['bind'](_0x59594d);}class wc{constructor(_0x456100,_0x3ea9c3){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3ea9c3,this['task']['then'](()=>{_0x456100(this);})['catch'](_0x17dc3b=>{this['error'](_0x17dc3b);});}['next'](_0x4eafab){this['forEachObserver'](_0x491d6a=>{_0x491d6a['next'](_0x4eafab);});}['error'](_0x4186c1){this['forEachObserver'](_0x4adc5c=>{_0x4adc5c['error'](_0x4186c1);}),this['close'](_0x4186c1);}['complete'](){this['forEachObserver'](_0x13ee7f=>{_0x13ee7f['complete']();}),this['close']();}['subscribe'](_0x1c00a7,_0x2d24d1,_0x1cab29){let _0x285092;if(_0x1c00a7===void 0x0&&_0x2d24d1===void 0x0&&_0x1cab29===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x1c00a7,['next','error','complete'])?_0x285092=_0x1c00a7:_0x285092={'next':_0x1c00a7,'error':_0x2d24d1,'complete':_0x1cab29},_0x285092['next']===void 0x0&&(_0x285092['next']=Qn),_0x285092['error']===void 0x0&&(_0x285092['error']=Qn),_0x285092['complete']===void 0x0&&(_0x285092['complete']=Qn);const _0x186602=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x285092['error'](this['finalError']):_0x285092['complete']();}catch{}}),this['observers']['push'](_0x285092),_0x186602;}['unsubscribeOne'](_0x3c96a4){this['observers']===void 0x0||this['observers'][_0x3c96a4]===void 0x0||(delete this['observers'][_0x3c96a4],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x137f38){if(!this['finalized']){for(let _0xaaac9c=0x0;_0xaaac9c<this['observers']['length'];_0xaaac9c++)this['sendOne'](_0xaaac9c,_0x137f38);}}['sendOne'](_0x158401,_0x1d1d08){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x158401]!==void 0x0)try{_0x1d1d08(this['observers'][_0x158401]);}catch(_0x4d0738){typeof console<'u'&&console['error']&&console['error'](_0x4d0738);}});}['close'](_0x169fda){this['finalized']||(this['finalized']=!0x0,_0x169fda!==void 0x0&&(this['finalError']=_0x169fda),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x5d761d,_0x4519d0){if(typeof _0x5d761d!='object'||_0x5d761d===null)return!0x1;for(const _0x4f1973 of _0x4519d0)if(_0x4f1973 in _0x5d761d&&typeof _0x5d761d[_0x4f1973]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x53360b,_0x1338bf){return _0x53360b+'\x20failed:\x20'+_0x1338bf+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x2e728a){const _0x50b31f=[];let _0x53e3f5=0x0;for(let _0x18a5b4=0x0;_0x18a5b4<_0x2e728a['length'];_0x18a5b4++){let _0x239abb=_0x2e728a['charCodeAt'](_0x18a5b4);if(_0x239abb>=0xd800&&_0x239abb<=0xdbff){const _0x345eff=_0x239abb-0xd800;_0x18a5b4++,f(_0x18a5b4<_0x2e728a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x26c606=_0x2e728a['charCodeAt'](_0x18a5b4)-0xdc00;_0x239abb=0x10000+(_0x345eff<<0xa)+_0x26c606;}_0x239abb<0x80?_0x50b31f[_0x53e3f5++]=_0x239abb:_0x239abb<0x800?(_0x50b31f[_0x53e3f5++]=_0x239abb>>0x6|0xc0,_0x50b31f[_0x53e3f5++]=_0x239abb&0x3f|0x80):_0x239abb<0x10000?(_0x50b31f[_0x53e3f5++]=_0x239abb>>0xc|0xe0,_0x50b31f[_0x53e3f5++]=_0x239abb>>0x6&0x3f|0x80,_0x50b31f[_0x53e3f5++]=_0x239abb&0x3f|0x80):(_0x50b31f[_0x53e3f5++]=_0x239abb>>0x12|0xf0,_0x50b31f[_0x53e3f5++]=_0x239abb>>0xc&0x3f|0x80,_0x50b31f[_0x53e3f5++]=_0x239abb>>0x6&0x3f|0x80,_0x50b31f[_0x53e3f5++]=_0x239abb&0x3f|0x80);}return _0x50b31f;},Pn=function(_0x106171){let _0x3f31ee=0x0;for(let _0x409417=0x0;_0x409417<_0x106171['length'];_0x409417++){const _0x59874f=_0x106171['charCodeAt'](_0x409417);_0x59874f<0x80?_0x3f31ee++:_0x59874f<0x800?_0x3f31ee+=0x2:_0x59874f>=0xd800&&_0x59874f<=0xdbff?(_0x3f31ee+=0x4,_0x409417++):_0x3f31ee+=0x3;}return _0x3f31ee;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x9e6d6b){return _0x9e6d6b&&_0x9e6d6b['_delegate']?_0x9e6d6b['_delegate']:_0x9e6d6b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x3b286f){try{return(_0x3b286f['startsWith']('http://')||_0x3b286f['startsWith']('https://')?new URL(_0x3b286f)['hostname']:_0x3b286f)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0xc13d4c){return(await fetch(_0xc13d4c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x33d2b5,_0x3a0682,_0x407932){this['name']=_0x33d2b5,this['instanceFactory']=_0x3a0682,this['type']=_0x407932,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5cb6cb){return this['instantiationMode']=_0x5cb6cb,this;}['setMultipleInstances'](_0xf9f624){return this['multipleInstances']=_0xf9f624,this;}['setServiceProps'](_0x233e27){return this['serviceProps']=_0x233e27,this;}['setInstanceCreatedCallback'](_0x3a7aa4){return this['onInstanceCreated']=_0x3a7aa4,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4f375d,_0x319f07){this['name']=_0x4f375d,this['container']=_0x319f07,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x803d1d){const _0x1bbf09=this['normalizeInstanceIdentifier'](_0x803d1d);if(!this['instancesDeferred']['has'](_0x1bbf09)){const _0x36f5d7=new Ve();if(this['instancesDeferred']['set'](_0x1bbf09,_0x36f5d7),this['isInitialized'](_0x1bbf09)||this['shouldAutoInitialize']())try{const _0x5142e4=this['getOrInitializeService']({'instanceIdentifier':_0x1bbf09});_0x5142e4&&_0x36f5d7['resolve'](_0x5142e4);}catch{}}return this['instancesDeferred']['get'](_0x1bbf09)['promise'];}['getImmediate'](_0x1f0424){const _0x3761a9=this['normalizeInstanceIdentifier'](_0x1f0424==null?void 0x0:_0x1f0424['identifier']),_0x3c236c=(_0x1f0424==null?void 0x0:_0x1f0424['optional'])??!0x1;if(this['isInitialized'](_0x3761a9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3761a9});}catch(_0x2e9a98){if(_0x3c236c)return null;throw _0x2e9a98;}else{if(_0x3c236c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3ad7f2){if(_0x3ad7f2['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3ad7f2['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3ad7f2,!!this['shouldAutoInitialize']()){if(Rc(_0x3ad7f2))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x5942ec,_0x2c7394]of this['instancesDeferred']['entries']()){const _0x294a89=this['normalizeInstanceIdentifier'](_0x5942ec);try{const _0x2e7472=this['getOrInitializeService']({'instanceIdentifier':_0x294a89});_0x2c7394['resolve'](_0x2e7472);}catch{}}}}['clearInstance'](_0x3eb447=ke){this['instancesDeferred']['delete'](_0x3eb447),this['instancesOptions']['delete'](_0x3eb447),this['instances']['delete'](_0x3eb447);}async['delete'](){const _0x96c02d=Array['from'](this['instances']['values']());await Promise['all']([..._0x96c02d['filter'](_0x24f523=>'INTERNAL'in _0x24f523)['map'](_0x7a26d9=>_0x7a26d9['INTERNAL']['delete']()),..._0x96c02d['filter'](_0x2cc690=>'_delete'in _0x2cc690)['map'](_0x9b99e8=>_0x9b99e8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x7882f=ke){return this['instances']['has'](_0x7882f);}['getOptions'](_0x14028b=ke){return this['instancesOptions']['get'](_0x14028b)||{};}['initialize'](_0x49870b={}){const {options:_0x5e3754={}}=_0x49870b,_0x36eab2=this['normalizeInstanceIdentifier'](_0x49870b['instanceIdentifier']);if(this['isInitialized'](_0x36eab2))throw Error(this['name']+'('+_0x36eab2+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x573bd7=this['getOrInitializeService']({'instanceIdentifier':_0x36eab2,'options':_0x5e3754});for(const [_0x8d89f3,_0x10f2c9]of this['instancesDeferred']['entries']()){const _0x5045be=this['normalizeInstanceIdentifier'](_0x8d89f3);_0x36eab2===_0x5045be&&_0x10f2c9['resolve'](_0x573bd7);}return _0x573bd7;}['onInit'](_0x358a78,_0xfafa61){const _0x1db9a7=this['normalizeInstanceIdentifier'](_0xfafa61),_0x1d60e4=this['onInitCallbacks']['get'](_0x1db9a7)??new Set();_0x1d60e4['add'](_0x358a78),this['onInitCallbacks']['set'](_0x1db9a7,_0x1d60e4);const _0x25c854=this['instances']['get'](_0x1db9a7);return _0x25c854&&_0x358a78(_0x25c854,_0x1db9a7),()=>{_0x1d60e4['delete'](_0x358a78);};}['invokeOnInitCallbacks'](_0x5d05f5,_0x48d68f){const _0x3ed8be=this['onInitCallbacks']['get'](_0x48d68f);if(_0x3ed8be){for(const _0x8ae90 of _0x3ed8be)try{_0x8ae90(_0x5d05f5,_0x48d68f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1f5462,options:_0xf07d8={}}){let _0x444e7d=this['instances']['get'](_0x1f5462);if(!_0x444e7d&&this['component']&&(_0x444e7d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x1f5462),'options':_0xf07d8}),this['instances']['set'](_0x1f5462,_0x444e7d),this['instancesOptions']['set'](_0x1f5462,_0xf07d8),this['invokeOnInitCallbacks'](_0x444e7d,_0x1f5462),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1f5462,_0x444e7d);}catch{}return _0x444e7d||null;}['normalizeInstanceIdentifier'](_0x430128=ke){return this['component']?this['component']['multipleInstances']?_0x430128:ke:_0x430128;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x4fb6d8){return _0x4fb6d8===ke?void 0x0:_0x4fb6d8;}function Rc(_0x14e149){return _0x14e149['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x49fe47){this['name']=_0x49fe47,this['providers']=new Map();}['addComponent'](_0x3701da){const _0x368da2=this['getProvider'](_0x3701da['name']);if(_0x368da2['isComponentSet']())throw new Error('Component\x20'+_0x3701da['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x368da2['setComponent'](_0x3701da);}['addOrOverwriteComponent'](_0x234490){this['getProvider'](_0x234490['name'])['isComponentSet']()&&this['providers']['delete'](_0x234490['name']),this['addComponent'](_0x234490);}['getProvider'](_0x3b6e02){if(this['providers']['has'](_0x3b6e02))return this['providers']['get'](_0x3b6e02);const _0xcdc3af=new Sc(_0x3b6e02,this);return this['providers']['set'](_0x3b6e02,_0xcdc3af),_0xcdc3af;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x47e83f){_0x47e83f[_0x47e83f['DEBUG']=0x0]='DEBUG',_0x47e83f[_0x47e83f['VERBOSE']=0x1]='VERBOSE',_0x47e83f[_0x47e83f['INFO']=0x2]='INFO',_0x47e83f[_0x47e83f['WARN']=0x3]='WARN',_0x47e83f[_0x47e83f['ERROR']=0x4]='ERROR',_0x47e83f[_0x47e83f['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x32c53f,_0x485de9,..._0x2db77f)=>{if(_0x485de9<_0x32c53f['logLevel'])return;const _0x46a0b7=new Date()['toISOString'](),_0x39295a=Pc[_0x485de9];if(_0x39295a)console[_0x39295a]('['+_0x46a0b7+']\x20\x20'+_0x32c53f['name']+':',..._0x2db77f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x485de9+')');};class xi{constructor(_0x114e03){this['name']=_0x114e03,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x52d3f3){if(!(_0x52d3f3 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x52d3f3+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x52d3f3;}['setLogLevel'](_0x5723a7){this['_logLevel']=typeof _0x5723a7=='string'?kc[_0x5723a7]:_0x5723a7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x26b344){if(typeof _0x26b344!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x26b344;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x452ce4){this['_userLogHandler']=_0x452ce4;}['debug'](..._0xfa8280){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xfa8280),this['_logHandler'](this,T['DEBUG'],..._0xfa8280);}['log'](..._0x2b5b67){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2b5b67),this['_logHandler'](this,T['VERBOSE'],..._0x2b5b67);}['info'](..._0x4c25fc){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4c25fc),this['_logHandler'](this,T['INFO'],..._0x4c25fc);}['warn'](..._0x178450){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x178450),this['_logHandler'](this,T['WARN'],..._0x178450);}['error'](..._0x5af213){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5af213),this['_logHandler'](this,T['ERROR'],..._0x5af213);}}const Dc=(_0x3ceeac,_0xa3b2f6)=>_0xa3b2f6['some'](_0x4e5bb0=>_0x3ceeac instanceof _0x4e5bb0);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x21b4ce){const _0x539da9=new Promise((_0x27cba7,_0x1aa6c3)=>{const _0x22f5ee=()=>{_0x21b4ce['removeEventListener']('success',_0x4a9251),_0x21b4ce['removeEventListener']('error',_0xf2643d);},_0x4a9251=()=>{_0x27cba7(_e(_0x21b4ce['result'])),_0x22f5ee();},_0xf2643d=()=>{_0x1aa6c3(_0x21b4ce['error']),_0x22f5ee();};_0x21b4ce['addEventListener']('success',_0x4a9251),_0x21b4ce['addEventListener']('error',_0xf2643d);});return _0x539da9['then'](_0x1b3469=>{_0x1b3469 instanceof IDBCursor&&Kr['set'](_0x1b3469,_0x21b4ce);})['catch'](()=>{}),Fi['set'](_0x539da9,_0x21b4ce),_0x539da9;}function Fc(_0x3bd83b){if(ui['has'](_0x3bd83b))return;const _0x2447a6=new Promise((_0x26ae4e,_0x19bfac)=>{const _0x3daee7=()=>{_0x3bd83b['removeEventListener']('complete',_0x21e04c),_0x3bd83b['removeEventListener']('error',_0x2da0e1),_0x3bd83b['removeEventListener']('abort',_0x2da0e1);},_0x21e04c=()=>{_0x26ae4e(),_0x3daee7();},_0x2da0e1=()=>{_0x19bfac(_0x3bd83b['error']||new DOMException('AbortError','AbortError')),_0x3daee7();};_0x3bd83b['addEventListener']('complete',_0x21e04c),_0x3bd83b['addEventListener']('error',_0x2da0e1),_0x3bd83b['addEventListener']('abort',_0x2da0e1);});ui['set'](_0x3bd83b,_0x2447a6);}let di={'get'(_0x39a936,_0x5df395,_0x1d6b01){if(_0x39a936 instanceof IDBTransaction){if(_0x5df395==='done')return ui['get'](_0x39a936);if(_0x5df395==='objectStoreNames')return _0x39a936['objectStoreNames']||Yr['get'](_0x39a936);if(_0x5df395==='store')return _0x1d6b01['objectStoreNames'][0x1]?void 0x0:_0x1d6b01['objectStore'](_0x1d6b01['objectStoreNames'][0x0]);}return _e(_0x39a936[_0x5df395]);},'set'(_0x3de3d7,_0xc4f9ae,_0x19f88c){return _0x3de3d7[_0xc4f9ae]=_0x19f88c,!0x0;},'has'(_0x3cb5f4,_0x27fab9){return _0x3cb5f4 instanceof IDBTransaction&&(_0x27fab9==='done'||_0x27fab9==='store')?!0x0:_0x27fab9 in _0x3cb5f4;}};function Uc(_0xfefefb){di=_0xfefefb(di);}function Wc(_0x12bc44){return _0x12bc44===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x1b35c1,..._0x3272c7){const _0x4c8fc4=_0x12bc44['call'](Xn(this),_0x1b35c1,..._0x3272c7);return Yr['set'](_0x4c8fc4,_0x1b35c1['sort']?_0x1b35c1['sort']():[_0x1b35c1]),_e(_0x4c8fc4);}:Lc()['includes'](_0x12bc44)?function(..._0x3d9022){return _0x12bc44['apply'](Xn(this),_0x3d9022),_e(Kr['get'](this));}:function(..._0xcde097){return _e(_0x12bc44['apply'](Xn(this),_0xcde097));};}function Bc(_0x295e3f){return typeof _0x295e3f=='function'?Wc(_0x295e3f):(_0x295e3f instanceof IDBTransaction&&Fc(_0x295e3f),Dc(_0x295e3f,Mc())?new Proxy(_0x295e3f,di):_0x295e3f);}function _e(_0x27c88b){if(_0x27c88b instanceof IDBRequest)return xc(_0x27c88b);if(Jn['has'](_0x27c88b))return Jn['get'](_0x27c88b);const _0x46ff14=Bc(_0x27c88b);return _0x46ff14!==_0x27c88b&&(Jn['set'](_0x27c88b,_0x46ff14),Fi['set'](_0x46ff14,_0x27c88b)),_0x46ff14;}const Xn=_0x6507e0=>Fi['get'](_0x6507e0);function Vc(_0x4fefad,_0x2c17fc,{blocked:_0x4184a1,upgrade:_0x53ef7b,blocking:_0x3c8b9e,terminated:_0x47c8a7}={}){const _0x3c9fa3=indexedDB['open'](_0x4fefad,_0x2c17fc),_0x779595=_e(_0x3c9fa3);return _0x53ef7b&&_0x3c9fa3['addEventListener']('upgradeneeded',_0x54e11a=>{_0x53ef7b(_e(_0x3c9fa3['result']),_0x54e11a['oldVersion'],_0x54e11a['newVersion'],_e(_0x3c9fa3['transaction']),_0x54e11a);}),_0x4184a1&&_0x3c9fa3['addEventListener']('blocked',_0x181b08=>_0x4184a1(_0x181b08['oldVersion'],_0x181b08['newVersion'],_0x181b08)),_0x779595['then'](_0x3862b6=>{_0x47c8a7&&_0x3862b6['addEventListener']('close',()=>_0x47c8a7()),_0x3c8b9e&&_0x3862b6['addEventListener']('versionchange',_0x315f36=>_0x3c8b9e(_0x315f36['oldVersion'],_0x315f36['newVersion'],_0x315f36));})['catch'](()=>{}),_0x779595;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0xc29a17,_0x567ead){if(!(_0xc29a17 instanceof IDBDatabase&&!(_0x567ead in _0xc29a17)&&typeof _0x567ead=='string'))return;if(Zn['get'](_0x567ead))return Zn['get'](_0x567ead);const _0x2050d9=_0x567ead['replace'](/FromIndex$/,''),_0x526e99=_0x567ead!==_0x2050d9,_0x346e22=$c['includes'](_0x2050d9);if(!(_0x2050d9 in(_0x526e99?IDBIndex:IDBObjectStore)['prototype'])||!(_0x346e22||Hc['includes'](_0x2050d9)))return;const _0x173b2e=async function(_0x178ee7,..._0x599208){const _0x2d1aac=this['transaction'](_0x178ee7,_0x346e22?'readwrite':'readonly');let _0x5bafa3=_0x2d1aac['store'];return _0x526e99&&(_0x5bafa3=_0x5bafa3['index'](_0x599208['shift']())),(await Promise['all']([_0x5bafa3[_0x2050d9](..._0x599208),_0x346e22&&_0x2d1aac['done']]))[0x0];};return Zn['set'](_0x567ead,_0x173b2e),_0x173b2e;}Uc(_0x404f08=>({..._0x404f08,'get':(_0x1475f8,_0x44d09a,_0xdaab88)=>Os(_0x1475f8,_0x44d09a)||_0x404f08['get'](_0x1475f8,_0x44d09a,_0xdaab88),'has':(_0x30cf85,_0x3f2b13)=>!!Os(_0x30cf85,_0x3f2b13)||_0x404f08['has'](_0x30cf85,_0x3f2b13)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x36661b){this['container']=_0x36661b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5436fa=>{if(qc(_0x5436fa)){const _0x20da2d=_0x5436fa['getImmediate']();return _0x20da2d['library']+'/'+_0x20da2d['version'];}else return null;})['filter'](_0x13a96a=>_0x13a96a)['join']('\x20');}}function qc(_0x41ba98){const _0xa552bd=_0x41ba98['getComponent']();return(_0xa552bd==null?void 0x0:_0xa552bd['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x4b7a83,_0x4f238a){try{_0x4b7a83['container']['addComponent'](_0x4f238a);}catch(_0x1ab47f){re['debug']('Component\x20'+_0x4f238a['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4b7a83['name'],_0x1ab47f);}}function et(_0x56b9c6){const _0x264724=_0x56b9c6['name'];if(gi['has'](_0x264724))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x264724+'.'),!0x1;gi['set'](_0x264724,_0x56b9c6);for(const _0x27e4ba of Le['values']())Ms(_0x27e4ba,_0x56b9c6);for(const _0x2c521b of _i['values']())Ms(_0x2c521b,_0x56b9c6);return!0x0;}function Ui(_0x15e93f,_0x40ba75){const _0x3edb8c=_0x15e93f['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3edb8c&&_0x3edb8c['triggerHeartbeat'](),_0x15e93f['container']['getProvider'](_0x40ba75);}function H(_0x50701f){return _0x50701f==null?!0x1:_0x50701f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x1fdd19,_0x9b68e,_0x27e17a){this['_isDeleted']=!0x1,this['_options']={..._0x1fdd19},this['_config']={..._0x9b68e},this['_name']=_0x9b68e['name'],this['_automaticDataCollectionEnabled']=_0x9b68e['automaticDataCollectionEnabled'],this['_container']=_0x27e17a,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x852189){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x852189;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5ee377){this['_isDeleted']=_0x5ee377;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x514f15,_0x4daa6c={}){let _0x1e7ef6=_0x514f15;typeof _0x4daa6c!='object'&&(_0x4daa6c={'name':_0x4daa6c});const _0x4c4887={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x4daa6c},_0x5256c6=_0x4c4887['name'];if(typeof _0x5256c6!='string'||!_0x5256c6)throw ge['create']('bad-app-name',{'appName':String(_0x5256c6)});if(_0x1e7ef6||(_0x1e7ef6=$r()),!_0x1e7ef6)throw ge['create']('no-options');const _0x8ca25b=Le['get'](_0x5256c6);if(_0x8ca25b){if(De(_0x1e7ef6,_0x8ca25b['options'])&&De(_0x4c4887,_0x8ca25b['config']))return _0x8ca25b;throw ge['create']('duplicate-app',{'appName':_0x5256c6});}const _0x3f8ab4=new Ac(_0x5256c6);for(const _0x413649 of gi['values']())_0x3f8ab4['addComponent'](_0x413649);const _0x47d1dd=new Il(_0x1e7ef6,_0x4c4887,_0x3f8ab4);return Le['set'](_0x5256c6,_0x47d1dd),_0x47d1dd;}function Qr(_0x3a21b2=pi){const _0x38c7eb=Le['get'](_0x3a21b2);if(!_0x38c7eb&&_0x3a21b2===pi&&$r())return wl();if(!_0x38c7eb)throw ge['create']('no-app',{'appName':_0x3a21b2});return _0x38c7eb;}function l_(){return Array['from'](Le['values']());}async function h_(_0x5a68e5){let _0x2c738d=!0x1;const _0x579686=_0x5a68e5['name'];Le['has'](_0x579686)?(_0x2c738d=!0x0,Le['delete'](_0x579686)):_i['has'](_0x579686)&&_0x5a68e5['decRefCount']()<=0x0&&(_i['delete'](_0x579686),_0x2c738d=!0x0),_0x2c738d&&(await Promise['all'](_0x5a68e5['container']['getProviders']()['map'](_0x1803e8=>_0x1803e8['delete']())),_0x5a68e5['isDeleted']=!0x0);}function me(_0x252bba,_0x507fdc,_0x590c08){let _0xa9d61=vl[_0x252bba]??_0x252bba;_0x590c08&&(_0xa9d61+='-'+_0x590c08);const _0x5993b7=_0xa9d61['match'](/\s|\//),_0x511ea4=_0x507fdc['match'](/\s|\//);if(_0x5993b7||_0x511ea4){const _0x285d1e=['Unable\x20to\x20register\x20library\x20\x22'+_0xa9d61+'\x22\x20with\x20version\x20\x22'+_0x507fdc+'\x22:'];_0x5993b7&&_0x285d1e['push']('library\x20name\x20\x22'+_0xa9d61+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5993b7&&_0x511ea4&&_0x285d1e['push']('and'),_0x511ea4&&_0x285d1e['push']('version\x20name\x20\x22'+_0x507fdc+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x285d1e['join']('\x20'));return;}et(new Me(_0xa9d61+'-version',()=>({'library':_0xa9d61,'version':_0x507fdc}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x4a6519,_0xb09c4a)=>{switch(_0xb09c4a){case 0x0:try{_0x4a6519['createObjectStore'](Rt);}catch(_0x44af01){console['warn'](_0x44af01);}}}})['catch'](_0x1bc228=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x1bc228['message']});})),ei;}async function Sl(_0x47a818){try{const _0x5e8c19=(await Jr())['transaction'](Rt),_0x3ca74b=await _0x5e8c19['objectStore'](Rt)['get'](Xr(_0x47a818));return await _0x5e8c19['done'],_0x3ca74b;}catch(_0x46fd2f){if(_0x46fd2f instanceof Se)re['warn'](_0x46fd2f['message']);else{const _0x507a10=ge['create']('idb-get',{'originalErrorMessage':_0x46fd2f==null?void 0x0:_0x46fd2f['message']});re['warn'](_0x507a10['message']);}}}async function Ls(_0x1233d7,_0x3019d3){try{const _0x4044be=(await Jr())['transaction'](Rt,'readwrite');await _0x4044be['objectStore'](Rt)['put'](_0x3019d3,Xr(_0x1233d7)),await _0x4044be['done'];}catch(_0x507f14){if(_0x507f14 instanceof Se)re['warn'](_0x507f14['message']);else{const _0x1062e7=ge['create']('idb-set',{'originalErrorMessage':_0x507f14==null?void 0x0:_0x507f14['message']});re['warn'](_0x1062e7['message']);}}}function Xr(_0x3b3bc5){return _0x3b3bc5['name']+'!'+_0x3b3bc5['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x9c492a){this['container']=_0x9c492a,this['_heartbeatsCache']=null;const _0x1cc604=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x1cc604),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x22ffa8=>(this['_heartbeatsCache']=_0x22ffa8,_0x22ffa8));}async['triggerHeartbeat'](){var _0x34a0a8,_0x348b45;try{const _0x24a593=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3a0e18=xs();if(((_0x34a0a8=this['_heartbeatsCache'])==null?void 0x0:_0x34a0a8['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x348b45=this['_heartbeatsCache'])==null?void 0x0:_0x348b45['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3a0e18||this['_heartbeatsCache']['heartbeats']['some'](_0x4845e3=>_0x4845e3['date']===_0x3a0e18))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3a0e18,'agent':_0x24a593}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x4fe553=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4fe553,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4541b0){re['warn'](_0x4541b0);}}async['getHeartbeatsHeader'](){var _0x4bf853;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4bf853=this['_heartbeatsCache'])==null?void 0x0:_0x4bf853['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x51fdae=xs(),{heartbeatsToSend:_0x539720,unsentEntries:_0x5644fb}=kl(this['_heartbeatsCache']['heartbeats']),_0x51fe79=an(JSON['stringify']({'version':0x2,'heartbeats':_0x539720}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x51fdae,_0x5644fb['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x5644fb,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x51fe79;}catch(_0xfbfb8a){return re['warn'](_0xfbfb8a),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0xfdf28,_0x409e19=bl){const _0x3f20bf=[];let _0x5866fc=_0xfdf28['slice']();for(const _0x47bf07 of _0xfdf28){const _0x25b0d4=_0x3f20bf['find'](_0x51ee5d=>_0x51ee5d['agent']===_0x47bf07['agent']);if(_0x25b0d4){if(_0x25b0d4['dates']['push'](_0x47bf07['date']),Fs(_0x3f20bf)>_0x409e19){_0x25b0d4['dates']['pop']();break;}}else{if(_0x3f20bf['push']({'agent':_0x47bf07['agent'],'dates':[_0x47bf07['date']]}),Fs(_0x3f20bf)>_0x409e19){_0x3f20bf['pop']();break;}}_0x5866fc=_0x5866fc['slice'](0x1);}return{'heartbeatsToSend':_0x3f20bf,'unsentEntries':_0x5866fc};}class Nl{constructor(_0x270cbd){this['app']=_0x270cbd,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x17a6cd=await Sl(this['app']);return _0x17a6cd!=null&&_0x17a6cd['heartbeats']?_0x17a6cd:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4945de){if(await this['_canUseIndexedDBPromise']){const _0x5c9225=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4945de['lastSentHeartbeatDate']??_0x5c9225['lastSentHeartbeatDate'],'heartbeats':_0x4945de['heartbeats']});}else return;}async['add'](_0x5c60e0){if(await this['_canUseIndexedDBPromise']){const _0x509628=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5c60e0['lastSentHeartbeatDate']??_0x509628['lastSentHeartbeatDate'],'heartbeats':[..._0x509628['heartbeats'],..._0x5c60e0['heartbeats']]});}else return;}}function Fs(_0x5b2389){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x5b2389}))['length'];}function Pl(_0x5f3bba){if(_0x5f3bba['length']===0x0)return-0x1;let _0x54ec5d=0x0,_0x32af1a=_0x5f3bba[0x0]['date'];for(let _0x55a4c7=0x1;_0x55a4c7<_0x5f3bba['length'];_0x55a4c7++)_0x5f3bba[_0x55a4c7]['date']<_0x32af1a&&(_0x32af1a=_0x5f3bba[_0x55a4c7]['date'],_0x54ec5d=_0x55a4c7);return _0x54ec5d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4bee10){et(new Me('platform-logger',_0x3e947d=>new Gc(_0x3e947d),'PRIVATE')),et(new Me('heartbeat',_0x1ad646=>new Al(_0x1ad646),'PRIVATE')),me(fi,Ds,_0x4bee10),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x46970e){Zr=_0x46970e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x1b719a){this['domStorage_']=_0x1b719a,this['prefix_']='firebase:';}['set'](_0x31c4b7,_0x22ad91){_0x22ad91==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x31c4b7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x31c4b7),O(_0x22ad91));}['get'](_0x33e917){const _0x2f3a4c=this['domStorage_']['getItem'](this['prefixedName_'](_0x33e917));return _0x2f3a4c==null?null:bt(_0x2f3a4c);}['remove'](_0x10deea){this['domStorage_']['removeItem'](this['prefixedName_'](_0x10deea));}['prefixedName_'](_0x403efe){return this['prefix_']+_0x403efe;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x19d6bb,_0x58e567){_0x58e567==null?delete this['cache_'][_0x19d6bb]:this['cache_'][_0x19d6bb]=_0x58e567;}['get'](_0x376d39){return Y(this['cache_'],_0x376d39)?this['cache_'][_0x376d39]:null;}['remove'](_0x1288a3){delete this['cache_'][_0x1288a3];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x1914f9){try{if(typeof window<'u'&&typeof window[_0x1914f9]<'u'){const _0x5be6d1=window[_0x1914f9];return _0x5be6d1['setItem']('firebase:sentinel','cache'),_0x5be6d1['removeItem']('firebase:sentinel'),new xl(_0x5be6d1);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x3b197a=0x1;return function(){return _0x3b197a++;};}()),no=function(_0x3bf837){const _0x11810b=Tc(_0x3bf837),_0x281a05=new Ec();_0x281a05['update'](_0x11810b);const _0x49ec7e=_0x281a05['digest']();return Di['encodeByteArray'](_0x49ec7e);},Bt=function(..._0x21afce){let _0x3d2d01='';for(let _0x433efc=0x0;_0x433efc<_0x21afce['length'];_0x433efc++){const _0x233e17=_0x21afce[_0x433efc];Array['isArray'](_0x233e17)||_0x233e17&&typeof _0x233e17=='object'&&typeof _0x233e17['length']=='number'?_0x3d2d01+=Bt['apply'](null,_0x233e17):typeof _0x233e17=='object'?_0x3d2d01+=O(_0x233e17):_0x3d2d01+=_0x233e17,_0x3d2d01+='\x20';}return _0x3d2d01;};let Et=null,Vs=!0x0;const Wl=function(_0x44e3b8,_0x513453){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5ea679){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x21f714=Bt['apply'](null,_0x5ea679);Et(_0x21f714);}},Vt=function(_0x564bc5){return function(..._0x19528d){L(_0x564bc5,..._0x19528d);};},mi=function(..._0x216011){const _0x585fee='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x216011);Qe['error'](_0x585fee);},oe=function(..._0x1c50a6){const _0x14803c='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x1c50a6);throw Qe['error'](_0x14803c),new Error(_0x14803c);},U=function(..._0x4ee0c3){const _0x2af3eb='FIREBASE\x20WARNING:\x20'+Bt(..._0x4ee0c3);Qe['warn'](_0x2af3eb);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x27ab95){return typeof _0x27ab95=='number'&&(_0x27ab95!==_0x27ab95||_0x27ab95===Number['POSITIVE_INFINITY']||_0x27ab95===Number['NEGATIVE_INFINITY']);},Vl=function(_0x2fcc94){if(document['readyState']==='complete')_0x2fcc94();else{let _0x464c5f=!0x1;const _0x21b210=function(){if(!document['body']){setTimeout(_0x21b210,Math['floor'](0xa));return;}_0x464c5f||(_0x464c5f=!0x0,_0x2fcc94());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x21b210,!0x1),window['addEventListener']('load',_0x21b210,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x21b210();}),window['attachEvent']('onload',_0x21b210));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x308f47,_0x34a36f){if(_0x308f47===_0x34a36f)return 0x0;if(_0x308f47===xe||_0x34a36f===Ie)return-0x1;if(_0x34a36f===xe||_0x308f47===Ie)return 0x1;{const _0x583c89=Hs(_0x308f47),_0x45f74a=Hs(_0x34a36f);return _0x583c89!==null?_0x45f74a!==null?_0x583c89-_0x45f74a===0x0?_0x308f47['length']-_0x34a36f['length']:_0x583c89-_0x45f74a:-0x1:_0x45f74a!==null?0x1:_0x308f47<_0x34a36f?-0x1:0x1;}},Hl=function(_0xa46daa,_0x272c0b){return _0xa46daa===_0x272c0b?0x0:_0xa46daa<_0x272c0b?-0x1:0x1;},pt=function(_0x1e20ac,_0x4c20db){if(_0x4c20db&&_0x1e20ac in _0x4c20db)return _0x4c20db[_0x1e20ac];throw new Error('Missing\x20required\x20key\x20('+_0x1e20ac+')\x20in\x20object:\x20'+O(_0x4c20db));},Bi=function(_0x1f0b99){if(typeof _0x1f0b99!='object'||_0x1f0b99===null)return O(_0x1f0b99);const _0x56d6bc=[];for(const _0x358874 in _0x1f0b99)_0x56d6bc['push'](_0x358874);_0x56d6bc['sort']();let _0x182fba='{';for(let _0x56a5c1=0x0;_0x56a5c1<_0x56d6bc['length'];_0x56a5c1++)_0x56a5c1!==0x0&&(_0x182fba+=','),_0x182fba+=O(_0x56d6bc[_0x56a5c1]),_0x182fba+=':',_0x182fba+=Bi(_0x1f0b99[_0x56d6bc[_0x56a5c1]]);return _0x182fba+='}',_0x182fba;},io=function(_0x29d79b,_0xc7e6fa){const _0x4b86c6=_0x29d79b['length'];if(_0x4b86c6<=_0xc7e6fa)return[_0x29d79b];const _0x45c3fb=[];for(let _0x1b02b7=0x0;_0x1b02b7<_0x4b86c6;_0x1b02b7+=_0xc7e6fa)_0x1b02b7+_0xc7e6fa>_0x4b86c6?_0x45c3fb['push'](_0x29d79b['substring'](_0x1b02b7,_0x4b86c6)):_0x45c3fb['push'](_0x29d79b['substring'](_0x1b02b7,_0x1b02b7+_0xc7e6fa));return _0x45c3fb;};function x(_0x1b93de,_0x722c79){for(const _0x19bc73 in _0x1b93de)_0x1b93de['hasOwnProperty'](_0x19bc73)&&_0x722c79(_0x19bc73,_0x1b93de[_0x19bc73]);}const so=function(_0x4d6683){f(!Wi(_0x4d6683),'Invalid\x20JSON\x20number');const _0x2246e0=0xb,_0x342f96=0x34,_0x245dfc=(0x1<<_0x2246e0-0x1)-0x1;let _0x37410a,_0x5004ab,_0x328cf6,_0x1fa27d,_0x5f326f;_0x4d6683===0x0?(_0x5004ab=0x0,_0x328cf6=0x0,_0x37410a=0x1/_0x4d6683===-0x1/0x0?0x1:0x0):(_0x37410a=_0x4d6683<0x0,_0x4d6683=Math['abs'](_0x4d6683),_0x4d6683>=Math['pow'](0x2,0x1-_0x245dfc)?(_0x1fa27d=Math['min'](Math['floor'](Math['log'](_0x4d6683)/Math['LN2']),_0x245dfc),_0x5004ab=_0x1fa27d+_0x245dfc,_0x328cf6=Math['round'](_0x4d6683*Math['pow'](0x2,_0x342f96-_0x1fa27d)-Math['pow'](0x2,_0x342f96))):(_0x5004ab=0x0,_0x328cf6=Math['round'](_0x4d6683/Math['pow'](0x2,0x1-_0x245dfc-_0x342f96))));const _0x4c9733=[];for(_0x5f326f=_0x342f96;_0x5f326f;_0x5f326f-=0x1)_0x4c9733['push'](_0x328cf6%0x2?0x1:0x0),_0x328cf6=Math['floor'](_0x328cf6/0x2);for(_0x5f326f=_0x2246e0;_0x5f326f;_0x5f326f-=0x1)_0x4c9733['push'](_0x5004ab%0x2?0x1:0x0),_0x5004ab=Math['floor'](_0x5004ab/0x2);_0x4c9733['push'](_0x37410a?0x1:0x0),_0x4c9733['reverse']();const _0x43fde6=_0x4c9733['join']('');let _0x48f04c='';for(_0x5f326f=0x0;_0x5f326f<0x40;_0x5f326f+=0x8){let _0x1a8af5=parseInt(_0x43fde6['substr'](_0x5f326f,0x8),0x2)['toString'](0x10);_0x1a8af5['length']===0x1&&(_0x1a8af5='0'+_0x1a8af5),_0x48f04c=_0x48f04c+_0x1a8af5;}return _0x48f04c['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x4e1b0d,_0x2bce8a){let _0x564611='Unknown\x20Error';_0x4e1b0d==='too_big'?_0x564611='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4e1b0d==='permission_denied'?_0x564611='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4e1b0d==='unavailable'&&(_0x564611='The\x20service\x20is\x20unavailable');const _0x42f360=new Error(_0x4e1b0d+'\x20at\x20'+_0x2bce8a['_path']['toString']()+':\x20'+_0x564611);return _0x42f360['code']=_0x4e1b0d['toUpperCase'](),_0x42f360;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x5bf466){if(zl['test'](_0x5bf466)){const _0x4b9770=Number(_0x5bf466);if(_0x4b9770>=jl&&_0x4b9770<=Kl)return _0x4b9770;}return null;},lt=function(_0x192e20){try{_0x192e20();}catch(_0x377a46){setTimeout(()=>{const _0xc4059e=_0x377a46['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xc4059e),_0x377a46;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x6fb2ff,_0x4e84ff){const _0x32936a=setTimeout(_0x6fb2ff,_0x4e84ff);return typeof _0x32936a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x32936a):typeof _0x32936a=='object'&&_0x32936a['unref']&&_0x32936a['unref'](),_0x32936a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x5f0fb3,_0x3ac6e){this['appCheckProvider']=_0x3ac6e,this['appName']=_0x5f0fb3['name'],H(_0x5f0fb3)&&_0x5f0fb3['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5f0fb3['settings']['appCheckToken']),this['appCheck']=_0x3ac6e==null?void 0x0:_0x3ac6e['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3ac6e==null||_0x3ac6e['get']()['then'](_0x3ed33a=>this['appCheck']=_0x3ed33a);}['getToken'](_0x2e3237){if(this['serverAppAppCheckToken']){if(_0x2e3237)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2e3237):new Promise((_0x1e95a7,_0x23c7f1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2e3237)['then'](_0x1e95a7,_0x23c7f1):_0x1e95a7(null);},0x0);});}['addTokenChangeListener'](_0x365985){var _0x10bde1;(_0x10bde1=this['appCheckProvider'])==null||_0x10bde1['get']()['then'](_0x5eaa48=>_0x5eaa48['addTokenListener'](_0x365985));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4bd221,_0x34a5ac,_0x3240d5){this['appName_']=_0x4bd221,this['firebaseOptions_']=_0x34a5ac,this['authProvider_']=_0x3240d5,this['auth_']=null,this['auth_']=_0x3240d5['getImmediate']({'optional':!0x0}),this['auth_']||_0x3240d5['onInit'](_0x7ee1f3=>this['auth_']=_0x7ee1f3);}['getToken'](_0x20a6d5){return this['auth_']?this['auth_']['getToken'](_0x20a6d5)['catch'](_0x483510=>_0x483510&&_0x483510['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x483510)):new Promise((_0x1688ee,_0x48bc2d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x20a6d5)['then'](_0x1688ee,_0x48bc2d):_0x1688ee(null);},0x0);});}['addTokenChangeListener'](_0x4c764f){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4c764f):this['authProvider_']['get']()['then'](_0x3cf946=>_0x3cf946['addAuthTokenListener'](_0x4c764f));}['removeTokenChangeListener'](_0xbbfd99){this['authProvider_']['get']()['then'](_0x22b605=>_0x22b605['removeAuthTokenListener'](_0xbbfd99));}['notifyForInvalidToken'](){let _0x198c2b='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x198c2b+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x198c2b+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x198c2b+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x198c2b);}}class tn{constructor(_0x35c65e){this['accessToken']=_0x35c65e;}['getToken'](_0x3d6ed2){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x547b84){_0x547b84(this['accessToken']);}['removeTokenChangeListener'](_0x481148){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x1bd168,_0x1314dd,_0x895d8b,_0x3269dc,_0x2b8c41=!0x1,_0x3b49a1='',_0x50f01e=!0x1,_0x45e885=!0x1,_0x44e782=null){this['secure']=_0x1314dd,this['namespace']=_0x895d8b,this['webSocketOnly']=_0x3269dc,this['nodeAdmin']=_0x2b8c41,this['persistenceKey']=_0x3b49a1,this['includeNamespaceInQueryParams']=_0x50f01e,this['isUsingEmulator']=_0x45e885,this['emulatorOptions']=_0x44e782,this['_host']=_0x1bd168['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x1bd168)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x191cd7){_0x191cd7!==this['internalHost']&&(this['internalHost']=_0x191cd7,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4832e8=this['toURLString']();return this['persistenceKey']&&(_0x4832e8+='<'+this['persistenceKey']+'>'),_0x4832e8;}['toURLString'](){const _0x4d5db7=this['secure']?'https://':'http://',_0x5a604c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4d5db7+this['host']+'/'+_0x5a604c;}}function Xl(_0x42fde3){return _0x42fde3['host']!==_0x42fde3['internalHost']||_0x42fde3['isCustomHost']()||_0x42fde3['includeNamespaceInQueryParams'];}function go(_0x4da5f6,_0x43028e,_0x5e8117){f(typeof _0x43028e=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5e8117=='object','typeof\x20params\x20must\x20==\x20object');let _0x5900d1;if(_0x43028e===fo)_0x5900d1=(_0x4da5f6['secure']?'wss://':'ws://')+_0x4da5f6['internalHost']+'/.ws?';else{if(_0x43028e===po)_0x5900d1=(_0x4da5f6['secure']?'https://':'http://')+_0x4da5f6['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x43028e);}Xl(_0x4da5f6)&&(_0x5e8117['ns']=_0x4da5f6['namespace']);const _0x518a83=[];return x(_0x5e8117,(_0x48909d,_0x5850c8)=>{_0x518a83['push'](_0x48909d+'='+_0x5850c8);}),_0x5900d1+_0x518a83['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x184511,_0x3d72a6=0x1){Y(this['counters_'],_0x184511)||(this['counters_'][_0x184511]=0x0),this['counters_'][_0x184511]+=_0x3d72a6;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x246067){const _0x356be2=_0x246067['toString']();return ti[_0x356be2]||(ti[_0x356be2]=new Zl()),ti[_0x356be2];}function eh(_0x2e3bf5,_0x5bea8e){const _0x4dd661=_0x2e3bf5['toString']();return ni[_0x4dd661]||(ni[_0x4dd661]=_0x5bea8e()),ni[_0x4dd661];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5ed5b2){this['onMessage_']=_0x5ed5b2,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x441087,_0x2f369b){this['closeAfterResponse']=_0x441087,this['onClose']=_0x2f369b,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x565d21,_0x708aba){for(this['pendingResponses'][_0x565d21]=_0x708aba;this['pendingResponses'][this['currentResponseNum']];){const _0x28aef8=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x28ea95=0x0;_0x28ea95<_0x28aef8['length'];++_0x28ea95)_0x28aef8[_0x28ea95]&&lt(()=>{this['onMessage_'](_0x28aef8[_0x28ea95]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x51ef10,_0x719e8c,_0x235a42,_0x4f3f6a,_0x57c892,_0x9e15b4,_0xbca57f){this['connId']=_0x51ef10,this['repoInfo']=_0x719e8c,this['applicationId']=_0x235a42,this['appCheckToken']=_0x4f3f6a,this['authToken']=_0x57c892,this['transportSessionId']=_0x9e15b4,this['lastSessionId']=_0xbca57f,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x51ef10),this['stats_']=Hi(_0x719e8c),this['urlFn']=_0x5d19fc=>(this['appCheckToken']&&(_0x5d19fc[yi]=this['appCheckToken']),go(_0x719e8c,po,_0x5d19fc));}['open'](_0x2ecd29,_0xb21ace){this['curSegmentNum']=0x0,this['onDisconnect_']=_0xb21ace,this['myPacketOrderer']=new th(_0x2ecd29),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x54cb58)=>{const [_0x1915f6,_0x581dc8,_0x2bf695,_0x4abc64,_0x262afc]=_0x54cb58;if(this['incrementIncomingBytes_'](_0x54cb58),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1915f6===$s)this['id']=_0x581dc8,this['password']=_0x2bf695;else{if(_0x1915f6===nh)_0x581dc8?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x581dc8,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1915f6);}}},(..._0x40da9d)=>{const [_0x380409,_0x5baf2f]=_0x40da9d;this['incrementIncomingBytes_'](_0x40da9d),this['myPacketOrderer']['handleResponse'](_0x380409,_0x5baf2f);},()=>{this['onClosed_']();},this['urlFn']);const _0x1b8a1f={};_0x1b8a1f[$s]='t',_0x1b8a1f[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1b8a1f[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1b8a1f[ro]=Vi,this['transportSessionId']&&(_0x1b8a1f[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1b8a1f[ho]=this['lastSessionId']),this['applicationId']&&(_0x1b8a1f[uo]=this['applicationId']),this['appCheckToken']&&(_0x1b8a1f[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1b8a1f[ao]=co);const _0x7b1543=this['urlFn'](_0x1b8a1f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x7b1543),this['scriptTagHolder']['addTag'](_0x7b1543,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5dda44){const _0x17b7be=O(_0x5dda44);this['bytesSent']+=_0x17b7be['length'],this['stats_']['incrementCounter']('bytes_sent',_0x17b7be['length']);const _0x4d7724=Br(_0x17b7be),_0x158f7b=io(_0x4d7724,hh);for(let _0x1bc606=0x0;_0x1bc606<_0x158f7b['length'];_0x1bc606++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x158f7b['length'],_0x158f7b[_0x1bc606]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x41be97,_0x5dc182){this['myDisconnFrame']=document['createElement']('iframe');const _0x5f19f5={};_0x5f19f5[lh]='t',_0x5f19f5[mo]=_0x41be97,_0x5f19f5[yo]=_0x5dc182,this['myDisconnFrame']['src']=this['urlFn'](_0x5f19f5),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1f06ae){const _0x4bf6fa=O(_0x1f06ae)['length'];this['bytesReceived']+=_0x4bf6fa,this['stats_']['incrementCounter']('bytes_received',_0x4bf6fa);}}class $i{constructor(_0x513ccd,_0x5658d9,_0x29fb18,_0x402de9){this['onDisconnect']=_0x29fb18,this['urlFn']=_0x402de9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x513ccd,window[sh+this['uniqueCallbackIdentifier']]=_0x5658d9,this['myIFrame']=$i['createIFrame_']();let _0x132287='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x132287='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x14d54c='<html><body>'+_0x132287+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x14d54c),this['myIFrame']['doc']['close']();}catch(_0x2661c5){L('frame\x20writing\x20exception'),_0x2661c5['stack']&&L(_0x2661c5['stack']),L(_0x2661c5);}}}static['createIFrame_'](){const _0x2a8622=document['createElement']('iframe');if(_0x2a8622['style']['display']='none',document['body']){document['body']['appendChild'](_0x2a8622);try{_0x2a8622['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x54dbf0=document['domain'];_0x2a8622['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x54dbf0+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2a8622['contentDocument']?_0x2a8622['doc']=_0x2a8622['contentDocument']:_0x2a8622['contentWindow']?_0x2a8622['doc']=_0x2a8622['contentWindow']['document']:_0x2a8622['document']&&(_0x2a8622['doc']=_0x2a8622['document']),_0x2a8622;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x12584d=this['onDisconnect'];_0x12584d&&(this['onDisconnect']=null,_0x12584d());}['startLongPoll'](_0x30cc87,_0x3bcfda){for(this['myID']=_0x30cc87,this['myPW']=_0x3bcfda,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1522fe={};_0x1522fe[mo]=this['myID'],_0x1522fe[yo]=this['myPW'],_0x1522fe[vo]=this['currentSerial'];let _0x423bc0=this['urlFn'](_0x1522fe),_0x57dd94='',_0x35c35a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x57dd94['length']<=Eo;){const _0x52f736=this['pendingSegs']['shift']();_0x57dd94=_0x57dd94+'&'+oh+_0x35c35a+'='+_0x52f736['seg']+'&'+ah+_0x35c35a+'='+_0x52f736['ts']+'&'+ch+_0x35c35a+'='+_0x52f736['d'],_0x35c35a++;}return _0x423bc0=_0x423bc0+_0x57dd94,this['addLongPollTag_'](_0x423bc0,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3ece2d,_0x5095e4,_0x1ecc36){this['pendingSegs']['push']({'seg':_0x3ece2d,'ts':_0x5095e4,'d':_0x1ecc36}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x445c0e,_0x30248f){this['outstandingRequests']['add'](_0x30248f);const _0x2234aa=()=>{this['outstandingRequests']['delete'](_0x30248f),this['newRequest_']();},_0x380c1e=setTimeout(_0x2234aa,Math['floor'](uh)),_0x5a0290=()=>{clearTimeout(_0x380c1e),_0x2234aa();};this['addTag'](_0x445c0e,_0x5a0290);}['addTag'](_0x28903a,_0x1e0d8a){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x373816=this['myIFrame']['doc']['createElement']('script');_0x373816['type']='text/javascript',_0x373816['async']=!0x0,_0x373816['src']=_0x28903a,_0x373816['onload']=_0x373816['onreadystatechange']=function(){const _0x52e46b=_0x373816['readyState'];(!_0x52e46b||_0x52e46b==='loaded'||_0x52e46b==='complete')&&(_0x373816['onload']=_0x373816['onreadystatechange']=null,_0x373816['parentNode']&&_0x373816['parentNode']['removeChild'](_0x373816),_0x1e0d8a());},_0x373816['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x28903a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x373816);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x210b85,_0x59d00e,_0x5c5aa3,_0x212db5,_0x390e81,_0x27f5ad,_0x531512){this['connId']=_0x210b85,this['applicationId']=_0x5c5aa3,this['appCheckToken']=_0x212db5,this['authToken']=_0x390e81,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x59d00e),this['connURL']=G['connectionURL_'](_0x59d00e,_0x27f5ad,_0x531512,_0x212db5,_0x5c5aa3),this['nodeAdmin']=_0x59d00e['nodeAdmin'];}static['connectionURL_'](_0x358f1c,_0x54f50a,_0xbd498b,_0x416214,_0x5d45eb){const _0x53fd76={};return _0x53fd76[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x53fd76[ao]=co),_0x54f50a&&(_0x53fd76[oo]=_0x54f50a),_0xbd498b&&(_0x53fd76[ho]=_0xbd498b),_0x416214&&(_0x53fd76[yi]=_0x416214),_0x5d45eb&&(_0x53fd76[uo]=_0x5d45eb),go(_0x358f1c,fo,_0x53fd76);}['open'](_0x26961,_0x5cb6a8){this['onDisconnect']=_0x5cb6a8,this['onMessage']=_0x26961,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x3c2364;dc(),this['mySock']=new hn(this['connURL'],[],_0x3c2364);}catch(_0xd0cea3){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1b7dbf=_0xd0cea3['message']||_0xd0cea3['data'];_0x1b7dbf&&this['log_'](_0x1b7dbf),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x346776=>{this['handleIncomingFrame'](_0x346776);},this['mySock']['onerror']=_0x5b8af4=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x22011=_0x5b8af4['message']||_0x5b8af4['data'];_0x22011&&this['log_'](_0x22011),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x43e26a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xf60571=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x436128=navigator['userAgent']['match'](_0xf60571);_0x436128&&_0x436128['length']>0x1&&parseFloat(_0x436128[0x1])<4.4&&(_0x43e26a=!0x0);}return!_0x43e26a&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5b0b2f){if(this['frames']['push'](_0x5b0b2f),this['frames']['length']===this['totalFrames']){const _0x19f554=this['frames']['join']('');this['frames']=null;const _0x1d0958=bt(_0x19f554);this['onMessage'](_0x1d0958);}}['handleNewFrameCount_'](_0xf3ba2){this['totalFrames']=_0xf3ba2,this['frames']=[];}['extractFrameCount_'](_0x52af7b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x52af7b['length']<=0x6){const _0x3c9992=Number(_0x52af7b);if(!isNaN(_0x3c9992))return this['handleNewFrameCount_'](_0x3c9992),null;}return this['handleNewFrameCount_'](0x1),_0x52af7b;}['handleIncomingFrame'](_0x75b763){if(this['mySock']===null)return;const _0x5573ef=_0x75b763['data'];if(this['bytesReceived']+=_0x5573ef['length'],this['stats_']['incrementCounter']('bytes_received',_0x5573ef['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5573ef);else{const _0x35fb50=this['extractFrameCount_'](_0x5573ef);_0x35fb50!==null&&this['appendFrame_'](_0x35fb50);}}['send'](_0x19f02e){this['resetKeepAlive']();const _0xdc0952=O(_0x19f02e);this['bytesSent']+=_0xdc0952['length'],this['stats_']['incrementCounter']('bytes_sent',_0xdc0952['length']);const _0x9093ba=io(_0xdc0952,fh);_0x9093ba['length']>0x1&&this['sendString_'](String(_0x9093ba['length']));for(let _0x34b929=0x0;_0x34b929<_0x9093ba['length'];_0x34b929++)this['sendString_'](_0x9093ba[_0x34b929]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x1bed0e){try{this['mySock']['send'](_0x1bed0e);}catch(_0x3b6efc){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3b6efc['message']||_0x3b6efc['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4e1fc6){this['initTransports_'](_0x4e1fc6);}['initTransports_'](_0x1da855){const _0x30c70a=G&&G['isAvailable']();let _0x5c1744=_0x30c70a&&!G['previouslyFailed']();if(_0x1da855['webSocketOnly']&&(_0x30c70a||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5c1744=!0x0),_0x5c1744)this['transports_']=[G];else{const _0x56e302=this['transports_']=[];for(const _0x47a0f6 of At['ALL_TRANSPORTS'])_0x47a0f6&&_0x47a0f6['isAvailable']()&&_0x56e302['push'](_0x47a0f6);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x23b516,_0x408a2f,_0x411c63,_0xc810dc,_0x492ed1,_0x41a2ec,_0x269c27,_0x4b879e,_0x46874d,_0x55ad21){this['id']=_0x23b516,this['repoInfo_']=_0x408a2f,this['applicationId_']=_0x411c63,this['appCheckToken_']=_0xc810dc,this['authToken_']=_0x492ed1,this['onMessage_']=_0x41a2ec,this['onReady_']=_0x269c27,this['onDisconnect_']=_0x4b879e,this['onKill_']=_0x46874d,this['lastSessionId']=_0x55ad21,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x408a2f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2ae306=this['transportManager_']['initialTransport']();this['conn_']=new _0x2ae306(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2ae306['responsesRequiredToBeHealthy']||0x0;const _0x363934=this['connReceiver_'](this['conn_']),_0x1f763e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x363934,_0x1f763e);},Math['floor'](0x0));const _0xdddcf0=_0x2ae306['healthyTimeout']||0x0;_0xdddcf0>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xdddcf0)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x490f87){return _0x390114=>{_0x490f87===this['conn_']?this['onConnectionLost_'](_0x390114):_0x490f87===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x479942){return _0x5c25f4=>{this['state_']!==0x2&&(_0x479942===this['rx_']?this['onPrimaryMessageReceived_'](_0x5c25f4):_0x479942===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5c25f4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5f1b6a){const _0x2f3896={'t':'d','d':_0x5f1b6a};this['sendData_'](_0x2f3896);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x111b94){if(ii in _0x111b94){const _0x85dddf=_0x111b94[ii];_0x85dddf===js?this['upgradeIfSecondaryHealthy_']():_0x85dddf===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x85dddf===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x59c76a){const _0x13c087=pt('t',_0x59c76a),_0x4279e3=pt('d',_0x59c76a);if(_0x13c087==='c')this['onSecondaryControl_'](_0x4279e3);else{if(_0x13c087==='d')this['pendingDataMessages']['push'](_0x4279e3);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x13c087);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xd3370b){const _0x4b625b=pt('t',_0xd3370b),_0xe06f61=pt('d',_0xd3370b);_0x4b625b==='c'?this['onControl_'](_0xe06f61):_0x4b625b==='d'&&this['onDataMessage_'](_0xe06f61);}['onDataMessage_'](_0x80a87a){this['onPrimaryResponse_'](),this['onMessage_'](_0x80a87a);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x10da3d){const _0x27cf59=pt(ii,_0x10da3d);if(Gs in _0x10da3d){const _0xc83e71=_0x10da3d[Gs];if(_0x27cf59===Ih){const _0x18667={..._0xc83e71};this['repoInfo_']['isUsingEmulator']&&(_0x18667['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x18667);}else{if(_0x27cf59===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5ce8bc=0x0;_0x5ce8bc<this['pendingDataMessages']['length'];++_0x5ce8bc)this['onDataMessage_'](this['pendingDataMessages'][_0x5ce8bc]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x27cf59===vh?this['onConnectionShutdown_'](_0xc83e71):_0x27cf59===qs?this['onReset_'](_0xc83e71):_0x27cf59===Eh?mi('Server\x20Error:\x20'+_0xc83e71):_0x27cf59===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x27cf59);}}}['onHandshake_'](_0x454589){const _0xa78cd=_0x454589['ts'],_0x4aa7ef=_0x454589['v'],_0x2b0227=_0x454589['h'];this['sessionId']=_0x454589['s'],this['repoInfo_']['host']=_0x2b0227,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xa78cd),Vi!==_0x4aa7ef&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x22bd56=this['transportManager_']['upgradeTransport']();_0x22bd56&&this['startUpgrade_'](_0x22bd56);}['startUpgrade_'](_0x4860bc){this['secondaryConn_']=new _0x4860bc(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4860bc['responsesRequiredToBeHealthy']||0x0;const _0x55ced1=this['connReceiver_'](this['secondaryConn_']),_0x5c6913=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x55ced1,_0x5c6913),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x14c7d4){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x14c7d4),this['repoInfo_']['host']=_0x14c7d4,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x12be49,_0xdd3a7a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x12be49,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xdd3a7a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3712c5=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3712c5||this['rx_']===_0x3712c5)&&this['close']();}['onConnectionLost_'](_0x2365c2){this['conn_']=null,!_0x2365c2&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x81fc4f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x81fc4f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x573ab2){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x573ab2);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x63453d,_0x3b3abe,_0x42cc11,_0x49fb66){}['merge'](_0x2719a2,_0x4d7bd3,_0x1751a1,_0x18cfc5){}['refreshAuthToken'](_0x1413c7){}['refreshAppCheckToken'](_0x5a9d25){}['onDisconnectPut'](_0x421948,_0x2d6f02,_0x5eec1b){}['onDisconnectMerge'](_0x528dee,_0x38a3c8,_0x4751d2){}['onDisconnectCancel'](_0x18dff4,_0x2acde3){}['reportStats'](_0x2beae1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x19dac9){this['allowedEvents_']=_0x19dac9,this['listeners_']={},f(Array['isArray'](_0x19dac9)&&_0x19dac9['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5b5548,..._0x251453){if(Array['isArray'](this['listeners_'][_0x5b5548])){const _0x558237=[...this['listeners_'][_0x5b5548]];for(let _0x3039e3=0x0;_0x3039e3<_0x558237['length'];_0x3039e3++)_0x558237[_0x3039e3]['callback']['apply'](_0x558237[_0x3039e3]['context'],_0x251453);}}['on'](_0x2ac5d6,_0x1349a3,_0xbeb967){this['validateEventType_'](_0x2ac5d6),this['listeners_'][_0x2ac5d6]=this['listeners_'][_0x2ac5d6]||[],this['listeners_'][_0x2ac5d6]['push']({'callback':_0x1349a3,'context':_0xbeb967});const _0x186020=this['getInitialEvent'](_0x2ac5d6);_0x186020&&_0x1349a3['apply'](_0xbeb967,_0x186020);}['off'](_0x232a8c,_0x60cfc6,_0x4e7df7){this['validateEventType_'](_0x232a8c);const _0x2c7504=this['listeners_'][_0x232a8c]||[];for(let _0x982cf0=0x0;_0x982cf0<_0x2c7504['length'];_0x982cf0++)if(_0x2c7504[_0x982cf0]['callback']===_0x60cfc6&&(!_0x4e7df7||_0x4e7df7===_0x2c7504[_0x982cf0]['context'])){_0x2c7504['splice'](_0x982cf0,0x1);return;}}['validateEventType_'](_0x3c34e6){f(this['allowedEvents_']['find'](_0x53c109=>_0x53c109===_0x3c34e6),'Unknown\x20event:\x20'+_0x3c34e6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x24ef85){return f(_0x24ef85==='online','Unknown\x20event\x20type:\x20'+_0x24ef85),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x3e3ea7,_0x6f2c44){if(_0x6f2c44===void 0x0){this['pieces_']=_0x3e3ea7['split']('/');let _0x50c56a=0x0;for(let _0x250e52=0x0;_0x250e52<this['pieces_']['length'];_0x250e52++)this['pieces_'][_0x250e52]['length']>0x0&&(this['pieces_'][_0x50c56a]=this['pieces_'][_0x250e52],_0x50c56a++);this['pieces_']['length']=_0x50c56a,this['pieceNum_']=0x0;}else this['pieces_']=_0x3e3ea7,this['pieceNum_']=_0x6f2c44;}['toString'](){let _0x4f47ec='';for(let _0x3ddf6e=this['pieceNum_'];_0x3ddf6e<this['pieces_']['length'];_0x3ddf6e++)this['pieces_'][_0x3ddf6e]!==''&&(_0x4f47ec+='/'+this['pieces_'][_0x3ddf6e]);return _0x4f47ec||'/';}}function w(){return new C('');}function y(_0x2e49a4){return _0x2e49a4['pieceNum_']>=_0x2e49a4['pieces_']['length']?null:_0x2e49a4['pieces_'][_0x2e49a4['pieceNum_']];}function we(_0x3c0a79){return _0x3c0a79['pieces_']['length']-_0x3c0a79['pieceNum_'];}function b(_0x50000d){let _0x590a44=_0x50000d['pieceNum_'];return _0x590a44<_0x50000d['pieces_']['length']&&_0x590a44++,new C(_0x50000d['pieces_'],_0x590a44);}function Gi(_0x3b9c42){return _0x3b9c42['pieceNum_']<_0x3b9c42['pieces_']['length']?_0x3b9c42['pieces_'][_0x3b9c42['pieces_']['length']-0x1]:null;}function Ch(_0x568dda){let _0x23eae9='';for(let _0x155358=_0x568dda['pieceNum_'];_0x155358<_0x568dda['pieces_']['length'];_0x155358++)_0x568dda['pieces_'][_0x155358]!==''&&(_0x23eae9+='/'+encodeURIComponent(String(_0x568dda['pieces_'][_0x155358])));return _0x23eae9||'/';}function kt(_0x4bebeb,_0x47af9b=0x0){return _0x4bebeb['pieces_']['slice'](_0x4bebeb['pieceNum_']+_0x47af9b);}function To(_0x411d40){if(_0x411d40['pieceNum_']>=_0x411d40['pieces_']['length'])return null;const _0x54968f=[];for(let _0x559716=_0x411d40['pieceNum_'];_0x559716<_0x411d40['pieces_']['length']-0x1;_0x559716++)_0x54968f['push'](_0x411d40['pieces_'][_0x559716]);return new C(_0x54968f,0x0);}function A(_0x2d474c,_0xbe3fc3){const _0x7a2c11=[];for(let _0x20c5b6=_0x2d474c['pieceNum_'];_0x20c5b6<_0x2d474c['pieces_']['length'];_0x20c5b6++)_0x7a2c11['push'](_0x2d474c['pieces_'][_0x20c5b6]);if(_0xbe3fc3 instanceof C){for(let _0x3ba504=_0xbe3fc3['pieceNum_'];_0x3ba504<_0xbe3fc3['pieces_']['length'];_0x3ba504++)_0x7a2c11['push'](_0xbe3fc3['pieces_'][_0x3ba504]);}else{const _0x52ebed=_0xbe3fc3['split']('/');for(let _0x107e70=0x0;_0x107e70<_0x52ebed['length'];_0x107e70++)_0x52ebed[_0x107e70]['length']>0x0&&_0x7a2c11['push'](_0x52ebed[_0x107e70]);}return new C(_0x7a2c11,0x0);}function v(_0x27ad32){return _0x27ad32['pieceNum_']>=_0x27ad32['pieces_']['length'];}function F(_0x58322d,_0x486865){const _0x40ce75=y(_0x58322d),_0x58f244=y(_0x486865);if(_0x40ce75===null)return _0x486865;if(_0x40ce75===_0x58f244)return F(b(_0x58322d),b(_0x486865));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x486865+')\x20is\x20not\x20within\x20outerPath\x20('+_0x58322d+')');}function Th(_0x2dce8d,_0x176809){const _0x4c86b1=kt(_0x2dce8d,0x0),_0x20c3bb=kt(_0x176809,0x0);for(let _0x159e93=0x0;_0x159e93<_0x4c86b1['length']&&_0x159e93<_0x20c3bb['length'];_0x159e93++){const _0x25cc12=He(_0x4c86b1[_0x159e93],_0x20c3bb[_0x159e93]);if(_0x25cc12!==0x0)return _0x25cc12;}return _0x4c86b1['length']===_0x20c3bb['length']?0x0:_0x4c86b1['length']<_0x20c3bb['length']?-0x1:0x1;}function qi(_0x3c9fc2,_0x5d0002){if(we(_0x3c9fc2)!==we(_0x5d0002))return!0x1;for(let _0x43d5ed=_0x3c9fc2['pieceNum_'],_0x5ce609=_0x5d0002['pieceNum_'];_0x43d5ed<=_0x3c9fc2['pieces_']['length'];_0x43d5ed++,_0x5ce609++)if(_0x3c9fc2['pieces_'][_0x43d5ed]!==_0x5d0002['pieces_'][_0x5ce609])return!0x1;return!0x0;}function $(_0x3236ca,_0x199294){let _0x36576d=_0x3236ca['pieceNum_'],_0x4d01a0=_0x199294['pieceNum_'];if(we(_0x3236ca)>we(_0x199294))return!0x1;for(;_0x36576d<_0x3236ca['pieces_']['length'];){if(_0x3236ca['pieces_'][_0x36576d]!==_0x199294['pieces_'][_0x4d01a0])return!0x1;++_0x36576d,++_0x4d01a0;}return!0x0;}class Sh{constructor(_0x4ca098,_0x2d7416){this['errorPrefix_']=_0x2d7416,this['parts_']=kt(_0x4ca098,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x31d282=0x0;_0x31d282<this['parts_']['length'];_0x31d282++)this['byteLength_']+=Pn(this['parts_'][_0x31d282]);So(this);}}function bh(_0xba0b5c,_0x2f5574){_0xba0b5c['parts_']['length']>0x0&&(_0xba0b5c['byteLength_']+=0x1),_0xba0b5c['parts_']['push'](_0x2f5574),_0xba0b5c['byteLength_']+=Pn(_0x2f5574),So(_0xba0b5c);}function Rh(_0x222087){const _0x24091e=_0x222087['parts_']['pop']();_0x222087['byteLength_']-=Pn(_0x24091e),_0x222087['parts_']['length']>0x0&&(_0x222087['byteLength_']-=0x1);}function So(_0x2bd8b0){if(_0x2bd8b0['byteLength_']>Js)throw new Error(_0x2bd8b0['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x2bd8b0['byteLength_']+').');if(_0x2bd8b0['parts_']['length']>Qs)throw new Error(_0x2bd8b0['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x2bd8b0));}function Ne(_0x21f5ab){return _0x21f5ab['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x21f5ab['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x1701ee,_0x5b400c;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5b400c='visibilitychange',_0x1701ee='hidden'):typeof document['mozHidden']<'u'?(_0x5b400c='mozvisibilitychange',_0x1701ee='mozHidden'):typeof document['msHidden']<'u'?(_0x5b400c='msvisibilitychange',_0x1701ee='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5b400c='webkitvisibilitychange',_0x1701ee='webkitHidden')),this['visible_']=!0x0,_0x5b400c&&document['addEventListener'](_0x5b400c,()=>{const _0x5150e9=!document[_0x1701ee];_0x5150e9!==this['visible_']&&(this['visible_']=_0x5150e9,this['trigger']('visible',_0x5150e9));},!0x1);}['getInitialEvent'](_0x2dcff2){return f(_0x2dcff2==='visible','Unknown\x20event\x20type:\x20'+_0x2dcff2),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x443cfd,_0x7be513,_0x4d7582,_0x164024,_0x2d2cf9,_0x3d0de0,_0x1752b9,_0x4c277d){if(super(),this['repoInfo_']=_0x443cfd,this['applicationId_']=_0x7be513,this['onDataUpdate_']=_0x4d7582,this['onConnectStatus_']=_0x164024,this['onServerInfoUpdate_']=_0x2d2cf9,this['authTokenProvider_']=_0x3d0de0,this['appCheckTokenProvider_']=_0x1752b9,this['authOverride_']=_0x4c277d,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4c277d)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x443cfd['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x47007f,_0xb1628e,_0x2f36c2){const _0x5e0651=++this['requestNumber_'],_0x59478a={'r':_0x5e0651,'a':_0x47007f,'b':_0xb1628e};this['log_'](O(_0x59478a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x59478a),_0x2f36c2&&(this['requestCBHash_'][_0x5e0651]=_0x2f36c2);}['get'](_0xf5186e){this['initConnection_']();const _0x28f68c=new Ve(),_0x2fca05={'action':'g','request':{'p':_0xf5186e['_path']['toString'](),'q':_0xf5186e['_queryObject']},'onComplete':_0x2576cd=>{const _0x4af499=_0x2576cd['d'];_0x2576cd['s']==='ok'?_0x28f68c['resolve'](_0x4af499):_0x28f68c['reject'](_0x4af499);}};this['outstandingGets_']['push'](_0x2fca05),this['outstandingGetCount_']++;const _0x4e1745=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4e1745),_0x28f68c['promise'];}['listen'](_0x2e52de,_0x3cb053,_0x3273d1,_0x2eda17){this['initConnection_']();const _0x360629=_0x2e52de['_queryIdentifier'],_0x6f8d69=_0x2e52de['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x6f8d69+'\x20'+_0x360629),this['listens']['has'](_0x6f8d69)||this['listens']['set'](_0x6f8d69,new Map()),f(_0x2e52de['_queryParams']['isDefault']()||!_0x2e52de['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x6f8d69)['has'](_0x360629),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4bba22={'onComplete':_0x2eda17,'hashFn':_0x3cb053,'query':_0x2e52de,'tag':_0x3273d1};this['listens']['get'](_0x6f8d69)['set'](_0x360629,_0x4bba22),this['connected_']&&this['sendListen_'](_0x4bba22);}['sendGet_'](_0x1b1cf4){const _0x916251=this['outstandingGets_'][_0x1b1cf4];this['sendRequest']('g',_0x916251['request'],_0xfeeb03=>{delete this['outstandingGets_'][_0x1b1cf4],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x916251['onComplete']&&_0x916251['onComplete'](_0xfeeb03);});}['sendListen_'](_0x4f2658){const _0x41f28b=_0x4f2658['query'],_0x3f3f38=_0x41f28b['_path']['toString'](),_0xdf27fe=_0x41f28b['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x3f3f38+'\x20for\x20'+_0xdf27fe);const _0x4c83e9={'p':_0x3f3f38},_0x5c118c='q';_0x4f2658['tag']&&(_0x4c83e9['q']=_0x41f28b['_queryObject'],_0x4c83e9['t']=_0x4f2658['tag']),_0x4c83e9['h']=_0x4f2658['hashFn'](),this['sendRequest'](_0x5c118c,_0x4c83e9,_0x54b90c=>{const _0x12254c=_0x54b90c['d'],_0x3e9cfb=_0x54b90c['s'];ie['warnOnListenWarnings_'](_0x12254c,_0x41f28b),(this['listens']['get'](_0x3f3f38)&&this['listens']['get'](_0x3f3f38)['get'](_0xdf27fe))===_0x4f2658&&(this['log_']('listen\x20response',_0x54b90c),_0x3e9cfb!=='ok'&&this['removeListen_'](_0x3f3f38,_0xdf27fe),_0x4f2658['onComplete']&&_0x4f2658['onComplete'](_0x3e9cfb,_0x12254c));});}static['warnOnListenWarnings_'](_0x55f5d7,_0x574c96){if(_0x55f5d7&&typeof _0x55f5d7=='object'&&Y(_0x55f5d7,'w')){const _0x55befa=Oe(_0x55f5d7,'w');if(Array['isArray'](_0x55befa)&&~_0x55befa['indexOf']('no_index')){const _0x1a6dea='\x22.indexOn\x22:\x20\x22'+_0x574c96['_queryParams']['getIndex']()['toString']()+'\x22',_0x439e28=_0x574c96['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1a6dea+'\x20at\x20'+_0x439e28+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x276757){this['authToken_']=_0x276757,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x276757);}['reduceReconnectDelayIfAdminCredential_'](_0xfe2d5){(_0xfe2d5&&_0xfe2d5['length']===0x28||vc(_0xfe2d5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x14f342){this['appCheckToken_']=_0x14f342,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x57fd64=this['authToken_'],_0x438ea5=yc(_0x57fd64)?'auth':'gauth',_0x1d4ac0={'cred':_0x57fd64};this['authOverride_']===null?_0x1d4ac0['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1d4ac0['authvar']=this['authOverride_']),this['sendRequest'](_0x438ea5,_0x1d4ac0,_0x1da4cf=>{const _0x5b20a1=_0x1da4cf['s'],_0x52f71d=_0x1da4cf['d']||'error';this['authToken_']===_0x57fd64&&(_0x5b20a1==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5b20a1,_0x52f71d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x757122=>{const _0x588de0=_0x757122['s'],_0xb04331=_0x757122['d']||'error';_0x588de0==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x588de0,_0xb04331);});}['unlisten'](_0x1f8c50,_0x212743){const _0x3202f5=_0x1f8c50['_path']['toString'](),_0x2e1f08=_0x1f8c50['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3202f5+'\x20'+_0x2e1f08),f(_0x1f8c50['_queryParams']['isDefault']()||!_0x1f8c50['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3202f5,_0x2e1f08)&&this['connected_']&&this['sendUnlisten_'](_0x3202f5,_0x2e1f08,_0x1f8c50['_queryObject'],_0x212743);}['sendUnlisten_'](_0x2a608f,_0x68139d,_0x4cbbed,_0x417faa){this['log_']('Unlisten\x20on\x20'+_0x2a608f+'\x20for\x20'+_0x68139d);const _0x7f12ee={'p':_0x2a608f},_0x3ef388='n';_0x417faa&&(_0x7f12ee['q']=_0x4cbbed,_0x7f12ee['t']=_0x417faa),this['sendRequest'](_0x3ef388,_0x7f12ee);}['onDisconnectPut'](_0x3f6555,_0x5cb1e7,_0x293a9b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3f6555,_0x5cb1e7,_0x293a9b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3f6555,'action':'o','data':_0x5cb1e7,'onComplete':_0x293a9b});}['onDisconnectMerge'](_0x5c5efd,_0x195f9a,_0x68241e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5c5efd,_0x195f9a,_0x68241e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5c5efd,'action':'om','data':_0x195f9a,'onComplete':_0x68241e});}['onDisconnectCancel'](_0x261300,_0x336d5e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x261300,null,_0x336d5e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x261300,'action':'oc','data':null,'onComplete':_0x336d5e});}['sendOnDisconnect_'](_0x448a9f,_0x44cb3e,_0x2cf7a0,_0x42592c){const _0x18e081={'p':_0x44cb3e,'d':_0x2cf7a0};this['log_']('onDisconnect\x20'+_0x448a9f,_0x18e081),this['sendRequest'](_0x448a9f,_0x18e081,_0x410d3=>{_0x42592c&&setTimeout(()=>{_0x42592c(_0x410d3['s'],_0x410d3['d']);},Math['floor'](0x0));});}['put'](_0x30c8db,_0x523db4,_0x2c5afb,_0x3510ee){this['putInternal']('p',_0x30c8db,_0x523db4,_0x2c5afb,_0x3510ee);}['merge'](_0x4fdb13,_0x5cfa70,_0x25a5c3,_0x214e75){this['putInternal']('m',_0x4fdb13,_0x5cfa70,_0x25a5c3,_0x214e75);}['putInternal'](_0x23f009,_0x370fb6,_0x243a6b,_0xbd511c,_0x29a333){this['initConnection_']();const _0x5218c9={'p':_0x370fb6,'d':_0x243a6b};_0x29a333!==void 0x0&&(_0x5218c9['h']=_0x29a333),this['outstandingPuts_']['push']({'action':_0x23f009,'request':_0x5218c9,'onComplete':_0xbd511c}),this['outstandingPutCount_']++;const _0x56add1=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x56add1):this['log_']('Buffering\x20put:\x20'+_0x370fb6);}['sendPut_'](_0x401760){const _0xde99af=this['outstandingPuts_'][_0x401760]['action'],_0x6ab773=this['outstandingPuts_'][_0x401760]['request'],_0x2f3b52=this['outstandingPuts_'][_0x401760]['onComplete'];this['outstandingPuts_'][_0x401760]['queued']=this['connected_'],this['sendRequest'](_0xde99af,_0x6ab773,_0x230092=>{this['log_'](_0xde99af+'\x20response',_0x230092),delete this['outstandingPuts_'][_0x401760],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2f3b52&&_0x2f3b52(_0x230092['s'],_0x230092['d']);});}['reportStats'](_0x147391){if(this['connected_']){const _0x518b1d={'c':_0x147391};this['log_']('reportStats',_0x518b1d),this['sendRequest']('s',_0x518b1d,_0x37edc8=>{if(_0x37edc8['s']!=='ok'){const _0x23db4c=_0x37edc8['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x23db4c);}});}}['onDataMessage_'](_0x34048e){if('r'in _0x34048e){this['log_']('from\x20server:\x20'+O(_0x34048e));const _0x2b6e7f=_0x34048e['r'],_0x2ba7da=this['requestCBHash_'][_0x2b6e7f];_0x2ba7da&&(delete this['requestCBHash_'][_0x2b6e7f],_0x2ba7da(_0x34048e['b']));}else{if('error'in _0x34048e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x34048e['error'];'a'in _0x34048e&&this['onDataPush_'](_0x34048e['a'],_0x34048e['b']);}}['onDataPush_'](_0x601963,_0x4f75df){this['log_']('handleServerMessage',_0x601963,_0x4f75df),_0x601963==='d'?this['onDataUpdate_'](_0x4f75df['p'],_0x4f75df['d'],!0x1,_0x4f75df['t']):_0x601963==='m'?this['onDataUpdate_'](_0x4f75df['p'],_0x4f75df['d'],!0x0,_0x4f75df['t']):_0x601963==='c'?this['onListenRevoked_'](_0x4f75df['p'],_0x4f75df['q']):_0x601963==='ac'?this['onAuthRevoked_'](_0x4f75df['s'],_0x4f75df['d']):_0x601963==='apc'?this['onAppCheckRevoked_'](_0x4f75df['s'],_0x4f75df['d']):_0x601963==='sd'?this['onSecurityDebugPacket_'](_0x4f75df):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x601963)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2a9697,_0x5d6c06){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2a9697),this['lastSessionId']=_0x5d6c06,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x7150cf){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x7150cf));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1b47ab){_0x1b47ab&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1b47ab;}['onOnline_'](_0x3c8d75){_0x3c8d75?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x609d7f=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4d94aa=Math['max'](0x0,this['reconnectDelay_']-_0x609d7f);_0x4d94aa=Math['random']()*_0x4d94aa,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4d94aa+'ms'),this['scheduleConnect_'](_0x4d94aa),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2d9d76=this['onDataMessage_']['bind'](this),_0x120406=this['onReady_']['bind'](this),_0x3bb943=this['onRealtimeDisconnect_']['bind'](this),_0x438852=this['id']+':'+ie['nextConnectionId_']++,_0x581ee4=this['lastSessionId'];let _0x2335c1=!0x1,_0x10b0a8=null;const _0x20ee97=function(){_0x10b0a8?_0x10b0a8['close']():(_0x2335c1=!0x0,_0x3bb943());},_0x5567e6=function(_0x242c15){f(_0x10b0a8,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x10b0a8['sendRequest'](_0x242c15);};this['realtime_']={'close':_0x20ee97,'sendRequest':_0x5567e6};const _0x26829f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2ef368,_0x1c5900]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x26829f),this['appCheckTokenProvider_']['getToken'](_0x26829f)]);_0x2335c1?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2ef368&&_0x2ef368['accessToken'],this['appCheckToken_']=_0x1c5900&&_0x1c5900['token'],_0x10b0a8=new wh(_0x438852,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2d9d76,_0x120406,_0x3bb943,_0x436e3b=>{U(_0x436e3b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x581ee4));}catch(_0x3297e6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3297e6),_0x2335c1||(this['repoInfo_']['nodeAdmin']&&U(_0x3297e6),_0x20ee97());}}}['interrupt'](_0x481914){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x481914),this['interruptReasons_'][_0x481914]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1f72d6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1f72d6),delete this['interruptReasons_'][_0x1f72d6],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x317b57){const _0x531361=_0x317b57-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x531361});}['cancelSentTransactions_'](){for(let _0x28ea60=0x0;_0x28ea60<this['outstandingPuts_']['length'];_0x28ea60++){const _0x5d99bf=this['outstandingPuts_'][_0x28ea60];_0x5d99bf&&'h'in _0x5d99bf['request']&&_0x5d99bf['queued']&&(_0x5d99bf['onComplete']&&_0x5d99bf['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x28ea60],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3a0ba6,_0x3c7ee7){let _0x2935ff;_0x3c7ee7?_0x2935ff=_0x3c7ee7['map'](_0x35e54f=>Bi(_0x35e54f))['join']('$'):_0x2935ff='default';const _0x57507c=this['removeListen_'](_0x3a0ba6,_0x2935ff);_0x57507c&&_0x57507c['onComplete']&&_0x57507c['onComplete']('permission_denied');}['removeListen_'](_0x19d618,_0x52c667){const _0x9a0ac3=new C(_0x19d618)['toString']();let _0x4fa5eb;if(this['listens']['has'](_0x9a0ac3)){const _0xca1da4=this['listens']['get'](_0x9a0ac3);_0x4fa5eb=_0xca1da4['get'](_0x52c667),_0xca1da4['delete'](_0x52c667),_0xca1da4['size']===0x0&&this['listens']['delete'](_0x9a0ac3);}else _0x4fa5eb=void 0x0;return _0x4fa5eb;}['onAuthRevoked_'](_0x428d64,_0x107421){L('Auth\x20token\x20revoked:\x20'+_0x428d64+'/'+_0x107421),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x428d64==='invalid_token'||_0x428d64==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4cd3b7,_0x4cbab1){L('App\x20check\x20token\x20revoked:\x20'+_0x4cd3b7+'/'+_0x4cbab1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4cd3b7==='invalid_token'||_0x4cd3b7==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x47f0e9){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x47f0e9):'msg'in _0x47f0e9&&console['log']('FIREBASE:\x20'+_0x47f0e9['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x323227 of this['listens']['values']())for(const _0x1f716f of _0x323227['values']())this['sendListen_'](_0x1f716f);for(let _0x1fae46=0x0;_0x1fae46<this['outstandingPuts_']['length'];_0x1fae46++)this['outstandingPuts_'][_0x1fae46]&&this['sendPut_'](_0x1fae46);for(;this['onDisconnectRequestQueue_']['length'];){const _0xc3dbff=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xc3dbff['action'],_0xc3dbff['pathString'],_0xc3dbff['data'],_0xc3dbff['onComplete']);}for(let _0x27748f=0x0;_0x27748f<this['outstandingGets_']['length'];_0x27748f++)this['outstandingGets_'][_0x27748f]&&this['sendGet_'](_0x27748f);}['sendConnectStats_'](){const _0x4891f3={};let _0x2bfe6e='js';_0x4891f3['sdk.'+_0x2bfe6e+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x4891f3['framework.cordova']=0x1:qr()&&(_0x4891f3['framework.reactnative']=0x1),this['reportStats'](_0x4891f3);}['shouldReconnect_'](){const _0x53aeb4=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x53aeb4;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2ed4c4,_0x5bcc09){this['name']=_0x2ed4c4,this['node']=_0x5bcc09;}static['Wrap'](_0x1c6556,_0x44a99f){return new E(_0x1c6556,_0x44a99f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3234e1,_0x262ea7){const _0x2b4584=new E(xe,_0x3234e1),_0x452047=new E(xe,_0x262ea7);return this['compare'](_0x2b4584,_0x452047)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x1a3b62){Xt=_0x1a3b62;}['compare'](_0x5f1125,_0x576c27){return He(_0x5f1125['name'],_0x576c27['name']);}['isDefinedOn'](_0x3890ec){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x382a7b,_0x525487){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x51ab55,_0x48c630){return f(typeof _0x51ab55=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x51ab55,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x39a500,_0x33bf2a,_0x15888a,_0x24ab98,_0x331dae=null){this['isReverse_']=_0x24ab98,this['resultGenerator_']=_0x331dae,this['nodeStack_']=[];let _0x1e7162=0x1;for(;!_0x39a500['isEmpty']();)if(_0x39a500=_0x39a500,_0x1e7162=_0x33bf2a?_0x15888a(_0x39a500['key'],_0x33bf2a):0x1,_0x24ab98&&(_0x1e7162*=-0x1),_0x1e7162<0x0)this['isReverse_']?_0x39a500=_0x39a500['left']:_0x39a500=_0x39a500['right'];else{if(_0x1e7162===0x0){this['nodeStack_']['push'](_0x39a500);break;}else this['nodeStack_']['push'](_0x39a500),this['isReverse_']?_0x39a500=_0x39a500['right']:_0x39a500=_0x39a500['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x57273a=this['nodeStack_']['pop'](),_0x2b50af;if(this['resultGenerator_']?_0x2b50af=this['resultGenerator_'](_0x57273a['key'],_0x57273a['value']):_0x2b50af={'key':_0x57273a['key'],'value':_0x57273a['value']},this['isReverse_']){for(_0x57273a=_0x57273a['left'];!_0x57273a['isEmpty']();)this['nodeStack_']['push'](_0x57273a),_0x57273a=_0x57273a['right'];}else{for(_0x57273a=_0x57273a['right'];!_0x57273a['isEmpty']();)this['nodeStack_']['push'](_0x57273a),_0x57273a=_0x57273a['left'];}return _0x2b50af;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x48c585=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x48c585['key'],_0x48c585['value']):{'key':_0x48c585['key'],'value':_0x48c585['value']};}}class M{constructor(_0x141471,_0x1cd050,_0x4ccfe9,_0x107e31,_0x2d298d){this['key']=_0x141471,this['value']=_0x1cd050,this['color']=_0x4ccfe9??M['RED'],this['left']=_0x107e31??B['EMPTY_NODE'],this['right']=_0x2d298d??B['EMPTY_NODE'];}['copy'](_0x3c6b62,_0x403ecb,_0x4f76f5,_0x11c9a8,_0x4e103a){return new M(_0x3c6b62??this['key'],_0x403ecb??this['value'],_0x4f76f5??this['color'],_0x11c9a8??this['left'],_0x4e103a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x338a64){return this['left']['inorderTraversal'](_0x338a64)||!!_0x338a64(this['key'],this['value'])||this['right']['inorderTraversal'](_0x338a64);}['reverseTraversal'](_0x555709){return this['right']['reverseTraversal'](_0x555709)||_0x555709(this['key'],this['value'])||this['left']['reverseTraversal'](_0x555709);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4fb9a6,_0x4b408a,_0x19f6a3){let _0x27f58d=this;const _0x742719=_0x19f6a3(_0x4fb9a6,_0x27f58d['key']);return _0x742719<0x0?_0x27f58d=_0x27f58d['copy'](null,null,null,_0x27f58d['left']['insert'](_0x4fb9a6,_0x4b408a,_0x19f6a3),null):_0x742719===0x0?_0x27f58d=_0x27f58d['copy'](null,_0x4b408a,null,null,null):_0x27f58d=_0x27f58d['copy'](null,null,null,null,_0x27f58d['right']['insert'](_0x4fb9a6,_0x4b408a,_0x19f6a3)),_0x27f58d['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x497711=this;return!_0x497711['left']['isRed_']()&&!_0x497711['left']['left']['isRed_']()&&(_0x497711=_0x497711['moveRedLeft_']()),_0x497711=_0x497711['copy'](null,null,null,_0x497711['left']['removeMin_'](),null),_0x497711['fixUp_']();}['remove'](_0x509d97,_0x4b25e9){let _0x365cbb,_0x1018aa;if(_0x365cbb=this,_0x4b25e9(_0x509d97,_0x365cbb['key'])<0x0)!_0x365cbb['left']['isEmpty']()&&!_0x365cbb['left']['isRed_']()&&!_0x365cbb['left']['left']['isRed_']()&&(_0x365cbb=_0x365cbb['moveRedLeft_']()),_0x365cbb=_0x365cbb['copy'](null,null,null,_0x365cbb['left']['remove'](_0x509d97,_0x4b25e9),null);else{if(_0x365cbb['left']['isRed_']()&&(_0x365cbb=_0x365cbb['rotateRight_']()),!_0x365cbb['right']['isEmpty']()&&!_0x365cbb['right']['isRed_']()&&!_0x365cbb['right']['left']['isRed_']()&&(_0x365cbb=_0x365cbb['moveRedRight_']()),_0x4b25e9(_0x509d97,_0x365cbb['key'])===0x0){if(_0x365cbb['right']['isEmpty']())return B['EMPTY_NODE'];_0x1018aa=_0x365cbb['right']['min_'](),_0x365cbb=_0x365cbb['copy'](_0x1018aa['key'],_0x1018aa['value'],null,null,_0x365cbb['right']['removeMin_']());}_0x365cbb=_0x365cbb['copy'](null,null,null,null,_0x365cbb['right']['remove'](_0x509d97,_0x4b25e9));}return _0x365cbb['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x203da8=this;return _0x203da8['right']['isRed_']()&&!_0x203da8['left']['isRed_']()&&(_0x203da8=_0x203da8['rotateLeft_']()),_0x203da8['left']['isRed_']()&&_0x203da8['left']['left']['isRed_']()&&(_0x203da8=_0x203da8['rotateRight_']()),_0x203da8['left']['isRed_']()&&_0x203da8['right']['isRed_']()&&(_0x203da8=_0x203da8['colorFlip_']()),_0x203da8;}['moveRedLeft_'](){let _0x4e27b8=this['colorFlip_']();return _0x4e27b8['right']['left']['isRed_']()&&(_0x4e27b8=_0x4e27b8['copy'](null,null,null,null,_0x4e27b8['right']['rotateRight_']()),_0x4e27b8=_0x4e27b8['rotateLeft_'](),_0x4e27b8=_0x4e27b8['colorFlip_']()),_0x4e27b8;}['moveRedRight_'](){let _0x14b155=this['colorFlip_']();return _0x14b155['left']['left']['isRed_']()&&(_0x14b155=_0x14b155['rotateRight_'](),_0x14b155=_0x14b155['colorFlip_']()),_0x14b155;}['rotateLeft_'](){const _0x466376=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x466376,null);}['rotateRight_'](){const _0x2d812a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2d812a);}['colorFlip_'](){const _0x54f83c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x16f133=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x54f83c,_0x16f133);}['checkMaxDepth_'](){const _0x30bb08=this['check_']();return Math['pow'](0x2,_0x30bb08)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x334f9b=this['left']['check_']();if(_0x334f9b!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x334f9b+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x2d7aca,_0x29f667,_0x445bd9,_0x4a4f5c,_0x2ccc37){return this;}['insert'](_0x4fba8f,_0x5e8e43,_0x1d85c8){return new M(_0x4fba8f,_0x5e8e43,null);}['remove'](_0x4b7ce9,_0x12c897){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x9f4c69){return!0x1;}['reverseTraversal'](_0xf5cb70){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2b27c4,_0x2ad823=B['EMPTY_NODE']){this['comparator_']=_0x2b27c4,this['root_']=_0x2ad823;}['insert'](_0x55cebf,_0x592acd){return new B(this['comparator_'],this['root_']['insert'](_0x55cebf,_0x592acd,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x443229){return new B(this['comparator_'],this['root_']['remove'](_0x443229,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x51d5d3){let _0x43db76,_0x15e890=this['root_'];for(;!_0x15e890['isEmpty']();){if(_0x43db76=this['comparator_'](_0x51d5d3,_0x15e890['key']),_0x43db76===0x0)return _0x15e890['value'];_0x43db76<0x0?_0x15e890=_0x15e890['left']:_0x43db76>0x0&&(_0x15e890=_0x15e890['right']);}return null;}['getPredecessorKey'](_0x50840d){let _0x342a37,_0x19f5e4=this['root_'],_0x3e2e3c=null;for(;!_0x19f5e4['isEmpty']();)if(_0x342a37=this['comparator_'](_0x50840d,_0x19f5e4['key']),_0x342a37===0x0){if(_0x19f5e4['left']['isEmpty']())return _0x3e2e3c?_0x3e2e3c['key']:null;for(_0x19f5e4=_0x19f5e4['left'];!_0x19f5e4['right']['isEmpty']();)_0x19f5e4=_0x19f5e4['right'];return _0x19f5e4['key'];}else _0x342a37<0x0?_0x19f5e4=_0x19f5e4['left']:_0x342a37>0x0&&(_0x3e2e3c=_0x19f5e4,_0x19f5e4=_0x19f5e4['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2f524b){return this['root_']['inorderTraversal'](_0x2f524b);}['reverseTraversal'](_0x147c40){return this['root_']['reverseTraversal'](_0x147c40);}['getIterator'](_0xc04d0c){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0xc04d0c);}['getIteratorFrom'](_0xfa133b,_0x1e6758){return new Zt(this['root_'],_0xfa133b,this['comparator_'],!0x1,_0x1e6758);}['getReverseIteratorFrom'](_0x2795b3,_0x28f30c){return new Zt(this['root_'],_0x2795b3,this['comparator_'],!0x0,_0x28f30c);}['getReverseIterator'](_0x50bbd2){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x50bbd2);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x46b15a,_0x52d1d3){return He(_0x46b15a['name'],_0x52d1d3['name']);}function ji(_0xa9c923,_0x2a89f2){return He(_0xa9c923,_0x2a89f2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x327600){vi=_0x327600;}const Ro=function(_0x49ee86){return typeof _0x49ee86=='number'?'number:'+so(_0x49ee86):'string:'+_0x49ee86;},Ao=function(_0x2f7df4){if(_0x2f7df4['isLeafNode']()){const _0x26aca9=_0x2f7df4['val']();f(typeof _0x26aca9=='string'||typeof _0x26aca9=='number'||typeof _0x26aca9=='object'&&Y(_0x26aca9,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2f7df4===vi||_0x2f7df4['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2f7df4===vi||_0x2f7df4['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x129542){er=_0x129542;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x5d1aca,_0xed6c64=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x5d1aca,this['priorityNode_']=_0xed6c64,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x34d946){return new D(this['value_'],_0x34d946);}['getImmediateChild'](_0x57abc9){return _0x57abc9==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1b8435){return v(_0x1b8435)?this:y(_0x1b8435)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1c2930,_0xc85c00){return null;}['updateImmediateChild'](_0x33ac9f,_0x24e4ad){return _0x33ac9f==='.priority'?this['updatePriority'](_0x24e4ad):_0x24e4ad['isEmpty']()&&_0x33ac9f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x33ac9f,_0x24e4ad)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x478d92,_0x23cb29){const _0x59dce7=y(_0x478d92);return _0x59dce7===null?_0x23cb29:_0x23cb29['isEmpty']()&&_0x59dce7!=='.priority'?this:(f(_0x59dce7!=='.priority'||we(_0x478d92)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x59dce7,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x478d92),_0x23cb29)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x42014c,_0x47b320){return!0x1;}['val'](_0x505bd5){return _0x505bd5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1fa7c3='';this['priorityNode_']['isEmpty']()||(_0x1fa7c3+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x2e0ddd=typeof this['value_'];_0x1fa7c3+=_0x2e0ddd+':',_0x2e0ddd==='number'?_0x1fa7c3+=so(this['value_']):_0x1fa7c3+=this['value_'],this['lazyHash_']=no(_0x1fa7c3);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x570cea){return _0x570cea===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x570cea instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x570cea['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x570cea));}['compareToLeafNode_'](_0x102925){const _0x5e913f=typeof _0x102925['value_'],_0x41fdfe=typeof this['value_'],_0x354b04=D['VALUE_TYPE_ORDER']['indexOf'](_0x5e913f),_0x449b0f=D['VALUE_TYPE_ORDER']['indexOf'](_0x41fdfe);return f(_0x354b04>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5e913f),f(_0x449b0f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x41fdfe),_0x354b04===_0x449b0f?_0x41fdfe==='object'?0x0:this['value_']<_0x102925['value_']?-0x1:this['value_']===_0x102925['value_']?0x0:0x1:_0x449b0f-_0x354b04;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x32f896){if(_0x32f896===this)return!0x0;if(_0x32f896['isLeafNode']()){const _0x42c714=_0x32f896;return this['value_']===_0x42c714['value_']&&this['priorityNode_']['equals'](_0x42c714['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1df4fe){ko=_0x1df4fe;}function xh(_0x218c20){No=_0x218c20;}class Fh extends On{['compare'](_0x339054,_0x850698){const _0x37478a=_0x339054['node']['getPriority'](),_0x22df0f=_0x850698['node']['getPriority'](),_0x3f3331=_0x37478a['compareTo'](_0x22df0f);return _0x3f3331===0x0?He(_0x339054['name'],_0x850698['name']):_0x3f3331;}['isDefinedOn'](_0x44a630){return!_0x44a630['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x384a20,_0x2b2622){return!_0x384a20['getPriority']()['equals'](_0x2b2622['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x208305,_0x1ebde2){const _0x2ef5d4=ko(_0x208305);return new E(_0x1ebde2,new D('[PRIORITY-POST]',_0x2ef5d4));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x2b360b){const _0x1a4ea9=_0x14a433=>parseInt(Math['log'](_0x14a433)/Uh,0xa),_0x29dcef=_0x308a6c=>parseInt(Array(_0x308a6c+0x1)['join']('1'),0x2);this['count']=_0x1a4ea9(_0x2b360b+0x1),this['current_']=this['count']-0x1;const _0x1c84b9=_0x29dcef(this['count']);this['bits_']=_0x2b360b+0x1&_0x1c84b9;}['nextBitIsOne'](){const _0x38e6a0=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x38e6a0;}}const dn=function(_0x311124,_0x5cb7d9,_0x140c9a,_0x5f94d){_0x311124['sort'](_0x5cb7d9);const _0x54c07b=function(_0x1b05bd,_0x1ac399){const _0x211194=_0x1ac399-_0x1b05bd;let _0x4920ba,_0x221d32;if(_0x211194===0x0)return null;if(_0x211194===0x1)return _0x4920ba=_0x311124[_0x1b05bd],_0x221d32=_0x140c9a?_0x140c9a(_0x4920ba):_0x4920ba,new M(_0x221d32,_0x4920ba['node'],M['BLACK'],null,null);{const _0x4442ff=parseInt(_0x211194/0x2,0xa)+_0x1b05bd,_0x5b509e=_0x54c07b(_0x1b05bd,_0x4442ff),_0x130810=_0x54c07b(_0x4442ff+0x1,_0x1ac399);return _0x4920ba=_0x311124[_0x4442ff],_0x221d32=_0x140c9a?_0x140c9a(_0x4920ba):_0x4920ba,new M(_0x221d32,_0x4920ba['node'],M['BLACK'],_0x5b509e,_0x130810);}},_0x1bb7e8=function(_0x466633){let _0x256fbd=null,_0x4d9b58=null,_0x528956=_0x311124['length'];const _0x2f1075=function(_0x10568e,_0x3fbc3e){const _0x5c5962=_0x528956-_0x10568e,_0x538b17=_0x528956;_0x528956-=_0x10568e;const _0x1ad89e=_0x54c07b(_0x5c5962+0x1,_0x538b17),_0x228939=_0x311124[_0x5c5962],_0x586518=_0x140c9a?_0x140c9a(_0x228939):_0x228939;_0x7e5fee(new M(_0x586518,_0x228939['node'],_0x3fbc3e,null,_0x1ad89e));},_0x7e5fee=function(_0x7995b9){_0x256fbd?(_0x256fbd['left']=_0x7995b9,_0x256fbd=_0x7995b9):(_0x4d9b58=_0x7995b9,_0x256fbd=_0x7995b9);};for(let _0x1eda7f=0x0;_0x1eda7f<_0x466633['count'];++_0x1eda7f){const _0x261fa4=_0x466633['nextBitIsOne'](),_0x11ff09=Math['pow'](0x2,_0x466633['count']-(_0x1eda7f+0x1));_0x261fa4?_0x2f1075(_0x11ff09,M['BLACK']):(_0x2f1075(_0x11ff09,M['BLACK']),_0x2f1075(_0x11ff09,M['RED']));}return _0x4d9b58;},_0x2c2269=new Wh(_0x311124['length']),_0x1bbc4c=_0x1bb7e8(_0x2c2269);return new B(_0x5f94d||_0x5cb7d9,_0x1bbc4c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x573260,_0x4b2efe){this['indexes_']=_0x573260,this['indexSet_']=_0x4b2efe;}['get'](_0x440ceb){const _0xe57ba0=Oe(this['indexes_'],_0x440ceb);if(!_0xe57ba0)throw new Error('No\x20index\x20defined\x20for\x20'+_0x440ceb);return _0xe57ba0 instanceof B?_0xe57ba0:null;}['hasIndex'](_0x54fe3f){return Y(this['indexSet_'],_0x54fe3f['toString']());}['addIndex'](_0x450dd2,_0x376d84){f(_0x450dd2!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x198b79=[];let _0x970f3e=!0x1;const _0x490c82=_0x376d84['getIterator'](E['Wrap']);let _0x2532ac=_0x490c82['getNext']();for(;_0x2532ac;)_0x970f3e=_0x970f3e||_0x450dd2['isDefinedOn'](_0x2532ac['node']),_0x198b79['push'](_0x2532ac),_0x2532ac=_0x490c82['getNext']();let _0x40cc25;_0x970f3e?_0x40cc25=dn(_0x198b79,_0x450dd2['getCompare']()):_0x40cc25=je;const _0x40e138=_0x450dd2['toString'](),_0x50e0ab={...this['indexSet_']};_0x50e0ab[_0x40e138]=_0x450dd2;const _0x4260ea={...this['indexes_']};return _0x4260ea[_0x40e138]=_0x40cc25,new ee(_0x4260ea,_0x50e0ab);}['addToIndexes'](_0x20716b,_0x1aa240){const _0x15b0e8=ln(this['indexes_'],(_0x59503b,_0x4fb98c)=>{const _0x358574=Oe(this['indexSet_'],_0x4fb98c);if(f(_0x358574,'Missing\x20index\x20implementation\x20for\x20'+_0x4fb98c),_0x59503b===je){if(_0x358574['isDefinedOn'](_0x20716b['node'])){const _0x231afb=[],_0x1ffb50=_0x1aa240['getIterator'](E['Wrap']);let _0x4684fe=_0x1ffb50['getNext']();for(;_0x4684fe;)_0x4684fe['name']!==_0x20716b['name']&&_0x231afb['push'](_0x4684fe),_0x4684fe=_0x1ffb50['getNext']();return _0x231afb['push'](_0x20716b),dn(_0x231afb,_0x358574['getCompare']());}else return je;}else{const _0x5e4246=_0x1aa240['get'](_0x20716b['name']);let _0x3e518d=_0x59503b;return _0x5e4246&&(_0x3e518d=_0x3e518d['remove'](new E(_0x20716b['name'],_0x5e4246))),_0x3e518d['insert'](_0x20716b,_0x20716b['node']);}});return new ee(_0x15b0e8,this['indexSet_']);}['removeFromIndexes'](_0xc1a426,_0x3a6670){const _0xeffada=ln(this['indexes_'],_0x4c2d7a=>{if(_0x4c2d7a===je)return _0x4c2d7a;{const _0x36d6b4=_0x3a6670['get'](_0xc1a426['name']);return _0x36d6b4?_0x4c2d7a['remove'](new E(_0xc1a426['name'],_0x36d6b4)):_0x4c2d7a;}});return new ee(_0xeffada,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x53acbe,_0x5e9225,_0x11cb79){this['children_']=_0x53acbe,this['priorityNode_']=_0x5e9225,this['indexMap_']=_0x11cb79,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0xff6ffb){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xff6ffb,this['indexMap_']);}['getImmediateChild'](_0x45a301){if(_0x45a301==='.priority')return this['getPriority']();{const _0x5c9b4e=this['children_']['get'](_0x45a301);return _0x5c9b4e===null?gt:_0x5c9b4e;}}['getChild'](_0x2b650a){const _0x1cb9d2=y(_0x2b650a);return _0x1cb9d2===null?this:this['getImmediateChild'](_0x1cb9d2)['getChild'](b(_0x2b650a));}['hasChild'](_0xeee573){return this['children_']['get'](_0xeee573)!==null;}['updateImmediateChild'](_0x7477de,_0x2b8790){if(f(_0x2b8790,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x7477de==='.priority')return this['updatePriority'](_0x2b8790);{const _0x3860ef=new E(_0x7477de,_0x2b8790);let _0x3cdaef,_0x1ea797;_0x2b8790['isEmpty']()?(_0x3cdaef=this['children_']['remove'](_0x7477de),_0x1ea797=this['indexMap_']['removeFromIndexes'](_0x3860ef,this['children_'])):(_0x3cdaef=this['children_']['insert'](_0x7477de,_0x2b8790),_0x1ea797=this['indexMap_']['addToIndexes'](_0x3860ef,this['children_']));const _0x2fab86=_0x3cdaef['isEmpty']()?gt:this['priorityNode_'];return new g(_0x3cdaef,_0x2fab86,_0x1ea797);}}['updateChild'](_0x51d085,_0x5ebeb5){const _0x2d2883=y(_0x51d085);if(_0x2d2883===null)return _0x5ebeb5;{f(y(_0x51d085)!=='.priority'||we(_0x51d085)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x42f3b6=this['getImmediateChild'](_0x2d2883)['updateChild'](b(_0x51d085),_0x5ebeb5);return this['updateImmediateChild'](_0x2d2883,_0x42f3b6);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xf22bd9){if(this['isEmpty']())return null;const _0xea55ae={};let _0x467757=0x0,_0x46076e=0x0,_0x1936dc=!0x0;if(this['forEachChild'](R,(_0x2ed5fb,_0x26fd98)=>{_0xea55ae[_0x2ed5fb]=_0x26fd98['val'](_0xf22bd9),_0x467757++,_0x1936dc&&g['INTEGER_REGEXP_']['test'](_0x2ed5fb)?_0x46076e=Math['max'](_0x46076e,Number(_0x2ed5fb)):_0x1936dc=!0x1;}),!_0xf22bd9&&_0x1936dc&&_0x46076e<0x2*_0x467757){const _0x2b10e2=[];for(const _0x2d12d5 in _0xea55ae)_0x2b10e2[_0x2d12d5]=_0xea55ae[_0x2d12d5];return _0x2b10e2;}else return _0xf22bd9&&!this['getPriority']()['isEmpty']()&&(_0xea55ae['.priority']=this['getPriority']()['val']()),_0xea55ae;}['hash'](){if(this['lazyHash_']===null){let _0x21694f='';this['getPriority']()['isEmpty']()||(_0x21694f+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2fc9d9,_0x4d033e)=>{const _0x5081ea=_0x4d033e['hash']();_0x5081ea!==''&&(_0x21694f+=':'+_0x2fc9d9+':'+_0x5081ea);}),this['lazyHash_']=_0x21694f===''?'':no(_0x21694f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2a65df,_0x27c479,_0x277345){const _0x4090f6=this['resolveIndex_'](_0x277345);if(_0x4090f6){const _0x159b59=_0x4090f6['getPredecessorKey'](new E(_0x2a65df,_0x27c479));return _0x159b59?_0x159b59['name']:null;}else return this['children_']['getPredecessorKey'](_0x2a65df);}['getFirstChildName'](_0x45bbae){const _0x49622=this['resolveIndex_'](_0x45bbae);if(_0x49622){const _0x5da840=_0x49622['minKey']();return _0x5da840&&_0x5da840['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xf76aaa){const _0x4fd7b0=this['getFirstChildName'](_0xf76aaa);return _0x4fd7b0?new E(_0x4fd7b0,this['children_']['get'](_0x4fd7b0)):null;}['getLastChildName'](_0x2f7f6c){const _0x5b1f9e=this['resolveIndex_'](_0x2f7f6c);if(_0x5b1f9e){const _0xc94cf7=_0x5b1f9e['maxKey']();return _0xc94cf7&&_0xc94cf7['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3c7489){const _0x54bf7f=this['getLastChildName'](_0x3c7489);return _0x54bf7f?new E(_0x54bf7f,this['children_']['get'](_0x54bf7f)):null;}['forEachChild'](_0x2762b8,_0x3671bd){const _0x360e6d=this['resolveIndex_'](_0x2762b8);return _0x360e6d?_0x360e6d['inorderTraversal'](_0x56116a=>_0x3671bd(_0x56116a['name'],_0x56116a['node'])):this['children_']['inorderTraversal'](_0x3671bd);}['getIterator'](_0x568d5f){return this['getIteratorFrom'](_0x568d5f['minPost'](),_0x568d5f);}['getIteratorFrom'](_0x42a7b9,_0x486aad){const _0x3a2e84=this['resolveIndex_'](_0x486aad);if(_0x3a2e84)return _0x3a2e84['getIteratorFrom'](_0x42a7b9,_0x189362=>_0x189362);{const _0x6d366f=this['children_']['getIteratorFrom'](_0x42a7b9['name'],E['Wrap']);let _0x5ae393=_0x6d366f['peek']();for(;_0x5ae393!=null&&_0x486aad['compare'](_0x5ae393,_0x42a7b9)<0x0;)_0x6d366f['getNext'](),_0x5ae393=_0x6d366f['peek']();return _0x6d366f;}}['getReverseIterator'](_0x1ef3ea){return this['getReverseIteratorFrom'](_0x1ef3ea['maxPost'](),_0x1ef3ea);}['getReverseIteratorFrom'](_0x8dcd33,_0x20f624){const _0x411d45=this['resolveIndex_'](_0x20f624);if(_0x411d45)return _0x411d45['getReverseIteratorFrom'](_0x8dcd33,_0x29c344=>_0x29c344);{const _0x3865bf=this['children_']['getReverseIteratorFrom'](_0x8dcd33['name'],E['Wrap']);let _0x1b0bce=_0x3865bf['peek']();for(;_0x1b0bce!=null&&_0x20f624['compare'](_0x1b0bce,_0x8dcd33)>0x0;)_0x3865bf['getNext'](),_0x1b0bce=_0x3865bf['peek']();return _0x3865bf;}}['compareTo'](_0x19a7d3){return this['isEmpty']()?_0x19a7d3['isEmpty']()?0x0:-0x1:_0x19a7d3['isLeafNode']()||_0x19a7d3['isEmpty']()?0x1:_0x19a7d3===Ht?-0x1:0x0;}['withIndex'](_0x420ef8){if(_0x420ef8===ye||this['indexMap_']['hasIndex'](_0x420ef8))return this;{const _0x559ede=this['indexMap_']['addIndex'](_0x420ef8,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x559ede);}}['isIndexed'](_0x433c3b){return _0x433c3b===ye||this['indexMap_']['hasIndex'](_0x433c3b);}['equals'](_0x299c9a){if(_0x299c9a===this)return!0x0;if(_0x299c9a['isLeafNode']())return!0x1;{const _0x2f2a01=_0x299c9a;if(this['getPriority']()['equals'](_0x2f2a01['getPriority']())){if(this['children_']['count']()===_0x2f2a01['children_']['count']()){const _0x4a969f=this['getIterator'](R),_0xbbc0d8=_0x2f2a01['getIterator'](R);let _0x401236=_0x4a969f['getNext'](),_0x3b245b=_0xbbc0d8['getNext']();for(;_0x401236&&_0x3b245b;){if(_0x401236['name']!==_0x3b245b['name']||!_0x401236['node']['equals'](_0x3b245b['node']))return!0x1;_0x401236=_0x4a969f['getNext'](),_0x3b245b=_0xbbc0d8['getNext']();}return _0x401236===null&&_0x3b245b===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x447f27){return _0x447f27===ye?null:this['indexMap_']['get'](_0x447f27['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x5b480f){return _0x5b480f===this?0x0:0x1;}['equals'](_0x4b0338){return _0x4b0338===this;}['getPriority'](){return this;}['getImmediateChild'](_0x502189){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5d77ef,_0x1d3eda=null){if(_0x5d77ef===null)return g['EMPTY_NODE'];if(typeof _0x5d77ef=='object'&&'.priority'in _0x5d77ef&&(_0x1d3eda=_0x5d77ef['.priority']),f(_0x1d3eda===null||typeof _0x1d3eda=='string'||typeof _0x1d3eda=='number'||typeof _0x1d3eda=='object'&&'.sv'in _0x1d3eda,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1d3eda),typeof _0x5d77ef=='object'&&'.value'in _0x5d77ef&&_0x5d77ef['.value']!==null&&(_0x5d77ef=_0x5d77ef['.value']),typeof _0x5d77ef!='object'||'.sv'in _0x5d77ef){const _0x289c62=_0x5d77ef;return new D(_0x289c62,N(_0x1d3eda));}if(!(_0x5d77ef instanceof Array)&&Vh){const _0x5918eb=[];let _0x2ba768=!0x1;if(x(_0x5d77ef,(_0x5ba4d5,_0xc44cf2)=>{if(_0x5ba4d5['substring'](0x0,0x1)!=='.'){const _0x23f914=N(_0xc44cf2);_0x23f914['isEmpty']()||(_0x2ba768=_0x2ba768||!_0x23f914['getPriority']()['isEmpty'](),_0x5918eb['push'](new E(_0x5ba4d5,_0x23f914)));}}),_0x5918eb['length']===0x0)return g['EMPTY_NODE'];const _0x2f429a=dn(_0x5918eb,Dh,_0x16034f=>_0x16034f['name'],ji);if(_0x2ba768){const _0x40b1bf=dn(_0x5918eb,R['getCompare']());return new g(_0x2f429a,N(_0x1d3eda),new ee({'.priority':_0x40b1bf},{'.priority':R}));}else return new g(_0x2f429a,N(_0x1d3eda),ee['Default']);}else{let _0x4f289a=g['EMPTY_NODE'];return x(_0x5d77ef,(_0x15ea8e,_0x44d4b9)=>{if(Y(_0x5d77ef,_0x15ea8e)&&_0x15ea8e['substring'](0x0,0x1)!=='.'){const _0x33bb6f=N(_0x44d4b9);(_0x33bb6f['isLeafNode']()||!_0x33bb6f['isEmpty']())&&(_0x4f289a=_0x4f289a['updateImmediateChild'](_0x15ea8e,_0x33bb6f));}}),_0x4f289a['updatePriority'](N(_0x1d3eda));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x323845){super(),this['indexPath_']=_0x323845,f(!v(_0x323845)&&y(_0x323845)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4c2288){return _0x4c2288['getChild'](this['indexPath_']);}['isDefinedOn'](_0x48f195){return!_0x48f195['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2f721b,_0x49adb3){const _0x31d47d=this['extractChild'](_0x2f721b['node']),_0x142275=this['extractChild'](_0x49adb3['node']),_0x49ce7a=_0x31d47d['compareTo'](_0x142275);return _0x49ce7a===0x0?He(_0x2f721b['name'],_0x49adb3['name']):_0x49ce7a;}['makePost'](_0x206235,_0x34f7c7){const _0x105111=N(_0x206235),_0x2f42aa=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x105111);return new E(_0x34f7c7,_0x2f42aa);}['maxPost'](){const _0xf25b65=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0xf25b65);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x118023,_0x2f9176){const _0x55713a=_0x118023['node']['compareTo'](_0x2f9176['node']);return _0x55713a===0x0?He(_0x118023['name'],_0x2f9176['name']):_0x55713a;}['isDefinedOn'](_0x25cd6c){return!0x0;}['indexedValueChanged'](_0x197b0e,_0x5c3cb3){return!_0x197b0e['equals'](_0x5c3cb3);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1d2107,_0x6a057a){const _0x2c9e95=N(_0x1d2107);return new E(_0x6a057a,_0x2c9e95);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5c1585){return{'type':'value','snapshotNode':_0x5c1585};}function tt(_0x4ea43f,_0x2bc4b6){return{'type':'child_added','snapshotNode':_0x2bc4b6,'childName':_0x4ea43f};}function Nt(_0x37c0d1,_0x563e12){return{'type':'child_removed','snapshotNode':_0x563e12,'childName':_0x37c0d1};}function Pt(_0x78f7d0,_0x5b23f3,_0xa7840c){return{'type':'child_changed','snapshotNode':_0x5b23f3,'childName':_0x78f7d0,'oldSnap':_0xa7840c};}function $h(_0x260fb3,_0x5a7b7c){return{'type':'child_moved','snapshotNode':_0x5a7b7c,'childName':_0x260fb3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x29a181){this['index_']=_0x29a181;}['updateChild'](_0x35ff1d,_0x2ab187,_0x37772e,_0x3a51e8,_0x308cda,_0x505f5c){f(_0x35ff1d['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x475134=_0x35ff1d['getImmediateChild'](_0x2ab187);return _0x475134['getChild'](_0x3a51e8)['equals'](_0x37772e['getChild'](_0x3a51e8))&&_0x475134['isEmpty']()===_0x37772e['isEmpty']()||(_0x505f5c!=null&&(_0x37772e['isEmpty']()?_0x35ff1d['hasChild'](_0x2ab187)?_0x505f5c['trackChildChange'](Nt(_0x2ab187,_0x475134)):f(_0x35ff1d['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x475134['isEmpty']()?_0x505f5c['trackChildChange'](tt(_0x2ab187,_0x37772e)):_0x505f5c['trackChildChange'](Pt(_0x2ab187,_0x37772e,_0x475134))),_0x35ff1d['isLeafNode']()&&_0x37772e['isEmpty']())?_0x35ff1d:_0x35ff1d['updateImmediateChild'](_0x2ab187,_0x37772e)['withIndex'](this['index_']);}['updateFullNode'](_0x529327,_0xe71a82,_0x2b7252){return _0x2b7252!=null&&(_0x529327['isLeafNode']()||_0x529327['forEachChild'](R,(_0x4b7045,_0x525625)=>{_0xe71a82['hasChild'](_0x4b7045)||_0x2b7252['trackChildChange'](Nt(_0x4b7045,_0x525625));}),_0xe71a82['isLeafNode']()||_0xe71a82['forEachChild'](R,(_0x3334de,_0x48ace0)=>{if(_0x529327['hasChild'](_0x3334de)){const _0x1ef6f7=_0x529327['getImmediateChild'](_0x3334de);_0x1ef6f7['equals'](_0x48ace0)||_0x2b7252['trackChildChange'](Pt(_0x3334de,_0x48ace0,_0x1ef6f7));}else _0x2b7252['trackChildChange'](tt(_0x3334de,_0x48ace0));})),_0xe71a82['withIndex'](this['index_']);}['updatePriority'](_0x1b8a54,_0x1d5697){return _0x1b8a54['isEmpty']()?g['EMPTY_NODE']:_0x1b8a54['updatePriority'](_0x1d5697);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x30029d){this['indexedFilter_']=new Yi(_0x30029d['getIndex']()),this['index_']=_0x30029d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x30029d),this['endPost_']=Ot['getEndPost_'](_0x30029d),this['startIsInclusive_']=!_0x30029d['startAfterSet_'],this['endIsInclusive_']=!_0x30029d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2a9936){const _0x427170=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2a9936)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2a9936)<0x0,_0x454401=this['endIsInclusive_']?this['index_']['compare'](_0x2a9936,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2a9936,this['getEndPost']())<0x0;return _0x427170&&_0x454401;}['updateChild'](_0x298fce,_0x16573a,_0x486138,_0x11d358,_0x34331b,_0x4314f1){return this['matches'](new E(_0x16573a,_0x486138))||(_0x486138=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x298fce,_0x16573a,_0x486138,_0x11d358,_0x34331b,_0x4314f1);}['updateFullNode'](_0x34ea8f,_0x1d4573,_0x4fb51e){_0x1d4573['isLeafNode']()&&(_0x1d4573=g['EMPTY_NODE']);let _0x1c150d=_0x1d4573['withIndex'](this['index_']);_0x1c150d=_0x1c150d['updatePriority'](g['EMPTY_NODE']);const _0x4d4dd3=this;return _0x1d4573['forEachChild'](R,(_0x1d83d9,_0x753b26)=>{_0x4d4dd3['matches'](new E(_0x1d83d9,_0x753b26))||(_0x1c150d=_0x1c150d['updateImmediateChild'](_0x1d83d9,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x34ea8f,_0x1c150d,_0x4fb51e);}['updatePriority'](_0x532e77,_0x337562){return _0x532e77;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x29b0b4){if(_0x29b0b4['hasStart']()){const _0x61c78=_0x29b0b4['getIndexStartName']();return _0x29b0b4['getIndex']()['makePost'](_0x29b0b4['getIndexStartValue'](),_0x61c78);}else return _0x29b0b4['getIndex']()['minPost']();}static['getEndPost_'](_0x3b6ea0){if(_0x3b6ea0['hasEnd']()){const _0x27c8b7=_0x3b6ea0['getIndexEndName']();return _0x3b6ea0['getIndex']()['makePost'](_0x3b6ea0['getIndexEndValue'](),_0x27c8b7);}else return _0x3b6ea0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0xfd2cd7){this['withinDirectionalStart']=_0x109282=>this['reverse_']?this['withinEndPost'](_0x109282):this['withinStartPost'](_0x109282),this['withinDirectionalEnd']=_0x3c2e4f=>this['reverse_']?this['withinStartPost'](_0x3c2e4f):this['withinEndPost'](_0x3c2e4f),this['withinStartPost']=_0x1bb313=>{const _0x32ca50=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1bb313);return this['startIsInclusive_']?_0x32ca50<=0x0:_0x32ca50<0x0;},this['withinEndPost']=_0x5a34f8=>{const _0x51b9cb=this['index_']['compare'](_0x5a34f8,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x51b9cb<=0x0:_0x51b9cb<0x0;},this['rangedFilter_']=new Ot(_0xfd2cd7),this['index_']=_0xfd2cd7['getIndex'](),this['limit_']=_0xfd2cd7['getLimit'](),this['reverse_']=!_0xfd2cd7['isViewFromLeft'](),this['startIsInclusive_']=!_0xfd2cd7['startAfterSet_'],this['endIsInclusive_']=!_0xfd2cd7['endBeforeSet_'];}['updateChild'](_0xc179e3,_0x58c263,_0xf946ff,_0x41d789,_0x3612cc,_0x4eec12){return this['rangedFilter_']['matches'](new E(_0x58c263,_0xf946ff))||(_0xf946ff=g['EMPTY_NODE']),_0xc179e3['getImmediateChild'](_0x58c263)['equals'](_0xf946ff)?_0xc179e3:_0xc179e3['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xc179e3,_0x58c263,_0xf946ff,_0x41d789,_0x3612cc,_0x4eec12):this['fullLimitUpdateChild_'](_0xc179e3,_0x58c263,_0xf946ff,_0x3612cc,_0x4eec12);}['updateFullNode'](_0x22258c,_0x41e347,_0x10f9d5){let _0xb57de;if(_0x41e347['isLeafNode']()||_0x41e347['isEmpty']())_0xb57de=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x41e347['numChildren']()&&_0x41e347['isIndexed'](this['index_'])){_0xb57de=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x22981e;this['reverse_']?_0x22981e=_0x41e347['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x22981e=_0x41e347['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x7aed14=0x0;for(;_0x22981e['hasNext']()&&_0x7aed14<this['limit_'];){const _0x452c1b=_0x22981e['getNext']();if(this['withinDirectionalStart'](_0x452c1b)){if(this['withinDirectionalEnd'](_0x452c1b))_0xb57de=_0xb57de['updateImmediateChild'](_0x452c1b['name'],_0x452c1b['node']),_0x7aed14++;else break;}else continue;}}else{_0xb57de=_0x41e347['withIndex'](this['index_']),_0xb57de=_0xb57de['updatePriority'](g['EMPTY_NODE']);let _0x1f4dc8;this['reverse_']?_0x1f4dc8=_0xb57de['getReverseIterator'](this['index_']):_0x1f4dc8=_0xb57de['getIterator'](this['index_']);let _0x5c4e2a=0x0;for(;_0x1f4dc8['hasNext']();){const _0x4bf70a=_0x1f4dc8['getNext']();_0x5c4e2a<this['limit_']&&this['withinDirectionalStart'](_0x4bf70a)&&this['withinDirectionalEnd'](_0x4bf70a)?_0x5c4e2a++:_0xb57de=_0xb57de['updateImmediateChild'](_0x4bf70a['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x22258c,_0xb57de,_0x10f9d5);}['updatePriority'](_0x1dccb0,_0x51f902){return _0x1dccb0;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3d643f,_0x5c8c19,_0xf74b47,_0x3492bb,_0x3c0ec7){let _0x109fcb;if(this['reverse_']){const _0x5a6c90=this['index_']['getCompare']();_0x109fcb=(_0x31ec00,_0x3369f7)=>_0x5a6c90(_0x3369f7,_0x31ec00);}else _0x109fcb=this['index_']['getCompare']();const _0x299d0b=_0x3d643f;f(_0x299d0b['numChildren']()===this['limit_'],'');const _0x77b7ab=new E(_0x5c8c19,_0xf74b47),_0x555b3d=this['reverse_']?_0x299d0b['getFirstChild'](this['index_']):_0x299d0b['getLastChild'](this['index_']),_0xdbbebb=this['rangedFilter_']['matches'](_0x77b7ab);if(_0x299d0b['hasChild'](_0x5c8c19)){const _0x316998=_0x299d0b['getImmediateChild'](_0x5c8c19);let _0x471d49=_0x3492bb['getChildAfterChild'](this['index_'],_0x555b3d,this['reverse_']);for(;_0x471d49!=null&&(_0x471d49['name']===_0x5c8c19||_0x299d0b['hasChild'](_0x471d49['name']));)_0x471d49=_0x3492bb['getChildAfterChild'](this['index_'],_0x471d49,this['reverse_']);const _0x13300d=_0x471d49==null?0x1:_0x109fcb(_0x471d49,_0x77b7ab);if(_0xdbbebb&&!_0xf74b47['isEmpty']()&&_0x13300d>=0x0)return _0x3c0ec7!=null&&_0x3c0ec7['trackChildChange'](Pt(_0x5c8c19,_0xf74b47,_0x316998)),_0x299d0b['updateImmediateChild'](_0x5c8c19,_0xf74b47);{_0x3c0ec7!=null&&_0x3c0ec7['trackChildChange'](Nt(_0x5c8c19,_0x316998));const _0x520d17=_0x299d0b['updateImmediateChild'](_0x5c8c19,g['EMPTY_NODE']);return _0x471d49!=null&&this['rangedFilter_']['matches'](_0x471d49)?(_0x3c0ec7!=null&&_0x3c0ec7['trackChildChange'](tt(_0x471d49['name'],_0x471d49['node'])),_0x520d17['updateImmediateChild'](_0x471d49['name'],_0x471d49['node'])):_0x520d17;}}else return _0xf74b47['isEmpty']()?_0x3d643f:_0xdbbebb&&_0x109fcb(_0x555b3d,_0x77b7ab)>=0x0?(_0x3c0ec7!=null&&(_0x3c0ec7['trackChildChange'](Nt(_0x555b3d['name'],_0x555b3d['node'])),_0x3c0ec7['trackChildChange'](tt(_0x5c8c19,_0xf74b47))),_0x299d0b['updateImmediateChild'](_0x5c8c19,_0xf74b47)['updateImmediateChild'](_0x555b3d['name'],g['EMPTY_NODE'])):_0x3d643f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x12e71c=new Qi();return _0x12e71c['limitSet_']=this['limitSet_'],_0x12e71c['limit_']=this['limit_'],_0x12e71c['startSet_']=this['startSet_'],_0x12e71c['startAfterSet_']=this['startAfterSet_'],_0x12e71c['indexStartValue_']=this['indexStartValue_'],_0x12e71c['startNameSet_']=this['startNameSet_'],_0x12e71c['indexStartName_']=this['indexStartName_'],_0x12e71c['endSet_']=this['endSet_'],_0x12e71c['endBeforeSet_']=this['endBeforeSet_'],_0x12e71c['indexEndValue_']=this['indexEndValue_'],_0x12e71c['endNameSet_']=this['endNameSet_'],_0x12e71c['indexEndName_']=this['indexEndName_'],_0x12e71c['index_']=this['index_'],_0x12e71c['viewFrom_']=this['viewFrom_'],_0x12e71c;}}function qh(_0x48ec22){return _0x48ec22['loadsAllData']()?new Yi(_0x48ec22['getIndex']()):_0x48ec22['hasLimit']()?new Gh(_0x48ec22):new Ot(_0x48ec22);}function zh(_0x12fc1d,_0x2ac762){const _0x31bfcd=_0x12fc1d['copy']();return _0x31bfcd['limitSet_']=!0x0,_0x31bfcd['limit_']=_0x2ac762,_0x31bfcd['viewFrom_']='l',_0x31bfcd;}function jh(_0x2b9c53,_0x45bb81,_0x5f5bc7){const _0x206380=_0x2b9c53['copy']();return _0x206380['startSet_']=!0x0,_0x45bb81===void 0x0&&(_0x45bb81=null),_0x206380['indexStartValue_']=_0x45bb81,_0x5f5bc7!=null?(_0x206380['startNameSet_']=!0x0,_0x206380['indexStartName_']=_0x5f5bc7):(_0x206380['startNameSet_']=!0x1,_0x206380['indexStartName_']=''),_0x206380;}function Kh(_0x4d4d77,_0x456b2e,_0x4a5bfb){const _0x1a7476=_0x4d4d77['copy']();return _0x1a7476['endSet_']=!0x0,_0x456b2e===void 0x0&&(_0x456b2e=null),_0x1a7476['indexEndValue_']=_0x456b2e,_0x4a5bfb!==void 0x0?(_0x1a7476['endNameSet_']=!0x0,_0x1a7476['indexEndName_']=_0x4a5bfb):(_0x1a7476['endNameSet_']=!0x1,_0x1a7476['indexEndName_']=''),_0x1a7476;}function Do(_0x1fc769,_0x141ab3){const _0x4bf12b=_0x1fc769['copy']();return _0x4bf12b['index_']=_0x141ab3,_0x4bf12b;}function tr(_0x401541){const _0x47eb6a={};if(_0x401541['isDefault']())return _0x47eb6a;let _0xd8d818;if(_0x401541['index_']===R?_0xd8d818='$priority':_0x401541['index_']===Po?_0xd8d818='$value':_0x401541['index_']===ye?_0xd8d818='$key':(f(_0x401541['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0xd8d818=_0x401541['index_']['toString']()),_0x47eb6a['orderBy']=O(_0xd8d818),_0x401541['startSet_']){const _0x2b9679=_0x401541['startAfterSet_']?'startAfter':'startAt';_0x47eb6a[_0x2b9679]=O(_0x401541['indexStartValue_']),_0x401541['startNameSet_']&&(_0x47eb6a[_0x2b9679]+=','+O(_0x401541['indexStartName_']));}if(_0x401541['endSet_']){const _0x4aa98b=_0x401541['endBeforeSet_']?'endBefore':'endAt';_0x47eb6a[_0x4aa98b]=O(_0x401541['indexEndValue_']),_0x401541['endNameSet_']&&(_0x47eb6a[_0x4aa98b]+=','+O(_0x401541['indexEndName_']));}return _0x401541['limitSet_']&&(_0x401541['isViewFromLeft']()?_0x47eb6a['limitToFirst']=_0x401541['limit_']:_0x47eb6a['limitToLast']=_0x401541['limit_']),_0x47eb6a;}function nr(_0x34b5ab){const _0x1358b3={};if(_0x34b5ab['startSet_']&&(_0x1358b3['sp']=_0x34b5ab['indexStartValue_'],_0x34b5ab['startNameSet_']&&(_0x1358b3['sn']=_0x34b5ab['indexStartName_']),_0x1358b3['sin']=!_0x34b5ab['startAfterSet_']),_0x34b5ab['endSet_']&&(_0x1358b3['ep']=_0x34b5ab['indexEndValue_'],_0x34b5ab['endNameSet_']&&(_0x1358b3['en']=_0x34b5ab['indexEndName_']),_0x1358b3['ein']=!_0x34b5ab['endBeforeSet_']),_0x34b5ab['limitSet_']){_0x1358b3['l']=_0x34b5ab['limit_'];let _0x1ad3b6=_0x34b5ab['viewFrom_'];_0x1ad3b6===''&&(_0x34b5ab['isViewFromLeft']()?_0x1ad3b6='l':_0x1ad3b6='r'),_0x1358b3['vf']=_0x1ad3b6;}return _0x34b5ab['index_']!==R&&(_0x1358b3['i']=_0x34b5ab['index_']['toString']()),_0x1358b3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x35a0d0){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2d44fb,_0x4d30d5){return _0x4d30d5!==void 0x0?'tag$'+_0x4d30d5:(f(_0x2d44fb['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2d44fb['_path']['toString']());}constructor(_0xfb640b,_0x4a2cb7,_0x3ad9c3,_0x40bf06){super(),this['repoInfo_']=_0xfb640b,this['onDataUpdate_']=_0x4a2cb7,this['authTokenProvider_']=_0x3ad9c3,this['appCheckTokenProvider_']=_0x40bf06,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x37bcef,_0x6adb19,_0x4c1339,_0x24ca11){const _0x4cc636=_0x37bcef['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4cc636+'\x20'+_0x37bcef['_queryIdentifier']);const _0x190b46=fn['getListenId_'](_0x37bcef,_0x4c1339),_0x1eff65={};this['listens_'][_0x190b46]=_0x1eff65;const _0x2d5a46=tr(_0x37bcef['_queryParams']);this['restRequest_'](_0x4cc636+'.json',_0x2d5a46,(_0x3f08ce,_0x95cc9e)=>{let _0x390650=_0x95cc9e;if(_0x3f08ce===0x194&&(_0x390650=null,_0x3f08ce=null),_0x3f08ce===null&&this['onDataUpdate_'](_0x4cc636,_0x390650,!0x1,_0x4c1339),Oe(this['listens_'],_0x190b46)===_0x1eff65){let _0x473bdd;_0x3f08ce?_0x3f08ce===0x191?_0x473bdd='permission_denied':_0x473bdd='rest_error:'+_0x3f08ce:_0x473bdd='ok',_0x24ca11(_0x473bdd,null);}});}['unlisten'](_0x2ba536,_0x248aa5){const _0x44644c=fn['getListenId_'](_0x2ba536,_0x248aa5);delete this['listens_'][_0x44644c];}['get'](_0x5a3610){const _0x30a872=tr(_0x5a3610['_queryParams']),_0x3d257b=_0x5a3610['_path']['toString'](),_0x2cda2a=new Ve();return this['restRequest_'](_0x3d257b+'.json',_0x30a872,(_0x48b814,_0x2573c6)=>{let _0x178568=_0x2573c6;_0x48b814===0x194&&(_0x178568=null,_0x48b814=null),_0x48b814===null?(this['onDataUpdate_'](_0x3d257b,_0x178568,!0x1,null),_0x2cda2a['resolve'](_0x178568)):_0x2cda2a['reject'](new Error(_0x178568));}),_0x2cda2a['promise'];}['refreshAuthToken'](_0x3410a0){}['restRequest_'](_0x662991,_0x4cd0c7={},_0x1a7fd7){return _0x4cd0c7['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x26b688,_0x53cd60])=>{_0x26b688&&_0x26b688['accessToken']&&(_0x4cd0c7['auth']=_0x26b688['accessToken']),_0x53cd60&&_0x53cd60['token']&&(_0x4cd0c7['ac']=_0x53cd60['token']);const _0x412bd1=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x662991+'?ns='+this['repoInfo_']['namespace']+at(_0x4cd0c7);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x412bd1);const _0x2d3f0a=new XMLHttpRequest();_0x2d3f0a['onreadystatechange']=()=>{if(_0x1a7fd7&&_0x2d3f0a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x412bd1+'\x20received.\x20status:',_0x2d3f0a['status'],'response:',_0x2d3f0a['responseText']);let _0x478123=null;if(_0x2d3f0a['status']>=0xc8&&_0x2d3f0a['status']<0x12c){try{_0x478123=bt(_0x2d3f0a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x412bd1+':\x20'+_0x2d3f0a['responseText']);}_0x1a7fd7(null,_0x478123);}else _0x2d3f0a['status']!==0x191&&_0x2d3f0a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x412bd1+'\x20Status:\x20'+_0x2d3f0a['status']),_0x1a7fd7(_0x2d3f0a['status']);_0x1a7fd7=null;}},_0x2d3f0a['open']('GET',_0x412bd1,!0x0),_0x2d3f0a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ab1e3){return this['rootNode_']['getChild'](_0x3ab1e3);}['updateSnapshot'](_0x1c94e3,_0x497a73){this['rootNode_']=this['rootNode_']['updateChild'](_0x1c94e3,_0x497a73);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x5b7ca7,_0xc26933,_0x2335bb){if(v(_0xc26933))_0x5b7ca7['value']=_0x2335bb,_0x5b7ca7['children']['clear']();else{if(_0x5b7ca7['value']!==null)_0x5b7ca7['value']=_0x5b7ca7['value']['updateChild'](_0xc26933,_0x2335bb);else{const _0x4adfde=y(_0xc26933);_0x5b7ca7['children']['has'](_0x4adfde)||_0x5b7ca7['children']['set'](_0x4adfde,pn());const _0x36bf69=_0x5b7ca7['children']['get'](_0x4adfde);_0xc26933=b(_0xc26933),Mo(_0x36bf69,_0xc26933,_0x2335bb);}}}function Ei(_0xb5ca42,_0x14849f,_0x3d79ea){_0xb5ca42['value']!==null?_0x3d79ea(_0x14849f,_0xb5ca42['value']):Qh(_0xb5ca42,(_0x1f809e,_0x86d5ce)=>{const _0x4b4fe1=new C(_0x14849f['toString']()+'/'+_0x1f809e);Ei(_0x86d5ce,_0x4b4fe1,_0x3d79ea);});}function Qh(_0x5c2797,_0x50c73f){_0x5c2797['children']['forEach']((_0x53c1b6,_0x1b8fc3)=>{_0x50c73f(_0x1b8fc3,_0x53c1b6);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x59151a){this['collection_']=_0x59151a,this['last_']=null;}['get'](){const _0x3c8216=this['collection_']['get'](),_0x3f4ed7={..._0x3c8216};return this['last_']&&x(this['last_'],(_0xa542ca,_0x1c0d4c)=>{_0x3f4ed7[_0xa542ca]=_0x3f4ed7[_0xa542ca]-_0x1c0d4c;}),this['last_']=_0x3c8216,_0x3f4ed7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x11e5cd,_0x5b9bdc){this['server_']=_0x5b9bdc,this['statsToReport_']={},this['statsListener_']=new Jh(_0x11e5cd);const _0x597cac=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x597cac));}['reportStats_'](){const _0x47551c=this['statsListener_']['get'](),_0x36759e={};let _0x5ca296=!0x1;x(_0x47551c,(_0x952d41,_0x686ef6)=>{_0x686ef6>0x0&&Y(this['statsToReport_'],_0x952d41)&&(_0x36759e[_0x952d41]=_0x686ef6,_0x5ca296=!0x0);}),_0x5ca296&&this['server_']['reportStats'](_0x36759e),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x951d8b){_0x951d8b[_0x951d8b['OVERWRITE']=0x0]='OVERWRITE',_0x951d8b[_0x951d8b['MERGE']=0x1]='MERGE',_0x951d8b[_0x951d8b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x951d8b[_0x951d8b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x430b93){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x430b93,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x354628,_0x4277cb,_0x2bdc95){this['path']=_0x354628,this['affectedTree']=_0x4277cb,this['revert']=_0x2bdc95,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x3f4ea4){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3e2b5b=this['affectedTree']['subtree'](new C(_0x3f4ea4));return new _n(w(),_0x3e2b5b,this['revert']);}}else return f(y(this['path'])===_0x3f4ea4,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x3fb83b,_0x1d40c9){this['source']=_0x3fb83b,this['path']=_0x1d40c9,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x3a7d8f){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x5505b3,_0x537b0f,_0x22eb88){this['source']=_0x5505b3,this['path']=_0x537b0f,this['snap']=_0x22eb88,this['type']=q['OVERWRITE'];}['operationForChild'](_0xc07c77){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0xc07c77)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x5f0a9a,_0x4d2996,_0x363cdc){this['source']=_0x5f0a9a,this['path']=_0x4d2996,this['children']=_0x363cdc,this['type']=q['MERGE'];}['operationForChild'](_0x5dbfa4){if(v(this['path'])){const _0x28e77d=this['children']['subtree'](new C(_0x5dbfa4));return _0x28e77d['isEmpty']()?null:_0x28e77d['value']?new Fe(this['source'],w(),_0x28e77d['value']):new nt(this['source'],w(),_0x28e77d);}else return f(y(this['path'])===_0x5dbfa4,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x41ea8a,_0xaa2edc,_0x24cba2){this['node_']=_0x41ea8a,this['fullyInitialized_']=_0xaa2edc,this['filtered_']=_0x24cba2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x43e728){if(v(_0x43e728))return this['isFullyInitialized']()&&!this['filtered_'];const _0x13a022=y(_0x43e728);return this['isCompleteForChild'](_0x13a022);}['isCompleteForChild'](_0x44effa){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x44effa);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x14bfd2){this['query_']=_0x14bfd2,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x212c1f,_0x47fb79,_0x43da70,_0x154978){const _0x545ed6=[],_0x33a291=[];return _0x47fb79['forEach'](_0x603bbe=>{_0x603bbe['type']==='child_changed'&&_0x212c1f['index_']['indexedValueChanged'](_0x603bbe['oldSnap'],_0x603bbe['snapshotNode'])&&_0x33a291['push']($h(_0x603bbe['childName'],_0x603bbe['snapshotNode']));}),mt(_0x212c1f,_0x545ed6,'child_removed',_0x47fb79,_0x154978,_0x43da70),mt(_0x212c1f,_0x545ed6,'child_added',_0x47fb79,_0x154978,_0x43da70),mt(_0x212c1f,_0x545ed6,'child_moved',_0x33a291,_0x154978,_0x43da70),mt(_0x212c1f,_0x545ed6,'child_changed',_0x47fb79,_0x154978,_0x43da70),mt(_0x212c1f,_0x545ed6,'value',_0x47fb79,_0x154978,_0x43da70),_0x545ed6;}function mt(_0xeb74b1,_0x52da76,_0x238c5a,_0xd818ab,_0x4796d8,_0x50ac46){const _0x54373a=_0xd818ab['filter'](_0x5ee236=>_0x5ee236['type']===_0x238c5a);_0x54373a['sort']((_0xd39483,_0x5695c9)=>su(_0xeb74b1,_0xd39483,_0x5695c9)),_0x54373a['forEach'](_0x24597f=>{const _0x3eaa42=iu(_0xeb74b1,_0x24597f,_0x50ac46);_0x4796d8['forEach'](_0x25a7d8=>{_0x25a7d8['respondsTo'](_0x24597f['type'])&&_0x52da76['push'](_0x25a7d8['createEvent'](_0x3eaa42,_0xeb74b1['query_']));});});}function iu(_0x4e4283,_0x156c13,_0x5ca474){return _0x156c13['type']==='value'||_0x156c13['type']==='child_removed'||(_0x156c13['prevName']=_0x5ca474['getPredecessorChildName'](_0x156c13['childName'],_0x156c13['snapshotNode'],_0x4e4283['index_'])),_0x156c13;}function su(_0x46712b,_0xcb8a0,_0x720f01){if(_0xcb8a0['childName']==null||_0x720f01['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x32e01e=new E(_0xcb8a0['childName'],_0xcb8a0['snapshotNode']),_0x37bd76=new E(_0x720f01['childName'],_0x720f01['snapshotNode']);return _0x46712b['index_']['compare'](_0x32e01e,_0x37bd76);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x5dcce3,_0x1aa396){return{'eventCache':_0x5dcce3,'serverCache':_0x1aa396};}function wt(_0x434044,_0x3c6d24,_0x5260da,_0x340f14){return Dn(new Ce(_0x3c6d24,_0x5260da,_0x340f14),_0x434044['serverCache']);}function Lo(_0x5b58e2,_0x36df76,_0x19b183,_0x1a13ce){return Dn(_0x5b58e2['eventCache'],new Ce(_0x36df76,_0x19b183,_0x1a13ce));}function gn(_0x4bef02){return _0x4bef02['eventCache']['isFullyInitialized']()?_0x4bef02['eventCache']['getNode']():null;}function Ue(_0x532395){return _0x532395['serverCache']['isFullyInitialized']()?_0x532395['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x403913){let _0x7d7aa7=new S(null);return x(_0x403913,(_0x420dcf,_0x4061fc)=>{_0x7d7aa7=_0x7d7aa7['set'](new C(_0x420dcf),_0x4061fc);}),_0x7d7aa7;}constructor(_0x4d39ae,_0x3ad9ed=ru()){this['value']=_0x4d39ae,this['children']=_0x3ad9ed;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3152a1,_0x5b551b){if(this['value']!=null&&_0x5b551b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3152a1))return null;{const _0x57ae29=y(_0x3152a1),_0x551d29=this['children']['get'](_0x57ae29);if(_0x551d29!==null){const _0x3091d1=_0x551d29['findRootMostMatchingPathAndValue'](b(_0x3152a1),_0x5b551b);return _0x3091d1!=null?{'path':A(new C(_0x57ae29),_0x3091d1['path']),'value':_0x3091d1['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x36ee30){return this['findRootMostMatchingPathAndValue'](_0x36ee30,()=>!0x0);}['subtree'](_0x504496){if(v(_0x504496))return this;{const _0x5535c7=y(_0x504496),_0x5404aa=this['children']['get'](_0x5535c7);return _0x5404aa!==null?_0x5404aa['subtree'](b(_0x504496)):new S(null);}}['set'](_0x5149f7,_0x186c22){if(v(_0x5149f7))return new S(_0x186c22,this['children']);{const _0x4033ca=y(_0x5149f7),_0x531de5=(this['children']['get'](_0x4033ca)||new S(null))['set'](b(_0x5149f7),_0x186c22),_0x17ed61=this['children']['insert'](_0x4033ca,_0x531de5);return new S(this['value'],_0x17ed61);}}['remove'](_0x25b8fe){if(v(_0x25b8fe))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x2f7263=y(_0x25b8fe),_0x28cab1=this['children']['get'](_0x2f7263);if(_0x28cab1){const _0x1bde05=_0x28cab1['remove'](b(_0x25b8fe));let _0x148304;return _0x1bde05['isEmpty']()?_0x148304=this['children']['remove'](_0x2f7263):_0x148304=this['children']['insert'](_0x2f7263,_0x1bde05),this['value']===null&&_0x148304['isEmpty']()?new S(null):new S(this['value'],_0x148304);}else return this;}}['get'](_0x3fc11f){if(v(_0x3fc11f))return this['value'];{const _0xfb7457=y(_0x3fc11f),_0x188d27=this['children']['get'](_0xfb7457);return _0x188d27?_0x188d27['get'](b(_0x3fc11f)):null;}}['setTree'](_0x3e34f6,_0x506b2b){if(v(_0x3e34f6))return _0x506b2b;{const _0x409a8f=y(_0x3e34f6),_0x2bda4d=(this['children']['get'](_0x409a8f)||new S(null))['setTree'](b(_0x3e34f6),_0x506b2b);let _0x15be86;return _0x2bda4d['isEmpty']()?_0x15be86=this['children']['remove'](_0x409a8f):_0x15be86=this['children']['insert'](_0x409a8f,_0x2bda4d),new S(this['value'],_0x15be86);}}['fold'](_0x2b3419){return this['fold_'](w(),_0x2b3419);}['fold_'](_0x509609,_0x1acba8){const _0x3345d4={};return this['children']['inorderTraversal']((_0x1c3891,_0x299c70)=>{_0x3345d4[_0x1c3891]=_0x299c70['fold_'](A(_0x509609,_0x1c3891),_0x1acba8);}),_0x1acba8(_0x509609,this['value'],_0x3345d4);}['findOnPath'](_0x2445f7,_0x562d3a){return this['findOnPath_'](_0x2445f7,w(),_0x562d3a);}['findOnPath_'](_0x8f39b6,_0x1c162d,_0x39bc30){const _0x5ac2e7=this['value']?_0x39bc30(_0x1c162d,this['value']):!0x1;if(_0x5ac2e7)return _0x5ac2e7;if(v(_0x8f39b6))return null;{const _0x1bf08b=y(_0x8f39b6),_0xeb9c51=this['children']['get'](_0x1bf08b);return _0xeb9c51?_0xeb9c51['findOnPath_'](b(_0x8f39b6),A(_0x1c162d,_0x1bf08b),_0x39bc30):null;}}['foreachOnPath'](_0x131b67,_0x5ac1a2){return this['foreachOnPath_'](_0x131b67,w(),_0x5ac1a2);}['foreachOnPath_'](_0x1e6cdb,_0x1a4e8c,_0xc218da){if(v(_0x1e6cdb))return this;{this['value']&&_0xc218da(_0x1a4e8c,this['value']);const _0xae437f=y(_0x1e6cdb),_0x23d2c3=this['children']['get'](_0xae437f);return _0x23d2c3?_0x23d2c3['foreachOnPath_'](b(_0x1e6cdb),A(_0x1a4e8c,_0xae437f),_0xc218da):new S(null);}}['foreach'](_0x2fbfc3){this['foreach_'](w(),_0x2fbfc3);}['foreach_'](_0xace705,_0x113d27){this['children']['inorderTraversal']((_0x50ecc9,_0xe083aa)=>{_0xe083aa['foreach_'](A(_0xace705,_0x50ecc9),_0x113d27);}),this['value']&&_0x113d27(_0xace705,this['value']);}['foreachChild'](_0x5ae61a){this['children']['inorderTraversal']((_0xad71f0,_0x26e230)=>{_0x26e230['value']&&_0x5ae61a(_0xad71f0,_0x26e230['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2cd403){this['writeTree_']=_0x2cd403;}static['empty'](){return new j(new S(null));}}function Ct(_0x25e9ae,_0x2e0dc0,_0x2fda2d){if(v(_0x2e0dc0))return new j(new S(_0x2fda2d));{const _0x39234a=_0x25e9ae['writeTree_']['findRootMostValueAndPath'](_0x2e0dc0);if(_0x39234a!=null){const _0x1975a1=_0x39234a['path'];let _0x52a785=_0x39234a['value'];const _0x21693c=F(_0x1975a1,_0x2e0dc0);return _0x52a785=_0x52a785['updateChild'](_0x21693c,_0x2fda2d),new j(_0x25e9ae['writeTree_']['set'](_0x1975a1,_0x52a785));}else{const _0x389301=new S(_0x2fda2d),_0x4faab4=_0x25e9ae['writeTree_']['setTree'](_0x2e0dc0,_0x389301);return new j(_0x4faab4);}}}function Ii(_0x488af9,_0x10ddf1,_0x4bc5b9){let _0x5def6b=_0x488af9;return x(_0x4bc5b9,(_0x43d7ff,_0xd7e7b)=>{_0x5def6b=Ct(_0x5def6b,A(_0x10ddf1,_0x43d7ff),_0xd7e7b);}),_0x5def6b;}function sr(_0xf44e7c,_0x35543b){if(v(_0x35543b))return j['empty']();{const _0x439cc2=_0xf44e7c['writeTree_']['setTree'](_0x35543b,new S(null));return new j(_0x439cc2);}}function wi(_0x465685,_0x142909){return $e(_0x465685,_0x142909)!=null;}function $e(_0x2ec852,_0x56d76f){const _0xe3d987=_0x2ec852['writeTree_']['findRootMostValueAndPath'](_0x56d76f);return _0xe3d987!=null?_0x2ec852['writeTree_']['get'](_0xe3d987['path'])['getChild'](F(_0xe3d987['path'],_0x56d76f)):null;}function rr(_0x5f1b26){const _0x4176cb=[],_0x1ab652=_0x5f1b26['writeTree_']['value'];return _0x1ab652!=null?_0x1ab652['isLeafNode']()||_0x1ab652['forEachChild'](R,(_0x1124cf,_0x4daa5a)=>{_0x4176cb['push'](new E(_0x1124cf,_0x4daa5a));}):_0x5f1b26['writeTree_']['children']['inorderTraversal']((_0x5c2650,_0x1133fc)=>{_0x1133fc['value']!=null&&_0x4176cb['push'](new E(_0x5c2650,_0x1133fc['value']));}),_0x4176cb;}function ve(_0xbfdc13,_0x152f7b){if(v(_0x152f7b))return _0xbfdc13;{const _0x1315fc=$e(_0xbfdc13,_0x152f7b);return _0x1315fc!=null?new j(new S(_0x1315fc)):new j(_0xbfdc13['writeTree_']['subtree'](_0x152f7b));}}function Ci(_0x68e53c){return _0x68e53c['writeTree_']['isEmpty']();}function it(_0x27fe6e,_0x5ad8dd){return xo(w(),_0x27fe6e['writeTree_'],_0x5ad8dd);}function xo(_0x45689f,_0x224976,_0x3ebd1f){if(_0x224976['value']!=null)return _0x3ebd1f['updateChild'](_0x45689f,_0x224976['value']);{let _0x4ba861=null;return _0x224976['children']['inorderTraversal']((_0x59f102,_0x425abd)=>{_0x59f102==='.priority'?(f(_0x425abd['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4ba861=_0x425abd['value']):_0x3ebd1f=xo(A(_0x45689f,_0x59f102),_0x425abd,_0x3ebd1f);}),!_0x3ebd1f['getChild'](_0x45689f)['isEmpty']()&&_0x4ba861!==null&&(_0x3ebd1f=_0x3ebd1f['updateChild'](A(_0x45689f,'.priority'),_0x4ba861)),_0x3ebd1f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x18ce00,_0x42768f){return Bo(_0x42768f,_0x18ce00);}function ou(_0x4e95c2,_0x5cfb28,_0x46c05d,_0x5060c0,_0x199ea5){f(_0x5060c0>_0x4e95c2['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x199ea5===void 0x0&&(_0x199ea5=!0x0),_0x4e95c2['allWrites']['push']({'path':_0x5cfb28,'snap':_0x46c05d,'writeId':_0x5060c0,'visible':_0x199ea5}),_0x199ea5&&(_0x4e95c2['visibleWrites']=Ct(_0x4e95c2['visibleWrites'],_0x5cfb28,_0x46c05d)),_0x4e95c2['lastWriteId']=_0x5060c0;}function au(_0x29a27a,_0x4ea145,_0x2caf82,_0x4f0eae){f(_0x4f0eae>_0x29a27a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x29a27a['allWrites']['push']({'path':_0x4ea145,'children':_0x2caf82,'writeId':_0x4f0eae,'visible':!0x0}),_0x29a27a['visibleWrites']=Ii(_0x29a27a['visibleWrites'],_0x4ea145,_0x2caf82),_0x29a27a['lastWriteId']=_0x4f0eae;}function cu(_0x5522c7,_0x19c8ec){for(let _0x3bca05=0x0;_0x3bca05<_0x5522c7['allWrites']['length'];_0x3bca05++){const _0x106adb=_0x5522c7['allWrites'][_0x3bca05];if(_0x106adb['writeId']===_0x19c8ec)return _0x106adb;}return null;}function lu(_0xc47525,_0x3ffd2b){const _0x567fe3=_0xc47525['allWrites']['findIndex'](_0x5e4ea8=>_0x5e4ea8['writeId']===_0x3ffd2b);f(_0x567fe3>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1c27e2=_0xc47525['allWrites'][_0x567fe3];_0xc47525['allWrites']['splice'](_0x567fe3,0x1);let _0x3be69e=_0x1c27e2['visible'],_0x335b06=!0x1,_0x202929=_0xc47525['allWrites']['length']-0x1;for(;_0x3be69e&&_0x202929>=0x0;){const _0xfcc7d5=_0xc47525['allWrites'][_0x202929];_0xfcc7d5['visible']&&(_0x202929>=_0x567fe3&&hu(_0xfcc7d5,_0x1c27e2['path'])?_0x3be69e=!0x1:$(_0x1c27e2['path'],_0xfcc7d5['path'])&&(_0x335b06=!0x0)),_0x202929--;}if(_0x3be69e){if(_0x335b06)return uu(_0xc47525),!0x0;if(_0x1c27e2['snap'])_0xc47525['visibleWrites']=sr(_0xc47525['visibleWrites'],_0x1c27e2['path']);else{const _0x405013=_0x1c27e2['children'];x(_0x405013,_0x49e6af=>{_0xc47525['visibleWrites']=sr(_0xc47525['visibleWrites'],A(_0x1c27e2['path'],_0x49e6af));});}return!0x0;}else return!0x1;}function hu(_0x1a9c9,_0x5d7273){if(_0x1a9c9['snap'])return $(_0x1a9c9['path'],_0x5d7273);for(const _0x2fc7da in _0x1a9c9['children'])if(_0x1a9c9['children']['hasOwnProperty'](_0x2fc7da)&&$(A(_0x1a9c9['path'],_0x2fc7da),_0x5d7273))return!0x0;return!0x1;}function uu(_0x4d3812){_0x4d3812['visibleWrites']=Fo(_0x4d3812['allWrites'],du,w()),_0x4d3812['allWrites']['length']>0x0?_0x4d3812['lastWriteId']=_0x4d3812['allWrites'][_0x4d3812['allWrites']['length']-0x1]['writeId']:_0x4d3812['lastWriteId']=-0x1;}function du(_0x486cb3){return _0x486cb3['visible'];}function Fo(_0x3d098f,_0x4cbb69,_0x266f4b){let _0x21c89d=j['empty']();for(let _0x455ce5=0x0;_0x455ce5<_0x3d098f['length'];++_0x455ce5){const _0xffbe8b=_0x3d098f[_0x455ce5];if(_0x4cbb69(_0xffbe8b)){const _0x1cecbe=_0xffbe8b['path'];let _0x61a255;if(_0xffbe8b['snap'])$(_0x266f4b,_0x1cecbe)?(_0x61a255=F(_0x266f4b,_0x1cecbe),_0x21c89d=Ct(_0x21c89d,_0x61a255,_0xffbe8b['snap'])):$(_0x1cecbe,_0x266f4b)&&(_0x61a255=F(_0x1cecbe,_0x266f4b),_0x21c89d=Ct(_0x21c89d,w(),_0xffbe8b['snap']['getChild'](_0x61a255)));else{if(_0xffbe8b['children']){if($(_0x266f4b,_0x1cecbe))_0x61a255=F(_0x266f4b,_0x1cecbe),_0x21c89d=Ii(_0x21c89d,_0x61a255,_0xffbe8b['children']);else{if($(_0x1cecbe,_0x266f4b)){if(_0x61a255=F(_0x1cecbe,_0x266f4b),v(_0x61a255))_0x21c89d=Ii(_0x21c89d,w(),_0xffbe8b['children']);else{const _0xfbebbc=Oe(_0xffbe8b['children'],y(_0x61a255));if(_0xfbebbc){const _0x12cabf=_0xfbebbc['getChild'](b(_0x61a255));_0x21c89d=Ct(_0x21c89d,w(),_0x12cabf);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x21c89d;}function Uo(_0x47b2cb,_0xb76e0d,_0x33e2d4,_0x142abe,_0x4d64ba){if(!_0x142abe&&!_0x4d64ba){const _0x18eed0=$e(_0x47b2cb['visibleWrites'],_0xb76e0d);if(_0x18eed0!=null)return _0x18eed0;{const _0x5d47f6=ve(_0x47b2cb['visibleWrites'],_0xb76e0d);if(Ci(_0x5d47f6))return _0x33e2d4;if(_0x33e2d4==null&&!wi(_0x5d47f6,w()))return null;{const _0x2c4bbe=_0x33e2d4||g['EMPTY_NODE'];return it(_0x5d47f6,_0x2c4bbe);}}}else{const _0x55bf78=ve(_0x47b2cb['visibleWrites'],_0xb76e0d);if(!_0x4d64ba&&Ci(_0x55bf78))return _0x33e2d4;if(!_0x4d64ba&&_0x33e2d4==null&&!wi(_0x55bf78,w()))return null;{const _0x2edfa1=function(_0x4d2644){return(_0x4d2644['visible']||_0x4d64ba)&&(!_0x142abe||!~_0x142abe['indexOf'](_0x4d2644['writeId']))&&($(_0x4d2644['path'],_0xb76e0d)||$(_0xb76e0d,_0x4d2644['path']));},_0x4ce2b7=Fo(_0x47b2cb['allWrites'],_0x2edfa1,_0xb76e0d),_0x533ec8=_0x33e2d4||g['EMPTY_NODE'];return it(_0x4ce2b7,_0x533ec8);}}}function fu(_0x3edb1d,_0x593215,_0x4ac668){let _0x13413c=g['EMPTY_NODE'];const _0x353b81=$e(_0x3edb1d['visibleWrites'],_0x593215);if(_0x353b81)return _0x353b81['isLeafNode']()||_0x353b81['forEachChild'](R,(_0x168cf4,_0x2b28ee)=>{_0x13413c=_0x13413c['updateImmediateChild'](_0x168cf4,_0x2b28ee);}),_0x13413c;if(_0x4ac668){const _0x3f195a=ve(_0x3edb1d['visibleWrites'],_0x593215);return _0x4ac668['forEachChild'](R,(_0x91bb9b,_0x333417)=>{const _0x2d7a92=it(ve(_0x3f195a,new C(_0x91bb9b)),_0x333417);_0x13413c=_0x13413c['updateImmediateChild'](_0x91bb9b,_0x2d7a92);}),rr(_0x3f195a)['forEach'](_0x32178b=>{_0x13413c=_0x13413c['updateImmediateChild'](_0x32178b['name'],_0x32178b['node']);}),_0x13413c;}else{const _0x135cf4=ve(_0x3edb1d['visibleWrites'],_0x593215);return rr(_0x135cf4)['forEach'](_0x292ec6=>{_0x13413c=_0x13413c['updateImmediateChild'](_0x292ec6['name'],_0x292ec6['node']);}),_0x13413c;}}function pu(_0x21a6db,_0x7b0a75,_0x49edce,_0x17a075,_0x855db3){f(_0x17a075||_0x855db3,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x46ca52=A(_0x7b0a75,_0x49edce);if(wi(_0x21a6db['visibleWrites'],_0x46ca52))return null;{const _0xaad129=ve(_0x21a6db['visibleWrites'],_0x46ca52);return Ci(_0xaad129)?_0x855db3['getChild'](_0x49edce):it(_0xaad129,_0x855db3['getChild'](_0x49edce));}}function _u(_0x4fb110,_0x2c7b85,_0x5aef69,_0x4c1dfc){const _0xa3d50a=A(_0x2c7b85,_0x5aef69),_0x1069b4=$e(_0x4fb110['visibleWrites'],_0xa3d50a);if(_0x1069b4!=null)return _0x1069b4;if(_0x4c1dfc['isCompleteForChild'](_0x5aef69)){const _0x2e319c=ve(_0x4fb110['visibleWrites'],_0xa3d50a);return it(_0x2e319c,_0x4c1dfc['getNode']()['getImmediateChild'](_0x5aef69));}else return null;}function gu(_0x26f009,_0x16db41){return $e(_0x26f009['visibleWrites'],_0x16db41);}function mu(_0x101e6e,_0x350f43,_0x56cbcc,_0x13efaa,_0x3f58ab,_0x2c1d3e,_0x48d6b9){let _0x5604c3;const _0x30a47d=ve(_0x101e6e['visibleWrites'],_0x350f43),_0x5f2512=$e(_0x30a47d,w());if(_0x5f2512!=null)_0x5604c3=_0x5f2512;else{if(_0x56cbcc!=null)_0x5604c3=it(_0x30a47d,_0x56cbcc);else return[];}if(_0x5604c3=_0x5604c3['withIndex'](_0x48d6b9),!_0x5604c3['isEmpty']()&&!_0x5604c3['isLeafNode']()){const _0x2e579c=[],_0x52cfec=_0x48d6b9['getCompare'](),_0x21b3e3=_0x2c1d3e?_0x5604c3['getReverseIteratorFrom'](_0x13efaa,_0x48d6b9):_0x5604c3['getIteratorFrom'](_0x13efaa,_0x48d6b9);let _0x4c7281=_0x21b3e3['getNext']();for(;_0x4c7281&&_0x2e579c['length']<_0x3f58ab;)_0x52cfec(_0x4c7281,_0x13efaa)!==0x0&&_0x2e579c['push'](_0x4c7281),_0x4c7281=_0x21b3e3['getNext']();return _0x2e579c;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x101625,_0x2897de,_0x146a6e,_0x2e27fe){return Uo(_0x101625['writeTree'],_0x101625['treePath'],_0x2897de,_0x146a6e,_0x2e27fe);}function es(_0x55da53,_0x1002d4){return fu(_0x55da53['writeTree'],_0x55da53['treePath'],_0x1002d4);}function or(_0x4f40a0,_0x1ddea5,_0x3cb6f3,_0x198e06){return pu(_0x4f40a0['writeTree'],_0x4f40a0['treePath'],_0x1ddea5,_0x3cb6f3,_0x198e06);}function yn(_0x328c51,_0x211dd6){return gu(_0x328c51['writeTree'],A(_0x328c51['treePath'],_0x211dd6));}function vu(_0x212514,_0xb0cb74,_0x48b79f,_0x51760a,_0x44bbcd,_0x465dd0){return mu(_0x212514['writeTree'],_0x212514['treePath'],_0xb0cb74,_0x48b79f,_0x51760a,_0x44bbcd,_0x465dd0);}function ts(_0x5aad6d,_0x3989c1,_0xeca495){return _u(_0x5aad6d['writeTree'],_0x5aad6d['treePath'],_0x3989c1,_0xeca495);}function Wo(_0xc9177a,_0x12fb89){return Bo(A(_0xc9177a['treePath'],_0x12fb89),_0xc9177a['writeTree']);}function Bo(_0x490b2b,_0x72d603){return{'treePath':_0x490b2b,'writeTree':_0x72d603};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xfd9f16){const _0x21ab7a=_0xfd9f16['type'],_0x3c9f3c=_0xfd9f16['childName'];f(_0x21ab7a==='child_added'||_0x21ab7a==='child_changed'||_0x21ab7a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3c9f3c!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2226e7=this['changeMap']['get'](_0x3c9f3c);if(_0x2226e7){const _0x26532b=_0x2226e7['type'];if(_0x21ab7a==='child_added'&&_0x26532b==='child_removed')this['changeMap']['set'](_0x3c9f3c,Pt(_0x3c9f3c,_0xfd9f16['snapshotNode'],_0x2226e7['snapshotNode']));else{if(_0x21ab7a==='child_removed'&&_0x26532b==='child_added')this['changeMap']['delete'](_0x3c9f3c);else{if(_0x21ab7a==='child_removed'&&_0x26532b==='child_changed')this['changeMap']['set'](_0x3c9f3c,Nt(_0x3c9f3c,_0x2226e7['oldSnap']));else{if(_0x21ab7a==='child_changed'&&_0x26532b==='child_added')this['changeMap']['set'](_0x3c9f3c,tt(_0x3c9f3c,_0xfd9f16['snapshotNode']));else{if(_0x21ab7a==='child_changed'&&_0x26532b==='child_changed')this['changeMap']['set'](_0x3c9f3c,Pt(_0x3c9f3c,_0xfd9f16['snapshotNode'],_0x2226e7['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0xfd9f16+'\x20occurred\x20after\x20'+_0x2226e7);}}}}}else this['changeMap']['set'](_0x3c9f3c,_0xfd9f16);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0xcb74d9){return null;}['getChildAfterChild'](_0x32fcd7,_0x189d80,_0xed2e94){return null;}}const Vo=new Iu();class ns{constructor(_0x3aeaf8,_0x1227eb,_0x5b41cf=null){this['writes_']=_0x3aeaf8,this['viewCache_']=_0x1227eb,this['optCompleteServerCache_']=_0x5b41cf;}['getCompleteChild'](_0x589641){const _0x5d6d52=this['viewCache_']['eventCache'];if(_0x5d6d52['isCompleteForChild'](_0x589641))return _0x5d6d52['getNode']()['getImmediateChild'](_0x589641);{const _0x40f4f0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x589641,_0x40f4f0);}}['getChildAfterChild'](_0x887e,_0x29d4bd,_0x59c1c4){const _0x5a90a2=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x58eb98=vu(this['writes_'],_0x5a90a2,_0x29d4bd,0x1,_0x59c1c4,_0x887e);return _0x58eb98['length']===0x0?null:_0x58eb98[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1899d7){return{'filter':_0x1899d7};}function Cu(_0x1ac34a,_0x53a41d){f(_0x53a41d['eventCache']['getNode']()['isIndexed'](_0x1ac34a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x53a41d['serverCache']['getNode']()['isIndexed'](_0x1ac34a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0xd05461,_0x44b89e,_0x96d419,_0x39ec0c,_0x1190ef){const _0x39222f=new Eu();let _0x11c763,_0x20ae08;if(_0x96d419['type']===q['OVERWRITE']){const _0x503fdc=_0x96d419;_0x503fdc['source']['fromUser']?_0x11c763=Ti(_0xd05461,_0x44b89e,_0x503fdc['path'],_0x503fdc['snap'],_0x39ec0c,_0x1190ef,_0x39222f):(f(_0x503fdc['source']['fromServer'],'Unknown\x20source.'),_0x20ae08=_0x503fdc['source']['tagged']||_0x44b89e['serverCache']['isFiltered']()&&!v(_0x503fdc['path']),_0x11c763=vn(_0xd05461,_0x44b89e,_0x503fdc['path'],_0x503fdc['snap'],_0x39ec0c,_0x1190ef,_0x20ae08,_0x39222f));}else{if(_0x96d419['type']===q['MERGE']){const _0x168651=_0x96d419;_0x168651['source']['fromUser']?_0x11c763=bu(_0xd05461,_0x44b89e,_0x168651['path'],_0x168651['children'],_0x39ec0c,_0x1190ef,_0x39222f):(f(_0x168651['source']['fromServer'],'Unknown\x20source.'),_0x20ae08=_0x168651['source']['tagged']||_0x44b89e['serverCache']['isFiltered'](),_0x11c763=Si(_0xd05461,_0x44b89e,_0x168651['path'],_0x168651['children'],_0x39ec0c,_0x1190ef,_0x20ae08,_0x39222f));}else{if(_0x96d419['type']===q['ACK_USER_WRITE']){const _0x209bda=_0x96d419;_0x209bda['revert']?_0x11c763=ku(_0xd05461,_0x44b89e,_0x209bda['path'],_0x39ec0c,_0x1190ef,_0x39222f):_0x11c763=Ru(_0xd05461,_0x44b89e,_0x209bda['path'],_0x209bda['affectedTree'],_0x39ec0c,_0x1190ef,_0x39222f);}else{if(_0x96d419['type']===q['LISTEN_COMPLETE'])_0x11c763=Au(_0xd05461,_0x44b89e,_0x96d419['path'],_0x39ec0c,_0x39222f);else throw ot('Unknown\x20operation\x20type:\x20'+_0x96d419['type']);}}}const _0x4ae888=_0x39222f['getChanges']();return Su(_0x44b89e,_0x11c763,_0x4ae888),{'viewCache':_0x11c763,'changes':_0x4ae888};}function Su(_0x1f4373,_0xf312b2,_0x4ba336){const _0x4f4b68=_0xf312b2['eventCache'];if(_0x4f4b68['isFullyInitialized']()){const _0x5b9479=_0x4f4b68['getNode']()['isLeafNode']()||_0x4f4b68['getNode']()['isEmpty'](),_0x46d70a=gn(_0x1f4373);(_0x4ba336['length']>0x0||!_0x1f4373['eventCache']['isFullyInitialized']()||_0x5b9479&&!_0x4f4b68['getNode']()['equals'](_0x46d70a)||!_0x4f4b68['getNode']()['getPriority']()['equals'](_0x46d70a['getPriority']()))&&_0x4ba336['push'](Oo(gn(_0xf312b2)));}}function Ho(_0x16f6ff,_0xa55ea0,_0x45ce58,_0x594627,_0x1f61a4,_0x1f949f){const _0x278f6d=_0xa55ea0['eventCache'];if(yn(_0x594627,_0x45ce58)!=null)return _0xa55ea0;{let _0x4bf011,_0x3ac130;if(v(_0x45ce58)){if(f(_0xa55ea0['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xa55ea0['serverCache']['isFiltered']()){const _0x4966f4=Ue(_0xa55ea0),_0x4d5514=_0x4966f4 instanceof g?_0x4966f4:g['EMPTY_NODE'],_0x1ea299=es(_0x594627,_0x4d5514);_0x4bf011=_0x16f6ff['filter']['updateFullNode'](_0xa55ea0['eventCache']['getNode'](),_0x1ea299,_0x1f949f);}else{const _0x13c380=mn(_0x594627,Ue(_0xa55ea0));_0x4bf011=_0x16f6ff['filter']['updateFullNode'](_0xa55ea0['eventCache']['getNode'](),_0x13c380,_0x1f949f);}}else{const _0x2690fd=y(_0x45ce58);if(_0x2690fd==='.priority'){f(we(_0x45ce58)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x6a6ee6=_0x278f6d['getNode']();_0x3ac130=_0xa55ea0['serverCache']['getNode']();const _0x52265e=or(_0x594627,_0x45ce58,_0x6a6ee6,_0x3ac130);_0x52265e!=null?_0x4bf011=_0x16f6ff['filter']['updatePriority'](_0x6a6ee6,_0x52265e):_0x4bf011=_0x278f6d['getNode']();}else{const _0x38a1f7=b(_0x45ce58);let _0x2a11b8;if(_0x278f6d['isCompleteForChild'](_0x2690fd)){_0x3ac130=_0xa55ea0['serverCache']['getNode']();const _0x326979=or(_0x594627,_0x45ce58,_0x278f6d['getNode'](),_0x3ac130);_0x326979!=null?_0x2a11b8=_0x278f6d['getNode']()['getImmediateChild'](_0x2690fd)['updateChild'](_0x38a1f7,_0x326979):_0x2a11b8=_0x278f6d['getNode']()['getImmediateChild'](_0x2690fd);}else _0x2a11b8=ts(_0x594627,_0x2690fd,_0xa55ea0['serverCache']);_0x2a11b8!=null?_0x4bf011=_0x16f6ff['filter']['updateChild'](_0x278f6d['getNode'](),_0x2690fd,_0x2a11b8,_0x38a1f7,_0x1f61a4,_0x1f949f):_0x4bf011=_0x278f6d['getNode']();}}return wt(_0xa55ea0,_0x4bf011,_0x278f6d['isFullyInitialized']()||v(_0x45ce58),_0x16f6ff['filter']['filtersNodes']());}}function vn(_0xe3c0d0,_0xf68a27,_0x5136c3,_0x192551,_0x339f79,_0x2ed441,_0x107643,_0x3f5597){const _0x365ffa=_0xf68a27['serverCache'];let _0x48bee2;const _0x38619e=_0x107643?_0xe3c0d0['filter']:_0xe3c0d0['filter']['getIndexedFilter']();if(v(_0x5136c3))_0x48bee2=_0x38619e['updateFullNode'](_0x365ffa['getNode'](),_0x192551,null);else{if(_0x38619e['filtersNodes']()&&!_0x365ffa['isFiltered']()){const _0x527d28=_0x365ffa['getNode']()['updateChild'](_0x5136c3,_0x192551);_0x48bee2=_0x38619e['updateFullNode'](_0x365ffa['getNode'](),_0x527d28,null);}else{const _0x9d8965=y(_0x5136c3);if(!_0x365ffa['isCompleteForPath'](_0x5136c3)&&we(_0x5136c3)>0x1)return _0xf68a27;const _0xc8a116=b(_0x5136c3),_0x50d6cc=_0x365ffa['getNode']()['getImmediateChild'](_0x9d8965)['updateChild'](_0xc8a116,_0x192551);_0x9d8965==='.priority'?_0x48bee2=_0x38619e['updatePriority'](_0x365ffa['getNode'](),_0x50d6cc):_0x48bee2=_0x38619e['updateChild'](_0x365ffa['getNode'](),_0x9d8965,_0x50d6cc,_0xc8a116,Vo,null);}}const _0x449a6a=Lo(_0xf68a27,_0x48bee2,_0x365ffa['isFullyInitialized']()||v(_0x5136c3),_0x38619e['filtersNodes']()),_0x1f6d30=new ns(_0x339f79,_0x449a6a,_0x2ed441);return Ho(_0xe3c0d0,_0x449a6a,_0x5136c3,_0x339f79,_0x1f6d30,_0x3f5597);}function Ti(_0x56c613,_0x331487,_0x3a925a,_0x1c9c12,_0x462b11,_0x1bc7c0,_0xc9eb2c){const _0xcc0ea=_0x331487['eventCache'];let _0x3a2525,_0xc879;const _0x313639=new ns(_0x462b11,_0x331487,_0x1bc7c0);if(v(_0x3a925a))_0xc879=_0x56c613['filter']['updateFullNode'](_0x331487['eventCache']['getNode'](),_0x1c9c12,_0xc9eb2c),_0x3a2525=wt(_0x331487,_0xc879,!0x0,_0x56c613['filter']['filtersNodes']());else{const _0x949079=y(_0x3a925a);if(_0x949079==='.priority')_0xc879=_0x56c613['filter']['updatePriority'](_0x331487['eventCache']['getNode'](),_0x1c9c12),_0x3a2525=wt(_0x331487,_0xc879,_0xcc0ea['isFullyInitialized'](),_0xcc0ea['isFiltered']());else{const _0x24cfb4=b(_0x3a925a),_0x18cef0=_0xcc0ea['getNode']()['getImmediateChild'](_0x949079);let _0x1cab32;if(v(_0x24cfb4))_0x1cab32=_0x1c9c12;else{const _0x11a634=_0x313639['getCompleteChild'](_0x949079);_0x11a634!=null?Gi(_0x24cfb4)==='.priority'&&_0x11a634['getChild'](To(_0x24cfb4))['isEmpty']()?_0x1cab32=_0x11a634:_0x1cab32=_0x11a634['updateChild'](_0x24cfb4,_0x1c9c12):_0x1cab32=g['EMPTY_NODE'];}if(_0x18cef0['equals'](_0x1cab32))_0x3a2525=_0x331487;else{const _0x5b6fdf=_0x56c613['filter']['updateChild'](_0xcc0ea['getNode'](),_0x949079,_0x1cab32,_0x24cfb4,_0x313639,_0xc9eb2c);_0x3a2525=wt(_0x331487,_0x5b6fdf,_0xcc0ea['isFullyInitialized'](),_0x56c613['filter']['filtersNodes']());}}}return _0x3a2525;}function ar(_0x2b41a7,_0xa1322d){return _0x2b41a7['eventCache']['isCompleteForChild'](_0xa1322d);}function bu(_0x4feb2a,_0x3e6ee1,_0x21922d,_0x34abe7,_0x58ef8a,_0x2a8d4f,_0x553dbf){let _0xcac020=_0x3e6ee1;return _0x34abe7['foreach']((_0x107220,_0x2d18b6)=>{const _0x563f43=A(_0x21922d,_0x107220);ar(_0x3e6ee1,y(_0x563f43))&&(_0xcac020=Ti(_0x4feb2a,_0xcac020,_0x563f43,_0x2d18b6,_0x58ef8a,_0x2a8d4f,_0x553dbf));}),_0x34abe7['foreach']((_0x341fd9,_0x5dbe7a)=>{const _0x15f2e4=A(_0x21922d,_0x341fd9);ar(_0x3e6ee1,y(_0x15f2e4))||(_0xcac020=Ti(_0x4feb2a,_0xcac020,_0x15f2e4,_0x5dbe7a,_0x58ef8a,_0x2a8d4f,_0x553dbf));}),_0xcac020;}function cr(_0x447739,_0x4b8280,_0x2cc89d){return _0x2cc89d['foreach']((_0x370b2c,_0x330ac1)=>{_0x4b8280=_0x4b8280['updateChild'](_0x370b2c,_0x330ac1);}),_0x4b8280;}function Si(_0x453cdc,_0x4123f4,_0x22d711,_0x2d5e2a,_0x4bc7ac,_0xa69399,_0x34fe1c,_0x4f0c08){if(_0x4123f4['serverCache']['getNode']()['isEmpty']()&&!_0x4123f4['serverCache']['isFullyInitialized']())return _0x4123f4;let _0xe0f1b7=_0x4123f4,_0x5c7fb8;v(_0x22d711)?_0x5c7fb8=_0x2d5e2a:_0x5c7fb8=new S(null)['setTree'](_0x22d711,_0x2d5e2a);const _0x5917ae=_0x4123f4['serverCache']['getNode']();return _0x5c7fb8['children']['inorderTraversal']((_0x4f203f,_0x5ebb12)=>{if(_0x5917ae['hasChild'](_0x4f203f)){const _0x15c63f=_0x4123f4['serverCache']['getNode']()['getImmediateChild'](_0x4f203f),_0x3ce626=cr(_0x453cdc,_0x15c63f,_0x5ebb12);_0xe0f1b7=vn(_0x453cdc,_0xe0f1b7,new C(_0x4f203f),_0x3ce626,_0x4bc7ac,_0xa69399,_0x34fe1c,_0x4f0c08);}}),_0x5c7fb8['children']['inorderTraversal']((_0x145ce8,_0x4a8819)=>{const _0x5009a7=!_0x4123f4['serverCache']['isCompleteForChild'](_0x145ce8)&&_0x4a8819['value']===null;if(!_0x5917ae['hasChild'](_0x145ce8)&&!_0x5009a7){const _0x26ccd9=_0x4123f4['serverCache']['getNode']()['getImmediateChild'](_0x145ce8),_0x34a81a=cr(_0x453cdc,_0x26ccd9,_0x4a8819);_0xe0f1b7=vn(_0x453cdc,_0xe0f1b7,new C(_0x145ce8),_0x34a81a,_0x4bc7ac,_0xa69399,_0x34fe1c,_0x4f0c08);}}),_0xe0f1b7;}function Ru(_0x56ef6b,_0x52b863,_0x13883a,_0x1567c0,_0xa2dc6a,_0x2f21ce,_0x13e147){if(yn(_0xa2dc6a,_0x13883a)!=null)return _0x52b863;const _0x238c2e=_0x52b863['serverCache']['isFiltered'](),_0x2cacd2=_0x52b863['serverCache'];if(_0x1567c0['value']!=null){if(v(_0x13883a)&&_0x2cacd2['isFullyInitialized']()||_0x2cacd2['isCompleteForPath'](_0x13883a))return vn(_0x56ef6b,_0x52b863,_0x13883a,_0x2cacd2['getNode']()['getChild'](_0x13883a),_0xa2dc6a,_0x2f21ce,_0x238c2e,_0x13e147);if(v(_0x13883a)){let _0xc1a2ee=new S(null);return _0x2cacd2['getNode']()['forEachChild'](ye,(_0x6d282d,_0x4b7c01)=>{_0xc1a2ee=_0xc1a2ee['set'](new C(_0x6d282d),_0x4b7c01);}),Si(_0x56ef6b,_0x52b863,_0x13883a,_0xc1a2ee,_0xa2dc6a,_0x2f21ce,_0x238c2e,_0x13e147);}else return _0x52b863;}else{let _0xd6e504=new S(null);return _0x1567c0['foreach']((_0x26a074,_0x4e2e11)=>{const _0x4c6418=A(_0x13883a,_0x26a074);_0x2cacd2['isCompleteForPath'](_0x4c6418)&&(_0xd6e504=_0xd6e504['set'](_0x26a074,_0x2cacd2['getNode']()['getChild'](_0x4c6418)));}),Si(_0x56ef6b,_0x52b863,_0x13883a,_0xd6e504,_0xa2dc6a,_0x2f21ce,_0x238c2e,_0x13e147);}}function Au(_0x119757,_0x4b2146,_0x2cfaa3,_0x21b089,_0x5d83f2){const _0x2b68e2=_0x4b2146['serverCache'],_0x3e33a0=Lo(_0x4b2146,_0x2b68e2['getNode'](),_0x2b68e2['isFullyInitialized']()||v(_0x2cfaa3),_0x2b68e2['isFiltered']());return Ho(_0x119757,_0x3e33a0,_0x2cfaa3,_0x21b089,Vo,_0x5d83f2);}function ku(_0x78945f,_0x48fd5c,_0x499e83,_0x3bb554,_0x490ee6,_0x44a015){let _0x5aaf65;if(yn(_0x3bb554,_0x499e83)!=null)return _0x48fd5c;{const _0x5e67cc=new ns(_0x3bb554,_0x48fd5c,_0x490ee6),_0x23f126=_0x48fd5c['eventCache']['getNode']();let _0x2bf795;if(v(_0x499e83)||y(_0x499e83)==='.priority'){let _0x429cec;if(_0x48fd5c['serverCache']['isFullyInitialized']())_0x429cec=mn(_0x3bb554,Ue(_0x48fd5c));else{const _0x36b286=_0x48fd5c['serverCache']['getNode']();f(_0x36b286 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x429cec=es(_0x3bb554,_0x36b286);}_0x429cec=_0x429cec,_0x2bf795=_0x78945f['filter']['updateFullNode'](_0x23f126,_0x429cec,_0x44a015);}else{const _0x55f4d4=y(_0x499e83);let _0x1a502b=ts(_0x3bb554,_0x55f4d4,_0x48fd5c['serverCache']);_0x1a502b==null&&_0x48fd5c['serverCache']['isCompleteForChild'](_0x55f4d4)&&(_0x1a502b=_0x23f126['getImmediateChild'](_0x55f4d4)),_0x1a502b!=null?_0x2bf795=_0x78945f['filter']['updateChild'](_0x23f126,_0x55f4d4,_0x1a502b,b(_0x499e83),_0x5e67cc,_0x44a015):_0x48fd5c['eventCache']['getNode']()['hasChild'](_0x55f4d4)?_0x2bf795=_0x78945f['filter']['updateChild'](_0x23f126,_0x55f4d4,g['EMPTY_NODE'],b(_0x499e83),_0x5e67cc,_0x44a015):_0x2bf795=_0x23f126,_0x2bf795['isEmpty']()&&_0x48fd5c['serverCache']['isFullyInitialized']()&&(_0x5aaf65=mn(_0x3bb554,Ue(_0x48fd5c)),_0x5aaf65['isLeafNode']()&&(_0x2bf795=_0x78945f['filter']['updateFullNode'](_0x2bf795,_0x5aaf65,_0x44a015)));}return _0x5aaf65=_0x48fd5c['serverCache']['isFullyInitialized']()||yn(_0x3bb554,w())!=null,wt(_0x48fd5c,_0x2bf795,_0x5aaf65,_0x78945f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3a2c45,_0x1ad6ac){this['query_']=_0x3a2c45,this['eventRegistrations_']=[];const _0x2a5693=this['query_']['_queryParams'],_0x11524c=new Yi(_0x2a5693['getIndex']()),_0x3e0b02=qh(_0x2a5693);this['processor_']=wu(_0x3e0b02);const _0x48c581=_0x1ad6ac['serverCache'],_0x4c9b95=_0x1ad6ac['eventCache'],_0x174ec2=_0x11524c['updateFullNode'](g['EMPTY_NODE'],_0x48c581['getNode'](),null),_0x52e3ba=_0x3e0b02['updateFullNode'](g['EMPTY_NODE'],_0x4c9b95['getNode'](),null),_0x408936=new Ce(_0x174ec2,_0x48c581['isFullyInitialized'](),_0x11524c['filtersNodes']()),_0x106bc8=new Ce(_0x52e3ba,_0x4c9b95['isFullyInitialized'](),_0x3e0b02['filtersNodes']());this['viewCache_']=Dn(_0x106bc8,_0x408936),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x55d093){return _0x55d093['viewCache_']['serverCache']['getNode']();}function Ou(_0x3fd398){return gn(_0x3fd398['viewCache_']);}function Du(_0x415713,_0x198882){const _0x4c0529=Ue(_0x415713['viewCache_']);return _0x4c0529&&(_0x415713['query']['_queryParams']['loadsAllData']()||!v(_0x198882)&&!_0x4c0529['getImmediateChild'](y(_0x198882))['isEmpty']())?_0x4c0529['getChild'](_0x198882):null;}function lr(_0x52a737){return _0x52a737['eventRegistrations_']['length']===0x0;}function Mu(_0xe7db5a,_0x5a1d5e){_0xe7db5a['eventRegistrations_']['push'](_0x5a1d5e);}function hr(_0x2b1732,_0x4bd070,_0xe15f67){const _0x3a76e8=[];if(_0xe15f67){f(_0x4bd070==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x971239=_0x2b1732['query']['_path'];_0x2b1732['eventRegistrations_']['forEach'](_0x326cac=>{const _0x566d43=_0x326cac['createCancelEvent'](_0xe15f67,_0x971239);_0x566d43&&_0x3a76e8['push'](_0x566d43);});}if(_0x4bd070){let _0x9a6b53=[];for(let _0x380ffe=0x0;_0x380ffe<_0x2b1732['eventRegistrations_']['length'];++_0x380ffe){const _0x10856d=_0x2b1732['eventRegistrations_'][_0x380ffe];if(!_0x10856d['matches'](_0x4bd070))_0x9a6b53['push'](_0x10856d);else{if(_0x4bd070['hasAnyCallback']()){_0x9a6b53=_0x9a6b53['concat'](_0x2b1732['eventRegistrations_']['slice'](_0x380ffe+0x1));break;}}}_0x2b1732['eventRegistrations_']=_0x9a6b53;}else _0x2b1732['eventRegistrations_']=[];return _0x3a76e8;}function ur(_0xc088c9,_0x422515,_0x4eacb6,_0x197e86){_0x422515['type']===q['MERGE']&&_0x422515['source']['queryId']!==null&&(f(Ue(_0xc088c9['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0xc088c9['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3498bd=_0xc088c9['viewCache_'],_0x2ab0d8=Tu(_0xc088c9['processor_'],_0x3498bd,_0x422515,_0x4eacb6,_0x197e86);return Cu(_0xc088c9['processor_'],_0x2ab0d8['viewCache']),f(_0x2ab0d8['viewCache']['serverCache']['isFullyInitialized']()||!_0x3498bd['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xc088c9['viewCache_']=_0x2ab0d8['viewCache'],$o(_0xc088c9,_0x2ab0d8['changes'],_0x2ab0d8['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x2ab4ec,_0x1082a1){const _0x175b46=_0x2ab4ec['viewCache_']['eventCache'],_0x3fba4d=[];return _0x175b46['getNode']()['isLeafNode']()||_0x175b46['getNode']()['forEachChild'](R,(_0x3c8dda,_0x40039b)=>{_0x3fba4d['push'](tt(_0x3c8dda,_0x40039b));}),_0x175b46['isFullyInitialized']()&&_0x3fba4d['push'](Oo(_0x175b46['getNode']())),$o(_0x2ab4ec,_0x3fba4d,_0x175b46['getNode'](),_0x1082a1);}function $o(_0x236c61,_0x47befd,_0x3af46c,_0x53c42f){const _0xc02e48=_0x53c42f?[_0x53c42f]:_0x236c61['eventRegistrations_'];return nu(_0x236c61['eventGenerator_'],_0x47befd,_0x3af46c,_0xc02e48);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x29f55b){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x29f55b;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x12452e){return _0x12452e['views']['size']===0x0;}function is(_0x2dbdc7,_0x1a1917,_0x2575a6,_0x4fcfd5){const _0x49934=_0x1a1917['source']['queryId'];if(_0x49934!==null){const _0xfc8de1=_0x2dbdc7['views']['get'](_0x49934);return f(_0xfc8de1!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0xfc8de1,_0x1a1917,_0x2575a6,_0x4fcfd5);}else{let _0x4bf024=[];for(const _0x4f1170 of _0x2dbdc7['views']['values']())_0x4bf024=_0x4bf024['concat'](ur(_0x4f1170,_0x1a1917,_0x2575a6,_0x4fcfd5));return _0x4bf024;}}function qo(_0x28afe5,_0x2c67a4,_0x3c213b,_0x27dd3e,_0x2a8d47){const _0xfcf43a=_0x2c67a4['_queryIdentifier'],_0x37126b=_0x28afe5['views']['get'](_0xfcf43a);if(!_0x37126b){let _0x48f334=mn(_0x3c213b,_0x2a8d47?_0x27dd3e:null),_0xe1fad0=!0x1;_0x48f334?_0xe1fad0=!0x0:_0x27dd3e instanceof g?(_0x48f334=es(_0x3c213b,_0x27dd3e),_0xe1fad0=!0x1):(_0x48f334=g['EMPTY_NODE'],_0xe1fad0=!0x1);const _0x187823=Dn(new Ce(_0x48f334,_0xe1fad0,!0x1),new Ce(_0x27dd3e,_0x2a8d47,!0x1));return new Nu(_0x2c67a4,_0x187823);}return _0x37126b;}function Wu(_0x31cd6a,_0x5af3f8,_0x8e2dd0,_0x4cad30,_0xbb0fb5,_0xaa0acf){const _0x25db9f=qo(_0x31cd6a,_0x5af3f8,_0x4cad30,_0xbb0fb5,_0xaa0acf);return _0x31cd6a['views']['has'](_0x5af3f8['_queryIdentifier'])||_0x31cd6a['views']['set'](_0x5af3f8['_queryIdentifier'],_0x25db9f),Mu(_0x25db9f,_0x8e2dd0),Lu(_0x25db9f,_0x8e2dd0);}function Bu(_0x4291ac,_0x521551,_0x3ad722,_0x1ac91f){const _0x346819=_0x521551['_queryIdentifier'],_0x2dbd33=[];let _0x3de235=[];const _0x564e1b=Te(_0x4291ac);if(_0x346819==='default'){for(const [_0x5e07a0,_0x5d8886]of _0x4291ac['views']['entries']())_0x3de235=_0x3de235['concat'](hr(_0x5d8886,_0x3ad722,_0x1ac91f)),lr(_0x5d8886)&&(_0x4291ac['views']['delete'](_0x5e07a0),_0x5d8886['query']['_queryParams']['loadsAllData']()||_0x2dbd33['push'](_0x5d8886['query']));}else{const _0x2db4b2=_0x4291ac['views']['get'](_0x346819);_0x2db4b2&&(_0x3de235=_0x3de235['concat'](hr(_0x2db4b2,_0x3ad722,_0x1ac91f)),lr(_0x2db4b2)&&(_0x4291ac['views']['delete'](_0x346819),_0x2db4b2['query']['_queryParams']['loadsAllData']()||_0x2dbd33['push'](_0x2db4b2['query'])));}return _0x564e1b&&!Te(_0x4291ac)&&_0x2dbd33['push'](new(Fu())(_0x521551['_repo'],_0x521551['_path'])),{'removed':_0x2dbd33,'events':_0x3de235};}function zo(_0x2c460a){const _0x1cdb00=[];for(const _0x593a65 of _0x2c460a['views']['values']())_0x593a65['query']['_queryParams']['loadsAllData']()||_0x1cdb00['push'](_0x593a65);return _0x1cdb00;}function Ee(_0x450cb4,_0x5d4dca){let _0x2438d5=null;for(const _0x1b1cdb of _0x450cb4['views']['values']())_0x2438d5=_0x2438d5||Du(_0x1b1cdb,_0x5d4dca);return _0x2438d5;}function jo(_0x367a3a,_0x247b37){if(_0x247b37['_queryParams']['loadsAllData']())return Ln(_0x367a3a);{const _0x418122=_0x247b37['_queryIdentifier'];return _0x367a3a['views']['get'](_0x418122);}}function Ko(_0x4ad090,_0x39c6b2){return jo(_0x4ad090,_0x39c6b2)!=null;}function Te(_0x2becc4){return Ln(_0x2becc4)!=null;}function Ln(_0x6b0b3b){for(const _0x407c6e of _0x6b0b3b['views']['values']())if(_0x407c6e['query']['_queryParams']['loadsAllData']())return _0x407c6e;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0xd33ecd){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xd33ecd;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x19ad60){this['listenProvider_']=_0x19ad60,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0xdbbf44,_0x137176,_0x9adfe9,_0x294c42,_0x61f1e1){return ou(_0xdbbf44['pendingWriteTree_'],_0x137176,_0x9adfe9,_0x294c42,_0x61f1e1),_0x61f1e1?ht(_0xdbbf44,new Fe(Ji(),_0x137176,_0x9adfe9)):[];}function Gu(_0x3e863f,_0x136ce8,_0x536450,_0x220e00){au(_0x3e863f['pendingWriteTree_'],_0x136ce8,_0x536450,_0x220e00);const _0x5a00bf=S['fromObject'](_0x536450);return ht(_0x3e863f,new nt(Ji(),_0x136ce8,_0x5a00bf));}function pe(_0x34ec80,_0x295ed8,_0x2da6ff=!0x1){const _0x37849b=cu(_0x34ec80['pendingWriteTree_'],_0x295ed8);if(lu(_0x34ec80['pendingWriteTree_'],_0x295ed8)){let _0x14306e=new S(null);return _0x37849b['snap']!=null?_0x14306e=_0x14306e['set'](w(),!0x0):x(_0x37849b['children'],_0x4ed323=>{_0x14306e=_0x14306e['set'](new C(_0x4ed323),!0x0);}),ht(_0x34ec80,new _n(_0x37849b['path'],_0x14306e,_0x2da6ff));}else return[];}function $t(_0x4eddde,_0x153458,_0x39a2d7){return ht(_0x4eddde,new Fe(Xi(),_0x153458,_0x39a2d7));}function qu(_0x2757bf,_0x5d10aa,_0x2b905d){const _0x3778df=S['fromObject'](_0x2b905d);return ht(_0x2757bf,new nt(Xi(),_0x5d10aa,_0x3778df));}function zu(_0x1035f2,_0x49a355){return ht(_0x1035f2,new Dt(Xi(),_0x49a355));}function ju(_0x79f024,_0x3973f0,_0x19f959){const _0x1ffa6e=rs(_0x79f024,_0x19f959);if(_0x1ffa6e){const _0x547cbe=os(_0x1ffa6e),_0x131925=_0x547cbe['path'],_0x30e21a=_0x547cbe['queryId'],_0x4c15f1=F(_0x131925,_0x3973f0),_0x56f171=new Dt(Zi(_0x30e21a),_0x4c15f1);return as(_0x79f024,_0x131925,_0x56f171);}else return[];}function wn(_0x62aa89,_0x624342,_0x3ab8d6,_0x4c38ef,_0x5d5ff3=!0x1){const _0x5594b0=_0x624342['_path'],_0x5cb9af=_0x62aa89['syncPointTree_']['get'](_0x5594b0);let _0x3a4a20=[];if(_0x5cb9af&&(_0x624342['_queryIdentifier']==='default'||Ko(_0x5cb9af,_0x624342))){const _0x1140b0=Bu(_0x5cb9af,_0x624342,_0x3ab8d6,_0x4c38ef);Uu(_0x5cb9af)&&(_0x62aa89['syncPointTree_']=_0x62aa89['syncPointTree_']['remove'](_0x5594b0));const _0x27fbc3=_0x1140b0['removed'];if(_0x3a4a20=_0x1140b0['events'],!_0x5d5ff3){const _0x2c7f68=_0x27fbc3['findIndex'](_0x83a9e1=>_0x83a9e1['_queryParams']['loadsAllData']())!==-0x1,_0x1b34e4=_0x62aa89['syncPointTree_']['findOnPath'](_0x5594b0,(_0x4d39e1,_0xe8b986)=>Te(_0xe8b986));if(_0x2c7f68&&!_0x1b34e4){const _0x34b78c=_0x62aa89['syncPointTree_']['subtree'](_0x5594b0);if(!_0x34b78c['isEmpty']()){const _0x1486f1=Qu(_0x34b78c);for(let _0x374b39=0x0;_0x374b39<_0x1486f1['length'];++_0x374b39){const _0x17f13a=_0x1486f1[_0x374b39],_0x1e9685=_0x17f13a['query'],_0x4e1dca=Xo(_0x62aa89,_0x17f13a);_0x62aa89['listenProvider_']['startListening'](Tt(_0x1e9685),Mt(_0x62aa89,_0x1e9685),_0x4e1dca['hashFn'],_0x4e1dca['onComplete']);}}}!_0x1b34e4&&_0x27fbc3['length']>0x0&&!_0x4c38ef&&(_0x2c7f68?_0x62aa89['listenProvider_']['stopListening'](Tt(_0x624342),null):_0x27fbc3['forEach'](_0xa2a53d=>{const _0x379fae=_0x62aa89['queryToTagMap']['get'](Fn(_0xa2a53d));_0x62aa89['listenProvider_']['stopListening'](Tt(_0xa2a53d),_0x379fae);}));}Ju(_0x62aa89,_0x27fbc3);}return _0x3a4a20;}function Yo(_0x5741ea,_0x4b49e3,_0x117e1c,_0x5561ca){const _0x5adae4=rs(_0x5741ea,_0x5561ca);if(_0x5adae4!=null){const _0x6c5aa9=os(_0x5adae4),_0x1d1870=_0x6c5aa9['path'],_0x59fc68=_0x6c5aa9['queryId'],_0x512e43=F(_0x1d1870,_0x4b49e3),_0x306c96=new Fe(Zi(_0x59fc68),_0x512e43,_0x117e1c);return as(_0x5741ea,_0x1d1870,_0x306c96);}else return[];}function Ku(_0x58aa90,_0x40d61a,_0x23b642,_0x52df44){const _0x2c2a32=rs(_0x58aa90,_0x52df44);if(_0x2c2a32){const _0xbda97e=os(_0x2c2a32),_0x417dcb=_0xbda97e['path'],_0x51d0a4=_0xbda97e['queryId'],_0xf76bf1=F(_0x417dcb,_0x40d61a),_0x23dd4e=S['fromObject'](_0x23b642),_0x3f59f3=new nt(Zi(_0x51d0a4),_0xf76bf1,_0x23dd4e);return as(_0x58aa90,_0x417dcb,_0x3f59f3);}else return[];}function bi(_0x474830,_0x1f2c21,_0x1913cc,_0x468ce8=!0x1){const _0x5694ed=_0x1f2c21['_path'];let _0x996938=null,_0x2057d1=!0x1;_0x474830['syncPointTree_']['foreachOnPath'](_0x5694ed,(_0x222b50,_0x235522)=>{const _0x5b4e68=F(_0x222b50,_0x5694ed);_0x996938=_0x996938||Ee(_0x235522,_0x5b4e68),_0x2057d1=_0x2057d1||Te(_0x235522);});let _0x37e97f=_0x474830['syncPointTree_']['get'](_0x5694ed);_0x37e97f?(_0x2057d1=_0x2057d1||Te(_0x37e97f),_0x996938=_0x996938||Ee(_0x37e97f,w())):(_0x37e97f=new Go(),_0x474830['syncPointTree_']=_0x474830['syncPointTree_']['set'](_0x5694ed,_0x37e97f));let _0x45fbf0;_0x996938!=null?_0x45fbf0=!0x0:(_0x45fbf0=!0x1,_0x996938=g['EMPTY_NODE'],_0x474830['syncPointTree_']['subtree'](_0x5694ed)['foreachChild']((_0x4b5d11,_0x227ca7)=>{const _0x513813=Ee(_0x227ca7,w());_0x513813&&(_0x996938=_0x996938['updateImmediateChild'](_0x4b5d11,_0x513813));}));const _0xf4ef48=Ko(_0x37e97f,_0x1f2c21);if(!_0xf4ef48&&!_0x1f2c21['_queryParams']['loadsAllData']()){const _0x2411dd=Fn(_0x1f2c21);f(!_0x474830['queryToTagMap']['has'](_0x2411dd),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x32a9a7=Xu();_0x474830['queryToTagMap']['set'](_0x2411dd,_0x32a9a7),_0x474830['tagToQueryMap']['set'](_0x32a9a7,_0x2411dd);}const _0x21eb7a=Mn(_0x474830['pendingWriteTree_'],_0x5694ed);let _0x3474c8=Wu(_0x37e97f,_0x1f2c21,_0x1913cc,_0x21eb7a,_0x996938,_0x45fbf0);if(!_0xf4ef48&&!_0x2057d1&&!_0x468ce8){const _0x1bfa03=jo(_0x37e97f,_0x1f2c21);_0x3474c8=_0x3474c8['concat'](Zu(_0x474830,_0x1f2c21,_0x1bfa03));}return _0x3474c8;}function xn(_0x34aba7,_0x361cbc,_0x57f3b5){const _0x14b9e0=_0x34aba7['pendingWriteTree_'],_0x4b5b10=_0x34aba7['syncPointTree_']['findOnPath'](_0x361cbc,(_0x22822c,_0x1e559b)=>{const _0x290945=F(_0x22822c,_0x361cbc),_0x303ac4=Ee(_0x1e559b,_0x290945);if(_0x303ac4)return _0x303ac4;});return Uo(_0x14b9e0,_0x361cbc,_0x4b5b10,_0x57f3b5,!0x0);}function Yu(_0x3fd19a,_0x7f2757){const _0xcd586=_0x7f2757['_path'];let _0x2b04d5=null;_0x3fd19a['syncPointTree_']['foreachOnPath'](_0xcd586,(_0x555338,_0x55a8fd)=>{const _0xf366dc=F(_0x555338,_0xcd586);_0x2b04d5=_0x2b04d5||Ee(_0x55a8fd,_0xf366dc);});let _0x41fffb=_0x3fd19a['syncPointTree_']['get'](_0xcd586);_0x41fffb?_0x2b04d5=_0x2b04d5||Ee(_0x41fffb,w()):(_0x41fffb=new Go(),_0x3fd19a['syncPointTree_']=_0x3fd19a['syncPointTree_']['set'](_0xcd586,_0x41fffb));const _0x3c8a04=_0x2b04d5!=null,_0x32ea8d=_0x3c8a04?new Ce(_0x2b04d5,!0x0,!0x1):null,_0xab6103=Mn(_0x3fd19a['pendingWriteTree_'],_0x7f2757['_path']),_0x30ac32=qo(_0x41fffb,_0x7f2757,_0xab6103,_0x3c8a04?_0x32ea8d['getNode']():g['EMPTY_NODE'],_0x3c8a04);return Ou(_0x30ac32);}function ht(_0x541bcc,_0x5134b4){return Qo(_0x5134b4,_0x541bcc['syncPointTree_'],null,Mn(_0x541bcc['pendingWriteTree_'],w()));}function Qo(_0x25d644,_0x409bd8,_0x38d869,_0x339e9b){if(v(_0x25d644['path']))return Jo(_0x25d644,_0x409bd8,_0x38d869,_0x339e9b);{const _0x21e485=_0x409bd8['get'](w());_0x38d869==null&&_0x21e485!=null&&(_0x38d869=Ee(_0x21e485,w()));let _0x4a03bc=[];const _0x497e73=y(_0x25d644['path']),_0x5610b1=_0x25d644['operationForChild'](_0x497e73),_0x55f9f5=_0x409bd8['children']['get'](_0x497e73);if(_0x55f9f5&&_0x5610b1){const _0x4efeec=_0x38d869?_0x38d869['getImmediateChild'](_0x497e73):null,_0x58f3fd=Wo(_0x339e9b,_0x497e73);_0x4a03bc=_0x4a03bc['concat'](Qo(_0x5610b1,_0x55f9f5,_0x4efeec,_0x58f3fd));}return _0x21e485&&(_0x4a03bc=_0x4a03bc['concat'](is(_0x21e485,_0x25d644,_0x339e9b,_0x38d869))),_0x4a03bc;}}function Jo(_0x3fc46f,_0x5b8654,_0x5297fb,_0x3aaffc){const _0x280579=_0x5b8654['get'](w());_0x5297fb==null&&_0x280579!=null&&(_0x5297fb=Ee(_0x280579,w()));let _0x49dd27=[];return _0x5b8654['children']['inorderTraversal']((_0x4446ec,_0x27688d)=>{const _0x3f5439=_0x5297fb?_0x5297fb['getImmediateChild'](_0x4446ec):null,_0x2fc184=Wo(_0x3aaffc,_0x4446ec),_0x271418=_0x3fc46f['operationForChild'](_0x4446ec);_0x271418&&(_0x49dd27=_0x49dd27['concat'](Jo(_0x271418,_0x27688d,_0x3f5439,_0x2fc184)));}),_0x280579&&(_0x49dd27=_0x49dd27['concat'](is(_0x280579,_0x3fc46f,_0x3aaffc,_0x5297fb))),_0x49dd27;}function Xo(_0x1da713,_0x38b154){const _0x2d1646=_0x38b154['query'],_0x1b3672=Mt(_0x1da713,_0x2d1646);return{'hashFn':()=>(Pu(_0x38b154)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x13e942=>{if(_0x13e942==='ok')return _0x1b3672?ju(_0x1da713,_0x2d1646['_path'],_0x1b3672):zu(_0x1da713,_0x2d1646['_path']);{const _0x23cf2e=ql(_0x13e942,_0x2d1646);return wn(_0x1da713,_0x2d1646,null,_0x23cf2e);}}};}function Mt(_0x840176,_0xa40003){const _0x23b95c=Fn(_0xa40003);return _0x840176['queryToTagMap']['get'](_0x23b95c);}function Fn(_0x247fc6){return _0x247fc6['_path']['toString']()+'$'+_0x247fc6['_queryIdentifier'];}function rs(_0x47e9e0,_0x4b2b46){return _0x47e9e0['tagToQueryMap']['get'](_0x4b2b46);}function os(_0x2249c9){const _0x4ebcc8=_0x2249c9['indexOf']('$');return f(_0x4ebcc8!==-0x1&&_0x4ebcc8<_0x2249c9['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2249c9['substr'](_0x4ebcc8+0x1),'path':new C(_0x2249c9['substr'](0x0,_0x4ebcc8))};}function as(_0x4016ba,_0x52b48a,_0x2d2cad){const _0x1bb40a=_0x4016ba['syncPointTree_']['get'](_0x52b48a);f(_0x1bb40a,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x16215f=Mn(_0x4016ba['pendingWriteTree_'],_0x52b48a);return is(_0x1bb40a,_0x2d2cad,_0x16215f,null);}function Qu(_0x34a8f3){return _0x34a8f3['fold']((_0x5279ab,_0x36ef22,_0x4e3b83)=>{if(_0x36ef22&&Te(_0x36ef22))return[Ln(_0x36ef22)];{let _0x25adb8=[];return _0x36ef22&&(_0x25adb8=zo(_0x36ef22)),x(_0x4e3b83,(_0x4eb744,_0x5eaa35)=>{_0x25adb8=_0x25adb8['concat'](_0x5eaa35);}),_0x25adb8;}});}function Tt(_0x489b5f){return _0x489b5f['_queryParams']['loadsAllData']()&&!_0x489b5f['_queryParams']['isDefault']()?new(Hu())(_0x489b5f['_repo'],_0x489b5f['_path']):_0x489b5f;}function Ju(_0x3befa1,_0x3bcbe7){for(let _0xbc30eb=0x0;_0xbc30eb<_0x3bcbe7['length'];++_0xbc30eb){const _0x28f561=_0x3bcbe7[_0xbc30eb];if(!_0x28f561['_queryParams']['loadsAllData']()){const _0xea2030=Fn(_0x28f561),_0x4289dc=_0x3befa1['queryToTagMap']['get'](_0xea2030);_0x3befa1['queryToTagMap']['delete'](_0xea2030),_0x3befa1['tagToQueryMap']['delete'](_0x4289dc);}}}function Xu(){return $u++;}function Zu(_0x284f84,_0x10eb68,_0x3657c8){const _0x19a142=_0x10eb68['_path'],_0x50d6a1=Mt(_0x284f84,_0x10eb68),_0x3121c5=Xo(_0x284f84,_0x3657c8),_0x46cc11=_0x284f84['listenProvider_']['startListening'](Tt(_0x10eb68),_0x50d6a1,_0x3121c5['hashFn'],_0x3121c5['onComplete']),_0x1d1f3b=_0x284f84['syncPointTree_']['subtree'](_0x19a142);if(_0x50d6a1)f(!Te(_0x1d1f3b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x11aa4a=_0x1d1f3b['fold']((_0x3ee269,_0x3f009c,_0x191048)=>{if(!v(_0x3ee269)&&_0x3f009c&&Te(_0x3f009c))return[Ln(_0x3f009c)['query']];{let _0x60bb20=[];return _0x3f009c&&(_0x60bb20=_0x60bb20['concat'](zo(_0x3f009c)['map'](_0xaa6932=>_0xaa6932['query']))),x(_0x191048,(_0x38d14b,_0x3249c5)=>{_0x60bb20=_0x60bb20['concat'](_0x3249c5);}),_0x60bb20;}});for(let _0xd49408=0x0;_0xd49408<_0x11aa4a['length'];++_0xd49408){const _0x1fead3=_0x11aa4a[_0xd49408];_0x284f84['listenProvider_']['stopListening'](Tt(_0x1fead3),Mt(_0x284f84,_0x1fead3));}}return _0x46cc11;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x417407){this['node_']=_0x417407;}['getImmediateChild'](_0x16119a){const _0xa70c49=this['node_']['getImmediateChild'](_0x16119a);return new cs(_0xa70c49);}['node'](){return this['node_'];}}class ls{constructor(_0x34d2c4,_0x21860c){this['syncTree_']=_0x34d2c4,this['path_']=_0x21860c;}['getImmediateChild'](_0x4a0777){const _0x377e24=A(this['path_'],_0x4a0777);return new ls(this['syncTree_'],_0x377e24);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x2272bf){return _0x2272bf=_0x2272bf||{},_0x2272bf['timestamp']=_0x2272bf['timestamp']||new Date()['getTime'](),_0x2272bf;},fr=function(_0x1575dc,_0x8f7b8a,_0x4974a1){if(!_0x1575dc||typeof _0x1575dc!='object')return _0x1575dc;if(f('.sv'in _0x1575dc,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1575dc['.sv']=='string')return td(_0x1575dc['.sv'],_0x8f7b8a,_0x4974a1);if(typeof _0x1575dc['.sv']=='object')return nd(_0x1575dc['.sv'],_0x8f7b8a);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1575dc,null,0x2));},td=function(_0x14669f,_0xb9bea6,_0x386f3a){switch(_0x14669f){case'timestamp':return _0x386f3a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x14669f);}},nd=function(_0x50e492,_0x1b3550,_0x5e49c5){_0x50e492['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x50e492,null,0x2));const _0x207839=_0x50e492['increment'];typeof _0x207839!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x207839);const _0x48495f=_0x1b3550['node']();if(f(_0x48495f!==null&&typeof _0x48495f<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x48495f['isLeafNode']())return _0x207839;const _0x16aa4d=_0x48495f['getValue']();return typeof _0x16aa4d!='number'?_0x207839:_0x16aa4d+_0x207839;},Zo=function(_0x536954,_0x57fdb1,_0xa3bdfc,_0x49635a){return us(_0x57fdb1,new ls(_0xa3bdfc,_0x536954),_0x49635a);},hs=function(_0xa22acd,_0x4be77e,_0x2e031b){return us(_0xa22acd,new cs(_0x4be77e),_0x2e031b);};function us(_0x5354e0,_0x78bd4b,_0x3096fa){const _0x44ff89=_0x5354e0['getPriority']()['val'](),_0x4d207f=fr(_0x44ff89,_0x78bd4b['getImmediateChild']('.priority'),_0x3096fa);let _0x5601ed;if(_0x5354e0['isLeafNode']()){const _0x4d8041=_0x5354e0,_0xf49391=fr(_0x4d8041['getValue'](),_0x78bd4b,_0x3096fa);return _0xf49391!==_0x4d8041['getValue']()||_0x4d207f!==_0x4d8041['getPriority']()['val']()?new D(_0xf49391,N(_0x4d207f)):_0x5354e0;}else{const _0x100645=_0x5354e0;return _0x5601ed=_0x100645,_0x4d207f!==_0x100645['getPriority']()['val']()&&(_0x5601ed=_0x5601ed['updatePriority'](new D(_0x4d207f))),_0x100645['forEachChild'](R,(_0x46d6e7,_0x170bdd)=>{const _0x46153f=us(_0x170bdd,_0x78bd4b['getImmediateChild'](_0x46d6e7),_0x3096fa);_0x46153f!==_0x170bdd&&(_0x5601ed=_0x5601ed['updateImmediateChild'](_0x46d6e7,_0x46153f));}),_0x5601ed;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3131c5='',_0x4e3d8b=null,_0xa5f8b8={'children':{},'childCount':0x0}){this['name']=_0x3131c5,this['parent']=_0x4e3d8b,this['node']=_0xa5f8b8;}}function Un(_0x22dc04,_0x1aebaa){let _0x1c8194=_0x1aebaa instanceof C?_0x1aebaa:new C(_0x1aebaa),_0x3a16a1=_0x22dc04,_0x21147a=y(_0x1c8194);for(;_0x21147a!==null;){const _0x517434=Oe(_0x3a16a1['node']['children'],_0x21147a)||{'children':{},'childCount':0x0};_0x3a16a1=new ds(_0x21147a,_0x3a16a1,_0x517434),_0x1c8194=b(_0x1c8194),_0x21147a=y(_0x1c8194);}return _0x3a16a1;}function Ge(_0x59207a){return _0x59207a['node']['value'];}function fs(_0x355445,_0x15de8c){_0x355445['node']['value']=_0x15de8c,Ri(_0x355445);}function ea(_0x41b617){return _0x41b617['node']['childCount']>0x0;}function id(_0x2abe36){return Ge(_0x2abe36)===void 0x0&&!ea(_0x2abe36);}function Wn(_0x5da8fb,_0x1e3595){x(_0x5da8fb['node']['children'],(_0xc31999,_0x534b05)=>{_0x1e3595(new ds(_0xc31999,_0x5da8fb,_0x534b05));});}function ta(_0x56a759,_0x4575bf,_0x11bfa1,_0x56cd50){_0x11bfa1&&_0x4575bf(_0x56a759),Wn(_0x56a759,_0x17a18d=>{ta(_0x17a18d,_0x4575bf,!0x0);});}function sd(_0x572176,_0x4c6478,_0x446ad6){let _0x1078a9=_0x572176['parent'];for(;_0x1078a9!==null;){if(_0x4c6478(_0x1078a9))return!0x0;_0x1078a9=_0x1078a9['parent'];}return!0x1;}function Gt(_0x1bd2d9){return new C(_0x1bd2d9['parent']===null?_0x1bd2d9['name']:Gt(_0x1bd2d9['parent'])+'/'+_0x1bd2d9['name']);}function Ri(_0x51574e){_0x51574e['parent']!==null&&rd(_0x51574e['parent'],_0x51574e['name'],_0x51574e);}function rd(_0x19ef2b,_0x4f40e7,_0x27c212){const _0x2d77ea=id(_0x27c212),_0x3b42f9=Y(_0x19ef2b['node']['children'],_0x4f40e7);_0x2d77ea&&_0x3b42f9?(delete _0x19ef2b['node']['children'][_0x4f40e7],_0x19ef2b['node']['childCount']--,Ri(_0x19ef2b)):!_0x2d77ea&&!_0x3b42f9&&(_0x19ef2b['node']['children'][_0x4f40e7]=_0x27c212['node'],_0x19ef2b['node']['childCount']++,Ri(_0x19ef2b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x51ab89){return typeof _0x51ab89=='string'&&_0x51ab89['length']!==0x0&&!od['test'](_0x51ab89);},na=function(_0x445cce){return typeof _0x445cce=='string'&&_0x445cce['length']!==0x0&&!ad['test'](_0x445cce);},cd=function(_0x28176c){return _0x28176c&&(_0x28176c=_0x28176c['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x28176c);},Cn=function(_0x482415){return _0x482415===null||typeof _0x482415=='string'||typeof _0x482415=='number'&&!Wi(_0x482415)||_0x482415&&typeof _0x482415=='object'&&Y(_0x482415,'.sv');},qt=function(_0x158e2f,_0xbfa0f5,_0x4b4826,_0xf012cb){_0xf012cb&&_0xbfa0f5===void 0x0||zt(Nn(_0x158e2f,'value'),_0xbfa0f5,_0x4b4826);},zt=function(_0x3fb159,_0x1084e6,_0x454863){const _0xb0d581=_0x454863 instanceof C?new Sh(_0x454863,_0x3fb159):_0x454863;if(_0x1084e6===void 0x0)throw new Error(_0x3fb159+'contains\x20undefined\x20'+Ne(_0xb0d581));if(typeof _0x1084e6=='function')throw new Error(_0x3fb159+'contains\x20a\x20function\x20'+Ne(_0xb0d581)+'\x20with\x20contents\x20=\x20'+_0x1084e6['toString']());if(Wi(_0x1084e6))throw new Error(_0x3fb159+'contains\x20'+_0x1084e6['toString']()+'\x20'+Ne(_0xb0d581));if(typeof _0x1084e6=='string'&&_0x1084e6['length']>oi/0x3&&Pn(_0x1084e6)>oi)throw new Error(_0x3fb159+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0xb0d581)+'\x20(\x27'+_0x1084e6['substring'](0x0,0x32)+'...\x27)');if(_0x1084e6&&typeof _0x1084e6=='object'){let _0x5627ce=!0x1,_0x35caa1=!0x1;if(x(_0x1084e6,(_0x4f0275,_0x1faa0c)=>{if(_0x4f0275==='.value')_0x5627ce=!0x0;else{if(_0x4f0275!=='.priority'&&_0x4f0275!=='.sv'&&(_0x35caa1=!0x0,!ps(_0x4f0275)))throw new Error(_0x3fb159+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4f0275+')\x20'+Ne(_0xb0d581)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0xb0d581,_0x4f0275),zt(_0x3fb159,_0x1faa0c,_0xb0d581),Rh(_0xb0d581);}),_0x5627ce&&_0x35caa1)throw new Error(_0x3fb159+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0xb0d581)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x59349e,_0x55d488){let _0x2e4f99,_0x10add3;for(_0x2e4f99=0x0;_0x2e4f99<_0x55d488['length'];_0x2e4f99++){_0x10add3=_0x55d488[_0x2e4f99];const _0x47cd6c=kt(_0x10add3);for(let _0x2449d3=0x0;_0x2449d3<_0x47cd6c['length'];_0x2449d3++)if(!(_0x47cd6c[_0x2449d3]==='.priority'&&_0x2449d3===_0x47cd6c['length']-0x1)){if(!ps(_0x47cd6c[_0x2449d3]))throw new Error(_0x59349e+'contains\x20an\x20invalid\x20key\x20('+_0x47cd6c[_0x2449d3]+')\x20in\x20path\x20'+_0x10add3['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x55d488['sort'](Th);let _0x5f4e37=null;for(_0x2e4f99=0x0;_0x2e4f99<_0x55d488['length'];_0x2e4f99++){if(_0x10add3=_0x55d488[_0x2e4f99],_0x5f4e37!==null&&$(_0x5f4e37,_0x10add3))throw new Error(_0x59349e+'contains\x20a\x20path\x20'+_0x5f4e37['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x10add3['toString']());_0x5f4e37=_0x10add3;}},hd=function(_0x3b0aa8,_0x1e2203,_0x4e0068,_0x3b7ab7){const _0x312a00=Nn(_0x3b0aa8,'values');if(!(_0x1e2203&&typeof _0x1e2203=='object')||Array['isArray'](_0x1e2203))throw new Error(_0x312a00+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4461f0=[];x(_0x1e2203,(_0x4fbb19,_0x2f3b95)=>{const _0x1a2240=new C(_0x4fbb19);if(zt(_0x312a00,_0x2f3b95,A(_0x4e0068,_0x1a2240)),Gi(_0x1a2240)==='.priority'&&!Cn(_0x2f3b95))throw new Error(_0x312a00+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1a2240['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4461f0['push'](_0x1a2240);}),ld(_0x312a00,_0x4461f0);},_s=function(_0x18544b,_0x52d9c6,_0x33cd6a,_0x4513b4){if(!na(_0x33cd6a))throw new Error(Nn(_0x18544b,_0x52d9c6)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x33cd6a+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5eff76,_0x13fd6b,_0x748b53,_0x320890){_0x748b53&&(_0x748b53=_0x748b53['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5eff76,_0x13fd6b,_0x748b53);},gs=function(_0x437f96,_0x3d4901){if(y(_0x3d4901)==='.info')throw new Error(_0x437f96+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x33f344,_0x35f031){const _0x4dbdd1=_0x35f031['path']['toString']();if(typeof _0x35f031['repoInfo']['host']!='string'||_0x35f031['repoInfo']['host']['length']===0x0||!ps(_0x35f031['repoInfo']['namespace'])&&_0x35f031['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4dbdd1['length']!==0x0&&!cd(_0x4dbdd1))throw new Error(Nn(_0x33f344,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x4dfe21,_0x5a049a){let _0x5df378=null;for(let _0x439331=0x0;_0x439331<_0x5a049a['length'];_0x439331++){const _0x290397=_0x5a049a[_0x439331],_0x512589=_0x290397['getPath']();_0x5df378!==null&&!qi(_0x512589,_0x5df378['path'])&&(_0x4dfe21['eventLists_']['push'](_0x5df378),_0x5df378=null),_0x5df378===null&&(_0x5df378={'events':[],'path':_0x512589}),_0x5df378['events']['push'](_0x290397);}_0x5df378&&_0x4dfe21['eventLists_']['push'](_0x5df378);}function ia(_0x49b72c,_0x54a73b,_0x5e66da){Bn(_0x49b72c,_0x5e66da),sa(_0x49b72c,_0x333a60=>qi(_0x333a60,_0x54a73b));}function V(_0x332267,_0x58e10d,_0xffdeb3){Bn(_0x332267,_0xffdeb3),sa(_0x332267,_0x4baeeb=>$(_0x4baeeb,_0x58e10d)||$(_0x58e10d,_0x4baeeb));}function sa(_0x17a151,_0x202bc3){_0x17a151['recursionDepth_']++;let _0x49d787=!0x0;for(let _0x540fca=0x0;_0x540fca<_0x17a151['eventLists_']['length'];_0x540fca++){const _0xee6c58=_0x17a151['eventLists_'][_0x540fca];if(_0xee6c58){const _0x10c014=_0xee6c58['path'];_0x202bc3(_0x10c014)?(pd(_0x17a151['eventLists_'][_0x540fca]),_0x17a151['eventLists_'][_0x540fca]=null):_0x49d787=!0x1;}}_0x49d787&&(_0x17a151['eventLists_']=[]),_0x17a151['recursionDepth_']--;}function pd(_0x5095a7){for(let _0x17f161=0x0;_0x17f161<_0x5095a7['events']['length'];_0x17f161++){const _0x1bd129=_0x5095a7['events'][_0x17f161];if(_0x1bd129!==null){_0x5095a7['events'][_0x17f161]=null;const _0x41257a=_0x1bd129['getEventRunner']();Et&&L('event:\x20'+_0x1bd129['toString']()),lt(_0x41257a);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x544fce,_0x250a0b,_0x12f575,_0x11fd15){this['repoInfo_']=_0x544fce,this['forceRestClient_']=_0x250a0b,this['authTokenProvider_']=_0x12f575,this['appCheckProvider_']=_0x11fd15,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x29d2ad,_0x2f1421,_0x1af823){if(_0x29d2ad['stats_']=Hi(_0x29d2ad['repoInfo_']),_0x29d2ad['forceRestClient_']||Yl())_0x29d2ad['server_']=new fn(_0x29d2ad['repoInfo_'],(_0x4162a1,_0x4edeb6,_0x5c9147,_0x3cc000)=>{pr(_0x29d2ad,_0x4162a1,_0x4edeb6,_0x5c9147,_0x3cc000);},_0x29d2ad['authTokenProvider_'],_0x29d2ad['appCheckProvider_']),setTimeout(()=>_r(_0x29d2ad,!0x0),0x0);else{if(typeof _0x1af823<'u'&&_0x1af823!==null){if(typeof _0x1af823!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1af823);}catch(_0x3aa2a1){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3aa2a1);}}_0x29d2ad['persistentConnection_']=new ie(_0x29d2ad['repoInfo_'],_0x2f1421,(_0x39fa96,_0x1d8fa9,_0x250c41,_0x357e75)=>{pr(_0x29d2ad,_0x39fa96,_0x1d8fa9,_0x250c41,_0x357e75);},_0x4b5da2=>{_r(_0x29d2ad,_0x4b5da2);},_0x4d93c7=>{yd(_0x29d2ad,_0x4d93c7);},_0x29d2ad['authTokenProvider_'],_0x29d2ad['appCheckProvider_'],_0x1af823),_0x29d2ad['server_']=_0x29d2ad['persistentConnection_'];}_0x29d2ad['authTokenProvider_']['addTokenChangeListener'](_0x11a45a=>{_0x29d2ad['server_']['refreshAuthToken'](_0x11a45a);}),_0x29d2ad['appCheckProvider_']['addTokenChangeListener'](_0x262305=>{_0x29d2ad['server_']['refreshAppCheckToken'](_0x262305['token']);}),_0x29d2ad['statsReporter_']=eh(_0x29d2ad['repoInfo_'],()=>new eu(_0x29d2ad['stats_'],_0x29d2ad['server_'])),_0x29d2ad['infoData_']=new Yh(),_0x29d2ad['infoSyncTree_']=new dr({'startListening':(_0x6d9c8e,_0x32688f,_0x1b2878,_0x5a5a03)=>{let _0x2e95d5=[];const _0x550533=_0x29d2ad['infoData_']['getNode'](_0x6d9c8e['_path']);return _0x550533['isEmpty']()||(_0x2e95d5=$t(_0x29d2ad['infoSyncTree_'],_0x6d9c8e['_path'],_0x550533),setTimeout(()=>{_0x5a5a03('ok');},0x0)),_0x2e95d5;},'stopListening':()=>{}}),ms(_0x29d2ad,'connected',!0x1),_0x29d2ad['serverSyncTree_']=new dr({'startListening':(_0x5c6c86,_0x5274c7,_0x173a15,_0x268a83)=>(_0x29d2ad['server_']['listen'](_0x5c6c86,_0x173a15,_0x5274c7,(_0x4aec2c,_0x1149eb)=>{const _0x3bba8e=_0x268a83(_0x4aec2c,_0x1149eb);V(_0x29d2ad['eventQueue_'],_0x5c6c86['_path'],_0x3bba8e);}),[]),'stopListening':(_0x18f63e,_0x271fe4)=>{_0x29d2ad['server_']['unlisten'](_0x18f63e,_0x271fe4);}});}function oa(_0x524d13){const _0x1aad90=_0x524d13['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1aad90;}function jt(_0x127db2){return ed({'timestamp':oa(_0x127db2)});}function pr(_0x12c3f1,_0x2a3327,_0x343033,_0x2b2d1c,_0x41e5db){_0x12c3f1['dataUpdateCount']++;const _0x173bcc=new C(_0x2a3327);_0x343033=_0x12c3f1['interceptServerDataCallback_']?_0x12c3f1['interceptServerDataCallback_'](_0x2a3327,_0x343033):_0x343033;let _0x529ff2=[];if(_0x41e5db){if(_0x2b2d1c){const _0x5ccf2e=ln(_0x343033,_0x4796ba=>N(_0x4796ba));_0x529ff2=Ku(_0x12c3f1['serverSyncTree_'],_0x173bcc,_0x5ccf2e,_0x41e5db);}else{const _0x415808=N(_0x343033);_0x529ff2=Yo(_0x12c3f1['serverSyncTree_'],_0x173bcc,_0x415808,_0x41e5db);}}else{if(_0x2b2d1c){const _0x2bcfe4=ln(_0x343033,_0x5e03f4=>N(_0x5e03f4));_0x529ff2=qu(_0x12c3f1['serverSyncTree_'],_0x173bcc,_0x2bcfe4);}else{const _0x186c6f=N(_0x343033);_0x529ff2=$t(_0x12c3f1['serverSyncTree_'],_0x173bcc,_0x186c6f);}}let _0x4bf51f=_0x173bcc;_0x529ff2['length']>0x0&&(_0x4bf51f=st(_0x12c3f1,_0x173bcc)),V(_0x12c3f1['eventQueue_'],_0x4bf51f,_0x529ff2);}function _r(_0x3c9bae,_0x3cc3d3){ms(_0x3c9bae,'connected',_0x3cc3d3),_0x3cc3d3===!0x1&&wd(_0x3c9bae);}function yd(_0x270d77,_0x5f299c){x(_0x5f299c,(_0x347fcb,_0x55e58b)=>{ms(_0x270d77,_0x347fcb,_0x55e58b);});}function ms(_0x4fc5c5,_0x32a5a7,_0x1d3e07){const _0x511e51=new C('/.info/'+_0x32a5a7),_0x4aa26a=N(_0x1d3e07);_0x4fc5c5['infoData_']['updateSnapshot'](_0x511e51,_0x4aa26a);const _0x2567d5=$t(_0x4fc5c5['infoSyncTree_'],_0x511e51,_0x4aa26a);V(_0x4fc5c5['eventQueue_'],_0x511e51,_0x2567d5);}function Vn(_0xe151f0){return _0xe151f0['nextWriteId_']++;}function vd(_0x1a2c62,_0xef5e82,_0x315f15){const _0x232cbc=Yu(_0x1a2c62['serverSyncTree_'],_0xef5e82);return _0x232cbc!=null?Promise['resolve'](_0x232cbc):_0x1a2c62['server_']['get'](_0xef5e82)['then'](_0x2aac07=>{const _0x1eda70=N(_0x2aac07)['withIndex'](_0xef5e82['_queryParams']['getIndex']());bi(_0x1a2c62['serverSyncTree_'],_0xef5e82,_0x315f15,!0x0);let _0x452983;if(_0xef5e82['_queryParams']['loadsAllData']())_0x452983=$t(_0x1a2c62['serverSyncTree_'],_0xef5e82['_path'],_0x1eda70);else{const _0x2c7a32=Mt(_0x1a2c62['serverSyncTree_'],_0xef5e82);_0x452983=Yo(_0x1a2c62['serverSyncTree_'],_0xef5e82['_path'],_0x1eda70,_0x2c7a32);}return V(_0x1a2c62['eventQueue_'],_0xef5e82['_path'],_0x452983),wn(_0x1a2c62['serverSyncTree_'],_0xef5e82,_0x315f15,null,!0x0),_0x1eda70;},_0xeadc4c=>(ut(_0x1a2c62,'get\x20for\x20query\x20'+O(_0xef5e82)+'\x20failed:\x20'+_0xeadc4c),Promise['reject'](new Error(_0xeadc4c))));}function Ed(_0x530d42,_0x30102,_0x1664ca,_0x213e6e,_0x269671){ut(_0x530d42,'set',{'path':_0x30102['toString'](),'value':_0x1664ca,'priority':_0x213e6e});const _0x18b540=jt(_0x530d42),_0x25d9ed=N(_0x1664ca,_0x213e6e),_0x485179=xn(_0x530d42['serverSyncTree_'],_0x30102),_0x411d61=hs(_0x25d9ed,_0x485179,_0x18b540),_0x3590b4=Vn(_0x530d42),_0x53730f=ss(_0x530d42['serverSyncTree_'],_0x30102,_0x411d61,_0x3590b4,!0x0);Bn(_0x530d42['eventQueue_'],_0x53730f),_0x530d42['server_']['put'](_0x30102['toString'](),_0x25d9ed['val'](!0x0),(_0x20cdc9,_0x1836fc)=>{const _0x75a25a=_0x20cdc9==='ok';_0x75a25a||U('set\x20at\x20'+_0x30102+'\x20failed:\x20'+_0x20cdc9);const _0x7fc5f1=pe(_0x530d42['serverSyncTree_'],_0x3590b4,!_0x75a25a);V(_0x530d42['eventQueue_'],_0x30102,_0x7fc5f1),Ai(_0x530d42,_0x269671,_0x20cdc9,_0x1836fc);});const _0x57276c=vs(_0x530d42,_0x30102);st(_0x530d42,_0x57276c),V(_0x530d42['eventQueue_'],_0x57276c,[]);}function Id(_0x210720,_0x4ccf19,_0x513769,_0x7d2c36){ut(_0x210720,'update',{'path':_0x4ccf19['toString'](),'value':_0x513769});let _0x3f637f=!0x0;const _0x1a086e=jt(_0x210720),_0x27f582={};if(x(_0x513769,(_0x5da400,_0x441797)=>{_0x3f637f=!0x1,_0x27f582[_0x5da400]=Zo(A(_0x4ccf19,_0x5da400),N(_0x441797),_0x210720['serverSyncTree_'],_0x1a086e);}),_0x3f637f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x210720,_0x7d2c36,'ok',void 0x0);else{const _0x1cc0b3=Vn(_0x210720),_0x504b68=Gu(_0x210720['serverSyncTree_'],_0x4ccf19,_0x27f582,_0x1cc0b3);Bn(_0x210720['eventQueue_'],_0x504b68),_0x210720['server_']['merge'](_0x4ccf19['toString'](),_0x513769,(_0x328e39,_0x520991)=>{const _0x56eb8b=_0x328e39==='ok';_0x56eb8b||U('update\x20at\x20'+_0x4ccf19+'\x20failed:\x20'+_0x328e39);const _0x5756d8=pe(_0x210720['serverSyncTree_'],_0x1cc0b3,!_0x56eb8b),_0x3bf0f2=_0x5756d8['length']>0x0?st(_0x210720,_0x4ccf19):_0x4ccf19;V(_0x210720['eventQueue_'],_0x3bf0f2,_0x5756d8),Ai(_0x210720,_0x7d2c36,_0x328e39,_0x520991);}),x(_0x513769,_0x10036c=>{const _0x435a0d=vs(_0x210720,A(_0x4ccf19,_0x10036c));st(_0x210720,_0x435a0d);}),V(_0x210720['eventQueue_'],_0x4ccf19,[]);}}function wd(_0x5caee0){ut(_0x5caee0,'onDisconnectEvents');const _0x34a2a0=jt(_0x5caee0),_0x1aa42f=pn();Ei(_0x5caee0['onDisconnect_'],w(),(_0x5b06f3,_0x4a3582)=>{const _0x297c55=Zo(_0x5b06f3,_0x4a3582,_0x5caee0['serverSyncTree_'],_0x34a2a0);Mo(_0x1aa42f,_0x5b06f3,_0x297c55);});let _0x21cc4a=[];Ei(_0x1aa42f,w(),(_0x26c034,_0x275f20)=>{_0x21cc4a=_0x21cc4a['concat']($t(_0x5caee0['serverSyncTree_'],_0x26c034,_0x275f20));const _0x3fb4f8=vs(_0x5caee0,_0x26c034);st(_0x5caee0,_0x3fb4f8);}),_0x5caee0['onDisconnect_']=pn(),V(_0x5caee0['eventQueue_'],w(),_0x21cc4a);}function Cd(_0x2bf111,_0x28cf07,_0x27e5f1){let _0x237fb2;y(_0x28cf07['_path'])==='.info'?_0x237fb2=bi(_0x2bf111['infoSyncTree_'],_0x28cf07,_0x27e5f1):_0x237fb2=bi(_0x2bf111['serverSyncTree_'],_0x28cf07,_0x27e5f1),ia(_0x2bf111['eventQueue_'],_0x28cf07['_path'],_0x237fb2);}function Td(_0x57f1bf,_0x133f73,_0x1158b2){let _0x27195e;y(_0x133f73['_path'])==='.info'?_0x27195e=wn(_0x57f1bf['infoSyncTree_'],_0x133f73,_0x1158b2):_0x27195e=wn(_0x57f1bf['serverSyncTree_'],_0x133f73,_0x1158b2),ia(_0x57f1bf['eventQueue_'],_0x133f73['_path'],_0x27195e);}function aa(_0x3e73d3){_0x3e73d3['persistentConnection_']&&_0x3e73d3['persistentConnection_']['interrupt'](ra);}function Sd(_0xb39622){_0xb39622['persistentConnection_']&&_0xb39622['persistentConnection_']['resume'](ra);}function ut(_0x9a537e,..._0x56f6e8){let _0x255aa2='';_0x9a537e['persistentConnection_']&&(_0x255aa2=_0x9a537e['persistentConnection_']['id']+':'),L(_0x255aa2,..._0x56f6e8);}function Ai(_0x18411a,_0x2ec887,_0x1dd907,_0x1ffeca){_0x2ec887&&lt(()=>{if(_0x1dd907==='ok')_0x2ec887(null);else{const _0x338301=(_0x1dd907||'error')['toUpperCase']();let _0x3e5476=_0x338301;_0x1ffeca&&(_0x3e5476+=':\x20'+_0x1ffeca);const _0x31457b=new Error(_0x3e5476);_0x31457b['code']=_0x338301,_0x2ec887(_0x31457b);}});}function bd(_0x49e008,_0x1f501b,_0x3d5468,_0x1c1130,_0xb4354b,_0x57c49d){ut(_0x49e008,'transaction\x20on\x20'+_0x1f501b);const _0x19d1ac={'path':_0x1f501b,'update':_0x3d5468,'onComplete':_0x1c1130,'status':null,'order':to(),'applyLocally':_0x57c49d,'retryCount':0x0,'unwatcher':_0xb4354b,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x18a71a=ys(_0x49e008,_0x1f501b,void 0x0);_0x19d1ac['currentInputSnapshot']=_0x18a71a;const _0xf6f08d=_0x19d1ac['update'](_0x18a71a['val']());if(_0xf6f08d===void 0x0)_0x19d1ac['unwatcher'](),_0x19d1ac['currentOutputSnapshotRaw']=null,_0x19d1ac['currentOutputSnapshotResolved']=null,_0x19d1ac['onComplete']&&_0x19d1ac['onComplete'](null,!0x1,_0x19d1ac['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0xf6f08d,_0x19d1ac['path']),_0x19d1ac['status']=0x0;const _0x3dab9d=Un(_0x49e008['transactionQueueTree_'],_0x1f501b),_0x54ae66=Ge(_0x3dab9d)||[];_0x54ae66['push'](_0x19d1ac),fs(_0x3dab9d,_0x54ae66);let _0xaed7c3;typeof _0xf6f08d=='object'&&_0xf6f08d!==null&&Y(_0xf6f08d,'.priority')?(_0xaed7c3=Oe(_0xf6f08d,'.priority'),f(Cn(_0xaed7c3),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xaed7c3=(xn(_0x49e008['serverSyncTree_'],_0x1f501b)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1beede=jt(_0x49e008),_0x298513=N(_0xf6f08d,_0xaed7c3),_0x3d7c7f=hs(_0x298513,_0x18a71a,_0x1beede);_0x19d1ac['currentOutputSnapshotRaw']=_0x298513,_0x19d1ac['currentOutputSnapshotResolved']=_0x3d7c7f,_0x19d1ac['currentWriteId']=Vn(_0x49e008);const _0x2beed2=ss(_0x49e008['serverSyncTree_'],_0x1f501b,_0x3d7c7f,_0x19d1ac['currentWriteId'],_0x19d1ac['applyLocally']);V(_0x49e008['eventQueue_'],_0x1f501b,_0x2beed2),Hn(_0x49e008,_0x49e008['transactionQueueTree_']);}}function ys(_0x4f51df,_0x4f108c,_0x38e2fc){return xn(_0x4f51df['serverSyncTree_'],_0x4f108c,_0x38e2fc)||g['EMPTY_NODE'];}function Hn(_0x42b655,_0x4487dc=_0x42b655['transactionQueueTree_']){if(_0x4487dc||$n(_0x42b655,_0x4487dc),Ge(_0x4487dc)){const _0x2e5c87=la(_0x42b655,_0x4487dc);f(_0x2e5c87['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2e5c87['every'](_0x2998fd=>_0x2998fd['status']===0x0)&&Rd(_0x42b655,Gt(_0x4487dc),_0x2e5c87);}else ea(_0x4487dc)&&Wn(_0x4487dc,_0x32b351=>{Hn(_0x42b655,_0x32b351);});}function Rd(_0x2992c1,_0x4e464d,_0x57c706){const _0x2d096b=_0x57c706['map'](_0x5a5b2c=>_0x5a5b2c['currentWriteId']),_0x324f52=ys(_0x2992c1,_0x4e464d,_0x2d096b);let _0x243912=_0x324f52;const _0x48ec89=_0x324f52['hash']();for(let _0x33d782=0x0;_0x33d782<_0x57c706['length'];_0x33d782++){const _0x3f3483=_0x57c706[_0x33d782];f(_0x3f3483['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3f3483['status']=0x1,_0x3f3483['retryCount']++;const _0x35a1b8=F(_0x4e464d,_0x3f3483['path']);_0x243912=_0x243912['updateChild'](_0x35a1b8,_0x3f3483['currentOutputSnapshotRaw']);}const _0x3b13de=_0x243912['val'](!0x0),_0x46e60c=_0x4e464d;_0x2992c1['server_']['put'](_0x46e60c['toString'](),_0x3b13de,_0x20099a=>{ut(_0x2992c1,'transaction\x20put\x20response',{'path':_0x46e60c['toString'](),'status':_0x20099a});let _0x3d14cc=[];if(_0x20099a==='ok'){const _0x3fa9dc=[];for(let _0x2c7078=0x0;_0x2c7078<_0x57c706['length'];_0x2c7078++)_0x57c706[_0x2c7078]['status']=0x2,_0x3d14cc=_0x3d14cc['concat'](pe(_0x2992c1['serverSyncTree_'],_0x57c706[_0x2c7078]['currentWriteId'])),_0x57c706[_0x2c7078]['onComplete']&&_0x3fa9dc['push'](()=>_0x57c706[_0x2c7078]['onComplete'](null,!0x0,_0x57c706[_0x2c7078]['currentOutputSnapshotResolved'])),_0x57c706[_0x2c7078]['unwatcher']();$n(_0x2992c1,Un(_0x2992c1['transactionQueueTree_'],_0x4e464d)),Hn(_0x2992c1,_0x2992c1['transactionQueueTree_']),V(_0x2992c1['eventQueue_'],_0x4e464d,_0x3d14cc);for(let _0x799deb=0x0;_0x799deb<_0x3fa9dc['length'];_0x799deb++)lt(_0x3fa9dc[_0x799deb]);}else{if(_0x20099a==='datastale'){for(let _0x1240e8=0x0;_0x1240e8<_0x57c706['length'];_0x1240e8++)_0x57c706[_0x1240e8]['status']===0x3?_0x57c706[_0x1240e8]['status']=0x4:_0x57c706[_0x1240e8]['status']=0x0;}else{U('transaction\x20at\x20'+_0x46e60c['toString']()+'\x20failed:\x20'+_0x20099a);for(let _0x3c9b3a=0x0;_0x3c9b3a<_0x57c706['length'];_0x3c9b3a++)_0x57c706[_0x3c9b3a]['status']=0x4,_0x57c706[_0x3c9b3a]['abortReason']=_0x20099a;}st(_0x2992c1,_0x4e464d);}},_0x48ec89);}function st(_0xdc8b25,_0x14c0e1){const _0x1d9474=ca(_0xdc8b25,_0x14c0e1),_0x4f5a97=Gt(_0x1d9474),_0x242304=la(_0xdc8b25,_0x1d9474);return Ad(_0xdc8b25,_0x242304,_0x4f5a97),_0x4f5a97;}function Ad(_0x27de09,_0x488147,_0x1a9a5f){if(_0x488147['length']===0x0)return;const _0x25544a=[];let _0x582b9e=[];const _0x6877a7=_0x488147['filter'](_0x18f459=>_0x18f459['status']===0x0)['map'](_0x1a6391=>_0x1a6391['currentWriteId']);for(let _0x4b6b94=0x0;_0x4b6b94<_0x488147['length'];_0x4b6b94++){const _0x43961d=_0x488147[_0x4b6b94],_0x4ab7de=F(_0x1a9a5f,_0x43961d['path']);let _0x586695=!0x1,_0x4a8258;if(f(_0x4ab7de!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x43961d['status']===0x4)_0x586695=!0x0,_0x4a8258=_0x43961d['abortReason'],_0x582b9e=_0x582b9e['concat'](pe(_0x27de09['serverSyncTree_'],_0x43961d['currentWriteId'],!0x0));else{if(_0x43961d['status']===0x0){if(_0x43961d['retryCount']>=_d)_0x586695=!0x0,_0x4a8258='maxretry',_0x582b9e=_0x582b9e['concat'](pe(_0x27de09['serverSyncTree_'],_0x43961d['currentWriteId'],!0x0));else{const _0x129bc6=ys(_0x27de09,_0x43961d['path'],_0x6877a7);_0x43961d['currentInputSnapshot']=_0x129bc6;const _0x4ff745=_0x488147[_0x4b6b94]['update'](_0x129bc6['val']());if(_0x4ff745!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x4ff745,_0x43961d['path']);let _0xae84cb=N(_0x4ff745);typeof _0x4ff745=='object'&&_0x4ff745!=null&&Y(_0x4ff745,'.priority')||(_0xae84cb=_0xae84cb['updatePriority'](_0x129bc6['getPriority']()));const _0x4c54c9=_0x43961d['currentWriteId'],_0x16c2b3=jt(_0x27de09),_0x13df2b=hs(_0xae84cb,_0x129bc6,_0x16c2b3);_0x43961d['currentOutputSnapshotRaw']=_0xae84cb,_0x43961d['currentOutputSnapshotResolved']=_0x13df2b,_0x43961d['currentWriteId']=Vn(_0x27de09),_0x6877a7['splice'](_0x6877a7['indexOf'](_0x4c54c9),0x1),_0x582b9e=_0x582b9e['concat'](ss(_0x27de09['serverSyncTree_'],_0x43961d['path'],_0x13df2b,_0x43961d['currentWriteId'],_0x43961d['applyLocally'])),_0x582b9e=_0x582b9e['concat'](pe(_0x27de09['serverSyncTree_'],_0x4c54c9,!0x0));}else _0x586695=!0x0,_0x4a8258='nodata',_0x582b9e=_0x582b9e['concat'](pe(_0x27de09['serverSyncTree_'],_0x43961d['currentWriteId'],!0x0));}}}V(_0x27de09['eventQueue_'],_0x1a9a5f,_0x582b9e),_0x582b9e=[],_0x586695&&(_0x488147[_0x4b6b94]['status']=0x2,function(_0x5e83b0){setTimeout(_0x5e83b0,Math['floor'](0x0));}(_0x488147[_0x4b6b94]['unwatcher']),_0x488147[_0x4b6b94]['onComplete']&&(_0x4a8258==='nodata'?_0x25544a['push'](()=>_0x488147[_0x4b6b94]['onComplete'](null,!0x1,_0x488147[_0x4b6b94]['currentInputSnapshot'])):_0x25544a['push'](()=>_0x488147[_0x4b6b94]['onComplete'](new Error(_0x4a8258),!0x1,null))));}$n(_0x27de09,_0x27de09['transactionQueueTree_']);for(let _0xa38be1=0x0;_0xa38be1<_0x25544a['length'];_0xa38be1++)lt(_0x25544a[_0xa38be1]);Hn(_0x27de09,_0x27de09['transactionQueueTree_']);}function ca(_0x454547,_0x4f5a28){let _0x7d2fe5,_0x11584d=_0x454547['transactionQueueTree_'];for(_0x7d2fe5=y(_0x4f5a28);_0x7d2fe5!==null&&Ge(_0x11584d)===void 0x0;)_0x11584d=Un(_0x11584d,_0x7d2fe5),_0x4f5a28=b(_0x4f5a28),_0x7d2fe5=y(_0x4f5a28);return _0x11584d;}function la(_0x2d7f55,_0x72f969){const _0x422589=[];return ha(_0x2d7f55,_0x72f969,_0x422589),_0x422589['sort']((_0x332ebf,_0x162f78)=>_0x332ebf['order']-_0x162f78['order']),_0x422589;}function ha(_0x322a26,_0x1c10d6,_0x122547){const _0x5c6252=Ge(_0x1c10d6);if(_0x5c6252){for(let _0x3e7956=0x0;_0x3e7956<_0x5c6252['length'];_0x3e7956++)_0x122547['push'](_0x5c6252[_0x3e7956]);}Wn(_0x1c10d6,_0x231703=>{ha(_0x322a26,_0x231703,_0x122547);});}function $n(_0x3fb844,_0x24a16b){const _0x16b521=Ge(_0x24a16b);if(_0x16b521){let _0x55ccbf=0x0;for(let _0x3dcdb4=0x0;_0x3dcdb4<_0x16b521['length'];_0x3dcdb4++)_0x16b521[_0x3dcdb4]['status']!==0x2&&(_0x16b521[_0x55ccbf]=_0x16b521[_0x3dcdb4],_0x55ccbf++);_0x16b521['length']=_0x55ccbf,fs(_0x24a16b,_0x16b521['length']>0x0?_0x16b521:void 0x0);}Wn(_0x24a16b,_0xbc9386=>{$n(_0x3fb844,_0xbc9386);});}function vs(_0x219cea,_0x45892b){const _0x227ce5=Gt(ca(_0x219cea,_0x45892b)),_0x222958=Un(_0x219cea['transactionQueueTree_'],_0x45892b);return sd(_0x222958,_0xbf35a1=>{ai(_0x219cea,_0xbf35a1);}),ai(_0x219cea,_0x222958),ta(_0x222958,_0x3e92d0=>{ai(_0x219cea,_0x3e92d0);}),_0x227ce5;}function ai(_0x3224b0,_0x2938db){const _0x31c584=Ge(_0x2938db);if(_0x31c584){const _0xd055fd=[];let _0x2a5b35=[],_0x2af56c=-0x1;for(let _0xb4bb57=0x0;_0xb4bb57<_0x31c584['length'];_0xb4bb57++)_0x31c584[_0xb4bb57]['status']===0x3||(_0x31c584[_0xb4bb57]['status']===0x1?(f(_0x2af56c===_0xb4bb57-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2af56c=_0xb4bb57,_0x31c584[_0xb4bb57]['status']=0x3,_0x31c584[_0xb4bb57]['abortReason']='set'):(f(_0x31c584[_0xb4bb57]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x31c584[_0xb4bb57]['unwatcher'](),_0x2a5b35=_0x2a5b35['concat'](pe(_0x3224b0['serverSyncTree_'],_0x31c584[_0xb4bb57]['currentWriteId'],!0x0)),_0x31c584[_0xb4bb57]['onComplete']&&_0xd055fd['push'](_0x31c584[_0xb4bb57]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2af56c===-0x1?fs(_0x2938db,void 0x0):_0x31c584['length']=_0x2af56c+0x1,V(_0x3224b0['eventQueue_'],Gt(_0x2938db),_0x2a5b35);for(let _0x38b348=0x0;_0x38b348<_0xd055fd['length'];_0x38b348++)lt(_0xd055fd[_0x38b348]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x5dd5ca){let _0x343b27='';const _0x234d02=_0x5dd5ca['split']('/');for(let _0x24e022=0x0;_0x24e022<_0x234d02['length'];_0x24e022++)if(_0x234d02[_0x24e022]['length']>0x0){let _0x2d2758=_0x234d02[_0x24e022];try{_0x2d2758=decodeURIComponent(_0x2d2758['replace'](/\+/g,'\x20'));}catch{}_0x343b27+='/'+_0x2d2758;}return _0x343b27;}function Nd(_0x2488d7){const _0x1f22aa={};_0x2488d7['charAt'](0x0)==='?'&&(_0x2488d7=_0x2488d7['substring'](0x1));for(const _0x50235d of _0x2488d7['split']('&')){if(_0x50235d['length']===0x0)continue;const _0x164577=_0x50235d['split']('=');_0x164577['length']===0x2?_0x1f22aa[decodeURIComponent(_0x164577[0x0])]=decodeURIComponent(_0x164577[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x50235d+'\x27\x20in\x20query\x20\x27'+_0x2488d7+'\x27');}return _0x1f22aa;}const gr=function(_0x192e96,_0x12c5a7){const _0x20b4e1=Pd(_0x192e96),_0x507a94=_0x20b4e1['namespace'];_0x20b4e1['domain']==='firebase.com'&&oe(_0x20b4e1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x507a94||_0x507a94==='undefined')&&_0x20b4e1['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x20b4e1['secure']||Bl();const _0x41bf3a=_0x20b4e1['scheme']==='ws'||_0x20b4e1['scheme']==='wss';return{'repoInfo':new _o(_0x20b4e1['host'],_0x20b4e1['secure'],_0x507a94,_0x41bf3a,_0x12c5a7,'',_0x507a94!==_0x20b4e1['subdomain']),'path':new C(_0x20b4e1['pathString'])};},Pd=function(_0x1191ba){let _0x130758='',_0x1e7f9c='',_0x13f7f4='',_0x5cfc21='',_0x28e53a='',_0x29def7=!0x0,_0x960322='https',_0xcf01e5=0x1bb;if(typeof _0x1191ba=='string'){let _0x1807bd=_0x1191ba['indexOf']('//');_0x1807bd>=0x0&&(_0x960322=_0x1191ba['substring'](0x0,_0x1807bd-0x1),_0x1191ba=_0x1191ba['substring'](_0x1807bd+0x2));let _0x265744=_0x1191ba['indexOf']('/');_0x265744===-0x1&&(_0x265744=_0x1191ba['length']);let _0x499280=_0x1191ba['indexOf']('?');_0x499280===-0x1&&(_0x499280=_0x1191ba['length']),_0x130758=_0x1191ba['substring'](0x0,Math['min'](_0x265744,_0x499280)),_0x265744<_0x499280&&(_0x5cfc21=kd(_0x1191ba['substring'](_0x265744,_0x499280)));const _0x4ffff9=Nd(_0x1191ba['substring'](Math['min'](_0x1191ba['length'],_0x499280)));_0x1807bd=_0x130758['indexOf'](':'),_0x1807bd>=0x0?(_0x29def7=_0x960322==='https'||_0x960322==='wss',_0xcf01e5=parseInt(_0x130758['substring'](_0x1807bd+0x1),0xa)):_0x1807bd=_0x130758['length'];const _0x34809c=_0x130758['slice'](0x0,_0x1807bd);if(_0x34809c['toLowerCase']()==='localhost')_0x1e7f9c='localhost';else{if(_0x34809c['split']('.')['length']<=0x2)_0x1e7f9c=_0x34809c;else{const _0x35560a=_0x130758['indexOf']('.');_0x13f7f4=_0x130758['substring'](0x0,_0x35560a)['toLowerCase'](),_0x1e7f9c=_0x130758['substring'](_0x35560a+0x1),_0x28e53a=_0x13f7f4;}}'ns'in _0x4ffff9&&(_0x28e53a=_0x4ffff9['ns']);}return{'host':_0x130758,'port':_0xcf01e5,'domain':_0x1e7f9c,'subdomain':_0x13f7f4,'secure':_0x29def7,'scheme':_0x960322,'pathString':_0x5cfc21,'namespace':_0x28e53a};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x21ce93=0x0;const _0x13008d=[];return function(_0x202c0e){const _0x523dfc=_0x202c0e===_0x21ce93;_0x21ce93=_0x202c0e;let _0x1d3354;const _0x1ffbf6=new Array(0x8);for(_0x1d3354=0x7;_0x1d3354>=0x0;_0x1d3354--)_0x1ffbf6[_0x1d3354]=mr['charAt'](_0x202c0e%0x40),_0x202c0e=Math['floor'](_0x202c0e/0x40);f(_0x202c0e===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1d6ec6=_0x1ffbf6['join']('');if(_0x523dfc){for(_0x1d3354=0xb;_0x1d3354>=0x0&&_0x13008d[_0x1d3354]===0x3f;_0x1d3354--)_0x13008d[_0x1d3354]=0x0;_0x13008d[_0x1d3354]++;}else{for(_0x1d3354=0x0;_0x1d3354<0xc;_0x1d3354++)_0x13008d[_0x1d3354]=Math['floor'](Math['random']()*0x40);}for(_0x1d3354=0x0;_0x1d3354<0xc;_0x1d3354++)_0x1d6ec6+=mr['charAt'](_0x13008d[_0x1d3354]);return f(_0x1d6ec6['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1d6ec6;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x4122ab,_0x5aa388,_0x2218d6,_0x1cbd33){this['eventType']=_0x4122ab,this['eventRegistration']=_0x5aa388,this['snapshot']=_0x2218d6,this['prevName']=_0x1cbd33;}['getPath'](){const _0x913879=this['snapshot']['ref'];return this['eventType']==='value'?_0x913879['_path']:_0x913879['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x450c17,_0x378639,_0xd6bf8e){this['eventRegistration']=_0x450c17,this['error']=_0x378639,this['path']=_0xd6bf8e;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x503658,_0x29c94e){this['snapshotCallback']=_0x503658,this['cancelCallback']=_0x29c94e;}['onValue'](_0x5b9306,_0x22f281){this['snapshotCallback']['call'](null,_0x5b9306,_0x22f281);}['onCancel'](_0x321485){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x321485);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x26140e){return this['snapshotCallback']===_0x26140e['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x26140e['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x26140e['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x2648ca,_0x468f6c,_0x4e0032,_0x2120f8){this['_repo']=_0x2648ca,this['_path']=_0x468f6c,this['_queryParams']=_0x4e0032,this['_orderByCalled']=_0x2120f8;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xd2eb1b=nr(this['_queryParams']),_0x10affe=Bi(_0xd2eb1b);return _0x10affe==='{}'?'default':_0x10affe;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x565744){if(_0x565744=k(_0x565744),!(_0x565744 instanceof be))return!0x1;const _0x2cfb8d=this['_repo']===_0x565744['_repo'],_0xb37da4=qi(this['_path'],_0x565744['_path']),_0x3b03ac=this['_queryIdentifier']===_0x565744['_queryIdentifier'];return _0x2cfb8d&&_0xb37da4&&_0x3b03ac;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x50c23d,_0x1aa498){if(_0x50c23d['_orderByCalled']===!0x0)throw new Error(_0x1aa498+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x3c1466){let _0x1d1d90=null,_0x771155=null;if(_0x3c1466['hasStart']()&&(_0x1d1d90=_0x3c1466['getIndexStartValue']()),_0x3c1466['hasEnd']()&&(_0x771155=_0x3c1466['getIndexEndValue']()),_0x3c1466['getIndex']()===ye){const _0xf6611='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x49778a='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3c1466['hasStart']()){if(_0x3c1466['getIndexStartName']()!==xe)throw new Error(_0xf6611);if(typeof _0x1d1d90!='string')throw new Error(_0x49778a);}if(_0x3c1466['hasEnd']()){if(_0x3c1466['getIndexEndName']()!==Ie)throw new Error(_0xf6611);if(typeof _0x771155!='string')throw new Error(_0x49778a);}}else{if(_0x3c1466['getIndex']()===R){if(_0x1d1d90!=null&&!Cn(_0x1d1d90)||_0x771155!=null&&!Cn(_0x771155))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3c1466['getIndex']()instanceof Ki||_0x3c1466['getIndex']()===Po,'unknown\x20index\x20type.'),_0x1d1d90!=null&&typeof _0x1d1d90=='object'||_0x771155!=null&&typeof _0x771155=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x5248d8){if(_0x5248d8['hasStart']()&&_0x5248d8['hasEnd']()&&_0x5248d8['hasLimit']()&&!_0x5248d8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2eeda8,_0x33c55e){super(_0x2eeda8,_0x33c55e,new Qi(),!0x1);}get['parent'](){const _0x327bd5=To(this['_path']);return _0x327bd5===null?null:new Z(this['_repo'],_0x327bd5);}get['root'](){let _0x5eb14f=this;for(;_0x5eb14f['parent']!==null;)_0x5eb14f=_0x5eb14f['parent'];return _0x5eb14f;}}class rt{constructor(_0x172dc3,_0x1da62a,_0x23768b){this['_node']=_0x172dc3,this['ref']=_0x1da62a,this['_index']=_0x23768b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3f3535){const _0x390bb3=new C(_0x3f3535),_0x5717c2=Lt(this['ref'],_0x3f3535);return new rt(this['_node']['getChild'](_0x390bb3),_0x5717c2,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x337376){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x253048,_0x56c12c)=>_0x337376(new rt(_0x56c12c,Lt(this['ref'],_0x253048),R)));}['hasChild'](_0x4c5721){const _0x718804=new C(_0x4c5721);return!this['_node']['getChild'](_0x718804)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x17a2fa,_0x143ea9){return _0x17a2fa=k(_0x17a2fa),_0x17a2fa['_checkNotDeleted']('ref'),_0x143ea9!==void 0x0?Lt(_0x17a2fa['_root'],_0x143ea9):_0x17a2fa['_root'];}function Lt(_0x2e5120,_0x2debcb){return _0x2e5120=k(_0x2e5120),y(_0x2e5120['_path'])===null?ud('child','path',_0x2debcb):_s('child','path',_0x2debcb),new Z(_0x2e5120['_repo'],A(_0x2e5120['_path'],_0x2debcb));}function d_(_0x487b61,_0x4512d8){_0x487b61=k(_0x487b61),gs('push',_0x487b61['_path']),qt('push',_0x4512d8,_0x487b61['_path'],!0x0);const _0x595d59=oa(_0x487b61['_repo']),_0x15f9a8=Od(_0x595d59),_0x3f58a6=Lt(_0x487b61,_0x15f9a8),_0x225a6e=Lt(_0x487b61,_0x15f9a8);let _0x526bcc;return _0x4512d8!=null?_0x526bcc=Ld(_0x225a6e,_0x4512d8)['then'](()=>_0x225a6e):_0x526bcc=Promise['resolve'](_0x225a6e),_0x3f58a6['then']=_0x526bcc['then']['bind'](_0x526bcc),_0x3f58a6['catch']=_0x526bcc['then']['bind'](_0x526bcc,void 0x0),_0x3f58a6;}function Ld(_0x2cc193,_0x172223){_0x2cc193=k(_0x2cc193),gs('set',_0x2cc193['_path']),qt('set',_0x172223,_0x2cc193['_path'],!0x1);const _0x9ab3a6=new Ve();return Ed(_0x2cc193['_repo'],_0x2cc193['_path'],_0x172223,null,_0x9ab3a6['wrapCallback'](()=>{})),_0x9ab3a6['promise'];}function f_(_0x10ebb0,_0x47bafe){hd('update',_0x47bafe,_0x10ebb0['_path']);const _0x49bc2d=new Ve();return Id(_0x10ebb0['_repo'],_0x10ebb0['_path'],_0x47bafe,_0x49bc2d['wrapCallback'](()=>{})),_0x49bc2d['promise'];}function p_(_0x46ea7e){_0x46ea7e=k(_0x46ea7e);const _0x2cd202=new ua(()=>{}),_0x5f3ef8=new qn(_0x2cd202);return vd(_0x46ea7e['_repo'],_0x46ea7e,_0x5f3ef8)['then'](_0x2ec0bd=>new rt(_0x2ec0bd,new Z(_0x46ea7e['_repo'],_0x46ea7e['_path']),_0x46ea7e['_queryParams']['getIndex']()));}class qn{constructor(_0x23a342){this['callbackContext']=_0x23a342;}['respondsTo'](_0x1a9c09){return _0x1a9c09==='value';}['createEvent'](_0x426ea2,_0x1d7621){const _0xdb333=_0x1d7621['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x426ea2['snapshotNode'],new Z(_0x1d7621['_repo'],_0x1d7621['_path']),_0xdb333));}['getEventRunner'](_0x47b972){return _0x47b972['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x47b972['error']):()=>this['callbackContext']['onValue'](_0x47b972['snapshot'],null);}['createCancelEvent'](_0x2944e7,_0x379612){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x2944e7,_0x379612):null;}['matches'](_0x41d4b4){return _0x41d4b4 instanceof qn?!_0x41d4b4['callbackContext']||!this['callbackContext']?!0x0:_0x41d4b4['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x59edf3,_0x466142,_0x47bdd1,_0x56af7f,_0x36fc57){const _0xeef30b=new ua(_0x47bdd1,void 0x0),_0x490c11=new qn(_0xeef30b);return Cd(_0x59edf3['_repo'],_0x59edf3,_0x490c11),()=>Td(_0x59edf3['_repo'],_0x59edf3,_0x490c11);}function Fd(_0x342c20,_0x3cf76b,_0x44ac5a,_0x60850c){return xd(_0x342c20,'value',_0x3cf76b);}class dt{}class pa extends dt{constructor(_0x95142a,_0x25b325){super(),this['_value']=_0x95142a,this['_key']=_0x25b325,this['type']='endAt';}['_apply'](_0x45fb5a){qt('endAt',this['_value'],_0x45fb5a['_path'],!0x0);const _0x3ab334=Kh(_0x45fb5a['_queryParams'],this['_value'],this['_key']);if(fa(_0x3ab334),Gn(_0x3ab334),_0x45fb5a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x45fb5a['_repo'],_0x45fb5a['_path'],_0x3ab334,_0x45fb5a['_orderByCalled']);}}function __(_0x523187,_0x484a61){return new pa(_0x523187,_0x484a61);}class _a extends dt{constructor(_0x322478,_0x5408e6){super(),this['_value']=_0x322478,this['_key']=_0x5408e6,this['type']='startAt';}['_apply'](_0x2ea0ff){qt('startAt',this['_value'],_0x2ea0ff['_path'],!0x0);const _0x23d0e3=jh(_0x2ea0ff['_queryParams'],this['_value'],this['_key']);if(fa(_0x23d0e3),Gn(_0x23d0e3),_0x2ea0ff['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2ea0ff['_repo'],_0x2ea0ff['_path'],_0x23d0e3,_0x2ea0ff['_orderByCalled']);}}function g_(_0x3f3d6f=null,_0x493491){return new _a(_0x3f3d6f,_0x493491);}class Ud extends dt{constructor(_0x1fd569){super(),this['_limit']=_0x1fd569,this['type']='limitToFirst';}['_apply'](_0x3cc0ec){if(_0x3cc0ec['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3cc0ec['_repo'],_0x3cc0ec['_path'],zh(_0x3cc0ec['_queryParams'],this['_limit']),_0x3cc0ec['_orderByCalled']);}}function m_(_0x175522){if(Math['floor'](_0x175522)!==_0x175522||_0x175522<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x175522);}class Wd extends dt{constructor(_0x1ae0e3){super(),this['_path']=_0x1ae0e3,this['type']='orderByChild';}['_apply'](_0x343100){da(_0x343100,'orderByChild');const _0x26c241=new C(this['_path']);if(v(_0x26c241))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x50dc58=new Ki(_0x26c241),_0x96317b=Do(_0x343100['_queryParams'],_0x50dc58);return Gn(_0x96317b),new be(_0x343100['_repo'],_0x343100['_path'],_0x96317b,!0x0);}}function y_(_0x42f39a){if(_0x42f39a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x42f39a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x42f39a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x42f39a),new Wd(_0x42f39a);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x450ebe){da(_0x450ebe,'orderByKey');const _0x438c0e=Do(_0x450ebe['_queryParams'],ye);return Gn(_0x438c0e),new be(_0x450ebe['_repo'],_0x450ebe['_path'],_0x438c0e,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x306106,_0x23adfa){super(),this['_value']=_0x306106,this['_key']=_0x23adfa,this['type']='equalTo';}['_apply'](_0x5c97aa){if(qt('equalTo',this['_value'],_0x5c97aa['_path'],!0x1),_0x5c97aa['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5c97aa['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x5c97aa));}}function E_(_0xc7faf6,_0x367ed0){return new Vd(_0xc7faf6,_0x367ed0);}function I_(_0x209afe,..._0x4abc2d){let _0x31bdbb=k(_0x209afe);for(const _0x5d469f of _0x4abc2d)_0x31bdbb=_0x5d469f['_apply'](_0x31bdbb);return _0x31bdbb;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x5b3d3f,_0x1dfb2d,_0x2b984c,_0x47e12d){const _0x18f734=_0x1dfb2d['lastIndexOf'](':'),_0x486fb3=_0x1dfb2d['substring'](0x0,_0x18f734),_0x1e6fc0=Wt(_0x486fb3);_0x5b3d3f['repoInfo_']=new _o(_0x1dfb2d,_0x1e6fc0,_0x5b3d3f['repoInfo_']['namespace'],_0x5b3d3f['repoInfo_']['webSocketOnly'],_0x5b3d3f['repoInfo_']['nodeAdmin'],_0x5b3d3f['repoInfo_']['persistenceKey'],_0x5b3d3f['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2b984c),_0x47e12d&&(_0x5b3d3f['authTokenProvider_']=_0x47e12d);}function qd(_0x56a1e1,_0x2cab25,_0x32839f,_0x14e114,_0x26e760){let _0x237b26=_0x14e114||_0x56a1e1['options']['databaseURL'];_0x237b26===void 0x0&&(_0x56a1e1['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x56a1e1['options']['projectId']),_0x237b26=_0x56a1e1['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x3333cb=gr(_0x237b26,_0x26e760),_0x249f96=_0x3333cb['repoInfo'],_0x1bb200;typeof process<'u'&&Us&&(_0x1bb200=Us[Hd]),_0x1bb200?(_0x237b26='http://'+_0x1bb200+'?ns='+_0x249f96['namespace'],_0x3333cb=gr(_0x237b26,_0x26e760),_0x249f96=_0x3333cb['repoInfo']):_0x3333cb['repoInfo']['secure'];const _0xd644f4=new Jl(_0x56a1e1['name'],_0x56a1e1['options'],_0x2cab25);dd('Invalid\x20Firebase\x20Database\x20URL',_0x3333cb),v(_0x3333cb['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x562e53=jd(_0x249f96,_0x56a1e1,_0xd644f4,new Ql(_0x56a1e1,_0x32839f));return new Kd(_0x562e53,_0x56a1e1);}function zd(_0x11a038,_0x5cb974){const _0x55925c=ki[_0x5cb974];(!_0x55925c||_0x55925c[_0x11a038['key']]!==_0x11a038)&&oe('Database\x20'+_0x5cb974+'('+_0x11a038['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x11a038),delete _0x55925c[_0x11a038['key']];}function jd(_0x36c858,_0x13ad4f,_0x14f8d6,_0x19f50b){let _0x5606c3=ki[_0x13ad4f['name']];_0x5606c3||(_0x5606c3={},ki[_0x13ad4f['name']]=_0x5606c3);let _0x6905d0=_0x5606c3[_0x36c858['toURLString']()];return _0x6905d0&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x6905d0=new gd(_0x36c858,$d,_0x14f8d6,_0x19f50b),_0x5606c3[_0x36c858['toURLString']()]=_0x6905d0,_0x6905d0;}class Kd{constructor(_0x462a7d,_0x3116fb){this['_repoInternal']=_0x462a7d,this['app']=_0x3116fb,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x180560){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x180560+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1be86c=Qr(),_0x1d78b2){const _0x178f26=Ui(_0x1be86c,'database')['getImmediate']({'identifier':_0x1d78b2});if(!_0x178f26['_instanceStarted']){const _0x4de5f8=ac('database');_0x4de5f8&&Yd(_0x178f26,..._0x4de5f8);}return _0x178f26;}function Yd(_0x59f7ec,_0x5a8e69,_0x5ddde4,_0x5c6b7e={}){_0x59f7ec=k(_0x59f7ec),_0x59f7ec['_checkNotDeleted']('useEmulator');const _0x4383de=_0x5a8e69+':'+_0x5ddde4,_0x252f7c=_0x59f7ec['_repoInternal'];if(_0x59f7ec['_instanceStarted']){if(_0x4383de===_0x59f7ec['_repoInternal']['repoInfo_']['host']&&De(_0x5c6b7e,_0x252f7c['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x282c89;if(_0x252f7c['repoInfo_']['nodeAdmin'])_0x5c6b7e['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x282c89=new tn(tn['OWNER']);else{if(_0x5c6b7e['mockUserToken']){const _0x2bc915=typeof _0x5c6b7e['mockUserToken']=='string'?_0x5c6b7e['mockUserToken']:cc(_0x5c6b7e['mockUserToken'],_0x59f7ec['app']['options']['projectId']);_0x282c89=new tn(_0x2bc915);}}Wt(_0x5a8e69)&&jr(_0x5a8e69),Gd(_0x252f7c,_0x4383de,_0x5c6b7e,_0x282c89);}function C_(_0x248ee3){_0x248ee3=k(_0x248ee3),_0x248ee3['_checkNotDeleted']('goOffline'),aa(_0x248ee3['_repo']);}function T_(_0xff3951){_0xff3951=k(_0xff3951),_0xff3951['_checkNotDeleted']('goOnline'),Sd(_0xff3951['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x26075c){Ll(ct),et(new Me('database',(_0x1b7c1d,{instanceIdentifier:_0x397c0d})=>{const _0x206f34=_0x1b7c1d['getProvider']('app')['getImmediate'](),_0x47b514=_0x1b7c1d['getProvider']('auth-internal'),_0x5e8422=_0x1b7c1d['getProvider']('app-check-internal');return qd(_0x206f34,_0x47b514,_0x5e8422,_0x397c0d);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x26075c),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x5d9498,_0x570310){this['committed']=_0x5d9498,this['snapshot']=_0x570310;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x54038a,_0x341853,_0x1b83f7){if(_0x54038a=k(_0x54038a),gs('Reference.transaction',_0x54038a['_path']),_0x54038a['key']==='.length'||_0x54038a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x54038a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x39238d=!0x0,_0x3c1021=new Ve(),_0x1c7ea1=(_0x5e91a4,_0x1d7208,_0xaf8bc1)=>{let _0x34b4a3=null;_0x5e91a4?_0x3c1021['reject'](_0x5e91a4):(_0x34b4a3=new rt(_0xaf8bc1,new Z(_0x54038a['_repo'],_0x54038a['_path']),R),_0x3c1021['resolve'](new Xd(_0x1d7208,_0x34b4a3)));},_0x4c2cbf=Fd(_0x54038a,()=>{});return bd(_0x54038a['_repo'],_0x54038a['_path'],_0x341853,_0x1c7ea1,_0x4c2cbf,_0x39238d),_0x3c1021['promise'];}ie['prototype']['simpleListen']=function(_0x7802c3,_0x5e6b11){this['sendRequest']('q',{'p':_0x7802c3},_0x5e6b11);},ie['prototype']['echo']=function(_0x44155d,_0x233992){this['sendRequest']('echo',{'d':_0x44155d},_0x233992);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x201bd3,..._0x4dd9ad){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x201bd3,..._0x4dd9ad);}function nn(_0x558bac,..._0x326ca1){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x558bac,..._0x326ca1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3c8e54,..._0x81d60c){throw Es(_0x3c8e54,..._0x81d60c);}function J(_0x17aa37,..._0x4d6633){return Es(_0x17aa37,..._0x4d6633);}function ya(_0x2a7222,_0x591d9d,_0x4a70f9){const _0x1db413={...Zd(),[_0x591d9d]:_0x4a70f9};return new Ut('auth','Firebase',_0x1db413)['create'](_0x591d9d,{'appName':_0x2a7222['name']});}function se(_0x203890){return ya(_0x203890,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5d7537,..._0x46f32b){if(typeof _0x5d7537!='string'){const _0x39a853=_0x46f32b[0x0],_0x4f671f=[..._0x46f32b['slice'](0x1)];return _0x4f671f[0x0]&&(_0x4f671f[0x0]['appName']=_0x5d7537['name']),_0x5d7537['_errorFactory']['create'](_0x39a853,..._0x4f671f);}return ma['create'](_0x5d7537,..._0x46f32b);}function m(_0x5af483,_0x4807db,..._0x509d67){if(!_0x5af483)throw Es(_0x4807db,..._0x509d67);}function te(_0x374000){const _0x4ec662='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x374000;throw nn(_0x4ec662),new Error(_0x4ec662);}function ae(_0x5537e2,_0x82c216){_0x5537e2||te(_0x82c216);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x422deb;return typeof self<'u'&&((_0x422deb=self['location'])==null?void 0x0:_0x422deb['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x531ba2;return typeof self<'u'&&((_0x531ba2=self['location'])==null?void 0x0:_0x531ba2['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x595748=navigator;return _0x595748['languages']&&_0x595748['languages'][0x0]||_0x595748['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x4b4deb,_0x1d12ae){this['shortDelay']=_0x4b4deb,this['longDelay']=_0x1d12ae,ae(_0x1d12ae>_0x4b4deb,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x306b19,_0x17cab9){ae(_0x306b19['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x14edbb}=_0x306b19['emulator'];return _0x17cab9?''+_0x14edbb+(_0x17cab9['startsWith']('/')?_0x17cab9['slice'](0x1):_0x17cab9):_0x14edbb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1a63da,_0x5663da,_0x433531){this['fetchImpl']=_0x1a63da,_0x5663da&&(this['headersImpl']=_0x5663da),_0x433531&&(this['responseImpl']=_0x433531);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x54d7ff,_0x2ef7a0){return _0x54d7ff['tenantId']&&!_0x2ef7a0['tenantId']?{..._0x2ef7a0,'tenantId':_0x54d7ff['tenantId']}:_0x2ef7a0;}async function Ae(_0x3d78cf,_0xa40911,_0x26a6eb,_0x313402,_0x465975={}){return Ea(_0x3d78cf,_0x465975,async()=>{let _0x1e4969={},_0x4c48b7={};_0x313402&&(_0xa40911==='GET'?_0x4c48b7=_0x313402:_0x1e4969={'body':JSON['stringify'](_0x313402)});const _0x2a1738=at({..._0x4c48b7,'key':_0x3d78cf['config']['apiKey']})['slice'](0x1),_0x2aa05d=await _0x3d78cf['_getAdditionalHeaders']();_0x2aa05d['Content-Type']='application/json',_0x3d78cf['languageCode']&&(_0x2aa05d['X-Firebase-Locale']=_0x3d78cf['languageCode']);const _0x5309b9={'method':_0xa40911,'headers':_0x2aa05d,..._0x1e4969};return lc()||(_0x5309b9['referrerPolicy']='strict-origin-when-cross-origin'),_0x3d78cf['emulatorConfig']&&Wt(_0x3d78cf['emulatorConfig']['host'])&&(_0x5309b9['credentials']='include'),va['fetch']()(await Ia(_0x3d78cf,_0x3d78cf['config']['apiHost'],_0x26a6eb,_0x2a1738),_0x5309b9);});}async function Ea(_0x205022,_0x141455,_0x202876){_0x205022['_canInitEmulator']=!0x1;const _0x518c14={...rf,..._0x141455};try{const _0x42085d=new lf(_0x205022),_0x37b36e=await Promise['race']([_0x202876(),_0x42085d['promise']]);_0x42085d['clearNetworkTimeout']();const _0x102ee5=await _0x37b36e['json']();if('needConfirmation'in _0x102ee5)throw en(_0x205022,'account-exists-with-different-credential',_0x102ee5);if(_0x37b36e['ok']&&!('errorMessage'in _0x102ee5))return _0x102ee5;{const _0x25462f=_0x37b36e['ok']?_0x102ee5['errorMessage']:_0x102ee5['error']['message'],[_0x1b78c6,_0x2df5ee]=_0x25462f['split']('\x20:\x20');if(_0x1b78c6==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x205022,'credential-already-in-use',_0x102ee5);if(_0x1b78c6==='EMAIL_EXISTS')throw en(_0x205022,'email-already-in-use',_0x102ee5);if(_0x1b78c6==='USER_DISABLED')throw en(_0x205022,'user-disabled',_0x102ee5);const _0x14d65d=_0x518c14[_0x1b78c6]||_0x1b78c6['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2df5ee)throw ya(_0x205022,_0x14d65d,_0x2df5ee);K(_0x205022,_0x14d65d);}}catch(_0x1cc2d2){if(_0x1cc2d2 instanceof Se)throw _0x1cc2d2;K(_0x205022,'network-request-failed',{'message':String(_0x1cc2d2)});}}async function Yt(_0x590c3c,_0x23763a,_0x323e20,_0x56a6e2,_0x131a93={}){const _0x597c6b=await Ae(_0x590c3c,_0x23763a,_0x323e20,_0x56a6e2,_0x131a93);return'mfaPendingCredential'in _0x597c6b&&K(_0x590c3c,'multi-factor-auth-required',{'_serverResponse':_0x597c6b}),_0x597c6b;}async function Ia(_0x18d41e,_0x16644d,_0x358840,_0x5ae542){const _0x2f0e8a=''+_0x16644d+_0x358840+'?'+_0x5ae542,_0x316d55=_0x18d41e,_0x327f09=_0x316d55['config']['emulator']?Is(_0x18d41e['config'],_0x2f0e8a):_0x18d41e['config']['apiScheme']+'://'+_0x2f0e8a;return of['includes'](_0x358840)&&(await _0x316d55['_persistenceManagerAvailable'],_0x316d55['_getPersistenceType']()==='COOKIE')?_0x316d55['_getPersistence']()['_getFinalTarget'](_0x327f09)['toString']():_0x327f09;}function cf(_0x16f31c){switch(_0x16f31c){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x456904){this['auth']=_0x456904,this['timer']=null,this['promise']=new Promise((_0x48ce41,_0x44e1e5)=>{this['timer']=setTimeout(()=>_0x44e1e5(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x4aaab6,_0x67805,_0x4dc7a4){const _0x5a44f8={'appName':_0x4aaab6['name']};_0x4dc7a4['email']&&(_0x5a44f8['email']=_0x4dc7a4['email']),_0x4dc7a4['phoneNumber']&&(_0x5a44f8['phoneNumber']=_0x4dc7a4['phoneNumber']);const _0x2cfb01=J(_0x4aaab6,_0x67805,_0x5a44f8);return _0x2cfb01['customData']['_tokenResponse']=_0x4dc7a4,_0x2cfb01;}function vr(_0x3a3a86){return _0x3a3a86!==void 0x0&&_0x3a3a86['enterprise']!==void 0x0;}class hf{constructor(_0x594b12){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x594b12['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x594b12['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x594b12['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x288173){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3b542e of this['recaptchaEnforcementState'])if(_0x3b542e['provider']&&_0x3b542e['provider']===_0x288173)return cf(_0x3b542e['enforcementState']);return null;}['isProviderEnabled'](_0x4c4156){return this['getProviderEnforcementState'](_0x4c4156)==='ENFORCE'||this['getProviderEnforcementState'](_0x4c4156)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x3f3ea6,_0x2a9201){return Ae(_0x3f3ea6,'GET','/v2/recaptchaConfig',Re(_0x3f3ea6,_0x2a9201));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x2a062d,_0x1ca6e3){return Ae(_0x2a062d,'POST','/v1/accounts:delete',_0x1ca6e3);}async function Sn(_0x46338e,_0x1945ae){return Ae(_0x46338e,'POST','/v1/accounts:lookup',_0x1945ae);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x187578){if(_0x187578)try{const _0x415009=new Date(Number(_0x187578));if(!isNaN(_0x415009['getTime']()))return _0x415009['toUTCString']();}catch{}}async function ff(_0x100b83,_0x442064=!0x1){const _0x1c71ba=k(_0x100b83),_0x7b4b72=await _0x1c71ba['getIdToken'](_0x442064),_0x58f5ae=ws(_0x7b4b72);m(_0x58f5ae&&_0x58f5ae['exp']&&_0x58f5ae['auth_time']&&_0x58f5ae['iat'],_0x1c71ba['auth'],'internal-error');const _0x3c7bf0=typeof _0x58f5ae['firebase']=='object'?_0x58f5ae['firebase']:void 0x0,_0x3da81a=_0x3c7bf0==null?void 0x0:_0x3c7bf0['sign_in_provider'];return{'claims':_0x58f5ae,'token':_0x7b4b72,'authTime':St(ci(_0x58f5ae['auth_time'])),'issuedAtTime':St(ci(_0x58f5ae['iat'])),'expirationTime':St(ci(_0x58f5ae['exp'])),'signInProvider':_0x3da81a||null,'signInSecondFactor':(_0x3c7bf0==null?void 0x0:_0x3c7bf0['sign_in_second_factor'])||null};}function ci(_0x46ca9f){return Number(_0x46ca9f)*0x3e8;}function ws(_0x21c82d){const [_0x28acf8,_0x34bdd5,_0x4dff66]=_0x21c82d['split']('.');if(_0x28acf8===void 0x0||_0x34bdd5===void 0x0||_0x4dff66===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2817f9=cn(_0x34bdd5);return _0x2817f9?JSON['parse'](_0x2817f9):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x44399d){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x44399d==null?void 0x0:_0x44399d['toString']()),null;}}function Er(_0x43839a){const _0x5a3e45=ws(_0x43839a);return m(_0x5a3e45,'internal-error'),m(typeof _0x5a3e45['exp']<'u','internal-error'),m(typeof _0x5a3e45['iat']<'u','internal-error'),Number(_0x5a3e45['exp'])-Number(_0x5a3e45['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x2bb196,_0xf012eb,_0x10be58=!0x1){if(_0x10be58)return _0xf012eb;try{return await _0xf012eb;}catch(_0x6fa834){throw _0x6fa834 instanceof Se&&pf(_0x6fa834)&&_0x2bb196['auth']['currentUser']===_0x2bb196&&await _0x2bb196['auth']['signOut'](),_0x6fa834;}}function pf({code:_0x58031f}){return _0x58031f==='auth/user-disabled'||_0x58031f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x8b88be){this['user']=_0x8b88be,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1ea7a9){if(_0x1ea7a9){const _0x345ee5=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x345ee5;}else{this['errorBackoff']=0x7530;const _0x12d053=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x12d053);}}['schedule'](_0x1f87dc=!0x1){if(!this['isRunning'])return;const _0x1aee9c=this['getInterval'](_0x1f87dc);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1aee9c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4473af){(_0x4473af==null?void 0x0:_0x4473af['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x19699c,_0x446470){this['createdAt']=_0x19699c,this['lastLoginAt']=_0x446470,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x294716){this['createdAt']=_0x294716['createdAt'],this['lastLoginAt']=_0x294716['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x15f5bc){var _0x1cbce8;const _0x1625b1=_0x15f5bc['auth'],_0x58f8f2=await _0x15f5bc['getIdToken'](),_0x5140fa=await xt(_0x15f5bc,Sn(_0x1625b1,{'idToken':_0x58f8f2}));m(_0x5140fa==null?void 0x0:_0x5140fa['users']['length'],_0x1625b1,'internal-error');const _0x56eaf8=_0x5140fa['users'][0x0];_0x15f5bc['_notifyReloadListener'](_0x56eaf8);const _0x3a726c=(_0x1cbce8=_0x56eaf8['providerUserInfo'])!=null&&_0x1cbce8['length']?wa(_0x56eaf8['providerUserInfo']):[],_0x4dbb63=mf(_0x15f5bc['providerData'],_0x3a726c),_0xe0c9a3=_0x15f5bc['isAnonymous'],_0x5e9e06=!(_0x15f5bc['email']&&_0x56eaf8['passwordHash'])&&!(_0x4dbb63!=null&&_0x4dbb63['length']),_0x884a21=_0xe0c9a3?_0x5e9e06:!0x1,_0x119212={'uid':_0x56eaf8['localId'],'displayName':_0x56eaf8['displayName']||null,'photoURL':_0x56eaf8['photoUrl']||null,'email':_0x56eaf8['email']||null,'emailVerified':_0x56eaf8['emailVerified']||!0x1,'phoneNumber':_0x56eaf8['phoneNumber']||null,'tenantId':_0x56eaf8['tenantId']||null,'providerData':_0x4dbb63,'metadata':new Pi(_0x56eaf8['createdAt'],_0x56eaf8['lastLoginAt']),'isAnonymous':_0x884a21};Object['assign'](_0x15f5bc,_0x119212);}async function gf(_0x3f3777){const _0x21e1f3=k(_0x3f3777);await bn(_0x21e1f3),await _0x21e1f3['auth']['_persistUserIfCurrent'](_0x21e1f3),_0x21e1f3['auth']['_notifyListenersIfCurrent'](_0x21e1f3);}function mf(_0x4e584d,_0x147979){return[..._0x4e584d['filter'](_0x25b483=>!_0x147979['some'](_0x2c7e08=>_0x2c7e08['providerId']===_0x25b483['providerId'])),..._0x147979];}function wa(_0x2c31b3){return _0x2c31b3['map'](({providerId:_0x333a0c,..._0xa2f86f})=>({'providerId':_0x333a0c,'uid':_0xa2f86f['rawId']||'','displayName':_0xa2f86f['displayName']||null,'email':_0xa2f86f['email']||null,'phoneNumber':_0xa2f86f['phoneNumber']||null,'photoURL':_0xa2f86f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0xff86a6,_0x1196d9){const _0x5e9876=await Ea(_0xff86a6,{},async()=>{const _0x1b7bd8=at({'grant_type':'refresh_token','refresh_token':_0x1196d9})['slice'](0x1),{tokenApiHost:_0xdf6563,apiKey:_0x557df9}=_0xff86a6['config'],_0x4fc7c4=await Ia(_0xff86a6,_0xdf6563,'/v1/token','key='+_0x557df9),_0x1774fe=await _0xff86a6['_getAdditionalHeaders']();_0x1774fe['Content-Type']='application/x-www-form-urlencoded';const _0x5a9d72={'method':'POST','headers':_0x1774fe,'body':_0x1b7bd8};return _0xff86a6['emulatorConfig']&&Wt(_0xff86a6['emulatorConfig']['host'])&&(_0x5a9d72['credentials']='include'),va['fetch']()(_0x4fc7c4,_0x5a9d72);});return{'accessToken':_0x5e9876['access_token'],'expiresIn':_0x5e9876['expires_in'],'refreshToken':_0x5e9876['refresh_token']};}async function vf(_0x764717,_0x1dc57e){return Ae(_0x764717,'POST','/v2/accounts:revokeToken',Re(_0x764717,_0x1dc57e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5b09b2){m(_0x5b09b2['idToken'],'internal-error'),m(typeof _0x5b09b2['idToken']<'u','internal-error'),m(typeof _0x5b09b2['refreshToken']<'u','internal-error');const _0x58348c='expiresIn'in _0x5b09b2&&typeof _0x5b09b2['expiresIn']<'u'?Number(_0x5b09b2['expiresIn']):Er(_0x5b09b2['idToken']);this['updateTokensAndExpiration'](_0x5b09b2['idToken'],_0x5b09b2['refreshToken'],_0x58348c);}['updateFromIdToken'](_0x16f14a){m(_0x16f14a['length']!==0x0,'internal-error');const _0x5e38d9=Er(_0x16f14a);this['updateTokensAndExpiration'](_0x16f14a,null,_0x5e38d9);}async['getToken'](_0x19674b,_0x535ea7=!0x1){return!_0x535ea7&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x19674b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x19674b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x21235b,_0x1ccc8b){const {accessToken:_0x5e6b92,refreshToken:_0x6a943b,expiresIn:_0x43f7f2}=await yf(_0x21235b,_0x1ccc8b);this['updateTokensAndExpiration'](_0x5e6b92,_0x6a943b,Number(_0x43f7f2));}['updateTokensAndExpiration'](_0xef432c,_0x49c704,_0x4e6fc6){this['refreshToken']=_0x49c704||null,this['accessToken']=_0xef432c||null,this['expirationTime']=Date['now']()+_0x4e6fc6*0x3e8;}static['fromJSON'](_0x21bca8,_0x3ee529){const {refreshToken:_0x57f3e2,accessToken:_0x4a985d,expirationTime:_0x26ed87}=_0x3ee529,_0x36f21c=new Je();return _0x57f3e2&&(m(typeof _0x57f3e2=='string','internal-error',{'appName':_0x21bca8}),_0x36f21c['refreshToken']=_0x57f3e2),_0x4a985d&&(m(typeof _0x4a985d=='string','internal-error',{'appName':_0x21bca8}),_0x36f21c['accessToken']=_0x4a985d),_0x26ed87&&(m(typeof _0x26ed87=='number','internal-error',{'appName':_0x21bca8}),_0x36f21c['expirationTime']=_0x26ed87),_0x36f21c;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4fb27b){this['accessToken']=_0x4fb27b['accessToken'],this['refreshToken']=_0x4fb27b['refreshToken'],this['expirationTime']=_0x4fb27b['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x5a9315,_0x5782ba){m(typeof _0x5a9315=='string'||typeof _0x5a9315>'u','internal-error',{'appName':_0x5782ba});}class z{constructor({uid:_0x328671,auth:_0x117635,stsTokenManager:_0x3e0a39,..._0x39a8e1}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x328671,this['auth']=_0x117635,this['stsTokenManager']=_0x3e0a39,this['accessToken']=_0x3e0a39['accessToken'],this['displayName']=_0x39a8e1['displayName']||null,this['email']=_0x39a8e1['email']||null,this['emailVerified']=_0x39a8e1['emailVerified']||!0x1,this['phoneNumber']=_0x39a8e1['phoneNumber']||null,this['photoURL']=_0x39a8e1['photoURL']||null,this['isAnonymous']=_0x39a8e1['isAnonymous']||!0x1,this['tenantId']=_0x39a8e1['tenantId']||null,this['providerData']=_0x39a8e1['providerData']?[..._0x39a8e1['providerData']]:[],this['metadata']=new Pi(_0x39a8e1['createdAt']||void 0x0,_0x39a8e1['lastLoginAt']||void 0x0);}async['getIdToken'](_0x403bef){const _0x3af44c=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x403bef));return m(_0x3af44c,this['auth'],'internal-error'),this['accessToken']!==_0x3af44c&&(this['accessToken']=_0x3af44c,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3af44c;}['getIdTokenResult'](_0x55dab7){return ff(this,_0x55dab7);}['reload'](){return gf(this);}['_assign'](_0xf43394){this!==_0xf43394&&(m(this['uid']===_0xf43394['uid'],this['auth'],'internal-error'),this['displayName']=_0xf43394['displayName'],this['photoURL']=_0xf43394['photoURL'],this['email']=_0xf43394['email'],this['emailVerified']=_0xf43394['emailVerified'],this['phoneNumber']=_0xf43394['phoneNumber'],this['isAnonymous']=_0xf43394['isAnonymous'],this['tenantId']=_0xf43394['tenantId'],this['providerData']=_0xf43394['providerData']['map'](_0x3ba085=>({..._0x3ba085})),this['metadata']['_copy'](_0xf43394['metadata']),this['stsTokenManager']['_assign'](_0xf43394['stsTokenManager']));}['_clone'](_0x26ce6f){const _0x435d6d=new z({...this,'auth':_0x26ce6f,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x435d6d['metadata']['_copy'](this['metadata']),_0x435d6d;}['_onReload'](_0x9253e8){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x9253e8,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2c19a2){this['reloadListener']?this['reloadListener'](_0x2c19a2):this['reloadUserInfo']=_0x2c19a2;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2e6539,_0x2d7728=!0x1){let _0x48136c=!0x1;_0x2e6539['idToken']&&_0x2e6539['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2e6539),_0x48136c=!0x0),_0x2d7728&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x48136c&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x3812ae=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x3812ae})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2da583=>({..._0x2da583})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2f0d83,_0x27296d){const _0x300909=_0x27296d['displayName']??void 0x0,_0x48eeda=_0x27296d['email']??void 0x0,_0x2a6629=_0x27296d['phoneNumber']??void 0x0,_0x535537=_0x27296d['photoURL']??void 0x0,_0x1125eb=_0x27296d['tenantId']??void 0x0,_0x509a11=_0x27296d['_redirectEventId']??void 0x0,_0x45951e=_0x27296d['createdAt']??void 0x0,_0x30be75=_0x27296d['lastLoginAt']??void 0x0,{uid:_0x40bcef,emailVerified:_0x95c205,isAnonymous:_0x1e6a8e,providerData:_0x32b4f1,stsTokenManager:_0x43a843}=_0x27296d;m(_0x40bcef&&_0x43a843,_0x2f0d83,'internal-error');const _0x25f8a4=Je['fromJSON'](this['name'],_0x43a843);m(typeof _0x40bcef=='string',_0x2f0d83,'internal-error'),ce(_0x300909,_0x2f0d83['name']),ce(_0x48eeda,_0x2f0d83['name']),m(typeof _0x95c205=='boolean',_0x2f0d83,'internal-error'),m(typeof _0x1e6a8e=='boolean',_0x2f0d83,'internal-error'),ce(_0x2a6629,_0x2f0d83['name']),ce(_0x535537,_0x2f0d83['name']),ce(_0x1125eb,_0x2f0d83['name']),ce(_0x509a11,_0x2f0d83['name']),ce(_0x45951e,_0x2f0d83['name']),ce(_0x30be75,_0x2f0d83['name']);const _0x1c0022=new z({'uid':_0x40bcef,'auth':_0x2f0d83,'email':_0x48eeda,'emailVerified':_0x95c205,'displayName':_0x300909,'isAnonymous':_0x1e6a8e,'photoURL':_0x535537,'phoneNumber':_0x2a6629,'tenantId':_0x1125eb,'stsTokenManager':_0x25f8a4,'createdAt':_0x45951e,'lastLoginAt':_0x30be75});return _0x32b4f1&&Array['isArray'](_0x32b4f1)&&(_0x1c0022['providerData']=_0x32b4f1['map'](_0x4e847f=>({..._0x4e847f}))),_0x509a11&&(_0x1c0022['_redirectEventId']=_0x509a11),_0x1c0022;}static async['_fromIdTokenResponse'](_0x499836,_0x5e350c,_0x1ac7e9=!0x1){const _0xa72d8f=new Je();_0xa72d8f['updateFromServerResponse'](_0x5e350c);const _0x2ee7d5=new z({'uid':_0x5e350c['localId'],'auth':_0x499836,'stsTokenManager':_0xa72d8f,'isAnonymous':_0x1ac7e9});return await bn(_0x2ee7d5),_0x2ee7d5;}static async['_fromGetAccountInfoResponse'](_0x273408,_0x7ace3c,_0x496f3e){const _0x1a4892=_0x7ace3c['users'][0x0];m(_0x1a4892['localId']!==void 0x0,'internal-error');const _0x5ae35f=_0x1a4892['providerUserInfo']!==void 0x0?wa(_0x1a4892['providerUserInfo']):[],_0xd6e1ea=!(_0x1a4892['email']&&_0x1a4892['passwordHash'])&&!(_0x5ae35f!=null&&_0x5ae35f['length']),_0x3ab799=new Je();_0x3ab799['updateFromIdToken'](_0x496f3e);const _0x4f2971=new z({'uid':_0x1a4892['localId'],'auth':_0x273408,'stsTokenManager':_0x3ab799,'isAnonymous':_0xd6e1ea}),_0x320b14={'uid':_0x1a4892['localId'],'displayName':_0x1a4892['displayName']||null,'photoURL':_0x1a4892['photoUrl']||null,'email':_0x1a4892['email']||null,'emailVerified':_0x1a4892['emailVerified']||!0x1,'phoneNumber':_0x1a4892['phoneNumber']||null,'tenantId':_0x1a4892['tenantId']||null,'providerData':_0x5ae35f,'metadata':new Pi(_0x1a4892['createdAt'],_0x1a4892['lastLoginAt']),'isAnonymous':!(_0x1a4892['email']&&_0x1a4892['passwordHash'])&&!(_0x5ae35f!=null&&_0x5ae35f['length'])};return Object['assign'](_0x4f2971,_0x320b14),_0x4f2971;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x5351a7){ae(_0x5351a7 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x273ae2=Ir['get'](_0x5351a7);return _0x273ae2?(ae(_0x273ae2 instanceof _0x5351a7,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x273ae2):(_0x273ae2=new _0x5351a7(),Ir['set'](_0x5351a7,_0x273ae2),_0x273ae2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x54d215,_0x858d05){this['storage'][_0x54d215]=_0x858d05;}async['_get'](_0x470f19){const _0x35ebbd=this['storage'][_0x470f19];return _0x35ebbd===void 0x0?null:_0x35ebbd;}async['_remove'](_0xfb51bc){delete this['storage'][_0xfb51bc];}['_addListener'](_0x63c9d9,_0x4f7980){}['_removeListener'](_0x4ba46e,_0x18f626){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x4e5554,_0x44af79,_0x144add){return'firebase:'+_0x4e5554+':'+_0x44af79+':'+_0x144add;}class Xe{constructor(_0x5b5aba,_0xd91470,_0x5ca675){this['persistence']=_0x5b5aba,this['auth']=_0xd91470,this['userKey']=_0x5ca675;const {config:_0x2031ca,name:_0x481df4}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x2031ca['apiKey'],_0x481df4),this['fullPersistenceKey']=sn('persistence',_0x2031ca['apiKey'],_0x481df4),this['boundEventHandler']=_0xd91470['_onStorageEvent']['bind'](_0xd91470),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x587693){return this['persistence']['_set'](this['fullUserKey'],_0x587693['toJSON']());}async['getCurrentUser'](){const _0x6a606d=await this['persistence']['_get'](this['fullUserKey']);if(!_0x6a606d)return null;if(typeof _0x6a606d=='string'){const _0x18c5a7=await Sn(this['auth'],{'idToken':_0x6a606d})['catch'](()=>{});return _0x18c5a7?z['_fromGetAccountInfoResponse'](this['auth'],_0x18c5a7,_0x6a606d):null;}return z['_fromJSON'](this['auth'],_0x6a606d);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x336bbd){if(this['persistence']===_0x336bbd)return;const _0x124805=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x336bbd,_0x124805)return this['setCurrentUser'](_0x124805);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x23ef5b,_0x31766c,_0x3327ab='authUser'){if(!_0x31766c['length'])return new Xe(ne(wr),_0x23ef5b,_0x3327ab);const _0x45297e=(await Promise['all'](_0x31766c['map'](async _0x252a6d=>{if(await _0x252a6d['_isAvailable']())return _0x252a6d;})))['filter'](_0x138ed=>_0x138ed);let _0x530b11=_0x45297e[0x0]||ne(wr);const _0x34fd55=sn(_0x3327ab,_0x23ef5b['config']['apiKey'],_0x23ef5b['name']);let _0xf454b7=null;for(const _0x2e3460 of _0x31766c)try{const _0x3b2763=await _0x2e3460['_get'](_0x34fd55);if(_0x3b2763){let _0x3a18c7;if(typeof _0x3b2763=='string'){const _0x4e16fa=await Sn(_0x23ef5b,{'idToken':_0x3b2763})['catch'](()=>{});if(!_0x4e16fa)break;_0x3a18c7=await z['_fromGetAccountInfoResponse'](_0x23ef5b,_0x4e16fa,_0x3b2763);}else _0x3a18c7=z['_fromJSON'](_0x23ef5b,_0x3b2763);_0x2e3460!==_0x530b11&&(_0xf454b7=_0x3a18c7),_0x530b11=_0x2e3460;break;}}catch{}const _0x20e3b8=_0x45297e['filter'](_0x650693=>_0x650693['_shouldAllowMigration']);return!_0x530b11['_shouldAllowMigration']||!_0x20e3b8['length']?new Xe(_0x530b11,_0x23ef5b,_0x3327ab):(_0x530b11=_0x20e3b8[0x0],_0xf454b7&&await _0x530b11['_set'](_0x34fd55,_0xf454b7['toJSON']()),await Promise['all'](_0x31766c['map'](async _0x2e4158=>{if(_0x2e4158!==_0x530b11)try{await _0x2e4158['_remove'](_0x34fd55);}catch{}})),new Xe(_0x530b11,_0x23ef5b,_0x3327ab));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x54ac89){const _0x5a2b8c=_0x54ac89['toLowerCase']();if(_0x5a2b8c['includes']('opera/')||_0x5a2b8c['includes']('opr/')||_0x5a2b8c['includes']('opios/'))return'Opera';if(Ra(_0x5a2b8c))return'IEMobile';if(_0x5a2b8c['includes']('msie')||_0x5a2b8c['includes']('trident/'))return'IE';if(_0x5a2b8c['includes']('edge/'))return'Edge';if(Ta(_0x5a2b8c))return'Firefox';if(_0x5a2b8c['includes']('silk/'))return'Silk';if(ka(_0x5a2b8c))return'Blackberry';if(Na(_0x5a2b8c))return'Webos';if(Sa(_0x5a2b8c))return'Safari';if((_0x5a2b8c['includes']('chrome/')||ba(_0x5a2b8c))&&!_0x5a2b8c['includes']('edge/'))return'Chrome';if(Aa(_0x5a2b8c))return'Android';{const _0x10e1c8=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x546807=_0x54ac89['match'](_0x10e1c8);if((_0x546807==null?void 0x0:_0x546807['length'])===0x2)return _0x546807[0x1];}return'Other';}function Ta(_0x258ff2=W()){return/firefox\//i['test'](_0x258ff2);}function Sa(_0x143d5d=W()){const _0x4c1da9=_0x143d5d['toLowerCase']();return _0x4c1da9['includes']('safari/')&&!_0x4c1da9['includes']('chrome/')&&!_0x4c1da9['includes']('crios/')&&!_0x4c1da9['includes']('android');}function ba(_0x58278e=W()){return/crios\//i['test'](_0x58278e);}function Ra(_0x693d96=W()){return/iemobile/i['test'](_0x693d96);}function Aa(_0xcfd15e=W()){return/android/i['test'](_0xcfd15e);}function ka(_0x3cc6cb=W()){return/blackberry/i['test'](_0x3cc6cb);}function Na(_0x419f69=W()){return/webos/i['test'](_0x419f69);}function Cs(_0x1bca04=W()){return/iphone|ipad|ipod/i['test'](_0x1bca04)||/macintosh/i['test'](_0x1bca04)&&/mobile/i['test'](_0x1bca04);}function Ef(_0x1a24fb=W()){var _0x5623fe;return Cs(_0x1a24fb)&&!!((_0x5623fe=window['navigator'])!=null&&_0x5623fe['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5df66f=W()){return Cs(_0x5df66f)||Aa(_0x5df66f)||Na(_0x5df66f)||ka(_0x5df66f)||/windows phone/i['test'](_0x5df66f)||Ra(_0x5df66f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x702dbc,_0x29ec3b=[]){let _0xc0a698;switch(_0x702dbc){case'Browser':_0xc0a698=Cr(W());break;case'Worker':_0xc0a698=Cr(W())+'-'+_0x702dbc;break;default:_0xc0a698=_0x702dbc;}const _0x494c9f=_0x29ec3b['length']?_0x29ec3b['join'](','):'FirebaseCore-web';return _0xc0a698+'/JsCore/'+ct+'/'+_0x494c9f;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x26e1cb){this['auth']=_0x26e1cb,this['queue']=[];}['pushCallback'](_0x5ef2ed,_0x5ada93){const _0x13c8ec=_0x3dc085=>new Promise((_0x45e23a,_0x2b094b)=>{try{const _0x1fca0f=_0x5ef2ed(_0x3dc085);_0x45e23a(_0x1fca0f);}catch(_0x49318f){_0x2b094b(_0x49318f);}});_0x13c8ec['onAbort']=_0x5ada93,this['queue']['push'](_0x13c8ec);const _0x5236e1=this['queue']['length']-0x1;return()=>{this['queue'][_0x5236e1]=()=>Promise['resolve']();};}async['runMiddleware'](_0x357899){if(this['auth']['currentUser']===_0x357899)return;const _0x38db82=[];try{for(const _0x4f46a1 of this['queue'])await _0x4f46a1(_0x357899),_0x4f46a1['onAbort']&&_0x38db82['push'](_0x4f46a1['onAbort']);}catch(_0xc32918){_0x38db82['reverse']();for(const _0xcc8f75 of _0x38db82)try{_0xcc8f75();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xc32918==null?void 0x0:_0xc32918['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4b6e6f,_0x2d3978={}){return Ae(_0x4b6e6f,'GET','/v2/passwordPolicy',Re(_0x4b6e6f,_0x2d3978));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x1baf7d){var _0x4b3f8b;const _0x29b96f=_0x1baf7d['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x29b96f['minPasswordLength']??Tf,_0x29b96f['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x29b96f['maxPasswordLength']),_0x29b96f['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x29b96f['containsLowercaseCharacter']),_0x29b96f['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x29b96f['containsUppercaseCharacter']),_0x29b96f['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x29b96f['containsNumericCharacter']),_0x29b96f['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x29b96f['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1baf7d['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4b3f8b=_0x1baf7d['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4b3f8b['join'](''))??'',this['forceUpgradeOnSignin']=_0x1baf7d['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1baf7d['schemaVersion'];}['validatePassword'](_0x2cb577){const _0x1c4272={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2cb577,_0x1c4272),this['validatePasswordCharacterOptions'](_0x2cb577,_0x1c4272),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['meetsMinPasswordLength']??!0x0),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['meetsMaxPasswordLength']??!0x0),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['containsLowercaseLetter']??!0x0),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['containsUppercaseLetter']??!0x0),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['containsNumericCharacter']??!0x0),_0x1c4272['isValid']&&(_0x1c4272['isValid']=_0x1c4272['containsNonAlphanumericCharacter']??!0x0),_0x1c4272;}['validatePasswordLengthOptions'](_0x3aed14,_0x20a5ff){const _0x442d13=this['customStrengthOptions']['minPasswordLength'],_0x4631f9=this['customStrengthOptions']['maxPasswordLength'];_0x442d13&&(_0x20a5ff['meetsMinPasswordLength']=_0x3aed14['length']>=_0x442d13),_0x4631f9&&(_0x20a5ff['meetsMaxPasswordLength']=_0x3aed14['length']<=_0x4631f9);}['validatePasswordCharacterOptions'](_0x4aa233,_0x52ef63){this['updatePasswordCharacterOptionsStatuses'](_0x52ef63,!0x1,!0x1,!0x1,!0x1);let _0x508e28;for(let _0x4a86cd=0x0;_0x4a86cd<_0x4aa233['length'];_0x4a86cd++)_0x508e28=_0x4aa233['charAt'](_0x4a86cd),this['updatePasswordCharacterOptionsStatuses'](_0x52ef63,_0x508e28>='a'&&_0x508e28<='z',_0x508e28>='A'&&_0x508e28<='Z',_0x508e28>='0'&&_0x508e28<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x508e28));}['updatePasswordCharacterOptionsStatuses'](_0x3c8602,_0x26fd00,_0x32a97d,_0x5c8749,_0x31fc81){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x3c8602['containsLowercaseLetter']||(_0x3c8602['containsLowercaseLetter']=_0x26fd00)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x3c8602['containsUppercaseLetter']||(_0x3c8602['containsUppercaseLetter']=_0x32a97d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x3c8602['containsNumericCharacter']||(_0x3c8602['containsNumericCharacter']=_0x5c8749)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x3c8602['containsNonAlphanumericCharacter']||(_0x3c8602['containsNonAlphanumericCharacter']=_0x31fc81));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x16c479,_0x9bdd2c,_0x56777d,_0x171d89){this['app']=_0x16c479,this['heartbeatServiceProvider']=_0x9bdd2c,this['appCheckServiceProvider']=_0x56777d,this['config']=_0x171d89,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x16c479['name'],this['clientVersion']=_0x171d89['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x59fc27=>this['_resolvePersistenceManagerAvailable']=_0x59fc27);}['_initializeWithPersistence'](_0x5adab2,_0x4dc04f){return _0x4dc04f&&(this['_popupRedirectResolver']=ne(_0x4dc04f)),this['_initializationPromise']=this['queue'](async()=>{var _0x1b8965,_0x4e25d4,_0x5cb02f;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x5adab2),(_0x1b8965=this['_resolvePersistenceManagerAvailable'])==null||_0x1b8965['call'](this),!this['_deleted'])){if((_0x4e25d4=this['_popupRedirectResolver'])!=null&&_0x4e25d4['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4dc04f),this['lastNotifiedUid']=((_0x5cb02f=this['currentUser'])==null?void 0x0:_0x5cb02f['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xad9844=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xad9844)){if(this['currentUser']&&_0xad9844&&this['currentUser']['uid']===_0xad9844['uid']){this['_currentUser']['_assign'](_0xad9844),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xad9844,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3828ed){try{const _0x6cf5aa=await Sn(this,{'idToken':_0x3828ed}),_0xaed535=await z['_fromGetAccountInfoResponse'](this,_0x6cf5aa,_0x3828ed);await this['directlySetCurrentUser'](_0xaed535);}catch(_0x7ee828){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x7ee828),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3486f2){var _0x30b394;if(H(this['app'])){const _0xce2d3=this['app']['settings']['authIdToken'];return _0xce2d3?new Promise(_0x3cbaf6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xce2d3)['then'](_0x3cbaf6,_0x3cbaf6));}):this['directlySetCurrentUser'](null);}const _0x89d8d7=await this['assertedPersistence']['getCurrentUser']();let _0xeeda03=_0x89d8d7,_0x15b54a=!0x1;if(_0x3486f2&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x138755=(_0x30b394=this['redirectUser'])==null?void 0x0:_0x30b394['_redirectEventId'],_0x5ebad5=_0xeeda03==null?void 0x0:_0xeeda03['_redirectEventId'],_0x5844d2=await this['tryRedirectSignIn'](_0x3486f2);(!_0x138755||_0x138755===_0x5ebad5)&&(_0x5844d2!=null&&_0x5844d2['user'])&&(_0xeeda03=_0x5844d2['user'],_0x15b54a=!0x0);}if(!_0xeeda03)return this['directlySetCurrentUser'](null);if(!_0xeeda03['_redirectEventId']){if(_0x15b54a)try{await this['beforeStateQueue']['runMiddleware'](_0xeeda03);}catch(_0x4563d3){_0xeeda03=_0x89d8d7,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4563d3));}return _0xeeda03?this['reloadAndSetCurrentUserOrClear'](_0xeeda03):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0xeeda03['_redirectEventId']?this['directlySetCurrentUser'](_0xeeda03):this['reloadAndSetCurrentUserOrClear'](_0xeeda03);}async['tryRedirectSignIn'](_0x3c9649){let _0x5264fa=null;try{_0x5264fa=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3c9649,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5264fa;}async['reloadAndSetCurrentUserOrClear'](_0x38608c){try{await bn(_0x38608c);}catch(_0x4c343f){if((_0x4c343f==null?void 0x0:_0x4c343f['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x38608c);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x21edf5){if(H(this['app']))return Promise['reject'](se(this));const _0x6f6cb8=_0x21edf5?k(_0x21edf5):null;return _0x6f6cb8&&m(_0x6f6cb8['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x6f6cb8&&_0x6f6cb8['_clone'](this));}async['_updateCurrentUser'](_0x383824,_0xfa1142=!0x1){if(!this['_deleted'])return _0x383824&&m(this['tenantId']===_0x383824['tenantId'],this,'tenant-id-mismatch'),_0xfa1142||await this['beforeStateQueue']['runMiddleware'](_0x383824),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x383824),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xb4f423){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xb4f423));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x56173f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x37c201=this['_getPasswordPolicyInternal']();return _0x37c201['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x37c201['validatePassword'](_0x56173f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x504476=await Cf(this),_0x13a450=new Sf(_0x504476);this['tenantId']===null?this['_projectPasswordPolicy']=_0x13a450:this['_tenantPasswordPolicies'][this['tenantId']]=_0x13a450;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x42b0ca){this['_errorFactory']=new Ut('auth','Firebase',_0x42b0ca());}['onAuthStateChanged'](_0x5ad0f2,_0xb1ef4e,_0x4ccb28){return this['registerStateListener'](this['authStateSubscription'],_0x5ad0f2,_0xb1ef4e,_0x4ccb28);}['beforeAuthStateChanged'](_0x3f3222,_0x356993){return this['beforeStateQueue']['pushCallback'](_0x3f3222,_0x356993);}['onIdTokenChanged'](_0x4a3c18,_0x427b34,_0x186d4b){return this['registerStateListener'](this['idTokenSubscription'],_0x4a3c18,_0x427b34,_0x186d4b);}['authStateReady'](){return new Promise((_0x5a9a39,_0x54a00e)=>{if(this['currentUser'])_0x5a9a39();else{const _0xd5b3aa=this['onAuthStateChanged'](()=>{_0xd5b3aa(),_0x5a9a39();},_0x54a00e);}});}async['revokeAccessToken'](_0x28f147){if(this['currentUser']){const _0x8dd067=await this['currentUser']['getIdToken'](),_0x27e85a={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x28f147,'idToken':_0x8dd067};this['tenantId']!=null&&(_0x27e85a['tenantId']=this['tenantId']),await vf(this,_0x27e85a);}}['toJSON'](){var _0x2674af;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2674af=this['_currentUser'])==null?void 0x0:_0x2674af['toJSON']()};}async['_setRedirectUser'](_0x3937ea,_0x3a4ff3){const _0x93412c=await this['getOrInitRedirectPersistenceManager'](_0x3a4ff3);return _0x3937ea===null?_0x93412c['removeCurrentUser']():_0x93412c['setCurrentUser'](_0x3937ea);}async['getOrInitRedirectPersistenceManager'](_0xb6d6d){if(!this['redirectPersistenceManager']){const _0xca2998=_0xb6d6d&&ne(_0xb6d6d)||this['_popupRedirectResolver'];m(_0xca2998,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0xca2998['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x415f46){var _0x534981,_0x1a9f4e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x534981=this['_currentUser'])==null?void 0x0:_0x534981['_redirectEventId'])===_0x415f46?this['_currentUser']:((_0x1a9f4e=this['redirectUser'])==null?void 0x0:_0x1a9f4e['_redirectEventId'])===_0x415f46?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2c3810){if(_0x2c3810===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2c3810));}['_notifyListenersIfCurrent'](_0x5cc6d4){_0x5cc6d4===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5f2a39;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x14944f=((_0x5f2a39=this['currentUser'])==null?void 0x0:_0x5f2a39['uid'])??null;this['lastNotifiedUid']!==_0x14944f&&(this['lastNotifiedUid']=_0x14944f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x24a81b,_0xd4bb3c,_0x1bdbca,_0x2ecf81){if(this['_deleted'])return()=>{};const _0x15ae79=typeof _0xd4bb3c=='function'?_0xd4bb3c:_0xd4bb3c['next']['bind'](_0xd4bb3c);let _0x55296b=!0x1;const _0x14d6de=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x14d6de,this,'internal-error'),_0x14d6de['then'](()=>{_0x55296b||_0x15ae79(this['currentUser']);}),typeof _0xd4bb3c=='function'){const _0x4f21b6=_0x24a81b['addObserver'](_0xd4bb3c,_0x1bdbca,_0x2ecf81);return()=>{_0x55296b=!0x0,_0x4f21b6();};}else{const _0x2d1110=_0x24a81b['addObserver'](_0xd4bb3c);return()=>{_0x55296b=!0x0,_0x2d1110();};}}async['directlySetCurrentUser'](_0x12c5e7){this['currentUser']&&this['currentUser']!==_0x12c5e7&&this['_currentUser']['_stopProactiveRefresh'](),_0x12c5e7&&this['isProactiveRefreshEnabled']&&_0x12c5e7['_startProactiveRefresh'](),this['currentUser']=_0x12c5e7,_0x12c5e7?await this['assertedPersistence']['setCurrentUser'](_0x12c5e7):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2921c1){return this['operations']=this['operations']['then'](_0x2921c1,_0x2921c1),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4dec8e){!_0x4dec8e||this['frameworks']['includes'](_0x4dec8e)||(this['frameworks']['push'](_0x4dec8e),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4ab1d6;const _0x2f04aa={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2f04aa['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x50982b=await((_0x4ab1d6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4ab1d6['getHeartbeatsHeader']());_0x50982b&&(_0x2f04aa['X-Firebase-Client']=_0x50982b);const _0x357812=await this['_getAppCheckToken']();return _0x357812&&(_0x2f04aa['X-Firebase-AppCheck']=_0x357812),_0x2f04aa;}async['_getAppCheckToken'](){var _0xdf2e9f;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1e417c=await((_0xdf2e9f=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xdf2e9f['getToken']());return _0x1e417c!=null&&_0x1e417c['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1e417c['error']),_0x1e417c==null?void 0x0:_0x1e417c['token'];}}function qe(_0x560a80){return k(_0x560a80);}class Tr{constructor(_0x172d96){this['auth']=_0x172d96,this['observer']=null,this['addObserver']=Ic(_0x18b028=>this['observer']=_0x18b028);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x323bcc){zn=_0x323bcc;}function Da(_0x3de0b5){return zn['loadJS'](_0x3de0b5);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x1795a9){return'__'+_0x1795a9+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x45c5a8){_0x45c5a8();}['execute'](_0x132ee5,_0x3508f8){return Promise['resolve']('token');}['render'](_0x2ed933,_0x4a76c4){return'';}}class Of{['ready'](_0x39f273){_0x39f273();}['execute'](_0x2aa995,_0x59af7d){return Promise['resolve']('token');}['render'](_0x1697c8,_0x1ff920){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4c6900){this['type']=Df,this['auth']=qe(_0x4c6900);}async['verify'](_0x4f7645='verify',_0x171ac9=!0x1){async function _0xe2dea0(_0x4f9e85){if(!_0x171ac9){if(_0x4f9e85['tenantId']==null&&_0x4f9e85['_agentRecaptchaConfig']!=null)return _0x4f9e85['_agentRecaptchaConfig']['siteKey'];if(_0x4f9e85['tenantId']!=null&&_0x4f9e85['_tenantRecaptchaConfigs'][_0x4f9e85['tenantId']]!==void 0x0)return _0x4f9e85['_tenantRecaptchaConfigs'][_0x4f9e85['tenantId']]['siteKey'];}return new Promise(async(_0x24d30f,_0x5f47de)=>{uf(_0x4f9e85,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x263a3c=>{if(_0x263a3c['recaptchaKey']===void 0x0)_0x5f47de(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x314af6=new hf(_0x263a3c);return _0x4f9e85['tenantId']==null?_0x4f9e85['_agentRecaptchaConfig']=_0x314af6:_0x4f9e85['_tenantRecaptchaConfigs'][_0x4f9e85['tenantId']]=_0x314af6,_0x24d30f(_0x314af6['siteKey']);}})['catch'](_0x4cbc71=>{_0x5f47de(_0x4cbc71);});});}function _0x413dd6(_0x6e06fe,_0x1c385e,_0x15e068){const _0x58f3a3=window['grecaptcha'];vr(_0x58f3a3)?_0x58f3a3['enterprise']['ready'](()=>{_0x58f3a3['enterprise']['execute'](_0x6e06fe,{'action':_0x4f7645})['then'](_0x11c413=>{_0x1c385e(_0x11c413);})['catch'](()=>{_0x1c385e(Ma);});}):_0x15e068(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x2f8b54,_0x14bf8a)=>{_0xe2dea0(this['auth'])['then'](async _0x3fca27=>{if(!_0x171ac9&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x413dd6(_0x3fca27,_0x2f8b54,_0x14bf8a);else{if(typeof window>'u'){_0x14bf8a(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5991c3=Af();_0x5991c3['length']!==0x0&&(_0x5991c3+=_0x3fca27+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x1ce149;(_0x1ce149=le['scriptInjectionDeferred'])==null||_0x1ce149['resolve']();},Da(_0x5991c3)['then'](()=>{var _0x162443;return(_0x162443=le['scriptInjectionDeferred'])==null?void 0x0:_0x162443['promise'];})['then'](()=>{_0x413dd6(_0x3fca27,_0x2f8b54,_0x14bf8a);})['catch'](_0x51d814=>{_0x14bf8a(_0x51d814);});}})['catch'](_0x19852d=>{_0x14bf8a(_0x19852d);});});}}le['scriptInjectionDeferred']=null;async function br(_0x63be2a,_0x10ad59,_0x3e0235,_0x2b93d5=!0x1,_0x1d2a23=!0x1){const _0x23928f=new le(_0x63be2a);let _0x422dac;if(_0x1d2a23)_0x422dac=Ma;else try{_0x422dac=await _0x23928f['verify'](_0x3e0235);}catch{_0x422dac=await _0x23928f['verify'](_0x3e0235,!0x0);}const _0x49f52d={..._0x10ad59};if(_0x3e0235==='mfaSmsEnrollment'||_0x3e0235==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x49f52d){const _0x5b300c=_0x49f52d['phoneEnrollmentInfo']['phoneNumber'],_0x17ff5b=_0x49f52d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x49f52d,{'phoneEnrollmentInfo':{'phoneNumber':_0x5b300c,'recaptchaToken':_0x17ff5b,'captchaResponse':_0x422dac,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x49f52d){const _0x3343a2=_0x49f52d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x49f52d,{'phoneSignInInfo':{'recaptchaToken':_0x3343a2,'captchaResponse':_0x422dac,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x49f52d;}return _0x2b93d5?Object['assign'](_0x49f52d,{'captchaResp':_0x422dac}):Object['assign'](_0x49f52d,{'captchaResponse':_0x422dac}),Object['assign'](_0x49f52d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x49f52d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x49f52d;}async function Oi(_0x31bc4e,_0x39c73e,_0x4c2f86,_0x32363e,_0x1fd333){var _0x145382;if((_0x145382=_0x31bc4e['_getRecaptchaConfig']())!=null&&_0x145382['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2d3113=await br(_0x31bc4e,_0x39c73e,_0x4c2f86,_0x4c2f86==='getOobCode');return _0x32363e(_0x31bc4e,_0x2d3113);}else return _0x32363e(_0x31bc4e,_0x39c73e)['catch'](async _0x1b569d=>{if(_0x1b569d['code']==='auth/missing-recaptcha-token'){console['log'](_0x4c2f86+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x21516f=await br(_0x31bc4e,_0x39c73e,_0x4c2f86,_0x4c2f86==='getOobCode');return _0x32363e(_0x31bc4e,_0x21516f);}else return Promise['reject'](_0x1b569d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x152256,_0x14bb8e){const _0x130eb9=Ui(_0x152256,'auth');if(_0x130eb9['isInitialized']()){const _0x135985=_0x130eb9['getImmediate'](),_0x1b0306=_0x130eb9['getOptions']();if(De(_0x1b0306,_0x14bb8e??{}))return _0x135985;K(_0x135985,'already-initialized');}return _0x130eb9['initialize']({'options':_0x14bb8e});}function Lf(_0x403bfa,_0x5a0ac4){const _0x5a3c60=(_0x5a0ac4==null?void 0x0:_0x5a0ac4['persistence'])||[],_0x173924=(Array['isArray'](_0x5a3c60)?_0x5a3c60:[_0x5a3c60])['map'](ne);_0x5a0ac4!=null&&_0x5a0ac4['errorMap']&&_0x403bfa['_updateErrorMap'](_0x5a0ac4['errorMap']),_0x403bfa['_initializeWithPersistence'](_0x173924,_0x5a0ac4==null?void 0x0:_0x5a0ac4['popupRedirectResolver']);}function xf(_0x1548f6,_0x524368,_0x59cc8a){const _0x2a127c=qe(_0x1548f6);m(/^https?:\/\//['test'](_0x524368),_0x2a127c,'invalid-emulator-scheme');const _0x379c33=!0x1,_0x2e5118=La(_0x524368),{host:_0x37fba4,port:_0x243e68}=Ff(_0x524368),_0x4432fa=_0x243e68===null?'':':'+_0x243e68,_0x1d3a8a={'url':_0x2e5118+'//'+_0x37fba4+_0x4432fa+'/'},_0x326263=Object['freeze']({'host':_0x37fba4,'port':_0x243e68,'protocol':_0x2e5118['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x379c33})});if(!_0x2a127c['_canInitEmulator']){m(_0x2a127c['config']['emulator']&&_0x2a127c['emulatorConfig'],_0x2a127c,'emulator-config-failed'),m(De(_0x1d3a8a,_0x2a127c['config']['emulator'])&&De(_0x326263,_0x2a127c['emulatorConfig']),_0x2a127c,'emulator-config-failed');return;}_0x2a127c['config']['emulator']=_0x1d3a8a,_0x2a127c['emulatorConfig']=_0x326263,_0x2a127c['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x37fba4)?jr(_0x2e5118+'//'+_0x37fba4+_0x4432fa):Uf();}function La(_0x8b8176){const _0x33c2aa=_0x8b8176['indexOf'](':');return _0x33c2aa<0x0?'':_0x8b8176['substr'](0x0,_0x33c2aa+0x1);}function Ff(_0x4f96b9){const _0x27026a=La(_0x4f96b9),_0x490175=/(\/\/)?([^?#/]+)/['exec'](_0x4f96b9['substr'](_0x27026a['length']));if(!_0x490175)return{'host':'','port':null};const _0x41c6e9=_0x490175[0x2]['split']('@')['pop']()||'',_0x6350bb=/^(\[[^\]]+\])(:|$)/['exec'](_0x41c6e9);if(_0x6350bb){const _0x4cc286=_0x6350bb[0x1];return{'host':_0x4cc286,'port':Rr(_0x41c6e9['substr'](_0x4cc286['length']+0x1))};}else{const [_0x432551,_0x2caa8d]=_0x41c6e9['split'](':');return{'host':_0x432551,'port':Rr(_0x2caa8d)};}}function Rr(_0x3999e8){if(!_0x3999e8)return null;const _0x4b466f=Number(_0x3999e8);return isNaN(_0x4b466f)?null:_0x4b466f;}function Uf(){function _0x54adae(){const _0x10097a=document['createElement']('p'),_0x367ff3=_0x10097a['style'];_0x10097a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x367ff3['position']='fixed',_0x367ff3['width']='100%',_0x367ff3['backgroundColor']='#ffffff',_0x367ff3['border']='.1em\x20solid\x20#000000',_0x367ff3['color']='#b50000',_0x367ff3['bottom']='0px',_0x367ff3['left']='0px',_0x367ff3['margin']='0px',_0x367ff3['zIndex']='10000',_0x367ff3['textAlign']='center',_0x10097a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x10097a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x54adae):_0x54adae());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x279953,_0x344a75){this['providerId']=_0x279953,this['signInMethod']=_0x344a75;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x28e290){return te('not\x20implemented');}['_linkToIdToken'](_0x5184e0,_0x232613){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x1fda08){return te('not\x20implemented');}}async function Wf(_0x1fca75,_0x1ccd94){return Ae(_0x1fca75,'POST','/v1/accounts:signUp',_0x1ccd94);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x41e455,_0x342824){return Yt(_0x41e455,'POST','/v1/accounts:signInWithPassword',Re(_0x41e455,_0x342824));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x7ea4bf,_0x300218){return Yt(_0x7ea4bf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x7ea4bf,_0x300218));}async function Hf(_0x41f4fe,_0x4e7b92){return Yt(_0x41f4fe,'POST','/v1/accounts:signInWithEmailLink',Re(_0x41f4fe,_0x4e7b92));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0xaaefb0,_0x46f0af,_0x4924f1,_0xac837c=null){super('password',_0x4924f1),this['_email']=_0xaaefb0,this['_password']=_0x46f0af,this['_tenantId']=_0xac837c;}static['_fromEmailAndPassword'](_0x50e556,_0x5cf650){return new Ft(_0x50e556,_0x5cf650,'password');}static['_fromEmailAndCode'](_0x5c3240,_0x3af2c8,_0x1560e3=null){return new Ft(_0x5c3240,_0x3af2c8,'emailLink',_0x1560e3);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x11e853){const _0x4b47e3=typeof _0x11e853=='string'?JSON['parse'](_0x11e853):_0x11e853;if(_0x4b47e3!=null&&_0x4b47e3['email']&&(_0x4b47e3!=null&&_0x4b47e3['password'])){if(_0x4b47e3['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4b47e3['email'],_0x4b47e3['password']);if(_0x4b47e3['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4b47e3['email'],_0x4b47e3['password'],_0x4b47e3['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4aed16){switch(this['signInMethod']){case'password':const _0x1085cb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x4aed16,_0x1085cb,'signInWithPassword',Bf);case'emailLink':return Vf(_0x4aed16,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x4aed16,'internal-error');}}async['_linkToIdToken'](_0x2efa3e,_0x2c81e7){switch(this['signInMethod']){case'password':const _0x3d01e0={'idToken':_0x2c81e7,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2efa3e,_0x3d01e0,'signUpPassword',Wf);case'emailLink':return Hf(_0x2efa3e,{'idToken':_0x2c81e7,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2efa3e,'internal-error');}}['_getReauthenticationResolver'](_0x4c08ed){return this['_getIdTokenResponse'](_0x4c08ed);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x424479,_0x429a58){return Yt(_0x424479,'POST','/v1/accounts:signInWithIdp',Re(_0x424479,_0x429a58));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5d380c){const _0x15337f=new We(_0x5d380c['providerId'],_0x5d380c['signInMethod']);return _0x5d380c['idToken']||_0x5d380c['accessToken']?(_0x5d380c['idToken']&&(_0x15337f['idToken']=_0x5d380c['idToken']),_0x5d380c['accessToken']&&(_0x15337f['accessToken']=_0x5d380c['accessToken']),_0x5d380c['nonce']&&!_0x5d380c['pendingToken']&&(_0x15337f['nonce']=_0x5d380c['nonce']),_0x5d380c['pendingToken']&&(_0x15337f['pendingToken']=_0x5d380c['pendingToken'])):_0x5d380c['oauthToken']&&_0x5d380c['oauthTokenSecret']?(_0x15337f['accessToken']=_0x5d380c['oauthToken'],_0x15337f['secret']=_0x5d380c['oauthTokenSecret']):K('argument-error'),_0x15337f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x12cdc3){const _0x1ec1fd=typeof _0x12cdc3=='string'?JSON['parse'](_0x12cdc3):_0x12cdc3,{providerId:_0x180ad5,signInMethod:_0x2530e0,..._0x529198}=_0x1ec1fd;if(!_0x180ad5||!_0x2530e0)return null;const _0x5dc6de=new We(_0x180ad5,_0x2530e0);return _0x5dc6de['idToken']=_0x529198['idToken']||void 0x0,_0x5dc6de['accessToken']=_0x529198['accessToken']||void 0x0,_0x5dc6de['secret']=_0x529198['secret'],_0x5dc6de['nonce']=_0x529198['nonce'],_0x5dc6de['pendingToken']=_0x529198['pendingToken']||null,_0x5dc6de;}['_getIdTokenResponse'](_0x235850){const _0x2897e3=this['buildRequest']();return Ze(_0x235850,_0x2897e3);}['_linkToIdToken'](_0x5a8320,_0x13a1dd){const _0x556c43=this['buildRequest']();return _0x556c43['idToken']=_0x13a1dd,Ze(_0x5a8320,_0x556c43);}['_getReauthenticationResolver'](_0x4d13e5){const _0x190221=this['buildRequest']();return _0x190221['autoCreate']=!0x1,Ze(_0x4d13e5,_0x190221);}['buildRequest'](){const _0x20b3c6={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x20b3c6['pendingToken']=this['pendingToken'];else{const _0x3ec328={};this['idToken']&&(_0x3ec328['id_token']=this['idToken']),this['accessToken']&&(_0x3ec328['access_token']=this['accessToken']),this['secret']&&(_0x3ec328['oauth_token_secret']=this['secret']),_0x3ec328['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3ec328['nonce']=this['nonce']),_0x20b3c6['postBody']=at(_0x3ec328);}return _0x20b3c6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x26daf7){switch(_0x26daf7){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2e468d){const _0x37c569=yt(vt(_0x2e468d))['link'],_0x263659=_0x37c569?yt(vt(_0x37c569))['deep_link_id']:null,_0x481124=yt(vt(_0x2e468d))['deep_link_id'];return(_0x481124?yt(vt(_0x481124))['link']:null)||_0x481124||_0x263659||_0x37c569||_0x2e468d;}class Ss{constructor(_0x272383){const _0x3ae2a9=yt(vt(_0x272383)),_0x3126b4=_0x3ae2a9['apiKey']??null,_0x3eaab3=_0x3ae2a9['oobCode']??null,_0x273e0b=Gf(_0x3ae2a9['mode']??null);m(_0x3126b4&&_0x3eaab3&&_0x273e0b,'argument-error'),this['apiKey']=_0x3126b4,this['operation']=_0x273e0b,this['code']=_0x3eaab3,this['continueUrl']=_0x3ae2a9['continueUrl']??null,this['languageCode']=_0x3ae2a9['lang']??null,this['tenantId']=_0x3ae2a9['tenantId']??null;}static['parseLink'](_0xe2d064){const _0x10dad0=qf(_0xe2d064);try{return new Ss(_0x10dad0);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x146429,_0x52a06c){return Ft['_fromEmailAndPassword'](_0x146429,_0x52a06c);}static['credentialWithLink'](_0x2d1225,_0x2690a9){const _0x158338=Ss['parseLink'](_0x2690a9);return m(_0x158338,'argument-error'),Ft['_fromEmailAndCode'](_0x2d1225,_0x158338['code'],_0x158338['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0xfcc9a3){this['providerId']=_0xfcc9a3,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x6eae7f){this['defaultLanguageCode']=_0x6eae7f;}['setCustomParameters'](_0x31422d){return this['customParameters']=_0x31422d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5d5c26){return this['scopes']['includes'](_0x5d5c26)||this['scopes']['push'](_0x5d5c26),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x4e1dc6){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4e1dc6});}static['credentialFromResult'](_0x380b84){return he['credentialFromTaggedObject'](_0x380b84);}static['credentialFromError'](_0xd8db15){return he['credentialFromTaggedObject'](_0xd8db15['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x35f3f6}){if(!_0x35f3f6||!('oauthAccessToken'in _0x35f3f6)||!_0x35f3f6['oauthAccessToken'])return null;try{return he['credential'](_0x35f3f6['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x195e8b,_0x3471d6){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x195e8b,'accessToken':_0x3471d6});}static['credentialFromResult'](_0x3f18d4){return ue['credentialFromTaggedObject'](_0x3f18d4);}static['credentialFromError'](_0x21a00e){return ue['credentialFromTaggedObject'](_0x21a00e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x550168}){if(!_0x550168)return null;const {oauthIdToken:_0x16f808,oauthAccessToken:_0x3c425d}=_0x550168;if(!_0x16f808&&!_0x3c425d)return null;try{return ue['credential'](_0x16f808,_0x3c425d);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x163b0c){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x163b0c});}static['credentialFromResult'](_0x2701ba){return de['credentialFromTaggedObject'](_0x2701ba);}static['credentialFromError'](_0x2602ec){return de['credentialFromTaggedObject'](_0x2602ec['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x226e89}){if(!_0x226e89||!('oauthAccessToken'in _0x226e89)||!_0x226e89['oauthAccessToken'])return null;try{return de['credential'](_0x226e89['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x570298,_0x9ac146){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x570298,'oauthTokenSecret':_0x9ac146});}static['credentialFromResult'](_0x56bd8c){return fe['credentialFromTaggedObject'](_0x56bd8c);}static['credentialFromError'](_0x30bd48){return fe['credentialFromTaggedObject'](_0x30bd48['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x48f7e4}){if(!_0x48f7e4)return null;const {oauthAccessToken:_0x3d8d47,oauthTokenSecret:_0x2a917a}=_0x48f7e4;if(!_0x3d8d47||!_0x2a917a)return null;try{return fe['credential'](_0x3d8d47,_0x2a917a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x50831a,_0x3b451a){return Yt(_0x50831a,'POST','/v1/accounts:signUp',Re(_0x50831a,_0x3b451a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xbed978){this['user']=_0xbed978['user'],this['providerId']=_0xbed978['providerId'],this['_tokenResponse']=_0xbed978['_tokenResponse'],this['operationType']=_0xbed978['operationType'];}static async['_fromIdTokenResponse'](_0x3a98f0,_0x214eac,_0x5d29ce,_0x156277=!0x1){const _0x5bfc03=await z['_fromIdTokenResponse'](_0x3a98f0,_0x5d29ce,_0x156277),_0x128b49=Ar(_0x5d29ce);return new Be({'user':_0x5bfc03,'providerId':_0x128b49,'_tokenResponse':_0x5d29ce,'operationType':_0x214eac});}static async['_forOperation'](_0x42ed73,_0x2481a4,_0x2d8c98){await _0x42ed73['_updateTokensIfNecessary'](_0x2d8c98,!0x0);const _0x4e049a=Ar(_0x2d8c98);return new Be({'user':_0x42ed73,'providerId':_0x4e049a,'_tokenResponse':_0x2d8c98,'operationType':_0x2481a4});}}function Ar(_0x588c60){return _0x588c60['providerId']?_0x588c60['providerId']:'phoneNumber'in _0x588c60?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x502568,_0x4f0701,_0x6311a,_0x1e3bbc){super(_0x4f0701['code'],_0x4f0701['message']),this['operationType']=_0x6311a,this['user']=_0x1e3bbc,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x502568['name'],'tenantId':_0x502568['tenantId']??void 0x0,'_serverResponse':_0x4f0701['customData']['_serverResponse'],'operationType':_0x6311a};}static['_fromErrorAndOperation'](_0x48d2c5,_0x2e11ba,_0x3da139,_0xd61b){return new Rn(_0x48d2c5,_0x2e11ba,_0x3da139,_0xd61b);}}function Fa(_0x499d2a,_0x5190e3,_0x356c57,_0x533110){return(_0x5190e3==='reauthenticate'?_0x356c57['_getReauthenticationResolver'](_0x499d2a):_0x356c57['_getIdTokenResponse'](_0x499d2a))['catch'](_0x260f9c=>{throw _0x260f9c['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x499d2a,_0x260f9c,_0x5190e3,_0x533110):_0x260f9c;});}async function jf(_0x89b98d,_0x33b192,_0x1a0b2a=!0x1){const _0x532235=await xt(_0x89b98d,_0x33b192['_linkToIdToken'](_0x89b98d['auth'],await _0x89b98d['getIdToken']()),_0x1a0b2a);return Be['_forOperation'](_0x89b98d,'link',_0x532235);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x248c64,_0x2a03cc,_0x5c4da5=!0x1){const {auth:_0x395f79}=_0x248c64;if(H(_0x395f79['app']))return Promise['reject'](se(_0x395f79));const _0x479c87='reauthenticate';try{const _0xc701e6=await xt(_0x248c64,Fa(_0x395f79,_0x479c87,_0x2a03cc,_0x248c64),_0x5c4da5);m(_0xc701e6['idToken'],_0x395f79,'internal-error');const _0x16a971=ws(_0xc701e6['idToken']);m(_0x16a971,_0x395f79,'internal-error');const {sub:_0x55e86c}=_0x16a971;return m(_0x248c64['uid']===_0x55e86c,_0x395f79,'user-mismatch'),Be['_forOperation'](_0x248c64,_0x479c87,_0xc701e6);}catch(_0x10d189){throw(_0x10d189==null?void 0x0:_0x10d189['code'])==='auth/user-not-found'&&K(_0x395f79,'user-mismatch'),_0x10d189;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x25826a,_0x3fc4b1,_0x3ca03d=!0x1){if(H(_0x25826a['app']))return Promise['reject'](se(_0x25826a));const _0x13e47f='signIn',_0x50f8fa=await Fa(_0x25826a,_0x13e47f,_0x3fc4b1),_0x44b128=await Be['_fromIdTokenResponse'](_0x25826a,_0x13e47f,_0x50f8fa);return _0x3ca03d||await _0x25826a['_updateCurrentUser'](_0x44b128['user']),_0x44b128;}async function Yf(_0x26a73e,_0x1a8a95){return Ua(qe(_0x26a73e),_0x1a8a95);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x271291){const _0x1b3a99=qe(_0x271291);_0x1b3a99['_getPasswordPolicyInternal']()&&await _0x1b3a99['_updatePasswordPolicy']();}async function R_(_0x5115cf,_0x72eed,_0x32be59){if(H(_0x5115cf['app']))return Promise['reject'](se(_0x5115cf));const _0x5bbb8e=qe(_0x5115cf),_0xd0a9d9=await Oi(_0x5bbb8e,{'returnSecureToken':!0x0,'email':_0x72eed,'password':_0x32be59,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x72a9bd=>{throw _0x72a9bd['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5115cf),_0x72a9bd;}),_0x2b3bab=await Be['_fromIdTokenResponse'](_0x5bbb8e,'signIn',_0xd0a9d9);return await _0x5bbb8e['_updateCurrentUser'](_0x2b3bab['user']),_0x2b3bab;}function A_(_0x328dbe,_0xc5c296,_0x49c9a8){return H(_0x328dbe['app'])?Promise['reject'](se(_0x328dbe)):Yf(k(_0x328dbe),ft['credential'](_0xc5c296,_0x49c9a8))['catch'](async _0x1c3eb2=>{throw _0x1c3eb2['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x328dbe),_0x1c3eb2;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0xa153b7,_0x5c320e){return k(_0xa153b7)['setPersistence'](_0x5c320e);}function Qf(_0x55d0a7,_0x3ae209,_0x59283f,_0x433afd){return k(_0x55d0a7)['onIdTokenChanged'](_0x3ae209,_0x59283f,_0x433afd);}function Jf(_0x98c67b,_0x2cc40d,_0xae1e02){return k(_0x98c67b)['beforeAuthStateChanged'](_0x2cc40d,_0xae1e02);}function N_(_0x52d5ed,_0xfca618,_0x3e6ebd,_0x1bf4ba){return k(_0x52d5ed)['onAuthStateChanged'](_0xfca618,_0x3e6ebd,_0x1bf4ba);}function P_(_0x407aab){return k(_0x407aab)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x366725,_0x370cab){this['storageRetriever']=_0x366725,this['type']=_0x370cab;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x24ee33,_0x35a85c){return this['storage']['setItem'](_0x24ee33,JSON['stringify'](_0x35a85c)),Promise['resolve']();}['_get'](_0x4a2959){const _0x147f08=this['storage']['getItem'](_0x4a2959);return Promise['resolve'](_0x147f08?JSON['parse'](_0x147f08):null);}['_remove'](_0x52031c){return this['storage']['removeItem'](_0x52031c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5433a2,_0x3e9e51)=>this['onStorageEvent'](_0x5433a2,_0x3e9e51),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2cfd65){for(const _0x50fee1 of Object['keys'](this['listeners'])){const _0x105253=this['storage']['getItem'](_0x50fee1),_0xc747d=this['localCache'][_0x50fee1];_0x105253!==_0xc747d&&_0x2cfd65(_0x50fee1,_0xc747d,_0x105253);}}['onStorageEvent'](_0x81a813,_0x27e714=!0x1){if(!_0x81a813['key']){this['forAllChangedKeys']((_0x1ae6b5,_0x56f1e2,_0x24b7bd)=>{this['notifyListeners'](_0x1ae6b5,_0x24b7bd);});return;}const _0x1aea9d=_0x81a813['key'];_0x27e714?this['detachListener']():this['stopPolling']();const _0x143087=()=>{const _0x1f0b79=this['storage']['getItem'](_0x1aea9d);!_0x27e714&&this['localCache'][_0x1aea9d]===_0x1f0b79||this['notifyListeners'](_0x1aea9d,_0x1f0b79);},_0x51e5c6=this['storage']['getItem'](_0x1aea9d);If()&&_0x51e5c6!==_0x81a813['newValue']&&_0x81a813['newValue']!==_0x81a813['oldValue']?setTimeout(_0x143087,Zf):_0x143087();}['notifyListeners'](_0x14abdf,_0x361d07){this['localCache'][_0x14abdf]=_0x361d07;const _0x10f057=this['listeners'][_0x14abdf];if(_0x10f057){for(const _0x52c871 of Array['from'](_0x10f057))_0x52c871(_0x361d07&&JSON['parse'](_0x361d07));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x184464,_0x1cb5b9,_0x8bc1f0)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x184464,'oldValue':_0x1cb5b9,'newValue':_0x8bc1f0}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x175eaa,_0x2981a0){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x175eaa]||(this['listeners'][_0x175eaa]=new Set(),this['localCache'][_0x175eaa]=this['storage']['getItem'](_0x175eaa)),this['listeners'][_0x175eaa]['add'](_0x2981a0);}['_removeListener'](_0x29445a,_0x59608a){this['listeners'][_0x29445a]&&(this['listeners'][_0x29445a]['delete'](_0x59608a),this['listeners'][_0x29445a]['size']===0x0&&delete this['listeners'][_0x29445a]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x259f29,_0x564e03){await super['_set'](_0x259f29,_0x564e03),this['localCache'][_0x259f29]=JSON['stringify'](_0x564e03);}async['_get'](_0x47b9b9){const _0xbf6894=await super['_get'](_0x47b9b9);return this['localCache'][_0x47b9b9]=JSON['stringify'](_0xbf6894),_0xbf6894;}async['_remove'](_0xf8737d){await super['_remove'](_0xf8737d),delete this['localCache'][_0xf8737d];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x10961b,_0x5f5800){}['_removeListener'](_0x5654da,_0x27b5dd){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0xdfff9d){return Promise['all'](_0xdfff9d['map'](async _0x33e185=>{try{return{'fulfilled':!0x0,'value':await _0x33e185};}catch(_0x42e07f){return{'fulfilled':!0x1,'reason':_0x42e07f};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x17d3f4){this['eventTarget']=_0x17d3f4,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x16336d){const _0x1348aa=this['receivers']['find'](_0x24fd61=>_0x24fd61['isListeningto'](_0x16336d));if(_0x1348aa)return _0x1348aa;const _0x556892=new jn(_0x16336d);return this['receivers']['push'](_0x556892),_0x556892;}['isListeningto'](_0x328cd0){return this['eventTarget']===_0x328cd0;}async['handleEvent'](_0xc429ce){const _0x2fa29a=_0xc429ce,{eventId:_0x355f2c,eventType:_0x4974fe,data:_0x3ce27f}=_0x2fa29a['data'],_0x12064f=this['handlersMap'][_0x4974fe];if(!(_0x12064f!=null&&_0x12064f['size']))return;_0x2fa29a['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x355f2c,'eventType':_0x4974fe});const _0x146372=Array['from'](_0x12064f)['map'](async _0x4bf0b1=>_0x4bf0b1(_0x2fa29a['origin'],_0x3ce27f)),_0xb5a731=await tp(_0x146372);_0x2fa29a['ports'][0x0]['postMessage']({'status':'done','eventId':_0x355f2c,'eventType':_0x4974fe,'response':_0xb5a731});}['_subscribe'](_0x7a043,_0x5f3742){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x7a043]||(this['handlersMap'][_0x7a043]=new Set()),this['handlersMap'][_0x7a043]['add'](_0x5f3742);}['_unsubscribe'](_0x512964,_0x22e1db){this['handlersMap'][_0x512964]&&_0x22e1db&&this['handlersMap'][_0x512964]['delete'](_0x22e1db),(!_0x22e1db||this['handlersMap'][_0x512964]['size']===0x0)&&delete this['handlersMap'][_0x512964],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x52f7f1='',_0x1fb54f=0xa){let _0x4023b0='';for(let _0x2cc8af=0x0;_0x2cc8af<_0x1fb54f;_0x2cc8af++)_0x4023b0+=Math['floor'](Math['random']()*0xa);return _0x52f7f1+_0x4023b0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0xaf7524){this['target']=_0xaf7524,this['handlers']=new Set();}['removeMessageHandler'](_0x3f990b){_0x3f990b['messageChannel']&&(_0x3f990b['messageChannel']['port1']['removeEventListener']('message',_0x3f990b['onMessage']),_0x3f990b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3f990b);}async['_send'](_0x1af6b3,_0x16188f,_0x53677c=0x32){const _0x1031b7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1031b7)throw new Error('connection_unavailable');let _0x4861,_0x16e04e;return new Promise((_0x25c612,_0x44db33)=>{const _0x19e03b=bs('',0x14);_0x1031b7['port1']['start']();const _0x2c291a=setTimeout(()=>{_0x44db33(new Error('unsupported_event'));},_0x53677c);_0x16e04e={'messageChannel':_0x1031b7,'onMessage'(_0x194775){const _0x55e846=_0x194775;if(_0x55e846['data']['eventId']===_0x19e03b)switch(_0x55e846['data']['status']){case'ack':clearTimeout(_0x2c291a),_0x4861=setTimeout(()=>{_0x44db33(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4861),_0x25c612(_0x55e846['data']['response']);break;default:clearTimeout(_0x2c291a),clearTimeout(_0x4861),_0x44db33(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x16e04e),_0x1031b7['port1']['addEventListener']('message',_0x16e04e['onMessage']),this['target']['postMessage']({'eventType':_0x1af6b3,'eventId':_0x19e03b,'data':_0x16188f},[_0x1031b7['port2']]);})['finally'](()=>{_0x16e04e&&this['removeMessageHandler'](_0x16e04e);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x16ac6e){X()['location']['href']=_0x16ac6e;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x3dd8d1;return((_0x3dd8d1=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3dd8d1['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x52542e){this['request']=_0x52542e;}['toPromise'](){return new Promise((_0x429db3,_0x6b6588)=>{this['request']['addEventListener']('success',()=>{_0x429db3(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x6b6588(this['request']['error']);});});}}function Kn(_0xebe8cc,_0x1462aa){return _0xebe8cc['transaction']([kn],_0x1462aa?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3726c3=indexedDB['deleteDatabase'](qa);return new Jt(_0x3726c3)['toPromise']();}function ja(){const _0x4cb80e=indexedDB['open'](qa,ap);return new Promise((_0x5b2696,_0x3edd64)=>{_0x4cb80e['addEventListener']('error',()=>{_0x3edd64(_0x4cb80e['error']);}),_0x4cb80e['addEventListener']('upgradeneeded',()=>{const _0x4fb644=_0x4cb80e['result'];try{_0x4fb644['createObjectStore'](kn,{'keyPath':za});}catch(_0x258dcf){_0x3edd64(_0x258dcf);}}),_0x4cb80e['addEventListener']('success',async()=>{const _0x5e5d3e=_0x4cb80e['result'];_0x5e5d3e['objectStoreNames']['contains'](kn)?_0x5b2696(_0x5e5d3e):(_0x5e5d3e['close'](),await cp(),_0x5b2696(await ja()));});});}async function kr(_0xb18dc1,_0x51aeb8,_0x586945){const _0xfbef46=Kn(_0xb18dc1,!0x0)['put']({[za]:_0x51aeb8,'value':_0x586945});return new Jt(_0xfbef46)['toPromise']();}async function lp(_0x3611c7,_0x5f123d){const _0x42a5a3=Kn(_0x3611c7,!0x1)['get'](_0x5f123d),_0x1bab70=await new Jt(_0x42a5a3)['toPromise']();return _0x1bab70===void 0x0?null:_0x1bab70['value'];}function Nr(_0x50c217,_0x12609d){const _0xcda0b0=Kn(_0x50c217,!0x0)['delete'](_0x12609d);return new Jt(_0xcda0b0)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x183bd1){let _0x23dace=0x0;for(;;)try{const _0x37dd49=await this['_openDb']();return await _0x183bd1(_0x37dd49);}catch(_0x30a8b8){if(_0x23dace++>up)throw _0x30a8b8;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x1a94eb,_0x15b180)=>({'keyProcessed':(await this['_poll']())['includes'](_0x15b180['key'])})),this['receiver']['_subscribe']('ping',async(_0x48ac85,_0x3f02f6)=>['keyChanged']);}async['initializeSender'](){var _0x1f0e74,_0x33fc25;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x4493bd=await this['sender']['_send']('ping',{},0x320);_0x4493bd&&(_0x1f0e74=_0x4493bd[0x0])!=null&&_0x1f0e74['fulfilled']&&(_0x33fc25=_0x4493bd[0x0])!=null&&_0x33fc25['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x20ab8e){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x20ab8e},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x60ed9a=>{await kr(_0x60ed9a,An,'1'),await Nr(_0x60ed9a,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x169fac){this['pendingWrites']++;try{await _0x169fac();}finally{this['pendingWrites']--;}}async['_set'](_0x4ca7c8,_0x22f1c6){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x66edf1=>kr(_0x66edf1,_0x4ca7c8,_0x22f1c6)),this['localCache'][_0x4ca7c8]=_0x22f1c6,this['notifyServiceWorker'](_0x4ca7c8)));}async['_get'](_0x444014){const _0x2a5647=await this['_withRetries'](_0x2c62d5=>lp(_0x2c62d5,_0x444014));return this['localCache'][_0x444014]=_0x2a5647,_0x2a5647;}async['_remove'](_0x35a7f7){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4034d5=>Nr(_0x4034d5,_0x35a7f7)),delete this['localCache'][_0x35a7f7],this['notifyServiceWorker'](_0x35a7f7)));}async['_poll'](){const _0x3cc351=await this['_withRetries'](_0x44ddd9=>{const _0x337308=Kn(_0x44ddd9,!0x1)['getAll']();return new Jt(_0x337308)['toPromise']();});if(!_0x3cc351)return[];if(this['pendingWrites']!==0x0)return[];const _0x5a4dc6=[],_0x524f05=new Set();if(_0x3cc351['length']!==0x0){for(const {fbase_key:_0xfc2f04,value:_0x5f4068}of _0x3cc351)_0x524f05['add'](_0xfc2f04),JSON['stringify'](this['localCache'][_0xfc2f04])!==JSON['stringify'](_0x5f4068)&&(this['notifyListeners'](_0xfc2f04,_0x5f4068),_0x5a4dc6['push'](_0xfc2f04));}for(const _0x40a2e3 of Object['keys'](this['localCache']))this['localCache'][_0x40a2e3]&&!_0x524f05['has'](_0x40a2e3)&&(this['notifyListeners'](_0x40a2e3,null),_0x5a4dc6['push'](_0x40a2e3));return _0x5a4dc6;}['notifyListeners'](_0x5466b9,_0x37f797){this['localCache'][_0x5466b9]=_0x37f797;const _0x2f8aaf=this['listeners'][_0x5466b9];if(_0x2f8aaf){for(const _0xf2c6a9 of Array['from'](_0x2f8aaf))_0xf2c6a9(_0x37f797);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xd03766,_0x39a39e){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xd03766]||(this['listeners'][_0xd03766]=new Set(),this['_get'](_0xd03766)),this['listeners'][_0xd03766]['add'](_0x39a39e);}['_removeListener'](_0xc64e55,_0x2c58ce){this['listeners'][_0xc64e55]&&(this['listeners'][_0xc64e55]['delete'](_0x2c58ce),this['listeners'][_0xc64e55]['size']===0x0&&delete this['listeners'][_0xc64e55]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x3473ab,_0x25b46f){return _0x25b46f?ne(_0x25b46f):(m(_0x3473ab['_popupRedirectResolver'],_0x3473ab,'argument-error'),_0x3473ab['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x41ab4a){super('custom','custom'),this['params']=_0x41ab4a;}['_getIdTokenResponse'](_0x19ff94){return Ze(_0x19ff94,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4e6fda,_0x21bd51){return Ze(_0x4e6fda,this['_buildIdpRequest'](_0x21bd51));}['_getReauthenticationResolver'](_0xbd192d){return Ze(_0xbd192d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5d62bf){const _0x172727={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5d62bf&&(_0x172727['idToken']=_0x5d62bf),_0x172727;}}function pp(_0x7a1b2c){return Ua(_0x7a1b2c['auth'],new Rs(_0x7a1b2c),_0x7a1b2c['bypassAuthState']);}function _p(_0x46286f){const {auth:_0x5ed696,user:_0x1c94d7}=_0x46286f;return m(_0x1c94d7,_0x5ed696,'internal-error'),Kf(_0x1c94d7,new Rs(_0x46286f),_0x46286f['bypassAuthState']);}async function gp(_0x585ecc){const {auth:_0x5a8214,user:_0x810400}=_0x585ecc;return m(_0x810400,_0x5a8214,'internal-error'),jf(_0x810400,new Rs(_0x585ecc),_0x585ecc['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x3ad481,_0x33b979,_0x54eb61,_0x4e5e50,_0x19bb40=!0x1){this['auth']=_0x3ad481,this['resolver']=_0x54eb61,this['user']=_0x4e5e50,this['bypassAuthState']=_0x19bb40,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x33b979)?_0x33b979:[_0x33b979];}['execute'](){return new Promise(async(_0x239bb4,_0x3344f6)=>{this['pendingPromise']={'resolve':_0x239bb4,'reject':_0x3344f6};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5b95d0){this['reject'](_0x5b95d0);}});}async['onAuthEvent'](_0x5dad5d){const {urlResponse:_0x5d4199,sessionId:_0x57a741,postBody:_0x32e994,tenantId:_0xa891c5,error:_0x18d4da,type:_0x4ae2fd}=_0x5dad5d;if(_0x18d4da){this['reject'](_0x18d4da);return;}const _0x1a0185={'auth':this['auth'],'requestUri':_0x5d4199,'sessionId':_0x57a741,'tenantId':_0xa891c5||void 0x0,'postBody':_0x32e994||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4ae2fd)(_0x1a0185));}catch(_0x1f9c4f){this['reject'](_0x1f9c4f);}}['onError'](_0x37c2de){this['reject'](_0x37c2de);}['getIdpTask'](_0x5c7fc1){switch(_0x5c7fc1){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x4fd792){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4fd792),this['unregisterAndCleanUp']();}['reject'](_0x43d187){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x43d187),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x5dee55,_0x51044b,_0x336000,_0xc5ee55,_0x30d583){super(_0x5dee55,_0x51044b,_0xc5ee55,_0x30d583),this['provider']=_0x336000,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x625526=await this['execute']();return m(_0x625526,this['auth'],'internal-error'),_0x625526;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5414d3=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5414d3),this['authWindow']['associatedEvent']=_0x5414d3,this['resolver']['_originValidation'](this['auth'])['catch'](_0x8b6d17=>{this['reject'](_0x8b6d17);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3c9dcf=>{_0x3c9dcf||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2756b4;return((_0x2756b4=this['authWindow'])==null?void 0x0:_0x2756b4['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1a8ba0=()=>{var _0xb69e64,_0x495e72;if((_0x495e72=(_0xb69e64=this['authWindow'])==null?void 0x0:_0xb69e64['window'])!=null&&_0x495e72['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1a8ba0,mp['get']());};_0x1a8ba0();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x589495,_0x110fbd,_0x5b6f21=!0x1){super(_0x589495,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x110fbd,void 0x0,_0x5b6f21),this['eventId']=null;}async['execute'](){let _0x380d72=rn['get'](this['auth']['_key']());if(!_0x380d72){try{const _0x5ced0b=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x380d72=()=>Promise['resolve'](_0x5ced0b);}catch(_0x10cdea){_0x380d72=()=>Promise['reject'](_0x10cdea);}rn['set'](this['auth']['_key'](),_0x380d72);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x380d72();}async['onAuthEvent'](_0x44d6bb){if(_0x44d6bb['type']==='signInViaRedirect')return super['onAuthEvent'](_0x44d6bb);if(_0x44d6bb['type']==='unknown'){this['resolve'](null);return;}if(_0x44d6bb['eventId']){const _0x558840=await this['auth']['_redirectUserForId'](_0x44d6bb['eventId']);if(_0x558840)return this['user']=_0x558840,super['onAuthEvent'](_0x44d6bb);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x2997a9,_0x510d6d){const _0x16ace2=Cp(_0x510d6d),_0x445592=wp(_0x2997a9);if(!await _0x445592['_isAvailable']())return!0x1;const _0x485f71=await _0x445592['_get'](_0x16ace2)==='true';return await _0x445592['_remove'](_0x16ace2),_0x485f71;}function Ip(_0xf4302,_0x1e89cb){rn['set'](_0xf4302['_key'](),_0x1e89cb);}function wp(_0x5a2508){return ne(_0x5a2508['_redirectPersistence']);}function Cp(_0x39f115){return sn(yp,_0x39f115['config']['apiKey'],_0x39f115['name']);}async function Tp(_0x2e5517,_0x5b4852,_0x15bf3e=!0x1){if(H(_0x2e5517['app']))return Promise['reject'](se(_0x2e5517));const _0x417949=qe(_0x2e5517),_0x34f1f7=fp(_0x417949,_0x5b4852),_0x53c74b=await new vp(_0x417949,_0x34f1f7,_0x15bf3e)['execute']();return _0x53c74b&&!_0x15bf3e&&(delete _0x53c74b['user']['_redirectEventId'],await _0x417949['_persistUserIfCurrent'](_0x53c74b['user']),await _0x417949['_setRedirectUser'](null,_0x5b4852)),_0x53c74b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x489d5a){this['auth']=_0x489d5a,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3de279){this['consumers']['add'](_0x3de279),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3de279)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3de279),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5193d8){this['consumers']['delete'](_0x5193d8);}['onEvent'](_0x1faeda){if(this['hasEventBeenHandled'](_0x1faeda))return!0x1;let _0x33508d=!0x1;return this['consumers']['forEach'](_0x4cb2f6=>{this['isEventForConsumer'](_0x1faeda,_0x4cb2f6)&&(_0x33508d=!0x0,this['sendToConsumer'](_0x1faeda,_0x4cb2f6),this['saveEventToCache'](_0x1faeda));}),this['hasHandledPotentialRedirect']||!Rp(_0x1faeda)||(this['hasHandledPotentialRedirect']=!0x0,_0x33508d||(this['queuedRedirectEvent']=_0x1faeda,_0x33508d=!0x0)),_0x33508d;}['sendToConsumer'](_0x5c0a68,_0x557c70){var _0x36b67e;if(_0x5c0a68['error']&&!Qa(_0x5c0a68)){const _0x1bc932=((_0x36b67e=_0x5c0a68['error']['code'])==null?void 0x0:_0x36b67e['split']('auth/')[0x1])||'internal-error';_0x557c70['onError'](J(this['auth'],_0x1bc932));}else _0x557c70['onAuthEvent'](_0x5c0a68);}['isEventForConsumer'](_0x157e39,_0x4c0f2b){const _0x3fb494=_0x4c0f2b['eventId']===null||!!_0x157e39['eventId']&&_0x157e39['eventId']===_0x4c0f2b['eventId'];return _0x4c0f2b['filter']['includes'](_0x157e39['type'])&&_0x3fb494;}['hasEventBeenHandled'](_0x8bb8e5){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x8bb8e5));}['saveEventToCache'](_0x53b8a6){this['cachedEventUids']['add'](Pr(_0x53b8a6)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x23653a){return[_0x23653a['type'],_0x23653a['eventId'],_0x23653a['sessionId'],_0x23653a['tenantId']]['filter'](_0x1f9ab6=>_0x1f9ab6)['join']('-');}function Qa({type:_0xff0d8e,error:_0x4b2b9b}){return _0xff0d8e==='unknown'&&(_0x4b2b9b==null?void 0x0:_0x4b2b9b['code'])==='auth/no-auth-event';}function Rp(_0x4c0394){switch(_0x4c0394['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x4c0394);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x5ccc5e,_0x2a3b02={}){return Ae(_0x5ccc5e,'GET','/v1/projects',_0x2a3b02);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x299647){if(_0x299647['config']['emulator'])return;const {authorizedDomains:_0x26c863}=await Ap(_0x299647);for(const _0x1e296a of _0x26c863)try{if(Op(_0x1e296a))return;}catch{}K(_0x299647,'unauthorized-domain');}function Op(_0x13e400){const _0x55c40e=Ni(),{protocol:_0x33d384,hostname:_0x3ce086}=new URL(_0x55c40e);if(_0x13e400['startsWith']('chrome-extension://')){const _0x362a39=new URL(_0x13e400);return _0x362a39['hostname']===''&&_0x3ce086===''?_0x33d384==='chrome-extension:'&&_0x13e400['replace']('chrome-extension://','')===_0x55c40e['replace']('chrome-extension://',''):_0x33d384==='chrome-extension:'&&_0x362a39['hostname']===_0x3ce086;}if(!Np['test'](_0x33d384))return!0x1;if(kp['test'](_0x13e400))return _0x3ce086===_0x13e400;const _0x45887a=_0x13e400['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x45887a+'|'+_0x45887a+')$','i')['test'](_0x3ce086);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x2a5a2e=X()['___jsl'];if(_0x2a5a2e!=null&&_0x2a5a2e['H']){for(const _0x59d98a of Object['keys'](_0x2a5a2e['H']))if(_0x2a5a2e['H'][_0x59d98a]['r']=_0x2a5a2e['H'][_0x59d98a]['r']||[],_0x2a5a2e['H'][_0x59d98a]['L']=_0x2a5a2e['H'][_0x59d98a]['L']||[],_0x2a5a2e['H'][_0x59d98a]['r']=[..._0x2a5a2e['H'][_0x59d98a]['L']],_0x2a5a2e['CP']){for(let _0x287ff5=0x0;_0x287ff5<_0x2a5a2e['CP']['length'];_0x287ff5++)_0x2a5a2e['CP'][_0x287ff5]=null;}}}function Mp(_0x27dc3a){return new Promise((_0x36fed9,_0x282af5)=>{var _0x30540b,_0x21897f,_0x3b0ffd;function _0x3f332f(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x36fed9(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x282af5(J(_0x27dc3a,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x21897f=(_0x30540b=X()['gapi'])==null?void 0x0:_0x30540b['iframes'])!=null&&_0x21897f['Iframe'])_0x36fed9(gapi['iframes']['getContext']());else{if((_0x3b0ffd=X()['gapi'])!=null&&_0x3b0ffd['load'])_0x3f332f();else{const _0x4e136b=Nf('iframefcb');return X()[_0x4e136b]=()=>{gapi['load']?_0x3f332f():_0x282af5(J(_0x27dc3a,'network-request-failed'));},Da(kf()+'?onload='+_0x4e136b)['catch'](_0x171cbe=>_0x282af5(_0x171cbe));}}})['catch'](_0x5ecbfa=>{throw on=null,_0x5ecbfa;});}let on=null;function Lp(_0x334e42){return on=on||Mp(_0x334e42),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x276ec0){const _0x481efb=_0x276ec0['config'];m(_0x481efb['authDomain'],_0x276ec0,'auth-domain-config-required');const _0x117dc9=_0x481efb['emulator']?Is(_0x481efb,Up):'https://'+_0x276ec0['config']['authDomain']+'/'+Fp,_0x4c6080={'apiKey':_0x481efb['apiKey'],'appName':_0x276ec0['name'],'v':ct},_0x3b89ba=Bp['get'](_0x276ec0['config']['apiHost']);_0x3b89ba&&(_0x4c6080['eid']=_0x3b89ba);const _0x5525f0=_0x276ec0['_getFrameworks']();return _0x5525f0['length']&&(_0x4c6080['fw']=_0x5525f0['join'](',')),_0x117dc9+'?'+at(_0x4c6080)['slice'](0x1);}async function Hp(_0x258fc5){const _0x1742b6=await Lp(_0x258fc5),_0x4104f0=X()['gapi'];return m(_0x4104f0,_0x258fc5,'internal-error'),_0x1742b6['open']({'where':document['body'],'url':Vp(_0x258fc5),'messageHandlersFilter':_0x4104f0['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x29a15d=>new Promise(async(_0x21f1e2,_0x30ec98)=>{await _0x29a15d['restyle']({'setHideOnLeave':!0x1});const _0x3261c6=J(_0x258fc5,'network-request-failed'),_0xa904c9=X()['setTimeout'](()=>{_0x30ec98(_0x3261c6);},xp['get']());function _0x2eddf3(){X()['clearTimeout'](_0xa904c9),_0x21f1e2(_0x29a15d);}_0x29a15d['ping'](_0x2eddf3)['then'](_0x2eddf3,()=>{_0x30ec98(_0x3261c6);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x5eef72){this['window']=_0x5eef72,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x2a6996,_0x387b3d,_0x4cd12c,_0x1682a9=Gp,_0x3e8961=qp){const _0x31eef9=Math['max']((window['screen']['availHeight']-_0x3e8961)/0x2,0x0)['toString'](),_0x31ae32=Math['max']((window['screen']['availWidth']-_0x1682a9)/0x2,0x0)['toString']();let _0x297428='';const _0x1d6091={...$p,'width':_0x1682a9['toString'](),'height':_0x3e8961['toString'](),'top':_0x31eef9,'left':_0x31ae32},_0x1570a2=W()['toLowerCase']();_0x4cd12c&&(_0x297428=ba(_0x1570a2)?zp:_0x4cd12c),Ta(_0x1570a2)&&(_0x387b3d=_0x387b3d||jp,_0x1d6091['scrollbars']='yes');const _0x4925fe=Object['entries'](_0x1d6091)['reduce']((_0x4b2122,[_0x3e1c56,_0x5d4e1f])=>''+_0x4b2122+_0x3e1c56+'='+_0x5d4e1f+',','');if(Ef(_0x1570a2)&&_0x297428!=='_self')return Yp(_0x387b3d||'',_0x297428),new Dr(null);const _0x388859=window['open'](_0x387b3d||'',_0x297428,_0x4925fe);m(_0x388859,_0x2a6996,'popup-blocked');try{_0x388859['focus']();}catch{}return new Dr(_0x388859);}function Yp(_0x4e881a,_0x37e574){const _0x14fb4e=document['createElement']('a');_0x14fb4e['href']=_0x4e881a,_0x14fb4e['target']=_0x37e574;const _0x273d90=document['createEvent']('MouseEvent');_0x273d90['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x14fb4e['dispatchEvent'](_0x273d90);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x33a5fc,_0x43e77a,_0xf634c4,_0x19187b,_0x63e56d,_0x43a0db){m(_0x33a5fc['config']['authDomain'],_0x33a5fc,'auth-domain-config-required'),m(_0x33a5fc['config']['apiKey'],_0x33a5fc,'invalid-api-key');const _0x16d37b={'apiKey':_0x33a5fc['config']['apiKey'],'appName':_0x33a5fc['name'],'authType':_0xf634c4,'redirectUrl':_0x19187b,'v':ct,'eventId':_0x63e56d};if(_0x43e77a instanceof xa){_0x43e77a['setDefaultLanguage'](_0x33a5fc['languageCode']),_0x16d37b['providerId']=_0x43e77a['providerId']||'',hi(_0x43e77a['getCustomParameters']())||(_0x16d37b['customParameters']=JSON['stringify'](_0x43e77a['getCustomParameters']()));for(const [_0x56d36c,_0x216dbd]of Object['entries']({}))_0x16d37b[_0x56d36c]=_0x216dbd;}if(_0x43e77a instanceof Qt){const _0xa564cd=_0x43e77a['getScopes']()['filter'](_0x432cc4=>_0x432cc4!=='');_0xa564cd['length']>0x0&&(_0x16d37b['scopes']=_0xa564cd['join'](','));}_0x33a5fc['tenantId']&&(_0x16d37b['tid']=_0x33a5fc['tenantId']);const _0x54c267=_0x16d37b;for(const _0x2d3045 of Object['keys'](_0x54c267))_0x54c267[_0x2d3045]===void 0x0&&delete _0x54c267[_0x2d3045];const _0x375e08=await _0x33a5fc['_getAppCheckToken'](),_0x141163=_0x375e08?'#'+Xp+'='+encodeURIComponent(_0x375e08):'';return Zp(_0x33a5fc)+'?'+at(_0x54c267)['slice'](0x1)+_0x141163;}function Zp({config:_0x1f318f}){return _0x1f318f['emulator']?Is(_0x1f318f,Jp):'https://'+_0x1f318f['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x28aca8,_0x116ced,_0x5c1c05,_0x2befbc){var _0x457b87;ae((_0x457b87=this['eventManagers'][_0x28aca8['_key']()])==null?void 0x0:_0x457b87['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x538653=await Mr(_0x28aca8,_0x116ced,_0x5c1c05,Ni(),_0x2befbc);return Kp(_0x28aca8,_0x538653,bs());}async['_openRedirect'](_0x5f57bd,_0x306cab,_0x3a6cf4,_0x11791a){await this['_originValidation'](_0x5f57bd);const _0x54168f=await Mr(_0x5f57bd,_0x306cab,_0x3a6cf4,Ni(),_0x11791a);return ip(_0x54168f),new Promise(()=>{});}['_initialize'](_0x37b9fb){const _0x39c141=_0x37b9fb['_key']();if(this['eventManagers'][_0x39c141]){const {manager:_0x4c8763,promise:_0x4443e8}=this['eventManagers'][_0x39c141];return _0x4c8763?Promise['resolve'](_0x4c8763):(ae(_0x4443e8,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4443e8);}const _0xc3beb6=this['initAndGetManager'](_0x37b9fb);return this['eventManagers'][_0x39c141]={'promise':_0xc3beb6},_0xc3beb6['catch'](()=>{delete this['eventManagers'][_0x39c141];}),_0xc3beb6;}async['initAndGetManager'](_0x293b41){const _0x526e7d=await Hp(_0x293b41),_0x4f97bb=new bp(_0x293b41);return _0x526e7d['register']('authEvent',_0x1d248d=>(m(_0x1d248d==null?void 0x0:_0x1d248d['authEvent'],_0x293b41,'invalid-auth-event'),{'status':_0x4f97bb['onEvent'](_0x1d248d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x293b41['_key']()]={'manager':_0x4f97bb},this['iframes'][_0x293b41['_key']()]=_0x526e7d,_0x4f97bb;}['_isIframeWebStorageSupported'](_0x42ded0,_0x2ae498){this['iframes'][_0x42ded0['_key']()]['send'](li,{'type':li},_0x146f07=>{var _0x126edc;const _0x4d420f=(_0x126edc=_0x146f07==null?void 0x0:_0x146f07[0x0])==null?void 0x0:_0x126edc[li];_0x4d420f!==void 0x0&&_0x2ae498(!!_0x4d420f),K(_0x42ded0,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x806b0e){const _0x3f1849=_0x806b0e['_key']();return this['originValidationPromises'][_0x3f1849]||(this['originValidationPromises'][_0x3f1849]=Pp(_0x806b0e)),this['originValidationPromises'][_0x3f1849];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x307c91){this['auth']=_0x307c91,this['internalListeners']=new Map();}['getUid'](){var _0x24d177;return this['assertAuthConfigured'](),((_0x24d177=this['auth']['currentUser'])==null?void 0x0:_0x24d177['uid'])||null;}async['getToken'](_0x144eed){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x144eed)}:null;}['addAuthTokenListener'](_0x4bf276){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4bf276))return;const _0x463028=this['auth']['onIdTokenChanged'](_0x3a1f8a=>{_0x4bf276((_0x3a1f8a==null?void 0x0:_0x3a1f8a['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4bf276,_0x463028),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xe1dca5){this['assertAuthConfigured']();const _0x339d3c=this['internalListeners']['get'](_0xe1dca5);_0x339d3c&&(this['internalListeners']['delete'](_0xe1dca5),_0x339d3c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5abca3){switch(_0x5abca3){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x5dba86){et(new Me('auth',(_0x390b65,{options:_0x14f29b})=>{const _0x3bd8d7=_0x390b65['getProvider']('app')['getImmediate'](),_0x25bf7d=_0x390b65['getProvider']('heartbeat'),_0x64fb04=_0x390b65['getProvider']('app-check-internal'),{apiKey:_0x455689,authDomain:_0x3b47b1}=_0x3bd8d7['options'];m(_0x455689&&!_0x455689['includes'](':'),'invalid-api-key',{'appName':_0x3bd8d7['name']});const _0x272b10={'apiKey':_0x455689,'authDomain':_0x3b47b1,'clientPlatform':_0x5dba86,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x5dba86)},_0x57c973=new bf(_0x3bd8d7,_0x25bf7d,_0x64fb04,_0x272b10);return Lf(_0x57c973,_0x14f29b),_0x57c973;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2a6e4a,_0x4df187,_0x5a1617)=>{_0x2a6e4a['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x537172=>{const _0x192737=qe(_0x537172['getProvider']('auth')['getImmediate']());return(_0x42a1d9=>new n_(_0x42a1d9))(_0x192737);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x5dba86)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x931699=>async _0x4ffa32=>{const _0x400e40=_0x4ffa32&&await _0x4ffa32['getIdTokenResult'](),_0x593c5e=_0x400e40&&(new Date()['getTime']()-Date['parse'](_0x400e40['issuedAtTime']))/0x3e8;if(_0x593c5e&&_0x593c5e>o_)return;const _0x210eb=_0x400e40==null?void 0x0:_0x400e40['token'];Fr!==_0x210eb&&(Fr=_0x210eb,await fetch(_0x931699,{'method':_0x210eb?'POST':'DELETE','headers':_0x210eb?{'Authorization':'Bearer\x20'+_0x210eb}:{}}));};function O_(_0x572dce=Qr()){const _0xe243ab=Ui(_0x572dce,'auth');if(_0xe243ab['isInitialized']())return _0xe243ab['getImmediate']();const _0xbd0e8c=Mf(_0x572dce,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x5b4318=Gr('authTokenSyncURL');if(_0x5b4318&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x33ee7e=new URL(_0x5b4318,location['origin']);if(location['origin']===_0x33ee7e['origin']){const _0x39b7d0=a_(_0x33ee7e['toString']());Jf(_0xbd0e8c,_0x39b7d0,()=>_0x39b7d0(_0xbd0e8c['currentUser'])),Qf(_0xbd0e8c,_0x25ea6b=>_0x39b7d0(_0x25ea6b));}}const _0x36fa05=Hr('auth');return _0x36fa05&&xf(_0xbd0e8c,'http://'+_0x36fa05),_0xbd0e8c;}function c_(){var _0x5975c9;return((_0x5975c9=document['getElementsByTagName']('head'))==null?void 0x0:_0x5975c9[0x0])??document;}Rf({'loadJS'(_0x13fa72){return new Promise((_0x119662,_0x171cda)=>{const _0x498ffe=document['createElement']('script');_0x498ffe['setAttribute']('src',_0x13fa72),_0x498ffe['onload']=_0x119662,_0x498ffe['onerror']=_0x108f4d=>{const _0x134891=J('internal-error');_0x134891['customData']=_0x108f4d,_0x171cda(_0x134891);},_0x498ffe['type']='text/javascript',_0x498ffe['charset']='UTF-8',c_()['appendChild'](_0x498ffe);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};