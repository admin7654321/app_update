const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x4d6286,_0x2c727a){if(!_0x4d6286)throw ot(_0x2c727a);},ot=function(_0x4b8c2e){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4b8c2e);},Wr=function(_0x275a23){const _0x37fb45=[];let _0x52057c=0x0;for(let _0x2bdca3=0x0;_0x2bdca3<_0x275a23['length'];_0x2bdca3++){let _0x9e30c0=_0x275a23['charCodeAt'](_0x2bdca3);_0x9e30c0<0x80?_0x37fb45[_0x52057c++]=_0x9e30c0:_0x9e30c0<0x800?(_0x37fb45[_0x52057c++]=_0x9e30c0>>0x6|0xc0,_0x37fb45[_0x52057c++]=_0x9e30c0&0x3f|0x80):(_0x9e30c0&0xfc00)===0xd800&&_0x2bdca3+0x1<_0x275a23['length']&&(_0x275a23['charCodeAt'](_0x2bdca3+0x1)&0xfc00)===0xdc00?(_0x9e30c0=0x10000+((_0x9e30c0&0x3ff)<<0xa)+(_0x275a23['charCodeAt'](++_0x2bdca3)&0x3ff),_0x37fb45[_0x52057c++]=_0x9e30c0>>0x12|0xf0,_0x37fb45[_0x52057c++]=_0x9e30c0>>0xc&0x3f|0x80,_0x37fb45[_0x52057c++]=_0x9e30c0>>0x6&0x3f|0x80,_0x37fb45[_0x52057c++]=_0x9e30c0&0x3f|0x80):(_0x37fb45[_0x52057c++]=_0x9e30c0>>0xc|0xe0,_0x37fb45[_0x52057c++]=_0x9e30c0>>0x6&0x3f|0x80,_0x37fb45[_0x52057c++]=_0x9e30c0&0x3f|0x80);}return _0x37fb45;},Za=function(_0x5d2387){const _0x118eec=[];let _0xc5065=0x0,_0x1f0fa3=0x0;for(;_0xc5065<_0x5d2387['length'];){const _0x2481b3=_0x5d2387[_0xc5065++];if(_0x2481b3<0x80)_0x118eec[_0x1f0fa3++]=String['fromCharCode'](_0x2481b3);else{if(_0x2481b3>0xbf&&_0x2481b3<0xe0){const _0x1de429=_0x5d2387[_0xc5065++];_0x118eec[_0x1f0fa3++]=String['fromCharCode']((_0x2481b3&0x1f)<<0x6|_0x1de429&0x3f);}else{if(_0x2481b3>0xef&&_0x2481b3<0x16d){const _0x4e7cfc=_0x5d2387[_0xc5065++],_0xfcc1a6=_0x5d2387[_0xc5065++],_0x15203a=_0x5d2387[_0xc5065++],_0x2214ec=((_0x2481b3&0x7)<<0x12|(_0x4e7cfc&0x3f)<<0xc|(_0xfcc1a6&0x3f)<<0x6|_0x15203a&0x3f)-0x10000;_0x118eec[_0x1f0fa3++]=String['fromCharCode'](0xd800+(_0x2214ec>>0xa)),_0x118eec[_0x1f0fa3++]=String['fromCharCode'](0xdc00+(_0x2214ec&0x3ff));}else{const _0xfc5748=_0x5d2387[_0xc5065++],_0x4a0a5f=_0x5d2387[_0xc5065++];_0x118eec[_0x1f0fa3++]=String['fromCharCode']((_0x2481b3&0xf)<<0xc|(_0xfc5748&0x3f)<<0x6|_0x4a0a5f&0x3f);}}}}return _0x118eec['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2673f0,_0x2b763b){if(!Array['isArray'](_0x2673f0))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x595b98=_0x2b763b?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4c0810=[];for(let _0x5bca5b=0x0;_0x5bca5b<_0x2673f0['length'];_0x5bca5b+=0x3){const _0x59ee48=_0x2673f0[_0x5bca5b],_0x50f776=_0x5bca5b+0x1<_0x2673f0['length'],_0x3e8176=_0x50f776?_0x2673f0[_0x5bca5b+0x1]:0x0,_0x239510=_0x5bca5b+0x2<_0x2673f0['length'],_0x4fec96=_0x239510?_0x2673f0[_0x5bca5b+0x2]:0x0,_0x4ff232=_0x59ee48>>0x2,_0x151f39=(_0x59ee48&0x3)<<0x4|_0x3e8176>>0x4;let _0x1a70c5=(_0x3e8176&0xf)<<0x2|_0x4fec96>>0x6,_0x5784ca=_0x4fec96&0x3f;_0x239510||(_0x5784ca=0x40,_0x50f776||(_0x1a70c5=0x40)),_0x4c0810['push'](_0x595b98[_0x4ff232],_0x595b98[_0x151f39],_0x595b98[_0x1a70c5],_0x595b98[_0x5784ca]);}return _0x4c0810['join']('');},'encodeString'(_0x170e3f,_0x10b5e9){return this['HAS_NATIVE_SUPPORT']&&!_0x10b5e9?btoa(_0x170e3f):this['encodeByteArray'](Wr(_0x170e3f),_0x10b5e9);},'decodeString'(_0xed921,_0x1e51b2){return this['HAS_NATIVE_SUPPORT']&&!_0x1e51b2?atob(_0xed921):Za(this['decodeStringToByteArray'](_0xed921,_0x1e51b2));},'decodeStringToByteArray'(_0x4b5bce,_0x129f89){this['init_']();const _0x34ae3a=_0x129f89?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4fff71=[];for(let _0x34874d=0x0;_0x34874d<_0x4b5bce['length'];){const _0x1f91e8=_0x34ae3a[_0x4b5bce['charAt'](_0x34874d++)],_0x387bbf=_0x34874d<_0x4b5bce['length']?_0x34ae3a[_0x4b5bce['charAt'](_0x34874d)]:0x0;++_0x34874d;const _0x33659f=_0x34874d<_0x4b5bce['length']?_0x34ae3a[_0x4b5bce['charAt'](_0x34874d)]:0x40;++_0x34874d;const _0x7ba521=_0x34874d<_0x4b5bce['length']?_0x34ae3a[_0x4b5bce['charAt'](_0x34874d)]:0x40;if(++_0x34874d,_0x1f91e8==null||_0x387bbf==null||_0x33659f==null||_0x7ba521==null)throw new ec();const _0x44ef08=_0x1f91e8<<0x2|_0x387bbf>>0x4;if(_0x4fff71['push'](_0x44ef08),_0x33659f!==0x40){const _0x524280=_0x387bbf<<0x4&0xf0|_0x33659f>>0x2;if(_0x4fff71['push'](_0x524280),_0x7ba521!==0x40){const _0x542998=_0x33659f<<0x6&0xc0|_0x7ba521;_0x4fff71['push'](_0x542998);}}}return _0x4fff71;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x55e22a=0x0;_0x55e22a<this['ENCODED_VALS']['length'];_0x55e22a++)this['byteToCharMap_'][_0x55e22a]=this['ENCODED_VALS']['charAt'](_0x55e22a),this['charToByteMap_'][this['byteToCharMap_'][_0x55e22a]]=_0x55e22a,this['byteToCharMapWebSafe_'][_0x55e22a]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x55e22a),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x55e22a]]=_0x55e22a,_0x55e22a>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x55e22a)]=_0x55e22a,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x55e22a)]=_0x55e22a);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x556435){const _0x18cf4e=Wr(_0x556435);return Di['encodeByteArray'](_0x18cf4e,!0x0);},an=function(_0x5a493d){return Br(_0x5a493d)['replace'](/\./g,'');},cn=function(_0x3b884e){try{return Di['decodeString'](_0x3b884e,!0x0);}catch(_0x11746a){console['error']('base64Decode\x20failed:\x20',_0x11746a);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x3cd2fd){return Vr(void 0x0,_0x3cd2fd);}function Vr(_0x3b7bc3,_0x30dfb4){if(!(_0x30dfb4 instanceof Object))return _0x30dfb4;switch(_0x30dfb4['constructor']){case Date:const _0x441490=_0x30dfb4;return new Date(_0x441490['getTime']());case Object:_0x3b7bc3===void 0x0&&(_0x3b7bc3={});break;case Array:_0x3b7bc3=[];break;default:return _0x30dfb4;}for(const _0x20be1c in _0x30dfb4)!_0x30dfb4['hasOwnProperty'](_0x20be1c)||!nc(_0x20be1c)||(_0x3b7bc3[_0x20be1c]=Vr(_0x3b7bc3[_0x20be1c],_0x30dfb4[_0x20be1c]));return _0x3b7bc3;}function nc(_0x38b107){return _0x38b107!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x435458=As['__FIREBASE_DEFAULTS__'];if(_0x435458)return JSON['parse'](_0x435458);},oc=()=>{if(typeof document>'u')return;let _0x5a4123;try{_0x5a4123=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xefabc7=_0x5a4123&&cn(_0x5a4123[0x1]);return _0xefabc7&&JSON['parse'](_0xefabc7);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x10829e){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x10829e);return;}},Hr=_0x37463a=>{var _0x4a2413,_0x12109;return(_0x12109=(_0x4a2413=Mi())==null?void 0x0:_0x4a2413['emulatorHosts'])==null?void 0x0:_0x12109[_0x37463a];},ac=_0x5778df=>{const _0x2eff5b=Hr(_0x5778df);if(!_0x2eff5b)return;const _0x345ac7=_0x2eff5b['lastIndexOf'](':');if(_0x345ac7<=0x0||_0x345ac7+0x1===_0x2eff5b['length'])throw new Error('Invalid\x20host\x20'+_0x2eff5b+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4203c3=parseInt(_0x2eff5b['substring'](_0x345ac7+0x1),0xa);return _0x2eff5b[0x0]==='['?[_0x2eff5b['substring'](0x1,_0x345ac7-0x1),_0x4203c3]:[_0x2eff5b['substring'](0x0,_0x345ac7),_0x4203c3];},$r=()=>{var _0x80b210;return(_0x80b210=Mi())==null?void 0x0:_0x80b210['config'];},Gr=_0x44752f=>{var _0x346af1;return(_0x346af1=Mi())==null?void 0x0:_0x346af1['_'+_0x44752f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x445474,_0x27ca95)=>{this['resolve']=_0x445474,this['reject']=_0x27ca95;});}['wrapCallback'](_0x469f88){return(_0x5ac731,_0x3f7102)=>{_0x5ac731?this['reject'](_0x5ac731):this['resolve'](_0x3f7102),typeof _0x469f88=='function'&&(this['promise']['catch'](()=>{}),_0x469f88['length']===0x1?_0x469f88(_0x5ac731):_0x469f88(_0x5ac731,_0x3f7102));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x4a50e2,_0x4b2f82){if(_0x4a50e2['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x14812b={'alg':'none','type':'JWT'},_0x53c39b=_0x4b2f82||'demo-project',_0x53288d=_0x4a50e2['iat']||0x0,_0x37577d=_0x4a50e2['sub']||_0x4a50e2['user_id'];if(!_0x37577d)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x68e30e={'iss':'https://securetoken.google.com/'+_0x53c39b,'aud':_0x53c39b,'iat':_0x53288d,'exp':_0x53288d+0xe10,'auth_time':_0x53288d,'sub':_0x37577d,'user_id':_0x37577d,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4a50e2};return[an(JSON['stringify'](_0x14812b)),an(JSON['stringify'](_0x68e30e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x3181b2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3181b2=='object'&&_0x3181b2['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x52c6f9=W();return _0x52c6f9['indexOf']('MSIE\x20')>=0x0||_0x52c6f9['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x585fd2,_0x232ea3)=>{try{let _0x35038c=!0x0;const _0x2d2dfc='validate-browser-context-for-indexeddb-analytics-module',_0x16f910=self['indexedDB']['open'](_0x2d2dfc);_0x16f910['onsuccess']=()=>{_0x16f910['result']['close'](),_0x35038c||self['indexedDB']['deleteDatabase'](_0x2d2dfc),_0x585fd2(!0x0);},_0x16f910['onupgradeneeded']=()=>{_0x35038c=!0x1;},_0x16f910['onerror']=()=>{var _0x31081c;_0x232ea3(((_0x31081c=_0x16f910['error'])==null?void 0x0:_0x31081c['message'])||'');};}catch(_0xfd5bdc){_0x232ea3(_0xfd5bdc);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x21e420,_0x4a1ec2,_0x283c80){super(_0x4a1ec2),this['code']=_0x21e420,this['customData']=_0x283c80,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x2b683c,_0x4d95d9,_0x981096){this['service']=_0x2b683c,this['serviceName']=_0x4d95d9,this['errors']=_0x981096;}['create'](_0x4275d6,..._0x514611){const _0x34e336=_0x514611[0x0]||{},_0x59cb58=this['service']+'/'+_0x4275d6,_0x11c9cb=this['errors'][_0x4275d6],_0x418300=_0x11c9cb?gc(_0x11c9cb,_0x34e336):'Error',_0x437a25=this['serviceName']+':\x20'+_0x418300+'\x20('+_0x59cb58+').';return new Se(_0x59cb58,_0x437a25,_0x34e336);}}function gc(_0x1f1b3c,_0x49e4d6){return _0x1f1b3c['replace'](mc,(_0x1a1d53,_0x30fbfd)=>{const _0x159e26=_0x49e4d6[_0x30fbfd];return _0x159e26!=null?String(_0x159e26):'<'+_0x30fbfd+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x508b78){return JSON['parse'](_0x508b78);}function O(_0x196295){return JSON['stringify'](_0x196295);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x37e5c1){let _0x3f2c83={},_0x195e79={},_0x46ed65={},_0x3f66e2='';try{const _0x3ebbc0=_0x37e5c1['split']('.');_0x3f2c83=bt(cn(_0x3ebbc0[0x0])||''),_0x195e79=bt(cn(_0x3ebbc0[0x1])||''),_0x3f66e2=_0x3ebbc0[0x2],_0x46ed65=_0x195e79['d']||{},delete _0x195e79['d'];}catch{}return{'header':_0x3f2c83,'claims':_0x195e79,'data':_0x46ed65,'signature':_0x3f66e2};},yc=function(_0x2e44e8){const _0x20a4c6=zr(_0x2e44e8),_0xda99e3=_0x20a4c6['claims'];return!!_0xda99e3&&typeof _0xda99e3=='object'&&_0xda99e3['hasOwnProperty']('iat');},vc=function(_0x52f6e0){const _0xe66ca6=zr(_0x52f6e0)['claims'];return typeof _0xe66ca6=='object'&&_0xe66ca6['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x45c26d,_0x5ede77){return Object['prototype']['hasOwnProperty']['call'](_0x45c26d,_0x5ede77);}function Oe(_0x26b2dd,_0x1784f1){if(Object['prototype']['hasOwnProperty']['call'](_0x26b2dd,_0x1784f1))return _0x26b2dd[_0x1784f1];}function hi(_0x191c52){for(const _0x5aa835 in _0x191c52)if(Object['prototype']['hasOwnProperty']['call'](_0x191c52,_0x5aa835))return!0x1;return!0x0;}function ln(_0x3e1c67,_0x29ff4c,_0x56d8e7){const _0x14432d={};for(const _0x43f9d9 in _0x3e1c67)Object['prototype']['hasOwnProperty']['call'](_0x3e1c67,_0x43f9d9)&&(_0x14432d[_0x43f9d9]=_0x29ff4c['call'](_0x56d8e7,_0x3e1c67[_0x43f9d9],_0x43f9d9,_0x3e1c67));return _0x14432d;}function De(_0x4c48f5,_0x5a59ef){if(_0x4c48f5===_0x5a59ef)return!0x0;const _0x543dc1=Object['keys'](_0x4c48f5),_0x14dc51=Object['keys'](_0x5a59ef);for(const _0x268420 of _0x543dc1){if(!_0x14dc51['includes'](_0x268420))return!0x1;const _0x46edc7=_0x4c48f5[_0x268420],_0x3ead36=_0x5a59ef[_0x268420];if(ks(_0x46edc7)&&ks(_0x3ead36)){if(!De(_0x46edc7,_0x3ead36))return!0x1;}else{if(_0x46edc7!==_0x3ead36)return!0x1;}}for(const _0x4865c5 of _0x14dc51)if(!_0x543dc1['includes'](_0x4865c5))return!0x1;return!0x0;}function ks(_0x2ff9c8){return _0x2ff9c8!==null&&typeof _0x2ff9c8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3ed0b9){const _0x2cd4b6=[];for(const [_0x184a66,_0x190bc7]of Object['entries'](_0x3ed0b9))Array['isArray'](_0x190bc7)?_0x190bc7['forEach'](_0x2053ca=>{_0x2cd4b6['push'](encodeURIComponent(_0x184a66)+'='+encodeURIComponent(_0x2053ca));}):_0x2cd4b6['push'](encodeURIComponent(_0x184a66)+'='+encodeURIComponent(_0x190bc7));return _0x2cd4b6['length']?'&'+_0x2cd4b6['join']('&'):'';}function yt(_0x2cd2a4){const _0x56d7e4={};return _0x2cd2a4['replace'](/^\?/,'')['split']('&')['forEach'](_0x225b10=>{if(_0x225b10){const [_0x57f358,_0xad91f6]=_0x225b10['split']('=');_0x56d7e4[decodeURIComponent(_0x57f358)]=decodeURIComponent(_0xad91f6);}}),_0x56d7e4;}function vt(_0x2cea90){const _0x18fd04=_0x2cea90['indexOf']('?');if(!_0x18fd04)return'';const _0x19ab2e=_0x2cea90['indexOf']('#',_0x18fd04);return _0x2cea90['substring'](_0x18fd04,_0x19ab2e>0x0?_0x19ab2e:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3c2750=0x1;_0x3c2750<this['blockSize'];++_0x3c2750)this['pad_'][_0x3c2750]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x22b846,_0x5582fe){_0x5582fe||(_0x5582fe=0x0);const _0x3088ee=this['W_'];if(typeof _0x22b846=='string'){for(let _0x5a6ebf=0x0;_0x5a6ebf<0x10;_0x5a6ebf++)_0x3088ee[_0x5a6ebf]=_0x22b846['charCodeAt'](_0x5582fe)<<0x18|_0x22b846['charCodeAt'](_0x5582fe+0x1)<<0x10|_0x22b846['charCodeAt'](_0x5582fe+0x2)<<0x8|_0x22b846['charCodeAt'](_0x5582fe+0x3),_0x5582fe+=0x4;}else{for(let _0xd0d87f=0x0;_0xd0d87f<0x10;_0xd0d87f++)_0x3088ee[_0xd0d87f]=_0x22b846[_0x5582fe]<<0x18|_0x22b846[_0x5582fe+0x1]<<0x10|_0x22b846[_0x5582fe+0x2]<<0x8|_0x22b846[_0x5582fe+0x3],_0x5582fe+=0x4;}for(let _0x4e9d29=0x10;_0x4e9d29<0x50;_0x4e9d29++){const _0x4ec479=_0x3088ee[_0x4e9d29-0x3]^_0x3088ee[_0x4e9d29-0x8]^_0x3088ee[_0x4e9d29-0xe]^_0x3088ee[_0x4e9d29-0x10];_0x3088ee[_0x4e9d29]=(_0x4ec479<<0x1|_0x4ec479>>>0x1f)&0xffffffff;}let _0x1046c3=this['chain_'][0x0],_0xc3380a=this['chain_'][0x1],_0x129d50=this['chain_'][0x2],_0x5e2c50=this['chain_'][0x3],_0x1cf566=this['chain_'][0x4],_0x29325e,_0x15ff10;for(let _0x214c23=0x0;_0x214c23<0x50;_0x214c23++){_0x214c23<0x28?_0x214c23<0x14?(_0x29325e=_0x5e2c50^_0xc3380a&(_0x129d50^_0x5e2c50),_0x15ff10=0x5a827999):(_0x29325e=_0xc3380a^_0x129d50^_0x5e2c50,_0x15ff10=0x6ed9eba1):_0x214c23<0x3c?(_0x29325e=_0xc3380a&_0x129d50|_0x5e2c50&(_0xc3380a|_0x129d50),_0x15ff10=0x8f1bbcdc):(_0x29325e=_0xc3380a^_0x129d50^_0x5e2c50,_0x15ff10=0xca62c1d6);const _0x27c514=(_0x1046c3<<0x5|_0x1046c3>>>0x1b)+_0x29325e+_0x1cf566+_0x15ff10+_0x3088ee[_0x214c23]&0xffffffff;_0x1cf566=_0x5e2c50,_0x5e2c50=_0x129d50,_0x129d50=(_0xc3380a<<0x1e|_0xc3380a>>>0x2)&0xffffffff,_0xc3380a=_0x1046c3,_0x1046c3=_0x27c514;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1046c3&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xc3380a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x129d50&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5e2c50&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1cf566&0xffffffff;}['update'](_0x48651b,_0x3cd22f){if(_0x48651b==null)return;_0x3cd22f===void 0x0&&(_0x3cd22f=_0x48651b['length']);const _0x2a2315=_0x3cd22f-this['blockSize'];let _0x49cefb=0x0;const _0x4312d6=this['buf_'];let _0x5c9915=this['inbuf_'];for(;_0x49cefb<_0x3cd22f;){if(_0x5c9915===0x0){for(;_0x49cefb<=_0x2a2315;)this['compress_'](_0x48651b,_0x49cefb),_0x49cefb+=this['blockSize'];}if(typeof _0x48651b=='string'){for(;_0x49cefb<_0x3cd22f;)if(_0x4312d6[_0x5c9915]=_0x48651b['charCodeAt'](_0x49cefb),++_0x5c9915,++_0x49cefb,_0x5c9915===this['blockSize']){this['compress_'](_0x4312d6),_0x5c9915=0x0;break;}}else{for(;_0x49cefb<_0x3cd22f;)if(_0x4312d6[_0x5c9915]=_0x48651b[_0x49cefb],++_0x5c9915,++_0x49cefb,_0x5c9915===this['blockSize']){this['compress_'](_0x4312d6),_0x5c9915=0x0;break;}}}this['inbuf_']=_0x5c9915,this['total_']+=_0x3cd22f;}['digest'](){const _0x19c279=[];let _0x2c9a6e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3fff7f=this['blockSize']-0x1;_0x3fff7f>=0x38;_0x3fff7f--)this['buf_'][_0x3fff7f]=_0x2c9a6e&0xff,_0x2c9a6e/=0x100;this['compress_'](this['buf_']);let _0xaae8a5=0x0;for(let _0x56dc39=0x0;_0x56dc39<0x5;_0x56dc39++)for(let _0x2dd3ee=0x18;_0x2dd3ee>=0x0;_0x2dd3ee-=0x8)_0x19c279[_0xaae8a5]=this['chain_'][_0x56dc39]>>_0x2dd3ee&0xff,++_0xaae8a5;return _0x19c279;}}function Ic(_0x570765,_0xdf0554){const _0x43733c=new wc(_0x570765,_0xdf0554);return _0x43733c['subscribe']['bind'](_0x43733c);}class wc{constructor(_0x680a9f,_0x22f0d6){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x22f0d6,this['task']['then'](()=>{_0x680a9f(this);})['catch'](_0x4b0c80=>{this['error'](_0x4b0c80);});}['next'](_0x55a5a0){this['forEachObserver'](_0x5c5320=>{_0x5c5320['next'](_0x55a5a0);});}['error'](_0xdbb374){this['forEachObserver'](_0x243ffe=>{_0x243ffe['error'](_0xdbb374);}),this['close'](_0xdbb374);}['complete'](){this['forEachObserver'](_0x5f1242=>{_0x5f1242['complete']();}),this['close']();}['subscribe'](_0x517bb9,_0x3b0c33,_0x86d45a){let _0x3f895d;if(_0x517bb9===void 0x0&&_0x3b0c33===void 0x0&&_0x86d45a===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x517bb9,['next','error','complete'])?_0x3f895d=_0x517bb9:_0x3f895d={'next':_0x517bb9,'error':_0x3b0c33,'complete':_0x86d45a},_0x3f895d['next']===void 0x0&&(_0x3f895d['next']=Qn),_0x3f895d['error']===void 0x0&&(_0x3f895d['error']=Qn),_0x3f895d['complete']===void 0x0&&(_0x3f895d['complete']=Qn);const _0x2952ba=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3f895d['error'](this['finalError']):_0x3f895d['complete']();}catch{}}),this['observers']['push'](_0x3f895d),_0x2952ba;}['unsubscribeOne'](_0x4c1cc7){this['observers']===void 0x0||this['observers'][_0x4c1cc7]===void 0x0||(delete this['observers'][_0x4c1cc7],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5909b3){if(!this['finalized']){for(let _0x79d6a2=0x0;_0x79d6a2<this['observers']['length'];_0x79d6a2++)this['sendOne'](_0x79d6a2,_0x5909b3);}}['sendOne'](_0x1ba6be,_0x5e0ffe){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1ba6be]!==void 0x0)try{_0x5e0ffe(this['observers'][_0x1ba6be]);}catch(_0x2ff5b8){typeof console<'u'&&console['error']&&console['error'](_0x2ff5b8);}});}['close'](_0x5bf9eb){this['finalized']||(this['finalized']=!0x0,_0x5bf9eb!==void 0x0&&(this['finalError']=_0x5bf9eb),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x46fc4e,_0x4158ba){if(typeof _0x46fc4e!='object'||_0x46fc4e===null)return!0x1;for(const _0x30c44c of _0x4158ba)if(_0x30c44c in _0x46fc4e&&typeof _0x46fc4e[_0x30c44c]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x57f0de,_0x45186b){return _0x57f0de+'\x20failed:\x20'+_0x45186b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x55e76a){const _0x220ca8=[];let _0x20764d=0x0;for(let _0x1db391=0x0;_0x1db391<_0x55e76a['length'];_0x1db391++){let _0xfef1ef=_0x55e76a['charCodeAt'](_0x1db391);if(_0xfef1ef>=0xd800&&_0xfef1ef<=0xdbff){const _0x1cba7f=_0xfef1ef-0xd800;_0x1db391++,f(_0x1db391<_0x55e76a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x41e25e=_0x55e76a['charCodeAt'](_0x1db391)-0xdc00;_0xfef1ef=0x10000+(_0x1cba7f<<0xa)+_0x41e25e;}_0xfef1ef<0x80?_0x220ca8[_0x20764d++]=_0xfef1ef:_0xfef1ef<0x800?(_0x220ca8[_0x20764d++]=_0xfef1ef>>0x6|0xc0,_0x220ca8[_0x20764d++]=_0xfef1ef&0x3f|0x80):_0xfef1ef<0x10000?(_0x220ca8[_0x20764d++]=_0xfef1ef>>0xc|0xe0,_0x220ca8[_0x20764d++]=_0xfef1ef>>0x6&0x3f|0x80,_0x220ca8[_0x20764d++]=_0xfef1ef&0x3f|0x80):(_0x220ca8[_0x20764d++]=_0xfef1ef>>0x12|0xf0,_0x220ca8[_0x20764d++]=_0xfef1ef>>0xc&0x3f|0x80,_0x220ca8[_0x20764d++]=_0xfef1ef>>0x6&0x3f|0x80,_0x220ca8[_0x20764d++]=_0xfef1ef&0x3f|0x80);}return _0x220ca8;},Pn=function(_0x4fc77f){let _0x1f94ae=0x0;for(let _0x33f01e=0x0;_0x33f01e<_0x4fc77f['length'];_0x33f01e++){const _0x18a017=_0x4fc77f['charCodeAt'](_0x33f01e);_0x18a017<0x80?_0x1f94ae++:_0x18a017<0x800?_0x1f94ae+=0x2:_0x18a017>=0xd800&&_0x18a017<=0xdbff?(_0x1f94ae+=0x4,_0x33f01e++):_0x1f94ae+=0x3;}return _0x1f94ae;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x5ea0e0){return _0x5ea0e0&&_0x5ea0e0['_delegate']?_0x5ea0e0['_delegate']:_0x5ea0e0;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x2961c1){try{return(_0x2961c1['startsWith']('http://')||_0x2961c1['startsWith']('https://')?new URL(_0x2961c1)['hostname']:_0x2961c1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x287248){return(await fetch(_0x287248,{'credentials':'include'}))['ok'];}class Me{constructor(_0xe724bd,_0x4aa935,_0x548c4a){this['name']=_0xe724bd,this['instanceFactory']=_0x4aa935,this['type']=_0x548c4a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0xfb497){return this['instantiationMode']=_0xfb497,this;}['setMultipleInstances'](_0x568632){return this['multipleInstances']=_0x568632,this;}['setServiceProps'](_0xc5966){return this['serviceProps']=_0xc5966,this;}['setInstanceCreatedCallback'](_0x440e38){return this['onInstanceCreated']=_0x440e38,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x34ed26,_0x5a48e8){this['name']=_0x34ed26,this['container']=_0x5a48e8,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x15cddd){const _0x3ab848=this['normalizeInstanceIdentifier'](_0x15cddd);if(!this['instancesDeferred']['has'](_0x3ab848)){const _0x655b87=new Ve();if(this['instancesDeferred']['set'](_0x3ab848,_0x655b87),this['isInitialized'](_0x3ab848)||this['shouldAutoInitialize']())try{const _0x48c560=this['getOrInitializeService']({'instanceIdentifier':_0x3ab848});_0x48c560&&_0x655b87['resolve'](_0x48c560);}catch{}}return this['instancesDeferred']['get'](_0x3ab848)['promise'];}['getImmediate'](_0x3373cb){const _0x15c084=this['normalizeInstanceIdentifier'](_0x3373cb==null?void 0x0:_0x3373cb['identifier']),_0x218f09=(_0x3373cb==null?void 0x0:_0x3373cb['optional'])??!0x1;if(this['isInitialized'](_0x15c084)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x15c084});}catch(_0x266482){if(_0x218f09)return null;throw _0x266482;}else{if(_0x218f09)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3deccd){if(_0x3deccd['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3deccd['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3deccd,!!this['shouldAutoInitialize']()){if(Rc(_0x3deccd))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3aef0b,_0x444925]of this['instancesDeferred']['entries']()){const _0x183835=this['normalizeInstanceIdentifier'](_0x3aef0b);try{const _0x12c03b=this['getOrInitializeService']({'instanceIdentifier':_0x183835});_0x444925['resolve'](_0x12c03b);}catch{}}}}['clearInstance'](_0x2a4d25=ke){this['instancesDeferred']['delete'](_0x2a4d25),this['instancesOptions']['delete'](_0x2a4d25),this['instances']['delete'](_0x2a4d25);}async['delete'](){const _0x3e0a6f=Array['from'](this['instances']['values']());await Promise['all']([..._0x3e0a6f['filter'](_0x50a01f=>'INTERNAL'in _0x50a01f)['map'](_0x2b9e83=>_0x2b9e83['INTERNAL']['delete']()),..._0x3e0a6f['filter'](_0x2989f7=>'_delete'in _0x2989f7)['map'](_0xdcfa52=>_0xdcfa52['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3071e2=ke){return this['instances']['has'](_0x3071e2);}['getOptions'](_0x3d099e=ke){return this['instancesOptions']['get'](_0x3d099e)||{};}['initialize'](_0x1ad1e6={}){const {options:_0x24f0c2={}}=_0x1ad1e6,_0x165f32=this['normalizeInstanceIdentifier'](_0x1ad1e6['instanceIdentifier']);if(this['isInitialized'](_0x165f32))throw Error(this['name']+'('+_0x165f32+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2191cf=this['getOrInitializeService']({'instanceIdentifier':_0x165f32,'options':_0x24f0c2});for(const [_0x2e6580,_0x5e9a32]of this['instancesDeferred']['entries']()){const _0xdedc5f=this['normalizeInstanceIdentifier'](_0x2e6580);_0x165f32===_0xdedc5f&&_0x5e9a32['resolve'](_0x2191cf);}return _0x2191cf;}['onInit'](_0x30c9e9,_0x47df90){const _0x362179=this['normalizeInstanceIdentifier'](_0x47df90),_0x297a83=this['onInitCallbacks']['get'](_0x362179)??new Set();_0x297a83['add'](_0x30c9e9),this['onInitCallbacks']['set'](_0x362179,_0x297a83);const _0x43b612=this['instances']['get'](_0x362179);return _0x43b612&&_0x30c9e9(_0x43b612,_0x362179),()=>{_0x297a83['delete'](_0x30c9e9);};}['invokeOnInitCallbacks'](_0x4b56e4,_0x1626a9){const _0x281dca=this['onInitCallbacks']['get'](_0x1626a9);if(_0x281dca){for(const _0x3ccc48 of _0x281dca)try{_0x3ccc48(_0x4b56e4,_0x1626a9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x111215,options:_0x29c853={}}){let _0x4d5688=this['instances']['get'](_0x111215);if(!_0x4d5688&&this['component']&&(_0x4d5688=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x111215),'options':_0x29c853}),this['instances']['set'](_0x111215,_0x4d5688),this['instancesOptions']['set'](_0x111215,_0x29c853),this['invokeOnInitCallbacks'](_0x4d5688,_0x111215),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x111215,_0x4d5688);}catch{}return _0x4d5688||null;}['normalizeInstanceIdentifier'](_0x32cc56=ke){return this['component']?this['component']['multipleInstances']?_0x32cc56:ke:_0x32cc56;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x182abf){return _0x182abf===ke?void 0x0:_0x182abf;}function Rc(_0x59692f){return _0x59692f['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2a9e6e){this['name']=_0x2a9e6e,this['providers']=new Map();}['addComponent'](_0x5d0591){const _0x117658=this['getProvider'](_0x5d0591['name']);if(_0x117658['isComponentSet']())throw new Error('Component\x20'+_0x5d0591['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x117658['setComponent'](_0x5d0591);}['addOrOverwriteComponent'](_0x40a367){this['getProvider'](_0x40a367['name'])['isComponentSet']()&&this['providers']['delete'](_0x40a367['name']),this['addComponent'](_0x40a367);}['getProvider'](_0x234462){if(this['providers']['has'](_0x234462))return this['providers']['get'](_0x234462);const _0x3d6d8d=new Sc(_0x234462,this);return this['providers']['set'](_0x234462,_0x3d6d8d),_0x3d6d8d;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x7ba4ec){_0x7ba4ec[_0x7ba4ec['DEBUG']=0x0]='DEBUG',_0x7ba4ec[_0x7ba4ec['VERBOSE']=0x1]='VERBOSE',_0x7ba4ec[_0x7ba4ec['INFO']=0x2]='INFO',_0x7ba4ec[_0x7ba4ec['WARN']=0x3]='WARN',_0x7ba4ec[_0x7ba4ec['ERROR']=0x4]='ERROR',_0x7ba4ec[_0x7ba4ec['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0xcd44b2,_0x1be195,..._0x5727b6)=>{if(_0x1be195<_0xcd44b2['logLevel'])return;const _0x511fe2=new Date()['toISOString'](),_0x1b4f70=Pc[_0x1be195];if(_0x1b4f70)console[_0x1b4f70]('['+_0x511fe2+']\x20\x20'+_0xcd44b2['name']+':',..._0x5727b6);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1be195+')');};class xi{constructor(_0xe42f6a){this['name']=_0xe42f6a,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3704a9){if(!(_0x3704a9 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3704a9+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3704a9;}['setLogLevel'](_0x377c12){this['_logLevel']=typeof _0x377c12=='string'?kc[_0x377c12]:_0x377c12;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x98f2a1){if(typeof _0x98f2a1!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x98f2a1;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x136205){this['_userLogHandler']=_0x136205;}['debug'](..._0x599b89){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x599b89),this['_logHandler'](this,T['DEBUG'],..._0x599b89);}['log'](..._0x51fc56){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x51fc56),this['_logHandler'](this,T['VERBOSE'],..._0x51fc56);}['info'](..._0x2657f1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x2657f1),this['_logHandler'](this,T['INFO'],..._0x2657f1);}['warn'](..._0x2c9834){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2c9834),this['_logHandler'](this,T['WARN'],..._0x2c9834);}['error'](..._0x570460){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x570460),this['_logHandler'](this,T['ERROR'],..._0x570460);}}const Dc=(_0x27b289,_0x4ecf47)=>_0x4ecf47['some'](_0x134628=>_0x27b289 instanceof _0x134628);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x27275a){const _0x3ad18e=new Promise((_0x31c8a6,_0xc73462)=>{const _0x1ee2ba=()=>{_0x27275a['removeEventListener']('success',_0x18250c),_0x27275a['removeEventListener']('error',_0x4101c6);},_0x18250c=()=>{_0x31c8a6(_e(_0x27275a['result'])),_0x1ee2ba();},_0x4101c6=()=>{_0xc73462(_0x27275a['error']),_0x1ee2ba();};_0x27275a['addEventListener']('success',_0x18250c),_0x27275a['addEventListener']('error',_0x4101c6);});return _0x3ad18e['then'](_0x16875e=>{_0x16875e instanceof IDBCursor&&Kr['set'](_0x16875e,_0x27275a);})['catch'](()=>{}),Fi['set'](_0x3ad18e,_0x27275a),_0x3ad18e;}function Fc(_0x3bfdb5){if(ui['has'](_0x3bfdb5))return;const _0x3ce6be=new Promise((_0xd1f92a,_0x474d59)=>{const _0x1d06bf=()=>{_0x3bfdb5['removeEventListener']('complete',_0x1d61cf),_0x3bfdb5['removeEventListener']('error',_0x3c7816),_0x3bfdb5['removeEventListener']('abort',_0x3c7816);},_0x1d61cf=()=>{_0xd1f92a(),_0x1d06bf();},_0x3c7816=()=>{_0x474d59(_0x3bfdb5['error']||new DOMException('AbortError','AbortError')),_0x1d06bf();};_0x3bfdb5['addEventListener']('complete',_0x1d61cf),_0x3bfdb5['addEventListener']('error',_0x3c7816),_0x3bfdb5['addEventListener']('abort',_0x3c7816);});ui['set'](_0x3bfdb5,_0x3ce6be);}let di={'get'(_0x374456,_0x356e60,_0x1febe8){if(_0x374456 instanceof IDBTransaction){if(_0x356e60==='done')return ui['get'](_0x374456);if(_0x356e60==='objectStoreNames')return _0x374456['objectStoreNames']||Yr['get'](_0x374456);if(_0x356e60==='store')return _0x1febe8['objectStoreNames'][0x1]?void 0x0:_0x1febe8['objectStore'](_0x1febe8['objectStoreNames'][0x0]);}return _e(_0x374456[_0x356e60]);},'set'(_0x52515e,_0x4b8c3d,_0x517366){return _0x52515e[_0x4b8c3d]=_0x517366,!0x0;},'has'(_0x36e134,_0x3bcc7d){return _0x36e134 instanceof IDBTransaction&&(_0x3bcc7d==='done'||_0x3bcc7d==='store')?!0x0:_0x3bcc7d in _0x36e134;}};function Uc(_0x20328f){di=_0x20328f(di);}function Wc(_0x26a70c){return _0x26a70c===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x46f62c,..._0x57e00b){const _0x5946b6=_0x26a70c['call'](Xn(this),_0x46f62c,..._0x57e00b);return Yr['set'](_0x5946b6,_0x46f62c['sort']?_0x46f62c['sort']():[_0x46f62c]),_e(_0x5946b6);}:Lc()['includes'](_0x26a70c)?function(..._0x8697ae){return _0x26a70c['apply'](Xn(this),_0x8697ae),_e(Kr['get'](this));}:function(..._0x55bdfd){return _e(_0x26a70c['apply'](Xn(this),_0x55bdfd));};}function Bc(_0x130376){return typeof _0x130376=='function'?Wc(_0x130376):(_0x130376 instanceof IDBTransaction&&Fc(_0x130376),Dc(_0x130376,Mc())?new Proxy(_0x130376,di):_0x130376);}function _e(_0x265e4a){if(_0x265e4a instanceof IDBRequest)return xc(_0x265e4a);if(Jn['has'](_0x265e4a))return Jn['get'](_0x265e4a);const _0x1aea1e=Bc(_0x265e4a);return _0x1aea1e!==_0x265e4a&&(Jn['set'](_0x265e4a,_0x1aea1e),Fi['set'](_0x1aea1e,_0x265e4a)),_0x1aea1e;}const Xn=_0x5be01e=>Fi['get'](_0x5be01e);function Vc(_0x8dc6df,_0x173bd,{blocked:_0x1cfe54,upgrade:_0x548618,blocking:_0x252f1d,terminated:_0x1936dc}={}){const _0x381af8=indexedDB['open'](_0x8dc6df,_0x173bd),_0x13d935=_e(_0x381af8);return _0x548618&&_0x381af8['addEventListener']('upgradeneeded',_0x221b18=>{_0x548618(_e(_0x381af8['result']),_0x221b18['oldVersion'],_0x221b18['newVersion'],_e(_0x381af8['transaction']),_0x221b18);}),_0x1cfe54&&_0x381af8['addEventListener']('blocked',_0x633128=>_0x1cfe54(_0x633128['oldVersion'],_0x633128['newVersion'],_0x633128)),_0x13d935['then'](_0x37f7ea=>{_0x1936dc&&_0x37f7ea['addEventListener']('close',()=>_0x1936dc()),_0x252f1d&&_0x37f7ea['addEventListener']('versionchange',_0x1387e9=>_0x252f1d(_0x1387e9['oldVersion'],_0x1387e9['newVersion'],_0x1387e9));})['catch'](()=>{}),_0x13d935;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x3ecb2e,_0x33898f){if(!(_0x3ecb2e instanceof IDBDatabase&&!(_0x33898f in _0x3ecb2e)&&typeof _0x33898f=='string'))return;if(Zn['get'](_0x33898f))return Zn['get'](_0x33898f);const _0x54d923=_0x33898f['replace'](/FromIndex$/,''),_0x3d2a16=_0x33898f!==_0x54d923,_0x3b87fd=$c['includes'](_0x54d923);if(!(_0x54d923 in(_0x3d2a16?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3b87fd||Hc['includes'](_0x54d923)))return;const _0x45b486=async function(_0x1e7001,..._0x1fb01a){const _0x2eaccb=this['transaction'](_0x1e7001,_0x3b87fd?'readwrite':'readonly');let _0x2e7a81=_0x2eaccb['store'];return _0x3d2a16&&(_0x2e7a81=_0x2e7a81['index'](_0x1fb01a['shift']())),(await Promise['all']([_0x2e7a81[_0x54d923](..._0x1fb01a),_0x3b87fd&&_0x2eaccb['done']]))[0x0];};return Zn['set'](_0x33898f,_0x45b486),_0x45b486;}Uc(_0x4ee292=>({..._0x4ee292,'get':(_0x3554d5,_0x30039f,_0x4a5693)=>Os(_0x3554d5,_0x30039f)||_0x4ee292['get'](_0x3554d5,_0x30039f,_0x4a5693),'has':(_0x1eea11,_0x540b5b)=>!!Os(_0x1eea11,_0x540b5b)||_0x4ee292['has'](_0x1eea11,_0x540b5b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x15e5f9){this['container']=_0x15e5f9;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x55edf8=>{if(qc(_0x55edf8)){const _0x412b16=_0x55edf8['getImmediate']();return _0x412b16['library']+'/'+_0x412b16['version'];}else return null;})['filter'](_0x7163e8=>_0x7163e8)['join']('\x20');}}function qc(_0x2a620a){const _0x34a287=_0x2a620a['getComponent']();return(_0x34a287==null?void 0x0:_0x34a287['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x38c962,_0x4a6cfa){try{_0x38c962['container']['addComponent'](_0x4a6cfa);}catch(_0x19b0f7){re['debug']('Component\x20'+_0x4a6cfa['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x38c962['name'],_0x19b0f7);}}function et(_0x43b1f1){const _0x10d6b1=_0x43b1f1['name'];if(gi['has'](_0x10d6b1))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x10d6b1+'.'),!0x1;gi['set'](_0x10d6b1,_0x43b1f1);for(const _0x137da2 of Le['values']())Ms(_0x137da2,_0x43b1f1);for(const _0x4609cf of _i['values']())Ms(_0x4609cf,_0x43b1f1);return!0x0;}function Ui(_0x4438ea,_0x4aa840){const _0x1dc305=_0x4438ea['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1dc305&&_0x1dc305['triggerHeartbeat'](),_0x4438ea['container']['getProvider'](_0x4aa840);}function H(_0x522786){return _0x522786==null?!0x1:_0x522786['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x296354,_0x1e742d,_0x440fa5){this['_isDeleted']=!0x1,this['_options']={..._0x296354},this['_config']={..._0x1e742d},this['_name']=_0x1e742d['name'],this['_automaticDataCollectionEnabled']=_0x1e742d['automaticDataCollectionEnabled'],this['_container']=_0x440fa5,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x22347d){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x22347d;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x590ae5){this['_isDeleted']=_0x590ae5;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x56e615,_0x82631b={}){let _0x49e909=_0x56e615;typeof _0x82631b!='object'&&(_0x82631b={'name':_0x82631b});const _0x44a828={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x82631b},_0x465553=_0x44a828['name'];if(typeof _0x465553!='string'||!_0x465553)throw ge['create']('bad-app-name',{'appName':String(_0x465553)});if(_0x49e909||(_0x49e909=$r()),!_0x49e909)throw ge['create']('no-options');const _0x1ccc2f=Le['get'](_0x465553);if(_0x1ccc2f){if(De(_0x49e909,_0x1ccc2f['options'])&&De(_0x44a828,_0x1ccc2f['config']))return _0x1ccc2f;throw ge['create']('duplicate-app',{'appName':_0x465553});}const _0x34d062=new Ac(_0x465553);for(const _0xf550d1 of gi['values']())_0x34d062['addComponent'](_0xf550d1);const _0x9c86fb=new Il(_0x49e909,_0x44a828,_0x34d062);return Le['set'](_0x465553,_0x9c86fb),_0x9c86fb;}function Qr(_0xeef6fc=pi){const _0x10b625=Le['get'](_0xeef6fc);if(!_0x10b625&&_0xeef6fc===pi&&$r())return wl();if(!_0x10b625)throw ge['create']('no-app',{'appName':_0xeef6fc});return _0x10b625;}function l_(){return Array['from'](Le['values']());}async function h_(_0x592a01){let _0x2c29e7=!0x1;const _0x43d830=_0x592a01['name'];Le['has'](_0x43d830)?(_0x2c29e7=!0x0,Le['delete'](_0x43d830)):_i['has'](_0x43d830)&&_0x592a01['decRefCount']()<=0x0&&(_i['delete'](_0x43d830),_0x2c29e7=!0x0),_0x2c29e7&&(await Promise['all'](_0x592a01['container']['getProviders']()['map'](_0x159d9f=>_0x159d9f['delete']())),_0x592a01['isDeleted']=!0x0);}function me(_0x244609,_0x3cf8d2,_0x54f5ec){let _0x140a12=vl[_0x244609]??_0x244609;_0x54f5ec&&(_0x140a12+='-'+_0x54f5ec);const _0x935a8b=_0x140a12['match'](/\s|\//),_0x5854da=_0x3cf8d2['match'](/\s|\//);if(_0x935a8b||_0x5854da){const _0x118bb9=['Unable\x20to\x20register\x20library\x20\x22'+_0x140a12+'\x22\x20with\x20version\x20\x22'+_0x3cf8d2+'\x22:'];_0x935a8b&&_0x118bb9['push']('library\x20name\x20\x22'+_0x140a12+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x935a8b&&_0x5854da&&_0x118bb9['push']('and'),_0x5854da&&_0x118bb9['push']('version\x20name\x20\x22'+_0x3cf8d2+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x118bb9['join']('\x20'));return;}et(new Me(_0x140a12+'-version',()=>({'library':_0x140a12,'version':_0x3cf8d2}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3b7637,_0x1e6052)=>{switch(_0x1e6052){case 0x0:try{_0x3b7637['createObjectStore'](Rt);}catch(_0x31bcbc){console['warn'](_0x31bcbc);}}}})['catch'](_0x34dfb4=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x34dfb4['message']});})),ei;}async function Sl(_0x99724){try{const _0x194eda=(await Jr())['transaction'](Rt),_0x3d023d=await _0x194eda['objectStore'](Rt)['get'](Xr(_0x99724));return await _0x194eda['done'],_0x3d023d;}catch(_0x531e50){if(_0x531e50 instanceof Se)re['warn'](_0x531e50['message']);else{const _0x51f2e7=ge['create']('idb-get',{'originalErrorMessage':_0x531e50==null?void 0x0:_0x531e50['message']});re['warn'](_0x51f2e7['message']);}}}async function Ls(_0x17959c,_0x240192){try{const _0x59deb6=(await Jr())['transaction'](Rt,'readwrite');await _0x59deb6['objectStore'](Rt)['put'](_0x240192,Xr(_0x17959c)),await _0x59deb6['done'];}catch(_0x554fe3){if(_0x554fe3 instanceof Se)re['warn'](_0x554fe3['message']);else{const _0x2bdd5d=ge['create']('idb-set',{'originalErrorMessage':_0x554fe3==null?void 0x0:_0x554fe3['message']});re['warn'](_0x2bdd5d['message']);}}}function Xr(_0x47018f){return _0x47018f['name']+'!'+_0x47018f['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2d6fce){this['container']=_0x2d6fce,this['_heartbeatsCache']=null;const _0x18c924=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x18c924),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x48cec5=>(this['_heartbeatsCache']=_0x48cec5,_0x48cec5));}async['triggerHeartbeat'](){var _0x1a06a7,_0x394298;try{const _0x17f17c=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xf1392a=xs();if(((_0x1a06a7=this['_heartbeatsCache'])==null?void 0x0:_0x1a06a7['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x394298=this['_heartbeatsCache'])==null?void 0x0:_0x394298['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xf1392a||this['_heartbeatsCache']['heartbeats']['some'](_0x23c7e0=>_0x23c7e0['date']===_0xf1392a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xf1392a,'agent':_0x17f17c}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x2c9905=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2c9905,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x20c90c){re['warn'](_0x20c90c);}}async['getHeartbeatsHeader'](){var _0xba64c5;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xba64c5=this['_heartbeatsCache'])==null?void 0x0:_0xba64c5['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x372ef1=xs(),{heartbeatsToSend:_0x96250a,unsentEntries:_0x449e39}=kl(this['_heartbeatsCache']['heartbeats']),_0x30003c=an(JSON['stringify']({'version':0x2,'heartbeats':_0x96250a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x372ef1,_0x449e39['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x449e39,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x30003c;}catch(_0x5edceb){return re['warn'](_0x5edceb),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x439964,_0x56f5f8=bl){const _0x501faa=[];let _0x15029a=_0x439964['slice']();for(const _0x3c6e70 of _0x439964){const _0x55d8c2=_0x501faa['find'](_0x581cf4=>_0x581cf4['agent']===_0x3c6e70['agent']);if(_0x55d8c2){if(_0x55d8c2['dates']['push'](_0x3c6e70['date']),Fs(_0x501faa)>_0x56f5f8){_0x55d8c2['dates']['pop']();break;}}else{if(_0x501faa['push']({'agent':_0x3c6e70['agent'],'dates':[_0x3c6e70['date']]}),Fs(_0x501faa)>_0x56f5f8){_0x501faa['pop']();break;}}_0x15029a=_0x15029a['slice'](0x1);}return{'heartbeatsToSend':_0x501faa,'unsentEntries':_0x15029a};}class Nl{constructor(_0xd7d1b9){this['app']=_0xd7d1b9,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x33e602=await Sl(this['app']);return _0x33e602!=null&&_0x33e602['heartbeats']?_0x33e602:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x240463){if(await this['_canUseIndexedDBPromise']){const _0x1674f7=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x240463['lastSentHeartbeatDate']??_0x1674f7['lastSentHeartbeatDate'],'heartbeats':_0x240463['heartbeats']});}else return;}async['add'](_0x4e90f2){if(await this['_canUseIndexedDBPromise']){const _0x4d8dd5=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x4e90f2['lastSentHeartbeatDate']??_0x4d8dd5['lastSentHeartbeatDate'],'heartbeats':[..._0x4d8dd5['heartbeats'],..._0x4e90f2['heartbeats']]});}else return;}}function Fs(_0x2af947){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x2af947}))['length'];}function Pl(_0x1b15d4){if(_0x1b15d4['length']===0x0)return-0x1;let _0x627f0d=0x0,_0x5b40fa=_0x1b15d4[0x0]['date'];for(let _0x22ba55=0x1;_0x22ba55<_0x1b15d4['length'];_0x22ba55++)_0x1b15d4[_0x22ba55]['date']<_0x5b40fa&&(_0x5b40fa=_0x1b15d4[_0x22ba55]['date'],_0x627f0d=_0x22ba55);return _0x627f0d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x430194){et(new Me('platform-logger',_0x446af2=>new Gc(_0x446af2),'PRIVATE')),et(new Me('heartbeat',_0x170345=>new Al(_0x170345),'PRIVATE')),me(fi,Ds,_0x430194),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x52824d){Zr=_0x52824d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x3b5eef){this['domStorage_']=_0x3b5eef,this['prefix_']='firebase:';}['set'](_0x5837e1,_0x2cfadd){_0x2cfadd==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5837e1)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5837e1),O(_0x2cfadd));}['get'](_0x438326){const _0x57b9ab=this['domStorage_']['getItem'](this['prefixedName_'](_0x438326));return _0x57b9ab==null?null:bt(_0x57b9ab);}['remove'](_0x30176b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x30176b));}['prefixedName_'](_0x5e0d3b){return this['prefix_']+_0x5e0d3b;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x395cf3,_0x247183){_0x247183==null?delete this['cache_'][_0x395cf3]:this['cache_'][_0x395cf3]=_0x247183;}['get'](_0x3b5b2b){return Y(this['cache_'],_0x3b5b2b)?this['cache_'][_0x3b5b2b]:null;}['remove'](_0x56ae68){delete this['cache_'][_0x56ae68];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x5c3f64){try{if(typeof window<'u'&&typeof window[_0x5c3f64]<'u'){const _0x22244b=window[_0x5c3f64];return _0x22244b['setItem']('firebase:sentinel','cache'),_0x22244b['removeItem']('firebase:sentinel'),new xl(_0x22244b);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x3d3244=0x1;return function(){return _0x3d3244++;};}()),no=function(_0x149023){const _0x48a732=Tc(_0x149023),_0x14283d=new Ec();_0x14283d['update'](_0x48a732);const _0x32c711=_0x14283d['digest']();return Di['encodeByteArray'](_0x32c711);},Bt=function(..._0x464ce0){let _0x181197='';for(let _0x272b9d=0x0;_0x272b9d<_0x464ce0['length'];_0x272b9d++){const _0x5f8d9=_0x464ce0[_0x272b9d];Array['isArray'](_0x5f8d9)||_0x5f8d9&&typeof _0x5f8d9=='object'&&typeof _0x5f8d9['length']=='number'?_0x181197+=Bt['apply'](null,_0x5f8d9):typeof _0x5f8d9=='object'?_0x181197+=O(_0x5f8d9):_0x181197+=_0x5f8d9,_0x181197+='\x20';}return _0x181197;};let Et=null,Vs=!0x0;const Wl=function(_0x63c3ab,_0x175699){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x1e138e){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3e9ad2=Bt['apply'](null,_0x1e138e);Et(_0x3e9ad2);}},Vt=function(_0x4cb0a0){return function(..._0x43f402){L(_0x4cb0a0,..._0x43f402);};},mi=function(..._0x28eac9){const _0xb3b0e9='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x28eac9);Qe['error'](_0xb3b0e9);},oe=function(..._0x2e8386){const _0x2baf43='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x2e8386);throw Qe['error'](_0x2baf43),new Error(_0x2baf43);},U=function(..._0x545070){const _0x563578='FIREBASE\x20WARNING:\x20'+Bt(..._0x545070);Qe['warn'](_0x563578);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x1f69c6){return typeof _0x1f69c6=='number'&&(_0x1f69c6!==_0x1f69c6||_0x1f69c6===Number['POSITIVE_INFINITY']||_0x1f69c6===Number['NEGATIVE_INFINITY']);},Vl=function(_0x4beeda){if(document['readyState']==='complete')_0x4beeda();else{let _0x1a4894=!0x1;const _0x313f86=function(){if(!document['body']){setTimeout(_0x313f86,Math['floor'](0xa));return;}_0x1a4894||(_0x1a4894=!0x0,_0x4beeda());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x313f86,!0x1),window['addEventListener']('load',_0x313f86,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x313f86();}),window['attachEvent']('onload',_0x313f86));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x338f82,_0x3d1948){if(_0x338f82===_0x3d1948)return 0x0;if(_0x338f82===xe||_0x3d1948===Ie)return-0x1;if(_0x3d1948===xe||_0x338f82===Ie)return 0x1;{const _0x16b794=Hs(_0x338f82),_0x234731=Hs(_0x3d1948);return _0x16b794!==null?_0x234731!==null?_0x16b794-_0x234731===0x0?_0x338f82['length']-_0x3d1948['length']:_0x16b794-_0x234731:-0x1:_0x234731!==null?0x1:_0x338f82<_0x3d1948?-0x1:0x1;}},Hl=function(_0x5d3618,_0x52ff6f){return _0x5d3618===_0x52ff6f?0x0:_0x5d3618<_0x52ff6f?-0x1:0x1;},pt=function(_0xbe639b,_0x3708ad){if(_0x3708ad&&_0xbe639b in _0x3708ad)return _0x3708ad[_0xbe639b];throw new Error('Missing\x20required\x20key\x20('+_0xbe639b+')\x20in\x20object:\x20'+O(_0x3708ad));},Bi=function(_0xa789e3){if(typeof _0xa789e3!='object'||_0xa789e3===null)return O(_0xa789e3);const _0x24f2e5=[];for(const _0x5cff3c in _0xa789e3)_0x24f2e5['push'](_0x5cff3c);_0x24f2e5['sort']();let _0x2c06b9='{';for(let _0x48e868=0x0;_0x48e868<_0x24f2e5['length'];_0x48e868++)_0x48e868!==0x0&&(_0x2c06b9+=','),_0x2c06b9+=O(_0x24f2e5[_0x48e868]),_0x2c06b9+=':',_0x2c06b9+=Bi(_0xa789e3[_0x24f2e5[_0x48e868]]);return _0x2c06b9+='}',_0x2c06b9;},io=function(_0x30c0bc,_0x276216){const _0x3884dc=_0x30c0bc['length'];if(_0x3884dc<=_0x276216)return[_0x30c0bc];const _0x1edd0c=[];for(let _0xbf213=0x0;_0xbf213<_0x3884dc;_0xbf213+=_0x276216)_0xbf213+_0x276216>_0x3884dc?_0x1edd0c['push'](_0x30c0bc['substring'](_0xbf213,_0x3884dc)):_0x1edd0c['push'](_0x30c0bc['substring'](_0xbf213,_0xbf213+_0x276216));return _0x1edd0c;};function x(_0x4bb55e,_0x1300ca){for(const _0x2320a1 in _0x4bb55e)_0x4bb55e['hasOwnProperty'](_0x2320a1)&&_0x1300ca(_0x2320a1,_0x4bb55e[_0x2320a1]);}const so=function(_0x4e069a){f(!Wi(_0x4e069a),'Invalid\x20JSON\x20number');const _0x39369d=0xb,_0x154e65=0x34,_0x11f6a5=(0x1<<_0x39369d-0x1)-0x1;let _0x3d7aed,_0x6d49e7,_0x1af4e1,_0x22a194,_0x3d9e94;_0x4e069a===0x0?(_0x6d49e7=0x0,_0x1af4e1=0x0,_0x3d7aed=0x1/_0x4e069a===-0x1/0x0?0x1:0x0):(_0x3d7aed=_0x4e069a<0x0,_0x4e069a=Math['abs'](_0x4e069a),_0x4e069a>=Math['pow'](0x2,0x1-_0x11f6a5)?(_0x22a194=Math['min'](Math['floor'](Math['log'](_0x4e069a)/Math['LN2']),_0x11f6a5),_0x6d49e7=_0x22a194+_0x11f6a5,_0x1af4e1=Math['round'](_0x4e069a*Math['pow'](0x2,_0x154e65-_0x22a194)-Math['pow'](0x2,_0x154e65))):(_0x6d49e7=0x0,_0x1af4e1=Math['round'](_0x4e069a/Math['pow'](0x2,0x1-_0x11f6a5-_0x154e65))));const _0x45eb60=[];for(_0x3d9e94=_0x154e65;_0x3d9e94;_0x3d9e94-=0x1)_0x45eb60['push'](_0x1af4e1%0x2?0x1:0x0),_0x1af4e1=Math['floor'](_0x1af4e1/0x2);for(_0x3d9e94=_0x39369d;_0x3d9e94;_0x3d9e94-=0x1)_0x45eb60['push'](_0x6d49e7%0x2?0x1:0x0),_0x6d49e7=Math['floor'](_0x6d49e7/0x2);_0x45eb60['push'](_0x3d7aed?0x1:0x0),_0x45eb60['reverse']();const _0x3cdf88=_0x45eb60['join']('');let _0x35ebd3='';for(_0x3d9e94=0x0;_0x3d9e94<0x40;_0x3d9e94+=0x8){let _0x2353a7=parseInt(_0x3cdf88['substr'](_0x3d9e94,0x8),0x2)['toString'](0x10);_0x2353a7['length']===0x1&&(_0x2353a7='0'+_0x2353a7),_0x35ebd3=_0x35ebd3+_0x2353a7;}return _0x35ebd3['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x5c9ed2,_0x5bf724){let _0x54d2b1='Unknown\x20Error';_0x5c9ed2==='too_big'?_0x54d2b1='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5c9ed2==='permission_denied'?_0x54d2b1='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5c9ed2==='unavailable'&&(_0x54d2b1='The\x20service\x20is\x20unavailable');const _0x3a47e0=new Error(_0x5c9ed2+'\x20at\x20'+_0x5bf724['_path']['toString']()+':\x20'+_0x54d2b1);return _0x3a47e0['code']=_0x5c9ed2['toUpperCase'](),_0x3a47e0;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x491fe0){if(zl['test'](_0x491fe0)){const _0xc73067=Number(_0x491fe0);if(_0xc73067>=jl&&_0xc73067<=Kl)return _0xc73067;}return null;},lt=function(_0xd05569){try{_0xd05569();}catch(_0xa88043){setTimeout(()=>{const _0x5af027=_0xa88043['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5af027),_0xa88043;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0xc1ead2,_0x243626){const _0x51828c=setTimeout(_0xc1ead2,_0x243626);return typeof _0x51828c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x51828c):typeof _0x51828c=='object'&&_0x51828c['unref']&&_0x51828c['unref'](),_0x51828c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x5a5b49,_0x536912){this['appCheckProvider']=_0x536912,this['appName']=_0x5a5b49['name'],H(_0x5a5b49)&&_0x5a5b49['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5a5b49['settings']['appCheckToken']),this['appCheck']=_0x536912==null?void 0x0:_0x536912['getImmediate']({'optional':!0x0}),this['appCheck']||_0x536912==null||_0x536912['get']()['then'](_0x3c379a=>this['appCheck']=_0x3c379a);}['getToken'](_0x2c4b38){if(this['serverAppAppCheckToken']){if(_0x2c4b38)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2c4b38):new Promise((_0x42320a,_0x127d59)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2c4b38)['then'](_0x42320a,_0x127d59):_0x42320a(null);},0x0);});}['addTokenChangeListener'](_0x269d8d){var _0xf92a48;(_0xf92a48=this['appCheckProvider'])==null||_0xf92a48['get']()['then'](_0x14f9bf=>_0x14f9bf['addTokenListener'](_0x269d8d));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x5b15df,_0xddf65e,_0x21afd9){this['appName_']=_0x5b15df,this['firebaseOptions_']=_0xddf65e,this['authProvider_']=_0x21afd9,this['auth_']=null,this['auth_']=_0x21afd9['getImmediate']({'optional':!0x0}),this['auth_']||_0x21afd9['onInit'](_0x2a0a4a=>this['auth_']=_0x2a0a4a);}['getToken'](_0x46eb13){return this['auth_']?this['auth_']['getToken'](_0x46eb13)['catch'](_0x270d5f=>_0x270d5f&&_0x270d5f['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x270d5f)):new Promise((_0x4133ba,_0x328c89)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x46eb13)['then'](_0x4133ba,_0x328c89):_0x4133ba(null);},0x0);});}['addTokenChangeListener'](_0x4921ab){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4921ab):this['authProvider_']['get']()['then'](_0x281d41=>_0x281d41['addAuthTokenListener'](_0x4921ab));}['removeTokenChangeListener'](_0xf746ad){this['authProvider_']['get']()['then'](_0xe18a59=>_0xe18a59['removeAuthTokenListener'](_0xf746ad));}['notifyForInvalidToken'](){let _0x4f98f8='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4f98f8+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4f98f8+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4f98f8+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4f98f8);}}class tn{constructor(_0xcc2ab3){this['accessToken']=_0xcc2ab3;}['getToken'](_0x37202f){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x338395){_0x338395(this['accessToken']);}['removeTokenChangeListener'](_0x347d91){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x316e0e,_0x3f545a,_0x273945,_0x7f166d,_0x30c9ca=!0x1,_0x592da6='',_0x481432=!0x1,_0x2924c0=!0x1,_0x128c3e=null){this['secure']=_0x3f545a,this['namespace']=_0x273945,this['webSocketOnly']=_0x7f166d,this['nodeAdmin']=_0x30c9ca,this['persistenceKey']=_0x592da6,this['includeNamespaceInQueryParams']=_0x481432,this['isUsingEmulator']=_0x2924c0,this['emulatorOptions']=_0x128c3e,this['_host']=_0x316e0e['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x316e0e)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2d4813){_0x2d4813!==this['internalHost']&&(this['internalHost']=_0x2d4813,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2bff8c=this['toURLString']();return this['persistenceKey']&&(_0x2bff8c+='<'+this['persistenceKey']+'>'),_0x2bff8c;}['toURLString'](){const _0x30946d=this['secure']?'https://':'http://',_0x23d6aa=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x30946d+this['host']+'/'+_0x23d6aa;}}function Xl(_0x159f0c){return _0x159f0c['host']!==_0x159f0c['internalHost']||_0x159f0c['isCustomHost']()||_0x159f0c['includeNamespaceInQueryParams'];}function go(_0x4030b5,_0x10e725,_0x3a48d7){f(typeof _0x10e725=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3a48d7=='object','typeof\x20params\x20must\x20==\x20object');let _0x59a72c;if(_0x10e725===fo)_0x59a72c=(_0x4030b5['secure']?'wss://':'ws://')+_0x4030b5['internalHost']+'/.ws?';else{if(_0x10e725===po)_0x59a72c=(_0x4030b5['secure']?'https://':'http://')+_0x4030b5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x10e725);}Xl(_0x4030b5)&&(_0x3a48d7['ns']=_0x4030b5['namespace']);const _0x1f0eab=[];return x(_0x3a48d7,(_0x2f8b6c,_0x2f012a)=>{_0x1f0eab['push'](_0x2f8b6c+'='+_0x2f012a);}),_0x59a72c+_0x1f0eab['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x99bcce,_0x1997bb=0x1){Y(this['counters_'],_0x99bcce)||(this['counters_'][_0x99bcce]=0x0),this['counters_'][_0x99bcce]+=_0x1997bb;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x301767){const _0x3eb982=_0x301767['toString']();return ti[_0x3eb982]||(ti[_0x3eb982]=new Zl()),ti[_0x3eb982];}function eh(_0x124e80,_0x5017a8){const _0x42369c=_0x124e80['toString']();return ni[_0x42369c]||(ni[_0x42369c]=_0x5017a8()),ni[_0x42369c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x5c8749){this['onMessage_']=_0x5c8749,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x33cf0f,_0x28fbf2){this['closeAfterResponse']=_0x33cf0f,this['onClose']=_0x28fbf2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5e86bb,_0x2da205){for(this['pendingResponses'][_0x5e86bb]=_0x2da205;this['pendingResponses'][this['currentResponseNum']];){const _0x351134=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x335e97=0x0;_0x335e97<_0x351134['length'];++_0x335e97)_0x351134[_0x335e97]&&lt(()=>{this['onMessage_'](_0x351134[_0x335e97]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x72314e,_0x5697e8,_0x20b8e3,_0xe91ba2,_0x1d0c04,_0x1a84ef,_0x572410){this['connId']=_0x72314e,this['repoInfo']=_0x5697e8,this['applicationId']=_0x20b8e3,this['appCheckToken']=_0xe91ba2,this['authToken']=_0x1d0c04,this['transportSessionId']=_0x1a84ef,this['lastSessionId']=_0x572410,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x72314e),this['stats_']=Hi(_0x5697e8),this['urlFn']=_0x555586=>(this['appCheckToken']&&(_0x555586[yi]=this['appCheckToken']),go(_0x5697e8,po,_0x555586));}['open'](_0x5de31f,_0x57e6b3){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x57e6b3,this['myPacketOrderer']=new th(_0x5de31f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0xabde6d)=>{const [_0x416daa,_0x5c74fd,_0x7e8474,_0x695d3d,_0x4f6c1b]=_0xabde6d;if(this['incrementIncomingBytes_'](_0xabde6d),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x416daa===$s)this['id']=_0x5c74fd,this['password']=_0x7e8474;else{if(_0x416daa===nh)_0x5c74fd?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5c74fd,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x416daa);}}},(..._0x262083)=>{const [_0xf7851c,_0x151d38]=_0x262083;this['incrementIncomingBytes_'](_0x262083),this['myPacketOrderer']['handleResponse'](_0xf7851c,_0x151d38);},()=>{this['onClosed_']();},this['urlFn']);const _0x242581={};_0x242581[$s]='t',_0x242581[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x242581[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x242581[ro]=Vi,this['transportSessionId']&&(_0x242581[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x242581[ho]=this['lastSessionId']),this['applicationId']&&(_0x242581[uo]=this['applicationId']),this['appCheckToken']&&(_0x242581[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x242581[ao]=co);const _0x4544af=this['urlFn'](_0x242581);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4544af),this['scriptTagHolder']['addTag'](_0x4544af,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1e6f0e){const _0x1e8f75=O(_0x1e6f0e);this['bytesSent']+=_0x1e8f75['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1e8f75['length']);const _0x4165e4=Br(_0x1e8f75),_0x404748=io(_0x4165e4,hh);for(let _0xb23a8d=0x0;_0xb23a8d<_0x404748['length'];_0xb23a8d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x404748['length'],_0x404748[_0xb23a8d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4f56e5,_0x31cf03){this['myDisconnFrame']=document['createElement']('iframe');const _0x4eb1d3={};_0x4eb1d3[lh]='t',_0x4eb1d3[mo]=_0x4f56e5,_0x4eb1d3[yo]=_0x31cf03,this['myDisconnFrame']['src']=this['urlFn'](_0x4eb1d3),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xd2d18){const _0x1056a7=O(_0xd2d18)['length'];this['bytesReceived']+=_0x1056a7,this['stats_']['incrementCounter']('bytes_received',_0x1056a7);}}class $i{constructor(_0x3d4edc,_0x2401de,_0x16950b,_0x2b49cd){this['onDisconnect']=_0x16950b,this['urlFn']=_0x2b49cd,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x3d4edc,window[sh+this['uniqueCallbackIdentifier']]=_0x2401de,this['myIFrame']=$i['createIFrame_']();let _0x419443='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x419443='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x31886b='<html><body>'+_0x419443+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x31886b),this['myIFrame']['doc']['close']();}catch(_0x140087){L('frame\x20writing\x20exception'),_0x140087['stack']&&L(_0x140087['stack']),L(_0x140087);}}}static['createIFrame_'](){const _0x21dc3e=document['createElement']('iframe');if(_0x21dc3e['style']['display']='none',document['body']){document['body']['appendChild'](_0x21dc3e);try{_0x21dc3e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x439511=document['domain'];_0x21dc3e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x439511+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x21dc3e['contentDocument']?_0x21dc3e['doc']=_0x21dc3e['contentDocument']:_0x21dc3e['contentWindow']?_0x21dc3e['doc']=_0x21dc3e['contentWindow']['document']:_0x21dc3e['document']&&(_0x21dc3e['doc']=_0x21dc3e['document']),_0x21dc3e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1153eb=this['onDisconnect'];_0x1153eb&&(this['onDisconnect']=null,_0x1153eb());}['startLongPoll'](_0x32de43,_0x1dd1bd){for(this['myID']=_0x32de43,this['myPW']=_0x1dd1bd,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x373d28={};_0x373d28[mo]=this['myID'],_0x373d28[yo]=this['myPW'],_0x373d28[vo]=this['currentSerial'];let _0x39845d=this['urlFn'](_0x373d28),_0xf71476='',_0x31ab1a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0xf71476['length']<=Eo;){const _0x48ebac=this['pendingSegs']['shift']();_0xf71476=_0xf71476+'&'+oh+_0x31ab1a+'='+_0x48ebac['seg']+'&'+ah+_0x31ab1a+'='+_0x48ebac['ts']+'&'+ch+_0x31ab1a+'='+_0x48ebac['d'],_0x31ab1a++;}return _0x39845d=_0x39845d+_0xf71476,this['addLongPollTag_'](_0x39845d,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0xa835f,_0x35e5d6,_0x573ba5){this['pendingSegs']['push']({'seg':_0xa835f,'ts':_0x35e5d6,'d':_0x573ba5}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x3fbb9c,_0x161515){this['outstandingRequests']['add'](_0x161515);const _0xd5eb3b=()=>{this['outstandingRequests']['delete'](_0x161515),this['newRequest_']();},_0x488a06=setTimeout(_0xd5eb3b,Math['floor'](uh)),_0x22ea0a=()=>{clearTimeout(_0x488a06),_0xd5eb3b();};this['addTag'](_0x3fbb9c,_0x22ea0a);}['addTag'](_0xe7cc8c,_0x20ee2d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5e32a2=this['myIFrame']['doc']['createElement']('script');_0x5e32a2['type']='text/javascript',_0x5e32a2['async']=!0x0,_0x5e32a2['src']=_0xe7cc8c,_0x5e32a2['onload']=_0x5e32a2['onreadystatechange']=function(){const _0x39872e=_0x5e32a2['readyState'];(!_0x39872e||_0x39872e==='loaded'||_0x39872e==='complete')&&(_0x5e32a2['onload']=_0x5e32a2['onreadystatechange']=null,_0x5e32a2['parentNode']&&_0x5e32a2['parentNode']['removeChild'](_0x5e32a2),_0x20ee2d());},_0x5e32a2['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xe7cc8c),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5e32a2);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x38894d,_0x310e18,_0x1c322a,_0x39a772,_0x4d68a1,_0x2695e6,_0x72137e){this['connId']=_0x38894d,this['applicationId']=_0x1c322a,this['appCheckToken']=_0x39a772,this['authToken']=_0x4d68a1,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x310e18),this['connURL']=G['connectionURL_'](_0x310e18,_0x2695e6,_0x72137e,_0x39a772,_0x1c322a),this['nodeAdmin']=_0x310e18['nodeAdmin'];}static['connectionURL_'](_0x516ab6,_0x28a0a6,_0xd1d6bb,_0x39c82c,_0x1b670d){const _0x3b92be={};return _0x3b92be[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3b92be[ao]=co),_0x28a0a6&&(_0x3b92be[oo]=_0x28a0a6),_0xd1d6bb&&(_0x3b92be[ho]=_0xd1d6bb),_0x39c82c&&(_0x3b92be[yi]=_0x39c82c),_0x1b670d&&(_0x3b92be[uo]=_0x1b670d),go(_0x516ab6,fo,_0x3b92be);}['open'](_0x176136,_0x5c70f4){this['onDisconnect']=_0x5c70f4,this['onMessage']=_0x176136,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x3bf818;dc(),this['mySock']=new hn(this['connURL'],[],_0x3bf818);}catch(_0xd85c0c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x28824c=_0xd85c0c['message']||_0xd85c0c['data'];_0x28824c&&this['log_'](_0x28824c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x48a416=>{this['handleIncomingFrame'](_0x48a416);},this['mySock']['onerror']=_0xe180e=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1ca089=_0xe180e['message']||_0xe180e['data'];_0x1ca089&&this['log_'](_0x1ca089),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x1b72d7=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x504ec7=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x23f755=navigator['userAgent']['match'](_0x504ec7);_0x23f755&&_0x23f755['length']>0x1&&parseFloat(_0x23f755[0x1])<4.4&&(_0x1b72d7=!0x0);}return!_0x1b72d7&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2cb76b){if(this['frames']['push'](_0x2cb76b),this['frames']['length']===this['totalFrames']){const _0x32328b=this['frames']['join']('');this['frames']=null;const _0x4a9bae=bt(_0x32328b);this['onMessage'](_0x4a9bae);}}['handleNewFrameCount_'](_0x3bb9c7){this['totalFrames']=_0x3bb9c7,this['frames']=[];}['extractFrameCount_'](_0x5ea82a){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5ea82a['length']<=0x6){const _0xdbeab9=Number(_0x5ea82a);if(!isNaN(_0xdbeab9))return this['handleNewFrameCount_'](_0xdbeab9),null;}return this['handleNewFrameCount_'](0x1),_0x5ea82a;}['handleIncomingFrame'](_0x3f752e){if(this['mySock']===null)return;const _0x25453e=_0x3f752e['data'];if(this['bytesReceived']+=_0x25453e['length'],this['stats_']['incrementCounter']('bytes_received',_0x25453e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x25453e);else{const _0xba7bec=this['extractFrameCount_'](_0x25453e);_0xba7bec!==null&&this['appendFrame_'](_0xba7bec);}}['send'](_0x2cd0b2){this['resetKeepAlive']();const _0x2cbd85=O(_0x2cd0b2);this['bytesSent']+=_0x2cbd85['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2cbd85['length']);const _0x169ca0=io(_0x2cbd85,fh);_0x169ca0['length']>0x1&&this['sendString_'](String(_0x169ca0['length']));for(let _0x51b675=0x0;_0x51b675<_0x169ca0['length'];_0x51b675++)this['sendString_'](_0x169ca0[_0x51b675]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x51cf64){try{this['mySock']['send'](_0x51cf64);}catch(_0x5949fd){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5949fd['message']||_0x5949fd['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x585bee){this['initTransports_'](_0x585bee);}['initTransports_'](_0x3f273f){const _0x4bcbe9=G&&G['isAvailable']();let _0x5c4d4b=_0x4bcbe9&&!G['previouslyFailed']();if(_0x3f273f['webSocketOnly']&&(_0x4bcbe9||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5c4d4b=!0x0),_0x5c4d4b)this['transports_']=[G];else{const _0x25c71c=this['transports_']=[];for(const _0x47b040 of At['ALL_TRANSPORTS'])_0x47b040&&_0x47b040['isAvailable']()&&_0x25c71c['push'](_0x47b040);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x3c8a4e,_0x4aabe8,_0x177d52,_0x3a574c,_0x13ea9c,_0x32230c,_0x287ce6,_0x13fd59,_0x398569,_0x11caf0){this['id']=_0x3c8a4e,this['repoInfo_']=_0x4aabe8,this['applicationId_']=_0x177d52,this['appCheckToken_']=_0x3a574c,this['authToken_']=_0x13ea9c,this['onMessage_']=_0x32230c,this['onReady_']=_0x287ce6,this['onDisconnect_']=_0x13fd59,this['onKill_']=_0x398569,this['lastSessionId']=_0x11caf0,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x4aabe8),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2a9d33=this['transportManager_']['initialTransport']();this['conn_']=new _0x2a9d33(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2a9d33['responsesRequiredToBeHealthy']||0x0;const _0xfde038=this['connReceiver_'](this['conn_']),_0x33f021=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xfde038,_0x33f021);},Math['floor'](0x0));const _0x537ca4=_0x2a9d33['healthyTimeout']||0x0;_0x537ca4>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x537ca4)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3d275d){return _0x72c0db=>{_0x3d275d===this['conn_']?this['onConnectionLost_'](_0x72c0db):_0x3d275d===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2499b4){return _0x5cc9ba=>{this['state_']!==0x2&&(_0x2499b4===this['rx_']?this['onPrimaryMessageReceived_'](_0x5cc9ba):_0x2499b4===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5cc9ba):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2596c3){const _0x575816={'t':'d','d':_0x2596c3};this['sendData_'](_0x575816);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x560f3d){if(ii in _0x560f3d){const _0x5018b5=_0x560f3d[ii];_0x5018b5===js?this['upgradeIfSecondaryHealthy_']():_0x5018b5===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5018b5===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xcec2fd){const _0x25b8a7=pt('t',_0xcec2fd),_0x16f178=pt('d',_0xcec2fd);if(_0x25b8a7==='c')this['onSecondaryControl_'](_0x16f178);else{if(_0x25b8a7==='d')this['pendingDataMessages']['push'](_0x16f178);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x25b8a7);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x78cdef){const _0x23e7f2=pt('t',_0x78cdef),_0x100287=pt('d',_0x78cdef);_0x23e7f2==='c'?this['onControl_'](_0x100287):_0x23e7f2==='d'&&this['onDataMessage_'](_0x100287);}['onDataMessage_'](_0x2d8c10){this['onPrimaryResponse_'](),this['onMessage_'](_0x2d8c10);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3df42c){const _0x2d6a4b=pt(ii,_0x3df42c);if(Gs in _0x3df42c){const _0x4efa4b=_0x3df42c[Gs];if(_0x2d6a4b===Ih){const _0x183830={..._0x4efa4b};this['repoInfo_']['isUsingEmulator']&&(_0x183830['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x183830);}else{if(_0x2d6a4b===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2544b9=0x0;_0x2544b9<this['pendingDataMessages']['length'];++_0x2544b9)this['onDataMessage_'](this['pendingDataMessages'][_0x2544b9]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2d6a4b===vh?this['onConnectionShutdown_'](_0x4efa4b):_0x2d6a4b===qs?this['onReset_'](_0x4efa4b):_0x2d6a4b===Eh?mi('Server\x20Error:\x20'+_0x4efa4b):_0x2d6a4b===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x2d6a4b);}}}['onHandshake_'](_0x3644b6){const _0x3fcf81=_0x3644b6['ts'],_0x41d2bb=_0x3644b6['v'],_0x3d1609=_0x3644b6['h'];this['sessionId']=_0x3644b6['s'],this['repoInfo_']['host']=_0x3d1609,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3fcf81),Vi!==_0x41d2bb&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x80ef38=this['transportManager_']['upgradeTransport']();_0x80ef38&&this['startUpgrade_'](_0x80ef38);}['startUpgrade_'](_0x593dba){this['secondaryConn_']=new _0x593dba(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x593dba['responsesRequiredToBeHealthy']||0x0;const _0x7bf868=this['connReceiver_'](this['secondaryConn_']),_0x37ee20=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x7bf868,_0x37ee20),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x52074c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x52074c),this['repoInfo_']['host']=_0x52074c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1b1cc7,_0x3265b8){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1b1cc7,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x3265b8,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xaf3db=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xaf3db||this['rx_']===_0xaf3db)&&this['close']();}['onConnectionLost_'](_0x228562){this['conn_']=null,!_0x228562&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4fca9a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4fca9a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x30b314){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x30b314);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x49c813,_0x309c38,_0x5efec0,_0x3cddb0){}['merge'](_0x55178b,_0x1029d8,_0x5be69f,_0x13a769){}['refreshAuthToken'](_0x225c46){}['refreshAppCheckToken'](_0x492424){}['onDisconnectPut'](_0x35cc6f,_0x59fd57,_0x2cb97e){}['onDisconnectMerge'](_0x2ba4a8,_0x18d3c3,_0x35410){}['onDisconnectCancel'](_0x59cf96,_0x317925){}['reportStats'](_0x21f961){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x5beb4c){this['allowedEvents_']=_0x5beb4c,this['listeners_']={},f(Array['isArray'](_0x5beb4c)&&_0x5beb4c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3b7fe6,..._0x47c6ad){if(Array['isArray'](this['listeners_'][_0x3b7fe6])){const _0x4cb09d=[...this['listeners_'][_0x3b7fe6]];for(let _0x4db2e0=0x0;_0x4db2e0<_0x4cb09d['length'];_0x4db2e0++)_0x4cb09d[_0x4db2e0]['callback']['apply'](_0x4cb09d[_0x4db2e0]['context'],_0x47c6ad);}}['on'](_0x47a4d8,_0x355da1,_0x1bf457){this['validateEventType_'](_0x47a4d8),this['listeners_'][_0x47a4d8]=this['listeners_'][_0x47a4d8]||[],this['listeners_'][_0x47a4d8]['push']({'callback':_0x355da1,'context':_0x1bf457});const _0x4ad8c3=this['getInitialEvent'](_0x47a4d8);_0x4ad8c3&&_0x355da1['apply'](_0x1bf457,_0x4ad8c3);}['off'](_0x4f7e90,_0x2c6848,_0xe15d2d){this['validateEventType_'](_0x4f7e90);const _0x3bc90b=this['listeners_'][_0x4f7e90]||[];for(let _0xd98592=0x0;_0xd98592<_0x3bc90b['length'];_0xd98592++)if(_0x3bc90b[_0xd98592]['callback']===_0x2c6848&&(!_0xe15d2d||_0xe15d2d===_0x3bc90b[_0xd98592]['context'])){_0x3bc90b['splice'](_0xd98592,0x1);return;}}['validateEventType_'](_0x313168){f(this['allowedEvents_']['find'](_0x589fd6=>_0x589fd6===_0x313168),'Unknown\x20event:\x20'+_0x313168);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x37dae1){return f(_0x37dae1==='online','Unknown\x20event\x20type:\x20'+_0x37dae1),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x1b2755,_0x2d9812){if(_0x2d9812===void 0x0){this['pieces_']=_0x1b2755['split']('/');let _0xcbbd72=0x0;for(let _0x297a18=0x0;_0x297a18<this['pieces_']['length'];_0x297a18++)this['pieces_'][_0x297a18]['length']>0x0&&(this['pieces_'][_0xcbbd72]=this['pieces_'][_0x297a18],_0xcbbd72++);this['pieces_']['length']=_0xcbbd72,this['pieceNum_']=0x0;}else this['pieces_']=_0x1b2755,this['pieceNum_']=_0x2d9812;}['toString'](){let _0x5df941='';for(let _0x236745=this['pieceNum_'];_0x236745<this['pieces_']['length'];_0x236745++)this['pieces_'][_0x236745]!==''&&(_0x5df941+='/'+this['pieces_'][_0x236745]);return _0x5df941||'/';}}function w(){return new C('');}function y(_0xedf2fd){return _0xedf2fd['pieceNum_']>=_0xedf2fd['pieces_']['length']?null:_0xedf2fd['pieces_'][_0xedf2fd['pieceNum_']];}function we(_0x517b22){return _0x517b22['pieces_']['length']-_0x517b22['pieceNum_'];}function b(_0x2b0cc2){let _0x440283=_0x2b0cc2['pieceNum_'];return _0x440283<_0x2b0cc2['pieces_']['length']&&_0x440283++,new C(_0x2b0cc2['pieces_'],_0x440283);}function Gi(_0x4533e2){return _0x4533e2['pieceNum_']<_0x4533e2['pieces_']['length']?_0x4533e2['pieces_'][_0x4533e2['pieces_']['length']-0x1]:null;}function Ch(_0x342687){let _0x5e8e65='';for(let _0x3edba7=_0x342687['pieceNum_'];_0x3edba7<_0x342687['pieces_']['length'];_0x3edba7++)_0x342687['pieces_'][_0x3edba7]!==''&&(_0x5e8e65+='/'+encodeURIComponent(String(_0x342687['pieces_'][_0x3edba7])));return _0x5e8e65||'/';}function kt(_0x5f376e,_0x3fefd8=0x0){return _0x5f376e['pieces_']['slice'](_0x5f376e['pieceNum_']+_0x3fefd8);}function To(_0x331168){if(_0x331168['pieceNum_']>=_0x331168['pieces_']['length'])return null;const _0x23e38b=[];for(let _0x119bed=_0x331168['pieceNum_'];_0x119bed<_0x331168['pieces_']['length']-0x1;_0x119bed++)_0x23e38b['push'](_0x331168['pieces_'][_0x119bed]);return new C(_0x23e38b,0x0);}function A(_0x576383,_0x3bbe7c){const _0x504e5b=[];for(let _0x27b712=_0x576383['pieceNum_'];_0x27b712<_0x576383['pieces_']['length'];_0x27b712++)_0x504e5b['push'](_0x576383['pieces_'][_0x27b712]);if(_0x3bbe7c instanceof C){for(let _0x2ca327=_0x3bbe7c['pieceNum_'];_0x2ca327<_0x3bbe7c['pieces_']['length'];_0x2ca327++)_0x504e5b['push'](_0x3bbe7c['pieces_'][_0x2ca327]);}else{const _0x144442=_0x3bbe7c['split']('/');for(let _0x25425a=0x0;_0x25425a<_0x144442['length'];_0x25425a++)_0x144442[_0x25425a]['length']>0x0&&_0x504e5b['push'](_0x144442[_0x25425a]);}return new C(_0x504e5b,0x0);}function v(_0x1c113d){return _0x1c113d['pieceNum_']>=_0x1c113d['pieces_']['length'];}function F(_0x2f7197,_0x47a03c){const _0x2e1123=y(_0x2f7197),_0x2ecb35=y(_0x47a03c);if(_0x2e1123===null)return _0x47a03c;if(_0x2e1123===_0x2ecb35)return F(b(_0x2f7197),b(_0x47a03c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x47a03c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2f7197+')');}function Th(_0x50c709,_0x575589){const _0x364ad4=kt(_0x50c709,0x0),_0x262d88=kt(_0x575589,0x0);for(let _0x1d5f90=0x0;_0x1d5f90<_0x364ad4['length']&&_0x1d5f90<_0x262d88['length'];_0x1d5f90++){const _0x262f4e=He(_0x364ad4[_0x1d5f90],_0x262d88[_0x1d5f90]);if(_0x262f4e!==0x0)return _0x262f4e;}return _0x364ad4['length']===_0x262d88['length']?0x0:_0x364ad4['length']<_0x262d88['length']?-0x1:0x1;}function qi(_0x53654c,_0x4e26f7){if(we(_0x53654c)!==we(_0x4e26f7))return!0x1;for(let _0x3e43c3=_0x53654c['pieceNum_'],_0xe54b61=_0x4e26f7['pieceNum_'];_0x3e43c3<=_0x53654c['pieces_']['length'];_0x3e43c3++,_0xe54b61++)if(_0x53654c['pieces_'][_0x3e43c3]!==_0x4e26f7['pieces_'][_0xe54b61])return!0x1;return!0x0;}function $(_0x459d0e,_0x38e188){let _0x159c37=_0x459d0e['pieceNum_'],_0x44b838=_0x38e188['pieceNum_'];if(we(_0x459d0e)>we(_0x38e188))return!0x1;for(;_0x159c37<_0x459d0e['pieces_']['length'];){if(_0x459d0e['pieces_'][_0x159c37]!==_0x38e188['pieces_'][_0x44b838])return!0x1;++_0x159c37,++_0x44b838;}return!0x0;}class Sh{constructor(_0x1d641f,_0x1d6eb3){this['errorPrefix_']=_0x1d6eb3,this['parts_']=kt(_0x1d641f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2e9fcf=0x0;_0x2e9fcf<this['parts_']['length'];_0x2e9fcf++)this['byteLength_']+=Pn(this['parts_'][_0x2e9fcf]);So(this);}}function bh(_0x4a7d84,_0x82bfbb){_0x4a7d84['parts_']['length']>0x0&&(_0x4a7d84['byteLength_']+=0x1),_0x4a7d84['parts_']['push'](_0x82bfbb),_0x4a7d84['byteLength_']+=Pn(_0x82bfbb),So(_0x4a7d84);}function Rh(_0x3c5c02){const _0x33e942=_0x3c5c02['parts_']['pop']();_0x3c5c02['byteLength_']-=Pn(_0x33e942),_0x3c5c02['parts_']['length']>0x0&&(_0x3c5c02['byteLength_']-=0x1);}function So(_0x483789){if(_0x483789['byteLength_']>Js)throw new Error(_0x483789['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x483789['byteLength_']+').');if(_0x483789['parts_']['length']>Qs)throw new Error(_0x483789['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x483789));}function Ne(_0x3a5c53){return _0x3a5c53['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3a5c53['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x50cf7b,_0x178ab6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x178ab6='visibilitychange',_0x50cf7b='hidden'):typeof document['mozHidden']<'u'?(_0x178ab6='mozvisibilitychange',_0x50cf7b='mozHidden'):typeof document['msHidden']<'u'?(_0x178ab6='msvisibilitychange',_0x50cf7b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x178ab6='webkitvisibilitychange',_0x50cf7b='webkitHidden')),this['visible_']=!0x0,_0x178ab6&&document['addEventListener'](_0x178ab6,()=>{const _0x2ba4c5=!document[_0x50cf7b];_0x2ba4c5!==this['visible_']&&(this['visible_']=_0x2ba4c5,this['trigger']('visible',_0x2ba4c5));},!0x1);}['getInitialEvent'](_0x884333){return f(_0x884333==='visible','Unknown\x20event\x20type:\x20'+_0x884333),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x366429,_0x495d19,_0x41094e,_0x3ff65d,_0x1e7061,_0x4fa820,_0x29435d,_0x42f9c4){if(super(),this['repoInfo_']=_0x366429,this['applicationId_']=_0x495d19,this['onDataUpdate_']=_0x41094e,this['onConnectStatus_']=_0x3ff65d,this['onServerInfoUpdate_']=_0x1e7061,this['authTokenProvider_']=_0x4fa820,this['appCheckTokenProvider_']=_0x29435d,this['authOverride_']=_0x42f9c4,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x42f9c4)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x366429['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x89d3e9,_0x288e80,_0x3c2e67){const _0x40a03c=++this['requestNumber_'],_0x4ea246={'r':_0x40a03c,'a':_0x89d3e9,'b':_0x288e80};this['log_'](O(_0x4ea246)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4ea246),_0x3c2e67&&(this['requestCBHash_'][_0x40a03c]=_0x3c2e67);}['get'](_0x367779){this['initConnection_']();const _0x3e5d54=new Ve(),_0x530081={'action':'g','request':{'p':_0x367779['_path']['toString'](),'q':_0x367779['_queryObject']},'onComplete':_0x1aaa91=>{const _0x230d58=_0x1aaa91['d'];_0x1aaa91['s']==='ok'?_0x3e5d54['resolve'](_0x230d58):_0x3e5d54['reject'](_0x230d58);}};this['outstandingGets_']['push'](_0x530081),this['outstandingGetCount_']++;const _0x27d418=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x27d418),_0x3e5d54['promise'];}['listen'](_0x551d65,_0x5cfa7d,_0x3007a4,_0x3ed915){this['initConnection_']();const _0x9bf865=_0x551d65['_queryIdentifier'],_0x1e3481=_0x551d65['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1e3481+'\x20'+_0x9bf865),this['listens']['has'](_0x1e3481)||this['listens']['set'](_0x1e3481,new Map()),f(_0x551d65['_queryParams']['isDefault']()||!_0x551d65['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1e3481)['has'](_0x9bf865),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2d2987={'onComplete':_0x3ed915,'hashFn':_0x5cfa7d,'query':_0x551d65,'tag':_0x3007a4};this['listens']['get'](_0x1e3481)['set'](_0x9bf865,_0x2d2987),this['connected_']&&this['sendListen_'](_0x2d2987);}['sendGet_'](_0x2a0f75){const _0x1b262e=this['outstandingGets_'][_0x2a0f75];this['sendRequest']('g',_0x1b262e['request'],_0x10bbff=>{delete this['outstandingGets_'][_0x2a0f75],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1b262e['onComplete']&&_0x1b262e['onComplete'](_0x10bbff);});}['sendListen_'](_0x2774e0){const _0x32e0e3=_0x2774e0['query'],_0x53840f=_0x32e0e3['_path']['toString'](),_0x47a2bb=_0x32e0e3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x53840f+'\x20for\x20'+_0x47a2bb);const _0x42f614={'p':_0x53840f},_0xab45c9='q';_0x2774e0['tag']&&(_0x42f614['q']=_0x32e0e3['_queryObject'],_0x42f614['t']=_0x2774e0['tag']),_0x42f614['h']=_0x2774e0['hashFn'](),this['sendRequest'](_0xab45c9,_0x42f614,_0x30932f=>{const _0x5a1645=_0x30932f['d'],_0x32f2e1=_0x30932f['s'];ie['warnOnListenWarnings_'](_0x5a1645,_0x32e0e3),(this['listens']['get'](_0x53840f)&&this['listens']['get'](_0x53840f)['get'](_0x47a2bb))===_0x2774e0&&(this['log_']('listen\x20response',_0x30932f),_0x32f2e1!=='ok'&&this['removeListen_'](_0x53840f,_0x47a2bb),_0x2774e0['onComplete']&&_0x2774e0['onComplete'](_0x32f2e1,_0x5a1645));});}static['warnOnListenWarnings_'](_0x3a2785,_0x48bb9c){if(_0x3a2785&&typeof _0x3a2785=='object'&&Y(_0x3a2785,'w')){const _0x357a69=Oe(_0x3a2785,'w');if(Array['isArray'](_0x357a69)&&~_0x357a69['indexOf']('no_index')){const _0x218648='\x22.indexOn\x22:\x20\x22'+_0x48bb9c['_queryParams']['getIndex']()['toString']()+'\x22',_0x36ce1a=_0x48bb9c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x218648+'\x20at\x20'+_0x36ce1a+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3c8f76){this['authToken_']=_0x3c8f76,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3c8f76);}['reduceReconnectDelayIfAdminCredential_'](_0xe3b285){(_0xe3b285&&_0xe3b285['length']===0x28||vc(_0xe3b285))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x231d03){this['appCheckToken_']=_0x231d03,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2c81dd=this['authToken_'],_0x51db22=yc(_0x2c81dd)?'auth':'gauth',_0x1f396e={'cred':_0x2c81dd};this['authOverride_']===null?_0x1f396e['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x1f396e['authvar']=this['authOverride_']),this['sendRequest'](_0x51db22,_0x1f396e,_0x4d4ef1=>{const _0x1eca50=_0x4d4ef1['s'],_0x256352=_0x4d4ef1['d']||'error';this['authToken_']===_0x2c81dd&&(_0x1eca50==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x1eca50,_0x256352));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x632ad9=>{const _0x13c424=_0x632ad9['s'],_0x11ec28=_0x632ad9['d']||'error';_0x13c424==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x13c424,_0x11ec28);});}['unlisten'](_0x423491,_0x546a5d){const _0x4d9119=_0x423491['_path']['toString'](),_0x203859=_0x423491['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4d9119+'\x20'+_0x203859),f(_0x423491['_queryParams']['isDefault']()||!_0x423491['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4d9119,_0x203859)&&this['connected_']&&this['sendUnlisten_'](_0x4d9119,_0x203859,_0x423491['_queryObject'],_0x546a5d);}['sendUnlisten_'](_0xb94a5b,_0x11714e,_0x150a9e,_0x1ad6b0){this['log_']('Unlisten\x20on\x20'+_0xb94a5b+'\x20for\x20'+_0x11714e);const _0x223ee8={'p':_0xb94a5b},_0x3c710d='n';_0x1ad6b0&&(_0x223ee8['q']=_0x150a9e,_0x223ee8['t']=_0x1ad6b0),this['sendRequest'](_0x3c710d,_0x223ee8);}['onDisconnectPut'](_0x12fd63,_0x1cc7a2,_0x87ab8d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x12fd63,_0x1cc7a2,_0x87ab8d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x12fd63,'action':'o','data':_0x1cc7a2,'onComplete':_0x87ab8d});}['onDisconnectMerge'](_0x1ebec7,_0x3bf02b,_0x46e2cd){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1ebec7,_0x3bf02b,_0x46e2cd):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1ebec7,'action':'om','data':_0x3bf02b,'onComplete':_0x46e2cd});}['onDisconnectCancel'](_0x188893,_0x51ed30){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x188893,null,_0x51ed30):this['onDisconnectRequestQueue_']['push']({'pathString':_0x188893,'action':'oc','data':null,'onComplete':_0x51ed30});}['sendOnDisconnect_'](_0x53c9bb,_0x262160,_0x235e19,_0x1f319d){const _0x4a4905={'p':_0x262160,'d':_0x235e19};this['log_']('onDisconnect\x20'+_0x53c9bb,_0x4a4905),this['sendRequest'](_0x53c9bb,_0x4a4905,_0x14e850=>{_0x1f319d&&setTimeout(()=>{_0x1f319d(_0x14e850['s'],_0x14e850['d']);},Math['floor'](0x0));});}['put'](_0x4ba31a,_0x1efdb5,_0x5c408c,_0x1d9e4d){this['putInternal']('p',_0x4ba31a,_0x1efdb5,_0x5c408c,_0x1d9e4d);}['merge'](_0x4a6ea5,_0x13b481,_0x2ee1d5,_0x4ae375){this['putInternal']('m',_0x4a6ea5,_0x13b481,_0x2ee1d5,_0x4ae375);}['putInternal'](_0x2acdde,_0x2a2735,_0x1d00a4,_0x284869,_0x41ce07){this['initConnection_']();const _0x16b141={'p':_0x2a2735,'d':_0x1d00a4};_0x41ce07!==void 0x0&&(_0x16b141['h']=_0x41ce07),this['outstandingPuts_']['push']({'action':_0x2acdde,'request':_0x16b141,'onComplete':_0x284869}),this['outstandingPutCount_']++;const _0x1fbcd9=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x1fbcd9):this['log_']('Buffering\x20put:\x20'+_0x2a2735);}['sendPut_'](_0x14c2cc){const _0x402698=this['outstandingPuts_'][_0x14c2cc]['action'],_0x173588=this['outstandingPuts_'][_0x14c2cc]['request'],_0x450cbb=this['outstandingPuts_'][_0x14c2cc]['onComplete'];this['outstandingPuts_'][_0x14c2cc]['queued']=this['connected_'],this['sendRequest'](_0x402698,_0x173588,_0x1b7a46=>{this['log_'](_0x402698+'\x20response',_0x1b7a46),delete this['outstandingPuts_'][_0x14c2cc],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x450cbb&&_0x450cbb(_0x1b7a46['s'],_0x1b7a46['d']);});}['reportStats'](_0x57e4ca){if(this['connected_']){const _0x9e730c={'c':_0x57e4ca};this['log_']('reportStats',_0x9e730c),this['sendRequest']('s',_0x9e730c,_0x347231=>{if(_0x347231['s']!=='ok'){const _0x897f82=_0x347231['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x897f82);}});}}['onDataMessage_'](_0x232a01){if('r'in _0x232a01){this['log_']('from\x20server:\x20'+O(_0x232a01));const _0x9f8020=_0x232a01['r'],_0xe81c3a=this['requestCBHash_'][_0x9f8020];_0xe81c3a&&(delete this['requestCBHash_'][_0x9f8020],_0xe81c3a(_0x232a01['b']));}else{if('error'in _0x232a01)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x232a01['error'];'a'in _0x232a01&&this['onDataPush_'](_0x232a01['a'],_0x232a01['b']);}}['onDataPush_'](_0x4b0593,_0x2fb939){this['log_']('handleServerMessage',_0x4b0593,_0x2fb939),_0x4b0593==='d'?this['onDataUpdate_'](_0x2fb939['p'],_0x2fb939['d'],!0x1,_0x2fb939['t']):_0x4b0593==='m'?this['onDataUpdate_'](_0x2fb939['p'],_0x2fb939['d'],!0x0,_0x2fb939['t']):_0x4b0593==='c'?this['onListenRevoked_'](_0x2fb939['p'],_0x2fb939['q']):_0x4b0593==='ac'?this['onAuthRevoked_'](_0x2fb939['s'],_0x2fb939['d']):_0x4b0593==='apc'?this['onAppCheckRevoked_'](_0x2fb939['s'],_0x2fb939['d']):_0x4b0593==='sd'?this['onSecurityDebugPacket_'](_0x2fb939):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4b0593)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4ccb5e,_0x28d09f){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4ccb5e),this['lastSessionId']=_0x28d09f,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5d0a10){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5d0a10));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x11e5be){_0x11e5be&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x11e5be;}['onOnline_'](_0x362110){_0x362110?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x51ee50=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2537ce=Math['max'](0x0,this['reconnectDelay_']-_0x51ee50);_0x2537ce=Math['random']()*_0x2537ce,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2537ce+'ms'),this['scheduleConnect_'](_0x2537ce),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2344bc=this['onDataMessage_']['bind'](this),_0x3795a1=this['onReady_']['bind'](this),_0x284aee=this['onRealtimeDisconnect_']['bind'](this),_0x31da06=this['id']+':'+ie['nextConnectionId_']++,_0x5cf574=this['lastSessionId'];let _0x27a239=!0x1,_0x41c240=null;const _0x583167=function(){_0x41c240?_0x41c240['close']():(_0x27a239=!0x0,_0x284aee());},_0x20eea1=function(_0x4cc5ea){f(_0x41c240,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x41c240['sendRequest'](_0x4cc5ea);};this['realtime_']={'close':_0x583167,'sendRequest':_0x20eea1};const _0x3279f3=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x344468,_0x18dfa9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3279f3),this['appCheckTokenProvider_']['getToken'](_0x3279f3)]);_0x27a239?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x344468&&_0x344468['accessToken'],this['appCheckToken_']=_0x18dfa9&&_0x18dfa9['token'],_0x41c240=new wh(_0x31da06,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2344bc,_0x3795a1,_0x284aee,_0x4f488c=>{U(_0x4f488c+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5cf574));}catch(_0x35ccbb){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x35ccbb),_0x27a239||(this['repoInfo_']['nodeAdmin']&&U(_0x35ccbb),_0x583167());}}}['interrupt'](_0xbf1bf3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xbf1bf3),this['interruptReasons_'][_0xbf1bf3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4e8bf4){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4e8bf4),delete this['interruptReasons_'][_0x4e8bf4],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x52cf7d){const _0x54e1f0=_0x52cf7d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x54e1f0});}['cancelSentTransactions_'](){for(let _0x69e0cf=0x0;_0x69e0cf<this['outstandingPuts_']['length'];_0x69e0cf++){const _0x42bc5f=this['outstandingPuts_'][_0x69e0cf];_0x42bc5f&&'h'in _0x42bc5f['request']&&_0x42bc5f['queued']&&(_0x42bc5f['onComplete']&&_0x42bc5f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x69e0cf],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2b6026,_0x3d1cec){let _0x520ff0;_0x3d1cec?_0x520ff0=_0x3d1cec['map'](_0x5ab87e=>Bi(_0x5ab87e))['join']('$'):_0x520ff0='default';const _0x4871de=this['removeListen_'](_0x2b6026,_0x520ff0);_0x4871de&&_0x4871de['onComplete']&&_0x4871de['onComplete']('permission_denied');}['removeListen_'](_0x4f6683,_0x5eb5f7){const _0x5bbea0=new C(_0x4f6683)['toString']();let _0x38279c;if(this['listens']['has'](_0x5bbea0)){const _0x5df0bd=this['listens']['get'](_0x5bbea0);_0x38279c=_0x5df0bd['get'](_0x5eb5f7),_0x5df0bd['delete'](_0x5eb5f7),_0x5df0bd['size']===0x0&&this['listens']['delete'](_0x5bbea0);}else _0x38279c=void 0x0;return _0x38279c;}['onAuthRevoked_'](_0x36370c,_0x57b940){L('Auth\x20token\x20revoked:\x20'+_0x36370c+'/'+_0x57b940),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x36370c==='invalid_token'||_0x36370c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4266e4,_0x1ddd9b){L('App\x20check\x20token\x20revoked:\x20'+_0x4266e4+'/'+_0x1ddd9b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4266e4==='invalid_token'||_0x4266e4==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x55c426){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x55c426):'msg'in _0x55c426&&console['log']('FIREBASE:\x20'+_0x55c426['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3a2c4a of this['listens']['values']())for(const _0x65f250 of _0x3a2c4a['values']())this['sendListen_'](_0x65f250);for(let _0x23e3f2=0x0;_0x23e3f2<this['outstandingPuts_']['length'];_0x23e3f2++)this['outstandingPuts_'][_0x23e3f2]&&this['sendPut_'](_0x23e3f2);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2355c7=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2355c7['action'],_0x2355c7['pathString'],_0x2355c7['data'],_0x2355c7['onComplete']);}for(let _0x2b13f9=0x0;_0x2b13f9<this['outstandingGets_']['length'];_0x2b13f9++)this['outstandingGets_'][_0x2b13f9]&&this['sendGet_'](_0x2b13f9);}['sendConnectStats_'](){const _0x45b894={};let _0x21a166='js';_0x45b894['sdk.'+_0x21a166+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x45b894['framework.cordova']=0x1:qr()&&(_0x45b894['framework.reactnative']=0x1),this['reportStats'](_0x45b894);}['shouldReconnect_'](){const _0x3933c2=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x3933c2;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1629a6,_0x3c0e56){this['name']=_0x1629a6,this['node']=_0x3c0e56;}static['Wrap'](_0x179be3,_0x3d430e){return new E(_0x179be3,_0x3d430e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x30224e,_0x26f7b0){const _0x17280c=new E(xe,_0x30224e),_0x4f012b=new E(xe,_0x26f7b0);return this['compare'](_0x17280c,_0x4f012b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x503f10){Xt=_0x503f10;}['compare'](_0x5f2ffa,_0x574961){return He(_0x5f2ffa['name'],_0x574961['name']);}['isDefinedOn'](_0x228a83){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x32fbfa,_0x2e6796){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0xeb641c,_0xbb9c3b){return f(typeof _0xeb641c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xeb641c,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x442c6e,_0xf759ba,_0x5d224e,_0x4e29e0,_0x3022d4=null){this['isReverse_']=_0x4e29e0,this['resultGenerator_']=_0x3022d4,this['nodeStack_']=[];let _0x15e403=0x1;for(;!_0x442c6e['isEmpty']();)if(_0x442c6e=_0x442c6e,_0x15e403=_0xf759ba?_0x5d224e(_0x442c6e['key'],_0xf759ba):0x1,_0x4e29e0&&(_0x15e403*=-0x1),_0x15e403<0x0)this['isReverse_']?_0x442c6e=_0x442c6e['left']:_0x442c6e=_0x442c6e['right'];else{if(_0x15e403===0x0){this['nodeStack_']['push'](_0x442c6e);break;}else this['nodeStack_']['push'](_0x442c6e),this['isReverse_']?_0x442c6e=_0x442c6e['right']:_0x442c6e=_0x442c6e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x376f1a=this['nodeStack_']['pop'](),_0x50f21d;if(this['resultGenerator_']?_0x50f21d=this['resultGenerator_'](_0x376f1a['key'],_0x376f1a['value']):_0x50f21d={'key':_0x376f1a['key'],'value':_0x376f1a['value']},this['isReverse_']){for(_0x376f1a=_0x376f1a['left'];!_0x376f1a['isEmpty']();)this['nodeStack_']['push'](_0x376f1a),_0x376f1a=_0x376f1a['right'];}else{for(_0x376f1a=_0x376f1a['right'];!_0x376f1a['isEmpty']();)this['nodeStack_']['push'](_0x376f1a),_0x376f1a=_0x376f1a['left'];}return _0x50f21d;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5d339d=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5d339d['key'],_0x5d339d['value']):{'key':_0x5d339d['key'],'value':_0x5d339d['value']};}}class M{constructor(_0x3d4fd5,_0x313d3a,_0x1dd328,_0x50b9b6,_0x315cc7){this['key']=_0x3d4fd5,this['value']=_0x313d3a,this['color']=_0x1dd328??M['RED'],this['left']=_0x50b9b6??B['EMPTY_NODE'],this['right']=_0x315cc7??B['EMPTY_NODE'];}['copy'](_0x37d68f,_0xc697b2,_0x2cf427,_0x5be4ea,_0x36622b){return new M(_0x37d68f??this['key'],_0xc697b2??this['value'],_0x2cf427??this['color'],_0x5be4ea??this['left'],_0x36622b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4ff514){return this['left']['inorderTraversal'](_0x4ff514)||!!_0x4ff514(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4ff514);}['reverseTraversal'](_0x372218){return this['right']['reverseTraversal'](_0x372218)||_0x372218(this['key'],this['value'])||this['left']['reverseTraversal'](_0x372218);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x180828,_0x4f78ab,_0x4f5c19){let _0x233e5c=this;const _0xba6afa=_0x4f5c19(_0x180828,_0x233e5c['key']);return _0xba6afa<0x0?_0x233e5c=_0x233e5c['copy'](null,null,null,_0x233e5c['left']['insert'](_0x180828,_0x4f78ab,_0x4f5c19),null):_0xba6afa===0x0?_0x233e5c=_0x233e5c['copy'](null,_0x4f78ab,null,null,null):_0x233e5c=_0x233e5c['copy'](null,null,null,null,_0x233e5c['right']['insert'](_0x180828,_0x4f78ab,_0x4f5c19)),_0x233e5c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x111860=this;return!_0x111860['left']['isRed_']()&&!_0x111860['left']['left']['isRed_']()&&(_0x111860=_0x111860['moveRedLeft_']()),_0x111860=_0x111860['copy'](null,null,null,_0x111860['left']['removeMin_'](),null),_0x111860['fixUp_']();}['remove'](_0x200ee1,_0x317d17){let _0x4dfc63,_0x2a987f;if(_0x4dfc63=this,_0x317d17(_0x200ee1,_0x4dfc63['key'])<0x0)!_0x4dfc63['left']['isEmpty']()&&!_0x4dfc63['left']['isRed_']()&&!_0x4dfc63['left']['left']['isRed_']()&&(_0x4dfc63=_0x4dfc63['moveRedLeft_']()),_0x4dfc63=_0x4dfc63['copy'](null,null,null,_0x4dfc63['left']['remove'](_0x200ee1,_0x317d17),null);else{if(_0x4dfc63['left']['isRed_']()&&(_0x4dfc63=_0x4dfc63['rotateRight_']()),!_0x4dfc63['right']['isEmpty']()&&!_0x4dfc63['right']['isRed_']()&&!_0x4dfc63['right']['left']['isRed_']()&&(_0x4dfc63=_0x4dfc63['moveRedRight_']()),_0x317d17(_0x200ee1,_0x4dfc63['key'])===0x0){if(_0x4dfc63['right']['isEmpty']())return B['EMPTY_NODE'];_0x2a987f=_0x4dfc63['right']['min_'](),_0x4dfc63=_0x4dfc63['copy'](_0x2a987f['key'],_0x2a987f['value'],null,null,_0x4dfc63['right']['removeMin_']());}_0x4dfc63=_0x4dfc63['copy'](null,null,null,null,_0x4dfc63['right']['remove'](_0x200ee1,_0x317d17));}return _0x4dfc63['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x55ccad=this;return _0x55ccad['right']['isRed_']()&&!_0x55ccad['left']['isRed_']()&&(_0x55ccad=_0x55ccad['rotateLeft_']()),_0x55ccad['left']['isRed_']()&&_0x55ccad['left']['left']['isRed_']()&&(_0x55ccad=_0x55ccad['rotateRight_']()),_0x55ccad['left']['isRed_']()&&_0x55ccad['right']['isRed_']()&&(_0x55ccad=_0x55ccad['colorFlip_']()),_0x55ccad;}['moveRedLeft_'](){let _0x42e060=this['colorFlip_']();return _0x42e060['right']['left']['isRed_']()&&(_0x42e060=_0x42e060['copy'](null,null,null,null,_0x42e060['right']['rotateRight_']()),_0x42e060=_0x42e060['rotateLeft_'](),_0x42e060=_0x42e060['colorFlip_']()),_0x42e060;}['moveRedRight_'](){let _0x1a1651=this['colorFlip_']();return _0x1a1651['left']['left']['isRed_']()&&(_0x1a1651=_0x1a1651['rotateRight_'](),_0x1a1651=_0x1a1651['colorFlip_']()),_0x1a1651;}['rotateLeft_'](){const _0x1b47eb=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1b47eb,null);}['rotateRight_'](){const _0x180209=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x180209);}['colorFlip_'](){const _0x3c1356=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x35180b=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3c1356,_0x35180b);}['checkMaxDepth_'](){const _0x1346bb=this['check_']();return Math['pow'](0x2,_0x1346bb)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1fb328=this['left']['check_']();if(_0x1fb328!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1fb328+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x56f389,_0x2fbc27,_0x2d73c1,_0x7a3167,_0x12b8f3){return this;}['insert'](_0x3d273d,_0x19764d,_0x186912){return new M(_0x3d273d,_0x19764d,null);}['remove'](_0x9e8b1c,_0x32986e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3d144e){return!0x1;}['reverseTraversal'](_0x44bcc8){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x3be602,_0x22641e=B['EMPTY_NODE']){this['comparator_']=_0x3be602,this['root_']=_0x22641e;}['insert'](_0x536cfd,_0x2f09d6){return new B(this['comparator_'],this['root_']['insert'](_0x536cfd,_0x2f09d6,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x36ee3c){return new B(this['comparator_'],this['root_']['remove'](_0x36ee3c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1a671e){let _0x420add,_0x4b12d0=this['root_'];for(;!_0x4b12d0['isEmpty']();){if(_0x420add=this['comparator_'](_0x1a671e,_0x4b12d0['key']),_0x420add===0x0)return _0x4b12d0['value'];_0x420add<0x0?_0x4b12d0=_0x4b12d0['left']:_0x420add>0x0&&(_0x4b12d0=_0x4b12d0['right']);}return null;}['getPredecessorKey'](_0x51c5d2){let _0x23b3f8,_0x4c605b=this['root_'],_0x235b62=null;for(;!_0x4c605b['isEmpty']();)if(_0x23b3f8=this['comparator_'](_0x51c5d2,_0x4c605b['key']),_0x23b3f8===0x0){if(_0x4c605b['left']['isEmpty']())return _0x235b62?_0x235b62['key']:null;for(_0x4c605b=_0x4c605b['left'];!_0x4c605b['right']['isEmpty']();)_0x4c605b=_0x4c605b['right'];return _0x4c605b['key'];}else _0x23b3f8<0x0?_0x4c605b=_0x4c605b['left']:_0x23b3f8>0x0&&(_0x235b62=_0x4c605b,_0x4c605b=_0x4c605b['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5903c6){return this['root_']['inorderTraversal'](_0x5903c6);}['reverseTraversal'](_0x20e203){return this['root_']['reverseTraversal'](_0x20e203);}['getIterator'](_0xb546aa){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0xb546aa);}['getIteratorFrom'](_0x3594a9,_0x5edcd6){return new Zt(this['root_'],_0x3594a9,this['comparator_'],!0x1,_0x5edcd6);}['getReverseIteratorFrom'](_0x30ea94,_0x37193d){return new Zt(this['root_'],_0x30ea94,this['comparator_'],!0x0,_0x37193d);}['getReverseIterator'](_0x38ff67){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x38ff67);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x576411,_0xea7ac9){return He(_0x576411['name'],_0xea7ac9['name']);}function ji(_0x14035f,_0x2f19a4){return He(_0x14035f,_0x2f19a4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x12ede5){vi=_0x12ede5;}const Ro=function(_0x2b8f6f){return typeof _0x2b8f6f=='number'?'number:'+so(_0x2b8f6f):'string:'+_0x2b8f6f;},Ao=function(_0x3a8c0d){if(_0x3a8c0d['isLeafNode']()){const _0x53e906=_0x3a8c0d['val']();f(typeof _0x53e906=='string'||typeof _0x53e906=='number'||typeof _0x53e906=='object'&&Y(_0x53e906,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3a8c0d===vi||_0x3a8c0d['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3a8c0d===vi||_0x3a8c0d['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x4bd8c4){er=_0x4bd8c4;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x447119,_0x4bd938=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x447119,this['priorityNode_']=_0x4bd938,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x22b541){return new D(this['value_'],_0x22b541);}['getImmediateChild'](_0x517cd5){return _0x517cd5==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x70848){return v(_0x70848)?this:y(_0x70848)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x14f19b,_0x40ec86){return null;}['updateImmediateChild'](_0x38b8c1,_0x206507){return _0x38b8c1==='.priority'?this['updatePriority'](_0x206507):_0x206507['isEmpty']()&&_0x38b8c1!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x38b8c1,_0x206507)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x342cc8,_0x3520cb){const _0x490668=y(_0x342cc8);return _0x490668===null?_0x3520cb:_0x3520cb['isEmpty']()&&_0x490668!=='.priority'?this:(f(_0x490668!=='.priority'||we(_0x342cc8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x490668,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x342cc8),_0x3520cb)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3a9ba4,_0x27cfaa){return!0x1;}['val'](_0x415e2f){return _0x415e2f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x42e5cc='';this['priorityNode_']['isEmpty']()||(_0x42e5cc+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x509c02=typeof this['value_'];_0x42e5cc+=_0x509c02+':',_0x509c02==='number'?_0x42e5cc+=so(this['value_']):_0x42e5cc+=this['value_'],this['lazyHash_']=no(_0x42e5cc);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x266caf){return _0x266caf===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x266caf instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x266caf['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x266caf));}['compareToLeafNode_'](_0x86c011){const _0x34d2f5=typeof _0x86c011['value_'],_0xb3a455=typeof this['value_'],_0x93b248=D['VALUE_TYPE_ORDER']['indexOf'](_0x34d2f5),_0x3d59a7=D['VALUE_TYPE_ORDER']['indexOf'](_0xb3a455);return f(_0x93b248>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x34d2f5),f(_0x3d59a7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xb3a455),_0x93b248===_0x3d59a7?_0xb3a455==='object'?0x0:this['value_']<_0x86c011['value_']?-0x1:this['value_']===_0x86c011['value_']?0x0:0x1:_0x3d59a7-_0x93b248;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5d3e81){if(_0x5d3e81===this)return!0x0;if(_0x5d3e81['isLeafNode']()){const _0x5125da=_0x5d3e81;return this['value_']===_0x5125da['value_']&&this['priorityNode_']['equals'](_0x5125da['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x1f6630){ko=_0x1f6630;}function xh(_0x49d1b6){No=_0x49d1b6;}class Fh extends On{['compare'](_0x5b7195,_0x152b1d){const _0x51510a=_0x5b7195['node']['getPriority'](),_0x2a0a89=_0x152b1d['node']['getPriority'](),_0x331efa=_0x51510a['compareTo'](_0x2a0a89);return _0x331efa===0x0?He(_0x5b7195['name'],_0x152b1d['name']):_0x331efa;}['isDefinedOn'](_0x138bed){return!_0x138bed['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x399832,_0x5b2468){return!_0x399832['getPriority']()['equals'](_0x5b2468['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1c6a44,_0xda5f66){const _0x4cb444=ko(_0x1c6a44);return new E(_0xda5f66,new D('[PRIORITY-POST]',_0x4cb444));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x5b9222){const _0x528b91=_0x15beb5=>parseInt(Math['log'](_0x15beb5)/Uh,0xa),_0x40fe1f=_0x571154=>parseInt(Array(_0x571154+0x1)['join']('1'),0x2);this['count']=_0x528b91(_0x5b9222+0x1),this['current_']=this['count']-0x1;const _0x361365=_0x40fe1f(this['count']);this['bits_']=_0x5b9222+0x1&_0x361365;}['nextBitIsOne'](){const _0x398dec=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x398dec;}}const dn=function(_0x5dab89,_0x22f26d,_0x380ce5,_0x1c7b2e){_0x5dab89['sort'](_0x22f26d);const _0x5012ca=function(_0x37b8fa,_0x33fe5f){const _0x130763=_0x33fe5f-_0x37b8fa;let _0x175fea,_0x5ea04a;if(_0x130763===0x0)return null;if(_0x130763===0x1)return _0x175fea=_0x5dab89[_0x37b8fa],_0x5ea04a=_0x380ce5?_0x380ce5(_0x175fea):_0x175fea,new M(_0x5ea04a,_0x175fea['node'],M['BLACK'],null,null);{const _0x40678c=parseInt(_0x130763/0x2,0xa)+_0x37b8fa,_0x33f3a5=_0x5012ca(_0x37b8fa,_0x40678c),_0x4c1341=_0x5012ca(_0x40678c+0x1,_0x33fe5f);return _0x175fea=_0x5dab89[_0x40678c],_0x5ea04a=_0x380ce5?_0x380ce5(_0x175fea):_0x175fea,new M(_0x5ea04a,_0x175fea['node'],M['BLACK'],_0x33f3a5,_0x4c1341);}},_0x698d7f=function(_0x5db233){let _0x16739f=null,_0x29e73c=null,_0x17ced2=_0x5dab89['length'];const _0x2d8266=function(_0x34f190,_0x2b8b97){const _0x38ae77=_0x17ced2-_0x34f190,_0x209c2a=_0x17ced2;_0x17ced2-=_0x34f190;const _0x3edfac=_0x5012ca(_0x38ae77+0x1,_0x209c2a),_0x4167b1=_0x5dab89[_0x38ae77],_0xf631a7=_0x380ce5?_0x380ce5(_0x4167b1):_0x4167b1;_0x2da08b(new M(_0xf631a7,_0x4167b1['node'],_0x2b8b97,null,_0x3edfac));},_0x2da08b=function(_0x1e1438){_0x16739f?(_0x16739f['left']=_0x1e1438,_0x16739f=_0x1e1438):(_0x29e73c=_0x1e1438,_0x16739f=_0x1e1438);};for(let _0x26ffbe=0x0;_0x26ffbe<_0x5db233['count'];++_0x26ffbe){const _0x24c43b=_0x5db233['nextBitIsOne'](),_0x143442=Math['pow'](0x2,_0x5db233['count']-(_0x26ffbe+0x1));_0x24c43b?_0x2d8266(_0x143442,M['BLACK']):(_0x2d8266(_0x143442,M['BLACK']),_0x2d8266(_0x143442,M['RED']));}return _0x29e73c;},_0x5d284b=new Wh(_0x5dab89['length']),_0x4ea545=_0x698d7f(_0x5d284b);return new B(_0x1c7b2e||_0x22f26d,_0x4ea545);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x58d918,_0x477a63){this['indexes_']=_0x58d918,this['indexSet_']=_0x477a63;}['get'](_0x3765d7){const _0x2d49af=Oe(this['indexes_'],_0x3765d7);if(!_0x2d49af)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3765d7);return _0x2d49af instanceof B?_0x2d49af:null;}['hasIndex'](_0x2b0b44){return Y(this['indexSet_'],_0x2b0b44['toString']());}['addIndex'](_0x1b4ac5,_0x1fc3db){f(_0x1b4ac5!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x117349=[];let _0x43c74a=!0x1;const _0x1ddfd6=_0x1fc3db['getIterator'](E['Wrap']);let _0x23b627=_0x1ddfd6['getNext']();for(;_0x23b627;)_0x43c74a=_0x43c74a||_0x1b4ac5['isDefinedOn'](_0x23b627['node']),_0x117349['push'](_0x23b627),_0x23b627=_0x1ddfd6['getNext']();let _0x53e38e;_0x43c74a?_0x53e38e=dn(_0x117349,_0x1b4ac5['getCompare']()):_0x53e38e=je;const _0x27aeae=_0x1b4ac5['toString'](),_0x249036={...this['indexSet_']};_0x249036[_0x27aeae]=_0x1b4ac5;const _0x26f2f9={...this['indexes_']};return _0x26f2f9[_0x27aeae]=_0x53e38e,new ee(_0x26f2f9,_0x249036);}['addToIndexes'](_0xd701b3,_0x406a35){const _0xe28ca9=ln(this['indexes_'],(_0x5daada,_0x1e2702)=>{const _0x283183=Oe(this['indexSet_'],_0x1e2702);if(f(_0x283183,'Missing\x20index\x20implementation\x20for\x20'+_0x1e2702),_0x5daada===je){if(_0x283183['isDefinedOn'](_0xd701b3['node'])){const _0x493d39=[],_0x1db335=_0x406a35['getIterator'](E['Wrap']);let _0x1cef65=_0x1db335['getNext']();for(;_0x1cef65;)_0x1cef65['name']!==_0xd701b3['name']&&_0x493d39['push'](_0x1cef65),_0x1cef65=_0x1db335['getNext']();return _0x493d39['push'](_0xd701b3),dn(_0x493d39,_0x283183['getCompare']());}else return je;}else{const _0x3ec8d3=_0x406a35['get'](_0xd701b3['name']);let _0x4b9246=_0x5daada;return _0x3ec8d3&&(_0x4b9246=_0x4b9246['remove'](new E(_0xd701b3['name'],_0x3ec8d3))),_0x4b9246['insert'](_0xd701b3,_0xd701b3['node']);}});return new ee(_0xe28ca9,this['indexSet_']);}['removeFromIndexes'](_0x4cfbf8,_0x221828){const _0x376e24=ln(this['indexes_'],_0x2693f5=>{if(_0x2693f5===je)return _0x2693f5;{const _0x3b3e79=_0x221828['get'](_0x4cfbf8['name']);return _0x3b3e79?_0x2693f5['remove'](new E(_0x4cfbf8['name'],_0x3b3e79)):_0x2693f5;}});return new ee(_0x376e24,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x2f678b,_0x93bd03,_0x374e48){this['children_']=_0x2f678b,this['priorityNode_']=_0x93bd03,this['indexMap_']=_0x374e48,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x26e679){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x26e679,this['indexMap_']);}['getImmediateChild'](_0x176569){if(_0x176569==='.priority')return this['getPriority']();{const _0x2074ae=this['children_']['get'](_0x176569);return _0x2074ae===null?gt:_0x2074ae;}}['getChild'](_0x24f214){const _0x3d276f=y(_0x24f214);return _0x3d276f===null?this:this['getImmediateChild'](_0x3d276f)['getChild'](b(_0x24f214));}['hasChild'](_0x166297){return this['children_']['get'](_0x166297)!==null;}['updateImmediateChild'](_0x2f250f,_0x10ea1c){if(f(_0x10ea1c,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2f250f==='.priority')return this['updatePriority'](_0x10ea1c);{const _0x41c6e9=new E(_0x2f250f,_0x10ea1c);let _0x5b66bd,_0x348ecd;_0x10ea1c['isEmpty']()?(_0x5b66bd=this['children_']['remove'](_0x2f250f),_0x348ecd=this['indexMap_']['removeFromIndexes'](_0x41c6e9,this['children_'])):(_0x5b66bd=this['children_']['insert'](_0x2f250f,_0x10ea1c),_0x348ecd=this['indexMap_']['addToIndexes'](_0x41c6e9,this['children_']));const _0x4b9028=_0x5b66bd['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5b66bd,_0x4b9028,_0x348ecd);}}['updateChild'](_0xccae6d,_0x12e843){const _0x1718f9=y(_0xccae6d);if(_0x1718f9===null)return _0x12e843;{f(y(_0xccae6d)!=='.priority'||we(_0xccae6d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4dbfaf=this['getImmediateChild'](_0x1718f9)['updateChild'](b(_0xccae6d),_0x12e843);return this['updateImmediateChild'](_0x1718f9,_0x4dbfaf);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5bced6){if(this['isEmpty']())return null;const _0x1b804b={};let _0x17e5f5=0x0,_0x24c534=0x0,_0x23adbc=!0x0;if(this['forEachChild'](R,(_0x29e714,_0x25b292)=>{_0x1b804b[_0x29e714]=_0x25b292['val'](_0x5bced6),_0x17e5f5++,_0x23adbc&&g['INTEGER_REGEXP_']['test'](_0x29e714)?_0x24c534=Math['max'](_0x24c534,Number(_0x29e714)):_0x23adbc=!0x1;}),!_0x5bced6&&_0x23adbc&&_0x24c534<0x2*_0x17e5f5){const _0x2d3fc0=[];for(const _0x187cba in _0x1b804b)_0x2d3fc0[_0x187cba]=_0x1b804b[_0x187cba];return _0x2d3fc0;}else return _0x5bced6&&!this['getPriority']()['isEmpty']()&&(_0x1b804b['.priority']=this['getPriority']()['val']()),_0x1b804b;}['hash'](){if(this['lazyHash_']===null){let _0x57c7ca='';this['getPriority']()['isEmpty']()||(_0x57c7ca+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1cc4b6,_0x1851e8)=>{const _0x290520=_0x1851e8['hash']();_0x290520!==''&&(_0x57c7ca+=':'+_0x1cc4b6+':'+_0x290520);}),this['lazyHash_']=_0x57c7ca===''?'':no(_0x57c7ca);}return this['lazyHash_'];}['getPredecessorChildName'](_0xfed989,_0x579443,_0x4f8e3d){const _0x5340bb=this['resolveIndex_'](_0x4f8e3d);if(_0x5340bb){const _0x2432cd=_0x5340bb['getPredecessorKey'](new E(_0xfed989,_0x579443));return _0x2432cd?_0x2432cd['name']:null;}else return this['children_']['getPredecessorKey'](_0xfed989);}['getFirstChildName'](_0x16e80f){const _0x4d9fee=this['resolveIndex_'](_0x16e80f);if(_0x4d9fee){const _0x3f3e42=_0x4d9fee['minKey']();return _0x3f3e42&&_0x3f3e42['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x35f4c0){const _0x23580e=this['getFirstChildName'](_0x35f4c0);return _0x23580e?new E(_0x23580e,this['children_']['get'](_0x23580e)):null;}['getLastChildName'](_0x579993){const _0x156aa9=this['resolveIndex_'](_0x579993);if(_0x156aa9){const _0x90e198=_0x156aa9['maxKey']();return _0x90e198&&_0x90e198['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5d2601){const _0x494eab=this['getLastChildName'](_0x5d2601);return _0x494eab?new E(_0x494eab,this['children_']['get'](_0x494eab)):null;}['forEachChild'](_0x2f914d,_0x3fce60){const _0x5427ff=this['resolveIndex_'](_0x2f914d);return _0x5427ff?_0x5427ff['inorderTraversal'](_0x16b6da=>_0x3fce60(_0x16b6da['name'],_0x16b6da['node'])):this['children_']['inorderTraversal'](_0x3fce60);}['getIterator'](_0x5ceec6){return this['getIteratorFrom'](_0x5ceec6['minPost'](),_0x5ceec6);}['getIteratorFrom'](_0x143dc7,_0x2c002c){const _0x86b418=this['resolveIndex_'](_0x2c002c);if(_0x86b418)return _0x86b418['getIteratorFrom'](_0x143dc7,_0x57fca3=>_0x57fca3);{const _0x4607c1=this['children_']['getIteratorFrom'](_0x143dc7['name'],E['Wrap']);let _0x22d58b=_0x4607c1['peek']();for(;_0x22d58b!=null&&_0x2c002c['compare'](_0x22d58b,_0x143dc7)<0x0;)_0x4607c1['getNext'](),_0x22d58b=_0x4607c1['peek']();return _0x4607c1;}}['getReverseIterator'](_0xe07342){return this['getReverseIteratorFrom'](_0xe07342['maxPost'](),_0xe07342);}['getReverseIteratorFrom'](_0x3768e7,_0x9efd35){const _0x3613db=this['resolveIndex_'](_0x9efd35);if(_0x3613db)return _0x3613db['getReverseIteratorFrom'](_0x3768e7,_0x23ec9c=>_0x23ec9c);{const _0x1b955c=this['children_']['getReverseIteratorFrom'](_0x3768e7['name'],E['Wrap']);let _0x2ec4b8=_0x1b955c['peek']();for(;_0x2ec4b8!=null&&_0x9efd35['compare'](_0x2ec4b8,_0x3768e7)>0x0;)_0x1b955c['getNext'](),_0x2ec4b8=_0x1b955c['peek']();return _0x1b955c;}}['compareTo'](_0x55ba4a){return this['isEmpty']()?_0x55ba4a['isEmpty']()?0x0:-0x1:_0x55ba4a['isLeafNode']()||_0x55ba4a['isEmpty']()?0x1:_0x55ba4a===Ht?-0x1:0x0;}['withIndex'](_0x40063c){if(_0x40063c===ye||this['indexMap_']['hasIndex'](_0x40063c))return this;{const _0x4b0bc2=this['indexMap_']['addIndex'](_0x40063c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4b0bc2);}}['isIndexed'](_0xbd1555){return _0xbd1555===ye||this['indexMap_']['hasIndex'](_0xbd1555);}['equals'](_0x1ccc56){if(_0x1ccc56===this)return!0x0;if(_0x1ccc56['isLeafNode']())return!0x1;{const _0x329de0=_0x1ccc56;if(this['getPriority']()['equals'](_0x329de0['getPriority']())){if(this['children_']['count']()===_0x329de0['children_']['count']()){const _0x4d9a56=this['getIterator'](R),_0x3dcc78=_0x329de0['getIterator'](R);let _0x56eb3a=_0x4d9a56['getNext'](),_0x172465=_0x3dcc78['getNext']();for(;_0x56eb3a&&_0x172465;){if(_0x56eb3a['name']!==_0x172465['name']||!_0x56eb3a['node']['equals'](_0x172465['node']))return!0x1;_0x56eb3a=_0x4d9a56['getNext'](),_0x172465=_0x3dcc78['getNext']();}return _0x56eb3a===null&&_0x172465===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x55f402){return _0x55f402===ye?null:this['indexMap_']['get'](_0x55f402['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x21e630){return _0x21e630===this?0x0:0x1;}['equals'](_0x412fe5){return _0x412fe5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x42e7b2){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x15ef4e,_0x46e910=null){if(_0x15ef4e===null)return g['EMPTY_NODE'];if(typeof _0x15ef4e=='object'&&'.priority'in _0x15ef4e&&(_0x46e910=_0x15ef4e['.priority']),f(_0x46e910===null||typeof _0x46e910=='string'||typeof _0x46e910=='number'||typeof _0x46e910=='object'&&'.sv'in _0x46e910,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x46e910),typeof _0x15ef4e=='object'&&'.value'in _0x15ef4e&&_0x15ef4e['.value']!==null&&(_0x15ef4e=_0x15ef4e['.value']),typeof _0x15ef4e!='object'||'.sv'in _0x15ef4e){const _0x5602ae=_0x15ef4e;return new D(_0x5602ae,N(_0x46e910));}if(!(_0x15ef4e instanceof Array)&&Vh){const _0x77169f=[];let _0x5d1528=!0x1;if(x(_0x15ef4e,(_0x1de7b8,_0x236891)=>{if(_0x1de7b8['substring'](0x0,0x1)!=='.'){const _0x4c9a61=N(_0x236891);_0x4c9a61['isEmpty']()||(_0x5d1528=_0x5d1528||!_0x4c9a61['getPriority']()['isEmpty'](),_0x77169f['push'](new E(_0x1de7b8,_0x4c9a61)));}}),_0x77169f['length']===0x0)return g['EMPTY_NODE'];const _0x13f473=dn(_0x77169f,Dh,_0x3353d9=>_0x3353d9['name'],ji);if(_0x5d1528){const _0x538dda=dn(_0x77169f,R['getCompare']());return new g(_0x13f473,N(_0x46e910),new ee({'.priority':_0x538dda},{'.priority':R}));}else return new g(_0x13f473,N(_0x46e910),ee['Default']);}else{let _0xdea22d=g['EMPTY_NODE'];return x(_0x15ef4e,(_0x3cafeb,_0x344faf)=>{if(Y(_0x15ef4e,_0x3cafeb)&&_0x3cafeb['substring'](0x0,0x1)!=='.'){const _0x2050b6=N(_0x344faf);(_0x2050b6['isLeafNode']()||!_0x2050b6['isEmpty']())&&(_0xdea22d=_0xdea22d['updateImmediateChild'](_0x3cafeb,_0x2050b6));}}),_0xdea22d['updatePriority'](N(_0x46e910));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2eb354){super(),this['indexPath_']=_0x2eb354,f(!v(_0x2eb354)&&y(_0x2eb354)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5748ec){return _0x5748ec['getChild'](this['indexPath_']);}['isDefinedOn'](_0xf47e57){return!_0xf47e57['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x482437,_0x2b4c3c){const _0x57b5b1=this['extractChild'](_0x482437['node']),_0x465dcd=this['extractChild'](_0x2b4c3c['node']),_0x218c9c=_0x57b5b1['compareTo'](_0x465dcd);return _0x218c9c===0x0?He(_0x482437['name'],_0x2b4c3c['name']):_0x218c9c;}['makePost'](_0x390e73,_0xc728e){const _0x4c2313=N(_0x390e73),_0xd1fd1a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4c2313);return new E(_0xc728e,_0xd1fd1a);}['maxPost'](){const _0x452785=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x452785);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x45c144,_0x57b3d5){const _0x50f641=_0x45c144['node']['compareTo'](_0x57b3d5['node']);return _0x50f641===0x0?He(_0x45c144['name'],_0x57b3d5['name']):_0x50f641;}['isDefinedOn'](_0x3ea2db){return!0x0;}['indexedValueChanged'](_0x576349,_0x1cb612){return!_0x576349['equals'](_0x1cb612);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x343803,_0x53c5b4){const _0x2a06fa=N(_0x343803);return new E(_0x53c5b4,_0x2a06fa);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x4a86dc){return{'type':'value','snapshotNode':_0x4a86dc};}function tt(_0x47c010,_0x44a894){return{'type':'child_added','snapshotNode':_0x44a894,'childName':_0x47c010};}function Nt(_0x574796,_0x42a4ff){return{'type':'child_removed','snapshotNode':_0x42a4ff,'childName':_0x574796};}function Pt(_0x5cf0d9,_0x77c6be,_0x570348){return{'type':'child_changed','snapshotNode':_0x77c6be,'childName':_0x5cf0d9,'oldSnap':_0x570348};}function $h(_0x472329,_0x40655b){return{'type':'child_moved','snapshotNode':_0x40655b,'childName':_0x472329};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x426105){this['index_']=_0x426105;}['updateChild'](_0x3aeb20,_0x13c135,_0x49ff32,_0x9819eb,_0x7451e2,_0x3a3ccc){f(_0x3aeb20['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x286068=_0x3aeb20['getImmediateChild'](_0x13c135);return _0x286068['getChild'](_0x9819eb)['equals'](_0x49ff32['getChild'](_0x9819eb))&&_0x286068['isEmpty']()===_0x49ff32['isEmpty']()||(_0x3a3ccc!=null&&(_0x49ff32['isEmpty']()?_0x3aeb20['hasChild'](_0x13c135)?_0x3a3ccc['trackChildChange'](Nt(_0x13c135,_0x286068)):f(_0x3aeb20['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x286068['isEmpty']()?_0x3a3ccc['trackChildChange'](tt(_0x13c135,_0x49ff32)):_0x3a3ccc['trackChildChange'](Pt(_0x13c135,_0x49ff32,_0x286068))),_0x3aeb20['isLeafNode']()&&_0x49ff32['isEmpty']())?_0x3aeb20:_0x3aeb20['updateImmediateChild'](_0x13c135,_0x49ff32)['withIndex'](this['index_']);}['updateFullNode'](_0x49f109,_0x42053a,_0x23a928){return _0x23a928!=null&&(_0x49f109['isLeafNode']()||_0x49f109['forEachChild'](R,(_0x2fa3ea,_0x40c317)=>{_0x42053a['hasChild'](_0x2fa3ea)||_0x23a928['trackChildChange'](Nt(_0x2fa3ea,_0x40c317));}),_0x42053a['isLeafNode']()||_0x42053a['forEachChild'](R,(_0x452ccf,_0x58b29e)=>{if(_0x49f109['hasChild'](_0x452ccf)){const _0x4e4c8b=_0x49f109['getImmediateChild'](_0x452ccf);_0x4e4c8b['equals'](_0x58b29e)||_0x23a928['trackChildChange'](Pt(_0x452ccf,_0x58b29e,_0x4e4c8b));}else _0x23a928['trackChildChange'](tt(_0x452ccf,_0x58b29e));})),_0x42053a['withIndex'](this['index_']);}['updatePriority'](_0x310637,_0x2385b2){return _0x310637['isEmpty']()?g['EMPTY_NODE']:_0x310637['updatePriority'](_0x2385b2);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x14ba1d){this['indexedFilter_']=new Yi(_0x14ba1d['getIndex']()),this['index_']=_0x14ba1d['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x14ba1d),this['endPost_']=Ot['getEndPost_'](_0x14ba1d),this['startIsInclusive_']=!_0x14ba1d['startAfterSet_'],this['endIsInclusive_']=!_0x14ba1d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x478304){const _0x25c173=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x478304)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x478304)<0x0,_0x45a99f=this['endIsInclusive_']?this['index_']['compare'](_0x478304,this['getEndPost']())<=0x0:this['index_']['compare'](_0x478304,this['getEndPost']())<0x0;return _0x25c173&&_0x45a99f;}['updateChild'](_0x2f31bd,_0x212748,_0x2f76bd,_0x7f0055,_0x2e4ca5,_0xd2f39){return this['matches'](new E(_0x212748,_0x2f76bd))||(_0x2f76bd=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2f31bd,_0x212748,_0x2f76bd,_0x7f0055,_0x2e4ca5,_0xd2f39);}['updateFullNode'](_0x356564,_0x5af16c,_0x534ea3){_0x5af16c['isLeafNode']()&&(_0x5af16c=g['EMPTY_NODE']);let _0x17d176=_0x5af16c['withIndex'](this['index_']);_0x17d176=_0x17d176['updatePriority'](g['EMPTY_NODE']);const _0x683fda=this;return _0x5af16c['forEachChild'](R,(_0x13fb5b,_0x38e31f)=>{_0x683fda['matches'](new E(_0x13fb5b,_0x38e31f))||(_0x17d176=_0x17d176['updateImmediateChild'](_0x13fb5b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x356564,_0x17d176,_0x534ea3);}['updatePriority'](_0x387329,_0x1e399e){return _0x387329;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x44099f){if(_0x44099f['hasStart']()){const _0xac0ee4=_0x44099f['getIndexStartName']();return _0x44099f['getIndex']()['makePost'](_0x44099f['getIndexStartValue'](),_0xac0ee4);}else return _0x44099f['getIndex']()['minPost']();}static['getEndPost_'](_0x3feb3b){if(_0x3feb3b['hasEnd']()){const _0x17c0a4=_0x3feb3b['getIndexEndName']();return _0x3feb3b['getIndex']()['makePost'](_0x3feb3b['getIndexEndValue'](),_0x17c0a4);}else return _0x3feb3b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x194bc8){this['withinDirectionalStart']=_0x4d98d5=>this['reverse_']?this['withinEndPost'](_0x4d98d5):this['withinStartPost'](_0x4d98d5),this['withinDirectionalEnd']=_0x389477=>this['reverse_']?this['withinStartPost'](_0x389477):this['withinEndPost'](_0x389477),this['withinStartPost']=_0x2a592c=>{const _0x365973=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2a592c);return this['startIsInclusive_']?_0x365973<=0x0:_0x365973<0x0;},this['withinEndPost']=_0x93599e=>{const _0x2037ff=this['index_']['compare'](_0x93599e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2037ff<=0x0:_0x2037ff<0x0;},this['rangedFilter_']=new Ot(_0x194bc8),this['index_']=_0x194bc8['getIndex'](),this['limit_']=_0x194bc8['getLimit'](),this['reverse_']=!_0x194bc8['isViewFromLeft'](),this['startIsInclusive_']=!_0x194bc8['startAfterSet_'],this['endIsInclusive_']=!_0x194bc8['endBeforeSet_'];}['updateChild'](_0x34dbd5,_0x304700,_0xc8874,_0x3b66ef,_0x79f754,_0x36592f){return this['rangedFilter_']['matches'](new E(_0x304700,_0xc8874))||(_0xc8874=g['EMPTY_NODE']),_0x34dbd5['getImmediateChild'](_0x304700)['equals'](_0xc8874)?_0x34dbd5:_0x34dbd5['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x34dbd5,_0x304700,_0xc8874,_0x3b66ef,_0x79f754,_0x36592f):this['fullLimitUpdateChild_'](_0x34dbd5,_0x304700,_0xc8874,_0x79f754,_0x36592f);}['updateFullNode'](_0x125238,_0x514363,_0x54a941){let _0x197baa;if(_0x514363['isLeafNode']()||_0x514363['isEmpty']())_0x197baa=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x514363['numChildren']()&&_0x514363['isIndexed'](this['index_'])){_0x197baa=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x46ac72;this['reverse_']?_0x46ac72=_0x514363['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x46ac72=_0x514363['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x22157f=0x0;for(;_0x46ac72['hasNext']()&&_0x22157f<this['limit_'];){const _0x2edadb=_0x46ac72['getNext']();if(this['withinDirectionalStart'](_0x2edadb)){if(this['withinDirectionalEnd'](_0x2edadb))_0x197baa=_0x197baa['updateImmediateChild'](_0x2edadb['name'],_0x2edadb['node']),_0x22157f++;else break;}else continue;}}else{_0x197baa=_0x514363['withIndex'](this['index_']),_0x197baa=_0x197baa['updatePriority'](g['EMPTY_NODE']);let _0x387966;this['reverse_']?_0x387966=_0x197baa['getReverseIterator'](this['index_']):_0x387966=_0x197baa['getIterator'](this['index_']);let _0x473c38=0x0;for(;_0x387966['hasNext']();){const _0x239630=_0x387966['getNext']();_0x473c38<this['limit_']&&this['withinDirectionalStart'](_0x239630)&&this['withinDirectionalEnd'](_0x239630)?_0x473c38++:_0x197baa=_0x197baa['updateImmediateChild'](_0x239630['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x125238,_0x197baa,_0x54a941);}['updatePriority'](_0x3d288f,_0x347f2f){return _0x3d288f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x8ec7aa,_0x2e1dcd,_0x50d392,_0x358fce,_0x33ce8c){let _0x3663f1;if(this['reverse_']){const _0x235721=this['index_']['getCompare']();_0x3663f1=(_0xc478fa,_0x4f58c8)=>_0x235721(_0x4f58c8,_0xc478fa);}else _0x3663f1=this['index_']['getCompare']();const _0x3818a3=_0x8ec7aa;f(_0x3818a3['numChildren']()===this['limit_'],'');const _0x1ea077=new E(_0x2e1dcd,_0x50d392),_0x3d1627=this['reverse_']?_0x3818a3['getFirstChild'](this['index_']):_0x3818a3['getLastChild'](this['index_']),_0x5cbfd9=this['rangedFilter_']['matches'](_0x1ea077);if(_0x3818a3['hasChild'](_0x2e1dcd)){const _0x2a928c=_0x3818a3['getImmediateChild'](_0x2e1dcd);let _0x20f0b2=_0x358fce['getChildAfterChild'](this['index_'],_0x3d1627,this['reverse_']);for(;_0x20f0b2!=null&&(_0x20f0b2['name']===_0x2e1dcd||_0x3818a3['hasChild'](_0x20f0b2['name']));)_0x20f0b2=_0x358fce['getChildAfterChild'](this['index_'],_0x20f0b2,this['reverse_']);const _0x5a5f36=_0x20f0b2==null?0x1:_0x3663f1(_0x20f0b2,_0x1ea077);if(_0x5cbfd9&&!_0x50d392['isEmpty']()&&_0x5a5f36>=0x0)return _0x33ce8c!=null&&_0x33ce8c['trackChildChange'](Pt(_0x2e1dcd,_0x50d392,_0x2a928c)),_0x3818a3['updateImmediateChild'](_0x2e1dcd,_0x50d392);{_0x33ce8c!=null&&_0x33ce8c['trackChildChange'](Nt(_0x2e1dcd,_0x2a928c));const _0x129868=_0x3818a3['updateImmediateChild'](_0x2e1dcd,g['EMPTY_NODE']);return _0x20f0b2!=null&&this['rangedFilter_']['matches'](_0x20f0b2)?(_0x33ce8c!=null&&_0x33ce8c['trackChildChange'](tt(_0x20f0b2['name'],_0x20f0b2['node'])),_0x129868['updateImmediateChild'](_0x20f0b2['name'],_0x20f0b2['node'])):_0x129868;}}else return _0x50d392['isEmpty']()?_0x8ec7aa:_0x5cbfd9&&_0x3663f1(_0x3d1627,_0x1ea077)>=0x0?(_0x33ce8c!=null&&(_0x33ce8c['trackChildChange'](Nt(_0x3d1627['name'],_0x3d1627['node'])),_0x33ce8c['trackChildChange'](tt(_0x2e1dcd,_0x50d392))),_0x3818a3['updateImmediateChild'](_0x2e1dcd,_0x50d392)['updateImmediateChild'](_0x3d1627['name'],g['EMPTY_NODE'])):_0x8ec7aa;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4d65a6=new Qi();return _0x4d65a6['limitSet_']=this['limitSet_'],_0x4d65a6['limit_']=this['limit_'],_0x4d65a6['startSet_']=this['startSet_'],_0x4d65a6['startAfterSet_']=this['startAfterSet_'],_0x4d65a6['indexStartValue_']=this['indexStartValue_'],_0x4d65a6['startNameSet_']=this['startNameSet_'],_0x4d65a6['indexStartName_']=this['indexStartName_'],_0x4d65a6['endSet_']=this['endSet_'],_0x4d65a6['endBeforeSet_']=this['endBeforeSet_'],_0x4d65a6['indexEndValue_']=this['indexEndValue_'],_0x4d65a6['endNameSet_']=this['endNameSet_'],_0x4d65a6['indexEndName_']=this['indexEndName_'],_0x4d65a6['index_']=this['index_'],_0x4d65a6['viewFrom_']=this['viewFrom_'],_0x4d65a6;}}function qh(_0x21081f){return _0x21081f['loadsAllData']()?new Yi(_0x21081f['getIndex']()):_0x21081f['hasLimit']()?new Gh(_0x21081f):new Ot(_0x21081f);}function zh(_0x1b42d2,_0x4e2806){const _0x4a435f=_0x1b42d2['copy']();return _0x4a435f['limitSet_']=!0x0,_0x4a435f['limit_']=_0x4e2806,_0x4a435f['viewFrom_']='l',_0x4a435f;}function jh(_0x3b2454,_0x15d1be,_0x41af3b){const _0x2660c9=_0x3b2454['copy']();return _0x2660c9['startSet_']=!0x0,_0x15d1be===void 0x0&&(_0x15d1be=null),_0x2660c9['indexStartValue_']=_0x15d1be,_0x41af3b!=null?(_0x2660c9['startNameSet_']=!0x0,_0x2660c9['indexStartName_']=_0x41af3b):(_0x2660c9['startNameSet_']=!0x1,_0x2660c9['indexStartName_']=''),_0x2660c9;}function Kh(_0x2b4b00,_0x29957b,_0x2fe4d8){const _0x38d522=_0x2b4b00['copy']();return _0x38d522['endSet_']=!0x0,_0x29957b===void 0x0&&(_0x29957b=null),_0x38d522['indexEndValue_']=_0x29957b,_0x2fe4d8!==void 0x0?(_0x38d522['endNameSet_']=!0x0,_0x38d522['indexEndName_']=_0x2fe4d8):(_0x38d522['endNameSet_']=!0x1,_0x38d522['indexEndName_']=''),_0x38d522;}function Do(_0x305e08,_0x4fa104){const _0x25ef73=_0x305e08['copy']();return _0x25ef73['index_']=_0x4fa104,_0x25ef73;}function tr(_0x2fa50f){const _0x2458f1={};if(_0x2fa50f['isDefault']())return _0x2458f1;let _0x5da359;if(_0x2fa50f['index_']===R?_0x5da359='$priority':_0x2fa50f['index_']===Po?_0x5da359='$value':_0x2fa50f['index_']===ye?_0x5da359='$key':(f(_0x2fa50f['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x5da359=_0x2fa50f['index_']['toString']()),_0x2458f1['orderBy']=O(_0x5da359),_0x2fa50f['startSet_']){const _0x33467e=_0x2fa50f['startAfterSet_']?'startAfter':'startAt';_0x2458f1[_0x33467e]=O(_0x2fa50f['indexStartValue_']),_0x2fa50f['startNameSet_']&&(_0x2458f1[_0x33467e]+=','+O(_0x2fa50f['indexStartName_']));}if(_0x2fa50f['endSet_']){const _0x3ed1ca=_0x2fa50f['endBeforeSet_']?'endBefore':'endAt';_0x2458f1[_0x3ed1ca]=O(_0x2fa50f['indexEndValue_']),_0x2fa50f['endNameSet_']&&(_0x2458f1[_0x3ed1ca]+=','+O(_0x2fa50f['indexEndName_']));}return _0x2fa50f['limitSet_']&&(_0x2fa50f['isViewFromLeft']()?_0x2458f1['limitToFirst']=_0x2fa50f['limit_']:_0x2458f1['limitToLast']=_0x2fa50f['limit_']),_0x2458f1;}function nr(_0x59309c){const _0x409274={};if(_0x59309c['startSet_']&&(_0x409274['sp']=_0x59309c['indexStartValue_'],_0x59309c['startNameSet_']&&(_0x409274['sn']=_0x59309c['indexStartName_']),_0x409274['sin']=!_0x59309c['startAfterSet_']),_0x59309c['endSet_']&&(_0x409274['ep']=_0x59309c['indexEndValue_'],_0x59309c['endNameSet_']&&(_0x409274['en']=_0x59309c['indexEndName_']),_0x409274['ein']=!_0x59309c['endBeforeSet_']),_0x59309c['limitSet_']){_0x409274['l']=_0x59309c['limit_'];let _0x14838c=_0x59309c['viewFrom_'];_0x14838c===''&&(_0x59309c['isViewFromLeft']()?_0x14838c='l':_0x14838c='r'),_0x409274['vf']=_0x14838c;}return _0x59309c['index_']!==R&&(_0x409274['i']=_0x59309c['index_']['toString']()),_0x409274;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x57f598){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x55bce4,_0x543563){return _0x543563!==void 0x0?'tag$'+_0x543563:(f(_0x55bce4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x55bce4['_path']['toString']());}constructor(_0x3a8a43,_0x2ad035,_0x1d4d2e,_0x2a8bff){super(),this['repoInfo_']=_0x3a8a43,this['onDataUpdate_']=_0x2ad035,this['authTokenProvider_']=_0x1d4d2e,this['appCheckTokenProvider_']=_0x2a8bff,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x1f4c6d,_0x16b3fd,_0x57b6f5,_0x2c7d3b){const _0x497cbd=_0x1f4c6d['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x497cbd+'\x20'+_0x1f4c6d['_queryIdentifier']);const _0xa50f85=fn['getListenId_'](_0x1f4c6d,_0x57b6f5),_0x212a0f={};this['listens_'][_0xa50f85]=_0x212a0f;const _0x2a449c=tr(_0x1f4c6d['_queryParams']);this['restRequest_'](_0x497cbd+'.json',_0x2a449c,(_0x2b50a0,_0x528c98)=>{let _0x5747b3=_0x528c98;if(_0x2b50a0===0x194&&(_0x5747b3=null,_0x2b50a0=null),_0x2b50a0===null&&this['onDataUpdate_'](_0x497cbd,_0x5747b3,!0x1,_0x57b6f5),Oe(this['listens_'],_0xa50f85)===_0x212a0f){let _0x46dd31;_0x2b50a0?_0x2b50a0===0x191?_0x46dd31='permission_denied':_0x46dd31='rest_error:'+_0x2b50a0:_0x46dd31='ok',_0x2c7d3b(_0x46dd31,null);}});}['unlisten'](_0x50bddf,_0x423852){const _0x784e6f=fn['getListenId_'](_0x50bddf,_0x423852);delete this['listens_'][_0x784e6f];}['get'](_0x2bacdd){const _0x11eadc=tr(_0x2bacdd['_queryParams']),_0x1bf30b=_0x2bacdd['_path']['toString'](),_0x58e2f7=new Ve();return this['restRequest_'](_0x1bf30b+'.json',_0x11eadc,(_0x5afff1,_0x4237fb)=>{let _0x16b601=_0x4237fb;_0x5afff1===0x194&&(_0x16b601=null,_0x5afff1=null),_0x5afff1===null?(this['onDataUpdate_'](_0x1bf30b,_0x16b601,!0x1,null),_0x58e2f7['resolve'](_0x16b601)):_0x58e2f7['reject'](new Error(_0x16b601));}),_0x58e2f7['promise'];}['refreshAuthToken'](_0x1a8806){}['restRequest_'](_0x4da0b5,_0x344ddf={},_0x3ee84a){return _0x344ddf['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x335c0b,_0x1bdf99])=>{_0x335c0b&&_0x335c0b['accessToken']&&(_0x344ddf['auth']=_0x335c0b['accessToken']),_0x1bdf99&&_0x1bdf99['token']&&(_0x344ddf['ac']=_0x1bdf99['token']);const _0x276285=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4da0b5+'?ns='+this['repoInfo_']['namespace']+at(_0x344ddf);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x276285);const _0x18336f=new XMLHttpRequest();_0x18336f['onreadystatechange']=()=>{if(_0x3ee84a&&_0x18336f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x276285+'\x20received.\x20status:',_0x18336f['status'],'response:',_0x18336f['responseText']);let _0x44a245=null;if(_0x18336f['status']>=0xc8&&_0x18336f['status']<0x12c){try{_0x44a245=bt(_0x18336f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x276285+':\x20'+_0x18336f['responseText']);}_0x3ee84a(null,_0x44a245);}else _0x18336f['status']!==0x191&&_0x18336f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x276285+'\x20Status:\x20'+_0x18336f['status']),_0x3ee84a(_0x18336f['status']);_0x3ee84a=null;}},_0x18336f['open']('GET',_0x276285,!0x0),_0x18336f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x509774){return this['rootNode_']['getChild'](_0x509774);}['updateSnapshot'](_0x54520f,_0x56132e){this['rootNode_']=this['rootNode_']['updateChild'](_0x54520f,_0x56132e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x29a739,_0x3f27b5,_0x194d6e){if(v(_0x3f27b5))_0x29a739['value']=_0x194d6e,_0x29a739['children']['clear']();else{if(_0x29a739['value']!==null)_0x29a739['value']=_0x29a739['value']['updateChild'](_0x3f27b5,_0x194d6e);else{const _0x27dbb9=y(_0x3f27b5);_0x29a739['children']['has'](_0x27dbb9)||_0x29a739['children']['set'](_0x27dbb9,pn());const _0x47d8c4=_0x29a739['children']['get'](_0x27dbb9);_0x3f27b5=b(_0x3f27b5),Mo(_0x47d8c4,_0x3f27b5,_0x194d6e);}}}function Ei(_0x21de8a,_0x54ef98,_0x4afe4e){_0x21de8a['value']!==null?_0x4afe4e(_0x54ef98,_0x21de8a['value']):Qh(_0x21de8a,(_0x57f725,_0x51d27d)=>{const _0x2b9aed=new C(_0x54ef98['toString']()+'/'+_0x57f725);Ei(_0x51d27d,_0x2b9aed,_0x4afe4e);});}function Qh(_0x43a8c7,_0x19949d){_0x43a8c7['children']['forEach']((_0x1aafad,_0x27a6d5)=>{_0x19949d(_0x27a6d5,_0x1aafad);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x52f020){this['collection_']=_0x52f020,this['last_']=null;}['get'](){const _0x450b06=this['collection_']['get'](),_0x21064c={..._0x450b06};return this['last_']&&x(this['last_'],(_0x13cdfd,_0x8b13a7)=>{_0x21064c[_0x13cdfd]=_0x21064c[_0x13cdfd]-_0x8b13a7;}),this['last_']=_0x450b06,_0x21064c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x2f181f,_0x162abe){this['server_']=_0x162abe,this['statsToReport_']={},this['statsListener_']=new Jh(_0x2f181f);const _0xe84ebb=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0xe84ebb));}['reportStats_'](){const _0x22ce9c=this['statsListener_']['get'](),_0x424b0b={};let _0x2c239d=!0x1;x(_0x22ce9c,(_0x106058,_0xc0be59)=>{_0xc0be59>0x0&&Y(this['statsToReport_'],_0x106058)&&(_0x424b0b[_0x106058]=_0xc0be59,_0x2c239d=!0x0);}),_0x2c239d&&this['server_']['reportStats'](_0x424b0b),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x1d20bc){_0x1d20bc[_0x1d20bc['OVERWRITE']=0x0]='OVERWRITE',_0x1d20bc[_0x1d20bc['MERGE']=0x1]='MERGE',_0x1d20bc[_0x1d20bc['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1d20bc[_0x1d20bc['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0xa2303e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xa2303e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0xb9655f,_0x428122,_0x2fa748){this['path']=_0xb9655f,this['affectedTree']=_0x428122,this['revert']=_0x2fa748,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x43d08e){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x48ac0d=this['affectedTree']['subtree'](new C(_0x43d08e));return new _n(w(),_0x48ac0d,this['revert']);}}else return f(y(this['path'])===_0x43d08e,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x38c641,_0x41e49f){this['source']=_0x38c641,this['path']=_0x41e49f,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x148abb){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x170036,_0x1df219,_0x215c60){this['source']=_0x170036,this['path']=_0x1df219,this['snap']=_0x215c60,this['type']=q['OVERWRITE'];}['operationForChild'](_0x235b6a){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x235b6a)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x300ebd,_0x1ccea9,_0x38fe85){this['source']=_0x300ebd,this['path']=_0x1ccea9,this['children']=_0x38fe85,this['type']=q['MERGE'];}['operationForChild'](_0x30524f){if(v(this['path'])){const _0x42548c=this['children']['subtree'](new C(_0x30524f));return _0x42548c['isEmpty']()?null:_0x42548c['value']?new Fe(this['source'],w(),_0x42548c['value']):new nt(this['source'],w(),_0x42548c);}else return f(y(this['path'])===_0x30524f,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x40657d,_0x1779f9,_0x56d78f){this['node_']=_0x40657d,this['fullyInitialized_']=_0x1779f9,this['filtered_']=_0x56d78f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1710ac){if(v(_0x1710ac))return this['isFullyInitialized']()&&!this['filtered_'];const _0x177f64=y(_0x1710ac);return this['isCompleteForChild'](_0x177f64);}['isCompleteForChild'](_0x394216){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x394216);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x5e3499){this['query_']=_0x5e3499,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x388723,_0x23c09a,_0x1db955,_0x585f39){const _0x1d3df1=[],_0x1fe0a0=[];return _0x23c09a['forEach'](_0x45e501=>{_0x45e501['type']==='child_changed'&&_0x388723['index_']['indexedValueChanged'](_0x45e501['oldSnap'],_0x45e501['snapshotNode'])&&_0x1fe0a0['push']($h(_0x45e501['childName'],_0x45e501['snapshotNode']));}),mt(_0x388723,_0x1d3df1,'child_removed',_0x23c09a,_0x585f39,_0x1db955),mt(_0x388723,_0x1d3df1,'child_added',_0x23c09a,_0x585f39,_0x1db955),mt(_0x388723,_0x1d3df1,'child_moved',_0x1fe0a0,_0x585f39,_0x1db955),mt(_0x388723,_0x1d3df1,'child_changed',_0x23c09a,_0x585f39,_0x1db955),mt(_0x388723,_0x1d3df1,'value',_0x23c09a,_0x585f39,_0x1db955),_0x1d3df1;}function mt(_0x3af9cb,_0x1c6207,_0x121854,_0x4c1321,_0x2004e9,_0x220f7a){const _0x30417c=_0x4c1321['filter'](_0x28ac60=>_0x28ac60['type']===_0x121854);_0x30417c['sort']((_0x28f647,_0x16b87d)=>su(_0x3af9cb,_0x28f647,_0x16b87d)),_0x30417c['forEach'](_0x4391d4=>{const _0xb2afce=iu(_0x3af9cb,_0x4391d4,_0x220f7a);_0x2004e9['forEach'](_0xba30c4=>{_0xba30c4['respondsTo'](_0x4391d4['type'])&&_0x1c6207['push'](_0xba30c4['createEvent'](_0xb2afce,_0x3af9cb['query_']));});});}function iu(_0x22a14b,_0x31a86d,_0x2d8ada){return _0x31a86d['type']==='value'||_0x31a86d['type']==='child_removed'||(_0x31a86d['prevName']=_0x2d8ada['getPredecessorChildName'](_0x31a86d['childName'],_0x31a86d['snapshotNode'],_0x22a14b['index_'])),_0x31a86d;}function su(_0x2d9781,_0x4f93ba,_0x109f13){if(_0x4f93ba['childName']==null||_0x109f13['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x35ae1d=new E(_0x4f93ba['childName'],_0x4f93ba['snapshotNode']),_0x1c9cf9=new E(_0x109f13['childName'],_0x109f13['snapshotNode']);return _0x2d9781['index_']['compare'](_0x35ae1d,_0x1c9cf9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x1b66f4,_0x490759){return{'eventCache':_0x1b66f4,'serverCache':_0x490759};}function wt(_0x4eea1a,_0x42224b,_0x2b2cf9,_0x4c9eef){return Dn(new Ce(_0x42224b,_0x2b2cf9,_0x4c9eef),_0x4eea1a['serverCache']);}function Lo(_0x8b709d,_0x45152a,_0x22aa3a,_0x1cec04){return Dn(_0x8b709d['eventCache'],new Ce(_0x45152a,_0x22aa3a,_0x1cec04));}function gn(_0x515747){return _0x515747['eventCache']['isFullyInitialized']()?_0x515747['eventCache']['getNode']():null;}function Ue(_0x1588e4){return _0x1588e4['serverCache']['isFullyInitialized']()?_0x1588e4['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x441d24){let _0x19de82=new S(null);return x(_0x441d24,(_0x1c319b,_0x51c6ca)=>{_0x19de82=_0x19de82['set'](new C(_0x1c319b),_0x51c6ca);}),_0x19de82;}constructor(_0x569fcc,_0x1b371c=ru()){this['value']=_0x569fcc,this['children']=_0x1b371c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1631ff,_0x30cf3c){if(this['value']!=null&&_0x30cf3c(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1631ff))return null;{const _0x3595=y(_0x1631ff),_0x52f7f8=this['children']['get'](_0x3595);if(_0x52f7f8!==null){const _0x1623e2=_0x52f7f8['findRootMostMatchingPathAndValue'](b(_0x1631ff),_0x30cf3c);return _0x1623e2!=null?{'path':A(new C(_0x3595),_0x1623e2['path']),'value':_0x1623e2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1030ab){return this['findRootMostMatchingPathAndValue'](_0x1030ab,()=>!0x0);}['subtree'](_0x5de8fb){if(v(_0x5de8fb))return this;{const _0x43809b=y(_0x5de8fb),_0x57380e=this['children']['get'](_0x43809b);return _0x57380e!==null?_0x57380e['subtree'](b(_0x5de8fb)):new S(null);}}['set'](_0x387b60,_0x41c95d){if(v(_0x387b60))return new S(_0x41c95d,this['children']);{const _0x57d7ca=y(_0x387b60),_0x42c89b=(this['children']['get'](_0x57d7ca)||new S(null))['set'](b(_0x387b60),_0x41c95d),_0x1a480f=this['children']['insert'](_0x57d7ca,_0x42c89b);return new S(this['value'],_0x1a480f);}}['remove'](_0x1fa09b){if(v(_0x1fa09b))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x521655=y(_0x1fa09b),_0x164e3f=this['children']['get'](_0x521655);if(_0x164e3f){const _0x5814d9=_0x164e3f['remove'](b(_0x1fa09b));let _0x50f80b;return _0x5814d9['isEmpty']()?_0x50f80b=this['children']['remove'](_0x521655):_0x50f80b=this['children']['insert'](_0x521655,_0x5814d9),this['value']===null&&_0x50f80b['isEmpty']()?new S(null):new S(this['value'],_0x50f80b);}else return this;}}['get'](_0x492c85){if(v(_0x492c85))return this['value'];{const _0x2e584d=y(_0x492c85),_0x1cfad8=this['children']['get'](_0x2e584d);return _0x1cfad8?_0x1cfad8['get'](b(_0x492c85)):null;}}['setTree'](_0x36c9d1,_0x2c81dc){if(v(_0x36c9d1))return _0x2c81dc;{const _0x3392e2=y(_0x36c9d1),_0x56d220=(this['children']['get'](_0x3392e2)||new S(null))['setTree'](b(_0x36c9d1),_0x2c81dc);let _0x917962;return _0x56d220['isEmpty']()?_0x917962=this['children']['remove'](_0x3392e2):_0x917962=this['children']['insert'](_0x3392e2,_0x56d220),new S(this['value'],_0x917962);}}['fold'](_0x5f2d04){return this['fold_'](w(),_0x5f2d04);}['fold_'](_0x20506a,_0x126bf2){const _0x23e24a={};return this['children']['inorderTraversal']((_0x19f506,_0x31382b)=>{_0x23e24a[_0x19f506]=_0x31382b['fold_'](A(_0x20506a,_0x19f506),_0x126bf2);}),_0x126bf2(_0x20506a,this['value'],_0x23e24a);}['findOnPath'](_0x994d77,_0x3e4fd2){return this['findOnPath_'](_0x994d77,w(),_0x3e4fd2);}['findOnPath_'](_0x3cab1b,_0x40e8af,_0x58effe){const _0x307824=this['value']?_0x58effe(_0x40e8af,this['value']):!0x1;if(_0x307824)return _0x307824;if(v(_0x3cab1b))return null;{const _0x4ae4bb=y(_0x3cab1b),_0xeb4f20=this['children']['get'](_0x4ae4bb);return _0xeb4f20?_0xeb4f20['findOnPath_'](b(_0x3cab1b),A(_0x40e8af,_0x4ae4bb),_0x58effe):null;}}['foreachOnPath'](_0x2c9dc0,_0x4875ea){return this['foreachOnPath_'](_0x2c9dc0,w(),_0x4875ea);}['foreachOnPath_'](_0x4935f4,_0x30ed91,_0x97b782){if(v(_0x4935f4))return this;{this['value']&&_0x97b782(_0x30ed91,this['value']);const _0x2720b1=y(_0x4935f4),_0x460b65=this['children']['get'](_0x2720b1);return _0x460b65?_0x460b65['foreachOnPath_'](b(_0x4935f4),A(_0x30ed91,_0x2720b1),_0x97b782):new S(null);}}['foreach'](_0x21572b){this['foreach_'](w(),_0x21572b);}['foreach_'](_0x1734c8,_0x16217d){this['children']['inorderTraversal']((_0x4f0ba0,_0x285106)=>{_0x285106['foreach_'](A(_0x1734c8,_0x4f0ba0),_0x16217d);}),this['value']&&_0x16217d(_0x1734c8,this['value']);}['foreachChild'](_0xf767eb){this['children']['inorderTraversal']((_0x25fc17,_0x1179fa)=>{_0x1179fa['value']&&_0xf767eb(_0x25fc17,_0x1179fa['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x49821e){this['writeTree_']=_0x49821e;}static['empty'](){return new j(new S(null));}}function Ct(_0x3ed66d,_0x5edae0,_0x30e2c0){if(v(_0x5edae0))return new j(new S(_0x30e2c0));{const _0x16767a=_0x3ed66d['writeTree_']['findRootMostValueAndPath'](_0x5edae0);if(_0x16767a!=null){const _0x1007a9=_0x16767a['path'];let _0x33bda6=_0x16767a['value'];const _0x16472a=F(_0x1007a9,_0x5edae0);return _0x33bda6=_0x33bda6['updateChild'](_0x16472a,_0x30e2c0),new j(_0x3ed66d['writeTree_']['set'](_0x1007a9,_0x33bda6));}else{const _0x3b972f=new S(_0x30e2c0),_0x1cef59=_0x3ed66d['writeTree_']['setTree'](_0x5edae0,_0x3b972f);return new j(_0x1cef59);}}}function Ii(_0x2dbf91,_0xac0147,_0x96636f){let _0x314df7=_0x2dbf91;return x(_0x96636f,(_0x2567d8,_0x24ca76)=>{_0x314df7=Ct(_0x314df7,A(_0xac0147,_0x2567d8),_0x24ca76);}),_0x314df7;}function sr(_0x261c7f,_0x5df46e){if(v(_0x5df46e))return j['empty']();{const _0x21de2f=_0x261c7f['writeTree_']['setTree'](_0x5df46e,new S(null));return new j(_0x21de2f);}}function wi(_0x2f336b,_0x45e3b8){return $e(_0x2f336b,_0x45e3b8)!=null;}function $e(_0x44157b,_0x4c1445){const _0x5d2528=_0x44157b['writeTree_']['findRootMostValueAndPath'](_0x4c1445);return _0x5d2528!=null?_0x44157b['writeTree_']['get'](_0x5d2528['path'])['getChild'](F(_0x5d2528['path'],_0x4c1445)):null;}function rr(_0x4ec011){const _0xe9318e=[],_0x464016=_0x4ec011['writeTree_']['value'];return _0x464016!=null?_0x464016['isLeafNode']()||_0x464016['forEachChild'](R,(_0x4da4d8,_0x311624)=>{_0xe9318e['push'](new E(_0x4da4d8,_0x311624));}):_0x4ec011['writeTree_']['children']['inorderTraversal']((_0x280648,_0x29e763)=>{_0x29e763['value']!=null&&_0xe9318e['push'](new E(_0x280648,_0x29e763['value']));}),_0xe9318e;}function ve(_0x3ed0ff,_0x335822){if(v(_0x335822))return _0x3ed0ff;{const _0x295986=$e(_0x3ed0ff,_0x335822);return _0x295986!=null?new j(new S(_0x295986)):new j(_0x3ed0ff['writeTree_']['subtree'](_0x335822));}}function Ci(_0x4429a4){return _0x4429a4['writeTree_']['isEmpty']();}function it(_0xe18d00,_0x456ae6){return xo(w(),_0xe18d00['writeTree_'],_0x456ae6);}function xo(_0x4afe8e,_0x4545a6,_0x30f320){if(_0x4545a6['value']!=null)return _0x30f320['updateChild'](_0x4afe8e,_0x4545a6['value']);{let _0xb2c999=null;return _0x4545a6['children']['inorderTraversal']((_0x49b1cc,_0x54e809)=>{_0x49b1cc==='.priority'?(f(_0x54e809['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xb2c999=_0x54e809['value']):_0x30f320=xo(A(_0x4afe8e,_0x49b1cc),_0x54e809,_0x30f320);}),!_0x30f320['getChild'](_0x4afe8e)['isEmpty']()&&_0xb2c999!==null&&(_0x30f320=_0x30f320['updateChild'](A(_0x4afe8e,'.priority'),_0xb2c999)),_0x30f320;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x40731f,_0x2cd1a7){return Bo(_0x2cd1a7,_0x40731f);}function ou(_0x3ba434,_0x4447d1,_0x39274d,_0x41fb51,_0x375579){f(_0x41fb51>_0x3ba434['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x375579===void 0x0&&(_0x375579=!0x0),_0x3ba434['allWrites']['push']({'path':_0x4447d1,'snap':_0x39274d,'writeId':_0x41fb51,'visible':_0x375579}),_0x375579&&(_0x3ba434['visibleWrites']=Ct(_0x3ba434['visibleWrites'],_0x4447d1,_0x39274d)),_0x3ba434['lastWriteId']=_0x41fb51;}function au(_0x537f7f,_0x5e7164,_0x242d77,_0x4baa6a){f(_0x4baa6a>_0x537f7f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x537f7f['allWrites']['push']({'path':_0x5e7164,'children':_0x242d77,'writeId':_0x4baa6a,'visible':!0x0}),_0x537f7f['visibleWrites']=Ii(_0x537f7f['visibleWrites'],_0x5e7164,_0x242d77),_0x537f7f['lastWriteId']=_0x4baa6a;}function cu(_0x440106,_0x167200){for(let _0x3e6308=0x0;_0x3e6308<_0x440106['allWrites']['length'];_0x3e6308++){const _0x1c133b=_0x440106['allWrites'][_0x3e6308];if(_0x1c133b['writeId']===_0x167200)return _0x1c133b;}return null;}function lu(_0x3192fc,_0x22cfd5){const _0x378077=_0x3192fc['allWrites']['findIndex'](_0x2dd247=>_0x2dd247['writeId']===_0x22cfd5);f(_0x378077>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xf29ea0=_0x3192fc['allWrites'][_0x378077];_0x3192fc['allWrites']['splice'](_0x378077,0x1);let _0x43c263=_0xf29ea0['visible'],_0x55c824=!0x1,_0x208ba3=_0x3192fc['allWrites']['length']-0x1;for(;_0x43c263&&_0x208ba3>=0x0;){const _0x11c897=_0x3192fc['allWrites'][_0x208ba3];_0x11c897['visible']&&(_0x208ba3>=_0x378077&&hu(_0x11c897,_0xf29ea0['path'])?_0x43c263=!0x1:$(_0xf29ea0['path'],_0x11c897['path'])&&(_0x55c824=!0x0)),_0x208ba3--;}if(_0x43c263){if(_0x55c824)return uu(_0x3192fc),!0x0;if(_0xf29ea0['snap'])_0x3192fc['visibleWrites']=sr(_0x3192fc['visibleWrites'],_0xf29ea0['path']);else{const _0x4fd275=_0xf29ea0['children'];x(_0x4fd275,_0x31a7e5=>{_0x3192fc['visibleWrites']=sr(_0x3192fc['visibleWrites'],A(_0xf29ea0['path'],_0x31a7e5));});}return!0x0;}else return!0x1;}function hu(_0x5238b4,_0x21ffbb){if(_0x5238b4['snap'])return $(_0x5238b4['path'],_0x21ffbb);for(const _0x544bde in _0x5238b4['children'])if(_0x5238b4['children']['hasOwnProperty'](_0x544bde)&&$(A(_0x5238b4['path'],_0x544bde),_0x21ffbb))return!0x0;return!0x1;}function uu(_0x1725ba){_0x1725ba['visibleWrites']=Fo(_0x1725ba['allWrites'],du,w()),_0x1725ba['allWrites']['length']>0x0?_0x1725ba['lastWriteId']=_0x1725ba['allWrites'][_0x1725ba['allWrites']['length']-0x1]['writeId']:_0x1725ba['lastWriteId']=-0x1;}function du(_0x5a4b8c){return _0x5a4b8c['visible'];}function Fo(_0x1974cd,_0x41abed,_0x350c20){let _0x702b8=j['empty']();for(let _0x50dafb=0x0;_0x50dafb<_0x1974cd['length'];++_0x50dafb){const _0xab6a59=_0x1974cd[_0x50dafb];if(_0x41abed(_0xab6a59)){const _0x19b38a=_0xab6a59['path'];let _0x55ef96;if(_0xab6a59['snap'])$(_0x350c20,_0x19b38a)?(_0x55ef96=F(_0x350c20,_0x19b38a),_0x702b8=Ct(_0x702b8,_0x55ef96,_0xab6a59['snap'])):$(_0x19b38a,_0x350c20)&&(_0x55ef96=F(_0x19b38a,_0x350c20),_0x702b8=Ct(_0x702b8,w(),_0xab6a59['snap']['getChild'](_0x55ef96)));else{if(_0xab6a59['children']){if($(_0x350c20,_0x19b38a))_0x55ef96=F(_0x350c20,_0x19b38a),_0x702b8=Ii(_0x702b8,_0x55ef96,_0xab6a59['children']);else{if($(_0x19b38a,_0x350c20)){if(_0x55ef96=F(_0x19b38a,_0x350c20),v(_0x55ef96))_0x702b8=Ii(_0x702b8,w(),_0xab6a59['children']);else{const _0x146017=Oe(_0xab6a59['children'],y(_0x55ef96));if(_0x146017){const _0x205ca6=_0x146017['getChild'](b(_0x55ef96));_0x702b8=Ct(_0x702b8,w(),_0x205ca6);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x702b8;}function Uo(_0x5836b3,_0x7db2c9,_0x17b9f0,_0x5268e8,_0x230c10){if(!_0x5268e8&&!_0x230c10){const _0x1bbb77=$e(_0x5836b3['visibleWrites'],_0x7db2c9);if(_0x1bbb77!=null)return _0x1bbb77;{const _0x2b0fc3=ve(_0x5836b3['visibleWrites'],_0x7db2c9);if(Ci(_0x2b0fc3))return _0x17b9f0;if(_0x17b9f0==null&&!wi(_0x2b0fc3,w()))return null;{const _0x1f91cb=_0x17b9f0||g['EMPTY_NODE'];return it(_0x2b0fc3,_0x1f91cb);}}}else{const _0x5f0d13=ve(_0x5836b3['visibleWrites'],_0x7db2c9);if(!_0x230c10&&Ci(_0x5f0d13))return _0x17b9f0;if(!_0x230c10&&_0x17b9f0==null&&!wi(_0x5f0d13,w()))return null;{const _0x35d172=function(_0x5d48a8){return(_0x5d48a8['visible']||_0x230c10)&&(!_0x5268e8||!~_0x5268e8['indexOf'](_0x5d48a8['writeId']))&&($(_0x5d48a8['path'],_0x7db2c9)||$(_0x7db2c9,_0x5d48a8['path']));},_0x75533d=Fo(_0x5836b3['allWrites'],_0x35d172,_0x7db2c9),_0x1ddf2d=_0x17b9f0||g['EMPTY_NODE'];return it(_0x75533d,_0x1ddf2d);}}}function fu(_0x1db050,_0x3b7977,_0x1ac2cd){let _0x1e836e=g['EMPTY_NODE'];const _0x109604=$e(_0x1db050['visibleWrites'],_0x3b7977);if(_0x109604)return _0x109604['isLeafNode']()||_0x109604['forEachChild'](R,(_0x22a1c2,_0x28b25c)=>{_0x1e836e=_0x1e836e['updateImmediateChild'](_0x22a1c2,_0x28b25c);}),_0x1e836e;if(_0x1ac2cd){const _0xb252bd=ve(_0x1db050['visibleWrites'],_0x3b7977);return _0x1ac2cd['forEachChild'](R,(_0x5be5c1,_0xbe43de)=>{const _0x26d6a3=it(ve(_0xb252bd,new C(_0x5be5c1)),_0xbe43de);_0x1e836e=_0x1e836e['updateImmediateChild'](_0x5be5c1,_0x26d6a3);}),rr(_0xb252bd)['forEach'](_0x536d92=>{_0x1e836e=_0x1e836e['updateImmediateChild'](_0x536d92['name'],_0x536d92['node']);}),_0x1e836e;}else{const _0x88e8ba=ve(_0x1db050['visibleWrites'],_0x3b7977);return rr(_0x88e8ba)['forEach'](_0x35a5e6=>{_0x1e836e=_0x1e836e['updateImmediateChild'](_0x35a5e6['name'],_0x35a5e6['node']);}),_0x1e836e;}}function pu(_0x4233ab,_0x508f29,_0x4d5cb1,_0x1f0fec,_0x47c8c1){f(_0x1f0fec||_0x47c8c1,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2b3642=A(_0x508f29,_0x4d5cb1);if(wi(_0x4233ab['visibleWrites'],_0x2b3642))return null;{const _0x54ad74=ve(_0x4233ab['visibleWrites'],_0x2b3642);return Ci(_0x54ad74)?_0x47c8c1['getChild'](_0x4d5cb1):it(_0x54ad74,_0x47c8c1['getChild'](_0x4d5cb1));}}function _u(_0x1b181d,_0x399271,_0x5c6055,_0x27081b){const _0x1acb15=A(_0x399271,_0x5c6055),_0x1af8a2=$e(_0x1b181d['visibleWrites'],_0x1acb15);if(_0x1af8a2!=null)return _0x1af8a2;if(_0x27081b['isCompleteForChild'](_0x5c6055)){const _0x101b7e=ve(_0x1b181d['visibleWrites'],_0x1acb15);return it(_0x101b7e,_0x27081b['getNode']()['getImmediateChild'](_0x5c6055));}else return null;}function gu(_0x31cdff,_0x4224e5){return $e(_0x31cdff['visibleWrites'],_0x4224e5);}function mu(_0x405992,_0x49a5c2,_0x79e204,_0x288892,_0x25eeec,_0x45f949,_0x5b9ef6){let _0x1bf366;const _0x702b64=ve(_0x405992['visibleWrites'],_0x49a5c2),_0x31950f=$e(_0x702b64,w());if(_0x31950f!=null)_0x1bf366=_0x31950f;else{if(_0x79e204!=null)_0x1bf366=it(_0x702b64,_0x79e204);else return[];}if(_0x1bf366=_0x1bf366['withIndex'](_0x5b9ef6),!_0x1bf366['isEmpty']()&&!_0x1bf366['isLeafNode']()){const _0x327ea7=[],_0x3e4983=_0x5b9ef6['getCompare'](),_0x45be8c=_0x45f949?_0x1bf366['getReverseIteratorFrom'](_0x288892,_0x5b9ef6):_0x1bf366['getIteratorFrom'](_0x288892,_0x5b9ef6);let _0x1a714d=_0x45be8c['getNext']();for(;_0x1a714d&&_0x327ea7['length']<_0x25eeec;)_0x3e4983(_0x1a714d,_0x288892)!==0x0&&_0x327ea7['push'](_0x1a714d),_0x1a714d=_0x45be8c['getNext']();return _0x327ea7;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x19ea65,_0x1314de,_0x273fac,_0x5294de){return Uo(_0x19ea65['writeTree'],_0x19ea65['treePath'],_0x1314de,_0x273fac,_0x5294de);}function es(_0xe5e36f,_0x380348){return fu(_0xe5e36f['writeTree'],_0xe5e36f['treePath'],_0x380348);}function or(_0x6c2538,_0xea1cd9,_0xcb4698,_0x2b2ec2){return pu(_0x6c2538['writeTree'],_0x6c2538['treePath'],_0xea1cd9,_0xcb4698,_0x2b2ec2);}function yn(_0x47b53b,_0x418c86){return gu(_0x47b53b['writeTree'],A(_0x47b53b['treePath'],_0x418c86));}function vu(_0x420ebb,_0x42e0af,_0xf0f04e,_0xee68be,_0x7d231e,_0x7e9ab1){return mu(_0x420ebb['writeTree'],_0x420ebb['treePath'],_0x42e0af,_0xf0f04e,_0xee68be,_0x7d231e,_0x7e9ab1);}function ts(_0x5668c1,_0x5d5fa5,_0x306a89){return _u(_0x5668c1['writeTree'],_0x5668c1['treePath'],_0x5d5fa5,_0x306a89);}function Wo(_0x3145a1,_0x26c1a8){return Bo(A(_0x3145a1['treePath'],_0x26c1a8),_0x3145a1['writeTree']);}function Bo(_0x4f2e0c,_0x25daf9){return{'treePath':_0x4f2e0c,'writeTree':_0x25daf9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3a1e13){const _0x462efe=_0x3a1e13['type'],_0x390ed6=_0x3a1e13['childName'];f(_0x462efe==='child_added'||_0x462efe==='child_changed'||_0x462efe==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x390ed6!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0xc39131=this['changeMap']['get'](_0x390ed6);if(_0xc39131){const _0x29b94e=_0xc39131['type'];if(_0x462efe==='child_added'&&_0x29b94e==='child_removed')this['changeMap']['set'](_0x390ed6,Pt(_0x390ed6,_0x3a1e13['snapshotNode'],_0xc39131['snapshotNode']));else{if(_0x462efe==='child_removed'&&_0x29b94e==='child_added')this['changeMap']['delete'](_0x390ed6);else{if(_0x462efe==='child_removed'&&_0x29b94e==='child_changed')this['changeMap']['set'](_0x390ed6,Nt(_0x390ed6,_0xc39131['oldSnap']));else{if(_0x462efe==='child_changed'&&_0x29b94e==='child_added')this['changeMap']['set'](_0x390ed6,tt(_0x390ed6,_0x3a1e13['snapshotNode']));else{if(_0x462efe==='child_changed'&&_0x29b94e==='child_changed')this['changeMap']['set'](_0x390ed6,Pt(_0x390ed6,_0x3a1e13['snapshotNode'],_0xc39131['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x3a1e13+'\x20occurred\x20after\x20'+_0xc39131);}}}}}else this['changeMap']['set'](_0x390ed6,_0x3a1e13);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x1cce67){return null;}['getChildAfterChild'](_0x55e72d,_0x47d580,_0x22263b){return null;}}const Vo=new Iu();class ns{constructor(_0x1c94c1,_0x20a20f,_0x1b3fe6=null){this['writes_']=_0x1c94c1,this['viewCache_']=_0x20a20f,this['optCompleteServerCache_']=_0x1b3fe6;}['getCompleteChild'](_0x26cd7b){const _0x91b69c=this['viewCache_']['eventCache'];if(_0x91b69c['isCompleteForChild'](_0x26cd7b))return _0x91b69c['getNode']()['getImmediateChild'](_0x26cd7b);{const _0x412e11=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x26cd7b,_0x412e11);}}['getChildAfterChild'](_0x48fd32,_0x973582,_0x2ce235){const _0x3dd5b4=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x58b5bc=vu(this['writes_'],_0x3dd5b4,_0x973582,0x1,_0x2ce235,_0x48fd32);return _0x58b5bc['length']===0x0?null:_0x58b5bc[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x1bde2b){return{'filter':_0x1bde2b};}function Cu(_0xf54763,_0xdb3924){f(_0xdb3924['eventCache']['getNode']()['isIndexed'](_0xf54763['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xdb3924['serverCache']['getNode']()['isIndexed'](_0xf54763['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0xf52384,_0x4216ab,_0x27b22b,_0x3096cc,_0x3faeb4){const _0x4a4610=new Eu();let _0x3d2cae,_0x1dd9a1;if(_0x27b22b['type']===q['OVERWRITE']){const _0x4937ba=_0x27b22b;_0x4937ba['source']['fromUser']?_0x3d2cae=Ti(_0xf52384,_0x4216ab,_0x4937ba['path'],_0x4937ba['snap'],_0x3096cc,_0x3faeb4,_0x4a4610):(f(_0x4937ba['source']['fromServer'],'Unknown\x20source.'),_0x1dd9a1=_0x4937ba['source']['tagged']||_0x4216ab['serverCache']['isFiltered']()&&!v(_0x4937ba['path']),_0x3d2cae=vn(_0xf52384,_0x4216ab,_0x4937ba['path'],_0x4937ba['snap'],_0x3096cc,_0x3faeb4,_0x1dd9a1,_0x4a4610));}else{if(_0x27b22b['type']===q['MERGE']){const _0x456b91=_0x27b22b;_0x456b91['source']['fromUser']?_0x3d2cae=bu(_0xf52384,_0x4216ab,_0x456b91['path'],_0x456b91['children'],_0x3096cc,_0x3faeb4,_0x4a4610):(f(_0x456b91['source']['fromServer'],'Unknown\x20source.'),_0x1dd9a1=_0x456b91['source']['tagged']||_0x4216ab['serverCache']['isFiltered'](),_0x3d2cae=Si(_0xf52384,_0x4216ab,_0x456b91['path'],_0x456b91['children'],_0x3096cc,_0x3faeb4,_0x1dd9a1,_0x4a4610));}else{if(_0x27b22b['type']===q['ACK_USER_WRITE']){const _0x391f02=_0x27b22b;_0x391f02['revert']?_0x3d2cae=ku(_0xf52384,_0x4216ab,_0x391f02['path'],_0x3096cc,_0x3faeb4,_0x4a4610):_0x3d2cae=Ru(_0xf52384,_0x4216ab,_0x391f02['path'],_0x391f02['affectedTree'],_0x3096cc,_0x3faeb4,_0x4a4610);}else{if(_0x27b22b['type']===q['LISTEN_COMPLETE'])_0x3d2cae=Au(_0xf52384,_0x4216ab,_0x27b22b['path'],_0x3096cc,_0x4a4610);else throw ot('Unknown\x20operation\x20type:\x20'+_0x27b22b['type']);}}}const _0x4ca373=_0x4a4610['getChanges']();return Su(_0x4216ab,_0x3d2cae,_0x4ca373),{'viewCache':_0x3d2cae,'changes':_0x4ca373};}function Su(_0x30a2d6,_0x41010a,_0x43df0e){const _0x4979a2=_0x41010a['eventCache'];if(_0x4979a2['isFullyInitialized']()){const _0x823dc=_0x4979a2['getNode']()['isLeafNode']()||_0x4979a2['getNode']()['isEmpty'](),_0x37da47=gn(_0x30a2d6);(_0x43df0e['length']>0x0||!_0x30a2d6['eventCache']['isFullyInitialized']()||_0x823dc&&!_0x4979a2['getNode']()['equals'](_0x37da47)||!_0x4979a2['getNode']()['getPriority']()['equals'](_0x37da47['getPriority']()))&&_0x43df0e['push'](Oo(gn(_0x41010a)));}}function Ho(_0x26b922,_0x2c4d7a,_0x41fd56,_0x282fb6,_0x20a58c,_0x377551){const _0x13e360=_0x2c4d7a['eventCache'];if(yn(_0x282fb6,_0x41fd56)!=null)return _0x2c4d7a;{let _0x1a5a6d,_0x5c54ac;if(v(_0x41fd56)){if(f(_0x2c4d7a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2c4d7a['serverCache']['isFiltered']()){const _0x496fe8=Ue(_0x2c4d7a),_0x10c104=_0x496fe8 instanceof g?_0x496fe8:g['EMPTY_NODE'],_0x18b91f=es(_0x282fb6,_0x10c104);_0x1a5a6d=_0x26b922['filter']['updateFullNode'](_0x2c4d7a['eventCache']['getNode'](),_0x18b91f,_0x377551);}else{const _0x2cdec0=mn(_0x282fb6,Ue(_0x2c4d7a));_0x1a5a6d=_0x26b922['filter']['updateFullNode'](_0x2c4d7a['eventCache']['getNode'](),_0x2cdec0,_0x377551);}}else{const _0x5a4962=y(_0x41fd56);if(_0x5a4962==='.priority'){f(we(_0x41fd56)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3a2962=_0x13e360['getNode']();_0x5c54ac=_0x2c4d7a['serverCache']['getNode']();const _0x28971d=or(_0x282fb6,_0x41fd56,_0x3a2962,_0x5c54ac);_0x28971d!=null?_0x1a5a6d=_0x26b922['filter']['updatePriority'](_0x3a2962,_0x28971d):_0x1a5a6d=_0x13e360['getNode']();}else{const _0x2172e5=b(_0x41fd56);let _0x4e60f0;if(_0x13e360['isCompleteForChild'](_0x5a4962)){_0x5c54ac=_0x2c4d7a['serverCache']['getNode']();const _0x3b4c82=or(_0x282fb6,_0x41fd56,_0x13e360['getNode'](),_0x5c54ac);_0x3b4c82!=null?_0x4e60f0=_0x13e360['getNode']()['getImmediateChild'](_0x5a4962)['updateChild'](_0x2172e5,_0x3b4c82):_0x4e60f0=_0x13e360['getNode']()['getImmediateChild'](_0x5a4962);}else _0x4e60f0=ts(_0x282fb6,_0x5a4962,_0x2c4d7a['serverCache']);_0x4e60f0!=null?_0x1a5a6d=_0x26b922['filter']['updateChild'](_0x13e360['getNode'](),_0x5a4962,_0x4e60f0,_0x2172e5,_0x20a58c,_0x377551):_0x1a5a6d=_0x13e360['getNode']();}}return wt(_0x2c4d7a,_0x1a5a6d,_0x13e360['isFullyInitialized']()||v(_0x41fd56),_0x26b922['filter']['filtersNodes']());}}function vn(_0x2028d8,_0x24eb51,_0x12ae7b,_0x41d579,_0x3cb6d0,_0x2477b8,_0x2b877a,_0x15eb80){const _0x388d12=_0x24eb51['serverCache'];let _0xe0fca6;const _0x16a174=_0x2b877a?_0x2028d8['filter']:_0x2028d8['filter']['getIndexedFilter']();if(v(_0x12ae7b))_0xe0fca6=_0x16a174['updateFullNode'](_0x388d12['getNode'](),_0x41d579,null);else{if(_0x16a174['filtersNodes']()&&!_0x388d12['isFiltered']()){const _0x170af4=_0x388d12['getNode']()['updateChild'](_0x12ae7b,_0x41d579);_0xe0fca6=_0x16a174['updateFullNode'](_0x388d12['getNode'](),_0x170af4,null);}else{const _0x12d54b=y(_0x12ae7b);if(!_0x388d12['isCompleteForPath'](_0x12ae7b)&&we(_0x12ae7b)>0x1)return _0x24eb51;const _0x212fe0=b(_0x12ae7b),_0x2325a5=_0x388d12['getNode']()['getImmediateChild'](_0x12d54b)['updateChild'](_0x212fe0,_0x41d579);_0x12d54b==='.priority'?_0xe0fca6=_0x16a174['updatePriority'](_0x388d12['getNode'](),_0x2325a5):_0xe0fca6=_0x16a174['updateChild'](_0x388d12['getNode'](),_0x12d54b,_0x2325a5,_0x212fe0,Vo,null);}}const _0x1cc96c=Lo(_0x24eb51,_0xe0fca6,_0x388d12['isFullyInitialized']()||v(_0x12ae7b),_0x16a174['filtersNodes']()),_0x59adbf=new ns(_0x3cb6d0,_0x1cc96c,_0x2477b8);return Ho(_0x2028d8,_0x1cc96c,_0x12ae7b,_0x3cb6d0,_0x59adbf,_0x15eb80);}function Ti(_0x844d2c,_0x405c88,_0x44cc20,_0x18b9f9,_0x1cc3f4,_0x3af80c,_0x2ab8a6){const _0x566391=_0x405c88['eventCache'];let _0x4150c0,_0x3e3f3c;const _0x3aa99c=new ns(_0x1cc3f4,_0x405c88,_0x3af80c);if(v(_0x44cc20))_0x3e3f3c=_0x844d2c['filter']['updateFullNode'](_0x405c88['eventCache']['getNode'](),_0x18b9f9,_0x2ab8a6),_0x4150c0=wt(_0x405c88,_0x3e3f3c,!0x0,_0x844d2c['filter']['filtersNodes']());else{const _0x5c0e45=y(_0x44cc20);if(_0x5c0e45==='.priority')_0x3e3f3c=_0x844d2c['filter']['updatePriority'](_0x405c88['eventCache']['getNode'](),_0x18b9f9),_0x4150c0=wt(_0x405c88,_0x3e3f3c,_0x566391['isFullyInitialized'](),_0x566391['isFiltered']());else{const _0x853462=b(_0x44cc20),_0x42bf5e=_0x566391['getNode']()['getImmediateChild'](_0x5c0e45);let _0x454773;if(v(_0x853462))_0x454773=_0x18b9f9;else{const _0x2737fa=_0x3aa99c['getCompleteChild'](_0x5c0e45);_0x2737fa!=null?Gi(_0x853462)==='.priority'&&_0x2737fa['getChild'](To(_0x853462))['isEmpty']()?_0x454773=_0x2737fa:_0x454773=_0x2737fa['updateChild'](_0x853462,_0x18b9f9):_0x454773=g['EMPTY_NODE'];}if(_0x42bf5e['equals'](_0x454773))_0x4150c0=_0x405c88;else{const _0x12e836=_0x844d2c['filter']['updateChild'](_0x566391['getNode'](),_0x5c0e45,_0x454773,_0x853462,_0x3aa99c,_0x2ab8a6);_0x4150c0=wt(_0x405c88,_0x12e836,_0x566391['isFullyInitialized'](),_0x844d2c['filter']['filtersNodes']());}}}return _0x4150c0;}function ar(_0x4d4059,_0x564535){return _0x4d4059['eventCache']['isCompleteForChild'](_0x564535);}function bu(_0x317c93,_0x2b91a8,_0xd14b25,_0x2d408f,_0x42eed3,_0x5413dc,_0x35c8a3){let _0x498410=_0x2b91a8;return _0x2d408f['foreach']((_0x536493,_0x38919d)=>{const _0x1efa40=A(_0xd14b25,_0x536493);ar(_0x2b91a8,y(_0x1efa40))&&(_0x498410=Ti(_0x317c93,_0x498410,_0x1efa40,_0x38919d,_0x42eed3,_0x5413dc,_0x35c8a3));}),_0x2d408f['foreach']((_0x884a45,_0x37b34f)=>{const _0x551223=A(_0xd14b25,_0x884a45);ar(_0x2b91a8,y(_0x551223))||(_0x498410=Ti(_0x317c93,_0x498410,_0x551223,_0x37b34f,_0x42eed3,_0x5413dc,_0x35c8a3));}),_0x498410;}function cr(_0x5aa45d,_0x2deddc,_0x3a9191){return _0x3a9191['foreach']((_0x5852ff,_0x303275)=>{_0x2deddc=_0x2deddc['updateChild'](_0x5852ff,_0x303275);}),_0x2deddc;}function Si(_0x10409f,_0x549360,_0x54181b,_0x2b0b72,_0x3cd29e,_0x1cdee8,_0x3aded3,_0x9c5e0f){if(_0x549360['serverCache']['getNode']()['isEmpty']()&&!_0x549360['serverCache']['isFullyInitialized']())return _0x549360;let _0xc5643d=_0x549360,_0x839ae5;v(_0x54181b)?_0x839ae5=_0x2b0b72:_0x839ae5=new S(null)['setTree'](_0x54181b,_0x2b0b72);const _0x5c7c3a=_0x549360['serverCache']['getNode']();return _0x839ae5['children']['inorderTraversal']((_0x5dafd6,_0x3fdde3)=>{if(_0x5c7c3a['hasChild'](_0x5dafd6)){const _0x1e0ded=_0x549360['serverCache']['getNode']()['getImmediateChild'](_0x5dafd6),_0x3daad3=cr(_0x10409f,_0x1e0ded,_0x3fdde3);_0xc5643d=vn(_0x10409f,_0xc5643d,new C(_0x5dafd6),_0x3daad3,_0x3cd29e,_0x1cdee8,_0x3aded3,_0x9c5e0f);}}),_0x839ae5['children']['inorderTraversal']((_0x3a5282,_0x26ab79)=>{const _0x467a9d=!_0x549360['serverCache']['isCompleteForChild'](_0x3a5282)&&_0x26ab79['value']===null;if(!_0x5c7c3a['hasChild'](_0x3a5282)&&!_0x467a9d){const _0x41acfa=_0x549360['serverCache']['getNode']()['getImmediateChild'](_0x3a5282),_0x568aeb=cr(_0x10409f,_0x41acfa,_0x26ab79);_0xc5643d=vn(_0x10409f,_0xc5643d,new C(_0x3a5282),_0x568aeb,_0x3cd29e,_0x1cdee8,_0x3aded3,_0x9c5e0f);}}),_0xc5643d;}function Ru(_0x127a81,_0x521623,_0x3262d1,_0x390666,_0x39d3ad,_0xedc9a8,_0x526e05){if(yn(_0x39d3ad,_0x3262d1)!=null)return _0x521623;const _0xf649d4=_0x521623['serverCache']['isFiltered'](),_0x1a407b=_0x521623['serverCache'];if(_0x390666['value']!=null){if(v(_0x3262d1)&&_0x1a407b['isFullyInitialized']()||_0x1a407b['isCompleteForPath'](_0x3262d1))return vn(_0x127a81,_0x521623,_0x3262d1,_0x1a407b['getNode']()['getChild'](_0x3262d1),_0x39d3ad,_0xedc9a8,_0xf649d4,_0x526e05);if(v(_0x3262d1)){let _0x1bab4f=new S(null);return _0x1a407b['getNode']()['forEachChild'](ye,(_0x1d8618,_0x2e62dd)=>{_0x1bab4f=_0x1bab4f['set'](new C(_0x1d8618),_0x2e62dd);}),Si(_0x127a81,_0x521623,_0x3262d1,_0x1bab4f,_0x39d3ad,_0xedc9a8,_0xf649d4,_0x526e05);}else return _0x521623;}else{let _0x5867a9=new S(null);return _0x390666['foreach']((_0x1b380f,_0x4ee7ac)=>{const _0x5ed21f=A(_0x3262d1,_0x1b380f);_0x1a407b['isCompleteForPath'](_0x5ed21f)&&(_0x5867a9=_0x5867a9['set'](_0x1b380f,_0x1a407b['getNode']()['getChild'](_0x5ed21f)));}),Si(_0x127a81,_0x521623,_0x3262d1,_0x5867a9,_0x39d3ad,_0xedc9a8,_0xf649d4,_0x526e05);}}function Au(_0x496960,_0x347dfb,_0x5c8b93,_0xc16196,_0x4d4c46){const _0x3aeb4c=_0x347dfb['serverCache'],_0xb92b27=Lo(_0x347dfb,_0x3aeb4c['getNode'](),_0x3aeb4c['isFullyInitialized']()||v(_0x5c8b93),_0x3aeb4c['isFiltered']());return Ho(_0x496960,_0xb92b27,_0x5c8b93,_0xc16196,Vo,_0x4d4c46);}function ku(_0x1e54cf,_0x4f4fe0,_0x1dc79c,_0x1f24cf,_0x1bf00f,_0x9e5c8){let _0x4b81a0;if(yn(_0x1f24cf,_0x1dc79c)!=null)return _0x4f4fe0;{const _0x8c5e87=new ns(_0x1f24cf,_0x4f4fe0,_0x1bf00f),_0x1b704d=_0x4f4fe0['eventCache']['getNode']();let _0x4e38e1;if(v(_0x1dc79c)||y(_0x1dc79c)==='.priority'){let _0x1e8625;if(_0x4f4fe0['serverCache']['isFullyInitialized']())_0x1e8625=mn(_0x1f24cf,Ue(_0x4f4fe0));else{const _0x133cec=_0x4f4fe0['serverCache']['getNode']();f(_0x133cec instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1e8625=es(_0x1f24cf,_0x133cec);}_0x1e8625=_0x1e8625,_0x4e38e1=_0x1e54cf['filter']['updateFullNode'](_0x1b704d,_0x1e8625,_0x9e5c8);}else{const _0x2b905f=y(_0x1dc79c);let _0x53297b=ts(_0x1f24cf,_0x2b905f,_0x4f4fe0['serverCache']);_0x53297b==null&&_0x4f4fe0['serverCache']['isCompleteForChild'](_0x2b905f)&&(_0x53297b=_0x1b704d['getImmediateChild'](_0x2b905f)),_0x53297b!=null?_0x4e38e1=_0x1e54cf['filter']['updateChild'](_0x1b704d,_0x2b905f,_0x53297b,b(_0x1dc79c),_0x8c5e87,_0x9e5c8):_0x4f4fe0['eventCache']['getNode']()['hasChild'](_0x2b905f)?_0x4e38e1=_0x1e54cf['filter']['updateChild'](_0x1b704d,_0x2b905f,g['EMPTY_NODE'],b(_0x1dc79c),_0x8c5e87,_0x9e5c8):_0x4e38e1=_0x1b704d,_0x4e38e1['isEmpty']()&&_0x4f4fe0['serverCache']['isFullyInitialized']()&&(_0x4b81a0=mn(_0x1f24cf,Ue(_0x4f4fe0)),_0x4b81a0['isLeafNode']()&&(_0x4e38e1=_0x1e54cf['filter']['updateFullNode'](_0x4e38e1,_0x4b81a0,_0x9e5c8)));}return _0x4b81a0=_0x4f4fe0['serverCache']['isFullyInitialized']()||yn(_0x1f24cf,w())!=null,wt(_0x4f4fe0,_0x4e38e1,_0x4b81a0,_0x1e54cf['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x3b71ed,_0x17a2a0){this['query_']=_0x3b71ed,this['eventRegistrations_']=[];const _0x53ca0b=this['query_']['_queryParams'],_0x410d90=new Yi(_0x53ca0b['getIndex']()),_0x5ddf46=qh(_0x53ca0b);this['processor_']=wu(_0x5ddf46);const _0x4d507d=_0x17a2a0['serverCache'],_0x20b8ce=_0x17a2a0['eventCache'],_0x395ac9=_0x410d90['updateFullNode'](g['EMPTY_NODE'],_0x4d507d['getNode'](),null),_0x171f20=_0x5ddf46['updateFullNode'](g['EMPTY_NODE'],_0x20b8ce['getNode'](),null),_0x5e4d46=new Ce(_0x395ac9,_0x4d507d['isFullyInitialized'](),_0x410d90['filtersNodes']()),_0x574417=new Ce(_0x171f20,_0x20b8ce['isFullyInitialized'](),_0x5ddf46['filtersNodes']());this['viewCache_']=Dn(_0x574417,_0x5e4d46),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x49e9de){return _0x49e9de['viewCache_']['serverCache']['getNode']();}function Ou(_0x566d81){return gn(_0x566d81['viewCache_']);}function Du(_0x12b63e,_0xd6b730){const _0x35d167=Ue(_0x12b63e['viewCache_']);return _0x35d167&&(_0x12b63e['query']['_queryParams']['loadsAllData']()||!v(_0xd6b730)&&!_0x35d167['getImmediateChild'](y(_0xd6b730))['isEmpty']())?_0x35d167['getChild'](_0xd6b730):null;}function lr(_0x437f01){return _0x437f01['eventRegistrations_']['length']===0x0;}function Mu(_0x2d958b,_0x33681f){_0x2d958b['eventRegistrations_']['push'](_0x33681f);}function hr(_0x11e3b8,_0x1634c6,_0x3a79e3){const _0x4df21c=[];if(_0x3a79e3){f(_0x1634c6==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2da4c9=_0x11e3b8['query']['_path'];_0x11e3b8['eventRegistrations_']['forEach'](_0x457301=>{const _0x7f2b55=_0x457301['createCancelEvent'](_0x3a79e3,_0x2da4c9);_0x7f2b55&&_0x4df21c['push'](_0x7f2b55);});}if(_0x1634c6){let _0x3eaba9=[];for(let _0x4e3b18=0x0;_0x4e3b18<_0x11e3b8['eventRegistrations_']['length'];++_0x4e3b18){const _0x5c12c1=_0x11e3b8['eventRegistrations_'][_0x4e3b18];if(!_0x5c12c1['matches'](_0x1634c6))_0x3eaba9['push'](_0x5c12c1);else{if(_0x1634c6['hasAnyCallback']()){_0x3eaba9=_0x3eaba9['concat'](_0x11e3b8['eventRegistrations_']['slice'](_0x4e3b18+0x1));break;}}}_0x11e3b8['eventRegistrations_']=_0x3eaba9;}else _0x11e3b8['eventRegistrations_']=[];return _0x4df21c;}function ur(_0x2b1128,_0x18d88d,_0x37181c,_0x5b39a3){_0x18d88d['type']===q['MERGE']&&_0x18d88d['source']['queryId']!==null&&(f(Ue(_0x2b1128['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2b1128['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5f277b=_0x2b1128['viewCache_'],_0x5d3eb1=Tu(_0x2b1128['processor_'],_0x5f277b,_0x18d88d,_0x37181c,_0x5b39a3);return Cu(_0x2b1128['processor_'],_0x5d3eb1['viewCache']),f(_0x5d3eb1['viewCache']['serverCache']['isFullyInitialized']()||!_0x5f277b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2b1128['viewCache_']=_0x5d3eb1['viewCache'],$o(_0x2b1128,_0x5d3eb1['changes'],_0x5d3eb1['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x428d5c,_0x23d646){const _0x50973a=_0x428d5c['viewCache_']['eventCache'],_0x2c4170=[];return _0x50973a['getNode']()['isLeafNode']()||_0x50973a['getNode']()['forEachChild'](R,(_0x55a052,_0x58407b)=>{_0x2c4170['push'](tt(_0x55a052,_0x58407b));}),_0x50973a['isFullyInitialized']()&&_0x2c4170['push'](Oo(_0x50973a['getNode']())),$o(_0x428d5c,_0x2c4170,_0x50973a['getNode'](),_0x23d646);}function $o(_0x5348c9,_0x189212,_0x58a1d5,_0x2e528a){const _0x2b53da=_0x2e528a?[_0x2e528a]:_0x5348c9['eventRegistrations_'];return nu(_0x5348c9['eventGenerator_'],_0x189212,_0x58a1d5,_0x2b53da);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x1494d8){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x1494d8;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x227235){return _0x227235['views']['size']===0x0;}function is(_0x9a25a4,_0x5c2354,_0x3ad4d9,_0x3ad095){const _0x38b893=_0x5c2354['source']['queryId'];if(_0x38b893!==null){const _0x437a1a=_0x9a25a4['views']['get'](_0x38b893);return f(_0x437a1a!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x437a1a,_0x5c2354,_0x3ad4d9,_0x3ad095);}else{let _0x3c0bc3=[];for(const _0x228a39 of _0x9a25a4['views']['values']())_0x3c0bc3=_0x3c0bc3['concat'](ur(_0x228a39,_0x5c2354,_0x3ad4d9,_0x3ad095));return _0x3c0bc3;}}function qo(_0x5a82b8,_0x5ad312,_0x3a56f7,_0x4c77e8,_0x4a1de1){const _0x528329=_0x5ad312['_queryIdentifier'],_0x46efbf=_0x5a82b8['views']['get'](_0x528329);if(!_0x46efbf){let _0x294afc=mn(_0x3a56f7,_0x4a1de1?_0x4c77e8:null),_0x19a4dd=!0x1;_0x294afc?_0x19a4dd=!0x0:_0x4c77e8 instanceof g?(_0x294afc=es(_0x3a56f7,_0x4c77e8),_0x19a4dd=!0x1):(_0x294afc=g['EMPTY_NODE'],_0x19a4dd=!0x1);const _0x347864=Dn(new Ce(_0x294afc,_0x19a4dd,!0x1),new Ce(_0x4c77e8,_0x4a1de1,!0x1));return new Nu(_0x5ad312,_0x347864);}return _0x46efbf;}function Wu(_0x364f30,_0xa64b22,_0x22121a,_0x894770,_0x4f4ef1,_0x27e1fb){const _0x5c5543=qo(_0x364f30,_0xa64b22,_0x894770,_0x4f4ef1,_0x27e1fb);return _0x364f30['views']['has'](_0xa64b22['_queryIdentifier'])||_0x364f30['views']['set'](_0xa64b22['_queryIdentifier'],_0x5c5543),Mu(_0x5c5543,_0x22121a),Lu(_0x5c5543,_0x22121a);}function Bu(_0x439dd9,_0x5e4534,_0x48fea2,_0x5df066){const _0x582b7e=_0x5e4534['_queryIdentifier'],_0x31d0af=[];let _0x24e37a=[];const _0x42c2b5=Te(_0x439dd9);if(_0x582b7e==='default'){for(const [_0x3fe499,_0x1c183d]of _0x439dd9['views']['entries']())_0x24e37a=_0x24e37a['concat'](hr(_0x1c183d,_0x48fea2,_0x5df066)),lr(_0x1c183d)&&(_0x439dd9['views']['delete'](_0x3fe499),_0x1c183d['query']['_queryParams']['loadsAllData']()||_0x31d0af['push'](_0x1c183d['query']));}else{const _0x68138d=_0x439dd9['views']['get'](_0x582b7e);_0x68138d&&(_0x24e37a=_0x24e37a['concat'](hr(_0x68138d,_0x48fea2,_0x5df066)),lr(_0x68138d)&&(_0x439dd9['views']['delete'](_0x582b7e),_0x68138d['query']['_queryParams']['loadsAllData']()||_0x31d0af['push'](_0x68138d['query'])));}return _0x42c2b5&&!Te(_0x439dd9)&&_0x31d0af['push'](new(Fu())(_0x5e4534['_repo'],_0x5e4534['_path'])),{'removed':_0x31d0af,'events':_0x24e37a};}function zo(_0xa6e26d){const _0x19505b=[];for(const _0x50cbd5 of _0xa6e26d['views']['values']())_0x50cbd5['query']['_queryParams']['loadsAllData']()||_0x19505b['push'](_0x50cbd5);return _0x19505b;}function Ee(_0x1206e4,_0x4d9cf7){let _0x442d73=null;for(const _0xd673fc of _0x1206e4['views']['values']())_0x442d73=_0x442d73||Du(_0xd673fc,_0x4d9cf7);return _0x442d73;}function jo(_0x1d414a,_0x394fb5){if(_0x394fb5['_queryParams']['loadsAllData']())return Ln(_0x1d414a);{const _0x432280=_0x394fb5['_queryIdentifier'];return _0x1d414a['views']['get'](_0x432280);}}function Ko(_0xaa97aa,_0x59302a){return jo(_0xaa97aa,_0x59302a)!=null;}function Te(_0x2c4cb7){return Ln(_0x2c4cb7)!=null;}function Ln(_0x246c8c){for(const _0x4beedf of _0x246c8c['views']['values']())if(_0x4beedf['query']['_queryParams']['loadsAllData']())return _0x4beedf;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x6e1d16){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x6e1d16;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x53d668){this['listenProvider_']=_0x53d668,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x4801b8,_0x384737,_0xd8f94,_0x4d54b7,_0x332801){return ou(_0x4801b8['pendingWriteTree_'],_0x384737,_0xd8f94,_0x4d54b7,_0x332801),_0x332801?ht(_0x4801b8,new Fe(Ji(),_0x384737,_0xd8f94)):[];}function Gu(_0x54c6e3,_0x4906fe,_0x2b4e22,_0x373e0d){au(_0x54c6e3['pendingWriteTree_'],_0x4906fe,_0x2b4e22,_0x373e0d);const _0x3735a8=S['fromObject'](_0x2b4e22);return ht(_0x54c6e3,new nt(Ji(),_0x4906fe,_0x3735a8));}function pe(_0x140d6e,_0x200ed2,_0x7f5af0=!0x1){const _0x1abfd9=cu(_0x140d6e['pendingWriteTree_'],_0x200ed2);if(lu(_0x140d6e['pendingWriteTree_'],_0x200ed2)){let _0x3f5f0e=new S(null);return _0x1abfd9['snap']!=null?_0x3f5f0e=_0x3f5f0e['set'](w(),!0x0):x(_0x1abfd9['children'],_0x339d7a=>{_0x3f5f0e=_0x3f5f0e['set'](new C(_0x339d7a),!0x0);}),ht(_0x140d6e,new _n(_0x1abfd9['path'],_0x3f5f0e,_0x7f5af0));}else return[];}function $t(_0x46dbce,_0xf7e076,_0x55760b){return ht(_0x46dbce,new Fe(Xi(),_0xf7e076,_0x55760b));}function qu(_0x1a14e0,_0x5f2d0b,_0x1cab77){const _0xaa2300=S['fromObject'](_0x1cab77);return ht(_0x1a14e0,new nt(Xi(),_0x5f2d0b,_0xaa2300));}function zu(_0x4bf4d8,_0x4ea31b){return ht(_0x4bf4d8,new Dt(Xi(),_0x4ea31b));}function ju(_0x989952,_0x3f509f,_0x544ba5){const _0x2f721b=rs(_0x989952,_0x544ba5);if(_0x2f721b){const _0x2d5e28=os(_0x2f721b),_0x14130d=_0x2d5e28['path'],_0x5c0c32=_0x2d5e28['queryId'],_0x3f7b1c=F(_0x14130d,_0x3f509f),_0x43006e=new Dt(Zi(_0x5c0c32),_0x3f7b1c);return as(_0x989952,_0x14130d,_0x43006e);}else return[];}function wn(_0x1d1841,_0x43d93e,_0x3ca452,_0x45bf75,_0x340bf2=!0x1){const _0x10d7ce=_0x43d93e['_path'],_0x4d8452=_0x1d1841['syncPointTree_']['get'](_0x10d7ce);let _0x3fb319=[];if(_0x4d8452&&(_0x43d93e['_queryIdentifier']==='default'||Ko(_0x4d8452,_0x43d93e))){const _0x1d0a23=Bu(_0x4d8452,_0x43d93e,_0x3ca452,_0x45bf75);Uu(_0x4d8452)&&(_0x1d1841['syncPointTree_']=_0x1d1841['syncPointTree_']['remove'](_0x10d7ce));const _0x1d3986=_0x1d0a23['removed'];if(_0x3fb319=_0x1d0a23['events'],!_0x340bf2){const _0x2eb679=_0x1d3986['findIndex'](_0x583878=>_0x583878['_queryParams']['loadsAllData']())!==-0x1,_0x48254c=_0x1d1841['syncPointTree_']['findOnPath'](_0x10d7ce,(_0x16eb35,_0x465e06)=>Te(_0x465e06));if(_0x2eb679&&!_0x48254c){const _0x356fbe=_0x1d1841['syncPointTree_']['subtree'](_0x10d7ce);if(!_0x356fbe['isEmpty']()){const _0x1d3aba=Qu(_0x356fbe);for(let _0x1afd42=0x0;_0x1afd42<_0x1d3aba['length'];++_0x1afd42){const _0x48fa05=_0x1d3aba[_0x1afd42],_0x5efe95=_0x48fa05['query'],_0x59874f=Xo(_0x1d1841,_0x48fa05);_0x1d1841['listenProvider_']['startListening'](Tt(_0x5efe95),Mt(_0x1d1841,_0x5efe95),_0x59874f['hashFn'],_0x59874f['onComplete']);}}}!_0x48254c&&_0x1d3986['length']>0x0&&!_0x45bf75&&(_0x2eb679?_0x1d1841['listenProvider_']['stopListening'](Tt(_0x43d93e),null):_0x1d3986['forEach'](_0x43875a=>{const _0x3792ad=_0x1d1841['queryToTagMap']['get'](Fn(_0x43875a));_0x1d1841['listenProvider_']['stopListening'](Tt(_0x43875a),_0x3792ad);}));}Ju(_0x1d1841,_0x1d3986);}return _0x3fb319;}function Yo(_0x3a2256,_0x34781a,_0x33f91a,_0x3358ec){const _0x57c10f=rs(_0x3a2256,_0x3358ec);if(_0x57c10f!=null){const _0x58607e=os(_0x57c10f),_0x5641f7=_0x58607e['path'],_0x3127bf=_0x58607e['queryId'],_0x2b2f91=F(_0x5641f7,_0x34781a),_0x1db842=new Fe(Zi(_0x3127bf),_0x2b2f91,_0x33f91a);return as(_0x3a2256,_0x5641f7,_0x1db842);}else return[];}function Ku(_0x37c568,_0x4e1529,_0x27876f,_0x55feec){const _0xdc6bde=rs(_0x37c568,_0x55feec);if(_0xdc6bde){const _0x5abc78=os(_0xdc6bde),_0x39cec0=_0x5abc78['path'],_0xae8c1c=_0x5abc78['queryId'],_0x2ac4a4=F(_0x39cec0,_0x4e1529),_0x1cb257=S['fromObject'](_0x27876f),_0x45539e=new nt(Zi(_0xae8c1c),_0x2ac4a4,_0x1cb257);return as(_0x37c568,_0x39cec0,_0x45539e);}else return[];}function bi(_0x11bd3a,_0x27fd58,_0xa46005,_0x503b48=!0x1){const _0x5e4aba=_0x27fd58['_path'];let _0x169e9e=null,_0x268f45=!0x1;_0x11bd3a['syncPointTree_']['foreachOnPath'](_0x5e4aba,(_0x75297f,_0x5015f5)=>{const _0x48754f=F(_0x75297f,_0x5e4aba);_0x169e9e=_0x169e9e||Ee(_0x5015f5,_0x48754f),_0x268f45=_0x268f45||Te(_0x5015f5);});let _0x5be8aa=_0x11bd3a['syncPointTree_']['get'](_0x5e4aba);_0x5be8aa?(_0x268f45=_0x268f45||Te(_0x5be8aa),_0x169e9e=_0x169e9e||Ee(_0x5be8aa,w())):(_0x5be8aa=new Go(),_0x11bd3a['syncPointTree_']=_0x11bd3a['syncPointTree_']['set'](_0x5e4aba,_0x5be8aa));let _0x7fe0ea;_0x169e9e!=null?_0x7fe0ea=!0x0:(_0x7fe0ea=!0x1,_0x169e9e=g['EMPTY_NODE'],_0x11bd3a['syncPointTree_']['subtree'](_0x5e4aba)['foreachChild']((_0x525b94,_0x182f21)=>{const _0x2ef8fe=Ee(_0x182f21,w());_0x2ef8fe&&(_0x169e9e=_0x169e9e['updateImmediateChild'](_0x525b94,_0x2ef8fe));}));const _0x15d838=Ko(_0x5be8aa,_0x27fd58);if(!_0x15d838&&!_0x27fd58['_queryParams']['loadsAllData']()){const _0x3bdfae=Fn(_0x27fd58);f(!_0x11bd3a['queryToTagMap']['has'](_0x3bdfae),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2f132a=Xu();_0x11bd3a['queryToTagMap']['set'](_0x3bdfae,_0x2f132a),_0x11bd3a['tagToQueryMap']['set'](_0x2f132a,_0x3bdfae);}const _0xba7161=Mn(_0x11bd3a['pendingWriteTree_'],_0x5e4aba);let _0x5970df=Wu(_0x5be8aa,_0x27fd58,_0xa46005,_0xba7161,_0x169e9e,_0x7fe0ea);if(!_0x15d838&&!_0x268f45&&!_0x503b48){const _0x39ee7f=jo(_0x5be8aa,_0x27fd58);_0x5970df=_0x5970df['concat'](Zu(_0x11bd3a,_0x27fd58,_0x39ee7f));}return _0x5970df;}function xn(_0x1fd358,_0x208126,_0xe4de09){const _0x20bd44=_0x1fd358['pendingWriteTree_'],_0x261260=_0x1fd358['syncPointTree_']['findOnPath'](_0x208126,(_0xc90c1e,_0x53eebe)=>{const _0x2d5d08=F(_0xc90c1e,_0x208126),_0x968b1f=Ee(_0x53eebe,_0x2d5d08);if(_0x968b1f)return _0x968b1f;});return Uo(_0x20bd44,_0x208126,_0x261260,_0xe4de09,!0x0);}function Yu(_0x422106,_0x2484fb){const _0x2e090d=_0x2484fb['_path'];let _0x775cc=null;_0x422106['syncPointTree_']['foreachOnPath'](_0x2e090d,(_0x2a65c1,_0x5d2bde)=>{const _0x474fc9=F(_0x2a65c1,_0x2e090d);_0x775cc=_0x775cc||Ee(_0x5d2bde,_0x474fc9);});let _0x3d9aa3=_0x422106['syncPointTree_']['get'](_0x2e090d);_0x3d9aa3?_0x775cc=_0x775cc||Ee(_0x3d9aa3,w()):(_0x3d9aa3=new Go(),_0x422106['syncPointTree_']=_0x422106['syncPointTree_']['set'](_0x2e090d,_0x3d9aa3));const _0x3001bb=_0x775cc!=null,_0x1d94cd=_0x3001bb?new Ce(_0x775cc,!0x0,!0x1):null,_0x5ecae5=Mn(_0x422106['pendingWriteTree_'],_0x2484fb['_path']),_0x1672bc=qo(_0x3d9aa3,_0x2484fb,_0x5ecae5,_0x3001bb?_0x1d94cd['getNode']():g['EMPTY_NODE'],_0x3001bb);return Ou(_0x1672bc);}function ht(_0x3439ec,_0xe6c0d5){return Qo(_0xe6c0d5,_0x3439ec['syncPointTree_'],null,Mn(_0x3439ec['pendingWriteTree_'],w()));}function Qo(_0x3d4fdc,_0x328b82,_0x4dc005,_0x4f87cc){if(v(_0x3d4fdc['path']))return Jo(_0x3d4fdc,_0x328b82,_0x4dc005,_0x4f87cc);{const _0x32ac5e=_0x328b82['get'](w());_0x4dc005==null&&_0x32ac5e!=null&&(_0x4dc005=Ee(_0x32ac5e,w()));let _0x5dadb3=[];const _0x4b186a=y(_0x3d4fdc['path']),_0x424a4a=_0x3d4fdc['operationForChild'](_0x4b186a),_0x407d34=_0x328b82['children']['get'](_0x4b186a);if(_0x407d34&&_0x424a4a){const _0x5d9461=_0x4dc005?_0x4dc005['getImmediateChild'](_0x4b186a):null,_0xfb1ba=Wo(_0x4f87cc,_0x4b186a);_0x5dadb3=_0x5dadb3['concat'](Qo(_0x424a4a,_0x407d34,_0x5d9461,_0xfb1ba));}return _0x32ac5e&&(_0x5dadb3=_0x5dadb3['concat'](is(_0x32ac5e,_0x3d4fdc,_0x4f87cc,_0x4dc005))),_0x5dadb3;}}function Jo(_0x4ad80b,_0x5803f2,_0x3dbd0c,_0x292382){const _0x17ffc1=_0x5803f2['get'](w());_0x3dbd0c==null&&_0x17ffc1!=null&&(_0x3dbd0c=Ee(_0x17ffc1,w()));let _0x849c53=[];return _0x5803f2['children']['inorderTraversal']((_0x54e8b5,_0x349b56)=>{const _0x496b18=_0x3dbd0c?_0x3dbd0c['getImmediateChild'](_0x54e8b5):null,_0x56eafe=Wo(_0x292382,_0x54e8b5),_0xcf2760=_0x4ad80b['operationForChild'](_0x54e8b5);_0xcf2760&&(_0x849c53=_0x849c53['concat'](Jo(_0xcf2760,_0x349b56,_0x496b18,_0x56eafe)));}),_0x17ffc1&&(_0x849c53=_0x849c53['concat'](is(_0x17ffc1,_0x4ad80b,_0x292382,_0x3dbd0c))),_0x849c53;}function Xo(_0x24ea87,_0x5a0d5b){const _0x5b2903=_0x5a0d5b['query'],_0x2fdc03=Mt(_0x24ea87,_0x5b2903);return{'hashFn':()=>(Pu(_0x5a0d5b)||g['EMPTY_NODE'])['hash'](),'onComplete':_0xa84e34=>{if(_0xa84e34==='ok')return _0x2fdc03?ju(_0x24ea87,_0x5b2903['_path'],_0x2fdc03):zu(_0x24ea87,_0x5b2903['_path']);{const _0x1d58c8=ql(_0xa84e34,_0x5b2903);return wn(_0x24ea87,_0x5b2903,null,_0x1d58c8);}}};}function Mt(_0x1415a5,_0x145194){const _0x4d40cf=Fn(_0x145194);return _0x1415a5['queryToTagMap']['get'](_0x4d40cf);}function Fn(_0x3efd50){return _0x3efd50['_path']['toString']()+'$'+_0x3efd50['_queryIdentifier'];}function rs(_0x50a990,_0x1856b1){return _0x50a990['tagToQueryMap']['get'](_0x1856b1);}function os(_0x3e1df2){const _0x5af0f7=_0x3e1df2['indexOf']('$');return f(_0x5af0f7!==-0x1&&_0x5af0f7<_0x3e1df2['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3e1df2['substr'](_0x5af0f7+0x1),'path':new C(_0x3e1df2['substr'](0x0,_0x5af0f7))};}function as(_0x34653a,_0x1c14ed,_0x2c0728){const _0x1d4805=_0x34653a['syncPointTree_']['get'](_0x1c14ed);f(_0x1d4805,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3ce4e2=Mn(_0x34653a['pendingWriteTree_'],_0x1c14ed);return is(_0x1d4805,_0x2c0728,_0x3ce4e2,null);}function Qu(_0x537059){return _0x537059['fold']((_0x23f86b,_0x4aa53d,_0x1efa4f)=>{if(_0x4aa53d&&Te(_0x4aa53d))return[Ln(_0x4aa53d)];{let _0x1cb21a=[];return _0x4aa53d&&(_0x1cb21a=zo(_0x4aa53d)),x(_0x1efa4f,(_0x2fdf83,_0x1d55a8)=>{_0x1cb21a=_0x1cb21a['concat'](_0x1d55a8);}),_0x1cb21a;}});}function Tt(_0x522498){return _0x522498['_queryParams']['loadsAllData']()&&!_0x522498['_queryParams']['isDefault']()?new(Hu())(_0x522498['_repo'],_0x522498['_path']):_0x522498;}function Ju(_0x131abd,_0x5820e5){for(let _0x477e9d=0x0;_0x477e9d<_0x5820e5['length'];++_0x477e9d){const _0xf4a86e=_0x5820e5[_0x477e9d];if(!_0xf4a86e['_queryParams']['loadsAllData']()){const _0x82b936=Fn(_0xf4a86e),_0x47d241=_0x131abd['queryToTagMap']['get'](_0x82b936);_0x131abd['queryToTagMap']['delete'](_0x82b936),_0x131abd['tagToQueryMap']['delete'](_0x47d241);}}}function Xu(){return $u++;}function Zu(_0x2bb1bb,_0x494968,_0x376711){const _0x34ccb9=_0x494968['_path'],_0x592f47=Mt(_0x2bb1bb,_0x494968),_0x596e82=Xo(_0x2bb1bb,_0x376711),_0x4c71b5=_0x2bb1bb['listenProvider_']['startListening'](Tt(_0x494968),_0x592f47,_0x596e82['hashFn'],_0x596e82['onComplete']),_0x1c0282=_0x2bb1bb['syncPointTree_']['subtree'](_0x34ccb9);if(_0x592f47)f(!Te(_0x1c0282['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2a2a55=_0x1c0282['fold']((_0x516323,_0x5f34ab,_0x501d23)=>{if(!v(_0x516323)&&_0x5f34ab&&Te(_0x5f34ab))return[Ln(_0x5f34ab)['query']];{let _0x49f2f7=[];return _0x5f34ab&&(_0x49f2f7=_0x49f2f7['concat'](zo(_0x5f34ab)['map'](_0x5f4d73=>_0x5f4d73['query']))),x(_0x501d23,(_0x3f8335,_0x108b4b)=>{_0x49f2f7=_0x49f2f7['concat'](_0x108b4b);}),_0x49f2f7;}});for(let _0x904b87=0x0;_0x904b87<_0x2a2a55['length'];++_0x904b87){const _0x28c83f=_0x2a2a55[_0x904b87];_0x2bb1bb['listenProvider_']['stopListening'](Tt(_0x28c83f),Mt(_0x2bb1bb,_0x28c83f));}}return _0x4c71b5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x105ea8){this['node_']=_0x105ea8;}['getImmediateChild'](_0x3778fe){const _0x216ec7=this['node_']['getImmediateChild'](_0x3778fe);return new cs(_0x216ec7);}['node'](){return this['node_'];}}class ls{constructor(_0x31010b,_0x2defe8){this['syncTree_']=_0x31010b,this['path_']=_0x2defe8;}['getImmediateChild'](_0x51bf11){const _0x135874=A(this['path_'],_0x51bf11);return new ls(this['syncTree_'],_0x135874);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x142398){return _0x142398=_0x142398||{},_0x142398['timestamp']=_0x142398['timestamp']||new Date()['getTime'](),_0x142398;},fr=function(_0x566baa,_0x29d4f8,_0x185cc5){if(!_0x566baa||typeof _0x566baa!='object')return _0x566baa;if(f('.sv'in _0x566baa,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x566baa['.sv']=='string')return td(_0x566baa['.sv'],_0x29d4f8,_0x185cc5);if(typeof _0x566baa['.sv']=='object')return nd(_0x566baa['.sv'],_0x29d4f8);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x566baa,null,0x2));},td=function(_0x20db00,_0x3d915e,_0x497df4){switch(_0x20db00){case'timestamp':return _0x497df4['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x20db00);}},nd=function(_0x31b78d,_0x5a2350,_0xcd7981){_0x31b78d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x31b78d,null,0x2));const _0x274ad8=_0x31b78d['increment'];typeof _0x274ad8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x274ad8);const _0x507132=_0x5a2350['node']();if(f(_0x507132!==null&&typeof _0x507132<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x507132['isLeafNode']())return _0x274ad8;const _0x1ed7d7=_0x507132['getValue']();return typeof _0x1ed7d7!='number'?_0x274ad8:_0x1ed7d7+_0x274ad8;},Zo=function(_0x39c69f,_0x1d387f,_0x397935,_0x2888d2){return us(_0x1d387f,new ls(_0x397935,_0x39c69f),_0x2888d2);},hs=function(_0x99d1da,_0x8d5ac,_0x3792d6){return us(_0x99d1da,new cs(_0x8d5ac),_0x3792d6);};function us(_0x290be0,_0x503d73,_0x293bff){const _0x1d7626=_0x290be0['getPriority']()['val'](),_0x343b5f=fr(_0x1d7626,_0x503d73['getImmediateChild']('.priority'),_0x293bff);let _0x729652;if(_0x290be0['isLeafNode']()){const _0x13429c=_0x290be0,_0x357764=fr(_0x13429c['getValue'](),_0x503d73,_0x293bff);return _0x357764!==_0x13429c['getValue']()||_0x343b5f!==_0x13429c['getPriority']()['val']()?new D(_0x357764,N(_0x343b5f)):_0x290be0;}else{const _0x166e96=_0x290be0;return _0x729652=_0x166e96,_0x343b5f!==_0x166e96['getPriority']()['val']()&&(_0x729652=_0x729652['updatePriority'](new D(_0x343b5f))),_0x166e96['forEachChild'](R,(_0x44a7c1,_0xa3120d)=>{const _0x249904=us(_0xa3120d,_0x503d73['getImmediateChild'](_0x44a7c1),_0x293bff);_0x249904!==_0xa3120d&&(_0x729652=_0x729652['updateImmediateChild'](_0x44a7c1,_0x249904));}),_0x729652;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x34bd7a='',_0x49ef60=null,_0x206a8d={'children':{},'childCount':0x0}){this['name']=_0x34bd7a,this['parent']=_0x49ef60,this['node']=_0x206a8d;}}function Un(_0x18c8b0,_0x2b233b){let _0x49ffb3=_0x2b233b instanceof C?_0x2b233b:new C(_0x2b233b),_0x57bc44=_0x18c8b0,_0x3fae7e=y(_0x49ffb3);for(;_0x3fae7e!==null;){const _0x5768a3=Oe(_0x57bc44['node']['children'],_0x3fae7e)||{'children':{},'childCount':0x0};_0x57bc44=new ds(_0x3fae7e,_0x57bc44,_0x5768a3),_0x49ffb3=b(_0x49ffb3),_0x3fae7e=y(_0x49ffb3);}return _0x57bc44;}function Ge(_0xc0b585){return _0xc0b585['node']['value'];}function fs(_0x38c005,_0x3f62a7){_0x38c005['node']['value']=_0x3f62a7,Ri(_0x38c005);}function ea(_0x20e7f9){return _0x20e7f9['node']['childCount']>0x0;}function id(_0x472946){return Ge(_0x472946)===void 0x0&&!ea(_0x472946);}function Wn(_0x34b58b,_0x4fa547){x(_0x34b58b['node']['children'],(_0x17ff72,_0xa857bf)=>{_0x4fa547(new ds(_0x17ff72,_0x34b58b,_0xa857bf));});}function ta(_0x4d0a74,_0x5b678b,_0x6fac03,_0x3dcc10){_0x6fac03&&_0x5b678b(_0x4d0a74),Wn(_0x4d0a74,_0x478797=>{ta(_0x478797,_0x5b678b,!0x0);});}function sd(_0x23c32b,_0x99e0f,_0x5ecbba){let _0x1cb6ab=_0x23c32b['parent'];for(;_0x1cb6ab!==null;){if(_0x99e0f(_0x1cb6ab))return!0x0;_0x1cb6ab=_0x1cb6ab['parent'];}return!0x1;}function Gt(_0x6baca0){return new C(_0x6baca0['parent']===null?_0x6baca0['name']:Gt(_0x6baca0['parent'])+'/'+_0x6baca0['name']);}function Ri(_0x5d6227){_0x5d6227['parent']!==null&&rd(_0x5d6227['parent'],_0x5d6227['name'],_0x5d6227);}function rd(_0x1d90c3,_0x5f521f,_0x1b2a9a){const _0x3c3343=id(_0x1b2a9a),_0x51d93a=Y(_0x1d90c3['node']['children'],_0x5f521f);_0x3c3343&&_0x51d93a?(delete _0x1d90c3['node']['children'][_0x5f521f],_0x1d90c3['node']['childCount']--,Ri(_0x1d90c3)):!_0x3c3343&&!_0x51d93a&&(_0x1d90c3['node']['children'][_0x5f521f]=_0x1b2a9a['node'],_0x1d90c3['node']['childCount']++,Ri(_0x1d90c3));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x474660){return typeof _0x474660=='string'&&_0x474660['length']!==0x0&&!od['test'](_0x474660);},na=function(_0x358745){return typeof _0x358745=='string'&&_0x358745['length']!==0x0&&!ad['test'](_0x358745);},cd=function(_0x24bcc2){return _0x24bcc2&&(_0x24bcc2=_0x24bcc2['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x24bcc2);},Cn=function(_0x1b0d06){return _0x1b0d06===null||typeof _0x1b0d06=='string'||typeof _0x1b0d06=='number'&&!Wi(_0x1b0d06)||_0x1b0d06&&typeof _0x1b0d06=='object'&&Y(_0x1b0d06,'.sv');},qt=function(_0x3248bd,_0x3762e6,_0x427d37,_0x2df5a5){_0x2df5a5&&_0x3762e6===void 0x0||zt(Nn(_0x3248bd,'value'),_0x3762e6,_0x427d37);},zt=function(_0x11abd6,_0x19f7de,_0x2e5583){const _0x2db0a6=_0x2e5583 instanceof C?new Sh(_0x2e5583,_0x11abd6):_0x2e5583;if(_0x19f7de===void 0x0)throw new Error(_0x11abd6+'contains\x20undefined\x20'+Ne(_0x2db0a6));if(typeof _0x19f7de=='function')throw new Error(_0x11abd6+'contains\x20a\x20function\x20'+Ne(_0x2db0a6)+'\x20with\x20contents\x20=\x20'+_0x19f7de['toString']());if(Wi(_0x19f7de))throw new Error(_0x11abd6+'contains\x20'+_0x19f7de['toString']()+'\x20'+Ne(_0x2db0a6));if(typeof _0x19f7de=='string'&&_0x19f7de['length']>oi/0x3&&Pn(_0x19f7de)>oi)throw new Error(_0x11abd6+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x2db0a6)+'\x20(\x27'+_0x19f7de['substring'](0x0,0x32)+'...\x27)');if(_0x19f7de&&typeof _0x19f7de=='object'){let _0x232f22=!0x1,_0x40a5fa=!0x1;if(x(_0x19f7de,(_0x14f652,_0x4b428d)=>{if(_0x14f652==='.value')_0x232f22=!0x0;else{if(_0x14f652!=='.priority'&&_0x14f652!=='.sv'&&(_0x40a5fa=!0x0,!ps(_0x14f652)))throw new Error(_0x11abd6+'\x20contains\x20an\x20invalid\x20key\x20('+_0x14f652+')\x20'+Ne(_0x2db0a6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x2db0a6,_0x14f652),zt(_0x11abd6,_0x4b428d,_0x2db0a6),Rh(_0x2db0a6);}),_0x232f22&&_0x40a5fa)throw new Error(_0x11abd6+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2db0a6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x313056,_0x4195dd){let _0x493130,_0xd10290;for(_0x493130=0x0;_0x493130<_0x4195dd['length'];_0x493130++){_0xd10290=_0x4195dd[_0x493130];const _0x332f8c=kt(_0xd10290);for(let _0x436f3a=0x0;_0x436f3a<_0x332f8c['length'];_0x436f3a++)if(!(_0x332f8c[_0x436f3a]==='.priority'&&_0x436f3a===_0x332f8c['length']-0x1)){if(!ps(_0x332f8c[_0x436f3a]))throw new Error(_0x313056+'contains\x20an\x20invalid\x20key\x20('+_0x332f8c[_0x436f3a]+')\x20in\x20path\x20'+_0xd10290['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4195dd['sort'](Th);let _0x17ac77=null;for(_0x493130=0x0;_0x493130<_0x4195dd['length'];_0x493130++){if(_0xd10290=_0x4195dd[_0x493130],_0x17ac77!==null&&$(_0x17ac77,_0xd10290))throw new Error(_0x313056+'contains\x20a\x20path\x20'+_0x17ac77['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xd10290['toString']());_0x17ac77=_0xd10290;}},hd=function(_0x4b42a7,_0x1c53e0,_0x407c8c,_0x12658a){const _0x42d756=Nn(_0x4b42a7,'values');if(!(_0x1c53e0&&typeof _0x1c53e0=='object')||Array['isArray'](_0x1c53e0))throw new Error(_0x42d756+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1decc4=[];x(_0x1c53e0,(_0x3ec9a4,_0x22914a)=>{const _0x3810f2=new C(_0x3ec9a4);if(zt(_0x42d756,_0x22914a,A(_0x407c8c,_0x3810f2)),Gi(_0x3810f2)==='.priority'&&!Cn(_0x22914a))throw new Error(_0x42d756+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3810f2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1decc4['push'](_0x3810f2);}),ld(_0x42d756,_0x1decc4);},_s=function(_0x41b9ba,_0x40a98b,_0x566116,_0x48200e){if(!na(_0x566116))throw new Error(Nn(_0x41b9ba,_0x40a98b)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x566116+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x29508a,_0x3b3037,_0x350e21,_0x4cd736){_0x350e21&&(_0x350e21=_0x350e21['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x29508a,_0x3b3037,_0x350e21);},gs=function(_0x309c71,_0x243001){if(y(_0x243001)==='.info')throw new Error(_0x309c71+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x33a8cf,_0x1ce408){const _0x4de6d1=_0x1ce408['path']['toString']();if(typeof _0x1ce408['repoInfo']['host']!='string'||_0x1ce408['repoInfo']['host']['length']===0x0||!ps(_0x1ce408['repoInfo']['namespace'])&&_0x1ce408['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4de6d1['length']!==0x0&&!cd(_0x4de6d1))throw new Error(Nn(_0x33a8cf,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0xf4d7ec,_0x1723bc){let _0x26c26b=null;for(let _0x4a813a=0x0;_0x4a813a<_0x1723bc['length'];_0x4a813a++){const _0x53a434=_0x1723bc[_0x4a813a],_0x4667f3=_0x53a434['getPath']();_0x26c26b!==null&&!qi(_0x4667f3,_0x26c26b['path'])&&(_0xf4d7ec['eventLists_']['push'](_0x26c26b),_0x26c26b=null),_0x26c26b===null&&(_0x26c26b={'events':[],'path':_0x4667f3}),_0x26c26b['events']['push'](_0x53a434);}_0x26c26b&&_0xf4d7ec['eventLists_']['push'](_0x26c26b);}function ia(_0x59e181,_0x3f2211,_0x34db8c){Bn(_0x59e181,_0x34db8c),sa(_0x59e181,_0x4ce80b=>qi(_0x4ce80b,_0x3f2211));}function V(_0x5b21e9,_0x3f7f48,_0x118aab){Bn(_0x5b21e9,_0x118aab),sa(_0x5b21e9,_0x24c375=>$(_0x24c375,_0x3f7f48)||$(_0x3f7f48,_0x24c375));}function sa(_0x39cef7,_0x569ac8){_0x39cef7['recursionDepth_']++;let _0x202577=!0x0;for(let _0x559f1b=0x0;_0x559f1b<_0x39cef7['eventLists_']['length'];_0x559f1b++){const _0x5a93fd=_0x39cef7['eventLists_'][_0x559f1b];if(_0x5a93fd){const _0x26ac2a=_0x5a93fd['path'];_0x569ac8(_0x26ac2a)?(pd(_0x39cef7['eventLists_'][_0x559f1b]),_0x39cef7['eventLists_'][_0x559f1b]=null):_0x202577=!0x1;}}_0x202577&&(_0x39cef7['eventLists_']=[]),_0x39cef7['recursionDepth_']--;}function pd(_0x4de0f0){for(let _0x20f23c=0x0;_0x20f23c<_0x4de0f0['events']['length'];_0x20f23c++){const _0x2e9e1b=_0x4de0f0['events'][_0x20f23c];if(_0x2e9e1b!==null){_0x4de0f0['events'][_0x20f23c]=null;const _0x38464c=_0x2e9e1b['getEventRunner']();Et&&L('event:\x20'+_0x2e9e1b['toString']()),lt(_0x38464c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x3765c4,_0x4f5ae3,_0x57990f,_0x11c49f){this['repoInfo_']=_0x3765c4,this['forceRestClient_']=_0x4f5ae3,this['authTokenProvider_']=_0x57990f,this['appCheckProvider_']=_0x11c49f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x2f9d46,_0x232889,_0xc0d139){if(_0x2f9d46['stats_']=Hi(_0x2f9d46['repoInfo_']),_0x2f9d46['forceRestClient_']||Yl())_0x2f9d46['server_']=new fn(_0x2f9d46['repoInfo_'],(_0x5a9948,_0xda841d,_0x1ac7d0,_0x481f18)=>{pr(_0x2f9d46,_0x5a9948,_0xda841d,_0x1ac7d0,_0x481f18);},_0x2f9d46['authTokenProvider_'],_0x2f9d46['appCheckProvider_']),setTimeout(()=>_r(_0x2f9d46,!0x0),0x0);else{if(typeof _0xc0d139<'u'&&_0xc0d139!==null){if(typeof _0xc0d139!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xc0d139);}catch(_0x57c102){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x57c102);}}_0x2f9d46['persistentConnection_']=new ie(_0x2f9d46['repoInfo_'],_0x232889,(_0xc74245,_0x10d191,_0x9c8acf,_0x5d62a2)=>{pr(_0x2f9d46,_0xc74245,_0x10d191,_0x9c8acf,_0x5d62a2);},_0x5d1ccc=>{_r(_0x2f9d46,_0x5d1ccc);},_0x4412c3=>{yd(_0x2f9d46,_0x4412c3);},_0x2f9d46['authTokenProvider_'],_0x2f9d46['appCheckProvider_'],_0xc0d139),_0x2f9d46['server_']=_0x2f9d46['persistentConnection_'];}_0x2f9d46['authTokenProvider_']['addTokenChangeListener'](_0x2ad5bd=>{_0x2f9d46['server_']['refreshAuthToken'](_0x2ad5bd);}),_0x2f9d46['appCheckProvider_']['addTokenChangeListener'](_0x30b5e7=>{_0x2f9d46['server_']['refreshAppCheckToken'](_0x30b5e7['token']);}),_0x2f9d46['statsReporter_']=eh(_0x2f9d46['repoInfo_'],()=>new eu(_0x2f9d46['stats_'],_0x2f9d46['server_'])),_0x2f9d46['infoData_']=new Yh(),_0x2f9d46['infoSyncTree_']=new dr({'startListening':(_0x646e0e,_0x47918f,_0x40036e,_0x42d079)=>{let _0x53e224=[];const _0x3e8142=_0x2f9d46['infoData_']['getNode'](_0x646e0e['_path']);return _0x3e8142['isEmpty']()||(_0x53e224=$t(_0x2f9d46['infoSyncTree_'],_0x646e0e['_path'],_0x3e8142),setTimeout(()=>{_0x42d079('ok');},0x0)),_0x53e224;},'stopListening':()=>{}}),ms(_0x2f9d46,'connected',!0x1),_0x2f9d46['serverSyncTree_']=new dr({'startListening':(_0x17f429,_0xc5bbef,_0x23275e,_0x41e413)=>(_0x2f9d46['server_']['listen'](_0x17f429,_0x23275e,_0xc5bbef,(_0x56a6b7,_0x37e0e0)=>{const _0xcaa211=_0x41e413(_0x56a6b7,_0x37e0e0);V(_0x2f9d46['eventQueue_'],_0x17f429['_path'],_0xcaa211);}),[]),'stopListening':(_0x35a74a,_0x50b2bc)=>{_0x2f9d46['server_']['unlisten'](_0x35a74a,_0x50b2bc);}});}function oa(_0x2c26a1){const _0x59f9ab=_0x2c26a1['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x59f9ab;}function jt(_0x2cdbe5){return ed({'timestamp':oa(_0x2cdbe5)});}function pr(_0x4df155,_0x5a9460,_0x1eff75,_0x11f098,_0x37bc34){_0x4df155['dataUpdateCount']++;const _0x4f583=new C(_0x5a9460);_0x1eff75=_0x4df155['interceptServerDataCallback_']?_0x4df155['interceptServerDataCallback_'](_0x5a9460,_0x1eff75):_0x1eff75;let _0x7e4989=[];if(_0x37bc34){if(_0x11f098){const _0x14c41d=ln(_0x1eff75,_0x1b72c7=>N(_0x1b72c7));_0x7e4989=Ku(_0x4df155['serverSyncTree_'],_0x4f583,_0x14c41d,_0x37bc34);}else{const _0x5780ed=N(_0x1eff75);_0x7e4989=Yo(_0x4df155['serverSyncTree_'],_0x4f583,_0x5780ed,_0x37bc34);}}else{if(_0x11f098){const _0x44bf44=ln(_0x1eff75,_0x374ad9=>N(_0x374ad9));_0x7e4989=qu(_0x4df155['serverSyncTree_'],_0x4f583,_0x44bf44);}else{const _0x2d9abb=N(_0x1eff75);_0x7e4989=$t(_0x4df155['serverSyncTree_'],_0x4f583,_0x2d9abb);}}let _0x519386=_0x4f583;_0x7e4989['length']>0x0&&(_0x519386=st(_0x4df155,_0x4f583)),V(_0x4df155['eventQueue_'],_0x519386,_0x7e4989);}function _r(_0x16671c,_0x347a52){ms(_0x16671c,'connected',_0x347a52),_0x347a52===!0x1&&wd(_0x16671c);}function yd(_0x262bf2,_0x3b2056){x(_0x3b2056,(_0x29f010,_0xa1e85e)=>{ms(_0x262bf2,_0x29f010,_0xa1e85e);});}function ms(_0x99c875,_0x288a4f,_0x172ed9){const _0x4273da=new C('/.info/'+_0x288a4f),_0x36e278=N(_0x172ed9);_0x99c875['infoData_']['updateSnapshot'](_0x4273da,_0x36e278);const _0x5d0abc=$t(_0x99c875['infoSyncTree_'],_0x4273da,_0x36e278);V(_0x99c875['eventQueue_'],_0x4273da,_0x5d0abc);}function Vn(_0xd8a9e3){return _0xd8a9e3['nextWriteId_']++;}function vd(_0x149b38,_0x5366ff,_0x560acb){const _0x4525e3=Yu(_0x149b38['serverSyncTree_'],_0x5366ff);return _0x4525e3!=null?Promise['resolve'](_0x4525e3):_0x149b38['server_']['get'](_0x5366ff)['then'](_0x3ca85e=>{const _0x2231b8=N(_0x3ca85e)['withIndex'](_0x5366ff['_queryParams']['getIndex']());bi(_0x149b38['serverSyncTree_'],_0x5366ff,_0x560acb,!0x0);let _0x2314d9;if(_0x5366ff['_queryParams']['loadsAllData']())_0x2314d9=$t(_0x149b38['serverSyncTree_'],_0x5366ff['_path'],_0x2231b8);else{const _0x23b763=Mt(_0x149b38['serverSyncTree_'],_0x5366ff);_0x2314d9=Yo(_0x149b38['serverSyncTree_'],_0x5366ff['_path'],_0x2231b8,_0x23b763);}return V(_0x149b38['eventQueue_'],_0x5366ff['_path'],_0x2314d9),wn(_0x149b38['serverSyncTree_'],_0x5366ff,_0x560acb,null,!0x0),_0x2231b8;},_0x7144e=>(ut(_0x149b38,'get\x20for\x20query\x20'+O(_0x5366ff)+'\x20failed:\x20'+_0x7144e),Promise['reject'](new Error(_0x7144e))));}function Ed(_0x2d03e5,_0x4934e6,_0x99435b,_0x3fad27,_0x57b9e8){ut(_0x2d03e5,'set',{'path':_0x4934e6['toString'](),'value':_0x99435b,'priority':_0x3fad27});const _0x377534=jt(_0x2d03e5),_0x90e593=N(_0x99435b,_0x3fad27),_0x4d72d7=xn(_0x2d03e5['serverSyncTree_'],_0x4934e6),_0x80e233=hs(_0x90e593,_0x4d72d7,_0x377534),_0x1cfa8d=Vn(_0x2d03e5),_0x298575=ss(_0x2d03e5['serverSyncTree_'],_0x4934e6,_0x80e233,_0x1cfa8d,!0x0);Bn(_0x2d03e5['eventQueue_'],_0x298575),_0x2d03e5['server_']['put'](_0x4934e6['toString'](),_0x90e593['val'](!0x0),(_0x1043cb,_0x1775a1)=>{const _0x26a179=_0x1043cb==='ok';_0x26a179||U('set\x20at\x20'+_0x4934e6+'\x20failed:\x20'+_0x1043cb);const _0x269137=pe(_0x2d03e5['serverSyncTree_'],_0x1cfa8d,!_0x26a179);V(_0x2d03e5['eventQueue_'],_0x4934e6,_0x269137),Ai(_0x2d03e5,_0x57b9e8,_0x1043cb,_0x1775a1);});const _0x5c805f=vs(_0x2d03e5,_0x4934e6);st(_0x2d03e5,_0x5c805f),V(_0x2d03e5['eventQueue_'],_0x5c805f,[]);}function Id(_0x4079f5,_0x1f74c1,_0x41fa18,_0x379ef1){ut(_0x4079f5,'update',{'path':_0x1f74c1['toString'](),'value':_0x41fa18});let _0x2a30f1=!0x0;const _0x17ef43=jt(_0x4079f5),_0x276f87={};if(x(_0x41fa18,(_0x5231ae,_0x39af43)=>{_0x2a30f1=!0x1,_0x276f87[_0x5231ae]=Zo(A(_0x1f74c1,_0x5231ae),N(_0x39af43),_0x4079f5['serverSyncTree_'],_0x17ef43);}),_0x2a30f1)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x4079f5,_0x379ef1,'ok',void 0x0);else{const _0x153954=Vn(_0x4079f5),_0x2c26fc=Gu(_0x4079f5['serverSyncTree_'],_0x1f74c1,_0x276f87,_0x153954);Bn(_0x4079f5['eventQueue_'],_0x2c26fc),_0x4079f5['server_']['merge'](_0x1f74c1['toString'](),_0x41fa18,(_0x420710,_0x4df6f2)=>{const _0x3d6d82=_0x420710==='ok';_0x3d6d82||U('update\x20at\x20'+_0x1f74c1+'\x20failed:\x20'+_0x420710);const _0x597f82=pe(_0x4079f5['serverSyncTree_'],_0x153954,!_0x3d6d82),_0x281983=_0x597f82['length']>0x0?st(_0x4079f5,_0x1f74c1):_0x1f74c1;V(_0x4079f5['eventQueue_'],_0x281983,_0x597f82),Ai(_0x4079f5,_0x379ef1,_0x420710,_0x4df6f2);}),x(_0x41fa18,_0x389c6c=>{const _0x1bfb3b=vs(_0x4079f5,A(_0x1f74c1,_0x389c6c));st(_0x4079f5,_0x1bfb3b);}),V(_0x4079f5['eventQueue_'],_0x1f74c1,[]);}}function wd(_0x4ef98e){ut(_0x4ef98e,'onDisconnectEvents');const _0x2d8bc9=jt(_0x4ef98e),_0x3d3a95=pn();Ei(_0x4ef98e['onDisconnect_'],w(),(_0x34e0bb,_0x4f8f85)=>{const _0x2315a9=Zo(_0x34e0bb,_0x4f8f85,_0x4ef98e['serverSyncTree_'],_0x2d8bc9);Mo(_0x3d3a95,_0x34e0bb,_0x2315a9);});let _0x3cd985=[];Ei(_0x3d3a95,w(),(_0xc9b25b,_0x29369a)=>{_0x3cd985=_0x3cd985['concat']($t(_0x4ef98e['serverSyncTree_'],_0xc9b25b,_0x29369a));const _0x5b0654=vs(_0x4ef98e,_0xc9b25b);st(_0x4ef98e,_0x5b0654);}),_0x4ef98e['onDisconnect_']=pn(),V(_0x4ef98e['eventQueue_'],w(),_0x3cd985);}function Cd(_0x185ee3,_0x29af44,_0x5a61f5){let _0x747e2c;y(_0x29af44['_path'])==='.info'?_0x747e2c=bi(_0x185ee3['infoSyncTree_'],_0x29af44,_0x5a61f5):_0x747e2c=bi(_0x185ee3['serverSyncTree_'],_0x29af44,_0x5a61f5),ia(_0x185ee3['eventQueue_'],_0x29af44['_path'],_0x747e2c);}function Td(_0x7061fb,_0x336f34,_0x12be67){let _0x8f1426;y(_0x336f34['_path'])==='.info'?_0x8f1426=wn(_0x7061fb['infoSyncTree_'],_0x336f34,_0x12be67):_0x8f1426=wn(_0x7061fb['serverSyncTree_'],_0x336f34,_0x12be67),ia(_0x7061fb['eventQueue_'],_0x336f34['_path'],_0x8f1426);}function aa(_0x1a3e44){_0x1a3e44['persistentConnection_']&&_0x1a3e44['persistentConnection_']['interrupt'](ra);}function Sd(_0x3cf0d4){_0x3cf0d4['persistentConnection_']&&_0x3cf0d4['persistentConnection_']['resume'](ra);}function ut(_0x263548,..._0x591291){let _0x3f47d6='';_0x263548['persistentConnection_']&&(_0x3f47d6=_0x263548['persistentConnection_']['id']+':'),L(_0x3f47d6,..._0x591291);}function Ai(_0x8a8f80,_0x1d38d0,_0x63d422,_0x4c605d){_0x1d38d0&&lt(()=>{if(_0x63d422==='ok')_0x1d38d0(null);else{const _0x2e3475=(_0x63d422||'error')['toUpperCase']();let _0x3b5deb=_0x2e3475;_0x4c605d&&(_0x3b5deb+=':\x20'+_0x4c605d);const _0x448835=new Error(_0x3b5deb);_0x448835['code']=_0x2e3475,_0x1d38d0(_0x448835);}});}function bd(_0x33d2ee,_0x46613c,_0x2af72f,_0x96a3a5,_0x3e439c,_0x447206){ut(_0x33d2ee,'transaction\x20on\x20'+_0x46613c);const _0xbcbd99={'path':_0x46613c,'update':_0x2af72f,'onComplete':_0x96a3a5,'status':null,'order':to(),'applyLocally':_0x447206,'retryCount':0x0,'unwatcher':_0x3e439c,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3ec31f=ys(_0x33d2ee,_0x46613c,void 0x0);_0xbcbd99['currentInputSnapshot']=_0x3ec31f;const _0x25ee83=_0xbcbd99['update'](_0x3ec31f['val']());if(_0x25ee83===void 0x0)_0xbcbd99['unwatcher'](),_0xbcbd99['currentOutputSnapshotRaw']=null,_0xbcbd99['currentOutputSnapshotResolved']=null,_0xbcbd99['onComplete']&&_0xbcbd99['onComplete'](null,!0x1,_0xbcbd99['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x25ee83,_0xbcbd99['path']),_0xbcbd99['status']=0x0;const _0x474375=Un(_0x33d2ee['transactionQueueTree_'],_0x46613c),_0x1eca55=Ge(_0x474375)||[];_0x1eca55['push'](_0xbcbd99),fs(_0x474375,_0x1eca55);let _0x20dcef;typeof _0x25ee83=='object'&&_0x25ee83!==null&&Y(_0x25ee83,'.priority')?(_0x20dcef=Oe(_0x25ee83,'.priority'),f(Cn(_0x20dcef),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x20dcef=(xn(_0x33d2ee['serverSyncTree_'],_0x46613c)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5033db=jt(_0x33d2ee),_0x1a55ef=N(_0x25ee83,_0x20dcef),_0x2bcd3b=hs(_0x1a55ef,_0x3ec31f,_0x5033db);_0xbcbd99['currentOutputSnapshotRaw']=_0x1a55ef,_0xbcbd99['currentOutputSnapshotResolved']=_0x2bcd3b,_0xbcbd99['currentWriteId']=Vn(_0x33d2ee);const _0x476f63=ss(_0x33d2ee['serverSyncTree_'],_0x46613c,_0x2bcd3b,_0xbcbd99['currentWriteId'],_0xbcbd99['applyLocally']);V(_0x33d2ee['eventQueue_'],_0x46613c,_0x476f63),Hn(_0x33d2ee,_0x33d2ee['transactionQueueTree_']);}}function ys(_0x36689f,_0x3e8363,_0x54e84f){return xn(_0x36689f['serverSyncTree_'],_0x3e8363,_0x54e84f)||g['EMPTY_NODE'];}function Hn(_0x3c0560,_0x19911d=_0x3c0560['transactionQueueTree_']){if(_0x19911d||$n(_0x3c0560,_0x19911d),Ge(_0x19911d)){const _0x5575c6=la(_0x3c0560,_0x19911d);f(_0x5575c6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5575c6['every'](_0x168051=>_0x168051['status']===0x0)&&Rd(_0x3c0560,Gt(_0x19911d),_0x5575c6);}else ea(_0x19911d)&&Wn(_0x19911d,_0x6fb679=>{Hn(_0x3c0560,_0x6fb679);});}function Rd(_0x41ec0c,_0xe9cb58,_0x409561){const _0x3fa074=_0x409561['map'](_0x42383f=>_0x42383f['currentWriteId']),_0x56859b=ys(_0x41ec0c,_0xe9cb58,_0x3fa074);let _0x1f763f=_0x56859b;const _0x51f134=_0x56859b['hash']();for(let _0x2c8a6c=0x0;_0x2c8a6c<_0x409561['length'];_0x2c8a6c++){const _0x31f101=_0x409561[_0x2c8a6c];f(_0x31f101['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x31f101['status']=0x1,_0x31f101['retryCount']++;const _0x4ed3f0=F(_0xe9cb58,_0x31f101['path']);_0x1f763f=_0x1f763f['updateChild'](_0x4ed3f0,_0x31f101['currentOutputSnapshotRaw']);}const _0xfa26d8=_0x1f763f['val'](!0x0),_0x268f23=_0xe9cb58;_0x41ec0c['server_']['put'](_0x268f23['toString'](),_0xfa26d8,_0x128f64=>{ut(_0x41ec0c,'transaction\x20put\x20response',{'path':_0x268f23['toString'](),'status':_0x128f64});let _0x43769c=[];if(_0x128f64==='ok'){const _0x5f0b19=[];for(let _0x58b5a1=0x0;_0x58b5a1<_0x409561['length'];_0x58b5a1++)_0x409561[_0x58b5a1]['status']=0x2,_0x43769c=_0x43769c['concat'](pe(_0x41ec0c['serverSyncTree_'],_0x409561[_0x58b5a1]['currentWriteId'])),_0x409561[_0x58b5a1]['onComplete']&&_0x5f0b19['push'](()=>_0x409561[_0x58b5a1]['onComplete'](null,!0x0,_0x409561[_0x58b5a1]['currentOutputSnapshotResolved'])),_0x409561[_0x58b5a1]['unwatcher']();$n(_0x41ec0c,Un(_0x41ec0c['transactionQueueTree_'],_0xe9cb58)),Hn(_0x41ec0c,_0x41ec0c['transactionQueueTree_']),V(_0x41ec0c['eventQueue_'],_0xe9cb58,_0x43769c);for(let _0x45ca48=0x0;_0x45ca48<_0x5f0b19['length'];_0x45ca48++)lt(_0x5f0b19[_0x45ca48]);}else{if(_0x128f64==='datastale'){for(let _0x34f732=0x0;_0x34f732<_0x409561['length'];_0x34f732++)_0x409561[_0x34f732]['status']===0x3?_0x409561[_0x34f732]['status']=0x4:_0x409561[_0x34f732]['status']=0x0;}else{U('transaction\x20at\x20'+_0x268f23['toString']()+'\x20failed:\x20'+_0x128f64);for(let _0x5044dd=0x0;_0x5044dd<_0x409561['length'];_0x5044dd++)_0x409561[_0x5044dd]['status']=0x4,_0x409561[_0x5044dd]['abortReason']=_0x128f64;}st(_0x41ec0c,_0xe9cb58);}},_0x51f134);}function st(_0x1ce66,_0x4d4091){const _0x37aa6c=ca(_0x1ce66,_0x4d4091),_0x335509=Gt(_0x37aa6c),_0x6c2ea6=la(_0x1ce66,_0x37aa6c);return Ad(_0x1ce66,_0x6c2ea6,_0x335509),_0x335509;}function Ad(_0x54692c,_0x25c86a,_0x2a20d1){if(_0x25c86a['length']===0x0)return;const _0x446d66=[];let _0x40033d=[];const _0x4bf763=_0x25c86a['filter'](_0x3776ad=>_0x3776ad['status']===0x0)['map'](_0x200375=>_0x200375['currentWriteId']);for(let _0xff350d=0x0;_0xff350d<_0x25c86a['length'];_0xff350d++){const _0x3c34b2=_0x25c86a[_0xff350d],_0x1340c2=F(_0x2a20d1,_0x3c34b2['path']);let _0x20dc07=!0x1,_0x1e2659;if(f(_0x1340c2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3c34b2['status']===0x4)_0x20dc07=!0x0,_0x1e2659=_0x3c34b2['abortReason'],_0x40033d=_0x40033d['concat'](pe(_0x54692c['serverSyncTree_'],_0x3c34b2['currentWriteId'],!0x0));else{if(_0x3c34b2['status']===0x0){if(_0x3c34b2['retryCount']>=_d)_0x20dc07=!0x0,_0x1e2659='maxretry',_0x40033d=_0x40033d['concat'](pe(_0x54692c['serverSyncTree_'],_0x3c34b2['currentWriteId'],!0x0));else{const _0x4f79f2=ys(_0x54692c,_0x3c34b2['path'],_0x4bf763);_0x3c34b2['currentInputSnapshot']=_0x4f79f2;const _0x267aa2=_0x25c86a[_0xff350d]['update'](_0x4f79f2['val']());if(_0x267aa2!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x267aa2,_0x3c34b2['path']);let _0x1362d5=N(_0x267aa2);typeof _0x267aa2=='object'&&_0x267aa2!=null&&Y(_0x267aa2,'.priority')||(_0x1362d5=_0x1362d5['updatePriority'](_0x4f79f2['getPriority']()));const _0x377ef1=_0x3c34b2['currentWriteId'],_0x5b8dbe=jt(_0x54692c),_0x977d66=hs(_0x1362d5,_0x4f79f2,_0x5b8dbe);_0x3c34b2['currentOutputSnapshotRaw']=_0x1362d5,_0x3c34b2['currentOutputSnapshotResolved']=_0x977d66,_0x3c34b2['currentWriteId']=Vn(_0x54692c),_0x4bf763['splice'](_0x4bf763['indexOf'](_0x377ef1),0x1),_0x40033d=_0x40033d['concat'](ss(_0x54692c['serverSyncTree_'],_0x3c34b2['path'],_0x977d66,_0x3c34b2['currentWriteId'],_0x3c34b2['applyLocally'])),_0x40033d=_0x40033d['concat'](pe(_0x54692c['serverSyncTree_'],_0x377ef1,!0x0));}else _0x20dc07=!0x0,_0x1e2659='nodata',_0x40033d=_0x40033d['concat'](pe(_0x54692c['serverSyncTree_'],_0x3c34b2['currentWriteId'],!0x0));}}}V(_0x54692c['eventQueue_'],_0x2a20d1,_0x40033d),_0x40033d=[],_0x20dc07&&(_0x25c86a[_0xff350d]['status']=0x2,function(_0x465925){setTimeout(_0x465925,Math['floor'](0x0));}(_0x25c86a[_0xff350d]['unwatcher']),_0x25c86a[_0xff350d]['onComplete']&&(_0x1e2659==='nodata'?_0x446d66['push'](()=>_0x25c86a[_0xff350d]['onComplete'](null,!0x1,_0x25c86a[_0xff350d]['currentInputSnapshot'])):_0x446d66['push'](()=>_0x25c86a[_0xff350d]['onComplete'](new Error(_0x1e2659),!0x1,null))));}$n(_0x54692c,_0x54692c['transactionQueueTree_']);for(let _0x4632fa=0x0;_0x4632fa<_0x446d66['length'];_0x4632fa++)lt(_0x446d66[_0x4632fa]);Hn(_0x54692c,_0x54692c['transactionQueueTree_']);}function ca(_0xba489e,_0x280f9a){let _0x1386c2,_0x3acfed=_0xba489e['transactionQueueTree_'];for(_0x1386c2=y(_0x280f9a);_0x1386c2!==null&&Ge(_0x3acfed)===void 0x0;)_0x3acfed=Un(_0x3acfed,_0x1386c2),_0x280f9a=b(_0x280f9a),_0x1386c2=y(_0x280f9a);return _0x3acfed;}function la(_0x545cf7,_0x211a00){const _0x54939d=[];return ha(_0x545cf7,_0x211a00,_0x54939d),_0x54939d['sort']((_0x4cc89c,_0x331bf4)=>_0x4cc89c['order']-_0x331bf4['order']),_0x54939d;}function ha(_0x3ac0e7,_0x167dbc,_0x883c9){const _0x4a3c44=Ge(_0x167dbc);if(_0x4a3c44){for(let _0x45c004=0x0;_0x45c004<_0x4a3c44['length'];_0x45c004++)_0x883c9['push'](_0x4a3c44[_0x45c004]);}Wn(_0x167dbc,_0x549f7d=>{ha(_0x3ac0e7,_0x549f7d,_0x883c9);});}function $n(_0x27fcb6,_0x356101){const _0x57f3e3=Ge(_0x356101);if(_0x57f3e3){let _0x529708=0x0;for(let _0x526352=0x0;_0x526352<_0x57f3e3['length'];_0x526352++)_0x57f3e3[_0x526352]['status']!==0x2&&(_0x57f3e3[_0x529708]=_0x57f3e3[_0x526352],_0x529708++);_0x57f3e3['length']=_0x529708,fs(_0x356101,_0x57f3e3['length']>0x0?_0x57f3e3:void 0x0);}Wn(_0x356101,_0x160f62=>{$n(_0x27fcb6,_0x160f62);});}function vs(_0x860866,_0x16096d){const _0x190309=Gt(ca(_0x860866,_0x16096d)),_0x5e5ed1=Un(_0x860866['transactionQueueTree_'],_0x16096d);return sd(_0x5e5ed1,_0x58d3b6=>{ai(_0x860866,_0x58d3b6);}),ai(_0x860866,_0x5e5ed1),ta(_0x5e5ed1,_0x3208da=>{ai(_0x860866,_0x3208da);}),_0x190309;}function ai(_0x22da13,_0x4471d2){const _0x29b106=Ge(_0x4471d2);if(_0x29b106){const _0x5357e3=[];let _0x3ccd2b=[],_0x6edf86=-0x1;for(let _0x1860ad=0x0;_0x1860ad<_0x29b106['length'];_0x1860ad++)_0x29b106[_0x1860ad]['status']===0x3||(_0x29b106[_0x1860ad]['status']===0x1?(f(_0x6edf86===_0x1860ad-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x6edf86=_0x1860ad,_0x29b106[_0x1860ad]['status']=0x3,_0x29b106[_0x1860ad]['abortReason']='set'):(f(_0x29b106[_0x1860ad]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x29b106[_0x1860ad]['unwatcher'](),_0x3ccd2b=_0x3ccd2b['concat'](pe(_0x22da13['serverSyncTree_'],_0x29b106[_0x1860ad]['currentWriteId'],!0x0)),_0x29b106[_0x1860ad]['onComplete']&&_0x5357e3['push'](_0x29b106[_0x1860ad]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x6edf86===-0x1?fs(_0x4471d2,void 0x0):_0x29b106['length']=_0x6edf86+0x1,V(_0x22da13['eventQueue_'],Gt(_0x4471d2),_0x3ccd2b);for(let _0x43ed9a=0x0;_0x43ed9a<_0x5357e3['length'];_0x43ed9a++)lt(_0x5357e3[_0x43ed9a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x262153){let _0x1b926e='';const _0x31e4dd=_0x262153['split']('/');for(let _0x1105e7=0x0;_0x1105e7<_0x31e4dd['length'];_0x1105e7++)if(_0x31e4dd[_0x1105e7]['length']>0x0){let _0x4dca26=_0x31e4dd[_0x1105e7];try{_0x4dca26=decodeURIComponent(_0x4dca26['replace'](/\+/g,'\x20'));}catch{}_0x1b926e+='/'+_0x4dca26;}return _0x1b926e;}function Nd(_0x414a7e){const _0x2e94d9={};_0x414a7e['charAt'](0x0)==='?'&&(_0x414a7e=_0x414a7e['substring'](0x1));for(const _0x45724a of _0x414a7e['split']('&')){if(_0x45724a['length']===0x0)continue;const _0xb90979=_0x45724a['split']('=');_0xb90979['length']===0x2?_0x2e94d9[decodeURIComponent(_0xb90979[0x0])]=decodeURIComponent(_0xb90979[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x45724a+'\x27\x20in\x20query\x20\x27'+_0x414a7e+'\x27');}return _0x2e94d9;}const gr=function(_0x408409,_0x404730){const _0x97e5ed=Pd(_0x408409),_0x5b38d9=_0x97e5ed['namespace'];_0x97e5ed['domain']==='firebase.com'&&oe(_0x97e5ed['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5b38d9||_0x5b38d9==='undefined')&&_0x97e5ed['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x97e5ed['secure']||Bl();const _0x376790=_0x97e5ed['scheme']==='ws'||_0x97e5ed['scheme']==='wss';return{'repoInfo':new _o(_0x97e5ed['host'],_0x97e5ed['secure'],_0x5b38d9,_0x376790,_0x404730,'',_0x5b38d9!==_0x97e5ed['subdomain']),'path':new C(_0x97e5ed['pathString'])};},Pd=function(_0x3fcfa5){let _0x59e0eb='',_0x16f061='',_0x10d202='',_0x2ac71b='',_0x4fdf37='',_0x55253f=!0x0,_0x437d8c='https',_0x378efa=0x1bb;if(typeof _0x3fcfa5=='string'){let _0x12baaa=_0x3fcfa5['indexOf']('//');_0x12baaa>=0x0&&(_0x437d8c=_0x3fcfa5['substring'](0x0,_0x12baaa-0x1),_0x3fcfa5=_0x3fcfa5['substring'](_0x12baaa+0x2));let _0x2a2c2a=_0x3fcfa5['indexOf']('/');_0x2a2c2a===-0x1&&(_0x2a2c2a=_0x3fcfa5['length']);let _0x182b0b=_0x3fcfa5['indexOf']('?');_0x182b0b===-0x1&&(_0x182b0b=_0x3fcfa5['length']),_0x59e0eb=_0x3fcfa5['substring'](0x0,Math['min'](_0x2a2c2a,_0x182b0b)),_0x2a2c2a<_0x182b0b&&(_0x2ac71b=kd(_0x3fcfa5['substring'](_0x2a2c2a,_0x182b0b)));const _0x28c567=Nd(_0x3fcfa5['substring'](Math['min'](_0x3fcfa5['length'],_0x182b0b)));_0x12baaa=_0x59e0eb['indexOf'](':'),_0x12baaa>=0x0?(_0x55253f=_0x437d8c==='https'||_0x437d8c==='wss',_0x378efa=parseInt(_0x59e0eb['substring'](_0x12baaa+0x1),0xa)):_0x12baaa=_0x59e0eb['length'];const _0x107943=_0x59e0eb['slice'](0x0,_0x12baaa);if(_0x107943['toLowerCase']()==='localhost')_0x16f061='localhost';else{if(_0x107943['split']('.')['length']<=0x2)_0x16f061=_0x107943;else{const _0x58b15c=_0x59e0eb['indexOf']('.');_0x10d202=_0x59e0eb['substring'](0x0,_0x58b15c)['toLowerCase'](),_0x16f061=_0x59e0eb['substring'](_0x58b15c+0x1),_0x4fdf37=_0x10d202;}}'ns'in _0x28c567&&(_0x4fdf37=_0x28c567['ns']);}return{'host':_0x59e0eb,'port':_0x378efa,'domain':_0x16f061,'subdomain':_0x10d202,'secure':_0x55253f,'scheme':_0x437d8c,'pathString':_0x2ac71b,'namespace':_0x4fdf37};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x1aee4e=0x0;const _0x3dc4d3=[];return function(_0x2cc1a9){const _0xa42f4e=_0x2cc1a9===_0x1aee4e;_0x1aee4e=_0x2cc1a9;let _0x32a37a;const _0x4f8876=new Array(0x8);for(_0x32a37a=0x7;_0x32a37a>=0x0;_0x32a37a--)_0x4f8876[_0x32a37a]=mr['charAt'](_0x2cc1a9%0x40),_0x2cc1a9=Math['floor'](_0x2cc1a9/0x40);f(_0x2cc1a9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2d41d5=_0x4f8876['join']('');if(_0xa42f4e){for(_0x32a37a=0xb;_0x32a37a>=0x0&&_0x3dc4d3[_0x32a37a]===0x3f;_0x32a37a--)_0x3dc4d3[_0x32a37a]=0x0;_0x3dc4d3[_0x32a37a]++;}else{for(_0x32a37a=0x0;_0x32a37a<0xc;_0x32a37a++)_0x3dc4d3[_0x32a37a]=Math['floor'](Math['random']()*0x40);}for(_0x32a37a=0x0;_0x32a37a<0xc;_0x32a37a++)_0x2d41d5+=mr['charAt'](_0x3dc4d3[_0x32a37a]);return f(_0x2d41d5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2d41d5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0xbce87e,_0x2f499c,_0x30c123,_0x3f8012){this['eventType']=_0xbce87e,this['eventRegistration']=_0x2f499c,this['snapshot']=_0x30c123,this['prevName']=_0x3f8012;}['getPath'](){const _0x4eaf79=this['snapshot']['ref'];return this['eventType']==='value'?_0x4eaf79['_path']:_0x4eaf79['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x30f881,_0x2eacb8,_0x297fa1){this['eventRegistration']=_0x30f881,this['error']=_0x2eacb8,this['path']=_0x297fa1;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x4e5fd2,_0x578c15){this['snapshotCallback']=_0x4e5fd2,this['cancelCallback']=_0x578c15;}['onValue'](_0x511413,_0xfd8287){this['snapshotCallback']['call'](null,_0x511413,_0xfd8287);}['onCancel'](_0x24bc29){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x24bc29);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2f7da4){return this['snapshotCallback']===_0x2f7da4['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2f7da4['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2f7da4['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x37c7d5,_0x25e2d7,_0x45dd76,_0x4880e3){this['_repo']=_0x37c7d5,this['_path']=_0x25e2d7,this['_queryParams']=_0x45dd76,this['_orderByCalled']=_0x4880e3;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x496e27=nr(this['_queryParams']),_0x4c7ede=Bi(_0x496e27);return _0x4c7ede==='{}'?'default':_0x4c7ede;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x2eaba6){if(_0x2eaba6=k(_0x2eaba6),!(_0x2eaba6 instanceof be))return!0x1;const _0x589383=this['_repo']===_0x2eaba6['_repo'],_0x11a7b6=qi(this['_path'],_0x2eaba6['_path']),_0x598f5a=this['_queryIdentifier']===_0x2eaba6['_queryIdentifier'];return _0x589383&&_0x11a7b6&&_0x598f5a;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0xed9958,_0x2f3826){if(_0xed9958['_orderByCalled']===!0x0)throw new Error(_0x2f3826+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x2a5116){let _0x1894cf=null,_0x3d7d3b=null;if(_0x2a5116['hasStart']()&&(_0x1894cf=_0x2a5116['getIndexStartValue']()),_0x2a5116['hasEnd']()&&(_0x3d7d3b=_0x2a5116['getIndexEndValue']()),_0x2a5116['getIndex']()===ye){const _0x27ef03='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4a8eb7='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2a5116['hasStart']()){if(_0x2a5116['getIndexStartName']()!==xe)throw new Error(_0x27ef03);if(typeof _0x1894cf!='string')throw new Error(_0x4a8eb7);}if(_0x2a5116['hasEnd']()){if(_0x2a5116['getIndexEndName']()!==Ie)throw new Error(_0x27ef03);if(typeof _0x3d7d3b!='string')throw new Error(_0x4a8eb7);}}else{if(_0x2a5116['getIndex']()===R){if(_0x1894cf!=null&&!Cn(_0x1894cf)||_0x3d7d3b!=null&&!Cn(_0x3d7d3b))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2a5116['getIndex']()instanceof Ki||_0x2a5116['getIndex']()===Po,'unknown\x20index\x20type.'),_0x1894cf!=null&&typeof _0x1894cf=='object'||_0x3d7d3b!=null&&typeof _0x3d7d3b=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0xdb1394){if(_0xdb1394['hasStart']()&&_0xdb1394['hasEnd']()&&_0xdb1394['hasLimit']()&&!_0xdb1394['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x365ea4,_0x29e9ca){super(_0x365ea4,_0x29e9ca,new Qi(),!0x1);}get['parent'](){const _0x5595bb=To(this['_path']);return _0x5595bb===null?null:new Z(this['_repo'],_0x5595bb);}get['root'](){let _0x2fe056=this;for(;_0x2fe056['parent']!==null;)_0x2fe056=_0x2fe056['parent'];return _0x2fe056;}}class rt{constructor(_0x41a0bd,_0x256fdc,_0x294222){this['_node']=_0x41a0bd,this['ref']=_0x256fdc,this['_index']=_0x294222;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x565e84){const _0x1346df=new C(_0x565e84),_0x4bace9=Lt(this['ref'],_0x565e84);return new rt(this['_node']['getChild'](_0x1346df),_0x4bace9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x11e7e2){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x34534f,_0x399d55)=>_0x11e7e2(new rt(_0x399d55,Lt(this['ref'],_0x34534f),R)));}['hasChild'](_0x85e40){const _0x4f3da6=new C(_0x85e40);return!this['_node']['getChild'](_0x4f3da6)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x4a2f6c,_0x2f5e71){return _0x4a2f6c=k(_0x4a2f6c),_0x4a2f6c['_checkNotDeleted']('ref'),_0x2f5e71!==void 0x0?Lt(_0x4a2f6c['_root'],_0x2f5e71):_0x4a2f6c['_root'];}function Lt(_0x56d6fd,_0xc41cbd){return _0x56d6fd=k(_0x56d6fd),y(_0x56d6fd['_path'])===null?ud('child','path',_0xc41cbd):_s('child','path',_0xc41cbd),new Z(_0x56d6fd['_repo'],A(_0x56d6fd['_path'],_0xc41cbd));}function d_(_0x5d32ea,_0x5b840e){_0x5d32ea=k(_0x5d32ea),gs('push',_0x5d32ea['_path']),qt('push',_0x5b840e,_0x5d32ea['_path'],!0x0);const _0x1641b9=oa(_0x5d32ea['_repo']),_0x2117a4=Od(_0x1641b9),_0x2c359c=Lt(_0x5d32ea,_0x2117a4),_0x2d46ad=Lt(_0x5d32ea,_0x2117a4);let _0x2349c5;return _0x5b840e!=null?_0x2349c5=Ld(_0x2d46ad,_0x5b840e)['then'](()=>_0x2d46ad):_0x2349c5=Promise['resolve'](_0x2d46ad),_0x2c359c['then']=_0x2349c5['then']['bind'](_0x2349c5),_0x2c359c['catch']=_0x2349c5['then']['bind'](_0x2349c5,void 0x0),_0x2c359c;}function Ld(_0x435472,_0x583c4c){_0x435472=k(_0x435472),gs('set',_0x435472['_path']),qt('set',_0x583c4c,_0x435472['_path'],!0x1);const _0x22cb15=new Ve();return Ed(_0x435472['_repo'],_0x435472['_path'],_0x583c4c,null,_0x22cb15['wrapCallback'](()=>{})),_0x22cb15['promise'];}function f_(_0x11f142,_0x2183dd){hd('update',_0x2183dd,_0x11f142['_path']);const _0x1749b0=new Ve();return Id(_0x11f142['_repo'],_0x11f142['_path'],_0x2183dd,_0x1749b0['wrapCallback'](()=>{})),_0x1749b0['promise'];}function p_(_0x296ba5){_0x296ba5=k(_0x296ba5);const _0x7dea3f=new ua(()=>{}),_0x3c150a=new qn(_0x7dea3f);return vd(_0x296ba5['_repo'],_0x296ba5,_0x3c150a)['then'](_0x35cd49=>new rt(_0x35cd49,new Z(_0x296ba5['_repo'],_0x296ba5['_path']),_0x296ba5['_queryParams']['getIndex']()));}class qn{constructor(_0x32e9aa){this['callbackContext']=_0x32e9aa;}['respondsTo'](_0x19a9bb){return _0x19a9bb==='value';}['createEvent'](_0x539c3f,_0x1666e6){const _0x32d39d=_0x1666e6['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x539c3f['snapshotNode'],new Z(_0x1666e6['_repo'],_0x1666e6['_path']),_0x32d39d));}['getEventRunner'](_0x545e3f){return _0x545e3f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x545e3f['error']):()=>this['callbackContext']['onValue'](_0x545e3f['snapshot'],null);}['createCancelEvent'](_0x486107,_0x50bb13){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x486107,_0x50bb13):null;}['matches'](_0x4e94d0){return _0x4e94d0 instanceof qn?!_0x4e94d0['callbackContext']||!this['callbackContext']?!0x0:_0x4e94d0['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x7c5493,_0x44e596,_0x8d0b5b,_0x23446f,_0x530108){const _0x51ff0f=new ua(_0x8d0b5b,void 0x0),_0x10b0a5=new qn(_0x51ff0f);return Cd(_0x7c5493['_repo'],_0x7c5493,_0x10b0a5),()=>Td(_0x7c5493['_repo'],_0x7c5493,_0x10b0a5);}function Fd(_0x710129,_0x520bdb,_0xcb30d7,_0x4e911f){return xd(_0x710129,'value',_0x520bdb);}class dt{}class pa extends dt{constructor(_0x10b46d,_0xe701a3){super(),this['_value']=_0x10b46d,this['_key']=_0xe701a3,this['type']='endAt';}['_apply'](_0x222326){qt('endAt',this['_value'],_0x222326['_path'],!0x0);const _0x357b42=Kh(_0x222326['_queryParams'],this['_value'],this['_key']);if(fa(_0x357b42),Gn(_0x357b42),_0x222326['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x222326['_repo'],_0x222326['_path'],_0x357b42,_0x222326['_orderByCalled']);}}function __(_0x3f53c4,_0x249873){return new pa(_0x3f53c4,_0x249873);}class _a extends dt{constructor(_0x584a3c,_0x31bb0c){super(),this['_value']=_0x584a3c,this['_key']=_0x31bb0c,this['type']='startAt';}['_apply'](_0x2cc8f5){qt('startAt',this['_value'],_0x2cc8f5['_path'],!0x0);const _0x5817d2=jh(_0x2cc8f5['_queryParams'],this['_value'],this['_key']);if(fa(_0x5817d2),Gn(_0x5817d2),_0x2cc8f5['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x2cc8f5['_repo'],_0x2cc8f5['_path'],_0x5817d2,_0x2cc8f5['_orderByCalled']);}}function g_(_0x4f99df=null,_0x4ad6ab){return new _a(_0x4f99df,_0x4ad6ab);}class Ud extends dt{constructor(_0x418f41){super(),this['_limit']=_0x418f41,this['type']='limitToFirst';}['_apply'](_0x54c9c8){if(_0x54c9c8['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x54c9c8['_repo'],_0x54c9c8['_path'],zh(_0x54c9c8['_queryParams'],this['_limit']),_0x54c9c8['_orderByCalled']);}}function m_(_0x3cbf7b){if(Math['floor'](_0x3cbf7b)!==_0x3cbf7b||_0x3cbf7b<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x3cbf7b);}class Wd extends dt{constructor(_0x2ee44c){super(),this['_path']=_0x2ee44c,this['type']='orderByChild';}['_apply'](_0x1829cd){da(_0x1829cd,'orderByChild');const _0x250c83=new C(this['_path']);if(v(_0x250c83))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1aa1c9=new Ki(_0x250c83),_0xb6f97a=Do(_0x1829cd['_queryParams'],_0x1aa1c9);return Gn(_0xb6f97a),new be(_0x1829cd['_repo'],_0x1829cd['_path'],_0xb6f97a,!0x0);}}function y_(_0x4b5885){if(_0x4b5885==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4b5885==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4b5885==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x4b5885),new Wd(_0x4b5885);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3a874a){da(_0x3a874a,'orderByKey');const _0x21de56=Do(_0x3a874a['_queryParams'],ye);return Gn(_0x21de56),new be(_0x3a874a['_repo'],_0x3a874a['_path'],_0x21de56,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x347e53,_0xe3b33b){super(),this['_value']=_0x347e53,this['_key']=_0xe3b33b,this['type']='equalTo';}['_apply'](_0x5edc7b){if(qt('equalTo',this['_value'],_0x5edc7b['_path'],!0x1),_0x5edc7b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x5edc7b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x5edc7b));}}function E_(_0x1f2f77,_0xcac860){return new Vd(_0x1f2f77,_0xcac860);}function I_(_0x45372c,..._0x29ff25){let _0x49518b=k(_0x45372c);for(const _0x364ac8 of _0x29ff25)_0x49518b=_0x364ac8['_apply'](_0x49518b);return _0x49518b;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x5c7efb,_0xefbd61,_0x9e6021,_0x27993a){const _0x5d4bb6=_0xefbd61['lastIndexOf'](':'),_0x4302bd=_0xefbd61['substring'](0x0,_0x5d4bb6),_0x4b0ea8=Wt(_0x4302bd);_0x5c7efb['repoInfo_']=new _o(_0xefbd61,_0x4b0ea8,_0x5c7efb['repoInfo_']['namespace'],_0x5c7efb['repoInfo_']['webSocketOnly'],_0x5c7efb['repoInfo_']['nodeAdmin'],_0x5c7efb['repoInfo_']['persistenceKey'],_0x5c7efb['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x9e6021),_0x27993a&&(_0x5c7efb['authTokenProvider_']=_0x27993a);}function qd(_0x45fcec,_0x24ba90,_0x2e876d,_0x6e73df,_0x542a0d){let _0x724919=_0x6e73df||_0x45fcec['options']['databaseURL'];_0x724919===void 0x0&&(_0x45fcec['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x45fcec['options']['projectId']),_0x724919=_0x45fcec['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x435502=gr(_0x724919,_0x542a0d),_0x432151=_0x435502['repoInfo'],_0x2397c6;typeof process<'u'&&Us&&(_0x2397c6=Us[Hd]),_0x2397c6?(_0x724919='http://'+_0x2397c6+'?ns='+_0x432151['namespace'],_0x435502=gr(_0x724919,_0x542a0d),_0x432151=_0x435502['repoInfo']):_0x435502['repoInfo']['secure'];const _0x403be3=new Jl(_0x45fcec['name'],_0x45fcec['options'],_0x24ba90);dd('Invalid\x20Firebase\x20Database\x20URL',_0x435502),v(_0x435502['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x303a19=jd(_0x432151,_0x45fcec,_0x403be3,new Ql(_0x45fcec,_0x2e876d));return new Kd(_0x303a19,_0x45fcec);}function zd(_0x103c31,_0x3c3988){const _0x2f68ab=ki[_0x3c3988];(!_0x2f68ab||_0x2f68ab[_0x103c31['key']]!==_0x103c31)&&oe('Database\x20'+_0x3c3988+'('+_0x103c31['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x103c31),delete _0x2f68ab[_0x103c31['key']];}function jd(_0x3c3a28,_0x52ede6,_0x2356c6,_0x422688){let _0x255a24=ki[_0x52ede6['name']];_0x255a24||(_0x255a24={},ki[_0x52ede6['name']]=_0x255a24);let _0x215236=_0x255a24[_0x3c3a28['toURLString']()];return _0x215236&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x215236=new gd(_0x3c3a28,$d,_0x2356c6,_0x422688),_0x255a24[_0x3c3a28['toURLString']()]=_0x215236,_0x215236;}class Kd{constructor(_0x408f2d,_0x1d1ad8){this['_repoInternal']=_0x408f2d,this['app']=_0x1d1ad8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3a96cf){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x3a96cf+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x423e3a=Qr(),_0x1b7785){const _0x53ce34=Ui(_0x423e3a,'database')['getImmediate']({'identifier':_0x1b7785});if(!_0x53ce34['_instanceStarted']){const _0x1cb566=ac('database');_0x1cb566&&Yd(_0x53ce34,..._0x1cb566);}return _0x53ce34;}function Yd(_0x4c5208,_0x3a1e03,_0x3cdb30,_0x258f62={}){_0x4c5208=k(_0x4c5208),_0x4c5208['_checkNotDeleted']('useEmulator');const _0x184644=_0x3a1e03+':'+_0x3cdb30,_0x4bdb65=_0x4c5208['_repoInternal'];if(_0x4c5208['_instanceStarted']){if(_0x184644===_0x4c5208['_repoInternal']['repoInfo_']['host']&&De(_0x258f62,_0x4bdb65['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3b9f41;if(_0x4bdb65['repoInfo_']['nodeAdmin'])_0x258f62['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3b9f41=new tn(tn['OWNER']);else{if(_0x258f62['mockUserToken']){const _0x19f4de=typeof _0x258f62['mockUserToken']=='string'?_0x258f62['mockUserToken']:cc(_0x258f62['mockUserToken'],_0x4c5208['app']['options']['projectId']);_0x3b9f41=new tn(_0x19f4de);}}Wt(_0x3a1e03)&&jr(_0x3a1e03),Gd(_0x4bdb65,_0x184644,_0x258f62,_0x3b9f41);}function C_(_0x493b6e){_0x493b6e=k(_0x493b6e),_0x493b6e['_checkNotDeleted']('goOffline'),aa(_0x493b6e['_repo']);}function T_(_0x402ea2){_0x402ea2=k(_0x402ea2),_0x402ea2['_checkNotDeleted']('goOnline'),Sd(_0x402ea2['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x5abde0){Ll(ct),et(new Me('database',(_0x2078db,{instanceIdentifier:_0x4362ad})=>{const _0x1ac99c=_0x2078db['getProvider']('app')['getImmediate'](),_0x4bb867=_0x2078db['getProvider']('auth-internal'),_0x180f44=_0x2078db['getProvider']('app-check-internal');return qd(_0x1ac99c,_0x4bb867,_0x180f44,_0x4362ad);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x5abde0),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1e64a5,_0x30789b){this['committed']=_0x1e64a5,this['snapshot']=_0x30789b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x35b14d,_0x17aaa8,_0x59d3d6){if(_0x35b14d=k(_0x35b14d),gs('Reference.transaction',_0x35b14d['_path']),_0x35b14d['key']==='.length'||_0x35b14d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x35b14d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x12dfbf=!0x0,_0xbf6001=new Ve(),_0x103a34=(_0x51665a,_0x2a701b,_0xba6f21)=>{let _0x4c887f=null;_0x51665a?_0xbf6001['reject'](_0x51665a):(_0x4c887f=new rt(_0xba6f21,new Z(_0x35b14d['_repo'],_0x35b14d['_path']),R),_0xbf6001['resolve'](new Xd(_0x2a701b,_0x4c887f)));},_0x171ad1=Fd(_0x35b14d,()=>{});return bd(_0x35b14d['_repo'],_0x35b14d['_path'],_0x17aaa8,_0x103a34,_0x171ad1,_0x12dfbf),_0xbf6001['promise'];}ie['prototype']['simpleListen']=function(_0x2c5af6,_0x4a656c){this['sendRequest']('q',{'p':_0x2c5af6},_0x4a656c);},ie['prototype']['echo']=function(_0x4a9943,_0x5559ff){this['sendRequest']('echo',{'d':_0x4a9943},_0x5559ff);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x27c32b,..._0x463a05){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x27c32b,..._0x463a05);}function nn(_0x2e40ab,..._0x1f63a8){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2e40ab,..._0x1f63a8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3c51b0,..._0x70fc1d){throw Es(_0x3c51b0,..._0x70fc1d);}function J(_0x3f5247,..._0x23049a){return Es(_0x3f5247,..._0x23049a);}function ya(_0x18035b,_0x4b2045,_0x14ad52){const _0x3c1f9f={...Zd(),[_0x4b2045]:_0x14ad52};return new Ut('auth','Firebase',_0x3c1f9f)['create'](_0x4b2045,{'appName':_0x18035b['name']});}function se(_0x3db146){return ya(_0x3db146,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x50a455,..._0x5cd9ad){if(typeof _0x50a455!='string'){const _0x5b3108=_0x5cd9ad[0x0],_0x3344bf=[..._0x5cd9ad['slice'](0x1)];return _0x3344bf[0x0]&&(_0x3344bf[0x0]['appName']=_0x50a455['name']),_0x50a455['_errorFactory']['create'](_0x5b3108,..._0x3344bf);}return ma['create'](_0x50a455,..._0x5cd9ad);}function m(_0x28dd4d,_0x1f29c3,..._0x4b5fa6){if(!_0x28dd4d)throw Es(_0x1f29c3,..._0x4b5fa6);}function te(_0x40de3b){const _0x41b953='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x40de3b;throw nn(_0x41b953),new Error(_0x41b953);}function ae(_0x4621ac,_0x39889c){_0x4621ac||te(_0x39889c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x42e728;return typeof self<'u'&&((_0x42e728=self['location'])==null?void 0x0:_0x42e728['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x36d28c;return typeof self<'u'&&((_0x36d28c=self['location'])==null?void 0x0:_0x36d28c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x3c2215=navigator;return _0x3c2215['languages']&&_0x3c2215['languages'][0x0]||_0x3c2215['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x439513,_0x4f25a9){this['shortDelay']=_0x439513,this['longDelay']=_0x4f25a9,ae(_0x4f25a9>_0x439513,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x81702f,_0x203f03){ae(_0x81702f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x47d4ce}=_0x81702f['emulator'];return _0x203f03?''+_0x47d4ce+(_0x203f03['startsWith']('/')?_0x203f03['slice'](0x1):_0x203f03):_0x47d4ce;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5e83ce,_0x2e3def,_0x5e1c41){this['fetchImpl']=_0x5e83ce,_0x2e3def&&(this['headersImpl']=_0x2e3def),_0x5e1c41&&(this['responseImpl']=_0x5e1c41);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0xbe9d82,_0x152dc7){return _0xbe9d82['tenantId']&&!_0x152dc7['tenantId']?{..._0x152dc7,'tenantId':_0xbe9d82['tenantId']}:_0x152dc7;}async function Ae(_0x581f31,_0x5105d7,_0x5c759b,_0x1466ec,_0x1d94e9={}){return Ea(_0x581f31,_0x1d94e9,async()=>{let _0x26c88e={},_0x29be84={};_0x1466ec&&(_0x5105d7==='GET'?_0x29be84=_0x1466ec:_0x26c88e={'body':JSON['stringify'](_0x1466ec)});const _0x3f6823=at({..._0x29be84,'key':_0x581f31['config']['apiKey']})['slice'](0x1),_0x3f0869=await _0x581f31['_getAdditionalHeaders']();_0x3f0869['Content-Type']='application/json',_0x581f31['languageCode']&&(_0x3f0869['X-Firebase-Locale']=_0x581f31['languageCode']);const _0x464037={'method':_0x5105d7,'headers':_0x3f0869,..._0x26c88e};return lc()||(_0x464037['referrerPolicy']='strict-origin-when-cross-origin'),_0x581f31['emulatorConfig']&&Wt(_0x581f31['emulatorConfig']['host'])&&(_0x464037['credentials']='include'),va['fetch']()(await Ia(_0x581f31,_0x581f31['config']['apiHost'],_0x5c759b,_0x3f6823),_0x464037);});}async function Ea(_0x1bdf5b,_0x506344,_0x57ca87){_0x1bdf5b['_canInitEmulator']=!0x1;const _0x2b164c={...rf,..._0x506344};try{const _0x256557=new lf(_0x1bdf5b),_0x575d9a=await Promise['race']([_0x57ca87(),_0x256557['promise']]);_0x256557['clearNetworkTimeout']();const _0x1e5037=await _0x575d9a['json']();if('needConfirmation'in _0x1e5037)throw en(_0x1bdf5b,'account-exists-with-different-credential',_0x1e5037);if(_0x575d9a['ok']&&!('errorMessage'in _0x1e5037))return _0x1e5037;{const _0x10afeb=_0x575d9a['ok']?_0x1e5037['errorMessage']:_0x1e5037['error']['message'],[_0x7d5fd1,_0x38847b]=_0x10afeb['split']('\x20:\x20');if(_0x7d5fd1==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1bdf5b,'credential-already-in-use',_0x1e5037);if(_0x7d5fd1==='EMAIL_EXISTS')throw en(_0x1bdf5b,'email-already-in-use',_0x1e5037);if(_0x7d5fd1==='USER_DISABLED')throw en(_0x1bdf5b,'user-disabled',_0x1e5037);const _0x46a0e7=_0x2b164c[_0x7d5fd1]||_0x7d5fd1['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x38847b)throw ya(_0x1bdf5b,_0x46a0e7,_0x38847b);K(_0x1bdf5b,_0x46a0e7);}}catch(_0x3d4d17){if(_0x3d4d17 instanceof Se)throw _0x3d4d17;K(_0x1bdf5b,'network-request-failed',{'message':String(_0x3d4d17)});}}async function Yt(_0x258d10,_0x40962a,_0x101106,_0x5dd430,_0x37148d={}){const _0x34af03=await Ae(_0x258d10,_0x40962a,_0x101106,_0x5dd430,_0x37148d);return'mfaPendingCredential'in _0x34af03&&K(_0x258d10,'multi-factor-auth-required',{'_serverResponse':_0x34af03}),_0x34af03;}async function Ia(_0x2fcad9,_0xa931cc,_0x472e75,_0x2356a5){const _0xb90647=''+_0xa931cc+_0x472e75+'?'+_0x2356a5,_0x5a5dcd=_0x2fcad9,_0x38c63a=_0x5a5dcd['config']['emulator']?Is(_0x2fcad9['config'],_0xb90647):_0x2fcad9['config']['apiScheme']+'://'+_0xb90647;return of['includes'](_0x472e75)&&(await _0x5a5dcd['_persistenceManagerAvailable'],_0x5a5dcd['_getPersistenceType']()==='COOKIE')?_0x5a5dcd['_getPersistence']()['_getFinalTarget'](_0x38c63a)['toString']():_0x38c63a;}function cf(_0x35a4df){switch(_0x35a4df){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2c4bf6){this['auth']=_0x2c4bf6,this['timer']=null,this['promise']=new Promise((_0x26aa8d,_0x243616)=>{this['timer']=setTimeout(()=>_0x243616(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x2f9453,_0x2e0520,_0xc4435d){const _0x59f9a6={'appName':_0x2f9453['name']};_0xc4435d['email']&&(_0x59f9a6['email']=_0xc4435d['email']),_0xc4435d['phoneNumber']&&(_0x59f9a6['phoneNumber']=_0xc4435d['phoneNumber']);const _0x5a3154=J(_0x2f9453,_0x2e0520,_0x59f9a6);return _0x5a3154['customData']['_tokenResponse']=_0xc4435d,_0x5a3154;}function vr(_0x5da357){return _0x5da357!==void 0x0&&_0x5da357['enterprise']!==void 0x0;}class hf{constructor(_0x2db45a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2db45a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2db45a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2db45a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4017d0){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5eec46 of this['recaptchaEnforcementState'])if(_0x5eec46['provider']&&_0x5eec46['provider']===_0x4017d0)return cf(_0x5eec46['enforcementState']);return null;}['isProviderEnabled'](_0x243dd7){return this['getProviderEnforcementState'](_0x243dd7)==='ENFORCE'||this['getProviderEnforcementState'](_0x243dd7)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x393951,_0x1b9315){return Ae(_0x393951,'GET','/v2/recaptchaConfig',Re(_0x393951,_0x1b9315));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x4e48c8,_0x3b160f){return Ae(_0x4e48c8,'POST','/v1/accounts:delete',_0x3b160f);}async function Sn(_0x53bbff,_0x513ffa){return Ae(_0x53bbff,'POST','/v1/accounts:lookup',_0x513ffa);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x10d34a){if(_0x10d34a)try{const _0x3d0f67=new Date(Number(_0x10d34a));if(!isNaN(_0x3d0f67['getTime']()))return _0x3d0f67['toUTCString']();}catch{}}async function ff(_0x2d8e16,_0x4afa5b=!0x1){const _0xade6de=k(_0x2d8e16),_0x1c3753=await _0xade6de['getIdToken'](_0x4afa5b),_0xa1f7df=ws(_0x1c3753);m(_0xa1f7df&&_0xa1f7df['exp']&&_0xa1f7df['auth_time']&&_0xa1f7df['iat'],_0xade6de['auth'],'internal-error');const _0x401aae=typeof _0xa1f7df['firebase']=='object'?_0xa1f7df['firebase']:void 0x0,_0x230933=_0x401aae==null?void 0x0:_0x401aae['sign_in_provider'];return{'claims':_0xa1f7df,'token':_0x1c3753,'authTime':St(ci(_0xa1f7df['auth_time'])),'issuedAtTime':St(ci(_0xa1f7df['iat'])),'expirationTime':St(ci(_0xa1f7df['exp'])),'signInProvider':_0x230933||null,'signInSecondFactor':(_0x401aae==null?void 0x0:_0x401aae['sign_in_second_factor'])||null};}function ci(_0xcab310){return Number(_0xcab310)*0x3e8;}function ws(_0x41b10e){const [_0x1cd8b8,_0x43457b,_0x115502]=_0x41b10e['split']('.');if(_0x1cd8b8===void 0x0||_0x43457b===void 0x0||_0x115502===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x59611a=cn(_0x43457b);return _0x59611a?JSON['parse'](_0x59611a):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2c0a6c){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2c0a6c==null?void 0x0:_0x2c0a6c['toString']()),null;}}function Er(_0x3f621a){const _0x41cf26=ws(_0x3f621a);return m(_0x41cf26,'internal-error'),m(typeof _0x41cf26['exp']<'u','internal-error'),m(typeof _0x41cf26['iat']<'u','internal-error'),Number(_0x41cf26['exp'])-Number(_0x41cf26['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x552115,_0x5a8637,_0x5b906c=!0x1){if(_0x5b906c)return _0x5a8637;try{return await _0x5a8637;}catch(_0x366c9a){throw _0x366c9a instanceof Se&&pf(_0x366c9a)&&_0x552115['auth']['currentUser']===_0x552115&&await _0x552115['auth']['signOut'](),_0x366c9a;}}function pf({code:_0x4fc418}){return _0x4fc418==='auth/user-disabled'||_0x4fc418==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x4836ef){this['user']=_0x4836ef,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x194f05){if(_0x194f05){const _0x1fe6c6=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1fe6c6;}else{this['errorBackoff']=0x7530;const _0x5a4f41=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5a4f41);}}['schedule'](_0x3e8f50=!0x1){if(!this['isRunning'])return;const _0x56ee97=this['getInterval'](_0x3e8f50);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x56ee97);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1a1df0){(_0x1a1df0==null?void 0x0:_0x1a1df0['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x43f8fb,_0x3fd394){this['createdAt']=_0x43f8fb,this['lastLoginAt']=_0x3fd394,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x17f0c0){this['createdAt']=_0x17f0c0['createdAt'],this['lastLoginAt']=_0x17f0c0['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x38622b){var _0x21a9f5;const _0x48c22f=_0x38622b['auth'],_0x2eba12=await _0x38622b['getIdToken'](),_0x365033=await xt(_0x38622b,Sn(_0x48c22f,{'idToken':_0x2eba12}));m(_0x365033==null?void 0x0:_0x365033['users']['length'],_0x48c22f,'internal-error');const _0x1ad558=_0x365033['users'][0x0];_0x38622b['_notifyReloadListener'](_0x1ad558);const _0x257836=(_0x21a9f5=_0x1ad558['providerUserInfo'])!=null&&_0x21a9f5['length']?wa(_0x1ad558['providerUserInfo']):[],_0x555a4b=mf(_0x38622b['providerData'],_0x257836),_0x4e085f=_0x38622b['isAnonymous'],_0x53275e=!(_0x38622b['email']&&_0x1ad558['passwordHash'])&&!(_0x555a4b!=null&&_0x555a4b['length']),_0x3b9d3e=_0x4e085f?_0x53275e:!0x1,_0x3aeb1f={'uid':_0x1ad558['localId'],'displayName':_0x1ad558['displayName']||null,'photoURL':_0x1ad558['photoUrl']||null,'email':_0x1ad558['email']||null,'emailVerified':_0x1ad558['emailVerified']||!0x1,'phoneNumber':_0x1ad558['phoneNumber']||null,'tenantId':_0x1ad558['tenantId']||null,'providerData':_0x555a4b,'metadata':new Pi(_0x1ad558['createdAt'],_0x1ad558['lastLoginAt']),'isAnonymous':_0x3b9d3e};Object['assign'](_0x38622b,_0x3aeb1f);}async function gf(_0x4d2831){const _0x1eb700=k(_0x4d2831);await bn(_0x1eb700),await _0x1eb700['auth']['_persistUserIfCurrent'](_0x1eb700),_0x1eb700['auth']['_notifyListenersIfCurrent'](_0x1eb700);}function mf(_0x397390,_0x583fc8){return[..._0x397390['filter'](_0x510da7=>!_0x583fc8['some'](_0x25aac5=>_0x25aac5['providerId']===_0x510da7['providerId'])),..._0x583fc8];}function wa(_0xf09070){return _0xf09070['map'](({providerId:_0x180bfc,..._0x459e3a})=>({'providerId':_0x180bfc,'uid':_0x459e3a['rawId']||'','displayName':_0x459e3a['displayName']||null,'email':_0x459e3a['email']||null,'phoneNumber':_0x459e3a['phoneNumber']||null,'photoURL':_0x459e3a['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x4f5b32,_0x58acd7){const _0x293522=await Ea(_0x4f5b32,{},async()=>{const _0x2a9c21=at({'grant_type':'refresh_token','refresh_token':_0x58acd7})['slice'](0x1),{tokenApiHost:_0x2a315e,apiKey:_0x56eb06}=_0x4f5b32['config'],_0x256f25=await Ia(_0x4f5b32,_0x2a315e,'/v1/token','key='+_0x56eb06),_0x4c8df5=await _0x4f5b32['_getAdditionalHeaders']();_0x4c8df5['Content-Type']='application/x-www-form-urlencoded';const _0x558aff={'method':'POST','headers':_0x4c8df5,'body':_0x2a9c21};return _0x4f5b32['emulatorConfig']&&Wt(_0x4f5b32['emulatorConfig']['host'])&&(_0x558aff['credentials']='include'),va['fetch']()(_0x256f25,_0x558aff);});return{'accessToken':_0x293522['access_token'],'expiresIn':_0x293522['expires_in'],'refreshToken':_0x293522['refresh_token']};}async function vf(_0x5efd9d,_0x54804d){return Ae(_0x5efd9d,'POST','/v2/accounts:revokeToken',Re(_0x5efd9d,_0x54804d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x584f9a){m(_0x584f9a['idToken'],'internal-error'),m(typeof _0x584f9a['idToken']<'u','internal-error'),m(typeof _0x584f9a['refreshToken']<'u','internal-error');const _0x425fac='expiresIn'in _0x584f9a&&typeof _0x584f9a['expiresIn']<'u'?Number(_0x584f9a['expiresIn']):Er(_0x584f9a['idToken']);this['updateTokensAndExpiration'](_0x584f9a['idToken'],_0x584f9a['refreshToken'],_0x425fac);}['updateFromIdToken'](_0xf1599b){m(_0xf1599b['length']!==0x0,'internal-error');const _0x56f22e=Er(_0xf1599b);this['updateTokensAndExpiration'](_0xf1599b,null,_0x56f22e);}async['getToken'](_0x19d1b7,_0x19dcb2=!0x1){return!_0x19dcb2&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x19d1b7,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x19d1b7,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x6697fd,_0x2a5e65){const {accessToken:_0x4ca83b,refreshToken:_0xe5203c,expiresIn:_0x13aba0}=await yf(_0x6697fd,_0x2a5e65);this['updateTokensAndExpiration'](_0x4ca83b,_0xe5203c,Number(_0x13aba0));}['updateTokensAndExpiration'](_0x19bdd3,_0x5cb67f,_0x177b0c){this['refreshToken']=_0x5cb67f||null,this['accessToken']=_0x19bdd3||null,this['expirationTime']=Date['now']()+_0x177b0c*0x3e8;}static['fromJSON'](_0x307c99,_0x38d2fb){const {refreshToken:_0x14bf6f,accessToken:_0x40f5f1,expirationTime:_0x464430}=_0x38d2fb,_0x15449a=new Je();return _0x14bf6f&&(m(typeof _0x14bf6f=='string','internal-error',{'appName':_0x307c99}),_0x15449a['refreshToken']=_0x14bf6f),_0x40f5f1&&(m(typeof _0x40f5f1=='string','internal-error',{'appName':_0x307c99}),_0x15449a['accessToken']=_0x40f5f1),_0x464430&&(m(typeof _0x464430=='number','internal-error',{'appName':_0x307c99}),_0x15449a['expirationTime']=_0x464430),_0x15449a;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3c1d22){this['accessToken']=_0x3c1d22['accessToken'],this['refreshToken']=_0x3c1d22['refreshToken'],this['expirationTime']=_0x3c1d22['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x366591,_0x1a827b){m(typeof _0x366591=='string'||typeof _0x366591>'u','internal-error',{'appName':_0x1a827b});}class z{constructor({uid:_0x1e42b1,auth:_0x5aa1d1,stsTokenManager:_0x59c88d,..._0x15805a}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1e42b1,this['auth']=_0x5aa1d1,this['stsTokenManager']=_0x59c88d,this['accessToken']=_0x59c88d['accessToken'],this['displayName']=_0x15805a['displayName']||null,this['email']=_0x15805a['email']||null,this['emailVerified']=_0x15805a['emailVerified']||!0x1,this['phoneNumber']=_0x15805a['phoneNumber']||null,this['photoURL']=_0x15805a['photoURL']||null,this['isAnonymous']=_0x15805a['isAnonymous']||!0x1,this['tenantId']=_0x15805a['tenantId']||null,this['providerData']=_0x15805a['providerData']?[..._0x15805a['providerData']]:[],this['metadata']=new Pi(_0x15805a['createdAt']||void 0x0,_0x15805a['lastLoginAt']||void 0x0);}async['getIdToken'](_0xf32b41){const _0x29f7ba=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0xf32b41));return m(_0x29f7ba,this['auth'],'internal-error'),this['accessToken']!==_0x29f7ba&&(this['accessToken']=_0x29f7ba,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x29f7ba;}['getIdTokenResult'](_0xe56acb){return ff(this,_0xe56acb);}['reload'](){return gf(this);}['_assign'](_0x3a9846){this!==_0x3a9846&&(m(this['uid']===_0x3a9846['uid'],this['auth'],'internal-error'),this['displayName']=_0x3a9846['displayName'],this['photoURL']=_0x3a9846['photoURL'],this['email']=_0x3a9846['email'],this['emailVerified']=_0x3a9846['emailVerified'],this['phoneNumber']=_0x3a9846['phoneNumber'],this['isAnonymous']=_0x3a9846['isAnonymous'],this['tenantId']=_0x3a9846['tenantId'],this['providerData']=_0x3a9846['providerData']['map'](_0x2f0397=>({..._0x2f0397})),this['metadata']['_copy'](_0x3a9846['metadata']),this['stsTokenManager']['_assign'](_0x3a9846['stsTokenManager']));}['_clone'](_0x206408){const _0x338796=new z({...this,'auth':_0x206408,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x338796['metadata']['_copy'](this['metadata']),_0x338796;}['_onReload'](_0x216c84){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x216c84,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x29fd6e){this['reloadListener']?this['reloadListener'](_0x29fd6e):this['reloadUserInfo']=_0x29fd6e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5a9794,_0x2ad5bf=!0x1){let _0x49fe0e=!0x1;_0x5a9794['idToken']&&_0x5a9794['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5a9794),_0x49fe0e=!0x0),_0x2ad5bf&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x49fe0e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x545d45=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x545d45})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1dd9f5=>({..._0x1dd9f5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x575171,_0x3b43da){const _0x5561fa=_0x3b43da['displayName']??void 0x0,_0x1bd531=_0x3b43da['email']??void 0x0,_0xd9a3d0=_0x3b43da['phoneNumber']??void 0x0,_0x23791e=_0x3b43da['photoURL']??void 0x0,_0x4b2e6a=_0x3b43da['tenantId']??void 0x0,_0x1bdb77=_0x3b43da['_redirectEventId']??void 0x0,_0x1f324f=_0x3b43da['createdAt']??void 0x0,_0x152240=_0x3b43da['lastLoginAt']??void 0x0,{uid:_0x1446b8,emailVerified:_0x3b5b51,isAnonymous:_0x3e4d37,providerData:_0x47000d,stsTokenManager:_0x2d63f0}=_0x3b43da;m(_0x1446b8&&_0x2d63f0,_0x575171,'internal-error');const _0x6d9df5=Je['fromJSON'](this['name'],_0x2d63f0);m(typeof _0x1446b8=='string',_0x575171,'internal-error'),ce(_0x5561fa,_0x575171['name']),ce(_0x1bd531,_0x575171['name']),m(typeof _0x3b5b51=='boolean',_0x575171,'internal-error'),m(typeof _0x3e4d37=='boolean',_0x575171,'internal-error'),ce(_0xd9a3d0,_0x575171['name']),ce(_0x23791e,_0x575171['name']),ce(_0x4b2e6a,_0x575171['name']),ce(_0x1bdb77,_0x575171['name']),ce(_0x1f324f,_0x575171['name']),ce(_0x152240,_0x575171['name']);const _0x5027c6=new z({'uid':_0x1446b8,'auth':_0x575171,'email':_0x1bd531,'emailVerified':_0x3b5b51,'displayName':_0x5561fa,'isAnonymous':_0x3e4d37,'photoURL':_0x23791e,'phoneNumber':_0xd9a3d0,'tenantId':_0x4b2e6a,'stsTokenManager':_0x6d9df5,'createdAt':_0x1f324f,'lastLoginAt':_0x152240});return _0x47000d&&Array['isArray'](_0x47000d)&&(_0x5027c6['providerData']=_0x47000d['map'](_0x3b70ca=>({..._0x3b70ca}))),_0x1bdb77&&(_0x5027c6['_redirectEventId']=_0x1bdb77),_0x5027c6;}static async['_fromIdTokenResponse'](_0x331a80,_0x474245,_0x42b1a8=!0x1){const _0xc49806=new Je();_0xc49806['updateFromServerResponse'](_0x474245);const _0x3eaec6=new z({'uid':_0x474245['localId'],'auth':_0x331a80,'stsTokenManager':_0xc49806,'isAnonymous':_0x42b1a8});return await bn(_0x3eaec6),_0x3eaec6;}static async['_fromGetAccountInfoResponse'](_0xe99e56,_0x37bc7e,_0x4ce8ae){const _0x4fb3a3=_0x37bc7e['users'][0x0];m(_0x4fb3a3['localId']!==void 0x0,'internal-error');const _0x14d4cf=_0x4fb3a3['providerUserInfo']!==void 0x0?wa(_0x4fb3a3['providerUserInfo']):[],_0x338bc2=!(_0x4fb3a3['email']&&_0x4fb3a3['passwordHash'])&&!(_0x14d4cf!=null&&_0x14d4cf['length']),_0x28579c=new Je();_0x28579c['updateFromIdToken'](_0x4ce8ae);const _0x35ddf5=new z({'uid':_0x4fb3a3['localId'],'auth':_0xe99e56,'stsTokenManager':_0x28579c,'isAnonymous':_0x338bc2}),_0x5674e0={'uid':_0x4fb3a3['localId'],'displayName':_0x4fb3a3['displayName']||null,'photoURL':_0x4fb3a3['photoUrl']||null,'email':_0x4fb3a3['email']||null,'emailVerified':_0x4fb3a3['emailVerified']||!0x1,'phoneNumber':_0x4fb3a3['phoneNumber']||null,'tenantId':_0x4fb3a3['tenantId']||null,'providerData':_0x14d4cf,'metadata':new Pi(_0x4fb3a3['createdAt'],_0x4fb3a3['lastLoginAt']),'isAnonymous':!(_0x4fb3a3['email']&&_0x4fb3a3['passwordHash'])&&!(_0x14d4cf!=null&&_0x14d4cf['length'])};return Object['assign'](_0x35ddf5,_0x5674e0),_0x35ddf5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x3bd9c0){ae(_0x3bd9c0 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1c147e=Ir['get'](_0x3bd9c0);return _0x1c147e?(ae(_0x1c147e instanceof _0x3bd9c0,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1c147e):(_0x1c147e=new _0x3bd9c0(),Ir['set'](_0x3bd9c0,_0x1c147e),_0x1c147e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5240e0,_0x414cc8){this['storage'][_0x5240e0]=_0x414cc8;}async['_get'](_0x4c359f){const _0x555b1b=this['storage'][_0x4c359f];return _0x555b1b===void 0x0?null:_0x555b1b;}async['_remove'](_0x412d2c){delete this['storage'][_0x412d2c];}['_addListener'](_0x5aa7cf,_0xf4fbc0){}['_removeListener'](_0x182934,_0x2a0cda){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x27559d,_0x182897,_0x96236){return'firebase:'+_0x27559d+':'+_0x182897+':'+_0x96236;}class Xe{constructor(_0x31abdf,_0x35d021,_0x508a17){this['persistence']=_0x31abdf,this['auth']=_0x35d021,this['userKey']=_0x508a17;const {config:_0x286773,name:_0xbc9922}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x286773['apiKey'],_0xbc9922),this['fullPersistenceKey']=sn('persistence',_0x286773['apiKey'],_0xbc9922),this['boundEventHandler']=_0x35d021['_onStorageEvent']['bind'](_0x35d021),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3108f5){return this['persistence']['_set'](this['fullUserKey'],_0x3108f5['toJSON']());}async['getCurrentUser'](){const _0x45a94c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x45a94c)return null;if(typeof _0x45a94c=='string'){const _0x1063ae=await Sn(this['auth'],{'idToken':_0x45a94c})['catch'](()=>{});return _0x1063ae?z['_fromGetAccountInfoResponse'](this['auth'],_0x1063ae,_0x45a94c):null;}return z['_fromJSON'](this['auth'],_0x45a94c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x580adc){if(this['persistence']===_0x580adc)return;const _0x10b391=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x580adc,_0x10b391)return this['setCurrentUser'](_0x10b391);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1adf4f,_0x4e0cac,_0x23fc0c='authUser'){if(!_0x4e0cac['length'])return new Xe(ne(wr),_0x1adf4f,_0x23fc0c);const _0x997752=(await Promise['all'](_0x4e0cac['map'](async _0x5b9b24=>{if(await _0x5b9b24['_isAvailable']())return _0x5b9b24;})))['filter'](_0x1320e9=>_0x1320e9);let _0x3f3c3d=_0x997752[0x0]||ne(wr);const _0x5cf750=sn(_0x23fc0c,_0x1adf4f['config']['apiKey'],_0x1adf4f['name']);let _0x2c8881=null;for(const _0x15c45f of _0x4e0cac)try{const _0x157c43=await _0x15c45f['_get'](_0x5cf750);if(_0x157c43){let _0x27a957;if(typeof _0x157c43=='string'){const _0x3ba5e1=await Sn(_0x1adf4f,{'idToken':_0x157c43})['catch'](()=>{});if(!_0x3ba5e1)break;_0x27a957=await z['_fromGetAccountInfoResponse'](_0x1adf4f,_0x3ba5e1,_0x157c43);}else _0x27a957=z['_fromJSON'](_0x1adf4f,_0x157c43);_0x15c45f!==_0x3f3c3d&&(_0x2c8881=_0x27a957),_0x3f3c3d=_0x15c45f;break;}}catch{}const _0x56dd60=_0x997752['filter'](_0x331f4e=>_0x331f4e['_shouldAllowMigration']);return!_0x3f3c3d['_shouldAllowMigration']||!_0x56dd60['length']?new Xe(_0x3f3c3d,_0x1adf4f,_0x23fc0c):(_0x3f3c3d=_0x56dd60[0x0],_0x2c8881&&await _0x3f3c3d['_set'](_0x5cf750,_0x2c8881['toJSON']()),await Promise['all'](_0x4e0cac['map'](async _0x3ca7ac=>{if(_0x3ca7ac!==_0x3f3c3d)try{await _0x3ca7ac['_remove'](_0x5cf750);}catch{}})),new Xe(_0x3f3c3d,_0x1adf4f,_0x23fc0c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0xc8614f){const _0x5540b2=_0xc8614f['toLowerCase']();if(_0x5540b2['includes']('opera/')||_0x5540b2['includes']('opr/')||_0x5540b2['includes']('opios/'))return'Opera';if(Ra(_0x5540b2))return'IEMobile';if(_0x5540b2['includes']('msie')||_0x5540b2['includes']('trident/'))return'IE';if(_0x5540b2['includes']('edge/'))return'Edge';if(Ta(_0x5540b2))return'Firefox';if(_0x5540b2['includes']('silk/'))return'Silk';if(ka(_0x5540b2))return'Blackberry';if(Na(_0x5540b2))return'Webos';if(Sa(_0x5540b2))return'Safari';if((_0x5540b2['includes']('chrome/')||ba(_0x5540b2))&&!_0x5540b2['includes']('edge/'))return'Chrome';if(Aa(_0x5540b2))return'Android';{const _0x4a45e5=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3bb0bd=_0xc8614f['match'](_0x4a45e5);if((_0x3bb0bd==null?void 0x0:_0x3bb0bd['length'])===0x2)return _0x3bb0bd[0x1];}return'Other';}function Ta(_0x457317=W()){return/firefox\//i['test'](_0x457317);}function Sa(_0x5983d0=W()){const _0x238bc0=_0x5983d0['toLowerCase']();return _0x238bc0['includes']('safari/')&&!_0x238bc0['includes']('chrome/')&&!_0x238bc0['includes']('crios/')&&!_0x238bc0['includes']('android');}function ba(_0x4c72c9=W()){return/crios\//i['test'](_0x4c72c9);}function Ra(_0x2442e9=W()){return/iemobile/i['test'](_0x2442e9);}function Aa(_0x13f53b=W()){return/android/i['test'](_0x13f53b);}function ka(_0x158b44=W()){return/blackberry/i['test'](_0x158b44);}function Na(_0x2374ce=W()){return/webos/i['test'](_0x2374ce);}function Cs(_0x20c56d=W()){return/iphone|ipad|ipod/i['test'](_0x20c56d)||/macintosh/i['test'](_0x20c56d)&&/mobile/i['test'](_0x20c56d);}function Ef(_0x3ff3b5=W()){var _0x31be5a;return Cs(_0x3ff3b5)&&!!((_0x31be5a=window['navigator'])!=null&&_0x31be5a['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0xfd651e=W()){return Cs(_0xfd651e)||Aa(_0xfd651e)||Na(_0xfd651e)||ka(_0xfd651e)||/windows phone/i['test'](_0xfd651e)||Ra(_0xfd651e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x4931a9,_0x2dde18=[]){let _0xf81740;switch(_0x4931a9){case'Browser':_0xf81740=Cr(W());break;case'Worker':_0xf81740=Cr(W())+'-'+_0x4931a9;break;default:_0xf81740=_0x4931a9;}const _0x55babc=_0x2dde18['length']?_0x2dde18['join'](','):'FirebaseCore-web';return _0xf81740+'/JsCore/'+ct+'/'+_0x55babc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2cad8d){this['auth']=_0x2cad8d,this['queue']=[];}['pushCallback'](_0x4d8ff5,_0x574551){const _0x102e1b=_0x1edb66=>new Promise((_0x2d336c,_0x3a7e27)=>{try{const _0x45c104=_0x4d8ff5(_0x1edb66);_0x2d336c(_0x45c104);}catch(_0x33a096){_0x3a7e27(_0x33a096);}});_0x102e1b['onAbort']=_0x574551,this['queue']['push'](_0x102e1b);const _0x5d2b91=this['queue']['length']-0x1;return()=>{this['queue'][_0x5d2b91]=()=>Promise['resolve']();};}async['runMiddleware'](_0x421993){if(this['auth']['currentUser']===_0x421993)return;const _0x197ec6=[];try{for(const _0x4e73ba of this['queue'])await _0x4e73ba(_0x421993),_0x4e73ba['onAbort']&&_0x197ec6['push'](_0x4e73ba['onAbort']);}catch(_0x4fdc5a){_0x197ec6['reverse']();for(const _0x354cdb of _0x197ec6)try{_0x354cdb();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4fdc5a==null?void 0x0:_0x4fdc5a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4f80c7,_0x2a74e2={}){return Ae(_0x4f80c7,'GET','/v2/passwordPolicy',Re(_0x4f80c7,_0x2a74e2));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3c126a){var _0x2ee5f9;const _0xfcf822=_0x3c126a['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xfcf822['minPasswordLength']??Tf,_0xfcf822['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xfcf822['maxPasswordLength']),_0xfcf822['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xfcf822['containsLowercaseCharacter']),_0xfcf822['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xfcf822['containsUppercaseCharacter']),_0xfcf822['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xfcf822['containsNumericCharacter']),_0xfcf822['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xfcf822['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3c126a['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2ee5f9=_0x3c126a['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2ee5f9['join'](''))??'',this['forceUpgradeOnSignin']=_0x3c126a['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3c126a['schemaVersion'];}['validatePassword'](_0x47a480){const _0x2d8ac4={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x47a480,_0x2d8ac4),this['validatePasswordCharacterOptions'](_0x47a480,_0x2d8ac4),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['meetsMinPasswordLength']??!0x0),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['meetsMaxPasswordLength']??!0x0),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['containsLowercaseLetter']??!0x0),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['containsUppercaseLetter']??!0x0),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['containsNumericCharacter']??!0x0),_0x2d8ac4['isValid']&&(_0x2d8ac4['isValid']=_0x2d8ac4['containsNonAlphanumericCharacter']??!0x0),_0x2d8ac4;}['validatePasswordLengthOptions'](_0x3838d4,_0x1a9794){const _0x3e7670=this['customStrengthOptions']['minPasswordLength'],_0x41002b=this['customStrengthOptions']['maxPasswordLength'];_0x3e7670&&(_0x1a9794['meetsMinPasswordLength']=_0x3838d4['length']>=_0x3e7670),_0x41002b&&(_0x1a9794['meetsMaxPasswordLength']=_0x3838d4['length']<=_0x41002b);}['validatePasswordCharacterOptions'](_0x45af35,_0x480f85){this['updatePasswordCharacterOptionsStatuses'](_0x480f85,!0x1,!0x1,!0x1,!0x1);let _0x268333;for(let _0x51e000=0x0;_0x51e000<_0x45af35['length'];_0x51e000++)_0x268333=_0x45af35['charAt'](_0x51e000),this['updatePasswordCharacterOptionsStatuses'](_0x480f85,_0x268333>='a'&&_0x268333<='z',_0x268333>='A'&&_0x268333<='Z',_0x268333>='0'&&_0x268333<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x268333));}['updatePasswordCharacterOptionsStatuses'](_0x44f6b5,_0x1dc1dc,_0x5f17de,_0x11e65f,_0x22be01){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x44f6b5['containsLowercaseLetter']||(_0x44f6b5['containsLowercaseLetter']=_0x1dc1dc)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x44f6b5['containsUppercaseLetter']||(_0x44f6b5['containsUppercaseLetter']=_0x5f17de)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x44f6b5['containsNumericCharacter']||(_0x44f6b5['containsNumericCharacter']=_0x11e65f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x44f6b5['containsNonAlphanumericCharacter']||(_0x44f6b5['containsNonAlphanumericCharacter']=_0x22be01));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x2ac72c,_0x100e3c,_0x21f46b,_0x2def20){this['app']=_0x2ac72c,this['heartbeatServiceProvider']=_0x100e3c,this['appCheckServiceProvider']=_0x21f46b,this['config']=_0x2def20,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x2ac72c['name'],this['clientVersion']=_0x2def20['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x28e0f1=>this['_resolvePersistenceManagerAvailable']=_0x28e0f1);}['_initializeWithPersistence'](_0x152c44,_0x2e9bb3){return _0x2e9bb3&&(this['_popupRedirectResolver']=ne(_0x2e9bb3)),this['_initializationPromise']=this['queue'](async()=>{var _0x4be9fd,_0x5cfa04,_0x47b9b8;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x152c44),(_0x4be9fd=this['_resolvePersistenceManagerAvailable'])==null||_0x4be9fd['call'](this),!this['_deleted'])){if((_0x5cfa04=this['_popupRedirectResolver'])!=null&&_0x5cfa04['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2e9bb3),this['lastNotifiedUid']=((_0x47b9b8=this['currentUser'])==null?void 0x0:_0x47b9b8['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x576a60=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x576a60)){if(this['currentUser']&&_0x576a60&&this['currentUser']['uid']===_0x576a60['uid']){this['_currentUser']['_assign'](_0x576a60),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x576a60,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1270f4){try{const _0x2e860e=await Sn(this,{'idToken':_0x1270f4}),_0x33b4b9=await z['_fromGetAccountInfoResponse'](this,_0x2e860e,_0x1270f4);await this['directlySetCurrentUser'](_0x33b4b9);}catch(_0xa32385){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xa32385),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x58db70){var _0xe698a4;if(H(this['app'])){const _0x538bfc=this['app']['settings']['authIdToken'];return _0x538bfc?new Promise(_0x495cc9=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x538bfc)['then'](_0x495cc9,_0x495cc9));}):this['directlySetCurrentUser'](null);}const _0x446658=await this['assertedPersistence']['getCurrentUser']();let _0x1fb2c8=_0x446658,_0x491093=!0x1;if(_0x58db70&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x318aed=(_0xe698a4=this['redirectUser'])==null?void 0x0:_0xe698a4['_redirectEventId'],_0x4f78f8=_0x1fb2c8==null?void 0x0:_0x1fb2c8['_redirectEventId'],_0xda4185=await this['tryRedirectSignIn'](_0x58db70);(!_0x318aed||_0x318aed===_0x4f78f8)&&(_0xda4185!=null&&_0xda4185['user'])&&(_0x1fb2c8=_0xda4185['user'],_0x491093=!0x0);}if(!_0x1fb2c8)return this['directlySetCurrentUser'](null);if(!_0x1fb2c8['_redirectEventId']){if(_0x491093)try{await this['beforeStateQueue']['runMiddleware'](_0x1fb2c8);}catch(_0x520b97){_0x1fb2c8=_0x446658,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x520b97));}return _0x1fb2c8?this['reloadAndSetCurrentUserOrClear'](_0x1fb2c8):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1fb2c8['_redirectEventId']?this['directlySetCurrentUser'](_0x1fb2c8):this['reloadAndSetCurrentUserOrClear'](_0x1fb2c8);}async['tryRedirectSignIn'](_0x4d6a79){let _0x4a3aba=null;try{_0x4a3aba=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4d6a79,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4a3aba;}async['reloadAndSetCurrentUserOrClear'](_0x1ca06d){try{await bn(_0x1ca06d);}catch(_0x5230d1){if((_0x5230d1==null?void 0x0:_0x5230d1['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1ca06d);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x261814){if(H(this['app']))return Promise['reject'](se(this));const _0x521b5d=_0x261814?k(_0x261814):null;return _0x521b5d&&m(_0x521b5d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x521b5d&&_0x521b5d['_clone'](this));}async['_updateCurrentUser'](_0x582977,_0x337f7d=!0x1){if(!this['_deleted'])return _0x582977&&m(this['tenantId']===_0x582977['tenantId'],this,'tenant-id-mismatch'),_0x337f7d||await this['beforeStateQueue']['runMiddleware'](_0x582977),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x582977),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x937214){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x937214));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x250aa8){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2fc3d6=this['_getPasswordPolicyInternal']();return _0x2fc3d6['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2fc3d6['validatePassword'](_0x250aa8);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x46196d=await Cf(this),_0x51fa31=new Sf(_0x46196d);this['tenantId']===null?this['_projectPasswordPolicy']=_0x51fa31:this['_tenantPasswordPolicies'][this['tenantId']]=_0x51fa31;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x6273a8){this['_errorFactory']=new Ut('auth','Firebase',_0x6273a8());}['onAuthStateChanged'](_0x207ec7,_0x1470b3,_0x160221){return this['registerStateListener'](this['authStateSubscription'],_0x207ec7,_0x1470b3,_0x160221);}['beforeAuthStateChanged'](_0x59554b,_0x1240b9){return this['beforeStateQueue']['pushCallback'](_0x59554b,_0x1240b9);}['onIdTokenChanged'](_0x4e46f2,_0x41bd97,_0x4415e2){return this['registerStateListener'](this['idTokenSubscription'],_0x4e46f2,_0x41bd97,_0x4415e2);}['authStateReady'](){return new Promise((_0x16029a,_0x485a10)=>{if(this['currentUser'])_0x16029a();else{const _0x29c533=this['onAuthStateChanged'](()=>{_0x29c533(),_0x16029a();},_0x485a10);}});}async['revokeAccessToken'](_0x5a8d2b){if(this['currentUser']){const _0x5e6b69=await this['currentUser']['getIdToken'](),_0xf1cc06={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5a8d2b,'idToken':_0x5e6b69};this['tenantId']!=null&&(_0xf1cc06['tenantId']=this['tenantId']),await vf(this,_0xf1cc06);}}['toJSON'](){var _0x15e61c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x15e61c=this['_currentUser'])==null?void 0x0:_0x15e61c['toJSON']()};}async['_setRedirectUser'](_0x4ea824,_0x2e1537){const _0x53b8bc=await this['getOrInitRedirectPersistenceManager'](_0x2e1537);return _0x4ea824===null?_0x53b8bc['removeCurrentUser']():_0x53b8bc['setCurrentUser'](_0x4ea824);}async['getOrInitRedirectPersistenceManager'](_0x5767ca){if(!this['redirectPersistenceManager']){const _0x392012=_0x5767ca&&ne(_0x5767ca)||this['_popupRedirectResolver'];m(_0x392012,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x392012['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x42a354){var _0x128379,_0x1e47b7;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x128379=this['_currentUser'])==null?void 0x0:_0x128379['_redirectEventId'])===_0x42a354?this['_currentUser']:((_0x1e47b7=this['redirectUser'])==null?void 0x0:_0x1e47b7['_redirectEventId'])===_0x42a354?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4a7871){if(_0x4a7871===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4a7871));}['_notifyListenersIfCurrent'](_0x8484c6){_0x8484c6===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x507055;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xbba7e8=((_0x507055=this['currentUser'])==null?void 0x0:_0x507055['uid'])??null;this['lastNotifiedUid']!==_0xbba7e8&&(this['lastNotifiedUid']=_0xbba7e8,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x15c3eb,_0x549eb9,_0x306ba9,_0x156cda){if(this['_deleted'])return()=>{};const _0x229441=typeof _0x549eb9=='function'?_0x549eb9:_0x549eb9['next']['bind'](_0x549eb9);let _0x25a7be=!0x1;const _0x414305=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x414305,this,'internal-error'),_0x414305['then'](()=>{_0x25a7be||_0x229441(this['currentUser']);}),typeof _0x549eb9=='function'){const _0xc35dc2=_0x15c3eb['addObserver'](_0x549eb9,_0x306ba9,_0x156cda);return()=>{_0x25a7be=!0x0,_0xc35dc2();};}else{const _0x3f6408=_0x15c3eb['addObserver'](_0x549eb9);return()=>{_0x25a7be=!0x0,_0x3f6408();};}}async['directlySetCurrentUser'](_0x2e4d85){this['currentUser']&&this['currentUser']!==_0x2e4d85&&this['_currentUser']['_stopProactiveRefresh'](),_0x2e4d85&&this['isProactiveRefreshEnabled']&&_0x2e4d85['_startProactiveRefresh'](),this['currentUser']=_0x2e4d85,_0x2e4d85?await this['assertedPersistence']['setCurrentUser'](_0x2e4d85):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5d9a47){return this['operations']=this['operations']['then'](_0x5d9a47,_0x5d9a47),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1a82d4){!_0x1a82d4||this['frameworks']['includes'](_0x1a82d4)||(this['frameworks']['push'](_0x1a82d4),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x12683a;const _0x597bcc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x597bcc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x302b59=await((_0x12683a=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x12683a['getHeartbeatsHeader']());_0x302b59&&(_0x597bcc['X-Firebase-Client']=_0x302b59);const _0x1024dc=await this['_getAppCheckToken']();return _0x1024dc&&(_0x597bcc['X-Firebase-AppCheck']=_0x1024dc),_0x597bcc;}async['_getAppCheckToken'](){var _0x549cf3;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4c138d=await((_0x549cf3=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x549cf3['getToken']());return _0x4c138d!=null&&_0x4c138d['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4c138d['error']),_0x4c138d==null?void 0x0:_0x4c138d['token'];}}function qe(_0x18e25b){return k(_0x18e25b);}class Tr{constructor(_0x3953f3){this['auth']=_0x3953f3,this['observer']=null,this['addObserver']=Ic(_0x2a23d8=>this['observer']=_0x2a23d8);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x231aab){zn=_0x231aab;}function Da(_0x12759c){return zn['loadJS'](_0x12759c);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x5a34d1){return'__'+_0x5a34d1+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x47b117){_0x47b117();}['execute'](_0x546707,_0x4c7ac3){return Promise['resolve']('token');}['render'](_0x2c5f39,_0x524260){return'';}}class Of{['ready'](_0x3316ce){_0x3316ce();}['execute'](_0x60ee27,_0x3556a7){return Promise['resolve']('token');}['render'](_0x2186b8,_0x24934b){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x2eef48){this['type']=Df,this['auth']=qe(_0x2eef48);}async['verify'](_0x5d2cb6='verify',_0x2a3bd3=!0x1){async function _0x556fdc(_0x585163){if(!_0x2a3bd3){if(_0x585163['tenantId']==null&&_0x585163['_agentRecaptchaConfig']!=null)return _0x585163['_agentRecaptchaConfig']['siteKey'];if(_0x585163['tenantId']!=null&&_0x585163['_tenantRecaptchaConfigs'][_0x585163['tenantId']]!==void 0x0)return _0x585163['_tenantRecaptchaConfigs'][_0x585163['tenantId']]['siteKey'];}return new Promise(async(_0x5dab0a,_0x15b43f)=>{uf(_0x585163,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x3af9af=>{if(_0x3af9af['recaptchaKey']===void 0x0)_0x15b43f(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xb3d4d9=new hf(_0x3af9af);return _0x585163['tenantId']==null?_0x585163['_agentRecaptchaConfig']=_0xb3d4d9:_0x585163['_tenantRecaptchaConfigs'][_0x585163['tenantId']]=_0xb3d4d9,_0x5dab0a(_0xb3d4d9['siteKey']);}})['catch'](_0x84cd32=>{_0x15b43f(_0x84cd32);});});}function _0x568d44(_0x341740,_0x426d1a,_0x2d23f4){const _0x10ea32=window['grecaptcha'];vr(_0x10ea32)?_0x10ea32['enterprise']['ready'](()=>{_0x10ea32['enterprise']['execute'](_0x341740,{'action':_0x5d2cb6})['then'](_0x250f94=>{_0x426d1a(_0x250f94);})['catch'](()=>{_0x426d1a(Ma);});}):_0x2d23f4(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x116991,_0x45e64b)=>{_0x556fdc(this['auth'])['then'](async _0x27b008=>{if(!_0x2a3bd3&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x568d44(_0x27b008,_0x116991,_0x45e64b);else{if(typeof window>'u'){_0x45e64b(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xaeb255=Af();_0xaeb255['length']!==0x0&&(_0xaeb255+=_0x27b008+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x5a2e70;(_0x5a2e70=le['scriptInjectionDeferred'])==null||_0x5a2e70['resolve']();},Da(_0xaeb255)['then'](()=>{var _0x2bfcaa;return(_0x2bfcaa=le['scriptInjectionDeferred'])==null?void 0x0:_0x2bfcaa['promise'];})['then'](()=>{_0x568d44(_0x27b008,_0x116991,_0x45e64b);})['catch'](_0xc3007a=>{_0x45e64b(_0xc3007a);});}})['catch'](_0x37cc8a=>{_0x45e64b(_0x37cc8a);});});}}le['scriptInjectionDeferred']=null;async function br(_0x268674,_0x59024c,_0x28898b,_0x1949e3=!0x1,_0x30ba4a=!0x1){const _0x588601=new le(_0x268674);let _0x54b47b;if(_0x30ba4a)_0x54b47b=Ma;else try{_0x54b47b=await _0x588601['verify'](_0x28898b);}catch{_0x54b47b=await _0x588601['verify'](_0x28898b,!0x0);}const _0x21207e={..._0x59024c};if(_0x28898b==='mfaSmsEnrollment'||_0x28898b==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x21207e){const _0x44c76b=_0x21207e['phoneEnrollmentInfo']['phoneNumber'],_0x1d6913=_0x21207e['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x21207e,{'phoneEnrollmentInfo':{'phoneNumber':_0x44c76b,'recaptchaToken':_0x1d6913,'captchaResponse':_0x54b47b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x21207e){const _0x480889=_0x21207e['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x21207e,{'phoneSignInInfo':{'recaptchaToken':_0x480889,'captchaResponse':_0x54b47b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x21207e;}return _0x1949e3?Object['assign'](_0x21207e,{'captchaResp':_0x54b47b}):Object['assign'](_0x21207e,{'captchaResponse':_0x54b47b}),Object['assign'](_0x21207e,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x21207e,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x21207e;}async function Oi(_0x290ff6,_0x195a73,_0x44cba4,_0x4f93a5,_0x126ba1){var _0x1b3640;if((_0x1b3640=_0x290ff6['_getRecaptchaConfig']())!=null&&_0x1b3640['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x17bba7=await br(_0x290ff6,_0x195a73,_0x44cba4,_0x44cba4==='getOobCode');return _0x4f93a5(_0x290ff6,_0x17bba7);}else return _0x4f93a5(_0x290ff6,_0x195a73)['catch'](async _0x5d3dc6=>{if(_0x5d3dc6['code']==='auth/missing-recaptcha-token'){console['log'](_0x44cba4+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1a3fc9=await br(_0x290ff6,_0x195a73,_0x44cba4,_0x44cba4==='getOobCode');return _0x4f93a5(_0x290ff6,_0x1a3fc9);}else return Promise['reject'](_0x5d3dc6);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x77bbfc,_0x390dc9){const _0x5739f4=Ui(_0x77bbfc,'auth');if(_0x5739f4['isInitialized']()){const _0x46bdcc=_0x5739f4['getImmediate'](),_0x23c25b=_0x5739f4['getOptions']();if(De(_0x23c25b,_0x390dc9??{}))return _0x46bdcc;K(_0x46bdcc,'already-initialized');}return _0x5739f4['initialize']({'options':_0x390dc9});}function Lf(_0x4029b1,_0x3b6ea4){const _0x5b1433=(_0x3b6ea4==null?void 0x0:_0x3b6ea4['persistence'])||[],_0x4c142f=(Array['isArray'](_0x5b1433)?_0x5b1433:[_0x5b1433])['map'](ne);_0x3b6ea4!=null&&_0x3b6ea4['errorMap']&&_0x4029b1['_updateErrorMap'](_0x3b6ea4['errorMap']),_0x4029b1['_initializeWithPersistence'](_0x4c142f,_0x3b6ea4==null?void 0x0:_0x3b6ea4['popupRedirectResolver']);}function xf(_0x30e050,_0x4ad049,_0x460c73){const _0x4c3c99=qe(_0x30e050);m(/^https?:\/\//['test'](_0x4ad049),_0x4c3c99,'invalid-emulator-scheme');const _0x5d70e4=!0x1,_0x27e489=La(_0x4ad049),{host:_0x24e0af,port:_0x10504d}=Ff(_0x4ad049),_0x1215f8=_0x10504d===null?'':':'+_0x10504d,_0x337dc3={'url':_0x27e489+'//'+_0x24e0af+_0x1215f8+'/'},_0x4fdbbe=Object['freeze']({'host':_0x24e0af,'port':_0x10504d,'protocol':_0x27e489['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5d70e4})});if(!_0x4c3c99['_canInitEmulator']){m(_0x4c3c99['config']['emulator']&&_0x4c3c99['emulatorConfig'],_0x4c3c99,'emulator-config-failed'),m(De(_0x337dc3,_0x4c3c99['config']['emulator'])&&De(_0x4fdbbe,_0x4c3c99['emulatorConfig']),_0x4c3c99,'emulator-config-failed');return;}_0x4c3c99['config']['emulator']=_0x337dc3,_0x4c3c99['emulatorConfig']=_0x4fdbbe,_0x4c3c99['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x24e0af)?jr(_0x27e489+'//'+_0x24e0af+_0x1215f8):Uf();}function La(_0xc48953){const _0x309ce5=_0xc48953['indexOf'](':');return _0x309ce5<0x0?'':_0xc48953['substr'](0x0,_0x309ce5+0x1);}function Ff(_0x31f202){const _0x1db622=La(_0x31f202),_0x1a1ce8=/(\/\/)?([^?#/]+)/['exec'](_0x31f202['substr'](_0x1db622['length']));if(!_0x1a1ce8)return{'host':'','port':null};const _0x4cc6df=_0x1a1ce8[0x2]['split']('@')['pop']()||'',_0xed82ae=/^(\[[^\]]+\])(:|$)/['exec'](_0x4cc6df);if(_0xed82ae){const _0x5b44f6=_0xed82ae[0x1];return{'host':_0x5b44f6,'port':Rr(_0x4cc6df['substr'](_0x5b44f6['length']+0x1))};}else{const [_0x212831,_0x554949]=_0x4cc6df['split'](':');return{'host':_0x212831,'port':Rr(_0x554949)};}}function Rr(_0x24d9ce){if(!_0x24d9ce)return null;const _0x519735=Number(_0x24d9ce);return isNaN(_0x519735)?null:_0x519735;}function Uf(){function _0x394e94(){const _0x383926=document['createElement']('p'),_0x239716=_0x383926['style'];_0x383926['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x239716['position']='fixed',_0x239716['width']='100%',_0x239716['backgroundColor']='#ffffff',_0x239716['border']='.1em\x20solid\x20#000000',_0x239716['color']='#b50000',_0x239716['bottom']='0px',_0x239716['left']='0px',_0x239716['margin']='0px',_0x239716['zIndex']='10000',_0x239716['textAlign']='center',_0x383926['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x383926);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x394e94):_0x394e94());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x463786,_0x18b74e){this['providerId']=_0x463786,this['signInMethod']=_0x18b74e;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3c62fa){return te('not\x20implemented');}['_linkToIdToken'](_0x2ee991,_0xb36ca4){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x3054fb){return te('not\x20implemented');}}async function Wf(_0x3357ad,_0x208d72){return Ae(_0x3357ad,'POST','/v1/accounts:signUp',_0x208d72);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x56ba98,_0x3fc193){return Yt(_0x56ba98,'POST','/v1/accounts:signInWithPassword',Re(_0x56ba98,_0x3fc193));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4951d1,_0x2b504e){return Yt(_0x4951d1,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4951d1,_0x2b504e));}async function Hf(_0x1a7fc3,_0x4b1ffe){return Yt(_0x1a7fc3,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1a7fc3,_0x4b1ffe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x43e165,_0x2a7934,_0x224646,_0x1a90eb=null){super('password',_0x224646),this['_email']=_0x43e165,this['_password']=_0x2a7934,this['_tenantId']=_0x1a90eb;}static['_fromEmailAndPassword'](_0x46d754,_0x2127fc){return new Ft(_0x46d754,_0x2127fc,'password');}static['_fromEmailAndCode'](_0x3fef96,_0x1c76c5,_0x3bf62a=null){return new Ft(_0x3fef96,_0x1c76c5,'emailLink',_0x3bf62a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xf43bd9){const _0x54bf5b=typeof _0xf43bd9=='string'?JSON['parse'](_0xf43bd9):_0xf43bd9;if(_0x54bf5b!=null&&_0x54bf5b['email']&&(_0x54bf5b!=null&&_0x54bf5b['password'])){if(_0x54bf5b['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x54bf5b['email'],_0x54bf5b['password']);if(_0x54bf5b['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x54bf5b['email'],_0x54bf5b['password'],_0x54bf5b['tenantId']);}return null;}async['_getIdTokenResponse'](_0x322108){switch(this['signInMethod']){case'password':const _0x4748fe={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x322108,_0x4748fe,'signInWithPassword',Bf);case'emailLink':return Vf(_0x322108,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x322108,'internal-error');}}async['_linkToIdToken'](_0xabb48,_0x1f0717){switch(this['signInMethod']){case'password':const _0x1673eb={'idToken':_0x1f0717,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0xabb48,_0x1673eb,'signUpPassword',Wf);case'emailLink':return Hf(_0xabb48,{'idToken':_0x1f0717,'email':this['_email'],'oobCode':this['_password']});default:K(_0xabb48,'internal-error');}}['_getReauthenticationResolver'](_0x32fd08){return this['_getIdTokenResponse'](_0x32fd08);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4b8187,_0x22422d){return Yt(_0x4b8187,'POST','/v1/accounts:signInWithIdp',Re(_0x4b8187,_0x22422d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1e18bc){const _0x1ad3e4=new We(_0x1e18bc['providerId'],_0x1e18bc['signInMethod']);return _0x1e18bc['idToken']||_0x1e18bc['accessToken']?(_0x1e18bc['idToken']&&(_0x1ad3e4['idToken']=_0x1e18bc['idToken']),_0x1e18bc['accessToken']&&(_0x1ad3e4['accessToken']=_0x1e18bc['accessToken']),_0x1e18bc['nonce']&&!_0x1e18bc['pendingToken']&&(_0x1ad3e4['nonce']=_0x1e18bc['nonce']),_0x1e18bc['pendingToken']&&(_0x1ad3e4['pendingToken']=_0x1e18bc['pendingToken'])):_0x1e18bc['oauthToken']&&_0x1e18bc['oauthTokenSecret']?(_0x1ad3e4['accessToken']=_0x1e18bc['oauthToken'],_0x1ad3e4['secret']=_0x1e18bc['oauthTokenSecret']):K('argument-error'),_0x1ad3e4;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2ea239){const _0xdf9864=typeof _0x2ea239=='string'?JSON['parse'](_0x2ea239):_0x2ea239,{providerId:_0x2f6ef8,signInMethod:_0x2b3f9d,..._0x413d0b}=_0xdf9864;if(!_0x2f6ef8||!_0x2b3f9d)return null;const _0x2b4e02=new We(_0x2f6ef8,_0x2b3f9d);return _0x2b4e02['idToken']=_0x413d0b['idToken']||void 0x0,_0x2b4e02['accessToken']=_0x413d0b['accessToken']||void 0x0,_0x2b4e02['secret']=_0x413d0b['secret'],_0x2b4e02['nonce']=_0x413d0b['nonce'],_0x2b4e02['pendingToken']=_0x413d0b['pendingToken']||null,_0x2b4e02;}['_getIdTokenResponse'](_0x10a089){const _0x55a1ea=this['buildRequest']();return Ze(_0x10a089,_0x55a1ea);}['_linkToIdToken'](_0x40c1bf,_0x4513d9){const _0x4b605d=this['buildRequest']();return _0x4b605d['idToken']=_0x4513d9,Ze(_0x40c1bf,_0x4b605d);}['_getReauthenticationResolver'](_0x37438a){const _0x25ddad=this['buildRequest']();return _0x25ddad['autoCreate']=!0x1,Ze(_0x37438a,_0x25ddad);}['buildRequest'](){const _0x52b1c2={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x52b1c2['pendingToken']=this['pendingToken'];else{const _0x4700b4={};this['idToken']&&(_0x4700b4['id_token']=this['idToken']),this['accessToken']&&(_0x4700b4['access_token']=this['accessToken']),this['secret']&&(_0x4700b4['oauth_token_secret']=this['secret']),_0x4700b4['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4700b4['nonce']=this['nonce']),_0x52b1c2['postBody']=at(_0x4700b4);}return _0x52b1c2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x5d676e){switch(_0x5d676e){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x2fe821){const _0x1ebe79=yt(vt(_0x2fe821))['link'],_0x3915cb=_0x1ebe79?yt(vt(_0x1ebe79))['deep_link_id']:null,_0x3bd8ef=yt(vt(_0x2fe821))['deep_link_id'];return(_0x3bd8ef?yt(vt(_0x3bd8ef))['link']:null)||_0x3bd8ef||_0x3915cb||_0x1ebe79||_0x2fe821;}class Ss{constructor(_0x32963e){const _0x5f1cdc=yt(vt(_0x32963e)),_0x13880e=_0x5f1cdc['apiKey']??null,_0x3d8bf1=_0x5f1cdc['oobCode']??null,_0x5dcc42=Gf(_0x5f1cdc['mode']??null);m(_0x13880e&&_0x3d8bf1&&_0x5dcc42,'argument-error'),this['apiKey']=_0x13880e,this['operation']=_0x5dcc42,this['code']=_0x3d8bf1,this['continueUrl']=_0x5f1cdc['continueUrl']??null,this['languageCode']=_0x5f1cdc['lang']??null,this['tenantId']=_0x5f1cdc['tenantId']??null;}static['parseLink'](_0x487bab){const _0x43e8ee=qf(_0x487bab);try{return new Ss(_0x43e8ee);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x259d43,_0x2e0f8c){return Ft['_fromEmailAndPassword'](_0x259d43,_0x2e0f8c);}static['credentialWithLink'](_0xadd8c6,_0x205597){const _0x540624=Ss['parseLink'](_0x205597);return m(_0x540624,'argument-error'),Ft['_fromEmailAndCode'](_0xadd8c6,_0x540624['code'],_0x540624['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x300c9c){this['providerId']=_0x300c9c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x56cf18){this['defaultLanguageCode']=_0x56cf18;}['setCustomParameters'](_0x2dc711){return this['customParameters']=_0x2dc711,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x360d82){return this['scopes']['includes'](_0x360d82)||this['scopes']['push'](_0x360d82),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x4fec43){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4fec43});}static['credentialFromResult'](_0x460d36){return he['credentialFromTaggedObject'](_0x460d36);}static['credentialFromError'](_0x11607d){return he['credentialFromTaggedObject'](_0x11607d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x42f36b}){if(!_0x42f36b||!('oauthAccessToken'in _0x42f36b)||!_0x42f36b['oauthAccessToken'])return null;try{return he['credential'](_0x42f36b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2f1eea,_0x568596){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2f1eea,'accessToken':_0x568596});}static['credentialFromResult'](_0x3f62af){return ue['credentialFromTaggedObject'](_0x3f62af);}static['credentialFromError'](_0x39f963){return ue['credentialFromTaggedObject'](_0x39f963['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ff7d2}){if(!_0x1ff7d2)return null;const {oauthIdToken:_0x50a6a6,oauthAccessToken:_0x4ea8fc}=_0x1ff7d2;if(!_0x50a6a6&&!_0x4ea8fc)return null;try{return ue['credential'](_0x50a6a6,_0x4ea8fc);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0xfc992a){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xfc992a});}static['credentialFromResult'](_0x3913fe){return de['credentialFromTaggedObject'](_0x3913fe);}static['credentialFromError'](_0x4c1de2){return de['credentialFromTaggedObject'](_0x4c1de2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x26673e}){if(!_0x26673e||!('oauthAccessToken'in _0x26673e)||!_0x26673e['oauthAccessToken'])return null;try{return de['credential'](_0x26673e['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x13574d,_0x302264){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x13574d,'oauthTokenSecret':_0x302264});}static['credentialFromResult'](_0x3c4059){return fe['credentialFromTaggedObject'](_0x3c4059);}static['credentialFromError'](_0x3d44c8){return fe['credentialFromTaggedObject'](_0x3d44c8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x407f7e}){if(!_0x407f7e)return null;const {oauthAccessToken:_0x5448aa,oauthTokenSecret:_0x2bd4ea}=_0x407f7e;if(!_0x5448aa||!_0x2bd4ea)return null;try{return fe['credential'](_0x5448aa,_0x2bd4ea);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0xb8f8e6,_0x27b00c){return Yt(_0xb8f8e6,'POST','/v1/accounts:signUp',Re(_0xb8f8e6,_0x27b00c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x22503d){this['user']=_0x22503d['user'],this['providerId']=_0x22503d['providerId'],this['_tokenResponse']=_0x22503d['_tokenResponse'],this['operationType']=_0x22503d['operationType'];}static async['_fromIdTokenResponse'](_0x355008,_0x9d848b,_0x52408d,_0x522b39=!0x1){const _0x2e9b7d=await z['_fromIdTokenResponse'](_0x355008,_0x52408d,_0x522b39),_0x2298ef=Ar(_0x52408d);return new Be({'user':_0x2e9b7d,'providerId':_0x2298ef,'_tokenResponse':_0x52408d,'operationType':_0x9d848b});}static async['_forOperation'](_0x59635b,_0x1dba5a,_0x4ba8a1){await _0x59635b['_updateTokensIfNecessary'](_0x4ba8a1,!0x0);const _0x5ae12b=Ar(_0x4ba8a1);return new Be({'user':_0x59635b,'providerId':_0x5ae12b,'_tokenResponse':_0x4ba8a1,'operationType':_0x1dba5a});}}function Ar(_0x265c43){return _0x265c43['providerId']?_0x265c43['providerId']:'phoneNumber'in _0x265c43?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x415f36,_0x4ef525,_0x1932bc,_0x3af52e){super(_0x4ef525['code'],_0x4ef525['message']),this['operationType']=_0x1932bc,this['user']=_0x3af52e,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x415f36['name'],'tenantId':_0x415f36['tenantId']??void 0x0,'_serverResponse':_0x4ef525['customData']['_serverResponse'],'operationType':_0x1932bc};}static['_fromErrorAndOperation'](_0x4c539e,_0x2a7590,_0x2a0b15,_0x30cfcf){return new Rn(_0x4c539e,_0x2a7590,_0x2a0b15,_0x30cfcf);}}function Fa(_0x13fcad,_0x39ea46,_0x374174,_0x2cdf4e){return(_0x39ea46==='reauthenticate'?_0x374174['_getReauthenticationResolver'](_0x13fcad):_0x374174['_getIdTokenResponse'](_0x13fcad))['catch'](_0x3e3b66=>{throw _0x3e3b66['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x13fcad,_0x3e3b66,_0x39ea46,_0x2cdf4e):_0x3e3b66;});}async function jf(_0x23553e,_0x5d90b1,_0x56e4c7=!0x1){const _0x30b71e=await xt(_0x23553e,_0x5d90b1['_linkToIdToken'](_0x23553e['auth'],await _0x23553e['getIdToken']()),_0x56e4c7);return Be['_forOperation'](_0x23553e,'link',_0x30b71e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3d5d06,_0x30279c,_0x4a8638=!0x1){const {auth:_0x1c082a}=_0x3d5d06;if(H(_0x1c082a['app']))return Promise['reject'](se(_0x1c082a));const _0x2c466c='reauthenticate';try{const _0x4fd378=await xt(_0x3d5d06,Fa(_0x1c082a,_0x2c466c,_0x30279c,_0x3d5d06),_0x4a8638);m(_0x4fd378['idToken'],_0x1c082a,'internal-error');const _0x163701=ws(_0x4fd378['idToken']);m(_0x163701,_0x1c082a,'internal-error');const {sub:_0x1797c}=_0x163701;return m(_0x3d5d06['uid']===_0x1797c,_0x1c082a,'user-mismatch'),Be['_forOperation'](_0x3d5d06,_0x2c466c,_0x4fd378);}catch(_0x21357a){throw(_0x21357a==null?void 0x0:_0x21357a['code'])==='auth/user-not-found'&&K(_0x1c082a,'user-mismatch'),_0x21357a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x12fe82,_0x14816d,_0x272cea=!0x1){if(H(_0x12fe82['app']))return Promise['reject'](se(_0x12fe82));const _0x3d4aad='signIn',_0x297081=await Fa(_0x12fe82,_0x3d4aad,_0x14816d),_0x3f287d=await Be['_fromIdTokenResponse'](_0x12fe82,_0x3d4aad,_0x297081);return _0x272cea||await _0x12fe82['_updateCurrentUser'](_0x3f287d['user']),_0x3f287d;}async function Yf(_0x35e4d3,_0xf4ade0){return Ua(qe(_0x35e4d3),_0xf4ade0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2787c2){const _0x2f5b89=qe(_0x2787c2);_0x2f5b89['_getPasswordPolicyInternal']()&&await _0x2f5b89['_updatePasswordPolicy']();}async function R_(_0x303dec,_0xafc91f,_0x50fd49){if(H(_0x303dec['app']))return Promise['reject'](se(_0x303dec));const _0x1a5c8b=qe(_0x303dec),_0x2b3b0a=await Oi(_0x1a5c8b,{'returnSecureToken':!0x0,'email':_0xafc91f,'password':_0x50fd49,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x19765c=>{throw _0x19765c['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x303dec),_0x19765c;}),_0x283f55=await Be['_fromIdTokenResponse'](_0x1a5c8b,'signIn',_0x2b3b0a);return await _0x1a5c8b['_updateCurrentUser'](_0x283f55['user']),_0x283f55;}function A_(_0x52200d,_0x1e94ce,_0xb8c4c2){return H(_0x52200d['app'])?Promise['reject'](se(_0x52200d)):Yf(k(_0x52200d),ft['credential'](_0x1e94ce,_0xb8c4c2))['catch'](async _0x26180f=>{throw _0x26180f['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x52200d),_0x26180f;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5eddea,_0x3bf289){return k(_0x5eddea)['setPersistence'](_0x3bf289);}function Qf(_0x48f015,_0x4f2fcb,_0x4f003a,_0x20e858){return k(_0x48f015)['onIdTokenChanged'](_0x4f2fcb,_0x4f003a,_0x20e858);}function Jf(_0x4c6d71,_0x5e0eb5,_0xc536d7){return k(_0x4c6d71)['beforeAuthStateChanged'](_0x5e0eb5,_0xc536d7);}function N_(_0x542688,_0x30ca4d,_0x2d71f5,_0x482dcd){return k(_0x542688)['onAuthStateChanged'](_0x30ca4d,_0x2d71f5,_0x482dcd);}function P_(_0x234308){return k(_0x234308)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x462879,_0x1dacde){this['storageRetriever']=_0x462879,this['type']=_0x1dacde;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x361931,_0x464a64){return this['storage']['setItem'](_0x361931,JSON['stringify'](_0x464a64)),Promise['resolve']();}['_get'](_0xb5ce80){const _0x488844=this['storage']['getItem'](_0xb5ce80);return Promise['resolve'](_0x488844?JSON['parse'](_0x488844):null);}['_remove'](_0x46eb44){return this['storage']['removeItem'](_0x46eb44),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x29687f,_0x50430f)=>this['onStorageEvent'](_0x29687f,_0x50430f),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1b5efb){for(const _0x1a93f2 of Object['keys'](this['listeners'])){const _0x3394d0=this['storage']['getItem'](_0x1a93f2),_0xcc4162=this['localCache'][_0x1a93f2];_0x3394d0!==_0xcc4162&&_0x1b5efb(_0x1a93f2,_0xcc4162,_0x3394d0);}}['onStorageEvent'](_0x5c7e24,_0x15a91a=!0x1){if(!_0x5c7e24['key']){this['forAllChangedKeys']((_0x399d57,_0x25d348,_0x5a5117)=>{this['notifyListeners'](_0x399d57,_0x5a5117);});return;}const _0x5de8db=_0x5c7e24['key'];_0x15a91a?this['detachListener']():this['stopPolling']();const _0x306087=()=>{const _0xe0c62d=this['storage']['getItem'](_0x5de8db);!_0x15a91a&&this['localCache'][_0x5de8db]===_0xe0c62d||this['notifyListeners'](_0x5de8db,_0xe0c62d);},_0xc7d114=this['storage']['getItem'](_0x5de8db);If()&&_0xc7d114!==_0x5c7e24['newValue']&&_0x5c7e24['newValue']!==_0x5c7e24['oldValue']?setTimeout(_0x306087,Zf):_0x306087();}['notifyListeners'](_0x58a0d5,_0x56c284){this['localCache'][_0x58a0d5]=_0x56c284;const _0x4587a0=this['listeners'][_0x58a0d5];if(_0x4587a0){for(const _0xf8918a of Array['from'](_0x4587a0))_0xf8918a(_0x56c284&&JSON['parse'](_0x56c284));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1b6364,_0x422376,_0x2bd968)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1b6364,'oldValue':_0x422376,'newValue':_0x2bd968}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x527e53,_0x4cee47){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x527e53]||(this['listeners'][_0x527e53]=new Set(),this['localCache'][_0x527e53]=this['storage']['getItem'](_0x527e53)),this['listeners'][_0x527e53]['add'](_0x4cee47);}['_removeListener'](_0x30d70c,_0x52d678){this['listeners'][_0x30d70c]&&(this['listeners'][_0x30d70c]['delete'](_0x52d678),this['listeners'][_0x30d70c]['size']===0x0&&delete this['listeners'][_0x30d70c]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1dd794,_0x434536){await super['_set'](_0x1dd794,_0x434536),this['localCache'][_0x1dd794]=JSON['stringify'](_0x434536);}async['_get'](_0x8b2177){const _0x31320d=await super['_get'](_0x8b2177);return this['localCache'][_0x8b2177]=JSON['stringify'](_0x31320d),_0x31320d;}async['_remove'](_0x2df4ea){await super['_remove'](_0x2df4ea),delete this['localCache'][_0x2df4ea];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x32b319,_0x373571){}['_removeListener'](_0x3aaf67,_0x101c7e){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x38a633){return Promise['all'](_0x38a633['map'](async _0x450561=>{try{return{'fulfilled':!0x0,'value':await _0x450561};}catch(_0x1a9a90){return{'fulfilled':!0x1,'reason':_0x1a9a90};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x44ad65){this['eventTarget']=_0x44ad65,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x57ed7c){const _0x49a483=this['receivers']['find'](_0x7f11ce=>_0x7f11ce['isListeningto'](_0x57ed7c));if(_0x49a483)return _0x49a483;const _0xb47a6b=new jn(_0x57ed7c);return this['receivers']['push'](_0xb47a6b),_0xb47a6b;}['isListeningto'](_0x3893eb){return this['eventTarget']===_0x3893eb;}async['handleEvent'](_0x5f9476){const _0x330b8d=_0x5f9476,{eventId:_0x2a16d8,eventType:_0x3a6571,data:_0x2bea4d}=_0x330b8d['data'],_0x5f56d6=this['handlersMap'][_0x3a6571];if(!(_0x5f56d6!=null&&_0x5f56d6['size']))return;_0x330b8d['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2a16d8,'eventType':_0x3a6571});const _0x4ecdba=Array['from'](_0x5f56d6)['map'](async _0x13d798=>_0x13d798(_0x330b8d['origin'],_0x2bea4d)),_0x19b97c=await tp(_0x4ecdba);_0x330b8d['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2a16d8,'eventType':_0x3a6571,'response':_0x19b97c});}['_subscribe'](_0x1dd44b,_0x5150d1){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1dd44b]||(this['handlersMap'][_0x1dd44b]=new Set()),this['handlersMap'][_0x1dd44b]['add'](_0x5150d1);}['_unsubscribe'](_0x2be0a4,_0x733378){this['handlersMap'][_0x2be0a4]&&_0x733378&&this['handlersMap'][_0x2be0a4]['delete'](_0x733378),(!_0x733378||this['handlersMap'][_0x2be0a4]['size']===0x0)&&delete this['handlersMap'][_0x2be0a4],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0xa5758c='',_0x494de1=0xa){let _0x55e737='';for(let _0xf4164d=0x0;_0xf4164d<_0x494de1;_0xf4164d++)_0x55e737+=Math['floor'](Math['random']()*0xa);return _0xa5758c+_0x55e737;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x3feca0){this['target']=_0x3feca0,this['handlers']=new Set();}['removeMessageHandler'](_0x4d765e){_0x4d765e['messageChannel']&&(_0x4d765e['messageChannel']['port1']['removeEventListener']('message',_0x4d765e['onMessage']),_0x4d765e['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4d765e);}async['_send'](_0x50788b,_0x2dfd08,_0x17fb2e=0x32){const _0x5b3eda=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x5b3eda)throw new Error('connection_unavailable');let _0x3c4254,_0x577c25;return new Promise((_0x5a21ff,_0x36ad06)=>{const _0x3e9ee6=bs('',0x14);_0x5b3eda['port1']['start']();const _0x2a4d8b=setTimeout(()=>{_0x36ad06(new Error('unsupported_event'));},_0x17fb2e);_0x577c25={'messageChannel':_0x5b3eda,'onMessage'(_0x1dcb35){const _0x2caf57=_0x1dcb35;if(_0x2caf57['data']['eventId']===_0x3e9ee6)switch(_0x2caf57['data']['status']){case'ack':clearTimeout(_0x2a4d8b),_0x3c4254=setTimeout(()=>{_0x36ad06(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3c4254),_0x5a21ff(_0x2caf57['data']['response']);break;default:clearTimeout(_0x2a4d8b),clearTimeout(_0x3c4254),_0x36ad06(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x577c25),_0x5b3eda['port1']['addEventListener']('message',_0x577c25['onMessage']),this['target']['postMessage']({'eventType':_0x50788b,'eventId':_0x3e9ee6,'data':_0x2dfd08},[_0x5b3eda['port2']]);})['finally'](()=>{_0x577c25&&this['removeMessageHandler'](_0x577c25);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x146228){X()['location']['href']=_0x146228;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x32cc9e;return((_0x32cc9e=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x32cc9e['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x4f2637){this['request']=_0x4f2637;}['toPromise'](){return new Promise((_0x1ede77,_0x4ca9f4)=>{this['request']['addEventListener']('success',()=>{_0x1ede77(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4ca9f4(this['request']['error']);});});}}function Kn(_0x70e4fc,_0x2cad4e){return _0x70e4fc['transaction']([kn],_0x2cad4e?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3e1811=indexedDB['deleteDatabase'](qa);return new Jt(_0x3e1811)['toPromise']();}function ja(){const _0x129658=indexedDB['open'](qa,ap);return new Promise((_0x2bccab,_0x3239f5)=>{_0x129658['addEventListener']('error',()=>{_0x3239f5(_0x129658['error']);}),_0x129658['addEventListener']('upgradeneeded',()=>{const _0x1479bf=_0x129658['result'];try{_0x1479bf['createObjectStore'](kn,{'keyPath':za});}catch(_0x46dd0c){_0x3239f5(_0x46dd0c);}}),_0x129658['addEventListener']('success',async()=>{const _0x35df6b=_0x129658['result'];_0x35df6b['objectStoreNames']['contains'](kn)?_0x2bccab(_0x35df6b):(_0x35df6b['close'](),await cp(),_0x2bccab(await ja()));});});}async function kr(_0x2dac51,_0x525bbc,_0x51355c){const _0x19e95f=Kn(_0x2dac51,!0x0)['put']({[za]:_0x525bbc,'value':_0x51355c});return new Jt(_0x19e95f)['toPromise']();}async function lp(_0x54aabf,_0x1f563d){const _0x3cc89b=Kn(_0x54aabf,!0x1)['get'](_0x1f563d),_0x14f886=await new Jt(_0x3cc89b)['toPromise']();return _0x14f886===void 0x0?null:_0x14f886['value'];}function Nr(_0x22a91d,_0x1e5806){const _0x4ce479=Kn(_0x22a91d,!0x0)['delete'](_0x1e5806);return new Jt(_0x4ce479)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3adf3a){let _0x8409e8=0x0;for(;;)try{const _0x14b047=await this['_openDb']();return await _0x3adf3a(_0x14b047);}catch(_0xb23a7b){if(_0x8409e8++>up)throw _0xb23a7b;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x17da37,_0x3ce8b9)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3ce8b9['key'])})),this['receiver']['_subscribe']('ping',async(_0x25a4bb,_0x394cb0)=>['keyChanged']);}async['initializeSender'](){var _0x2f1c45,_0x575029;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x332c2c=await this['sender']['_send']('ping',{},0x320);_0x332c2c&&(_0x2f1c45=_0x332c2c[0x0])!=null&&_0x2f1c45['fulfilled']&&(_0x575029=_0x332c2c[0x0])!=null&&_0x575029['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x232b09){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x232b09},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x92b15c=>{await kr(_0x92b15c,An,'1'),await Nr(_0x92b15c,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x22828a){this['pendingWrites']++;try{await _0x22828a();}finally{this['pendingWrites']--;}}async['_set'](_0x2e0a64,_0x18c4e9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5b4a7d=>kr(_0x5b4a7d,_0x2e0a64,_0x18c4e9)),this['localCache'][_0x2e0a64]=_0x18c4e9,this['notifyServiceWorker'](_0x2e0a64)));}async['_get'](_0x3ed60c){const _0x4ec012=await this['_withRetries'](_0x431483=>lp(_0x431483,_0x3ed60c));return this['localCache'][_0x3ed60c]=_0x4ec012,_0x4ec012;}async['_remove'](_0x1f1ec8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1f878f=>Nr(_0x1f878f,_0x1f1ec8)),delete this['localCache'][_0x1f1ec8],this['notifyServiceWorker'](_0x1f1ec8)));}async['_poll'](){const _0x4e937b=await this['_withRetries'](_0x393ce3=>{const _0x140675=Kn(_0x393ce3,!0x1)['getAll']();return new Jt(_0x140675)['toPromise']();});if(!_0x4e937b)return[];if(this['pendingWrites']!==0x0)return[];const _0x30daba=[],_0x4773b2=new Set();if(_0x4e937b['length']!==0x0){for(const {fbase_key:_0x571af3,value:_0x263d0b}of _0x4e937b)_0x4773b2['add'](_0x571af3),JSON['stringify'](this['localCache'][_0x571af3])!==JSON['stringify'](_0x263d0b)&&(this['notifyListeners'](_0x571af3,_0x263d0b),_0x30daba['push'](_0x571af3));}for(const _0x7cbcd6 of Object['keys'](this['localCache']))this['localCache'][_0x7cbcd6]&&!_0x4773b2['has'](_0x7cbcd6)&&(this['notifyListeners'](_0x7cbcd6,null),_0x30daba['push'](_0x7cbcd6));return _0x30daba;}['notifyListeners'](_0x3e0ff6,_0x43a076){this['localCache'][_0x3e0ff6]=_0x43a076;const _0x223a9a=this['listeners'][_0x3e0ff6];if(_0x223a9a){for(const _0x564013 of Array['from'](_0x223a9a))_0x564013(_0x43a076);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x265e0f,_0x48ca24){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x265e0f]||(this['listeners'][_0x265e0f]=new Set(),this['_get'](_0x265e0f)),this['listeners'][_0x265e0f]['add'](_0x48ca24);}['_removeListener'](_0x1e2f7c,_0x53bf1a){this['listeners'][_0x1e2f7c]&&(this['listeners'][_0x1e2f7c]['delete'](_0x53bf1a),this['listeners'][_0x1e2f7c]['size']===0x0&&delete this['listeners'][_0x1e2f7c]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x178fe0,_0x32ffcf){return _0x32ffcf?ne(_0x32ffcf):(m(_0x178fe0['_popupRedirectResolver'],_0x178fe0,'argument-error'),_0x178fe0['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x4fe1a5){super('custom','custom'),this['params']=_0x4fe1a5;}['_getIdTokenResponse'](_0x46b500){return Ze(_0x46b500,this['_buildIdpRequest']());}['_linkToIdToken'](_0x9c23b8,_0x58d960){return Ze(_0x9c23b8,this['_buildIdpRequest'](_0x58d960));}['_getReauthenticationResolver'](_0x536b5e){return Ze(_0x536b5e,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x42e437){const _0x5a140c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x42e437&&(_0x5a140c['idToken']=_0x42e437),_0x5a140c;}}function pp(_0x499a71){return Ua(_0x499a71['auth'],new Rs(_0x499a71),_0x499a71['bypassAuthState']);}function _p(_0xaab769){const {auth:_0x44bf92,user:_0xb7638b}=_0xaab769;return m(_0xb7638b,_0x44bf92,'internal-error'),Kf(_0xb7638b,new Rs(_0xaab769),_0xaab769['bypassAuthState']);}async function gp(_0x22dbc2){const {auth:_0x52cde8,user:_0x40a27a}=_0x22dbc2;return m(_0x40a27a,_0x52cde8,'internal-error'),jf(_0x40a27a,new Rs(_0x22dbc2),_0x22dbc2['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x4848da,_0x597dfa,_0x4ae28a,_0x345931,_0x5b6488=!0x1){this['auth']=_0x4848da,this['resolver']=_0x4ae28a,this['user']=_0x345931,this['bypassAuthState']=_0x5b6488,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x597dfa)?_0x597dfa:[_0x597dfa];}['execute'](){return new Promise(async(_0x404382,_0x4a28ad)=>{this['pendingPromise']={'resolve':_0x404382,'reject':_0x4a28ad};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x17fdc4){this['reject'](_0x17fdc4);}});}async['onAuthEvent'](_0x863450){const {urlResponse:_0xc1767d,sessionId:_0x18f2e9,postBody:_0x2ec0f9,tenantId:_0x12e3e0,error:_0x411fc8,type:_0x3dc44c}=_0x863450;if(_0x411fc8){this['reject'](_0x411fc8);return;}const _0xeae1ca={'auth':this['auth'],'requestUri':_0xc1767d,'sessionId':_0x18f2e9,'tenantId':_0x12e3e0||void 0x0,'postBody':_0x2ec0f9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3dc44c)(_0xeae1ca));}catch(_0x1e063b){this['reject'](_0x1e063b);}}['onError'](_0x168cdd){this['reject'](_0x168cdd);}['getIdpTask'](_0x183927){switch(_0x183927){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x206e9e){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x206e9e),this['unregisterAndCleanUp']();}['reject'](_0x31c0fc){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x31c0fc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0xa7d9f8,_0x3dbf7a,_0x171359,_0x13ec49,_0x3ae19e){super(_0xa7d9f8,_0x3dbf7a,_0x13ec49,_0x3ae19e),this['provider']=_0x171359,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x2bd4c8=await this['execute']();return m(_0x2bd4c8,this['auth'],'internal-error'),_0x2bd4c8;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x220533=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x220533),this['authWindow']['associatedEvent']=_0x220533,this['resolver']['_originValidation'](this['auth'])['catch'](_0x32ce6d=>{this['reject'](_0x32ce6d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x215609=>{_0x215609||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x313802;return((_0x313802=this['authWindow'])==null?void 0x0:_0x313802['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x28f844=()=>{var _0x36e03e,_0x4b502a;if((_0x4b502a=(_0x36e03e=this['authWindow'])==null?void 0x0:_0x36e03e['window'])!=null&&_0x4b502a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x28f844,mp['get']());};_0x28f844();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x99aca,_0x269aca,_0x34cc64=!0x1){super(_0x99aca,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x269aca,void 0x0,_0x34cc64),this['eventId']=null;}async['execute'](){let _0x28d9d3=rn['get'](this['auth']['_key']());if(!_0x28d9d3){try{const _0x4d7731=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x28d9d3=()=>Promise['resolve'](_0x4d7731);}catch(_0x450c06){_0x28d9d3=()=>Promise['reject'](_0x450c06);}rn['set'](this['auth']['_key'](),_0x28d9d3);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x28d9d3();}async['onAuthEvent'](_0x57f5fb){if(_0x57f5fb['type']==='signInViaRedirect')return super['onAuthEvent'](_0x57f5fb);if(_0x57f5fb['type']==='unknown'){this['resolve'](null);return;}if(_0x57f5fb['eventId']){const _0x29f08f=await this['auth']['_redirectUserForId'](_0x57f5fb['eventId']);if(_0x29f08f)return this['user']=_0x29f08f,super['onAuthEvent'](_0x57f5fb);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xbfbc48,_0x119d06){const _0x3305ec=Cp(_0x119d06),_0x1dbcce=wp(_0xbfbc48);if(!await _0x1dbcce['_isAvailable']())return!0x1;const _0x169638=await _0x1dbcce['_get'](_0x3305ec)==='true';return await _0x1dbcce['_remove'](_0x3305ec),_0x169638;}function Ip(_0x4b5c57,_0x51b0a4){rn['set'](_0x4b5c57['_key'](),_0x51b0a4);}function wp(_0x23ec59){return ne(_0x23ec59['_redirectPersistence']);}function Cp(_0x560cc1){return sn(yp,_0x560cc1['config']['apiKey'],_0x560cc1['name']);}async function Tp(_0x39639e,_0x2b243f,_0x2a7d0b=!0x1){if(H(_0x39639e['app']))return Promise['reject'](se(_0x39639e));const _0x2f53cf=qe(_0x39639e),_0x25b203=fp(_0x2f53cf,_0x2b243f),_0x33e522=await new vp(_0x2f53cf,_0x25b203,_0x2a7d0b)['execute']();return _0x33e522&&!_0x2a7d0b&&(delete _0x33e522['user']['_redirectEventId'],await _0x2f53cf['_persistUserIfCurrent'](_0x33e522['user']),await _0x2f53cf['_setRedirectUser'](null,_0x2b243f)),_0x33e522;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x1d1c6d){this['auth']=_0x1d1c6d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x33afa3){this['consumers']['add'](_0x33afa3),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x33afa3)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x33afa3),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x144ad9){this['consumers']['delete'](_0x144ad9);}['onEvent'](_0x474221){if(this['hasEventBeenHandled'](_0x474221))return!0x1;let _0x24b485=!0x1;return this['consumers']['forEach'](_0x2a8019=>{this['isEventForConsumer'](_0x474221,_0x2a8019)&&(_0x24b485=!0x0,this['sendToConsumer'](_0x474221,_0x2a8019),this['saveEventToCache'](_0x474221));}),this['hasHandledPotentialRedirect']||!Rp(_0x474221)||(this['hasHandledPotentialRedirect']=!0x0,_0x24b485||(this['queuedRedirectEvent']=_0x474221,_0x24b485=!0x0)),_0x24b485;}['sendToConsumer'](_0x1b3ef2,_0x4c59ac){var _0x2bb423;if(_0x1b3ef2['error']&&!Qa(_0x1b3ef2)){const _0xd4a56a=((_0x2bb423=_0x1b3ef2['error']['code'])==null?void 0x0:_0x2bb423['split']('auth/')[0x1])||'internal-error';_0x4c59ac['onError'](J(this['auth'],_0xd4a56a));}else _0x4c59ac['onAuthEvent'](_0x1b3ef2);}['isEventForConsumer'](_0x2e6ee6,_0x59b913){const _0x294b83=_0x59b913['eventId']===null||!!_0x2e6ee6['eventId']&&_0x2e6ee6['eventId']===_0x59b913['eventId'];return _0x59b913['filter']['includes'](_0x2e6ee6['type'])&&_0x294b83;}['hasEventBeenHandled'](_0x5ae16e){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x5ae16e));}['saveEventToCache'](_0x515c20){this['cachedEventUids']['add'](Pr(_0x515c20)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x48a2d8){return[_0x48a2d8['type'],_0x48a2d8['eventId'],_0x48a2d8['sessionId'],_0x48a2d8['tenantId']]['filter'](_0x1c201d=>_0x1c201d)['join']('-');}function Qa({type:_0x25f426,error:_0x565cfd}){return _0x25f426==='unknown'&&(_0x565cfd==null?void 0x0:_0x565cfd['code'])==='auth/no-auth-event';}function Rp(_0x3c86a4){switch(_0x3c86a4['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3c86a4);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x2d749d,_0xf292eb={}){return Ae(_0x2d749d,'GET','/v1/projects',_0xf292eb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5f4b5b){if(_0x5f4b5b['config']['emulator'])return;const {authorizedDomains:_0x4c56c0}=await Ap(_0x5f4b5b);for(const _0x293b11 of _0x4c56c0)try{if(Op(_0x293b11))return;}catch{}K(_0x5f4b5b,'unauthorized-domain');}function Op(_0x5135b5){const _0x2356cb=Ni(),{protocol:_0x41e182,hostname:_0x4aa8b6}=new URL(_0x2356cb);if(_0x5135b5['startsWith']('chrome-extension://')){const _0x406d97=new URL(_0x5135b5);return _0x406d97['hostname']===''&&_0x4aa8b6===''?_0x41e182==='chrome-extension:'&&_0x5135b5['replace']('chrome-extension://','')===_0x2356cb['replace']('chrome-extension://',''):_0x41e182==='chrome-extension:'&&_0x406d97['hostname']===_0x4aa8b6;}if(!Np['test'](_0x41e182))return!0x1;if(kp['test'](_0x5135b5))return _0x4aa8b6===_0x5135b5;const _0x3ab8e0=_0x5135b5['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3ab8e0+'|'+_0x3ab8e0+')$','i')['test'](_0x4aa8b6);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x634913=X()['___jsl'];if(_0x634913!=null&&_0x634913['H']){for(const _0x22a12d of Object['keys'](_0x634913['H']))if(_0x634913['H'][_0x22a12d]['r']=_0x634913['H'][_0x22a12d]['r']||[],_0x634913['H'][_0x22a12d]['L']=_0x634913['H'][_0x22a12d]['L']||[],_0x634913['H'][_0x22a12d]['r']=[..._0x634913['H'][_0x22a12d]['L']],_0x634913['CP']){for(let _0x30c11b=0x0;_0x30c11b<_0x634913['CP']['length'];_0x30c11b++)_0x634913['CP'][_0x30c11b]=null;}}}function Mp(_0x57728a){return new Promise((_0x306fd5,_0x4c2284)=>{var _0x543b30,_0x1221d6,_0xb3339d;function _0x242b10(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x306fd5(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x4c2284(J(_0x57728a,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x1221d6=(_0x543b30=X()['gapi'])==null?void 0x0:_0x543b30['iframes'])!=null&&_0x1221d6['Iframe'])_0x306fd5(gapi['iframes']['getContext']());else{if((_0xb3339d=X()['gapi'])!=null&&_0xb3339d['load'])_0x242b10();else{const _0x4cfd41=Nf('iframefcb');return X()[_0x4cfd41]=()=>{gapi['load']?_0x242b10():_0x4c2284(J(_0x57728a,'network-request-failed'));},Da(kf()+'?onload='+_0x4cfd41)['catch'](_0x3aa9b3=>_0x4c2284(_0x3aa9b3));}}})['catch'](_0x48f174=>{throw on=null,_0x48f174;});}let on=null;function Lp(_0x3c4546){return on=on||Mp(_0x3c4546),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x47d28b){const _0x310241=_0x47d28b['config'];m(_0x310241['authDomain'],_0x47d28b,'auth-domain-config-required');const _0x126700=_0x310241['emulator']?Is(_0x310241,Up):'https://'+_0x47d28b['config']['authDomain']+'/'+Fp,_0x2e67e4={'apiKey':_0x310241['apiKey'],'appName':_0x47d28b['name'],'v':ct},_0x13920e=Bp['get'](_0x47d28b['config']['apiHost']);_0x13920e&&(_0x2e67e4['eid']=_0x13920e);const _0x3c374e=_0x47d28b['_getFrameworks']();return _0x3c374e['length']&&(_0x2e67e4['fw']=_0x3c374e['join'](',')),_0x126700+'?'+at(_0x2e67e4)['slice'](0x1);}async function Hp(_0x2a98e1){const _0xd48aba=await Lp(_0x2a98e1),_0xf17ab5=X()['gapi'];return m(_0xf17ab5,_0x2a98e1,'internal-error'),_0xd48aba['open']({'where':document['body'],'url':Vp(_0x2a98e1),'messageHandlersFilter':_0xf17ab5['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x1e47c2=>new Promise(async(_0x330bae,_0x4509b2)=>{await _0x1e47c2['restyle']({'setHideOnLeave':!0x1});const _0x4ba2d7=J(_0x2a98e1,'network-request-failed'),_0x406bbd=X()['setTimeout'](()=>{_0x4509b2(_0x4ba2d7);},xp['get']());function _0x27401c(){X()['clearTimeout'](_0x406bbd),_0x330bae(_0x1e47c2);}_0x1e47c2['ping'](_0x27401c)['then'](_0x27401c,()=>{_0x4509b2(_0x4ba2d7);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x3d1195){this['window']=_0x3d1195,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0xfcb4c1,_0x2a06c4,_0x4ec070,_0x5e81cf=Gp,_0x14e21b=qp){const _0xdd258d=Math['max']((window['screen']['availHeight']-_0x14e21b)/0x2,0x0)['toString'](),_0x523c1a=Math['max']((window['screen']['availWidth']-_0x5e81cf)/0x2,0x0)['toString']();let _0xf4c19b='';const _0x2bcf72={...$p,'width':_0x5e81cf['toString'](),'height':_0x14e21b['toString'](),'top':_0xdd258d,'left':_0x523c1a},_0x618513=W()['toLowerCase']();_0x4ec070&&(_0xf4c19b=ba(_0x618513)?zp:_0x4ec070),Ta(_0x618513)&&(_0x2a06c4=_0x2a06c4||jp,_0x2bcf72['scrollbars']='yes');const _0x33300d=Object['entries'](_0x2bcf72)['reduce']((_0x4ff277,[_0x17c1c5,_0x2960ca])=>''+_0x4ff277+_0x17c1c5+'='+_0x2960ca+',','');if(Ef(_0x618513)&&_0xf4c19b!=='_self')return Yp(_0x2a06c4||'',_0xf4c19b),new Dr(null);const _0x19a087=window['open'](_0x2a06c4||'',_0xf4c19b,_0x33300d);m(_0x19a087,_0xfcb4c1,'popup-blocked');try{_0x19a087['focus']();}catch{}return new Dr(_0x19a087);}function Yp(_0x55ebbf,_0x2f58ea){const _0x20fc6b=document['createElement']('a');_0x20fc6b['href']=_0x55ebbf,_0x20fc6b['target']=_0x2f58ea;const _0x1f9232=document['createEvent']('MouseEvent');_0x1f9232['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x20fc6b['dispatchEvent'](_0x1f9232);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x2df579,_0x5669c5,_0x29a68e,_0x3a81ed,_0x370676,_0x1d1da6){m(_0x2df579['config']['authDomain'],_0x2df579,'auth-domain-config-required'),m(_0x2df579['config']['apiKey'],_0x2df579,'invalid-api-key');const _0x4d8b5f={'apiKey':_0x2df579['config']['apiKey'],'appName':_0x2df579['name'],'authType':_0x29a68e,'redirectUrl':_0x3a81ed,'v':ct,'eventId':_0x370676};if(_0x5669c5 instanceof xa){_0x5669c5['setDefaultLanguage'](_0x2df579['languageCode']),_0x4d8b5f['providerId']=_0x5669c5['providerId']||'',hi(_0x5669c5['getCustomParameters']())||(_0x4d8b5f['customParameters']=JSON['stringify'](_0x5669c5['getCustomParameters']()));for(const [_0x5cda06,_0x364062]of Object['entries']({}))_0x4d8b5f[_0x5cda06]=_0x364062;}if(_0x5669c5 instanceof Qt){const _0x5ae7e4=_0x5669c5['getScopes']()['filter'](_0x40a632=>_0x40a632!=='');_0x5ae7e4['length']>0x0&&(_0x4d8b5f['scopes']=_0x5ae7e4['join'](','));}_0x2df579['tenantId']&&(_0x4d8b5f['tid']=_0x2df579['tenantId']);const _0x3d7b55=_0x4d8b5f;for(const _0x4f9865 of Object['keys'](_0x3d7b55))_0x3d7b55[_0x4f9865]===void 0x0&&delete _0x3d7b55[_0x4f9865];const _0x445dc1=await _0x2df579['_getAppCheckToken'](),_0x4c55bd=_0x445dc1?'#'+Xp+'='+encodeURIComponent(_0x445dc1):'';return Zp(_0x2df579)+'?'+at(_0x3d7b55)['slice'](0x1)+_0x4c55bd;}function Zp({config:_0x13b0d1}){return _0x13b0d1['emulator']?Is(_0x13b0d1,Jp):'https://'+_0x13b0d1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x2ef293,_0x5e1e79,_0x14ba57,_0x226852){var _0x28835c;ae((_0x28835c=this['eventManagers'][_0x2ef293['_key']()])==null?void 0x0:_0x28835c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3712f3=await Mr(_0x2ef293,_0x5e1e79,_0x14ba57,Ni(),_0x226852);return Kp(_0x2ef293,_0x3712f3,bs());}async['_openRedirect'](_0x4646b5,_0x53fcfe,_0x5166c1,_0x3ffb33){await this['_originValidation'](_0x4646b5);const _0x3fac2b=await Mr(_0x4646b5,_0x53fcfe,_0x5166c1,Ni(),_0x3ffb33);return ip(_0x3fac2b),new Promise(()=>{});}['_initialize'](_0x31806a){const _0x189e24=_0x31806a['_key']();if(this['eventManagers'][_0x189e24]){const {manager:_0x1a19c0,promise:_0x31aca7}=this['eventManagers'][_0x189e24];return _0x1a19c0?Promise['resolve'](_0x1a19c0):(ae(_0x31aca7,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x31aca7);}const _0x1641c4=this['initAndGetManager'](_0x31806a);return this['eventManagers'][_0x189e24]={'promise':_0x1641c4},_0x1641c4['catch'](()=>{delete this['eventManagers'][_0x189e24];}),_0x1641c4;}async['initAndGetManager'](_0x61c0ab){const _0x48603a=await Hp(_0x61c0ab),_0x5c7786=new bp(_0x61c0ab);return _0x48603a['register']('authEvent',_0x49bcfc=>(m(_0x49bcfc==null?void 0x0:_0x49bcfc['authEvent'],_0x61c0ab,'invalid-auth-event'),{'status':_0x5c7786['onEvent'](_0x49bcfc['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x61c0ab['_key']()]={'manager':_0x5c7786},this['iframes'][_0x61c0ab['_key']()]=_0x48603a,_0x5c7786;}['_isIframeWebStorageSupported'](_0x367ce4,_0x7382d4){this['iframes'][_0x367ce4['_key']()]['send'](li,{'type':li},_0x4d7129=>{var _0x49f696;const _0x20273c=(_0x49f696=_0x4d7129==null?void 0x0:_0x4d7129[0x0])==null?void 0x0:_0x49f696[li];_0x20273c!==void 0x0&&_0x7382d4(!!_0x20273c),K(_0x367ce4,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2856c9){const _0x485db3=_0x2856c9['_key']();return this['originValidationPromises'][_0x485db3]||(this['originValidationPromises'][_0x485db3]=Pp(_0x2856c9)),this['originValidationPromises'][_0x485db3];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x3cfb0a){this['auth']=_0x3cfb0a,this['internalListeners']=new Map();}['getUid'](){var _0x349170;return this['assertAuthConfigured'](),((_0x349170=this['auth']['currentUser'])==null?void 0x0:_0x349170['uid'])||null;}async['getToken'](_0x22d686){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x22d686)}:null;}['addAuthTokenListener'](_0xe8a5a3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xe8a5a3))return;const _0x190bfd=this['auth']['onIdTokenChanged'](_0x142e6b=>{_0xe8a5a3((_0x142e6b==null?void 0x0:_0x142e6b['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xe8a5a3,_0x190bfd),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x43e5a4){this['assertAuthConfigured']();const _0x2ed18c=this['internalListeners']['get'](_0x43e5a4);_0x2ed18c&&(this['internalListeners']['delete'](_0x43e5a4),_0x2ed18c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x16e778){switch(_0x16e778){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x1bb1a3){et(new Me('auth',(_0x569a74,{options:_0x5033c0})=>{const _0x11aecd=_0x569a74['getProvider']('app')['getImmediate'](),_0x484452=_0x569a74['getProvider']('heartbeat'),_0x95d2=_0x569a74['getProvider']('app-check-internal'),{apiKey:_0xf6b23d,authDomain:_0x23cd59}=_0x11aecd['options'];m(_0xf6b23d&&!_0xf6b23d['includes'](':'),'invalid-api-key',{'appName':_0x11aecd['name']});const _0x5d91a4={'apiKey':_0xf6b23d,'authDomain':_0x23cd59,'clientPlatform':_0x1bb1a3,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x1bb1a3)},_0x27ed97=new bf(_0x11aecd,_0x484452,_0x95d2,_0x5d91a4);return Lf(_0x27ed97,_0x5033c0),_0x27ed97;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x27d077,_0x18f7a5,_0x3dcd98)=>{_0x27d077['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x5dc296=>{const _0x32e6bc=qe(_0x5dc296['getProvider']('auth')['getImmediate']());return(_0x3d51bc=>new n_(_0x3d51bc))(_0x32e6bc);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x1bb1a3)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x3610e9=>async _0x570b37=>{const _0x72b66f=_0x570b37&&await _0x570b37['getIdTokenResult'](),_0x5a6f6b=_0x72b66f&&(new Date()['getTime']()-Date['parse'](_0x72b66f['issuedAtTime']))/0x3e8;if(_0x5a6f6b&&_0x5a6f6b>o_)return;const _0x1d1f27=_0x72b66f==null?void 0x0:_0x72b66f['token'];Fr!==_0x1d1f27&&(Fr=_0x1d1f27,await fetch(_0x3610e9,{'method':_0x1d1f27?'POST':'DELETE','headers':_0x1d1f27?{'Authorization':'Bearer\x20'+_0x1d1f27}:{}}));};function O_(_0x290aaf=Qr()){const _0x489e45=Ui(_0x290aaf,'auth');if(_0x489e45['isInitialized']())return _0x489e45['getImmediate']();const _0x18d45a=Mf(_0x290aaf,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x38b2c1=Gr('authTokenSyncURL');if(_0x38b2c1&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x31ec8b=new URL(_0x38b2c1,location['origin']);if(location['origin']===_0x31ec8b['origin']){const _0x4aa207=a_(_0x31ec8b['toString']());Jf(_0x18d45a,_0x4aa207,()=>_0x4aa207(_0x18d45a['currentUser'])),Qf(_0x18d45a,_0x1ea419=>_0x4aa207(_0x1ea419));}}const _0x5c7c66=Hr('auth');return _0x5c7c66&&xf(_0x18d45a,'http://'+_0x5c7c66),_0x18d45a;}function c_(){var _0x17ba9d;return((_0x17ba9d=document['getElementsByTagName']('head'))==null?void 0x0:_0x17ba9d[0x0])??document;}Rf({'loadJS'(_0x26060b){return new Promise((_0x4bba33,_0x174e28)=>{const _0x4f6573=document['createElement']('script');_0x4f6573['setAttribute']('src',_0x26060b),_0x4f6573['onload']=_0x4bba33,_0x4f6573['onerror']=_0x491a0d=>{const _0x33ae2f=J('internal-error');_0x33ae2f['customData']=_0x491a0d,_0x174e28(_0x33ae2f);},_0x4f6573['type']='text/javascript',_0x4f6573['charset']='UTF-8',c_()['appendChild'](_0x4f6573);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};