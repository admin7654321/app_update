const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x45e347,_0x30ec34){if(!_0x45e347)throw ot(_0x30ec34);},ot=function(_0x4fee31){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4fee31);},Wr=function(_0x3040b8){const _0xc47360=[];let _0x119e4f=0x0;for(let _0x6635fa=0x0;_0x6635fa<_0x3040b8['length'];_0x6635fa++){let _0x427c03=_0x3040b8['charCodeAt'](_0x6635fa);_0x427c03<0x80?_0xc47360[_0x119e4f++]=_0x427c03:_0x427c03<0x800?(_0xc47360[_0x119e4f++]=_0x427c03>>0x6|0xc0,_0xc47360[_0x119e4f++]=_0x427c03&0x3f|0x80):(_0x427c03&0xfc00)===0xd800&&_0x6635fa+0x1<_0x3040b8['length']&&(_0x3040b8['charCodeAt'](_0x6635fa+0x1)&0xfc00)===0xdc00?(_0x427c03=0x10000+((_0x427c03&0x3ff)<<0xa)+(_0x3040b8['charCodeAt'](++_0x6635fa)&0x3ff),_0xc47360[_0x119e4f++]=_0x427c03>>0x12|0xf0,_0xc47360[_0x119e4f++]=_0x427c03>>0xc&0x3f|0x80,_0xc47360[_0x119e4f++]=_0x427c03>>0x6&0x3f|0x80,_0xc47360[_0x119e4f++]=_0x427c03&0x3f|0x80):(_0xc47360[_0x119e4f++]=_0x427c03>>0xc|0xe0,_0xc47360[_0x119e4f++]=_0x427c03>>0x6&0x3f|0x80,_0xc47360[_0x119e4f++]=_0x427c03&0x3f|0x80);}return _0xc47360;},Za=function(_0x3f0766){const _0x45b2a9=[];let _0x2b0727=0x0,_0xca0c5a=0x0;for(;_0x2b0727<_0x3f0766['length'];){const _0x33ab4c=_0x3f0766[_0x2b0727++];if(_0x33ab4c<0x80)_0x45b2a9[_0xca0c5a++]=String['fromCharCode'](_0x33ab4c);else{if(_0x33ab4c>0xbf&&_0x33ab4c<0xe0){const _0x47c197=_0x3f0766[_0x2b0727++];_0x45b2a9[_0xca0c5a++]=String['fromCharCode']((_0x33ab4c&0x1f)<<0x6|_0x47c197&0x3f);}else{if(_0x33ab4c>0xef&&_0x33ab4c<0x16d){const _0x24a64a=_0x3f0766[_0x2b0727++],_0x24aea1=_0x3f0766[_0x2b0727++],_0x40ae44=_0x3f0766[_0x2b0727++],_0x36570a=((_0x33ab4c&0x7)<<0x12|(_0x24a64a&0x3f)<<0xc|(_0x24aea1&0x3f)<<0x6|_0x40ae44&0x3f)-0x10000;_0x45b2a9[_0xca0c5a++]=String['fromCharCode'](0xd800+(_0x36570a>>0xa)),_0x45b2a9[_0xca0c5a++]=String['fromCharCode'](0xdc00+(_0x36570a&0x3ff));}else{const _0x50886e=_0x3f0766[_0x2b0727++],_0x3cbe86=_0x3f0766[_0x2b0727++];_0x45b2a9[_0xca0c5a++]=String['fromCharCode']((_0x33ab4c&0xf)<<0xc|(_0x50886e&0x3f)<<0x6|_0x3cbe86&0x3f);}}}}return _0x45b2a9['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x31c9de,_0x91358e){if(!Array['isArray'](_0x31c9de))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x9c84f5=_0x91358e?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3fc728=[];for(let _0x5e34a1=0x0;_0x5e34a1<_0x31c9de['length'];_0x5e34a1+=0x3){const _0x42a5ca=_0x31c9de[_0x5e34a1],_0x390d45=_0x5e34a1+0x1<_0x31c9de['length'],_0x43b4b3=_0x390d45?_0x31c9de[_0x5e34a1+0x1]:0x0,_0x1219e6=_0x5e34a1+0x2<_0x31c9de['length'],_0x4c9363=_0x1219e6?_0x31c9de[_0x5e34a1+0x2]:0x0,_0x4b6b06=_0x42a5ca>>0x2,_0x1875cd=(_0x42a5ca&0x3)<<0x4|_0x43b4b3>>0x4;let _0x4ba72c=(_0x43b4b3&0xf)<<0x2|_0x4c9363>>0x6,_0xd6d97b=_0x4c9363&0x3f;_0x1219e6||(_0xd6d97b=0x40,_0x390d45||(_0x4ba72c=0x40)),_0x3fc728['push'](_0x9c84f5[_0x4b6b06],_0x9c84f5[_0x1875cd],_0x9c84f5[_0x4ba72c],_0x9c84f5[_0xd6d97b]);}return _0x3fc728['join']('');},'encodeString'(_0x306241,_0x454bf7){return this['HAS_NATIVE_SUPPORT']&&!_0x454bf7?btoa(_0x306241):this['encodeByteArray'](Wr(_0x306241),_0x454bf7);},'decodeString'(_0x4260fb,_0x15098b){return this['HAS_NATIVE_SUPPORT']&&!_0x15098b?atob(_0x4260fb):Za(this['decodeStringToByteArray'](_0x4260fb,_0x15098b));},'decodeStringToByteArray'(_0xd4b966,_0xf55866){this['init_']();const _0x1e4ed0=_0xf55866?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1ed4b5=[];for(let _0x18aa24=0x0;_0x18aa24<_0xd4b966['length'];){const _0x7c3b38=_0x1e4ed0[_0xd4b966['charAt'](_0x18aa24++)],_0x17ff2c=_0x18aa24<_0xd4b966['length']?_0x1e4ed0[_0xd4b966['charAt'](_0x18aa24)]:0x0;++_0x18aa24;const _0x293b03=_0x18aa24<_0xd4b966['length']?_0x1e4ed0[_0xd4b966['charAt'](_0x18aa24)]:0x40;++_0x18aa24;const _0x17fc61=_0x18aa24<_0xd4b966['length']?_0x1e4ed0[_0xd4b966['charAt'](_0x18aa24)]:0x40;if(++_0x18aa24,_0x7c3b38==null||_0x17ff2c==null||_0x293b03==null||_0x17fc61==null)throw new ec();const _0x3d0e93=_0x7c3b38<<0x2|_0x17ff2c>>0x4;if(_0x1ed4b5['push'](_0x3d0e93),_0x293b03!==0x40){const _0x3f3f1f=_0x17ff2c<<0x4&0xf0|_0x293b03>>0x2;if(_0x1ed4b5['push'](_0x3f3f1f),_0x17fc61!==0x40){const _0x3f4a91=_0x293b03<<0x6&0xc0|_0x17fc61;_0x1ed4b5['push'](_0x3f4a91);}}}return _0x1ed4b5;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x26556b=0x0;_0x26556b<this['ENCODED_VALS']['length'];_0x26556b++)this['byteToCharMap_'][_0x26556b]=this['ENCODED_VALS']['charAt'](_0x26556b),this['charToByteMap_'][this['byteToCharMap_'][_0x26556b]]=_0x26556b,this['byteToCharMapWebSafe_'][_0x26556b]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26556b),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x26556b]]=_0x26556b,_0x26556b>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26556b)]=_0x26556b,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x26556b)]=_0x26556b);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x131ddd){const _0x33f183=Wr(_0x131ddd);return Di['encodeByteArray'](_0x33f183,!0x0);},an=function(_0x116a41){return Br(_0x116a41)['replace'](/\./g,'');},cn=function(_0x4dbd6c){try{return Di['decodeString'](_0x4dbd6c,!0x0);}catch(_0xb9516){console['error']('base64Decode\x20failed:\x20',_0xb9516);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x48745a){return Vr(void 0x0,_0x48745a);}function Vr(_0xd797cd,_0x160b5b){if(!(_0x160b5b instanceof Object))return _0x160b5b;switch(_0x160b5b['constructor']){case Date:const _0x12922e=_0x160b5b;return new Date(_0x12922e['getTime']());case Object:_0xd797cd===void 0x0&&(_0xd797cd={});break;case Array:_0xd797cd=[];break;default:return _0x160b5b;}for(const _0x358db9 in _0x160b5b)!_0x160b5b['hasOwnProperty'](_0x358db9)||!nc(_0x358db9)||(_0xd797cd[_0x358db9]=Vr(_0xd797cd[_0x358db9],_0x160b5b[_0x358db9]));return _0xd797cd;}function nc(_0x56b847){return _0x56b847!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x53e2ed=As['__FIREBASE_DEFAULTS__'];if(_0x53e2ed)return JSON['parse'](_0x53e2ed);},oc=()=>{if(typeof document>'u')return;let _0x4b93b3;try{_0x4b93b3=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3816a0=_0x4b93b3&&cn(_0x4b93b3[0x1]);return _0x3816a0&&JSON['parse'](_0x3816a0);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x11ceae){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x11ceae);return;}},Hr=_0x36ccfb=>{var _0x58e61f,_0x4e4898;return(_0x4e4898=(_0x58e61f=Mi())==null?void 0x0:_0x58e61f['emulatorHosts'])==null?void 0x0:_0x4e4898[_0x36ccfb];},ac=_0x48c4e9=>{const _0x44cb6d=Hr(_0x48c4e9);if(!_0x44cb6d)return;const _0xce67d4=_0x44cb6d['lastIndexOf'](':');if(_0xce67d4<=0x0||_0xce67d4+0x1===_0x44cb6d['length'])throw new Error('Invalid\x20host\x20'+_0x44cb6d+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x258b1e=parseInt(_0x44cb6d['substring'](_0xce67d4+0x1),0xa);return _0x44cb6d[0x0]==='['?[_0x44cb6d['substring'](0x1,_0xce67d4-0x1),_0x258b1e]:[_0x44cb6d['substring'](0x0,_0xce67d4),_0x258b1e];},$r=()=>{var _0x49fe15;return(_0x49fe15=Mi())==null?void 0x0:_0x49fe15['config'];},Gr=_0x37af46=>{var _0x356e26;return(_0x356e26=Mi())==null?void 0x0:_0x356e26['_'+_0x37af46];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x46c267,_0x1c4a8c)=>{this['resolve']=_0x46c267,this['reject']=_0x1c4a8c;});}['wrapCallback'](_0x4a8805){return(_0x2cb450,_0x3294b6)=>{_0x2cb450?this['reject'](_0x2cb450):this['resolve'](_0x3294b6),typeof _0x4a8805=='function'&&(this['promise']['catch'](()=>{}),_0x4a8805['length']===0x1?_0x4a8805(_0x2cb450):_0x4a8805(_0x2cb450,_0x3294b6));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x22d068,_0x574a37){if(_0x22d068['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x449ac7={'alg':'none','type':'JWT'},_0x3d8ab2=_0x574a37||'demo-project',_0xc50f83=_0x22d068['iat']||0x0,_0x1d1007=_0x22d068['sub']||_0x22d068['user_id'];if(!_0x1d1007)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x24a0fd={'iss':'https://securetoken.google.com/'+_0x3d8ab2,'aud':_0x3d8ab2,'iat':_0xc50f83,'exp':_0xc50f83+0xe10,'auth_time':_0xc50f83,'sub':_0x1d1007,'user_id':_0x1d1007,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x22d068};return[an(JSON['stringify'](_0x449ac7)),an(JSON['stringify'](_0x24a0fd)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x277ab2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x277ab2=='object'&&_0x277ab2['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x5e109d=W();return _0x5e109d['indexOf']('MSIE\x20')>=0x0||_0x5e109d['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x486927,_0x229b33)=>{try{let _0x1e0c8d=!0x0;const _0x2c3323='validate-browser-context-for-indexeddb-analytics-module',_0x13da77=self['indexedDB']['open'](_0x2c3323);_0x13da77['onsuccess']=()=>{_0x13da77['result']['close'](),_0x1e0c8d||self['indexedDB']['deleteDatabase'](_0x2c3323),_0x486927(!0x0);},_0x13da77['onupgradeneeded']=()=>{_0x1e0c8d=!0x1;},_0x13da77['onerror']=()=>{var _0xb3a513;_0x229b33(((_0xb3a513=_0x13da77['error'])==null?void 0x0:_0xb3a513['message'])||'');};}catch(_0x388904){_0x229b33(_0x388904);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0xa8e38d,_0x14225f,_0xe1b144){super(_0x14225f),this['code']=_0xa8e38d,this['customData']=_0xe1b144,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x827451,_0x5951b0,_0x10ea62){this['service']=_0x827451,this['serviceName']=_0x5951b0,this['errors']=_0x10ea62;}['create'](_0x171de5,..._0x339b9d){const _0x481d12=_0x339b9d[0x0]||{},_0x338f32=this['service']+'/'+_0x171de5,_0x11378c=this['errors'][_0x171de5],_0xed58=_0x11378c?gc(_0x11378c,_0x481d12):'Error',_0x488e6c=this['serviceName']+':\x20'+_0xed58+'\x20('+_0x338f32+').';return new Se(_0x338f32,_0x488e6c,_0x481d12);}}function gc(_0x30d81f,_0x5f32a2){return _0x30d81f['replace'](mc,(_0xa353bf,_0x4f8d6e)=>{const _0x3030fa=_0x5f32a2[_0x4f8d6e];return _0x3030fa!=null?String(_0x3030fa):'<'+_0x4f8d6e+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0xf3587d){return JSON['parse'](_0xf3587d);}function O(_0x6bb947){return JSON['stringify'](_0x6bb947);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0xbf197f){let _0x2ed464={},_0x48ce67={},_0x43838a={},_0x12ba3e='';try{const _0x598ec4=_0xbf197f['split']('.');_0x2ed464=bt(cn(_0x598ec4[0x0])||''),_0x48ce67=bt(cn(_0x598ec4[0x1])||''),_0x12ba3e=_0x598ec4[0x2],_0x43838a=_0x48ce67['d']||{},delete _0x48ce67['d'];}catch{}return{'header':_0x2ed464,'claims':_0x48ce67,'data':_0x43838a,'signature':_0x12ba3e};},yc=function(_0x13eb38){const _0x37ead9=zr(_0x13eb38),_0x3a76f0=_0x37ead9['claims'];return!!_0x3a76f0&&typeof _0x3a76f0=='object'&&_0x3a76f0['hasOwnProperty']('iat');},vc=function(_0x101040){const _0x261cbf=zr(_0x101040)['claims'];return typeof _0x261cbf=='object'&&_0x261cbf['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5d888d,_0x1b9713){return Object['prototype']['hasOwnProperty']['call'](_0x5d888d,_0x1b9713);}function Oe(_0x2035d4,_0x5b8132){if(Object['prototype']['hasOwnProperty']['call'](_0x2035d4,_0x5b8132))return _0x2035d4[_0x5b8132];}function hi(_0x4addd1){for(const _0x3b89eb in _0x4addd1)if(Object['prototype']['hasOwnProperty']['call'](_0x4addd1,_0x3b89eb))return!0x1;return!0x0;}function ln(_0x3badb2,_0x8afdd3,_0x30fa91){const _0x2f572e={};for(const _0x17bc6f in _0x3badb2)Object['prototype']['hasOwnProperty']['call'](_0x3badb2,_0x17bc6f)&&(_0x2f572e[_0x17bc6f]=_0x8afdd3['call'](_0x30fa91,_0x3badb2[_0x17bc6f],_0x17bc6f,_0x3badb2));return _0x2f572e;}function De(_0x565d37,_0x266abc){if(_0x565d37===_0x266abc)return!0x0;const _0x553878=Object['keys'](_0x565d37),_0x4bd698=Object['keys'](_0x266abc);for(const _0xbb16b5 of _0x553878){if(!_0x4bd698['includes'](_0xbb16b5))return!0x1;const _0x1ae0ba=_0x565d37[_0xbb16b5],_0x38250d=_0x266abc[_0xbb16b5];if(ks(_0x1ae0ba)&&ks(_0x38250d)){if(!De(_0x1ae0ba,_0x38250d))return!0x1;}else{if(_0x1ae0ba!==_0x38250d)return!0x1;}}for(const _0x1181eb of _0x4bd698)if(!_0x553878['includes'](_0x1181eb))return!0x1;return!0x0;}function ks(_0x5b5d4c){return _0x5b5d4c!==null&&typeof _0x5b5d4c=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x25def1){const _0x2a096d=[];for(const [_0x35da72,_0x511e70]of Object['entries'](_0x25def1))Array['isArray'](_0x511e70)?_0x511e70['forEach'](_0x454e47=>{_0x2a096d['push'](encodeURIComponent(_0x35da72)+'='+encodeURIComponent(_0x454e47));}):_0x2a096d['push'](encodeURIComponent(_0x35da72)+'='+encodeURIComponent(_0x511e70));return _0x2a096d['length']?'&'+_0x2a096d['join']('&'):'';}function yt(_0x3dc54f){const _0x67a25a={};return _0x3dc54f['replace'](/^\?/,'')['split']('&')['forEach'](_0x37fcb8=>{if(_0x37fcb8){const [_0x5de1a2,_0x36c422]=_0x37fcb8['split']('=');_0x67a25a[decodeURIComponent(_0x5de1a2)]=decodeURIComponent(_0x36c422);}}),_0x67a25a;}function vt(_0x463129){const _0x5e7712=_0x463129['indexOf']('?');if(!_0x5e7712)return'';const _0x3c0f08=_0x463129['indexOf']('#',_0x5e7712);return _0x463129['substring'](_0x5e7712,_0x3c0f08>0x0?_0x3c0f08:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xaf52b9=0x1;_0xaf52b9<this['blockSize'];++_0xaf52b9)this['pad_'][_0xaf52b9]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x37c8be,_0x71648f){_0x71648f||(_0x71648f=0x0);const _0x532e6c=this['W_'];if(typeof _0x37c8be=='string'){for(let _0x956075=0x0;_0x956075<0x10;_0x956075++)_0x532e6c[_0x956075]=_0x37c8be['charCodeAt'](_0x71648f)<<0x18|_0x37c8be['charCodeAt'](_0x71648f+0x1)<<0x10|_0x37c8be['charCodeAt'](_0x71648f+0x2)<<0x8|_0x37c8be['charCodeAt'](_0x71648f+0x3),_0x71648f+=0x4;}else{for(let _0x3cd8d9=0x0;_0x3cd8d9<0x10;_0x3cd8d9++)_0x532e6c[_0x3cd8d9]=_0x37c8be[_0x71648f]<<0x18|_0x37c8be[_0x71648f+0x1]<<0x10|_0x37c8be[_0x71648f+0x2]<<0x8|_0x37c8be[_0x71648f+0x3],_0x71648f+=0x4;}for(let _0x4b84de=0x10;_0x4b84de<0x50;_0x4b84de++){const _0x3e969c=_0x532e6c[_0x4b84de-0x3]^_0x532e6c[_0x4b84de-0x8]^_0x532e6c[_0x4b84de-0xe]^_0x532e6c[_0x4b84de-0x10];_0x532e6c[_0x4b84de]=(_0x3e969c<<0x1|_0x3e969c>>>0x1f)&0xffffffff;}let _0x9c9bcd=this['chain_'][0x0],_0x551d33=this['chain_'][0x1],_0xc4ff5c=this['chain_'][0x2],_0x1af4e3=this['chain_'][0x3],_0x328d3b=this['chain_'][0x4],_0x4bdf4a,_0x265032;for(let _0x48971b=0x0;_0x48971b<0x50;_0x48971b++){_0x48971b<0x28?_0x48971b<0x14?(_0x4bdf4a=_0x1af4e3^_0x551d33&(_0xc4ff5c^_0x1af4e3),_0x265032=0x5a827999):(_0x4bdf4a=_0x551d33^_0xc4ff5c^_0x1af4e3,_0x265032=0x6ed9eba1):_0x48971b<0x3c?(_0x4bdf4a=_0x551d33&_0xc4ff5c|_0x1af4e3&(_0x551d33|_0xc4ff5c),_0x265032=0x8f1bbcdc):(_0x4bdf4a=_0x551d33^_0xc4ff5c^_0x1af4e3,_0x265032=0xca62c1d6);const _0x15f067=(_0x9c9bcd<<0x5|_0x9c9bcd>>>0x1b)+_0x4bdf4a+_0x328d3b+_0x265032+_0x532e6c[_0x48971b]&0xffffffff;_0x328d3b=_0x1af4e3,_0x1af4e3=_0xc4ff5c,_0xc4ff5c=(_0x551d33<<0x1e|_0x551d33>>>0x2)&0xffffffff,_0x551d33=_0x9c9bcd,_0x9c9bcd=_0x15f067;}this['chain_'][0x0]=this['chain_'][0x0]+_0x9c9bcd&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x551d33&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xc4ff5c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1af4e3&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x328d3b&0xffffffff;}['update'](_0x1b56e8,_0x5225da){if(_0x1b56e8==null)return;_0x5225da===void 0x0&&(_0x5225da=_0x1b56e8['length']);const _0x12a3f8=_0x5225da-this['blockSize'];let _0x1e9d09=0x0;const _0x18681b=this['buf_'];let _0x168376=this['inbuf_'];for(;_0x1e9d09<_0x5225da;){if(_0x168376===0x0){for(;_0x1e9d09<=_0x12a3f8;)this['compress_'](_0x1b56e8,_0x1e9d09),_0x1e9d09+=this['blockSize'];}if(typeof _0x1b56e8=='string'){for(;_0x1e9d09<_0x5225da;)if(_0x18681b[_0x168376]=_0x1b56e8['charCodeAt'](_0x1e9d09),++_0x168376,++_0x1e9d09,_0x168376===this['blockSize']){this['compress_'](_0x18681b),_0x168376=0x0;break;}}else{for(;_0x1e9d09<_0x5225da;)if(_0x18681b[_0x168376]=_0x1b56e8[_0x1e9d09],++_0x168376,++_0x1e9d09,_0x168376===this['blockSize']){this['compress_'](_0x18681b),_0x168376=0x0;break;}}}this['inbuf_']=_0x168376,this['total_']+=_0x5225da;}['digest'](){const _0x158283=[];let _0x350eda=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2b8df9=this['blockSize']-0x1;_0x2b8df9>=0x38;_0x2b8df9--)this['buf_'][_0x2b8df9]=_0x350eda&0xff,_0x350eda/=0x100;this['compress_'](this['buf_']);let _0x16e804=0x0;for(let _0x2b7daa=0x0;_0x2b7daa<0x5;_0x2b7daa++)for(let _0x947310=0x18;_0x947310>=0x0;_0x947310-=0x8)_0x158283[_0x16e804]=this['chain_'][_0x2b7daa]>>_0x947310&0xff,++_0x16e804;return _0x158283;}}function Ic(_0x214d9b,_0x49f196){const _0x4f01ef=new wc(_0x214d9b,_0x49f196);return _0x4f01ef['subscribe']['bind'](_0x4f01ef);}class wc{constructor(_0x5c4178,_0x4048ca){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4048ca,this['task']['then'](()=>{_0x5c4178(this);})['catch'](_0x24b341=>{this['error'](_0x24b341);});}['next'](_0x3d24da){this['forEachObserver'](_0x30d898=>{_0x30d898['next'](_0x3d24da);});}['error'](_0x3d3297){this['forEachObserver'](_0xf5e65d=>{_0xf5e65d['error'](_0x3d3297);}),this['close'](_0x3d3297);}['complete'](){this['forEachObserver'](_0x22fe97=>{_0x22fe97['complete']();}),this['close']();}['subscribe'](_0x31144e,_0xbce7d0,_0x27f5f1){let _0xcb5542;if(_0x31144e===void 0x0&&_0xbce7d0===void 0x0&&_0x27f5f1===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x31144e,['next','error','complete'])?_0xcb5542=_0x31144e:_0xcb5542={'next':_0x31144e,'error':_0xbce7d0,'complete':_0x27f5f1},_0xcb5542['next']===void 0x0&&(_0xcb5542['next']=Qn),_0xcb5542['error']===void 0x0&&(_0xcb5542['error']=Qn),_0xcb5542['complete']===void 0x0&&(_0xcb5542['complete']=Qn);const _0x1d2cf0=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xcb5542['error'](this['finalError']):_0xcb5542['complete']();}catch{}}),this['observers']['push'](_0xcb5542),_0x1d2cf0;}['unsubscribeOne'](_0xb5366e){this['observers']===void 0x0||this['observers'][_0xb5366e]===void 0x0||(delete this['observers'][_0xb5366e],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x31dce4){if(!this['finalized']){for(let _0x240a70=0x0;_0x240a70<this['observers']['length'];_0x240a70++)this['sendOne'](_0x240a70,_0x31dce4);}}['sendOne'](_0x229c6c,_0xe6c598){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x229c6c]!==void 0x0)try{_0xe6c598(this['observers'][_0x229c6c]);}catch(_0x2c9388){typeof console<'u'&&console['error']&&console['error'](_0x2c9388);}});}['close'](_0x4f4789){this['finalized']||(this['finalized']=!0x0,_0x4f4789!==void 0x0&&(this['finalError']=_0x4f4789),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x134a08,_0x5f59d2){if(typeof _0x134a08!='object'||_0x134a08===null)return!0x1;for(const _0x2dd597 of _0x5f59d2)if(_0x2dd597 in _0x134a08&&typeof _0x134a08[_0x2dd597]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x3a655a,_0x339918){return _0x3a655a+'\x20failed:\x20'+_0x339918+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x3c1eb7){const _0x44e44d=[];let _0x40d0d3=0x0;for(let _0x496ba6=0x0;_0x496ba6<_0x3c1eb7['length'];_0x496ba6++){let _0x17e756=_0x3c1eb7['charCodeAt'](_0x496ba6);if(_0x17e756>=0xd800&&_0x17e756<=0xdbff){const _0x2ce23e=_0x17e756-0xd800;_0x496ba6++,f(_0x496ba6<_0x3c1eb7['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x23b788=_0x3c1eb7['charCodeAt'](_0x496ba6)-0xdc00;_0x17e756=0x10000+(_0x2ce23e<<0xa)+_0x23b788;}_0x17e756<0x80?_0x44e44d[_0x40d0d3++]=_0x17e756:_0x17e756<0x800?(_0x44e44d[_0x40d0d3++]=_0x17e756>>0x6|0xc0,_0x44e44d[_0x40d0d3++]=_0x17e756&0x3f|0x80):_0x17e756<0x10000?(_0x44e44d[_0x40d0d3++]=_0x17e756>>0xc|0xe0,_0x44e44d[_0x40d0d3++]=_0x17e756>>0x6&0x3f|0x80,_0x44e44d[_0x40d0d3++]=_0x17e756&0x3f|0x80):(_0x44e44d[_0x40d0d3++]=_0x17e756>>0x12|0xf0,_0x44e44d[_0x40d0d3++]=_0x17e756>>0xc&0x3f|0x80,_0x44e44d[_0x40d0d3++]=_0x17e756>>0x6&0x3f|0x80,_0x44e44d[_0x40d0d3++]=_0x17e756&0x3f|0x80);}return _0x44e44d;},Pn=function(_0x26f3ee){let _0x4c5f1b=0x0;for(let _0x1322ff=0x0;_0x1322ff<_0x26f3ee['length'];_0x1322ff++){const _0x21d3f6=_0x26f3ee['charCodeAt'](_0x1322ff);_0x21d3f6<0x80?_0x4c5f1b++:_0x21d3f6<0x800?_0x4c5f1b+=0x2:_0x21d3f6>=0xd800&&_0x21d3f6<=0xdbff?(_0x4c5f1b+=0x4,_0x1322ff++):_0x4c5f1b+=0x3;}return _0x4c5f1b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4976c6){return _0x4976c6&&_0x4976c6['_delegate']?_0x4976c6['_delegate']:_0x4976c6;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0xdb7c4e){try{return(_0xdb7c4e['startsWith']('http://')||_0xdb7c4e['startsWith']('https://')?new URL(_0xdb7c4e)['hostname']:_0xdb7c4e)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x408a10){return(await fetch(_0x408a10,{'credentials':'include'}))['ok'];}class Me{constructor(_0x498922,_0x384efb,_0x406fcf){this['name']=_0x498922,this['instanceFactory']=_0x384efb,this['type']=_0x406fcf,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x8fbe45){return this['instantiationMode']=_0x8fbe45,this;}['setMultipleInstances'](_0x12a820){return this['multipleInstances']=_0x12a820,this;}['setServiceProps'](_0x12961e){return this['serviceProps']=_0x12961e,this;}['setInstanceCreatedCallback'](_0x4d809f){return this['onInstanceCreated']=_0x4d809f,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x4b3826,_0x18d483){this['name']=_0x4b3826,this['container']=_0x18d483,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x43ed56){const _0x5d1ee9=this['normalizeInstanceIdentifier'](_0x43ed56);if(!this['instancesDeferred']['has'](_0x5d1ee9)){const _0x546cf4=new Ve();if(this['instancesDeferred']['set'](_0x5d1ee9,_0x546cf4),this['isInitialized'](_0x5d1ee9)||this['shouldAutoInitialize']())try{const _0x4c6709=this['getOrInitializeService']({'instanceIdentifier':_0x5d1ee9});_0x4c6709&&_0x546cf4['resolve'](_0x4c6709);}catch{}}return this['instancesDeferred']['get'](_0x5d1ee9)['promise'];}['getImmediate'](_0xb1171c){const _0x346138=this['normalizeInstanceIdentifier'](_0xb1171c==null?void 0x0:_0xb1171c['identifier']),_0x191b76=(_0xb1171c==null?void 0x0:_0xb1171c['optional'])??!0x1;if(this['isInitialized'](_0x346138)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x346138});}catch(_0x1f31f6){if(_0x191b76)return null;throw _0x1f31f6;}else{if(_0x191b76)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4f2848){if(_0x4f2848['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4f2848['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4f2848,!!this['shouldAutoInitialize']()){if(Rc(_0x4f2848))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x121a63,_0x42e571]of this['instancesDeferred']['entries']()){const _0x38d5a5=this['normalizeInstanceIdentifier'](_0x121a63);try{const _0x27f351=this['getOrInitializeService']({'instanceIdentifier':_0x38d5a5});_0x42e571['resolve'](_0x27f351);}catch{}}}}['clearInstance'](_0x44120e=ke){this['instancesDeferred']['delete'](_0x44120e),this['instancesOptions']['delete'](_0x44120e),this['instances']['delete'](_0x44120e);}async['delete'](){const _0xac86cb=Array['from'](this['instances']['values']());await Promise['all']([..._0xac86cb['filter'](_0x279d47=>'INTERNAL'in _0x279d47)['map'](_0x1551c3=>_0x1551c3['INTERNAL']['delete']()),..._0xac86cb['filter'](_0x502eea=>'_delete'in _0x502eea)['map'](_0x518044=>_0x518044['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x445334=ke){return this['instances']['has'](_0x445334);}['getOptions'](_0x41ef01=ke){return this['instancesOptions']['get'](_0x41ef01)||{};}['initialize'](_0x22a3cf={}){const {options:_0x225cbb={}}=_0x22a3cf,_0x4f4352=this['normalizeInstanceIdentifier'](_0x22a3cf['instanceIdentifier']);if(this['isInitialized'](_0x4f4352))throw Error(this['name']+'('+_0x4f4352+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5e9832=this['getOrInitializeService']({'instanceIdentifier':_0x4f4352,'options':_0x225cbb});for(const [_0x2e2da6,_0x5c06ea]of this['instancesDeferred']['entries']()){const _0xd2f92c=this['normalizeInstanceIdentifier'](_0x2e2da6);_0x4f4352===_0xd2f92c&&_0x5c06ea['resolve'](_0x5e9832);}return _0x5e9832;}['onInit'](_0x4cbcf7,_0x478625){const _0x54e0c2=this['normalizeInstanceIdentifier'](_0x478625),_0x469b0a=this['onInitCallbacks']['get'](_0x54e0c2)??new Set();_0x469b0a['add'](_0x4cbcf7),this['onInitCallbacks']['set'](_0x54e0c2,_0x469b0a);const _0x1f7ded=this['instances']['get'](_0x54e0c2);return _0x1f7ded&&_0x4cbcf7(_0x1f7ded,_0x54e0c2),()=>{_0x469b0a['delete'](_0x4cbcf7);};}['invokeOnInitCallbacks'](_0x2c6ae7,_0x801d1c){const _0x3fddf8=this['onInitCallbacks']['get'](_0x801d1c);if(_0x3fddf8){for(const _0x3c8ebf of _0x3fddf8)try{_0x3c8ebf(_0x2c6ae7,_0x801d1c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xdcf8f6,options:_0x51827e={}}){let _0x5604d5=this['instances']['get'](_0xdcf8f6);if(!_0x5604d5&&this['component']&&(_0x5604d5=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0xdcf8f6),'options':_0x51827e}),this['instances']['set'](_0xdcf8f6,_0x5604d5),this['instancesOptions']['set'](_0xdcf8f6,_0x51827e),this['invokeOnInitCallbacks'](_0x5604d5,_0xdcf8f6),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xdcf8f6,_0x5604d5);}catch{}return _0x5604d5||null;}['normalizeInstanceIdentifier'](_0x425c2a=ke){return this['component']?this['component']['multipleInstances']?_0x425c2a:ke:_0x425c2a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x4ec9f3){return _0x4ec9f3===ke?void 0x0:_0x4ec9f3;}function Rc(_0x456e8e){return _0x456e8e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3d317c){this['name']=_0x3d317c,this['providers']=new Map();}['addComponent'](_0x2e5a21){const _0x3b0910=this['getProvider'](_0x2e5a21['name']);if(_0x3b0910['isComponentSet']())throw new Error('Component\x20'+_0x2e5a21['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3b0910['setComponent'](_0x2e5a21);}['addOrOverwriteComponent'](_0x27b750){this['getProvider'](_0x27b750['name'])['isComponentSet']()&&this['providers']['delete'](_0x27b750['name']),this['addComponent'](_0x27b750);}['getProvider'](_0xf8f54a){if(this['providers']['has'](_0xf8f54a))return this['providers']['get'](_0xf8f54a);const _0x58b174=new Sc(_0xf8f54a,this);return this['providers']['set'](_0xf8f54a,_0x58b174),_0x58b174;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x117a08){_0x117a08[_0x117a08['DEBUG']=0x0]='DEBUG',_0x117a08[_0x117a08['VERBOSE']=0x1]='VERBOSE',_0x117a08[_0x117a08['INFO']=0x2]='INFO',_0x117a08[_0x117a08['WARN']=0x3]='WARN',_0x117a08[_0x117a08['ERROR']=0x4]='ERROR',_0x117a08[_0x117a08['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x2b493b,_0x12b84d,..._0x5a4d23)=>{if(_0x12b84d<_0x2b493b['logLevel'])return;const _0x732518=new Date()['toISOString'](),_0xa1758b=Pc[_0x12b84d];if(_0xa1758b)console[_0xa1758b]('['+_0x732518+']\x20\x20'+_0x2b493b['name']+':',..._0x5a4d23);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x12b84d+')');};class xi{constructor(_0x22116d){this['name']=_0x22116d,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4fb455){if(!(_0x4fb455 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4fb455+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4fb455;}['setLogLevel'](_0x330f25){this['_logLevel']=typeof _0x330f25=='string'?kc[_0x330f25]:_0x330f25;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3d1a7f){if(typeof _0x3d1a7f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3d1a7f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5b3aa5){this['_userLogHandler']=_0x5b3aa5;}['debug'](..._0x17053d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x17053d),this['_logHandler'](this,T['DEBUG'],..._0x17053d);}['log'](..._0x10e06c){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x10e06c),this['_logHandler'](this,T['VERBOSE'],..._0x10e06c);}['info'](..._0x32bbf4){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x32bbf4),this['_logHandler'](this,T['INFO'],..._0x32bbf4);}['warn'](..._0x442a79){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x442a79),this['_logHandler'](this,T['WARN'],..._0x442a79);}['error'](..._0x1a2479){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1a2479),this['_logHandler'](this,T['ERROR'],..._0x1a2479);}}const Dc=(_0x4455eb,_0x27b0cb)=>_0x27b0cb['some'](_0x1740e7=>_0x4455eb instanceof _0x1740e7);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x429624){const _0x423cf2=new Promise((_0x162855,_0xc8e87d)=>{const _0x1d223c=()=>{_0x429624['removeEventListener']('success',_0x327bae),_0x429624['removeEventListener']('error',_0x334e88);},_0x327bae=()=>{_0x162855(_e(_0x429624['result'])),_0x1d223c();},_0x334e88=()=>{_0xc8e87d(_0x429624['error']),_0x1d223c();};_0x429624['addEventListener']('success',_0x327bae),_0x429624['addEventListener']('error',_0x334e88);});return _0x423cf2['then'](_0x56deb1=>{_0x56deb1 instanceof IDBCursor&&Kr['set'](_0x56deb1,_0x429624);})['catch'](()=>{}),Fi['set'](_0x423cf2,_0x429624),_0x423cf2;}function Fc(_0x3f9d95){if(ui['has'](_0x3f9d95))return;const _0x380f7e=new Promise((_0x299dbe,_0x3509a9)=>{const _0x1c7719=()=>{_0x3f9d95['removeEventListener']('complete',_0x4c18bd),_0x3f9d95['removeEventListener']('error',_0x2ede2d),_0x3f9d95['removeEventListener']('abort',_0x2ede2d);},_0x4c18bd=()=>{_0x299dbe(),_0x1c7719();},_0x2ede2d=()=>{_0x3509a9(_0x3f9d95['error']||new DOMException('AbortError','AbortError')),_0x1c7719();};_0x3f9d95['addEventListener']('complete',_0x4c18bd),_0x3f9d95['addEventListener']('error',_0x2ede2d),_0x3f9d95['addEventListener']('abort',_0x2ede2d);});ui['set'](_0x3f9d95,_0x380f7e);}let di={'get'(_0x42d8e4,_0x3b1012,_0x1d9d76){if(_0x42d8e4 instanceof IDBTransaction){if(_0x3b1012==='done')return ui['get'](_0x42d8e4);if(_0x3b1012==='objectStoreNames')return _0x42d8e4['objectStoreNames']||Yr['get'](_0x42d8e4);if(_0x3b1012==='store')return _0x1d9d76['objectStoreNames'][0x1]?void 0x0:_0x1d9d76['objectStore'](_0x1d9d76['objectStoreNames'][0x0]);}return _e(_0x42d8e4[_0x3b1012]);},'set'(_0x595f8a,_0x1df70e,_0x30fc02){return _0x595f8a[_0x1df70e]=_0x30fc02,!0x0;},'has'(_0x5ee9e2,_0x5e1fa7){return _0x5ee9e2 instanceof IDBTransaction&&(_0x5e1fa7==='done'||_0x5e1fa7==='store')?!0x0:_0x5e1fa7 in _0x5ee9e2;}};function Uc(_0x2b681c){di=_0x2b681c(di);}function Wc(_0x323033){return _0x323033===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xf922f8,..._0x591bdd){const _0x175453=_0x323033['call'](Xn(this),_0xf922f8,..._0x591bdd);return Yr['set'](_0x175453,_0xf922f8['sort']?_0xf922f8['sort']():[_0xf922f8]),_e(_0x175453);}:Lc()['includes'](_0x323033)?function(..._0x1e3a4f){return _0x323033['apply'](Xn(this),_0x1e3a4f),_e(Kr['get'](this));}:function(..._0x4cfdec){return _e(_0x323033['apply'](Xn(this),_0x4cfdec));};}function Bc(_0x315f39){return typeof _0x315f39=='function'?Wc(_0x315f39):(_0x315f39 instanceof IDBTransaction&&Fc(_0x315f39),Dc(_0x315f39,Mc())?new Proxy(_0x315f39,di):_0x315f39);}function _e(_0x68d0d9){if(_0x68d0d9 instanceof IDBRequest)return xc(_0x68d0d9);if(Jn['has'](_0x68d0d9))return Jn['get'](_0x68d0d9);const _0x5ae3d0=Bc(_0x68d0d9);return _0x5ae3d0!==_0x68d0d9&&(Jn['set'](_0x68d0d9,_0x5ae3d0),Fi['set'](_0x5ae3d0,_0x68d0d9)),_0x5ae3d0;}const Xn=_0x26d23a=>Fi['get'](_0x26d23a);function Vc(_0x265c38,_0x39b261,{blocked:_0x2d5f7b,upgrade:_0xd1d40a,blocking:_0x432c05,terminated:_0x2f4a2f}={}){const _0x5e23a2=indexedDB['open'](_0x265c38,_0x39b261),_0x2d981f=_e(_0x5e23a2);return _0xd1d40a&&_0x5e23a2['addEventListener']('upgradeneeded',_0x55cf9a=>{_0xd1d40a(_e(_0x5e23a2['result']),_0x55cf9a['oldVersion'],_0x55cf9a['newVersion'],_e(_0x5e23a2['transaction']),_0x55cf9a);}),_0x2d5f7b&&_0x5e23a2['addEventListener']('blocked',_0x50458b=>_0x2d5f7b(_0x50458b['oldVersion'],_0x50458b['newVersion'],_0x50458b)),_0x2d981f['then'](_0x3734ed=>{_0x2f4a2f&&_0x3734ed['addEventListener']('close',()=>_0x2f4a2f()),_0x432c05&&_0x3734ed['addEventListener']('versionchange',_0x489970=>_0x432c05(_0x489970['oldVersion'],_0x489970['newVersion'],_0x489970));})['catch'](()=>{}),_0x2d981f;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x3ee58d,_0x6079cb){if(!(_0x3ee58d instanceof IDBDatabase&&!(_0x6079cb in _0x3ee58d)&&typeof _0x6079cb=='string'))return;if(Zn['get'](_0x6079cb))return Zn['get'](_0x6079cb);const _0x48f8ec=_0x6079cb['replace'](/FromIndex$/,''),_0x19a84b=_0x6079cb!==_0x48f8ec,_0x3d1e82=$c['includes'](_0x48f8ec);if(!(_0x48f8ec in(_0x19a84b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3d1e82||Hc['includes'](_0x48f8ec)))return;const _0x135271=async function(_0x11078f,..._0x546497){const _0x249a0c=this['transaction'](_0x11078f,_0x3d1e82?'readwrite':'readonly');let _0x2a2005=_0x249a0c['store'];return _0x19a84b&&(_0x2a2005=_0x2a2005['index'](_0x546497['shift']())),(await Promise['all']([_0x2a2005[_0x48f8ec](..._0x546497),_0x3d1e82&&_0x249a0c['done']]))[0x0];};return Zn['set'](_0x6079cb,_0x135271),_0x135271;}Uc(_0x4b903e=>({..._0x4b903e,'get':(_0x1bc25b,_0x422ec5,_0x771267)=>Os(_0x1bc25b,_0x422ec5)||_0x4b903e['get'](_0x1bc25b,_0x422ec5,_0x771267),'has':(_0x55e8f3,_0x2b3f71)=>!!Os(_0x55e8f3,_0x2b3f71)||_0x4b903e['has'](_0x55e8f3,_0x2b3f71)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x1cf833){this['container']=_0x1cf833;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x119df0=>{if(qc(_0x119df0)){const _0x159b14=_0x119df0['getImmediate']();return _0x159b14['library']+'/'+_0x159b14['version'];}else return null;})['filter'](_0x170eb2=>_0x170eb2)['join']('\x20');}}function qc(_0x3d1e32){const _0xed2bf4=_0x3d1e32['getComponent']();return(_0xed2bf4==null?void 0x0:_0xed2bf4['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2d093a,_0x386757){try{_0x2d093a['container']['addComponent'](_0x386757);}catch(_0x3939c1){re['debug']('Component\x20'+_0x386757['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2d093a['name'],_0x3939c1);}}function et(_0x1fc683){const _0x139440=_0x1fc683['name'];if(gi['has'](_0x139440))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x139440+'.'),!0x1;gi['set'](_0x139440,_0x1fc683);for(const _0x1406a3 of Le['values']())Ms(_0x1406a3,_0x1fc683);for(const _0x389a3c of _i['values']())Ms(_0x389a3c,_0x1fc683);return!0x0;}function Ui(_0x3e8d9d,_0x2739fc){const _0x2264bb=_0x3e8d9d['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x2264bb&&_0x2264bb['triggerHeartbeat'](),_0x3e8d9d['container']['getProvider'](_0x2739fc);}function H(_0x250424){return _0x250424==null?!0x1:_0x250424['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x111024,_0x1e5e07,_0x11088c){this['_isDeleted']=!0x1,this['_options']={..._0x111024},this['_config']={..._0x1e5e07},this['_name']=_0x1e5e07['name'],this['_automaticDataCollectionEnabled']=_0x1e5e07['automaticDataCollectionEnabled'],this['_container']=_0x11088c,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x57c1b9){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x57c1b9;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x14186a){this['_isDeleted']=_0x14186a;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x4fdaa8,_0xe39bd6={}){let _0x2a3765=_0x4fdaa8;typeof _0xe39bd6!='object'&&(_0xe39bd6={'name':_0xe39bd6});const _0x2aa7c={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0xe39bd6},_0x703d10=_0x2aa7c['name'];if(typeof _0x703d10!='string'||!_0x703d10)throw ge['create']('bad-app-name',{'appName':String(_0x703d10)});if(_0x2a3765||(_0x2a3765=$r()),!_0x2a3765)throw ge['create']('no-options');const _0x1945a4=Le['get'](_0x703d10);if(_0x1945a4){if(De(_0x2a3765,_0x1945a4['options'])&&De(_0x2aa7c,_0x1945a4['config']))return _0x1945a4;throw ge['create']('duplicate-app',{'appName':_0x703d10});}const _0x248f45=new Ac(_0x703d10);for(const _0xa9a56c of gi['values']())_0x248f45['addComponent'](_0xa9a56c);const _0x4707b7=new Il(_0x2a3765,_0x2aa7c,_0x248f45);return Le['set'](_0x703d10,_0x4707b7),_0x4707b7;}function Qr(_0x5cc1f0=pi){const _0x5eb0a6=Le['get'](_0x5cc1f0);if(!_0x5eb0a6&&_0x5cc1f0===pi&&$r())return wl();if(!_0x5eb0a6)throw ge['create']('no-app',{'appName':_0x5cc1f0});return _0x5eb0a6;}function l_(){return Array['from'](Le['values']());}async function h_(_0x261d06){let _0x4a2dfd=!0x1;const _0x5da1b5=_0x261d06['name'];Le['has'](_0x5da1b5)?(_0x4a2dfd=!0x0,Le['delete'](_0x5da1b5)):_i['has'](_0x5da1b5)&&_0x261d06['decRefCount']()<=0x0&&(_i['delete'](_0x5da1b5),_0x4a2dfd=!0x0),_0x4a2dfd&&(await Promise['all'](_0x261d06['container']['getProviders']()['map'](_0xa37956=>_0xa37956['delete']())),_0x261d06['isDeleted']=!0x0);}function me(_0x2a65ee,_0x28c7e9,_0x3d1ae4){let _0x584658=vl[_0x2a65ee]??_0x2a65ee;_0x3d1ae4&&(_0x584658+='-'+_0x3d1ae4);const _0x438803=_0x584658['match'](/\s|\//),_0x1ec1e9=_0x28c7e9['match'](/\s|\//);if(_0x438803||_0x1ec1e9){const _0x3e7784=['Unable\x20to\x20register\x20library\x20\x22'+_0x584658+'\x22\x20with\x20version\x20\x22'+_0x28c7e9+'\x22:'];_0x438803&&_0x3e7784['push']('library\x20name\x20\x22'+_0x584658+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x438803&&_0x1ec1e9&&_0x3e7784['push']('and'),_0x1ec1e9&&_0x3e7784['push']('version\x20name\x20\x22'+_0x28c7e9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3e7784['join']('\x20'));return;}et(new Me(_0x584658+'-version',()=>({'library':_0x584658,'version':_0x28c7e9}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x5f1d6e,_0x1c96ea)=>{switch(_0x1c96ea){case 0x0:try{_0x5f1d6e['createObjectStore'](Rt);}catch(_0x9e8b3b){console['warn'](_0x9e8b3b);}}}})['catch'](_0xc72d23=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xc72d23['message']});})),ei;}async function Sl(_0x570136){try{const _0x3c76f5=(await Jr())['transaction'](Rt),_0x3a94b2=await _0x3c76f5['objectStore'](Rt)['get'](Xr(_0x570136));return await _0x3c76f5['done'],_0x3a94b2;}catch(_0xf6ddb4){if(_0xf6ddb4 instanceof Se)re['warn'](_0xf6ddb4['message']);else{const _0x4d1f75=ge['create']('idb-get',{'originalErrorMessage':_0xf6ddb4==null?void 0x0:_0xf6ddb4['message']});re['warn'](_0x4d1f75['message']);}}}async function Ls(_0xe722e3,_0x1da37f){try{const _0x1c7987=(await Jr())['transaction'](Rt,'readwrite');await _0x1c7987['objectStore'](Rt)['put'](_0x1da37f,Xr(_0xe722e3)),await _0x1c7987['done'];}catch(_0x440c87){if(_0x440c87 instanceof Se)re['warn'](_0x440c87['message']);else{const _0xeb886f=ge['create']('idb-set',{'originalErrorMessage':_0x440c87==null?void 0x0:_0x440c87['message']});re['warn'](_0xeb886f['message']);}}}function Xr(_0x206a7a){return _0x206a7a['name']+'!'+_0x206a7a['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x4de2a2){this['container']=_0x4de2a2,this['_heartbeatsCache']=null;const _0x22b736=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x22b736),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x449f90=>(this['_heartbeatsCache']=_0x449f90,_0x449f90));}async['triggerHeartbeat'](){var _0x1420c0,_0x5b511e;try{const _0x549fbc=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x599271=xs();if(((_0x1420c0=this['_heartbeatsCache'])==null?void 0x0:_0x1420c0['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5b511e=this['_heartbeatsCache'])==null?void 0x0:_0x5b511e['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x599271||this['_heartbeatsCache']['heartbeats']['some'](_0x344677=>_0x344677['date']===_0x599271))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x599271,'agent':_0x549fbc}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x3d7edb=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3d7edb,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x44d359){re['warn'](_0x44d359);}}async['getHeartbeatsHeader'](){var _0x3ff4e3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3ff4e3=this['_heartbeatsCache'])==null?void 0x0:_0x3ff4e3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4bf3ed=xs(),{heartbeatsToSend:_0x441485,unsentEntries:_0x55fc85}=kl(this['_heartbeatsCache']['heartbeats']),_0x12f842=an(JSON['stringify']({'version':0x2,'heartbeats':_0x441485}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4bf3ed,_0x55fc85['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x55fc85,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x12f842;}catch(_0x24e6d4){return re['warn'](_0x24e6d4),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0xa20006,_0x102089=bl){const _0x10945c=[];let _0x4cba6b=_0xa20006['slice']();for(const _0x17d4b3 of _0xa20006){const _0x15e2c1=_0x10945c['find'](_0x8b9b40=>_0x8b9b40['agent']===_0x17d4b3['agent']);if(_0x15e2c1){if(_0x15e2c1['dates']['push'](_0x17d4b3['date']),Fs(_0x10945c)>_0x102089){_0x15e2c1['dates']['pop']();break;}}else{if(_0x10945c['push']({'agent':_0x17d4b3['agent'],'dates':[_0x17d4b3['date']]}),Fs(_0x10945c)>_0x102089){_0x10945c['pop']();break;}}_0x4cba6b=_0x4cba6b['slice'](0x1);}return{'heartbeatsToSend':_0x10945c,'unsentEntries':_0x4cba6b};}class Nl{constructor(_0x3d1867){this['app']=_0x3d1867,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5e0d99=await Sl(this['app']);return _0x5e0d99!=null&&_0x5e0d99['heartbeats']?_0x5e0d99:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x189612){if(await this['_canUseIndexedDBPromise']){const _0x13e6f8=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x189612['lastSentHeartbeatDate']??_0x13e6f8['lastSentHeartbeatDate'],'heartbeats':_0x189612['heartbeats']});}else return;}async['add'](_0x14ba9c){if(await this['_canUseIndexedDBPromise']){const _0x4b30bc=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x14ba9c['lastSentHeartbeatDate']??_0x4b30bc['lastSentHeartbeatDate'],'heartbeats':[..._0x4b30bc['heartbeats'],..._0x14ba9c['heartbeats']]});}else return;}}function Fs(_0x1525e6){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x1525e6}))['length'];}function Pl(_0x5ef4e1){if(_0x5ef4e1['length']===0x0)return-0x1;let _0x3b3c81=0x0,_0x2caa3e=_0x5ef4e1[0x0]['date'];for(let _0x511103=0x1;_0x511103<_0x5ef4e1['length'];_0x511103++)_0x5ef4e1[_0x511103]['date']<_0x2caa3e&&(_0x2caa3e=_0x5ef4e1[_0x511103]['date'],_0x3b3c81=_0x511103);return _0x3b3c81;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x51727d){et(new Me('platform-logger',_0xa82cce=>new Gc(_0xa82cce),'PRIVATE')),et(new Me('heartbeat',_0x1b52a1=>new Al(_0x1b52a1),'PRIVATE')),me(fi,Ds,_0x51727d),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x2104c4){Zr=_0x2104c4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x235dbd){this['domStorage_']=_0x235dbd,this['prefix_']='firebase:';}['set'](_0x5b7118,_0x10476b){_0x10476b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5b7118)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5b7118),O(_0x10476b));}['get'](_0x3c50b3){const _0x22a79b=this['domStorage_']['getItem'](this['prefixedName_'](_0x3c50b3));return _0x22a79b==null?null:bt(_0x22a79b);}['remove'](_0x5b4728){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5b4728));}['prefixedName_'](_0x307299){return this['prefix_']+_0x307299;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5d139c,_0x4e53d4){_0x4e53d4==null?delete this['cache_'][_0x5d139c]:this['cache_'][_0x5d139c]=_0x4e53d4;}['get'](_0x450af1){return Y(this['cache_'],_0x450af1)?this['cache_'][_0x450af1]:null;}['remove'](_0x37e1f8){delete this['cache_'][_0x37e1f8];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x58b3c2){try{if(typeof window<'u'&&typeof window[_0x58b3c2]<'u'){const _0xa9b717=window[_0x58b3c2];return _0xa9b717['setItem']('firebase:sentinel','cache'),_0xa9b717['removeItem']('firebase:sentinel'),new xl(_0xa9b717);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x55e3e0=0x1;return function(){return _0x55e3e0++;};}()),no=function(_0x271876){const _0x4959ae=Tc(_0x271876),_0x48d5d8=new Ec();_0x48d5d8['update'](_0x4959ae);const _0x2b066c=_0x48d5d8['digest']();return Di['encodeByteArray'](_0x2b066c);},Bt=function(..._0x4ba381){let _0x3b6986='';for(let _0x342c3e=0x0;_0x342c3e<_0x4ba381['length'];_0x342c3e++){const _0x2b8bdb=_0x4ba381[_0x342c3e];Array['isArray'](_0x2b8bdb)||_0x2b8bdb&&typeof _0x2b8bdb=='object'&&typeof _0x2b8bdb['length']=='number'?_0x3b6986+=Bt['apply'](null,_0x2b8bdb):typeof _0x2b8bdb=='object'?_0x3b6986+=O(_0x2b8bdb):_0x3b6986+=_0x2b8bdb,_0x3b6986+='\x20';}return _0x3b6986;};let Et=null,Vs=!0x0;const Wl=function(_0x3f7066,_0x3a1a65){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x2d4611){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x422e51=Bt['apply'](null,_0x2d4611);Et(_0x422e51);}},Vt=function(_0xffae13){return function(..._0x254783){L(_0xffae13,..._0x254783);};},mi=function(..._0x508628){const _0x60b8f7='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x508628);Qe['error'](_0x60b8f7);},oe=function(..._0x325c58){const _0x5da235='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x325c58);throw Qe['error'](_0x5da235),new Error(_0x5da235);},U=function(..._0x132dc3){const _0x29737f='FIREBASE\x20WARNING:\x20'+Bt(..._0x132dc3);Qe['warn'](_0x29737f);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x189f57){return typeof _0x189f57=='number'&&(_0x189f57!==_0x189f57||_0x189f57===Number['POSITIVE_INFINITY']||_0x189f57===Number['NEGATIVE_INFINITY']);},Vl=function(_0x137075){if(document['readyState']==='complete')_0x137075();else{let _0xae2238=!0x1;const _0xfb0c9e=function(){if(!document['body']){setTimeout(_0xfb0c9e,Math['floor'](0xa));return;}_0xae2238||(_0xae2238=!0x0,_0x137075());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xfb0c9e,!0x1),window['addEventListener']('load',_0xfb0c9e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xfb0c9e();}),window['attachEvent']('onload',_0xfb0c9e));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x5e3883,_0x2a4c8f){if(_0x5e3883===_0x2a4c8f)return 0x0;if(_0x5e3883===xe||_0x2a4c8f===Ie)return-0x1;if(_0x2a4c8f===xe||_0x5e3883===Ie)return 0x1;{const _0x470a98=Hs(_0x5e3883),_0x586542=Hs(_0x2a4c8f);return _0x470a98!==null?_0x586542!==null?_0x470a98-_0x586542===0x0?_0x5e3883['length']-_0x2a4c8f['length']:_0x470a98-_0x586542:-0x1:_0x586542!==null?0x1:_0x5e3883<_0x2a4c8f?-0x1:0x1;}},Hl=function(_0x495daf,_0x3c1f95){return _0x495daf===_0x3c1f95?0x0:_0x495daf<_0x3c1f95?-0x1:0x1;},pt=function(_0x101da5,_0x4b3483){if(_0x4b3483&&_0x101da5 in _0x4b3483)return _0x4b3483[_0x101da5];throw new Error('Missing\x20required\x20key\x20('+_0x101da5+')\x20in\x20object:\x20'+O(_0x4b3483));},Bi=function(_0x1163fe){if(typeof _0x1163fe!='object'||_0x1163fe===null)return O(_0x1163fe);const _0x20a9b3=[];for(const _0x3bf7ab in _0x1163fe)_0x20a9b3['push'](_0x3bf7ab);_0x20a9b3['sort']();let _0x36a2be='{';for(let _0x3abda9=0x0;_0x3abda9<_0x20a9b3['length'];_0x3abda9++)_0x3abda9!==0x0&&(_0x36a2be+=','),_0x36a2be+=O(_0x20a9b3[_0x3abda9]),_0x36a2be+=':',_0x36a2be+=Bi(_0x1163fe[_0x20a9b3[_0x3abda9]]);return _0x36a2be+='}',_0x36a2be;},io=function(_0xe2564d,_0x4860df){const _0xec85e1=_0xe2564d['length'];if(_0xec85e1<=_0x4860df)return[_0xe2564d];const _0x19c038=[];for(let _0x32e338=0x0;_0x32e338<_0xec85e1;_0x32e338+=_0x4860df)_0x32e338+_0x4860df>_0xec85e1?_0x19c038['push'](_0xe2564d['substring'](_0x32e338,_0xec85e1)):_0x19c038['push'](_0xe2564d['substring'](_0x32e338,_0x32e338+_0x4860df));return _0x19c038;};function x(_0x49126f,_0x3224b0){for(const _0xc8f7dc in _0x49126f)_0x49126f['hasOwnProperty'](_0xc8f7dc)&&_0x3224b0(_0xc8f7dc,_0x49126f[_0xc8f7dc]);}const so=function(_0xaa4c5e){f(!Wi(_0xaa4c5e),'Invalid\x20JSON\x20number');const _0x4623e2=0xb,_0x141573=0x34,_0x32ef2d=(0x1<<_0x4623e2-0x1)-0x1;let _0x3ac406,_0x4cc9cb,_0x5a2032,_0x3776c1,_0x2b9d76;_0xaa4c5e===0x0?(_0x4cc9cb=0x0,_0x5a2032=0x0,_0x3ac406=0x1/_0xaa4c5e===-0x1/0x0?0x1:0x0):(_0x3ac406=_0xaa4c5e<0x0,_0xaa4c5e=Math['abs'](_0xaa4c5e),_0xaa4c5e>=Math['pow'](0x2,0x1-_0x32ef2d)?(_0x3776c1=Math['min'](Math['floor'](Math['log'](_0xaa4c5e)/Math['LN2']),_0x32ef2d),_0x4cc9cb=_0x3776c1+_0x32ef2d,_0x5a2032=Math['round'](_0xaa4c5e*Math['pow'](0x2,_0x141573-_0x3776c1)-Math['pow'](0x2,_0x141573))):(_0x4cc9cb=0x0,_0x5a2032=Math['round'](_0xaa4c5e/Math['pow'](0x2,0x1-_0x32ef2d-_0x141573))));const _0x1a51b3=[];for(_0x2b9d76=_0x141573;_0x2b9d76;_0x2b9d76-=0x1)_0x1a51b3['push'](_0x5a2032%0x2?0x1:0x0),_0x5a2032=Math['floor'](_0x5a2032/0x2);for(_0x2b9d76=_0x4623e2;_0x2b9d76;_0x2b9d76-=0x1)_0x1a51b3['push'](_0x4cc9cb%0x2?0x1:0x0),_0x4cc9cb=Math['floor'](_0x4cc9cb/0x2);_0x1a51b3['push'](_0x3ac406?0x1:0x0),_0x1a51b3['reverse']();const _0x46a94b=_0x1a51b3['join']('');let _0x5db4da='';for(_0x2b9d76=0x0;_0x2b9d76<0x40;_0x2b9d76+=0x8){let _0x3e3dce=parseInt(_0x46a94b['substr'](_0x2b9d76,0x8),0x2)['toString'](0x10);_0x3e3dce['length']===0x1&&(_0x3e3dce='0'+_0x3e3dce),_0x5db4da=_0x5db4da+_0x3e3dce;}return _0x5db4da['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x38015a,_0x148862){let _0x4c9bce='Unknown\x20Error';_0x38015a==='too_big'?_0x4c9bce='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x38015a==='permission_denied'?_0x4c9bce='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x38015a==='unavailable'&&(_0x4c9bce='The\x20service\x20is\x20unavailable');const _0x3aad76=new Error(_0x38015a+'\x20at\x20'+_0x148862['_path']['toString']()+':\x20'+_0x4c9bce);return _0x3aad76['code']=_0x38015a['toUpperCase'](),_0x3aad76;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x3f4d66){if(zl['test'](_0x3f4d66)){const _0x193056=Number(_0x3f4d66);if(_0x193056>=jl&&_0x193056<=Kl)return _0x193056;}return null;},lt=function(_0x34d128){try{_0x34d128();}catch(_0x3156cd){setTimeout(()=>{const _0x112683=_0x3156cd['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x112683),_0x3156cd;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x4eb4b0,_0x179ace){const _0x36167a=setTimeout(_0x4eb4b0,_0x179ace);return typeof _0x36167a=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x36167a):typeof _0x36167a=='object'&&_0x36167a['unref']&&_0x36167a['unref'](),_0x36167a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x4891cd,_0x1f8ded){this['appCheckProvider']=_0x1f8ded,this['appName']=_0x4891cd['name'],H(_0x4891cd)&&_0x4891cd['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4891cd['settings']['appCheckToken']),this['appCheck']=_0x1f8ded==null?void 0x0:_0x1f8ded['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1f8ded==null||_0x1f8ded['get']()['then'](_0x25b436=>this['appCheck']=_0x25b436);}['getToken'](_0x34bbf9){if(this['serverAppAppCheckToken']){if(_0x34bbf9)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x34bbf9):new Promise((_0xe0b838,_0x37912e)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x34bbf9)['then'](_0xe0b838,_0x37912e):_0xe0b838(null);},0x0);});}['addTokenChangeListener'](_0x5ad518){var _0x519915;(_0x519915=this['appCheckProvider'])==null||_0x519915['get']()['then'](_0x71eba6=>_0x71eba6['addTokenListener'](_0x5ad518));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x1ae631,_0x5665c3,_0x32bd6b){this['appName_']=_0x1ae631,this['firebaseOptions_']=_0x5665c3,this['authProvider_']=_0x32bd6b,this['auth_']=null,this['auth_']=_0x32bd6b['getImmediate']({'optional':!0x0}),this['auth_']||_0x32bd6b['onInit'](_0xafec34=>this['auth_']=_0xafec34);}['getToken'](_0x30c17a){return this['auth_']?this['auth_']['getToken'](_0x30c17a)['catch'](_0x242a3e=>_0x242a3e&&_0x242a3e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x242a3e)):new Promise((_0x181b24,_0x111ecc)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x30c17a)['then'](_0x181b24,_0x111ecc):_0x181b24(null);},0x0);});}['addTokenChangeListener'](_0x23fa44){this['auth_']?this['auth_']['addAuthTokenListener'](_0x23fa44):this['authProvider_']['get']()['then'](_0x4a6a94=>_0x4a6a94['addAuthTokenListener'](_0x23fa44));}['removeTokenChangeListener'](_0x48f9ab){this['authProvider_']['get']()['then'](_0x316172=>_0x316172['removeAuthTokenListener'](_0x48f9ab));}['notifyForInvalidToken'](){let _0x5a8ad1='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5a8ad1+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5a8ad1+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5a8ad1+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5a8ad1);}}class tn{constructor(_0x4009b8){this['accessToken']=_0x4009b8;}['getToken'](_0x4a70b8){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1a73cc){_0x1a73cc(this['accessToken']);}['removeTokenChangeListener'](_0x47324a){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x416712,_0x3beafd,_0x5a0277,_0x18ac41,_0x246141=!0x1,_0x4da55a='',_0x2a07c6=!0x1,_0x5ecb07=!0x1,_0x2bad84=null){this['secure']=_0x3beafd,this['namespace']=_0x5a0277,this['webSocketOnly']=_0x18ac41,this['nodeAdmin']=_0x246141,this['persistenceKey']=_0x4da55a,this['includeNamespaceInQueryParams']=_0x2a07c6,this['isUsingEmulator']=_0x5ecb07,this['emulatorOptions']=_0x2bad84,this['_host']=_0x416712['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x416712)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x239afe){_0x239afe!==this['internalHost']&&(this['internalHost']=_0x239afe,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x506505=this['toURLString']();return this['persistenceKey']&&(_0x506505+='<'+this['persistenceKey']+'>'),_0x506505;}['toURLString'](){const _0x4dfab6=this['secure']?'https://':'http://',_0x18a85d=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4dfab6+this['host']+'/'+_0x18a85d;}}function Xl(_0x46586d){return _0x46586d['host']!==_0x46586d['internalHost']||_0x46586d['isCustomHost']()||_0x46586d['includeNamespaceInQueryParams'];}function go(_0x3b007a,_0x9c0a0f,_0x5c406b){f(typeof _0x9c0a0f=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5c406b=='object','typeof\x20params\x20must\x20==\x20object');let _0x4be3ac;if(_0x9c0a0f===fo)_0x4be3ac=(_0x3b007a['secure']?'wss://':'ws://')+_0x3b007a['internalHost']+'/.ws?';else{if(_0x9c0a0f===po)_0x4be3ac=(_0x3b007a['secure']?'https://':'http://')+_0x3b007a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x9c0a0f);}Xl(_0x3b007a)&&(_0x5c406b['ns']=_0x3b007a['namespace']);const _0x413876=[];return x(_0x5c406b,(_0x552443,_0x32da19)=>{_0x413876['push'](_0x552443+'='+_0x32da19);}),_0x4be3ac+_0x413876['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x4593d0,_0x5d19dd=0x1){Y(this['counters_'],_0x4593d0)||(this['counters_'][_0x4593d0]=0x0),this['counters_'][_0x4593d0]+=_0x5d19dd;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x14bd57){const _0xa016d7=_0x14bd57['toString']();return ti[_0xa016d7]||(ti[_0xa016d7]=new Zl()),ti[_0xa016d7];}function eh(_0x4f0699,_0x12ec70){const _0x3a8231=_0x4f0699['toString']();return ni[_0x3a8231]||(ni[_0x3a8231]=_0x12ec70()),ni[_0x3a8231];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x93e89b){this['onMessage_']=_0x93e89b,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3c9ad7,_0x5c43be){this['closeAfterResponse']=_0x3c9ad7,this['onClose']=_0x5c43be,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x31bfcc,_0x2cb995){for(this['pendingResponses'][_0x31bfcc]=_0x2cb995;this['pendingResponses'][this['currentResponseNum']];){const _0x2ce36d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3ba7f7=0x0;_0x3ba7f7<_0x2ce36d['length'];++_0x3ba7f7)_0x2ce36d[_0x3ba7f7]&&lt(()=>{this['onMessage_'](_0x2ce36d[_0x3ba7f7]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x5c91cc,_0x516f44,_0x573413,_0x302528,_0x94234f,_0x33ece6,_0x152a78){this['connId']=_0x5c91cc,this['repoInfo']=_0x516f44,this['applicationId']=_0x573413,this['appCheckToken']=_0x302528,this['authToken']=_0x94234f,this['transportSessionId']=_0x33ece6,this['lastSessionId']=_0x152a78,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x5c91cc),this['stats_']=Hi(_0x516f44),this['urlFn']=_0x533fc9=>(this['appCheckToken']&&(_0x533fc9[yi]=this['appCheckToken']),go(_0x516f44,po,_0x533fc9));}['open'](_0x5967a6,_0x1944ef){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1944ef,this['myPacketOrderer']=new th(_0x5967a6),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x22ffec)=>{const [_0x1ffc33,_0x55db1b,_0x1a95a4,_0x4edf7b,_0xdff393]=_0x22ffec;if(this['incrementIncomingBytes_'](_0x22ffec),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1ffc33===$s)this['id']=_0x55db1b,this['password']=_0x1a95a4;else{if(_0x1ffc33===nh)_0x55db1b?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x55db1b,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1ffc33);}}},(..._0x3c0712)=>{const [_0x4a0a3b,_0x464f06]=_0x3c0712;this['incrementIncomingBytes_'](_0x3c0712),this['myPacketOrderer']['handleResponse'](_0x4a0a3b,_0x464f06);},()=>{this['onClosed_']();},this['urlFn']);const _0x4748b3={};_0x4748b3[$s]='t',_0x4748b3[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4748b3[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4748b3[ro]=Vi,this['transportSessionId']&&(_0x4748b3[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x4748b3[ho]=this['lastSessionId']),this['applicationId']&&(_0x4748b3[uo]=this['applicationId']),this['appCheckToken']&&(_0x4748b3[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4748b3[ao]=co);const _0x208ae2=this['urlFn'](_0x4748b3);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x208ae2),this['scriptTagHolder']['addTag'](_0x208ae2,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1ec1b5){const _0x557737=O(_0x1ec1b5);this['bytesSent']+=_0x557737['length'],this['stats_']['incrementCounter']('bytes_sent',_0x557737['length']);const _0x5e4452=Br(_0x557737),_0xbbe76b=io(_0x5e4452,hh);for(let _0x429300=0x0;_0x429300<_0xbbe76b['length'];_0x429300++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xbbe76b['length'],_0xbbe76b[_0x429300]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x452248,_0x408703){this['myDisconnFrame']=document['createElement']('iframe');const _0x379760={};_0x379760[lh]='t',_0x379760[mo]=_0x452248,_0x379760[yo]=_0x408703,this['myDisconnFrame']['src']=this['urlFn'](_0x379760),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5c7609){const _0x2fbfe1=O(_0x5c7609)['length'];this['bytesReceived']+=_0x2fbfe1,this['stats_']['incrementCounter']('bytes_received',_0x2fbfe1);}}class $i{constructor(_0x4085e3,_0x3a546c,_0x2892c1,_0x1120a8){this['onDisconnect']=_0x2892c1,this['urlFn']=_0x1120a8,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x4085e3,window[sh+this['uniqueCallbackIdentifier']]=_0x3a546c,this['myIFrame']=$i['createIFrame_']();let _0x145c11='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x145c11='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x47d85d='<html><body>'+_0x145c11+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x47d85d),this['myIFrame']['doc']['close']();}catch(_0x15a9fe){L('frame\x20writing\x20exception'),_0x15a9fe['stack']&&L(_0x15a9fe['stack']),L(_0x15a9fe);}}}static['createIFrame_'](){const _0x24557b=document['createElement']('iframe');if(_0x24557b['style']['display']='none',document['body']){document['body']['appendChild'](_0x24557b);try{_0x24557b['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3d926f=document['domain'];_0x24557b['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3d926f+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x24557b['contentDocument']?_0x24557b['doc']=_0x24557b['contentDocument']:_0x24557b['contentWindow']?_0x24557b['doc']=_0x24557b['contentWindow']['document']:_0x24557b['document']&&(_0x24557b['doc']=_0x24557b['document']),_0x24557b;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x19d5a2=this['onDisconnect'];_0x19d5a2&&(this['onDisconnect']=null,_0x19d5a2());}['startLongPoll'](_0x16e8e9,_0x247da3){for(this['myID']=_0x16e8e9,this['myPW']=_0x247da3,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2167ec={};_0x2167ec[mo]=this['myID'],_0x2167ec[yo]=this['myPW'],_0x2167ec[vo]=this['currentSerial'];let _0xe93e80=this['urlFn'](_0x2167ec),_0x5a918c='',_0x55c4be=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5a918c['length']<=Eo;){const _0x1f73d9=this['pendingSegs']['shift']();_0x5a918c=_0x5a918c+'&'+oh+_0x55c4be+'='+_0x1f73d9['seg']+'&'+ah+_0x55c4be+'='+_0x1f73d9['ts']+'&'+ch+_0x55c4be+'='+_0x1f73d9['d'],_0x55c4be++;}return _0xe93e80=_0xe93e80+_0x5a918c,this['addLongPollTag_'](_0xe93e80,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x39d728,_0x185dc9,_0x1c1457){this['pendingSegs']['push']({'seg':_0x39d728,'ts':_0x185dc9,'d':_0x1c1457}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x420655,_0x3398ec){this['outstandingRequests']['add'](_0x3398ec);const _0x21db21=()=>{this['outstandingRequests']['delete'](_0x3398ec),this['newRequest_']();},_0x2006fa=setTimeout(_0x21db21,Math['floor'](uh)),_0x59a027=()=>{clearTimeout(_0x2006fa),_0x21db21();};this['addTag'](_0x420655,_0x59a027);}['addTag'](_0xc0c78a,_0x2eaa9d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x594697=this['myIFrame']['doc']['createElement']('script');_0x594697['type']='text/javascript',_0x594697['async']=!0x0,_0x594697['src']=_0xc0c78a,_0x594697['onload']=_0x594697['onreadystatechange']=function(){const _0x829207=_0x594697['readyState'];(!_0x829207||_0x829207==='loaded'||_0x829207==='complete')&&(_0x594697['onload']=_0x594697['onreadystatechange']=null,_0x594697['parentNode']&&_0x594697['parentNode']['removeChild'](_0x594697),_0x2eaa9d());},_0x594697['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xc0c78a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x594697);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x584155,_0xf3b6c4,_0x3c47b9,_0x59437e,_0x2276e1,_0x337a4f,_0x38cf75){this['connId']=_0x584155,this['applicationId']=_0x3c47b9,this['appCheckToken']=_0x59437e,this['authToken']=_0x2276e1,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0xf3b6c4),this['connURL']=G['connectionURL_'](_0xf3b6c4,_0x337a4f,_0x38cf75,_0x59437e,_0x3c47b9),this['nodeAdmin']=_0xf3b6c4['nodeAdmin'];}static['connectionURL_'](_0x2c68b3,_0x22d885,_0x27353c,_0x28dc3e,_0x3ede51){const _0x1128fb={};return _0x1128fb[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1128fb[ao]=co),_0x22d885&&(_0x1128fb[oo]=_0x22d885),_0x27353c&&(_0x1128fb[ho]=_0x27353c),_0x28dc3e&&(_0x1128fb[yi]=_0x28dc3e),_0x3ede51&&(_0x1128fb[uo]=_0x3ede51),go(_0x2c68b3,fo,_0x1128fb);}['open'](_0x911f19,_0x4d0e77){this['onDisconnect']=_0x4d0e77,this['onMessage']=_0x911f19,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x96ee32;dc(),this['mySock']=new hn(this['connURL'],[],_0x96ee32);}catch(_0x42ee12){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2b36c0=_0x42ee12['message']||_0x42ee12['data'];_0x2b36c0&&this['log_'](_0x2b36c0),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xe2a388=>{this['handleIncomingFrame'](_0xe2a388);},this['mySock']['onerror']=_0x1fcaea=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5eb6b7=_0x1fcaea['message']||_0x1fcaea['data'];_0x5eb6b7&&this['log_'](_0x5eb6b7),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3339e1=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x140e80=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3016fe=navigator['userAgent']['match'](_0x140e80);_0x3016fe&&_0x3016fe['length']>0x1&&parseFloat(_0x3016fe[0x1])<4.4&&(_0x3339e1=!0x0);}return!_0x3339e1&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x19a1de){if(this['frames']['push'](_0x19a1de),this['frames']['length']===this['totalFrames']){const _0x482553=this['frames']['join']('');this['frames']=null;const _0x424eb4=bt(_0x482553);this['onMessage'](_0x424eb4);}}['handleNewFrameCount_'](_0x38b4ce){this['totalFrames']=_0x38b4ce,this['frames']=[];}['extractFrameCount_'](_0x46591d){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x46591d['length']<=0x6){const _0x4b8576=Number(_0x46591d);if(!isNaN(_0x4b8576))return this['handleNewFrameCount_'](_0x4b8576),null;}return this['handleNewFrameCount_'](0x1),_0x46591d;}['handleIncomingFrame'](_0x2a9979){if(this['mySock']===null)return;const _0x485752=_0x2a9979['data'];if(this['bytesReceived']+=_0x485752['length'],this['stats_']['incrementCounter']('bytes_received',_0x485752['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x485752);else{const _0xc231a7=this['extractFrameCount_'](_0x485752);_0xc231a7!==null&&this['appendFrame_'](_0xc231a7);}}['send'](_0x203c0a){this['resetKeepAlive']();const _0x40f12f=O(_0x203c0a);this['bytesSent']+=_0x40f12f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x40f12f['length']);const _0x15f752=io(_0x40f12f,fh);_0x15f752['length']>0x1&&this['sendString_'](String(_0x15f752['length']));for(let _0x4ac798=0x0;_0x4ac798<_0x15f752['length'];_0x4ac798++)this['sendString_'](_0x15f752[_0x4ac798]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x42bd9f){try{this['mySock']['send'](_0x42bd9f);}catch(_0x475994){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x475994['message']||_0x475994['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5f0814){this['initTransports_'](_0x5f0814);}['initTransports_'](_0x4affcb){const _0x5e77f9=G&&G['isAvailable']();let _0x3e195f=_0x5e77f9&&!G['previouslyFailed']();if(_0x4affcb['webSocketOnly']&&(_0x5e77f9||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3e195f=!0x0),_0x3e195f)this['transports_']=[G];else{const _0x3e3499=this['transports_']=[];for(const _0x56a03b of At['ALL_TRANSPORTS'])_0x56a03b&&_0x56a03b['isAvailable']()&&_0x3e3499['push'](_0x56a03b);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x4d4e1e,_0x12e137,_0x1a1671,_0x5b6093,_0x45538d,_0xb39bac,_0x22a2c4,_0x478a1d,_0x36d8b5,_0x1a8886){this['id']=_0x4d4e1e,this['repoInfo_']=_0x12e137,this['applicationId_']=_0x1a1671,this['appCheckToken_']=_0x5b6093,this['authToken_']=_0x45538d,this['onMessage_']=_0xb39bac,this['onReady_']=_0x22a2c4,this['onDisconnect_']=_0x478a1d,this['onKill_']=_0x36d8b5,this['lastSessionId']=_0x1a8886,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x12e137),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x525afe=this['transportManager_']['initialTransport']();this['conn_']=new _0x525afe(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x525afe['responsesRequiredToBeHealthy']||0x0;const _0x838ff9=this['connReceiver_'](this['conn_']),_0x253cc1=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x838ff9,_0x253cc1);},Math['floor'](0x0));const _0x501807=_0x525afe['healthyTimeout']||0x0;_0x501807>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x501807)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x280d51){return _0x2325bf=>{_0x280d51===this['conn_']?this['onConnectionLost_'](_0x2325bf):_0x280d51===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x332af3){return _0x11f86d=>{this['state_']!==0x2&&(_0x332af3===this['rx_']?this['onPrimaryMessageReceived_'](_0x11f86d):_0x332af3===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x11f86d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2eca59){const _0x2764c5={'t':'d','d':_0x2eca59};this['sendData_'](_0x2764c5);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1e8853){if(ii in _0x1e8853){const _0x19d182=_0x1e8853[ii];_0x19d182===js?this['upgradeIfSecondaryHealthy_']():_0x19d182===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x19d182===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4daf1f){const _0x861fe0=pt('t',_0x4daf1f),_0x4ff92b=pt('d',_0x4daf1f);if(_0x861fe0==='c')this['onSecondaryControl_'](_0x4ff92b);else{if(_0x861fe0==='d')this['pendingDataMessages']['push'](_0x4ff92b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x861fe0);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x11ec57){const _0x4d2b60=pt('t',_0x11ec57),_0x1e2379=pt('d',_0x11ec57);_0x4d2b60==='c'?this['onControl_'](_0x1e2379):_0x4d2b60==='d'&&this['onDataMessage_'](_0x1e2379);}['onDataMessage_'](_0x4fdbd9){this['onPrimaryResponse_'](),this['onMessage_'](_0x4fdbd9);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3c9945){const _0x3ca939=pt(ii,_0x3c9945);if(Gs in _0x3c9945){const _0x5bfdd5=_0x3c9945[Gs];if(_0x3ca939===Ih){const _0x800c6e={..._0x5bfdd5};this['repoInfo_']['isUsingEmulator']&&(_0x800c6e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x800c6e);}else{if(_0x3ca939===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1fa82c=0x0;_0x1fa82c<this['pendingDataMessages']['length'];++_0x1fa82c)this['onDataMessage_'](this['pendingDataMessages'][_0x1fa82c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3ca939===vh?this['onConnectionShutdown_'](_0x5bfdd5):_0x3ca939===qs?this['onReset_'](_0x5bfdd5):_0x3ca939===Eh?mi('Server\x20Error:\x20'+_0x5bfdd5):_0x3ca939===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x3ca939);}}}['onHandshake_'](_0x4c214b){const _0x330ad3=_0x4c214b['ts'],_0x24b1b2=_0x4c214b['v'],_0x2f9764=_0x4c214b['h'];this['sessionId']=_0x4c214b['s'],this['repoInfo_']['host']=_0x2f9764,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x330ad3),Vi!==_0x24b1b2&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2dd516=this['transportManager_']['upgradeTransport']();_0x2dd516&&this['startUpgrade_'](_0x2dd516);}['startUpgrade_'](_0x32258d){this['secondaryConn_']=new _0x32258d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x32258d['responsesRequiredToBeHealthy']||0x0;const _0x5220f8=this['connReceiver_'](this['secondaryConn_']),_0x46e41c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5220f8,_0x46e41c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0xd948f0){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xd948f0),this['repoInfo_']['host']=_0xd948f0,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5d6e81,_0x6aad22){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5d6e81,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x6aad22,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xd6929e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xd6929e||this['rx_']===_0xd6929e)&&this['close']();}['onConnectionLost_'](_0x42dcfb){this['conn_']=null,!_0x42dcfb&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2c99e0){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2c99e0),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4bb82b){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4bb82b);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x5789ea,_0x28785f,_0x221f33,_0x22d1b7){}['merge'](_0x477bbb,_0x1f4dcb,_0x19ff75,_0x300f5c){}['refreshAuthToken'](_0x148342){}['refreshAppCheckToken'](_0x74c1f7){}['onDisconnectPut'](_0x43a7c2,_0x53b1dc,_0x484da7){}['onDisconnectMerge'](_0x24cad3,_0x4bab94,_0x13f848){}['onDisconnectCancel'](_0xb736f5,_0x2117fa){}['reportStats'](_0x44b5bc){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x5bf650){this['allowedEvents_']=_0x5bf650,this['listeners_']={},f(Array['isArray'](_0x5bf650)&&_0x5bf650['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x273fe3,..._0x554890){if(Array['isArray'](this['listeners_'][_0x273fe3])){const _0x179a2d=[...this['listeners_'][_0x273fe3]];for(let _0x206748=0x0;_0x206748<_0x179a2d['length'];_0x206748++)_0x179a2d[_0x206748]['callback']['apply'](_0x179a2d[_0x206748]['context'],_0x554890);}}['on'](_0x24a178,_0x143dd1,_0x23e495){this['validateEventType_'](_0x24a178),this['listeners_'][_0x24a178]=this['listeners_'][_0x24a178]||[],this['listeners_'][_0x24a178]['push']({'callback':_0x143dd1,'context':_0x23e495});const _0x432a8c=this['getInitialEvent'](_0x24a178);_0x432a8c&&_0x143dd1['apply'](_0x23e495,_0x432a8c);}['off'](_0x1cc58e,_0x15b843,_0x20385d){this['validateEventType_'](_0x1cc58e);const _0x48d944=this['listeners_'][_0x1cc58e]||[];for(let _0x156901=0x0;_0x156901<_0x48d944['length'];_0x156901++)if(_0x48d944[_0x156901]['callback']===_0x15b843&&(!_0x20385d||_0x20385d===_0x48d944[_0x156901]['context'])){_0x48d944['splice'](_0x156901,0x1);return;}}['validateEventType_'](_0x320f42){f(this['allowedEvents_']['find'](_0x54ec0c=>_0x54ec0c===_0x320f42),'Unknown\x20event:\x20'+_0x320f42);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x464da2){return f(_0x464da2==='online','Unknown\x20event\x20type:\x20'+_0x464da2),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x205bc0,_0x486de8){if(_0x486de8===void 0x0){this['pieces_']=_0x205bc0['split']('/');let _0x2b11d5=0x0;for(let _0xf3a22b=0x0;_0xf3a22b<this['pieces_']['length'];_0xf3a22b++)this['pieces_'][_0xf3a22b]['length']>0x0&&(this['pieces_'][_0x2b11d5]=this['pieces_'][_0xf3a22b],_0x2b11d5++);this['pieces_']['length']=_0x2b11d5,this['pieceNum_']=0x0;}else this['pieces_']=_0x205bc0,this['pieceNum_']=_0x486de8;}['toString'](){let _0x415f20='';for(let _0x49276d=this['pieceNum_'];_0x49276d<this['pieces_']['length'];_0x49276d++)this['pieces_'][_0x49276d]!==''&&(_0x415f20+='/'+this['pieces_'][_0x49276d]);return _0x415f20||'/';}}function w(){return new C('');}function y(_0x2f8184){return _0x2f8184['pieceNum_']>=_0x2f8184['pieces_']['length']?null:_0x2f8184['pieces_'][_0x2f8184['pieceNum_']];}function we(_0x4c59d6){return _0x4c59d6['pieces_']['length']-_0x4c59d6['pieceNum_'];}function b(_0x1ab0ec){let _0x543b76=_0x1ab0ec['pieceNum_'];return _0x543b76<_0x1ab0ec['pieces_']['length']&&_0x543b76++,new C(_0x1ab0ec['pieces_'],_0x543b76);}function Gi(_0x4b9d26){return _0x4b9d26['pieceNum_']<_0x4b9d26['pieces_']['length']?_0x4b9d26['pieces_'][_0x4b9d26['pieces_']['length']-0x1]:null;}function Ch(_0x455238){let _0x1659ea='';for(let _0x44bdf6=_0x455238['pieceNum_'];_0x44bdf6<_0x455238['pieces_']['length'];_0x44bdf6++)_0x455238['pieces_'][_0x44bdf6]!==''&&(_0x1659ea+='/'+encodeURIComponent(String(_0x455238['pieces_'][_0x44bdf6])));return _0x1659ea||'/';}function kt(_0x20482f,_0x5a8132=0x0){return _0x20482f['pieces_']['slice'](_0x20482f['pieceNum_']+_0x5a8132);}function To(_0x259cfd){if(_0x259cfd['pieceNum_']>=_0x259cfd['pieces_']['length'])return null;const _0x2806dd=[];for(let _0x5757d9=_0x259cfd['pieceNum_'];_0x5757d9<_0x259cfd['pieces_']['length']-0x1;_0x5757d9++)_0x2806dd['push'](_0x259cfd['pieces_'][_0x5757d9]);return new C(_0x2806dd,0x0);}function A(_0x472c58,_0x348154){const _0x382923=[];for(let _0x4b63a9=_0x472c58['pieceNum_'];_0x4b63a9<_0x472c58['pieces_']['length'];_0x4b63a9++)_0x382923['push'](_0x472c58['pieces_'][_0x4b63a9]);if(_0x348154 instanceof C){for(let _0x5dedd2=_0x348154['pieceNum_'];_0x5dedd2<_0x348154['pieces_']['length'];_0x5dedd2++)_0x382923['push'](_0x348154['pieces_'][_0x5dedd2]);}else{const _0xe31d13=_0x348154['split']('/');for(let _0x271851=0x0;_0x271851<_0xe31d13['length'];_0x271851++)_0xe31d13[_0x271851]['length']>0x0&&_0x382923['push'](_0xe31d13[_0x271851]);}return new C(_0x382923,0x0);}function v(_0x39359a){return _0x39359a['pieceNum_']>=_0x39359a['pieces_']['length'];}function F(_0x2e1745,_0x567839){const _0x50c58b=y(_0x2e1745),_0xf25a47=y(_0x567839);if(_0x50c58b===null)return _0x567839;if(_0x50c58b===_0xf25a47)return F(b(_0x2e1745),b(_0x567839));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x567839+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2e1745+')');}function Th(_0x144a3b,_0x4d06ae){const _0x59246f=kt(_0x144a3b,0x0),_0x4c632a=kt(_0x4d06ae,0x0);for(let _0x24bf8b=0x0;_0x24bf8b<_0x59246f['length']&&_0x24bf8b<_0x4c632a['length'];_0x24bf8b++){const _0xacf2ab=He(_0x59246f[_0x24bf8b],_0x4c632a[_0x24bf8b]);if(_0xacf2ab!==0x0)return _0xacf2ab;}return _0x59246f['length']===_0x4c632a['length']?0x0:_0x59246f['length']<_0x4c632a['length']?-0x1:0x1;}function qi(_0x1155dc,_0x3ec7f7){if(we(_0x1155dc)!==we(_0x3ec7f7))return!0x1;for(let _0x5c2def=_0x1155dc['pieceNum_'],_0x3f33e6=_0x3ec7f7['pieceNum_'];_0x5c2def<=_0x1155dc['pieces_']['length'];_0x5c2def++,_0x3f33e6++)if(_0x1155dc['pieces_'][_0x5c2def]!==_0x3ec7f7['pieces_'][_0x3f33e6])return!0x1;return!0x0;}function $(_0x140da6,_0x2c53b2){let _0x4a1f98=_0x140da6['pieceNum_'],_0x32b3d7=_0x2c53b2['pieceNum_'];if(we(_0x140da6)>we(_0x2c53b2))return!0x1;for(;_0x4a1f98<_0x140da6['pieces_']['length'];){if(_0x140da6['pieces_'][_0x4a1f98]!==_0x2c53b2['pieces_'][_0x32b3d7])return!0x1;++_0x4a1f98,++_0x32b3d7;}return!0x0;}class Sh{constructor(_0x1b1863,_0x4c42af){this['errorPrefix_']=_0x4c42af,this['parts_']=kt(_0x1b1863,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1ab2e2=0x0;_0x1ab2e2<this['parts_']['length'];_0x1ab2e2++)this['byteLength_']+=Pn(this['parts_'][_0x1ab2e2]);So(this);}}function bh(_0x5f2e82,_0x3cbc9d){_0x5f2e82['parts_']['length']>0x0&&(_0x5f2e82['byteLength_']+=0x1),_0x5f2e82['parts_']['push'](_0x3cbc9d),_0x5f2e82['byteLength_']+=Pn(_0x3cbc9d),So(_0x5f2e82);}function Rh(_0x53a3f0){const _0x252bae=_0x53a3f0['parts_']['pop']();_0x53a3f0['byteLength_']-=Pn(_0x252bae),_0x53a3f0['parts_']['length']>0x0&&(_0x53a3f0['byteLength_']-=0x1);}function So(_0x4fc82c){if(_0x4fc82c['byteLength_']>Js)throw new Error(_0x4fc82c['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4fc82c['byteLength_']+').');if(_0x4fc82c['parts_']['length']>Qs)throw new Error(_0x4fc82c['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4fc82c));}function Ne(_0x129502){return _0x129502['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x129502['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x5e52ae,_0x27a635;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x27a635='visibilitychange',_0x5e52ae='hidden'):typeof document['mozHidden']<'u'?(_0x27a635='mozvisibilitychange',_0x5e52ae='mozHidden'):typeof document['msHidden']<'u'?(_0x27a635='msvisibilitychange',_0x5e52ae='msHidden'):typeof document['webkitHidden']<'u'&&(_0x27a635='webkitvisibilitychange',_0x5e52ae='webkitHidden')),this['visible_']=!0x0,_0x27a635&&document['addEventListener'](_0x27a635,()=>{const _0x56361a=!document[_0x5e52ae];_0x56361a!==this['visible_']&&(this['visible_']=_0x56361a,this['trigger']('visible',_0x56361a));},!0x1);}['getInitialEvent'](_0xa11e0){return f(_0xa11e0==='visible','Unknown\x20event\x20type:\x20'+_0xa11e0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x2d6110,_0x5e930c,_0x3f6985,_0x1adfff,_0xc4fa43,_0x5705c3,_0x552554,_0x3cccf6){if(super(),this['repoInfo_']=_0x2d6110,this['applicationId_']=_0x5e930c,this['onDataUpdate_']=_0x3f6985,this['onConnectStatus_']=_0x1adfff,this['onServerInfoUpdate_']=_0xc4fa43,this['authTokenProvider_']=_0x5705c3,this['appCheckTokenProvider_']=_0x552554,this['authOverride_']=_0x3cccf6,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3cccf6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2d6110['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5d14f2,_0x426748,_0x47d729){const _0x46194b=++this['requestNumber_'],_0xf8ee28={'r':_0x46194b,'a':_0x5d14f2,'b':_0x426748};this['log_'](O(_0xf8ee28)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xf8ee28),_0x47d729&&(this['requestCBHash_'][_0x46194b]=_0x47d729);}['get'](_0x3c96f3){this['initConnection_']();const _0x30a762=new Ve(),_0x5dd5fe={'action':'g','request':{'p':_0x3c96f3['_path']['toString'](),'q':_0x3c96f3['_queryObject']},'onComplete':_0x1d7d5c=>{const _0x3edc72=_0x1d7d5c['d'];_0x1d7d5c['s']==='ok'?_0x30a762['resolve'](_0x3edc72):_0x30a762['reject'](_0x3edc72);}};this['outstandingGets_']['push'](_0x5dd5fe),this['outstandingGetCount_']++;const _0x522084=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x522084),_0x30a762['promise'];}['listen'](_0x505f90,_0x55b23a,_0x5a5dd3,_0x34119a){this['initConnection_']();const _0xc66995=_0x505f90['_queryIdentifier'],_0x458b7e=_0x505f90['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x458b7e+'\x20'+_0xc66995),this['listens']['has'](_0x458b7e)||this['listens']['set'](_0x458b7e,new Map()),f(_0x505f90['_queryParams']['isDefault']()||!_0x505f90['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x458b7e)['has'](_0xc66995),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x263f44={'onComplete':_0x34119a,'hashFn':_0x55b23a,'query':_0x505f90,'tag':_0x5a5dd3};this['listens']['get'](_0x458b7e)['set'](_0xc66995,_0x263f44),this['connected_']&&this['sendListen_'](_0x263f44);}['sendGet_'](_0xbea94e){const _0x57debd=this['outstandingGets_'][_0xbea94e];this['sendRequest']('g',_0x57debd['request'],_0x2bcb81=>{delete this['outstandingGets_'][_0xbea94e],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x57debd['onComplete']&&_0x57debd['onComplete'](_0x2bcb81);});}['sendListen_'](_0x35ea8e){const _0x54b357=_0x35ea8e['query'],_0x2a209d=_0x54b357['_path']['toString'](),_0x4bb18a=_0x54b357['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2a209d+'\x20for\x20'+_0x4bb18a);const _0x1b9acc={'p':_0x2a209d},_0x2d12e1='q';_0x35ea8e['tag']&&(_0x1b9acc['q']=_0x54b357['_queryObject'],_0x1b9acc['t']=_0x35ea8e['tag']),_0x1b9acc['h']=_0x35ea8e['hashFn'](),this['sendRequest'](_0x2d12e1,_0x1b9acc,_0x581e2e=>{const _0x35729d=_0x581e2e['d'],_0x2d682d=_0x581e2e['s'];ie['warnOnListenWarnings_'](_0x35729d,_0x54b357),(this['listens']['get'](_0x2a209d)&&this['listens']['get'](_0x2a209d)['get'](_0x4bb18a))===_0x35ea8e&&(this['log_']('listen\x20response',_0x581e2e),_0x2d682d!=='ok'&&this['removeListen_'](_0x2a209d,_0x4bb18a),_0x35ea8e['onComplete']&&_0x35ea8e['onComplete'](_0x2d682d,_0x35729d));});}static['warnOnListenWarnings_'](_0x28fd18,_0x2421f7){if(_0x28fd18&&typeof _0x28fd18=='object'&&Y(_0x28fd18,'w')){const _0x304398=Oe(_0x28fd18,'w');if(Array['isArray'](_0x304398)&&~_0x304398['indexOf']('no_index')){const _0x59260c='\x22.indexOn\x22:\x20\x22'+_0x2421f7['_queryParams']['getIndex']()['toString']()+'\x22',_0x251366=_0x2421f7['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x59260c+'\x20at\x20'+_0x251366+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x423b08){this['authToken_']=_0x423b08,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x423b08);}['reduceReconnectDelayIfAdminCredential_'](_0x3de5b1){(_0x3de5b1&&_0x3de5b1['length']===0x28||vc(_0x3de5b1))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x4f8afc){this['appCheckToken_']=_0x4f8afc,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3bb163=this['authToken_'],_0x560bfe=yc(_0x3bb163)?'auth':'gauth',_0x33309f={'cred':_0x3bb163};this['authOverride_']===null?_0x33309f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x33309f['authvar']=this['authOverride_']),this['sendRequest'](_0x560bfe,_0x33309f,_0x442833=>{const _0x30b1d0=_0x442833['s'],_0x36f6be=_0x442833['d']||'error';this['authToken_']===_0x3bb163&&(_0x30b1d0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x30b1d0,_0x36f6be));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x473297=>{const _0xa7f585=_0x473297['s'],_0x5ae9ef=_0x473297['d']||'error';_0xa7f585==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xa7f585,_0x5ae9ef);});}['unlisten'](_0x3aea57,_0x9c4a16){const _0x3d8bad=_0x3aea57['_path']['toString'](),_0x553fe8=_0x3aea57['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3d8bad+'\x20'+_0x553fe8),f(_0x3aea57['_queryParams']['isDefault']()||!_0x3aea57['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3d8bad,_0x553fe8)&&this['connected_']&&this['sendUnlisten_'](_0x3d8bad,_0x553fe8,_0x3aea57['_queryObject'],_0x9c4a16);}['sendUnlisten_'](_0x428f64,_0x286194,_0x372b7d,_0x11f13b){this['log_']('Unlisten\x20on\x20'+_0x428f64+'\x20for\x20'+_0x286194);const _0x539bf9={'p':_0x428f64},_0x375830='n';_0x11f13b&&(_0x539bf9['q']=_0x372b7d,_0x539bf9['t']=_0x11f13b),this['sendRequest'](_0x375830,_0x539bf9);}['onDisconnectPut'](_0x5946bd,_0x20390b,_0x4ec965){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5946bd,_0x20390b,_0x4ec965):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5946bd,'action':'o','data':_0x20390b,'onComplete':_0x4ec965});}['onDisconnectMerge'](_0x44ee66,_0x5b5519,_0x17ea2d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x44ee66,_0x5b5519,_0x17ea2d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x44ee66,'action':'om','data':_0x5b5519,'onComplete':_0x17ea2d});}['onDisconnectCancel'](_0x524c50,_0x14c5d6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x524c50,null,_0x14c5d6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x524c50,'action':'oc','data':null,'onComplete':_0x14c5d6});}['sendOnDisconnect_'](_0x5cc685,_0x3a0c0b,_0xbcc4d9,_0x303209){const _0x5aa8c6={'p':_0x3a0c0b,'d':_0xbcc4d9};this['log_']('onDisconnect\x20'+_0x5cc685,_0x5aa8c6),this['sendRequest'](_0x5cc685,_0x5aa8c6,_0x27d2ff=>{_0x303209&&setTimeout(()=>{_0x303209(_0x27d2ff['s'],_0x27d2ff['d']);},Math['floor'](0x0));});}['put'](_0x38eb8d,_0x3750f8,_0x117f5b,_0x4816c2){this['putInternal']('p',_0x38eb8d,_0x3750f8,_0x117f5b,_0x4816c2);}['merge'](_0x27d782,_0x12d29a,_0xc36361,_0x1f890f){this['putInternal']('m',_0x27d782,_0x12d29a,_0xc36361,_0x1f890f);}['putInternal'](_0x54b65f,_0x30f375,_0x2fbaeb,_0x88a678,_0x562b32){this['initConnection_']();const _0x1051a5={'p':_0x30f375,'d':_0x2fbaeb};_0x562b32!==void 0x0&&(_0x1051a5['h']=_0x562b32),this['outstandingPuts_']['push']({'action':_0x54b65f,'request':_0x1051a5,'onComplete':_0x88a678}),this['outstandingPutCount_']++;const _0x34e488=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x34e488):this['log_']('Buffering\x20put:\x20'+_0x30f375);}['sendPut_'](_0x5a6c23){const _0x2bcdfc=this['outstandingPuts_'][_0x5a6c23]['action'],_0x45c9da=this['outstandingPuts_'][_0x5a6c23]['request'],_0x2697e9=this['outstandingPuts_'][_0x5a6c23]['onComplete'];this['outstandingPuts_'][_0x5a6c23]['queued']=this['connected_'],this['sendRequest'](_0x2bcdfc,_0x45c9da,_0x327ac1=>{this['log_'](_0x2bcdfc+'\x20response',_0x327ac1),delete this['outstandingPuts_'][_0x5a6c23],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2697e9&&_0x2697e9(_0x327ac1['s'],_0x327ac1['d']);});}['reportStats'](_0x2f4871){if(this['connected_']){const _0x428d6f={'c':_0x2f4871};this['log_']('reportStats',_0x428d6f),this['sendRequest']('s',_0x428d6f,_0x15af8d=>{if(_0x15af8d['s']!=='ok'){const _0x256d4d=_0x15af8d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x256d4d);}});}}['onDataMessage_'](_0x37089f){if('r'in _0x37089f){this['log_']('from\x20server:\x20'+O(_0x37089f));const _0x541369=_0x37089f['r'],_0x52d014=this['requestCBHash_'][_0x541369];_0x52d014&&(delete this['requestCBHash_'][_0x541369],_0x52d014(_0x37089f['b']));}else{if('error'in _0x37089f)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x37089f['error'];'a'in _0x37089f&&this['onDataPush_'](_0x37089f['a'],_0x37089f['b']);}}['onDataPush_'](_0x533f90,_0x4bb2cb){this['log_']('handleServerMessage',_0x533f90,_0x4bb2cb),_0x533f90==='d'?this['onDataUpdate_'](_0x4bb2cb['p'],_0x4bb2cb['d'],!0x1,_0x4bb2cb['t']):_0x533f90==='m'?this['onDataUpdate_'](_0x4bb2cb['p'],_0x4bb2cb['d'],!0x0,_0x4bb2cb['t']):_0x533f90==='c'?this['onListenRevoked_'](_0x4bb2cb['p'],_0x4bb2cb['q']):_0x533f90==='ac'?this['onAuthRevoked_'](_0x4bb2cb['s'],_0x4bb2cb['d']):_0x533f90==='apc'?this['onAppCheckRevoked_'](_0x4bb2cb['s'],_0x4bb2cb['d']):_0x533f90==='sd'?this['onSecurityDebugPacket_'](_0x4bb2cb):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x533f90)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x37ed7d,_0xae59c9){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x37ed7d),this['lastSessionId']=_0xae59c9,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x38311c){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x38311c));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5d80d7){_0x5d80d7&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5d80d7;}['onOnline_'](_0x163867){_0x163867?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x46040c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3b853e=Math['max'](0x0,this['reconnectDelay_']-_0x46040c);_0x3b853e=Math['random']()*_0x3b853e,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3b853e+'ms'),this['scheduleConnect_'](_0x3b853e),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1bfb4b=this['onDataMessage_']['bind'](this),_0x71692=this['onReady_']['bind'](this),_0x215c61=this['onRealtimeDisconnect_']['bind'](this),_0x104193=this['id']+':'+ie['nextConnectionId_']++,_0x1f61e7=this['lastSessionId'];let _0x35c30c=!0x1,_0x7bed05=null;const _0xb2efd9=function(){_0x7bed05?_0x7bed05['close']():(_0x35c30c=!0x0,_0x215c61());},_0x5cbe26=function(_0x1eed9e){f(_0x7bed05,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x7bed05['sendRequest'](_0x1eed9e);};this['realtime_']={'close':_0xb2efd9,'sendRequest':_0x5cbe26};const _0x4135f4=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x48ae36,_0x7ca3a8]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4135f4),this['appCheckTokenProvider_']['getToken'](_0x4135f4)]);_0x35c30c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x48ae36&&_0x48ae36['accessToken'],this['appCheckToken_']=_0x7ca3a8&&_0x7ca3a8['token'],_0x7bed05=new wh(_0x104193,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1bfb4b,_0x71692,_0x215c61,_0x289fd7=>{U(_0x289fd7+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x1f61e7));}catch(_0x488433){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x488433),_0x35c30c||(this['repoInfo_']['nodeAdmin']&&U(_0x488433),_0xb2efd9());}}}['interrupt'](_0x16b02d){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x16b02d),this['interruptReasons_'][_0x16b02d]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x494626){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x494626),delete this['interruptReasons_'][_0x494626],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xc19bc7){const _0x5e5000=_0xc19bc7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5e5000});}['cancelSentTransactions_'](){for(let _0x2a3839=0x0;_0x2a3839<this['outstandingPuts_']['length'];_0x2a3839++){const _0x8442be=this['outstandingPuts_'][_0x2a3839];_0x8442be&&'h'in _0x8442be['request']&&_0x8442be['queued']&&(_0x8442be['onComplete']&&_0x8442be['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2a3839],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x14808c,_0x31ba97){let _0x52312b;_0x31ba97?_0x52312b=_0x31ba97['map'](_0x14564d=>Bi(_0x14564d))['join']('$'):_0x52312b='default';const _0x19566a=this['removeListen_'](_0x14808c,_0x52312b);_0x19566a&&_0x19566a['onComplete']&&_0x19566a['onComplete']('permission_denied');}['removeListen_'](_0x3c9ac6,_0x5aa8a3){const _0x19f7e7=new C(_0x3c9ac6)['toString']();let _0x1c1d73;if(this['listens']['has'](_0x19f7e7)){const _0x2146a3=this['listens']['get'](_0x19f7e7);_0x1c1d73=_0x2146a3['get'](_0x5aa8a3),_0x2146a3['delete'](_0x5aa8a3),_0x2146a3['size']===0x0&&this['listens']['delete'](_0x19f7e7);}else _0x1c1d73=void 0x0;return _0x1c1d73;}['onAuthRevoked_'](_0x5aa738,_0x113a1b){L('Auth\x20token\x20revoked:\x20'+_0x5aa738+'/'+_0x113a1b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5aa738==='invalid_token'||_0x5aa738==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x571ab1,_0x542988){L('App\x20check\x20token\x20revoked:\x20'+_0x571ab1+'/'+_0x542988),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x571ab1==='invalid_token'||_0x571ab1==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1f2d40){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1f2d40):'msg'in _0x1f2d40&&console['log']('FIREBASE:\x20'+_0x1f2d40['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3b0e2e of this['listens']['values']())for(const _0x16b697 of _0x3b0e2e['values']())this['sendListen_'](_0x16b697);for(let _0x1c66e5=0x0;_0x1c66e5<this['outstandingPuts_']['length'];_0x1c66e5++)this['outstandingPuts_'][_0x1c66e5]&&this['sendPut_'](_0x1c66e5);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3f1e62=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3f1e62['action'],_0x3f1e62['pathString'],_0x3f1e62['data'],_0x3f1e62['onComplete']);}for(let _0x3c6e06=0x0;_0x3c6e06<this['outstandingGets_']['length'];_0x3c6e06++)this['outstandingGets_'][_0x3c6e06]&&this['sendGet_'](_0x3c6e06);}['sendConnectStats_'](){const _0x50d21d={};let _0x589643='js';_0x50d21d['sdk.'+_0x589643+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x50d21d['framework.cordova']=0x1:qr()&&(_0x50d21d['framework.reactnative']=0x1),this['reportStats'](_0x50d21d);}['shouldReconnect_'](){const _0x41b93f=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x41b93f;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x44b6f6,_0x403720){this['name']=_0x44b6f6,this['node']=_0x403720;}static['Wrap'](_0x46a081,_0x374e5f){return new E(_0x46a081,_0x374e5f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x42b662,_0x578ce2){const _0x32b912=new E(xe,_0x42b662),_0x25afa0=new E(xe,_0x578ce2);return this['compare'](_0x32b912,_0x25afa0)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x503743){Xt=_0x503743;}['compare'](_0x1c3316,_0xa348dd){return He(_0x1c3316['name'],_0xa348dd['name']);}['isDefinedOn'](_0x103e7c){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2006e4,_0x52b8aa){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x21a4b1,_0x21748b){return f(typeof _0x21a4b1=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x21a4b1,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3b32f5,_0x3d0c25,_0x39f384,_0x19b970,_0x127611=null){this['isReverse_']=_0x19b970,this['resultGenerator_']=_0x127611,this['nodeStack_']=[];let _0x23eb06=0x1;for(;!_0x3b32f5['isEmpty']();)if(_0x3b32f5=_0x3b32f5,_0x23eb06=_0x3d0c25?_0x39f384(_0x3b32f5['key'],_0x3d0c25):0x1,_0x19b970&&(_0x23eb06*=-0x1),_0x23eb06<0x0)this['isReverse_']?_0x3b32f5=_0x3b32f5['left']:_0x3b32f5=_0x3b32f5['right'];else{if(_0x23eb06===0x0){this['nodeStack_']['push'](_0x3b32f5);break;}else this['nodeStack_']['push'](_0x3b32f5),this['isReverse_']?_0x3b32f5=_0x3b32f5['right']:_0x3b32f5=_0x3b32f5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x41bb61=this['nodeStack_']['pop'](),_0x1cb8cb;if(this['resultGenerator_']?_0x1cb8cb=this['resultGenerator_'](_0x41bb61['key'],_0x41bb61['value']):_0x1cb8cb={'key':_0x41bb61['key'],'value':_0x41bb61['value']},this['isReverse_']){for(_0x41bb61=_0x41bb61['left'];!_0x41bb61['isEmpty']();)this['nodeStack_']['push'](_0x41bb61),_0x41bb61=_0x41bb61['right'];}else{for(_0x41bb61=_0x41bb61['right'];!_0x41bb61['isEmpty']();)this['nodeStack_']['push'](_0x41bb61),_0x41bb61=_0x41bb61['left'];}return _0x1cb8cb;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4d3f25=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4d3f25['key'],_0x4d3f25['value']):{'key':_0x4d3f25['key'],'value':_0x4d3f25['value']};}}class M{constructor(_0x539461,_0x12c4ca,_0x1a89a7,_0x4bca17,_0x30ae1e){this['key']=_0x539461,this['value']=_0x12c4ca,this['color']=_0x1a89a7??M['RED'],this['left']=_0x4bca17??B['EMPTY_NODE'],this['right']=_0x30ae1e??B['EMPTY_NODE'];}['copy'](_0x4dbca5,_0x14f845,_0x3cbf9f,_0x5b3f5e,_0x191a35){return new M(_0x4dbca5??this['key'],_0x14f845??this['value'],_0x3cbf9f??this['color'],_0x5b3f5e??this['left'],_0x191a35??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x53a066){return this['left']['inorderTraversal'](_0x53a066)||!!_0x53a066(this['key'],this['value'])||this['right']['inorderTraversal'](_0x53a066);}['reverseTraversal'](_0x315ad6){return this['right']['reverseTraversal'](_0x315ad6)||_0x315ad6(this['key'],this['value'])||this['left']['reverseTraversal'](_0x315ad6);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x132482,_0x167c04,_0x408829){let _0x2f8f42=this;const _0x3ec17=_0x408829(_0x132482,_0x2f8f42['key']);return _0x3ec17<0x0?_0x2f8f42=_0x2f8f42['copy'](null,null,null,_0x2f8f42['left']['insert'](_0x132482,_0x167c04,_0x408829),null):_0x3ec17===0x0?_0x2f8f42=_0x2f8f42['copy'](null,_0x167c04,null,null,null):_0x2f8f42=_0x2f8f42['copy'](null,null,null,null,_0x2f8f42['right']['insert'](_0x132482,_0x167c04,_0x408829)),_0x2f8f42['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x56a7fb=this;return!_0x56a7fb['left']['isRed_']()&&!_0x56a7fb['left']['left']['isRed_']()&&(_0x56a7fb=_0x56a7fb['moveRedLeft_']()),_0x56a7fb=_0x56a7fb['copy'](null,null,null,_0x56a7fb['left']['removeMin_'](),null),_0x56a7fb['fixUp_']();}['remove'](_0x33d89e,_0x372276){let _0x25f481,_0x5767f1;if(_0x25f481=this,_0x372276(_0x33d89e,_0x25f481['key'])<0x0)!_0x25f481['left']['isEmpty']()&&!_0x25f481['left']['isRed_']()&&!_0x25f481['left']['left']['isRed_']()&&(_0x25f481=_0x25f481['moveRedLeft_']()),_0x25f481=_0x25f481['copy'](null,null,null,_0x25f481['left']['remove'](_0x33d89e,_0x372276),null);else{if(_0x25f481['left']['isRed_']()&&(_0x25f481=_0x25f481['rotateRight_']()),!_0x25f481['right']['isEmpty']()&&!_0x25f481['right']['isRed_']()&&!_0x25f481['right']['left']['isRed_']()&&(_0x25f481=_0x25f481['moveRedRight_']()),_0x372276(_0x33d89e,_0x25f481['key'])===0x0){if(_0x25f481['right']['isEmpty']())return B['EMPTY_NODE'];_0x5767f1=_0x25f481['right']['min_'](),_0x25f481=_0x25f481['copy'](_0x5767f1['key'],_0x5767f1['value'],null,null,_0x25f481['right']['removeMin_']());}_0x25f481=_0x25f481['copy'](null,null,null,null,_0x25f481['right']['remove'](_0x33d89e,_0x372276));}return _0x25f481['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1f78e0=this;return _0x1f78e0['right']['isRed_']()&&!_0x1f78e0['left']['isRed_']()&&(_0x1f78e0=_0x1f78e0['rotateLeft_']()),_0x1f78e0['left']['isRed_']()&&_0x1f78e0['left']['left']['isRed_']()&&(_0x1f78e0=_0x1f78e0['rotateRight_']()),_0x1f78e0['left']['isRed_']()&&_0x1f78e0['right']['isRed_']()&&(_0x1f78e0=_0x1f78e0['colorFlip_']()),_0x1f78e0;}['moveRedLeft_'](){let _0x433005=this['colorFlip_']();return _0x433005['right']['left']['isRed_']()&&(_0x433005=_0x433005['copy'](null,null,null,null,_0x433005['right']['rotateRight_']()),_0x433005=_0x433005['rotateLeft_'](),_0x433005=_0x433005['colorFlip_']()),_0x433005;}['moveRedRight_'](){let _0x5d4a70=this['colorFlip_']();return _0x5d4a70['left']['left']['isRed_']()&&(_0x5d4a70=_0x5d4a70['rotateRight_'](),_0x5d4a70=_0x5d4a70['colorFlip_']()),_0x5d4a70;}['rotateLeft_'](){const _0x19f1c9=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x19f1c9,null);}['rotateRight_'](){const _0x51cb40=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x51cb40);}['colorFlip_'](){const _0x352635=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x521e63=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x352635,_0x521e63);}['checkMaxDepth_'](){const _0x3bce21=this['check_']();return Math['pow'](0x2,_0x3bce21)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2c89ea=this['left']['check_']();if(_0x2c89ea!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2c89ea+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x20e945,_0x2afcdc,_0x382047,_0x3952c8,_0x46d3b3){return this;}['insert'](_0x3cd28d,_0x410b09,_0x4651d7){return new M(_0x3cd28d,_0x410b09,null);}['remove'](_0x5b6013,_0x4fbf75){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1cb2a7){return!0x1;}['reverseTraversal'](_0x36fa10){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2f92f2,_0x22b068=B['EMPTY_NODE']){this['comparator_']=_0x2f92f2,this['root_']=_0x22b068;}['insert'](_0x28a8af,_0x53d410){return new B(this['comparator_'],this['root_']['insert'](_0x28a8af,_0x53d410,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4b06ce){return new B(this['comparator_'],this['root_']['remove'](_0x4b06ce,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x447a07){let _0x2d50e2,_0x324b77=this['root_'];for(;!_0x324b77['isEmpty']();){if(_0x2d50e2=this['comparator_'](_0x447a07,_0x324b77['key']),_0x2d50e2===0x0)return _0x324b77['value'];_0x2d50e2<0x0?_0x324b77=_0x324b77['left']:_0x2d50e2>0x0&&(_0x324b77=_0x324b77['right']);}return null;}['getPredecessorKey'](_0x1a506f){let _0x49cf7a,_0x590a24=this['root_'],_0x4334db=null;for(;!_0x590a24['isEmpty']();)if(_0x49cf7a=this['comparator_'](_0x1a506f,_0x590a24['key']),_0x49cf7a===0x0){if(_0x590a24['left']['isEmpty']())return _0x4334db?_0x4334db['key']:null;for(_0x590a24=_0x590a24['left'];!_0x590a24['right']['isEmpty']();)_0x590a24=_0x590a24['right'];return _0x590a24['key'];}else _0x49cf7a<0x0?_0x590a24=_0x590a24['left']:_0x49cf7a>0x0&&(_0x4334db=_0x590a24,_0x590a24=_0x590a24['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x26816d){return this['root_']['inorderTraversal'](_0x26816d);}['reverseTraversal'](_0x26e904){return this['root_']['reverseTraversal'](_0x26e904);}['getIterator'](_0x52d5ad){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x52d5ad);}['getIteratorFrom'](_0x172500,_0x2675be){return new Zt(this['root_'],_0x172500,this['comparator_'],!0x1,_0x2675be);}['getReverseIteratorFrom'](_0x51bee4,_0xddbedf){return new Zt(this['root_'],_0x51bee4,this['comparator_'],!0x0,_0xddbedf);}['getReverseIterator'](_0x1e5bb8){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x1e5bb8);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x3789c9,_0x1b1a9b){return He(_0x3789c9['name'],_0x1b1a9b['name']);}function ji(_0x1c3c80,_0x306ff6){return He(_0x1c3c80,_0x306ff6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x49c46e){vi=_0x49c46e;}const Ro=function(_0x258537){return typeof _0x258537=='number'?'number:'+so(_0x258537):'string:'+_0x258537;},Ao=function(_0x126405){if(_0x126405['isLeafNode']()){const _0x33a680=_0x126405['val']();f(typeof _0x33a680=='string'||typeof _0x33a680=='number'||typeof _0x33a680=='object'&&Y(_0x33a680,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x126405===vi||_0x126405['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x126405===vi||_0x126405['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x83a56){er=_0x83a56;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xfe196c,_0x2f8c49=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xfe196c,this['priorityNode_']=_0x2f8c49,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x143447){return new D(this['value_'],_0x143447);}['getImmediateChild'](_0x2d2de7){return _0x2d2de7==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4b224a){return v(_0x4b224a)?this:y(_0x4b224a)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5c1b89,_0x115ed3){return null;}['updateImmediateChild'](_0x5e7049,_0x425e19){return _0x5e7049==='.priority'?this['updatePriority'](_0x425e19):_0x425e19['isEmpty']()&&_0x5e7049!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5e7049,_0x425e19)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1ceca9,_0x1948b8){const _0x4c58ec=y(_0x1ceca9);return _0x4c58ec===null?_0x1948b8:_0x1948b8['isEmpty']()&&_0x4c58ec!=='.priority'?this:(f(_0x4c58ec!=='.priority'||we(_0x1ceca9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4c58ec,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x1ceca9),_0x1948b8)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3d189b,_0x34753a){return!0x1;}['val'](_0x340dac){return _0x340dac&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x437344='';this['priorityNode_']['isEmpty']()||(_0x437344+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x3199ec=typeof this['value_'];_0x437344+=_0x3199ec+':',_0x3199ec==='number'?_0x437344+=so(this['value_']):_0x437344+=this['value_'],this['lazyHash_']=no(_0x437344);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x7bbbce){return _0x7bbbce===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x7bbbce instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x7bbbce['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x7bbbce));}['compareToLeafNode_'](_0x3b9035){const _0x1a7937=typeof _0x3b9035['value_'],_0x31d93b=typeof this['value_'],_0x1befb0=D['VALUE_TYPE_ORDER']['indexOf'](_0x1a7937),_0x415859=D['VALUE_TYPE_ORDER']['indexOf'](_0x31d93b);return f(_0x1befb0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1a7937),f(_0x415859>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x31d93b),_0x1befb0===_0x415859?_0x31d93b==='object'?0x0:this['value_']<_0x3b9035['value_']?-0x1:this['value_']===_0x3b9035['value_']?0x0:0x1:_0x415859-_0x1befb0;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3b3830){if(_0x3b3830===this)return!0x0;if(_0x3b3830['isLeafNode']()){const _0xfe8426=_0x3b3830;return this['value_']===_0xfe8426['value_']&&this['priorityNode_']['equals'](_0xfe8426['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x3b2250){ko=_0x3b2250;}function xh(_0x160454){No=_0x160454;}class Fh extends On{['compare'](_0x142f53,_0x5d7d85){const _0x3a5f4d=_0x142f53['node']['getPriority'](),_0x116d1b=_0x5d7d85['node']['getPriority'](),_0x48a3ca=_0x3a5f4d['compareTo'](_0x116d1b);return _0x48a3ca===0x0?He(_0x142f53['name'],_0x5d7d85['name']):_0x48a3ca;}['isDefinedOn'](_0x54c304){return!_0x54c304['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x55bfc6,_0x579fdd){return!_0x55bfc6['getPriority']()['equals'](_0x579fdd['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x5096bf,_0x27f8c0){const _0x4a0d9a=ko(_0x5096bf);return new E(_0x27f8c0,new D('[PRIORITY-POST]',_0x4a0d9a));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x1653c7){const _0x3d6e58=_0xd65be5=>parseInt(Math['log'](_0xd65be5)/Uh,0xa),_0x4b510c=_0x179e0d=>parseInt(Array(_0x179e0d+0x1)['join']('1'),0x2);this['count']=_0x3d6e58(_0x1653c7+0x1),this['current_']=this['count']-0x1;const _0x467d26=_0x4b510c(this['count']);this['bits_']=_0x1653c7+0x1&_0x467d26;}['nextBitIsOne'](){const _0x2d10c9=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2d10c9;}}const dn=function(_0x3109a8,_0x59f8c6,_0x5f317e,_0x4cf90d){_0x3109a8['sort'](_0x59f8c6);const _0x23544c=function(_0x34fd6d,_0x510c6a){const _0xdbd8f4=_0x510c6a-_0x34fd6d;let _0x56405e,_0x32e15d;if(_0xdbd8f4===0x0)return null;if(_0xdbd8f4===0x1)return _0x56405e=_0x3109a8[_0x34fd6d],_0x32e15d=_0x5f317e?_0x5f317e(_0x56405e):_0x56405e,new M(_0x32e15d,_0x56405e['node'],M['BLACK'],null,null);{const _0x51a5f8=parseInt(_0xdbd8f4/0x2,0xa)+_0x34fd6d,_0x5d6698=_0x23544c(_0x34fd6d,_0x51a5f8),_0x4cbd12=_0x23544c(_0x51a5f8+0x1,_0x510c6a);return _0x56405e=_0x3109a8[_0x51a5f8],_0x32e15d=_0x5f317e?_0x5f317e(_0x56405e):_0x56405e,new M(_0x32e15d,_0x56405e['node'],M['BLACK'],_0x5d6698,_0x4cbd12);}},_0x5951db=function(_0x9cf51c){let _0x5f3a17=null,_0xd0a513=null,_0x2049f7=_0x3109a8['length'];const _0x229154=function(_0x586d44,_0x59c07e){const _0x130495=_0x2049f7-_0x586d44,_0x141818=_0x2049f7;_0x2049f7-=_0x586d44;const _0x50ae8d=_0x23544c(_0x130495+0x1,_0x141818),_0x870785=_0x3109a8[_0x130495],_0x166ab0=_0x5f317e?_0x5f317e(_0x870785):_0x870785;_0x510448(new M(_0x166ab0,_0x870785['node'],_0x59c07e,null,_0x50ae8d));},_0x510448=function(_0x49f1f6){_0x5f3a17?(_0x5f3a17['left']=_0x49f1f6,_0x5f3a17=_0x49f1f6):(_0xd0a513=_0x49f1f6,_0x5f3a17=_0x49f1f6);};for(let _0xc95c3c=0x0;_0xc95c3c<_0x9cf51c['count'];++_0xc95c3c){const _0x5d4d5d=_0x9cf51c['nextBitIsOne'](),_0x951036=Math['pow'](0x2,_0x9cf51c['count']-(_0xc95c3c+0x1));_0x5d4d5d?_0x229154(_0x951036,M['BLACK']):(_0x229154(_0x951036,M['BLACK']),_0x229154(_0x951036,M['RED']));}return _0xd0a513;},_0x53c01b=new Wh(_0x3109a8['length']),_0x2bc37f=_0x5951db(_0x53c01b);return new B(_0x4cf90d||_0x59f8c6,_0x2bc37f);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x18a0f5,_0x5eee4c){this['indexes_']=_0x18a0f5,this['indexSet_']=_0x5eee4c;}['get'](_0x1a4739){const _0x5ab12d=Oe(this['indexes_'],_0x1a4739);if(!_0x5ab12d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1a4739);return _0x5ab12d instanceof B?_0x5ab12d:null;}['hasIndex'](_0xc98f5c){return Y(this['indexSet_'],_0xc98f5c['toString']());}['addIndex'](_0x3ea84b,_0x17e84e){f(_0x3ea84b!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1b5cb0=[];let _0x19b073=!0x1;const _0x3b1ffc=_0x17e84e['getIterator'](E['Wrap']);let _0x504c7b=_0x3b1ffc['getNext']();for(;_0x504c7b;)_0x19b073=_0x19b073||_0x3ea84b['isDefinedOn'](_0x504c7b['node']),_0x1b5cb0['push'](_0x504c7b),_0x504c7b=_0x3b1ffc['getNext']();let _0x4d18ab;_0x19b073?_0x4d18ab=dn(_0x1b5cb0,_0x3ea84b['getCompare']()):_0x4d18ab=je;const _0x22bf62=_0x3ea84b['toString'](),_0x4a31f6={...this['indexSet_']};_0x4a31f6[_0x22bf62]=_0x3ea84b;const _0x1f7c0c={...this['indexes_']};return _0x1f7c0c[_0x22bf62]=_0x4d18ab,new ee(_0x1f7c0c,_0x4a31f6);}['addToIndexes'](_0x272ebd,_0x5c6e43){const _0x3f7fee=ln(this['indexes_'],(_0x3fcd4a,_0x5b42cd)=>{const _0x3d420a=Oe(this['indexSet_'],_0x5b42cd);if(f(_0x3d420a,'Missing\x20index\x20implementation\x20for\x20'+_0x5b42cd),_0x3fcd4a===je){if(_0x3d420a['isDefinedOn'](_0x272ebd['node'])){const _0x757a97=[],_0x68bca8=_0x5c6e43['getIterator'](E['Wrap']);let _0x57dc91=_0x68bca8['getNext']();for(;_0x57dc91;)_0x57dc91['name']!==_0x272ebd['name']&&_0x757a97['push'](_0x57dc91),_0x57dc91=_0x68bca8['getNext']();return _0x757a97['push'](_0x272ebd),dn(_0x757a97,_0x3d420a['getCompare']());}else return je;}else{const _0x5e5588=_0x5c6e43['get'](_0x272ebd['name']);let _0x158820=_0x3fcd4a;return _0x5e5588&&(_0x158820=_0x158820['remove'](new E(_0x272ebd['name'],_0x5e5588))),_0x158820['insert'](_0x272ebd,_0x272ebd['node']);}});return new ee(_0x3f7fee,this['indexSet_']);}['removeFromIndexes'](_0x48b66a,_0x3b16cb){const _0x10de05=ln(this['indexes_'],_0xf4a88c=>{if(_0xf4a88c===je)return _0xf4a88c;{const _0x11ac6a=_0x3b16cb['get'](_0x48b66a['name']);return _0x11ac6a?_0xf4a88c['remove'](new E(_0x48b66a['name'],_0x11ac6a)):_0xf4a88c;}});return new ee(_0x10de05,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x49f041,_0x25a2cb,_0x22fd6b){this['children_']=_0x49f041,this['priorityNode_']=_0x25a2cb,this['indexMap_']=_0x22fd6b,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0xe6e476){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xe6e476,this['indexMap_']);}['getImmediateChild'](_0x570cec){if(_0x570cec==='.priority')return this['getPriority']();{const _0x3560e5=this['children_']['get'](_0x570cec);return _0x3560e5===null?gt:_0x3560e5;}}['getChild'](_0x206193){const _0x5b30c7=y(_0x206193);return _0x5b30c7===null?this:this['getImmediateChild'](_0x5b30c7)['getChild'](b(_0x206193));}['hasChild'](_0x3a46a8){return this['children_']['get'](_0x3a46a8)!==null;}['updateImmediateChild'](_0xc8620d,_0x450015){if(f(_0x450015,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xc8620d==='.priority')return this['updatePriority'](_0x450015);{const _0x2fbce8=new E(_0xc8620d,_0x450015);let _0x494446,_0x39b922;_0x450015['isEmpty']()?(_0x494446=this['children_']['remove'](_0xc8620d),_0x39b922=this['indexMap_']['removeFromIndexes'](_0x2fbce8,this['children_'])):(_0x494446=this['children_']['insert'](_0xc8620d,_0x450015),_0x39b922=this['indexMap_']['addToIndexes'](_0x2fbce8,this['children_']));const _0x47f14e=_0x494446['isEmpty']()?gt:this['priorityNode_'];return new g(_0x494446,_0x47f14e,_0x39b922);}}['updateChild'](_0x40e350,_0x29a4b6){const _0x566f6a=y(_0x40e350);if(_0x566f6a===null)return _0x29a4b6;{f(y(_0x40e350)!=='.priority'||we(_0x40e350)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x3c6185=this['getImmediateChild'](_0x566f6a)['updateChild'](b(_0x40e350),_0x29a4b6);return this['updateImmediateChild'](_0x566f6a,_0x3c6185);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2fe22c){if(this['isEmpty']())return null;const _0x45cde9={};let _0xe6485d=0x0,_0x305aff=0x0,_0x51b913=!0x0;if(this['forEachChild'](R,(_0x2f4231,_0x2d4ee4)=>{_0x45cde9[_0x2f4231]=_0x2d4ee4['val'](_0x2fe22c),_0xe6485d++,_0x51b913&&g['INTEGER_REGEXP_']['test'](_0x2f4231)?_0x305aff=Math['max'](_0x305aff,Number(_0x2f4231)):_0x51b913=!0x1;}),!_0x2fe22c&&_0x51b913&&_0x305aff<0x2*_0xe6485d){const _0x50b020=[];for(const _0x275001 in _0x45cde9)_0x50b020[_0x275001]=_0x45cde9[_0x275001];return _0x50b020;}else return _0x2fe22c&&!this['getPriority']()['isEmpty']()&&(_0x45cde9['.priority']=this['getPriority']()['val']()),_0x45cde9;}['hash'](){if(this['lazyHash_']===null){let _0x975804='';this['getPriority']()['isEmpty']()||(_0x975804+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1c609f,_0x284495)=>{const _0x24f0ba=_0x284495['hash']();_0x24f0ba!==''&&(_0x975804+=':'+_0x1c609f+':'+_0x24f0ba);}),this['lazyHash_']=_0x975804===''?'':no(_0x975804);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3989d6,_0x595474,_0xee50d){const _0x4c56ee=this['resolveIndex_'](_0xee50d);if(_0x4c56ee){const _0x14a385=_0x4c56ee['getPredecessorKey'](new E(_0x3989d6,_0x595474));return _0x14a385?_0x14a385['name']:null;}else return this['children_']['getPredecessorKey'](_0x3989d6);}['getFirstChildName'](_0x309cb7){const _0x1b7935=this['resolveIndex_'](_0x309cb7);if(_0x1b7935){const _0x339153=_0x1b7935['minKey']();return _0x339153&&_0x339153['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x22f28c){const _0x33ba00=this['getFirstChildName'](_0x22f28c);return _0x33ba00?new E(_0x33ba00,this['children_']['get'](_0x33ba00)):null;}['getLastChildName'](_0x41ba1d){const _0x4b2db9=this['resolveIndex_'](_0x41ba1d);if(_0x4b2db9){const _0x158074=_0x4b2db9['maxKey']();return _0x158074&&_0x158074['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x274ff3){const _0x22fcac=this['getLastChildName'](_0x274ff3);return _0x22fcac?new E(_0x22fcac,this['children_']['get'](_0x22fcac)):null;}['forEachChild'](_0xf67077,_0x6c50f8){const _0x1b75a1=this['resolveIndex_'](_0xf67077);return _0x1b75a1?_0x1b75a1['inorderTraversal'](_0x574453=>_0x6c50f8(_0x574453['name'],_0x574453['node'])):this['children_']['inorderTraversal'](_0x6c50f8);}['getIterator'](_0x18ab0c){return this['getIteratorFrom'](_0x18ab0c['minPost'](),_0x18ab0c);}['getIteratorFrom'](_0x2e0f89,_0x12ad47){const _0x4aeaa9=this['resolveIndex_'](_0x12ad47);if(_0x4aeaa9)return _0x4aeaa9['getIteratorFrom'](_0x2e0f89,_0x922181=>_0x922181);{const _0x5336a3=this['children_']['getIteratorFrom'](_0x2e0f89['name'],E['Wrap']);let _0xa6138c=_0x5336a3['peek']();for(;_0xa6138c!=null&&_0x12ad47['compare'](_0xa6138c,_0x2e0f89)<0x0;)_0x5336a3['getNext'](),_0xa6138c=_0x5336a3['peek']();return _0x5336a3;}}['getReverseIterator'](_0x901439){return this['getReverseIteratorFrom'](_0x901439['maxPost'](),_0x901439);}['getReverseIteratorFrom'](_0x52016b,_0x17ddef){const _0x34d461=this['resolveIndex_'](_0x17ddef);if(_0x34d461)return _0x34d461['getReverseIteratorFrom'](_0x52016b,_0x1dae15=>_0x1dae15);{const _0x3a8a52=this['children_']['getReverseIteratorFrom'](_0x52016b['name'],E['Wrap']);let _0x4a4f4d=_0x3a8a52['peek']();for(;_0x4a4f4d!=null&&_0x17ddef['compare'](_0x4a4f4d,_0x52016b)>0x0;)_0x3a8a52['getNext'](),_0x4a4f4d=_0x3a8a52['peek']();return _0x3a8a52;}}['compareTo'](_0x2aaa4c){return this['isEmpty']()?_0x2aaa4c['isEmpty']()?0x0:-0x1:_0x2aaa4c['isLeafNode']()||_0x2aaa4c['isEmpty']()?0x1:_0x2aaa4c===Ht?-0x1:0x0;}['withIndex'](_0x1b0b1e){if(_0x1b0b1e===ye||this['indexMap_']['hasIndex'](_0x1b0b1e))return this;{const _0x7128af=this['indexMap_']['addIndex'](_0x1b0b1e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x7128af);}}['isIndexed'](_0x249408){return _0x249408===ye||this['indexMap_']['hasIndex'](_0x249408);}['equals'](_0x1816af){if(_0x1816af===this)return!0x0;if(_0x1816af['isLeafNode']())return!0x1;{const _0x10988f=_0x1816af;if(this['getPriority']()['equals'](_0x10988f['getPriority']())){if(this['children_']['count']()===_0x10988f['children_']['count']()){const _0x45a0e4=this['getIterator'](R),_0x3bffe2=_0x10988f['getIterator'](R);let _0x19e1c1=_0x45a0e4['getNext'](),_0x2c2593=_0x3bffe2['getNext']();for(;_0x19e1c1&&_0x2c2593;){if(_0x19e1c1['name']!==_0x2c2593['name']||!_0x19e1c1['node']['equals'](_0x2c2593['node']))return!0x1;_0x19e1c1=_0x45a0e4['getNext'](),_0x2c2593=_0x3bffe2['getNext']();}return _0x19e1c1===null&&_0x2c2593===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x240eb8){return _0x240eb8===ye?null:this['indexMap_']['get'](_0x240eb8['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x1f354b){return _0x1f354b===this?0x0:0x1;}['equals'](_0x15ae05){return _0x15ae05===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5477a7){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x45427f,_0x259ae9=null){if(_0x45427f===null)return g['EMPTY_NODE'];if(typeof _0x45427f=='object'&&'.priority'in _0x45427f&&(_0x259ae9=_0x45427f['.priority']),f(_0x259ae9===null||typeof _0x259ae9=='string'||typeof _0x259ae9=='number'||typeof _0x259ae9=='object'&&'.sv'in _0x259ae9,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x259ae9),typeof _0x45427f=='object'&&'.value'in _0x45427f&&_0x45427f['.value']!==null&&(_0x45427f=_0x45427f['.value']),typeof _0x45427f!='object'||'.sv'in _0x45427f){const _0x18e9e9=_0x45427f;return new D(_0x18e9e9,N(_0x259ae9));}if(!(_0x45427f instanceof Array)&&Vh){const _0x51007f=[];let _0x32079d=!0x1;if(x(_0x45427f,(_0xe9b8a1,_0x3ab6a9)=>{if(_0xe9b8a1['substring'](0x0,0x1)!=='.'){const _0x227a22=N(_0x3ab6a9);_0x227a22['isEmpty']()||(_0x32079d=_0x32079d||!_0x227a22['getPriority']()['isEmpty'](),_0x51007f['push'](new E(_0xe9b8a1,_0x227a22)));}}),_0x51007f['length']===0x0)return g['EMPTY_NODE'];const _0x202b70=dn(_0x51007f,Dh,_0x306793=>_0x306793['name'],ji);if(_0x32079d){const _0x99b636=dn(_0x51007f,R['getCompare']());return new g(_0x202b70,N(_0x259ae9),new ee({'.priority':_0x99b636},{'.priority':R}));}else return new g(_0x202b70,N(_0x259ae9),ee['Default']);}else{let _0x5f0f89=g['EMPTY_NODE'];return x(_0x45427f,(_0x252525,_0x515e96)=>{if(Y(_0x45427f,_0x252525)&&_0x252525['substring'](0x0,0x1)!=='.'){const _0x3ee66c=N(_0x515e96);(_0x3ee66c['isLeafNode']()||!_0x3ee66c['isEmpty']())&&(_0x5f0f89=_0x5f0f89['updateImmediateChild'](_0x252525,_0x3ee66c));}}),_0x5f0f89['updatePriority'](N(_0x259ae9));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x3ac6c4){super(),this['indexPath_']=_0x3ac6c4,f(!v(_0x3ac6c4)&&y(_0x3ac6c4)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x14bb17){return _0x14bb17['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4827d8){return!_0x4827d8['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5eb2be,_0x51831f){const _0x4061b4=this['extractChild'](_0x5eb2be['node']),_0x513733=this['extractChild'](_0x51831f['node']),_0x1fc4d5=_0x4061b4['compareTo'](_0x513733);return _0x1fc4d5===0x0?He(_0x5eb2be['name'],_0x51831f['name']):_0x1fc4d5;}['makePost'](_0x123f08,_0x514d19){const _0x9eb1a5=N(_0x123f08),_0x2b8919=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x9eb1a5);return new E(_0x514d19,_0x2b8919);}['maxPost'](){const _0x1fa671=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x1fa671);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x2bb884,_0x47b86b){const _0x36cd39=_0x2bb884['node']['compareTo'](_0x47b86b['node']);return _0x36cd39===0x0?He(_0x2bb884['name'],_0x47b86b['name']):_0x36cd39;}['isDefinedOn'](_0x5d540d){return!0x0;}['indexedValueChanged'](_0x124a5c,_0x2d03fe){return!_0x124a5c['equals'](_0x2d03fe);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1ce01e,_0x12d151){const _0x2b6be4=N(_0x1ce01e);return new E(_0x12d151,_0x2b6be4);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0xb14f78){return{'type':'value','snapshotNode':_0xb14f78};}function tt(_0x2ac15f,_0x2f0934){return{'type':'child_added','snapshotNode':_0x2f0934,'childName':_0x2ac15f};}function Nt(_0x53778a,_0x82cd0a){return{'type':'child_removed','snapshotNode':_0x82cd0a,'childName':_0x53778a};}function Pt(_0x399801,_0x4de292,_0x89e990){return{'type':'child_changed','snapshotNode':_0x4de292,'childName':_0x399801,'oldSnap':_0x89e990};}function $h(_0x20206a,_0x4e01e3){return{'type':'child_moved','snapshotNode':_0x4e01e3,'childName':_0x20206a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x53a45e){this['index_']=_0x53a45e;}['updateChild'](_0x15470a,_0x414b62,_0x54146c,_0x27fa00,_0x487e4a,_0x58afc2){f(_0x15470a['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1656d9=_0x15470a['getImmediateChild'](_0x414b62);return _0x1656d9['getChild'](_0x27fa00)['equals'](_0x54146c['getChild'](_0x27fa00))&&_0x1656d9['isEmpty']()===_0x54146c['isEmpty']()||(_0x58afc2!=null&&(_0x54146c['isEmpty']()?_0x15470a['hasChild'](_0x414b62)?_0x58afc2['trackChildChange'](Nt(_0x414b62,_0x1656d9)):f(_0x15470a['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1656d9['isEmpty']()?_0x58afc2['trackChildChange'](tt(_0x414b62,_0x54146c)):_0x58afc2['trackChildChange'](Pt(_0x414b62,_0x54146c,_0x1656d9))),_0x15470a['isLeafNode']()&&_0x54146c['isEmpty']())?_0x15470a:_0x15470a['updateImmediateChild'](_0x414b62,_0x54146c)['withIndex'](this['index_']);}['updateFullNode'](_0x2758fb,_0x2107d9,_0x24d5d9){return _0x24d5d9!=null&&(_0x2758fb['isLeafNode']()||_0x2758fb['forEachChild'](R,(_0xcae42e,_0x250a2f)=>{_0x2107d9['hasChild'](_0xcae42e)||_0x24d5d9['trackChildChange'](Nt(_0xcae42e,_0x250a2f));}),_0x2107d9['isLeafNode']()||_0x2107d9['forEachChild'](R,(_0x5d48e0,_0x305496)=>{if(_0x2758fb['hasChild'](_0x5d48e0)){const _0xfa0571=_0x2758fb['getImmediateChild'](_0x5d48e0);_0xfa0571['equals'](_0x305496)||_0x24d5d9['trackChildChange'](Pt(_0x5d48e0,_0x305496,_0xfa0571));}else _0x24d5d9['trackChildChange'](tt(_0x5d48e0,_0x305496));})),_0x2107d9['withIndex'](this['index_']);}['updatePriority'](_0xdc1853,_0x5b8da0){return _0xdc1853['isEmpty']()?g['EMPTY_NODE']:_0xdc1853['updatePriority'](_0x5b8da0);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x23a251){this['indexedFilter_']=new Yi(_0x23a251['getIndex']()),this['index_']=_0x23a251['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x23a251),this['endPost_']=Ot['getEndPost_'](_0x23a251),this['startIsInclusive_']=!_0x23a251['startAfterSet_'],this['endIsInclusive_']=!_0x23a251['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5fb797){const _0x2a7101=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5fb797)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5fb797)<0x0,_0x1a229d=this['endIsInclusive_']?this['index_']['compare'](_0x5fb797,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5fb797,this['getEndPost']())<0x0;return _0x2a7101&&_0x1a229d;}['updateChild'](_0x427d7e,_0x1d2014,_0x36566f,_0x4dc313,_0x1a5242,_0x58e6b6){return this['matches'](new E(_0x1d2014,_0x36566f))||(_0x36566f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x427d7e,_0x1d2014,_0x36566f,_0x4dc313,_0x1a5242,_0x58e6b6);}['updateFullNode'](_0xb93e2c,_0x517e4b,_0x273aa3){_0x517e4b['isLeafNode']()&&(_0x517e4b=g['EMPTY_NODE']);let _0x491cff=_0x517e4b['withIndex'](this['index_']);_0x491cff=_0x491cff['updatePriority'](g['EMPTY_NODE']);const _0x309a57=this;return _0x517e4b['forEachChild'](R,(_0x4d87c9,_0x14786f)=>{_0x309a57['matches'](new E(_0x4d87c9,_0x14786f))||(_0x491cff=_0x491cff['updateImmediateChild'](_0x4d87c9,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0xb93e2c,_0x491cff,_0x273aa3);}['updatePriority'](_0x812d41,_0x551235){return _0x812d41;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3a9adb){if(_0x3a9adb['hasStart']()){const _0x274f0d=_0x3a9adb['getIndexStartName']();return _0x3a9adb['getIndex']()['makePost'](_0x3a9adb['getIndexStartValue'](),_0x274f0d);}else return _0x3a9adb['getIndex']()['minPost']();}static['getEndPost_'](_0x4f9502){if(_0x4f9502['hasEnd']()){const _0x478812=_0x4f9502['getIndexEndName']();return _0x4f9502['getIndex']()['makePost'](_0x4f9502['getIndexEndValue'](),_0x478812);}else return _0x4f9502['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x1b834a){this['withinDirectionalStart']=_0x370cac=>this['reverse_']?this['withinEndPost'](_0x370cac):this['withinStartPost'](_0x370cac),this['withinDirectionalEnd']=_0x14206f=>this['reverse_']?this['withinStartPost'](_0x14206f):this['withinEndPost'](_0x14206f),this['withinStartPost']=_0xed3673=>{const _0x1a25b5=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xed3673);return this['startIsInclusive_']?_0x1a25b5<=0x0:_0x1a25b5<0x0;},this['withinEndPost']=_0xcb8b30=>{const _0xddd282=this['index_']['compare'](_0xcb8b30,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xddd282<=0x0:_0xddd282<0x0;},this['rangedFilter_']=new Ot(_0x1b834a),this['index_']=_0x1b834a['getIndex'](),this['limit_']=_0x1b834a['getLimit'](),this['reverse_']=!_0x1b834a['isViewFromLeft'](),this['startIsInclusive_']=!_0x1b834a['startAfterSet_'],this['endIsInclusive_']=!_0x1b834a['endBeforeSet_'];}['updateChild'](_0x236e7b,_0x2f1e2f,_0x37b9d4,_0x324c7a,_0x2bfaac,_0x30cbff){return this['rangedFilter_']['matches'](new E(_0x2f1e2f,_0x37b9d4))||(_0x37b9d4=g['EMPTY_NODE']),_0x236e7b['getImmediateChild'](_0x2f1e2f)['equals'](_0x37b9d4)?_0x236e7b:_0x236e7b['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x236e7b,_0x2f1e2f,_0x37b9d4,_0x324c7a,_0x2bfaac,_0x30cbff):this['fullLimitUpdateChild_'](_0x236e7b,_0x2f1e2f,_0x37b9d4,_0x2bfaac,_0x30cbff);}['updateFullNode'](_0x5cbcc4,_0x5f1b42,_0x240191){let _0x18cfc6;if(_0x5f1b42['isLeafNode']()||_0x5f1b42['isEmpty']())_0x18cfc6=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5f1b42['numChildren']()&&_0x5f1b42['isIndexed'](this['index_'])){_0x18cfc6=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4b5982;this['reverse_']?_0x4b5982=_0x5f1b42['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4b5982=_0x5f1b42['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x18d802=0x0;for(;_0x4b5982['hasNext']()&&_0x18d802<this['limit_'];){const _0x2ee9ec=_0x4b5982['getNext']();if(this['withinDirectionalStart'](_0x2ee9ec)){if(this['withinDirectionalEnd'](_0x2ee9ec))_0x18cfc6=_0x18cfc6['updateImmediateChild'](_0x2ee9ec['name'],_0x2ee9ec['node']),_0x18d802++;else break;}else continue;}}else{_0x18cfc6=_0x5f1b42['withIndex'](this['index_']),_0x18cfc6=_0x18cfc6['updatePriority'](g['EMPTY_NODE']);let _0xd6c4b4;this['reverse_']?_0xd6c4b4=_0x18cfc6['getReverseIterator'](this['index_']):_0xd6c4b4=_0x18cfc6['getIterator'](this['index_']);let _0x417c3a=0x0;for(;_0xd6c4b4['hasNext']();){const _0x25a3a6=_0xd6c4b4['getNext']();_0x417c3a<this['limit_']&&this['withinDirectionalStart'](_0x25a3a6)&&this['withinDirectionalEnd'](_0x25a3a6)?_0x417c3a++:_0x18cfc6=_0x18cfc6['updateImmediateChild'](_0x25a3a6['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5cbcc4,_0x18cfc6,_0x240191);}['updatePriority'](_0x513f10,_0x40073c){return _0x513f10;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x211ee5,_0x199055,_0x551269,_0x1ab713,_0x5154b4){let _0x1e0f4a;if(this['reverse_']){const _0x5103d2=this['index_']['getCompare']();_0x1e0f4a=(_0xd87d68,_0xe0fa7e)=>_0x5103d2(_0xe0fa7e,_0xd87d68);}else _0x1e0f4a=this['index_']['getCompare']();const _0x52ebb4=_0x211ee5;f(_0x52ebb4['numChildren']()===this['limit_'],'');const _0x5bc423=new E(_0x199055,_0x551269),_0x3c0eba=this['reverse_']?_0x52ebb4['getFirstChild'](this['index_']):_0x52ebb4['getLastChild'](this['index_']),_0x51ec4e=this['rangedFilter_']['matches'](_0x5bc423);if(_0x52ebb4['hasChild'](_0x199055)){const _0x148de4=_0x52ebb4['getImmediateChild'](_0x199055);let _0x5bf1c9=_0x1ab713['getChildAfterChild'](this['index_'],_0x3c0eba,this['reverse_']);for(;_0x5bf1c9!=null&&(_0x5bf1c9['name']===_0x199055||_0x52ebb4['hasChild'](_0x5bf1c9['name']));)_0x5bf1c9=_0x1ab713['getChildAfterChild'](this['index_'],_0x5bf1c9,this['reverse_']);const _0x127ba2=_0x5bf1c9==null?0x1:_0x1e0f4a(_0x5bf1c9,_0x5bc423);if(_0x51ec4e&&!_0x551269['isEmpty']()&&_0x127ba2>=0x0)return _0x5154b4!=null&&_0x5154b4['trackChildChange'](Pt(_0x199055,_0x551269,_0x148de4)),_0x52ebb4['updateImmediateChild'](_0x199055,_0x551269);{_0x5154b4!=null&&_0x5154b4['trackChildChange'](Nt(_0x199055,_0x148de4));const _0x45a446=_0x52ebb4['updateImmediateChild'](_0x199055,g['EMPTY_NODE']);return _0x5bf1c9!=null&&this['rangedFilter_']['matches'](_0x5bf1c9)?(_0x5154b4!=null&&_0x5154b4['trackChildChange'](tt(_0x5bf1c9['name'],_0x5bf1c9['node'])),_0x45a446['updateImmediateChild'](_0x5bf1c9['name'],_0x5bf1c9['node'])):_0x45a446;}}else return _0x551269['isEmpty']()?_0x211ee5:_0x51ec4e&&_0x1e0f4a(_0x3c0eba,_0x5bc423)>=0x0?(_0x5154b4!=null&&(_0x5154b4['trackChildChange'](Nt(_0x3c0eba['name'],_0x3c0eba['node'])),_0x5154b4['trackChildChange'](tt(_0x199055,_0x551269))),_0x52ebb4['updateImmediateChild'](_0x199055,_0x551269)['updateImmediateChild'](_0x3c0eba['name'],g['EMPTY_NODE'])):_0x211ee5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1d6359=new Qi();return _0x1d6359['limitSet_']=this['limitSet_'],_0x1d6359['limit_']=this['limit_'],_0x1d6359['startSet_']=this['startSet_'],_0x1d6359['startAfterSet_']=this['startAfterSet_'],_0x1d6359['indexStartValue_']=this['indexStartValue_'],_0x1d6359['startNameSet_']=this['startNameSet_'],_0x1d6359['indexStartName_']=this['indexStartName_'],_0x1d6359['endSet_']=this['endSet_'],_0x1d6359['endBeforeSet_']=this['endBeforeSet_'],_0x1d6359['indexEndValue_']=this['indexEndValue_'],_0x1d6359['endNameSet_']=this['endNameSet_'],_0x1d6359['indexEndName_']=this['indexEndName_'],_0x1d6359['index_']=this['index_'],_0x1d6359['viewFrom_']=this['viewFrom_'],_0x1d6359;}}function qh(_0x30c3b0){return _0x30c3b0['loadsAllData']()?new Yi(_0x30c3b0['getIndex']()):_0x30c3b0['hasLimit']()?new Gh(_0x30c3b0):new Ot(_0x30c3b0);}function zh(_0x398ae6,_0x2494f9){const _0x22c758=_0x398ae6['copy']();return _0x22c758['limitSet_']=!0x0,_0x22c758['limit_']=_0x2494f9,_0x22c758['viewFrom_']='l',_0x22c758;}function jh(_0x475811,_0x5a9f98,_0x2fa000){const _0x3c939a=_0x475811['copy']();return _0x3c939a['startSet_']=!0x0,_0x5a9f98===void 0x0&&(_0x5a9f98=null),_0x3c939a['indexStartValue_']=_0x5a9f98,_0x2fa000!=null?(_0x3c939a['startNameSet_']=!0x0,_0x3c939a['indexStartName_']=_0x2fa000):(_0x3c939a['startNameSet_']=!0x1,_0x3c939a['indexStartName_']=''),_0x3c939a;}function Kh(_0x23f0e8,_0x3c2096,_0x193aa9){const _0x1f2553=_0x23f0e8['copy']();return _0x1f2553['endSet_']=!0x0,_0x3c2096===void 0x0&&(_0x3c2096=null),_0x1f2553['indexEndValue_']=_0x3c2096,_0x193aa9!==void 0x0?(_0x1f2553['endNameSet_']=!0x0,_0x1f2553['indexEndName_']=_0x193aa9):(_0x1f2553['endNameSet_']=!0x1,_0x1f2553['indexEndName_']=''),_0x1f2553;}function Do(_0x3b7915,_0x3641a2){const _0x593ce5=_0x3b7915['copy']();return _0x593ce5['index_']=_0x3641a2,_0x593ce5;}function tr(_0x5728db){const _0x2cff1d={};if(_0x5728db['isDefault']())return _0x2cff1d;let _0x27d23e;if(_0x5728db['index_']===R?_0x27d23e='$priority':_0x5728db['index_']===Po?_0x27d23e='$value':_0x5728db['index_']===ye?_0x27d23e='$key':(f(_0x5728db['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x27d23e=_0x5728db['index_']['toString']()),_0x2cff1d['orderBy']=O(_0x27d23e),_0x5728db['startSet_']){const _0x2f4ee5=_0x5728db['startAfterSet_']?'startAfter':'startAt';_0x2cff1d[_0x2f4ee5]=O(_0x5728db['indexStartValue_']),_0x5728db['startNameSet_']&&(_0x2cff1d[_0x2f4ee5]+=','+O(_0x5728db['indexStartName_']));}if(_0x5728db['endSet_']){const _0x35b06a=_0x5728db['endBeforeSet_']?'endBefore':'endAt';_0x2cff1d[_0x35b06a]=O(_0x5728db['indexEndValue_']),_0x5728db['endNameSet_']&&(_0x2cff1d[_0x35b06a]+=','+O(_0x5728db['indexEndName_']));}return _0x5728db['limitSet_']&&(_0x5728db['isViewFromLeft']()?_0x2cff1d['limitToFirst']=_0x5728db['limit_']:_0x2cff1d['limitToLast']=_0x5728db['limit_']),_0x2cff1d;}function nr(_0x57b2e1){const _0x3ffaef={};if(_0x57b2e1['startSet_']&&(_0x3ffaef['sp']=_0x57b2e1['indexStartValue_'],_0x57b2e1['startNameSet_']&&(_0x3ffaef['sn']=_0x57b2e1['indexStartName_']),_0x3ffaef['sin']=!_0x57b2e1['startAfterSet_']),_0x57b2e1['endSet_']&&(_0x3ffaef['ep']=_0x57b2e1['indexEndValue_'],_0x57b2e1['endNameSet_']&&(_0x3ffaef['en']=_0x57b2e1['indexEndName_']),_0x3ffaef['ein']=!_0x57b2e1['endBeforeSet_']),_0x57b2e1['limitSet_']){_0x3ffaef['l']=_0x57b2e1['limit_'];let _0x3aa230=_0x57b2e1['viewFrom_'];_0x3aa230===''&&(_0x57b2e1['isViewFromLeft']()?_0x3aa230='l':_0x3aa230='r'),_0x3ffaef['vf']=_0x3aa230;}return _0x57b2e1['index_']!==R&&(_0x3ffaef['i']=_0x57b2e1['index_']['toString']()),_0x3ffaef;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x33636e){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2494ce,_0x1cc2c6){return _0x1cc2c6!==void 0x0?'tag$'+_0x1cc2c6:(f(_0x2494ce['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2494ce['_path']['toString']());}constructor(_0x134e70,_0x3d4b32,_0x31b647,_0x1e8934){super(),this['repoInfo_']=_0x134e70,this['onDataUpdate_']=_0x3d4b32,this['authTokenProvider_']=_0x31b647,this['appCheckTokenProvider_']=_0x1e8934,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x3043e9,_0x22d44e,_0x564339,_0x22d5f0){const _0x41020d=_0x3043e9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x41020d+'\x20'+_0x3043e9['_queryIdentifier']);const _0x5c0d3f=fn['getListenId_'](_0x3043e9,_0x564339),_0x43b438={};this['listens_'][_0x5c0d3f]=_0x43b438;const _0x900732=tr(_0x3043e9['_queryParams']);this['restRequest_'](_0x41020d+'.json',_0x900732,(_0x546e2a,_0x4993e4)=>{let _0x2804b7=_0x4993e4;if(_0x546e2a===0x194&&(_0x2804b7=null,_0x546e2a=null),_0x546e2a===null&&this['onDataUpdate_'](_0x41020d,_0x2804b7,!0x1,_0x564339),Oe(this['listens_'],_0x5c0d3f)===_0x43b438){let _0x1218aa;_0x546e2a?_0x546e2a===0x191?_0x1218aa='permission_denied':_0x1218aa='rest_error:'+_0x546e2a:_0x1218aa='ok',_0x22d5f0(_0x1218aa,null);}});}['unlisten'](_0x509397,_0x26ff9b){const _0x211d3a=fn['getListenId_'](_0x509397,_0x26ff9b);delete this['listens_'][_0x211d3a];}['get'](_0x570f81){const _0x194c4f=tr(_0x570f81['_queryParams']),_0x327285=_0x570f81['_path']['toString'](),_0x4be5f2=new Ve();return this['restRequest_'](_0x327285+'.json',_0x194c4f,(_0x28ea69,_0x5475e4)=>{let _0x17751a=_0x5475e4;_0x28ea69===0x194&&(_0x17751a=null,_0x28ea69=null),_0x28ea69===null?(this['onDataUpdate_'](_0x327285,_0x17751a,!0x1,null),_0x4be5f2['resolve'](_0x17751a)):_0x4be5f2['reject'](new Error(_0x17751a));}),_0x4be5f2['promise'];}['refreshAuthToken'](_0x469689){}['restRequest_'](_0x536413,_0x4f9b9c={},_0x36f9c7){return _0x4f9b9c['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1af993,_0x2cf06d])=>{_0x1af993&&_0x1af993['accessToken']&&(_0x4f9b9c['auth']=_0x1af993['accessToken']),_0x2cf06d&&_0x2cf06d['token']&&(_0x4f9b9c['ac']=_0x2cf06d['token']);const _0x328c74=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x536413+'?ns='+this['repoInfo_']['namespace']+at(_0x4f9b9c);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x328c74);const _0x4f8e4=new XMLHttpRequest();_0x4f8e4['onreadystatechange']=()=>{if(_0x36f9c7&&_0x4f8e4['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x328c74+'\x20received.\x20status:',_0x4f8e4['status'],'response:',_0x4f8e4['responseText']);let _0x539796=null;if(_0x4f8e4['status']>=0xc8&&_0x4f8e4['status']<0x12c){try{_0x539796=bt(_0x4f8e4['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x328c74+':\x20'+_0x4f8e4['responseText']);}_0x36f9c7(null,_0x539796);}else _0x4f8e4['status']!==0x191&&_0x4f8e4['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x328c74+'\x20Status:\x20'+_0x4f8e4['status']),_0x36f9c7(_0x4f8e4['status']);_0x36f9c7=null;}},_0x4f8e4['open']('GET',_0x328c74,!0x0),_0x4f8e4['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x259eb9){return this['rootNode_']['getChild'](_0x259eb9);}['updateSnapshot'](_0x395be6,_0x191dc5){this['rootNode_']=this['rootNode_']['updateChild'](_0x395be6,_0x191dc5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x3ea1e1,_0x1ab6d4,_0x288a61){if(v(_0x1ab6d4))_0x3ea1e1['value']=_0x288a61,_0x3ea1e1['children']['clear']();else{if(_0x3ea1e1['value']!==null)_0x3ea1e1['value']=_0x3ea1e1['value']['updateChild'](_0x1ab6d4,_0x288a61);else{const _0x18a0c6=y(_0x1ab6d4);_0x3ea1e1['children']['has'](_0x18a0c6)||_0x3ea1e1['children']['set'](_0x18a0c6,pn());const _0x410976=_0x3ea1e1['children']['get'](_0x18a0c6);_0x1ab6d4=b(_0x1ab6d4),Mo(_0x410976,_0x1ab6d4,_0x288a61);}}}function Ei(_0x15de5f,_0x17f79a,_0x5de078){_0x15de5f['value']!==null?_0x5de078(_0x17f79a,_0x15de5f['value']):Qh(_0x15de5f,(_0x5e60e9,_0x1dc6ea)=>{const _0x5802dd=new C(_0x17f79a['toString']()+'/'+_0x5e60e9);Ei(_0x1dc6ea,_0x5802dd,_0x5de078);});}function Qh(_0xc2c1f1,_0x5725c4){_0xc2c1f1['children']['forEach']((_0x360eae,_0x161d44)=>{_0x5725c4(_0x161d44,_0x360eae);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x7fe81a){this['collection_']=_0x7fe81a,this['last_']=null;}['get'](){const _0x2e66f0=this['collection_']['get'](),_0x1199ad={..._0x2e66f0};return this['last_']&&x(this['last_'],(_0x51e37a,_0x488107)=>{_0x1199ad[_0x51e37a]=_0x1199ad[_0x51e37a]-_0x488107;}),this['last_']=_0x2e66f0,_0x1199ad;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x387fc7,_0xdcd9ae){this['server_']=_0xdcd9ae,this['statsToReport_']={},this['statsListener_']=new Jh(_0x387fc7);const _0x140114=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x140114));}['reportStats_'](){const _0x3293d6=this['statsListener_']['get'](),_0x5840b4={};let _0x196cb9=!0x1;x(_0x3293d6,(_0x2d066a,_0x1a31d4)=>{_0x1a31d4>0x0&&Y(this['statsToReport_'],_0x2d066a)&&(_0x5840b4[_0x2d066a]=_0x1a31d4,_0x196cb9=!0x0);}),_0x196cb9&&this['server_']['reportStats'](_0x5840b4),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x452198){_0x452198[_0x452198['OVERWRITE']=0x0]='OVERWRITE',_0x452198[_0x452198['MERGE']=0x1]='MERGE',_0x452198[_0x452198['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x452198[_0x452198['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x3a55e2){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3a55e2,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x53ed11,_0x50798b,_0x2c42b7){this['path']=_0x53ed11,this['affectedTree']=_0x50798b,this['revert']=_0x2c42b7,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0xcfa2d0){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1f3bbb=this['affectedTree']['subtree'](new C(_0xcfa2d0));return new _n(w(),_0x1f3bbb,this['revert']);}}else return f(y(this['path'])===_0xcfa2d0,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x442803,_0x248cb8){this['source']=_0x442803,this['path']=_0x248cb8,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x16ba7c){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x5d008c,_0x1fae70,_0x135048){this['source']=_0x5d008c,this['path']=_0x1fae70,this['snap']=_0x135048,this['type']=q['OVERWRITE'];}['operationForChild'](_0x289fcf){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x289fcf)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0xeba4cc,_0x3c0aa7,_0x444e05){this['source']=_0xeba4cc,this['path']=_0x3c0aa7,this['children']=_0x444e05,this['type']=q['MERGE'];}['operationForChild'](_0x39b706){if(v(this['path'])){const _0x25b000=this['children']['subtree'](new C(_0x39b706));return _0x25b000['isEmpty']()?null:_0x25b000['value']?new Fe(this['source'],w(),_0x25b000['value']):new nt(this['source'],w(),_0x25b000);}else return f(y(this['path'])===_0x39b706,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x310655,_0xa3f109,_0x4cf056){this['node_']=_0x310655,this['fullyInitialized_']=_0xa3f109,this['filtered_']=_0x4cf056;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4674c2){if(v(_0x4674c2))return this['isFullyInitialized']()&&!this['filtered_'];const _0x33c822=y(_0x4674c2);return this['isCompleteForChild'](_0x33c822);}['isCompleteForChild'](_0x1ba5de){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1ba5de);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2b2984){this['query_']=_0x2b2984,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x19898d,_0x461444,_0x11276b,_0x3aebff){const _0x3e53de=[],_0x1375db=[];return _0x461444['forEach'](_0xf7a3=>{_0xf7a3['type']==='child_changed'&&_0x19898d['index_']['indexedValueChanged'](_0xf7a3['oldSnap'],_0xf7a3['snapshotNode'])&&_0x1375db['push']($h(_0xf7a3['childName'],_0xf7a3['snapshotNode']));}),mt(_0x19898d,_0x3e53de,'child_removed',_0x461444,_0x3aebff,_0x11276b),mt(_0x19898d,_0x3e53de,'child_added',_0x461444,_0x3aebff,_0x11276b),mt(_0x19898d,_0x3e53de,'child_moved',_0x1375db,_0x3aebff,_0x11276b),mt(_0x19898d,_0x3e53de,'child_changed',_0x461444,_0x3aebff,_0x11276b),mt(_0x19898d,_0x3e53de,'value',_0x461444,_0x3aebff,_0x11276b),_0x3e53de;}function mt(_0x7698ff,_0x5156d7,_0x1ead27,_0x20e4cf,_0x3c6259,_0xa0c9b2){const _0x4accb9=_0x20e4cf['filter'](_0x242af3=>_0x242af3['type']===_0x1ead27);_0x4accb9['sort']((_0x4ab00d,_0x3f9c81)=>su(_0x7698ff,_0x4ab00d,_0x3f9c81)),_0x4accb9['forEach'](_0x354d98=>{const _0x53a332=iu(_0x7698ff,_0x354d98,_0xa0c9b2);_0x3c6259['forEach'](_0x18f02c=>{_0x18f02c['respondsTo'](_0x354d98['type'])&&_0x5156d7['push'](_0x18f02c['createEvent'](_0x53a332,_0x7698ff['query_']));});});}function iu(_0x32f466,_0x2f3246,_0x2d977b){return _0x2f3246['type']==='value'||_0x2f3246['type']==='child_removed'||(_0x2f3246['prevName']=_0x2d977b['getPredecessorChildName'](_0x2f3246['childName'],_0x2f3246['snapshotNode'],_0x32f466['index_'])),_0x2f3246;}function su(_0xa21deb,_0x343239,_0x4d8ad0){if(_0x343239['childName']==null||_0x4d8ad0['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x5675da=new E(_0x343239['childName'],_0x343239['snapshotNode']),_0x410b5f=new E(_0x4d8ad0['childName'],_0x4d8ad0['snapshotNode']);return _0xa21deb['index_']['compare'](_0x5675da,_0x410b5f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x405221,_0x3fb630){return{'eventCache':_0x405221,'serverCache':_0x3fb630};}function wt(_0x33fdc4,_0xe0ae7e,_0x2e1ed6,_0x1c542c){return Dn(new Ce(_0xe0ae7e,_0x2e1ed6,_0x1c542c),_0x33fdc4['serverCache']);}function Lo(_0x7d688a,_0x515850,_0x3ace57,_0x43d85c){return Dn(_0x7d688a['eventCache'],new Ce(_0x515850,_0x3ace57,_0x43d85c));}function gn(_0x160bf4){return _0x160bf4['eventCache']['isFullyInitialized']()?_0x160bf4['eventCache']['getNode']():null;}function Ue(_0x1f526e){return _0x1f526e['serverCache']['isFullyInitialized']()?_0x1f526e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x233777){let _0x373500=new S(null);return x(_0x233777,(_0x8fd19,_0x1017b3)=>{_0x373500=_0x373500['set'](new C(_0x8fd19),_0x1017b3);}),_0x373500;}constructor(_0x291a1e,_0x1ab2cb=ru()){this['value']=_0x291a1e,this['children']=_0x1ab2cb;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x486792,_0x2e1520){if(this['value']!=null&&_0x2e1520(this['value']))return{'path':w(),'value':this['value']};if(v(_0x486792))return null;{const _0xcef24a=y(_0x486792),_0xf7e35d=this['children']['get'](_0xcef24a);if(_0xf7e35d!==null){const _0x3295b9=_0xf7e35d['findRootMostMatchingPathAndValue'](b(_0x486792),_0x2e1520);return _0x3295b9!=null?{'path':A(new C(_0xcef24a),_0x3295b9['path']),'value':_0x3295b9['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x341196){return this['findRootMostMatchingPathAndValue'](_0x341196,()=>!0x0);}['subtree'](_0xaed689){if(v(_0xaed689))return this;{const _0x483af3=y(_0xaed689),_0xd7519a=this['children']['get'](_0x483af3);return _0xd7519a!==null?_0xd7519a['subtree'](b(_0xaed689)):new S(null);}}['set'](_0x15af9a,_0x2d212e){if(v(_0x15af9a))return new S(_0x2d212e,this['children']);{const _0xeccaf4=y(_0x15af9a),_0x10fe81=(this['children']['get'](_0xeccaf4)||new S(null))['set'](b(_0x15af9a),_0x2d212e),_0x65135e=this['children']['insert'](_0xeccaf4,_0x10fe81);return new S(this['value'],_0x65135e);}}['remove'](_0x5c0ed0){if(v(_0x5c0ed0))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4f4637=y(_0x5c0ed0),_0x46dca4=this['children']['get'](_0x4f4637);if(_0x46dca4){const _0x437fd2=_0x46dca4['remove'](b(_0x5c0ed0));let _0x5a9efa;return _0x437fd2['isEmpty']()?_0x5a9efa=this['children']['remove'](_0x4f4637):_0x5a9efa=this['children']['insert'](_0x4f4637,_0x437fd2),this['value']===null&&_0x5a9efa['isEmpty']()?new S(null):new S(this['value'],_0x5a9efa);}else return this;}}['get'](_0x138b80){if(v(_0x138b80))return this['value'];{const _0x30b5b8=y(_0x138b80),_0x25d35f=this['children']['get'](_0x30b5b8);return _0x25d35f?_0x25d35f['get'](b(_0x138b80)):null;}}['setTree'](_0x505750,_0x154ab3){if(v(_0x505750))return _0x154ab3;{const _0x1bd2b1=y(_0x505750),_0x729c89=(this['children']['get'](_0x1bd2b1)||new S(null))['setTree'](b(_0x505750),_0x154ab3);let _0xaf4ddd;return _0x729c89['isEmpty']()?_0xaf4ddd=this['children']['remove'](_0x1bd2b1):_0xaf4ddd=this['children']['insert'](_0x1bd2b1,_0x729c89),new S(this['value'],_0xaf4ddd);}}['fold'](_0x1bdf03){return this['fold_'](w(),_0x1bdf03);}['fold_'](_0x1766f6,_0x822c56){const _0x5decad={};return this['children']['inorderTraversal']((_0x3eea24,_0xdbe7c7)=>{_0x5decad[_0x3eea24]=_0xdbe7c7['fold_'](A(_0x1766f6,_0x3eea24),_0x822c56);}),_0x822c56(_0x1766f6,this['value'],_0x5decad);}['findOnPath'](_0x595f4a,_0xde3c60){return this['findOnPath_'](_0x595f4a,w(),_0xde3c60);}['findOnPath_'](_0x19bc0a,_0x363777,_0x209a0e){const _0x3fdd7f=this['value']?_0x209a0e(_0x363777,this['value']):!0x1;if(_0x3fdd7f)return _0x3fdd7f;if(v(_0x19bc0a))return null;{const _0x7906b7=y(_0x19bc0a),_0x4f49a7=this['children']['get'](_0x7906b7);return _0x4f49a7?_0x4f49a7['findOnPath_'](b(_0x19bc0a),A(_0x363777,_0x7906b7),_0x209a0e):null;}}['foreachOnPath'](_0x8d6396,_0x4a5f99){return this['foreachOnPath_'](_0x8d6396,w(),_0x4a5f99);}['foreachOnPath_'](_0x211b3c,_0x1a970f,_0x4b175a){if(v(_0x211b3c))return this;{this['value']&&_0x4b175a(_0x1a970f,this['value']);const _0x40b421=y(_0x211b3c),_0x2ecb16=this['children']['get'](_0x40b421);return _0x2ecb16?_0x2ecb16['foreachOnPath_'](b(_0x211b3c),A(_0x1a970f,_0x40b421),_0x4b175a):new S(null);}}['foreach'](_0x12907f){this['foreach_'](w(),_0x12907f);}['foreach_'](_0x42e35f,_0x24230b){this['children']['inorderTraversal']((_0x4aeb98,_0x443ebd)=>{_0x443ebd['foreach_'](A(_0x42e35f,_0x4aeb98),_0x24230b);}),this['value']&&_0x24230b(_0x42e35f,this['value']);}['foreachChild'](_0x327746){this['children']['inorderTraversal']((_0x1c706c,_0x3a2c64)=>{_0x3a2c64['value']&&_0x327746(_0x1c706c,_0x3a2c64['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x48bd6a){this['writeTree_']=_0x48bd6a;}static['empty'](){return new j(new S(null));}}function Ct(_0x178c31,_0x4e72bd,_0x501c64){if(v(_0x4e72bd))return new j(new S(_0x501c64));{const _0x253d71=_0x178c31['writeTree_']['findRootMostValueAndPath'](_0x4e72bd);if(_0x253d71!=null){const _0x48e4dc=_0x253d71['path'];let _0x39e900=_0x253d71['value'];const _0x290196=F(_0x48e4dc,_0x4e72bd);return _0x39e900=_0x39e900['updateChild'](_0x290196,_0x501c64),new j(_0x178c31['writeTree_']['set'](_0x48e4dc,_0x39e900));}else{const _0x15e286=new S(_0x501c64),_0x1616e0=_0x178c31['writeTree_']['setTree'](_0x4e72bd,_0x15e286);return new j(_0x1616e0);}}}function Ii(_0x67d69,_0x1650bb,_0x30372e){let _0x1d6e4e=_0x67d69;return x(_0x30372e,(_0x14faa3,_0x1e91b4)=>{_0x1d6e4e=Ct(_0x1d6e4e,A(_0x1650bb,_0x14faa3),_0x1e91b4);}),_0x1d6e4e;}function sr(_0x604ebe,_0x55fcdd){if(v(_0x55fcdd))return j['empty']();{const _0x54b8c6=_0x604ebe['writeTree_']['setTree'](_0x55fcdd,new S(null));return new j(_0x54b8c6);}}function wi(_0x10dad6,_0x3fde0a){return $e(_0x10dad6,_0x3fde0a)!=null;}function $e(_0x57d8ab,_0xe66388){const _0x4b4000=_0x57d8ab['writeTree_']['findRootMostValueAndPath'](_0xe66388);return _0x4b4000!=null?_0x57d8ab['writeTree_']['get'](_0x4b4000['path'])['getChild'](F(_0x4b4000['path'],_0xe66388)):null;}function rr(_0x527491){const _0x524cd9=[],_0x5d5a89=_0x527491['writeTree_']['value'];return _0x5d5a89!=null?_0x5d5a89['isLeafNode']()||_0x5d5a89['forEachChild'](R,(_0x151dcd,_0x43dcc5)=>{_0x524cd9['push'](new E(_0x151dcd,_0x43dcc5));}):_0x527491['writeTree_']['children']['inorderTraversal']((_0x29942e,_0x3052a1)=>{_0x3052a1['value']!=null&&_0x524cd9['push'](new E(_0x29942e,_0x3052a1['value']));}),_0x524cd9;}function ve(_0x355dc9,_0x21ee8f){if(v(_0x21ee8f))return _0x355dc9;{const _0x2ae6b2=$e(_0x355dc9,_0x21ee8f);return _0x2ae6b2!=null?new j(new S(_0x2ae6b2)):new j(_0x355dc9['writeTree_']['subtree'](_0x21ee8f));}}function Ci(_0x505fa0){return _0x505fa0['writeTree_']['isEmpty']();}function it(_0x457bbf,_0xdfe0db){return xo(w(),_0x457bbf['writeTree_'],_0xdfe0db);}function xo(_0x420451,_0x41f46c,_0x13682a){if(_0x41f46c['value']!=null)return _0x13682a['updateChild'](_0x420451,_0x41f46c['value']);{let _0x2f3faf=null;return _0x41f46c['children']['inorderTraversal']((_0x25156a,_0xb88620)=>{_0x25156a==='.priority'?(f(_0xb88620['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2f3faf=_0xb88620['value']):_0x13682a=xo(A(_0x420451,_0x25156a),_0xb88620,_0x13682a);}),!_0x13682a['getChild'](_0x420451)['isEmpty']()&&_0x2f3faf!==null&&(_0x13682a=_0x13682a['updateChild'](A(_0x420451,'.priority'),_0x2f3faf)),_0x13682a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1e870d,_0x4f0480){return Bo(_0x4f0480,_0x1e870d);}function ou(_0x4e45c2,_0x1369b1,_0x10f7b6,_0x61d564,_0xc77357){f(_0x61d564>_0x4e45c2['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xc77357===void 0x0&&(_0xc77357=!0x0),_0x4e45c2['allWrites']['push']({'path':_0x1369b1,'snap':_0x10f7b6,'writeId':_0x61d564,'visible':_0xc77357}),_0xc77357&&(_0x4e45c2['visibleWrites']=Ct(_0x4e45c2['visibleWrites'],_0x1369b1,_0x10f7b6)),_0x4e45c2['lastWriteId']=_0x61d564;}function au(_0x242204,_0x3bec8b,_0x38bc05,_0x7c443e){f(_0x7c443e>_0x242204['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x242204['allWrites']['push']({'path':_0x3bec8b,'children':_0x38bc05,'writeId':_0x7c443e,'visible':!0x0}),_0x242204['visibleWrites']=Ii(_0x242204['visibleWrites'],_0x3bec8b,_0x38bc05),_0x242204['lastWriteId']=_0x7c443e;}function cu(_0x2a8965,_0x498c45){for(let _0x5360c3=0x0;_0x5360c3<_0x2a8965['allWrites']['length'];_0x5360c3++){const _0x22ccdc=_0x2a8965['allWrites'][_0x5360c3];if(_0x22ccdc['writeId']===_0x498c45)return _0x22ccdc;}return null;}function lu(_0x5781d0,_0x45bf84){const _0x4a390e=_0x5781d0['allWrites']['findIndex'](_0xdb9fd9=>_0xdb9fd9['writeId']===_0x45bf84);f(_0x4a390e>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xa259f=_0x5781d0['allWrites'][_0x4a390e];_0x5781d0['allWrites']['splice'](_0x4a390e,0x1);let _0x4fae3f=_0xa259f['visible'],_0x2ee1ac=!0x1,_0x677d53=_0x5781d0['allWrites']['length']-0x1;for(;_0x4fae3f&&_0x677d53>=0x0;){const _0x4149b1=_0x5781d0['allWrites'][_0x677d53];_0x4149b1['visible']&&(_0x677d53>=_0x4a390e&&hu(_0x4149b1,_0xa259f['path'])?_0x4fae3f=!0x1:$(_0xa259f['path'],_0x4149b1['path'])&&(_0x2ee1ac=!0x0)),_0x677d53--;}if(_0x4fae3f){if(_0x2ee1ac)return uu(_0x5781d0),!0x0;if(_0xa259f['snap'])_0x5781d0['visibleWrites']=sr(_0x5781d0['visibleWrites'],_0xa259f['path']);else{const _0x5bc002=_0xa259f['children'];x(_0x5bc002,_0x24c4c7=>{_0x5781d0['visibleWrites']=sr(_0x5781d0['visibleWrites'],A(_0xa259f['path'],_0x24c4c7));});}return!0x0;}else return!0x1;}function hu(_0x553c66,_0x4f1d27){if(_0x553c66['snap'])return $(_0x553c66['path'],_0x4f1d27);for(const _0x2879db in _0x553c66['children'])if(_0x553c66['children']['hasOwnProperty'](_0x2879db)&&$(A(_0x553c66['path'],_0x2879db),_0x4f1d27))return!0x0;return!0x1;}function uu(_0x5d00d5){_0x5d00d5['visibleWrites']=Fo(_0x5d00d5['allWrites'],du,w()),_0x5d00d5['allWrites']['length']>0x0?_0x5d00d5['lastWriteId']=_0x5d00d5['allWrites'][_0x5d00d5['allWrites']['length']-0x1]['writeId']:_0x5d00d5['lastWriteId']=-0x1;}function du(_0x76b322){return _0x76b322['visible'];}function Fo(_0x42ea9c,_0xeba73b,_0x5621aa){let _0x54a563=j['empty']();for(let _0xad0652=0x0;_0xad0652<_0x42ea9c['length'];++_0xad0652){const _0x351230=_0x42ea9c[_0xad0652];if(_0xeba73b(_0x351230)){const _0x17a57c=_0x351230['path'];let _0x1e23cf;if(_0x351230['snap'])$(_0x5621aa,_0x17a57c)?(_0x1e23cf=F(_0x5621aa,_0x17a57c),_0x54a563=Ct(_0x54a563,_0x1e23cf,_0x351230['snap'])):$(_0x17a57c,_0x5621aa)&&(_0x1e23cf=F(_0x17a57c,_0x5621aa),_0x54a563=Ct(_0x54a563,w(),_0x351230['snap']['getChild'](_0x1e23cf)));else{if(_0x351230['children']){if($(_0x5621aa,_0x17a57c))_0x1e23cf=F(_0x5621aa,_0x17a57c),_0x54a563=Ii(_0x54a563,_0x1e23cf,_0x351230['children']);else{if($(_0x17a57c,_0x5621aa)){if(_0x1e23cf=F(_0x17a57c,_0x5621aa),v(_0x1e23cf))_0x54a563=Ii(_0x54a563,w(),_0x351230['children']);else{const _0x57c23a=Oe(_0x351230['children'],y(_0x1e23cf));if(_0x57c23a){const _0x57aa78=_0x57c23a['getChild'](b(_0x1e23cf));_0x54a563=Ct(_0x54a563,w(),_0x57aa78);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x54a563;}function Uo(_0x6fc257,_0x4603fd,_0x1a71e0,_0x25e242,_0x36f204){if(!_0x25e242&&!_0x36f204){const _0x3aeae8=$e(_0x6fc257['visibleWrites'],_0x4603fd);if(_0x3aeae8!=null)return _0x3aeae8;{const _0x38ecaf=ve(_0x6fc257['visibleWrites'],_0x4603fd);if(Ci(_0x38ecaf))return _0x1a71e0;if(_0x1a71e0==null&&!wi(_0x38ecaf,w()))return null;{const _0x23de14=_0x1a71e0||g['EMPTY_NODE'];return it(_0x38ecaf,_0x23de14);}}}else{const _0x41196e=ve(_0x6fc257['visibleWrites'],_0x4603fd);if(!_0x36f204&&Ci(_0x41196e))return _0x1a71e0;if(!_0x36f204&&_0x1a71e0==null&&!wi(_0x41196e,w()))return null;{const _0x5d4b93=function(_0x1192c0){return(_0x1192c0['visible']||_0x36f204)&&(!_0x25e242||!~_0x25e242['indexOf'](_0x1192c0['writeId']))&&($(_0x1192c0['path'],_0x4603fd)||$(_0x4603fd,_0x1192c0['path']));},_0x476f8a=Fo(_0x6fc257['allWrites'],_0x5d4b93,_0x4603fd),_0x183de1=_0x1a71e0||g['EMPTY_NODE'];return it(_0x476f8a,_0x183de1);}}}function fu(_0xe7f20b,_0x43c78f,_0x5e5a73){let _0x59bd60=g['EMPTY_NODE'];const _0x3107a0=$e(_0xe7f20b['visibleWrites'],_0x43c78f);if(_0x3107a0)return _0x3107a0['isLeafNode']()||_0x3107a0['forEachChild'](R,(_0x5b537f,_0x4c6063)=>{_0x59bd60=_0x59bd60['updateImmediateChild'](_0x5b537f,_0x4c6063);}),_0x59bd60;if(_0x5e5a73){const _0xd44288=ve(_0xe7f20b['visibleWrites'],_0x43c78f);return _0x5e5a73['forEachChild'](R,(_0xaae7a8,_0x433bf3)=>{const _0x50c3d0=it(ve(_0xd44288,new C(_0xaae7a8)),_0x433bf3);_0x59bd60=_0x59bd60['updateImmediateChild'](_0xaae7a8,_0x50c3d0);}),rr(_0xd44288)['forEach'](_0x2bab4a=>{_0x59bd60=_0x59bd60['updateImmediateChild'](_0x2bab4a['name'],_0x2bab4a['node']);}),_0x59bd60;}else{const _0x2c28e1=ve(_0xe7f20b['visibleWrites'],_0x43c78f);return rr(_0x2c28e1)['forEach'](_0x5331d0=>{_0x59bd60=_0x59bd60['updateImmediateChild'](_0x5331d0['name'],_0x5331d0['node']);}),_0x59bd60;}}function pu(_0x313aaf,_0x32bff0,_0x119f1d,_0x385921,_0x22e622){f(_0x385921||_0x22e622,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1ada6b=A(_0x32bff0,_0x119f1d);if(wi(_0x313aaf['visibleWrites'],_0x1ada6b))return null;{const _0x2db69d=ve(_0x313aaf['visibleWrites'],_0x1ada6b);return Ci(_0x2db69d)?_0x22e622['getChild'](_0x119f1d):it(_0x2db69d,_0x22e622['getChild'](_0x119f1d));}}function _u(_0x32d81f,_0x53a8ed,_0x49507e,_0x2df67c){const _0x27af47=A(_0x53a8ed,_0x49507e),_0x49c0c3=$e(_0x32d81f['visibleWrites'],_0x27af47);if(_0x49c0c3!=null)return _0x49c0c3;if(_0x2df67c['isCompleteForChild'](_0x49507e)){const _0x292209=ve(_0x32d81f['visibleWrites'],_0x27af47);return it(_0x292209,_0x2df67c['getNode']()['getImmediateChild'](_0x49507e));}else return null;}function gu(_0x20cde5,_0x56f2a2){return $e(_0x20cde5['visibleWrites'],_0x56f2a2);}function mu(_0x51c7a5,_0xcb87ec,_0x3700fa,_0xee3ad,_0x4ac670,_0x4d705e,_0x1b1ea8){let _0x4b1773;const _0x30c968=ve(_0x51c7a5['visibleWrites'],_0xcb87ec),_0x346aaf=$e(_0x30c968,w());if(_0x346aaf!=null)_0x4b1773=_0x346aaf;else{if(_0x3700fa!=null)_0x4b1773=it(_0x30c968,_0x3700fa);else return[];}if(_0x4b1773=_0x4b1773['withIndex'](_0x1b1ea8),!_0x4b1773['isEmpty']()&&!_0x4b1773['isLeafNode']()){const _0x557460=[],_0xc9891b=_0x1b1ea8['getCompare'](),_0xdff8be=_0x4d705e?_0x4b1773['getReverseIteratorFrom'](_0xee3ad,_0x1b1ea8):_0x4b1773['getIteratorFrom'](_0xee3ad,_0x1b1ea8);let _0x1320c9=_0xdff8be['getNext']();for(;_0x1320c9&&_0x557460['length']<_0x4ac670;)_0xc9891b(_0x1320c9,_0xee3ad)!==0x0&&_0x557460['push'](_0x1320c9),_0x1320c9=_0xdff8be['getNext']();return _0x557460;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x45cba7,_0x2abaac,_0x521706,_0x7d076e){return Uo(_0x45cba7['writeTree'],_0x45cba7['treePath'],_0x2abaac,_0x521706,_0x7d076e);}function es(_0x4e549e,_0x45b0f2){return fu(_0x4e549e['writeTree'],_0x4e549e['treePath'],_0x45b0f2);}function or(_0x20fd24,_0x143b05,_0xc4f259,_0x2a88a4){return pu(_0x20fd24['writeTree'],_0x20fd24['treePath'],_0x143b05,_0xc4f259,_0x2a88a4);}function yn(_0x46981f,_0x51f37b){return gu(_0x46981f['writeTree'],A(_0x46981f['treePath'],_0x51f37b));}function vu(_0x2c1218,_0x4d1e90,_0x1be7a2,_0x5b03b9,_0x1bc1c4,_0x493b34){return mu(_0x2c1218['writeTree'],_0x2c1218['treePath'],_0x4d1e90,_0x1be7a2,_0x5b03b9,_0x1bc1c4,_0x493b34);}function ts(_0x15bf7b,_0x5d3b26,_0x2f1209){return _u(_0x15bf7b['writeTree'],_0x15bf7b['treePath'],_0x5d3b26,_0x2f1209);}function Wo(_0x5bd6dd,_0x1d2e30){return Bo(A(_0x5bd6dd['treePath'],_0x1d2e30),_0x5bd6dd['writeTree']);}function Bo(_0x44031a,_0x17b9a9){return{'treePath':_0x44031a,'writeTree':_0x17b9a9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2ddf61){const _0x49e355=_0x2ddf61['type'],_0x53f7f7=_0x2ddf61['childName'];f(_0x49e355==='child_added'||_0x49e355==='child_changed'||_0x49e355==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x53f7f7!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x33ee35=this['changeMap']['get'](_0x53f7f7);if(_0x33ee35){const _0x53a8ae=_0x33ee35['type'];if(_0x49e355==='child_added'&&_0x53a8ae==='child_removed')this['changeMap']['set'](_0x53f7f7,Pt(_0x53f7f7,_0x2ddf61['snapshotNode'],_0x33ee35['snapshotNode']));else{if(_0x49e355==='child_removed'&&_0x53a8ae==='child_added')this['changeMap']['delete'](_0x53f7f7);else{if(_0x49e355==='child_removed'&&_0x53a8ae==='child_changed')this['changeMap']['set'](_0x53f7f7,Nt(_0x53f7f7,_0x33ee35['oldSnap']));else{if(_0x49e355==='child_changed'&&_0x53a8ae==='child_added')this['changeMap']['set'](_0x53f7f7,tt(_0x53f7f7,_0x2ddf61['snapshotNode']));else{if(_0x49e355==='child_changed'&&_0x53a8ae==='child_changed')this['changeMap']['set'](_0x53f7f7,Pt(_0x53f7f7,_0x2ddf61['snapshotNode'],_0x33ee35['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x2ddf61+'\x20occurred\x20after\x20'+_0x33ee35);}}}}}else this['changeMap']['set'](_0x53f7f7,_0x2ddf61);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x59698c){return null;}['getChildAfterChild'](_0x234b97,_0x4ce7dd,_0x59a76e){return null;}}const Vo=new Iu();class ns{constructor(_0x18dce2,_0x30c7ed,_0xa21e01=null){this['writes_']=_0x18dce2,this['viewCache_']=_0x30c7ed,this['optCompleteServerCache_']=_0xa21e01;}['getCompleteChild'](_0x187b19){const _0x2cb59c=this['viewCache_']['eventCache'];if(_0x2cb59c['isCompleteForChild'](_0x187b19))return _0x2cb59c['getNode']()['getImmediateChild'](_0x187b19);{const _0xfb6dbd=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x187b19,_0xfb6dbd);}}['getChildAfterChild'](_0x3a5bb7,_0x4c8450,_0x407579){const _0x31b729=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x271ef1=vu(this['writes_'],_0x31b729,_0x4c8450,0x1,_0x407579,_0x3a5bb7);return _0x271ef1['length']===0x0?null:_0x271ef1[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x46ba13){return{'filter':_0x46ba13};}function Cu(_0x468a03,_0x5a99d2){f(_0x5a99d2['eventCache']['getNode']()['isIndexed'](_0x468a03['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5a99d2['serverCache']['getNode']()['isIndexed'](_0x468a03['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x2762ac,_0x3262d4,_0x57a7f0,_0x1c35ca,_0x5daf7d){const _0x21d550=new Eu();let _0x568fb8,_0xb20f32;if(_0x57a7f0['type']===q['OVERWRITE']){const _0x2e5c83=_0x57a7f0;_0x2e5c83['source']['fromUser']?_0x568fb8=Ti(_0x2762ac,_0x3262d4,_0x2e5c83['path'],_0x2e5c83['snap'],_0x1c35ca,_0x5daf7d,_0x21d550):(f(_0x2e5c83['source']['fromServer'],'Unknown\x20source.'),_0xb20f32=_0x2e5c83['source']['tagged']||_0x3262d4['serverCache']['isFiltered']()&&!v(_0x2e5c83['path']),_0x568fb8=vn(_0x2762ac,_0x3262d4,_0x2e5c83['path'],_0x2e5c83['snap'],_0x1c35ca,_0x5daf7d,_0xb20f32,_0x21d550));}else{if(_0x57a7f0['type']===q['MERGE']){const _0x3580ff=_0x57a7f0;_0x3580ff['source']['fromUser']?_0x568fb8=bu(_0x2762ac,_0x3262d4,_0x3580ff['path'],_0x3580ff['children'],_0x1c35ca,_0x5daf7d,_0x21d550):(f(_0x3580ff['source']['fromServer'],'Unknown\x20source.'),_0xb20f32=_0x3580ff['source']['tagged']||_0x3262d4['serverCache']['isFiltered'](),_0x568fb8=Si(_0x2762ac,_0x3262d4,_0x3580ff['path'],_0x3580ff['children'],_0x1c35ca,_0x5daf7d,_0xb20f32,_0x21d550));}else{if(_0x57a7f0['type']===q['ACK_USER_WRITE']){const _0x7fad62=_0x57a7f0;_0x7fad62['revert']?_0x568fb8=ku(_0x2762ac,_0x3262d4,_0x7fad62['path'],_0x1c35ca,_0x5daf7d,_0x21d550):_0x568fb8=Ru(_0x2762ac,_0x3262d4,_0x7fad62['path'],_0x7fad62['affectedTree'],_0x1c35ca,_0x5daf7d,_0x21d550);}else{if(_0x57a7f0['type']===q['LISTEN_COMPLETE'])_0x568fb8=Au(_0x2762ac,_0x3262d4,_0x57a7f0['path'],_0x1c35ca,_0x21d550);else throw ot('Unknown\x20operation\x20type:\x20'+_0x57a7f0['type']);}}}const _0x562642=_0x21d550['getChanges']();return Su(_0x3262d4,_0x568fb8,_0x562642),{'viewCache':_0x568fb8,'changes':_0x562642};}function Su(_0x39fed3,_0x214b48,_0x9a2fd3){const _0x1c1591=_0x214b48['eventCache'];if(_0x1c1591['isFullyInitialized']()){const _0x1ca103=_0x1c1591['getNode']()['isLeafNode']()||_0x1c1591['getNode']()['isEmpty'](),_0x264c31=gn(_0x39fed3);(_0x9a2fd3['length']>0x0||!_0x39fed3['eventCache']['isFullyInitialized']()||_0x1ca103&&!_0x1c1591['getNode']()['equals'](_0x264c31)||!_0x1c1591['getNode']()['getPriority']()['equals'](_0x264c31['getPriority']()))&&_0x9a2fd3['push'](Oo(gn(_0x214b48)));}}function Ho(_0x4684ee,_0x3a69ca,_0x504612,_0x2aa399,_0x33a925,_0x4ac339){const _0x1b9440=_0x3a69ca['eventCache'];if(yn(_0x2aa399,_0x504612)!=null)return _0x3a69ca;{let _0x307e03,_0x52010d;if(v(_0x504612)){if(f(_0x3a69ca['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3a69ca['serverCache']['isFiltered']()){const _0x1b733e=Ue(_0x3a69ca),_0x2f7fec=_0x1b733e instanceof g?_0x1b733e:g['EMPTY_NODE'],_0x1ab9ea=es(_0x2aa399,_0x2f7fec);_0x307e03=_0x4684ee['filter']['updateFullNode'](_0x3a69ca['eventCache']['getNode'](),_0x1ab9ea,_0x4ac339);}else{const _0x209780=mn(_0x2aa399,Ue(_0x3a69ca));_0x307e03=_0x4684ee['filter']['updateFullNode'](_0x3a69ca['eventCache']['getNode'](),_0x209780,_0x4ac339);}}else{const _0x31d0b6=y(_0x504612);if(_0x31d0b6==='.priority'){f(we(_0x504612)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x419970=_0x1b9440['getNode']();_0x52010d=_0x3a69ca['serverCache']['getNode']();const _0x35d759=or(_0x2aa399,_0x504612,_0x419970,_0x52010d);_0x35d759!=null?_0x307e03=_0x4684ee['filter']['updatePriority'](_0x419970,_0x35d759):_0x307e03=_0x1b9440['getNode']();}else{const _0x524c81=b(_0x504612);let _0x55c1c6;if(_0x1b9440['isCompleteForChild'](_0x31d0b6)){_0x52010d=_0x3a69ca['serverCache']['getNode']();const _0x50bcf7=or(_0x2aa399,_0x504612,_0x1b9440['getNode'](),_0x52010d);_0x50bcf7!=null?_0x55c1c6=_0x1b9440['getNode']()['getImmediateChild'](_0x31d0b6)['updateChild'](_0x524c81,_0x50bcf7):_0x55c1c6=_0x1b9440['getNode']()['getImmediateChild'](_0x31d0b6);}else _0x55c1c6=ts(_0x2aa399,_0x31d0b6,_0x3a69ca['serverCache']);_0x55c1c6!=null?_0x307e03=_0x4684ee['filter']['updateChild'](_0x1b9440['getNode'](),_0x31d0b6,_0x55c1c6,_0x524c81,_0x33a925,_0x4ac339):_0x307e03=_0x1b9440['getNode']();}}return wt(_0x3a69ca,_0x307e03,_0x1b9440['isFullyInitialized']()||v(_0x504612),_0x4684ee['filter']['filtersNodes']());}}function vn(_0x283e6c,_0x330826,_0x56fb85,_0x222533,_0x1bb0e2,_0x5a02f8,_0x3a85c2,_0x511a75){const _0xef4f03=_0x330826['serverCache'];let _0x59d879;const _0x5826bb=_0x3a85c2?_0x283e6c['filter']:_0x283e6c['filter']['getIndexedFilter']();if(v(_0x56fb85))_0x59d879=_0x5826bb['updateFullNode'](_0xef4f03['getNode'](),_0x222533,null);else{if(_0x5826bb['filtersNodes']()&&!_0xef4f03['isFiltered']()){const _0x56353a=_0xef4f03['getNode']()['updateChild'](_0x56fb85,_0x222533);_0x59d879=_0x5826bb['updateFullNode'](_0xef4f03['getNode'](),_0x56353a,null);}else{const _0x38fed1=y(_0x56fb85);if(!_0xef4f03['isCompleteForPath'](_0x56fb85)&&we(_0x56fb85)>0x1)return _0x330826;const _0x1f7d44=b(_0x56fb85),_0x341a2b=_0xef4f03['getNode']()['getImmediateChild'](_0x38fed1)['updateChild'](_0x1f7d44,_0x222533);_0x38fed1==='.priority'?_0x59d879=_0x5826bb['updatePriority'](_0xef4f03['getNode'](),_0x341a2b):_0x59d879=_0x5826bb['updateChild'](_0xef4f03['getNode'](),_0x38fed1,_0x341a2b,_0x1f7d44,Vo,null);}}const _0x2f5330=Lo(_0x330826,_0x59d879,_0xef4f03['isFullyInitialized']()||v(_0x56fb85),_0x5826bb['filtersNodes']()),_0x5efda4=new ns(_0x1bb0e2,_0x2f5330,_0x5a02f8);return Ho(_0x283e6c,_0x2f5330,_0x56fb85,_0x1bb0e2,_0x5efda4,_0x511a75);}function Ti(_0x18bc9e,_0x2dd0e6,_0x3bb5bd,_0x545e3c,_0x28cf57,_0x49348e,_0x4f4872){const _0x46b14f=_0x2dd0e6['eventCache'];let _0x3986cc,_0x160674;const _0x585af1=new ns(_0x28cf57,_0x2dd0e6,_0x49348e);if(v(_0x3bb5bd))_0x160674=_0x18bc9e['filter']['updateFullNode'](_0x2dd0e6['eventCache']['getNode'](),_0x545e3c,_0x4f4872),_0x3986cc=wt(_0x2dd0e6,_0x160674,!0x0,_0x18bc9e['filter']['filtersNodes']());else{const _0x40e525=y(_0x3bb5bd);if(_0x40e525==='.priority')_0x160674=_0x18bc9e['filter']['updatePriority'](_0x2dd0e6['eventCache']['getNode'](),_0x545e3c),_0x3986cc=wt(_0x2dd0e6,_0x160674,_0x46b14f['isFullyInitialized'](),_0x46b14f['isFiltered']());else{const _0x23acde=b(_0x3bb5bd),_0x23a41f=_0x46b14f['getNode']()['getImmediateChild'](_0x40e525);let _0x2aee0d;if(v(_0x23acde))_0x2aee0d=_0x545e3c;else{const _0x16c9e5=_0x585af1['getCompleteChild'](_0x40e525);_0x16c9e5!=null?Gi(_0x23acde)==='.priority'&&_0x16c9e5['getChild'](To(_0x23acde))['isEmpty']()?_0x2aee0d=_0x16c9e5:_0x2aee0d=_0x16c9e5['updateChild'](_0x23acde,_0x545e3c):_0x2aee0d=g['EMPTY_NODE'];}if(_0x23a41f['equals'](_0x2aee0d))_0x3986cc=_0x2dd0e6;else{const _0x509a53=_0x18bc9e['filter']['updateChild'](_0x46b14f['getNode'](),_0x40e525,_0x2aee0d,_0x23acde,_0x585af1,_0x4f4872);_0x3986cc=wt(_0x2dd0e6,_0x509a53,_0x46b14f['isFullyInitialized'](),_0x18bc9e['filter']['filtersNodes']());}}}return _0x3986cc;}function ar(_0x47646e,_0x6be400){return _0x47646e['eventCache']['isCompleteForChild'](_0x6be400);}function bu(_0x125f70,_0x54d890,_0x4e2082,_0xf35044,_0x3709b7,_0x92a03,_0x1f0058){let _0x18cfb9=_0x54d890;return _0xf35044['foreach']((_0xa83055,_0x5a5f82)=>{const _0x5c68d8=A(_0x4e2082,_0xa83055);ar(_0x54d890,y(_0x5c68d8))&&(_0x18cfb9=Ti(_0x125f70,_0x18cfb9,_0x5c68d8,_0x5a5f82,_0x3709b7,_0x92a03,_0x1f0058));}),_0xf35044['foreach']((_0x5cc763,_0x2c3634)=>{const _0x46fbfa=A(_0x4e2082,_0x5cc763);ar(_0x54d890,y(_0x46fbfa))||(_0x18cfb9=Ti(_0x125f70,_0x18cfb9,_0x46fbfa,_0x2c3634,_0x3709b7,_0x92a03,_0x1f0058));}),_0x18cfb9;}function cr(_0x2801df,_0x4f40f8,_0x534d8c){return _0x534d8c['foreach']((_0x1acf27,_0x3c0fcc)=>{_0x4f40f8=_0x4f40f8['updateChild'](_0x1acf27,_0x3c0fcc);}),_0x4f40f8;}function Si(_0x190e6b,_0x40e0f6,_0x1140bc,_0x40765c,_0x22df89,_0x2bd68e,_0x3d0313,_0x3ed7b9){if(_0x40e0f6['serverCache']['getNode']()['isEmpty']()&&!_0x40e0f6['serverCache']['isFullyInitialized']())return _0x40e0f6;let _0x52dbdf=_0x40e0f6,_0x545bfc;v(_0x1140bc)?_0x545bfc=_0x40765c:_0x545bfc=new S(null)['setTree'](_0x1140bc,_0x40765c);const _0x1d1296=_0x40e0f6['serverCache']['getNode']();return _0x545bfc['children']['inorderTraversal']((_0x47ae7f,_0x25d9a1)=>{if(_0x1d1296['hasChild'](_0x47ae7f)){const _0x325a10=_0x40e0f6['serverCache']['getNode']()['getImmediateChild'](_0x47ae7f),_0x3c12ef=cr(_0x190e6b,_0x325a10,_0x25d9a1);_0x52dbdf=vn(_0x190e6b,_0x52dbdf,new C(_0x47ae7f),_0x3c12ef,_0x22df89,_0x2bd68e,_0x3d0313,_0x3ed7b9);}}),_0x545bfc['children']['inorderTraversal']((_0x13d9e0,_0x12feea)=>{const _0x5015b6=!_0x40e0f6['serverCache']['isCompleteForChild'](_0x13d9e0)&&_0x12feea['value']===null;if(!_0x1d1296['hasChild'](_0x13d9e0)&&!_0x5015b6){const _0x68327d=_0x40e0f6['serverCache']['getNode']()['getImmediateChild'](_0x13d9e0),_0xc72513=cr(_0x190e6b,_0x68327d,_0x12feea);_0x52dbdf=vn(_0x190e6b,_0x52dbdf,new C(_0x13d9e0),_0xc72513,_0x22df89,_0x2bd68e,_0x3d0313,_0x3ed7b9);}}),_0x52dbdf;}function Ru(_0x37e765,_0x1c9b08,_0x35f5c6,_0x461eaf,_0x593ded,_0x54fd55,_0x3c3a59){if(yn(_0x593ded,_0x35f5c6)!=null)return _0x1c9b08;const _0x43bece=_0x1c9b08['serverCache']['isFiltered'](),_0x2f6b0c=_0x1c9b08['serverCache'];if(_0x461eaf['value']!=null){if(v(_0x35f5c6)&&_0x2f6b0c['isFullyInitialized']()||_0x2f6b0c['isCompleteForPath'](_0x35f5c6))return vn(_0x37e765,_0x1c9b08,_0x35f5c6,_0x2f6b0c['getNode']()['getChild'](_0x35f5c6),_0x593ded,_0x54fd55,_0x43bece,_0x3c3a59);if(v(_0x35f5c6)){let _0x3be28e=new S(null);return _0x2f6b0c['getNode']()['forEachChild'](ye,(_0x1fe0b3,_0x2a69c6)=>{_0x3be28e=_0x3be28e['set'](new C(_0x1fe0b3),_0x2a69c6);}),Si(_0x37e765,_0x1c9b08,_0x35f5c6,_0x3be28e,_0x593ded,_0x54fd55,_0x43bece,_0x3c3a59);}else return _0x1c9b08;}else{let _0x58cc53=new S(null);return _0x461eaf['foreach']((_0xeed21a,_0x51788e)=>{const _0x45e3f9=A(_0x35f5c6,_0xeed21a);_0x2f6b0c['isCompleteForPath'](_0x45e3f9)&&(_0x58cc53=_0x58cc53['set'](_0xeed21a,_0x2f6b0c['getNode']()['getChild'](_0x45e3f9)));}),Si(_0x37e765,_0x1c9b08,_0x35f5c6,_0x58cc53,_0x593ded,_0x54fd55,_0x43bece,_0x3c3a59);}}function Au(_0x5f30fb,_0x14e6cf,_0xc4eb5b,_0x4ef92c,_0x39c874){const _0xc46053=_0x14e6cf['serverCache'],_0x11bee3=Lo(_0x14e6cf,_0xc46053['getNode'](),_0xc46053['isFullyInitialized']()||v(_0xc4eb5b),_0xc46053['isFiltered']());return Ho(_0x5f30fb,_0x11bee3,_0xc4eb5b,_0x4ef92c,Vo,_0x39c874);}function ku(_0x3a331f,_0x35eca2,_0x4b64aa,_0x38e124,_0x6e5592,_0x12a072){let _0x4cb9f9;if(yn(_0x38e124,_0x4b64aa)!=null)return _0x35eca2;{const _0x222e1a=new ns(_0x38e124,_0x35eca2,_0x6e5592),_0x5e5a57=_0x35eca2['eventCache']['getNode']();let _0x3f0c4e;if(v(_0x4b64aa)||y(_0x4b64aa)==='.priority'){let _0x18944d;if(_0x35eca2['serverCache']['isFullyInitialized']())_0x18944d=mn(_0x38e124,Ue(_0x35eca2));else{const _0x39bc72=_0x35eca2['serverCache']['getNode']();f(_0x39bc72 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x18944d=es(_0x38e124,_0x39bc72);}_0x18944d=_0x18944d,_0x3f0c4e=_0x3a331f['filter']['updateFullNode'](_0x5e5a57,_0x18944d,_0x12a072);}else{const _0x5e74db=y(_0x4b64aa);let _0x170806=ts(_0x38e124,_0x5e74db,_0x35eca2['serverCache']);_0x170806==null&&_0x35eca2['serverCache']['isCompleteForChild'](_0x5e74db)&&(_0x170806=_0x5e5a57['getImmediateChild'](_0x5e74db)),_0x170806!=null?_0x3f0c4e=_0x3a331f['filter']['updateChild'](_0x5e5a57,_0x5e74db,_0x170806,b(_0x4b64aa),_0x222e1a,_0x12a072):_0x35eca2['eventCache']['getNode']()['hasChild'](_0x5e74db)?_0x3f0c4e=_0x3a331f['filter']['updateChild'](_0x5e5a57,_0x5e74db,g['EMPTY_NODE'],b(_0x4b64aa),_0x222e1a,_0x12a072):_0x3f0c4e=_0x5e5a57,_0x3f0c4e['isEmpty']()&&_0x35eca2['serverCache']['isFullyInitialized']()&&(_0x4cb9f9=mn(_0x38e124,Ue(_0x35eca2)),_0x4cb9f9['isLeafNode']()&&(_0x3f0c4e=_0x3a331f['filter']['updateFullNode'](_0x3f0c4e,_0x4cb9f9,_0x12a072)));}return _0x4cb9f9=_0x35eca2['serverCache']['isFullyInitialized']()||yn(_0x38e124,w())!=null,wt(_0x35eca2,_0x3f0c4e,_0x4cb9f9,_0x3a331f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x15827e,_0x15231a){this['query_']=_0x15827e,this['eventRegistrations_']=[];const _0x36435b=this['query_']['_queryParams'],_0xb42712=new Yi(_0x36435b['getIndex']()),_0xffeefe=qh(_0x36435b);this['processor_']=wu(_0xffeefe);const _0xc56c70=_0x15231a['serverCache'],_0x152888=_0x15231a['eventCache'],_0x1d1991=_0xb42712['updateFullNode'](g['EMPTY_NODE'],_0xc56c70['getNode'](),null),_0x6e6573=_0xffeefe['updateFullNode'](g['EMPTY_NODE'],_0x152888['getNode'](),null),_0x5b1254=new Ce(_0x1d1991,_0xc56c70['isFullyInitialized'](),_0xb42712['filtersNodes']()),_0x45c8f8=new Ce(_0x6e6573,_0x152888['isFullyInitialized'](),_0xffeefe['filtersNodes']());this['viewCache_']=Dn(_0x45c8f8,_0x5b1254),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0xf40b5b){return _0xf40b5b['viewCache_']['serverCache']['getNode']();}function Ou(_0x4dcebf){return gn(_0x4dcebf['viewCache_']);}function Du(_0x29a250,_0x112466){const _0x46480e=Ue(_0x29a250['viewCache_']);return _0x46480e&&(_0x29a250['query']['_queryParams']['loadsAllData']()||!v(_0x112466)&&!_0x46480e['getImmediateChild'](y(_0x112466))['isEmpty']())?_0x46480e['getChild'](_0x112466):null;}function lr(_0x318479){return _0x318479['eventRegistrations_']['length']===0x0;}function Mu(_0x26770d,_0x1ac88e){_0x26770d['eventRegistrations_']['push'](_0x1ac88e);}function hr(_0xbaf92d,_0x1aa362,_0x448d8b){const _0x3982fe=[];if(_0x448d8b){f(_0x1aa362==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3f2510=_0xbaf92d['query']['_path'];_0xbaf92d['eventRegistrations_']['forEach'](_0x5254c4=>{const _0x2edaaa=_0x5254c4['createCancelEvent'](_0x448d8b,_0x3f2510);_0x2edaaa&&_0x3982fe['push'](_0x2edaaa);});}if(_0x1aa362){let _0xb2eaea=[];for(let _0x571c36=0x0;_0x571c36<_0xbaf92d['eventRegistrations_']['length'];++_0x571c36){const _0x55f44e=_0xbaf92d['eventRegistrations_'][_0x571c36];if(!_0x55f44e['matches'](_0x1aa362))_0xb2eaea['push'](_0x55f44e);else{if(_0x1aa362['hasAnyCallback']()){_0xb2eaea=_0xb2eaea['concat'](_0xbaf92d['eventRegistrations_']['slice'](_0x571c36+0x1));break;}}}_0xbaf92d['eventRegistrations_']=_0xb2eaea;}else _0xbaf92d['eventRegistrations_']=[];return _0x3982fe;}function ur(_0x2ef641,_0x210869,_0x2735b7,_0x54b10e){_0x210869['type']===q['MERGE']&&_0x210869['source']['queryId']!==null&&(f(Ue(_0x2ef641['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2ef641['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1d7842=_0x2ef641['viewCache_'],_0x113998=Tu(_0x2ef641['processor_'],_0x1d7842,_0x210869,_0x2735b7,_0x54b10e);return Cu(_0x2ef641['processor_'],_0x113998['viewCache']),f(_0x113998['viewCache']['serverCache']['isFullyInitialized']()||!_0x1d7842['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2ef641['viewCache_']=_0x113998['viewCache'],$o(_0x2ef641,_0x113998['changes'],_0x113998['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x2ad5c0,_0x4bb45c){const _0x7ce706=_0x2ad5c0['viewCache_']['eventCache'],_0x471dc1=[];return _0x7ce706['getNode']()['isLeafNode']()||_0x7ce706['getNode']()['forEachChild'](R,(_0x47f251,_0x319546)=>{_0x471dc1['push'](tt(_0x47f251,_0x319546));}),_0x7ce706['isFullyInitialized']()&&_0x471dc1['push'](Oo(_0x7ce706['getNode']())),$o(_0x2ad5c0,_0x471dc1,_0x7ce706['getNode'](),_0x4bb45c);}function $o(_0xce33b2,_0x1d2dd6,_0x440c67,_0x266fd9){const _0x4e4dfc=_0x266fd9?[_0x266fd9]:_0xce33b2['eventRegistrations_'];return nu(_0xce33b2['eventGenerator_'],_0x1d2dd6,_0x440c67,_0x4e4dfc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x48001e){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x48001e;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x4a5d1c){return _0x4a5d1c['views']['size']===0x0;}function is(_0x4e8047,_0x3534cc,_0x1fd4ed,_0x3e8adb){const _0x309ce0=_0x3534cc['source']['queryId'];if(_0x309ce0!==null){const _0x3d7408=_0x4e8047['views']['get'](_0x309ce0);return f(_0x3d7408!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x3d7408,_0x3534cc,_0x1fd4ed,_0x3e8adb);}else{let _0x27f970=[];for(const _0x46045f of _0x4e8047['views']['values']())_0x27f970=_0x27f970['concat'](ur(_0x46045f,_0x3534cc,_0x1fd4ed,_0x3e8adb));return _0x27f970;}}function qo(_0x57c0cc,_0x38f152,_0x2475a9,_0x10f786,_0x45409b){const _0x20bbaa=_0x38f152['_queryIdentifier'],_0x22abb8=_0x57c0cc['views']['get'](_0x20bbaa);if(!_0x22abb8){let _0x51cc4e=mn(_0x2475a9,_0x45409b?_0x10f786:null),_0x39c10f=!0x1;_0x51cc4e?_0x39c10f=!0x0:_0x10f786 instanceof g?(_0x51cc4e=es(_0x2475a9,_0x10f786),_0x39c10f=!0x1):(_0x51cc4e=g['EMPTY_NODE'],_0x39c10f=!0x1);const _0x2a3c06=Dn(new Ce(_0x51cc4e,_0x39c10f,!0x1),new Ce(_0x10f786,_0x45409b,!0x1));return new Nu(_0x38f152,_0x2a3c06);}return _0x22abb8;}function Wu(_0x5981c9,_0x12f0e7,_0x392dc6,_0x34aabb,_0x1c09cc,_0x41d235){const _0x556fec=qo(_0x5981c9,_0x12f0e7,_0x34aabb,_0x1c09cc,_0x41d235);return _0x5981c9['views']['has'](_0x12f0e7['_queryIdentifier'])||_0x5981c9['views']['set'](_0x12f0e7['_queryIdentifier'],_0x556fec),Mu(_0x556fec,_0x392dc6),Lu(_0x556fec,_0x392dc6);}function Bu(_0x4cd839,_0x3f8d99,_0x1b96af,_0x25d374){const _0x469428=_0x3f8d99['_queryIdentifier'],_0x4fd8bf=[];let _0x3f2384=[];const _0x43c530=Te(_0x4cd839);if(_0x469428==='default'){for(const [_0x1dc00c,_0x4d5043]of _0x4cd839['views']['entries']())_0x3f2384=_0x3f2384['concat'](hr(_0x4d5043,_0x1b96af,_0x25d374)),lr(_0x4d5043)&&(_0x4cd839['views']['delete'](_0x1dc00c),_0x4d5043['query']['_queryParams']['loadsAllData']()||_0x4fd8bf['push'](_0x4d5043['query']));}else{const _0x5b3f8d=_0x4cd839['views']['get'](_0x469428);_0x5b3f8d&&(_0x3f2384=_0x3f2384['concat'](hr(_0x5b3f8d,_0x1b96af,_0x25d374)),lr(_0x5b3f8d)&&(_0x4cd839['views']['delete'](_0x469428),_0x5b3f8d['query']['_queryParams']['loadsAllData']()||_0x4fd8bf['push'](_0x5b3f8d['query'])));}return _0x43c530&&!Te(_0x4cd839)&&_0x4fd8bf['push'](new(Fu())(_0x3f8d99['_repo'],_0x3f8d99['_path'])),{'removed':_0x4fd8bf,'events':_0x3f2384};}function zo(_0x358dcd){const _0x567fc1=[];for(const _0xe92a9 of _0x358dcd['views']['values']())_0xe92a9['query']['_queryParams']['loadsAllData']()||_0x567fc1['push'](_0xe92a9);return _0x567fc1;}function Ee(_0x3a674c,_0x55f8c6){let _0x4c4b10=null;for(const _0x197060 of _0x3a674c['views']['values']())_0x4c4b10=_0x4c4b10||Du(_0x197060,_0x55f8c6);return _0x4c4b10;}function jo(_0x377ffc,_0x335a85){if(_0x335a85['_queryParams']['loadsAllData']())return Ln(_0x377ffc);{const _0x32e198=_0x335a85['_queryIdentifier'];return _0x377ffc['views']['get'](_0x32e198);}}function Ko(_0x55d03e,_0x3ebcfd){return jo(_0x55d03e,_0x3ebcfd)!=null;}function Te(_0x2dbe4b){return Ln(_0x2dbe4b)!=null;}function Ln(_0x1ccecc){for(const _0x38e0f4 of _0x1ccecc['views']['values']())if(_0x38e0f4['query']['_queryParams']['loadsAllData']())return _0x38e0f4;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x409511){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x409511;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x3391bd){this['listenProvider_']=_0x3391bd,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x56b65f,_0x343042,_0x4c06e8,_0x1b4778,_0x382675){return ou(_0x56b65f['pendingWriteTree_'],_0x343042,_0x4c06e8,_0x1b4778,_0x382675),_0x382675?ht(_0x56b65f,new Fe(Ji(),_0x343042,_0x4c06e8)):[];}function Gu(_0x35c34c,_0x1720a9,_0x5642d1,_0x1413d4){au(_0x35c34c['pendingWriteTree_'],_0x1720a9,_0x5642d1,_0x1413d4);const _0x183407=S['fromObject'](_0x5642d1);return ht(_0x35c34c,new nt(Ji(),_0x1720a9,_0x183407));}function pe(_0x15efb3,_0x50651b,_0x3a3379=!0x1){const _0x1c5619=cu(_0x15efb3['pendingWriteTree_'],_0x50651b);if(lu(_0x15efb3['pendingWriteTree_'],_0x50651b)){let _0x12e0a9=new S(null);return _0x1c5619['snap']!=null?_0x12e0a9=_0x12e0a9['set'](w(),!0x0):x(_0x1c5619['children'],_0x1bd783=>{_0x12e0a9=_0x12e0a9['set'](new C(_0x1bd783),!0x0);}),ht(_0x15efb3,new _n(_0x1c5619['path'],_0x12e0a9,_0x3a3379));}else return[];}function $t(_0x5864ce,_0x282280,_0x4433e6){return ht(_0x5864ce,new Fe(Xi(),_0x282280,_0x4433e6));}function qu(_0x15610e,_0x424216,_0x578e1b){const _0x3a211a=S['fromObject'](_0x578e1b);return ht(_0x15610e,new nt(Xi(),_0x424216,_0x3a211a));}function zu(_0x255903,_0x3cded2){return ht(_0x255903,new Dt(Xi(),_0x3cded2));}function ju(_0x20abaa,_0x2d7994,_0x24af89){const _0x4eaa6e=rs(_0x20abaa,_0x24af89);if(_0x4eaa6e){const _0x947746=os(_0x4eaa6e),_0x2ff235=_0x947746['path'],_0x1b47db=_0x947746['queryId'],_0xa9a383=F(_0x2ff235,_0x2d7994),_0x4980c8=new Dt(Zi(_0x1b47db),_0xa9a383);return as(_0x20abaa,_0x2ff235,_0x4980c8);}else return[];}function wn(_0x4101c8,_0x33a479,_0x369899,_0x106828,_0x46b95e=!0x1){const _0x2564e5=_0x33a479['_path'],_0x5792d1=_0x4101c8['syncPointTree_']['get'](_0x2564e5);let _0x2c1cd8=[];if(_0x5792d1&&(_0x33a479['_queryIdentifier']==='default'||Ko(_0x5792d1,_0x33a479))){const _0x2d65a8=Bu(_0x5792d1,_0x33a479,_0x369899,_0x106828);Uu(_0x5792d1)&&(_0x4101c8['syncPointTree_']=_0x4101c8['syncPointTree_']['remove'](_0x2564e5));const _0x495daa=_0x2d65a8['removed'];if(_0x2c1cd8=_0x2d65a8['events'],!_0x46b95e){const _0x22522a=_0x495daa['findIndex'](_0x35f3ed=>_0x35f3ed['_queryParams']['loadsAllData']())!==-0x1,_0x5973c8=_0x4101c8['syncPointTree_']['findOnPath'](_0x2564e5,(_0x521de6,_0x382361)=>Te(_0x382361));if(_0x22522a&&!_0x5973c8){const _0x17551c=_0x4101c8['syncPointTree_']['subtree'](_0x2564e5);if(!_0x17551c['isEmpty']()){const _0x1062b4=Qu(_0x17551c);for(let _0x1f5bd6=0x0;_0x1f5bd6<_0x1062b4['length'];++_0x1f5bd6){const _0x29b9bf=_0x1062b4[_0x1f5bd6],_0x3dfb6f=_0x29b9bf['query'],_0x45cc6c=Xo(_0x4101c8,_0x29b9bf);_0x4101c8['listenProvider_']['startListening'](Tt(_0x3dfb6f),Mt(_0x4101c8,_0x3dfb6f),_0x45cc6c['hashFn'],_0x45cc6c['onComplete']);}}}!_0x5973c8&&_0x495daa['length']>0x0&&!_0x106828&&(_0x22522a?_0x4101c8['listenProvider_']['stopListening'](Tt(_0x33a479),null):_0x495daa['forEach'](_0x1ada1b=>{const _0x13d614=_0x4101c8['queryToTagMap']['get'](Fn(_0x1ada1b));_0x4101c8['listenProvider_']['stopListening'](Tt(_0x1ada1b),_0x13d614);}));}Ju(_0x4101c8,_0x495daa);}return _0x2c1cd8;}function Yo(_0x5534cf,_0x881c38,_0x142f80,_0x451ba1){const _0x5676b8=rs(_0x5534cf,_0x451ba1);if(_0x5676b8!=null){const _0x345971=os(_0x5676b8),_0x11a781=_0x345971['path'],_0x29adb0=_0x345971['queryId'],_0x3e93fb=F(_0x11a781,_0x881c38),_0x409602=new Fe(Zi(_0x29adb0),_0x3e93fb,_0x142f80);return as(_0x5534cf,_0x11a781,_0x409602);}else return[];}function Ku(_0x18dae8,_0x5a5535,_0x4a9133,_0x19a6c3){const _0x3a07a4=rs(_0x18dae8,_0x19a6c3);if(_0x3a07a4){const _0x58305e=os(_0x3a07a4),_0x3b400a=_0x58305e['path'],_0x4eb9d7=_0x58305e['queryId'],_0x47c5f7=F(_0x3b400a,_0x5a5535),_0x39c698=S['fromObject'](_0x4a9133),_0x4a40cf=new nt(Zi(_0x4eb9d7),_0x47c5f7,_0x39c698);return as(_0x18dae8,_0x3b400a,_0x4a40cf);}else return[];}function bi(_0x1544fd,_0x554bed,_0x151894,_0x5f5584=!0x1){const _0x5611a3=_0x554bed['_path'];let _0x55cf66=null,_0x34f732=!0x1;_0x1544fd['syncPointTree_']['foreachOnPath'](_0x5611a3,(_0x426286,_0x3ed58e)=>{const _0x45f455=F(_0x426286,_0x5611a3);_0x55cf66=_0x55cf66||Ee(_0x3ed58e,_0x45f455),_0x34f732=_0x34f732||Te(_0x3ed58e);});let _0x306605=_0x1544fd['syncPointTree_']['get'](_0x5611a3);_0x306605?(_0x34f732=_0x34f732||Te(_0x306605),_0x55cf66=_0x55cf66||Ee(_0x306605,w())):(_0x306605=new Go(),_0x1544fd['syncPointTree_']=_0x1544fd['syncPointTree_']['set'](_0x5611a3,_0x306605));let _0x278f0f;_0x55cf66!=null?_0x278f0f=!0x0:(_0x278f0f=!0x1,_0x55cf66=g['EMPTY_NODE'],_0x1544fd['syncPointTree_']['subtree'](_0x5611a3)['foreachChild']((_0x216b32,_0x16461d)=>{const _0xb2794b=Ee(_0x16461d,w());_0xb2794b&&(_0x55cf66=_0x55cf66['updateImmediateChild'](_0x216b32,_0xb2794b));}));const _0x30ec41=Ko(_0x306605,_0x554bed);if(!_0x30ec41&&!_0x554bed['_queryParams']['loadsAllData']()){const _0xd7e2e6=Fn(_0x554bed);f(!_0x1544fd['queryToTagMap']['has'](_0xd7e2e6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1cc190=Xu();_0x1544fd['queryToTagMap']['set'](_0xd7e2e6,_0x1cc190),_0x1544fd['tagToQueryMap']['set'](_0x1cc190,_0xd7e2e6);}const _0x21179c=Mn(_0x1544fd['pendingWriteTree_'],_0x5611a3);let _0x2a8799=Wu(_0x306605,_0x554bed,_0x151894,_0x21179c,_0x55cf66,_0x278f0f);if(!_0x30ec41&&!_0x34f732&&!_0x5f5584){const _0x5f50bd=jo(_0x306605,_0x554bed);_0x2a8799=_0x2a8799['concat'](Zu(_0x1544fd,_0x554bed,_0x5f50bd));}return _0x2a8799;}function xn(_0x4b1b51,_0x4ad0f6,_0x2106fb){const _0x3a8370=_0x4b1b51['pendingWriteTree_'],_0x41ccd8=_0x4b1b51['syncPointTree_']['findOnPath'](_0x4ad0f6,(_0x5e521e,_0xdf7dee)=>{const _0xddcc34=F(_0x5e521e,_0x4ad0f6),_0x2f6c1e=Ee(_0xdf7dee,_0xddcc34);if(_0x2f6c1e)return _0x2f6c1e;});return Uo(_0x3a8370,_0x4ad0f6,_0x41ccd8,_0x2106fb,!0x0);}function Yu(_0x540e1d,_0x2f1ef2){const _0x2ba450=_0x2f1ef2['_path'];let _0x7bd933=null;_0x540e1d['syncPointTree_']['foreachOnPath'](_0x2ba450,(_0x5ef057,_0x2a6c49)=>{const _0x1e12cd=F(_0x5ef057,_0x2ba450);_0x7bd933=_0x7bd933||Ee(_0x2a6c49,_0x1e12cd);});let _0x28f28a=_0x540e1d['syncPointTree_']['get'](_0x2ba450);_0x28f28a?_0x7bd933=_0x7bd933||Ee(_0x28f28a,w()):(_0x28f28a=new Go(),_0x540e1d['syncPointTree_']=_0x540e1d['syncPointTree_']['set'](_0x2ba450,_0x28f28a));const _0xb85708=_0x7bd933!=null,_0x43e593=_0xb85708?new Ce(_0x7bd933,!0x0,!0x1):null,_0x4fdcfd=Mn(_0x540e1d['pendingWriteTree_'],_0x2f1ef2['_path']),_0x4d69c1=qo(_0x28f28a,_0x2f1ef2,_0x4fdcfd,_0xb85708?_0x43e593['getNode']():g['EMPTY_NODE'],_0xb85708);return Ou(_0x4d69c1);}function ht(_0x2035a2,_0x4f6fcf){return Qo(_0x4f6fcf,_0x2035a2['syncPointTree_'],null,Mn(_0x2035a2['pendingWriteTree_'],w()));}function Qo(_0x385f71,_0x15d878,_0x2a83ee,_0x292f9f){if(v(_0x385f71['path']))return Jo(_0x385f71,_0x15d878,_0x2a83ee,_0x292f9f);{const _0x519d05=_0x15d878['get'](w());_0x2a83ee==null&&_0x519d05!=null&&(_0x2a83ee=Ee(_0x519d05,w()));let _0x425ea5=[];const _0x2a17b9=y(_0x385f71['path']),_0x3bd3da=_0x385f71['operationForChild'](_0x2a17b9),_0x290ea9=_0x15d878['children']['get'](_0x2a17b9);if(_0x290ea9&&_0x3bd3da){const _0x5d37bf=_0x2a83ee?_0x2a83ee['getImmediateChild'](_0x2a17b9):null,_0x594351=Wo(_0x292f9f,_0x2a17b9);_0x425ea5=_0x425ea5['concat'](Qo(_0x3bd3da,_0x290ea9,_0x5d37bf,_0x594351));}return _0x519d05&&(_0x425ea5=_0x425ea5['concat'](is(_0x519d05,_0x385f71,_0x292f9f,_0x2a83ee))),_0x425ea5;}}function Jo(_0x385d6d,_0x932222,_0xe1b608,_0x1402c1){const _0x342ccc=_0x932222['get'](w());_0xe1b608==null&&_0x342ccc!=null&&(_0xe1b608=Ee(_0x342ccc,w()));let _0x2167b4=[];return _0x932222['children']['inorderTraversal']((_0x1fca7c,_0x3cf8de)=>{const _0x54d6dd=_0xe1b608?_0xe1b608['getImmediateChild'](_0x1fca7c):null,_0x109ac9=Wo(_0x1402c1,_0x1fca7c),_0x259d32=_0x385d6d['operationForChild'](_0x1fca7c);_0x259d32&&(_0x2167b4=_0x2167b4['concat'](Jo(_0x259d32,_0x3cf8de,_0x54d6dd,_0x109ac9)));}),_0x342ccc&&(_0x2167b4=_0x2167b4['concat'](is(_0x342ccc,_0x385d6d,_0x1402c1,_0xe1b608))),_0x2167b4;}function Xo(_0x40021d,_0x2c715d){const _0x5719a0=_0x2c715d['query'],_0x49a0c7=Mt(_0x40021d,_0x5719a0);return{'hashFn':()=>(Pu(_0x2c715d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x35739d=>{if(_0x35739d==='ok')return _0x49a0c7?ju(_0x40021d,_0x5719a0['_path'],_0x49a0c7):zu(_0x40021d,_0x5719a0['_path']);{const _0x1818c5=ql(_0x35739d,_0x5719a0);return wn(_0x40021d,_0x5719a0,null,_0x1818c5);}}};}function Mt(_0x32919c,_0x141687){const _0x1840ab=Fn(_0x141687);return _0x32919c['queryToTagMap']['get'](_0x1840ab);}function Fn(_0x438e51){return _0x438e51['_path']['toString']()+'$'+_0x438e51['_queryIdentifier'];}function rs(_0x22a084,_0x1570a1){return _0x22a084['tagToQueryMap']['get'](_0x1570a1);}function os(_0xc6757f){const _0x56d3fd=_0xc6757f['indexOf']('$');return f(_0x56d3fd!==-0x1&&_0x56d3fd<_0xc6757f['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xc6757f['substr'](_0x56d3fd+0x1),'path':new C(_0xc6757f['substr'](0x0,_0x56d3fd))};}function as(_0x2445f2,_0x30c28c,_0x12ef84){const _0x529240=_0x2445f2['syncPointTree_']['get'](_0x30c28c);f(_0x529240,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5466ff=Mn(_0x2445f2['pendingWriteTree_'],_0x30c28c);return is(_0x529240,_0x12ef84,_0x5466ff,null);}function Qu(_0x43e792){return _0x43e792['fold']((_0x344285,_0x89072,_0x558549)=>{if(_0x89072&&Te(_0x89072))return[Ln(_0x89072)];{let _0x2f52d6=[];return _0x89072&&(_0x2f52d6=zo(_0x89072)),x(_0x558549,(_0x106565,_0x49ffd8)=>{_0x2f52d6=_0x2f52d6['concat'](_0x49ffd8);}),_0x2f52d6;}});}function Tt(_0x5e3094){return _0x5e3094['_queryParams']['loadsAllData']()&&!_0x5e3094['_queryParams']['isDefault']()?new(Hu())(_0x5e3094['_repo'],_0x5e3094['_path']):_0x5e3094;}function Ju(_0x2e0c9d,_0x3f10ea){for(let _0x3cb089=0x0;_0x3cb089<_0x3f10ea['length'];++_0x3cb089){const _0x379c5e=_0x3f10ea[_0x3cb089];if(!_0x379c5e['_queryParams']['loadsAllData']()){const _0xc80f12=Fn(_0x379c5e),_0x2b64ff=_0x2e0c9d['queryToTagMap']['get'](_0xc80f12);_0x2e0c9d['queryToTagMap']['delete'](_0xc80f12),_0x2e0c9d['tagToQueryMap']['delete'](_0x2b64ff);}}}function Xu(){return $u++;}function Zu(_0x2b6d4a,_0x533853,_0x22a1c0){const _0x345dfe=_0x533853['_path'],_0x659615=Mt(_0x2b6d4a,_0x533853),_0x4049cb=Xo(_0x2b6d4a,_0x22a1c0),_0xd6423a=_0x2b6d4a['listenProvider_']['startListening'](Tt(_0x533853),_0x659615,_0x4049cb['hashFn'],_0x4049cb['onComplete']),_0x9d8bd7=_0x2b6d4a['syncPointTree_']['subtree'](_0x345dfe);if(_0x659615)f(!Te(_0x9d8bd7['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xed9699=_0x9d8bd7['fold']((_0x119916,_0x23ebb2,_0x5385fb)=>{if(!v(_0x119916)&&_0x23ebb2&&Te(_0x23ebb2))return[Ln(_0x23ebb2)['query']];{let _0x3a56b1=[];return _0x23ebb2&&(_0x3a56b1=_0x3a56b1['concat'](zo(_0x23ebb2)['map'](_0x56e4c9=>_0x56e4c9['query']))),x(_0x5385fb,(_0x500648,_0x39a2fc)=>{_0x3a56b1=_0x3a56b1['concat'](_0x39a2fc);}),_0x3a56b1;}});for(let _0xe0afbb=0x0;_0xe0afbb<_0xed9699['length'];++_0xe0afbb){const _0x3767ad=_0xed9699[_0xe0afbb];_0x2b6d4a['listenProvider_']['stopListening'](Tt(_0x3767ad),Mt(_0x2b6d4a,_0x3767ad));}}return _0xd6423a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x46536f){this['node_']=_0x46536f;}['getImmediateChild'](_0x2dac45){const _0x2493f2=this['node_']['getImmediateChild'](_0x2dac45);return new cs(_0x2493f2);}['node'](){return this['node_'];}}class ls{constructor(_0x323f06,_0x410e92){this['syncTree_']=_0x323f06,this['path_']=_0x410e92;}['getImmediateChild'](_0x1d32cf){const _0x2424d2=A(this['path_'],_0x1d32cf);return new ls(this['syncTree_'],_0x2424d2);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x198d33){return _0x198d33=_0x198d33||{},_0x198d33['timestamp']=_0x198d33['timestamp']||new Date()['getTime'](),_0x198d33;},fr=function(_0xe813c9,_0x413268,_0x46fa8f){if(!_0xe813c9||typeof _0xe813c9!='object')return _0xe813c9;if(f('.sv'in _0xe813c9,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xe813c9['.sv']=='string')return td(_0xe813c9['.sv'],_0x413268,_0x46fa8f);if(typeof _0xe813c9['.sv']=='object')return nd(_0xe813c9['.sv'],_0x413268);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xe813c9,null,0x2));},td=function(_0x507b34,_0x5b9985,_0x149630){switch(_0x507b34){case'timestamp':return _0x149630['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x507b34);}},nd=function(_0x4c750a,_0x8f718b,_0x2a8fe6){_0x4c750a['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4c750a,null,0x2));const _0x23dddb=_0x4c750a['increment'];typeof _0x23dddb!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x23dddb);const _0x28df95=_0x8f718b['node']();if(f(_0x28df95!==null&&typeof _0x28df95<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x28df95['isLeafNode']())return _0x23dddb;const _0x158402=_0x28df95['getValue']();return typeof _0x158402!='number'?_0x23dddb:_0x158402+_0x23dddb;},Zo=function(_0x38a983,_0x1f7191,_0xa4238f,_0x577ae2){return us(_0x1f7191,new ls(_0xa4238f,_0x38a983),_0x577ae2);},hs=function(_0x5a4558,_0x3a06e8,_0x59d7fd){return us(_0x5a4558,new cs(_0x3a06e8),_0x59d7fd);};function us(_0x1082d4,_0x3016df,_0x3fad69){const _0x3acbe1=_0x1082d4['getPriority']()['val'](),_0x3d9cc8=fr(_0x3acbe1,_0x3016df['getImmediateChild']('.priority'),_0x3fad69);let _0xade852;if(_0x1082d4['isLeafNode']()){const _0x3b763e=_0x1082d4,_0x502a03=fr(_0x3b763e['getValue'](),_0x3016df,_0x3fad69);return _0x502a03!==_0x3b763e['getValue']()||_0x3d9cc8!==_0x3b763e['getPriority']()['val']()?new D(_0x502a03,N(_0x3d9cc8)):_0x1082d4;}else{const _0xbff1d9=_0x1082d4;return _0xade852=_0xbff1d9,_0x3d9cc8!==_0xbff1d9['getPriority']()['val']()&&(_0xade852=_0xade852['updatePriority'](new D(_0x3d9cc8))),_0xbff1d9['forEachChild'](R,(_0x1c695f,_0x5e2b82)=>{const _0x6e8d96=us(_0x5e2b82,_0x3016df['getImmediateChild'](_0x1c695f),_0x3fad69);_0x6e8d96!==_0x5e2b82&&(_0xade852=_0xade852['updateImmediateChild'](_0x1c695f,_0x6e8d96));}),_0xade852;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x1ddbe8='',_0x10926f=null,_0x2f60e5={'children':{},'childCount':0x0}){this['name']=_0x1ddbe8,this['parent']=_0x10926f,this['node']=_0x2f60e5;}}function Un(_0x43c5e1,_0x1bdbc9){let _0x2e33=_0x1bdbc9 instanceof C?_0x1bdbc9:new C(_0x1bdbc9),_0x3bce6d=_0x43c5e1,_0xfc645f=y(_0x2e33);for(;_0xfc645f!==null;){const _0x1b5a51=Oe(_0x3bce6d['node']['children'],_0xfc645f)||{'children':{},'childCount':0x0};_0x3bce6d=new ds(_0xfc645f,_0x3bce6d,_0x1b5a51),_0x2e33=b(_0x2e33),_0xfc645f=y(_0x2e33);}return _0x3bce6d;}function Ge(_0x47eba8){return _0x47eba8['node']['value'];}function fs(_0x52180d,_0x3d8adf){_0x52180d['node']['value']=_0x3d8adf,Ri(_0x52180d);}function ea(_0x3c4d32){return _0x3c4d32['node']['childCount']>0x0;}function id(_0x1b621e){return Ge(_0x1b621e)===void 0x0&&!ea(_0x1b621e);}function Wn(_0x479783,_0x5ec1e6){x(_0x479783['node']['children'],(_0x1810a2,_0xac092f)=>{_0x5ec1e6(new ds(_0x1810a2,_0x479783,_0xac092f));});}function ta(_0x482eb8,_0x1df389,_0x1d7000,_0x2fba4d){_0x1d7000&&_0x1df389(_0x482eb8),Wn(_0x482eb8,_0x1a3286=>{ta(_0x1a3286,_0x1df389,!0x0);});}function sd(_0x31b7ed,_0x1118ee,_0x101b30){let _0x252fbf=_0x31b7ed['parent'];for(;_0x252fbf!==null;){if(_0x1118ee(_0x252fbf))return!0x0;_0x252fbf=_0x252fbf['parent'];}return!0x1;}function Gt(_0x1f2f2b){return new C(_0x1f2f2b['parent']===null?_0x1f2f2b['name']:Gt(_0x1f2f2b['parent'])+'/'+_0x1f2f2b['name']);}function Ri(_0x1c636a){_0x1c636a['parent']!==null&&rd(_0x1c636a['parent'],_0x1c636a['name'],_0x1c636a);}function rd(_0x2101cc,_0x3c751e,_0xf4341d){const _0x587c69=id(_0xf4341d),_0x466f8d=Y(_0x2101cc['node']['children'],_0x3c751e);_0x587c69&&_0x466f8d?(delete _0x2101cc['node']['children'][_0x3c751e],_0x2101cc['node']['childCount']--,Ri(_0x2101cc)):!_0x587c69&&!_0x466f8d&&(_0x2101cc['node']['children'][_0x3c751e]=_0xf4341d['node'],_0x2101cc['node']['childCount']++,Ri(_0x2101cc));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x2c27e8){return typeof _0x2c27e8=='string'&&_0x2c27e8['length']!==0x0&&!od['test'](_0x2c27e8);},na=function(_0x4f642d){return typeof _0x4f642d=='string'&&_0x4f642d['length']!==0x0&&!ad['test'](_0x4f642d);},cd=function(_0x3fd133){return _0x3fd133&&(_0x3fd133=_0x3fd133['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x3fd133);},Cn=function(_0x203f6f){return _0x203f6f===null||typeof _0x203f6f=='string'||typeof _0x203f6f=='number'&&!Wi(_0x203f6f)||_0x203f6f&&typeof _0x203f6f=='object'&&Y(_0x203f6f,'.sv');},qt=function(_0x1d2c0b,_0x4ff964,_0x4c5edf,_0x25c9c1){_0x25c9c1&&_0x4ff964===void 0x0||zt(Nn(_0x1d2c0b,'value'),_0x4ff964,_0x4c5edf);},zt=function(_0x2cfb0e,_0x5434b8,_0x3005a1){const _0x3ee335=_0x3005a1 instanceof C?new Sh(_0x3005a1,_0x2cfb0e):_0x3005a1;if(_0x5434b8===void 0x0)throw new Error(_0x2cfb0e+'contains\x20undefined\x20'+Ne(_0x3ee335));if(typeof _0x5434b8=='function')throw new Error(_0x2cfb0e+'contains\x20a\x20function\x20'+Ne(_0x3ee335)+'\x20with\x20contents\x20=\x20'+_0x5434b8['toString']());if(Wi(_0x5434b8))throw new Error(_0x2cfb0e+'contains\x20'+_0x5434b8['toString']()+'\x20'+Ne(_0x3ee335));if(typeof _0x5434b8=='string'&&_0x5434b8['length']>oi/0x3&&Pn(_0x5434b8)>oi)throw new Error(_0x2cfb0e+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x3ee335)+'\x20(\x27'+_0x5434b8['substring'](0x0,0x32)+'...\x27)');if(_0x5434b8&&typeof _0x5434b8=='object'){let _0x3160c7=!0x1,_0x3e2c66=!0x1;if(x(_0x5434b8,(_0x4e87c9,_0x16f823)=>{if(_0x4e87c9==='.value')_0x3160c7=!0x0;else{if(_0x4e87c9!=='.priority'&&_0x4e87c9!=='.sv'&&(_0x3e2c66=!0x0,!ps(_0x4e87c9)))throw new Error(_0x2cfb0e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4e87c9+')\x20'+Ne(_0x3ee335)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x3ee335,_0x4e87c9),zt(_0x2cfb0e,_0x16f823,_0x3ee335),Rh(_0x3ee335);}),_0x3160c7&&_0x3e2c66)throw new Error(_0x2cfb0e+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x3ee335)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x467528,_0x46bc0c){let _0x28f320,_0x13a7ea;for(_0x28f320=0x0;_0x28f320<_0x46bc0c['length'];_0x28f320++){_0x13a7ea=_0x46bc0c[_0x28f320];const _0x111637=kt(_0x13a7ea);for(let _0xf14c63=0x0;_0xf14c63<_0x111637['length'];_0xf14c63++)if(!(_0x111637[_0xf14c63]==='.priority'&&_0xf14c63===_0x111637['length']-0x1)){if(!ps(_0x111637[_0xf14c63]))throw new Error(_0x467528+'contains\x20an\x20invalid\x20key\x20('+_0x111637[_0xf14c63]+')\x20in\x20path\x20'+_0x13a7ea['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x46bc0c['sort'](Th);let _0x45a1d2=null;for(_0x28f320=0x0;_0x28f320<_0x46bc0c['length'];_0x28f320++){if(_0x13a7ea=_0x46bc0c[_0x28f320],_0x45a1d2!==null&&$(_0x45a1d2,_0x13a7ea))throw new Error(_0x467528+'contains\x20a\x20path\x20'+_0x45a1d2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x13a7ea['toString']());_0x45a1d2=_0x13a7ea;}},hd=function(_0x5d1889,_0x2d5bf7,_0x36d39c,_0x5c798a){const _0x5d0691=Nn(_0x5d1889,'values');if(!(_0x2d5bf7&&typeof _0x2d5bf7=='object')||Array['isArray'](_0x2d5bf7))throw new Error(_0x5d0691+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1997a2=[];x(_0x2d5bf7,(_0x472799,_0x16b9b3)=>{const _0xb9b3f7=new C(_0x472799);if(zt(_0x5d0691,_0x16b9b3,A(_0x36d39c,_0xb9b3f7)),Gi(_0xb9b3f7)==='.priority'&&!Cn(_0x16b9b3))throw new Error(_0x5d0691+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0xb9b3f7['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1997a2['push'](_0xb9b3f7);}),ld(_0x5d0691,_0x1997a2);},_s=function(_0x5667ee,_0x60d437,_0x286304,_0x139bd3){if(!na(_0x286304))throw new Error(Nn(_0x5667ee,_0x60d437)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x286304+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x282fb7,_0x266a26,_0x5bbd8e,_0x1c2300){_0x5bbd8e&&(_0x5bbd8e=_0x5bbd8e['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x282fb7,_0x266a26,_0x5bbd8e);},gs=function(_0x5c5251,_0x26dbf6){if(y(_0x26dbf6)==='.info')throw new Error(_0x5c5251+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x16d705,_0x380e5c){const _0xf8b156=_0x380e5c['path']['toString']();if(typeof _0x380e5c['repoInfo']['host']!='string'||_0x380e5c['repoInfo']['host']['length']===0x0||!ps(_0x380e5c['repoInfo']['namespace'])&&_0x380e5c['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xf8b156['length']!==0x0&&!cd(_0xf8b156))throw new Error(Nn(_0x16d705,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5bf7c2,_0x9c6e72){let _0xdc7a13=null;for(let _0x1ea8ce=0x0;_0x1ea8ce<_0x9c6e72['length'];_0x1ea8ce++){const _0x4141d2=_0x9c6e72[_0x1ea8ce],_0x21265c=_0x4141d2['getPath']();_0xdc7a13!==null&&!qi(_0x21265c,_0xdc7a13['path'])&&(_0x5bf7c2['eventLists_']['push'](_0xdc7a13),_0xdc7a13=null),_0xdc7a13===null&&(_0xdc7a13={'events':[],'path':_0x21265c}),_0xdc7a13['events']['push'](_0x4141d2);}_0xdc7a13&&_0x5bf7c2['eventLists_']['push'](_0xdc7a13);}function ia(_0x5edda7,_0x57ae1b,_0x1e9b61){Bn(_0x5edda7,_0x1e9b61),sa(_0x5edda7,_0x32448d=>qi(_0x32448d,_0x57ae1b));}function V(_0x55c099,_0x286294,_0x2bd9b3){Bn(_0x55c099,_0x2bd9b3),sa(_0x55c099,_0x31cd01=>$(_0x31cd01,_0x286294)||$(_0x286294,_0x31cd01));}function sa(_0x5bc8cd,_0x1dcc4e){_0x5bc8cd['recursionDepth_']++;let _0x117866=!0x0;for(let _0x305f3a=0x0;_0x305f3a<_0x5bc8cd['eventLists_']['length'];_0x305f3a++){const _0x10ee4c=_0x5bc8cd['eventLists_'][_0x305f3a];if(_0x10ee4c){const _0xf288d3=_0x10ee4c['path'];_0x1dcc4e(_0xf288d3)?(pd(_0x5bc8cd['eventLists_'][_0x305f3a]),_0x5bc8cd['eventLists_'][_0x305f3a]=null):_0x117866=!0x1;}}_0x117866&&(_0x5bc8cd['eventLists_']=[]),_0x5bc8cd['recursionDepth_']--;}function pd(_0x44092e){for(let _0x4987ec=0x0;_0x4987ec<_0x44092e['events']['length'];_0x4987ec++){const _0x540e09=_0x44092e['events'][_0x4987ec];if(_0x540e09!==null){_0x44092e['events'][_0x4987ec]=null;const _0x229f3a=_0x540e09['getEventRunner']();Et&&L('event:\x20'+_0x540e09['toString']()),lt(_0x229f3a);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x13545b,_0x68986a,_0x594044,_0x15fcfd){this['repoInfo_']=_0x13545b,this['forceRestClient_']=_0x68986a,this['authTokenProvider_']=_0x594044,this['appCheckProvider_']=_0x15fcfd,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x15e06b,_0x4791f8,_0x461bc2){if(_0x15e06b['stats_']=Hi(_0x15e06b['repoInfo_']),_0x15e06b['forceRestClient_']||Yl())_0x15e06b['server_']=new fn(_0x15e06b['repoInfo_'],(_0x1fe89b,_0x26715c,_0x2481ff,_0x189d2e)=>{pr(_0x15e06b,_0x1fe89b,_0x26715c,_0x2481ff,_0x189d2e);},_0x15e06b['authTokenProvider_'],_0x15e06b['appCheckProvider_']),setTimeout(()=>_r(_0x15e06b,!0x0),0x0);else{if(typeof _0x461bc2<'u'&&_0x461bc2!==null){if(typeof _0x461bc2!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x461bc2);}catch(_0x254e48){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x254e48);}}_0x15e06b['persistentConnection_']=new ie(_0x15e06b['repoInfo_'],_0x4791f8,(_0x597526,_0x177db9,_0x5ac4d7,_0x18df39)=>{pr(_0x15e06b,_0x597526,_0x177db9,_0x5ac4d7,_0x18df39);},_0x294070=>{_r(_0x15e06b,_0x294070);},_0x35beb4=>{yd(_0x15e06b,_0x35beb4);},_0x15e06b['authTokenProvider_'],_0x15e06b['appCheckProvider_'],_0x461bc2),_0x15e06b['server_']=_0x15e06b['persistentConnection_'];}_0x15e06b['authTokenProvider_']['addTokenChangeListener'](_0x5cb613=>{_0x15e06b['server_']['refreshAuthToken'](_0x5cb613);}),_0x15e06b['appCheckProvider_']['addTokenChangeListener'](_0x3a7d10=>{_0x15e06b['server_']['refreshAppCheckToken'](_0x3a7d10['token']);}),_0x15e06b['statsReporter_']=eh(_0x15e06b['repoInfo_'],()=>new eu(_0x15e06b['stats_'],_0x15e06b['server_'])),_0x15e06b['infoData_']=new Yh(),_0x15e06b['infoSyncTree_']=new dr({'startListening':(_0x342992,_0x3facce,_0x3db1c2,_0x38aa7c)=>{let _0x1bfad3=[];const _0x9cffd7=_0x15e06b['infoData_']['getNode'](_0x342992['_path']);return _0x9cffd7['isEmpty']()||(_0x1bfad3=$t(_0x15e06b['infoSyncTree_'],_0x342992['_path'],_0x9cffd7),setTimeout(()=>{_0x38aa7c('ok');},0x0)),_0x1bfad3;},'stopListening':()=>{}}),ms(_0x15e06b,'connected',!0x1),_0x15e06b['serverSyncTree_']=new dr({'startListening':(_0x3d0b08,_0x55eacb,_0x19b778,_0x4768bd)=>(_0x15e06b['server_']['listen'](_0x3d0b08,_0x19b778,_0x55eacb,(_0x4d4af5,_0x368790)=>{const _0x5c0ec6=_0x4768bd(_0x4d4af5,_0x368790);V(_0x15e06b['eventQueue_'],_0x3d0b08['_path'],_0x5c0ec6);}),[]),'stopListening':(_0x565cc7,_0x18b79b)=>{_0x15e06b['server_']['unlisten'](_0x565cc7,_0x18b79b);}});}function oa(_0x39beab){const _0x3f90f7=_0x39beab['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3f90f7;}function jt(_0x432a0d){return ed({'timestamp':oa(_0x432a0d)});}function pr(_0x44e131,_0x393ed6,_0x44bf63,_0xff8e34,_0x6429b1){_0x44e131['dataUpdateCount']++;const _0x475abe=new C(_0x393ed6);_0x44bf63=_0x44e131['interceptServerDataCallback_']?_0x44e131['interceptServerDataCallback_'](_0x393ed6,_0x44bf63):_0x44bf63;let _0x2991c3=[];if(_0x6429b1){if(_0xff8e34){const _0x420302=ln(_0x44bf63,_0x441cd3=>N(_0x441cd3));_0x2991c3=Ku(_0x44e131['serverSyncTree_'],_0x475abe,_0x420302,_0x6429b1);}else{const _0x3b7a0e=N(_0x44bf63);_0x2991c3=Yo(_0x44e131['serverSyncTree_'],_0x475abe,_0x3b7a0e,_0x6429b1);}}else{if(_0xff8e34){const _0xfda6f2=ln(_0x44bf63,_0x1d7515=>N(_0x1d7515));_0x2991c3=qu(_0x44e131['serverSyncTree_'],_0x475abe,_0xfda6f2);}else{const _0x52035a=N(_0x44bf63);_0x2991c3=$t(_0x44e131['serverSyncTree_'],_0x475abe,_0x52035a);}}let _0x36d750=_0x475abe;_0x2991c3['length']>0x0&&(_0x36d750=st(_0x44e131,_0x475abe)),V(_0x44e131['eventQueue_'],_0x36d750,_0x2991c3);}function _r(_0x37e401,_0x184520){ms(_0x37e401,'connected',_0x184520),_0x184520===!0x1&&wd(_0x37e401);}function yd(_0x2a00f0,_0x29d496){x(_0x29d496,(_0x3b76c6,_0x4b7058)=>{ms(_0x2a00f0,_0x3b76c6,_0x4b7058);});}function ms(_0x1ab453,_0x203db0,_0x146d7c){const _0x4b580d=new C('/.info/'+_0x203db0),_0x1c072e=N(_0x146d7c);_0x1ab453['infoData_']['updateSnapshot'](_0x4b580d,_0x1c072e);const _0x4d20e2=$t(_0x1ab453['infoSyncTree_'],_0x4b580d,_0x1c072e);V(_0x1ab453['eventQueue_'],_0x4b580d,_0x4d20e2);}function Vn(_0x3e0045){return _0x3e0045['nextWriteId_']++;}function vd(_0x53fec1,_0x4a776f,_0xa7d51e){const _0x24694f=Yu(_0x53fec1['serverSyncTree_'],_0x4a776f);return _0x24694f!=null?Promise['resolve'](_0x24694f):_0x53fec1['server_']['get'](_0x4a776f)['then'](_0x1b359b=>{const _0x1aa6f8=N(_0x1b359b)['withIndex'](_0x4a776f['_queryParams']['getIndex']());bi(_0x53fec1['serverSyncTree_'],_0x4a776f,_0xa7d51e,!0x0);let _0x5a8f4e;if(_0x4a776f['_queryParams']['loadsAllData']())_0x5a8f4e=$t(_0x53fec1['serverSyncTree_'],_0x4a776f['_path'],_0x1aa6f8);else{const _0x6b6048=Mt(_0x53fec1['serverSyncTree_'],_0x4a776f);_0x5a8f4e=Yo(_0x53fec1['serverSyncTree_'],_0x4a776f['_path'],_0x1aa6f8,_0x6b6048);}return V(_0x53fec1['eventQueue_'],_0x4a776f['_path'],_0x5a8f4e),wn(_0x53fec1['serverSyncTree_'],_0x4a776f,_0xa7d51e,null,!0x0),_0x1aa6f8;},_0x5622a9=>(ut(_0x53fec1,'get\x20for\x20query\x20'+O(_0x4a776f)+'\x20failed:\x20'+_0x5622a9),Promise['reject'](new Error(_0x5622a9))));}function Ed(_0x53b52b,_0x1aec26,_0x3f1faf,_0x486968,_0x468514){ut(_0x53b52b,'set',{'path':_0x1aec26['toString'](),'value':_0x3f1faf,'priority':_0x486968});const _0x7f1ea7=jt(_0x53b52b),_0x5d76a2=N(_0x3f1faf,_0x486968),_0x5e10cf=xn(_0x53b52b['serverSyncTree_'],_0x1aec26),_0x4a8ef8=hs(_0x5d76a2,_0x5e10cf,_0x7f1ea7),_0x2b7127=Vn(_0x53b52b),_0x4e4ed7=ss(_0x53b52b['serverSyncTree_'],_0x1aec26,_0x4a8ef8,_0x2b7127,!0x0);Bn(_0x53b52b['eventQueue_'],_0x4e4ed7),_0x53b52b['server_']['put'](_0x1aec26['toString'](),_0x5d76a2['val'](!0x0),(_0x2602d7,_0x515d55)=>{const _0x420696=_0x2602d7==='ok';_0x420696||U('set\x20at\x20'+_0x1aec26+'\x20failed:\x20'+_0x2602d7);const _0x3b0563=pe(_0x53b52b['serverSyncTree_'],_0x2b7127,!_0x420696);V(_0x53b52b['eventQueue_'],_0x1aec26,_0x3b0563),Ai(_0x53b52b,_0x468514,_0x2602d7,_0x515d55);});const _0x4413a8=vs(_0x53b52b,_0x1aec26);st(_0x53b52b,_0x4413a8),V(_0x53b52b['eventQueue_'],_0x4413a8,[]);}function Id(_0x18ab4c,_0x3c60b0,_0x20ee2d,_0x12dcdc){ut(_0x18ab4c,'update',{'path':_0x3c60b0['toString'](),'value':_0x20ee2d});let _0x333ac5=!0x0;const _0x4c651e=jt(_0x18ab4c),_0x430373={};if(x(_0x20ee2d,(_0xe5c12,_0x5aeca1)=>{_0x333ac5=!0x1,_0x430373[_0xe5c12]=Zo(A(_0x3c60b0,_0xe5c12),N(_0x5aeca1),_0x18ab4c['serverSyncTree_'],_0x4c651e);}),_0x333ac5)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x18ab4c,_0x12dcdc,'ok',void 0x0);else{const _0xb0dc13=Vn(_0x18ab4c),_0x40a9f2=Gu(_0x18ab4c['serverSyncTree_'],_0x3c60b0,_0x430373,_0xb0dc13);Bn(_0x18ab4c['eventQueue_'],_0x40a9f2),_0x18ab4c['server_']['merge'](_0x3c60b0['toString'](),_0x20ee2d,(_0x15cbef,_0x5b0b52)=>{const _0x312a27=_0x15cbef==='ok';_0x312a27||U('update\x20at\x20'+_0x3c60b0+'\x20failed:\x20'+_0x15cbef);const _0x5cd877=pe(_0x18ab4c['serverSyncTree_'],_0xb0dc13,!_0x312a27),_0x837447=_0x5cd877['length']>0x0?st(_0x18ab4c,_0x3c60b0):_0x3c60b0;V(_0x18ab4c['eventQueue_'],_0x837447,_0x5cd877),Ai(_0x18ab4c,_0x12dcdc,_0x15cbef,_0x5b0b52);}),x(_0x20ee2d,_0x49a4cd=>{const _0x55079d=vs(_0x18ab4c,A(_0x3c60b0,_0x49a4cd));st(_0x18ab4c,_0x55079d);}),V(_0x18ab4c['eventQueue_'],_0x3c60b0,[]);}}function wd(_0x156761){ut(_0x156761,'onDisconnectEvents');const _0x1e5e1d=jt(_0x156761),_0x133430=pn();Ei(_0x156761['onDisconnect_'],w(),(_0xfc7b6f,_0x3d6cf1)=>{const _0xbf3cbd=Zo(_0xfc7b6f,_0x3d6cf1,_0x156761['serverSyncTree_'],_0x1e5e1d);Mo(_0x133430,_0xfc7b6f,_0xbf3cbd);});let _0x537f02=[];Ei(_0x133430,w(),(_0x20682c,_0x458052)=>{_0x537f02=_0x537f02['concat']($t(_0x156761['serverSyncTree_'],_0x20682c,_0x458052));const _0x144494=vs(_0x156761,_0x20682c);st(_0x156761,_0x144494);}),_0x156761['onDisconnect_']=pn(),V(_0x156761['eventQueue_'],w(),_0x537f02);}function Cd(_0x1d1ed7,_0x56c132,_0x19e2d1){let _0x458099;y(_0x56c132['_path'])==='.info'?_0x458099=bi(_0x1d1ed7['infoSyncTree_'],_0x56c132,_0x19e2d1):_0x458099=bi(_0x1d1ed7['serverSyncTree_'],_0x56c132,_0x19e2d1),ia(_0x1d1ed7['eventQueue_'],_0x56c132['_path'],_0x458099);}function Td(_0x3d05ea,_0x46f73b,_0x372958){let _0x46c334;y(_0x46f73b['_path'])==='.info'?_0x46c334=wn(_0x3d05ea['infoSyncTree_'],_0x46f73b,_0x372958):_0x46c334=wn(_0x3d05ea['serverSyncTree_'],_0x46f73b,_0x372958),ia(_0x3d05ea['eventQueue_'],_0x46f73b['_path'],_0x46c334);}function aa(_0x169b49){_0x169b49['persistentConnection_']&&_0x169b49['persistentConnection_']['interrupt'](ra);}function Sd(_0x22463d){_0x22463d['persistentConnection_']&&_0x22463d['persistentConnection_']['resume'](ra);}function ut(_0x153c55,..._0x79b4e0){let _0x1e648='';_0x153c55['persistentConnection_']&&(_0x1e648=_0x153c55['persistentConnection_']['id']+':'),L(_0x1e648,..._0x79b4e0);}function Ai(_0x4690f8,_0x289219,_0x11cb1d,_0x5070ff){_0x289219&&lt(()=>{if(_0x11cb1d==='ok')_0x289219(null);else{const _0x35143e=(_0x11cb1d||'error')['toUpperCase']();let _0x1a3ced=_0x35143e;_0x5070ff&&(_0x1a3ced+=':\x20'+_0x5070ff);const _0x31ce8c=new Error(_0x1a3ced);_0x31ce8c['code']=_0x35143e,_0x289219(_0x31ce8c);}});}function bd(_0x1757f8,_0x687696,_0x262d8e,_0x559cab,_0x1bb9a1,_0x4af070){ut(_0x1757f8,'transaction\x20on\x20'+_0x687696);const _0x38d628={'path':_0x687696,'update':_0x262d8e,'onComplete':_0x559cab,'status':null,'order':to(),'applyLocally':_0x4af070,'retryCount':0x0,'unwatcher':_0x1bb9a1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x474c91=ys(_0x1757f8,_0x687696,void 0x0);_0x38d628['currentInputSnapshot']=_0x474c91;const _0x33f212=_0x38d628['update'](_0x474c91['val']());if(_0x33f212===void 0x0)_0x38d628['unwatcher'](),_0x38d628['currentOutputSnapshotRaw']=null,_0x38d628['currentOutputSnapshotResolved']=null,_0x38d628['onComplete']&&_0x38d628['onComplete'](null,!0x1,_0x38d628['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x33f212,_0x38d628['path']),_0x38d628['status']=0x0;const _0x186dc7=Un(_0x1757f8['transactionQueueTree_'],_0x687696),_0x22dd30=Ge(_0x186dc7)||[];_0x22dd30['push'](_0x38d628),fs(_0x186dc7,_0x22dd30);let _0x26053a;typeof _0x33f212=='object'&&_0x33f212!==null&&Y(_0x33f212,'.priority')?(_0x26053a=Oe(_0x33f212,'.priority'),f(Cn(_0x26053a),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x26053a=(xn(_0x1757f8['serverSyncTree_'],_0x687696)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x16219d=jt(_0x1757f8),_0x5cdf9a=N(_0x33f212,_0x26053a),_0x2683e6=hs(_0x5cdf9a,_0x474c91,_0x16219d);_0x38d628['currentOutputSnapshotRaw']=_0x5cdf9a,_0x38d628['currentOutputSnapshotResolved']=_0x2683e6,_0x38d628['currentWriteId']=Vn(_0x1757f8);const _0x84dd1a=ss(_0x1757f8['serverSyncTree_'],_0x687696,_0x2683e6,_0x38d628['currentWriteId'],_0x38d628['applyLocally']);V(_0x1757f8['eventQueue_'],_0x687696,_0x84dd1a),Hn(_0x1757f8,_0x1757f8['transactionQueueTree_']);}}function ys(_0x2296b9,_0x42b804,_0x5c3cc0){return xn(_0x2296b9['serverSyncTree_'],_0x42b804,_0x5c3cc0)||g['EMPTY_NODE'];}function Hn(_0x42a9b1,_0x17d010=_0x42a9b1['transactionQueueTree_']){if(_0x17d010||$n(_0x42a9b1,_0x17d010),Ge(_0x17d010)){const _0x253214=la(_0x42a9b1,_0x17d010);f(_0x253214['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x253214['every'](_0x2f7176=>_0x2f7176['status']===0x0)&&Rd(_0x42a9b1,Gt(_0x17d010),_0x253214);}else ea(_0x17d010)&&Wn(_0x17d010,_0x5a1bee=>{Hn(_0x42a9b1,_0x5a1bee);});}function Rd(_0x3f7a79,_0x676ddc,_0x14c15e){const _0x3a344e=_0x14c15e['map'](_0x3ab51d=>_0x3ab51d['currentWriteId']),_0x154bc1=ys(_0x3f7a79,_0x676ddc,_0x3a344e);let _0x29dcff=_0x154bc1;const _0xf2f337=_0x154bc1['hash']();for(let _0x6eb5a3=0x0;_0x6eb5a3<_0x14c15e['length'];_0x6eb5a3++){const _0x400592=_0x14c15e[_0x6eb5a3];f(_0x400592['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x400592['status']=0x1,_0x400592['retryCount']++;const _0xd64a87=F(_0x676ddc,_0x400592['path']);_0x29dcff=_0x29dcff['updateChild'](_0xd64a87,_0x400592['currentOutputSnapshotRaw']);}const _0x1fee1f=_0x29dcff['val'](!0x0),_0x37793a=_0x676ddc;_0x3f7a79['server_']['put'](_0x37793a['toString'](),_0x1fee1f,_0x2b9775=>{ut(_0x3f7a79,'transaction\x20put\x20response',{'path':_0x37793a['toString'](),'status':_0x2b9775});let _0x3222a2=[];if(_0x2b9775==='ok'){const _0x1484cc=[];for(let _0x1017e2=0x0;_0x1017e2<_0x14c15e['length'];_0x1017e2++)_0x14c15e[_0x1017e2]['status']=0x2,_0x3222a2=_0x3222a2['concat'](pe(_0x3f7a79['serverSyncTree_'],_0x14c15e[_0x1017e2]['currentWriteId'])),_0x14c15e[_0x1017e2]['onComplete']&&_0x1484cc['push'](()=>_0x14c15e[_0x1017e2]['onComplete'](null,!0x0,_0x14c15e[_0x1017e2]['currentOutputSnapshotResolved'])),_0x14c15e[_0x1017e2]['unwatcher']();$n(_0x3f7a79,Un(_0x3f7a79['transactionQueueTree_'],_0x676ddc)),Hn(_0x3f7a79,_0x3f7a79['transactionQueueTree_']),V(_0x3f7a79['eventQueue_'],_0x676ddc,_0x3222a2);for(let _0x51e348=0x0;_0x51e348<_0x1484cc['length'];_0x51e348++)lt(_0x1484cc[_0x51e348]);}else{if(_0x2b9775==='datastale'){for(let _0x4cad37=0x0;_0x4cad37<_0x14c15e['length'];_0x4cad37++)_0x14c15e[_0x4cad37]['status']===0x3?_0x14c15e[_0x4cad37]['status']=0x4:_0x14c15e[_0x4cad37]['status']=0x0;}else{U('transaction\x20at\x20'+_0x37793a['toString']()+'\x20failed:\x20'+_0x2b9775);for(let _0x5996fe=0x0;_0x5996fe<_0x14c15e['length'];_0x5996fe++)_0x14c15e[_0x5996fe]['status']=0x4,_0x14c15e[_0x5996fe]['abortReason']=_0x2b9775;}st(_0x3f7a79,_0x676ddc);}},_0xf2f337);}function st(_0x129053,_0x3833e1){const _0x114c01=ca(_0x129053,_0x3833e1),_0x4e29d8=Gt(_0x114c01),_0x307f41=la(_0x129053,_0x114c01);return Ad(_0x129053,_0x307f41,_0x4e29d8),_0x4e29d8;}function Ad(_0x2cdf02,_0x1f43ee,_0x16ced8){if(_0x1f43ee['length']===0x0)return;const _0x278ce7=[];let _0x207fea=[];const _0x1c128f=_0x1f43ee['filter'](_0x110476=>_0x110476['status']===0x0)['map'](_0x4377cf=>_0x4377cf['currentWriteId']);for(let _0x200ef8=0x0;_0x200ef8<_0x1f43ee['length'];_0x200ef8++){const _0x3c73ea=_0x1f43ee[_0x200ef8],_0x4e4a46=F(_0x16ced8,_0x3c73ea['path']);let _0x5acaaf=!0x1,_0x334c8e;if(f(_0x4e4a46!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3c73ea['status']===0x4)_0x5acaaf=!0x0,_0x334c8e=_0x3c73ea['abortReason'],_0x207fea=_0x207fea['concat'](pe(_0x2cdf02['serverSyncTree_'],_0x3c73ea['currentWriteId'],!0x0));else{if(_0x3c73ea['status']===0x0){if(_0x3c73ea['retryCount']>=_d)_0x5acaaf=!0x0,_0x334c8e='maxretry',_0x207fea=_0x207fea['concat'](pe(_0x2cdf02['serverSyncTree_'],_0x3c73ea['currentWriteId'],!0x0));else{const _0x5bd1b5=ys(_0x2cdf02,_0x3c73ea['path'],_0x1c128f);_0x3c73ea['currentInputSnapshot']=_0x5bd1b5;const _0x5a5f6b=_0x1f43ee[_0x200ef8]['update'](_0x5bd1b5['val']());if(_0x5a5f6b!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x5a5f6b,_0x3c73ea['path']);let _0x45c26a=N(_0x5a5f6b);typeof _0x5a5f6b=='object'&&_0x5a5f6b!=null&&Y(_0x5a5f6b,'.priority')||(_0x45c26a=_0x45c26a['updatePriority'](_0x5bd1b5['getPriority']()));const _0x4ac006=_0x3c73ea['currentWriteId'],_0x3cd460=jt(_0x2cdf02),_0x531056=hs(_0x45c26a,_0x5bd1b5,_0x3cd460);_0x3c73ea['currentOutputSnapshotRaw']=_0x45c26a,_0x3c73ea['currentOutputSnapshotResolved']=_0x531056,_0x3c73ea['currentWriteId']=Vn(_0x2cdf02),_0x1c128f['splice'](_0x1c128f['indexOf'](_0x4ac006),0x1),_0x207fea=_0x207fea['concat'](ss(_0x2cdf02['serverSyncTree_'],_0x3c73ea['path'],_0x531056,_0x3c73ea['currentWriteId'],_0x3c73ea['applyLocally'])),_0x207fea=_0x207fea['concat'](pe(_0x2cdf02['serverSyncTree_'],_0x4ac006,!0x0));}else _0x5acaaf=!0x0,_0x334c8e='nodata',_0x207fea=_0x207fea['concat'](pe(_0x2cdf02['serverSyncTree_'],_0x3c73ea['currentWriteId'],!0x0));}}}V(_0x2cdf02['eventQueue_'],_0x16ced8,_0x207fea),_0x207fea=[],_0x5acaaf&&(_0x1f43ee[_0x200ef8]['status']=0x2,function(_0x156d17){setTimeout(_0x156d17,Math['floor'](0x0));}(_0x1f43ee[_0x200ef8]['unwatcher']),_0x1f43ee[_0x200ef8]['onComplete']&&(_0x334c8e==='nodata'?_0x278ce7['push'](()=>_0x1f43ee[_0x200ef8]['onComplete'](null,!0x1,_0x1f43ee[_0x200ef8]['currentInputSnapshot'])):_0x278ce7['push'](()=>_0x1f43ee[_0x200ef8]['onComplete'](new Error(_0x334c8e),!0x1,null))));}$n(_0x2cdf02,_0x2cdf02['transactionQueueTree_']);for(let _0x427c35=0x0;_0x427c35<_0x278ce7['length'];_0x427c35++)lt(_0x278ce7[_0x427c35]);Hn(_0x2cdf02,_0x2cdf02['transactionQueueTree_']);}function ca(_0x505adf,_0x4a7708){let _0x3aec7f,_0x5a6e2c=_0x505adf['transactionQueueTree_'];for(_0x3aec7f=y(_0x4a7708);_0x3aec7f!==null&&Ge(_0x5a6e2c)===void 0x0;)_0x5a6e2c=Un(_0x5a6e2c,_0x3aec7f),_0x4a7708=b(_0x4a7708),_0x3aec7f=y(_0x4a7708);return _0x5a6e2c;}function la(_0x116710,_0x35dab8){const _0x5de376=[];return ha(_0x116710,_0x35dab8,_0x5de376),_0x5de376['sort']((_0x389f78,_0x12d7ba)=>_0x389f78['order']-_0x12d7ba['order']),_0x5de376;}function ha(_0x4312cf,_0x164d4b,_0x4f9d26){const _0x1f65a1=Ge(_0x164d4b);if(_0x1f65a1){for(let _0x1a2010=0x0;_0x1a2010<_0x1f65a1['length'];_0x1a2010++)_0x4f9d26['push'](_0x1f65a1[_0x1a2010]);}Wn(_0x164d4b,_0x53b113=>{ha(_0x4312cf,_0x53b113,_0x4f9d26);});}function $n(_0x56ccdd,_0x3442a9){const _0x2f0604=Ge(_0x3442a9);if(_0x2f0604){let _0x19b564=0x0;for(let _0x45ab33=0x0;_0x45ab33<_0x2f0604['length'];_0x45ab33++)_0x2f0604[_0x45ab33]['status']!==0x2&&(_0x2f0604[_0x19b564]=_0x2f0604[_0x45ab33],_0x19b564++);_0x2f0604['length']=_0x19b564,fs(_0x3442a9,_0x2f0604['length']>0x0?_0x2f0604:void 0x0);}Wn(_0x3442a9,_0x26a726=>{$n(_0x56ccdd,_0x26a726);});}function vs(_0x48e379,_0x4fef1f){const _0x4f7a7f=Gt(ca(_0x48e379,_0x4fef1f)),_0x51ef42=Un(_0x48e379['transactionQueueTree_'],_0x4fef1f);return sd(_0x51ef42,_0xcdb3d4=>{ai(_0x48e379,_0xcdb3d4);}),ai(_0x48e379,_0x51ef42),ta(_0x51ef42,_0x58de49=>{ai(_0x48e379,_0x58de49);}),_0x4f7a7f;}function ai(_0x4fdbab,_0x3e64ee){const _0x2a314d=Ge(_0x3e64ee);if(_0x2a314d){const _0x37764c=[];let _0x265502=[],_0x4809f0=-0x1;for(let _0x57c873=0x0;_0x57c873<_0x2a314d['length'];_0x57c873++)_0x2a314d[_0x57c873]['status']===0x3||(_0x2a314d[_0x57c873]['status']===0x1?(f(_0x4809f0===_0x57c873-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4809f0=_0x57c873,_0x2a314d[_0x57c873]['status']=0x3,_0x2a314d[_0x57c873]['abortReason']='set'):(f(_0x2a314d[_0x57c873]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2a314d[_0x57c873]['unwatcher'](),_0x265502=_0x265502['concat'](pe(_0x4fdbab['serverSyncTree_'],_0x2a314d[_0x57c873]['currentWriteId'],!0x0)),_0x2a314d[_0x57c873]['onComplete']&&_0x37764c['push'](_0x2a314d[_0x57c873]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4809f0===-0x1?fs(_0x3e64ee,void 0x0):_0x2a314d['length']=_0x4809f0+0x1,V(_0x4fdbab['eventQueue_'],Gt(_0x3e64ee),_0x265502);for(let _0x3eaf22=0x0;_0x3eaf22<_0x37764c['length'];_0x3eaf22++)lt(_0x37764c[_0x3eaf22]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x52a886){let _0x390dc8='';const _0xcc9c3f=_0x52a886['split']('/');for(let _0x545904=0x0;_0x545904<_0xcc9c3f['length'];_0x545904++)if(_0xcc9c3f[_0x545904]['length']>0x0){let _0x10e0ac=_0xcc9c3f[_0x545904];try{_0x10e0ac=decodeURIComponent(_0x10e0ac['replace'](/\+/g,'\x20'));}catch{}_0x390dc8+='/'+_0x10e0ac;}return _0x390dc8;}function Nd(_0x4dfd8d){const _0x435718={};_0x4dfd8d['charAt'](0x0)==='?'&&(_0x4dfd8d=_0x4dfd8d['substring'](0x1));for(const _0x4de37b of _0x4dfd8d['split']('&')){if(_0x4de37b['length']===0x0)continue;const _0x5d6c8b=_0x4de37b['split']('=');_0x5d6c8b['length']===0x2?_0x435718[decodeURIComponent(_0x5d6c8b[0x0])]=decodeURIComponent(_0x5d6c8b[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4de37b+'\x27\x20in\x20query\x20\x27'+_0x4dfd8d+'\x27');}return _0x435718;}const gr=function(_0x3a3f03,_0x5b369d){const _0x20f8dd=Pd(_0x3a3f03),_0x461076=_0x20f8dd['namespace'];_0x20f8dd['domain']==='firebase.com'&&oe(_0x20f8dd['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x461076||_0x461076==='undefined')&&_0x20f8dd['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x20f8dd['secure']||Bl();const _0x9192ad=_0x20f8dd['scheme']==='ws'||_0x20f8dd['scheme']==='wss';return{'repoInfo':new _o(_0x20f8dd['host'],_0x20f8dd['secure'],_0x461076,_0x9192ad,_0x5b369d,'',_0x461076!==_0x20f8dd['subdomain']),'path':new C(_0x20f8dd['pathString'])};},Pd=function(_0x4706fb){let _0xfdf450='',_0x292da5='',_0x5d6c06='',_0x3384da='',_0x24707d='',_0x164924=!0x0,_0x1131e6='https',_0x377116=0x1bb;if(typeof _0x4706fb=='string'){let _0x112748=_0x4706fb['indexOf']('//');_0x112748>=0x0&&(_0x1131e6=_0x4706fb['substring'](0x0,_0x112748-0x1),_0x4706fb=_0x4706fb['substring'](_0x112748+0x2));let _0x41ce73=_0x4706fb['indexOf']('/');_0x41ce73===-0x1&&(_0x41ce73=_0x4706fb['length']);let _0x320bf6=_0x4706fb['indexOf']('?');_0x320bf6===-0x1&&(_0x320bf6=_0x4706fb['length']),_0xfdf450=_0x4706fb['substring'](0x0,Math['min'](_0x41ce73,_0x320bf6)),_0x41ce73<_0x320bf6&&(_0x3384da=kd(_0x4706fb['substring'](_0x41ce73,_0x320bf6)));const _0x417345=Nd(_0x4706fb['substring'](Math['min'](_0x4706fb['length'],_0x320bf6)));_0x112748=_0xfdf450['indexOf'](':'),_0x112748>=0x0?(_0x164924=_0x1131e6==='https'||_0x1131e6==='wss',_0x377116=parseInt(_0xfdf450['substring'](_0x112748+0x1),0xa)):_0x112748=_0xfdf450['length'];const _0x2fbe5b=_0xfdf450['slice'](0x0,_0x112748);if(_0x2fbe5b['toLowerCase']()==='localhost')_0x292da5='localhost';else{if(_0x2fbe5b['split']('.')['length']<=0x2)_0x292da5=_0x2fbe5b;else{const _0x2807e6=_0xfdf450['indexOf']('.');_0x5d6c06=_0xfdf450['substring'](0x0,_0x2807e6)['toLowerCase'](),_0x292da5=_0xfdf450['substring'](_0x2807e6+0x1),_0x24707d=_0x5d6c06;}}'ns'in _0x417345&&(_0x24707d=_0x417345['ns']);}return{'host':_0xfdf450,'port':_0x377116,'domain':_0x292da5,'subdomain':_0x5d6c06,'secure':_0x164924,'scheme':_0x1131e6,'pathString':_0x3384da,'namespace':_0x24707d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x426673=0x0;const _0x219148=[];return function(_0x34b186){const _0x50c167=_0x34b186===_0x426673;_0x426673=_0x34b186;let _0x519940;const _0x398652=new Array(0x8);for(_0x519940=0x7;_0x519940>=0x0;_0x519940--)_0x398652[_0x519940]=mr['charAt'](_0x34b186%0x40),_0x34b186=Math['floor'](_0x34b186/0x40);f(_0x34b186===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x6227f2=_0x398652['join']('');if(_0x50c167){for(_0x519940=0xb;_0x519940>=0x0&&_0x219148[_0x519940]===0x3f;_0x519940--)_0x219148[_0x519940]=0x0;_0x219148[_0x519940]++;}else{for(_0x519940=0x0;_0x519940<0xc;_0x519940++)_0x219148[_0x519940]=Math['floor'](Math['random']()*0x40);}for(_0x519940=0x0;_0x519940<0xc;_0x519940++)_0x6227f2+=mr['charAt'](_0x219148[_0x519940]);return f(_0x6227f2['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x6227f2;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x826f8f,_0x4ce91b,_0x512f6f,_0x59da5c){this['eventType']=_0x826f8f,this['eventRegistration']=_0x4ce91b,this['snapshot']=_0x512f6f,this['prevName']=_0x59da5c;}['getPath'](){const _0x203633=this['snapshot']['ref'];return this['eventType']==='value'?_0x203633['_path']:_0x203633['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3e84be,_0x23a490,_0x5d0ecf){this['eventRegistration']=_0x3e84be,this['error']=_0x23a490,this['path']=_0x5d0ecf;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x45b4f6,_0x14af7){this['snapshotCallback']=_0x45b4f6,this['cancelCallback']=_0x14af7;}['onValue'](_0x51f60a,_0x5ee7fd){this['snapshotCallback']['call'](null,_0x51f60a,_0x5ee7fd);}['onCancel'](_0x47d89b){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x47d89b);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xe4315e){return this['snapshotCallback']===_0xe4315e['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xe4315e['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xe4315e['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xfb9606,_0x11bef6,_0x3696e2,_0x19ac36){this['_repo']=_0xfb9606,this['_path']=_0x11bef6,this['_queryParams']=_0x3696e2,this['_orderByCalled']=_0x19ac36;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x599399=nr(this['_queryParams']),_0x5ba63e=Bi(_0x599399);return _0x5ba63e==='{}'?'default':_0x5ba63e;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x25b4cd){if(_0x25b4cd=k(_0x25b4cd),!(_0x25b4cd instanceof be))return!0x1;const _0x474ef0=this['_repo']===_0x25b4cd['_repo'],_0x4e11c1=qi(this['_path'],_0x25b4cd['_path']),_0x3ab479=this['_queryIdentifier']===_0x25b4cd['_queryIdentifier'];return _0x474ef0&&_0x4e11c1&&_0x3ab479;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x3c72dd,_0x1d9314){if(_0x3c72dd['_orderByCalled']===!0x0)throw new Error(_0x1d9314+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x2f9530){let _0x161b68=null,_0x2aa0b0=null;if(_0x2f9530['hasStart']()&&(_0x161b68=_0x2f9530['getIndexStartValue']()),_0x2f9530['hasEnd']()&&(_0x2aa0b0=_0x2f9530['getIndexEndValue']()),_0x2f9530['getIndex']()===ye){const _0x5726fa='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2f67c3='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2f9530['hasStart']()){if(_0x2f9530['getIndexStartName']()!==xe)throw new Error(_0x5726fa);if(typeof _0x161b68!='string')throw new Error(_0x2f67c3);}if(_0x2f9530['hasEnd']()){if(_0x2f9530['getIndexEndName']()!==Ie)throw new Error(_0x5726fa);if(typeof _0x2aa0b0!='string')throw new Error(_0x2f67c3);}}else{if(_0x2f9530['getIndex']()===R){if(_0x161b68!=null&&!Cn(_0x161b68)||_0x2aa0b0!=null&&!Cn(_0x2aa0b0))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2f9530['getIndex']()instanceof Ki||_0x2f9530['getIndex']()===Po,'unknown\x20index\x20type.'),_0x161b68!=null&&typeof _0x161b68=='object'||_0x2aa0b0!=null&&typeof _0x2aa0b0=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2b057c){if(_0x2b057c['hasStart']()&&_0x2b057c['hasEnd']()&&_0x2b057c['hasLimit']()&&!_0x2b057c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x5c6d89,_0x1be7ca){super(_0x5c6d89,_0x1be7ca,new Qi(),!0x1);}get['parent'](){const _0x54cea4=To(this['_path']);return _0x54cea4===null?null:new Z(this['_repo'],_0x54cea4);}get['root'](){let _0x196f2a=this;for(;_0x196f2a['parent']!==null;)_0x196f2a=_0x196f2a['parent'];return _0x196f2a;}}class rt{constructor(_0x5a99e0,_0x4c0a38,_0x46b7b0){this['_node']=_0x5a99e0,this['ref']=_0x4c0a38,this['_index']=_0x46b7b0;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x9dafd2){const _0x393a8a=new C(_0x9dafd2),_0x25c79a=Lt(this['ref'],_0x9dafd2);return new rt(this['_node']['getChild'](_0x393a8a),_0x25c79a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x534ca3){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x527b3f,_0x23f75b)=>_0x534ca3(new rt(_0x23f75b,Lt(this['ref'],_0x527b3f),R)));}['hasChild'](_0x188bef){const _0x2ceb7b=new C(_0x188bef);return!this['_node']['getChild'](_0x2ceb7b)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x63e8bd,_0xbb5e83){return _0x63e8bd=k(_0x63e8bd),_0x63e8bd['_checkNotDeleted']('ref'),_0xbb5e83!==void 0x0?Lt(_0x63e8bd['_root'],_0xbb5e83):_0x63e8bd['_root'];}function Lt(_0x2f44df,_0x49d167){return _0x2f44df=k(_0x2f44df),y(_0x2f44df['_path'])===null?ud('child','path',_0x49d167):_s('child','path',_0x49d167),new Z(_0x2f44df['_repo'],A(_0x2f44df['_path'],_0x49d167));}function d_(_0x2608de,_0x425702){_0x2608de=k(_0x2608de),gs('push',_0x2608de['_path']),qt('push',_0x425702,_0x2608de['_path'],!0x0);const _0x59ef8e=oa(_0x2608de['_repo']),_0x2ed580=Od(_0x59ef8e),_0x55938c=Lt(_0x2608de,_0x2ed580),_0x55404d=Lt(_0x2608de,_0x2ed580);let _0x458113;return _0x425702!=null?_0x458113=Ld(_0x55404d,_0x425702)['then'](()=>_0x55404d):_0x458113=Promise['resolve'](_0x55404d),_0x55938c['then']=_0x458113['then']['bind'](_0x458113),_0x55938c['catch']=_0x458113['then']['bind'](_0x458113,void 0x0),_0x55938c;}function Ld(_0x59dc6a,_0x3052d5){_0x59dc6a=k(_0x59dc6a),gs('set',_0x59dc6a['_path']),qt('set',_0x3052d5,_0x59dc6a['_path'],!0x1);const _0x26d17c=new Ve();return Ed(_0x59dc6a['_repo'],_0x59dc6a['_path'],_0x3052d5,null,_0x26d17c['wrapCallback'](()=>{})),_0x26d17c['promise'];}function f_(_0x4e6bbd,_0x4acb58){hd('update',_0x4acb58,_0x4e6bbd['_path']);const _0x158a86=new Ve();return Id(_0x4e6bbd['_repo'],_0x4e6bbd['_path'],_0x4acb58,_0x158a86['wrapCallback'](()=>{})),_0x158a86['promise'];}function p_(_0xf51a35){_0xf51a35=k(_0xf51a35);const _0x12e62e=new ua(()=>{}),_0x5e3df8=new qn(_0x12e62e);return vd(_0xf51a35['_repo'],_0xf51a35,_0x5e3df8)['then'](_0xdc5e97=>new rt(_0xdc5e97,new Z(_0xf51a35['_repo'],_0xf51a35['_path']),_0xf51a35['_queryParams']['getIndex']()));}class qn{constructor(_0x1e5e6f){this['callbackContext']=_0x1e5e6f;}['respondsTo'](_0x57102b){return _0x57102b==='value';}['createEvent'](_0x14fce1,_0x4647a5){const _0x2dd3ac=_0x4647a5['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x14fce1['snapshotNode'],new Z(_0x4647a5['_repo'],_0x4647a5['_path']),_0x2dd3ac));}['getEventRunner'](_0x1eb075){return _0x1eb075['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1eb075['error']):()=>this['callbackContext']['onValue'](_0x1eb075['snapshot'],null);}['createCancelEvent'](_0x460c4e,_0x26f4c2){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x460c4e,_0x26f4c2):null;}['matches'](_0x125c11){return _0x125c11 instanceof qn?!_0x125c11['callbackContext']||!this['callbackContext']?!0x0:_0x125c11['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x5e8c1d,_0xa43167,_0x4cf080,_0x2278af,_0x2be73d){const _0x8c64f4=new ua(_0x4cf080,void 0x0),_0x4a24fa=new qn(_0x8c64f4);return Cd(_0x5e8c1d['_repo'],_0x5e8c1d,_0x4a24fa),()=>Td(_0x5e8c1d['_repo'],_0x5e8c1d,_0x4a24fa);}function Fd(_0x1de471,_0x36e460,_0x5626f3,_0x197273){return xd(_0x1de471,'value',_0x36e460);}class dt{}class pa extends dt{constructor(_0x307bee,_0x4201cd){super(),this['_value']=_0x307bee,this['_key']=_0x4201cd,this['type']='endAt';}['_apply'](_0x38dc91){qt('endAt',this['_value'],_0x38dc91['_path'],!0x0);const _0x435f19=Kh(_0x38dc91['_queryParams'],this['_value'],this['_key']);if(fa(_0x435f19),Gn(_0x435f19),_0x38dc91['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x38dc91['_repo'],_0x38dc91['_path'],_0x435f19,_0x38dc91['_orderByCalled']);}}function __(_0x2cd92c,_0x303881){return new pa(_0x2cd92c,_0x303881);}class _a extends dt{constructor(_0x2c398b,_0x2e0398){super(),this['_value']=_0x2c398b,this['_key']=_0x2e0398,this['type']='startAt';}['_apply'](_0x23d5bb){qt('startAt',this['_value'],_0x23d5bb['_path'],!0x0);const _0x50ee0a=jh(_0x23d5bb['_queryParams'],this['_value'],this['_key']);if(fa(_0x50ee0a),Gn(_0x50ee0a),_0x23d5bb['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x23d5bb['_repo'],_0x23d5bb['_path'],_0x50ee0a,_0x23d5bb['_orderByCalled']);}}function g_(_0x8fed71=null,_0x4b1249){return new _a(_0x8fed71,_0x4b1249);}class Ud extends dt{constructor(_0x2432c2){super(),this['_limit']=_0x2432c2,this['type']='limitToFirst';}['_apply'](_0x2a109a){if(_0x2a109a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2a109a['_repo'],_0x2a109a['_path'],zh(_0x2a109a['_queryParams'],this['_limit']),_0x2a109a['_orderByCalled']);}}function m_(_0x191cd4){if(Math['floor'](_0x191cd4)!==_0x191cd4||_0x191cd4<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x191cd4);}class Wd extends dt{constructor(_0xb616e1){super(),this['_path']=_0xb616e1,this['type']='orderByChild';}['_apply'](_0xa7e97b){da(_0xa7e97b,'orderByChild');const _0x50789f=new C(this['_path']);if(v(_0x50789f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3f7745=new Ki(_0x50789f),_0x2aa298=Do(_0xa7e97b['_queryParams'],_0x3f7745);return Gn(_0x2aa298),new be(_0xa7e97b['_repo'],_0xa7e97b['_path'],_0x2aa298,!0x0);}}function y_(_0x127033){if(_0x127033==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x127033==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x127033==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x127033),new Wd(_0x127033);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3efdeb){da(_0x3efdeb,'orderByKey');const _0x3564b4=Do(_0x3efdeb['_queryParams'],ye);return Gn(_0x3564b4),new be(_0x3efdeb['_repo'],_0x3efdeb['_path'],_0x3564b4,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x1d7585,_0x2ea132){super(),this['_value']=_0x1d7585,this['_key']=_0x2ea132,this['type']='equalTo';}['_apply'](_0x2b5482){if(qt('equalTo',this['_value'],_0x2b5482['_path'],!0x1),_0x2b5482['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2b5482['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x2b5482));}}function E_(_0xfdd14,_0x4faa86){return new Vd(_0xfdd14,_0x4faa86);}function I_(_0x3b33bf,..._0x1df4d0){let _0x270a64=k(_0x3b33bf);for(const _0x4b64a8 of _0x1df4d0)_0x270a64=_0x4b64a8['_apply'](_0x270a64);return _0x270a64;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x449918,_0x15eb80,_0x2a2259,_0x1bcc53){const _0x32df11=_0x15eb80['lastIndexOf'](':'),_0x43529d=_0x15eb80['substring'](0x0,_0x32df11),_0x8896fa=Wt(_0x43529d);_0x449918['repoInfo_']=new _o(_0x15eb80,_0x8896fa,_0x449918['repoInfo_']['namespace'],_0x449918['repoInfo_']['webSocketOnly'],_0x449918['repoInfo_']['nodeAdmin'],_0x449918['repoInfo_']['persistenceKey'],_0x449918['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2a2259),_0x1bcc53&&(_0x449918['authTokenProvider_']=_0x1bcc53);}function qd(_0x8001dd,_0x2a4a40,_0x57cb07,_0x11f29c,_0x484939){let _0x14e449=_0x11f29c||_0x8001dd['options']['databaseURL'];_0x14e449===void 0x0&&(_0x8001dd['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x8001dd['options']['projectId']),_0x14e449=_0x8001dd['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2e4e91=gr(_0x14e449,_0x484939),_0x3bc33f=_0x2e4e91['repoInfo'],_0x5c8f4f;typeof process<'u'&&Us&&(_0x5c8f4f=Us[Hd]),_0x5c8f4f?(_0x14e449='http://'+_0x5c8f4f+'?ns='+_0x3bc33f['namespace'],_0x2e4e91=gr(_0x14e449,_0x484939),_0x3bc33f=_0x2e4e91['repoInfo']):_0x2e4e91['repoInfo']['secure'];const _0x46b53c=new Jl(_0x8001dd['name'],_0x8001dd['options'],_0x2a4a40);dd('Invalid\x20Firebase\x20Database\x20URL',_0x2e4e91),v(_0x2e4e91['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x192bdb=jd(_0x3bc33f,_0x8001dd,_0x46b53c,new Ql(_0x8001dd,_0x57cb07));return new Kd(_0x192bdb,_0x8001dd);}function zd(_0x5e6b58,_0x2ee2bd){const _0x50b66b=ki[_0x2ee2bd];(!_0x50b66b||_0x50b66b[_0x5e6b58['key']]!==_0x5e6b58)&&oe('Database\x20'+_0x2ee2bd+'('+_0x5e6b58['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5e6b58),delete _0x50b66b[_0x5e6b58['key']];}function jd(_0x3278b2,_0x980a04,_0x5db797,_0x4ae464){let _0x488df1=ki[_0x980a04['name']];_0x488df1||(_0x488df1={},ki[_0x980a04['name']]=_0x488df1);let _0x72fe97=_0x488df1[_0x3278b2['toURLString']()];return _0x72fe97&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x72fe97=new gd(_0x3278b2,$d,_0x5db797,_0x4ae464),_0x488df1[_0x3278b2['toURLString']()]=_0x72fe97,_0x72fe97;}class Kd{constructor(_0xb2e894,_0x18d372){this['_repoInternal']=_0xb2e894,this['app']=_0x18d372,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4561c3){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x4561c3+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x567894=Qr(),_0x2920df){const _0x255ce9=Ui(_0x567894,'database')['getImmediate']({'identifier':_0x2920df});if(!_0x255ce9['_instanceStarted']){const _0x203dad=ac('database');_0x203dad&&Yd(_0x255ce9,..._0x203dad);}return _0x255ce9;}function Yd(_0x4b29ee,_0x20c8f2,_0x12e728,_0x258724={}){_0x4b29ee=k(_0x4b29ee),_0x4b29ee['_checkNotDeleted']('useEmulator');const _0x2ef17d=_0x20c8f2+':'+_0x12e728,_0x26aaa1=_0x4b29ee['_repoInternal'];if(_0x4b29ee['_instanceStarted']){if(_0x2ef17d===_0x4b29ee['_repoInternal']['repoInfo_']['host']&&De(_0x258724,_0x26aaa1['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xc150c3;if(_0x26aaa1['repoInfo_']['nodeAdmin'])_0x258724['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xc150c3=new tn(tn['OWNER']);else{if(_0x258724['mockUserToken']){const _0x27c025=typeof _0x258724['mockUserToken']=='string'?_0x258724['mockUserToken']:cc(_0x258724['mockUserToken'],_0x4b29ee['app']['options']['projectId']);_0xc150c3=new tn(_0x27c025);}}Wt(_0x20c8f2)&&jr(_0x20c8f2),Gd(_0x26aaa1,_0x2ef17d,_0x258724,_0xc150c3);}function C_(_0x35d149){_0x35d149=k(_0x35d149),_0x35d149['_checkNotDeleted']('goOffline'),aa(_0x35d149['_repo']);}function T_(_0x3dcfbd){_0x3dcfbd=k(_0x3dcfbd),_0x3dcfbd['_checkNotDeleted']('goOnline'),Sd(_0x3dcfbd['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x36c5ae){Ll(ct),et(new Me('database',(_0x38b955,{instanceIdentifier:_0x4ac9cd})=>{const _0x21271f=_0x38b955['getProvider']('app')['getImmediate'](),_0x1f09fb=_0x38b955['getProvider']('auth-internal'),_0x1f2d74=_0x38b955['getProvider']('app-check-internal');return qd(_0x21271f,_0x1f09fb,_0x1f2d74,_0x4ac9cd);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x36c5ae),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0xa72f0a,_0x5a7ebc){this['committed']=_0xa72f0a,this['snapshot']=_0x5a7ebc;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3fef8d,_0x251128,_0x39bbbd){if(_0x3fef8d=k(_0x3fef8d),gs('Reference.transaction',_0x3fef8d['_path']),_0x3fef8d['key']==='.length'||_0x3fef8d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3fef8d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x55ebea=!0x0,_0x291b7e=new Ve(),_0x555f27=(_0x423992,_0x2f30fa,_0x1f46f7)=>{let _0x356045=null;_0x423992?_0x291b7e['reject'](_0x423992):(_0x356045=new rt(_0x1f46f7,new Z(_0x3fef8d['_repo'],_0x3fef8d['_path']),R),_0x291b7e['resolve'](new Xd(_0x2f30fa,_0x356045)));},_0x1ed279=Fd(_0x3fef8d,()=>{});return bd(_0x3fef8d['_repo'],_0x3fef8d['_path'],_0x251128,_0x555f27,_0x1ed279,_0x55ebea),_0x291b7e['promise'];}ie['prototype']['simpleListen']=function(_0x462f95,_0x3fdf68){this['sendRequest']('q',{'p':_0x462f95},_0x3fdf68);},ie['prototype']['echo']=function(_0xe9c91e,_0x3dc9dd){this['sendRequest']('echo',{'d':_0xe9c91e},_0x3dc9dd);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x237484,..._0x144122){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x237484,..._0x144122);}function nn(_0x45e461,..._0xc038c5){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x45e461,..._0xc038c5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x5c755c,..._0x1da478){throw Es(_0x5c755c,..._0x1da478);}function J(_0xc1eb3c,..._0x4040a0){return Es(_0xc1eb3c,..._0x4040a0);}function ya(_0x1d3c8e,_0x524e7e,_0x21084d){const _0x75fe4={...Zd(),[_0x524e7e]:_0x21084d};return new Ut('auth','Firebase',_0x75fe4)['create'](_0x524e7e,{'appName':_0x1d3c8e['name']});}function se(_0x2a0c14){return ya(_0x2a0c14,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5f2ebe,..._0x5513b4){if(typeof _0x5f2ebe!='string'){const _0xff4908=_0x5513b4[0x0],_0x20901d=[..._0x5513b4['slice'](0x1)];return _0x20901d[0x0]&&(_0x20901d[0x0]['appName']=_0x5f2ebe['name']),_0x5f2ebe['_errorFactory']['create'](_0xff4908,..._0x20901d);}return ma['create'](_0x5f2ebe,..._0x5513b4);}function m(_0x1865d8,_0x344ed6,..._0x2c011a){if(!_0x1865d8)throw Es(_0x344ed6,..._0x2c011a);}function te(_0x2f98b9){const _0x3755e8='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2f98b9;throw nn(_0x3755e8),new Error(_0x3755e8);}function ae(_0x22a52e,_0x202a04){_0x22a52e||te(_0x202a04);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x41186f;return typeof self<'u'&&((_0x41186f=self['location'])==null?void 0x0:_0x41186f['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x2bd06a;return typeof self<'u'&&((_0x2bd06a=self['location'])==null?void 0x0:_0x2bd06a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x467107=navigator;return _0x467107['languages']&&_0x467107['languages'][0x0]||_0x467107['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x422bf9,_0x523529){this['shortDelay']=_0x422bf9,this['longDelay']=_0x523529,ae(_0x523529>_0x422bf9,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x3ee4c2,_0x56bf3a){ae(_0x3ee4c2['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x158f16}=_0x3ee4c2['emulator'];return _0x56bf3a?''+_0x158f16+(_0x56bf3a['startsWith']('/')?_0x56bf3a['slice'](0x1):_0x56bf3a):_0x158f16;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x154ce5,_0x175bcd,_0x2095a5){this['fetchImpl']=_0x154ce5,_0x175bcd&&(this['headersImpl']=_0x175bcd),_0x2095a5&&(this['responseImpl']=_0x2095a5);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x155960,_0xb3e857){return _0x155960['tenantId']&&!_0xb3e857['tenantId']?{..._0xb3e857,'tenantId':_0x155960['tenantId']}:_0xb3e857;}async function Ae(_0x3179c3,_0x5bac55,_0x4da189,_0x3cb63b,_0x530adb={}){return Ea(_0x3179c3,_0x530adb,async()=>{let _0xa46ed7={},_0x28ca9c={};_0x3cb63b&&(_0x5bac55==='GET'?_0x28ca9c=_0x3cb63b:_0xa46ed7={'body':JSON['stringify'](_0x3cb63b)});const _0x163d48=at({..._0x28ca9c,'key':_0x3179c3['config']['apiKey']})['slice'](0x1),_0x4cd00a=await _0x3179c3['_getAdditionalHeaders']();_0x4cd00a['Content-Type']='application/json',_0x3179c3['languageCode']&&(_0x4cd00a['X-Firebase-Locale']=_0x3179c3['languageCode']);const _0x4d2843={'method':_0x5bac55,'headers':_0x4cd00a,..._0xa46ed7};return lc()||(_0x4d2843['referrerPolicy']='strict-origin-when-cross-origin'),_0x3179c3['emulatorConfig']&&Wt(_0x3179c3['emulatorConfig']['host'])&&(_0x4d2843['credentials']='include'),va['fetch']()(await Ia(_0x3179c3,_0x3179c3['config']['apiHost'],_0x4da189,_0x163d48),_0x4d2843);});}async function Ea(_0x1e6b52,_0x4f8fb1,_0x126a40){_0x1e6b52['_canInitEmulator']=!0x1;const _0x4930e3={...rf,..._0x4f8fb1};try{const _0x239dcd=new lf(_0x1e6b52),_0x358b55=await Promise['race']([_0x126a40(),_0x239dcd['promise']]);_0x239dcd['clearNetworkTimeout']();const _0x49f49b=await _0x358b55['json']();if('needConfirmation'in _0x49f49b)throw en(_0x1e6b52,'account-exists-with-different-credential',_0x49f49b);if(_0x358b55['ok']&&!('errorMessage'in _0x49f49b))return _0x49f49b;{const _0xe037ae=_0x358b55['ok']?_0x49f49b['errorMessage']:_0x49f49b['error']['message'],[_0x2243a6,_0x1cd8c2]=_0xe037ae['split']('\x20:\x20');if(_0x2243a6==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x1e6b52,'credential-already-in-use',_0x49f49b);if(_0x2243a6==='EMAIL_EXISTS')throw en(_0x1e6b52,'email-already-in-use',_0x49f49b);if(_0x2243a6==='USER_DISABLED')throw en(_0x1e6b52,'user-disabled',_0x49f49b);const _0x510ad4=_0x4930e3[_0x2243a6]||_0x2243a6['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1cd8c2)throw ya(_0x1e6b52,_0x510ad4,_0x1cd8c2);K(_0x1e6b52,_0x510ad4);}}catch(_0x3b6ee3){if(_0x3b6ee3 instanceof Se)throw _0x3b6ee3;K(_0x1e6b52,'network-request-failed',{'message':String(_0x3b6ee3)});}}async function Yt(_0x579783,_0x428746,_0x50d756,_0x1c8830,_0x46ac43={}){const _0x659228=await Ae(_0x579783,_0x428746,_0x50d756,_0x1c8830,_0x46ac43);return'mfaPendingCredential'in _0x659228&&K(_0x579783,'multi-factor-auth-required',{'_serverResponse':_0x659228}),_0x659228;}async function Ia(_0x10d2c5,_0x1a364b,_0x43a83f,_0x26b08d){const _0x3cdf42=''+_0x1a364b+_0x43a83f+'?'+_0x26b08d,_0x284f05=_0x10d2c5,_0x2b16e2=_0x284f05['config']['emulator']?Is(_0x10d2c5['config'],_0x3cdf42):_0x10d2c5['config']['apiScheme']+'://'+_0x3cdf42;return of['includes'](_0x43a83f)&&(await _0x284f05['_persistenceManagerAvailable'],_0x284f05['_getPersistenceType']()==='COOKIE')?_0x284f05['_getPersistence']()['_getFinalTarget'](_0x2b16e2)['toString']():_0x2b16e2;}function cf(_0x5a7099){switch(_0x5a7099){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x102662){this['auth']=_0x102662,this['timer']=null,this['promise']=new Promise((_0x164057,_0x4a54f9)=>{this['timer']=setTimeout(()=>_0x4a54f9(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x1c5b97,_0x633aec,_0x4087fc){const _0x12a6e8={'appName':_0x1c5b97['name']};_0x4087fc['email']&&(_0x12a6e8['email']=_0x4087fc['email']),_0x4087fc['phoneNumber']&&(_0x12a6e8['phoneNumber']=_0x4087fc['phoneNumber']);const _0x26b3f5=J(_0x1c5b97,_0x633aec,_0x12a6e8);return _0x26b3f5['customData']['_tokenResponse']=_0x4087fc,_0x26b3f5;}function vr(_0x558cce){return _0x558cce!==void 0x0&&_0x558cce['enterprise']!==void 0x0;}class hf{constructor(_0x5d4957){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5d4957['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5d4957['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5d4957['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2f2c9e){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x599533 of this['recaptchaEnforcementState'])if(_0x599533['provider']&&_0x599533['provider']===_0x2f2c9e)return cf(_0x599533['enforcementState']);return null;}['isProviderEnabled'](_0x5d0f52){return this['getProviderEnforcementState'](_0x5d0f52)==='ENFORCE'||this['getProviderEnforcementState'](_0x5d0f52)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x254694,_0x5b6dcc){return Ae(_0x254694,'GET','/v2/recaptchaConfig',Re(_0x254694,_0x5b6dcc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x47ba56,_0x4e39d1){return Ae(_0x47ba56,'POST','/v1/accounts:delete',_0x4e39d1);}async function Sn(_0x542d59,_0x1b2ba7){return Ae(_0x542d59,'POST','/v1/accounts:lookup',_0x1b2ba7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x3fe1ee){if(_0x3fe1ee)try{const _0x2e6053=new Date(Number(_0x3fe1ee));if(!isNaN(_0x2e6053['getTime']()))return _0x2e6053['toUTCString']();}catch{}}async function ff(_0x8bb639,_0x5f061f=!0x1){const _0x3f67be=k(_0x8bb639),_0x5b689d=await _0x3f67be['getIdToken'](_0x5f061f),_0x29ccd7=ws(_0x5b689d);m(_0x29ccd7&&_0x29ccd7['exp']&&_0x29ccd7['auth_time']&&_0x29ccd7['iat'],_0x3f67be['auth'],'internal-error');const _0x5affff=typeof _0x29ccd7['firebase']=='object'?_0x29ccd7['firebase']:void 0x0,_0xe3df55=_0x5affff==null?void 0x0:_0x5affff['sign_in_provider'];return{'claims':_0x29ccd7,'token':_0x5b689d,'authTime':St(ci(_0x29ccd7['auth_time'])),'issuedAtTime':St(ci(_0x29ccd7['iat'])),'expirationTime':St(ci(_0x29ccd7['exp'])),'signInProvider':_0xe3df55||null,'signInSecondFactor':(_0x5affff==null?void 0x0:_0x5affff['sign_in_second_factor'])||null};}function ci(_0x31d0e6){return Number(_0x31d0e6)*0x3e8;}function ws(_0x41dc21){const [_0x40d21e,_0xf219fe,_0x86ff4c]=_0x41dc21['split']('.');if(_0x40d21e===void 0x0||_0xf219fe===void 0x0||_0x86ff4c===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x43bb24=cn(_0xf219fe);return _0x43bb24?JSON['parse'](_0x43bb24):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x26c315){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x26c315==null?void 0x0:_0x26c315['toString']()),null;}}function Er(_0x5da3fe){const _0x5aa9a8=ws(_0x5da3fe);return m(_0x5aa9a8,'internal-error'),m(typeof _0x5aa9a8['exp']<'u','internal-error'),m(typeof _0x5aa9a8['iat']<'u','internal-error'),Number(_0x5aa9a8['exp'])-Number(_0x5aa9a8['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x25ceb3,_0x54132b,_0x1aec7a=!0x1){if(_0x1aec7a)return _0x54132b;try{return await _0x54132b;}catch(_0x4faac9){throw _0x4faac9 instanceof Se&&pf(_0x4faac9)&&_0x25ceb3['auth']['currentUser']===_0x25ceb3&&await _0x25ceb3['auth']['signOut'](),_0x4faac9;}}function pf({code:_0x2d6914}){return _0x2d6914==='auth/user-disabled'||_0x2d6914==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x561eee){this['user']=_0x561eee,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x199347){if(_0x199347){const _0xf31343=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xf31343;}else{this['errorBackoff']=0x7530;const _0x184a2e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x184a2e);}}['schedule'](_0x491b7f=!0x1){if(!this['isRunning'])return;const _0x4c22ac=this['getInterval'](_0x491b7f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4c22ac);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1773f4){(_0x1773f4==null?void 0x0:_0x1773f4['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x455256,_0x2a8d2f){this['createdAt']=_0x455256,this['lastLoginAt']=_0x2a8d2f,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0xbb9a3b){this['createdAt']=_0xbb9a3b['createdAt'],this['lastLoginAt']=_0xbb9a3b['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x4ab4b2){var _0x131b5e;const _0x48a85c=_0x4ab4b2['auth'],_0x4c94f5=await _0x4ab4b2['getIdToken'](),_0x1f7160=await xt(_0x4ab4b2,Sn(_0x48a85c,{'idToken':_0x4c94f5}));m(_0x1f7160==null?void 0x0:_0x1f7160['users']['length'],_0x48a85c,'internal-error');const _0x19ffa8=_0x1f7160['users'][0x0];_0x4ab4b2['_notifyReloadListener'](_0x19ffa8);const _0x56b654=(_0x131b5e=_0x19ffa8['providerUserInfo'])!=null&&_0x131b5e['length']?wa(_0x19ffa8['providerUserInfo']):[],_0x7775a6=mf(_0x4ab4b2['providerData'],_0x56b654),_0x1fd64d=_0x4ab4b2['isAnonymous'],_0x456832=!(_0x4ab4b2['email']&&_0x19ffa8['passwordHash'])&&!(_0x7775a6!=null&&_0x7775a6['length']),_0x235397=_0x1fd64d?_0x456832:!0x1,_0x1d6f3a={'uid':_0x19ffa8['localId'],'displayName':_0x19ffa8['displayName']||null,'photoURL':_0x19ffa8['photoUrl']||null,'email':_0x19ffa8['email']||null,'emailVerified':_0x19ffa8['emailVerified']||!0x1,'phoneNumber':_0x19ffa8['phoneNumber']||null,'tenantId':_0x19ffa8['tenantId']||null,'providerData':_0x7775a6,'metadata':new Pi(_0x19ffa8['createdAt'],_0x19ffa8['lastLoginAt']),'isAnonymous':_0x235397};Object['assign'](_0x4ab4b2,_0x1d6f3a);}async function gf(_0x18ee7f){const _0x5a2473=k(_0x18ee7f);await bn(_0x5a2473),await _0x5a2473['auth']['_persistUserIfCurrent'](_0x5a2473),_0x5a2473['auth']['_notifyListenersIfCurrent'](_0x5a2473);}function mf(_0x7eb334,_0x512dfe){return[..._0x7eb334['filter'](_0x389d53=>!_0x512dfe['some'](_0x554d81=>_0x554d81['providerId']===_0x389d53['providerId'])),..._0x512dfe];}function wa(_0x151454){return _0x151454['map'](({providerId:_0x332891,..._0x5e1877})=>({'providerId':_0x332891,'uid':_0x5e1877['rawId']||'','displayName':_0x5e1877['displayName']||null,'email':_0x5e1877['email']||null,'phoneNumber':_0x5e1877['phoneNumber']||null,'photoURL':_0x5e1877['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0xa9007b,_0x3e59ba){const _0x21c148=await Ea(_0xa9007b,{},async()=>{const _0x43d34f=at({'grant_type':'refresh_token','refresh_token':_0x3e59ba})['slice'](0x1),{tokenApiHost:_0x172f08,apiKey:_0x5d0260}=_0xa9007b['config'],_0x5d0e2a=await Ia(_0xa9007b,_0x172f08,'/v1/token','key='+_0x5d0260),_0x350214=await _0xa9007b['_getAdditionalHeaders']();_0x350214['Content-Type']='application/x-www-form-urlencoded';const _0x12ed40={'method':'POST','headers':_0x350214,'body':_0x43d34f};return _0xa9007b['emulatorConfig']&&Wt(_0xa9007b['emulatorConfig']['host'])&&(_0x12ed40['credentials']='include'),va['fetch']()(_0x5d0e2a,_0x12ed40);});return{'accessToken':_0x21c148['access_token'],'expiresIn':_0x21c148['expires_in'],'refreshToken':_0x21c148['refresh_token']};}async function vf(_0x3e0978,_0x48fa85){return Ae(_0x3e0978,'POST','/v2/accounts:revokeToken',Re(_0x3e0978,_0x48fa85));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x11a084){m(_0x11a084['idToken'],'internal-error'),m(typeof _0x11a084['idToken']<'u','internal-error'),m(typeof _0x11a084['refreshToken']<'u','internal-error');const _0x353809='expiresIn'in _0x11a084&&typeof _0x11a084['expiresIn']<'u'?Number(_0x11a084['expiresIn']):Er(_0x11a084['idToken']);this['updateTokensAndExpiration'](_0x11a084['idToken'],_0x11a084['refreshToken'],_0x353809);}['updateFromIdToken'](_0xfb11b8){m(_0xfb11b8['length']!==0x0,'internal-error');const _0x1126e1=Er(_0xfb11b8);this['updateTokensAndExpiration'](_0xfb11b8,null,_0x1126e1);}async['getToken'](_0x35b23f,_0x591af9=!0x1){return!_0x591af9&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x35b23f,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x35b23f,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1407b5,_0x5e2649){const {accessToken:_0x5bab52,refreshToken:_0x1cf5e9,expiresIn:_0x186c08}=await yf(_0x1407b5,_0x5e2649);this['updateTokensAndExpiration'](_0x5bab52,_0x1cf5e9,Number(_0x186c08));}['updateTokensAndExpiration'](_0xf85d8b,_0x54ec71,_0x59e94c){this['refreshToken']=_0x54ec71||null,this['accessToken']=_0xf85d8b||null,this['expirationTime']=Date['now']()+_0x59e94c*0x3e8;}static['fromJSON'](_0x4226a6,_0x3050d0){const {refreshToken:_0x576cbf,accessToken:_0x1638e8,expirationTime:_0x4b109e}=_0x3050d0,_0x134d42=new Je();return _0x576cbf&&(m(typeof _0x576cbf=='string','internal-error',{'appName':_0x4226a6}),_0x134d42['refreshToken']=_0x576cbf),_0x1638e8&&(m(typeof _0x1638e8=='string','internal-error',{'appName':_0x4226a6}),_0x134d42['accessToken']=_0x1638e8),_0x4b109e&&(m(typeof _0x4b109e=='number','internal-error',{'appName':_0x4226a6}),_0x134d42['expirationTime']=_0x4b109e),_0x134d42;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x27e58a){this['accessToken']=_0x27e58a['accessToken'],this['refreshToken']=_0x27e58a['refreshToken'],this['expirationTime']=_0x27e58a['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x30cfbc,_0x32a88c){m(typeof _0x30cfbc=='string'||typeof _0x30cfbc>'u','internal-error',{'appName':_0x32a88c});}class z{constructor({uid:_0x95c72c,auth:_0x54c8ae,stsTokenManager:_0x16c900,..._0x1ed231}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x95c72c,this['auth']=_0x54c8ae,this['stsTokenManager']=_0x16c900,this['accessToken']=_0x16c900['accessToken'],this['displayName']=_0x1ed231['displayName']||null,this['email']=_0x1ed231['email']||null,this['emailVerified']=_0x1ed231['emailVerified']||!0x1,this['phoneNumber']=_0x1ed231['phoneNumber']||null,this['photoURL']=_0x1ed231['photoURL']||null,this['isAnonymous']=_0x1ed231['isAnonymous']||!0x1,this['tenantId']=_0x1ed231['tenantId']||null,this['providerData']=_0x1ed231['providerData']?[..._0x1ed231['providerData']]:[],this['metadata']=new Pi(_0x1ed231['createdAt']||void 0x0,_0x1ed231['lastLoginAt']||void 0x0);}async['getIdToken'](_0x306278){const _0x2ca23b=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x306278));return m(_0x2ca23b,this['auth'],'internal-error'),this['accessToken']!==_0x2ca23b&&(this['accessToken']=_0x2ca23b,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2ca23b;}['getIdTokenResult'](_0x1e8c07){return ff(this,_0x1e8c07);}['reload'](){return gf(this);}['_assign'](_0x5b112b){this!==_0x5b112b&&(m(this['uid']===_0x5b112b['uid'],this['auth'],'internal-error'),this['displayName']=_0x5b112b['displayName'],this['photoURL']=_0x5b112b['photoURL'],this['email']=_0x5b112b['email'],this['emailVerified']=_0x5b112b['emailVerified'],this['phoneNumber']=_0x5b112b['phoneNumber'],this['isAnonymous']=_0x5b112b['isAnonymous'],this['tenantId']=_0x5b112b['tenantId'],this['providerData']=_0x5b112b['providerData']['map'](_0x50440d=>({..._0x50440d})),this['metadata']['_copy'](_0x5b112b['metadata']),this['stsTokenManager']['_assign'](_0x5b112b['stsTokenManager']));}['_clone'](_0x10ca08){const _0x3be48e=new z({...this,'auth':_0x10ca08,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3be48e['metadata']['_copy'](this['metadata']),_0x3be48e;}['_onReload'](_0x1e03c9){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1e03c9,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4cf2a5){this['reloadListener']?this['reloadListener'](_0x4cf2a5):this['reloadUserInfo']=_0x4cf2a5;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x192dfc,_0x1891f8=!0x1){let _0x14d3dc=!0x1;_0x192dfc['idToken']&&_0x192dfc['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x192dfc),_0x14d3dc=!0x0),_0x1891f8&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x14d3dc&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x4f69bd=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x4f69bd})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4471b8=>({..._0x4471b8})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x18b7b6,_0x1938de){const _0x144e3b=_0x1938de['displayName']??void 0x0,_0x4c0415=_0x1938de['email']??void 0x0,_0x4e91b6=_0x1938de['phoneNumber']??void 0x0,_0x50ac84=_0x1938de['photoURL']??void 0x0,_0x4119cf=_0x1938de['tenantId']??void 0x0,_0x2046d9=_0x1938de['_redirectEventId']??void 0x0,_0xa850ec=_0x1938de['createdAt']??void 0x0,_0x432278=_0x1938de['lastLoginAt']??void 0x0,{uid:_0x26b5bc,emailVerified:_0x2a9a01,isAnonymous:_0x7e06f8,providerData:_0x572aef,stsTokenManager:_0x36277d}=_0x1938de;m(_0x26b5bc&&_0x36277d,_0x18b7b6,'internal-error');const _0x57e67e=Je['fromJSON'](this['name'],_0x36277d);m(typeof _0x26b5bc=='string',_0x18b7b6,'internal-error'),ce(_0x144e3b,_0x18b7b6['name']),ce(_0x4c0415,_0x18b7b6['name']),m(typeof _0x2a9a01=='boolean',_0x18b7b6,'internal-error'),m(typeof _0x7e06f8=='boolean',_0x18b7b6,'internal-error'),ce(_0x4e91b6,_0x18b7b6['name']),ce(_0x50ac84,_0x18b7b6['name']),ce(_0x4119cf,_0x18b7b6['name']),ce(_0x2046d9,_0x18b7b6['name']),ce(_0xa850ec,_0x18b7b6['name']),ce(_0x432278,_0x18b7b6['name']);const _0x612368=new z({'uid':_0x26b5bc,'auth':_0x18b7b6,'email':_0x4c0415,'emailVerified':_0x2a9a01,'displayName':_0x144e3b,'isAnonymous':_0x7e06f8,'photoURL':_0x50ac84,'phoneNumber':_0x4e91b6,'tenantId':_0x4119cf,'stsTokenManager':_0x57e67e,'createdAt':_0xa850ec,'lastLoginAt':_0x432278});return _0x572aef&&Array['isArray'](_0x572aef)&&(_0x612368['providerData']=_0x572aef['map'](_0x17a24f=>({..._0x17a24f}))),_0x2046d9&&(_0x612368['_redirectEventId']=_0x2046d9),_0x612368;}static async['_fromIdTokenResponse'](_0x41035d,_0x870f13,_0x2dc93f=!0x1){const _0x51ea57=new Je();_0x51ea57['updateFromServerResponse'](_0x870f13);const _0x1882a6=new z({'uid':_0x870f13['localId'],'auth':_0x41035d,'stsTokenManager':_0x51ea57,'isAnonymous':_0x2dc93f});return await bn(_0x1882a6),_0x1882a6;}static async['_fromGetAccountInfoResponse'](_0x440b15,_0x4126e4,_0x14f660){const _0x464576=_0x4126e4['users'][0x0];m(_0x464576['localId']!==void 0x0,'internal-error');const _0xae57a1=_0x464576['providerUserInfo']!==void 0x0?wa(_0x464576['providerUserInfo']):[],_0x305213=!(_0x464576['email']&&_0x464576['passwordHash'])&&!(_0xae57a1!=null&&_0xae57a1['length']),_0x15e13b=new Je();_0x15e13b['updateFromIdToken'](_0x14f660);const _0x1bd8ec=new z({'uid':_0x464576['localId'],'auth':_0x440b15,'stsTokenManager':_0x15e13b,'isAnonymous':_0x305213}),_0x2f7589={'uid':_0x464576['localId'],'displayName':_0x464576['displayName']||null,'photoURL':_0x464576['photoUrl']||null,'email':_0x464576['email']||null,'emailVerified':_0x464576['emailVerified']||!0x1,'phoneNumber':_0x464576['phoneNumber']||null,'tenantId':_0x464576['tenantId']||null,'providerData':_0xae57a1,'metadata':new Pi(_0x464576['createdAt'],_0x464576['lastLoginAt']),'isAnonymous':!(_0x464576['email']&&_0x464576['passwordHash'])&&!(_0xae57a1!=null&&_0xae57a1['length'])};return Object['assign'](_0x1bd8ec,_0x2f7589),_0x1bd8ec;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x318ebd){ae(_0x318ebd instanceof Function,'Expected\x20a\x20class\x20definition');let _0x411f61=Ir['get'](_0x318ebd);return _0x411f61?(ae(_0x411f61 instanceof _0x318ebd,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x411f61):(_0x411f61=new _0x318ebd(),Ir['set'](_0x318ebd,_0x411f61),_0x411f61);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x480123,_0x13559a){this['storage'][_0x480123]=_0x13559a;}async['_get'](_0x476e35){const _0x496936=this['storage'][_0x476e35];return _0x496936===void 0x0?null:_0x496936;}async['_remove'](_0x107480){delete this['storage'][_0x107480];}['_addListener'](_0x5b3299,_0x204a5a){}['_removeListener'](_0x5838db,_0x106aa5){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x4d0334,_0x26c44d,_0x56207a){return'firebase:'+_0x4d0334+':'+_0x26c44d+':'+_0x56207a;}class Xe{constructor(_0x1a7418,_0x58f37c,_0x1f717f){this['persistence']=_0x1a7418,this['auth']=_0x58f37c,this['userKey']=_0x1f717f;const {config:_0x28f54e,name:_0x5d3c70}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x28f54e['apiKey'],_0x5d3c70),this['fullPersistenceKey']=sn('persistence',_0x28f54e['apiKey'],_0x5d3c70),this['boundEventHandler']=_0x58f37c['_onStorageEvent']['bind'](_0x58f37c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x20de3c){return this['persistence']['_set'](this['fullUserKey'],_0x20de3c['toJSON']());}async['getCurrentUser'](){const _0x3dbf99=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3dbf99)return null;if(typeof _0x3dbf99=='string'){const _0x2a4be8=await Sn(this['auth'],{'idToken':_0x3dbf99})['catch'](()=>{});return _0x2a4be8?z['_fromGetAccountInfoResponse'](this['auth'],_0x2a4be8,_0x3dbf99):null;}return z['_fromJSON'](this['auth'],_0x3dbf99);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x163b0b){if(this['persistence']===_0x163b0b)return;const _0x255870=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x163b0b,_0x255870)return this['setCurrentUser'](_0x255870);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4a46b2,_0x518753,_0x465a20='authUser'){if(!_0x518753['length'])return new Xe(ne(wr),_0x4a46b2,_0x465a20);const _0x371d6d=(await Promise['all'](_0x518753['map'](async _0x3071eb=>{if(await _0x3071eb['_isAvailable']())return _0x3071eb;})))['filter'](_0x293865=>_0x293865);let _0x1b50cc=_0x371d6d[0x0]||ne(wr);const _0x29d5d8=sn(_0x465a20,_0x4a46b2['config']['apiKey'],_0x4a46b2['name']);let _0x2d8c0d=null;for(const _0x43b8d4 of _0x518753)try{const _0x5716c4=await _0x43b8d4['_get'](_0x29d5d8);if(_0x5716c4){let _0x44456f;if(typeof _0x5716c4=='string'){const _0x373275=await Sn(_0x4a46b2,{'idToken':_0x5716c4})['catch'](()=>{});if(!_0x373275)break;_0x44456f=await z['_fromGetAccountInfoResponse'](_0x4a46b2,_0x373275,_0x5716c4);}else _0x44456f=z['_fromJSON'](_0x4a46b2,_0x5716c4);_0x43b8d4!==_0x1b50cc&&(_0x2d8c0d=_0x44456f),_0x1b50cc=_0x43b8d4;break;}}catch{}const _0x3459c7=_0x371d6d['filter'](_0x55e096=>_0x55e096['_shouldAllowMigration']);return!_0x1b50cc['_shouldAllowMigration']||!_0x3459c7['length']?new Xe(_0x1b50cc,_0x4a46b2,_0x465a20):(_0x1b50cc=_0x3459c7[0x0],_0x2d8c0d&&await _0x1b50cc['_set'](_0x29d5d8,_0x2d8c0d['toJSON']()),await Promise['all'](_0x518753['map'](async _0xc3a383=>{if(_0xc3a383!==_0x1b50cc)try{await _0xc3a383['_remove'](_0x29d5d8);}catch{}})),new Xe(_0x1b50cc,_0x4a46b2,_0x465a20));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x336e3b){const _0x13e261=_0x336e3b['toLowerCase']();if(_0x13e261['includes']('opera/')||_0x13e261['includes']('opr/')||_0x13e261['includes']('opios/'))return'Opera';if(Ra(_0x13e261))return'IEMobile';if(_0x13e261['includes']('msie')||_0x13e261['includes']('trident/'))return'IE';if(_0x13e261['includes']('edge/'))return'Edge';if(Ta(_0x13e261))return'Firefox';if(_0x13e261['includes']('silk/'))return'Silk';if(ka(_0x13e261))return'Blackberry';if(Na(_0x13e261))return'Webos';if(Sa(_0x13e261))return'Safari';if((_0x13e261['includes']('chrome/')||ba(_0x13e261))&&!_0x13e261['includes']('edge/'))return'Chrome';if(Aa(_0x13e261))return'Android';{const _0x43be20=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x29f3f9=_0x336e3b['match'](_0x43be20);if((_0x29f3f9==null?void 0x0:_0x29f3f9['length'])===0x2)return _0x29f3f9[0x1];}return'Other';}function Ta(_0x4165c2=W()){return/firefox\//i['test'](_0x4165c2);}function Sa(_0x4ddaf0=W()){const _0x2ff976=_0x4ddaf0['toLowerCase']();return _0x2ff976['includes']('safari/')&&!_0x2ff976['includes']('chrome/')&&!_0x2ff976['includes']('crios/')&&!_0x2ff976['includes']('android');}function ba(_0x4f5a34=W()){return/crios\//i['test'](_0x4f5a34);}function Ra(_0x2944e2=W()){return/iemobile/i['test'](_0x2944e2);}function Aa(_0x33ed14=W()){return/android/i['test'](_0x33ed14);}function ka(_0x33926f=W()){return/blackberry/i['test'](_0x33926f);}function Na(_0x134e1c=W()){return/webos/i['test'](_0x134e1c);}function Cs(_0x38ab8e=W()){return/iphone|ipad|ipod/i['test'](_0x38ab8e)||/macintosh/i['test'](_0x38ab8e)&&/mobile/i['test'](_0x38ab8e);}function Ef(_0x57dda9=W()){var _0x46bc8d;return Cs(_0x57dda9)&&!!((_0x46bc8d=window['navigator'])!=null&&_0x46bc8d['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2fd2a3=W()){return Cs(_0x2fd2a3)||Aa(_0x2fd2a3)||Na(_0x2fd2a3)||ka(_0x2fd2a3)||/windows phone/i['test'](_0x2fd2a3)||Ra(_0x2fd2a3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x40e9ac,_0x22c776=[]){let _0x277c20;switch(_0x40e9ac){case'Browser':_0x277c20=Cr(W());break;case'Worker':_0x277c20=Cr(W())+'-'+_0x40e9ac;break;default:_0x277c20=_0x40e9ac;}const _0x59585a=_0x22c776['length']?_0x22c776['join'](','):'FirebaseCore-web';return _0x277c20+'/JsCore/'+ct+'/'+_0x59585a;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x243010){this['auth']=_0x243010,this['queue']=[];}['pushCallback'](_0x29cc7d,_0x4e42ed){const _0x1769b3=_0x1e9352=>new Promise((_0x29aa0c,_0x6be1e1)=>{try{const _0x3e118d=_0x29cc7d(_0x1e9352);_0x29aa0c(_0x3e118d);}catch(_0x527109){_0x6be1e1(_0x527109);}});_0x1769b3['onAbort']=_0x4e42ed,this['queue']['push'](_0x1769b3);const _0x28ddb2=this['queue']['length']-0x1;return()=>{this['queue'][_0x28ddb2]=()=>Promise['resolve']();};}async['runMiddleware'](_0x8b94ea){if(this['auth']['currentUser']===_0x8b94ea)return;const _0x5a15e1=[];try{for(const _0x5815a1 of this['queue'])await _0x5815a1(_0x8b94ea),_0x5815a1['onAbort']&&_0x5a15e1['push'](_0x5815a1['onAbort']);}catch(_0x4b2d80){_0x5a15e1['reverse']();for(const _0x243b0e of _0x5a15e1)try{_0x243b0e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4b2d80==null?void 0x0:_0x4b2d80['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x3a64fc,_0x495eaa={}){return Ae(_0x3a64fc,'GET','/v2/passwordPolicy',Re(_0x3a64fc,_0x495eaa));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x2e5f69){var _0x9fc712;const _0x4a7ca0=_0x2e5f69['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4a7ca0['minPasswordLength']??Tf,_0x4a7ca0['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4a7ca0['maxPasswordLength']),_0x4a7ca0['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4a7ca0['containsLowercaseCharacter']),_0x4a7ca0['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4a7ca0['containsUppercaseCharacter']),_0x4a7ca0['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4a7ca0['containsNumericCharacter']),_0x4a7ca0['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4a7ca0['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2e5f69['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x9fc712=_0x2e5f69['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x9fc712['join'](''))??'',this['forceUpgradeOnSignin']=_0x2e5f69['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2e5f69['schemaVersion'];}['validatePassword'](_0x490e54){const _0x59f505={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x490e54,_0x59f505),this['validatePasswordCharacterOptions'](_0x490e54,_0x59f505),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['meetsMinPasswordLength']??!0x0),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['meetsMaxPasswordLength']??!0x0),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['containsLowercaseLetter']??!0x0),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['containsUppercaseLetter']??!0x0),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['containsNumericCharacter']??!0x0),_0x59f505['isValid']&&(_0x59f505['isValid']=_0x59f505['containsNonAlphanumericCharacter']??!0x0),_0x59f505;}['validatePasswordLengthOptions'](_0x1e9f13,_0x5a50d0){const _0x24fd61=this['customStrengthOptions']['minPasswordLength'],_0x37d392=this['customStrengthOptions']['maxPasswordLength'];_0x24fd61&&(_0x5a50d0['meetsMinPasswordLength']=_0x1e9f13['length']>=_0x24fd61),_0x37d392&&(_0x5a50d0['meetsMaxPasswordLength']=_0x1e9f13['length']<=_0x37d392);}['validatePasswordCharacterOptions'](_0x45bb5,_0x578362){this['updatePasswordCharacterOptionsStatuses'](_0x578362,!0x1,!0x1,!0x1,!0x1);let _0x50805b;for(let _0x9cc69d=0x0;_0x9cc69d<_0x45bb5['length'];_0x9cc69d++)_0x50805b=_0x45bb5['charAt'](_0x9cc69d),this['updatePasswordCharacterOptionsStatuses'](_0x578362,_0x50805b>='a'&&_0x50805b<='z',_0x50805b>='A'&&_0x50805b<='Z',_0x50805b>='0'&&_0x50805b<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x50805b));}['updatePasswordCharacterOptionsStatuses'](_0x4c3248,_0x4ff352,_0x407d62,_0x51aaf6,_0x3378f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4c3248['containsLowercaseLetter']||(_0x4c3248['containsLowercaseLetter']=_0x4ff352)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4c3248['containsUppercaseLetter']||(_0x4c3248['containsUppercaseLetter']=_0x407d62)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4c3248['containsNumericCharacter']||(_0x4c3248['containsNumericCharacter']=_0x51aaf6)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4c3248['containsNonAlphanumericCharacter']||(_0x4c3248['containsNonAlphanumericCharacter']=_0x3378f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x34522f,_0x15e96b,_0x477c7b,_0x307c83){this['app']=_0x34522f,this['heartbeatServiceProvider']=_0x15e96b,this['appCheckServiceProvider']=_0x477c7b,this['config']=_0x307c83,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x34522f['name'],this['clientVersion']=_0x307c83['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x449a99=>this['_resolvePersistenceManagerAvailable']=_0x449a99);}['_initializeWithPersistence'](_0x1d2dfe,_0x5c8ff0){return _0x5c8ff0&&(this['_popupRedirectResolver']=ne(_0x5c8ff0)),this['_initializationPromise']=this['queue'](async()=>{var _0x38b0a9,_0x46c213,_0x1654d6;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x1d2dfe),(_0x38b0a9=this['_resolvePersistenceManagerAvailable'])==null||_0x38b0a9['call'](this),!this['_deleted'])){if((_0x46c213=this['_popupRedirectResolver'])!=null&&_0x46c213['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5c8ff0),this['lastNotifiedUid']=((_0x1654d6=this['currentUser'])==null?void 0x0:_0x1654d6['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2a3b22=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2a3b22)){if(this['currentUser']&&_0x2a3b22&&this['currentUser']['uid']===_0x2a3b22['uid']){this['_currentUser']['_assign'](_0x2a3b22),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2a3b22,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x18bd33){try{const _0x10a512=await Sn(this,{'idToken':_0x18bd33}),_0x342b92=await z['_fromGetAccountInfoResponse'](this,_0x10a512,_0x18bd33);await this['directlySetCurrentUser'](_0x342b92);}catch(_0x38d5e5){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x38d5e5),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3c9993){var _0xa8305e;if(H(this['app'])){const _0x509142=this['app']['settings']['authIdToken'];return _0x509142?new Promise(_0x4fe9c6=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x509142)['then'](_0x4fe9c6,_0x4fe9c6));}):this['directlySetCurrentUser'](null);}const _0x10a2f7=await this['assertedPersistence']['getCurrentUser']();let _0x4676d7=_0x10a2f7,_0x23760b=!0x1;if(_0x3c9993&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1bd985=(_0xa8305e=this['redirectUser'])==null?void 0x0:_0xa8305e['_redirectEventId'],_0x2ed699=_0x4676d7==null?void 0x0:_0x4676d7['_redirectEventId'],_0x388ec3=await this['tryRedirectSignIn'](_0x3c9993);(!_0x1bd985||_0x1bd985===_0x2ed699)&&(_0x388ec3!=null&&_0x388ec3['user'])&&(_0x4676d7=_0x388ec3['user'],_0x23760b=!0x0);}if(!_0x4676d7)return this['directlySetCurrentUser'](null);if(!_0x4676d7['_redirectEventId']){if(_0x23760b)try{await this['beforeStateQueue']['runMiddleware'](_0x4676d7);}catch(_0x2fd5e0){_0x4676d7=_0x10a2f7,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2fd5e0));}return _0x4676d7?this['reloadAndSetCurrentUserOrClear'](_0x4676d7):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4676d7['_redirectEventId']?this['directlySetCurrentUser'](_0x4676d7):this['reloadAndSetCurrentUserOrClear'](_0x4676d7);}async['tryRedirectSignIn'](_0x5baaad){let _0x2a263d=null;try{_0x2a263d=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5baaad,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2a263d;}async['reloadAndSetCurrentUserOrClear'](_0x190e5c){try{await bn(_0x190e5c);}catch(_0x322c4a){if((_0x322c4a==null?void 0x0:_0x322c4a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x190e5c);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5a9156){if(H(this['app']))return Promise['reject'](se(this));const _0x253c5c=_0x5a9156?k(_0x5a9156):null;return _0x253c5c&&m(_0x253c5c['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x253c5c&&_0x253c5c['_clone'](this));}async['_updateCurrentUser'](_0x478301,_0x58aad7=!0x1){if(!this['_deleted'])return _0x478301&&m(this['tenantId']===_0x478301['tenantId'],this,'tenant-id-mismatch'),_0x58aad7||await this['beforeStateQueue']['runMiddleware'](_0x478301),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x478301),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xe32a80){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xe32a80));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x235900){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x54c96e=this['_getPasswordPolicyInternal']();return _0x54c96e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x54c96e['validatePassword'](_0x235900);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3b0d98=await Cf(this),_0x5cffd5=new Sf(_0x3b0d98);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5cffd5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5cffd5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x39411c){this['_errorFactory']=new Ut('auth','Firebase',_0x39411c());}['onAuthStateChanged'](_0x4afdf0,_0x127cfe,_0x47eda8){return this['registerStateListener'](this['authStateSubscription'],_0x4afdf0,_0x127cfe,_0x47eda8);}['beforeAuthStateChanged'](_0x4180cb,_0x2d9cf7){return this['beforeStateQueue']['pushCallback'](_0x4180cb,_0x2d9cf7);}['onIdTokenChanged'](_0x23d3a3,_0x38bf5e,_0x4de057){return this['registerStateListener'](this['idTokenSubscription'],_0x23d3a3,_0x38bf5e,_0x4de057);}['authStateReady'](){return new Promise((_0x1ec853,_0x4270ae)=>{if(this['currentUser'])_0x1ec853();else{const _0x4b8187=this['onAuthStateChanged'](()=>{_0x4b8187(),_0x1ec853();},_0x4270ae);}});}async['revokeAccessToken'](_0x326f43){if(this['currentUser']){const _0x25c182=await this['currentUser']['getIdToken'](),_0x1f27bb={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x326f43,'idToken':_0x25c182};this['tenantId']!=null&&(_0x1f27bb['tenantId']=this['tenantId']),await vf(this,_0x1f27bb);}}['toJSON'](){var _0x537b49;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x537b49=this['_currentUser'])==null?void 0x0:_0x537b49['toJSON']()};}async['_setRedirectUser'](_0x135459,_0x4f53a3){const _0x5271b3=await this['getOrInitRedirectPersistenceManager'](_0x4f53a3);return _0x135459===null?_0x5271b3['removeCurrentUser']():_0x5271b3['setCurrentUser'](_0x135459);}async['getOrInitRedirectPersistenceManager'](_0x1eee89){if(!this['redirectPersistenceManager']){const _0x5ac794=_0x1eee89&&ne(_0x1eee89)||this['_popupRedirectResolver'];m(_0x5ac794,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x5ac794['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3daa2a){var _0x568e9f,_0x52e4cb;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x568e9f=this['_currentUser'])==null?void 0x0:_0x568e9f['_redirectEventId'])===_0x3daa2a?this['_currentUser']:((_0x52e4cb=this['redirectUser'])==null?void 0x0:_0x52e4cb['_redirectEventId'])===_0x3daa2a?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3c2ecc){if(_0x3c2ecc===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3c2ecc));}['_notifyListenersIfCurrent'](_0x4c01ac){_0x4c01ac===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x16aa13;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xc27a85=((_0x16aa13=this['currentUser'])==null?void 0x0:_0x16aa13['uid'])??null;this['lastNotifiedUid']!==_0xc27a85&&(this['lastNotifiedUid']=_0xc27a85,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1c6150,_0x2b2aff,_0x514702,_0x3cc258){if(this['_deleted'])return()=>{};const _0x3f2e2f=typeof _0x2b2aff=='function'?_0x2b2aff:_0x2b2aff['next']['bind'](_0x2b2aff);let _0x360f46=!0x1;const _0x3d3903=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3d3903,this,'internal-error'),_0x3d3903['then'](()=>{_0x360f46||_0x3f2e2f(this['currentUser']);}),typeof _0x2b2aff=='function'){const _0xc2832c=_0x1c6150['addObserver'](_0x2b2aff,_0x514702,_0x3cc258);return()=>{_0x360f46=!0x0,_0xc2832c();};}else{const _0x54f10e=_0x1c6150['addObserver'](_0x2b2aff);return()=>{_0x360f46=!0x0,_0x54f10e();};}}async['directlySetCurrentUser'](_0x26f4bf){this['currentUser']&&this['currentUser']!==_0x26f4bf&&this['_currentUser']['_stopProactiveRefresh'](),_0x26f4bf&&this['isProactiveRefreshEnabled']&&_0x26f4bf['_startProactiveRefresh'](),this['currentUser']=_0x26f4bf,_0x26f4bf?await this['assertedPersistence']['setCurrentUser'](_0x26f4bf):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x168fe3){return this['operations']=this['operations']['then'](_0x168fe3,_0x168fe3),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2cbaf9){!_0x2cbaf9||this['frameworks']['includes'](_0x2cbaf9)||(this['frameworks']['push'](_0x2cbaf9),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x247b85;const _0x17ca8d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x17ca8d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x14c5c4=await((_0x247b85=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x247b85['getHeartbeatsHeader']());_0x14c5c4&&(_0x17ca8d['X-Firebase-Client']=_0x14c5c4);const _0x19bc54=await this['_getAppCheckToken']();return _0x19bc54&&(_0x17ca8d['X-Firebase-AppCheck']=_0x19bc54),_0x17ca8d;}async['_getAppCheckToken'](){var _0x40ffaa;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x29459b=await((_0x40ffaa=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x40ffaa['getToken']());return _0x29459b!=null&&_0x29459b['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x29459b['error']),_0x29459b==null?void 0x0:_0x29459b['token'];}}function qe(_0xbf001d){return k(_0xbf001d);}class Tr{constructor(_0xe7bdee){this['auth']=_0xe7bdee,this['observer']=null,this['addObserver']=Ic(_0x477b37=>this['observer']=_0x477b37);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x403837){zn=_0x403837;}function Da(_0x3ef8e7){return zn['loadJS'](_0x3ef8e7);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0xb0d66f){return'__'+_0xb0d66f+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x264484){_0x264484();}['execute'](_0x39bc0f,_0x4938b4){return Promise['resolve']('token');}['render'](_0x2a588d,_0x47c328){return'';}}class Of{['ready'](_0x26c8e1){_0x26c8e1();}['execute'](_0x13adf3,_0x40389a){return Promise['resolve']('token');}['render'](_0x338ec1,_0xd3a7ba){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4146ea){this['type']=Df,this['auth']=qe(_0x4146ea);}async['verify'](_0x5587eb='verify',_0xb1fc39=!0x1){async function _0x430b85(_0x3d9fd7){if(!_0xb1fc39){if(_0x3d9fd7['tenantId']==null&&_0x3d9fd7['_agentRecaptchaConfig']!=null)return _0x3d9fd7['_agentRecaptchaConfig']['siteKey'];if(_0x3d9fd7['tenantId']!=null&&_0x3d9fd7['_tenantRecaptchaConfigs'][_0x3d9fd7['tenantId']]!==void 0x0)return _0x3d9fd7['_tenantRecaptchaConfigs'][_0x3d9fd7['tenantId']]['siteKey'];}return new Promise(async(_0x111946,_0x24742c)=>{uf(_0x3d9fd7,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2164a6=>{if(_0x2164a6['recaptchaKey']===void 0x0)_0x24742c(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x873415=new hf(_0x2164a6);return _0x3d9fd7['tenantId']==null?_0x3d9fd7['_agentRecaptchaConfig']=_0x873415:_0x3d9fd7['_tenantRecaptchaConfigs'][_0x3d9fd7['tenantId']]=_0x873415,_0x111946(_0x873415['siteKey']);}})['catch'](_0x2bc2ff=>{_0x24742c(_0x2bc2ff);});});}function _0x71f5c8(_0x18a43b,_0x4e959f,_0x3816bf){const _0x4c6211=window['grecaptcha'];vr(_0x4c6211)?_0x4c6211['enterprise']['ready'](()=>{_0x4c6211['enterprise']['execute'](_0x18a43b,{'action':_0x5587eb})['then'](_0x4e3d45=>{_0x4e959f(_0x4e3d45);})['catch'](()=>{_0x4e959f(Ma);});}):_0x3816bf(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x39319b,_0x5924c4)=>{_0x430b85(this['auth'])['then'](async _0x42c146=>{if(!_0xb1fc39&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x71f5c8(_0x42c146,_0x39319b,_0x5924c4);else{if(typeof window>'u'){_0x5924c4(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x6be6b8=Af();_0x6be6b8['length']!==0x0&&(_0x6be6b8+=_0x42c146+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x40adfc;(_0x40adfc=le['scriptInjectionDeferred'])==null||_0x40adfc['resolve']();},Da(_0x6be6b8)['then'](()=>{var _0xa2de75;return(_0xa2de75=le['scriptInjectionDeferred'])==null?void 0x0:_0xa2de75['promise'];})['then'](()=>{_0x71f5c8(_0x42c146,_0x39319b,_0x5924c4);})['catch'](_0x28e72e=>{_0x5924c4(_0x28e72e);});}})['catch'](_0x58b12d=>{_0x5924c4(_0x58b12d);});});}}le['scriptInjectionDeferred']=null;async function br(_0x2b5cd6,_0x47a741,_0x1681cb,_0x42139d=!0x1,_0xeea3f6=!0x1){const _0x7abf8d=new le(_0x2b5cd6);let _0x314e;if(_0xeea3f6)_0x314e=Ma;else try{_0x314e=await _0x7abf8d['verify'](_0x1681cb);}catch{_0x314e=await _0x7abf8d['verify'](_0x1681cb,!0x0);}const _0x11097f={..._0x47a741};if(_0x1681cb==='mfaSmsEnrollment'||_0x1681cb==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x11097f){const _0x11442b=_0x11097f['phoneEnrollmentInfo']['phoneNumber'],_0x290505=_0x11097f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x11097f,{'phoneEnrollmentInfo':{'phoneNumber':_0x11442b,'recaptchaToken':_0x290505,'captchaResponse':_0x314e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x11097f){const _0x4badfa=_0x11097f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x11097f,{'phoneSignInInfo':{'recaptchaToken':_0x4badfa,'captchaResponse':_0x314e,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x11097f;}return _0x42139d?Object['assign'](_0x11097f,{'captchaResp':_0x314e}):Object['assign'](_0x11097f,{'captchaResponse':_0x314e}),Object['assign'](_0x11097f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x11097f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x11097f;}async function Oi(_0x29ae52,_0x40c10,_0x10c218,_0xdb3236,_0x3dfa75){var _0x437d57;if((_0x437d57=_0x29ae52['_getRecaptchaConfig']())!=null&&_0x437d57['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5aecb2=await br(_0x29ae52,_0x40c10,_0x10c218,_0x10c218==='getOobCode');return _0xdb3236(_0x29ae52,_0x5aecb2);}else return _0xdb3236(_0x29ae52,_0x40c10)['catch'](async _0x41a739=>{if(_0x41a739['code']==='auth/missing-recaptcha-token'){console['log'](_0x10c218+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x508300=await br(_0x29ae52,_0x40c10,_0x10c218,_0x10c218==='getOobCode');return _0xdb3236(_0x29ae52,_0x508300);}else return Promise['reject'](_0x41a739);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x33fbd1,_0x2fdcd3){const _0x2b26a3=Ui(_0x33fbd1,'auth');if(_0x2b26a3['isInitialized']()){const _0x342dee=_0x2b26a3['getImmediate'](),_0x33d980=_0x2b26a3['getOptions']();if(De(_0x33d980,_0x2fdcd3??{}))return _0x342dee;K(_0x342dee,'already-initialized');}return _0x2b26a3['initialize']({'options':_0x2fdcd3});}function Lf(_0x4c1362,_0x13e72e){const _0x4c3a37=(_0x13e72e==null?void 0x0:_0x13e72e['persistence'])||[],_0x3c52a9=(Array['isArray'](_0x4c3a37)?_0x4c3a37:[_0x4c3a37])['map'](ne);_0x13e72e!=null&&_0x13e72e['errorMap']&&_0x4c1362['_updateErrorMap'](_0x13e72e['errorMap']),_0x4c1362['_initializeWithPersistence'](_0x3c52a9,_0x13e72e==null?void 0x0:_0x13e72e['popupRedirectResolver']);}function xf(_0xaeb39e,_0x3137a8,_0x1f1d91){const _0x24a8d6=qe(_0xaeb39e);m(/^https?:\/\//['test'](_0x3137a8),_0x24a8d6,'invalid-emulator-scheme');const _0x31f7b4=!0x1,_0x305c3f=La(_0x3137a8),{host:_0x5beb24,port:_0x8ede0b}=Ff(_0x3137a8),_0x8d3287=_0x8ede0b===null?'':':'+_0x8ede0b,_0xac17dc={'url':_0x305c3f+'//'+_0x5beb24+_0x8d3287+'/'},_0x5c0066=Object['freeze']({'host':_0x5beb24,'port':_0x8ede0b,'protocol':_0x305c3f['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x31f7b4})});if(!_0x24a8d6['_canInitEmulator']){m(_0x24a8d6['config']['emulator']&&_0x24a8d6['emulatorConfig'],_0x24a8d6,'emulator-config-failed'),m(De(_0xac17dc,_0x24a8d6['config']['emulator'])&&De(_0x5c0066,_0x24a8d6['emulatorConfig']),_0x24a8d6,'emulator-config-failed');return;}_0x24a8d6['config']['emulator']=_0xac17dc,_0x24a8d6['emulatorConfig']=_0x5c0066,_0x24a8d6['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x5beb24)?jr(_0x305c3f+'//'+_0x5beb24+_0x8d3287):Uf();}function La(_0x1e9595){const _0x56f8b2=_0x1e9595['indexOf'](':');return _0x56f8b2<0x0?'':_0x1e9595['substr'](0x0,_0x56f8b2+0x1);}function Ff(_0x11f19c){const _0x47e23f=La(_0x11f19c),_0x4bba82=/(\/\/)?([^?#/]+)/['exec'](_0x11f19c['substr'](_0x47e23f['length']));if(!_0x4bba82)return{'host':'','port':null};const _0x298b66=_0x4bba82[0x2]['split']('@')['pop']()||'',_0x4d4572=/^(\[[^\]]+\])(:|$)/['exec'](_0x298b66);if(_0x4d4572){const _0x11bf04=_0x4d4572[0x1];return{'host':_0x11bf04,'port':Rr(_0x298b66['substr'](_0x11bf04['length']+0x1))};}else{const [_0x417b47,_0x52a306]=_0x298b66['split'](':');return{'host':_0x417b47,'port':Rr(_0x52a306)};}}function Rr(_0x2cb5ae){if(!_0x2cb5ae)return null;const _0x544332=Number(_0x2cb5ae);return isNaN(_0x544332)?null:_0x544332;}function Uf(){function _0x6c727d(){const _0x48f5f3=document['createElement']('p'),_0x48628e=_0x48f5f3['style'];_0x48f5f3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x48628e['position']='fixed',_0x48628e['width']='100%',_0x48628e['backgroundColor']='#ffffff',_0x48628e['border']='.1em\x20solid\x20#000000',_0x48628e['color']='#b50000',_0x48628e['bottom']='0px',_0x48628e['left']='0px',_0x48628e['margin']='0px',_0x48628e['zIndex']='10000',_0x48628e['textAlign']='center',_0x48f5f3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x48f5f3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x6c727d):_0x6c727d());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x35eee3,_0x2b7a6c){this['providerId']=_0x35eee3,this['signInMethod']=_0x2b7a6c;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x249a8b){return te('not\x20implemented');}['_linkToIdToken'](_0x21caf0,_0x3f66f5){return te('not\x20implemented');}['_getReauthenticationResolver'](_0xa6836b){return te('not\x20implemented');}}async function Wf(_0x263d26,_0x25486f){return Ae(_0x263d26,'POST','/v1/accounts:signUp',_0x25486f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x260e99,_0x44b34c){return Yt(_0x260e99,'POST','/v1/accounts:signInWithPassword',Re(_0x260e99,_0x44b34c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x3a6088,_0x25372c){return Yt(_0x3a6088,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3a6088,_0x25372c));}async function Hf(_0x40940f,_0x1393e0){return Yt(_0x40940f,'POST','/v1/accounts:signInWithEmailLink',Re(_0x40940f,_0x1393e0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x51bbdc,_0xf559bb,_0x9ef67,_0x3aa430=null){super('password',_0x9ef67),this['_email']=_0x51bbdc,this['_password']=_0xf559bb,this['_tenantId']=_0x3aa430;}static['_fromEmailAndPassword'](_0x524983,_0x275f9c){return new Ft(_0x524983,_0x275f9c,'password');}static['_fromEmailAndCode'](_0x1b8cf5,_0x42bd46,_0x5800b1=null){return new Ft(_0x1b8cf5,_0x42bd46,'emailLink',_0x5800b1);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1b5711){const _0x53f19a=typeof _0x1b5711=='string'?JSON['parse'](_0x1b5711):_0x1b5711;if(_0x53f19a!=null&&_0x53f19a['email']&&(_0x53f19a!=null&&_0x53f19a['password'])){if(_0x53f19a['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x53f19a['email'],_0x53f19a['password']);if(_0x53f19a['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x53f19a['email'],_0x53f19a['password'],_0x53f19a['tenantId']);}return null;}async['_getIdTokenResponse'](_0x31e3f2){switch(this['signInMethod']){case'password':const _0x4c8789={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x31e3f2,_0x4c8789,'signInWithPassword',Bf);case'emailLink':return Vf(_0x31e3f2,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x31e3f2,'internal-error');}}async['_linkToIdToken'](_0x3b34f0,_0x2f82aa){switch(this['signInMethod']){case'password':const _0x185acf={'idToken':_0x2f82aa,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x3b34f0,_0x185acf,'signUpPassword',Wf);case'emailLink':return Hf(_0x3b34f0,{'idToken':_0x2f82aa,'email':this['_email'],'oobCode':this['_password']});default:K(_0x3b34f0,'internal-error');}}['_getReauthenticationResolver'](_0x15348b){return this['_getIdTokenResponse'](_0x15348b);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4dc1f4,_0x676b8e){return Yt(_0x4dc1f4,'POST','/v1/accounts:signInWithIdp',Re(_0x4dc1f4,_0x676b8e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x24e1b9){const _0x4a900c=new We(_0x24e1b9['providerId'],_0x24e1b9['signInMethod']);return _0x24e1b9['idToken']||_0x24e1b9['accessToken']?(_0x24e1b9['idToken']&&(_0x4a900c['idToken']=_0x24e1b9['idToken']),_0x24e1b9['accessToken']&&(_0x4a900c['accessToken']=_0x24e1b9['accessToken']),_0x24e1b9['nonce']&&!_0x24e1b9['pendingToken']&&(_0x4a900c['nonce']=_0x24e1b9['nonce']),_0x24e1b9['pendingToken']&&(_0x4a900c['pendingToken']=_0x24e1b9['pendingToken'])):_0x24e1b9['oauthToken']&&_0x24e1b9['oauthTokenSecret']?(_0x4a900c['accessToken']=_0x24e1b9['oauthToken'],_0x4a900c['secret']=_0x24e1b9['oauthTokenSecret']):K('argument-error'),_0x4a900c;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x25a3c7){const _0x413685=typeof _0x25a3c7=='string'?JSON['parse'](_0x25a3c7):_0x25a3c7,{providerId:_0x1f7547,signInMethod:_0x1008bf,..._0x190581}=_0x413685;if(!_0x1f7547||!_0x1008bf)return null;const _0x423f55=new We(_0x1f7547,_0x1008bf);return _0x423f55['idToken']=_0x190581['idToken']||void 0x0,_0x423f55['accessToken']=_0x190581['accessToken']||void 0x0,_0x423f55['secret']=_0x190581['secret'],_0x423f55['nonce']=_0x190581['nonce'],_0x423f55['pendingToken']=_0x190581['pendingToken']||null,_0x423f55;}['_getIdTokenResponse'](_0x21badd){const _0x2ede03=this['buildRequest']();return Ze(_0x21badd,_0x2ede03);}['_linkToIdToken'](_0x155aff,_0x3dbd22){const _0x298ee9=this['buildRequest']();return _0x298ee9['idToken']=_0x3dbd22,Ze(_0x155aff,_0x298ee9);}['_getReauthenticationResolver'](_0x18b1ec){const _0x125e14=this['buildRequest']();return _0x125e14['autoCreate']=!0x1,Ze(_0x18b1ec,_0x125e14);}['buildRequest'](){const _0x4f3ef5={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4f3ef5['pendingToken']=this['pendingToken'];else{const _0x372c8e={};this['idToken']&&(_0x372c8e['id_token']=this['idToken']),this['accessToken']&&(_0x372c8e['access_token']=this['accessToken']),this['secret']&&(_0x372c8e['oauth_token_secret']=this['secret']),_0x372c8e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x372c8e['nonce']=this['nonce']),_0x4f3ef5['postBody']=at(_0x372c8e);}return _0x4f3ef5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x112622){switch(_0x112622){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x24ac6e){const _0x510bdf=yt(vt(_0x24ac6e))['link'],_0x39e881=_0x510bdf?yt(vt(_0x510bdf))['deep_link_id']:null,_0x271044=yt(vt(_0x24ac6e))['deep_link_id'];return(_0x271044?yt(vt(_0x271044))['link']:null)||_0x271044||_0x39e881||_0x510bdf||_0x24ac6e;}class Ss{constructor(_0x4b06b5){const _0x5daecf=yt(vt(_0x4b06b5)),_0x1bfaa1=_0x5daecf['apiKey']??null,_0x50dbc1=_0x5daecf['oobCode']??null,_0x2ca7e7=Gf(_0x5daecf['mode']??null);m(_0x1bfaa1&&_0x50dbc1&&_0x2ca7e7,'argument-error'),this['apiKey']=_0x1bfaa1,this['operation']=_0x2ca7e7,this['code']=_0x50dbc1,this['continueUrl']=_0x5daecf['continueUrl']??null,this['languageCode']=_0x5daecf['lang']??null,this['tenantId']=_0x5daecf['tenantId']??null;}static['parseLink'](_0x2ddf8f){const _0xa77278=qf(_0x2ddf8f);try{return new Ss(_0xa77278);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x37f18b,_0xc211b1){return Ft['_fromEmailAndPassword'](_0x37f18b,_0xc211b1);}static['credentialWithLink'](_0xd23d6a,_0xfc089d){const _0x212f67=Ss['parseLink'](_0xfc089d);return m(_0x212f67,'argument-error'),Ft['_fromEmailAndCode'](_0xd23d6a,_0x212f67['code'],_0x212f67['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x80c3c3){this['providerId']=_0x80c3c3,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3f0b0e){this['defaultLanguageCode']=_0x3f0b0e;}['setCustomParameters'](_0x430b37){return this['customParameters']=_0x430b37,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5024a2){return this['scopes']['includes'](_0x5024a2)||this['scopes']['push'](_0x5024a2),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x423cff){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x423cff});}static['credentialFromResult'](_0x5db2e7){return he['credentialFromTaggedObject'](_0x5db2e7);}static['credentialFromError'](_0x138dc5){return he['credentialFromTaggedObject'](_0x138dc5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4ed027}){if(!_0x4ed027||!('oauthAccessToken'in _0x4ed027)||!_0x4ed027['oauthAccessToken'])return null;try{return he['credential'](_0x4ed027['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3f7736,_0x58d8bf){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3f7736,'accessToken':_0x58d8bf});}static['credentialFromResult'](_0x189d9f){return ue['credentialFromTaggedObject'](_0x189d9f);}static['credentialFromError'](_0x229d38){return ue['credentialFromTaggedObject'](_0x229d38['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3ccd2a}){if(!_0x3ccd2a)return null;const {oauthIdToken:_0x4c25b5,oauthAccessToken:_0x374539}=_0x3ccd2a;if(!_0x4c25b5&&!_0x374539)return null;try{return ue['credential'](_0x4c25b5,_0x374539);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x444778){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x444778});}static['credentialFromResult'](_0xb8936c){return de['credentialFromTaggedObject'](_0xb8936c);}static['credentialFromError'](_0x441f56){return de['credentialFromTaggedObject'](_0x441f56['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5a64bc}){if(!_0x5a64bc||!('oauthAccessToken'in _0x5a64bc)||!_0x5a64bc['oauthAccessToken'])return null;try{return de['credential'](_0x5a64bc['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x27cfd9,_0x2412b8){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x27cfd9,'oauthTokenSecret':_0x2412b8});}static['credentialFromResult'](_0x482036){return fe['credentialFromTaggedObject'](_0x482036);}static['credentialFromError'](_0x51a130){return fe['credentialFromTaggedObject'](_0x51a130['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x34b0e7}){if(!_0x34b0e7)return null;const {oauthAccessToken:_0x243016,oauthTokenSecret:_0x5274d1}=_0x34b0e7;if(!_0x243016||!_0x5274d1)return null;try{return fe['credential'](_0x243016,_0x5274d1);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x459762,_0x23bbe6){return Yt(_0x459762,'POST','/v1/accounts:signUp',Re(_0x459762,_0x23bbe6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x2b61db){this['user']=_0x2b61db['user'],this['providerId']=_0x2b61db['providerId'],this['_tokenResponse']=_0x2b61db['_tokenResponse'],this['operationType']=_0x2b61db['operationType'];}static async['_fromIdTokenResponse'](_0x2d94c1,_0x513d57,_0x52cfb4,_0x491d5e=!0x1){const _0x25df4f=await z['_fromIdTokenResponse'](_0x2d94c1,_0x52cfb4,_0x491d5e),_0x7077fb=Ar(_0x52cfb4);return new Be({'user':_0x25df4f,'providerId':_0x7077fb,'_tokenResponse':_0x52cfb4,'operationType':_0x513d57});}static async['_forOperation'](_0x2c9ad1,_0x23eba5,_0x1c0bd8){await _0x2c9ad1['_updateTokensIfNecessary'](_0x1c0bd8,!0x0);const _0x22ffc6=Ar(_0x1c0bd8);return new Be({'user':_0x2c9ad1,'providerId':_0x22ffc6,'_tokenResponse':_0x1c0bd8,'operationType':_0x23eba5});}}function Ar(_0x372dda){return _0x372dda['providerId']?_0x372dda['providerId']:'phoneNumber'in _0x372dda?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x59cb52,_0x5fcee,_0x36433f,_0x1e3a2a){super(_0x5fcee['code'],_0x5fcee['message']),this['operationType']=_0x36433f,this['user']=_0x1e3a2a,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x59cb52['name'],'tenantId':_0x59cb52['tenantId']??void 0x0,'_serverResponse':_0x5fcee['customData']['_serverResponse'],'operationType':_0x36433f};}static['_fromErrorAndOperation'](_0x5021bf,_0xd5acbd,_0x3a8ec9,_0x5096a1){return new Rn(_0x5021bf,_0xd5acbd,_0x3a8ec9,_0x5096a1);}}function Fa(_0x25dc94,_0x5f38d4,_0xb56f61,_0x6d215d){return(_0x5f38d4==='reauthenticate'?_0xb56f61['_getReauthenticationResolver'](_0x25dc94):_0xb56f61['_getIdTokenResponse'](_0x25dc94))['catch'](_0x38281a=>{throw _0x38281a['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x25dc94,_0x38281a,_0x5f38d4,_0x6d215d):_0x38281a;});}async function jf(_0x15b41a,_0xf6e79,_0x1fce6d=!0x1){const _0x3d4e3b=await xt(_0x15b41a,_0xf6e79['_linkToIdToken'](_0x15b41a['auth'],await _0x15b41a['getIdToken']()),_0x1fce6d);return Be['_forOperation'](_0x15b41a,'link',_0x3d4e3b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x56e9f9,_0x19cde5,_0x1eb4dc=!0x1){const {auth:_0x5d8bfb}=_0x56e9f9;if(H(_0x5d8bfb['app']))return Promise['reject'](se(_0x5d8bfb));const _0x3baab9='reauthenticate';try{const _0x5903d1=await xt(_0x56e9f9,Fa(_0x5d8bfb,_0x3baab9,_0x19cde5,_0x56e9f9),_0x1eb4dc);m(_0x5903d1['idToken'],_0x5d8bfb,'internal-error');const _0x27512e=ws(_0x5903d1['idToken']);m(_0x27512e,_0x5d8bfb,'internal-error');const {sub:_0x428fab}=_0x27512e;return m(_0x56e9f9['uid']===_0x428fab,_0x5d8bfb,'user-mismatch'),Be['_forOperation'](_0x56e9f9,_0x3baab9,_0x5903d1);}catch(_0x479e32){throw(_0x479e32==null?void 0x0:_0x479e32['code'])==='auth/user-not-found'&&K(_0x5d8bfb,'user-mismatch'),_0x479e32;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x35e492,_0x56b75a,_0x1574eb=!0x1){if(H(_0x35e492['app']))return Promise['reject'](se(_0x35e492));const _0x395fbb='signIn',_0x46ffad=await Fa(_0x35e492,_0x395fbb,_0x56b75a),_0x21a83f=await Be['_fromIdTokenResponse'](_0x35e492,_0x395fbb,_0x46ffad);return _0x1574eb||await _0x35e492['_updateCurrentUser'](_0x21a83f['user']),_0x21a83f;}async function Yf(_0x1e287b,_0x42394d){return Ua(qe(_0x1e287b),_0x42394d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x4a52ad){const _0x1db205=qe(_0x4a52ad);_0x1db205['_getPasswordPolicyInternal']()&&await _0x1db205['_updatePasswordPolicy']();}async function R_(_0x36217a,_0x43e605,_0x31f217){if(H(_0x36217a['app']))return Promise['reject'](se(_0x36217a));const _0x247bb1=qe(_0x36217a),_0xca7970=await Oi(_0x247bb1,{'returnSecureToken':!0x0,'email':_0x43e605,'password':_0x31f217,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x95e6b1=>{throw _0x95e6b1['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x36217a),_0x95e6b1;}),_0x4b7803=await Be['_fromIdTokenResponse'](_0x247bb1,'signIn',_0xca7970);return await _0x247bb1['_updateCurrentUser'](_0x4b7803['user']),_0x4b7803;}function A_(_0x4121d7,_0xd8bd91,_0x522118){return H(_0x4121d7['app'])?Promise['reject'](se(_0x4121d7)):Yf(k(_0x4121d7),ft['credential'](_0xd8bd91,_0x522118))['catch'](async _0x24f041=>{throw _0x24f041['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4121d7),_0x24f041;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x5c767e,_0x467db3){return k(_0x5c767e)['setPersistence'](_0x467db3);}function Qf(_0x31b3d8,_0x4472bb,_0x26cd6b,_0x3f7793){return k(_0x31b3d8)['onIdTokenChanged'](_0x4472bb,_0x26cd6b,_0x3f7793);}function Jf(_0x5a6a3d,_0x129f98,_0x39ecaa){return k(_0x5a6a3d)['beforeAuthStateChanged'](_0x129f98,_0x39ecaa);}function N_(_0x344c10,_0x45cdae,_0x2b4110,_0x25136b){return k(_0x344c10)['onAuthStateChanged'](_0x45cdae,_0x2b4110,_0x25136b);}function P_(_0x1d28f3){return k(_0x1d28f3)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x1dcd6e,_0x4a17de){this['storageRetriever']=_0x1dcd6e,this['type']=_0x4a17de;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x53ab3d,_0x69a7f9){return this['storage']['setItem'](_0x53ab3d,JSON['stringify'](_0x69a7f9)),Promise['resolve']();}['_get'](_0x655d67){const _0x347010=this['storage']['getItem'](_0x655d67);return Promise['resolve'](_0x347010?JSON['parse'](_0x347010):null);}['_remove'](_0x796961){return this['storage']['removeItem'](_0x796961),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x550951,_0x3606b3)=>this['onStorageEvent'](_0x550951,_0x3606b3),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x393aaf){for(const _0x3b4295 of Object['keys'](this['listeners'])){const _0x25416c=this['storage']['getItem'](_0x3b4295),_0x1505a8=this['localCache'][_0x3b4295];_0x25416c!==_0x1505a8&&_0x393aaf(_0x3b4295,_0x1505a8,_0x25416c);}}['onStorageEvent'](_0x5c60e6,_0x3ae7b4=!0x1){if(!_0x5c60e6['key']){this['forAllChangedKeys']((_0x494d66,_0x2c5f5f,_0xc81f47)=>{this['notifyListeners'](_0x494d66,_0xc81f47);});return;}const _0xe9e0d7=_0x5c60e6['key'];_0x3ae7b4?this['detachListener']():this['stopPolling']();const _0x469a6f=()=>{const _0xe4d4cb=this['storage']['getItem'](_0xe9e0d7);!_0x3ae7b4&&this['localCache'][_0xe9e0d7]===_0xe4d4cb||this['notifyListeners'](_0xe9e0d7,_0xe4d4cb);},_0x5cc998=this['storage']['getItem'](_0xe9e0d7);If()&&_0x5cc998!==_0x5c60e6['newValue']&&_0x5c60e6['newValue']!==_0x5c60e6['oldValue']?setTimeout(_0x469a6f,Zf):_0x469a6f();}['notifyListeners'](_0x1914de,_0x26bad4){this['localCache'][_0x1914de]=_0x26bad4;const _0x4ab60c=this['listeners'][_0x1914de];if(_0x4ab60c){for(const _0x1a4135 of Array['from'](_0x4ab60c))_0x1a4135(_0x26bad4&&JSON['parse'](_0x26bad4));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x37ad3b,_0x2d36c5,_0x290fff)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x37ad3b,'oldValue':_0x2d36c5,'newValue':_0x290fff}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4488bd,_0xcfadcd){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4488bd]||(this['listeners'][_0x4488bd]=new Set(),this['localCache'][_0x4488bd]=this['storage']['getItem'](_0x4488bd)),this['listeners'][_0x4488bd]['add'](_0xcfadcd);}['_removeListener'](_0x386239,_0x14d62c){this['listeners'][_0x386239]&&(this['listeners'][_0x386239]['delete'](_0x14d62c),this['listeners'][_0x386239]['size']===0x0&&delete this['listeners'][_0x386239]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x51bb7a,_0x217797){await super['_set'](_0x51bb7a,_0x217797),this['localCache'][_0x51bb7a]=JSON['stringify'](_0x217797);}async['_get'](_0x721dbb){const _0x348a52=await super['_get'](_0x721dbb);return this['localCache'][_0x721dbb]=JSON['stringify'](_0x348a52),_0x348a52;}async['_remove'](_0x535f10){await super['_remove'](_0x535f10),delete this['localCache'][_0x535f10];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x427dd9,_0x22497c){}['_removeListener'](_0x53aace,_0x26a68e){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x567eb1){return Promise['all'](_0x567eb1['map'](async _0x3536b9=>{try{return{'fulfilled':!0x0,'value':await _0x3536b9};}catch(_0x521b61){return{'fulfilled':!0x1,'reason':_0x521b61};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x2e7c82){this['eventTarget']=_0x2e7c82,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x451587){const _0x33e394=this['receivers']['find'](_0x570a88=>_0x570a88['isListeningto'](_0x451587));if(_0x33e394)return _0x33e394;const _0xbd5871=new jn(_0x451587);return this['receivers']['push'](_0xbd5871),_0xbd5871;}['isListeningto'](_0x5afdea){return this['eventTarget']===_0x5afdea;}async['handleEvent'](_0x47a554){const _0x5ae386=_0x47a554,{eventId:_0x44dfa7,eventType:_0x18694b,data:_0x19a269}=_0x5ae386['data'],_0x6898c8=this['handlersMap'][_0x18694b];if(!(_0x6898c8!=null&&_0x6898c8['size']))return;_0x5ae386['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x44dfa7,'eventType':_0x18694b});const _0x6e4a7b=Array['from'](_0x6898c8)['map'](async _0x1e055a=>_0x1e055a(_0x5ae386['origin'],_0x19a269)),_0x5f0fe8=await tp(_0x6e4a7b);_0x5ae386['ports'][0x0]['postMessage']({'status':'done','eventId':_0x44dfa7,'eventType':_0x18694b,'response':_0x5f0fe8});}['_subscribe'](_0x3b9a54,_0x1eb744){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3b9a54]||(this['handlersMap'][_0x3b9a54]=new Set()),this['handlersMap'][_0x3b9a54]['add'](_0x1eb744);}['_unsubscribe'](_0x2d8d0f,_0xc43e0e){this['handlersMap'][_0x2d8d0f]&&_0xc43e0e&&this['handlersMap'][_0x2d8d0f]['delete'](_0xc43e0e),(!_0xc43e0e||this['handlersMap'][_0x2d8d0f]['size']===0x0)&&delete this['handlersMap'][_0x2d8d0f],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x3f3ff7='',_0x49bcde=0xa){let _0x10a637='';for(let _0x3cce3d=0x0;_0x3cce3d<_0x49bcde;_0x3cce3d++)_0x10a637+=Math['floor'](Math['random']()*0xa);return _0x3f3ff7+_0x10a637;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x16d427){this['target']=_0x16d427,this['handlers']=new Set();}['removeMessageHandler'](_0x5a3506){_0x5a3506['messageChannel']&&(_0x5a3506['messageChannel']['port1']['removeEventListener']('message',_0x5a3506['onMessage']),_0x5a3506['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5a3506);}async['_send'](_0x1d4e11,_0x285640,_0x54664a=0x32){const _0x47564c=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x47564c)throw new Error('connection_unavailable');let _0x56cd32,_0x568d5b;return new Promise((_0x1dd7a7,_0x531e71)=>{const _0x42df9e=bs('',0x14);_0x47564c['port1']['start']();const _0x3777b3=setTimeout(()=>{_0x531e71(new Error('unsupported_event'));},_0x54664a);_0x568d5b={'messageChannel':_0x47564c,'onMessage'(_0x314754){const _0x3aacf3=_0x314754;if(_0x3aacf3['data']['eventId']===_0x42df9e)switch(_0x3aacf3['data']['status']){case'ack':clearTimeout(_0x3777b3),_0x56cd32=setTimeout(()=>{_0x531e71(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x56cd32),_0x1dd7a7(_0x3aacf3['data']['response']);break;default:clearTimeout(_0x3777b3),clearTimeout(_0x56cd32),_0x531e71(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x568d5b),_0x47564c['port1']['addEventListener']('message',_0x568d5b['onMessage']),this['target']['postMessage']({'eventType':_0x1d4e11,'eventId':_0x42df9e,'data':_0x285640},[_0x47564c['port2']]);})['finally'](()=>{_0x568d5b&&this['removeMessageHandler'](_0x568d5b);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x5a33d5){X()['location']['href']=_0x5a33d5;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0xc9d7ad;return((_0xc9d7ad=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xc9d7ad['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x1b6807){this['request']=_0x1b6807;}['toPromise'](){return new Promise((_0x38c331,_0x31b379)=>{this['request']['addEventListener']('success',()=>{_0x38c331(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x31b379(this['request']['error']);});});}}function Kn(_0x2390bb,_0xc089a7){return _0x2390bb['transaction']([kn],_0xc089a7?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x1d1030=indexedDB['deleteDatabase'](qa);return new Jt(_0x1d1030)['toPromise']();}function ja(){const _0x24f097=indexedDB['open'](qa,ap);return new Promise((_0x57934c,_0x1682fd)=>{_0x24f097['addEventListener']('error',()=>{_0x1682fd(_0x24f097['error']);}),_0x24f097['addEventListener']('upgradeneeded',()=>{const _0x5cc62d=_0x24f097['result'];try{_0x5cc62d['createObjectStore'](kn,{'keyPath':za});}catch(_0x1b0cc7){_0x1682fd(_0x1b0cc7);}}),_0x24f097['addEventListener']('success',async()=>{const _0x159618=_0x24f097['result'];_0x159618['objectStoreNames']['contains'](kn)?_0x57934c(_0x159618):(_0x159618['close'](),await cp(),_0x57934c(await ja()));});});}async function kr(_0x32d35d,_0x5135ce,_0x19a622){const _0x4a38a9=Kn(_0x32d35d,!0x0)['put']({[za]:_0x5135ce,'value':_0x19a622});return new Jt(_0x4a38a9)['toPromise']();}async function lp(_0x4a643c,_0x3b8e61){const _0xfeb174=Kn(_0x4a643c,!0x1)['get'](_0x3b8e61),_0x45631d=await new Jt(_0xfeb174)['toPromise']();return _0x45631d===void 0x0?null:_0x45631d['value'];}function Nr(_0x57c22a,_0xed9326){const _0x3f132a=Kn(_0x57c22a,!0x0)['delete'](_0xed9326);return new Jt(_0x3f132a)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2db3bd){let _0x3b7875=0x0;for(;;)try{const _0x4ea1f2=await this['_openDb']();return await _0x2db3bd(_0x4ea1f2);}catch(_0x416c88){if(_0x3b7875++>up)throw _0x416c88;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x550baa,_0x581549)=>({'keyProcessed':(await this['_poll']())['includes'](_0x581549['key'])})),this['receiver']['_subscribe']('ping',async(_0x1ca1f5,_0x560081)=>['keyChanged']);}async['initializeSender'](){var _0x18bda7,_0x8e8174;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x1acb2e=await this['sender']['_send']('ping',{},0x320);_0x1acb2e&&(_0x18bda7=_0x1acb2e[0x0])!=null&&_0x18bda7['fulfilled']&&(_0x8e8174=_0x1acb2e[0x0])!=null&&_0x8e8174['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x839495){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x839495},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4d96e8=>{await kr(_0x4d96e8,An,'1'),await Nr(_0x4d96e8,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3b2d83){this['pendingWrites']++;try{await _0x3b2d83();}finally{this['pendingWrites']--;}}async['_set'](_0x2e8840,_0x1f2acd){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4b4b6d=>kr(_0x4b4b6d,_0x2e8840,_0x1f2acd)),this['localCache'][_0x2e8840]=_0x1f2acd,this['notifyServiceWorker'](_0x2e8840)));}async['_get'](_0x5295f7){const _0x4878e6=await this['_withRetries'](_0x4a4d5d=>lp(_0x4a4d5d,_0x5295f7));return this['localCache'][_0x5295f7]=_0x4878e6,_0x4878e6;}async['_remove'](_0x3ac285){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2fdb20=>Nr(_0x2fdb20,_0x3ac285)),delete this['localCache'][_0x3ac285],this['notifyServiceWorker'](_0x3ac285)));}async['_poll'](){const _0x3c88d9=await this['_withRetries'](_0xcaae0=>{const _0x5ab201=Kn(_0xcaae0,!0x1)['getAll']();return new Jt(_0x5ab201)['toPromise']();});if(!_0x3c88d9)return[];if(this['pendingWrites']!==0x0)return[];const _0x48229a=[],_0x2d60db=new Set();if(_0x3c88d9['length']!==0x0){for(const {fbase_key:_0x57c289,value:_0x3f5ccd}of _0x3c88d9)_0x2d60db['add'](_0x57c289),JSON['stringify'](this['localCache'][_0x57c289])!==JSON['stringify'](_0x3f5ccd)&&(this['notifyListeners'](_0x57c289,_0x3f5ccd),_0x48229a['push'](_0x57c289));}for(const _0x291011 of Object['keys'](this['localCache']))this['localCache'][_0x291011]&&!_0x2d60db['has'](_0x291011)&&(this['notifyListeners'](_0x291011,null),_0x48229a['push'](_0x291011));return _0x48229a;}['notifyListeners'](_0x4de46b,_0x485e83){this['localCache'][_0x4de46b]=_0x485e83;const _0x325d67=this['listeners'][_0x4de46b];if(_0x325d67){for(const _0x3483d6 of Array['from'](_0x325d67))_0x3483d6(_0x485e83);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1f35f5,_0x46cd6b){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1f35f5]||(this['listeners'][_0x1f35f5]=new Set(),this['_get'](_0x1f35f5)),this['listeners'][_0x1f35f5]['add'](_0x46cd6b);}['_removeListener'](_0x3a1d51,_0x3d6edc){this['listeners'][_0x3a1d51]&&(this['listeners'][_0x3a1d51]['delete'](_0x3d6edc),this['listeners'][_0x3a1d51]['size']===0x0&&delete this['listeners'][_0x3a1d51]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x1135e5,_0x3109d1){return _0x3109d1?ne(_0x3109d1):(m(_0x1135e5['_popupRedirectResolver'],_0x1135e5,'argument-error'),_0x1135e5['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0xda4d7){super('custom','custom'),this['params']=_0xda4d7;}['_getIdTokenResponse'](_0x14fe81){return Ze(_0x14fe81,this['_buildIdpRequest']());}['_linkToIdToken'](_0x10611b,_0x485475){return Ze(_0x10611b,this['_buildIdpRequest'](_0x485475));}['_getReauthenticationResolver'](_0x1ede6b){return Ze(_0x1ede6b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x581665){const _0x1b195c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x581665&&(_0x1b195c['idToken']=_0x581665),_0x1b195c;}}function pp(_0xb07d19){return Ua(_0xb07d19['auth'],new Rs(_0xb07d19),_0xb07d19['bypassAuthState']);}function _p(_0x4d6582){const {auth:_0x35c147,user:_0x454bf5}=_0x4d6582;return m(_0x454bf5,_0x35c147,'internal-error'),Kf(_0x454bf5,new Rs(_0x4d6582),_0x4d6582['bypassAuthState']);}async function gp(_0x19a5e3){const {auth:_0x4925e3,user:_0x4b5a4a}=_0x19a5e3;return m(_0x4b5a4a,_0x4925e3,'internal-error'),jf(_0x4b5a4a,new Rs(_0x19a5e3),_0x19a5e3['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x5c14cc,_0x3cb799,_0x4d5baf,_0x95b6db,_0x335a9b=!0x1){this['auth']=_0x5c14cc,this['resolver']=_0x4d5baf,this['user']=_0x95b6db,this['bypassAuthState']=_0x335a9b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3cb799)?_0x3cb799:[_0x3cb799];}['execute'](){return new Promise(async(_0x3d34cb,_0x59e6d8)=>{this['pendingPromise']={'resolve':_0x3d34cb,'reject':_0x59e6d8};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3e0ec2){this['reject'](_0x3e0ec2);}});}async['onAuthEvent'](_0x4e3ff5){const {urlResponse:_0x1b3450,sessionId:_0x5e6510,postBody:_0x109c34,tenantId:_0x5bdc5c,error:_0x7b892a,type:_0x252003}=_0x4e3ff5;if(_0x7b892a){this['reject'](_0x7b892a);return;}const _0x3ecb24={'auth':this['auth'],'requestUri':_0x1b3450,'sessionId':_0x5e6510,'tenantId':_0x5bdc5c||void 0x0,'postBody':_0x109c34||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x252003)(_0x3ecb24));}catch(_0x3cade6){this['reject'](_0x3cade6);}}['onError'](_0x439264){this['reject'](_0x439264);}['getIdpTask'](_0x22f0ca){switch(_0x22f0ca){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x36ba9e){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x36ba9e),this['unregisterAndCleanUp']();}['reject'](_0x414d01){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x414d01),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x3d6012,_0x21063f,_0x31c85c,_0x9850da,_0x3f1736){super(_0x3d6012,_0x21063f,_0x9850da,_0x3f1736),this['provider']=_0x31c85c,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x17a636=await this['execute']();return m(_0x17a636,this['auth'],'internal-error'),_0x17a636;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0xfb44be=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0xfb44be),this['authWindow']['associatedEvent']=_0xfb44be,this['resolver']['_originValidation'](this['auth'])['catch'](_0x5141d2=>{this['reject'](_0x5141d2);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x307e42=>{_0x307e42||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x467d01;return((_0x467d01=this['authWindow'])==null?void 0x0:_0x467d01['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x206055=()=>{var _0x5261f2,_0x47aa10;if((_0x47aa10=(_0x5261f2=this['authWindow'])==null?void 0x0:_0x5261f2['window'])!=null&&_0x47aa10['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x206055,mp['get']());};_0x206055();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x4fdd00,_0x5cad62,_0x1a678e=!0x1){super(_0x4fdd00,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5cad62,void 0x0,_0x1a678e),this['eventId']=null;}async['execute'](){let _0x854440=rn['get'](this['auth']['_key']());if(!_0x854440){try{const _0x332bf3=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x854440=()=>Promise['resolve'](_0x332bf3);}catch(_0xd1337b){_0x854440=()=>Promise['reject'](_0xd1337b);}rn['set'](this['auth']['_key'](),_0x854440);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x854440();}async['onAuthEvent'](_0x2c67ba){if(_0x2c67ba['type']==='signInViaRedirect')return super['onAuthEvent'](_0x2c67ba);if(_0x2c67ba['type']==='unknown'){this['resolve'](null);return;}if(_0x2c67ba['eventId']){const _0x406e02=await this['auth']['_redirectUserForId'](_0x2c67ba['eventId']);if(_0x406e02)return this['user']=_0x406e02,super['onAuthEvent'](_0x2c67ba);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x4be502,_0x365645){const _0x46b8d8=Cp(_0x365645),_0x5a02d6=wp(_0x4be502);if(!await _0x5a02d6['_isAvailable']())return!0x1;const _0xcfbf30=await _0x5a02d6['_get'](_0x46b8d8)==='true';return await _0x5a02d6['_remove'](_0x46b8d8),_0xcfbf30;}function Ip(_0x5885da,_0x5edd61){rn['set'](_0x5885da['_key'](),_0x5edd61);}function wp(_0x373932){return ne(_0x373932['_redirectPersistence']);}function Cp(_0x470f79){return sn(yp,_0x470f79['config']['apiKey'],_0x470f79['name']);}async function Tp(_0xedf862,_0x253225,_0xfd17b0=!0x1){if(H(_0xedf862['app']))return Promise['reject'](se(_0xedf862));const _0x5175b1=qe(_0xedf862),_0x1dd143=fp(_0x5175b1,_0x253225),_0x3758ad=await new vp(_0x5175b1,_0x1dd143,_0xfd17b0)['execute']();return _0x3758ad&&!_0xfd17b0&&(delete _0x3758ad['user']['_redirectEventId'],await _0x5175b1['_persistUserIfCurrent'](_0x3758ad['user']),await _0x5175b1['_setRedirectUser'](null,_0x253225)),_0x3758ad;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x42b727){this['auth']=_0x42b727,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x24fd37){this['consumers']['add'](_0x24fd37),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x24fd37)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x24fd37),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x578eaf){this['consumers']['delete'](_0x578eaf);}['onEvent'](_0x33de89){if(this['hasEventBeenHandled'](_0x33de89))return!0x1;let _0x27a014=!0x1;return this['consumers']['forEach'](_0x332161=>{this['isEventForConsumer'](_0x33de89,_0x332161)&&(_0x27a014=!0x0,this['sendToConsumer'](_0x33de89,_0x332161),this['saveEventToCache'](_0x33de89));}),this['hasHandledPotentialRedirect']||!Rp(_0x33de89)||(this['hasHandledPotentialRedirect']=!0x0,_0x27a014||(this['queuedRedirectEvent']=_0x33de89,_0x27a014=!0x0)),_0x27a014;}['sendToConsumer'](_0x1c955a,_0x36515d){var _0x4a4936;if(_0x1c955a['error']&&!Qa(_0x1c955a)){const _0x4762e0=((_0x4a4936=_0x1c955a['error']['code'])==null?void 0x0:_0x4a4936['split']('auth/')[0x1])||'internal-error';_0x36515d['onError'](J(this['auth'],_0x4762e0));}else _0x36515d['onAuthEvent'](_0x1c955a);}['isEventForConsumer'](_0x3ae88a,_0x290e78){const _0xe57b07=_0x290e78['eventId']===null||!!_0x3ae88a['eventId']&&_0x3ae88a['eventId']===_0x290e78['eventId'];return _0x290e78['filter']['includes'](_0x3ae88a['type'])&&_0xe57b07;}['hasEventBeenHandled'](_0x2e9c1d){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2e9c1d));}['saveEventToCache'](_0x5c33cd){this['cachedEventUids']['add'](Pr(_0x5c33cd)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2f6934){return[_0x2f6934['type'],_0x2f6934['eventId'],_0x2f6934['sessionId'],_0x2f6934['tenantId']]['filter'](_0x3cd64f=>_0x3cd64f)['join']('-');}function Qa({type:_0x3d8277,error:_0x4f27db}){return _0x3d8277==='unknown'&&(_0x4f27db==null?void 0x0:_0x4f27db['code'])==='auth/no-auth-event';}function Rp(_0x3594a8){switch(_0x3594a8['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x3594a8);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x125a3a,_0x4f8e03={}){return Ae(_0x125a3a,'GET','/v1/projects',_0x4f8e03);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x5af83f){if(_0x5af83f['config']['emulator'])return;const {authorizedDomains:_0x4103d9}=await Ap(_0x5af83f);for(const _0x5a1e77 of _0x4103d9)try{if(Op(_0x5a1e77))return;}catch{}K(_0x5af83f,'unauthorized-domain');}function Op(_0x4524c1){const _0x588c15=Ni(),{protocol:_0x986dd9,hostname:_0x2d3b5c}=new URL(_0x588c15);if(_0x4524c1['startsWith']('chrome-extension://')){const _0x54f74b=new URL(_0x4524c1);return _0x54f74b['hostname']===''&&_0x2d3b5c===''?_0x986dd9==='chrome-extension:'&&_0x4524c1['replace']('chrome-extension://','')===_0x588c15['replace']('chrome-extension://',''):_0x986dd9==='chrome-extension:'&&_0x54f74b['hostname']===_0x2d3b5c;}if(!Np['test'](_0x986dd9))return!0x1;if(kp['test'](_0x4524c1))return _0x2d3b5c===_0x4524c1;const _0x58f2c4=_0x4524c1['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x58f2c4+'|'+_0x58f2c4+')$','i')['test'](_0x2d3b5c);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0xc0d1c8=X()['___jsl'];if(_0xc0d1c8!=null&&_0xc0d1c8['H']){for(const _0x717a5e of Object['keys'](_0xc0d1c8['H']))if(_0xc0d1c8['H'][_0x717a5e]['r']=_0xc0d1c8['H'][_0x717a5e]['r']||[],_0xc0d1c8['H'][_0x717a5e]['L']=_0xc0d1c8['H'][_0x717a5e]['L']||[],_0xc0d1c8['H'][_0x717a5e]['r']=[..._0xc0d1c8['H'][_0x717a5e]['L']],_0xc0d1c8['CP']){for(let _0x177e32=0x0;_0x177e32<_0xc0d1c8['CP']['length'];_0x177e32++)_0xc0d1c8['CP'][_0x177e32]=null;}}}function Mp(_0x196f58){return new Promise((_0x39a5e2,_0x421fcf)=>{var _0x52384,_0x5e5c6c,_0x4cd8f6;function _0x4ad70a(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x39a5e2(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x421fcf(J(_0x196f58,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x5e5c6c=(_0x52384=X()['gapi'])==null?void 0x0:_0x52384['iframes'])!=null&&_0x5e5c6c['Iframe'])_0x39a5e2(gapi['iframes']['getContext']());else{if((_0x4cd8f6=X()['gapi'])!=null&&_0x4cd8f6['load'])_0x4ad70a();else{const _0x38dce0=Nf('iframefcb');return X()[_0x38dce0]=()=>{gapi['load']?_0x4ad70a():_0x421fcf(J(_0x196f58,'network-request-failed'));},Da(kf()+'?onload='+_0x38dce0)['catch'](_0x12555e=>_0x421fcf(_0x12555e));}}})['catch'](_0x43c81a=>{throw on=null,_0x43c81a;});}let on=null;function Lp(_0x50ef4f){return on=on||Mp(_0x50ef4f),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x229f80){const _0x337fc2=_0x229f80['config'];m(_0x337fc2['authDomain'],_0x229f80,'auth-domain-config-required');const _0x23208c=_0x337fc2['emulator']?Is(_0x337fc2,Up):'https://'+_0x229f80['config']['authDomain']+'/'+Fp,_0x532b09={'apiKey':_0x337fc2['apiKey'],'appName':_0x229f80['name'],'v':ct},_0x36814b=Bp['get'](_0x229f80['config']['apiHost']);_0x36814b&&(_0x532b09['eid']=_0x36814b);const _0x26cebd=_0x229f80['_getFrameworks']();return _0x26cebd['length']&&(_0x532b09['fw']=_0x26cebd['join'](',')),_0x23208c+'?'+at(_0x532b09)['slice'](0x1);}async function Hp(_0x1ac711){const _0x32b08c=await Lp(_0x1ac711),_0x3ca6da=X()['gapi'];return m(_0x3ca6da,_0x1ac711,'internal-error'),_0x32b08c['open']({'where':document['body'],'url':Vp(_0x1ac711),'messageHandlersFilter':_0x3ca6da['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x21e6e2=>new Promise(async(_0x49177a,_0x368bab)=>{await _0x21e6e2['restyle']({'setHideOnLeave':!0x1});const _0x47032f=J(_0x1ac711,'network-request-failed'),_0x3cac52=X()['setTimeout'](()=>{_0x368bab(_0x47032f);},xp['get']());function _0xe1b127(){X()['clearTimeout'](_0x3cac52),_0x49177a(_0x21e6e2);}_0x21e6e2['ping'](_0xe1b127)['then'](_0xe1b127,()=>{_0x368bab(_0x47032f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x11b678){this['window']=_0x11b678,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0xa350ef,_0x5b52af,_0x2f5861,_0x2a37ce=Gp,_0x57c5d2=qp){const _0x43da24=Math['max']((window['screen']['availHeight']-_0x57c5d2)/0x2,0x0)['toString'](),_0xd82e91=Math['max']((window['screen']['availWidth']-_0x2a37ce)/0x2,0x0)['toString']();let _0x5d724a='';const _0x1c2f17={...$p,'width':_0x2a37ce['toString'](),'height':_0x57c5d2['toString'](),'top':_0x43da24,'left':_0xd82e91},_0x15ee9f=W()['toLowerCase']();_0x2f5861&&(_0x5d724a=ba(_0x15ee9f)?zp:_0x2f5861),Ta(_0x15ee9f)&&(_0x5b52af=_0x5b52af||jp,_0x1c2f17['scrollbars']='yes');const _0x1d1f43=Object['entries'](_0x1c2f17)['reduce']((_0x501d8c,[_0x1453d5,_0x57ee23])=>''+_0x501d8c+_0x1453d5+'='+_0x57ee23+',','');if(Ef(_0x15ee9f)&&_0x5d724a!=='_self')return Yp(_0x5b52af||'',_0x5d724a),new Dr(null);const _0x4db368=window['open'](_0x5b52af||'',_0x5d724a,_0x1d1f43);m(_0x4db368,_0xa350ef,'popup-blocked');try{_0x4db368['focus']();}catch{}return new Dr(_0x4db368);}function Yp(_0x4e90c7,_0x12f44c){const _0x21c6d2=document['createElement']('a');_0x21c6d2['href']=_0x4e90c7,_0x21c6d2['target']=_0x12f44c;const _0x48dea0=document['createEvent']('MouseEvent');_0x48dea0['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x21c6d2['dispatchEvent'](_0x48dea0);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x39fa10,_0x1cd0ca,_0x1df42e,_0x28e175,_0x26b746,_0x216579){m(_0x39fa10['config']['authDomain'],_0x39fa10,'auth-domain-config-required'),m(_0x39fa10['config']['apiKey'],_0x39fa10,'invalid-api-key');const _0x290b17={'apiKey':_0x39fa10['config']['apiKey'],'appName':_0x39fa10['name'],'authType':_0x1df42e,'redirectUrl':_0x28e175,'v':ct,'eventId':_0x26b746};if(_0x1cd0ca instanceof xa){_0x1cd0ca['setDefaultLanguage'](_0x39fa10['languageCode']),_0x290b17['providerId']=_0x1cd0ca['providerId']||'',hi(_0x1cd0ca['getCustomParameters']())||(_0x290b17['customParameters']=JSON['stringify'](_0x1cd0ca['getCustomParameters']()));for(const [_0x32dedb,_0x5bb9cf]of Object['entries']({}))_0x290b17[_0x32dedb]=_0x5bb9cf;}if(_0x1cd0ca instanceof Qt){const _0x3bd333=_0x1cd0ca['getScopes']()['filter'](_0x169037=>_0x169037!=='');_0x3bd333['length']>0x0&&(_0x290b17['scopes']=_0x3bd333['join'](','));}_0x39fa10['tenantId']&&(_0x290b17['tid']=_0x39fa10['tenantId']);const _0x2acf6f=_0x290b17;for(const _0x54be0e of Object['keys'](_0x2acf6f))_0x2acf6f[_0x54be0e]===void 0x0&&delete _0x2acf6f[_0x54be0e];const _0x40a654=await _0x39fa10['_getAppCheckToken'](),_0x25c2dd=_0x40a654?'#'+Xp+'='+encodeURIComponent(_0x40a654):'';return Zp(_0x39fa10)+'?'+at(_0x2acf6f)['slice'](0x1)+_0x25c2dd;}function Zp({config:_0x555137}){return _0x555137['emulator']?Is(_0x555137,Jp):'https://'+_0x555137['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x12d6e5,_0x220f42,_0x2b9283,_0x201277){var _0x49a13d;ae((_0x49a13d=this['eventManagers'][_0x12d6e5['_key']()])==null?void 0x0:_0x49a13d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3edc92=await Mr(_0x12d6e5,_0x220f42,_0x2b9283,Ni(),_0x201277);return Kp(_0x12d6e5,_0x3edc92,bs());}async['_openRedirect'](_0xcdaaf1,_0x18e9ad,_0x2c31bc,_0x36caa0){await this['_originValidation'](_0xcdaaf1);const _0x81dfad=await Mr(_0xcdaaf1,_0x18e9ad,_0x2c31bc,Ni(),_0x36caa0);return ip(_0x81dfad),new Promise(()=>{});}['_initialize'](_0xe05e5d){const _0x484c0f=_0xe05e5d['_key']();if(this['eventManagers'][_0x484c0f]){const {manager:_0x50c14d,promise:_0x895fe1}=this['eventManagers'][_0x484c0f];return _0x50c14d?Promise['resolve'](_0x50c14d):(ae(_0x895fe1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x895fe1);}const _0x4a756a=this['initAndGetManager'](_0xe05e5d);return this['eventManagers'][_0x484c0f]={'promise':_0x4a756a},_0x4a756a['catch'](()=>{delete this['eventManagers'][_0x484c0f];}),_0x4a756a;}async['initAndGetManager'](_0x4608b7){const _0x184ef3=await Hp(_0x4608b7),_0x156fe4=new bp(_0x4608b7);return _0x184ef3['register']('authEvent',_0x27b65f=>(m(_0x27b65f==null?void 0x0:_0x27b65f['authEvent'],_0x4608b7,'invalid-auth-event'),{'status':_0x156fe4['onEvent'](_0x27b65f['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4608b7['_key']()]={'manager':_0x156fe4},this['iframes'][_0x4608b7['_key']()]=_0x184ef3,_0x156fe4;}['_isIframeWebStorageSupported'](_0x574e91,_0x459974){this['iframes'][_0x574e91['_key']()]['send'](li,{'type':li},_0x5d2e0=>{var _0x5b3f09;const _0x50ef64=(_0x5b3f09=_0x5d2e0==null?void 0x0:_0x5d2e0[0x0])==null?void 0x0:_0x5b3f09[li];_0x50ef64!==void 0x0&&_0x459974(!!_0x50ef64),K(_0x574e91,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1dd332){const _0x4129b8=_0x1dd332['_key']();return this['originValidationPromises'][_0x4129b8]||(this['originValidationPromises'][_0x4129b8]=Pp(_0x1dd332)),this['originValidationPromises'][_0x4129b8];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x160573){this['auth']=_0x160573,this['internalListeners']=new Map();}['getUid'](){var _0x5283ec;return this['assertAuthConfigured'](),((_0x5283ec=this['auth']['currentUser'])==null?void 0x0:_0x5283ec['uid'])||null;}async['getToken'](_0x471f1b){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x471f1b)}:null;}['addAuthTokenListener'](_0x4af3a3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4af3a3))return;const _0x2a2d08=this['auth']['onIdTokenChanged'](_0x9b3e9d=>{_0x4af3a3((_0x9b3e9d==null?void 0x0:_0x9b3e9d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4af3a3,_0x2a2d08),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x365e18){this['assertAuthConfigured']();const _0x472a6e=this['internalListeners']['get'](_0x365e18);_0x472a6e&&(this['internalListeners']['delete'](_0x365e18),_0x472a6e(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x598750){switch(_0x598750){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x52b12f){et(new Me('auth',(_0x80df73,{options:_0x744219})=>{const _0x3c0adb=_0x80df73['getProvider']('app')['getImmediate'](),_0x42ae37=_0x80df73['getProvider']('heartbeat'),_0x9f9adb=_0x80df73['getProvider']('app-check-internal'),{apiKey:_0x24e9db,authDomain:_0x2c72e2}=_0x3c0adb['options'];m(_0x24e9db&&!_0x24e9db['includes'](':'),'invalid-api-key',{'appName':_0x3c0adb['name']});const _0x3e389a={'apiKey':_0x24e9db,'authDomain':_0x2c72e2,'clientPlatform':_0x52b12f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x52b12f)},_0x45f451=new bf(_0x3c0adb,_0x42ae37,_0x9f9adb,_0x3e389a);return Lf(_0x45f451,_0x744219),_0x45f451;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x242e8e,_0xe68eb4,_0xd54b6c)=>{_0x242e8e['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x57c936=>{const _0x15fa99=qe(_0x57c936['getProvider']('auth')['getImmediate']());return(_0x207a42=>new n_(_0x207a42))(_0x15fa99);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x52b12f)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x490953=>async _0x19197e=>{const _0x73344f=_0x19197e&&await _0x19197e['getIdTokenResult'](),_0x366d9c=_0x73344f&&(new Date()['getTime']()-Date['parse'](_0x73344f['issuedAtTime']))/0x3e8;if(_0x366d9c&&_0x366d9c>o_)return;const _0x4b69be=_0x73344f==null?void 0x0:_0x73344f['token'];Fr!==_0x4b69be&&(Fr=_0x4b69be,await fetch(_0x490953,{'method':_0x4b69be?'POST':'DELETE','headers':_0x4b69be?{'Authorization':'Bearer\x20'+_0x4b69be}:{}}));};function O_(_0x4656e7=Qr()){const _0x2bfc35=Ui(_0x4656e7,'auth');if(_0x2bfc35['isInitialized']())return _0x2bfc35['getImmediate']();const _0x2e6042=Mf(_0x4656e7,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x4fb13f=Gr('authTokenSyncURL');if(_0x4fb13f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x130340=new URL(_0x4fb13f,location['origin']);if(location['origin']===_0x130340['origin']){const _0x1221ff=a_(_0x130340['toString']());Jf(_0x2e6042,_0x1221ff,()=>_0x1221ff(_0x2e6042['currentUser'])),Qf(_0x2e6042,_0x7dbe07=>_0x1221ff(_0x7dbe07));}}const _0x2cfa21=Hr('auth');return _0x2cfa21&&xf(_0x2e6042,'http://'+_0x2cfa21),_0x2e6042;}function c_(){var _0x5acf61;return((_0x5acf61=document['getElementsByTagName']('head'))==null?void 0x0:_0x5acf61[0x0])??document;}Rf({'loadJS'(_0x1c1d5e){return new Promise((_0xba993d,_0x2ffb1d)=>{const _0x5d9512=document['createElement']('script');_0x5d9512['setAttribute']('src',_0x1c1d5e),_0x5d9512['onload']=_0xba993d,_0x5d9512['onerror']=_0x1c2f94=>{const _0x7d6a6e=J('internal-error');_0x7d6a6e['customData']=_0x1c2f94,_0x2ffb1d(_0x7d6a6e);},_0x5d9512['type']='text/javascript',_0x5d9512['charset']='UTF-8',c_()['appendChild'](_0x5d9512);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};