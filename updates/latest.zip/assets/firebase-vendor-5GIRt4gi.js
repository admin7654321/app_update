const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xc89068,_0xd7ae48){if(!_0xc89068)throw ot(_0xd7ae48);},ot=function(_0x2d713d){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2d713d);},Wr=function(_0x772b55){const _0x34795b=[];let _0x12864c=0x0;for(let _0xabee1e=0x0;_0xabee1e<_0x772b55['length'];_0xabee1e++){let _0x39e8aa=_0x772b55['charCodeAt'](_0xabee1e);_0x39e8aa<0x80?_0x34795b[_0x12864c++]=_0x39e8aa:_0x39e8aa<0x800?(_0x34795b[_0x12864c++]=_0x39e8aa>>0x6|0xc0,_0x34795b[_0x12864c++]=_0x39e8aa&0x3f|0x80):(_0x39e8aa&0xfc00)===0xd800&&_0xabee1e+0x1<_0x772b55['length']&&(_0x772b55['charCodeAt'](_0xabee1e+0x1)&0xfc00)===0xdc00?(_0x39e8aa=0x10000+((_0x39e8aa&0x3ff)<<0xa)+(_0x772b55['charCodeAt'](++_0xabee1e)&0x3ff),_0x34795b[_0x12864c++]=_0x39e8aa>>0x12|0xf0,_0x34795b[_0x12864c++]=_0x39e8aa>>0xc&0x3f|0x80,_0x34795b[_0x12864c++]=_0x39e8aa>>0x6&0x3f|0x80,_0x34795b[_0x12864c++]=_0x39e8aa&0x3f|0x80):(_0x34795b[_0x12864c++]=_0x39e8aa>>0xc|0xe0,_0x34795b[_0x12864c++]=_0x39e8aa>>0x6&0x3f|0x80,_0x34795b[_0x12864c++]=_0x39e8aa&0x3f|0x80);}return _0x34795b;},Za=function(_0x35f410){const _0x241536=[];let _0x5effa8=0x0,_0x540042=0x0;for(;_0x5effa8<_0x35f410['length'];){const _0x1a7c4f=_0x35f410[_0x5effa8++];if(_0x1a7c4f<0x80)_0x241536[_0x540042++]=String['fromCharCode'](_0x1a7c4f);else{if(_0x1a7c4f>0xbf&&_0x1a7c4f<0xe0){const _0xc42a3d=_0x35f410[_0x5effa8++];_0x241536[_0x540042++]=String['fromCharCode']((_0x1a7c4f&0x1f)<<0x6|_0xc42a3d&0x3f);}else{if(_0x1a7c4f>0xef&&_0x1a7c4f<0x16d){const _0x266d3c=_0x35f410[_0x5effa8++],_0x3fbde0=_0x35f410[_0x5effa8++],_0x8ec2a=_0x35f410[_0x5effa8++],_0x166745=((_0x1a7c4f&0x7)<<0x12|(_0x266d3c&0x3f)<<0xc|(_0x3fbde0&0x3f)<<0x6|_0x8ec2a&0x3f)-0x10000;_0x241536[_0x540042++]=String['fromCharCode'](0xd800+(_0x166745>>0xa)),_0x241536[_0x540042++]=String['fromCharCode'](0xdc00+(_0x166745&0x3ff));}else{const _0x512ac6=_0x35f410[_0x5effa8++],_0x4ef606=_0x35f410[_0x5effa8++];_0x241536[_0x540042++]=String['fromCharCode']((_0x1a7c4f&0xf)<<0xc|(_0x512ac6&0x3f)<<0x6|_0x4ef606&0x3f);}}}}return _0x241536['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x58ee5a,_0x5cf001){if(!Array['isArray'](_0x58ee5a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x46f6e2=_0x5cf001?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3c44af=[];for(let _0x4a622e=0x0;_0x4a622e<_0x58ee5a['length'];_0x4a622e+=0x3){const _0x4fec6e=_0x58ee5a[_0x4a622e],_0x3a51ad=_0x4a622e+0x1<_0x58ee5a['length'],_0x5b40fc=_0x3a51ad?_0x58ee5a[_0x4a622e+0x1]:0x0,_0x5b1c37=_0x4a622e+0x2<_0x58ee5a['length'],_0x2c18c8=_0x5b1c37?_0x58ee5a[_0x4a622e+0x2]:0x0,_0x172ac5=_0x4fec6e>>0x2,_0x47cb04=(_0x4fec6e&0x3)<<0x4|_0x5b40fc>>0x4;let _0x403678=(_0x5b40fc&0xf)<<0x2|_0x2c18c8>>0x6,_0x161ac2=_0x2c18c8&0x3f;_0x5b1c37||(_0x161ac2=0x40,_0x3a51ad||(_0x403678=0x40)),_0x3c44af['push'](_0x46f6e2[_0x172ac5],_0x46f6e2[_0x47cb04],_0x46f6e2[_0x403678],_0x46f6e2[_0x161ac2]);}return _0x3c44af['join']('');},'encodeString'(_0x28984d,_0x11aa9d){return this['HAS_NATIVE_SUPPORT']&&!_0x11aa9d?btoa(_0x28984d):this['encodeByteArray'](Wr(_0x28984d),_0x11aa9d);},'decodeString'(_0x10d0ab,_0x3018bf){return this['HAS_NATIVE_SUPPORT']&&!_0x3018bf?atob(_0x10d0ab):Za(this['decodeStringToByteArray'](_0x10d0ab,_0x3018bf));},'decodeStringToByteArray'(_0x3b5d26,_0x38723a){this['init_']();const _0x52e81a=_0x38723a?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1fa3d0=[];for(let _0x1f4b2c=0x0;_0x1f4b2c<_0x3b5d26['length'];){const _0xc4a694=_0x52e81a[_0x3b5d26['charAt'](_0x1f4b2c++)],_0x383f1d=_0x1f4b2c<_0x3b5d26['length']?_0x52e81a[_0x3b5d26['charAt'](_0x1f4b2c)]:0x0;++_0x1f4b2c;const _0x5d1188=_0x1f4b2c<_0x3b5d26['length']?_0x52e81a[_0x3b5d26['charAt'](_0x1f4b2c)]:0x40;++_0x1f4b2c;const _0x7ba040=_0x1f4b2c<_0x3b5d26['length']?_0x52e81a[_0x3b5d26['charAt'](_0x1f4b2c)]:0x40;if(++_0x1f4b2c,_0xc4a694==null||_0x383f1d==null||_0x5d1188==null||_0x7ba040==null)throw new ec();const _0x2898a8=_0xc4a694<<0x2|_0x383f1d>>0x4;if(_0x1fa3d0['push'](_0x2898a8),_0x5d1188!==0x40){const _0x2419dc=_0x383f1d<<0x4&0xf0|_0x5d1188>>0x2;if(_0x1fa3d0['push'](_0x2419dc),_0x7ba040!==0x40){const _0xb3536a=_0x5d1188<<0x6&0xc0|_0x7ba040;_0x1fa3d0['push'](_0xb3536a);}}}return _0x1fa3d0;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x31a2e7=0x0;_0x31a2e7<this['ENCODED_VALS']['length'];_0x31a2e7++)this['byteToCharMap_'][_0x31a2e7]=this['ENCODED_VALS']['charAt'](_0x31a2e7),this['charToByteMap_'][this['byteToCharMap_'][_0x31a2e7]]=_0x31a2e7,this['byteToCharMapWebSafe_'][_0x31a2e7]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x31a2e7),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x31a2e7]]=_0x31a2e7,_0x31a2e7>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x31a2e7)]=_0x31a2e7,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x31a2e7)]=_0x31a2e7);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x5c4d89){const _0x1c0f53=Wr(_0x5c4d89);return Di['encodeByteArray'](_0x1c0f53,!0x0);},an=function(_0x87a4a1){return Br(_0x87a4a1)['replace'](/\./g,'');},cn=function(_0x32da8f){try{return Di['decodeString'](_0x32da8f,!0x0);}catch(_0x1e1ad1){console['error']('base64Decode\x20failed:\x20',_0x1e1ad1);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x37e1a5){return Vr(void 0x0,_0x37e1a5);}function Vr(_0x31edf8,_0x272cab){if(!(_0x272cab instanceof Object))return _0x272cab;switch(_0x272cab['constructor']){case Date:const _0x356fbe=_0x272cab;return new Date(_0x356fbe['getTime']());case Object:_0x31edf8===void 0x0&&(_0x31edf8={});break;case Array:_0x31edf8=[];break;default:return _0x272cab;}for(const _0x513b9e in _0x272cab)!_0x272cab['hasOwnProperty'](_0x513b9e)||!nc(_0x513b9e)||(_0x31edf8[_0x513b9e]=Vr(_0x31edf8[_0x513b9e],_0x272cab[_0x513b9e]));return _0x31edf8;}function nc(_0x4105f9){return _0x4105f9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0xefc389=As['__FIREBASE_DEFAULTS__'];if(_0xefc389)return JSON['parse'](_0xefc389);},oc=()=>{if(typeof document>'u')return;let _0x5d8dd3;try{_0x5d8dd3=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x497f8e=_0x5d8dd3&&cn(_0x5d8dd3[0x1]);return _0x497f8e&&JSON['parse'](_0x497f8e);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x18e294){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x18e294);return;}},Hr=_0x413ec5=>{var _0x58fa9f,_0x452a16;return(_0x452a16=(_0x58fa9f=Mi())==null?void 0x0:_0x58fa9f['emulatorHosts'])==null?void 0x0:_0x452a16[_0x413ec5];},ac=_0x81f0c5=>{const _0x608f88=Hr(_0x81f0c5);if(!_0x608f88)return;const _0xed2355=_0x608f88['lastIndexOf'](':');if(_0xed2355<=0x0||_0xed2355+0x1===_0x608f88['length'])throw new Error('Invalid\x20host\x20'+_0x608f88+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2aabbb=parseInt(_0x608f88['substring'](_0xed2355+0x1),0xa);return _0x608f88[0x0]==='['?[_0x608f88['substring'](0x1,_0xed2355-0x1),_0x2aabbb]:[_0x608f88['substring'](0x0,_0xed2355),_0x2aabbb];},$r=()=>{var _0x5f4f72;return(_0x5f4f72=Mi())==null?void 0x0:_0x5f4f72['config'];},Gr=_0x5eea6c=>{var _0x53fc25;return(_0x53fc25=Mi())==null?void 0x0:_0x53fc25['_'+_0x5eea6c];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4c6195,_0x50c9d0)=>{this['resolve']=_0x4c6195,this['reject']=_0x50c9d0;});}['wrapCallback'](_0x17317c){return(_0x4ebafb,_0x22d8b3)=>{_0x4ebafb?this['reject'](_0x4ebafb):this['resolve'](_0x22d8b3),typeof _0x17317c=='function'&&(this['promise']['catch'](()=>{}),_0x17317c['length']===0x1?_0x17317c(_0x4ebafb):_0x17317c(_0x4ebafb,_0x22d8b3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x485b9e,_0x89436){if(_0x485b9e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1f8a13={'alg':'none','type':'JWT'},_0x1c9696=_0x89436||'demo-project',_0x2f0885=_0x485b9e['iat']||0x0,_0x4f3ebe=_0x485b9e['sub']||_0x485b9e['user_id'];if(!_0x4f3ebe)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x324bc5={'iss':'https://securetoken.google.com/'+_0x1c9696,'aud':_0x1c9696,'iat':_0x2f0885,'exp':_0x2f0885+0xe10,'auth_time':_0x2f0885,'sub':_0x4f3ebe,'user_id':_0x4f3ebe,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x485b9e};return[an(JSON['stringify'](_0x1f8a13)),an(JSON['stringify'](_0x324bc5)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x2ff61b=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2ff61b=='object'&&_0x2ff61b['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x1f25a9=W();return _0x1f25a9['indexOf']('MSIE\x20')>=0x0||_0x1f25a9['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0xd81c38,_0x1d115a)=>{try{let _0x708ef4=!0x0;const _0x559e2b='validate-browser-context-for-indexeddb-analytics-module',_0x11534b=self['indexedDB']['open'](_0x559e2b);_0x11534b['onsuccess']=()=>{_0x11534b['result']['close'](),_0x708ef4||self['indexedDB']['deleteDatabase'](_0x559e2b),_0xd81c38(!0x0);},_0x11534b['onupgradeneeded']=()=>{_0x708ef4=!0x1;},_0x11534b['onerror']=()=>{var _0x124f98;_0x1d115a(((_0x124f98=_0x11534b['error'])==null?void 0x0:_0x124f98['message'])||'');};}catch(_0x5440d3){_0x1d115a(_0x5440d3);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x175796,_0x268c5c,_0x264eec){super(_0x268c5c),this['code']=_0x175796,this['customData']=_0x264eec,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x53dd52,_0x1d9b92,_0x365445){this['service']=_0x53dd52,this['serviceName']=_0x1d9b92,this['errors']=_0x365445;}['create'](_0x32d837,..._0x3a834d){const _0x4174f5=_0x3a834d[0x0]||{},_0x3cb5f1=this['service']+'/'+_0x32d837,_0x4e20af=this['errors'][_0x32d837],_0x26c065=_0x4e20af?gc(_0x4e20af,_0x4174f5):'Error',_0x498e23=this['serviceName']+':\x20'+_0x26c065+'\x20('+_0x3cb5f1+').';return new Se(_0x3cb5f1,_0x498e23,_0x4174f5);}}function gc(_0xbc989,_0x25297d){return _0xbc989['replace'](mc,(_0x3292c7,_0x2f4d0a)=>{const _0x3ee107=_0x25297d[_0x2f4d0a];return _0x3ee107!=null?String(_0x3ee107):'<'+_0x2f4d0a+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x2b6667){return JSON['parse'](_0x2b6667);}function O(_0x53d9d5){return JSON['stringify'](_0x53d9d5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x4beedb){let _0xb8f873={},_0x274cde={},_0x4c7af9={},_0x3066f4='';try{const _0x5eafea=_0x4beedb['split']('.');_0xb8f873=bt(cn(_0x5eafea[0x0])||''),_0x274cde=bt(cn(_0x5eafea[0x1])||''),_0x3066f4=_0x5eafea[0x2],_0x4c7af9=_0x274cde['d']||{},delete _0x274cde['d'];}catch{}return{'header':_0xb8f873,'claims':_0x274cde,'data':_0x4c7af9,'signature':_0x3066f4};},yc=function(_0x2bd8e2){const _0x50b954=zr(_0x2bd8e2),_0x14291a=_0x50b954['claims'];return!!_0x14291a&&typeof _0x14291a=='object'&&_0x14291a['hasOwnProperty']('iat');},vc=function(_0x3c616a){const _0x5cc698=zr(_0x3c616a)['claims'];return typeof _0x5cc698=='object'&&_0x5cc698['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xcba40e,_0x42801e){return Object['prototype']['hasOwnProperty']['call'](_0xcba40e,_0x42801e);}function Oe(_0x241556,_0x55b189){if(Object['prototype']['hasOwnProperty']['call'](_0x241556,_0x55b189))return _0x241556[_0x55b189];}function hi(_0x342544){for(const _0x1844f2 in _0x342544)if(Object['prototype']['hasOwnProperty']['call'](_0x342544,_0x1844f2))return!0x1;return!0x0;}function ln(_0x16afee,_0x3ffc95,_0x2f554c){const _0x3bef8c={};for(const _0x4ff149 in _0x16afee)Object['prototype']['hasOwnProperty']['call'](_0x16afee,_0x4ff149)&&(_0x3bef8c[_0x4ff149]=_0x3ffc95['call'](_0x2f554c,_0x16afee[_0x4ff149],_0x4ff149,_0x16afee));return _0x3bef8c;}function De(_0x30e220,_0x39f5b2){if(_0x30e220===_0x39f5b2)return!0x0;const _0x736082=Object['keys'](_0x30e220),_0x57de84=Object['keys'](_0x39f5b2);for(const _0x5cd4aa of _0x736082){if(!_0x57de84['includes'](_0x5cd4aa))return!0x1;const _0x46999c=_0x30e220[_0x5cd4aa],_0x252781=_0x39f5b2[_0x5cd4aa];if(ks(_0x46999c)&&ks(_0x252781)){if(!De(_0x46999c,_0x252781))return!0x1;}else{if(_0x46999c!==_0x252781)return!0x1;}}for(const _0x524f75 of _0x57de84)if(!_0x736082['includes'](_0x524f75))return!0x1;return!0x0;}function ks(_0x233806){return _0x233806!==null&&typeof _0x233806=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x4de479){const _0x27415c=[];for(const [_0x56cf75,_0x58aff2]of Object['entries'](_0x4de479))Array['isArray'](_0x58aff2)?_0x58aff2['forEach'](_0xea9800=>{_0x27415c['push'](encodeURIComponent(_0x56cf75)+'='+encodeURIComponent(_0xea9800));}):_0x27415c['push'](encodeURIComponent(_0x56cf75)+'='+encodeURIComponent(_0x58aff2));return _0x27415c['length']?'&'+_0x27415c['join']('&'):'';}function yt(_0xf8f111){const _0x3206dd={};return _0xf8f111['replace'](/^\?/,'')['split']('&')['forEach'](_0x264f52=>{if(_0x264f52){const [_0x5ebeb9,_0x466053]=_0x264f52['split']('=');_0x3206dd[decodeURIComponent(_0x5ebeb9)]=decodeURIComponent(_0x466053);}}),_0x3206dd;}function vt(_0x4cfa94){const _0xba8135=_0x4cfa94['indexOf']('?');if(!_0xba8135)return'';const _0x563419=_0x4cfa94['indexOf']('#',_0xba8135);return _0x4cfa94['substring'](_0xba8135,_0x563419>0x0?_0x563419:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x48619f=0x1;_0x48619f<this['blockSize'];++_0x48619f)this['pad_'][_0x48619f]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x3acd7c,_0x3bb693){_0x3bb693||(_0x3bb693=0x0);const _0x598a04=this['W_'];if(typeof _0x3acd7c=='string'){for(let _0x1f5156=0x0;_0x1f5156<0x10;_0x1f5156++)_0x598a04[_0x1f5156]=_0x3acd7c['charCodeAt'](_0x3bb693)<<0x18|_0x3acd7c['charCodeAt'](_0x3bb693+0x1)<<0x10|_0x3acd7c['charCodeAt'](_0x3bb693+0x2)<<0x8|_0x3acd7c['charCodeAt'](_0x3bb693+0x3),_0x3bb693+=0x4;}else{for(let _0x271f7d=0x0;_0x271f7d<0x10;_0x271f7d++)_0x598a04[_0x271f7d]=_0x3acd7c[_0x3bb693]<<0x18|_0x3acd7c[_0x3bb693+0x1]<<0x10|_0x3acd7c[_0x3bb693+0x2]<<0x8|_0x3acd7c[_0x3bb693+0x3],_0x3bb693+=0x4;}for(let _0x41a987=0x10;_0x41a987<0x50;_0x41a987++){const _0x16affc=_0x598a04[_0x41a987-0x3]^_0x598a04[_0x41a987-0x8]^_0x598a04[_0x41a987-0xe]^_0x598a04[_0x41a987-0x10];_0x598a04[_0x41a987]=(_0x16affc<<0x1|_0x16affc>>>0x1f)&0xffffffff;}let _0x1f1e0a=this['chain_'][0x0],_0x54f503=this['chain_'][0x1],_0xc8ed7c=this['chain_'][0x2],_0x38bda5=this['chain_'][0x3],_0x1f0a64=this['chain_'][0x4],_0x35625b,_0x3bc6f1;for(let _0x468cb7=0x0;_0x468cb7<0x50;_0x468cb7++){_0x468cb7<0x28?_0x468cb7<0x14?(_0x35625b=_0x38bda5^_0x54f503&(_0xc8ed7c^_0x38bda5),_0x3bc6f1=0x5a827999):(_0x35625b=_0x54f503^_0xc8ed7c^_0x38bda5,_0x3bc6f1=0x6ed9eba1):_0x468cb7<0x3c?(_0x35625b=_0x54f503&_0xc8ed7c|_0x38bda5&(_0x54f503|_0xc8ed7c),_0x3bc6f1=0x8f1bbcdc):(_0x35625b=_0x54f503^_0xc8ed7c^_0x38bda5,_0x3bc6f1=0xca62c1d6);const _0x584e54=(_0x1f1e0a<<0x5|_0x1f1e0a>>>0x1b)+_0x35625b+_0x1f0a64+_0x3bc6f1+_0x598a04[_0x468cb7]&0xffffffff;_0x1f0a64=_0x38bda5,_0x38bda5=_0xc8ed7c,_0xc8ed7c=(_0x54f503<<0x1e|_0x54f503>>>0x2)&0xffffffff,_0x54f503=_0x1f1e0a,_0x1f1e0a=_0x584e54;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1f1e0a&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x54f503&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xc8ed7c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x38bda5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1f0a64&0xffffffff;}['update'](_0x36f048,_0x58f86b){if(_0x36f048==null)return;_0x58f86b===void 0x0&&(_0x58f86b=_0x36f048['length']);const _0x4044fe=_0x58f86b-this['blockSize'];let _0x34de9b=0x0;const _0x2ed731=this['buf_'];let _0x355489=this['inbuf_'];for(;_0x34de9b<_0x58f86b;){if(_0x355489===0x0){for(;_0x34de9b<=_0x4044fe;)this['compress_'](_0x36f048,_0x34de9b),_0x34de9b+=this['blockSize'];}if(typeof _0x36f048=='string'){for(;_0x34de9b<_0x58f86b;)if(_0x2ed731[_0x355489]=_0x36f048['charCodeAt'](_0x34de9b),++_0x355489,++_0x34de9b,_0x355489===this['blockSize']){this['compress_'](_0x2ed731),_0x355489=0x0;break;}}else{for(;_0x34de9b<_0x58f86b;)if(_0x2ed731[_0x355489]=_0x36f048[_0x34de9b],++_0x355489,++_0x34de9b,_0x355489===this['blockSize']){this['compress_'](_0x2ed731),_0x355489=0x0;break;}}}this['inbuf_']=_0x355489,this['total_']+=_0x58f86b;}['digest'](){const _0x4a3456=[];let _0x18e864=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1bab34=this['blockSize']-0x1;_0x1bab34>=0x38;_0x1bab34--)this['buf_'][_0x1bab34]=_0x18e864&0xff,_0x18e864/=0x100;this['compress_'](this['buf_']);let _0x5a7263=0x0;for(let _0x25f7ee=0x0;_0x25f7ee<0x5;_0x25f7ee++)for(let _0x1bad97=0x18;_0x1bad97>=0x0;_0x1bad97-=0x8)_0x4a3456[_0x5a7263]=this['chain_'][_0x25f7ee]>>_0x1bad97&0xff,++_0x5a7263;return _0x4a3456;}}function Ic(_0x5256b7,_0xdd70ac){const _0x551fb6=new wc(_0x5256b7,_0xdd70ac);return _0x551fb6['subscribe']['bind'](_0x551fb6);}class wc{constructor(_0x508304,_0x488e55){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x488e55,this['task']['then'](()=>{_0x508304(this);})['catch'](_0x47314f=>{this['error'](_0x47314f);});}['next'](_0x359b23){this['forEachObserver'](_0x34c7de=>{_0x34c7de['next'](_0x359b23);});}['error'](_0x4c483a){this['forEachObserver'](_0x2ef9b0=>{_0x2ef9b0['error'](_0x4c483a);}),this['close'](_0x4c483a);}['complete'](){this['forEachObserver'](_0x5d08f8=>{_0x5d08f8['complete']();}),this['close']();}['subscribe'](_0x3b344a,_0x3ec569,_0x3c9818){let _0x2d3295;if(_0x3b344a===void 0x0&&_0x3ec569===void 0x0&&_0x3c9818===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x3b344a,['next','error','complete'])?_0x2d3295=_0x3b344a:_0x2d3295={'next':_0x3b344a,'error':_0x3ec569,'complete':_0x3c9818},_0x2d3295['next']===void 0x0&&(_0x2d3295['next']=Qn),_0x2d3295['error']===void 0x0&&(_0x2d3295['error']=Qn),_0x2d3295['complete']===void 0x0&&(_0x2d3295['complete']=Qn);const _0x50c30c=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2d3295['error'](this['finalError']):_0x2d3295['complete']();}catch{}}),this['observers']['push'](_0x2d3295),_0x50c30c;}['unsubscribeOne'](_0x43fb6e){this['observers']===void 0x0||this['observers'][_0x43fb6e]===void 0x0||(delete this['observers'][_0x43fb6e],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x6a72fb){if(!this['finalized']){for(let _0x3dc68d=0x0;_0x3dc68d<this['observers']['length'];_0x3dc68d++)this['sendOne'](_0x3dc68d,_0x6a72fb);}}['sendOne'](_0x35fbb7,_0x340df7){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x35fbb7]!==void 0x0)try{_0x340df7(this['observers'][_0x35fbb7]);}catch(_0xa3c40f){typeof console<'u'&&console['error']&&console['error'](_0xa3c40f);}});}['close'](_0x2f0ef4){this['finalized']||(this['finalized']=!0x0,_0x2f0ef4!==void 0x0&&(this['finalError']=_0x2f0ef4),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0xdee5db,_0x50d34e){if(typeof _0xdee5db!='object'||_0xdee5db===null)return!0x1;for(const _0x47d377 of _0x50d34e)if(_0x47d377 in _0xdee5db&&typeof _0xdee5db[_0x47d377]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x2fedaa,_0x24da43){return _0x2fedaa+'\x20failed:\x20'+_0x24da43+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x210da1){const _0x365ab9=[];let _0x31db26=0x0;for(let _0x164121=0x0;_0x164121<_0x210da1['length'];_0x164121++){let _0x288881=_0x210da1['charCodeAt'](_0x164121);if(_0x288881>=0xd800&&_0x288881<=0xdbff){const _0x4e129c=_0x288881-0xd800;_0x164121++,f(_0x164121<_0x210da1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1b412e=_0x210da1['charCodeAt'](_0x164121)-0xdc00;_0x288881=0x10000+(_0x4e129c<<0xa)+_0x1b412e;}_0x288881<0x80?_0x365ab9[_0x31db26++]=_0x288881:_0x288881<0x800?(_0x365ab9[_0x31db26++]=_0x288881>>0x6|0xc0,_0x365ab9[_0x31db26++]=_0x288881&0x3f|0x80):_0x288881<0x10000?(_0x365ab9[_0x31db26++]=_0x288881>>0xc|0xe0,_0x365ab9[_0x31db26++]=_0x288881>>0x6&0x3f|0x80,_0x365ab9[_0x31db26++]=_0x288881&0x3f|0x80):(_0x365ab9[_0x31db26++]=_0x288881>>0x12|0xf0,_0x365ab9[_0x31db26++]=_0x288881>>0xc&0x3f|0x80,_0x365ab9[_0x31db26++]=_0x288881>>0x6&0x3f|0x80,_0x365ab9[_0x31db26++]=_0x288881&0x3f|0x80);}return _0x365ab9;},Pn=function(_0xac7a68){let _0x40c1ec=0x0;for(let _0x1206c7=0x0;_0x1206c7<_0xac7a68['length'];_0x1206c7++){const _0x48e7b0=_0xac7a68['charCodeAt'](_0x1206c7);_0x48e7b0<0x80?_0x40c1ec++:_0x48e7b0<0x800?_0x40c1ec+=0x2:_0x48e7b0>=0xd800&&_0x48e7b0<=0xdbff?(_0x40c1ec+=0x4,_0x1206c7++):_0x40c1ec+=0x3;}return _0x40c1ec;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x3b1046){return _0x3b1046&&_0x3b1046['_delegate']?_0x3b1046['_delegate']:_0x3b1046;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x5c4cf3){try{return(_0x5c4cf3['startsWith']('http://')||_0x5c4cf3['startsWith']('https://')?new URL(_0x5c4cf3)['hostname']:_0x5c4cf3)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x45ecb7){return(await fetch(_0x45ecb7,{'credentials':'include'}))['ok'];}class Me{constructor(_0x218b51,_0x4a0be9,_0x39a808){this['name']=_0x218b51,this['instanceFactory']=_0x4a0be9,this['type']=_0x39a808,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x13c2bc){return this['instantiationMode']=_0x13c2bc,this;}['setMultipleInstances'](_0x12bc46){return this['multipleInstances']=_0x12bc46,this;}['setServiceProps'](_0x5c7daa){return this['serviceProps']=_0x5c7daa,this;}['setInstanceCreatedCallback'](_0x2c91d7){return this['onInstanceCreated']=_0x2c91d7,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x20b1f8,_0x393a18){this['name']=_0x20b1f8,this['container']=_0x393a18,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1419c0){const _0x941969=this['normalizeInstanceIdentifier'](_0x1419c0);if(!this['instancesDeferred']['has'](_0x941969)){const _0x5eba36=new Ve();if(this['instancesDeferred']['set'](_0x941969,_0x5eba36),this['isInitialized'](_0x941969)||this['shouldAutoInitialize']())try{const _0x2a1686=this['getOrInitializeService']({'instanceIdentifier':_0x941969});_0x2a1686&&_0x5eba36['resolve'](_0x2a1686);}catch{}}return this['instancesDeferred']['get'](_0x941969)['promise'];}['getImmediate'](_0x7aaa6a){const _0x4833ac=this['normalizeInstanceIdentifier'](_0x7aaa6a==null?void 0x0:_0x7aaa6a['identifier']),_0x328554=(_0x7aaa6a==null?void 0x0:_0x7aaa6a['optional'])??!0x1;if(this['isInitialized'](_0x4833ac)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4833ac});}catch(_0x1fc08e){if(_0x328554)return null;throw _0x1fc08e;}else{if(_0x328554)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2d1f5a){if(_0x2d1f5a['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2d1f5a['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2d1f5a,!!this['shouldAutoInitialize']()){if(Rc(_0x2d1f5a))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x496c4f,_0x59e678]of this['instancesDeferred']['entries']()){const _0x4c884f=this['normalizeInstanceIdentifier'](_0x496c4f);try{const _0x4cea1d=this['getOrInitializeService']({'instanceIdentifier':_0x4c884f});_0x59e678['resolve'](_0x4cea1d);}catch{}}}}['clearInstance'](_0x4453ea=ke){this['instancesDeferred']['delete'](_0x4453ea),this['instancesOptions']['delete'](_0x4453ea),this['instances']['delete'](_0x4453ea);}async['delete'](){const _0x4ccfda=Array['from'](this['instances']['values']());await Promise['all']([..._0x4ccfda['filter'](_0x5607a4=>'INTERNAL'in _0x5607a4)['map'](_0xa5f3ee=>_0xa5f3ee['INTERNAL']['delete']()),..._0x4ccfda['filter'](_0x33e31c=>'_delete'in _0x33e31c)['map'](_0x24f98d=>_0x24f98d['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x55ef9b=ke){return this['instances']['has'](_0x55ef9b);}['getOptions'](_0x58d31e=ke){return this['instancesOptions']['get'](_0x58d31e)||{};}['initialize'](_0x519914={}){const {options:_0x4f1eb5={}}=_0x519914,_0x4b2b6a=this['normalizeInstanceIdentifier'](_0x519914['instanceIdentifier']);if(this['isInitialized'](_0x4b2b6a))throw Error(this['name']+'('+_0x4b2b6a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3a8a37=this['getOrInitializeService']({'instanceIdentifier':_0x4b2b6a,'options':_0x4f1eb5});for(const [_0x5e9fff,_0x36ccee]of this['instancesDeferred']['entries']()){const _0x5d7404=this['normalizeInstanceIdentifier'](_0x5e9fff);_0x4b2b6a===_0x5d7404&&_0x36ccee['resolve'](_0x3a8a37);}return _0x3a8a37;}['onInit'](_0x9d1456,_0x1400a){const _0xcb09b3=this['normalizeInstanceIdentifier'](_0x1400a),_0x4f9957=this['onInitCallbacks']['get'](_0xcb09b3)??new Set();_0x4f9957['add'](_0x9d1456),this['onInitCallbacks']['set'](_0xcb09b3,_0x4f9957);const _0x515b57=this['instances']['get'](_0xcb09b3);return _0x515b57&&_0x9d1456(_0x515b57,_0xcb09b3),()=>{_0x4f9957['delete'](_0x9d1456);};}['invokeOnInitCallbacks'](_0xa23d1,_0x1111e1){const _0xbd05b0=this['onInitCallbacks']['get'](_0x1111e1);if(_0xbd05b0){for(const _0x26a933 of _0xbd05b0)try{_0x26a933(_0xa23d1,_0x1111e1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x281eba,options:_0x5be123={}}){let _0xb879e4=this['instances']['get'](_0x281eba);if(!_0xb879e4&&this['component']&&(_0xb879e4=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x281eba),'options':_0x5be123}),this['instances']['set'](_0x281eba,_0xb879e4),this['instancesOptions']['set'](_0x281eba,_0x5be123),this['invokeOnInitCallbacks'](_0xb879e4,_0x281eba),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x281eba,_0xb879e4);}catch{}return _0xb879e4||null;}['normalizeInstanceIdentifier'](_0x183878=ke){return this['component']?this['component']['multipleInstances']?_0x183878:ke:_0x183878;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2d6b02){return _0x2d6b02===ke?void 0x0:_0x2d6b02;}function Rc(_0x3301e7){return _0x3301e7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1c0d0a){this['name']=_0x1c0d0a,this['providers']=new Map();}['addComponent'](_0x2076ef){const _0x3ab60d=this['getProvider'](_0x2076ef['name']);if(_0x3ab60d['isComponentSet']())throw new Error('Component\x20'+_0x2076ef['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3ab60d['setComponent'](_0x2076ef);}['addOrOverwriteComponent'](_0x3ef9c2){this['getProvider'](_0x3ef9c2['name'])['isComponentSet']()&&this['providers']['delete'](_0x3ef9c2['name']),this['addComponent'](_0x3ef9c2);}['getProvider'](_0x39fb7d){if(this['providers']['has'](_0x39fb7d))return this['providers']['get'](_0x39fb7d);const _0x2c0559=new Sc(_0x39fb7d,this);return this['providers']['set'](_0x39fb7d,_0x2c0559),_0x2c0559;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x503fdf){_0x503fdf[_0x503fdf['DEBUG']=0x0]='DEBUG',_0x503fdf[_0x503fdf['VERBOSE']=0x1]='VERBOSE',_0x503fdf[_0x503fdf['INFO']=0x2]='INFO',_0x503fdf[_0x503fdf['WARN']=0x3]='WARN',_0x503fdf[_0x503fdf['ERROR']=0x4]='ERROR',_0x503fdf[_0x503fdf['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x9d24cb,_0x2e073,..._0x33a4e9)=>{if(_0x2e073<_0x9d24cb['logLevel'])return;const _0x4424f0=new Date()['toISOString'](),_0x5ac677=Pc[_0x2e073];if(_0x5ac677)console[_0x5ac677]('['+_0x4424f0+']\x20\x20'+_0x9d24cb['name']+':',..._0x33a4e9);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2e073+')');};class xi{constructor(_0x535a16){this['name']=_0x535a16,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x23727f){if(!(_0x23727f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x23727f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x23727f;}['setLogLevel'](_0x1f3dfd){this['_logLevel']=typeof _0x1f3dfd=='string'?kc[_0x1f3dfd]:_0x1f3dfd;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3c4d3f){if(typeof _0x3c4d3f!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3c4d3f;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x41a231){this['_userLogHandler']=_0x41a231;}['debug'](..._0x4fc872){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4fc872),this['_logHandler'](this,T['DEBUG'],..._0x4fc872);}['log'](..._0x2870f3){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2870f3),this['_logHandler'](this,T['VERBOSE'],..._0x2870f3);}['info'](..._0x77969a){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x77969a),this['_logHandler'](this,T['INFO'],..._0x77969a);}['warn'](..._0x7f90e7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x7f90e7),this['_logHandler'](this,T['WARN'],..._0x7f90e7);}['error'](..._0x26e212){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x26e212),this['_logHandler'](this,T['ERROR'],..._0x26e212);}}const Dc=(_0x1e3a34,_0x3deab0)=>_0x3deab0['some'](_0x3ff2da=>_0x1e3a34 instanceof _0x3ff2da);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x26f7df){const _0x3f9d5e=new Promise((_0x21961b,_0x250a7b)=>{const _0x2df0ba=()=>{_0x26f7df['removeEventListener']('success',_0x3301d4),_0x26f7df['removeEventListener']('error',_0x30ce03);},_0x3301d4=()=>{_0x21961b(_e(_0x26f7df['result'])),_0x2df0ba();},_0x30ce03=()=>{_0x250a7b(_0x26f7df['error']),_0x2df0ba();};_0x26f7df['addEventListener']('success',_0x3301d4),_0x26f7df['addEventListener']('error',_0x30ce03);});return _0x3f9d5e['then'](_0x36ada6=>{_0x36ada6 instanceof IDBCursor&&Kr['set'](_0x36ada6,_0x26f7df);})['catch'](()=>{}),Fi['set'](_0x3f9d5e,_0x26f7df),_0x3f9d5e;}function Fc(_0x33fc3a){if(ui['has'](_0x33fc3a))return;const _0xf9ab48=new Promise((_0x39f0b7,_0x5aaee)=>{const _0x16fa9b=()=>{_0x33fc3a['removeEventListener']('complete',_0x43d4f9),_0x33fc3a['removeEventListener']('error',_0x466164),_0x33fc3a['removeEventListener']('abort',_0x466164);},_0x43d4f9=()=>{_0x39f0b7(),_0x16fa9b();},_0x466164=()=>{_0x5aaee(_0x33fc3a['error']||new DOMException('AbortError','AbortError')),_0x16fa9b();};_0x33fc3a['addEventListener']('complete',_0x43d4f9),_0x33fc3a['addEventListener']('error',_0x466164),_0x33fc3a['addEventListener']('abort',_0x466164);});ui['set'](_0x33fc3a,_0xf9ab48);}let di={'get'(_0xb659cc,_0x147842,_0x31159e){if(_0xb659cc instanceof IDBTransaction){if(_0x147842==='done')return ui['get'](_0xb659cc);if(_0x147842==='objectStoreNames')return _0xb659cc['objectStoreNames']||Yr['get'](_0xb659cc);if(_0x147842==='store')return _0x31159e['objectStoreNames'][0x1]?void 0x0:_0x31159e['objectStore'](_0x31159e['objectStoreNames'][0x0]);}return _e(_0xb659cc[_0x147842]);},'set'(_0x25e977,_0x593ada,_0x1f982c){return _0x25e977[_0x593ada]=_0x1f982c,!0x0;},'has'(_0x349cdf,_0x4608c5){return _0x349cdf instanceof IDBTransaction&&(_0x4608c5==='done'||_0x4608c5==='store')?!0x0:_0x4608c5 in _0x349cdf;}};function Uc(_0x25f555){di=_0x25f555(di);}function Wc(_0x4fac47){return _0x4fac47===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4ae621,..._0x5b93a8){const _0x343140=_0x4fac47['call'](Xn(this),_0x4ae621,..._0x5b93a8);return Yr['set'](_0x343140,_0x4ae621['sort']?_0x4ae621['sort']():[_0x4ae621]),_e(_0x343140);}:Lc()['includes'](_0x4fac47)?function(..._0x17394f){return _0x4fac47['apply'](Xn(this),_0x17394f),_e(Kr['get'](this));}:function(..._0x3c670f){return _e(_0x4fac47['apply'](Xn(this),_0x3c670f));};}function Bc(_0x2530a2){return typeof _0x2530a2=='function'?Wc(_0x2530a2):(_0x2530a2 instanceof IDBTransaction&&Fc(_0x2530a2),Dc(_0x2530a2,Mc())?new Proxy(_0x2530a2,di):_0x2530a2);}function _e(_0x13f3bd){if(_0x13f3bd instanceof IDBRequest)return xc(_0x13f3bd);if(Jn['has'](_0x13f3bd))return Jn['get'](_0x13f3bd);const _0x285f9d=Bc(_0x13f3bd);return _0x285f9d!==_0x13f3bd&&(Jn['set'](_0x13f3bd,_0x285f9d),Fi['set'](_0x285f9d,_0x13f3bd)),_0x285f9d;}const Xn=_0x505c0d=>Fi['get'](_0x505c0d);function Vc(_0x5cf9c9,_0x107101,{blocked:_0x1833a5,upgrade:_0x454c39,blocking:_0x36c2c5,terminated:_0x3225b4}={}){const _0x48e5e0=indexedDB['open'](_0x5cf9c9,_0x107101),_0x2e6e86=_e(_0x48e5e0);return _0x454c39&&_0x48e5e0['addEventListener']('upgradeneeded',_0x338c36=>{_0x454c39(_e(_0x48e5e0['result']),_0x338c36['oldVersion'],_0x338c36['newVersion'],_e(_0x48e5e0['transaction']),_0x338c36);}),_0x1833a5&&_0x48e5e0['addEventListener']('blocked',_0x5c1048=>_0x1833a5(_0x5c1048['oldVersion'],_0x5c1048['newVersion'],_0x5c1048)),_0x2e6e86['then'](_0x370b70=>{_0x3225b4&&_0x370b70['addEventListener']('close',()=>_0x3225b4()),_0x36c2c5&&_0x370b70['addEventListener']('versionchange',_0x5f03b2=>_0x36c2c5(_0x5f03b2['oldVersion'],_0x5f03b2['newVersion'],_0x5f03b2));})['catch'](()=>{}),_0x2e6e86;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x131a41,_0x9b2251){if(!(_0x131a41 instanceof IDBDatabase&&!(_0x9b2251 in _0x131a41)&&typeof _0x9b2251=='string'))return;if(Zn['get'](_0x9b2251))return Zn['get'](_0x9b2251);const _0xf64ceb=_0x9b2251['replace'](/FromIndex$/,''),_0x296fd0=_0x9b2251!==_0xf64ceb,_0x3169ee=$c['includes'](_0xf64ceb);if(!(_0xf64ceb in(_0x296fd0?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3169ee||Hc['includes'](_0xf64ceb)))return;const _0x2be215=async function(_0x1cc626,..._0x2044f2){const _0x3e2031=this['transaction'](_0x1cc626,_0x3169ee?'readwrite':'readonly');let _0x62f6c6=_0x3e2031['store'];return _0x296fd0&&(_0x62f6c6=_0x62f6c6['index'](_0x2044f2['shift']())),(await Promise['all']([_0x62f6c6[_0xf64ceb](..._0x2044f2),_0x3169ee&&_0x3e2031['done']]))[0x0];};return Zn['set'](_0x9b2251,_0x2be215),_0x2be215;}Uc(_0x1c1684=>({..._0x1c1684,'get':(_0x50e09c,_0x5ac3b6,_0x16affd)=>Os(_0x50e09c,_0x5ac3b6)||_0x1c1684['get'](_0x50e09c,_0x5ac3b6,_0x16affd),'has':(_0xb16d2b,_0x3d935d)=>!!Os(_0xb16d2b,_0x3d935d)||_0x1c1684['has'](_0xb16d2b,_0x3d935d)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x1d5c67){this['container']=_0x1d5c67;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1f3052=>{if(qc(_0x1f3052)){const _0x16fa09=_0x1f3052['getImmediate']();return _0x16fa09['library']+'/'+_0x16fa09['version'];}else return null;})['filter'](_0x219af2=>_0x219af2)['join']('\x20');}}function qc(_0x225e84){const _0x4aa53e=_0x225e84['getComponent']();return(_0x4aa53e==null?void 0x0:_0x4aa53e['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x2450da,_0x36bfc8){try{_0x2450da['container']['addComponent'](_0x36bfc8);}catch(_0x1100ab){re['debug']('Component\x20'+_0x36bfc8['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2450da['name'],_0x1100ab);}}function et(_0x366785){const _0x177f79=_0x366785['name'];if(gi['has'](_0x177f79))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x177f79+'.'),!0x1;gi['set'](_0x177f79,_0x366785);for(const _0x5179e6 of Le['values']())Ms(_0x5179e6,_0x366785);for(const _0x1b8273 of _i['values']())Ms(_0x1b8273,_0x366785);return!0x0;}function Ui(_0xd94e69,_0x27e1b0){const _0x8ca71b=_0xd94e69['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x8ca71b&&_0x8ca71b['triggerHeartbeat'](),_0xd94e69['container']['getProvider'](_0x27e1b0);}function H(_0x1020b1){return _0x1020b1==null?!0x1:_0x1020b1['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x52c0f0,_0x4c4d28,_0x2a1577){this['_isDeleted']=!0x1,this['_options']={..._0x52c0f0},this['_config']={..._0x4c4d28},this['_name']=_0x4c4d28['name'],this['_automaticDataCollectionEnabled']=_0x4c4d28['automaticDataCollectionEnabled'],this['_container']=_0x2a1577,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3b77c1){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3b77c1;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2342d3){this['_isDeleted']=_0x2342d3;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5d90bf,_0x50c237={}){let _0x5da02d=_0x5d90bf;typeof _0x50c237!='object'&&(_0x50c237={'name':_0x50c237});const _0x2ea9a0={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x50c237},_0x2c0b05=_0x2ea9a0['name'];if(typeof _0x2c0b05!='string'||!_0x2c0b05)throw ge['create']('bad-app-name',{'appName':String(_0x2c0b05)});if(_0x5da02d||(_0x5da02d=$r()),!_0x5da02d)throw ge['create']('no-options');const _0x345336=Le['get'](_0x2c0b05);if(_0x345336){if(De(_0x5da02d,_0x345336['options'])&&De(_0x2ea9a0,_0x345336['config']))return _0x345336;throw ge['create']('duplicate-app',{'appName':_0x2c0b05});}const _0x2fa25f=new Ac(_0x2c0b05);for(const _0x1bb076 of gi['values']())_0x2fa25f['addComponent'](_0x1bb076);const _0x641139=new Il(_0x5da02d,_0x2ea9a0,_0x2fa25f);return Le['set'](_0x2c0b05,_0x641139),_0x641139;}function Qr(_0x1b4647=pi){const _0x142feb=Le['get'](_0x1b4647);if(!_0x142feb&&_0x1b4647===pi&&$r())return wl();if(!_0x142feb)throw ge['create']('no-app',{'appName':_0x1b4647});return _0x142feb;}function l_(){return Array['from'](Le['values']());}async function h_(_0xd10679){let _0x37f24b=!0x1;const _0x17b32a=_0xd10679['name'];Le['has'](_0x17b32a)?(_0x37f24b=!0x0,Le['delete'](_0x17b32a)):_i['has'](_0x17b32a)&&_0xd10679['decRefCount']()<=0x0&&(_i['delete'](_0x17b32a),_0x37f24b=!0x0),_0x37f24b&&(await Promise['all'](_0xd10679['container']['getProviders']()['map'](_0x4ee422=>_0x4ee422['delete']())),_0xd10679['isDeleted']=!0x0);}function me(_0x38f94b,_0x3aa349,_0x5cfdae){let _0x387cc6=vl[_0x38f94b]??_0x38f94b;_0x5cfdae&&(_0x387cc6+='-'+_0x5cfdae);const _0x3d5bfd=_0x387cc6['match'](/\s|\//),_0x550b37=_0x3aa349['match'](/\s|\//);if(_0x3d5bfd||_0x550b37){const _0x14748e=['Unable\x20to\x20register\x20library\x20\x22'+_0x387cc6+'\x22\x20with\x20version\x20\x22'+_0x3aa349+'\x22:'];_0x3d5bfd&&_0x14748e['push']('library\x20name\x20\x22'+_0x387cc6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3d5bfd&&_0x550b37&&_0x14748e['push']('and'),_0x550b37&&_0x14748e['push']('version\x20name\x20\x22'+_0x3aa349+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x14748e['join']('\x20'));return;}et(new Me(_0x387cc6+'-version',()=>({'library':_0x387cc6,'version':_0x3aa349}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x295b6e,_0x2e5720)=>{switch(_0x2e5720){case 0x0:try{_0x295b6e['createObjectStore'](Rt);}catch(_0x723bd4){console['warn'](_0x723bd4);}}}})['catch'](_0x3e12cf=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3e12cf['message']});})),ei;}async function Sl(_0x2dee6a){try{const _0x2c8878=(await Jr())['transaction'](Rt),_0x14567a=await _0x2c8878['objectStore'](Rt)['get'](Xr(_0x2dee6a));return await _0x2c8878['done'],_0x14567a;}catch(_0x113b35){if(_0x113b35 instanceof Se)re['warn'](_0x113b35['message']);else{const _0x2afc7c=ge['create']('idb-get',{'originalErrorMessage':_0x113b35==null?void 0x0:_0x113b35['message']});re['warn'](_0x2afc7c['message']);}}}async function Ls(_0x5612fe,_0x53f438){try{const _0x2fab9a=(await Jr())['transaction'](Rt,'readwrite');await _0x2fab9a['objectStore'](Rt)['put'](_0x53f438,Xr(_0x5612fe)),await _0x2fab9a['done'];}catch(_0x54bf6f){if(_0x54bf6f instanceof Se)re['warn'](_0x54bf6f['message']);else{const _0x455247=ge['create']('idb-set',{'originalErrorMessage':_0x54bf6f==null?void 0x0:_0x54bf6f['message']});re['warn'](_0x455247['message']);}}}function Xr(_0x1fda6f){return _0x1fda6f['name']+'!'+_0x1fda6f['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x5df131){this['container']=_0x5df131,this['_heartbeatsCache']=null;const _0x2a2c87=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x2a2c87),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x858d4c=>(this['_heartbeatsCache']=_0x858d4c,_0x858d4c));}async['triggerHeartbeat'](){var _0x148773,_0x2f7402;try{const _0x165350=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xd86e9=xs();if(((_0x148773=this['_heartbeatsCache'])==null?void 0x0:_0x148773['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x2f7402=this['_heartbeatsCache'])==null?void 0x0:_0x2f7402['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xd86e9||this['_heartbeatsCache']['heartbeats']['some'](_0x1414f7=>_0x1414f7['date']===_0xd86e9))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xd86e9,'agent':_0x165350}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x9334ef=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x9334ef,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x21fd56){re['warn'](_0x21fd56);}}async['getHeartbeatsHeader'](){var _0x3a7c47;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3a7c47=this['_heartbeatsCache'])==null?void 0x0:_0x3a7c47['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5bcb74=xs(),{heartbeatsToSend:_0x5ea229,unsentEntries:_0x2db571}=kl(this['_heartbeatsCache']['heartbeats']),_0x4e7fa5=an(JSON['stringify']({'version':0x2,'heartbeats':_0x5ea229}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5bcb74,_0x2db571['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2db571,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4e7fa5;}catch(_0x19502b){return re['warn'](_0x19502b),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x3017ef,_0x581228=bl){const _0x550ad2=[];let _0x3a0b6f=_0x3017ef['slice']();for(const _0x25b22b of _0x3017ef){const _0x54d478=_0x550ad2['find'](_0x559e67=>_0x559e67['agent']===_0x25b22b['agent']);if(_0x54d478){if(_0x54d478['dates']['push'](_0x25b22b['date']),Fs(_0x550ad2)>_0x581228){_0x54d478['dates']['pop']();break;}}else{if(_0x550ad2['push']({'agent':_0x25b22b['agent'],'dates':[_0x25b22b['date']]}),Fs(_0x550ad2)>_0x581228){_0x550ad2['pop']();break;}}_0x3a0b6f=_0x3a0b6f['slice'](0x1);}return{'heartbeatsToSend':_0x550ad2,'unsentEntries':_0x3a0b6f};}class Nl{constructor(_0x1901ce){this['app']=_0x1901ce,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3e9baf=await Sl(this['app']);return _0x3e9baf!=null&&_0x3e9baf['heartbeats']?_0x3e9baf:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x105343){if(await this['_canUseIndexedDBPromise']){const _0x16d885=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x105343['lastSentHeartbeatDate']??_0x16d885['lastSentHeartbeatDate'],'heartbeats':_0x105343['heartbeats']});}else return;}async['add'](_0x3420ac){if(await this['_canUseIndexedDBPromise']){const _0x1dfcc6=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x3420ac['lastSentHeartbeatDate']??_0x1dfcc6['lastSentHeartbeatDate'],'heartbeats':[..._0x1dfcc6['heartbeats'],..._0x3420ac['heartbeats']]});}else return;}}function Fs(_0x215fda){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x215fda}))['length'];}function Pl(_0x4dbf9b){if(_0x4dbf9b['length']===0x0)return-0x1;let _0x55b47c=0x0,_0x55c5da=_0x4dbf9b[0x0]['date'];for(let _0x54cb72=0x1;_0x54cb72<_0x4dbf9b['length'];_0x54cb72++)_0x4dbf9b[_0x54cb72]['date']<_0x55c5da&&(_0x55c5da=_0x4dbf9b[_0x54cb72]['date'],_0x55b47c=_0x54cb72);return _0x55b47c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x5f3033){et(new Me('platform-logger',_0x1ac100=>new Gc(_0x1ac100),'PRIVATE')),et(new Me('heartbeat',_0x546238=>new Al(_0x546238),'PRIVATE')),me(fi,Ds,_0x5f3033),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x354948){Zr=_0x354948;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x163d63){this['domStorage_']=_0x163d63,this['prefix_']='firebase:';}['set'](_0x66d27e,_0x50c428){_0x50c428==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x66d27e)):this['domStorage_']['setItem'](this['prefixedName_'](_0x66d27e),O(_0x50c428));}['get'](_0x249e9d){const _0x17b4d8=this['domStorage_']['getItem'](this['prefixedName_'](_0x249e9d));return _0x17b4d8==null?null:bt(_0x17b4d8);}['remove'](_0x34eef5){this['domStorage_']['removeItem'](this['prefixedName_'](_0x34eef5));}['prefixedName_'](_0x1d6a8d){return this['prefix_']+_0x1d6a8d;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1e0d44,_0x271f12){_0x271f12==null?delete this['cache_'][_0x1e0d44]:this['cache_'][_0x1e0d44]=_0x271f12;}['get'](_0xe0a5d6){return Y(this['cache_'],_0xe0a5d6)?this['cache_'][_0xe0a5d6]:null;}['remove'](_0x4ea747){delete this['cache_'][_0x4ea747];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x120759){try{if(typeof window<'u'&&typeof window[_0x120759]<'u'){const _0x3669dc=window[_0x120759];return _0x3669dc['setItem']('firebase:sentinel','cache'),_0x3669dc['removeItem']('firebase:sentinel'),new xl(_0x3669dc);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0xe52872=0x1;return function(){return _0xe52872++;};}()),no=function(_0x287dc0){const _0xe40d2c=Tc(_0x287dc0),_0x3831fe=new Ec();_0x3831fe['update'](_0xe40d2c);const _0x4cbbc0=_0x3831fe['digest']();return Di['encodeByteArray'](_0x4cbbc0);},Bt=function(..._0x408899){let _0x37885b='';for(let _0x24a1b1=0x0;_0x24a1b1<_0x408899['length'];_0x24a1b1++){const _0x214897=_0x408899[_0x24a1b1];Array['isArray'](_0x214897)||_0x214897&&typeof _0x214897=='object'&&typeof _0x214897['length']=='number'?_0x37885b+=Bt['apply'](null,_0x214897):typeof _0x214897=='object'?_0x37885b+=O(_0x214897):_0x37885b+=_0x214897,_0x37885b+='\x20';}return _0x37885b;};let Et=null,Vs=!0x0;const Wl=function(_0x196cae,_0x4975c0){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x3af9cc){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x3a2f5f=Bt['apply'](null,_0x3af9cc);Et(_0x3a2f5f);}},Vt=function(_0x1e98c9){return function(..._0x200179){L(_0x1e98c9,..._0x200179);};},mi=function(..._0x1e788d){const _0x449556='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x1e788d);Qe['error'](_0x449556);},oe=function(..._0x4f2a4c){const _0x4d3a1='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4f2a4c);throw Qe['error'](_0x4d3a1),new Error(_0x4d3a1);},U=function(..._0x5f3cfe){const _0x5cd109='FIREBASE\x20WARNING:\x20'+Bt(..._0x5f3cfe);Qe['warn'](_0x5cd109);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x335ab3){return typeof _0x335ab3=='number'&&(_0x335ab3!==_0x335ab3||_0x335ab3===Number['POSITIVE_INFINITY']||_0x335ab3===Number['NEGATIVE_INFINITY']);},Vl=function(_0x272019){if(document['readyState']==='complete')_0x272019();else{let _0x22baeb=!0x1;const _0x2e92b1=function(){if(!document['body']){setTimeout(_0x2e92b1,Math['floor'](0xa));return;}_0x22baeb||(_0x22baeb=!0x0,_0x272019());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2e92b1,!0x1),window['addEventListener']('load',_0x2e92b1,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2e92b1();}),window['attachEvent']('onload',_0x2e92b1));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x496b62,_0x34adb8){if(_0x496b62===_0x34adb8)return 0x0;if(_0x496b62===xe||_0x34adb8===Ie)return-0x1;if(_0x34adb8===xe||_0x496b62===Ie)return 0x1;{const _0x53489c=Hs(_0x496b62),_0x27ef5c=Hs(_0x34adb8);return _0x53489c!==null?_0x27ef5c!==null?_0x53489c-_0x27ef5c===0x0?_0x496b62['length']-_0x34adb8['length']:_0x53489c-_0x27ef5c:-0x1:_0x27ef5c!==null?0x1:_0x496b62<_0x34adb8?-0x1:0x1;}},Hl=function(_0x262905,_0x17baa9){return _0x262905===_0x17baa9?0x0:_0x262905<_0x17baa9?-0x1:0x1;},pt=function(_0x359943,_0x372293){if(_0x372293&&_0x359943 in _0x372293)return _0x372293[_0x359943];throw new Error('Missing\x20required\x20key\x20('+_0x359943+')\x20in\x20object:\x20'+O(_0x372293));},Bi=function(_0x4f0408){if(typeof _0x4f0408!='object'||_0x4f0408===null)return O(_0x4f0408);const _0x1b5f24=[];for(const _0x5c97b0 in _0x4f0408)_0x1b5f24['push'](_0x5c97b0);_0x1b5f24['sort']();let _0x3390dc='{';for(let _0x3ab963=0x0;_0x3ab963<_0x1b5f24['length'];_0x3ab963++)_0x3ab963!==0x0&&(_0x3390dc+=','),_0x3390dc+=O(_0x1b5f24[_0x3ab963]),_0x3390dc+=':',_0x3390dc+=Bi(_0x4f0408[_0x1b5f24[_0x3ab963]]);return _0x3390dc+='}',_0x3390dc;},io=function(_0x555539,_0x550d42){const _0x5ca899=_0x555539['length'];if(_0x5ca899<=_0x550d42)return[_0x555539];const _0x4e9bb4=[];for(let _0x242764=0x0;_0x242764<_0x5ca899;_0x242764+=_0x550d42)_0x242764+_0x550d42>_0x5ca899?_0x4e9bb4['push'](_0x555539['substring'](_0x242764,_0x5ca899)):_0x4e9bb4['push'](_0x555539['substring'](_0x242764,_0x242764+_0x550d42));return _0x4e9bb4;};function x(_0x117e90,_0x21b3a4){for(const _0x163571 in _0x117e90)_0x117e90['hasOwnProperty'](_0x163571)&&_0x21b3a4(_0x163571,_0x117e90[_0x163571]);}const so=function(_0x2b3e94){f(!Wi(_0x2b3e94),'Invalid\x20JSON\x20number');const _0x1c73aa=0xb,_0x59ddf0=0x34,_0xb37dce=(0x1<<_0x1c73aa-0x1)-0x1;let _0x27b823,_0x3b769c,_0x24530c,_0x1465df,_0x4e0025;_0x2b3e94===0x0?(_0x3b769c=0x0,_0x24530c=0x0,_0x27b823=0x1/_0x2b3e94===-0x1/0x0?0x1:0x0):(_0x27b823=_0x2b3e94<0x0,_0x2b3e94=Math['abs'](_0x2b3e94),_0x2b3e94>=Math['pow'](0x2,0x1-_0xb37dce)?(_0x1465df=Math['min'](Math['floor'](Math['log'](_0x2b3e94)/Math['LN2']),_0xb37dce),_0x3b769c=_0x1465df+_0xb37dce,_0x24530c=Math['round'](_0x2b3e94*Math['pow'](0x2,_0x59ddf0-_0x1465df)-Math['pow'](0x2,_0x59ddf0))):(_0x3b769c=0x0,_0x24530c=Math['round'](_0x2b3e94/Math['pow'](0x2,0x1-_0xb37dce-_0x59ddf0))));const _0x54693e=[];for(_0x4e0025=_0x59ddf0;_0x4e0025;_0x4e0025-=0x1)_0x54693e['push'](_0x24530c%0x2?0x1:0x0),_0x24530c=Math['floor'](_0x24530c/0x2);for(_0x4e0025=_0x1c73aa;_0x4e0025;_0x4e0025-=0x1)_0x54693e['push'](_0x3b769c%0x2?0x1:0x0),_0x3b769c=Math['floor'](_0x3b769c/0x2);_0x54693e['push'](_0x27b823?0x1:0x0),_0x54693e['reverse']();const _0x45ed5a=_0x54693e['join']('');let _0x2bd6f1='';for(_0x4e0025=0x0;_0x4e0025<0x40;_0x4e0025+=0x8){let _0x8e10a4=parseInt(_0x45ed5a['substr'](_0x4e0025,0x8),0x2)['toString'](0x10);_0x8e10a4['length']===0x1&&(_0x8e10a4='0'+_0x8e10a4),_0x2bd6f1=_0x2bd6f1+_0x8e10a4;}return _0x2bd6f1['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2ff529,_0x4e1b63){let _0x138486='Unknown\x20Error';_0x2ff529==='too_big'?_0x138486='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2ff529==='permission_denied'?_0x138486='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2ff529==='unavailable'&&(_0x138486='The\x20service\x20is\x20unavailable');const _0x5bfc37=new Error(_0x2ff529+'\x20at\x20'+_0x4e1b63['_path']['toString']()+':\x20'+_0x138486);return _0x5bfc37['code']=_0x2ff529['toUpperCase'](),_0x5bfc37;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x35f42d){if(zl['test'](_0x35f42d)){const _0x58f482=Number(_0x35f42d);if(_0x58f482>=jl&&_0x58f482<=Kl)return _0x58f482;}return null;},lt=function(_0x40828b){try{_0x40828b();}catch(_0x598447){setTimeout(()=>{const _0x25666d=_0x598447['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x25666d),_0x598447;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x517d21,_0x5222cf){const _0x1e3ca0=setTimeout(_0x517d21,_0x5222cf);return typeof _0x1e3ca0=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1e3ca0):typeof _0x1e3ca0=='object'&&_0x1e3ca0['unref']&&_0x1e3ca0['unref'](),_0x1e3ca0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x5ddc1b,_0x553077){this['appCheckProvider']=_0x553077,this['appName']=_0x5ddc1b['name'],H(_0x5ddc1b)&&_0x5ddc1b['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5ddc1b['settings']['appCheckToken']),this['appCheck']=_0x553077==null?void 0x0:_0x553077['getImmediate']({'optional':!0x0}),this['appCheck']||_0x553077==null||_0x553077['get']()['then'](_0x310a22=>this['appCheck']=_0x310a22);}['getToken'](_0x3a521d){if(this['serverAppAppCheckToken']){if(_0x3a521d)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3a521d):new Promise((_0x4f1403,_0x48fbe1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3a521d)['then'](_0x4f1403,_0x48fbe1):_0x4f1403(null);},0x0);});}['addTokenChangeListener'](_0x2f5534){var _0x5e3870;(_0x5e3870=this['appCheckProvider'])==null||_0x5e3870['get']()['then'](_0x2a2c15=>_0x2a2c15['addTokenListener'](_0x2f5534));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x4030fa,_0x350217,_0xc9a76b){this['appName_']=_0x4030fa,this['firebaseOptions_']=_0x350217,this['authProvider_']=_0xc9a76b,this['auth_']=null,this['auth_']=_0xc9a76b['getImmediate']({'optional':!0x0}),this['auth_']||_0xc9a76b['onInit'](_0x3ba762=>this['auth_']=_0x3ba762);}['getToken'](_0x30366c){return this['auth_']?this['auth_']['getToken'](_0x30366c)['catch'](_0x151db2=>_0x151db2&&_0x151db2['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x151db2)):new Promise((_0x1519f6,_0xe644d4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x30366c)['then'](_0x1519f6,_0xe644d4):_0x1519f6(null);},0x0);});}['addTokenChangeListener'](_0x1f6356){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1f6356):this['authProvider_']['get']()['then'](_0x583931=>_0x583931['addAuthTokenListener'](_0x1f6356));}['removeTokenChangeListener'](_0x5b588f){this['authProvider_']['get']()['then'](_0xd6abc1=>_0xd6abc1['removeAuthTokenListener'](_0x5b588f));}['notifyForInvalidToken'](){let _0x9e2402='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x9e2402+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x9e2402+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x9e2402+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x9e2402);}}class tn{constructor(_0x498e5d){this['accessToken']=_0x498e5d;}['getToken'](_0x205ece){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x315c70){_0x315c70(this['accessToken']);}['removeTokenChangeListener'](_0x400b53){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x53c9f4,_0x585af1,_0x1ee8ca,_0x2b8cc5,_0x550314=!0x1,_0x4fbe90='',_0x21eae3=!0x1,_0x22c6ab=!0x1,_0x3c46d9=null){this['secure']=_0x585af1,this['namespace']=_0x1ee8ca,this['webSocketOnly']=_0x2b8cc5,this['nodeAdmin']=_0x550314,this['persistenceKey']=_0x4fbe90,this['includeNamespaceInQueryParams']=_0x21eae3,this['isUsingEmulator']=_0x22c6ab,this['emulatorOptions']=_0x3c46d9,this['_host']=_0x53c9f4['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x53c9f4)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2ead70){_0x2ead70!==this['internalHost']&&(this['internalHost']=_0x2ead70,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x30d949=this['toURLString']();return this['persistenceKey']&&(_0x30d949+='<'+this['persistenceKey']+'>'),_0x30d949;}['toURLString'](){const _0x5da135=this['secure']?'https://':'http://',_0xd22bc9=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5da135+this['host']+'/'+_0xd22bc9;}}function Xl(_0x2cf266){return _0x2cf266['host']!==_0x2cf266['internalHost']||_0x2cf266['isCustomHost']()||_0x2cf266['includeNamespaceInQueryParams'];}function go(_0x268701,_0x3298ff,_0x4e8213){f(typeof _0x3298ff=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4e8213=='object','typeof\x20params\x20must\x20==\x20object');let _0x570ff2;if(_0x3298ff===fo)_0x570ff2=(_0x268701['secure']?'wss://':'ws://')+_0x268701['internalHost']+'/.ws?';else{if(_0x3298ff===po)_0x570ff2=(_0x268701['secure']?'https://':'http://')+_0x268701['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3298ff);}Xl(_0x268701)&&(_0x4e8213['ns']=_0x268701['namespace']);const _0x3dd3a6=[];return x(_0x4e8213,(_0x5aea1e,_0x474da2)=>{_0x3dd3a6['push'](_0x5aea1e+'='+_0x474da2);}),_0x570ff2+_0x3dd3a6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x267c85,_0x555b79=0x1){Y(this['counters_'],_0x267c85)||(this['counters_'][_0x267c85]=0x0),this['counters_'][_0x267c85]+=_0x555b79;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0xaeb4b3){const _0x248535=_0xaeb4b3['toString']();return ti[_0x248535]||(ti[_0x248535]=new Zl()),ti[_0x248535];}function eh(_0x597800,_0x527208){const _0x2e5bae=_0x597800['toString']();return ni[_0x2e5bae]||(ni[_0x2e5bae]=_0x527208()),ni[_0x2e5bae];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x2284fe){this['onMessage_']=_0x2284fe,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xf2d1da,_0x3f9eaa){this['closeAfterResponse']=_0xf2d1da,this['onClose']=_0x3f9eaa,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3a6d55,_0x41a11a){for(this['pendingResponses'][_0x3a6d55]=_0x41a11a;this['pendingResponses'][this['currentResponseNum']];){const _0x2e369b=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x41b782=0x0;_0x41b782<_0x2e369b['length'];++_0x41b782)_0x2e369b[_0x41b782]&&lt(()=>{this['onMessage_'](_0x2e369b[_0x41b782]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2cb6d5,_0x51e1d1,_0x20b3cf,_0xfdd50a,_0x1bc81b,_0x11afa5,_0x8e4e3c){this['connId']=_0x2cb6d5,this['repoInfo']=_0x51e1d1,this['applicationId']=_0x20b3cf,this['appCheckToken']=_0xfdd50a,this['authToken']=_0x1bc81b,this['transportSessionId']=_0x11afa5,this['lastSessionId']=_0x8e4e3c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2cb6d5),this['stats_']=Hi(_0x51e1d1),this['urlFn']=_0xc60789=>(this['appCheckToken']&&(_0xc60789[yi]=this['appCheckToken']),go(_0x51e1d1,po,_0xc60789));}['open'](_0x4a48c4,_0x6a45d3){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x6a45d3,this['myPacketOrderer']=new th(_0x4a48c4),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x139510)=>{const [_0x3eca0a,_0x5c8884,_0x9b043d,_0x58cdf1,_0x50f112]=_0x139510;if(this['incrementIncomingBytes_'](_0x139510),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x3eca0a===$s)this['id']=_0x5c8884,this['password']=_0x9b043d;else{if(_0x3eca0a===nh)_0x5c8884?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5c8884,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x3eca0a);}}},(..._0x383c35)=>{const [_0x590453,_0x36795c]=_0x383c35;this['incrementIncomingBytes_'](_0x383c35),this['myPacketOrderer']['handleResponse'](_0x590453,_0x36795c);},()=>{this['onClosed_']();},this['urlFn']);const _0x1a2be5={};_0x1a2be5[$s]='t',_0x1a2be5[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1a2be5[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1a2be5[ro]=Vi,this['transportSessionId']&&(_0x1a2be5[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x1a2be5[ho]=this['lastSessionId']),this['applicationId']&&(_0x1a2be5[uo]=this['applicationId']),this['appCheckToken']&&(_0x1a2be5[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x1a2be5[ao]=co);const _0xed2e3=this['urlFn'](_0x1a2be5);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xed2e3),this['scriptTagHolder']['addTag'](_0xed2e3,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x32991a){const _0x54f156=O(_0x32991a);this['bytesSent']+=_0x54f156['length'],this['stats_']['incrementCounter']('bytes_sent',_0x54f156['length']);const _0x3167b6=Br(_0x54f156),_0x258764=io(_0x3167b6,hh);for(let _0x5bb42b=0x0;_0x5bb42b<_0x258764['length'];_0x5bb42b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x258764['length'],_0x258764[_0x5bb42b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2b4c80,_0x54bc0c){this['myDisconnFrame']=document['createElement']('iframe');const _0x4b7bc3={};_0x4b7bc3[lh]='t',_0x4b7bc3[mo]=_0x2b4c80,_0x4b7bc3[yo]=_0x54bc0c,this['myDisconnFrame']['src']=this['urlFn'](_0x4b7bc3),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1683f4){const _0x2c0849=O(_0x1683f4)['length'];this['bytesReceived']+=_0x2c0849,this['stats_']['incrementCounter']('bytes_received',_0x2c0849);}}class $i{constructor(_0x175fc3,_0x1a87cd,_0x54fe82,_0xedca1b){this['onDisconnect']=_0x54fe82,this['urlFn']=_0xedca1b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x175fc3,window[sh+this['uniqueCallbackIdentifier']]=_0x1a87cd,this['myIFrame']=$i['createIFrame_']();let _0x4bc1e1='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4bc1e1='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x460dca='<html><body>'+_0x4bc1e1+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x460dca),this['myIFrame']['doc']['close']();}catch(_0x23a3e1){L('frame\x20writing\x20exception'),_0x23a3e1['stack']&&L(_0x23a3e1['stack']),L(_0x23a3e1);}}}static['createIFrame_'](){const _0x4016f3=document['createElement']('iframe');if(_0x4016f3['style']['display']='none',document['body']){document['body']['appendChild'](_0x4016f3);try{_0x4016f3['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x323d52=document['domain'];_0x4016f3['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x323d52+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4016f3['contentDocument']?_0x4016f3['doc']=_0x4016f3['contentDocument']:_0x4016f3['contentWindow']?_0x4016f3['doc']=_0x4016f3['contentWindow']['document']:_0x4016f3['document']&&(_0x4016f3['doc']=_0x4016f3['document']),_0x4016f3;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5aaf0f=this['onDisconnect'];_0x5aaf0f&&(this['onDisconnect']=null,_0x5aaf0f());}['startLongPoll'](_0x24e20a,_0x3b7d8d){for(this['myID']=_0x24e20a,this['myPW']=_0x3b7d8d,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x31d2ef={};_0x31d2ef[mo]=this['myID'],_0x31d2ef[yo]=this['myPW'],_0x31d2ef[vo]=this['currentSerial'];let _0x460cd9=this['urlFn'](_0x31d2ef),_0x34c75f='',_0x17c1fa=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x34c75f['length']<=Eo;){const _0x460bbc=this['pendingSegs']['shift']();_0x34c75f=_0x34c75f+'&'+oh+_0x17c1fa+'='+_0x460bbc['seg']+'&'+ah+_0x17c1fa+'='+_0x460bbc['ts']+'&'+ch+_0x17c1fa+'='+_0x460bbc['d'],_0x17c1fa++;}return _0x460cd9=_0x460cd9+_0x34c75f,this['addLongPollTag_'](_0x460cd9,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x4f70f9,_0x4727e0,_0x5f1c4a){this['pendingSegs']['push']({'seg':_0x4f70f9,'ts':_0x4727e0,'d':_0x5f1c4a}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x7d41bf,_0x244b8b){this['outstandingRequests']['add'](_0x244b8b);const _0x1a53b1=()=>{this['outstandingRequests']['delete'](_0x244b8b),this['newRequest_']();},_0x5eb68f=setTimeout(_0x1a53b1,Math['floor'](uh)),_0x30d221=()=>{clearTimeout(_0x5eb68f),_0x1a53b1();};this['addTag'](_0x7d41bf,_0x30d221);}['addTag'](_0xb0da7e,_0x28adb2){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4588b7=this['myIFrame']['doc']['createElement']('script');_0x4588b7['type']='text/javascript',_0x4588b7['async']=!0x0,_0x4588b7['src']=_0xb0da7e,_0x4588b7['onload']=_0x4588b7['onreadystatechange']=function(){const _0x2aa1bc=_0x4588b7['readyState'];(!_0x2aa1bc||_0x2aa1bc==='loaded'||_0x2aa1bc==='complete')&&(_0x4588b7['onload']=_0x4588b7['onreadystatechange']=null,_0x4588b7['parentNode']&&_0x4588b7['parentNode']['removeChild'](_0x4588b7),_0x28adb2());},_0x4588b7['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xb0da7e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4588b7);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x4a8eb9,_0x211605,_0x238146,_0x6f8804,_0x182d2f,_0x341cf9,_0x5d94f6){this['connId']=_0x4a8eb9,this['applicationId']=_0x238146,this['appCheckToken']=_0x6f8804,this['authToken']=_0x182d2f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x211605),this['connURL']=G['connectionURL_'](_0x211605,_0x341cf9,_0x5d94f6,_0x6f8804,_0x238146),this['nodeAdmin']=_0x211605['nodeAdmin'];}static['connectionURL_'](_0x1d92b7,_0x34157d,_0x2a5234,_0x2d1e1f,_0x592484){const _0x4789fe={};return _0x4789fe[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x4789fe[ao]=co),_0x34157d&&(_0x4789fe[oo]=_0x34157d),_0x2a5234&&(_0x4789fe[ho]=_0x2a5234),_0x2d1e1f&&(_0x4789fe[yi]=_0x2d1e1f),_0x592484&&(_0x4789fe[uo]=_0x592484),go(_0x1d92b7,fo,_0x4789fe);}['open'](_0x2e30a1,_0x53809a){this['onDisconnect']=_0x53809a,this['onMessage']=_0x2e30a1,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x461611;dc(),this['mySock']=new hn(this['connURL'],[],_0x461611);}catch(_0x162c6c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5e5a3e=_0x162c6c['message']||_0x162c6c['data'];_0x5e5a3e&&this['log_'](_0x5e5a3e),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4ff1ba=>{this['handleIncomingFrame'](_0x4ff1ba);},this['mySock']['onerror']=_0x202be4=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x6cec87=_0x202be4['message']||_0x202be4['data'];_0x6cec87&&this['log_'](_0x6cec87),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5ad528=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1b508a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x26da07=navigator['userAgent']['match'](_0x1b508a);_0x26da07&&_0x26da07['length']>0x1&&parseFloat(_0x26da07[0x1])<4.4&&(_0x5ad528=!0x0);}return!_0x5ad528&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x38884e){if(this['frames']['push'](_0x38884e),this['frames']['length']===this['totalFrames']){const _0x11d9a0=this['frames']['join']('');this['frames']=null;const _0x543066=bt(_0x11d9a0);this['onMessage'](_0x543066);}}['handleNewFrameCount_'](_0x3559f8){this['totalFrames']=_0x3559f8,this['frames']=[];}['extractFrameCount_'](_0x4011b9){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4011b9['length']<=0x6){const _0x427c90=Number(_0x4011b9);if(!isNaN(_0x427c90))return this['handleNewFrameCount_'](_0x427c90),null;}return this['handleNewFrameCount_'](0x1),_0x4011b9;}['handleIncomingFrame'](_0x3077fd){if(this['mySock']===null)return;const _0x9a8f54=_0x3077fd['data'];if(this['bytesReceived']+=_0x9a8f54['length'],this['stats_']['incrementCounter']('bytes_received',_0x9a8f54['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x9a8f54);else{const _0x57b96c=this['extractFrameCount_'](_0x9a8f54);_0x57b96c!==null&&this['appendFrame_'](_0x57b96c);}}['send'](_0x2de213){this['resetKeepAlive']();const _0x30a0e1=O(_0x2de213);this['bytesSent']+=_0x30a0e1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x30a0e1['length']);const _0x3478b2=io(_0x30a0e1,fh);_0x3478b2['length']>0x1&&this['sendString_'](String(_0x3478b2['length']));for(let _0x2899b5=0x0;_0x2899b5<_0x3478b2['length'];_0x2899b5++)this['sendString_'](_0x3478b2[_0x2899b5]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x4fa3f6){try{this['mySock']['send'](_0x4fa3f6);}catch(_0x240798){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x240798['message']||_0x240798['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x107332){this['initTransports_'](_0x107332);}['initTransports_'](_0x5c4e95){const _0x4b5569=G&&G['isAvailable']();let _0x710a04=_0x4b5569&&!G['previouslyFailed']();if(_0x5c4e95['webSocketOnly']&&(_0x4b5569||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x710a04=!0x0),_0x710a04)this['transports_']=[G];else{const _0x550292=this['transports_']=[];for(const _0x4722bb of At['ALL_TRANSPORTS'])_0x4722bb&&_0x4722bb['isAvailable']()&&_0x550292['push'](_0x4722bb);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x44c931,_0x2069f3,_0x222647,_0x51fe71,_0x8b3856,_0x50b27a,_0x1f45ab,_0x4420d2,_0xd328b3,_0x58f80b){this['id']=_0x44c931,this['repoInfo_']=_0x2069f3,this['applicationId_']=_0x222647,this['appCheckToken_']=_0x51fe71,this['authToken_']=_0x8b3856,this['onMessage_']=_0x50b27a,this['onReady_']=_0x1f45ab,this['onDisconnect_']=_0x4420d2,this['onKill_']=_0xd328b3,this['lastSessionId']=_0x58f80b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x2069f3),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x39f7df=this['transportManager_']['initialTransport']();this['conn_']=new _0x39f7df(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x39f7df['responsesRequiredToBeHealthy']||0x0;const _0x51ec3b=this['connReceiver_'](this['conn_']),_0x10b103=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x51ec3b,_0x10b103);},Math['floor'](0x0));const _0x4cc95f=_0x39f7df['healthyTimeout']||0x0;_0x4cc95f>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4cc95f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x274df4){return _0x24fe90=>{_0x274df4===this['conn_']?this['onConnectionLost_'](_0x24fe90):_0x274df4===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2d399b){return _0x315646=>{this['state_']!==0x2&&(_0x2d399b===this['rx_']?this['onPrimaryMessageReceived_'](_0x315646):_0x2d399b===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x315646):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2ded82){const _0x201464={'t':'d','d':_0x2ded82};this['sendData_'](_0x201464);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1e979d){if(ii in _0x1e979d){const _0x4f0289=_0x1e979d[ii];_0x4f0289===js?this['upgradeIfSecondaryHealthy_']():_0x4f0289===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4f0289===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x4f8644){const _0x27607a=pt('t',_0x4f8644),_0x443d23=pt('d',_0x4f8644);if(_0x27607a==='c')this['onSecondaryControl_'](_0x443d23);else{if(_0x27607a==='d')this['pendingDataMessages']['push'](_0x443d23);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x27607a);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2e9eec){const _0x1cfdf8=pt('t',_0x2e9eec),_0x58107a=pt('d',_0x2e9eec);_0x1cfdf8==='c'?this['onControl_'](_0x58107a):_0x1cfdf8==='d'&&this['onDataMessage_'](_0x58107a);}['onDataMessage_'](_0x43ddbf){this['onPrimaryResponse_'](),this['onMessage_'](_0x43ddbf);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x489be1){const _0x3f9afa=pt(ii,_0x489be1);if(Gs in _0x489be1){const _0x57d319=_0x489be1[Gs];if(_0x3f9afa===Ih){const _0x1525b4={..._0x57d319};this['repoInfo_']['isUsingEmulator']&&(_0x1525b4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1525b4);}else{if(_0x3f9afa===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1f94a0=0x0;_0x1f94a0<this['pendingDataMessages']['length'];++_0x1f94a0)this['onDataMessage_'](this['pendingDataMessages'][_0x1f94a0]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3f9afa===vh?this['onConnectionShutdown_'](_0x57d319):_0x3f9afa===qs?this['onReset_'](_0x57d319):_0x3f9afa===Eh?mi('Server\x20Error:\x20'+_0x57d319):_0x3f9afa===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x3f9afa);}}}['onHandshake_'](_0x5e3462){const _0x25ae6f=_0x5e3462['ts'],_0x20a52b=_0x5e3462['v'],_0x28e1c2=_0x5e3462['h'];this['sessionId']=_0x5e3462['s'],this['repoInfo_']['host']=_0x28e1c2,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x25ae6f),Vi!==_0x20a52b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5440ff=this['transportManager_']['upgradeTransport']();_0x5440ff&&this['startUpgrade_'](_0x5440ff);}['startUpgrade_'](_0x349aba){this['secondaryConn_']=new _0x349aba(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x349aba['responsesRequiredToBeHealthy']||0x0;const _0x45462e=this['connReceiver_'](this['secondaryConn_']),_0x537231=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x45462e,_0x537231),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x1acb78){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1acb78),this['repoInfo_']['host']=_0x1acb78,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2d65af,_0x4b133d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2d65af,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4b133d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4b0cc5=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4b0cc5||this['rx_']===_0x4b0cc5)&&this['close']();}['onConnectionLost_'](_0x23eae4){this['conn_']=null,!_0x23eae4&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x28084f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x28084f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x75a96e){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x75a96e);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x455ceb,_0x4e8ab5,_0x5ff7bc,_0x2de019){}['merge'](_0x3d976f,_0x19c39e,_0x221980,_0x56a00f){}['refreshAuthToken'](_0x3d3abd){}['refreshAppCheckToken'](_0x11ae14){}['onDisconnectPut'](_0x39c523,_0x1e51c0,_0x34046d){}['onDisconnectMerge'](_0x421ce0,_0x5965b8,_0x234cf5){}['onDisconnectCancel'](_0x3c0d82,_0x457870){}['reportStats'](_0x1cca9c){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x5e2b68){this['allowedEvents_']=_0x5e2b68,this['listeners_']={},f(Array['isArray'](_0x5e2b68)&&_0x5e2b68['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x56a837,..._0x404f74){if(Array['isArray'](this['listeners_'][_0x56a837])){const _0x51a8d0=[...this['listeners_'][_0x56a837]];for(let _0x1c22e4=0x0;_0x1c22e4<_0x51a8d0['length'];_0x1c22e4++)_0x51a8d0[_0x1c22e4]['callback']['apply'](_0x51a8d0[_0x1c22e4]['context'],_0x404f74);}}['on'](_0xd45713,_0x4fcbb1,_0x21ada3){this['validateEventType_'](_0xd45713),this['listeners_'][_0xd45713]=this['listeners_'][_0xd45713]||[],this['listeners_'][_0xd45713]['push']({'callback':_0x4fcbb1,'context':_0x21ada3});const _0x2e6f6d=this['getInitialEvent'](_0xd45713);_0x2e6f6d&&_0x4fcbb1['apply'](_0x21ada3,_0x2e6f6d);}['off'](_0x3e2577,_0x4122c6,_0x459012){this['validateEventType_'](_0x3e2577);const _0x4f2a66=this['listeners_'][_0x3e2577]||[];for(let _0x4a8461=0x0;_0x4a8461<_0x4f2a66['length'];_0x4a8461++)if(_0x4f2a66[_0x4a8461]['callback']===_0x4122c6&&(!_0x459012||_0x459012===_0x4f2a66[_0x4a8461]['context'])){_0x4f2a66['splice'](_0x4a8461,0x1);return;}}['validateEventType_'](_0x33e01f){f(this['allowedEvents_']['find'](_0x190fdd=>_0x190fdd===_0x33e01f),'Unknown\x20event:\x20'+_0x33e01f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2e5432){return f(_0x2e5432==='online','Unknown\x20event\x20type:\x20'+_0x2e5432),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x46299d,_0x2e5147){if(_0x2e5147===void 0x0){this['pieces_']=_0x46299d['split']('/');let _0x31773c=0x0;for(let _0x2e152b=0x0;_0x2e152b<this['pieces_']['length'];_0x2e152b++)this['pieces_'][_0x2e152b]['length']>0x0&&(this['pieces_'][_0x31773c]=this['pieces_'][_0x2e152b],_0x31773c++);this['pieces_']['length']=_0x31773c,this['pieceNum_']=0x0;}else this['pieces_']=_0x46299d,this['pieceNum_']=_0x2e5147;}['toString'](){let _0x407b53='';for(let _0x52573d=this['pieceNum_'];_0x52573d<this['pieces_']['length'];_0x52573d++)this['pieces_'][_0x52573d]!==''&&(_0x407b53+='/'+this['pieces_'][_0x52573d]);return _0x407b53||'/';}}function w(){return new C('');}function y(_0x3f95e0){return _0x3f95e0['pieceNum_']>=_0x3f95e0['pieces_']['length']?null:_0x3f95e0['pieces_'][_0x3f95e0['pieceNum_']];}function we(_0x4b5124){return _0x4b5124['pieces_']['length']-_0x4b5124['pieceNum_'];}function b(_0x3b6674){let _0x371ccf=_0x3b6674['pieceNum_'];return _0x371ccf<_0x3b6674['pieces_']['length']&&_0x371ccf++,new C(_0x3b6674['pieces_'],_0x371ccf);}function Gi(_0x4ad6f8){return _0x4ad6f8['pieceNum_']<_0x4ad6f8['pieces_']['length']?_0x4ad6f8['pieces_'][_0x4ad6f8['pieces_']['length']-0x1]:null;}function Ch(_0x5ca9d2){let _0x3865b8='';for(let _0x4f97ba=_0x5ca9d2['pieceNum_'];_0x4f97ba<_0x5ca9d2['pieces_']['length'];_0x4f97ba++)_0x5ca9d2['pieces_'][_0x4f97ba]!==''&&(_0x3865b8+='/'+encodeURIComponent(String(_0x5ca9d2['pieces_'][_0x4f97ba])));return _0x3865b8||'/';}function kt(_0x56922c,_0x23fd3f=0x0){return _0x56922c['pieces_']['slice'](_0x56922c['pieceNum_']+_0x23fd3f);}function To(_0x2cbe36){if(_0x2cbe36['pieceNum_']>=_0x2cbe36['pieces_']['length'])return null;const _0x2c877e=[];for(let _0x57b1bb=_0x2cbe36['pieceNum_'];_0x57b1bb<_0x2cbe36['pieces_']['length']-0x1;_0x57b1bb++)_0x2c877e['push'](_0x2cbe36['pieces_'][_0x57b1bb]);return new C(_0x2c877e,0x0);}function A(_0x4acfdb,_0x51288e){const _0x23bfdd=[];for(let _0x3605c5=_0x4acfdb['pieceNum_'];_0x3605c5<_0x4acfdb['pieces_']['length'];_0x3605c5++)_0x23bfdd['push'](_0x4acfdb['pieces_'][_0x3605c5]);if(_0x51288e instanceof C){for(let _0xfe4c38=_0x51288e['pieceNum_'];_0xfe4c38<_0x51288e['pieces_']['length'];_0xfe4c38++)_0x23bfdd['push'](_0x51288e['pieces_'][_0xfe4c38]);}else{const _0xb7264a=_0x51288e['split']('/');for(let _0x5c9702=0x0;_0x5c9702<_0xb7264a['length'];_0x5c9702++)_0xb7264a[_0x5c9702]['length']>0x0&&_0x23bfdd['push'](_0xb7264a[_0x5c9702]);}return new C(_0x23bfdd,0x0);}function v(_0x5ee740){return _0x5ee740['pieceNum_']>=_0x5ee740['pieces_']['length'];}function F(_0x1ce794,_0x320bdb){const _0x1b8340=y(_0x1ce794),_0x385f4f=y(_0x320bdb);if(_0x1b8340===null)return _0x320bdb;if(_0x1b8340===_0x385f4f)return F(b(_0x1ce794),b(_0x320bdb));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x320bdb+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1ce794+')');}function Th(_0x38aed8,_0x22c45e){const _0x3345af=kt(_0x38aed8,0x0),_0x1e0a5d=kt(_0x22c45e,0x0);for(let _0x4ebe24=0x0;_0x4ebe24<_0x3345af['length']&&_0x4ebe24<_0x1e0a5d['length'];_0x4ebe24++){const _0x262113=He(_0x3345af[_0x4ebe24],_0x1e0a5d[_0x4ebe24]);if(_0x262113!==0x0)return _0x262113;}return _0x3345af['length']===_0x1e0a5d['length']?0x0:_0x3345af['length']<_0x1e0a5d['length']?-0x1:0x1;}function qi(_0x1fd332,_0x526d27){if(we(_0x1fd332)!==we(_0x526d27))return!0x1;for(let _0x556468=_0x1fd332['pieceNum_'],_0x13ba02=_0x526d27['pieceNum_'];_0x556468<=_0x1fd332['pieces_']['length'];_0x556468++,_0x13ba02++)if(_0x1fd332['pieces_'][_0x556468]!==_0x526d27['pieces_'][_0x13ba02])return!0x1;return!0x0;}function $(_0x5b413f,_0x22b2fa){let _0x2941d8=_0x5b413f['pieceNum_'],_0x302327=_0x22b2fa['pieceNum_'];if(we(_0x5b413f)>we(_0x22b2fa))return!0x1;for(;_0x2941d8<_0x5b413f['pieces_']['length'];){if(_0x5b413f['pieces_'][_0x2941d8]!==_0x22b2fa['pieces_'][_0x302327])return!0x1;++_0x2941d8,++_0x302327;}return!0x0;}class Sh{constructor(_0x20a510,_0x2b3bab){this['errorPrefix_']=_0x2b3bab,this['parts_']=kt(_0x20a510,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2d3c93=0x0;_0x2d3c93<this['parts_']['length'];_0x2d3c93++)this['byteLength_']+=Pn(this['parts_'][_0x2d3c93]);So(this);}}function bh(_0x41c399,_0x2abc67){_0x41c399['parts_']['length']>0x0&&(_0x41c399['byteLength_']+=0x1),_0x41c399['parts_']['push'](_0x2abc67),_0x41c399['byteLength_']+=Pn(_0x2abc67),So(_0x41c399);}function Rh(_0x1a20b8){const _0x5bc5b7=_0x1a20b8['parts_']['pop']();_0x1a20b8['byteLength_']-=Pn(_0x5bc5b7),_0x1a20b8['parts_']['length']>0x0&&(_0x1a20b8['byteLength_']-=0x1);}function So(_0x4b22b6){if(_0x4b22b6['byteLength_']>Js)throw new Error(_0x4b22b6['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x4b22b6['byteLength_']+').');if(_0x4b22b6['parts_']['length']>Qs)throw new Error(_0x4b22b6['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x4b22b6));}function Ne(_0x2bcf6b){return _0x2bcf6b['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2bcf6b['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x57d99e,_0x430917;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x430917='visibilitychange',_0x57d99e='hidden'):typeof document['mozHidden']<'u'?(_0x430917='mozvisibilitychange',_0x57d99e='mozHidden'):typeof document['msHidden']<'u'?(_0x430917='msvisibilitychange',_0x57d99e='msHidden'):typeof document['webkitHidden']<'u'&&(_0x430917='webkitvisibilitychange',_0x57d99e='webkitHidden')),this['visible_']=!0x0,_0x430917&&document['addEventListener'](_0x430917,()=>{const _0x3e562e=!document[_0x57d99e];_0x3e562e!==this['visible_']&&(this['visible_']=_0x3e562e,this['trigger']('visible',_0x3e562e));},!0x1);}['getInitialEvent'](_0x160ad4){return f(_0x160ad4==='visible','Unknown\x20event\x20type:\x20'+_0x160ad4),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x509d95,_0x1a8984,_0x3dd544,_0x5ba6b2,_0x3280b1,_0x4322fd,_0x2cf6ab,_0x115143){if(super(),this['repoInfo_']=_0x509d95,this['applicationId_']=_0x1a8984,this['onDataUpdate_']=_0x3dd544,this['onConnectStatus_']=_0x5ba6b2,this['onServerInfoUpdate_']=_0x3280b1,this['authTokenProvider_']=_0x4322fd,this['appCheckTokenProvider_']=_0x2cf6ab,this['authOverride_']=_0x115143,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x115143)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x509d95['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x35d360,_0x124c5e,_0x381c5a){const _0x62191e=++this['requestNumber_'],_0x3c429e={'r':_0x62191e,'a':_0x35d360,'b':_0x124c5e};this['log_'](O(_0x3c429e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3c429e),_0x381c5a&&(this['requestCBHash_'][_0x62191e]=_0x381c5a);}['get'](_0x2867d7){this['initConnection_']();const _0x339468=new Ve(),_0x1b566b={'action':'g','request':{'p':_0x2867d7['_path']['toString'](),'q':_0x2867d7['_queryObject']},'onComplete':_0x24edeb=>{const _0x3c7977=_0x24edeb['d'];_0x24edeb['s']==='ok'?_0x339468['resolve'](_0x3c7977):_0x339468['reject'](_0x3c7977);}};this['outstandingGets_']['push'](_0x1b566b),this['outstandingGetCount_']++;const _0x42a33b=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x42a33b),_0x339468['promise'];}['listen'](_0x2730b0,_0x122eb3,_0x3f0a25,_0x169144){this['initConnection_']();const _0x4a59b8=_0x2730b0['_queryIdentifier'],_0x497ddd=_0x2730b0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x497ddd+'\x20'+_0x4a59b8),this['listens']['has'](_0x497ddd)||this['listens']['set'](_0x497ddd,new Map()),f(_0x2730b0['_queryParams']['isDefault']()||!_0x2730b0['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x497ddd)['has'](_0x4a59b8),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x19a459={'onComplete':_0x169144,'hashFn':_0x122eb3,'query':_0x2730b0,'tag':_0x3f0a25};this['listens']['get'](_0x497ddd)['set'](_0x4a59b8,_0x19a459),this['connected_']&&this['sendListen_'](_0x19a459);}['sendGet_'](_0x2f9154){const _0x14baca=this['outstandingGets_'][_0x2f9154];this['sendRequest']('g',_0x14baca['request'],_0x3993d2=>{delete this['outstandingGets_'][_0x2f9154],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x14baca['onComplete']&&_0x14baca['onComplete'](_0x3993d2);});}['sendListen_'](_0x3afc91){const _0x39c50d=_0x3afc91['query'],_0x287f35=_0x39c50d['_path']['toString'](),_0x101c27=_0x39c50d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x287f35+'\x20for\x20'+_0x101c27);const _0x3b5dd3={'p':_0x287f35},_0x10c586='q';_0x3afc91['tag']&&(_0x3b5dd3['q']=_0x39c50d['_queryObject'],_0x3b5dd3['t']=_0x3afc91['tag']),_0x3b5dd3['h']=_0x3afc91['hashFn'](),this['sendRequest'](_0x10c586,_0x3b5dd3,_0x47380c=>{const _0x11c876=_0x47380c['d'],_0x371902=_0x47380c['s'];ie['warnOnListenWarnings_'](_0x11c876,_0x39c50d),(this['listens']['get'](_0x287f35)&&this['listens']['get'](_0x287f35)['get'](_0x101c27))===_0x3afc91&&(this['log_']('listen\x20response',_0x47380c),_0x371902!=='ok'&&this['removeListen_'](_0x287f35,_0x101c27),_0x3afc91['onComplete']&&_0x3afc91['onComplete'](_0x371902,_0x11c876));});}static['warnOnListenWarnings_'](_0x2778ca,_0x5ae7ea){if(_0x2778ca&&typeof _0x2778ca=='object'&&Y(_0x2778ca,'w')){const _0x11b907=Oe(_0x2778ca,'w');if(Array['isArray'](_0x11b907)&&~_0x11b907['indexOf']('no_index')){const _0x270f59='\x22.indexOn\x22:\x20\x22'+_0x5ae7ea['_queryParams']['getIndex']()['toString']()+'\x22',_0x101285=_0x5ae7ea['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x270f59+'\x20at\x20'+_0x101285+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x54269d){this['authToken_']=_0x54269d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x54269d);}['reduceReconnectDelayIfAdminCredential_'](_0x4118d5){(_0x4118d5&&_0x4118d5['length']===0x28||vc(_0x4118d5))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x317439){this['appCheckToken_']=_0x317439,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x45fb10=this['authToken_'],_0x21d0d2=yc(_0x45fb10)?'auth':'gauth',_0x28ecc7={'cred':_0x45fb10};this['authOverride_']===null?_0x28ecc7['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x28ecc7['authvar']=this['authOverride_']),this['sendRequest'](_0x21d0d2,_0x28ecc7,_0xb888f8=>{const _0x1425f3=_0xb888f8['s'],_0x1e9467=_0xb888f8['d']||'error';this['authToken_']===_0x45fb10&&(_0x1425f3==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x1425f3,_0x1e9467));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1dd549=>{const _0x23fa1d=_0x1dd549['s'],_0x3e2d39=_0x1dd549['d']||'error';_0x23fa1d==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x23fa1d,_0x3e2d39);});}['unlisten'](_0x8e1eeb,_0x502ed3){const _0x1a98a8=_0x8e1eeb['_path']['toString'](),_0x23ac06=_0x8e1eeb['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1a98a8+'\x20'+_0x23ac06),f(_0x8e1eeb['_queryParams']['isDefault']()||!_0x8e1eeb['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1a98a8,_0x23ac06)&&this['connected_']&&this['sendUnlisten_'](_0x1a98a8,_0x23ac06,_0x8e1eeb['_queryObject'],_0x502ed3);}['sendUnlisten_'](_0x4f99d5,_0x78051d,_0x1556f9,_0x4566af){this['log_']('Unlisten\x20on\x20'+_0x4f99d5+'\x20for\x20'+_0x78051d);const _0xae6a58={'p':_0x4f99d5},_0x48ae0c='n';_0x4566af&&(_0xae6a58['q']=_0x1556f9,_0xae6a58['t']=_0x4566af),this['sendRequest'](_0x48ae0c,_0xae6a58);}['onDisconnectPut'](_0x9caa28,_0x1edede,_0x59ca53){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x9caa28,_0x1edede,_0x59ca53):this['onDisconnectRequestQueue_']['push']({'pathString':_0x9caa28,'action':'o','data':_0x1edede,'onComplete':_0x59ca53});}['onDisconnectMerge'](_0x541e66,_0x30996a,_0x2a3b2a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x541e66,_0x30996a,_0x2a3b2a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x541e66,'action':'om','data':_0x30996a,'onComplete':_0x2a3b2a});}['onDisconnectCancel'](_0x94dae1,_0x3751cc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x94dae1,null,_0x3751cc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x94dae1,'action':'oc','data':null,'onComplete':_0x3751cc});}['sendOnDisconnect_'](_0x3f3da3,_0x32bff3,_0x3ab3f0,_0x1acd39){const _0x3bc26b={'p':_0x32bff3,'d':_0x3ab3f0};this['log_']('onDisconnect\x20'+_0x3f3da3,_0x3bc26b),this['sendRequest'](_0x3f3da3,_0x3bc26b,_0x54536e=>{_0x1acd39&&setTimeout(()=>{_0x1acd39(_0x54536e['s'],_0x54536e['d']);},Math['floor'](0x0));});}['put'](_0x5b0221,_0x111a81,_0x169f3e,_0x17b7a1){this['putInternal']('p',_0x5b0221,_0x111a81,_0x169f3e,_0x17b7a1);}['merge'](_0x1e635a,_0x1ba7c8,_0x3c0687,_0x1aca57){this['putInternal']('m',_0x1e635a,_0x1ba7c8,_0x3c0687,_0x1aca57);}['putInternal'](_0x4c2631,_0x2762b8,_0x593f0,_0x2b51cf,_0x2189b9){this['initConnection_']();const _0x43cad7={'p':_0x2762b8,'d':_0x593f0};_0x2189b9!==void 0x0&&(_0x43cad7['h']=_0x2189b9),this['outstandingPuts_']['push']({'action':_0x4c2631,'request':_0x43cad7,'onComplete':_0x2b51cf}),this['outstandingPutCount_']++;const _0x88286b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x88286b):this['log_']('Buffering\x20put:\x20'+_0x2762b8);}['sendPut_'](_0x40f470){const _0x1386af=this['outstandingPuts_'][_0x40f470]['action'],_0x4b2359=this['outstandingPuts_'][_0x40f470]['request'],_0x147920=this['outstandingPuts_'][_0x40f470]['onComplete'];this['outstandingPuts_'][_0x40f470]['queued']=this['connected_'],this['sendRequest'](_0x1386af,_0x4b2359,_0x3b99d4=>{this['log_'](_0x1386af+'\x20response',_0x3b99d4),delete this['outstandingPuts_'][_0x40f470],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x147920&&_0x147920(_0x3b99d4['s'],_0x3b99d4['d']);});}['reportStats'](_0x1cfb2b){if(this['connected_']){const _0xd92d54={'c':_0x1cfb2b};this['log_']('reportStats',_0xd92d54),this['sendRequest']('s',_0xd92d54,_0xdf5ec9=>{if(_0xdf5ec9['s']!=='ok'){const _0x41985b=_0xdf5ec9['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x41985b);}});}}['onDataMessage_'](_0xf55832){if('r'in _0xf55832){this['log_']('from\x20server:\x20'+O(_0xf55832));const _0x2e3a52=_0xf55832['r'],_0x5e188d=this['requestCBHash_'][_0x2e3a52];_0x5e188d&&(delete this['requestCBHash_'][_0x2e3a52],_0x5e188d(_0xf55832['b']));}else{if('error'in _0xf55832)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xf55832['error'];'a'in _0xf55832&&this['onDataPush_'](_0xf55832['a'],_0xf55832['b']);}}['onDataPush_'](_0x24bd3f,_0x41c1fa){this['log_']('handleServerMessage',_0x24bd3f,_0x41c1fa),_0x24bd3f==='d'?this['onDataUpdate_'](_0x41c1fa['p'],_0x41c1fa['d'],!0x1,_0x41c1fa['t']):_0x24bd3f==='m'?this['onDataUpdate_'](_0x41c1fa['p'],_0x41c1fa['d'],!0x0,_0x41c1fa['t']):_0x24bd3f==='c'?this['onListenRevoked_'](_0x41c1fa['p'],_0x41c1fa['q']):_0x24bd3f==='ac'?this['onAuthRevoked_'](_0x41c1fa['s'],_0x41c1fa['d']):_0x24bd3f==='apc'?this['onAppCheckRevoked_'](_0x41c1fa['s'],_0x41c1fa['d']):_0x24bd3f==='sd'?this['onSecurityDebugPacket_'](_0x41c1fa):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x24bd3f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4b4f47,_0x5881b8){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4b4f47),this['lastSessionId']=_0x5881b8,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xd1f954){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xd1f954));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x503438){_0x503438&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x503438;}['onOnline_'](_0x3ddd1b){_0x3ddd1b?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3bc582=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x2ed3ed=Math['max'](0x0,this['reconnectDelay_']-_0x3bc582);_0x2ed3ed=Math['random']()*_0x2ed3ed,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x2ed3ed+'ms'),this['scheduleConnect_'](_0x2ed3ed),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x8e2220=this['onDataMessage_']['bind'](this),_0x439dd7=this['onReady_']['bind'](this),_0x4c81f2=this['onRealtimeDisconnect_']['bind'](this),_0x4edb0e=this['id']+':'+ie['nextConnectionId_']++,_0x5d9dbd=this['lastSessionId'];let _0x144e75=!0x1,_0x245a83=null;const _0x849867=function(){_0x245a83?_0x245a83['close']():(_0x144e75=!0x0,_0x4c81f2());},_0x445617=function(_0x4837da){f(_0x245a83,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x245a83['sendRequest'](_0x4837da);};this['realtime_']={'close':_0x849867,'sendRequest':_0x445617};const _0x6ef0e8=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1aea94,_0x1f211a]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x6ef0e8),this['appCheckTokenProvider_']['getToken'](_0x6ef0e8)]);_0x144e75?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1aea94&&_0x1aea94['accessToken'],this['appCheckToken_']=_0x1f211a&&_0x1f211a['token'],_0x245a83=new wh(_0x4edb0e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x8e2220,_0x439dd7,_0x4c81f2,_0x16011d=>{U(_0x16011d+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x5d9dbd));}catch(_0x3d7589){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3d7589),_0x144e75||(this['repoInfo_']['nodeAdmin']&&U(_0x3d7589),_0x849867());}}}['interrupt'](_0x3ee530){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3ee530),this['interruptReasons_'][_0x3ee530]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x30b43d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x30b43d),delete this['interruptReasons_'][_0x30b43d],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3ce3e7){const _0xd0034e=_0x3ce3e7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xd0034e});}['cancelSentTransactions_'](){for(let _0x1002ae=0x0;_0x1002ae<this['outstandingPuts_']['length'];_0x1002ae++){const _0x3cdc2c=this['outstandingPuts_'][_0x1002ae];_0x3cdc2c&&'h'in _0x3cdc2c['request']&&_0x3cdc2c['queued']&&(_0x3cdc2c['onComplete']&&_0x3cdc2c['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1002ae],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x220ca2,_0x141bab){let _0x2a9283;_0x141bab?_0x2a9283=_0x141bab['map'](_0x4842d7=>Bi(_0x4842d7))['join']('$'):_0x2a9283='default';const _0x26b35f=this['removeListen_'](_0x220ca2,_0x2a9283);_0x26b35f&&_0x26b35f['onComplete']&&_0x26b35f['onComplete']('permission_denied');}['removeListen_'](_0x69aad,_0x29c3ec){const _0x214a05=new C(_0x69aad)['toString']();let _0x20ae34;if(this['listens']['has'](_0x214a05)){const _0x485c47=this['listens']['get'](_0x214a05);_0x20ae34=_0x485c47['get'](_0x29c3ec),_0x485c47['delete'](_0x29c3ec),_0x485c47['size']===0x0&&this['listens']['delete'](_0x214a05);}else _0x20ae34=void 0x0;return _0x20ae34;}['onAuthRevoked_'](_0x2b36ab,_0x30cb9c){L('Auth\x20token\x20revoked:\x20'+_0x2b36ab+'/'+_0x30cb9c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2b36ab==='invalid_token'||_0x2b36ab==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3a7ee8,_0x5d93c5){L('App\x20check\x20token\x20revoked:\x20'+_0x3a7ee8+'/'+_0x5d93c5),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3a7ee8==='invalid_token'||_0x3a7ee8==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x416b6d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x416b6d):'msg'in _0x416b6d&&console['log']('FIREBASE:\x20'+_0x416b6d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x31fddf of this['listens']['values']())for(const _0x49b62a of _0x31fddf['values']())this['sendListen_'](_0x49b62a);for(let _0x3245f1=0x0;_0x3245f1<this['outstandingPuts_']['length'];_0x3245f1++)this['outstandingPuts_'][_0x3245f1]&&this['sendPut_'](_0x3245f1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x6e8443=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x6e8443['action'],_0x6e8443['pathString'],_0x6e8443['data'],_0x6e8443['onComplete']);}for(let _0x54c489=0x0;_0x54c489<this['outstandingGets_']['length'];_0x54c489++)this['outstandingGets_'][_0x54c489]&&this['sendGet_'](_0x54c489);}['sendConnectStats_'](){const _0x1530ba={};let _0x29d3de='js';_0x1530ba['sdk.'+_0x29d3de+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1530ba['framework.cordova']=0x1:qr()&&(_0x1530ba['framework.reactnative']=0x1),this['reportStats'](_0x1530ba);}['shouldReconnect_'](){const _0x488f09=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x488f09;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x22b0c6,_0x1723e5){this['name']=_0x22b0c6,this['node']=_0x1723e5;}static['Wrap'](_0x575158,_0x442cc5){return new E(_0x575158,_0x442cc5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x34b879,_0x23732e){const _0x5ca324=new E(xe,_0x34b879),_0x29c6dc=new E(xe,_0x23732e);return this['compare'](_0x5ca324,_0x29c6dc)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x121a7e){Xt=_0x121a7e;}['compare'](_0x364627,_0x362692){return He(_0x364627['name'],_0x362692['name']);}['isDefinedOn'](_0x31eeb7){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x5eddc5,_0x4bb3b9){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x49dfd8,_0x261d59){return f(typeof _0x49dfd8=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x49dfd8,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2178c1,_0x40f50c,_0x458c58,_0x524bdb,_0x5d79c1=null){this['isReverse_']=_0x524bdb,this['resultGenerator_']=_0x5d79c1,this['nodeStack_']=[];let _0x5b186e=0x1;for(;!_0x2178c1['isEmpty']();)if(_0x2178c1=_0x2178c1,_0x5b186e=_0x40f50c?_0x458c58(_0x2178c1['key'],_0x40f50c):0x1,_0x524bdb&&(_0x5b186e*=-0x1),_0x5b186e<0x0)this['isReverse_']?_0x2178c1=_0x2178c1['left']:_0x2178c1=_0x2178c1['right'];else{if(_0x5b186e===0x0){this['nodeStack_']['push'](_0x2178c1);break;}else this['nodeStack_']['push'](_0x2178c1),this['isReverse_']?_0x2178c1=_0x2178c1['right']:_0x2178c1=_0x2178c1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x7528b8=this['nodeStack_']['pop'](),_0x357f61;if(this['resultGenerator_']?_0x357f61=this['resultGenerator_'](_0x7528b8['key'],_0x7528b8['value']):_0x357f61={'key':_0x7528b8['key'],'value':_0x7528b8['value']},this['isReverse_']){for(_0x7528b8=_0x7528b8['left'];!_0x7528b8['isEmpty']();)this['nodeStack_']['push'](_0x7528b8),_0x7528b8=_0x7528b8['right'];}else{for(_0x7528b8=_0x7528b8['right'];!_0x7528b8['isEmpty']();)this['nodeStack_']['push'](_0x7528b8),_0x7528b8=_0x7528b8['left'];}return _0x357f61;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0xe9b0b0=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0xe9b0b0['key'],_0xe9b0b0['value']):{'key':_0xe9b0b0['key'],'value':_0xe9b0b0['value']};}}class M{constructor(_0x33bfb1,_0x495ea0,_0x20fa5a,_0x25c3e6,_0x3cde1c){this['key']=_0x33bfb1,this['value']=_0x495ea0,this['color']=_0x20fa5a??M['RED'],this['left']=_0x25c3e6??B['EMPTY_NODE'],this['right']=_0x3cde1c??B['EMPTY_NODE'];}['copy'](_0x113687,_0x2fcb1c,_0x221601,_0xf8bb2a,_0x414fd8){return new M(_0x113687??this['key'],_0x2fcb1c??this['value'],_0x221601??this['color'],_0xf8bb2a??this['left'],_0x414fd8??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x294bb9){return this['left']['inorderTraversal'](_0x294bb9)||!!_0x294bb9(this['key'],this['value'])||this['right']['inorderTraversal'](_0x294bb9);}['reverseTraversal'](_0x3c019f){return this['right']['reverseTraversal'](_0x3c019f)||_0x3c019f(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3c019f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x26e3d3,_0x1e580e,_0x5d9ca7){let _0x137283=this;const _0x3de467=_0x5d9ca7(_0x26e3d3,_0x137283['key']);return _0x3de467<0x0?_0x137283=_0x137283['copy'](null,null,null,_0x137283['left']['insert'](_0x26e3d3,_0x1e580e,_0x5d9ca7),null):_0x3de467===0x0?_0x137283=_0x137283['copy'](null,_0x1e580e,null,null,null):_0x137283=_0x137283['copy'](null,null,null,null,_0x137283['right']['insert'](_0x26e3d3,_0x1e580e,_0x5d9ca7)),_0x137283['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x55d5c3=this;return!_0x55d5c3['left']['isRed_']()&&!_0x55d5c3['left']['left']['isRed_']()&&(_0x55d5c3=_0x55d5c3['moveRedLeft_']()),_0x55d5c3=_0x55d5c3['copy'](null,null,null,_0x55d5c3['left']['removeMin_'](),null),_0x55d5c3['fixUp_']();}['remove'](_0x14adb9,_0x353fb1){let _0x35d0f1,_0x2301f0;if(_0x35d0f1=this,_0x353fb1(_0x14adb9,_0x35d0f1['key'])<0x0)!_0x35d0f1['left']['isEmpty']()&&!_0x35d0f1['left']['isRed_']()&&!_0x35d0f1['left']['left']['isRed_']()&&(_0x35d0f1=_0x35d0f1['moveRedLeft_']()),_0x35d0f1=_0x35d0f1['copy'](null,null,null,_0x35d0f1['left']['remove'](_0x14adb9,_0x353fb1),null);else{if(_0x35d0f1['left']['isRed_']()&&(_0x35d0f1=_0x35d0f1['rotateRight_']()),!_0x35d0f1['right']['isEmpty']()&&!_0x35d0f1['right']['isRed_']()&&!_0x35d0f1['right']['left']['isRed_']()&&(_0x35d0f1=_0x35d0f1['moveRedRight_']()),_0x353fb1(_0x14adb9,_0x35d0f1['key'])===0x0){if(_0x35d0f1['right']['isEmpty']())return B['EMPTY_NODE'];_0x2301f0=_0x35d0f1['right']['min_'](),_0x35d0f1=_0x35d0f1['copy'](_0x2301f0['key'],_0x2301f0['value'],null,null,_0x35d0f1['right']['removeMin_']());}_0x35d0f1=_0x35d0f1['copy'](null,null,null,null,_0x35d0f1['right']['remove'](_0x14adb9,_0x353fb1));}return _0x35d0f1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3734fd=this;return _0x3734fd['right']['isRed_']()&&!_0x3734fd['left']['isRed_']()&&(_0x3734fd=_0x3734fd['rotateLeft_']()),_0x3734fd['left']['isRed_']()&&_0x3734fd['left']['left']['isRed_']()&&(_0x3734fd=_0x3734fd['rotateRight_']()),_0x3734fd['left']['isRed_']()&&_0x3734fd['right']['isRed_']()&&(_0x3734fd=_0x3734fd['colorFlip_']()),_0x3734fd;}['moveRedLeft_'](){let _0x55aa2a=this['colorFlip_']();return _0x55aa2a['right']['left']['isRed_']()&&(_0x55aa2a=_0x55aa2a['copy'](null,null,null,null,_0x55aa2a['right']['rotateRight_']()),_0x55aa2a=_0x55aa2a['rotateLeft_'](),_0x55aa2a=_0x55aa2a['colorFlip_']()),_0x55aa2a;}['moveRedRight_'](){let _0x59bb53=this['colorFlip_']();return _0x59bb53['left']['left']['isRed_']()&&(_0x59bb53=_0x59bb53['rotateRight_'](),_0x59bb53=_0x59bb53['colorFlip_']()),_0x59bb53;}['rotateLeft_'](){const _0xc357c0=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xc357c0,null);}['rotateRight_'](){const _0x5c41e2=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5c41e2);}['colorFlip_'](){const _0x3f9866=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x90e6fc=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3f9866,_0x90e6fc);}['checkMaxDepth_'](){const _0x40066a=this['check_']();return Math['pow'](0x2,_0x40066a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x241614=this['left']['check_']();if(_0x241614!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x241614+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x3729cd,_0x1be5fa,_0x382d47,_0x2eed16,_0x35e128){return this;}['insert'](_0x55c618,_0x2a827a,_0x3b80c2){return new M(_0x55c618,_0x2a827a,null);}['remove'](_0x50a2fd,_0x56feac){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x47aaad){return!0x1;}['reverseTraversal'](_0x414ad3){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4521e9,_0x53423f=B['EMPTY_NODE']){this['comparator_']=_0x4521e9,this['root_']=_0x53423f;}['insert'](_0x354e96,_0x301697){return new B(this['comparator_'],this['root_']['insert'](_0x354e96,_0x301697,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x35131d){return new B(this['comparator_'],this['root_']['remove'](_0x35131d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x14553a){let _0x46f3a3,_0x318179=this['root_'];for(;!_0x318179['isEmpty']();){if(_0x46f3a3=this['comparator_'](_0x14553a,_0x318179['key']),_0x46f3a3===0x0)return _0x318179['value'];_0x46f3a3<0x0?_0x318179=_0x318179['left']:_0x46f3a3>0x0&&(_0x318179=_0x318179['right']);}return null;}['getPredecessorKey'](_0x5ca130){let _0x2df8a9,_0x49d134=this['root_'],_0x2b261e=null;for(;!_0x49d134['isEmpty']();)if(_0x2df8a9=this['comparator_'](_0x5ca130,_0x49d134['key']),_0x2df8a9===0x0){if(_0x49d134['left']['isEmpty']())return _0x2b261e?_0x2b261e['key']:null;for(_0x49d134=_0x49d134['left'];!_0x49d134['right']['isEmpty']();)_0x49d134=_0x49d134['right'];return _0x49d134['key'];}else _0x2df8a9<0x0?_0x49d134=_0x49d134['left']:_0x2df8a9>0x0&&(_0x2b261e=_0x49d134,_0x49d134=_0x49d134['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1e48ba){return this['root_']['inorderTraversal'](_0x1e48ba);}['reverseTraversal'](_0x43a097){return this['root_']['reverseTraversal'](_0x43a097);}['getIterator'](_0x5c2767){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x5c2767);}['getIteratorFrom'](_0x5f4974,_0x7bfc7b){return new Zt(this['root_'],_0x5f4974,this['comparator_'],!0x1,_0x7bfc7b);}['getReverseIteratorFrom'](_0x2cf084,_0x393f93){return new Zt(this['root_'],_0x2cf084,this['comparator_'],!0x0,_0x393f93);}['getReverseIterator'](_0x55dbbf){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x55dbbf);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x353d45,_0x328505){return He(_0x353d45['name'],_0x328505['name']);}function ji(_0x29ebef,_0x1b3bfe){return He(_0x29ebef,_0x1b3bfe);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x1041e1){vi=_0x1041e1;}const Ro=function(_0x3268fe){return typeof _0x3268fe=='number'?'number:'+so(_0x3268fe):'string:'+_0x3268fe;},Ao=function(_0x2fadd2){if(_0x2fadd2['isLeafNode']()){const _0x3a2a56=_0x2fadd2['val']();f(typeof _0x3a2a56=='string'||typeof _0x3a2a56=='number'||typeof _0x3a2a56=='object'&&Y(_0x3a2a56,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2fadd2===vi||_0x2fadd2['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2fadd2===vi||_0x2fadd2['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x2aa555){er=_0x2aa555;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x4cc6d6,_0x538d70=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4cc6d6,this['priorityNode_']=_0x538d70,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x31ef33){return new D(this['value_'],_0x31ef33);}['getImmediateChild'](_0x9ac73e){return _0x9ac73e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x240d7a){return v(_0x240d7a)?this:y(_0x240d7a)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x318cf7,_0x296eb7){return null;}['updateImmediateChild'](_0x1962aa,_0x469b47){return _0x1962aa==='.priority'?this['updatePriority'](_0x469b47):_0x469b47['isEmpty']()&&_0x1962aa!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1962aa,_0x469b47)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4ef541,_0x40fe22){const _0x4f427b=y(_0x4ef541);return _0x4f427b===null?_0x40fe22:_0x40fe22['isEmpty']()&&_0x4f427b!=='.priority'?this:(f(_0x4f427b!=='.priority'||we(_0x4ef541)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4f427b,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4ef541),_0x40fe22)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xefb549,_0xc6ede6){return!0x1;}['val'](_0x14947d){return _0x14947d&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3df563='';this['priorityNode_']['isEmpty']()||(_0x3df563+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x12801a=typeof this['value_'];_0x3df563+=_0x12801a+':',_0x12801a==='number'?_0x3df563+=so(this['value_']):_0x3df563+=this['value_'],this['lazyHash_']=no(_0x3df563);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2a12cd){return _0x2a12cd===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2a12cd instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2a12cd['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2a12cd));}['compareToLeafNode_'](_0x3cad54){const _0x30141d=typeof _0x3cad54['value_'],_0x30ac26=typeof this['value_'],_0x30b134=D['VALUE_TYPE_ORDER']['indexOf'](_0x30141d),_0x55bdfe=D['VALUE_TYPE_ORDER']['indexOf'](_0x30ac26);return f(_0x30b134>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x30141d),f(_0x55bdfe>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x30ac26),_0x30b134===_0x55bdfe?_0x30ac26==='object'?0x0:this['value_']<_0x3cad54['value_']?-0x1:this['value_']===_0x3cad54['value_']?0x0:0x1:_0x55bdfe-_0x30b134;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x573042){if(_0x573042===this)return!0x0;if(_0x573042['isLeafNode']()){const _0x241696=_0x573042;return this['value_']===_0x241696['value_']&&this['priorityNode_']['equals'](_0x241696['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x41ca45){ko=_0x41ca45;}function xh(_0x27afc2){No=_0x27afc2;}class Fh extends On{['compare'](_0x4436e5,_0x3abf2a){const _0x3115d6=_0x4436e5['node']['getPriority'](),_0x5c6d3b=_0x3abf2a['node']['getPriority'](),_0x4a5c66=_0x3115d6['compareTo'](_0x5c6d3b);return _0x4a5c66===0x0?He(_0x4436e5['name'],_0x3abf2a['name']):_0x4a5c66;}['isDefinedOn'](_0x508c8e){return!_0x508c8e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3b8eb2,_0xa45210){return!_0x3b8eb2['getPriority']()['equals'](_0xa45210['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x374c71,_0xbad603){const _0x3a6671=ko(_0x374c71);return new E(_0xbad603,new D('[PRIORITY-POST]',_0x3a6671));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x2d6180){const _0x51ec03=_0x505b31=>parseInt(Math['log'](_0x505b31)/Uh,0xa),_0x35a566=_0xfe1cea=>parseInt(Array(_0xfe1cea+0x1)['join']('1'),0x2);this['count']=_0x51ec03(_0x2d6180+0x1),this['current_']=this['count']-0x1;const _0x92c777=_0x35a566(this['count']);this['bits_']=_0x2d6180+0x1&_0x92c777;}['nextBitIsOne'](){const _0x55924e=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x55924e;}}const dn=function(_0x66381b,_0x3d0e47,_0x3ca15c,_0x61bc85){_0x66381b['sort'](_0x3d0e47);const _0x1b7d1e=function(_0x4894d1,_0x30dd62){const _0x5d52f5=_0x30dd62-_0x4894d1;let _0x13e5aa,_0x46314d;if(_0x5d52f5===0x0)return null;if(_0x5d52f5===0x1)return _0x13e5aa=_0x66381b[_0x4894d1],_0x46314d=_0x3ca15c?_0x3ca15c(_0x13e5aa):_0x13e5aa,new M(_0x46314d,_0x13e5aa['node'],M['BLACK'],null,null);{const _0x3acdc6=parseInt(_0x5d52f5/0x2,0xa)+_0x4894d1,_0x108f57=_0x1b7d1e(_0x4894d1,_0x3acdc6),_0x38b960=_0x1b7d1e(_0x3acdc6+0x1,_0x30dd62);return _0x13e5aa=_0x66381b[_0x3acdc6],_0x46314d=_0x3ca15c?_0x3ca15c(_0x13e5aa):_0x13e5aa,new M(_0x46314d,_0x13e5aa['node'],M['BLACK'],_0x108f57,_0x38b960);}},_0x51b60b=function(_0x3f369d){let _0x20c71d=null,_0xd310b0=null,_0x26a188=_0x66381b['length'];const _0x18adaa=function(_0x39c804,_0x57c6bf){const _0x3ce5eb=_0x26a188-_0x39c804,_0x46421e=_0x26a188;_0x26a188-=_0x39c804;const _0x4f430e=_0x1b7d1e(_0x3ce5eb+0x1,_0x46421e),_0x24fa56=_0x66381b[_0x3ce5eb],_0x2ced0c=_0x3ca15c?_0x3ca15c(_0x24fa56):_0x24fa56;_0x259a90(new M(_0x2ced0c,_0x24fa56['node'],_0x57c6bf,null,_0x4f430e));},_0x259a90=function(_0x288cf5){_0x20c71d?(_0x20c71d['left']=_0x288cf5,_0x20c71d=_0x288cf5):(_0xd310b0=_0x288cf5,_0x20c71d=_0x288cf5);};for(let _0x1f7fed=0x0;_0x1f7fed<_0x3f369d['count'];++_0x1f7fed){const _0x260645=_0x3f369d['nextBitIsOne'](),_0x1fc407=Math['pow'](0x2,_0x3f369d['count']-(_0x1f7fed+0x1));_0x260645?_0x18adaa(_0x1fc407,M['BLACK']):(_0x18adaa(_0x1fc407,M['BLACK']),_0x18adaa(_0x1fc407,M['RED']));}return _0xd310b0;},_0x34d775=new Wh(_0x66381b['length']),_0x2f9168=_0x51b60b(_0x34d775);return new B(_0x61bc85||_0x3d0e47,_0x2f9168);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x5a3ed9,_0x328b1c){this['indexes_']=_0x5a3ed9,this['indexSet_']=_0x328b1c;}['get'](_0xaa3035){const _0x511f74=Oe(this['indexes_'],_0xaa3035);if(!_0x511f74)throw new Error('No\x20index\x20defined\x20for\x20'+_0xaa3035);return _0x511f74 instanceof B?_0x511f74:null;}['hasIndex'](_0xbde30b){return Y(this['indexSet_'],_0xbde30b['toString']());}['addIndex'](_0x339900,_0x3cd30b){f(_0x339900!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x4f78f6=[];let _0x5c8286=!0x1;const _0x4a9366=_0x3cd30b['getIterator'](E['Wrap']);let _0x478a90=_0x4a9366['getNext']();for(;_0x478a90;)_0x5c8286=_0x5c8286||_0x339900['isDefinedOn'](_0x478a90['node']),_0x4f78f6['push'](_0x478a90),_0x478a90=_0x4a9366['getNext']();let _0x3ac91f;_0x5c8286?_0x3ac91f=dn(_0x4f78f6,_0x339900['getCompare']()):_0x3ac91f=je;const _0x2331ed=_0x339900['toString'](),_0x255446={...this['indexSet_']};_0x255446[_0x2331ed]=_0x339900;const _0x5a078b={...this['indexes_']};return _0x5a078b[_0x2331ed]=_0x3ac91f,new ee(_0x5a078b,_0x255446);}['addToIndexes'](_0x4f33b5,_0x5e4f07){const _0x76f96d=ln(this['indexes_'],(_0x5c621c,_0x58022c)=>{const _0x3ee212=Oe(this['indexSet_'],_0x58022c);if(f(_0x3ee212,'Missing\x20index\x20implementation\x20for\x20'+_0x58022c),_0x5c621c===je){if(_0x3ee212['isDefinedOn'](_0x4f33b5['node'])){const _0x289bc4=[],_0x510b18=_0x5e4f07['getIterator'](E['Wrap']);let _0x365e39=_0x510b18['getNext']();for(;_0x365e39;)_0x365e39['name']!==_0x4f33b5['name']&&_0x289bc4['push'](_0x365e39),_0x365e39=_0x510b18['getNext']();return _0x289bc4['push'](_0x4f33b5),dn(_0x289bc4,_0x3ee212['getCompare']());}else return je;}else{const _0x470a88=_0x5e4f07['get'](_0x4f33b5['name']);let _0x568c70=_0x5c621c;return _0x470a88&&(_0x568c70=_0x568c70['remove'](new E(_0x4f33b5['name'],_0x470a88))),_0x568c70['insert'](_0x4f33b5,_0x4f33b5['node']);}});return new ee(_0x76f96d,this['indexSet_']);}['removeFromIndexes'](_0x2f7e8,_0x339d42){const _0x8f08fd=ln(this['indexes_'],_0x2804fe=>{if(_0x2804fe===je)return _0x2804fe;{const _0x2c8610=_0x339d42['get'](_0x2f7e8['name']);return _0x2c8610?_0x2804fe['remove'](new E(_0x2f7e8['name'],_0x2c8610)):_0x2804fe;}});return new ee(_0x8f08fd,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x587584,_0x51aed7,_0x3eb19e){this['children_']=_0x587584,this['priorityNode_']=_0x51aed7,this['indexMap_']=_0x3eb19e,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x36112a){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x36112a,this['indexMap_']);}['getImmediateChild'](_0x584979){if(_0x584979==='.priority')return this['getPriority']();{const _0x5615e7=this['children_']['get'](_0x584979);return _0x5615e7===null?gt:_0x5615e7;}}['getChild'](_0x3ea952){const _0x83400f=y(_0x3ea952);return _0x83400f===null?this:this['getImmediateChild'](_0x83400f)['getChild'](b(_0x3ea952));}['hasChild'](_0x4d4a77){return this['children_']['get'](_0x4d4a77)!==null;}['updateImmediateChild'](_0xdaff6c,_0xf9039d){if(f(_0xf9039d,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xdaff6c==='.priority')return this['updatePriority'](_0xf9039d);{const _0x33196e=new E(_0xdaff6c,_0xf9039d);let _0x44aacf,_0x33b638;_0xf9039d['isEmpty']()?(_0x44aacf=this['children_']['remove'](_0xdaff6c),_0x33b638=this['indexMap_']['removeFromIndexes'](_0x33196e,this['children_'])):(_0x44aacf=this['children_']['insert'](_0xdaff6c,_0xf9039d),_0x33b638=this['indexMap_']['addToIndexes'](_0x33196e,this['children_']));const _0x2cc43e=_0x44aacf['isEmpty']()?gt:this['priorityNode_'];return new g(_0x44aacf,_0x2cc43e,_0x33b638);}}['updateChild'](_0x42f508,_0x38d65e){const _0x1177ea=y(_0x42f508);if(_0x1177ea===null)return _0x38d65e;{f(y(_0x42f508)!=='.priority'||we(_0x42f508)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2f9cd2=this['getImmediateChild'](_0x1177ea)['updateChild'](b(_0x42f508),_0x38d65e);return this['updateImmediateChild'](_0x1177ea,_0x2f9cd2);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x42507c){if(this['isEmpty']())return null;const _0x56353a={};let _0x241938=0x0,_0x266567=0x0,_0x31a305=!0x0;if(this['forEachChild'](R,(_0x4f8ec3,_0x278348)=>{_0x56353a[_0x4f8ec3]=_0x278348['val'](_0x42507c),_0x241938++,_0x31a305&&g['INTEGER_REGEXP_']['test'](_0x4f8ec3)?_0x266567=Math['max'](_0x266567,Number(_0x4f8ec3)):_0x31a305=!0x1;}),!_0x42507c&&_0x31a305&&_0x266567<0x2*_0x241938){const _0x9a08f6=[];for(const _0x10156f in _0x56353a)_0x9a08f6[_0x10156f]=_0x56353a[_0x10156f];return _0x9a08f6;}else return _0x42507c&&!this['getPriority']()['isEmpty']()&&(_0x56353a['.priority']=this['getPriority']()['val']()),_0x56353a;}['hash'](){if(this['lazyHash_']===null){let _0x407d00='';this['getPriority']()['isEmpty']()||(_0x407d00+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x29a816,_0x18c4a2)=>{const _0x5ce7a9=_0x18c4a2['hash']();_0x5ce7a9!==''&&(_0x407d00+=':'+_0x29a816+':'+_0x5ce7a9);}),this['lazyHash_']=_0x407d00===''?'':no(_0x407d00);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5deb82,_0x526290,_0x5cc793){const _0x54141b=this['resolveIndex_'](_0x5cc793);if(_0x54141b){const _0xb1a84b=_0x54141b['getPredecessorKey'](new E(_0x5deb82,_0x526290));return _0xb1a84b?_0xb1a84b['name']:null;}else return this['children_']['getPredecessorKey'](_0x5deb82);}['getFirstChildName'](_0x49a517){const _0x1cb611=this['resolveIndex_'](_0x49a517);if(_0x1cb611){const _0x57e6eb=_0x1cb611['minKey']();return _0x57e6eb&&_0x57e6eb['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x406c2e){const _0x5efe55=this['getFirstChildName'](_0x406c2e);return _0x5efe55?new E(_0x5efe55,this['children_']['get'](_0x5efe55)):null;}['getLastChildName'](_0x5f334f){const _0x251c45=this['resolveIndex_'](_0x5f334f);if(_0x251c45){const _0x2c70be=_0x251c45['maxKey']();return _0x2c70be&&_0x2c70be['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x259c4d){const _0xc3a17d=this['getLastChildName'](_0x259c4d);return _0xc3a17d?new E(_0xc3a17d,this['children_']['get'](_0xc3a17d)):null;}['forEachChild'](_0x1808d9,_0x18a223){const _0xf6b588=this['resolveIndex_'](_0x1808d9);return _0xf6b588?_0xf6b588['inorderTraversal'](_0x4a50b7=>_0x18a223(_0x4a50b7['name'],_0x4a50b7['node'])):this['children_']['inorderTraversal'](_0x18a223);}['getIterator'](_0x81c7d8){return this['getIteratorFrom'](_0x81c7d8['minPost'](),_0x81c7d8);}['getIteratorFrom'](_0x46527f,_0x212064){const _0x5e1bf3=this['resolveIndex_'](_0x212064);if(_0x5e1bf3)return _0x5e1bf3['getIteratorFrom'](_0x46527f,_0x553eb2=>_0x553eb2);{const _0x28dfca=this['children_']['getIteratorFrom'](_0x46527f['name'],E['Wrap']);let _0x207ca0=_0x28dfca['peek']();for(;_0x207ca0!=null&&_0x212064['compare'](_0x207ca0,_0x46527f)<0x0;)_0x28dfca['getNext'](),_0x207ca0=_0x28dfca['peek']();return _0x28dfca;}}['getReverseIterator'](_0x30671b){return this['getReverseIteratorFrom'](_0x30671b['maxPost'](),_0x30671b);}['getReverseIteratorFrom'](_0x2aee5d,_0x24f487){const _0x3e0555=this['resolveIndex_'](_0x24f487);if(_0x3e0555)return _0x3e0555['getReverseIteratorFrom'](_0x2aee5d,_0x174c3d=>_0x174c3d);{const _0x57101c=this['children_']['getReverseIteratorFrom'](_0x2aee5d['name'],E['Wrap']);let _0x48b698=_0x57101c['peek']();for(;_0x48b698!=null&&_0x24f487['compare'](_0x48b698,_0x2aee5d)>0x0;)_0x57101c['getNext'](),_0x48b698=_0x57101c['peek']();return _0x57101c;}}['compareTo'](_0x11dab0){return this['isEmpty']()?_0x11dab0['isEmpty']()?0x0:-0x1:_0x11dab0['isLeafNode']()||_0x11dab0['isEmpty']()?0x1:_0x11dab0===Ht?-0x1:0x0;}['withIndex'](_0x396e96){if(_0x396e96===ye||this['indexMap_']['hasIndex'](_0x396e96))return this;{const _0xf81e1=this['indexMap_']['addIndex'](_0x396e96,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xf81e1);}}['isIndexed'](_0x215c6f){return _0x215c6f===ye||this['indexMap_']['hasIndex'](_0x215c6f);}['equals'](_0x226ba4){if(_0x226ba4===this)return!0x0;if(_0x226ba4['isLeafNode']())return!0x1;{const _0x130166=_0x226ba4;if(this['getPriority']()['equals'](_0x130166['getPriority']())){if(this['children_']['count']()===_0x130166['children_']['count']()){const _0x6e6748=this['getIterator'](R),_0x338291=_0x130166['getIterator'](R);let _0x35d188=_0x6e6748['getNext'](),_0x1a6288=_0x338291['getNext']();for(;_0x35d188&&_0x1a6288;){if(_0x35d188['name']!==_0x1a6288['name']||!_0x35d188['node']['equals'](_0x1a6288['node']))return!0x1;_0x35d188=_0x6e6748['getNext'](),_0x1a6288=_0x338291['getNext']();}return _0x35d188===null&&_0x1a6288===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5b6f90){return _0x5b6f90===ye?null:this['indexMap_']['get'](_0x5b6f90['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x2dfd0b){return _0x2dfd0b===this?0x0:0x1;}['equals'](_0x58b00c){return _0x58b00c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4781bc){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x4c517a,_0x2066ea=null){if(_0x4c517a===null)return g['EMPTY_NODE'];if(typeof _0x4c517a=='object'&&'.priority'in _0x4c517a&&(_0x2066ea=_0x4c517a['.priority']),f(_0x2066ea===null||typeof _0x2066ea=='string'||typeof _0x2066ea=='number'||typeof _0x2066ea=='object'&&'.sv'in _0x2066ea,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2066ea),typeof _0x4c517a=='object'&&'.value'in _0x4c517a&&_0x4c517a['.value']!==null&&(_0x4c517a=_0x4c517a['.value']),typeof _0x4c517a!='object'||'.sv'in _0x4c517a){const _0x330951=_0x4c517a;return new D(_0x330951,N(_0x2066ea));}if(!(_0x4c517a instanceof Array)&&Vh){const _0x5a8a01=[];let _0x5c4d3f=!0x1;if(x(_0x4c517a,(_0x571f42,_0x31cd0e)=>{if(_0x571f42['substring'](0x0,0x1)!=='.'){const _0x104127=N(_0x31cd0e);_0x104127['isEmpty']()||(_0x5c4d3f=_0x5c4d3f||!_0x104127['getPriority']()['isEmpty'](),_0x5a8a01['push'](new E(_0x571f42,_0x104127)));}}),_0x5a8a01['length']===0x0)return g['EMPTY_NODE'];const _0x35c766=dn(_0x5a8a01,Dh,_0x410b28=>_0x410b28['name'],ji);if(_0x5c4d3f){const _0x45f523=dn(_0x5a8a01,R['getCompare']());return new g(_0x35c766,N(_0x2066ea),new ee({'.priority':_0x45f523},{'.priority':R}));}else return new g(_0x35c766,N(_0x2066ea),ee['Default']);}else{let _0x4a1da4=g['EMPTY_NODE'];return x(_0x4c517a,(_0x528ccc,_0x4d0aef)=>{if(Y(_0x4c517a,_0x528ccc)&&_0x528ccc['substring'](0x0,0x1)!=='.'){const _0x1e2c6b=N(_0x4d0aef);(_0x1e2c6b['isLeafNode']()||!_0x1e2c6b['isEmpty']())&&(_0x4a1da4=_0x4a1da4['updateImmediateChild'](_0x528ccc,_0x1e2c6b));}}),_0x4a1da4['updatePriority'](N(_0x2066ea));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x1d4b5a){super(),this['indexPath_']=_0x1d4b5a,f(!v(_0x1d4b5a)&&y(_0x1d4b5a)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1610f9){return _0x1610f9['getChild'](this['indexPath_']);}['isDefinedOn'](_0x15a508){return!_0x15a508['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1073a1,_0x586ae2){const _0x2cf54f=this['extractChild'](_0x1073a1['node']),_0x36f90d=this['extractChild'](_0x586ae2['node']),_0x224ee8=_0x2cf54f['compareTo'](_0x36f90d);return _0x224ee8===0x0?He(_0x1073a1['name'],_0x586ae2['name']):_0x224ee8;}['makePost'](_0x1e6e60,_0x2b2149){const _0x635bab=N(_0x1e6e60),_0x39b66f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x635bab);return new E(_0x2b2149,_0x39b66f);}['maxPost'](){const _0xaf5ed6=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0xaf5ed6);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x5d92c9,_0x414ba7){const _0x538bd9=_0x5d92c9['node']['compareTo'](_0x414ba7['node']);return _0x538bd9===0x0?He(_0x5d92c9['name'],_0x414ba7['name']):_0x538bd9;}['isDefinedOn'](_0x49bedb){return!0x0;}['indexedValueChanged'](_0xc8f6a5,_0x309184){return!_0xc8f6a5['equals'](_0x309184);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x16d6b7,_0x1fa498){const _0x174805=N(_0x16d6b7);return new E(_0x1fa498,_0x174805);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x1dede5){return{'type':'value','snapshotNode':_0x1dede5};}function tt(_0x5e78b2,_0x5b1457){return{'type':'child_added','snapshotNode':_0x5b1457,'childName':_0x5e78b2};}function Nt(_0x1a59de,_0x1931c4){return{'type':'child_removed','snapshotNode':_0x1931c4,'childName':_0x1a59de};}function Pt(_0x4d555f,_0x241de4,_0xb4213a){return{'type':'child_changed','snapshotNode':_0x241de4,'childName':_0x4d555f,'oldSnap':_0xb4213a};}function $h(_0x277fdb,_0xd2f812){return{'type':'child_moved','snapshotNode':_0xd2f812,'childName':_0x277fdb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x320471){this['index_']=_0x320471;}['updateChild'](_0x504ce1,_0x3ee2cc,_0x7e045b,_0x32753b,_0x89b383,_0x37c7a5){f(_0x504ce1['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x469d83=_0x504ce1['getImmediateChild'](_0x3ee2cc);return _0x469d83['getChild'](_0x32753b)['equals'](_0x7e045b['getChild'](_0x32753b))&&_0x469d83['isEmpty']()===_0x7e045b['isEmpty']()||(_0x37c7a5!=null&&(_0x7e045b['isEmpty']()?_0x504ce1['hasChild'](_0x3ee2cc)?_0x37c7a5['trackChildChange'](Nt(_0x3ee2cc,_0x469d83)):f(_0x504ce1['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x469d83['isEmpty']()?_0x37c7a5['trackChildChange'](tt(_0x3ee2cc,_0x7e045b)):_0x37c7a5['trackChildChange'](Pt(_0x3ee2cc,_0x7e045b,_0x469d83))),_0x504ce1['isLeafNode']()&&_0x7e045b['isEmpty']())?_0x504ce1:_0x504ce1['updateImmediateChild'](_0x3ee2cc,_0x7e045b)['withIndex'](this['index_']);}['updateFullNode'](_0x4ce0c5,_0xda4c2c,_0x350a1f){return _0x350a1f!=null&&(_0x4ce0c5['isLeafNode']()||_0x4ce0c5['forEachChild'](R,(_0x4c72be,_0x205a01)=>{_0xda4c2c['hasChild'](_0x4c72be)||_0x350a1f['trackChildChange'](Nt(_0x4c72be,_0x205a01));}),_0xda4c2c['isLeafNode']()||_0xda4c2c['forEachChild'](R,(_0x4fe846,_0x30c997)=>{if(_0x4ce0c5['hasChild'](_0x4fe846)){const _0x59eaa3=_0x4ce0c5['getImmediateChild'](_0x4fe846);_0x59eaa3['equals'](_0x30c997)||_0x350a1f['trackChildChange'](Pt(_0x4fe846,_0x30c997,_0x59eaa3));}else _0x350a1f['trackChildChange'](tt(_0x4fe846,_0x30c997));})),_0xda4c2c['withIndex'](this['index_']);}['updatePriority'](_0x1279fb,_0x255604){return _0x1279fb['isEmpty']()?g['EMPTY_NODE']:_0x1279fb['updatePriority'](_0x255604);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x13eb16){this['indexedFilter_']=new Yi(_0x13eb16['getIndex']()),this['index_']=_0x13eb16['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x13eb16),this['endPost_']=Ot['getEndPost_'](_0x13eb16),this['startIsInclusive_']=!_0x13eb16['startAfterSet_'],this['endIsInclusive_']=!_0x13eb16['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1caba4){const _0x188698=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1caba4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1caba4)<0x0,_0x80e3f8=this['endIsInclusive_']?this['index_']['compare'](_0x1caba4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1caba4,this['getEndPost']())<0x0;return _0x188698&&_0x80e3f8;}['updateChild'](_0x42dc5a,_0x4f4597,_0x5186f2,_0x44b815,_0x4993f8,_0x5944f7){return this['matches'](new E(_0x4f4597,_0x5186f2))||(_0x5186f2=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x42dc5a,_0x4f4597,_0x5186f2,_0x44b815,_0x4993f8,_0x5944f7);}['updateFullNode'](_0x290222,_0x596c48,_0x10259c){_0x596c48['isLeafNode']()&&(_0x596c48=g['EMPTY_NODE']);let _0x18abf0=_0x596c48['withIndex'](this['index_']);_0x18abf0=_0x18abf0['updatePriority'](g['EMPTY_NODE']);const _0x5a32f0=this;return _0x596c48['forEachChild'](R,(_0x3eac7d,_0x52bccd)=>{_0x5a32f0['matches'](new E(_0x3eac7d,_0x52bccd))||(_0x18abf0=_0x18abf0['updateImmediateChild'](_0x3eac7d,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x290222,_0x18abf0,_0x10259c);}['updatePriority'](_0x2b6506,_0x2602f1){return _0x2b6506;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2d9718){if(_0x2d9718['hasStart']()){const _0x3a3a3f=_0x2d9718['getIndexStartName']();return _0x2d9718['getIndex']()['makePost'](_0x2d9718['getIndexStartValue'](),_0x3a3a3f);}else return _0x2d9718['getIndex']()['minPost']();}static['getEndPost_'](_0x540120){if(_0x540120['hasEnd']()){const _0x3fa573=_0x540120['getIndexEndName']();return _0x540120['getIndex']()['makePost'](_0x540120['getIndexEndValue'](),_0x3fa573);}else return _0x540120['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x1db9a1){this['withinDirectionalStart']=_0x968f6d=>this['reverse_']?this['withinEndPost'](_0x968f6d):this['withinStartPost'](_0x968f6d),this['withinDirectionalEnd']=_0x194f72=>this['reverse_']?this['withinStartPost'](_0x194f72):this['withinEndPost'](_0x194f72),this['withinStartPost']=_0x3a0969=>{const _0x581a45=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3a0969);return this['startIsInclusive_']?_0x581a45<=0x0:_0x581a45<0x0;},this['withinEndPost']=_0x1b07ba=>{const _0x4a92b5=this['index_']['compare'](_0x1b07ba,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4a92b5<=0x0:_0x4a92b5<0x0;},this['rangedFilter_']=new Ot(_0x1db9a1),this['index_']=_0x1db9a1['getIndex'](),this['limit_']=_0x1db9a1['getLimit'](),this['reverse_']=!_0x1db9a1['isViewFromLeft'](),this['startIsInclusive_']=!_0x1db9a1['startAfterSet_'],this['endIsInclusive_']=!_0x1db9a1['endBeforeSet_'];}['updateChild'](_0x11019f,_0x2d9c60,_0x3016b7,_0x564831,_0x50e26f,_0x5a56e7){return this['rangedFilter_']['matches'](new E(_0x2d9c60,_0x3016b7))||(_0x3016b7=g['EMPTY_NODE']),_0x11019f['getImmediateChild'](_0x2d9c60)['equals'](_0x3016b7)?_0x11019f:_0x11019f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x11019f,_0x2d9c60,_0x3016b7,_0x564831,_0x50e26f,_0x5a56e7):this['fullLimitUpdateChild_'](_0x11019f,_0x2d9c60,_0x3016b7,_0x50e26f,_0x5a56e7);}['updateFullNode'](_0x44a0be,_0xa7dec6,_0x34729c){let _0x4d510c;if(_0xa7dec6['isLeafNode']()||_0xa7dec6['isEmpty']())_0x4d510c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0xa7dec6['numChildren']()&&_0xa7dec6['isIndexed'](this['index_'])){_0x4d510c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5a5ced;this['reverse_']?_0x5a5ced=_0xa7dec6['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5a5ced=_0xa7dec6['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4c7e7f=0x0;for(;_0x5a5ced['hasNext']()&&_0x4c7e7f<this['limit_'];){const _0x3ebb8e=_0x5a5ced['getNext']();if(this['withinDirectionalStart'](_0x3ebb8e)){if(this['withinDirectionalEnd'](_0x3ebb8e))_0x4d510c=_0x4d510c['updateImmediateChild'](_0x3ebb8e['name'],_0x3ebb8e['node']),_0x4c7e7f++;else break;}else continue;}}else{_0x4d510c=_0xa7dec6['withIndex'](this['index_']),_0x4d510c=_0x4d510c['updatePriority'](g['EMPTY_NODE']);let _0x5549e3;this['reverse_']?_0x5549e3=_0x4d510c['getReverseIterator'](this['index_']):_0x5549e3=_0x4d510c['getIterator'](this['index_']);let _0x51a55f=0x0;for(;_0x5549e3['hasNext']();){const _0x3ceadb=_0x5549e3['getNext']();_0x51a55f<this['limit_']&&this['withinDirectionalStart'](_0x3ceadb)&&this['withinDirectionalEnd'](_0x3ceadb)?_0x51a55f++:_0x4d510c=_0x4d510c['updateImmediateChild'](_0x3ceadb['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x44a0be,_0x4d510c,_0x34729c);}['updatePriority'](_0xec0919,_0x1cff1b){return _0xec0919;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x419998,_0x11617b,_0x3bb9d9,_0x5bf966,_0x4a9f3d){let _0x1635f1;if(this['reverse_']){const _0x200399=this['index_']['getCompare']();_0x1635f1=(_0x45b89f,_0xc0077)=>_0x200399(_0xc0077,_0x45b89f);}else _0x1635f1=this['index_']['getCompare']();const _0x47fe64=_0x419998;f(_0x47fe64['numChildren']()===this['limit_'],'');const _0x208507=new E(_0x11617b,_0x3bb9d9),_0x4bf5ce=this['reverse_']?_0x47fe64['getFirstChild'](this['index_']):_0x47fe64['getLastChild'](this['index_']),_0xdab4d6=this['rangedFilter_']['matches'](_0x208507);if(_0x47fe64['hasChild'](_0x11617b)){const _0x4a1fa5=_0x47fe64['getImmediateChild'](_0x11617b);let _0x3fd07c=_0x5bf966['getChildAfterChild'](this['index_'],_0x4bf5ce,this['reverse_']);for(;_0x3fd07c!=null&&(_0x3fd07c['name']===_0x11617b||_0x47fe64['hasChild'](_0x3fd07c['name']));)_0x3fd07c=_0x5bf966['getChildAfterChild'](this['index_'],_0x3fd07c,this['reverse_']);const _0x161b17=_0x3fd07c==null?0x1:_0x1635f1(_0x3fd07c,_0x208507);if(_0xdab4d6&&!_0x3bb9d9['isEmpty']()&&_0x161b17>=0x0)return _0x4a9f3d!=null&&_0x4a9f3d['trackChildChange'](Pt(_0x11617b,_0x3bb9d9,_0x4a1fa5)),_0x47fe64['updateImmediateChild'](_0x11617b,_0x3bb9d9);{_0x4a9f3d!=null&&_0x4a9f3d['trackChildChange'](Nt(_0x11617b,_0x4a1fa5));const _0x2b151e=_0x47fe64['updateImmediateChild'](_0x11617b,g['EMPTY_NODE']);return _0x3fd07c!=null&&this['rangedFilter_']['matches'](_0x3fd07c)?(_0x4a9f3d!=null&&_0x4a9f3d['trackChildChange'](tt(_0x3fd07c['name'],_0x3fd07c['node'])),_0x2b151e['updateImmediateChild'](_0x3fd07c['name'],_0x3fd07c['node'])):_0x2b151e;}}else return _0x3bb9d9['isEmpty']()?_0x419998:_0xdab4d6&&_0x1635f1(_0x4bf5ce,_0x208507)>=0x0?(_0x4a9f3d!=null&&(_0x4a9f3d['trackChildChange'](Nt(_0x4bf5ce['name'],_0x4bf5ce['node'])),_0x4a9f3d['trackChildChange'](tt(_0x11617b,_0x3bb9d9))),_0x47fe64['updateImmediateChild'](_0x11617b,_0x3bb9d9)['updateImmediateChild'](_0x4bf5ce['name'],g['EMPTY_NODE'])):_0x419998;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x258959=new Qi();return _0x258959['limitSet_']=this['limitSet_'],_0x258959['limit_']=this['limit_'],_0x258959['startSet_']=this['startSet_'],_0x258959['startAfterSet_']=this['startAfterSet_'],_0x258959['indexStartValue_']=this['indexStartValue_'],_0x258959['startNameSet_']=this['startNameSet_'],_0x258959['indexStartName_']=this['indexStartName_'],_0x258959['endSet_']=this['endSet_'],_0x258959['endBeforeSet_']=this['endBeforeSet_'],_0x258959['indexEndValue_']=this['indexEndValue_'],_0x258959['endNameSet_']=this['endNameSet_'],_0x258959['indexEndName_']=this['indexEndName_'],_0x258959['index_']=this['index_'],_0x258959['viewFrom_']=this['viewFrom_'],_0x258959;}}function qh(_0x1345e5){return _0x1345e5['loadsAllData']()?new Yi(_0x1345e5['getIndex']()):_0x1345e5['hasLimit']()?new Gh(_0x1345e5):new Ot(_0x1345e5);}function zh(_0x3eb8ee,_0x168035){const _0x5b53e0=_0x3eb8ee['copy']();return _0x5b53e0['limitSet_']=!0x0,_0x5b53e0['limit_']=_0x168035,_0x5b53e0['viewFrom_']='l',_0x5b53e0;}function jh(_0xaa3d07,_0x2dc8a8,_0x594a1c){const _0x3b4a46=_0xaa3d07['copy']();return _0x3b4a46['startSet_']=!0x0,_0x2dc8a8===void 0x0&&(_0x2dc8a8=null),_0x3b4a46['indexStartValue_']=_0x2dc8a8,_0x594a1c!=null?(_0x3b4a46['startNameSet_']=!0x0,_0x3b4a46['indexStartName_']=_0x594a1c):(_0x3b4a46['startNameSet_']=!0x1,_0x3b4a46['indexStartName_']=''),_0x3b4a46;}function Kh(_0x54d6a0,_0x235a75,_0x1cac2b){const _0x33483c=_0x54d6a0['copy']();return _0x33483c['endSet_']=!0x0,_0x235a75===void 0x0&&(_0x235a75=null),_0x33483c['indexEndValue_']=_0x235a75,_0x1cac2b!==void 0x0?(_0x33483c['endNameSet_']=!0x0,_0x33483c['indexEndName_']=_0x1cac2b):(_0x33483c['endNameSet_']=!0x1,_0x33483c['indexEndName_']=''),_0x33483c;}function Do(_0x590bff,_0x505d6c){const _0x2dac66=_0x590bff['copy']();return _0x2dac66['index_']=_0x505d6c,_0x2dac66;}function tr(_0x6fb5a6){const _0x1958a5={};if(_0x6fb5a6['isDefault']())return _0x1958a5;let _0x455ec4;if(_0x6fb5a6['index_']===R?_0x455ec4='$priority':_0x6fb5a6['index_']===Po?_0x455ec4='$value':_0x6fb5a6['index_']===ye?_0x455ec4='$key':(f(_0x6fb5a6['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x455ec4=_0x6fb5a6['index_']['toString']()),_0x1958a5['orderBy']=O(_0x455ec4),_0x6fb5a6['startSet_']){const _0x35f1cc=_0x6fb5a6['startAfterSet_']?'startAfter':'startAt';_0x1958a5[_0x35f1cc]=O(_0x6fb5a6['indexStartValue_']),_0x6fb5a6['startNameSet_']&&(_0x1958a5[_0x35f1cc]+=','+O(_0x6fb5a6['indexStartName_']));}if(_0x6fb5a6['endSet_']){const _0x20c5ff=_0x6fb5a6['endBeforeSet_']?'endBefore':'endAt';_0x1958a5[_0x20c5ff]=O(_0x6fb5a6['indexEndValue_']),_0x6fb5a6['endNameSet_']&&(_0x1958a5[_0x20c5ff]+=','+O(_0x6fb5a6['indexEndName_']));}return _0x6fb5a6['limitSet_']&&(_0x6fb5a6['isViewFromLeft']()?_0x1958a5['limitToFirst']=_0x6fb5a6['limit_']:_0x1958a5['limitToLast']=_0x6fb5a6['limit_']),_0x1958a5;}function nr(_0xb9d981){const _0x426ef3={};if(_0xb9d981['startSet_']&&(_0x426ef3['sp']=_0xb9d981['indexStartValue_'],_0xb9d981['startNameSet_']&&(_0x426ef3['sn']=_0xb9d981['indexStartName_']),_0x426ef3['sin']=!_0xb9d981['startAfterSet_']),_0xb9d981['endSet_']&&(_0x426ef3['ep']=_0xb9d981['indexEndValue_'],_0xb9d981['endNameSet_']&&(_0x426ef3['en']=_0xb9d981['indexEndName_']),_0x426ef3['ein']=!_0xb9d981['endBeforeSet_']),_0xb9d981['limitSet_']){_0x426ef3['l']=_0xb9d981['limit_'];let _0x2f5527=_0xb9d981['viewFrom_'];_0x2f5527===''&&(_0xb9d981['isViewFromLeft']()?_0x2f5527='l':_0x2f5527='r'),_0x426ef3['vf']=_0x2f5527;}return _0xb9d981['index_']!==R&&(_0x426ef3['i']=_0xb9d981['index_']['toString']()),_0x426ef3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x1a0040){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x36c040,_0x6a82a8){return _0x6a82a8!==void 0x0?'tag$'+_0x6a82a8:(f(_0x36c040['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x36c040['_path']['toString']());}constructor(_0x2ccf24,_0x2f37d7,_0x166550,_0x1a6d51){super(),this['repoInfo_']=_0x2ccf24,this['onDataUpdate_']=_0x2f37d7,this['authTokenProvider_']=_0x166550,this['appCheckTokenProvider_']=_0x1a6d51,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x7cd810,_0x23daf3,_0x22f92a,_0x4e9375){const _0x55e06e=_0x7cd810['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x55e06e+'\x20'+_0x7cd810['_queryIdentifier']);const _0xd1b42a=fn['getListenId_'](_0x7cd810,_0x22f92a),_0x4a1b66={};this['listens_'][_0xd1b42a]=_0x4a1b66;const _0x248811=tr(_0x7cd810['_queryParams']);this['restRequest_'](_0x55e06e+'.json',_0x248811,(_0x1477d7,_0x1911b1)=>{let _0x169381=_0x1911b1;if(_0x1477d7===0x194&&(_0x169381=null,_0x1477d7=null),_0x1477d7===null&&this['onDataUpdate_'](_0x55e06e,_0x169381,!0x1,_0x22f92a),Oe(this['listens_'],_0xd1b42a)===_0x4a1b66){let _0x26a964;_0x1477d7?_0x1477d7===0x191?_0x26a964='permission_denied':_0x26a964='rest_error:'+_0x1477d7:_0x26a964='ok',_0x4e9375(_0x26a964,null);}});}['unlisten'](_0x237fb4,_0xe2867d){const _0x42dc98=fn['getListenId_'](_0x237fb4,_0xe2867d);delete this['listens_'][_0x42dc98];}['get'](_0x27541d){const _0x119e6e=tr(_0x27541d['_queryParams']),_0x4740b4=_0x27541d['_path']['toString'](),_0xe5daf1=new Ve();return this['restRequest_'](_0x4740b4+'.json',_0x119e6e,(_0x37702b,_0x49fddd)=>{let _0x3560ae=_0x49fddd;_0x37702b===0x194&&(_0x3560ae=null,_0x37702b=null),_0x37702b===null?(this['onDataUpdate_'](_0x4740b4,_0x3560ae,!0x1,null),_0xe5daf1['resolve'](_0x3560ae)):_0xe5daf1['reject'](new Error(_0x3560ae));}),_0xe5daf1['promise'];}['refreshAuthToken'](_0x42f7a9){}['restRequest_'](_0x5c7fa4,_0x450db7={},_0x151793){return _0x450db7['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xa39113,_0x1e977f])=>{_0xa39113&&_0xa39113['accessToken']&&(_0x450db7['auth']=_0xa39113['accessToken']),_0x1e977f&&_0x1e977f['token']&&(_0x450db7['ac']=_0x1e977f['token']);const _0x3a67d0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5c7fa4+'?ns='+this['repoInfo_']['namespace']+at(_0x450db7);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x3a67d0);const _0x107795=new XMLHttpRequest();_0x107795['onreadystatechange']=()=>{if(_0x151793&&_0x107795['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x3a67d0+'\x20received.\x20status:',_0x107795['status'],'response:',_0x107795['responseText']);let _0x343dce=null;if(_0x107795['status']>=0xc8&&_0x107795['status']<0x12c){try{_0x343dce=bt(_0x107795['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x3a67d0+':\x20'+_0x107795['responseText']);}_0x151793(null,_0x343dce);}else _0x107795['status']!==0x191&&_0x107795['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x3a67d0+'\x20Status:\x20'+_0x107795['status']),_0x151793(_0x107795['status']);_0x151793=null;}},_0x107795['open']('GET',_0x3a67d0,!0x0),_0x107795['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3b1d8a){return this['rootNode_']['getChild'](_0x3b1d8a);}['updateSnapshot'](_0x572963,_0x435585){this['rootNode_']=this['rootNode_']['updateChild'](_0x572963,_0x435585);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x487774,_0x4d83f7,_0x4bcd15){if(v(_0x4d83f7))_0x487774['value']=_0x4bcd15,_0x487774['children']['clear']();else{if(_0x487774['value']!==null)_0x487774['value']=_0x487774['value']['updateChild'](_0x4d83f7,_0x4bcd15);else{const _0x17be59=y(_0x4d83f7);_0x487774['children']['has'](_0x17be59)||_0x487774['children']['set'](_0x17be59,pn());const _0x1cc965=_0x487774['children']['get'](_0x17be59);_0x4d83f7=b(_0x4d83f7),Mo(_0x1cc965,_0x4d83f7,_0x4bcd15);}}}function Ei(_0x2edcc9,_0x58f13b,_0x5c8e2d){_0x2edcc9['value']!==null?_0x5c8e2d(_0x58f13b,_0x2edcc9['value']):Qh(_0x2edcc9,(_0x58cf16,_0x3969bd)=>{const _0x20a2ec=new C(_0x58f13b['toString']()+'/'+_0x58cf16);Ei(_0x3969bd,_0x20a2ec,_0x5c8e2d);});}function Qh(_0x3e19d3,_0x54e2fd){_0x3e19d3['children']['forEach']((_0x465717,_0x1e2d7b)=>{_0x54e2fd(_0x1e2d7b,_0x465717);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x431f00){this['collection_']=_0x431f00,this['last_']=null;}['get'](){const _0x201aa0=this['collection_']['get'](),_0x808e60={..._0x201aa0};return this['last_']&&x(this['last_'],(_0x414f09,_0x2a42a9)=>{_0x808e60[_0x414f09]=_0x808e60[_0x414f09]-_0x2a42a9;}),this['last_']=_0x201aa0,_0x808e60;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x1d3334,_0x402525){this['server_']=_0x402525,this['statsToReport_']={},this['statsListener_']=new Jh(_0x1d3334);const _0x20a065=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x20a065));}['reportStats_'](){const _0x49d831=this['statsListener_']['get'](),_0x6b58f6={};let _0x50f2a8=!0x1;x(_0x49d831,(_0x5bb326,_0x1d8b1d)=>{_0x1d8b1d>0x0&&Y(this['statsToReport_'],_0x5bb326)&&(_0x6b58f6[_0x5bb326]=_0x1d8b1d,_0x50f2a8=!0x0);}),_0x50f2a8&&this['server_']['reportStats'](_0x6b58f6),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x20cde2){_0x20cde2[_0x20cde2['OVERWRITE']=0x0]='OVERWRITE',_0x20cde2[_0x20cde2['MERGE']=0x1]='MERGE',_0x20cde2[_0x20cde2['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x20cde2[_0x20cde2['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x4caff7){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4caff7,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x5b8a6d,_0x1d5341,_0xa7736f){this['path']=_0x5b8a6d,this['affectedTree']=_0x1d5341,this['revert']=_0xa7736f,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5db340){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2588f1=this['affectedTree']['subtree'](new C(_0x5db340));return new _n(w(),_0x2588f1,this['revert']);}}else return f(y(this['path'])===_0x5db340,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x2f3588,_0x241782){this['source']=_0x2f3588,this['path']=_0x241782,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1ef127){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x37cd75,_0x1a7a2f,_0x562f2d){this['source']=_0x37cd75,this['path']=_0x1a7a2f,this['snap']=_0x562f2d,this['type']=q['OVERWRITE'];}['operationForChild'](_0x38429e){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x38429e)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x415065,_0x21fea4,_0x1f1fe6){this['source']=_0x415065,this['path']=_0x21fea4,this['children']=_0x1f1fe6,this['type']=q['MERGE'];}['operationForChild'](_0x311727){if(v(this['path'])){const _0x545095=this['children']['subtree'](new C(_0x311727));return _0x545095['isEmpty']()?null:_0x545095['value']?new Fe(this['source'],w(),_0x545095['value']):new nt(this['source'],w(),_0x545095);}else return f(y(this['path'])===_0x311727,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x33200b,_0x5e3942,_0x2ec9c7){this['node_']=_0x33200b,this['fullyInitialized_']=_0x5e3942,this['filtered_']=_0x2ec9c7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4b39cb){if(v(_0x4b39cb))return this['isFullyInitialized']()&&!this['filtered_'];const _0x16b611=y(_0x4b39cb);return this['isCompleteForChild'](_0x16b611);}['isCompleteForChild'](_0x2089d3){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2089d3);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x50afce){this['query_']=_0x50afce,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x107f6e,_0x3a0053,_0x56cb77,_0x5b2ed8){const _0x187d0c=[],_0x40a544=[];return _0x3a0053['forEach'](_0x47bfa0=>{_0x47bfa0['type']==='child_changed'&&_0x107f6e['index_']['indexedValueChanged'](_0x47bfa0['oldSnap'],_0x47bfa0['snapshotNode'])&&_0x40a544['push']($h(_0x47bfa0['childName'],_0x47bfa0['snapshotNode']));}),mt(_0x107f6e,_0x187d0c,'child_removed',_0x3a0053,_0x5b2ed8,_0x56cb77),mt(_0x107f6e,_0x187d0c,'child_added',_0x3a0053,_0x5b2ed8,_0x56cb77),mt(_0x107f6e,_0x187d0c,'child_moved',_0x40a544,_0x5b2ed8,_0x56cb77),mt(_0x107f6e,_0x187d0c,'child_changed',_0x3a0053,_0x5b2ed8,_0x56cb77),mt(_0x107f6e,_0x187d0c,'value',_0x3a0053,_0x5b2ed8,_0x56cb77),_0x187d0c;}function mt(_0x4f2618,_0x52ef85,_0x2bb66e,_0x2ddf9d,_0x1a397d,_0x4eaba9){const _0x9b4ee5=_0x2ddf9d['filter'](_0x5e968d=>_0x5e968d['type']===_0x2bb66e);_0x9b4ee5['sort']((_0x6ae6bc,_0x1f3aba)=>su(_0x4f2618,_0x6ae6bc,_0x1f3aba)),_0x9b4ee5['forEach'](_0x246104=>{const _0x21b6fe=iu(_0x4f2618,_0x246104,_0x4eaba9);_0x1a397d['forEach'](_0x23229b=>{_0x23229b['respondsTo'](_0x246104['type'])&&_0x52ef85['push'](_0x23229b['createEvent'](_0x21b6fe,_0x4f2618['query_']));});});}function iu(_0x261681,_0x5f06f3,_0xbe24eb){return _0x5f06f3['type']==='value'||_0x5f06f3['type']==='child_removed'||(_0x5f06f3['prevName']=_0xbe24eb['getPredecessorChildName'](_0x5f06f3['childName'],_0x5f06f3['snapshotNode'],_0x261681['index_'])),_0x5f06f3;}function su(_0x57f07f,_0x2a3675,_0xed84fc){if(_0x2a3675['childName']==null||_0xed84fc['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0xd7ca29=new E(_0x2a3675['childName'],_0x2a3675['snapshotNode']),_0xe17b6c=new E(_0xed84fc['childName'],_0xed84fc['snapshotNode']);return _0x57f07f['index_']['compare'](_0xd7ca29,_0xe17b6c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x1caf5d,_0x4f19ae){return{'eventCache':_0x1caf5d,'serverCache':_0x4f19ae};}function wt(_0x1298aa,_0x81fa36,_0x8b2e22,_0x3958b5){return Dn(new Ce(_0x81fa36,_0x8b2e22,_0x3958b5),_0x1298aa['serverCache']);}function Lo(_0x40a9f,_0x293e62,_0x46e482,_0x333476){return Dn(_0x40a9f['eventCache'],new Ce(_0x293e62,_0x46e482,_0x333476));}function gn(_0x1cc617){return _0x1cc617['eventCache']['isFullyInitialized']()?_0x1cc617['eventCache']['getNode']():null;}function Ue(_0x58b3b2){return _0x58b3b2['serverCache']['isFullyInitialized']()?_0x58b3b2['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x3ed323){let _0x3bd48a=new S(null);return x(_0x3ed323,(_0x52169c,_0x41d36f)=>{_0x3bd48a=_0x3bd48a['set'](new C(_0x52169c),_0x41d36f);}),_0x3bd48a;}constructor(_0x20d56e,_0x15296c=ru()){this['value']=_0x20d56e,this['children']=_0x15296c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2b2fdb,_0x2c9b36){if(this['value']!=null&&_0x2c9b36(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2b2fdb))return null;{const _0x5971aa=y(_0x2b2fdb),_0x432f48=this['children']['get'](_0x5971aa);if(_0x432f48!==null){const _0x23175c=_0x432f48['findRootMostMatchingPathAndValue'](b(_0x2b2fdb),_0x2c9b36);return _0x23175c!=null?{'path':A(new C(_0x5971aa),_0x23175c['path']),'value':_0x23175c['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x241633){return this['findRootMostMatchingPathAndValue'](_0x241633,()=>!0x0);}['subtree'](_0x2783f6){if(v(_0x2783f6))return this;{const _0x543440=y(_0x2783f6),_0x160d0e=this['children']['get'](_0x543440);return _0x160d0e!==null?_0x160d0e['subtree'](b(_0x2783f6)):new S(null);}}['set'](_0x191bc0,_0x1a6868){if(v(_0x191bc0))return new S(_0x1a6868,this['children']);{const _0x272976=y(_0x191bc0),_0x4bb32e=(this['children']['get'](_0x272976)||new S(null))['set'](b(_0x191bc0),_0x1a6868),_0x543b3b=this['children']['insert'](_0x272976,_0x4bb32e);return new S(this['value'],_0x543b3b);}}['remove'](_0x4dcb80){if(v(_0x4dcb80))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x729298=y(_0x4dcb80),_0x4c4abd=this['children']['get'](_0x729298);if(_0x4c4abd){const _0x40cb1c=_0x4c4abd['remove'](b(_0x4dcb80));let _0x4653a9;return _0x40cb1c['isEmpty']()?_0x4653a9=this['children']['remove'](_0x729298):_0x4653a9=this['children']['insert'](_0x729298,_0x40cb1c),this['value']===null&&_0x4653a9['isEmpty']()?new S(null):new S(this['value'],_0x4653a9);}else return this;}}['get'](_0x1e7abd){if(v(_0x1e7abd))return this['value'];{const _0x328e75=y(_0x1e7abd),_0x191518=this['children']['get'](_0x328e75);return _0x191518?_0x191518['get'](b(_0x1e7abd)):null;}}['setTree'](_0xe8b1d0,_0x3ceed3){if(v(_0xe8b1d0))return _0x3ceed3;{const _0x29dcb0=y(_0xe8b1d0),_0x2c0ced=(this['children']['get'](_0x29dcb0)||new S(null))['setTree'](b(_0xe8b1d0),_0x3ceed3);let _0x45705f;return _0x2c0ced['isEmpty']()?_0x45705f=this['children']['remove'](_0x29dcb0):_0x45705f=this['children']['insert'](_0x29dcb0,_0x2c0ced),new S(this['value'],_0x45705f);}}['fold'](_0x11fa28){return this['fold_'](w(),_0x11fa28);}['fold_'](_0x3bd419,_0x2092f3){const _0x2d0830={};return this['children']['inorderTraversal']((_0xa4758b,_0x99248a)=>{_0x2d0830[_0xa4758b]=_0x99248a['fold_'](A(_0x3bd419,_0xa4758b),_0x2092f3);}),_0x2092f3(_0x3bd419,this['value'],_0x2d0830);}['findOnPath'](_0x2ad953,_0x5f3917){return this['findOnPath_'](_0x2ad953,w(),_0x5f3917);}['findOnPath_'](_0x5470c6,_0x1481d1,_0x2c7383){const _0x1ca0e4=this['value']?_0x2c7383(_0x1481d1,this['value']):!0x1;if(_0x1ca0e4)return _0x1ca0e4;if(v(_0x5470c6))return null;{const _0x553730=y(_0x5470c6),_0x5a81b9=this['children']['get'](_0x553730);return _0x5a81b9?_0x5a81b9['findOnPath_'](b(_0x5470c6),A(_0x1481d1,_0x553730),_0x2c7383):null;}}['foreachOnPath'](_0x2bb95b,_0x49ab2c){return this['foreachOnPath_'](_0x2bb95b,w(),_0x49ab2c);}['foreachOnPath_'](_0x4c978a,_0x363206,_0x432cfd){if(v(_0x4c978a))return this;{this['value']&&_0x432cfd(_0x363206,this['value']);const _0x240dcb=y(_0x4c978a),_0x389739=this['children']['get'](_0x240dcb);return _0x389739?_0x389739['foreachOnPath_'](b(_0x4c978a),A(_0x363206,_0x240dcb),_0x432cfd):new S(null);}}['foreach'](_0x12c853){this['foreach_'](w(),_0x12c853);}['foreach_'](_0x3adb7f,_0x5e97dc){this['children']['inorderTraversal']((_0x32e091,_0x528954)=>{_0x528954['foreach_'](A(_0x3adb7f,_0x32e091),_0x5e97dc);}),this['value']&&_0x5e97dc(_0x3adb7f,this['value']);}['foreachChild'](_0x35e5bc){this['children']['inorderTraversal']((_0xf2183a,_0x212903)=>{_0x212903['value']&&_0x35e5bc(_0xf2183a,_0x212903['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x57d098){this['writeTree_']=_0x57d098;}static['empty'](){return new j(new S(null));}}function Ct(_0x21e561,_0x730580,_0x342a0a){if(v(_0x730580))return new j(new S(_0x342a0a));{const _0x57570d=_0x21e561['writeTree_']['findRootMostValueAndPath'](_0x730580);if(_0x57570d!=null){const _0x488bf6=_0x57570d['path'];let _0x1d2720=_0x57570d['value'];const _0x58e18e=F(_0x488bf6,_0x730580);return _0x1d2720=_0x1d2720['updateChild'](_0x58e18e,_0x342a0a),new j(_0x21e561['writeTree_']['set'](_0x488bf6,_0x1d2720));}else{const _0x506c22=new S(_0x342a0a),_0xaed05a=_0x21e561['writeTree_']['setTree'](_0x730580,_0x506c22);return new j(_0xaed05a);}}}function Ii(_0x4a29ba,_0x3d7d32,_0x359378){let _0xad8b00=_0x4a29ba;return x(_0x359378,(_0x5f4ab5,_0xe427ab)=>{_0xad8b00=Ct(_0xad8b00,A(_0x3d7d32,_0x5f4ab5),_0xe427ab);}),_0xad8b00;}function sr(_0x2e57c0,_0x1bc2aa){if(v(_0x1bc2aa))return j['empty']();{const _0x117ad5=_0x2e57c0['writeTree_']['setTree'](_0x1bc2aa,new S(null));return new j(_0x117ad5);}}function wi(_0x1756ee,_0x12b884){return $e(_0x1756ee,_0x12b884)!=null;}function $e(_0x57baa2,_0x5d90c6){const _0x307f1a=_0x57baa2['writeTree_']['findRootMostValueAndPath'](_0x5d90c6);return _0x307f1a!=null?_0x57baa2['writeTree_']['get'](_0x307f1a['path'])['getChild'](F(_0x307f1a['path'],_0x5d90c6)):null;}function rr(_0x1cda9e){const _0x39bb94=[],_0x318bb1=_0x1cda9e['writeTree_']['value'];return _0x318bb1!=null?_0x318bb1['isLeafNode']()||_0x318bb1['forEachChild'](R,(_0x1c4c1a,_0x4a485d)=>{_0x39bb94['push'](new E(_0x1c4c1a,_0x4a485d));}):_0x1cda9e['writeTree_']['children']['inorderTraversal']((_0x3fc4d4,_0x3779c3)=>{_0x3779c3['value']!=null&&_0x39bb94['push'](new E(_0x3fc4d4,_0x3779c3['value']));}),_0x39bb94;}function ve(_0x3207ef,_0x187c4b){if(v(_0x187c4b))return _0x3207ef;{const _0x3a94ae=$e(_0x3207ef,_0x187c4b);return _0x3a94ae!=null?new j(new S(_0x3a94ae)):new j(_0x3207ef['writeTree_']['subtree'](_0x187c4b));}}function Ci(_0x26dd28){return _0x26dd28['writeTree_']['isEmpty']();}function it(_0x7804f3,_0x48a8ef){return xo(w(),_0x7804f3['writeTree_'],_0x48a8ef);}function xo(_0x42fa39,_0x1568d0,_0x5e30d0){if(_0x1568d0['value']!=null)return _0x5e30d0['updateChild'](_0x42fa39,_0x1568d0['value']);{let _0x36f275=null;return _0x1568d0['children']['inorderTraversal']((_0x1dbcc7,_0x47ba2a)=>{_0x1dbcc7==='.priority'?(f(_0x47ba2a['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x36f275=_0x47ba2a['value']):_0x5e30d0=xo(A(_0x42fa39,_0x1dbcc7),_0x47ba2a,_0x5e30d0);}),!_0x5e30d0['getChild'](_0x42fa39)['isEmpty']()&&_0x36f275!==null&&(_0x5e30d0=_0x5e30d0['updateChild'](A(_0x42fa39,'.priority'),_0x36f275)),_0x5e30d0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x3aa7f3,_0x3c6d91){return Bo(_0x3c6d91,_0x3aa7f3);}function ou(_0x21a3a6,_0x4bb936,_0x554018,_0x34e623,_0x2c6add){f(_0x34e623>_0x21a3a6['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2c6add===void 0x0&&(_0x2c6add=!0x0),_0x21a3a6['allWrites']['push']({'path':_0x4bb936,'snap':_0x554018,'writeId':_0x34e623,'visible':_0x2c6add}),_0x2c6add&&(_0x21a3a6['visibleWrites']=Ct(_0x21a3a6['visibleWrites'],_0x4bb936,_0x554018)),_0x21a3a6['lastWriteId']=_0x34e623;}function au(_0x2d1b5c,_0x47a1ff,_0x1007cb,_0x579342){f(_0x579342>_0x2d1b5c['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2d1b5c['allWrites']['push']({'path':_0x47a1ff,'children':_0x1007cb,'writeId':_0x579342,'visible':!0x0}),_0x2d1b5c['visibleWrites']=Ii(_0x2d1b5c['visibleWrites'],_0x47a1ff,_0x1007cb),_0x2d1b5c['lastWriteId']=_0x579342;}function cu(_0x5b7587,_0x336a97){for(let _0x12125e=0x0;_0x12125e<_0x5b7587['allWrites']['length'];_0x12125e++){const _0x466a83=_0x5b7587['allWrites'][_0x12125e];if(_0x466a83['writeId']===_0x336a97)return _0x466a83;}return null;}function lu(_0x34c0b0,_0x479e74){const _0x5a0a9b=_0x34c0b0['allWrites']['findIndex'](_0x53802c=>_0x53802c['writeId']===_0x479e74);f(_0x5a0a9b>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5589b3=_0x34c0b0['allWrites'][_0x5a0a9b];_0x34c0b0['allWrites']['splice'](_0x5a0a9b,0x1);let _0x2b6807=_0x5589b3['visible'],_0x501cc1=!0x1,_0x3db30c=_0x34c0b0['allWrites']['length']-0x1;for(;_0x2b6807&&_0x3db30c>=0x0;){const _0x32e637=_0x34c0b0['allWrites'][_0x3db30c];_0x32e637['visible']&&(_0x3db30c>=_0x5a0a9b&&hu(_0x32e637,_0x5589b3['path'])?_0x2b6807=!0x1:$(_0x5589b3['path'],_0x32e637['path'])&&(_0x501cc1=!0x0)),_0x3db30c--;}if(_0x2b6807){if(_0x501cc1)return uu(_0x34c0b0),!0x0;if(_0x5589b3['snap'])_0x34c0b0['visibleWrites']=sr(_0x34c0b0['visibleWrites'],_0x5589b3['path']);else{const _0x5cd491=_0x5589b3['children'];x(_0x5cd491,_0x61de6d=>{_0x34c0b0['visibleWrites']=sr(_0x34c0b0['visibleWrites'],A(_0x5589b3['path'],_0x61de6d));});}return!0x0;}else return!0x1;}function hu(_0x172cf6,_0x260198){if(_0x172cf6['snap'])return $(_0x172cf6['path'],_0x260198);for(const _0x5ef04b in _0x172cf6['children'])if(_0x172cf6['children']['hasOwnProperty'](_0x5ef04b)&&$(A(_0x172cf6['path'],_0x5ef04b),_0x260198))return!0x0;return!0x1;}function uu(_0x2956da){_0x2956da['visibleWrites']=Fo(_0x2956da['allWrites'],du,w()),_0x2956da['allWrites']['length']>0x0?_0x2956da['lastWriteId']=_0x2956da['allWrites'][_0x2956da['allWrites']['length']-0x1]['writeId']:_0x2956da['lastWriteId']=-0x1;}function du(_0x33fd20){return _0x33fd20['visible'];}function Fo(_0x5557a5,_0x4b8f00,_0x34a723){let _0x1a67d1=j['empty']();for(let _0x5cdfb7=0x0;_0x5cdfb7<_0x5557a5['length'];++_0x5cdfb7){const _0x1f6f55=_0x5557a5[_0x5cdfb7];if(_0x4b8f00(_0x1f6f55)){const _0x4fec63=_0x1f6f55['path'];let _0x337b3d;if(_0x1f6f55['snap'])$(_0x34a723,_0x4fec63)?(_0x337b3d=F(_0x34a723,_0x4fec63),_0x1a67d1=Ct(_0x1a67d1,_0x337b3d,_0x1f6f55['snap'])):$(_0x4fec63,_0x34a723)&&(_0x337b3d=F(_0x4fec63,_0x34a723),_0x1a67d1=Ct(_0x1a67d1,w(),_0x1f6f55['snap']['getChild'](_0x337b3d)));else{if(_0x1f6f55['children']){if($(_0x34a723,_0x4fec63))_0x337b3d=F(_0x34a723,_0x4fec63),_0x1a67d1=Ii(_0x1a67d1,_0x337b3d,_0x1f6f55['children']);else{if($(_0x4fec63,_0x34a723)){if(_0x337b3d=F(_0x4fec63,_0x34a723),v(_0x337b3d))_0x1a67d1=Ii(_0x1a67d1,w(),_0x1f6f55['children']);else{const _0x5e9c6d=Oe(_0x1f6f55['children'],y(_0x337b3d));if(_0x5e9c6d){const _0x2376e4=_0x5e9c6d['getChild'](b(_0x337b3d));_0x1a67d1=Ct(_0x1a67d1,w(),_0x2376e4);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1a67d1;}function Uo(_0x212449,_0x4f6c32,_0x22111c,_0x218baa,_0x112be5){if(!_0x218baa&&!_0x112be5){const _0x4a1723=$e(_0x212449['visibleWrites'],_0x4f6c32);if(_0x4a1723!=null)return _0x4a1723;{const _0x15a337=ve(_0x212449['visibleWrites'],_0x4f6c32);if(Ci(_0x15a337))return _0x22111c;if(_0x22111c==null&&!wi(_0x15a337,w()))return null;{const _0x125fe5=_0x22111c||g['EMPTY_NODE'];return it(_0x15a337,_0x125fe5);}}}else{const _0x283175=ve(_0x212449['visibleWrites'],_0x4f6c32);if(!_0x112be5&&Ci(_0x283175))return _0x22111c;if(!_0x112be5&&_0x22111c==null&&!wi(_0x283175,w()))return null;{const _0x5b3be6=function(_0x1c5510){return(_0x1c5510['visible']||_0x112be5)&&(!_0x218baa||!~_0x218baa['indexOf'](_0x1c5510['writeId']))&&($(_0x1c5510['path'],_0x4f6c32)||$(_0x4f6c32,_0x1c5510['path']));},_0x319347=Fo(_0x212449['allWrites'],_0x5b3be6,_0x4f6c32),_0x44c640=_0x22111c||g['EMPTY_NODE'];return it(_0x319347,_0x44c640);}}}function fu(_0x15b57d,_0x313a9e,_0x548547){let _0x65beea=g['EMPTY_NODE'];const _0x27f862=$e(_0x15b57d['visibleWrites'],_0x313a9e);if(_0x27f862)return _0x27f862['isLeafNode']()||_0x27f862['forEachChild'](R,(_0x56bf74,_0x5aadce)=>{_0x65beea=_0x65beea['updateImmediateChild'](_0x56bf74,_0x5aadce);}),_0x65beea;if(_0x548547){const _0x516700=ve(_0x15b57d['visibleWrites'],_0x313a9e);return _0x548547['forEachChild'](R,(_0xf46b3e,_0x27d926)=>{const _0xb84673=it(ve(_0x516700,new C(_0xf46b3e)),_0x27d926);_0x65beea=_0x65beea['updateImmediateChild'](_0xf46b3e,_0xb84673);}),rr(_0x516700)['forEach'](_0x56ab04=>{_0x65beea=_0x65beea['updateImmediateChild'](_0x56ab04['name'],_0x56ab04['node']);}),_0x65beea;}else{const _0x3d6306=ve(_0x15b57d['visibleWrites'],_0x313a9e);return rr(_0x3d6306)['forEach'](_0x5a3e2e=>{_0x65beea=_0x65beea['updateImmediateChild'](_0x5a3e2e['name'],_0x5a3e2e['node']);}),_0x65beea;}}function pu(_0xa732b,_0x179561,_0x1bc638,_0xe86475,_0x320680){f(_0xe86475||_0x320680,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x92bdbd=A(_0x179561,_0x1bc638);if(wi(_0xa732b['visibleWrites'],_0x92bdbd))return null;{const _0x54629f=ve(_0xa732b['visibleWrites'],_0x92bdbd);return Ci(_0x54629f)?_0x320680['getChild'](_0x1bc638):it(_0x54629f,_0x320680['getChild'](_0x1bc638));}}function _u(_0x1214f4,_0x15ad2e,_0x1e3b04,_0x47ebce){const _0x5a5bb2=A(_0x15ad2e,_0x1e3b04),_0x394eea=$e(_0x1214f4['visibleWrites'],_0x5a5bb2);if(_0x394eea!=null)return _0x394eea;if(_0x47ebce['isCompleteForChild'](_0x1e3b04)){const _0x466251=ve(_0x1214f4['visibleWrites'],_0x5a5bb2);return it(_0x466251,_0x47ebce['getNode']()['getImmediateChild'](_0x1e3b04));}else return null;}function gu(_0xd1985d,_0x4cff8c){return $e(_0xd1985d['visibleWrites'],_0x4cff8c);}function mu(_0x12cf3f,_0x55f1f0,_0x5ae598,_0x11f9a7,_0x582823,_0x56eef9,_0x1c39ec){let _0x2e1d9b;const _0x392c07=ve(_0x12cf3f['visibleWrites'],_0x55f1f0),_0x199e6a=$e(_0x392c07,w());if(_0x199e6a!=null)_0x2e1d9b=_0x199e6a;else{if(_0x5ae598!=null)_0x2e1d9b=it(_0x392c07,_0x5ae598);else return[];}if(_0x2e1d9b=_0x2e1d9b['withIndex'](_0x1c39ec),!_0x2e1d9b['isEmpty']()&&!_0x2e1d9b['isLeafNode']()){const _0x2cd126=[],_0x3d47d2=_0x1c39ec['getCompare'](),_0x300773=_0x56eef9?_0x2e1d9b['getReverseIteratorFrom'](_0x11f9a7,_0x1c39ec):_0x2e1d9b['getIteratorFrom'](_0x11f9a7,_0x1c39ec);let _0x4236ad=_0x300773['getNext']();for(;_0x4236ad&&_0x2cd126['length']<_0x582823;)_0x3d47d2(_0x4236ad,_0x11f9a7)!==0x0&&_0x2cd126['push'](_0x4236ad),_0x4236ad=_0x300773['getNext']();return _0x2cd126;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x228284,_0x56ef71,_0x403ec6,_0x75b12a){return Uo(_0x228284['writeTree'],_0x228284['treePath'],_0x56ef71,_0x403ec6,_0x75b12a);}function es(_0x31241d,_0x238437){return fu(_0x31241d['writeTree'],_0x31241d['treePath'],_0x238437);}function or(_0x8cfadd,_0x1656d5,_0x28d24c,_0x3f8d8d){return pu(_0x8cfadd['writeTree'],_0x8cfadd['treePath'],_0x1656d5,_0x28d24c,_0x3f8d8d);}function yn(_0x1594cc,_0xcb36dd){return gu(_0x1594cc['writeTree'],A(_0x1594cc['treePath'],_0xcb36dd));}function vu(_0x40a2ac,_0x490356,_0x1f8f2e,_0x33b597,_0xd5963f,_0x5c18f9){return mu(_0x40a2ac['writeTree'],_0x40a2ac['treePath'],_0x490356,_0x1f8f2e,_0x33b597,_0xd5963f,_0x5c18f9);}function ts(_0x26759a,_0x40bbbc,_0x10bde1){return _u(_0x26759a['writeTree'],_0x26759a['treePath'],_0x40bbbc,_0x10bde1);}function Wo(_0x41e9e4,_0x3b3e70){return Bo(A(_0x41e9e4['treePath'],_0x3b3e70),_0x41e9e4['writeTree']);}function Bo(_0x2c0fd2,_0x34e062){return{'treePath':_0x2c0fd2,'writeTree':_0x34e062};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x49619a){const _0x103116=_0x49619a['type'],_0x11f128=_0x49619a['childName'];f(_0x103116==='child_added'||_0x103116==='child_changed'||_0x103116==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x11f128!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5f16ef=this['changeMap']['get'](_0x11f128);if(_0x5f16ef){const _0x2c556b=_0x5f16ef['type'];if(_0x103116==='child_added'&&_0x2c556b==='child_removed')this['changeMap']['set'](_0x11f128,Pt(_0x11f128,_0x49619a['snapshotNode'],_0x5f16ef['snapshotNode']));else{if(_0x103116==='child_removed'&&_0x2c556b==='child_added')this['changeMap']['delete'](_0x11f128);else{if(_0x103116==='child_removed'&&_0x2c556b==='child_changed')this['changeMap']['set'](_0x11f128,Nt(_0x11f128,_0x5f16ef['oldSnap']));else{if(_0x103116==='child_changed'&&_0x2c556b==='child_added')this['changeMap']['set'](_0x11f128,tt(_0x11f128,_0x49619a['snapshotNode']));else{if(_0x103116==='child_changed'&&_0x2c556b==='child_changed')this['changeMap']['set'](_0x11f128,Pt(_0x11f128,_0x49619a['snapshotNode'],_0x5f16ef['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x49619a+'\x20occurred\x20after\x20'+_0x5f16ef);}}}}}else this['changeMap']['set'](_0x11f128,_0x49619a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x35c372){return null;}['getChildAfterChild'](_0xf5e070,_0x1dc9ae,_0x2272e4){return null;}}const Vo=new Iu();class ns{constructor(_0x3fb1a3,_0x35c702,_0x371a06=null){this['writes_']=_0x3fb1a3,this['viewCache_']=_0x35c702,this['optCompleteServerCache_']=_0x371a06;}['getCompleteChild'](_0x3c8013){const _0x2ce7ae=this['viewCache_']['eventCache'];if(_0x2ce7ae['isCompleteForChild'](_0x3c8013))return _0x2ce7ae['getNode']()['getImmediateChild'](_0x3c8013);{const _0x5c2475=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x3c8013,_0x5c2475);}}['getChildAfterChild'](_0x3bd752,_0x10dc41,_0x21e533){const _0x40025a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x22074b=vu(this['writes_'],_0x40025a,_0x10dc41,0x1,_0x21e533,_0x3bd752);return _0x22074b['length']===0x0?null:_0x22074b[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x3c19a4){return{'filter':_0x3c19a4};}function Cu(_0x4c4960,_0x3dad45){f(_0x3dad45['eventCache']['getNode']()['isIndexed'](_0x4c4960['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3dad45['serverCache']['getNode']()['isIndexed'](_0x4c4960['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x14239b,_0x2dbf33,_0x6777e9,_0x1c5ea8,_0x361822){const _0x2108d3=new Eu();let _0x2ae248,_0xb9d70b;if(_0x6777e9['type']===q['OVERWRITE']){const _0x3c5079=_0x6777e9;_0x3c5079['source']['fromUser']?_0x2ae248=Ti(_0x14239b,_0x2dbf33,_0x3c5079['path'],_0x3c5079['snap'],_0x1c5ea8,_0x361822,_0x2108d3):(f(_0x3c5079['source']['fromServer'],'Unknown\x20source.'),_0xb9d70b=_0x3c5079['source']['tagged']||_0x2dbf33['serverCache']['isFiltered']()&&!v(_0x3c5079['path']),_0x2ae248=vn(_0x14239b,_0x2dbf33,_0x3c5079['path'],_0x3c5079['snap'],_0x1c5ea8,_0x361822,_0xb9d70b,_0x2108d3));}else{if(_0x6777e9['type']===q['MERGE']){const _0x40e35e=_0x6777e9;_0x40e35e['source']['fromUser']?_0x2ae248=bu(_0x14239b,_0x2dbf33,_0x40e35e['path'],_0x40e35e['children'],_0x1c5ea8,_0x361822,_0x2108d3):(f(_0x40e35e['source']['fromServer'],'Unknown\x20source.'),_0xb9d70b=_0x40e35e['source']['tagged']||_0x2dbf33['serverCache']['isFiltered'](),_0x2ae248=Si(_0x14239b,_0x2dbf33,_0x40e35e['path'],_0x40e35e['children'],_0x1c5ea8,_0x361822,_0xb9d70b,_0x2108d3));}else{if(_0x6777e9['type']===q['ACK_USER_WRITE']){const _0x403203=_0x6777e9;_0x403203['revert']?_0x2ae248=ku(_0x14239b,_0x2dbf33,_0x403203['path'],_0x1c5ea8,_0x361822,_0x2108d3):_0x2ae248=Ru(_0x14239b,_0x2dbf33,_0x403203['path'],_0x403203['affectedTree'],_0x1c5ea8,_0x361822,_0x2108d3);}else{if(_0x6777e9['type']===q['LISTEN_COMPLETE'])_0x2ae248=Au(_0x14239b,_0x2dbf33,_0x6777e9['path'],_0x1c5ea8,_0x2108d3);else throw ot('Unknown\x20operation\x20type:\x20'+_0x6777e9['type']);}}}const _0x47f2af=_0x2108d3['getChanges']();return Su(_0x2dbf33,_0x2ae248,_0x47f2af),{'viewCache':_0x2ae248,'changes':_0x47f2af};}function Su(_0x5e1b72,_0x10437d,_0x4b80bc){const _0x80773a=_0x10437d['eventCache'];if(_0x80773a['isFullyInitialized']()){const _0x200844=_0x80773a['getNode']()['isLeafNode']()||_0x80773a['getNode']()['isEmpty'](),_0x3fe2d9=gn(_0x5e1b72);(_0x4b80bc['length']>0x0||!_0x5e1b72['eventCache']['isFullyInitialized']()||_0x200844&&!_0x80773a['getNode']()['equals'](_0x3fe2d9)||!_0x80773a['getNode']()['getPriority']()['equals'](_0x3fe2d9['getPriority']()))&&_0x4b80bc['push'](Oo(gn(_0x10437d)));}}function Ho(_0x3e037e,_0x888eb,_0x536fd8,_0x51e749,_0x231798,_0x97bdaa){const _0xb72ad3=_0x888eb['eventCache'];if(yn(_0x51e749,_0x536fd8)!=null)return _0x888eb;{let _0x44faa1,_0x3a1f90;if(v(_0x536fd8)){if(f(_0x888eb['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x888eb['serverCache']['isFiltered']()){const _0x41f567=Ue(_0x888eb),_0x3a49df=_0x41f567 instanceof g?_0x41f567:g['EMPTY_NODE'],_0x15e7ed=es(_0x51e749,_0x3a49df);_0x44faa1=_0x3e037e['filter']['updateFullNode'](_0x888eb['eventCache']['getNode'](),_0x15e7ed,_0x97bdaa);}else{const _0x49d9f6=mn(_0x51e749,Ue(_0x888eb));_0x44faa1=_0x3e037e['filter']['updateFullNode'](_0x888eb['eventCache']['getNode'](),_0x49d9f6,_0x97bdaa);}}else{const _0x5b5924=y(_0x536fd8);if(_0x5b5924==='.priority'){f(we(_0x536fd8)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x30a309=_0xb72ad3['getNode']();_0x3a1f90=_0x888eb['serverCache']['getNode']();const _0x1c020f=or(_0x51e749,_0x536fd8,_0x30a309,_0x3a1f90);_0x1c020f!=null?_0x44faa1=_0x3e037e['filter']['updatePriority'](_0x30a309,_0x1c020f):_0x44faa1=_0xb72ad3['getNode']();}else{const _0x1fe80c=b(_0x536fd8);let _0x5197c5;if(_0xb72ad3['isCompleteForChild'](_0x5b5924)){_0x3a1f90=_0x888eb['serverCache']['getNode']();const _0x1cce2c=or(_0x51e749,_0x536fd8,_0xb72ad3['getNode'](),_0x3a1f90);_0x1cce2c!=null?_0x5197c5=_0xb72ad3['getNode']()['getImmediateChild'](_0x5b5924)['updateChild'](_0x1fe80c,_0x1cce2c):_0x5197c5=_0xb72ad3['getNode']()['getImmediateChild'](_0x5b5924);}else _0x5197c5=ts(_0x51e749,_0x5b5924,_0x888eb['serverCache']);_0x5197c5!=null?_0x44faa1=_0x3e037e['filter']['updateChild'](_0xb72ad3['getNode'](),_0x5b5924,_0x5197c5,_0x1fe80c,_0x231798,_0x97bdaa):_0x44faa1=_0xb72ad3['getNode']();}}return wt(_0x888eb,_0x44faa1,_0xb72ad3['isFullyInitialized']()||v(_0x536fd8),_0x3e037e['filter']['filtersNodes']());}}function vn(_0xedf6e6,_0x3035f0,_0x4d8a64,_0x10c1fb,_0x2f3825,_0x43e5d5,_0x34b92a,_0x51313b){const _0x4e7734=_0x3035f0['serverCache'];let _0x5bf9c0;const _0x3b5322=_0x34b92a?_0xedf6e6['filter']:_0xedf6e6['filter']['getIndexedFilter']();if(v(_0x4d8a64))_0x5bf9c0=_0x3b5322['updateFullNode'](_0x4e7734['getNode'](),_0x10c1fb,null);else{if(_0x3b5322['filtersNodes']()&&!_0x4e7734['isFiltered']()){const _0x1190d9=_0x4e7734['getNode']()['updateChild'](_0x4d8a64,_0x10c1fb);_0x5bf9c0=_0x3b5322['updateFullNode'](_0x4e7734['getNode'](),_0x1190d9,null);}else{const _0x4cf8c5=y(_0x4d8a64);if(!_0x4e7734['isCompleteForPath'](_0x4d8a64)&&we(_0x4d8a64)>0x1)return _0x3035f0;const _0x26f8ce=b(_0x4d8a64),_0x3587d4=_0x4e7734['getNode']()['getImmediateChild'](_0x4cf8c5)['updateChild'](_0x26f8ce,_0x10c1fb);_0x4cf8c5==='.priority'?_0x5bf9c0=_0x3b5322['updatePriority'](_0x4e7734['getNode'](),_0x3587d4):_0x5bf9c0=_0x3b5322['updateChild'](_0x4e7734['getNode'](),_0x4cf8c5,_0x3587d4,_0x26f8ce,Vo,null);}}const _0x12a466=Lo(_0x3035f0,_0x5bf9c0,_0x4e7734['isFullyInitialized']()||v(_0x4d8a64),_0x3b5322['filtersNodes']()),_0x2a166f=new ns(_0x2f3825,_0x12a466,_0x43e5d5);return Ho(_0xedf6e6,_0x12a466,_0x4d8a64,_0x2f3825,_0x2a166f,_0x51313b);}function Ti(_0x2adc89,_0x166a9a,_0x472a6f,_0x6559e8,_0x579f9c,_0x24ef35,_0x53cc37){const _0x3355c9=_0x166a9a['eventCache'];let _0xb754cf,_0x551b79;const _0x431e9a=new ns(_0x579f9c,_0x166a9a,_0x24ef35);if(v(_0x472a6f))_0x551b79=_0x2adc89['filter']['updateFullNode'](_0x166a9a['eventCache']['getNode'](),_0x6559e8,_0x53cc37),_0xb754cf=wt(_0x166a9a,_0x551b79,!0x0,_0x2adc89['filter']['filtersNodes']());else{const _0x7877af=y(_0x472a6f);if(_0x7877af==='.priority')_0x551b79=_0x2adc89['filter']['updatePriority'](_0x166a9a['eventCache']['getNode'](),_0x6559e8),_0xb754cf=wt(_0x166a9a,_0x551b79,_0x3355c9['isFullyInitialized'](),_0x3355c9['isFiltered']());else{const _0x40de35=b(_0x472a6f),_0x10c759=_0x3355c9['getNode']()['getImmediateChild'](_0x7877af);let _0x4dd3ac;if(v(_0x40de35))_0x4dd3ac=_0x6559e8;else{const _0x3dfa80=_0x431e9a['getCompleteChild'](_0x7877af);_0x3dfa80!=null?Gi(_0x40de35)==='.priority'&&_0x3dfa80['getChild'](To(_0x40de35))['isEmpty']()?_0x4dd3ac=_0x3dfa80:_0x4dd3ac=_0x3dfa80['updateChild'](_0x40de35,_0x6559e8):_0x4dd3ac=g['EMPTY_NODE'];}if(_0x10c759['equals'](_0x4dd3ac))_0xb754cf=_0x166a9a;else{const _0x947bde=_0x2adc89['filter']['updateChild'](_0x3355c9['getNode'](),_0x7877af,_0x4dd3ac,_0x40de35,_0x431e9a,_0x53cc37);_0xb754cf=wt(_0x166a9a,_0x947bde,_0x3355c9['isFullyInitialized'](),_0x2adc89['filter']['filtersNodes']());}}}return _0xb754cf;}function ar(_0x49bb80,_0x17883c){return _0x49bb80['eventCache']['isCompleteForChild'](_0x17883c);}function bu(_0x4ae46d,_0x5e1ad3,_0x1209b8,_0x34648d,_0x5b61cd,_0x3f3174,_0x5ef964){let _0x25ccac=_0x5e1ad3;return _0x34648d['foreach']((_0x46ffd8,_0x32ca16)=>{const _0x24d331=A(_0x1209b8,_0x46ffd8);ar(_0x5e1ad3,y(_0x24d331))&&(_0x25ccac=Ti(_0x4ae46d,_0x25ccac,_0x24d331,_0x32ca16,_0x5b61cd,_0x3f3174,_0x5ef964));}),_0x34648d['foreach']((_0x37662d,_0x4c5878)=>{const _0x1a4873=A(_0x1209b8,_0x37662d);ar(_0x5e1ad3,y(_0x1a4873))||(_0x25ccac=Ti(_0x4ae46d,_0x25ccac,_0x1a4873,_0x4c5878,_0x5b61cd,_0x3f3174,_0x5ef964));}),_0x25ccac;}function cr(_0x34a78d,_0x4c5dff,_0x122394){return _0x122394['foreach']((_0x51cad1,_0x533064)=>{_0x4c5dff=_0x4c5dff['updateChild'](_0x51cad1,_0x533064);}),_0x4c5dff;}function Si(_0x440441,_0x589d01,_0x477581,_0x4a72b1,_0x4fccdb,_0xb6c869,_0x3f039f,_0x1cce70){if(_0x589d01['serverCache']['getNode']()['isEmpty']()&&!_0x589d01['serverCache']['isFullyInitialized']())return _0x589d01;let _0x51f843=_0x589d01,_0x57ed70;v(_0x477581)?_0x57ed70=_0x4a72b1:_0x57ed70=new S(null)['setTree'](_0x477581,_0x4a72b1);const _0x45306e=_0x589d01['serverCache']['getNode']();return _0x57ed70['children']['inorderTraversal']((_0x5e9127,_0x537d29)=>{if(_0x45306e['hasChild'](_0x5e9127)){const _0x5a11ac=_0x589d01['serverCache']['getNode']()['getImmediateChild'](_0x5e9127),_0x374129=cr(_0x440441,_0x5a11ac,_0x537d29);_0x51f843=vn(_0x440441,_0x51f843,new C(_0x5e9127),_0x374129,_0x4fccdb,_0xb6c869,_0x3f039f,_0x1cce70);}}),_0x57ed70['children']['inorderTraversal']((_0x2abaea,_0xbac13f)=>{const _0x29eeaa=!_0x589d01['serverCache']['isCompleteForChild'](_0x2abaea)&&_0xbac13f['value']===null;if(!_0x45306e['hasChild'](_0x2abaea)&&!_0x29eeaa){const _0x44cfde=_0x589d01['serverCache']['getNode']()['getImmediateChild'](_0x2abaea),_0x31e16b=cr(_0x440441,_0x44cfde,_0xbac13f);_0x51f843=vn(_0x440441,_0x51f843,new C(_0x2abaea),_0x31e16b,_0x4fccdb,_0xb6c869,_0x3f039f,_0x1cce70);}}),_0x51f843;}function Ru(_0x20ccc3,_0x1a82d4,_0x5ec159,_0x59099e,_0x37fa6f,_0x4e4d17,_0x579bb1){if(yn(_0x37fa6f,_0x5ec159)!=null)return _0x1a82d4;const _0x4aeb3c=_0x1a82d4['serverCache']['isFiltered'](),_0x1e5db7=_0x1a82d4['serverCache'];if(_0x59099e['value']!=null){if(v(_0x5ec159)&&_0x1e5db7['isFullyInitialized']()||_0x1e5db7['isCompleteForPath'](_0x5ec159))return vn(_0x20ccc3,_0x1a82d4,_0x5ec159,_0x1e5db7['getNode']()['getChild'](_0x5ec159),_0x37fa6f,_0x4e4d17,_0x4aeb3c,_0x579bb1);if(v(_0x5ec159)){let _0x56ac01=new S(null);return _0x1e5db7['getNode']()['forEachChild'](ye,(_0x129560,_0x1b2bc0)=>{_0x56ac01=_0x56ac01['set'](new C(_0x129560),_0x1b2bc0);}),Si(_0x20ccc3,_0x1a82d4,_0x5ec159,_0x56ac01,_0x37fa6f,_0x4e4d17,_0x4aeb3c,_0x579bb1);}else return _0x1a82d4;}else{let _0x14cb27=new S(null);return _0x59099e['foreach']((_0x308c6f,_0x204163)=>{const _0x2b902e=A(_0x5ec159,_0x308c6f);_0x1e5db7['isCompleteForPath'](_0x2b902e)&&(_0x14cb27=_0x14cb27['set'](_0x308c6f,_0x1e5db7['getNode']()['getChild'](_0x2b902e)));}),Si(_0x20ccc3,_0x1a82d4,_0x5ec159,_0x14cb27,_0x37fa6f,_0x4e4d17,_0x4aeb3c,_0x579bb1);}}function Au(_0x541cb6,_0x410ad1,_0x159536,_0x6de80b,_0x221e69){const _0x2af612=_0x410ad1['serverCache'],_0x15ed7c=Lo(_0x410ad1,_0x2af612['getNode'](),_0x2af612['isFullyInitialized']()||v(_0x159536),_0x2af612['isFiltered']());return Ho(_0x541cb6,_0x15ed7c,_0x159536,_0x6de80b,Vo,_0x221e69);}function ku(_0x2a814d,_0x41ebb1,_0x2b6d7e,_0xe16612,_0x2bcf17,_0x3e8ebe){let _0x5794db;if(yn(_0xe16612,_0x2b6d7e)!=null)return _0x41ebb1;{const _0x282437=new ns(_0xe16612,_0x41ebb1,_0x2bcf17),_0x4a52ad=_0x41ebb1['eventCache']['getNode']();let _0x59db84;if(v(_0x2b6d7e)||y(_0x2b6d7e)==='.priority'){let _0x438c07;if(_0x41ebb1['serverCache']['isFullyInitialized']())_0x438c07=mn(_0xe16612,Ue(_0x41ebb1));else{const _0x46d53d=_0x41ebb1['serverCache']['getNode']();f(_0x46d53d instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x438c07=es(_0xe16612,_0x46d53d);}_0x438c07=_0x438c07,_0x59db84=_0x2a814d['filter']['updateFullNode'](_0x4a52ad,_0x438c07,_0x3e8ebe);}else{const _0x29fed9=y(_0x2b6d7e);let _0x1a158d=ts(_0xe16612,_0x29fed9,_0x41ebb1['serverCache']);_0x1a158d==null&&_0x41ebb1['serverCache']['isCompleteForChild'](_0x29fed9)&&(_0x1a158d=_0x4a52ad['getImmediateChild'](_0x29fed9)),_0x1a158d!=null?_0x59db84=_0x2a814d['filter']['updateChild'](_0x4a52ad,_0x29fed9,_0x1a158d,b(_0x2b6d7e),_0x282437,_0x3e8ebe):_0x41ebb1['eventCache']['getNode']()['hasChild'](_0x29fed9)?_0x59db84=_0x2a814d['filter']['updateChild'](_0x4a52ad,_0x29fed9,g['EMPTY_NODE'],b(_0x2b6d7e),_0x282437,_0x3e8ebe):_0x59db84=_0x4a52ad,_0x59db84['isEmpty']()&&_0x41ebb1['serverCache']['isFullyInitialized']()&&(_0x5794db=mn(_0xe16612,Ue(_0x41ebb1)),_0x5794db['isLeafNode']()&&(_0x59db84=_0x2a814d['filter']['updateFullNode'](_0x59db84,_0x5794db,_0x3e8ebe)));}return _0x5794db=_0x41ebb1['serverCache']['isFullyInitialized']()||yn(_0xe16612,w())!=null,wt(_0x41ebb1,_0x59db84,_0x5794db,_0x2a814d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x5dbe9c,_0x3f71e1){this['query_']=_0x5dbe9c,this['eventRegistrations_']=[];const _0x1c3c0c=this['query_']['_queryParams'],_0x3967af=new Yi(_0x1c3c0c['getIndex']()),_0x616ad7=qh(_0x1c3c0c);this['processor_']=wu(_0x616ad7);const _0x3f4e6d=_0x3f71e1['serverCache'],_0x3315ea=_0x3f71e1['eventCache'],_0x413f19=_0x3967af['updateFullNode'](g['EMPTY_NODE'],_0x3f4e6d['getNode'](),null),_0x2319c5=_0x616ad7['updateFullNode'](g['EMPTY_NODE'],_0x3315ea['getNode'](),null),_0x410179=new Ce(_0x413f19,_0x3f4e6d['isFullyInitialized'](),_0x3967af['filtersNodes']()),_0x66fa30=new Ce(_0x2319c5,_0x3315ea['isFullyInitialized'](),_0x616ad7['filtersNodes']());this['viewCache_']=Dn(_0x66fa30,_0x410179),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x49a1e7){return _0x49a1e7['viewCache_']['serverCache']['getNode']();}function Ou(_0x388103){return gn(_0x388103['viewCache_']);}function Du(_0x251a59,_0x3960fc){const _0x22c0e0=Ue(_0x251a59['viewCache_']);return _0x22c0e0&&(_0x251a59['query']['_queryParams']['loadsAllData']()||!v(_0x3960fc)&&!_0x22c0e0['getImmediateChild'](y(_0x3960fc))['isEmpty']())?_0x22c0e0['getChild'](_0x3960fc):null;}function lr(_0x525842){return _0x525842['eventRegistrations_']['length']===0x0;}function Mu(_0x181a78,_0x58abb0){_0x181a78['eventRegistrations_']['push'](_0x58abb0);}function hr(_0x28c9ef,_0x2e66c1,_0x9db662){const _0xa86415=[];if(_0x9db662){f(_0x2e66c1==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3fac69=_0x28c9ef['query']['_path'];_0x28c9ef['eventRegistrations_']['forEach'](_0x463a65=>{const _0x2d7e47=_0x463a65['createCancelEvent'](_0x9db662,_0x3fac69);_0x2d7e47&&_0xa86415['push'](_0x2d7e47);});}if(_0x2e66c1){let _0x30a302=[];for(let _0x14e979=0x0;_0x14e979<_0x28c9ef['eventRegistrations_']['length'];++_0x14e979){const _0x34a652=_0x28c9ef['eventRegistrations_'][_0x14e979];if(!_0x34a652['matches'](_0x2e66c1))_0x30a302['push'](_0x34a652);else{if(_0x2e66c1['hasAnyCallback']()){_0x30a302=_0x30a302['concat'](_0x28c9ef['eventRegistrations_']['slice'](_0x14e979+0x1));break;}}}_0x28c9ef['eventRegistrations_']=_0x30a302;}else _0x28c9ef['eventRegistrations_']=[];return _0xa86415;}function ur(_0x2899ba,_0x759ec9,_0xcca842,_0x4c3b3c){_0x759ec9['type']===q['MERGE']&&_0x759ec9['source']['queryId']!==null&&(f(Ue(_0x2899ba['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x2899ba['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4bc209=_0x2899ba['viewCache_'],_0x1dc7ad=Tu(_0x2899ba['processor_'],_0x4bc209,_0x759ec9,_0xcca842,_0x4c3b3c);return Cu(_0x2899ba['processor_'],_0x1dc7ad['viewCache']),f(_0x1dc7ad['viewCache']['serverCache']['isFullyInitialized']()||!_0x4bc209['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2899ba['viewCache_']=_0x1dc7ad['viewCache'],$o(_0x2899ba,_0x1dc7ad['changes'],_0x1dc7ad['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x3a369b,_0x222ec9){const _0x47efa1=_0x3a369b['viewCache_']['eventCache'],_0x4ba0e3=[];return _0x47efa1['getNode']()['isLeafNode']()||_0x47efa1['getNode']()['forEachChild'](R,(_0x461f18,_0x1e5c8d)=>{_0x4ba0e3['push'](tt(_0x461f18,_0x1e5c8d));}),_0x47efa1['isFullyInitialized']()&&_0x4ba0e3['push'](Oo(_0x47efa1['getNode']())),$o(_0x3a369b,_0x4ba0e3,_0x47efa1['getNode'](),_0x222ec9);}function $o(_0x1a70d1,_0x25ba23,_0x2e6d36,_0x356fcb){const _0x3c4802=_0x356fcb?[_0x356fcb]:_0x1a70d1['eventRegistrations_'];return nu(_0x1a70d1['eventGenerator_'],_0x25ba23,_0x2e6d36,_0x3c4802);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x57ba9a){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x57ba9a;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x4252e0){return _0x4252e0['views']['size']===0x0;}function is(_0x131868,_0x26fc18,_0x266aba,_0x3ccb5c){const _0x24db28=_0x26fc18['source']['queryId'];if(_0x24db28!==null){const _0x10fb32=_0x131868['views']['get'](_0x24db28);return f(_0x10fb32!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x10fb32,_0x26fc18,_0x266aba,_0x3ccb5c);}else{let _0x361c58=[];for(const _0x253867 of _0x131868['views']['values']())_0x361c58=_0x361c58['concat'](ur(_0x253867,_0x26fc18,_0x266aba,_0x3ccb5c));return _0x361c58;}}function qo(_0x3ea589,_0x721fa7,_0x75db67,_0x28a337,_0x5a333){const _0x3df2de=_0x721fa7['_queryIdentifier'],_0x2effbf=_0x3ea589['views']['get'](_0x3df2de);if(!_0x2effbf){let _0x5512fe=mn(_0x75db67,_0x5a333?_0x28a337:null),_0x20d94=!0x1;_0x5512fe?_0x20d94=!0x0:_0x28a337 instanceof g?(_0x5512fe=es(_0x75db67,_0x28a337),_0x20d94=!0x1):(_0x5512fe=g['EMPTY_NODE'],_0x20d94=!0x1);const _0x28ba03=Dn(new Ce(_0x5512fe,_0x20d94,!0x1),new Ce(_0x28a337,_0x5a333,!0x1));return new Nu(_0x721fa7,_0x28ba03);}return _0x2effbf;}function Wu(_0x1bc9f7,_0x5c40f8,_0x1164e0,_0x1a3f45,_0x30c9da,_0x2a0040){const _0x3d5340=qo(_0x1bc9f7,_0x5c40f8,_0x1a3f45,_0x30c9da,_0x2a0040);return _0x1bc9f7['views']['has'](_0x5c40f8['_queryIdentifier'])||_0x1bc9f7['views']['set'](_0x5c40f8['_queryIdentifier'],_0x3d5340),Mu(_0x3d5340,_0x1164e0),Lu(_0x3d5340,_0x1164e0);}function Bu(_0x36ae9c,_0x329aae,_0x352efa,_0x84727a){const _0x434ae6=_0x329aae['_queryIdentifier'],_0x5be580=[];let _0x5d129b=[];const _0x34ca3f=Te(_0x36ae9c);if(_0x434ae6==='default'){for(const [_0x4158ec,_0x1d466b]of _0x36ae9c['views']['entries']())_0x5d129b=_0x5d129b['concat'](hr(_0x1d466b,_0x352efa,_0x84727a)),lr(_0x1d466b)&&(_0x36ae9c['views']['delete'](_0x4158ec),_0x1d466b['query']['_queryParams']['loadsAllData']()||_0x5be580['push'](_0x1d466b['query']));}else{const _0x35aba0=_0x36ae9c['views']['get'](_0x434ae6);_0x35aba0&&(_0x5d129b=_0x5d129b['concat'](hr(_0x35aba0,_0x352efa,_0x84727a)),lr(_0x35aba0)&&(_0x36ae9c['views']['delete'](_0x434ae6),_0x35aba0['query']['_queryParams']['loadsAllData']()||_0x5be580['push'](_0x35aba0['query'])));}return _0x34ca3f&&!Te(_0x36ae9c)&&_0x5be580['push'](new(Fu())(_0x329aae['_repo'],_0x329aae['_path'])),{'removed':_0x5be580,'events':_0x5d129b};}function zo(_0x2471a8){const _0x4e522a=[];for(const _0x3ab045 of _0x2471a8['views']['values']())_0x3ab045['query']['_queryParams']['loadsAllData']()||_0x4e522a['push'](_0x3ab045);return _0x4e522a;}function Ee(_0x4a7de2,_0x5b0546){let _0x3f5bc7=null;for(const _0x269efb of _0x4a7de2['views']['values']())_0x3f5bc7=_0x3f5bc7||Du(_0x269efb,_0x5b0546);return _0x3f5bc7;}function jo(_0x46c04c,_0x3c9dab){if(_0x3c9dab['_queryParams']['loadsAllData']())return Ln(_0x46c04c);{const _0x6ba80b=_0x3c9dab['_queryIdentifier'];return _0x46c04c['views']['get'](_0x6ba80b);}}function Ko(_0x28b615,_0x3c3277){return jo(_0x28b615,_0x3c3277)!=null;}function Te(_0x597055){return Ln(_0x597055)!=null;}function Ln(_0x541ef1){for(const _0x1a936c of _0x541ef1['views']['values']())if(_0x1a936c['query']['_queryParams']['loadsAllData']())return _0x1a936c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1b1059){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1b1059;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x2046aa){this['listenProvider_']=_0x2046aa,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x36bc92,_0x3426d0,_0x15262a,_0x156738,_0x3fcd90){return ou(_0x36bc92['pendingWriteTree_'],_0x3426d0,_0x15262a,_0x156738,_0x3fcd90),_0x3fcd90?ht(_0x36bc92,new Fe(Ji(),_0x3426d0,_0x15262a)):[];}function Gu(_0x3bf580,_0xfd42d7,_0x4ea0fc,_0x4ff33f){au(_0x3bf580['pendingWriteTree_'],_0xfd42d7,_0x4ea0fc,_0x4ff33f);const _0x3178d7=S['fromObject'](_0x4ea0fc);return ht(_0x3bf580,new nt(Ji(),_0xfd42d7,_0x3178d7));}function pe(_0x4c8c64,_0xb53d55,_0x348449=!0x1){const _0x3fcc02=cu(_0x4c8c64['pendingWriteTree_'],_0xb53d55);if(lu(_0x4c8c64['pendingWriteTree_'],_0xb53d55)){let _0x10be25=new S(null);return _0x3fcc02['snap']!=null?_0x10be25=_0x10be25['set'](w(),!0x0):x(_0x3fcc02['children'],_0x4e8bac=>{_0x10be25=_0x10be25['set'](new C(_0x4e8bac),!0x0);}),ht(_0x4c8c64,new _n(_0x3fcc02['path'],_0x10be25,_0x348449));}else return[];}function $t(_0x5de76e,_0x3e6c44,_0x27a0fd){return ht(_0x5de76e,new Fe(Xi(),_0x3e6c44,_0x27a0fd));}function qu(_0x4a2960,_0x2e40ac,_0x322f2e){const _0x399578=S['fromObject'](_0x322f2e);return ht(_0x4a2960,new nt(Xi(),_0x2e40ac,_0x399578));}function zu(_0x5375c7,_0x584f76){return ht(_0x5375c7,new Dt(Xi(),_0x584f76));}function ju(_0x10c213,_0x4e2439,_0x33b450){const _0x5760b3=rs(_0x10c213,_0x33b450);if(_0x5760b3){const _0x5c9ca7=os(_0x5760b3),_0x39d9ca=_0x5c9ca7['path'],_0x43cfef=_0x5c9ca7['queryId'],_0x51e87e=F(_0x39d9ca,_0x4e2439),_0x3e2c88=new Dt(Zi(_0x43cfef),_0x51e87e);return as(_0x10c213,_0x39d9ca,_0x3e2c88);}else return[];}function wn(_0x2a7c03,_0x23e33e,_0x51f043,_0x23b107,_0x5a9ded=!0x1){const _0x1385a1=_0x23e33e['_path'],_0x1f689e=_0x2a7c03['syncPointTree_']['get'](_0x1385a1);let _0x295b9b=[];if(_0x1f689e&&(_0x23e33e['_queryIdentifier']==='default'||Ko(_0x1f689e,_0x23e33e))){const _0x3178ab=Bu(_0x1f689e,_0x23e33e,_0x51f043,_0x23b107);Uu(_0x1f689e)&&(_0x2a7c03['syncPointTree_']=_0x2a7c03['syncPointTree_']['remove'](_0x1385a1));const _0x3ee189=_0x3178ab['removed'];if(_0x295b9b=_0x3178ab['events'],!_0x5a9ded){const _0x4c7613=_0x3ee189['findIndex'](_0x27e080=>_0x27e080['_queryParams']['loadsAllData']())!==-0x1,_0xbae81c=_0x2a7c03['syncPointTree_']['findOnPath'](_0x1385a1,(_0x22b712,_0x28019e)=>Te(_0x28019e));if(_0x4c7613&&!_0xbae81c){const _0x498789=_0x2a7c03['syncPointTree_']['subtree'](_0x1385a1);if(!_0x498789['isEmpty']()){const _0x31ee2e=Qu(_0x498789);for(let _0x21c911=0x0;_0x21c911<_0x31ee2e['length'];++_0x21c911){const _0x423e6e=_0x31ee2e[_0x21c911],_0x22a87c=_0x423e6e['query'],_0x1f8910=Xo(_0x2a7c03,_0x423e6e);_0x2a7c03['listenProvider_']['startListening'](Tt(_0x22a87c),Mt(_0x2a7c03,_0x22a87c),_0x1f8910['hashFn'],_0x1f8910['onComplete']);}}}!_0xbae81c&&_0x3ee189['length']>0x0&&!_0x23b107&&(_0x4c7613?_0x2a7c03['listenProvider_']['stopListening'](Tt(_0x23e33e),null):_0x3ee189['forEach'](_0x2d9212=>{const _0x7dadf4=_0x2a7c03['queryToTagMap']['get'](Fn(_0x2d9212));_0x2a7c03['listenProvider_']['stopListening'](Tt(_0x2d9212),_0x7dadf4);}));}Ju(_0x2a7c03,_0x3ee189);}return _0x295b9b;}function Yo(_0x2f635e,_0x577888,_0x55f218,_0x58ef6b){const _0x2b052f=rs(_0x2f635e,_0x58ef6b);if(_0x2b052f!=null){const _0x450175=os(_0x2b052f),_0x4b85bf=_0x450175['path'],_0x4afc44=_0x450175['queryId'],_0x1be827=F(_0x4b85bf,_0x577888),_0x36a93f=new Fe(Zi(_0x4afc44),_0x1be827,_0x55f218);return as(_0x2f635e,_0x4b85bf,_0x36a93f);}else return[];}function Ku(_0x163a3e,_0x32d7b2,_0x296881,_0x219842){const _0x3c0f72=rs(_0x163a3e,_0x219842);if(_0x3c0f72){const _0x3a37df=os(_0x3c0f72),_0x151dd7=_0x3a37df['path'],_0x732f95=_0x3a37df['queryId'],_0x18a1ab=F(_0x151dd7,_0x32d7b2),_0x59d276=S['fromObject'](_0x296881),_0x29ef05=new nt(Zi(_0x732f95),_0x18a1ab,_0x59d276);return as(_0x163a3e,_0x151dd7,_0x29ef05);}else return[];}function bi(_0x4862e0,_0x454d85,_0x406af7,_0x4c43a8=!0x1){const _0x4bf2bb=_0x454d85['_path'];let _0x7fc715=null,_0xadba6d=!0x1;_0x4862e0['syncPointTree_']['foreachOnPath'](_0x4bf2bb,(_0x47fd98,_0x569ec6)=>{const _0x2d71b2=F(_0x47fd98,_0x4bf2bb);_0x7fc715=_0x7fc715||Ee(_0x569ec6,_0x2d71b2),_0xadba6d=_0xadba6d||Te(_0x569ec6);});let _0x4c10c4=_0x4862e0['syncPointTree_']['get'](_0x4bf2bb);_0x4c10c4?(_0xadba6d=_0xadba6d||Te(_0x4c10c4),_0x7fc715=_0x7fc715||Ee(_0x4c10c4,w())):(_0x4c10c4=new Go(),_0x4862e0['syncPointTree_']=_0x4862e0['syncPointTree_']['set'](_0x4bf2bb,_0x4c10c4));let _0x33348a;_0x7fc715!=null?_0x33348a=!0x0:(_0x33348a=!0x1,_0x7fc715=g['EMPTY_NODE'],_0x4862e0['syncPointTree_']['subtree'](_0x4bf2bb)['foreachChild']((_0x5b68f8,_0x5cbd9c)=>{const _0x3b2b85=Ee(_0x5cbd9c,w());_0x3b2b85&&(_0x7fc715=_0x7fc715['updateImmediateChild'](_0x5b68f8,_0x3b2b85));}));const _0x22bbaa=Ko(_0x4c10c4,_0x454d85);if(!_0x22bbaa&&!_0x454d85['_queryParams']['loadsAllData']()){const _0x42aca1=Fn(_0x454d85);f(!_0x4862e0['queryToTagMap']['has'](_0x42aca1),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3f17a3=Xu();_0x4862e0['queryToTagMap']['set'](_0x42aca1,_0x3f17a3),_0x4862e0['tagToQueryMap']['set'](_0x3f17a3,_0x42aca1);}const _0xea9eb1=Mn(_0x4862e0['pendingWriteTree_'],_0x4bf2bb);let _0x170c19=Wu(_0x4c10c4,_0x454d85,_0x406af7,_0xea9eb1,_0x7fc715,_0x33348a);if(!_0x22bbaa&&!_0xadba6d&&!_0x4c43a8){const _0x2893f9=jo(_0x4c10c4,_0x454d85);_0x170c19=_0x170c19['concat'](Zu(_0x4862e0,_0x454d85,_0x2893f9));}return _0x170c19;}function xn(_0x3a3259,_0x459b81,_0x539ff2){const _0x3b1f5c=_0x3a3259['pendingWriteTree_'],_0x26292c=_0x3a3259['syncPointTree_']['findOnPath'](_0x459b81,(_0x3f5e75,_0x293282)=>{const _0x2bd1cb=F(_0x3f5e75,_0x459b81),_0x546f56=Ee(_0x293282,_0x2bd1cb);if(_0x546f56)return _0x546f56;});return Uo(_0x3b1f5c,_0x459b81,_0x26292c,_0x539ff2,!0x0);}function Yu(_0x4854bd,_0x57c43b){const _0x53297f=_0x57c43b['_path'];let _0x584021=null;_0x4854bd['syncPointTree_']['foreachOnPath'](_0x53297f,(_0x5beaff,_0x1715c5)=>{const _0x35cefc=F(_0x5beaff,_0x53297f);_0x584021=_0x584021||Ee(_0x1715c5,_0x35cefc);});let _0x33c835=_0x4854bd['syncPointTree_']['get'](_0x53297f);_0x33c835?_0x584021=_0x584021||Ee(_0x33c835,w()):(_0x33c835=new Go(),_0x4854bd['syncPointTree_']=_0x4854bd['syncPointTree_']['set'](_0x53297f,_0x33c835));const _0x58b8aa=_0x584021!=null,_0x6924f=_0x58b8aa?new Ce(_0x584021,!0x0,!0x1):null,_0x3023ea=Mn(_0x4854bd['pendingWriteTree_'],_0x57c43b['_path']),_0x23705a=qo(_0x33c835,_0x57c43b,_0x3023ea,_0x58b8aa?_0x6924f['getNode']():g['EMPTY_NODE'],_0x58b8aa);return Ou(_0x23705a);}function ht(_0xbe935a,_0x4467c3){return Qo(_0x4467c3,_0xbe935a['syncPointTree_'],null,Mn(_0xbe935a['pendingWriteTree_'],w()));}function Qo(_0x483e74,_0x434751,_0x5c40cf,_0x70f38f){if(v(_0x483e74['path']))return Jo(_0x483e74,_0x434751,_0x5c40cf,_0x70f38f);{const _0x5e7075=_0x434751['get'](w());_0x5c40cf==null&&_0x5e7075!=null&&(_0x5c40cf=Ee(_0x5e7075,w()));let _0x1b9dd6=[];const _0x290d28=y(_0x483e74['path']),_0x402eb2=_0x483e74['operationForChild'](_0x290d28),_0x22d088=_0x434751['children']['get'](_0x290d28);if(_0x22d088&&_0x402eb2){const _0x260b02=_0x5c40cf?_0x5c40cf['getImmediateChild'](_0x290d28):null,_0x1678f5=Wo(_0x70f38f,_0x290d28);_0x1b9dd6=_0x1b9dd6['concat'](Qo(_0x402eb2,_0x22d088,_0x260b02,_0x1678f5));}return _0x5e7075&&(_0x1b9dd6=_0x1b9dd6['concat'](is(_0x5e7075,_0x483e74,_0x70f38f,_0x5c40cf))),_0x1b9dd6;}}function Jo(_0x5dcaff,_0x3aa4e6,_0x5ca11c,_0x4fc9d3){const _0x50eb22=_0x3aa4e6['get'](w());_0x5ca11c==null&&_0x50eb22!=null&&(_0x5ca11c=Ee(_0x50eb22,w()));let _0x17e942=[];return _0x3aa4e6['children']['inorderTraversal']((_0x3a5703,_0x4ab306)=>{const _0x162bd4=_0x5ca11c?_0x5ca11c['getImmediateChild'](_0x3a5703):null,_0xef49a9=Wo(_0x4fc9d3,_0x3a5703),_0x13b353=_0x5dcaff['operationForChild'](_0x3a5703);_0x13b353&&(_0x17e942=_0x17e942['concat'](Jo(_0x13b353,_0x4ab306,_0x162bd4,_0xef49a9)));}),_0x50eb22&&(_0x17e942=_0x17e942['concat'](is(_0x50eb22,_0x5dcaff,_0x4fc9d3,_0x5ca11c))),_0x17e942;}function Xo(_0x1ee41a,_0xcc55db){const _0x11e5a8=_0xcc55db['query'],_0x48713a=Mt(_0x1ee41a,_0x11e5a8);return{'hashFn':()=>(Pu(_0xcc55db)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x46ed19=>{if(_0x46ed19==='ok')return _0x48713a?ju(_0x1ee41a,_0x11e5a8['_path'],_0x48713a):zu(_0x1ee41a,_0x11e5a8['_path']);{const _0x18e2f3=ql(_0x46ed19,_0x11e5a8);return wn(_0x1ee41a,_0x11e5a8,null,_0x18e2f3);}}};}function Mt(_0x417f46,_0x3531a1){const _0x2373dc=Fn(_0x3531a1);return _0x417f46['queryToTagMap']['get'](_0x2373dc);}function Fn(_0x5ec8e2){return _0x5ec8e2['_path']['toString']()+'$'+_0x5ec8e2['_queryIdentifier'];}function rs(_0x45f500,_0x18e9a6){return _0x45f500['tagToQueryMap']['get'](_0x18e9a6);}function os(_0x493593){const _0x4a63fd=_0x493593['indexOf']('$');return f(_0x4a63fd!==-0x1&&_0x4a63fd<_0x493593['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x493593['substr'](_0x4a63fd+0x1),'path':new C(_0x493593['substr'](0x0,_0x4a63fd))};}function as(_0x5d7a49,_0x408ef5,_0x55d702){const _0x1c9d3c=_0x5d7a49['syncPointTree_']['get'](_0x408ef5);f(_0x1c9d3c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x43c13c=Mn(_0x5d7a49['pendingWriteTree_'],_0x408ef5);return is(_0x1c9d3c,_0x55d702,_0x43c13c,null);}function Qu(_0x2b54fe){return _0x2b54fe['fold']((_0x5a67f9,_0x380418,_0x3c02c1)=>{if(_0x380418&&Te(_0x380418))return[Ln(_0x380418)];{let _0x650bef=[];return _0x380418&&(_0x650bef=zo(_0x380418)),x(_0x3c02c1,(_0x12c291,_0x214d60)=>{_0x650bef=_0x650bef['concat'](_0x214d60);}),_0x650bef;}});}function Tt(_0x46f904){return _0x46f904['_queryParams']['loadsAllData']()&&!_0x46f904['_queryParams']['isDefault']()?new(Hu())(_0x46f904['_repo'],_0x46f904['_path']):_0x46f904;}function Ju(_0x2ee070,_0xd5d291){for(let _0x1006ba=0x0;_0x1006ba<_0xd5d291['length'];++_0x1006ba){const _0x32a47a=_0xd5d291[_0x1006ba];if(!_0x32a47a['_queryParams']['loadsAllData']()){const _0x4ed5f1=Fn(_0x32a47a),_0x345cab=_0x2ee070['queryToTagMap']['get'](_0x4ed5f1);_0x2ee070['queryToTagMap']['delete'](_0x4ed5f1),_0x2ee070['tagToQueryMap']['delete'](_0x345cab);}}}function Xu(){return $u++;}function Zu(_0x2ef35e,_0x3dc4c4,_0x5c6d9e){const _0x4ca893=_0x3dc4c4['_path'],_0xf31f57=Mt(_0x2ef35e,_0x3dc4c4),_0x1aeab3=Xo(_0x2ef35e,_0x5c6d9e),_0x2053f8=_0x2ef35e['listenProvider_']['startListening'](Tt(_0x3dc4c4),_0xf31f57,_0x1aeab3['hashFn'],_0x1aeab3['onComplete']),_0x548b10=_0x2ef35e['syncPointTree_']['subtree'](_0x4ca893);if(_0xf31f57)f(!Te(_0x548b10['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x27f961=_0x548b10['fold']((_0x5534e3,_0x1407f3,_0x3de031)=>{if(!v(_0x5534e3)&&_0x1407f3&&Te(_0x1407f3))return[Ln(_0x1407f3)['query']];{let _0xe49e85=[];return _0x1407f3&&(_0xe49e85=_0xe49e85['concat'](zo(_0x1407f3)['map'](_0x4d19=>_0x4d19['query']))),x(_0x3de031,(_0x4dedaa,_0x93f8dc)=>{_0xe49e85=_0xe49e85['concat'](_0x93f8dc);}),_0xe49e85;}});for(let _0x326574=0x0;_0x326574<_0x27f961['length'];++_0x326574){const _0x490431=_0x27f961[_0x326574];_0x2ef35e['listenProvider_']['stopListening'](Tt(_0x490431),Mt(_0x2ef35e,_0x490431));}}return _0x2053f8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x314871){this['node_']=_0x314871;}['getImmediateChild'](_0x549d0a){const _0x456d6f=this['node_']['getImmediateChild'](_0x549d0a);return new cs(_0x456d6f);}['node'](){return this['node_'];}}class ls{constructor(_0x3c6745,_0x131829){this['syncTree_']=_0x3c6745,this['path_']=_0x131829;}['getImmediateChild'](_0x179669){const _0x40889b=A(this['path_'],_0x179669);return new ls(this['syncTree_'],_0x40889b);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0xd219a6){return _0xd219a6=_0xd219a6||{},_0xd219a6['timestamp']=_0xd219a6['timestamp']||new Date()['getTime'](),_0xd219a6;},fr=function(_0x3f99c7,_0x259d6e,_0x120b27){if(!_0x3f99c7||typeof _0x3f99c7!='object')return _0x3f99c7;if(f('.sv'in _0x3f99c7,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3f99c7['.sv']=='string')return td(_0x3f99c7['.sv'],_0x259d6e,_0x120b27);if(typeof _0x3f99c7['.sv']=='object')return nd(_0x3f99c7['.sv'],_0x259d6e);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3f99c7,null,0x2));},td=function(_0x55790a,_0x54d8eb,_0x5c1529){switch(_0x55790a){case'timestamp':return _0x5c1529['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x55790a);}},nd=function(_0x43f7ca,_0x12188d,_0x10348a){_0x43f7ca['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x43f7ca,null,0x2));const _0x37f7d7=_0x43f7ca['increment'];typeof _0x37f7d7!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x37f7d7);const _0x394b97=_0x12188d['node']();if(f(_0x394b97!==null&&typeof _0x394b97<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x394b97['isLeafNode']())return _0x37f7d7;const _0x23ece0=_0x394b97['getValue']();return typeof _0x23ece0!='number'?_0x37f7d7:_0x23ece0+_0x37f7d7;},Zo=function(_0x54aaf5,_0x194df3,_0x29157c,_0x16a6c7){return us(_0x194df3,new ls(_0x29157c,_0x54aaf5),_0x16a6c7);},hs=function(_0x4a5bc9,_0x236464,_0x58fdf6){return us(_0x4a5bc9,new cs(_0x236464),_0x58fdf6);};function us(_0x322033,_0x30f0f5,_0x2966ed){const _0x4b968a=_0x322033['getPriority']()['val'](),_0x5e685b=fr(_0x4b968a,_0x30f0f5['getImmediateChild']('.priority'),_0x2966ed);let _0x660830;if(_0x322033['isLeafNode']()){const _0x3394a7=_0x322033,_0x30e0e4=fr(_0x3394a7['getValue'](),_0x30f0f5,_0x2966ed);return _0x30e0e4!==_0x3394a7['getValue']()||_0x5e685b!==_0x3394a7['getPriority']()['val']()?new D(_0x30e0e4,N(_0x5e685b)):_0x322033;}else{const _0x115ec2=_0x322033;return _0x660830=_0x115ec2,_0x5e685b!==_0x115ec2['getPriority']()['val']()&&(_0x660830=_0x660830['updatePriority'](new D(_0x5e685b))),_0x115ec2['forEachChild'](R,(_0x4da2e4,_0x487182)=>{const _0x590fe2=us(_0x487182,_0x30f0f5['getImmediateChild'](_0x4da2e4),_0x2966ed);_0x590fe2!==_0x487182&&(_0x660830=_0x660830['updateImmediateChild'](_0x4da2e4,_0x590fe2));}),_0x660830;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x2b3484='',_0x4458de=null,_0x5682cf={'children':{},'childCount':0x0}){this['name']=_0x2b3484,this['parent']=_0x4458de,this['node']=_0x5682cf;}}function Un(_0x3a4254,_0x3df4f7){let _0x1298e9=_0x3df4f7 instanceof C?_0x3df4f7:new C(_0x3df4f7),_0x5f17d5=_0x3a4254,_0x2b19c3=y(_0x1298e9);for(;_0x2b19c3!==null;){const _0x6c5be4=Oe(_0x5f17d5['node']['children'],_0x2b19c3)||{'children':{},'childCount':0x0};_0x5f17d5=new ds(_0x2b19c3,_0x5f17d5,_0x6c5be4),_0x1298e9=b(_0x1298e9),_0x2b19c3=y(_0x1298e9);}return _0x5f17d5;}function Ge(_0x2364b7){return _0x2364b7['node']['value'];}function fs(_0xed5b92,_0x1b654c){_0xed5b92['node']['value']=_0x1b654c,Ri(_0xed5b92);}function ea(_0x188f4f){return _0x188f4f['node']['childCount']>0x0;}function id(_0x454877){return Ge(_0x454877)===void 0x0&&!ea(_0x454877);}function Wn(_0x140af6,_0x3b8f5a){x(_0x140af6['node']['children'],(_0x139bd9,_0x5ac535)=>{_0x3b8f5a(new ds(_0x139bd9,_0x140af6,_0x5ac535));});}function ta(_0x48354a,_0x4b6e97,_0x197f5d,_0x5ee4a5){_0x197f5d&&_0x4b6e97(_0x48354a),Wn(_0x48354a,_0xffc809=>{ta(_0xffc809,_0x4b6e97,!0x0);});}function sd(_0xb5f48a,_0xee66a4,_0x42d047){let _0x25e355=_0xb5f48a['parent'];for(;_0x25e355!==null;){if(_0xee66a4(_0x25e355))return!0x0;_0x25e355=_0x25e355['parent'];}return!0x1;}function Gt(_0x47315f){return new C(_0x47315f['parent']===null?_0x47315f['name']:Gt(_0x47315f['parent'])+'/'+_0x47315f['name']);}function Ri(_0x15d46f){_0x15d46f['parent']!==null&&rd(_0x15d46f['parent'],_0x15d46f['name'],_0x15d46f);}function rd(_0x15aa1c,_0x11626b,_0xafcba7){const _0x3e8d0a=id(_0xafcba7),_0x345618=Y(_0x15aa1c['node']['children'],_0x11626b);_0x3e8d0a&&_0x345618?(delete _0x15aa1c['node']['children'][_0x11626b],_0x15aa1c['node']['childCount']--,Ri(_0x15aa1c)):!_0x3e8d0a&&!_0x345618&&(_0x15aa1c['node']['children'][_0x11626b]=_0xafcba7['node'],_0x15aa1c['node']['childCount']++,Ri(_0x15aa1c));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0xf2e76d){return typeof _0xf2e76d=='string'&&_0xf2e76d['length']!==0x0&&!od['test'](_0xf2e76d);},na=function(_0x6bb439){return typeof _0x6bb439=='string'&&_0x6bb439['length']!==0x0&&!ad['test'](_0x6bb439);},cd=function(_0x568d03){return _0x568d03&&(_0x568d03=_0x568d03['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x568d03);},Cn=function(_0x16bd4f){return _0x16bd4f===null||typeof _0x16bd4f=='string'||typeof _0x16bd4f=='number'&&!Wi(_0x16bd4f)||_0x16bd4f&&typeof _0x16bd4f=='object'&&Y(_0x16bd4f,'.sv');},qt=function(_0x5f1e17,_0x5ef543,_0x5dbc1c,_0x55a617){_0x55a617&&_0x5ef543===void 0x0||zt(Nn(_0x5f1e17,'value'),_0x5ef543,_0x5dbc1c);},zt=function(_0x4b046f,_0x457eed,_0x297dbf){const _0x15df97=_0x297dbf instanceof C?new Sh(_0x297dbf,_0x4b046f):_0x297dbf;if(_0x457eed===void 0x0)throw new Error(_0x4b046f+'contains\x20undefined\x20'+Ne(_0x15df97));if(typeof _0x457eed=='function')throw new Error(_0x4b046f+'contains\x20a\x20function\x20'+Ne(_0x15df97)+'\x20with\x20contents\x20=\x20'+_0x457eed['toString']());if(Wi(_0x457eed))throw new Error(_0x4b046f+'contains\x20'+_0x457eed['toString']()+'\x20'+Ne(_0x15df97));if(typeof _0x457eed=='string'&&_0x457eed['length']>oi/0x3&&Pn(_0x457eed)>oi)throw new Error(_0x4b046f+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x15df97)+'\x20(\x27'+_0x457eed['substring'](0x0,0x32)+'...\x27)');if(_0x457eed&&typeof _0x457eed=='object'){let _0x4879fb=!0x1,_0x47230c=!0x1;if(x(_0x457eed,(_0x3c0d88,_0x290c4c)=>{if(_0x3c0d88==='.value')_0x4879fb=!0x0;else{if(_0x3c0d88!=='.priority'&&_0x3c0d88!=='.sv'&&(_0x47230c=!0x0,!ps(_0x3c0d88)))throw new Error(_0x4b046f+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3c0d88+')\x20'+Ne(_0x15df97)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x15df97,_0x3c0d88),zt(_0x4b046f,_0x290c4c,_0x15df97),Rh(_0x15df97);}),_0x4879fb&&_0x47230c)throw new Error(_0x4b046f+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x15df97)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x3e3a4c,_0x560071){let _0x3c93a2,_0x8036b4;for(_0x3c93a2=0x0;_0x3c93a2<_0x560071['length'];_0x3c93a2++){_0x8036b4=_0x560071[_0x3c93a2];const _0xa718ad=kt(_0x8036b4);for(let _0x4488f2=0x0;_0x4488f2<_0xa718ad['length'];_0x4488f2++)if(!(_0xa718ad[_0x4488f2]==='.priority'&&_0x4488f2===_0xa718ad['length']-0x1)){if(!ps(_0xa718ad[_0x4488f2]))throw new Error(_0x3e3a4c+'contains\x20an\x20invalid\x20key\x20('+_0xa718ad[_0x4488f2]+')\x20in\x20path\x20'+_0x8036b4['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x560071['sort'](Th);let _0x59dad5=null;for(_0x3c93a2=0x0;_0x3c93a2<_0x560071['length'];_0x3c93a2++){if(_0x8036b4=_0x560071[_0x3c93a2],_0x59dad5!==null&&$(_0x59dad5,_0x8036b4))throw new Error(_0x3e3a4c+'contains\x20a\x20path\x20'+_0x59dad5['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x8036b4['toString']());_0x59dad5=_0x8036b4;}},hd=function(_0x1aee17,_0x2abbae,_0x3c93bf,_0x4ea4e3){const _0x4825d7=Nn(_0x1aee17,'values');if(!(_0x2abbae&&typeof _0x2abbae=='object')||Array['isArray'](_0x2abbae))throw new Error(_0x4825d7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x36bf59=[];x(_0x2abbae,(_0x1df3bf,_0x479115)=>{const _0x33d0ba=new C(_0x1df3bf);if(zt(_0x4825d7,_0x479115,A(_0x3c93bf,_0x33d0ba)),Gi(_0x33d0ba)==='.priority'&&!Cn(_0x479115))throw new Error(_0x4825d7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x33d0ba['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x36bf59['push'](_0x33d0ba);}),ld(_0x4825d7,_0x36bf59);},_s=function(_0x1d95a7,_0x2bdd9a,_0x787ca8,_0x32dc45){if(!na(_0x787ca8))throw new Error(Nn(_0x1d95a7,_0x2bdd9a)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x787ca8+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x892c16,_0x2e1e70,_0x428107,_0x2ab6fe){_0x428107&&(_0x428107=_0x428107['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x892c16,_0x2e1e70,_0x428107);},gs=function(_0x12acd1,_0x561cf7){if(y(_0x561cf7)==='.info')throw new Error(_0x12acd1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x178fc6,_0x322150){const _0x2b3b75=_0x322150['path']['toString']();if(typeof _0x322150['repoInfo']['host']!='string'||_0x322150['repoInfo']['host']['length']===0x0||!ps(_0x322150['repoInfo']['namespace'])&&_0x322150['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2b3b75['length']!==0x0&&!cd(_0x2b3b75))throw new Error(Nn(_0x178fc6,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x27adc5,_0x1794b4){let _0x1c8df5=null;for(let _0x3f59b1=0x0;_0x3f59b1<_0x1794b4['length'];_0x3f59b1++){const _0x52ca1b=_0x1794b4[_0x3f59b1],_0x28def1=_0x52ca1b['getPath']();_0x1c8df5!==null&&!qi(_0x28def1,_0x1c8df5['path'])&&(_0x27adc5['eventLists_']['push'](_0x1c8df5),_0x1c8df5=null),_0x1c8df5===null&&(_0x1c8df5={'events':[],'path':_0x28def1}),_0x1c8df5['events']['push'](_0x52ca1b);}_0x1c8df5&&_0x27adc5['eventLists_']['push'](_0x1c8df5);}function ia(_0x394195,_0x175931,_0x358c0a){Bn(_0x394195,_0x358c0a),sa(_0x394195,_0x5617a3=>qi(_0x5617a3,_0x175931));}function V(_0x41e128,_0x49c88e,_0x7533db){Bn(_0x41e128,_0x7533db),sa(_0x41e128,_0x4d8ee0=>$(_0x4d8ee0,_0x49c88e)||$(_0x49c88e,_0x4d8ee0));}function sa(_0x567630,_0x138977){_0x567630['recursionDepth_']++;let _0x4b979d=!0x0;for(let _0xa38184=0x0;_0xa38184<_0x567630['eventLists_']['length'];_0xa38184++){const _0xb4b1a1=_0x567630['eventLists_'][_0xa38184];if(_0xb4b1a1){const _0x2f477e=_0xb4b1a1['path'];_0x138977(_0x2f477e)?(pd(_0x567630['eventLists_'][_0xa38184]),_0x567630['eventLists_'][_0xa38184]=null):_0x4b979d=!0x1;}}_0x4b979d&&(_0x567630['eventLists_']=[]),_0x567630['recursionDepth_']--;}function pd(_0x455168){for(let _0x51046a=0x0;_0x51046a<_0x455168['events']['length'];_0x51046a++){const _0x5bcdb9=_0x455168['events'][_0x51046a];if(_0x5bcdb9!==null){_0x455168['events'][_0x51046a]=null;const _0x27f603=_0x5bcdb9['getEventRunner']();Et&&L('event:\x20'+_0x5bcdb9['toString']()),lt(_0x27f603);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x32bad3,_0x57a775,_0x5dfa43,_0x3d0321){this['repoInfo_']=_0x32bad3,this['forceRestClient_']=_0x57a775,this['authTokenProvider_']=_0x5dfa43,this['appCheckProvider_']=_0x3d0321,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x42ba58,_0x34c4ce,_0x5480ce){if(_0x42ba58['stats_']=Hi(_0x42ba58['repoInfo_']),_0x42ba58['forceRestClient_']||Yl())_0x42ba58['server_']=new fn(_0x42ba58['repoInfo_'],(_0x8b74a0,_0x47dbc1,_0x1f3ce5,_0x1966a7)=>{pr(_0x42ba58,_0x8b74a0,_0x47dbc1,_0x1f3ce5,_0x1966a7);},_0x42ba58['authTokenProvider_'],_0x42ba58['appCheckProvider_']),setTimeout(()=>_r(_0x42ba58,!0x0),0x0);else{if(typeof _0x5480ce<'u'&&_0x5480ce!==null){if(typeof _0x5480ce!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5480ce);}catch(_0x164590){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x164590);}}_0x42ba58['persistentConnection_']=new ie(_0x42ba58['repoInfo_'],_0x34c4ce,(_0x144d15,_0x217970,_0x3d8016,_0x452cfd)=>{pr(_0x42ba58,_0x144d15,_0x217970,_0x3d8016,_0x452cfd);},_0x4e16bf=>{_r(_0x42ba58,_0x4e16bf);},_0x13cff5=>{yd(_0x42ba58,_0x13cff5);},_0x42ba58['authTokenProvider_'],_0x42ba58['appCheckProvider_'],_0x5480ce),_0x42ba58['server_']=_0x42ba58['persistentConnection_'];}_0x42ba58['authTokenProvider_']['addTokenChangeListener'](_0x330e26=>{_0x42ba58['server_']['refreshAuthToken'](_0x330e26);}),_0x42ba58['appCheckProvider_']['addTokenChangeListener'](_0x282d9d=>{_0x42ba58['server_']['refreshAppCheckToken'](_0x282d9d['token']);}),_0x42ba58['statsReporter_']=eh(_0x42ba58['repoInfo_'],()=>new eu(_0x42ba58['stats_'],_0x42ba58['server_'])),_0x42ba58['infoData_']=new Yh(),_0x42ba58['infoSyncTree_']=new dr({'startListening':(_0x4e7650,_0x4e7671,_0x26a7de,_0x500f69)=>{let _0x12192d=[];const _0x248b66=_0x42ba58['infoData_']['getNode'](_0x4e7650['_path']);return _0x248b66['isEmpty']()||(_0x12192d=$t(_0x42ba58['infoSyncTree_'],_0x4e7650['_path'],_0x248b66),setTimeout(()=>{_0x500f69('ok');},0x0)),_0x12192d;},'stopListening':()=>{}}),ms(_0x42ba58,'connected',!0x1),_0x42ba58['serverSyncTree_']=new dr({'startListening':(_0x5301b9,_0x6e2423,_0x1ea408,_0x464ef9)=>(_0x42ba58['server_']['listen'](_0x5301b9,_0x1ea408,_0x6e2423,(_0x2e81ae,_0x55c171)=>{const _0x33a9ca=_0x464ef9(_0x2e81ae,_0x55c171);V(_0x42ba58['eventQueue_'],_0x5301b9['_path'],_0x33a9ca);}),[]),'stopListening':(_0x9d3de,_0x2c564b)=>{_0x42ba58['server_']['unlisten'](_0x9d3de,_0x2c564b);}});}function oa(_0x269511){const _0x373b14=_0x269511['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x373b14;}function jt(_0x4ca8b7){return ed({'timestamp':oa(_0x4ca8b7)});}function pr(_0x530c86,_0x5802df,_0x37b51f,_0x30354a,_0x1610a9){_0x530c86['dataUpdateCount']++;const _0x40ad4b=new C(_0x5802df);_0x37b51f=_0x530c86['interceptServerDataCallback_']?_0x530c86['interceptServerDataCallback_'](_0x5802df,_0x37b51f):_0x37b51f;let _0xabb3b9=[];if(_0x1610a9){if(_0x30354a){const _0x12ba44=ln(_0x37b51f,_0x4c9add=>N(_0x4c9add));_0xabb3b9=Ku(_0x530c86['serverSyncTree_'],_0x40ad4b,_0x12ba44,_0x1610a9);}else{const _0x516b54=N(_0x37b51f);_0xabb3b9=Yo(_0x530c86['serverSyncTree_'],_0x40ad4b,_0x516b54,_0x1610a9);}}else{if(_0x30354a){const _0x587f12=ln(_0x37b51f,_0x310da6=>N(_0x310da6));_0xabb3b9=qu(_0x530c86['serverSyncTree_'],_0x40ad4b,_0x587f12);}else{const _0x1374c5=N(_0x37b51f);_0xabb3b9=$t(_0x530c86['serverSyncTree_'],_0x40ad4b,_0x1374c5);}}let _0x2f607b=_0x40ad4b;_0xabb3b9['length']>0x0&&(_0x2f607b=st(_0x530c86,_0x40ad4b)),V(_0x530c86['eventQueue_'],_0x2f607b,_0xabb3b9);}function _r(_0x20516a,_0x20f305){ms(_0x20516a,'connected',_0x20f305),_0x20f305===!0x1&&wd(_0x20516a);}function yd(_0x183dfa,_0x299a41){x(_0x299a41,(_0x566b0d,_0x5c1863)=>{ms(_0x183dfa,_0x566b0d,_0x5c1863);});}function ms(_0x2ce82f,_0x8173ae,_0x1123b8){const _0xd1e0c4=new C('/.info/'+_0x8173ae),_0x296a89=N(_0x1123b8);_0x2ce82f['infoData_']['updateSnapshot'](_0xd1e0c4,_0x296a89);const _0x35733a=$t(_0x2ce82f['infoSyncTree_'],_0xd1e0c4,_0x296a89);V(_0x2ce82f['eventQueue_'],_0xd1e0c4,_0x35733a);}function Vn(_0x12f435){return _0x12f435['nextWriteId_']++;}function vd(_0x490826,_0x42b212,_0x862bc7){const _0x3aea29=Yu(_0x490826['serverSyncTree_'],_0x42b212);return _0x3aea29!=null?Promise['resolve'](_0x3aea29):_0x490826['server_']['get'](_0x42b212)['then'](_0x53e933=>{const _0x135e93=N(_0x53e933)['withIndex'](_0x42b212['_queryParams']['getIndex']());bi(_0x490826['serverSyncTree_'],_0x42b212,_0x862bc7,!0x0);let _0x5a3a8f;if(_0x42b212['_queryParams']['loadsAllData']())_0x5a3a8f=$t(_0x490826['serverSyncTree_'],_0x42b212['_path'],_0x135e93);else{const _0x3b741b=Mt(_0x490826['serverSyncTree_'],_0x42b212);_0x5a3a8f=Yo(_0x490826['serverSyncTree_'],_0x42b212['_path'],_0x135e93,_0x3b741b);}return V(_0x490826['eventQueue_'],_0x42b212['_path'],_0x5a3a8f),wn(_0x490826['serverSyncTree_'],_0x42b212,_0x862bc7,null,!0x0),_0x135e93;},_0x531383=>(ut(_0x490826,'get\x20for\x20query\x20'+O(_0x42b212)+'\x20failed:\x20'+_0x531383),Promise['reject'](new Error(_0x531383))));}function Ed(_0x209cc9,_0x1bb9af,_0x1dc1b9,_0x50021f,_0x38f7b0){ut(_0x209cc9,'set',{'path':_0x1bb9af['toString'](),'value':_0x1dc1b9,'priority':_0x50021f});const _0x316d4c=jt(_0x209cc9),_0x184715=N(_0x1dc1b9,_0x50021f),_0x44dd4f=xn(_0x209cc9['serverSyncTree_'],_0x1bb9af),_0x362675=hs(_0x184715,_0x44dd4f,_0x316d4c),_0x175ac8=Vn(_0x209cc9),_0x301689=ss(_0x209cc9['serverSyncTree_'],_0x1bb9af,_0x362675,_0x175ac8,!0x0);Bn(_0x209cc9['eventQueue_'],_0x301689),_0x209cc9['server_']['put'](_0x1bb9af['toString'](),_0x184715['val'](!0x0),(_0x1e0e42,_0x3586d7)=>{const _0x2c18d2=_0x1e0e42==='ok';_0x2c18d2||U('set\x20at\x20'+_0x1bb9af+'\x20failed:\x20'+_0x1e0e42);const _0x41a876=pe(_0x209cc9['serverSyncTree_'],_0x175ac8,!_0x2c18d2);V(_0x209cc9['eventQueue_'],_0x1bb9af,_0x41a876),Ai(_0x209cc9,_0x38f7b0,_0x1e0e42,_0x3586d7);});const _0x3d04e5=vs(_0x209cc9,_0x1bb9af);st(_0x209cc9,_0x3d04e5),V(_0x209cc9['eventQueue_'],_0x3d04e5,[]);}function Id(_0x420fcf,_0x24a2e0,_0x55a348,_0x1f0964){ut(_0x420fcf,'update',{'path':_0x24a2e0['toString'](),'value':_0x55a348});let _0x3c0539=!0x0;const _0x5c1abb=jt(_0x420fcf),_0xef614c={};if(x(_0x55a348,(_0x19a480,_0x14c09d)=>{_0x3c0539=!0x1,_0xef614c[_0x19a480]=Zo(A(_0x24a2e0,_0x19a480),N(_0x14c09d),_0x420fcf['serverSyncTree_'],_0x5c1abb);}),_0x3c0539)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x420fcf,_0x1f0964,'ok',void 0x0);else{const _0x242df1=Vn(_0x420fcf),_0x331c85=Gu(_0x420fcf['serverSyncTree_'],_0x24a2e0,_0xef614c,_0x242df1);Bn(_0x420fcf['eventQueue_'],_0x331c85),_0x420fcf['server_']['merge'](_0x24a2e0['toString'](),_0x55a348,(_0xe53a62,_0x540e1b)=>{const _0x241b8d=_0xe53a62==='ok';_0x241b8d||U('update\x20at\x20'+_0x24a2e0+'\x20failed:\x20'+_0xe53a62);const _0xffbf26=pe(_0x420fcf['serverSyncTree_'],_0x242df1,!_0x241b8d),_0x3ffde2=_0xffbf26['length']>0x0?st(_0x420fcf,_0x24a2e0):_0x24a2e0;V(_0x420fcf['eventQueue_'],_0x3ffde2,_0xffbf26),Ai(_0x420fcf,_0x1f0964,_0xe53a62,_0x540e1b);}),x(_0x55a348,_0x3c39b4=>{const _0x144f1f=vs(_0x420fcf,A(_0x24a2e0,_0x3c39b4));st(_0x420fcf,_0x144f1f);}),V(_0x420fcf['eventQueue_'],_0x24a2e0,[]);}}function wd(_0x36fbc7){ut(_0x36fbc7,'onDisconnectEvents');const _0x33732e=jt(_0x36fbc7),_0x5cd989=pn();Ei(_0x36fbc7['onDisconnect_'],w(),(_0x24975f,_0xba2721)=>{const _0x4ea8a6=Zo(_0x24975f,_0xba2721,_0x36fbc7['serverSyncTree_'],_0x33732e);Mo(_0x5cd989,_0x24975f,_0x4ea8a6);});let _0x1348d2=[];Ei(_0x5cd989,w(),(_0x38163e,_0x148ebe)=>{_0x1348d2=_0x1348d2['concat']($t(_0x36fbc7['serverSyncTree_'],_0x38163e,_0x148ebe));const _0x4256e8=vs(_0x36fbc7,_0x38163e);st(_0x36fbc7,_0x4256e8);}),_0x36fbc7['onDisconnect_']=pn(),V(_0x36fbc7['eventQueue_'],w(),_0x1348d2);}function Cd(_0x5d5732,_0x34c961,_0x1a7300){let _0x371591;y(_0x34c961['_path'])==='.info'?_0x371591=bi(_0x5d5732['infoSyncTree_'],_0x34c961,_0x1a7300):_0x371591=bi(_0x5d5732['serverSyncTree_'],_0x34c961,_0x1a7300),ia(_0x5d5732['eventQueue_'],_0x34c961['_path'],_0x371591);}function Td(_0x107a6b,_0x53fe77,_0x531792){let _0x3f2e37;y(_0x53fe77['_path'])==='.info'?_0x3f2e37=wn(_0x107a6b['infoSyncTree_'],_0x53fe77,_0x531792):_0x3f2e37=wn(_0x107a6b['serverSyncTree_'],_0x53fe77,_0x531792),ia(_0x107a6b['eventQueue_'],_0x53fe77['_path'],_0x3f2e37);}function aa(_0x2f048c){_0x2f048c['persistentConnection_']&&_0x2f048c['persistentConnection_']['interrupt'](ra);}function Sd(_0x3ed317){_0x3ed317['persistentConnection_']&&_0x3ed317['persistentConnection_']['resume'](ra);}function ut(_0x4a071c,..._0x2f020a){let _0x4cb90f='';_0x4a071c['persistentConnection_']&&(_0x4cb90f=_0x4a071c['persistentConnection_']['id']+':'),L(_0x4cb90f,..._0x2f020a);}function Ai(_0x2db485,_0x348a31,_0x1f1fe9,_0x4066c7){_0x348a31&&lt(()=>{if(_0x1f1fe9==='ok')_0x348a31(null);else{const _0x3b309a=(_0x1f1fe9||'error')['toUpperCase']();let _0x5d640c=_0x3b309a;_0x4066c7&&(_0x5d640c+=':\x20'+_0x4066c7);const _0x18dfe9=new Error(_0x5d640c);_0x18dfe9['code']=_0x3b309a,_0x348a31(_0x18dfe9);}});}function bd(_0x18e0f3,_0x3fae20,_0x5bc5c0,_0x1286fb,_0x38719e,_0x4a4d4d){ut(_0x18e0f3,'transaction\x20on\x20'+_0x3fae20);const _0x7ff2c5={'path':_0x3fae20,'update':_0x5bc5c0,'onComplete':_0x1286fb,'status':null,'order':to(),'applyLocally':_0x4a4d4d,'retryCount':0x0,'unwatcher':_0x38719e,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x52577e=ys(_0x18e0f3,_0x3fae20,void 0x0);_0x7ff2c5['currentInputSnapshot']=_0x52577e;const _0x183a98=_0x7ff2c5['update'](_0x52577e['val']());if(_0x183a98===void 0x0)_0x7ff2c5['unwatcher'](),_0x7ff2c5['currentOutputSnapshotRaw']=null,_0x7ff2c5['currentOutputSnapshotResolved']=null,_0x7ff2c5['onComplete']&&_0x7ff2c5['onComplete'](null,!0x1,_0x7ff2c5['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x183a98,_0x7ff2c5['path']),_0x7ff2c5['status']=0x0;const _0x2863cc=Un(_0x18e0f3['transactionQueueTree_'],_0x3fae20),_0x25e3c0=Ge(_0x2863cc)||[];_0x25e3c0['push'](_0x7ff2c5),fs(_0x2863cc,_0x25e3c0);let _0x3a1f97;typeof _0x183a98=='object'&&_0x183a98!==null&&Y(_0x183a98,'.priority')?(_0x3a1f97=Oe(_0x183a98,'.priority'),f(Cn(_0x3a1f97),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3a1f97=(xn(_0x18e0f3['serverSyncTree_'],_0x3fae20)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x65d2be=jt(_0x18e0f3),_0x5da720=N(_0x183a98,_0x3a1f97),_0x1e10dc=hs(_0x5da720,_0x52577e,_0x65d2be);_0x7ff2c5['currentOutputSnapshotRaw']=_0x5da720,_0x7ff2c5['currentOutputSnapshotResolved']=_0x1e10dc,_0x7ff2c5['currentWriteId']=Vn(_0x18e0f3);const _0x59523a=ss(_0x18e0f3['serverSyncTree_'],_0x3fae20,_0x1e10dc,_0x7ff2c5['currentWriteId'],_0x7ff2c5['applyLocally']);V(_0x18e0f3['eventQueue_'],_0x3fae20,_0x59523a),Hn(_0x18e0f3,_0x18e0f3['transactionQueueTree_']);}}function ys(_0x527c6d,_0x5ae8ef,_0x4b04ff){return xn(_0x527c6d['serverSyncTree_'],_0x5ae8ef,_0x4b04ff)||g['EMPTY_NODE'];}function Hn(_0x38f9c9,_0x463763=_0x38f9c9['transactionQueueTree_']){if(_0x463763||$n(_0x38f9c9,_0x463763),Ge(_0x463763)){const _0x1e53e4=la(_0x38f9c9,_0x463763);f(_0x1e53e4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x1e53e4['every'](_0x3b4ce2=>_0x3b4ce2['status']===0x0)&&Rd(_0x38f9c9,Gt(_0x463763),_0x1e53e4);}else ea(_0x463763)&&Wn(_0x463763,_0x43a12a=>{Hn(_0x38f9c9,_0x43a12a);});}function Rd(_0x381850,_0xd09337,_0x1cfbed){const _0x78ec26=_0x1cfbed['map'](_0x2ce4ca=>_0x2ce4ca['currentWriteId']),_0x16a468=ys(_0x381850,_0xd09337,_0x78ec26);let _0x31cb1f=_0x16a468;const _0x3875cb=_0x16a468['hash']();for(let _0x3372e3=0x0;_0x3372e3<_0x1cfbed['length'];_0x3372e3++){const _0x354027=_0x1cfbed[_0x3372e3];f(_0x354027['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x354027['status']=0x1,_0x354027['retryCount']++;const _0x3cca13=F(_0xd09337,_0x354027['path']);_0x31cb1f=_0x31cb1f['updateChild'](_0x3cca13,_0x354027['currentOutputSnapshotRaw']);}const _0x260b7a=_0x31cb1f['val'](!0x0),_0x2ff4a7=_0xd09337;_0x381850['server_']['put'](_0x2ff4a7['toString'](),_0x260b7a,_0x5905c9=>{ut(_0x381850,'transaction\x20put\x20response',{'path':_0x2ff4a7['toString'](),'status':_0x5905c9});let _0x4074a1=[];if(_0x5905c9==='ok'){const _0x4f6837=[];for(let _0x1e44e1=0x0;_0x1e44e1<_0x1cfbed['length'];_0x1e44e1++)_0x1cfbed[_0x1e44e1]['status']=0x2,_0x4074a1=_0x4074a1['concat'](pe(_0x381850['serverSyncTree_'],_0x1cfbed[_0x1e44e1]['currentWriteId'])),_0x1cfbed[_0x1e44e1]['onComplete']&&_0x4f6837['push'](()=>_0x1cfbed[_0x1e44e1]['onComplete'](null,!0x0,_0x1cfbed[_0x1e44e1]['currentOutputSnapshotResolved'])),_0x1cfbed[_0x1e44e1]['unwatcher']();$n(_0x381850,Un(_0x381850['transactionQueueTree_'],_0xd09337)),Hn(_0x381850,_0x381850['transactionQueueTree_']),V(_0x381850['eventQueue_'],_0xd09337,_0x4074a1);for(let _0x4d042c=0x0;_0x4d042c<_0x4f6837['length'];_0x4d042c++)lt(_0x4f6837[_0x4d042c]);}else{if(_0x5905c9==='datastale'){for(let _0x561ec9=0x0;_0x561ec9<_0x1cfbed['length'];_0x561ec9++)_0x1cfbed[_0x561ec9]['status']===0x3?_0x1cfbed[_0x561ec9]['status']=0x4:_0x1cfbed[_0x561ec9]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2ff4a7['toString']()+'\x20failed:\x20'+_0x5905c9);for(let _0x19374a=0x0;_0x19374a<_0x1cfbed['length'];_0x19374a++)_0x1cfbed[_0x19374a]['status']=0x4,_0x1cfbed[_0x19374a]['abortReason']=_0x5905c9;}st(_0x381850,_0xd09337);}},_0x3875cb);}function st(_0x392c8a,_0x1c1576){const _0x359433=ca(_0x392c8a,_0x1c1576),_0x58d66b=Gt(_0x359433),_0x19d130=la(_0x392c8a,_0x359433);return Ad(_0x392c8a,_0x19d130,_0x58d66b),_0x58d66b;}function Ad(_0x3b22fe,_0x1ed839,_0x5e701d){if(_0x1ed839['length']===0x0)return;const _0x795f1a=[];let _0x4015a8=[];const _0x46c17a=_0x1ed839['filter'](_0x1059b9=>_0x1059b9['status']===0x0)['map'](_0x5ffea5=>_0x5ffea5['currentWriteId']);for(let _0x4631a3=0x0;_0x4631a3<_0x1ed839['length'];_0x4631a3++){const _0x367539=_0x1ed839[_0x4631a3],_0x38aeca=F(_0x5e701d,_0x367539['path']);let _0x5e9619=!0x1,_0x7c5d16;if(f(_0x38aeca!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x367539['status']===0x4)_0x5e9619=!0x0,_0x7c5d16=_0x367539['abortReason'],_0x4015a8=_0x4015a8['concat'](pe(_0x3b22fe['serverSyncTree_'],_0x367539['currentWriteId'],!0x0));else{if(_0x367539['status']===0x0){if(_0x367539['retryCount']>=_d)_0x5e9619=!0x0,_0x7c5d16='maxretry',_0x4015a8=_0x4015a8['concat'](pe(_0x3b22fe['serverSyncTree_'],_0x367539['currentWriteId'],!0x0));else{const _0x1bc925=ys(_0x3b22fe,_0x367539['path'],_0x46c17a);_0x367539['currentInputSnapshot']=_0x1bc925;const _0x2a6c18=_0x1ed839[_0x4631a3]['update'](_0x1bc925['val']());if(_0x2a6c18!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x2a6c18,_0x367539['path']);let _0x4221c0=N(_0x2a6c18);typeof _0x2a6c18=='object'&&_0x2a6c18!=null&&Y(_0x2a6c18,'.priority')||(_0x4221c0=_0x4221c0['updatePriority'](_0x1bc925['getPriority']()));const _0xc19bfa=_0x367539['currentWriteId'],_0x131082=jt(_0x3b22fe),_0x17179b=hs(_0x4221c0,_0x1bc925,_0x131082);_0x367539['currentOutputSnapshotRaw']=_0x4221c0,_0x367539['currentOutputSnapshotResolved']=_0x17179b,_0x367539['currentWriteId']=Vn(_0x3b22fe),_0x46c17a['splice'](_0x46c17a['indexOf'](_0xc19bfa),0x1),_0x4015a8=_0x4015a8['concat'](ss(_0x3b22fe['serverSyncTree_'],_0x367539['path'],_0x17179b,_0x367539['currentWriteId'],_0x367539['applyLocally'])),_0x4015a8=_0x4015a8['concat'](pe(_0x3b22fe['serverSyncTree_'],_0xc19bfa,!0x0));}else _0x5e9619=!0x0,_0x7c5d16='nodata',_0x4015a8=_0x4015a8['concat'](pe(_0x3b22fe['serverSyncTree_'],_0x367539['currentWriteId'],!0x0));}}}V(_0x3b22fe['eventQueue_'],_0x5e701d,_0x4015a8),_0x4015a8=[],_0x5e9619&&(_0x1ed839[_0x4631a3]['status']=0x2,function(_0x2ad5ac){setTimeout(_0x2ad5ac,Math['floor'](0x0));}(_0x1ed839[_0x4631a3]['unwatcher']),_0x1ed839[_0x4631a3]['onComplete']&&(_0x7c5d16==='nodata'?_0x795f1a['push'](()=>_0x1ed839[_0x4631a3]['onComplete'](null,!0x1,_0x1ed839[_0x4631a3]['currentInputSnapshot'])):_0x795f1a['push'](()=>_0x1ed839[_0x4631a3]['onComplete'](new Error(_0x7c5d16),!0x1,null))));}$n(_0x3b22fe,_0x3b22fe['transactionQueueTree_']);for(let _0x3e18df=0x0;_0x3e18df<_0x795f1a['length'];_0x3e18df++)lt(_0x795f1a[_0x3e18df]);Hn(_0x3b22fe,_0x3b22fe['transactionQueueTree_']);}function ca(_0x5bc53d,_0x1ff857){let _0x19ce81,_0x465377=_0x5bc53d['transactionQueueTree_'];for(_0x19ce81=y(_0x1ff857);_0x19ce81!==null&&Ge(_0x465377)===void 0x0;)_0x465377=Un(_0x465377,_0x19ce81),_0x1ff857=b(_0x1ff857),_0x19ce81=y(_0x1ff857);return _0x465377;}function la(_0x2a6751,_0x2960c7){const _0x320eac=[];return ha(_0x2a6751,_0x2960c7,_0x320eac),_0x320eac['sort']((_0x1da9b7,_0xa611c2)=>_0x1da9b7['order']-_0xa611c2['order']),_0x320eac;}function ha(_0x14e255,_0x2d5dcd,_0x151d3f){const _0x5e1d4f=Ge(_0x2d5dcd);if(_0x5e1d4f){for(let _0x10b8fd=0x0;_0x10b8fd<_0x5e1d4f['length'];_0x10b8fd++)_0x151d3f['push'](_0x5e1d4f[_0x10b8fd]);}Wn(_0x2d5dcd,_0x5cc972=>{ha(_0x14e255,_0x5cc972,_0x151d3f);});}function $n(_0x251189,_0x3054e7){const _0xf682bc=Ge(_0x3054e7);if(_0xf682bc){let _0x1f3c3c=0x0;for(let _0x207448=0x0;_0x207448<_0xf682bc['length'];_0x207448++)_0xf682bc[_0x207448]['status']!==0x2&&(_0xf682bc[_0x1f3c3c]=_0xf682bc[_0x207448],_0x1f3c3c++);_0xf682bc['length']=_0x1f3c3c,fs(_0x3054e7,_0xf682bc['length']>0x0?_0xf682bc:void 0x0);}Wn(_0x3054e7,_0x5d85b8=>{$n(_0x251189,_0x5d85b8);});}function vs(_0x2b927e,_0x13a035){const _0xc04be3=Gt(ca(_0x2b927e,_0x13a035)),_0x4a26f=Un(_0x2b927e['transactionQueueTree_'],_0x13a035);return sd(_0x4a26f,_0x383601=>{ai(_0x2b927e,_0x383601);}),ai(_0x2b927e,_0x4a26f),ta(_0x4a26f,_0x4ff613=>{ai(_0x2b927e,_0x4ff613);}),_0xc04be3;}function ai(_0x351163,_0x589d42){const _0x2bab54=Ge(_0x589d42);if(_0x2bab54){const _0x38e9ee=[];let _0xfbd0a2=[],_0x20950a=-0x1;for(let _0xc64dd3=0x0;_0xc64dd3<_0x2bab54['length'];_0xc64dd3++)_0x2bab54[_0xc64dd3]['status']===0x3||(_0x2bab54[_0xc64dd3]['status']===0x1?(f(_0x20950a===_0xc64dd3-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x20950a=_0xc64dd3,_0x2bab54[_0xc64dd3]['status']=0x3,_0x2bab54[_0xc64dd3]['abortReason']='set'):(f(_0x2bab54[_0xc64dd3]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2bab54[_0xc64dd3]['unwatcher'](),_0xfbd0a2=_0xfbd0a2['concat'](pe(_0x351163['serverSyncTree_'],_0x2bab54[_0xc64dd3]['currentWriteId'],!0x0)),_0x2bab54[_0xc64dd3]['onComplete']&&_0x38e9ee['push'](_0x2bab54[_0xc64dd3]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x20950a===-0x1?fs(_0x589d42,void 0x0):_0x2bab54['length']=_0x20950a+0x1,V(_0x351163['eventQueue_'],Gt(_0x589d42),_0xfbd0a2);for(let _0xd04b4e=0x0;_0xd04b4e<_0x38e9ee['length'];_0xd04b4e++)lt(_0x38e9ee[_0xd04b4e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0xc46730){let _0x15379e='';const _0x12da5b=_0xc46730['split']('/');for(let _0x130254=0x0;_0x130254<_0x12da5b['length'];_0x130254++)if(_0x12da5b[_0x130254]['length']>0x0){let _0x4d7c4b=_0x12da5b[_0x130254];try{_0x4d7c4b=decodeURIComponent(_0x4d7c4b['replace'](/\+/g,'\x20'));}catch{}_0x15379e+='/'+_0x4d7c4b;}return _0x15379e;}function Nd(_0x5442bc){const _0x2ebcbc={};_0x5442bc['charAt'](0x0)==='?'&&(_0x5442bc=_0x5442bc['substring'](0x1));for(const _0x7cde75 of _0x5442bc['split']('&')){if(_0x7cde75['length']===0x0)continue;const _0x5d08ec=_0x7cde75['split']('=');_0x5d08ec['length']===0x2?_0x2ebcbc[decodeURIComponent(_0x5d08ec[0x0])]=decodeURIComponent(_0x5d08ec[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x7cde75+'\x27\x20in\x20query\x20\x27'+_0x5442bc+'\x27');}return _0x2ebcbc;}const gr=function(_0x13d07b,_0x5c59ce){const _0x13adbc=Pd(_0x13d07b),_0x30be16=_0x13adbc['namespace'];_0x13adbc['domain']==='firebase.com'&&oe(_0x13adbc['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x30be16||_0x30be16==='undefined')&&_0x13adbc['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x13adbc['secure']||Bl();const _0x43b005=_0x13adbc['scheme']==='ws'||_0x13adbc['scheme']==='wss';return{'repoInfo':new _o(_0x13adbc['host'],_0x13adbc['secure'],_0x30be16,_0x43b005,_0x5c59ce,'',_0x30be16!==_0x13adbc['subdomain']),'path':new C(_0x13adbc['pathString'])};},Pd=function(_0x2e4abf){let _0x14c40f='',_0x324d88='',_0x43bc56='',_0x430fba='',_0xfa4f38='',_0x6ab9c9=!0x0,_0x2bc701='https',_0x46a607=0x1bb;if(typeof _0x2e4abf=='string'){let _0x34b777=_0x2e4abf['indexOf']('//');_0x34b777>=0x0&&(_0x2bc701=_0x2e4abf['substring'](0x0,_0x34b777-0x1),_0x2e4abf=_0x2e4abf['substring'](_0x34b777+0x2));let _0x14439b=_0x2e4abf['indexOf']('/');_0x14439b===-0x1&&(_0x14439b=_0x2e4abf['length']);let _0x4f34a1=_0x2e4abf['indexOf']('?');_0x4f34a1===-0x1&&(_0x4f34a1=_0x2e4abf['length']),_0x14c40f=_0x2e4abf['substring'](0x0,Math['min'](_0x14439b,_0x4f34a1)),_0x14439b<_0x4f34a1&&(_0x430fba=kd(_0x2e4abf['substring'](_0x14439b,_0x4f34a1)));const _0x342e44=Nd(_0x2e4abf['substring'](Math['min'](_0x2e4abf['length'],_0x4f34a1)));_0x34b777=_0x14c40f['indexOf'](':'),_0x34b777>=0x0?(_0x6ab9c9=_0x2bc701==='https'||_0x2bc701==='wss',_0x46a607=parseInt(_0x14c40f['substring'](_0x34b777+0x1),0xa)):_0x34b777=_0x14c40f['length'];const _0x58878a=_0x14c40f['slice'](0x0,_0x34b777);if(_0x58878a['toLowerCase']()==='localhost')_0x324d88='localhost';else{if(_0x58878a['split']('.')['length']<=0x2)_0x324d88=_0x58878a;else{const _0x5ed74f=_0x14c40f['indexOf']('.');_0x43bc56=_0x14c40f['substring'](0x0,_0x5ed74f)['toLowerCase'](),_0x324d88=_0x14c40f['substring'](_0x5ed74f+0x1),_0xfa4f38=_0x43bc56;}}'ns'in _0x342e44&&(_0xfa4f38=_0x342e44['ns']);}return{'host':_0x14c40f,'port':_0x46a607,'domain':_0x324d88,'subdomain':_0x43bc56,'secure':_0x6ab9c9,'scheme':_0x2bc701,'pathString':_0x430fba,'namespace':_0xfa4f38};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x44eb3d=0x0;const _0x483101=[];return function(_0x111f46){const _0x35c81c=_0x111f46===_0x44eb3d;_0x44eb3d=_0x111f46;let _0xb1eaaf;const _0x8caa75=new Array(0x8);for(_0xb1eaaf=0x7;_0xb1eaaf>=0x0;_0xb1eaaf--)_0x8caa75[_0xb1eaaf]=mr['charAt'](_0x111f46%0x40),_0x111f46=Math['floor'](_0x111f46/0x40);f(_0x111f46===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x448972=_0x8caa75['join']('');if(_0x35c81c){for(_0xb1eaaf=0xb;_0xb1eaaf>=0x0&&_0x483101[_0xb1eaaf]===0x3f;_0xb1eaaf--)_0x483101[_0xb1eaaf]=0x0;_0x483101[_0xb1eaaf]++;}else{for(_0xb1eaaf=0x0;_0xb1eaaf<0xc;_0xb1eaaf++)_0x483101[_0xb1eaaf]=Math['floor'](Math['random']()*0x40);}for(_0xb1eaaf=0x0;_0xb1eaaf<0xc;_0xb1eaaf++)_0x448972+=mr['charAt'](_0x483101[_0xb1eaaf]);return f(_0x448972['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x448972;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x241759,_0x13fdf8,_0x5164fe,_0x53435f){this['eventType']=_0x241759,this['eventRegistration']=_0x13fdf8,this['snapshot']=_0x5164fe,this['prevName']=_0x53435f;}['getPath'](){const _0x52c511=this['snapshot']['ref'];return this['eventType']==='value'?_0x52c511['_path']:_0x52c511['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x55888b,_0x727f3f,_0x19b3c7){this['eventRegistration']=_0x55888b,this['error']=_0x727f3f,this['path']=_0x19b3c7;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x314400,_0x1c8648){this['snapshotCallback']=_0x314400,this['cancelCallback']=_0x1c8648;}['onValue'](_0xcc2cf,_0x6e4f90){this['snapshotCallback']['call'](null,_0xcc2cf,_0x6e4f90);}['onCancel'](_0x44ff05){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x44ff05);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4f583d){return this['snapshotCallback']===_0x4f583d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4f583d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4f583d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x191282,_0x515206,_0x20fcfb,_0x34d450){this['_repo']=_0x191282,this['_path']=_0x515206,this['_queryParams']=_0x20fcfb,this['_orderByCalled']=_0x34d450;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x29d3fa=nr(this['_queryParams']),_0x231c4d=Bi(_0x29d3fa);return _0x231c4d==='{}'?'default':_0x231c4d;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x5977a5){if(_0x5977a5=k(_0x5977a5),!(_0x5977a5 instanceof be))return!0x1;const _0x52e0dd=this['_repo']===_0x5977a5['_repo'],_0x17291e=qi(this['_path'],_0x5977a5['_path']),_0x55ee24=this['_queryIdentifier']===_0x5977a5['_queryIdentifier'];return _0x52e0dd&&_0x17291e&&_0x55ee24;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x2dcf85,_0x411d01){if(_0x2dcf85['_orderByCalled']===!0x0)throw new Error(_0x411d01+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0xee1866){let _0x8b5cc6=null,_0xfbf4cf=null;if(_0xee1866['hasStart']()&&(_0x8b5cc6=_0xee1866['getIndexStartValue']()),_0xee1866['hasEnd']()&&(_0xfbf4cf=_0xee1866['getIndexEndValue']()),_0xee1866['getIndex']()===ye){const _0x35e74d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xed14fb='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xee1866['hasStart']()){if(_0xee1866['getIndexStartName']()!==xe)throw new Error(_0x35e74d);if(typeof _0x8b5cc6!='string')throw new Error(_0xed14fb);}if(_0xee1866['hasEnd']()){if(_0xee1866['getIndexEndName']()!==Ie)throw new Error(_0x35e74d);if(typeof _0xfbf4cf!='string')throw new Error(_0xed14fb);}}else{if(_0xee1866['getIndex']()===R){if(_0x8b5cc6!=null&&!Cn(_0x8b5cc6)||_0xfbf4cf!=null&&!Cn(_0xfbf4cf))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xee1866['getIndex']()instanceof Ki||_0xee1866['getIndex']()===Po,'unknown\x20index\x20type.'),_0x8b5cc6!=null&&typeof _0x8b5cc6=='object'||_0xfbf4cf!=null&&typeof _0xfbf4cf=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x1a035e){if(_0x1a035e['hasStart']()&&_0x1a035e['hasEnd']()&&_0x1a035e['hasLimit']()&&!_0x1a035e['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x5c4604,_0x1d658e){super(_0x5c4604,_0x1d658e,new Qi(),!0x1);}get['parent'](){const _0xeeb69c=To(this['_path']);return _0xeeb69c===null?null:new Z(this['_repo'],_0xeeb69c);}get['root'](){let _0x455311=this;for(;_0x455311['parent']!==null;)_0x455311=_0x455311['parent'];return _0x455311;}}class rt{constructor(_0x35110f,_0x525843,_0x163319){this['_node']=_0x35110f,this['ref']=_0x525843,this['_index']=_0x163319;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x583cb1){const _0x377bd9=new C(_0x583cb1),_0x22900a=Lt(this['ref'],_0x583cb1);return new rt(this['_node']['getChild'](_0x377bd9),_0x22900a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x37a783){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3d0029,_0x327492)=>_0x37a783(new rt(_0x327492,Lt(this['ref'],_0x3d0029),R)));}['hasChild'](_0x512818){const _0x1ef82a=new C(_0x512818);return!this['_node']['getChild'](_0x1ef82a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x49e086,_0x26d44e){return _0x49e086=k(_0x49e086),_0x49e086['_checkNotDeleted']('ref'),_0x26d44e!==void 0x0?Lt(_0x49e086['_root'],_0x26d44e):_0x49e086['_root'];}function Lt(_0x17dc1d,_0x45fbe4){return _0x17dc1d=k(_0x17dc1d),y(_0x17dc1d['_path'])===null?ud('child','path',_0x45fbe4):_s('child','path',_0x45fbe4),new Z(_0x17dc1d['_repo'],A(_0x17dc1d['_path'],_0x45fbe4));}function d_(_0x51ebd9,_0x501a0f){_0x51ebd9=k(_0x51ebd9),gs('push',_0x51ebd9['_path']),qt('push',_0x501a0f,_0x51ebd9['_path'],!0x0);const _0x25b59f=oa(_0x51ebd9['_repo']),_0x188d88=Od(_0x25b59f),_0x5a6d40=Lt(_0x51ebd9,_0x188d88),_0x470ef5=Lt(_0x51ebd9,_0x188d88);let _0x302d85;return _0x501a0f!=null?_0x302d85=Ld(_0x470ef5,_0x501a0f)['then'](()=>_0x470ef5):_0x302d85=Promise['resolve'](_0x470ef5),_0x5a6d40['then']=_0x302d85['then']['bind'](_0x302d85),_0x5a6d40['catch']=_0x302d85['then']['bind'](_0x302d85,void 0x0),_0x5a6d40;}function Ld(_0x2273ab,_0x3f5a1c){_0x2273ab=k(_0x2273ab),gs('set',_0x2273ab['_path']),qt('set',_0x3f5a1c,_0x2273ab['_path'],!0x1);const _0x1dd481=new Ve();return Ed(_0x2273ab['_repo'],_0x2273ab['_path'],_0x3f5a1c,null,_0x1dd481['wrapCallback'](()=>{})),_0x1dd481['promise'];}function f_(_0x455c61,_0x4b7b24){hd('update',_0x4b7b24,_0x455c61['_path']);const _0x427c73=new Ve();return Id(_0x455c61['_repo'],_0x455c61['_path'],_0x4b7b24,_0x427c73['wrapCallback'](()=>{})),_0x427c73['promise'];}function p_(_0x19ef2c){_0x19ef2c=k(_0x19ef2c);const _0x128e0d=new ua(()=>{}),_0x517db8=new qn(_0x128e0d);return vd(_0x19ef2c['_repo'],_0x19ef2c,_0x517db8)['then'](_0x25b3fe=>new rt(_0x25b3fe,new Z(_0x19ef2c['_repo'],_0x19ef2c['_path']),_0x19ef2c['_queryParams']['getIndex']()));}class qn{constructor(_0x105bb4){this['callbackContext']=_0x105bb4;}['respondsTo'](_0x46ec60){return _0x46ec60==='value';}['createEvent'](_0x51aaa0,_0x6db0b){const _0x4b8ba5=_0x6db0b['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x51aaa0['snapshotNode'],new Z(_0x6db0b['_repo'],_0x6db0b['_path']),_0x4b8ba5));}['getEventRunner'](_0x3c261d){return _0x3c261d['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3c261d['error']):()=>this['callbackContext']['onValue'](_0x3c261d['snapshot'],null);}['createCancelEvent'](_0x12da23,_0x49b160){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x12da23,_0x49b160):null;}['matches'](_0x21beb4){return _0x21beb4 instanceof qn?!_0x21beb4['callbackContext']||!this['callbackContext']?!0x0:_0x21beb4['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x179ff7,_0x57cbb7,_0x24057e,_0x49696d,_0x17edd4){const _0x335a2a=new ua(_0x24057e,void 0x0),_0x5da1b7=new qn(_0x335a2a);return Cd(_0x179ff7['_repo'],_0x179ff7,_0x5da1b7),()=>Td(_0x179ff7['_repo'],_0x179ff7,_0x5da1b7);}function Fd(_0x1cf220,_0x224e6f,_0x45d38e,_0x570f2c){return xd(_0x1cf220,'value',_0x224e6f);}class dt{}class pa extends dt{constructor(_0x198566,_0x5c0192){super(),this['_value']=_0x198566,this['_key']=_0x5c0192,this['type']='endAt';}['_apply'](_0x4534c9){qt('endAt',this['_value'],_0x4534c9['_path'],!0x0);const _0x3adf0e=Kh(_0x4534c9['_queryParams'],this['_value'],this['_key']);if(fa(_0x3adf0e),Gn(_0x3adf0e),_0x4534c9['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4534c9['_repo'],_0x4534c9['_path'],_0x3adf0e,_0x4534c9['_orderByCalled']);}}function __(_0x4394e8,_0x5eb1bc){return new pa(_0x4394e8,_0x5eb1bc);}class _a extends dt{constructor(_0x45e52a,_0x34d3dc){super(),this['_value']=_0x45e52a,this['_key']=_0x34d3dc,this['type']='startAt';}['_apply'](_0x30d60d){qt('startAt',this['_value'],_0x30d60d['_path'],!0x0);const _0x15e6ad=jh(_0x30d60d['_queryParams'],this['_value'],this['_key']);if(fa(_0x15e6ad),Gn(_0x15e6ad),_0x30d60d['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x30d60d['_repo'],_0x30d60d['_path'],_0x15e6ad,_0x30d60d['_orderByCalled']);}}function g_(_0x22e95d=null,_0xa698be){return new _a(_0x22e95d,_0xa698be);}class Ud extends dt{constructor(_0x53345a){super(),this['_limit']=_0x53345a,this['type']='limitToFirst';}['_apply'](_0x1ca8ef){if(_0x1ca8ef['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x1ca8ef['_repo'],_0x1ca8ef['_path'],zh(_0x1ca8ef['_queryParams'],this['_limit']),_0x1ca8ef['_orderByCalled']);}}function m_(_0x50ef45){if(Math['floor'](_0x50ef45)!==_0x50ef45||_0x50ef45<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x50ef45);}class Wd extends dt{constructor(_0x3c3479){super(),this['_path']=_0x3c3479,this['type']='orderByChild';}['_apply'](_0x39f8cf){da(_0x39f8cf,'orderByChild');const _0x3611da=new C(this['_path']);if(v(_0x3611da))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x98963a=new Ki(_0x3611da),_0x58614c=Do(_0x39f8cf['_queryParams'],_0x98963a);return Gn(_0x58614c),new be(_0x39f8cf['_repo'],_0x39f8cf['_path'],_0x58614c,!0x0);}}function y_(_0x57d07c){if(_0x57d07c==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x57d07c==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x57d07c==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x57d07c),new Wd(_0x57d07c);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x37fcd6){da(_0x37fcd6,'orderByKey');const _0xb62bae=Do(_0x37fcd6['_queryParams'],ye);return Gn(_0xb62bae),new be(_0x37fcd6['_repo'],_0x37fcd6['_path'],_0xb62bae,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x150fa0,_0x364836){super(),this['_value']=_0x150fa0,this['_key']=_0x364836,this['type']='equalTo';}['_apply'](_0x1827b7){if(qt('equalTo',this['_value'],_0x1827b7['_path'],!0x1),_0x1827b7['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1827b7['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x1827b7));}}function E_(_0x357721,_0x450c39){return new Vd(_0x357721,_0x450c39);}function I_(_0x39f10d,..._0x103e19){let _0x5adeaf=k(_0x39f10d);for(const _0x476b07 of _0x103e19)_0x5adeaf=_0x476b07['_apply'](_0x5adeaf);return _0x5adeaf;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3fd1d5,_0x562045,_0x4d6356,_0x56088a){const _0x500177=_0x562045['lastIndexOf'](':'),_0x4f9575=_0x562045['substring'](0x0,_0x500177),_0x56495f=Wt(_0x4f9575);_0x3fd1d5['repoInfo_']=new _o(_0x562045,_0x56495f,_0x3fd1d5['repoInfo_']['namespace'],_0x3fd1d5['repoInfo_']['webSocketOnly'],_0x3fd1d5['repoInfo_']['nodeAdmin'],_0x3fd1d5['repoInfo_']['persistenceKey'],_0x3fd1d5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4d6356),_0x56088a&&(_0x3fd1d5['authTokenProvider_']=_0x56088a);}function qd(_0x3203d3,_0x3f2338,_0x5033a8,_0x347832,_0x23ef81){let _0x29d7ff=_0x347832||_0x3203d3['options']['databaseURL'];_0x29d7ff===void 0x0&&(_0x3203d3['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3203d3['options']['projectId']),_0x29d7ff=_0x3203d3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5f36d6=gr(_0x29d7ff,_0x23ef81),_0x401d37=_0x5f36d6['repoInfo'],_0x23672e;typeof process<'u'&&Us&&(_0x23672e=Us[Hd]),_0x23672e?(_0x29d7ff='http://'+_0x23672e+'?ns='+_0x401d37['namespace'],_0x5f36d6=gr(_0x29d7ff,_0x23ef81),_0x401d37=_0x5f36d6['repoInfo']):_0x5f36d6['repoInfo']['secure'];const _0x20eca2=new Jl(_0x3203d3['name'],_0x3203d3['options'],_0x3f2338);dd('Invalid\x20Firebase\x20Database\x20URL',_0x5f36d6),v(_0x5f36d6['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1eb0d3=jd(_0x401d37,_0x3203d3,_0x20eca2,new Ql(_0x3203d3,_0x5033a8));return new Kd(_0x1eb0d3,_0x3203d3);}function zd(_0x3235ce,_0x93042e){const _0xc14993=ki[_0x93042e];(!_0xc14993||_0xc14993[_0x3235ce['key']]!==_0x3235ce)&&oe('Database\x20'+_0x93042e+'('+_0x3235ce['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x3235ce),delete _0xc14993[_0x3235ce['key']];}function jd(_0x58d4d5,_0x5ca574,_0x4ee2f0,_0x4aed69){let _0x27b12f=ki[_0x5ca574['name']];_0x27b12f||(_0x27b12f={},ki[_0x5ca574['name']]=_0x27b12f);let _0x1847ce=_0x27b12f[_0x58d4d5['toURLString']()];return _0x1847ce&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1847ce=new gd(_0x58d4d5,$d,_0x4ee2f0,_0x4aed69),_0x27b12f[_0x58d4d5['toURLString']()]=_0x1847ce,_0x1847ce;}class Kd{constructor(_0x42d3d9,_0x15dbb8){this['_repoInternal']=_0x42d3d9,this['app']=_0x15dbb8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3028da){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x3028da+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x1ee15d=Qr(),_0x19a1d2){const _0x47b330=Ui(_0x1ee15d,'database')['getImmediate']({'identifier':_0x19a1d2});if(!_0x47b330['_instanceStarted']){const _0x5a287b=ac('database');_0x5a287b&&Yd(_0x47b330,..._0x5a287b);}return _0x47b330;}function Yd(_0x330e0f,_0x1d56ad,_0x4ad264,_0x213f00={}){_0x330e0f=k(_0x330e0f),_0x330e0f['_checkNotDeleted']('useEmulator');const _0x3a4af9=_0x1d56ad+':'+_0x4ad264,_0x8d8110=_0x330e0f['_repoInternal'];if(_0x330e0f['_instanceStarted']){if(_0x3a4af9===_0x330e0f['_repoInternal']['repoInfo_']['host']&&De(_0x213f00,_0x8d8110['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3343bb;if(_0x8d8110['repoInfo_']['nodeAdmin'])_0x213f00['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3343bb=new tn(tn['OWNER']);else{if(_0x213f00['mockUserToken']){const _0x3d9e53=typeof _0x213f00['mockUserToken']=='string'?_0x213f00['mockUserToken']:cc(_0x213f00['mockUserToken'],_0x330e0f['app']['options']['projectId']);_0x3343bb=new tn(_0x3d9e53);}}Wt(_0x1d56ad)&&jr(_0x1d56ad),Gd(_0x8d8110,_0x3a4af9,_0x213f00,_0x3343bb);}function C_(_0x2002f6){_0x2002f6=k(_0x2002f6),_0x2002f6['_checkNotDeleted']('goOffline'),aa(_0x2002f6['_repo']);}function T_(_0x3ece06){_0x3ece06=k(_0x3ece06),_0x3ece06['_checkNotDeleted']('goOnline'),Sd(_0x3ece06['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x759be3){Ll(ct),et(new Me('database',(_0x27d2fa,{instanceIdentifier:_0x167c24})=>{const _0x2f8627=_0x27d2fa['getProvider']('app')['getImmediate'](),_0x4e0100=_0x27d2fa['getProvider']('auth-internal'),_0x4c4603=_0x27d2fa['getProvider']('app-check-internal');return qd(_0x2f8627,_0x4e0100,_0x4c4603,_0x167c24);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x759be3),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1a16b9,_0x255cf){this['committed']=_0x1a16b9,this['snapshot']=_0x255cf;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x402280,_0x3a258e,_0x418a70){if(_0x402280=k(_0x402280),gs('Reference.transaction',_0x402280['_path']),_0x402280['key']==='.length'||_0x402280['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x402280['key']+'\x20is\x20a\x20read-only\x20object.';const _0x394e96=!0x0,_0x5a35c2=new Ve(),_0x1c52ea=(_0x17ec1e,_0x3c9641,_0xbfd029)=>{let _0x39f17a=null;_0x17ec1e?_0x5a35c2['reject'](_0x17ec1e):(_0x39f17a=new rt(_0xbfd029,new Z(_0x402280['_repo'],_0x402280['_path']),R),_0x5a35c2['resolve'](new Xd(_0x3c9641,_0x39f17a)));},_0x581583=Fd(_0x402280,()=>{});return bd(_0x402280['_repo'],_0x402280['_path'],_0x3a258e,_0x1c52ea,_0x581583,_0x394e96),_0x5a35c2['promise'];}ie['prototype']['simpleListen']=function(_0x59951c,_0x4f43c6){this['sendRequest']('q',{'p':_0x59951c},_0x4f43c6);},ie['prototype']['echo']=function(_0x3fb5e1,_0x2b6fee){this['sendRequest']('echo',{'d':_0x3fb5e1},_0x2b6fee);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x48f815,..._0x2ac916){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x48f815,..._0x2ac916);}function nn(_0x4aebf7,..._0x20a0cb){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x4aebf7,..._0x20a0cb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x10fced,..._0xe6a83b){throw Es(_0x10fced,..._0xe6a83b);}function J(_0x22e6dd,..._0x5213d6){return Es(_0x22e6dd,..._0x5213d6);}function ya(_0x5dea61,_0x3db230,_0x3c6056){const _0x3e6edc={...Zd(),[_0x3db230]:_0x3c6056};return new Ut('auth','Firebase',_0x3e6edc)['create'](_0x3db230,{'appName':_0x5dea61['name']});}function se(_0x36af3a){return ya(_0x36af3a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x5a8585,..._0x412554){if(typeof _0x5a8585!='string'){const _0xdf0b38=_0x412554[0x0],_0x2f463e=[..._0x412554['slice'](0x1)];return _0x2f463e[0x0]&&(_0x2f463e[0x0]['appName']=_0x5a8585['name']),_0x5a8585['_errorFactory']['create'](_0xdf0b38,..._0x2f463e);}return ma['create'](_0x5a8585,..._0x412554);}function m(_0x3a25d3,_0x100c4d,..._0x3c379e){if(!_0x3a25d3)throw Es(_0x100c4d,..._0x3c379e);}function te(_0x432a22){const _0x533a29='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x432a22;throw nn(_0x533a29),new Error(_0x533a29);}function ae(_0x375a71,_0x5f3422){_0x375a71||te(_0x5f3422);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x42e16a;return typeof self<'u'&&((_0x42e16a=self['location'])==null?void 0x0:_0x42e16a['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x1550df;return typeof self<'u'&&((_0x1550df=self['location'])==null?void 0x0:_0x1550df['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x211c08=navigator;return _0x211c08['languages']&&_0x211c08['languages'][0x0]||_0x211c08['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x3c109d,_0x18d747){this['shortDelay']=_0x3c109d,this['longDelay']=_0x18d747,ae(_0x18d747>_0x3c109d,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x2e8184,_0x12d3f7){ae(_0x2e8184['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x38ef46}=_0x2e8184['emulator'];return _0x12d3f7?''+_0x38ef46+(_0x12d3f7['startsWith']('/')?_0x12d3f7['slice'](0x1):_0x12d3f7):_0x38ef46;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x21be44,_0x453d3a,_0x259b34){this['fetchImpl']=_0x21be44,_0x453d3a&&(this['headersImpl']=_0x453d3a),_0x259b34&&(this['responseImpl']=_0x259b34);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x350397,_0x3683c3){return _0x350397['tenantId']&&!_0x3683c3['tenantId']?{..._0x3683c3,'tenantId':_0x350397['tenantId']}:_0x3683c3;}async function Ae(_0x18c5e4,_0x43b3bf,_0xc04bd3,_0x34b801,_0x3b1829={}){return Ea(_0x18c5e4,_0x3b1829,async()=>{let _0x2c1874={},_0x4a135c={};_0x34b801&&(_0x43b3bf==='GET'?_0x4a135c=_0x34b801:_0x2c1874={'body':JSON['stringify'](_0x34b801)});const _0xeab3a0=at({..._0x4a135c,'key':_0x18c5e4['config']['apiKey']})['slice'](0x1),_0xcc1eaf=await _0x18c5e4['_getAdditionalHeaders']();_0xcc1eaf['Content-Type']='application/json',_0x18c5e4['languageCode']&&(_0xcc1eaf['X-Firebase-Locale']=_0x18c5e4['languageCode']);const _0x9ab62e={'method':_0x43b3bf,'headers':_0xcc1eaf,..._0x2c1874};return lc()||(_0x9ab62e['referrerPolicy']='strict-origin-when-cross-origin'),_0x18c5e4['emulatorConfig']&&Wt(_0x18c5e4['emulatorConfig']['host'])&&(_0x9ab62e['credentials']='include'),va['fetch']()(await Ia(_0x18c5e4,_0x18c5e4['config']['apiHost'],_0xc04bd3,_0xeab3a0),_0x9ab62e);});}async function Ea(_0x2ef2f3,_0x26664a,_0x1b2a48){_0x2ef2f3['_canInitEmulator']=!0x1;const _0x653d37={...rf,..._0x26664a};try{const _0xba97eb=new lf(_0x2ef2f3),_0x1da3d3=await Promise['race']([_0x1b2a48(),_0xba97eb['promise']]);_0xba97eb['clearNetworkTimeout']();const _0xaf4fb=await _0x1da3d3['json']();if('needConfirmation'in _0xaf4fb)throw en(_0x2ef2f3,'account-exists-with-different-credential',_0xaf4fb);if(_0x1da3d3['ok']&&!('errorMessage'in _0xaf4fb))return _0xaf4fb;{const _0x289ec1=_0x1da3d3['ok']?_0xaf4fb['errorMessage']:_0xaf4fb['error']['message'],[_0x31a34a,_0x17f6e6]=_0x289ec1['split']('\x20:\x20');if(_0x31a34a==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x2ef2f3,'credential-already-in-use',_0xaf4fb);if(_0x31a34a==='EMAIL_EXISTS')throw en(_0x2ef2f3,'email-already-in-use',_0xaf4fb);if(_0x31a34a==='USER_DISABLED')throw en(_0x2ef2f3,'user-disabled',_0xaf4fb);const _0x4364e9=_0x653d37[_0x31a34a]||_0x31a34a['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x17f6e6)throw ya(_0x2ef2f3,_0x4364e9,_0x17f6e6);K(_0x2ef2f3,_0x4364e9);}}catch(_0x51d9a0){if(_0x51d9a0 instanceof Se)throw _0x51d9a0;K(_0x2ef2f3,'network-request-failed',{'message':String(_0x51d9a0)});}}async function Yt(_0x28ffcf,_0x23a922,_0x42a46d,_0x417544,_0x36c025={}){const _0x4aed75=await Ae(_0x28ffcf,_0x23a922,_0x42a46d,_0x417544,_0x36c025);return'mfaPendingCredential'in _0x4aed75&&K(_0x28ffcf,'multi-factor-auth-required',{'_serverResponse':_0x4aed75}),_0x4aed75;}async function Ia(_0x235a50,_0x37ce8f,_0x4003c4,_0x50239c){const _0x44371d=''+_0x37ce8f+_0x4003c4+'?'+_0x50239c,_0x3291a2=_0x235a50,_0x30101d=_0x3291a2['config']['emulator']?Is(_0x235a50['config'],_0x44371d):_0x235a50['config']['apiScheme']+'://'+_0x44371d;return of['includes'](_0x4003c4)&&(await _0x3291a2['_persistenceManagerAvailable'],_0x3291a2['_getPersistenceType']()==='COOKIE')?_0x3291a2['_getPersistence']()['_getFinalTarget'](_0x30101d)['toString']():_0x30101d;}function cf(_0x22948b){switch(_0x22948b){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x36be71){this['auth']=_0x36be71,this['timer']=null,this['promise']=new Promise((_0xee3c3f,_0x1afbe9)=>{this['timer']=setTimeout(()=>_0x1afbe9(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x167a42,_0x349999,_0x32732f){const _0x11df48={'appName':_0x167a42['name']};_0x32732f['email']&&(_0x11df48['email']=_0x32732f['email']),_0x32732f['phoneNumber']&&(_0x11df48['phoneNumber']=_0x32732f['phoneNumber']);const _0x55c7c0=J(_0x167a42,_0x349999,_0x11df48);return _0x55c7c0['customData']['_tokenResponse']=_0x32732f,_0x55c7c0;}function vr(_0x472725){return _0x472725!==void 0x0&&_0x472725['enterprise']!==void 0x0;}class hf{constructor(_0x5d97f0){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5d97f0['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5d97f0['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5d97f0['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x50c8ca){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x25405b of this['recaptchaEnforcementState'])if(_0x25405b['provider']&&_0x25405b['provider']===_0x50c8ca)return cf(_0x25405b['enforcementState']);return null;}['isProviderEnabled'](_0xb4050b){return this['getProviderEnforcementState'](_0xb4050b)==='ENFORCE'||this['getProviderEnforcementState'](_0xb4050b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x1d3988,_0x4440de){return Ae(_0x1d3988,'GET','/v2/recaptchaConfig',Re(_0x1d3988,_0x4440de));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x10dd31,_0x996c90){return Ae(_0x10dd31,'POST','/v1/accounts:delete',_0x996c90);}async function Sn(_0x3874c2,_0x51a9ab){return Ae(_0x3874c2,'POST','/v1/accounts:lookup',_0x51a9ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x5db887){if(_0x5db887)try{const _0x449977=new Date(Number(_0x5db887));if(!isNaN(_0x449977['getTime']()))return _0x449977['toUTCString']();}catch{}}async function ff(_0x177112,_0x2d4e69=!0x1){const _0x3b47da=k(_0x177112),_0xcffef8=await _0x3b47da['getIdToken'](_0x2d4e69),_0x2fcd07=ws(_0xcffef8);m(_0x2fcd07&&_0x2fcd07['exp']&&_0x2fcd07['auth_time']&&_0x2fcd07['iat'],_0x3b47da['auth'],'internal-error');const _0xfedc9b=typeof _0x2fcd07['firebase']=='object'?_0x2fcd07['firebase']:void 0x0,_0x59f69f=_0xfedc9b==null?void 0x0:_0xfedc9b['sign_in_provider'];return{'claims':_0x2fcd07,'token':_0xcffef8,'authTime':St(ci(_0x2fcd07['auth_time'])),'issuedAtTime':St(ci(_0x2fcd07['iat'])),'expirationTime':St(ci(_0x2fcd07['exp'])),'signInProvider':_0x59f69f||null,'signInSecondFactor':(_0xfedc9b==null?void 0x0:_0xfedc9b['sign_in_second_factor'])||null};}function ci(_0x679cb5){return Number(_0x679cb5)*0x3e8;}function ws(_0x427c9e){const [_0x1c6f04,_0x484947,_0x540312]=_0x427c9e['split']('.');if(_0x1c6f04===void 0x0||_0x484947===void 0x0||_0x540312===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x117853=cn(_0x484947);return _0x117853?JSON['parse'](_0x117853):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x718c5c){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x718c5c==null?void 0x0:_0x718c5c['toString']()),null;}}function Er(_0x55adb3){const _0x347a99=ws(_0x55adb3);return m(_0x347a99,'internal-error'),m(typeof _0x347a99['exp']<'u','internal-error'),m(typeof _0x347a99['iat']<'u','internal-error'),Number(_0x347a99['exp'])-Number(_0x347a99['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0xf58371,_0x4bd05a,_0x2b6a80=!0x1){if(_0x2b6a80)return _0x4bd05a;try{return await _0x4bd05a;}catch(_0x16e524){throw _0x16e524 instanceof Se&&pf(_0x16e524)&&_0xf58371['auth']['currentUser']===_0xf58371&&await _0xf58371['auth']['signOut'](),_0x16e524;}}function pf({code:_0x144b72}){return _0x144b72==='auth/user-disabled'||_0x144b72==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x278262){this['user']=_0x278262,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x49672f){if(_0x49672f){const _0x3c1caa=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3c1caa;}else{this['errorBackoff']=0x7530;const _0x22f0ac=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x22f0ac);}}['schedule'](_0x5b88f0=!0x1){if(!this['isRunning'])return;const _0x4f33b4=this['getInterval'](_0x5b88f0);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4f33b4);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x32aabe){(_0x32aabe==null?void 0x0:_0x32aabe['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x21a73c,_0x2e6bcd){this['createdAt']=_0x21a73c,this['lastLoginAt']=_0x2e6bcd,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x572da6){this['createdAt']=_0x572da6['createdAt'],this['lastLoginAt']=_0x572da6['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x50b180){var _0x172b9b;const _0x19cc47=_0x50b180['auth'],_0x39cb4b=await _0x50b180['getIdToken'](),_0x273d24=await xt(_0x50b180,Sn(_0x19cc47,{'idToken':_0x39cb4b}));m(_0x273d24==null?void 0x0:_0x273d24['users']['length'],_0x19cc47,'internal-error');const _0x1a78d5=_0x273d24['users'][0x0];_0x50b180['_notifyReloadListener'](_0x1a78d5);const _0x9c5eb4=(_0x172b9b=_0x1a78d5['providerUserInfo'])!=null&&_0x172b9b['length']?wa(_0x1a78d5['providerUserInfo']):[],_0x14afbe=mf(_0x50b180['providerData'],_0x9c5eb4),_0x5a3c3a=_0x50b180['isAnonymous'],_0x516be8=!(_0x50b180['email']&&_0x1a78d5['passwordHash'])&&!(_0x14afbe!=null&&_0x14afbe['length']),_0x436b52=_0x5a3c3a?_0x516be8:!0x1,_0x3af3a2={'uid':_0x1a78d5['localId'],'displayName':_0x1a78d5['displayName']||null,'photoURL':_0x1a78d5['photoUrl']||null,'email':_0x1a78d5['email']||null,'emailVerified':_0x1a78d5['emailVerified']||!0x1,'phoneNumber':_0x1a78d5['phoneNumber']||null,'tenantId':_0x1a78d5['tenantId']||null,'providerData':_0x14afbe,'metadata':new Pi(_0x1a78d5['createdAt'],_0x1a78d5['lastLoginAt']),'isAnonymous':_0x436b52};Object['assign'](_0x50b180,_0x3af3a2);}async function gf(_0x24a548){const _0x321bd0=k(_0x24a548);await bn(_0x321bd0),await _0x321bd0['auth']['_persistUserIfCurrent'](_0x321bd0),_0x321bd0['auth']['_notifyListenersIfCurrent'](_0x321bd0);}function mf(_0x449def,_0x3f7d82){return[..._0x449def['filter'](_0x167db0=>!_0x3f7d82['some'](_0xf8d7a0=>_0xf8d7a0['providerId']===_0x167db0['providerId'])),..._0x3f7d82];}function wa(_0x10cbbd){return _0x10cbbd['map'](({providerId:_0x5dbd3e,..._0x4b5c13})=>({'providerId':_0x5dbd3e,'uid':_0x4b5c13['rawId']||'','displayName':_0x4b5c13['displayName']||null,'email':_0x4b5c13['email']||null,'phoneNumber':_0x4b5c13['phoneNumber']||null,'photoURL':_0x4b5c13['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x90c1b9,_0x541387){const _0x475a1b=await Ea(_0x90c1b9,{},async()=>{const _0x5dc847=at({'grant_type':'refresh_token','refresh_token':_0x541387})['slice'](0x1),{tokenApiHost:_0x319304,apiKey:_0x56fe6e}=_0x90c1b9['config'],_0x16a09c=await Ia(_0x90c1b9,_0x319304,'/v1/token','key='+_0x56fe6e),_0x4346ee=await _0x90c1b9['_getAdditionalHeaders']();_0x4346ee['Content-Type']='application/x-www-form-urlencoded';const _0x5f3ef5={'method':'POST','headers':_0x4346ee,'body':_0x5dc847};return _0x90c1b9['emulatorConfig']&&Wt(_0x90c1b9['emulatorConfig']['host'])&&(_0x5f3ef5['credentials']='include'),va['fetch']()(_0x16a09c,_0x5f3ef5);});return{'accessToken':_0x475a1b['access_token'],'expiresIn':_0x475a1b['expires_in'],'refreshToken':_0x475a1b['refresh_token']};}async function vf(_0x2f26eb,_0x4a42e1){return Ae(_0x2f26eb,'POST','/v2/accounts:revokeToken',Re(_0x2f26eb,_0x4a42e1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3ffa88){m(_0x3ffa88['idToken'],'internal-error'),m(typeof _0x3ffa88['idToken']<'u','internal-error'),m(typeof _0x3ffa88['refreshToken']<'u','internal-error');const _0x5e083a='expiresIn'in _0x3ffa88&&typeof _0x3ffa88['expiresIn']<'u'?Number(_0x3ffa88['expiresIn']):Er(_0x3ffa88['idToken']);this['updateTokensAndExpiration'](_0x3ffa88['idToken'],_0x3ffa88['refreshToken'],_0x5e083a);}['updateFromIdToken'](_0x385049){m(_0x385049['length']!==0x0,'internal-error');const _0x41c41b=Er(_0x385049);this['updateTokensAndExpiration'](_0x385049,null,_0x41c41b);}async['getToken'](_0x180cec,_0x3f87ee=!0x1){return!_0x3f87ee&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x180cec,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x180cec,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5ca1de,_0x4de5e){const {accessToken:_0x443ff7,refreshToken:_0x58c0b1,expiresIn:_0x11bba7}=await yf(_0x5ca1de,_0x4de5e);this['updateTokensAndExpiration'](_0x443ff7,_0x58c0b1,Number(_0x11bba7));}['updateTokensAndExpiration'](_0x398c46,_0x461228,_0x2ec1ae){this['refreshToken']=_0x461228||null,this['accessToken']=_0x398c46||null,this['expirationTime']=Date['now']()+_0x2ec1ae*0x3e8;}static['fromJSON'](_0x363c67,_0xf6d9e8){const {refreshToken:_0xdbcdd3,accessToken:_0x2d6baa,expirationTime:_0x3b4a20}=_0xf6d9e8,_0x3a54a8=new Je();return _0xdbcdd3&&(m(typeof _0xdbcdd3=='string','internal-error',{'appName':_0x363c67}),_0x3a54a8['refreshToken']=_0xdbcdd3),_0x2d6baa&&(m(typeof _0x2d6baa=='string','internal-error',{'appName':_0x363c67}),_0x3a54a8['accessToken']=_0x2d6baa),_0x3b4a20&&(m(typeof _0x3b4a20=='number','internal-error',{'appName':_0x363c67}),_0x3a54a8['expirationTime']=_0x3b4a20),_0x3a54a8;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xecbe07){this['accessToken']=_0xecbe07['accessToken'],this['refreshToken']=_0xecbe07['refreshToken'],this['expirationTime']=_0xecbe07['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x3ee33c,_0xf982a0){m(typeof _0x3ee33c=='string'||typeof _0x3ee33c>'u','internal-error',{'appName':_0xf982a0});}class z{constructor({uid:_0x4926b9,auth:_0x1f4e0a,stsTokenManager:_0x5ec9b3,..._0x1e5e20}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4926b9,this['auth']=_0x1f4e0a,this['stsTokenManager']=_0x5ec9b3,this['accessToken']=_0x5ec9b3['accessToken'],this['displayName']=_0x1e5e20['displayName']||null,this['email']=_0x1e5e20['email']||null,this['emailVerified']=_0x1e5e20['emailVerified']||!0x1,this['phoneNumber']=_0x1e5e20['phoneNumber']||null,this['photoURL']=_0x1e5e20['photoURL']||null,this['isAnonymous']=_0x1e5e20['isAnonymous']||!0x1,this['tenantId']=_0x1e5e20['tenantId']||null,this['providerData']=_0x1e5e20['providerData']?[..._0x1e5e20['providerData']]:[],this['metadata']=new Pi(_0x1e5e20['createdAt']||void 0x0,_0x1e5e20['lastLoginAt']||void 0x0);}async['getIdToken'](_0x54183d){const _0x459d03=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x54183d));return m(_0x459d03,this['auth'],'internal-error'),this['accessToken']!==_0x459d03&&(this['accessToken']=_0x459d03,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x459d03;}['getIdTokenResult'](_0xb99f3b){return ff(this,_0xb99f3b);}['reload'](){return gf(this);}['_assign'](_0x41567a){this!==_0x41567a&&(m(this['uid']===_0x41567a['uid'],this['auth'],'internal-error'),this['displayName']=_0x41567a['displayName'],this['photoURL']=_0x41567a['photoURL'],this['email']=_0x41567a['email'],this['emailVerified']=_0x41567a['emailVerified'],this['phoneNumber']=_0x41567a['phoneNumber'],this['isAnonymous']=_0x41567a['isAnonymous'],this['tenantId']=_0x41567a['tenantId'],this['providerData']=_0x41567a['providerData']['map'](_0x37a208=>({..._0x37a208})),this['metadata']['_copy'](_0x41567a['metadata']),this['stsTokenManager']['_assign'](_0x41567a['stsTokenManager']));}['_clone'](_0x4e6a6b){const _0x340a43=new z({...this,'auth':_0x4e6a6b,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x340a43['metadata']['_copy'](this['metadata']),_0x340a43;}['_onReload'](_0x3759b9){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x3759b9,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x10a4c0){this['reloadListener']?this['reloadListener'](_0x10a4c0):this['reloadUserInfo']=_0x10a4c0;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x45058d,_0x3f4611=!0x1){let _0x3c577c=!0x1;_0x45058d['idToken']&&_0x45058d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x45058d),_0x3c577c=!0x0),_0x3f4611&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3c577c&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x9568fb=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x9568fb})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xef2422=>({..._0xef2422})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x84eca7,_0x44a1df){const _0x3969ee=_0x44a1df['displayName']??void 0x0,_0x332349=_0x44a1df['email']??void 0x0,_0x2611c2=_0x44a1df['phoneNumber']??void 0x0,_0x468f9f=_0x44a1df['photoURL']??void 0x0,_0x1412d0=_0x44a1df['tenantId']??void 0x0,_0xd6e5bc=_0x44a1df['_redirectEventId']??void 0x0,_0x3f83aa=_0x44a1df['createdAt']??void 0x0,_0xef84b=_0x44a1df['lastLoginAt']??void 0x0,{uid:_0x20e3ff,emailVerified:_0x32c09a,isAnonymous:_0x1325bc,providerData:_0x3b0816,stsTokenManager:_0x2e7e85}=_0x44a1df;m(_0x20e3ff&&_0x2e7e85,_0x84eca7,'internal-error');const _0x441833=Je['fromJSON'](this['name'],_0x2e7e85);m(typeof _0x20e3ff=='string',_0x84eca7,'internal-error'),ce(_0x3969ee,_0x84eca7['name']),ce(_0x332349,_0x84eca7['name']),m(typeof _0x32c09a=='boolean',_0x84eca7,'internal-error'),m(typeof _0x1325bc=='boolean',_0x84eca7,'internal-error'),ce(_0x2611c2,_0x84eca7['name']),ce(_0x468f9f,_0x84eca7['name']),ce(_0x1412d0,_0x84eca7['name']),ce(_0xd6e5bc,_0x84eca7['name']),ce(_0x3f83aa,_0x84eca7['name']),ce(_0xef84b,_0x84eca7['name']);const _0x5edd8f=new z({'uid':_0x20e3ff,'auth':_0x84eca7,'email':_0x332349,'emailVerified':_0x32c09a,'displayName':_0x3969ee,'isAnonymous':_0x1325bc,'photoURL':_0x468f9f,'phoneNumber':_0x2611c2,'tenantId':_0x1412d0,'stsTokenManager':_0x441833,'createdAt':_0x3f83aa,'lastLoginAt':_0xef84b});return _0x3b0816&&Array['isArray'](_0x3b0816)&&(_0x5edd8f['providerData']=_0x3b0816['map'](_0x572f85=>({..._0x572f85}))),_0xd6e5bc&&(_0x5edd8f['_redirectEventId']=_0xd6e5bc),_0x5edd8f;}static async['_fromIdTokenResponse'](_0x1ecfff,_0x353658,_0x229138=!0x1){const _0x1189f1=new Je();_0x1189f1['updateFromServerResponse'](_0x353658);const _0x1939bf=new z({'uid':_0x353658['localId'],'auth':_0x1ecfff,'stsTokenManager':_0x1189f1,'isAnonymous':_0x229138});return await bn(_0x1939bf),_0x1939bf;}static async['_fromGetAccountInfoResponse'](_0x5a9169,_0x2fff3c,_0x4e3e61){const _0x14665a=_0x2fff3c['users'][0x0];m(_0x14665a['localId']!==void 0x0,'internal-error');const _0x25c395=_0x14665a['providerUserInfo']!==void 0x0?wa(_0x14665a['providerUserInfo']):[],_0x3c1b90=!(_0x14665a['email']&&_0x14665a['passwordHash'])&&!(_0x25c395!=null&&_0x25c395['length']),_0x606fb2=new Je();_0x606fb2['updateFromIdToken'](_0x4e3e61);const _0x2527d6=new z({'uid':_0x14665a['localId'],'auth':_0x5a9169,'stsTokenManager':_0x606fb2,'isAnonymous':_0x3c1b90}),_0x3d830f={'uid':_0x14665a['localId'],'displayName':_0x14665a['displayName']||null,'photoURL':_0x14665a['photoUrl']||null,'email':_0x14665a['email']||null,'emailVerified':_0x14665a['emailVerified']||!0x1,'phoneNumber':_0x14665a['phoneNumber']||null,'tenantId':_0x14665a['tenantId']||null,'providerData':_0x25c395,'metadata':new Pi(_0x14665a['createdAt'],_0x14665a['lastLoginAt']),'isAnonymous':!(_0x14665a['email']&&_0x14665a['passwordHash'])&&!(_0x25c395!=null&&_0x25c395['length'])};return Object['assign'](_0x2527d6,_0x3d830f),_0x2527d6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x7695e9){ae(_0x7695e9 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x45b600=Ir['get'](_0x7695e9);return _0x45b600?(ae(_0x45b600 instanceof _0x7695e9,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x45b600):(_0x45b600=new _0x7695e9(),Ir['set'](_0x7695e9,_0x45b600),_0x45b600);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3bf602,_0x455874){this['storage'][_0x3bf602]=_0x455874;}async['_get'](_0x478481){const _0x81883e=this['storage'][_0x478481];return _0x81883e===void 0x0?null:_0x81883e;}async['_remove'](_0x840e84){delete this['storage'][_0x840e84];}['_addListener'](_0x442fd4,_0x396f5a){}['_removeListener'](_0x14dd3a,_0x3d7beb){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0xd8bc24,_0x54ee16,_0x5f3a3c){return'firebase:'+_0xd8bc24+':'+_0x54ee16+':'+_0x5f3a3c;}class Xe{constructor(_0x331957,_0x4c73f8,_0x53e492){this['persistence']=_0x331957,this['auth']=_0x4c73f8,this['userKey']=_0x53e492;const {config:_0x3495ac,name:_0x4a31fd}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x3495ac['apiKey'],_0x4a31fd),this['fullPersistenceKey']=sn('persistence',_0x3495ac['apiKey'],_0x4a31fd),this['boundEventHandler']=_0x4c73f8['_onStorageEvent']['bind'](_0x4c73f8),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4b42c4){return this['persistence']['_set'](this['fullUserKey'],_0x4b42c4['toJSON']());}async['getCurrentUser'](){const _0xbb0de=await this['persistence']['_get'](this['fullUserKey']);if(!_0xbb0de)return null;if(typeof _0xbb0de=='string'){const _0x6e607b=await Sn(this['auth'],{'idToken':_0xbb0de})['catch'](()=>{});return _0x6e607b?z['_fromGetAccountInfoResponse'](this['auth'],_0x6e607b,_0xbb0de):null;}return z['_fromJSON'](this['auth'],_0xbb0de);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x345c93){if(this['persistence']===_0x345c93)return;const _0x3e6d8=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x345c93,_0x3e6d8)return this['setCurrentUser'](_0x3e6d8);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2959cb,_0x109f3f,_0x4d7a6a='authUser'){if(!_0x109f3f['length'])return new Xe(ne(wr),_0x2959cb,_0x4d7a6a);const _0x252153=(await Promise['all'](_0x109f3f['map'](async _0x58922f=>{if(await _0x58922f['_isAvailable']())return _0x58922f;})))['filter'](_0x44e3eb=>_0x44e3eb);let _0x33f2aa=_0x252153[0x0]||ne(wr);const _0x256c7c=sn(_0x4d7a6a,_0x2959cb['config']['apiKey'],_0x2959cb['name']);let _0x15add9=null;for(const _0xdf0775 of _0x109f3f)try{const _0x8d3f8e=await _0xdf0775['_get'](_0x256c7c);if(_0x8d3f8e){let _0x5baa5d;if(typeof _0x8d3f8e=='string'){const _0x30c631=await Sn(_0x2959cb,{'idToken':_0x8d3f8e})['catch'](()=>{});if(!_0x30c631)break;_0x5baa5d=await z['_fromGetAccountInfoResponse'](_0x2959cb,_0x30c631,_0x8d3f8e);}else _0x5baa5d=z['_fromJSON'](_0x2959cb,_0x8d3f8e);_0xdf0775!==_0x33f2aa&&(_0x15add9=_0x5baa5d),_0x33f2aa=_0xdf0775;break;}}catch{}const _0x25e271=_0x252153['filter'](_0x57f8de=>_0x57f8de['_shouldAllowMigration']);return!_0x33f2aa['_shouldAllowMigration']||!_0x25e271['length']?new Xe(_0x33f2aa,_0x2959cb,_0x4d7a6a):(_0x33f2aa=_0x25e271[0x0],_0x15add9&&await _0x33f2aa['_set'](_0x256c7c,_0x15add9['toJSON']()),await Promise['all'](_0x109f3f['map'](async _0x2326e0=>{if(_0x2326e0!==_0x33f2aa)try{await _0x2326e0['_remove'](_0x256c7c);}catch{}})),new Xe(_0x33f2aa,_0x2959cb,_0x4d7a6a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x373909){const _0x563e24=_0x373909['toLowerCase']();if(_0x563e24['includes']('opera/')||_0x563e24['includes']('opr/')||_0x563e24['includes']('opios/'))return'Opera';if(Ra(_0x563e24))return'IEMobile';if(_0x563e24['includes']('msie')||_0x563e24['includes']('trident/'))return'IE';if(_0x563e24['includes']('edge/'))return'Edge';if(Ta(_0x563e24))return'Firefox';if(_0x563e24['includes']('silk/'))return'Silk';if(ka(_0x563e24))return'Blackberry';if(Na(_0x563e24))return'Webos';if(Sa(_0x563e24))return'Safari';if((_0x563e24['includes']('chrome/')||ba(_0x563e24))&&!_0x563e24['includes']('edge/'))return'Chrome';if(Aa(_0x563e24))return'Android';{const _0x336651=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x45e64a=_0x373909['match'](_0x336651);if((_0x45e64a==null?void 0x0:_0x45e64a['length'])===0x2)return _0x45e64a[0x1];}return'Other';}function Ta(_0x5c7c3c=W()){return/firefox\//i['test'](_0x5c7c3c);}function Sa(_0x11e1ac=W()){const _0x21e29b=_0x11e1ac['toLowerCase']();return _0x21e29b['includes']('safari/')&&!_0x21e29b['includes']('chrome/')&&!_0x21e29b['includes']('crios/')&&!_0x21e29b['includes']('android');}function ba(_0x3290da=W()){return/crios\//i['test'](_0x3290da);}function Ra(_0x39d84c=W()){return/iemobile/i['test'](_0x39d84c);}function Aa(_0x5722e1=W()){return/android/i['test'](_0x5722e1);}function ka(_0x13bf8c=W()){return/blackberry/i['test'](_0x13bf8c);}function Na(_0x1694d7=W()){return/webos/i['test'](_0x1694d7);}function Cs(_0x4791a3=W()){return/iphone|ipad|ipod/i['test'](_0x4791a3)||/macintosh/i['test'](_0x4791a3)&&/mobile/i['test'](_0x4791a3);}function Ef(_0x2bc190=W()){var _0x3fb8d0;return Cs(_0x2bc190)&&!!((_0x3fb8d0=window['navigator'])!=null&&_0x3fb8d0['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x2a6a9d=W()){return Cs(_0x2a6a9d)||Aa(_0x2a6a9d)||Na(_0x2a6a9d)||ka(_0x2a6a9d)||/windows phone/i['test'](_0x2a6a9d)||Ra(_0x2a6a9d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x5bd29b,_0x7590c9=[]){let _0x4238dd;switch(_0x5bd29b){case'Browser':_0x4238dd=Cr(W());break;case'Worker':_0x4238dd=Cr(W())+'-'+_0x5bd29b;break;default:_0x4238dd=_0x5bd29b;}const _0x5bde5d=_0x7590c9['length']?_0x7590c9['join'](','):'FirebaseCore-web';return _0x4238dd+'/JsCore/'+ct+'/'+_0x5bde5d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x455248){this['auth']=_0x455248,this['queue']=[];}['pushCallback'](_0x3c7105,_0x535e36){const _0x104c57=_0x347f65=>new Promise((_0x18f57d,_0x4c4ca2)=>{try{const _0x52e603=_0x3c7105(_0x347f65);_0x18f57d(_0x52e603);}catch(_0xc842a8){_0x4c4ca2(_0xc842a8);}});_0x104c57['onAbort']=_0x535e36,this['queue']['push'](_0x104c57);const _0x40e89a=this['queue']['length']-0x1;return()=>{this['queue'][_0x40e89a]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3f983e){if(this['auth']['currentUser']===_0x3f983e)return;const _0x4d59ca=[];try{for(const _0x48941b of this['queue'])await _0x48941b(_0x3f983e),_0x48941b['onAbort']&&_0x4d59ca['push'](_0x48941b['onAbort']);}catch(_0x3d227f){_0x4d59ca['reverse']();for(const _0x4f10e9 of _0x4d59ca)try{_0x4f10e9();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3d227f==null?void 0x0:_0x3d227f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x4ba8a8,_0x6081ed={}){return Ae(_0x4ba8a8,'GET','/v2/passwordPolicy',Re(_0x4ba8a8,_0x6081ed));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0x3c0388){var _0x2c2846;const _0x1b6313=_0x3c0388['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1b6313['minPasswordLength']??Tf,_0x1b6313['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1b6313['maxPasswordLength']),_0x1b6313['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1b6313['containsLowercaseCharacter']),_0x1b6313['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1b6313['containsUppercaseCharacter']),_0x1b6313['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1b6313['containsNumericCharacter']),_0x1b6313['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1b6313['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3c0388['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2c2846=_0x3c0388['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2c2846['join'](''))??'',this['forceUpgradeOnSignin']=_0x3c0388['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3c0388['schemaVersion'];}['validatePassword'](_0x1b3654){const _0x50aa87={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1b3654,_0x50aa87),this['validatePasswordCharacterOptions'](_0x1b3654,_0x50aa87),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['meetsMinPasswordLength']??!0x0),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['meetsMaxPasswordLength']??!0x0),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['containsLowercaseLetter']??!0x0),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['containsUppercaseLetter']??!0x0),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['containsNumericCharacter']??!0x0),_0x50aa87['isValid']&&(_0x50aa87['isValid']=_0x50aa87['containsNonAlphanumericCharacter']??!0x0),_0x50aa87;}['validatePasswordLengthOptions'](_0x2daca2,_0x23365e){const _0x303e92=this['customStrengthOptions']['minPasswordLength'],_0x588761=this['customStrengthOptions']['maxPasswordLength'];_0x303e92&&(_0x23365e['meetsMinPasswordLength']=_0x2daca2['length']>=_0x303e92),_0x588761&&(_0x23365e['meetsMaxPasswordLength']=_0x2daca2['length']<=_0x588761);}['validatePasswordCharacterOptions'](_0x339894,_0x27df35){this['updatePasswordCharacterOptionsStatuses'](_0x27df35,!0x1,!0x1,!0x1,!0x1);let _0xdd56d1;for(let _0x5da0b6=0x0;_0x5da0b6<_0x339894['length'];_0x5da0b6++)_0xdd56d1=_0x339894['charAt'](_0x5da0b6),this['updatePasswordCharacterOptionsStatuses'](_0x27df35,_0xdd56d1>='a'&&_0xdd56d1<='z',_0xdd56d1>='A'&&_0xdd56d1<='Z',_0xdd56d1>='0'&&_0xdd56d1<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xdd56d1));}['updatePasswordCharacterOptionsStatuses'](_0x5d354c,_0x281441,_0x4bfa8b,_0x917333,_0x5c1751){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5d354c['containsLowercaseLetter']||(_0x5d354c['containsLowercaseLetter']=_0x281441)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5d354c['containsUppercaseLetter']||(_0x5d354c['containsUppercaseLetter']=_0x4bfa8b)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5d354c['containsNumericCharacter']||(_0x5d354c['containsNumericCharacter']=_0x917333)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5d354c['containsNonAlphanumericCharacter']||(_0x5d354c['containsNonAlphanumericCharacter']=_0x5c1751));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x1ec276,_0x2f3f3b,_0xf485f5,_0x5850e0){this['app']=_0x1ec276,this['heartbeatServiceProvider']=_0x2f3f3b,this['appCheckServiceProvider']=_0xf485f5,this['config']=_0x5850e0,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1ec276['name'],this['clientVersion']=_0x5850e0['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5dfc4a=>this['_resolvePersistenceManagerAvailable']=_0x5dfc4a);}['_initializeWithPersistence'](_0x2657b6,_0x4d57c4){return _0x4d57c4&&(this['_popupRedirectResolver']=ne(_0x4d57c4)),this['_initializationPromise']=this['queue'](async()=>{var _0x4f6f06,_0x58637d,_0x53a776;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x2657b6),(_0x4f6f06=this['_resolvePersistenceManagerAvailable'])==null||_0x4f6f06['call'](this),!this['_deleted'])){if((_0x58637d=this['_popupRedirectResolver'])!=null&&_0x58637d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4d57c4),this['lastNotifiedUid']=((_0x53a776=this['currentUser'])==null?void 0x0:_0x53a776['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1d0c14=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1d0c14)){if(this['currentUser']&&_0x1d0c14&&this['currentUser']['uid']===_0x1d0c14['uid']){this['_currentUser']['_assign'](_0x1d0c14),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1d0c14,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x260045){try{const _0x37c88a=await Sn(this,{'idToken':_0x260045}),_0xd2945d=await z['_fromGetAccountInfoResponse'](this,_0x37c88a,_0x260045);await this['directlySetCurrentUser'](_0xd2945d);}catch(_0x1d5450){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1d5450),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4b5677){var _0x567479;if(H(this['app'])){const _0x90b415=this['app']['settings']['authIdToken'];return _0x90b415?new Promise(_0x3033fa=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x90b415)['then'](_0x3033fa,_0x3033fa));}):this['directlySetCurrentUser'](null);}const _0x52c198=await this['assertedPersistence']['getCurrentUser']();let _0x4bb9d0=_0x52c198,_0x44b4a1=!0x1;if(_0x4b5677&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1e4fbd=(_0x567479=this['redirectUser'])==null?void 0x0:_0x567479['_redirectEventId'],_0x193a65=_0x4bb9d0==null?void 0x0:_0x4bb9d0['_redirectEventId'],_0x22110b=await this['tryRedirectSignIn'](_0x4b5677);(!_0x1e4fbd||_0x1e4fbd===_0x193a65)&&(_0x22110b!=null&&_0x22110b['user'])&&(_0x4bb9d0=_0x22110b['user'],_0x44b4a1=!0x0);}if(!_0x4bb9d0)return this['directlySetCurrentUser'](null);if(!_0x4bb9d0['_redirectEventId']){if(_0x44b4a1)try{await this['beforeStateQueue']['runMiddleware'](_0x4bb9d0);}catch(_0x2b0b15){_0x4bb9d0=_0x52c198,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2b0b15));}return _0x4bb9d0?this['reloadAndSetCurrentUserOrClear'](_0x4bb9d0):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4bb9d0['_redirectEventId']?this['directlySetCurrentUser'](_0x4bb9d0):this['reloadAndSetCurrentUserOrClear'](_0x4bb9d0);}async['tryRedirectSignIn'](_0x5f1e98){let _0x2c4383=null;try{_0x2c4383=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5f1e98,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2c4383;}async['reloadAndSetCurrentUserOrClear'](_0x2a5dbe){try{await bn(_0x2a5dbe);}catch(_0x3b6b3d){if((_0x3b6b3d==null?void 0x0:_0x3b6b3d['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2a5dbe);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x123897){if(H(this['app']))return Promise['reject'](se(this));const _0x3fad51=_0x123897?k(_0x123897):null;return _0x3fad51&&m(_0x3fad51['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3fad51&&_0x3fad51['_clone'](this));}async['_updateCurrentUser'](_0x159d42,_0x249a1a=!0x1){if(!this['_deleted'])return _0x159d42&&m(this['tenantId']===_0x159d42['tenantId'],this,'tenant-id-mismatch'),_0x249a1a||await this['beforeStateQueue']['runMiddleware'](_0x159d42),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x159d42),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x294020){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x294020));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1493ed){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x557abd=this['_getPasswordPolicyInternal']();return _0x557abd['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x557abd['validatePassword'](_0x1493ed);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x26e147=await Cf(this),_0x1d369b=new Sf(_0x26e147);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1d369b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1d369b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4cc15f){this['_errorFactory']=new Ut('auth','Firebase',_0x4cc15f());}['onAuthStateChanged'](_0x218244,_0x479fe2,_0x2a7537){return this['registerStateListener'](this['authStateSubscription'],_0x218244,_0x479fe2,_0x2a7537);}['beforeAuthStateChanged'](_0xbbe78c,_0x4a4aff){return this['beforeStateQueue']['pushCallback'](_0xbbe78c,_0x4a4aff);}['onIdTokenChanged'](_0x5e28a2,_0xe046a6,_0x30f5c7){return this['registerStateListener'](this['idTokenSubscription'],_0x5e28a2,_0xe046a6,_0x30f5c7);}['authStateReady'](){return new Promise((_0x603ccc,_0x45484b)=>{if(this['currentUser'])_0x603ccc();else{const _0x3308cf=this['onAuthStateChanged'](()=>{_0x3308cf(),_0x603ccc();},_0x45484b);}});}async['revokeAccessToken'](_0x2dcf4a){if(this['currentUser']){const _0x5cf31c=await this['currentUser']['getIdToken'](),_0x4ad79e={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2dcf4a,'idToken':_0x5cf31c};this['tenantId']!=null&&(_0x4ad79e['tenantId']=this['tenantId']),await vf(this,_0x4ad79e);}}['toJSON'](){var _0x5f19ce;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5f19ce=this['_currentUser'])==null?void 0x0:_0x5f19ce['toJSON']()};}async['_setRedirectUser'](_0x1402ae,_0x1b8854){const _0x115f29=await this['getOrInitRedirectPersistenceManager'](_0x1b8854);return _0x1402ae===null?_0x115f29['removeCurrentUser']():_0x115f29['setCurrentUser'](_0x1402ae);}async['getOrInitRedirectPersistenceManager'](_0x243cf){if(!this['redirectPersistenceManager']){const _0x3a6ba8=_0x243cf&&ne(_0x243cf)||this['_popupRedirectResolver'];m(_0x3a6ba8,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x3a6ba8['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x10d22d){var _0x123069,_0x5e6a9e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x123069=this['_currentUser'])==null?void 0x0:_0x123069['_redirectEventId'])===_0x10d22d?this['_currentUser']:((_0x5e6a9e=this['redirectUser'])==null?void 0x0:_0x5e6a9e['_redirectEventId'])===_0x10d22d?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3feb3f){if(_0x3feb3f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3feb3f));}['_notifyListenersIfCurrent'](_0x1859fd){_0x1859fd===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x6e7f0;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x223138=((_0x6e7f0=this['currentUser'])==null?void 0x0:_0x6e7f0['uid'])??null;this['lastNotifiedUid']!==_0x223138&&(this['lastNotifiedUid']=_0x223138,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x111b9a,_0x459b92,_0x3bf0e4,_0x4399e6){if(this['_deleted'])return()=>{};const _0x26427b=typeof _0x459b92=='function'?_0x459b92:_0x459b92['next']['bind'](_0x459b92);let _0x24387a=!0x1;const _0xd4b5cd=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xd4b5cd,this,'internal-error'),_0xd4b5cd['then'](()=>{_0x24387a||_0x26427b(this['currentUser']);}),typeof _0x459b92=='function'){const _0x5c61e9=_0x111b9a['addObserver'](_0x459b92,_0x3bf0e4,_0x4399e6);return()=>{_0x24387a=!0x0,_0x5c61e9();};}else{const _0x4aafc2=_0x111b9a['addObserver'](_0x459b92);return()=>{_0x24387a=!0x0,_0x4aafc2();};}}async['directlySetCurrentUser'](_0x1212db){this['currentUser']&&this['currentUser']!==_0x1212db&&this['_currentUser']['_stopProactiveRefresh'](),_0x1212db&&this['isProactiveRefreshEnabled']&&_0x1212db['_startProactiveRefresh'](),this['currentUser']=_0x1212db,_0x1212db?await this['assertedPersistence']['setCurrentUser'](_0x1212db):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x170ee8){return this['operations']=this['operations']['then'](_0x170ee8,_0x170ee8),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5499c7){!_0x5499c7||this['frameworks']['includes'](_0x5499c7)||(this['frameworks']['push'](_0x5499c7),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x45efb6;const _0x488c5a={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x488c5a['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3d537e=await((_0x45efb6=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x45efb6['getHeartbeatsHeader']());_0x3d537e&&(_0x488c5a['X-Firebase-Client']=_0x3d537e);const _0x41a7e3=await this['_getAppCheckToken']();return _0x41a7e3&&(_0x488c5a['X-Firebase-AppCheck']=_0x41a7e3),_0x488c5a;}async['_getAppCheckToken'](){var _0x47b924;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x25a872=await((_0x47b924=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x47b924['getToken']());return _0x25a872!=null&&_0x25a872['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x25a872['error']),_0x25a872==null?void 0x0:_0x25a872['token'];}}function qe(_0x55d928){return k(_0x55d928);}class Tr{constructor(_0x545b59){this['auth']=_0x545b59,this['observer']=null,this['addObserver']=Ic(_0x303655=>this['observer']=_0x303655);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x421d21){zn=_0x421d21;}function Da(_0x5617b5){return zn['loadJS'](_0x5617b5);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0x409387){return'__'+_0x409387+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x5a9fd0){_0x5a9fd0();}['execute'](_0x3ec5e3,_0x2afefa){return Promise['resolve']('token');}['render'](_0x41b617,_0x5a9016){return'';}}class Of{['ready'](_0xacd795){_0xacd795();}['execute'](_0x433504,_0x59f73b){return Promise['resolve']('token');}['render'](_0x480bc0,_0x4ba6cc){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x220825){this['type']=Df,this['auth']=qe(_0x220825);}async['verify'](_0xbbb67a='verify',_0x19b87b=!0x1){async function _0x480cb9(_0x35a4ac){if(!_0x19b87b){if(_0x35a4ac['tenantId']==null&&_0x35a4ac['_agentRecaptchaConfig']!=null)return _0x35a4ac['_agentRecaptchaConfig']['siteKey'];if(_0x35a4ac['tenantId']!=null&&_0x35a4ac['_tenantRecaptchaConfigs'][_0x35a4ac['tenantId']]!==void 0x0)return _0x35a4ac['_tenantRecaptchaConfigs'][_0x35a4ac['tenantId']]['siteKey'];}return new Promise(async(_0x110c3f,_0x42e873)=>{uf(_0x35a4ac,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x59d515=>{if(_0x59d515['recaptchaKey']===void 0x0)_0x42e873(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x9941ba=new hf(_0x59d515);return _0x35a4ac['tenantId']==null?_0x35a4ac['_agentRecaptchaConfig']=_0x9941ba:_0x35a4ac['_tenantRecaptchaConfigs'][_0x35a4ac['tenantId']]=_0x9941ba,_0x110c3f(_0x9941ba['siteKey']);}})['catch'](_0x1b4526=>{_0x42e873(_0x1b4526);});});}function _0x3d39d4(_0x4d86c6,_0x5cb5b2,_0x438898){const _0x35102=window['grecaptcha'];vr(_0x35102)?_0x35102['enterprise']['ready'](()=>{_0x35102['enterprise']['execute'](_0x4d86c6,{'action':_0xbbb67a})['then'](_0x17ca9d=>{_0x5cb5b2(_0x17ca9d);})['catch'](()=>{_0x5cb5b2(Ma);});}):_0x438898(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5ae92a,_0x4201c5)=>{_0x480cb9(this['auth'])['then'](async _0x5e7e03=>{if(!_0x19b87b&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3d39d4(_0x5e7e03,_0x5ae92a,_0x4201c5);else{if(typeof window>'u'){_0x4201c5(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x31a493=Af();_0x31a493['length']!==0x0&&(_0x31a493+=_0x5e7e03+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x70b9c2;(_0x70b9c2=le['scriptInjectionDeferred'])==null||_0x70b9c2['resolve']();},Da(_0x31a493)['then'](()=>{var _0x4d73b4;return(_0x4d73b4=le['scriptInjectionDeferred'])==null?void 0x0:_0x4d73b4['promise'];})['then'](()=>{_0x3d39d4(_0x5e7e03,_0x5ae92a,_0x4201c5);})['catch'](_0x2a51e3=>{_0x4201c5(_0x2a51e3);});}})['catch'](_0x282f59=>{_0x4201c5(_0x282f59);});});}}le['scriptInjectionDeferred']=null;async function br(_0x3399ad,_0x2504d7,_0x221d04,_0x3159d0=!0x1,_0x74f438=!0x1){const _0x2cea4c=new le(_0x3399ad);let _0x1c195b;if(_0x74f438)_0x1c195b=Ma;else try{_0x1c195b=await _0x2cea4c['verify'](_0x221d04);}catch{_0x1c195b=await _0x2cea4c['verify'](_0x221d04,!0x0);}const _0x3199f6={..._0x2504d7};if(_0x221d04==='mfaSmsEnrollment'||_0x221d04==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3199f6){const _0x42afbd=_0x3199f6['phoneEnrollmentInfo']['phoneNumber'],_0x5d8fe4=_0x3199f6['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3199f6,{'phoneEnrollmentInfo':{'phoneNumber':_0x42afbd,'recaptchaToken':_0x5d8fe4,'captchaResponse':_0x1c195b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3199f6){const _0xae5acd=_0x3199f6['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3199f6,{'phoneSignInInfo':{'recaptchaToken':_0xae5acd,'captchaResponse':_0x1c195b,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3199f6;}return _0x3159d0?Object['assign'](_0x3199f6,{'captchaResp':_0x1c195b}):Object['assign'](_0x3199f6,{'captchaResponse':_0x1c195b}),Object['assign'](_0x3199f6,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3199f6,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3199f6;}async function Oi(_0x3932b8,_0x3d0e48,_0x6d3fa5,_0x5937c8,_0x32df1e){var _0x9557e6;if((_0x9557e6=_0x3932b8['_getRecaptchaConfig']())!=null&&_0x9557e6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x367d8d=await br(_0x3932b8,_0x3d0e48,_0x6d3fa5,_0x6d3fa5==='getOobCode');return _0x5937c8(_0x3932b8,_0x367d8d);}else return _0x5937c8(_0x3932b8,_0x3d0e48)['catch'](async _0x57007a=>{if(_0x57007a['code']==='auth/missing-recaptcha-token'){console['log'](_0x6d3fa5+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3dfc2a=await br(_0x3932b8,_0x3d0e48,_0x6d3fa5,_0x6d3fa5==='getOobCode');return _0x5937c8(_0x3932b8,_0x3dfc2a);}else return Promise['reject'](_0x57007a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x379b84,_0x50726f){const _0x15f7c9=Ui(_0x379b84,'auth');if(_0x15f7c9['isInitialized']()){const _0x10421e=_0x15f7c9['getImmediate'](),_0x5644ee=_0x15f7c9['getOptions']();if(De(_0x5644ee,_0x50726f??{}))return _0x10421e;K(_0x10421e,'already-initialized');}return _0x15f7c9['initialize']({'options':_0x50726f});}function Lf(_0x28b773,_0x5be5be){const _0x36c613=(_0x5be5be==null?void 0x0:_0x5be5be['persistence'])||[],_0xd382a0=(Array['isArray'](_0x36c613)?_0x36c613:[_0x36c613])['map'](ne);_0x5be5be!=null&&_0x5be5be['errorMap']&&_0x28b773['_updateErrorMap'](_0x5be5be['errorMap']),_0x28b773['_initializeWithPersistence'](_0xd382a0,_0x5be5be==null?void 0x0:_0x5be5be['popupRedirectResolver']);}function xf(_0x17be96,_0x55d562,_0x11f207){const _0x4ea25b=qe(_0x17be96);m(/^https?:\/\//['test'](_0x55d562),_0x4ea25b,'invalid-emulator-scheme');const _0x2ebe9b=!0x1,_0x151e25=La(_0x55d562),{host:_0x59bfcf,port:_0x409603}=Ff(_0x55d562),_0x2bf844=_0x409603===null?'':':'+_0x409603,_0x53b17c={'url':_0x151e25+'//'+_0x59bfcf+_0x2bf844+'/'},_0x323767=Object['freeze']({'host':_0x59bfcf,'port':_0x409603,'protocol':_0x151e25['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2ebe9b})});if(!_0x4ea25b['_canInitEmulator']){m(_0x4ea25b['config']['emulator']&&_0x4ea25b['emulatorConfig'],_0x4ea25b,'emulator-config-failed'),m(De(_0x53b17c,_0x4ea25b['config']['emulator'])&&De(_0x323767,_0x4ea25b['emulatorConfig']),_0x4ea25b,'emulator-config-failed');return;}_0x4ea25b['config']['emulator']=_0x53b17c,_0x4ea25b['emulatorConfig']=_0x323767,_0x4ea25b['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x59bfcf)?jr(_0x151e25+'//'+_0x59bfcf+_0x2bf844):Uf();}function La(_0x53948c){const _0x288e81=_0x53948c['indexOf'](':');return _0x288e81<0x0?'':_0x53948c['substr'](0x0,_0x288e81+0x1);}function Ff(_0x4caa0d){const _0x3ce8d8=La(_0x4caa0d),_0x3ebe26=/(\/\/)?([^?#/]+)/['exec'](_0x4caa0d['substr'](_0x3ce8d8['length']));if(!_0x3ebe26)return{'host':'','port':null};const _0x3eee4a=_0x3ebe26[0x2]['split']('@')['pop']()||'',_0x31e032=/^(\[[^\]]+\])(:|$)/['exec'](_0x3eee4a);if(_0x31e032){const _0x125657=_0x31e032[0x1];return{'host':_0x125657,'port':Rr(_0x3eee4a['substr'](_0x125657['length']+0x1))};}else{const [_0x5adc0b,_0x44414f]=_0x3eee4a['split'](':');return{'host':_0x5adc0b,'port':Rr(_0x44414f)};}}function Rr(_0x1e04a9){if(!_0x1e04a9)return null;const _0x4ee567=Number(_0x1e04a9);return isNaN(_0x4ee567)?null:_0x4ee567;}function Uf(){function _0x546ea3(){const _0x1860f1=document['createElement']('p'),_0x4253fd=_0x1860f1['style'];_0x1860f1['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4253fd['position']='fixed',_0x4253fd['width']='100%',_0x4253fd['backgroundColor']='#ffffff',_0x4253fd['border']='.1em\x20solid\x20#000000',_0x4253fd['color']='#b50000',_0x4253fd['bottom']='0px',_0x4253fd['left']='0px',_0x4253fd['margin']='0px',_0x4253fd['zIndex']='10000',_0x4253fd['textAlign']='center',_0x1860f1['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x1860f1);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x546ea3):_0x546ea3());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2cf864,_0x35f8fc){this['providerId']=_0x2cf864,this['signInMethod']=_0x35f8fc;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x1f54e7){return te('not\x20implemented');}['_linkToIdToken'](_0x211d1a,_0x27e389){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x225865){return te('not\x20implemented');}}async function Wf(_0x11afc7,_0xdc9f2){return Ae(_0x11afc7,'POST','/v1/accounts:signUp',_0xdc9f2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x43bc85,_0xe2fc22){return Yt(_0x43bc85,'POST','/v1/accounts:signInWithPassword',Re(_0x43bc85,_0xe2fc22));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x4ca2e0,_0xc2882f){return Yt(_0x4ca2e0,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4ca2e0,_0xc2882f));}async function Hf(_0x2f2591,_0x308cf7){return Yt(_0x2f2591,'POST','/v1/accounts:signInWithEmailLink',Re(_0x2f2591,_0x308cf7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x1d3baa,_0x49a8c9,_0x50c747,_0x21fc77=null){super('password',_0x50c747),this['_email']=_0x1d3baa,this['_password']=_0x49a8c9,this['_tenantId']=_0x21fc77;}static['_fromEmailAndPassword'](_0x1fa55e,_0x2b3f75){return new Ft(_0x1fa55e,_0x2b3f75,'password');}static['_fromEmailAndCode'](_0x9723fa,_0x133011,_0x3919d7=null){return new Ft(_0x9723fa,_0x133011,'emailLink',_0x3919d7);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xd98b42){const _0x3570d8=typeof _0xd98b42=='string'?JSON['parse'](_0xd98b42):_0xd98b42;if(_0x3570d8!=null&&_0x3570d8['email']&&(_0x3570d8!=null&&_0x3570d8['password'])){if(_0x3570d8['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3570d8['email'],_0x3570d8['password']);if(_0x3570d8['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3570d8['email'],_0x3570d8['password'],_0x3570d8['tenantId']);}return null;}async['_getIdTokenResponse'](_0x27fac3){switch(this['signInMethod']){case'password':const _0x1a19bc={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x27fac3,_0x1a19bc,'signInWithPassword',Bf);case'emailLink':return Vf(_0x27fac3,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x27fac3,'internal-error');}}async['_linkToIdToken'](_0x2f18c7,_0x2042a7){switch(this['signInMethod']){case'password':const _0x301699={'idToken':_0x2042a7,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2f18c7,_0x301699,'signUpPassword',Wf);case'emailLink':return Hf(_0x2f18c7,{'idToken':_0x2042a7,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2f18c7,'internal-error');}}['_getReauthenticationResolver'](_0x1db0ac){return this['_getIdTokenResponse'](_0x1db0ac);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x52fbff,_0x41697){return Yt(_0x52fbff,'POST','/v1/accounts:signInWithIdp',Re(_0x52fbff,_0x41697));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3ec7a3){const _0x2a1f9a=new We(_0x3ec7a3['providerId'],_0x3ec7a3['signInMethod']);return _0x3ec7a3['idToken']||_0x3ec7a3['accessToken']?(_0x3ec7a3['idToken']&&(_0x2a1f9a['idToken']=_0x3ec7a3['idToken']),_0x3ec7a3['accessToken']&&(_0x2a1f9a['accessToken']=_0x3ec7a3['accessToken']),_0x3ec7a3['nonce']&&!_0x3ec7a3['pendingToken']&&(_0x2a1f9a['nonce']=_0x3ec7a3['nonce']),_0x3ec7a3['pendingToken']&&(_0x2a1f9a['pendingToken']=_0x3ec7a3['pendingToken'])):_0x3ec7a3['oauthToken']&&_0x3ec7a3['oauthTokenSecret']?(_0x2a1f9a['accessToken']=_0x3ec7a3['oauthToken'],_0x2a1f9a['secret']=_0x3ec7a3['oauthTokenSecret']):K('argument-error'),_0x2a1f9a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1e0b7a){const _0x4628aa=typeof _0x1e0b7a=='string'?JSON['parse'](_0x1e0b7a):_0x1e0b7a,{providerId:_0x5458f9,signInMethod:_0x7d43dc,..._0x1621ab}=_0x4628aa;if(!_0x5458f9||!_0x7d43dc)return null;const _0x3dccae=new We(_0x5458f9,_0x7d43dc);return _0x3dccae['idToken']=_0x1621ab['idToken']||void 0x0,_0x3dccae['accessToken']=_0x1621ab['accessToken']||void 0x0,_0x3dccae['secret']=_0x1621ab['secret'],_0x3dccae['nonce']=_0x1621ab['nonce'],_0x3dccae['pendingToken']=_0x1621ab['pendingToken']||null,_0x3dccae;}['_getIdTokenResponse'](_0xbabc82){const _0x31e3b7=this['buildRequest']();return Ze(_0xbabc82,_0x31e3b7);}['_linkToIdToken'](_0x5d2106,_0x25248b){const _0x328df0=this['buildRequest']();return _0x328df0['idToken']=_0x25248b,Ze(_0x5d2106,_0x328df0);}['_getReauthenticationResolver'](_0x5088c3){const _0x5c0dd5=this['buildRequest']();return _0x5c0dd5['autoCreate']=!0x1,Ze(_0x5088c3,_0x5c0dd5);}['buildRequest'](){const _0x486f82={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x486f82['pendingToken']=this['pendingToken'];else{const _0x1695e2={};this['idToken']&&(_0x1695e2['id_token']=this['idToken']),this['accessToken']&&(_0x1695e2['access_token']=this['accessToken']),this['secret']&&(_0x1695e2['oauth_token_secret']=this['secret']),_0x1695e2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1695e2['nonce']=this['nonce']),_0x486f82['postBody']=at(_0x1695e2);}return _0x486f82;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x1f5404){switch(_0x1f5404){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x430580){const _0x488bd2=yt(vt(_0x430580))['link'],_0x4a1c84=_0x488bd2?yt(vt(_0x488bd2))['deep_link_id']:null,_0x4d0f60=yt(vt(_0x430580))['deep_link_id'];return(_0x4d0f60?yt(vt(_0x4d0f60))['link']:null)||_0x4d0f60||_0x4a1c84||_0x488bd2||_0x430580;}class Ss{constructor(_0x293099){const _0x5d8c09=yt(vt(_0x293099)),_0x3a213e=_0x5d8c09['apiKey']??null,_0x4c4f63=_0x5d8c09['oobCode']??null,_0x397452=Gf(_0x5d8c09['mode']??null);m(_0x3a213e&&_0x4c4f63&&_0x397452,'argument-error'),this['apiKey']=_0x3a213e,this['operation']=_0x397452,this['code']=_0x4c4f63,this['continueUrl']=_0x5d8c09['continueUrl']??null,this['languageCode']=_0x5d8c09['lang']??null,this['tenantId']=_0x5d8c09['tenantId']??null;}static['parseLink'](_0x12c0de){const _0x6a641=qf(_0x12c0de);try{return new Ss(_0x6a641);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x37b768,_0x227909){return Ft['_fromEmailAndPassword'](_0x37b768,_0x227909);}static['credentialWithLink'](_0x34482d,_0x1e3ae3){const _0x3b528b=Ss['parseLink'](_0x1e3ae3);return m(_0x3b528b,'argument-error'),Ft['_fromEmailAndCode'](_0x34482d,_0x3b528b['code'],_0x3b528b['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x58d448){this['providerId']=_0x58d448,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3dbfd9){this['defaultLanguageCode']=_0x3dbfd9;}['setCustomParameters'](_0x240f5d){return this['customParameters']=_0x240f5d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x46c78b){return this['scopes']['includes'](_0x46c78b)||this['scopes']['push'](_0x46c78b),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x4a0a07){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4a0a07});}static['credentialFromResult'](_0x10918d){return he['credentialFromTaggedObject'](_0x10918d);}static['credentialFromError'](_0x445713){return he['credentialFromTaggedObject'](_0x445713['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59a633}){if(!_0x59a633||!('oauthAccessToken'in _0x59a633)||!_0x59a633['oauthAccessToken'])return null;try{return he['credential'](_0x59a633['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x409a31,_0x3cdcde){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x409a31,'accessToken':_0x3cdcde});}static['credentialFromResult'](_0x496c1d){return ue['credentialFromTaggedObject'](_0x496c1d);}static['credentialFromError'](_0x9d57a4){return ue['credentialFromTaggedObject'](_0x9d57a4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2d52e1}){if(!_0x2d52e1)return null;const {oauthIdToken:_0x5526c2,oauthAccessToken:_0x34d50d}=_0x2d52e1;if(!_0x5526c2&&!_0x34d50d)return null;try{return ue['credential'](_0x5526c2,_0x34d50d);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x180a6e){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x180a6e});}static['credentialFromResult'](_0x56cb05){return de['credentialFromTaggedObject'](_0x56cb05);}static['credentialFromError'](_0x17c821){return de['credentialFromTaggedObject'](_0x17c821['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x35ff1a}){if(!_0x35ff1a||!('oauthAccessToken'in _0x35ff1a)||!_0x35ff1a['oauthAccessToken'])return null;try{return de['credential'](_0x35ff1a['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x332bd4,_0x572437){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x332bd4,'oauthTokenSecret':_0x572437});}static['credentialFromResult'](_0x4970a4){return fe['credentialFromTaggedObject'](_0x4970a4);}static['credentialFromError'](_0x54a55c){return fe['credentialFromTaggedObject'](_0x54a55c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xdff3ce}){if(!_0xdff3ce)return null;const {oauthAccessToken:_0x257945,oauthTokenSecret:_0x19c9db}=_0xdff3ce;if(!_0x257945||!_0x19c9db)return null;try{return fe['credential'](_0x257945,_0x19c9db);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x3a0a0d,_0x2ce8f1){return Yt(_0x3a0a0d,'POST','/v1/accounts:signUp',Re(_0x3a0a0d,_0x2ce8f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x515ce0){this['user']=_0x515ce0['user'],this['providerId']=_0x515ce0['providerId'],this['_tokenResponse']=_0x515ce0['_tokenResponse'],this['operationType']=_0x515ce0['operationType'];}static async['_fromIdTokenResponse'](_0x20eca0,_0x39e0c2,_0x15d26c,_0x39fd33=!0x1){const _0x587fff=await z['_fromIdTokenResponse'](_0x20eca0,_0x15d26c,_0x39fd33),_0x2262db=Ar(_0x15d26c);return new Be({'user':_0x587fff,'providerId':_0x2262db,'_tokenResponse':_0x15d26c,'operationType':_0x39e0c2});}static async['_forOperation'](_0x5dc690,_0x1ed001,_0x2b18c1){await _0x5dc690['_updateTokensIfNecessary'](_0x2b18c1,!0x0);const _0x214181=Ar(_0x2b18c1);return new Be({'user':_0x5dc690,'providerId':_0x214181,'_tokenResponse':_0x2b18c1,'operationType':_0x1ed001});}}function Ar(_0x4647c8){return _0x4647c8['providerId']?_0x4647c8['providerId']:'phoneNumber'in _0x4647c8?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x5db1bf,_0x3f96a4,_0x1d871e,_0x18ac64){super(_0x3f96a4['code'],_0x3f96a4['message']),this['operationType']=_0x1d871e,this['user']=_0x18ac64,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x5db1bf['name'],'tenantId':_0x5db1bf['tenantId']??void 0x0,'_serverResponse':_0x3f96a4['customData']['_serverResponse'],'operationType':_0x1d871e};}static['_fromErrorAndOperation'](_0x16ce0f,_0x5e7f95,_0x45566d,_0xd59ee9){return new Rn(_0x16ce0f,_0x5e7f95,_0x45566d,_0xd59ee9);}}function Fa(_0x1ab7f6,_0xf416ac,_0x7f54b7,_0x211166){return(_0xf416ac==='reauthenticate'?_0x7f54b7['_getReauthenticationResolver'](_0x1ab7f6):_0x7f54b7['_getIdTokenResponse'](_0x1ab7f6))['catch'](_0x2a8c6b=>{throw _0x2a8c6b['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x1ab7f6,_0x2a8c6b,_0xf416ac,_0x211166):_0x2a8c6b;});}async function jf(_0x317d12,_0x42793c,_0x3c5be1=!0x1){const _0x3ecfee=await xt(_0x317d12,_0x42793c['_linkToIdToken'](_0x317d12['auth'],await _0x317d12['getIdToken']()),_0x3c5be1);return Be['_forOperation'](_0x317d12,'link',_0x3ecfee);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x301326,_0x5b2e12,_0x11bd9a=!0x1){const {auth:_0x5e3fad}=_0x301326;if(H(_0x5e3fad['app']))return Promise['reject'](se(_0x5e3fad));const _0x58e520='reauthenticate';try{const _0x3c3573=await xt(_0x301326,Fa(_0x5e3fad,_0x58e520,_0x5b2e12,_0x301326),_0x11bd9a);m(_0x3c3573['idToken'],_0x5e3fad,'internal-error');const _0x5ee3a1=ws(_0x3c3573['idToken']);m(_0x5ee3a1,_0x5e3fad,'internal-error');const {sub:_0x17c8c0}=_0x5ee3a1;return m(_0x301326['uid']===_0x17c8c0,_0x5e3fad,'user-mismatch'),Be['_forOperation'](_0x301326,_0x58e520,_0x3c3573);}catch(_0x1c5bdb){throw(_0x1c5bdb==null?void 0x0:_0x1c5bdb['code'])==='auth/user-not-found'&&K(_0x5e3fad,'user-mismatch'),_0x1c5bdb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x4b5d3f,_0x31e79b,_0x53504a=!0x1){if(H(_0x4b5d3f['app']))return Promise['reject'](se(_0x4b5d3f));const _0x406f4e='signIn',_0x4d95b5=await Fa(_0x4b5d3f,_0x406f4e,_0x31e79b),_0xea291a=await Be['_fromIdTokenResponse'](_0x4b5d3f,_0x406f4e,_0x4d95b5);return _0x53504a||await _0x4b5d3f['_updateCurrentUser'](_0xea291a['user']),_0xea291a;}async function Yf(_0x19c721,_0x15772f){return Ua(qe(_0x19c721),_0x15772f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x11c694){const _0x1a9945=qe(_0x11c694);_0x1a9945['_getPasswordPolicyInternal']()&&await _0x1a9945['_updatePasswordPolicy']();}async function R_(_0x567369,_0x42698c,_0x38f281){if(H(_0x567369['app']))return Promise['reject'](se(_0x567369));const _0x3ba5d2=qe(_0x567369),_0x32dc9f=await Oi(_0x3ba5d2,{'returnSecureToken':!0x0,'email':_0x42698c,'password':_0x38f281,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x56c296=>{throw _0x56c296['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x567369),_0x56c296;}),_0x29c43d=await Be['_fromIdTokenResponse'](_0x3ba5d2,'signIn',_0x32dc9f);return await _0x3ba5d2['_updateCurrentUser'](_0x29c43d['user']),_0x29c43d;}function A_(_0x579a74,_0x249e34,_0x52256e){return H(_0x579a74['app'])?Promise['reject'](se(_0x579a74)):Yf(k(_0x579a74),ft['credential'](_0x249e34,_0x52256e))['catch'](async _0x32b657=>{throw _0x32b657['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x579a74),_0x32b657;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x53ef26,_0xba7400){return k(_0x53ef26)['setPersistence'](_0xba7400);}function Qf(_0x546e18,_0x4d4d82,_0x36d483,_0x17e2c6){return k(_0x546e18)['onIdTokenChanged'](_0x4d4d82,_0x36d483,_0x17e2c6);}function Jf(_0x973f14,_0x1edc3d,_0x3dbc40){return k(_0x973f14)['beforeAuthStateChanged'](_0x1edc3d,_0x3dbc40);}function N_(_0x479c69,_0xd78dcb,_0x763d07,_0x3e710e){return k(_0x479c69)['onAuthStateChanged'](_0xd78dcb,_0x763d07,_0x3e710e);}function P_(_0x47c964){return k(_0x47c964)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x5567af,_0x19d768){this['storageRetriever']=_0x5567af,this['type']=_0x19d768;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1b13c6,_0x546d8b){return this['storage']['setItem'](_0x1b13c6,JSON['stringify'](_0x546d8b)),Promise['resolve']();}['_get'](_0x9fe754){const _0x3461f2=this['storage']['getItem'](_0x9fe754);return Promise['resolve'](_0x3461f2?JSON['parse'](_0x3461f2):null);}['_remove'](_0xea3639){return this['storage']['removeItem'](_0xea3639),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x28ace7,_0xb4af)=>this['onStorageEvent'](_0x28ace7,_0xb4af),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x25ae4c){for(const _0x4f8239 of Object['keys'](this['listeners'])){const _0x201b46=this['storage']['getItem'](_0x4f8239),_0x4d27ad=this['localCache'][_0x4f8239];_0x201b46!==_0x4d27ad&&_0x25ae4c(_0x4f8239,_0x4d27ad,_0x201b46);}}['onStorageEvent'](_0x593b6b,_0x1fbd77=!0x1){if(!_0x593b6b['key']){this['forAllChangedKeys']((_0x56443a,_0x2b5dd9,_0x75fa3a)=>{this['notifyListeners'](_0x56443a,_0x75fa3a);});return;}const _0xcd5d5b=_0x593b6b['key'];_0x1fbd77?this['detachListener']():this['stopPolling']();const _0x124a06=()=>{const _0x2202b7=this['storage']['getItem'](_0xcd5d5b);!_0x1fbd77&&this['localCache'][_0xcd5d5b]===_0x2202b7||this['notifyListeners'](_0xcd5d5b,_0x2202b7);},_0x867018=this['storage']['getItem'](_0xcd5d5b);If()&&_0x867018!==_0x593b6b['newValue']&&_0x593b6b['newValue']!==_0x593b6b['oldValue']?setTimeout(_0x124a06,Zf):_0x124a06();}['notifyListeners'](_0x5a0045,_0x2cb1ed){this['localCache'][_0x5a0045]=_0x2cb1ed;const _0x3bf3df=this['listeners'][_0x5a0045];if(_0x3bf3df){for(const _0x2dc22a of Array['from'](_0x3bf3df))_0x2dc22a(_0x2cb1ed&&JSON['parse'](_0x2cb1ed));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5bf55a,_0x39e379,_0x407e13)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5bf55a,'oldValue':_0x39e379,'newValue':_0x407e13}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4b3891,_0x351668){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4b3891]||(this['listeners'][_0x4b3891]=new Set(),this['localCache'][_0x4b3891]=this['storage']['getItem'](_0x4b3891)),this['listeners'][_0x4b3891]['add'](_0x351668);}['_removeListener'](_0x229f12,_0x51eff1){this['listeners'][_0x229f12]&&(this['listeners'][_0x229f12]['delete'](_0x51eff1),this['listeners'][_0x229f12]['size']===0x0&&delete this['listeners'][_0x229f12]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2c1adb,_0xdd1f46){await super['_set'](_0x2c1adb,_0xdd1f46),this['localCache'][_0x2c1adb]=JSON['stringify'](_0xdd1f46);}async['_get'](_0x5f5bad){const _0x22e543=await super['_get'](_0x5f5bad);return this['localCache'][_0x5f5bad]=JSON['stringify'](_0x22e543),_0x22e543;}async['_remove'](_0x525c27){await super['_remove'](_0x525c27),delete this['localCache'][_0x525c27];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xfb4da2,_0x2dbe43){}['_removeListener'](_0x514927,_0x1aeb74){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x309cc2){return Promise['all'](_0x309cc2['map'](async _0x31a891=>{try{return{'fulfilled':!0x0,'value':await _0x31a891};}catch(_0x2f6d47){return{'fulfilled':!0x1,'reason':_0x2f6d47};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x461911){this['eventTarget']=_0x461911,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x175daf){const _0xd08842=this['receivers']['find'](_0x8f902e=>_0x8f902e['isListeningto'](_0x175daf));if(_0xd08842)return _0xd08842;const _0x574753=new jn(_0x175daf);return this['receivers']['push'](_0x574753),_0x574753;}['isListeningto'](_0x540581){return this['eventTarget']===_0x540581;}async['handleEvent'](_0x446209){const _0x1cb10f=_0x446209,{eventId:_0x460397,eventType:_0x386572,data:_0x238328}=_0x1cb10f['data'],_0x1f9cdb=this['handlersMap'][_0x386572];if(!(_0x1f9cdb!=null&&_0x1f9cdb['size']))return;_0x1cb10f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x460397,'eventType':_0x386572});const _0x5ba4f0=Array['from'](_0x1f9cdb)['map'](async _0x451106=>_0x451106(_0x1cb10f['origin'],_0x238328)),_0x36bcf7=await tp(_0x5ba4f0);_0x1cb10f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x460397,'eventType':_0x386572,'response':_0x36bcf7});}['_subscribe'](_0x54c596,_0x52acdc){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x54c596]||(this['handlersMap'][_0x54c596]=new Set()),this['handlersMap'][_0x54c596]['add'](_0x52acdc);}['_unsubscribe'](_0x452aab,_0x1abe96){this['handlersMap'][_0x452aab]&&_0x1abe96&&this['handlersMap'][_0x452aab]['delete'](_0x1abe96),(!_0x1abe96||this['handlersMap'][_0x452aab]['size']===0x0)&&delete this['handlersMap'][_0x452aab],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x5d8db7='',_0x5a23b1=0xa){let _0x215b19='';for(let _0x59cef6=0x0;_0x59cef6<_0x5a23b1;_0x59cef6++)_0x215b19+=Math['floor'](Math['random']()*0xa);return _0x5d8db7+_0x215b19;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x491af6){this['target']=_0x491af6,this['handlers']=new Set();}['removeMessageHandler'](_0x3dc33b){_0x3dc33b['messageChannel']&&(_0x3dc33b['messageChannel']['port1']['removeEventListener']('message',_0x3dc33b['onMessage']),_0x3dc33b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3dc33b);}async['_send'](_0x4325a3,_0x5e2ac1,_0x12fd1c=0x32){const _0x53b783=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x53b783)throw new Error('connection_unavailable');let _0x5a6310,_0x5cd4c1;return new Promise((_0x41bd8c,_0xe6670c)=>{const _0x229761=bs('',0x14);_0x53b783['port1']['start']();const _0x1ceb56=setTimeout(()=>{_0xe6670c(new Error('unsupported_event'));},_0x12fd1c);_0x5cd4c1={'messageChannel':_0x53b783,'onMessage'(_0x12f622){const _0x2e8449=_0x12f622;if(_0x2e8449['data']['eventId']===_0x229761)switch(_0x2e8449['data']['status']){case'ack':clearTimeout(_0x1ceb56),_0x5a6310=setTimeout(()=>{_0xe6670c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5a6310),_0x41bd8c(_0x2e8449['data']['response']);break;default:clearTimeout(_0x1ceb56),clearTimeout(_0x5a6310),_0xe6670c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x5cd4c1),_0x53b783['port1']['addEventListener']('message',_0x5cd4c1['onMessage']),this['target']['postMessage']({'eventType':_0x4325a3,'eventId':_0x229761,'data':_0x5e2ac1},[_0x53b783['port2']]);})['finally'](()=>{_0x5cd4c1&&this['removeMessageHandler'](_0x5cd4c1);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0x315753){X()['location']['href']=_0x315753;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0x5e3bb9;return((_0x5e3bb9=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5e3bb9['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x48be50){this['request']=_0x48be50;}['toPromise'](){return new Promise((_0x22fa7e,_0x199b4f)=>{this['request']['addEventListener']('success',()=>{_0x22fa7e(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x199b4f(this['request']['error']);});});}}function Kn(_0x16fceb,_0x3551be){return _0x16fceb['transaction']([kn],_0x3551be?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x1a9a62=indexedDB['deleteDatabase'](qa);return new Jt(_0x1a9a62)['toPromise']();}function ja(){const _0x1a2015=indexedDB['open'](qa,ap);return new Promise((_0x1262b6,_0x12c739)=>{_0x1a2015['addEventListener']('error',()=>{_0x12c739(_0x1a2015['error']);}),_0x1a2015['addEventListener']('upgradeneeded',()=>{const _0x429879=_0x1a2015['result'];try{_0x429879['createObjectStore'](kn,{'keyPath':za});}catch(_0x583434){_0x12c739(_0x583434);}}),_0x1a2015['addEventListener']('success',async()=>{const _0x246a52=_0x1a2015['result'];_0x246a52['objectStoreNames']['contains'](kn)?_0x1262b6(_0x246a52):(_0x246a52['close'](),await cp(),_0x1262b6(await ja()));});});}async function kr(_0x236883,_0x325e22,_0x27b79d){const _0x22c83=Kn(_0x236883,!0x0)['put']({[za]:_0x325e22,'value':_0x27b79d});return new Jt(_0x22c83)['toPromise']();}async function lp(_0x5d583e,_0x2a26f0){const _0x5da032=Kn(_0x5d583e,!0x1)['get'](_0x2a26f0),_0x2863e5=await new Jt(_0x5da032)['toPromise']();return _0x2863e5===void 0x0?null:_0x2863e5['value'];}function Nr(_0x2a838b,_0x2cdc07){const _0x523fc8=Kn(_0x2a838b,!0x0)['delete'](_0x2cdc07);return new Jt(_0x523fc8)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x4be781){let _0x42475e=0x0;for(;;)try{const _0x1a1534=await this['_openDb']();return await _0x4be781(_0x1a1534);}catch(_0x1ab341){if(_0x42475e++>up)throw _0x1ab341;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x39923a,_0x2f3302)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2f3302['key'])})),this['receiver']['_subscribe']('ping',async(_0x523f0c,_0x1f90b9)=>['keyChanged']);}async['initializeSender'](){var _0x2dc363,_0x3a9070;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x238d3c=await this['sender']['_send']('ping',{},0x320);_0x238d3c&&(_0x2dc363=_0x238d3c[0x0])!=null&&_0x2dc363['fulfilled']&&(_0x3a9070=_0x238d3c[0x0])!=null&&_0x3a9070['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2663f5){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2663f5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x46f8c1=>{await kr(_0x46f8c1,An,'1'),await Nr(_0x46f8c1,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4fa2b9){this['pendingWrites']++;try{await _0x4fa2b9();}finally{this['pendingWrites']--;}}async['_set'](_0x127458,_0x472d7e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2e7b6f=>kr(_0x2e7b6f,_0x127458,_0x472d7e)),this['localCache'][_0x127458]=_0x472d7e,this['notifyServiceWorker'](_0x127458)));}async['_get'](_0x506e4d){const _0xb91fd6=await this['_withRetries'](_0x420bef=>lp(_0x420bef,_0x506e4d));return this['localCache'][_0x506e4d]=_0xb91fd6,_0xb91fd6;}async['_remove'](_0x253b06){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4f49e9=>Nr(_0x4f49e9,_0x253b06)),delete this['localCache'][_0x253b06],this['notifyServiceWorker'](_0x253b06)));}async['_poll'](){const _0x5a706c=await this['_withRetries'](_0x51e071=>{const _0x2f8981=Kn(_0x51e071,!0x1)['getAll']();return new Jt(_0x2f8981)['toPromise']();});if(!_0x5a706c)return[];if(this['pendingWrites']!==0x0)return[];const _0x45d2af=[],_0x2559c5=new Set();if(_0x5a706c['length']!==0x0){for(const {fbase_key:_0x4e74f6,value:_0x4b33fd}of _0x5a706c)_0x2559c5['add'](_0x4e74f6),JSON['stringify'](this['localCache'][_0x4e74f6])!==JSON['stringify'](_0x4b33fd)&&(this['notifyListeners'](_0x4e74f6,_0x4b33fd),_0x45d2af['push'](_0x4e74f6));}for(const _0x2a15f7 of Object['keys'](this['localCache']))this['localCache'][_0x2a15f7]&&!_0x2559c5['has'](_0x2a15f7)&&(this['notifyListeners'](_0x2a15f7,null),_0x45d2af['push'](_0x2a15f7));return _0x45d2af;}['notifyListeners'](_0x3a108c,_0x1c8772){this['localCache'][_0x3a108c]=_0x1c8772;const _0x1de3c6=this['listeners'][_0x3a108c];if(_0x1de3c6){for(const _0x4ac6a9 of Array['from'](_0x1de3c6))_0x4ac6a9(_0x1c8772);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x270e09,_0x2bc0f7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x270e09]||(this['listeners'][_0x270e09]=new Set(),this['_get'](_0x270e09)),this['listeners'][_0x270e09]['add'](_0x2bc0f7);}['_removeListener'](_0x2508f0,_0x260ab8){this['listeners'][_0x2508f0]&&(this['listeners'][_0x2508f0]['delete'](_0x260ab8),this['listeners'][_0x2508f0]['size']===0x0&&delete this['listeners'][_0x2508f0]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x43a732,_0x267b57){return _0x267b57?ne(_0x267b57):(m(_0x43a732['_popupRedirectResolver'],_0x43a732,'argument-error'),_0x43a732['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x274c4c){super('custom','custom'),this['params']=_0x274c4c;}['_getIdTokenResponse'](_0x3193a3){return Ze(_0x3193a3,this['_buildIdpRequest']());}['_linkToIdToken'](_0x14161c,_0x5a9cd6){return Ze(_0x14161c,this['_buildIdpRequest'](_0x5a9cd6));}['_getReauthenticationResolver'](_0x43a6fc){return Ze(_0x43a6fc,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x30954b){const _0x34c7d8={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x30954b&&(_0x34c7d8['idToken']=_0x30954b),_0x34c7d8;}}function pp(_0x6aa1bd){return Ua(_0x6aa1bd['auth'],new Rs(_0x6aa1bd),_0x6aa1bd['bypassAuthState']);}function _p(_0x4f2a95){const {auth:_0x1097d8,user:_0x11ba3f}=_0x4f2a95;return m(_0x11ba3f,_0x1097d8,'internal-error'),Kf(_0x11ba3f,new Rs(_0x4f2a95),_0x4f2a95['bypassAuthState']);}async function gp(_0x3d0501){const {auth:_0x13ed2a,user:_0xfdb98a}=_0x3d0501;return m(_0xfdb98a,_0x13ed2a,'internal-error'),jf(_0xfdb98a,new Rs(_0x3d0501),_0x3d0501['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x1728e4,_0x5056dc,_0x3e0e53,_0x2fd672,_0x3d1240=!0x1){this['auth']=_0x1728e4,this['resolver']=_0x3e0e53,this['user']=_0x2fd672,this['bypassAuthState']=_0x3d1240,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5056dc)?_0x5056dc:[_0x5056dc];}['execute'](){return new Promise(async(_0x408cbe,_0x1a898f)=>{this['pendingPromise']={'resolve':_0x408cbe,'reject':_0x1a898f};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5bb026){this['reject'](_0x5bb026);}});}async['onAuthEvent'](_0x3826da){const {urlResponse:_0xeee6d2,sessionId:_0x49e32b,postBody:_0x19308d,tenantId:_0x503980,error:_0x582d16,type:_0x37b982}=_0x3826da;if(_0x582d16){this['reject'](_0x582d16);return;}const _0x2bde1a={'auth':this['auth'],'requestUri':_0xeee6d2,'sessionId':_0x49e32b,'tenantId':_0x503980||void 0x0,'postBody':_0x19308d||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x37b982)(_0x2bde1a));}catch(_0x1fc12b){this['reject'](_0x1fc12b);}}['onError'](_0x22987f){this['reject'](_0x22987f);}['getIdpTask'](_0x589eb6){switch(_0x589eb6){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x558204){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x558204),this['unregisterAndCleanUp']();}['reject'](_0x5c4945){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5c4945),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x381ca7,_0x44ebfe,_0x2f026a,_0x3c46aa,_0x108fac){super(_0x381ca7,_0x44ebfe,_0x3c46aa,_0x108fac),this['provider']=_0x2f026a,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x24df36=await this['execute']();return m(_0x24df36,this['auth'],'internal-error'),_0x24df36;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x527659=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x527659),this['authWindow']['associatedEvent']=_0x527659,this['resolver']['_originValidation'](this['auth'])['catch'](_0x2c1b40=>{this['reject'](_0x2c1b40);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0xfded4=>{_0xfded4||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1ea328;return((_0x1ea328=this['authWindow'])==null?void 0x0:_0x1ea328['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x31fe27=()=>{var _0x5f2177,_0x31e025;if((_0x31e025=(_0x5f2177=this['authWindow'])==null?void 0x0:_0x5f2177['window'])!=null&&_0x31e025['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x31fe27,mp['get']());};_0x31fe27();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x55bcf5,_0x408942,_0x9cd51d=!0x1){super(_0x55bcf5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x408942,void 0x0,_0x9cd51d),this['eventId']=null;}async['execute'](){let _0x55ba24=rn['get'](this['auth']['_key']());if(!_0x55ba24){try{const _0x57bf63=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x55ba24=()=>Promise['resolve'](_0x57bf63);}catch(_0x13c272){_0x55ba24=()=>Promise['reject'](_0x13c272);}rn['set'](this['auth']['_key'](),_0x55ba24);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x55ba24();}async['onAuthEvent'](_0x136600){if(_0x136600['type']==='signInViaRedirect')return super['onAuthEvent'](_0x136600);if(_0x136600['type']==='unknown'){this['resolve'](null);return;}if(_0x136600['eventId']){const _0x41cb94=await this['auth']['_redirectUserForId'](_0x136600['eventId']);if(_0x41cb94)return this['user']=_0x41cb94,super['onAuthEvent'](_0x136600);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0x2f56be,_0x3794fb){const _0x269668=Cp(_0x3794fb),_0xe78a19=wp(_0x2f56be);if(!await _0xe78a19['_isAvailable']())return!0x1;const _0x24e69b=await _0xe78a19['_get'](_0x269668)==='true';return await _0xe78a19['_remove'](_0x269668),_0x24e69b;}function Ip(_0x507bef,_0x9cf655){rn['set'](_0x507bef['_key'](),_0x9cf655);}function wp(_0x438d29){return ne(_0x438d29['_redirectPersistence']);}function Cp(_0x26ecbf){return sn(yp,_0x26ecbf['config']['apiKey'],_0x26ecbf['name']);}async function Tp(_0x4a1ee7,_0x4d0fac,_0x1514b5=!0x1){if(H(_0x4a1ee7['app']))return Promise['reject'](se(_0x4a1ee7));const _0x47a2c3=qe(_0x4a1ee7),_0x3521ad=fp(_0x47a2c3,_0x4d0fac),_0x2db688=await new vp(_0x47a2c3,_0x3521ad,_0x1514b5)['execute']();return _0x2db688&&!_0x1514b5&&(delete _0x2db688['user']['_redirectEventId'],await _0x47a2c3['_persistUserIfCurrent'](_0x2db688['user']),await _0x47a2c3['_setRedirectUser'](null,_0x4d0fac)),_0x2db688;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x2f8b18){this['auth']=_0x2f8b18,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x26b67a){this['consumers']['add'](_0x26b67a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x26b67a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x26b67a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x30c5f5){this['consumers']['delete'](_0x30c5f5);}['onEvent'](_0x3df4d2){if(this['hasEventBeenHandled'](_0x3df4d2))return!0x1;let _0x462144=!0x1;return this['consumers']['forEach'](_0x45c4b6=>{this['isEventForConsumer'](_0x3df4d2,_0x45c4b6)&&(_0x462144=!0x0,this['sendToConsumer'](_0x3df4d2,_0x45c4b6),this['saveEventToCache'](_0x3df4d2));}),this['hasHandledPotentialRedirect']||!Rp(_0x3df4d2)||(this['hasHandledPotentialRedirect']=!0x0,_0x462144||(this['queuedRedirectEvent']=_0x3df4d2,_0x462144=!0x0)),_0x462144;}['sendToConsumer'](_0x4c18b2,_0x3f610d){var _0x376795;if(_0x4c18b2['error']&&!Qa(_0x4c18b2)){const _0x355010=((_0x376795=_0x4c18b2['error']['code'])==null?void 0x0:_0x376795['split']('auth/')[0x1])||'internal-error';_0x3f610d['onError'](J(this['auth'],_0x355010));}else _0x3f610d['onAuthEvent'](_0x4c18b2);}['isEventForConsumer'](_0x5f03d1,_0x119955){const _0xd0af73=_0x119955['eventId']===null||!!_0x5f03d1['eventId']&&_0x5f03d1['eventId']===_0x119955['eventId'];return _0x119955['filter']['includes'](_0x5f03d1['type'])&&_0xd0af73;}['hasEventBeenHandled'](_0x2f478f){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2f478f));}['saveEventToCache'](_0x56bfce){this['cachedEventUids']['add'](Pr(_0x56bfce)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x2f945b){return[_0x2f945b['type'],_0x2f945b['eventId'],_0x2f945b['sessionId'],_0x2f945b['tenantId']]['filter'](_0x34a6cf=>_0x34a6cf)['join']('-');}function Qa({type:_0x408135,error:_0x1a8f71}){return _0x408135==='unknown'&&(_0x1a8f71==null?void 0x0:_0x1a8f71['code'])==='auth/no-auth-event';}function Rp(_0x7678e){switch(_0x7678e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x7678e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x58d07b,_0x5ccb4a={}){return Ae(_0x58d07b,'GET','/v1/projects',_0x5ccb4a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x50683f){if(_0x50683f['config']['emulator'])return;const {authorizedDomains:_0x3174ab}=await Ap(_0x50683f);for(const _0x5e06fd of _0x3174ab)try{if(Op(_0x5e06fd))return;}catch{}K(_0x50683f,'unauthorized-domain');}function Op(_0x51d4ee){const _0x5d14b8=Ni(),{protocol:_0x1907d3,hostname:_0x5933e1}=new URL(_0x5d14b8);if(_0x51d4ee['startsWith']('chrome-extension://')){const _0x25cff4=new URL(_0x51d4ee);return _0x25cff4['hostname']===''&&_0x5933e1===''?_0x1907d3==='chrome-extension:'&&_0x51d4ee['replace']('chrome-extension://','')===_0x5d14b8['replace']('chrome-extension://',''):_0x1907d3==='chrome-extension:'&&_0x25cff4['hostname']===_0x5933e1;}if(!Np['test'](_0x1907d3))return!0x1;if(kp['test'](_0x51d4ee))return _0x5933e1===_0x51d4ee;const _0x7d3947=_0x51d4ee['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x7d3947+'|'+_0x7d3947+')$','i')['test'](_0x5933e1);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x976b72=X()['___jsl'];if(_0x976b72!=null&&_0x976b72['H']){for(const _0x4246cd of Object['keys'](_0x976b72['H']))if(_0x976b72['H'][_0x4246cd]['r']=_0x976b72['H'][_0x4246cd]['r']||[],_0x976b72['H'][_0x4246cd]['L']=_0x976b72['H'][_0x4246cd]['L']||[],_0x976b72['H'][_0x4246cd]['r']=[..._0x976b72['H'][_0x4246cd]['L']],_0x976b72['CP']){for(let _0x120232=0x0;_0x120232<_0x976b72['CP']['length'];_0x120232++)_0x976b72['CP'][_0x120232]=null;}}}function Mp(_0x1075cf){return new Promise((_0x3f9918,_0x17fdec)=>{var _0x3a942f,_0x40229a,_0x56a746;function _0x2ec70a(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3f9918(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x17fdec(J(_0x1075cf,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x40229a=(_0x3a942f=X()['gapi'])==null?void 0x0:_0x3a942f['iframes'])!=null&&_0x40229a['Iframe'])_0x3f9918(gapi['iframes']['getContext']());else{if((_0x56a746=X()['gapi'])!=null&&_0x56a746['load'])_0x2ec70a();else{const _0x9822d4=Nf('iframefcb');return X()[_0x9822d4]=()=>{gapi['load']?_0x2ec70a():_0x17fdec(J(_0x1075cf,'network-request-failed'));},Da(kf()+'?onload='+_0x9822d4)['catch'](_0x16b390=>_0x17fdec(_0x16b390));}}})['catch'](_0xf436e=>{throw on=null,_0xf436e;});}let on=null;function Lp(_0x147b9c){return on=on||Mp(_0x147b9c),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x10ca95){const _0x343ba8=_0x10ca95['config'];m(_0x343ba8['authDomain'],_0x10ca95,'auth-domain-config-required');const _0x5a7ed3=_0x343ba8['emulator']?Is(_0x343ba8,Up):'https://'+_0x10ca95['config']['authDomain']+'/'+Fp,_0x6b927f={'apiKey':_0x343ba8['apiKey'],'appName':_0x10ca95['name'],'v':ct},_0x3a02bd=Bp['get'](_0x10ca95['config']['apiHost']);_0x3a02bd&&(_0x6b927f['eid']=_0x3a02bd);const _0x47bf0e=_0x10ca95['_getFrameworks']();return _0x47bf0e['length']&&(_0x6b927f['fw']=_0x47bf0e['join'](',')),_0x5a7ed3+'?'+at(_0x6b927f)['slice'](0x1);}async function Hp(_0xd48aa3){const _0xc054bb=await Lp(_0xd48aa3),_0x383463=X()['gapi'];return m(_0x383463,_0xd48aa3,'internal-error'),_0xc054bb['open']({'where':document['body'],'url':Vp(_0xd48aa3),'messageHandlersFilter':_0x383463['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x46b966=>new Promise(async(_0x505695,_0x144252)=>{await _0x46b966['restyle']({'setHideOnLeave':!0x1});const _0x2760f6=J(_0xd48aa3,'network-request-failed'),_0x400569=X()['setTimeout'](()=>{_0x144252(_0x2760f6);},xp['get']());function _0x4ff135(){X()['clearTimeout'](_0x400569),_0x505695(_0x46b966);}_0x46b966['ping'](_0x4ff135)['then'](_0x4ff135,()=>{_0x144252(_0x2760f6);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0xe2bf5e){this['window']=_0xe2bf5e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x5dc821,_0x3d5f02,_0x5769d8,_0x56b7b8=Gp,_0x393c93=qp){const _0xc076be=Math['max']((window['screen']['availHeight']-_0x393c93)/0x2,0x0)['toString'](),_0x3609be=Math['max']((window['screen']['availWidth']-_0x56b7b8)/0x2,0x0)['toString']();let _0x543e72='';const _0x34f11f={...$p,'width':_0x56b7b8['toString'](),'height':_0x393c93['toString'](),'top':_0xc076be,'left':_0x3609be},_0x3d6ed=W()['toLowerCase']();_0x5769d8&&(_0x543e72=ba(_0x3d6ed)?zp:_0x5769d8),Ta(_0x3d6ed)&&(_0x3d5f02=_0x3d5f02||jp,_0x34f11f['scrollbars']='yes');const _0x258d62=Object['entries'](_0x34f11f)['reduce']((_0x631384,[_0x2f47e5,_0x1419a8])=>''+_0x631384+_0x2f47e5+'='+_0x1419a8+',','');if(Ef(_0x3d6ed)&&_0x543e72!=='_self')return Yp(_0x3d5f02||'',_0x543e72),new Dr(null);const _0x2322f5=window['open'](_0x3d5f02||'',_0x543e72,_0x258d62);m(_0x2322f5,_0x5dc821,'popup-blocked');try{_0x2322f5['focus']();}catch{}return new Dr(_0x2322f5);}function Yp(_0x165e0d,_0x3571a4){const _0x2ecf2d=document['createElement']('a');_0x2ecf2d['href']=_0x165e0d,_0x2ecf2d['target']=_0x3571a4;const _0x5f4bc2=document['createEvent']('MouseEvent');_0x5f4bc2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2ecf2d['dispatchEvent'](_0x5f4bc2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x4b63fa,_0x3044b4,_0x4b5c96,_0x2565cf,_0x407647,_0x35fbf1){m(_0x4b63fa['config']['authDomain'],_0x4b63fa,'auth-domain-config-required'),m(_0x4b63fa['config']['apiKey'],_0x4b63fa,'invalid-api-key');const _0x4b3485={'apiKey':_0x4b63fa['config']['apiKey'],'appName':_0x4b63fa['name'],'authType':_0x4b5c96,'redirectUrl':_0x2565cf,'v':ct,'eventId':_0x407647};if(_0x3044b4 instanceof xa){_0x3044b4['setDefaultLanguage'](_0x4b63fa['languageCode']),_0x4b3485['providerId']=_0x3044b4['providerId']||'',hi(_0x3044b4['getCustomParameters']())||(_0x4b3485['customParameters']=JSON['stringify'](_0x3044b4['getCustomParameters']()));for(const [_0x2ab4a8,_0x17cd45]of Object['entries']({}))_0x4b3485[_0x2ab4a8]=_0x17cd45;}if(_0x3044b4 instanceof Qt){const _0x238ea0=_0x3044b4['getScopes']()['filter'](_0x192b16=>_0x192b16!=='');_0x238ea0['length']>0x0&&(_0x4b3485['scopes']=_0x238ea0['join'](','));}_0x4b63fa['tenantId']&&(_0x4b3485['tid']=_0x4b63fa['tenantId']);const _0x3f675f=_0x4b3485;for(const _0x5571aa of Object['keys'](_0x3f675f))_0x3f675f[_0x5571aa]===void 0x0&&delete _0x3f675f[_0x5571aa];const _0x3aa113=await _0x4b63fa['_getAppCheckToken'](),_0xb53b4d=_0x3aa113?'#'+Xp+'='+encodeURIComponent(_0x3aa113):'';return Zp(_0x4b63fa)+'?'+at(_0x3f675f)['slice'](0x1)+_0xb53b4d;}function Zp({config:_0x30662e}){return _0x30662e['emulator']?Is(_0x30662e,Jp):'https://'+_0x30662e['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x520639,_0x31d417,_0x284e64,_0x46fce7){var _0x2d6fd4;ae((_0x2d6fd4=this['eventManagers'][_0x520639['_key']()])==null?void 0x0:_0x2d6fd4['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x429be0=await Mr(_0x520639,_0x31d417,_0x284e64,Ni(),_0x46fce7);return Kp(_0x520639,_0x429be0,bs());}async['_openRedirect'](_0x4d5b9e,_0x52c87a,_0x1521f1,_0x29655e){await this['_originValidation'](_0x4d5b9e);const _0x2bbe5c=await Mr(_0x4d5b9e,_0x52c87a,_0x1521f1,Ni(),_0x29655e);return ip(_0x2bbe5c),new Promise(()=>{});}['_initialize'](_0x37e5dc){const _0x44a464=_0x37e5dc['_key']();if(this['eventManagers'][_0x44a464]){const {manager:_0x57e26a,promise:_0x280d74}=this['eventManagers'][_0x44a464];return _0x57e26a?Promise['resolve'](_0x57e26a):(ae(_0x280d74,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x280d74);}const _0x2c1ba2=this['initAndGetManager'](_0x37e5dc);return this['eventManagers'][_0x44a464]={'promise':_0x2c1ba2},_0x2c1ba2['catch'](()=>{delete this['eventManagers'][_0x44a464];}),_0x2c1ba2;}async['initAndGetManager'](_0x2bd393){const _0x7719f6=await Hp(_0x2bd393),_0x41d1f2=new bp(_0x2bd393);return _0x7719f6['register']('authEvent',_0x40ee6a=>(m(_0x40ee6a==null?void 0x0:_0x40ee6a['authEvent'],_0x2bd393,'invalid-auth-event'),{'status':_0x41d1f2['onEvent'](_0x40ee6a['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x2bd393['_key']()]={'manager':_0x41d1f2},this['iframes'][_0x2bd393['_key']()]=_0x7719f6,_0x41d1f2;}['_isIframeWebStorageSupported'](_0x32e34a,_0x281302){this['iframes'][_0x32e34a['_key']()]['send'](li,{'type':li},_0x4c8078=>{var _0x5f112e;const _0x3a9446=(_0x5f112e=_0x4c8078==null?void 0x0:_0x4c8078[0x0])==null?void 0x0:_0x5f112e[li];_0x3a9446!==void 0x0&&_0x281302(!!_0x3a9446),K(_0x32e34a,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x596614){const _0x5735c5=_0x596614['_key']();return this['originValidationPromises'][_0x5735c5]||(this['originValidationPromises'][_0x5735c5]=Pp(_0x596614)),this['originValidationPromises'][_0x5735c5];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x3826e7){this['auth']=_0x3826e7,this['internalListeners']=new Map();}['getUid'](){var _0x431ef4;return this['assertAuthConfigured'](),((_0x431ef4=this['auth']['currentUser'])==null?void 0x0:_0x431ef4['uid'])||null;}async['getToken'](_0xdcdbbd){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xdcdbbd)}:null;}['addAuthTokenListener'](_0xd1477d){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xd1477d))return;const _0x268877=this['auth']['onIdTokenChanged'](_0xc8d855=>{_0xd1477d((_0xc8d855==null?void 0x0:_0xc8d855['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xd1477d,_0x268877),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x29f116){this['assertAuthConfigured']();const _0xe659a7=this['internalListeners']['get'](_0x29f116);_0xe659a7&&(this['internalListeners']['delete'](_0x29f116),_0xe659a7(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x1eaaa1){switch(_0x1eaaa1){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x23be2e){et(new Me('auth',(_0x82f9e8,{options:_0x432404})=>{const _0x41a41b=_0x82f9e8['getProvider']('app')['getImmediate'](),_0x82eb17=_0x82f9e8['getProvider']('heartbeat'),_0x2d5e86=_0x82f9e8['getProvider']('app-check-internal'),{apiKey:_0x3c109b,authDomain:_0x33e240}=_0x41a41b['options'];m(_0x3c109b&&!_0x3c109b['includes'](':'),'invalid-api-key',{'appName':_0x41a41b['name']});const _0x2c6dd2={'apiKey':_0x3c109b,'authDomain':_0x33e240,'clientPlatform':_0x23be2e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x23be2e)},_0x4fe52d=new bf(_0x41a41b,_0x82eb17,_0x2d5e86,_0x2c6dd2);return Lf(_0x4fe52d,_0x432404),_0x4fe52d;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x157ae2,_0x22a248,_0xad1e51)=>{_0x157ae2['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1d1664=>{const _0x3d140f=qe(_0x1d1664['getProvider']('auth')['getImmediate']());return(_0x153b40=>new n_(_0x153b40))(_0x3d140f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x23be2e)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x12554d=>async _0x46f32b=>{const _0x271c41=_0x46f32b&&await _0x46f32b['getIdTokenResult'](),_0x4dda9f=_0x271c41&&(new Date()['getTime']()-Date['parse'](_0x271c41['issuedAtTime']))/0x3e8;if(_0x4dda9f&&_0x4dda9f>o_)return;const _0x5c6e09=_0x271c41==null?void 0x0:_0x271c41['token'];Fr!==_0x5c6e09&&(Fr=_0x5c6e09,await fetch(_0x12554d,{'method':_0x5c6e09?'POST':'DELETE','headers':_0x5c6e09?{'Authorization':'Bearer\x20'+_0x5c6e09}:{}}));};function O_(_0x1810ea=Qr()){const _0x2f5547=Ui(_0x1810ea,'auth');if(_0x2f5547['isInitialized']())return _0x2f5547['getImmediate']();const _0x10a4f8=Mf(_0x1810ea,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x3f8946=Gr('authTokenSyncURL');if(_0x3f8946&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x237886=new URL(_0x3f8946,location['origin']);if(location['origin']===_0x237886['origin']){const _0xc4fc0f=a_(_0x237886['toString']());Jf(_0x10a4f8,_0xc4fc0f,()=>_0xc4fc0f(_0x10a4f8['currentUser'])),Qf(_0x10a4f8,_0x408aaa=>_0xc4fc0f(_0x408aaa));}}const _0x32fea1=Hr('auth');return _0x32fea1&&xf(_0x10a4f8,'http://'+_0x32fea1),_0x10a4f8;}function c_(){var _0x54f4ba;return((_0x54f4ba=document['getElementsByTagName']('head'))==null?void 0x0:_0x54f4ba[0x0])??document;}Rf({'loadJS'(_0x548c75){return new Promise((_0x4b3e3f,_0x7843a8)=>{const _0x2b9ce8=document['createElement']('script');_0x2b9ce8['setAttribute']('src',_0x548c75),_0x2b9ce8['onload']=_0x4b3e3f,_0x2b9ce8['onerror']=_0x231411=>{const _0x5c0e41=J('internal-error');_0x5c0e41['customData']=_0x231411,_0x7843a8(_0x5c0e41);},_0x2b9ce8['type']='text/javascript',_0x2b9ce8['charset']='UTF-8',c_()['appendChild'](_0x2b9ce8);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};