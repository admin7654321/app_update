const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1b3cf3,_0x3a9091){if(!_0x1b3cf3)throw ot(_0x3a9091);},ot=function(_0x3204bb){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3204bb);},Wr=function(_0xf9ef65){const _0x16b5ec=[];let _0x2192e4=0x0;for(let _0x36c198=0x0;_0x36c198<_0xf9ef65['length'];_0x36c198++){let _0x42ef7a=_0xf9ef65['charCodeAt'](_0x36c198);_0x42ef7a<0x80?_0x16b5ec[_0x2192e4++]=_0x42ef7a:_0x42ef7a<0x800?(_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0x6|0xc0,_0x16b5ec[_0x2192e4++]=_0x42ef7a&0x3f|0x80):(_0x42ef7a&0xfc00)===0xd800&&_0x36c198+0x1<_0xf9ef65['length']&&(_0xf9ef65['charCodeAt'](_0x36c198+0x1)&0xfc00)===0xdc00?(_0x42ef7a=0x10000+((_0x42ef7a&0x3ff)<<0xa)+(_0xf9ef65['charCodeAt'](++_0x36c198)&0x3ff),_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0x12|0xf0,_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0xc&0x3f|0x80,_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0x6&0x3f|0x80,_0x16b5ec[_0x2192e4++]=_0x42ef7a&0x3f|0x80):(_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0xc|0xe0,_0x16b5ec[_0x2192e4++]=_0x42ef7a>>0x6&0x3f|0x80,_0x16b5ec[_0x2192e4++]=_0x42ef7a&0x3f|0x80);}return _0x16b5ec;},Za=function(_0xfb93b7){const _0x13fdaf=[];let _0xac8b6=0x0,_0x28e16e=0x0;for(;_0xac8b6<_0xfb93b7['length'];){const _0x576c82=_0xfb93b7[_0xac8b6++];if(_0x576c82<0x80)_0x13fdaf[_0x28e16e++]=String['fromCharCode'](_0x576c82);else{if(_0x576c82>0xbf&&_0x576c82<0xe0){const _0x1d7799=_0xfb93b7[_0xac8b6++];_0x13fdaf[_0x28e16e++]=String['fromCharCode']((_0x576c82&0x1f)<<0x6|_0x1d7799&0x3f);}else{if(_0x576c82>0xef&&_0x576c82<0x16d){const _0x2f9497=_0xfb93b7[_0xac8b6++],_0x131ef0=_0xfb93b7[_0xac8b6++],_0x4b98b8=_0xfb93b7[_0xac8b6++],_0x4a066c=((_0x576c82&0x7)<<0x12|(_0x2f9497&0x3f)<<0xc|(_0x131ef0&0x3f)<<0x6|_0x4b98b8&0x3f)-0x10000;_0x13fdaf[_0x28e16e++]=String['fromCharCode'](0xd800+(_0x4a066c>>0xa)),_0x13fdaf[_0x28e16e++]=String['fromCharCode'](0xdc00+(_0x4a066c&0x3ff));}else{const _0x5e8077=_0xfb93b7[_0xac8b6++],_0x121785=_0xfb93b7[_0xac8b6++];_0x13fdaf[_0x28e16e++]=String['fromCharCode']((_0x576c82&0xf)<<0xc|(_0x5e8077&0x3f)<<0x6|_0x121785&0x3f);}}}}return _0x13fdaf['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4dcbe2,_0x5530a6){if(!Array['isArray'](_0x4dcbe2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2c27f8=_0x5530a6?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xd3c12d=[];for(let _0x5c508d=0x0;_0x5c508d<_0x4dcbe2['length'];_0x5c508d+=0x3){const _0x1ed08e=_0x4dcbe2[_0x5c508d],_0x59b5b1=_0x5c508d+0x1<_0x4dcbe2['length'],_0x1af52f=_0x59b5b1?_0x4dcbe2[_0x5c508d+0x1]:0x0,_0x281ddd=_0x5c508d+0x2<_0x4dcbe2['length'],_0x18569f=_0x281ddd?_0x4dcbe2[_0x5c508d+0x2]:0x0,_0x4d42ea=_0x1ed08e>>0x2,_0x1b2ddc=(_0x1ed08e&0x3)<<0x4|_0x1af52f>>0x4;let _0x496647=(_0x1af52f&0xf)<<0x2|_0x18569f>>0x6,_0x5993dc=_0x18569f&0x3f;_0x281ddd||(_0x5993dc=0x40,_0x59b5b1||(_0x496647=0x40)),_0xd3c12d['push'](_0x2c27f8[_0x4d42ea],_0x2c27f8[_0x1b2ddc],_0x2c27f8[_0x496647],_0x2c27f8[_0x5993dc]);}return _0xd3c12d['join']('');},'encodeString'(_0x2a76af,_0x213100){return this['HAS_NATIVE_SUPPORT']&&!_0x213100?btoa(_0x2a76af):this['encodeByteArray'](Wr(_0x2a76af),_0x213100);},'decodeString'(_0xa0dba5,_0x21a7fc){return this['HAS_NATIVE_SUPPORT']&&!_0x21a7fc?atob(_0xa0dba5):Za(this['decodeStringToByteArray'](_0xa0dba5,_0x21a7fc));},'decodeStringToByteArray'(_0x2a6529,_0x3af0eb){this['init_']();const _0x5c5df1=_0x3af0eb?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x8d4b93=[];for(let _0x1c834f=0x0;_0x1c834f<_0x2a6529['length'];){const _0x439488=_0x5c5df1[_0x2a6529['charAt'](_0x1c834f++)],_0x48226f=_0x1c834f<_0x2a6529['length']?_0x5c5df1[_0x2a6529['charAt'](_0x1c834f)]:0x0;++_0x1c834f;const _0x2239f2=_0x1c834f<_0x2a6529['length']?_0x5c5df1[_0x2a6529['charAt'](_0x1c834f)]:0x40;++_0x1c834f;const _0x221758=_0x1c834f<_0x2a6529['length']?_0x5c5df1[_0x2a6529['charAt'](_0x1c834f)]:0x40;if(++_0x1c834f,_0x439488==null||_0x48226f==null||_0x2239f2==null||_0x221758==null)throw new ec();const _0x37a541=_0x439488<<0x2|_0x48226f>>0x4;if(_0x8d4b93['push'](_0x37a541),_0x2239f2!==0x40){const _0x4817b6=_0x48226f<<0x4&0xf0|_0x2239f2>>0x2;if(_0x8d4b93['push'](_0x4817b6),_0x221758!==0x40){const _0x15f752=_0x2239f2<<0x6&0xc0|_0x221758;_0x8d4b93['push'](_0x15f752);}}}return _0x8d4b93;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5ebb40=0x0;_0x5ebb40<this['ENCODED_VALS']['length'];_0x5ebb40++)this['byteToCharMap_'][_0x5ebb40]=this['ENCODED_VALS']['charAt'](_0x5ebb40),this['charToByteMap_'][this['byteToCharMap_'][_0x5ebb40]]=_0x5ebb40,this['byteToCharMapWebSafe_'][_0x5ebb40]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5ebb40),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5ebb40]]=_0x5ebb40,_0x5ebb40>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5ebb40)]=_0x5ebb40,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5ebb40)]=_0x5ebb40);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x15c6ff){const _0x51833d=Wr(_0x15c6ff);return Di['encodeByteArray'](_0x51833d,!0x0);},an=function(_0xef7849){return Br(_0xef7849)['replace'](/\./g,'');},cn=function(_0x5aea37){try{return Di['decodeString'](_0x5aea37,!0x0);}catch(_0x315bbb){console['error']('base64Decode\x20failed:\x20',_0x315bbb);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x5538d2){return Vr(void 0x0,_0x5538d2);}function Vr(_0x4a718b,_0x2dd000){if(!(_0x2dd000 instanceof Object))return _0x2dd000;switch(_0x2dd000['constructor']){case Date:const _0x27142d=_0x2dd000;return new Date(_0x27142d['getTime']());case Object:_0x4a718b===void 0x0&&(_0x4a718b={});break;case Array:_0x4a718b=[];break;default:return _0x2dd000;}for(const _0x27fd9d in _0x2dd000)!_0x2dd000['hasOwnProperty'](_0x27fd9d)||!nc(_0x27fd9d)||(_0x4a718b[_0x27fd9d]=Vr(_0x4a718b[_0x27fd9d],_0x2dd000[_0x27fd9d]));return _0x4a718b;}function nc(_0x465bc1){return _0x465bc1!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x58a806=As['__FIREBASE_DEFAULTS__'];if(_0x58a806)return JSON['parse'](_0x58a806);},oc=()=>{if(typeof document>'u')return;let _0x4f927d;try{_0x4f927d=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x287fc7=_0x4f927d&&cn(_0x4f927d[0x1]);return _0x287fc7&&JSON['parse'](_0x287fc7);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x494bfd){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x494bfd);return;}},Hr=_0x22d50d=>{var _0x184b77,_0x2be981;return(_0x2be981=(_0x184b77=Mi())==null?void 0x0:_0x184b77['emulatorHosts'])==null?void 0x0:_0x2be981[_0x22d50d];},ac=_0x2f388b=>{const _0x21ba73=Hr(_0x2f388b);if(!_0x21ba73)return;const _0x530f1d=_0x21ba73['lastIndexOf'](':');if(_0x530f1d<=0x0||_0x530f1d+0x1===_0x21ba73['length'])throw new Error('Invalid\x20host\x20'+_0x21ba73+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x58e417=parseInt(_0x21ba73['substring'](_0x530f1d+0x1),0xa);return _0x21ba73[0x0]==='['?[_0x21ba73['substring'](0x1,_0x530f1d-0x1),_0x58e417]:[_0x21ba73['substring'](0x0,_0x530f1d),_0x58e417];},$r=()=>{var _0x3ca2d7;return(_0x3ca2d7=Mi())==null?void 0x0:_0x3ca2d7['config'];},Gr=_0x4e376d=>{var _0x1c4edb;return(_0x1c4edb=Mi())==null?void 0x0:_0x1c4edb['_'+_0x4e376d];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1318e4,_0x4dadcc)=>{this['resolve']=_0x1318e4,this['reject']=_0x4dadcc;});}['wrapCallback'](_0xa41537){return(_0x4bbdb9,_0x3ba895)=>{_0x4bbdb9?this['reject'](_0x4bbdb9):this['resolve'](_0x3ba895),typeof _0xa41537=='function'&&(this['promise']['catch'](()=>{}),_0xa41537['length']===0x1?_0xa41537(_0x4bbdb9):_0xa41537(_0x4bbdb9,_0x3ba895));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x3f545d,_0x210186){if(_0x3f545d['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x282abd={'alg':'none','type':'JWT'},_0x1f3d58=_0x210186||'demo-project',_0xece3ce=_0x3f545d['iat']||0x0,_0x34b180=_0x3f545d['sub']||_0x3f545d['user_id'];if(!_0x34b180)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3b4843={'iss':'https://securetoken.google.com/'+_0x1f3d58,'aud':_0x1f3d58,'iat':_0xece3ce,'exp':_0xece3ce+0xe10,'auth_time':_0xece3ce,'sub':_0x34b180,'user_id':_0x34b180,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3f545d};return[an(JSON['stringify'](_0x282abd)),an(JSON['stringify'](_0x3b4843)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x4d82d7=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4d82d7=='object'&&_0x4d82d7['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0xaff7f7=W();return _0xaff7f7['indexOf']('MSIE\x20')>=0x0||_0xaff7f7['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0xfbe233,_0x40260f)=>{try{let _0xf36696=!0x0;const _0x1a3f66='validate-browser-context-for-indexeddb-analytics-module',_0xb8b4d8=self['indexedDB']['open'](_0x1a3f66);_0xb8b4d8['onsuccess']=()=>{_0xb8b4d8['result']['close'](),_0xf36696||self['indexedDB']['deleteDatabase'](_0x1a3f66),_0xfbe233(!0x0);},_0xb8b4d8['onupgradeneeded']=()=>{_0xf36696=!0x1;},_0xb8b4d8['onerror']=()=>{var _0x5d6806;_0x40260f(((_0x5d6806=_0xb8b4d8['error'])==null?void 0x0:_0x5d6806['message'])||'');};}catch(_0x308b59){_0x40260f(_0x308b59);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x1e00bb,_0xbc20db,_0x399e92){super(_0xbc20db),this['code']=_0x1e00bb,this['customData']=_0x399e92,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4eb790,_0x8e0a3,_0x673c63){this['service']=_0x4eb790,this['serviceName']=_0x8e0a3,this['errors']=_0x673c63;}['create'](_0x265014,..._0x29f7de){const _0x25c892=_0x29f7de[0x0]||{},_0x52dc5a=this['service']+'/'+_0x265014,_0xaa4cd6=this['errors'][_0x265014],_0x41daa6=_0xaa4cd6?gc(_0xaa4cd6,_0x25c892):'Error',_0x2ac378=this['serviceName']+':\x20'+_0x41daa6+'\x20('+_0x52dc5a+').';return new Se(_0x52dc5a,_0x2ac378,_0x25c892);}}function gc(_0x35a0ff,_0x3c74c0){return _0x35a0ff['replace'](mc,(_0x1481ac,_0x274a35)=>{const _0x2ae618=_0x3c74c0[_0x274a35];return _0x2ae618!=null?String(_0x2ae618):'<'+_0x274a35+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x1f77a4){return JSON['parse'](_0x1f77a4);}function O(_0x242ab7){return JSON['stringify'](_0x242ab7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x45ffb2){let _0x160190={},_0x5067f1={},_0x159385={},_0x3f89a9='';try{const _0x5bcc71=_0x45ffb2['split']('.');_0x160190=bt(cn(_0x5bcc71[0x0])||''),_0x5067f1=bt(cn(_0x5bcc71[0x1])||''),_0x3f89a9=_0x5bcc71[0x2],_0x159385=_0x5067f1['d']||{},delete _0x5067f1['d'];}catch{}return{'header':_0x160190,'claims':_0x5067f1,'data':_0x159385,'signature':_0x3f89a9};},yc=function(_0x6fb1e7){const _0x228cb3=zr(_0x6fb1e7),_0x1e2310=_0x228cb3['claims'];return!!_0x1e2310&&typeof _0x1e2310=='object'&&_0x1e2310['hasOwnProperty']('iat');},vc=function(_0x34f513){const _0xeecd0=zr(_0x34f513)['claims'];return typeof _0xeecd0=='object'&&_0xeecd0['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1772e2,_0x55351c){return Object['prototype']['hasOwnProperty']['call'](_0x1772e2,_0x55351c);}function Oe(_0x3c7fd1,_0x56263b){if(Object['prototype']['hasOwnProperty']['call'](_0x3c7fd1,_0x56263b))return _0x3c7fd1[_0x56263b];}function hi(_0x4aae85){for(const _0x188def in _0x4aae85)if(Object['prototype']['hasOwnProperty']['call'](_0x4aae85,_0x188def))return!0x1;return!0x0;}function ln(_0x278ca3,_0x6157e,_0xf10f43){const _0x2f0610={};for(const _0x20729f in _0x278ca3)Object['prototype']['hasOwnProperty']['call'](_0x278ca3,_0x20729f)&&(_0x2f0610[_0x20729f]=_0x6157e['call'](_0xf10f43,_0x278ca3[_0x20729f],_0x20729f,_0x278ca3));return _0x2f0610;}function De(_0x4aee7e,_0x26c77e){if(_0x4aee7e===_0x26c77e)return!0x0;const _0x4f85c5=Object['keys'](_0x4aee7e),_0x3ad4cb=Object['keys'](_0x26c77e);for(const _0x3510dc of _0x4f85c5){if(!_0x3ad4cb['includes'](_0x3510dc))return!0x1;const _0x344ed6=_0x4aee7e[_0x3510dc],_0x51962b=_0x26c77e[_0x3510dc];if(ks(_0x344ed6)&&ks(_0x51962b)){if(!De(_0x344ed6,_0x51962b))return!0x1;}else{if(_0x344ed6!==_0x51962b)return!0x1;}}for(const _0x1678c7 of _0x3ad4cb)if(!_0x4f85c5['includes'](_0x1678c7))return!0x1;return!0x0;}function ks(_0x43d833){return _0x43d833!==null&&typeof _0x43d833=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x47b8ba){const _0x592b30=[];for(const [_0x5d720d,_0x599828]of Object['entries'](_0x47b8ba))Array['isArray'](_0x599828)?_0x599828['forEach'](_0x410eed=>{_0x592b30['push'](encodeURIComponent(_0x5d720d)+'='+encodeURIComponent(_0x410eed));}):_0x592b30['push'](encodeURIComponent(_0x5d720d)+'='+encodeURIComponent(_0x599828));return _0x592b30['length']?'&'+_0x592b30['join']('&'):'';}function yt(_0x55f9c1){const _0x512ebc={};return _0x55f9c1['replace'](/^\?/,'')['split']('&')['forEach'](_0x40d16e=>{if(_0x40d16e){const [_0x7d4bc0,_0x36e013]=_0x40d16e['split']('=');_0x512ebc[decodeURIComponent(_0x7d4bc0)]=decodeURIComponent(_0x36e013);}}),_0x512ebc;}function vt(_0x183e8b){const _0x34be03=_0x183e8b['indexOf']('?');if(!_0x34be03)return'';const _0xda9526=_0x183e8b['indexOf']('#',_0x34be03);return _0x183e8b['substring'](_0x34be03,_0xda9526>0x0?_0xda9526:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2129d0=0x1;_0x2129d0<this['blockSize'];++_0x2129d0)this['pad_'][_0x2129d0]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2940ac,_0x11d7aa){_0x11d7aa||(_0x11d7aa=0x0);const _0x459c95=this['W_'];if(typeof _0x2940ac=='string'){for(let _0x24a8df=0x0;_0x24a8df<0x10;_0x24a8df++)_0x459c95[_0x24a8df]=_0x2940ac['charCodeAt'](_0x11d7aa)<<0x18|_0x2940ac['charCodeAt'](_0x11d7aa+0x1)<<0x10|_0x2940ac['charCodeAt'](_0x11d7aa+0x2)<<0x8|_0x2940ac['charCodeAt'](_0x11d7aa+0x3),_0x11d7aa+=0x4;}else{for(let _0x356011=0x0;_0x356011<0x10;_0x356011++)_0x459c95[_0x356011]=_0x2940ac[_0x11d7aa]<<0x18|_0x2940ac[_0x11d7aa+0x1]<<0x10|_0x2940ac[_0x11d7aa+0x2]<<0x8|_0x2940ac[_0x11d7aa+0x3],_0x11d7aa+=0x4;}for(let _0x3abe65=0x10;_0x3abe65<0x50;_0x3abe65++){const _0x1686ee=_0x459c95[_0x3abe65-0x3]^_0x459c95[_0x3abe65-0x8]^_0x459c95[_0x3abe65-0xe]^_0x459c95[_0x3abe65-0x10];_0x459c95[_0x3abe65]=(_0x1686ee<<0x1|_0x1686ee>>>0x1f)&0xffffffff;}let _0x4dcb18=this['chain_'][0x0],_0x536527=this['chain_'][0x1],_0x6b0dc0=this['chain_'][0x2],_0x54e49d=this['chain_'][0x3],_0x26063d=this['chain_'][0x4],_0x5538a4,_0x46ef89;for(let _0x4696f4=0x0;_0x4696f4<0x50;_0x4696f4++){_0x4696f4<0x28?_0x4696f4<0x14?(_0x5538a4=_0x54e49d^_0x536527&(_0x6b0dc0^_0x54e49d),_0x46ef89=0x5a827999):(_0x5538a4=_0x536527^_0x6b0dc0^_0x54e49d,_0x46ef89=0x6ed9eba1):_0x4696f4<0x3c?(_0x5538a4=_0x536527&_0x6b0dc0|_0x54e49d&(_0x536527|_0x6b0dc0),_0x46ef89=0x8f1bbcdc):(_0x5538a4=_0x536527^_0x6b0dc0^_0x54e49d,_0x46ef89=0xca62c1d6);const _0x2b8865=(_0x4dcb18<<0x5|_0x4dcb18>>>0x1b)+_0x5538a4+_0x26063d+_0x46ef89+_0x459c95[_0x4696f4]&0xffffffff;_0x26063d=_0x54e49d,_0x54e49d=_0x6b0dc0,_0x6b0dc0=(_0x536527<<0x1e|_0x536527>>>0x2)&0xffffffff,_0x536527=_0x4dcb18,_0x4dcb18=_0x2b8865;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4dcb18&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x536527&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x6b0dc0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x54e49d&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x26063d&0xffffffff;}['update'](_0x49fb7a,_0xa03f06){if(_0x49fb7a==null)return;_0xa03f06===void 0x0&&(_0xa03f06=_0x49fb7a['length']);const _0x3cfc85=_0xa03f06-this['blockSize'];let _0x524995=0x0;const _0x37581b=this['buf_'];let _0xe7f530=this['inbuf_'];for(;_0x524995<_0xa03f06;){if(_0xe7f530===0x0){for(;_0x524995<=_0x3cfc85;)this['compress_'](_0x49fb7a,_0x524995),_0x524995+=this['blockSize'];}if(typeof _0x49fb7a=='string'){for(;_0x524995<_0xa03f06;)if(_0x37581b[_0xe7f530]=_0x49fb7a['charCodeAt'](_0x524995),++_0xe7f530,++_0x524995,_0xe7f530===this['blockSize']){this['compress_'](_0x37581b),_0xe7f530=0x0;break;}}else{for(;_0x524995<_0xa03f06;)if(_0x37581b[_0xe7f530]=_0x49fb7a[_0x524995],++_0xe7f530,++_0x524995,_0xe7f530===this['blockSize']){this['compress_'](_0x37581b),_0xe7f530=0x0;break;}}}this['inbuf_']=_0xe7f530,this['total_']+=_0xa03f06;}['digest'](){const _0xe74022=[];let _0x2fb490=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4011fe=this['blockSize']-0x1;_0x4011fe>=0x38;_0x4011fe--)this['buf_'][_0x4011fe]=_0x2fb490&0xff,_0x2fb490/=0x100;this['compress_'](this['buf_']);let _0x28a251=0x0;for(let _0x156c21=0x0;_0x156c21<0x5;_0x156c21++)for(let _0x3b8857=0x18;_0x3b8857>=0x0;_0x3b8857-=0x8)_0xe74022[_0x28a251]=this['chain_'][_0x156c21]>>_0x3b8857&0xff,++_0x28a251;return _0xe74022;}}function Ic(_0x2dc974,_0x158e6c){const _0x31aee7=new wc(_0x2dc974,_0x158e6c);return _0x31aee7['subscribe']['bind'](_0x31aee7);}class wc{constructor(_0x28dcf1,_0x1b424a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1b424a,this['task']['then'](()=>{_0x28dcf1(this);})['catch'](_0x3a7dee=>{this['error'](_0x3a7dee);});}['next'](_0x3dbd94){this['forEachObserver'](_0x46c696=>{_0x46c696['next'](_0x3dbd94);});}['error'](_0x33a158){this['forEachObserver'](_0x3b2cc6=>{_0x3b2cc6['error'](_0x33a158);}),this['close'](_0x33a158);}['complete'](){this['forEachObserver'](_0x1e38da=>{_0x1e38da['complete']();}),this['close']();}['subscribe'](_0x49b922,_0x171152,_0x537bdc){let _0x4e6931;if(_0x49b922===void 0x0&&_0x171152===void 0x0&&_0x537bdc===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x49b922,['next','error','complete'])?_0x4e6931=_0x49b922:_0x4e6931={'next':_0x49b922,'error':_0x171152,'complete':_0x537bdc},_0x4e6931['next']===void 0x0&&(_0x4e6931['next']=Qn),_0x4e6931['error']===void 0x0&&(_0x4e6931['error']=Qn),_0x4e6931['complete']===void 0x0&&(_0x4e6931['complete']=Qn);const _0x27b573=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4e6931['error'](this['finalError']):_0x4e6931['complete']();}catch{}}),this['observers']['push'](_0x4e6931),_0x27b573;}['unsubscribeOne'](_0x3a1291){this['observers']===void 0x0||this['observers'][_0x3a1291]===void 0x0||(delete this['observers'][_0x3a1291],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x456afc){if(!this['finalized']){for(let _0x30f356=0x0;_0x30f356<this['observers']['length'];_0x30f356++)this['sendOne'](_0x30f356,_0x456afc);}}['sendOne'](_0x3ef42a,_0x2752bc){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3ef42a]!==void 0x0)try{_0x2752bc(this['observers'][_0x3ef42a]);}catch(_0x1cbd17){typeof console<'u'&&console['error']&&console['error'](_0x1cbd17);}});}['close'](_0xf735a7){this['finalized']||(this['finalized']=!0x0,_0xf735a7!==void 0x0&&(this['finalError']=_0xf735a7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x85c31f,_0x5ad849){if(typeof _0x85c31f!='object'||_0x85c31f===null)return!0x1;for(const _0x7005a9 of _0x5ad849)if(_0x7005a9 in _0x85c31f&&typeof _0x85c31f[_0x7005a9]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x2f41d7,_0x6d6ee0){return _0x2f41d7+'\x20failed:\x20'+_0x6d6ee0+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x4deb83){const _0x167d16=[];let _0xebc7e8=0x0;for(let _0x12a79b=0x0;_0x12a79b<_0x4deb83['length'];_0x12a79b++){let _0x3517eb=_0x4deb83['charCodeAt'](_0x12a79b);if(_0x3517eb>=0xd800&&_0x3517eb<=0xdbff){const _0x11eb74=_0x3517eb-0xd800;_0x12a79b++,f(_0x12a79b<_0x4deb83['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5f153d=_0x4deb83['charCodeAt'](_0x12a79b)-0xdc00;_0x3517eb=0x10000+(_0x11eb74<<0xa)+_0x5f153d;}_0x3517eb<0x80?_0x167d16[_0xebc7e8++]=_0x3517eb:_0x3517eb<0x800?(_0x167d16[_0xebc7e8++]=_0x3517eb>>0x6|0xc0,_0x167d16[_0xebc7e8++]=_0x3517eb&0x3f|0x80):_0x3517eb<0x10000?(_0x167d16[_0xebc7e8++]=_0x3517eb>>0xc|0xe0,_0x167d16[_0xebc7e8++]=_0x3517eb>>0x6&0x3f|0x80,_0x167d16[_0xebc7e8++]=_0x3517eb&0x3f|0x80):(_0x167d16[_0xebc7e8++]=_0x3517eb>>0x12|0xf0,_0x167d16[_0xebc7e8++]=_0x3517eb>>0xc&0x3f|0x80,_0x167d16[_0xebc7e8++]=_0x3517eb>>0x6&0x3f|0x80,_0x167d16[_0xebc7e8++]=_0x3517eb&0x3f|0x80);}return _0x167d16;},Pn=function(_0x45832b){let _0x576c4d=0x0;for(let _0x1c1371=0x0;_0x1c1371<_0x45832b['length'];_0x1c1371++){const _0x3738a0=_0x45832b['charCodeAt'](_0x1c1371);_0x3738a0<0x80?_0x576c4d++:_0x3738a0<0x800?_0x576c4d+=0x2:_0x3738a0>=0xd800&&_0x3738a0<=0xdbff?(_0x576c4d+=0x4,_0x1c1371++):_0x576c4d+=0x3;}return _0x576c4d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x4c7b2a){return _0x4c7b2a&&_0x4c7b2a['_delegate']?_0x4c7b2a['_delegate']:_0x4c7b2a;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x24275b){try{return(_0x24275b['startsWith']('http://')||_0x24275b['startsWith']('https://')?new URL(_0x24275b)['hostname']:_0x24275b)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x5e81b2){return(await fetch(_0x5e81b2,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4b871a,_0x5e7bbd,_0x41b03e){this['name']=_0x4b871a,this['instanceFactory']=_0x5e7bbd,this['type']=_0x41b03e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x427e3f){return this['instantiationMode']=_0x427e3f,this;}['setMultipleInstances'](_0x284184){return this['multipleInstances']=_0x284184,this;}['setServiceProps'](_0x2c10d1){return this['serviceProps']=_0x2c10d1,this;}['setInstanceCreatedCallback'](_0x31d2c4){return this['onInstanceCreated']=_0x31d2c4,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x6d19c6,_0x279146){this['name']=_0x6d19c6,this['container']=_0x279146,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1c3520){const _0x3bae53=this['normalizeInstanceIdentifier'](_0x1c3520);if(!this['instancesDeferred']['has'](_0x3bae53)){const _0x1452f9=new Ve();if(this['instancesDeferred']['set'](_0x3bae53,_0x1452f9),this['isInitialized'](_0x3bae53)||this['shouldAutoInitialize']())try{const _0xde0523=this['getOrInitializeService']({'instanceIdentifier':_0x3bae53});_0xde0523&&_0x1452f9['resolve'](_0xde0523);}catch{}}return this['instancesDeferred']['get'](_0x3bae53)['promise'];}['getImmediate'](_0x555534){const _0x2a6d4e=this['normalizeInstanceIdentifier'](_0x555534==null?void 0x0:_0x555534['identifier']),_0x2099ef=(_0x555534==null?void 0x0:_0x555534['optional'])??!0x1;if(this['isInitialized'](_0x2a6d4e)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2a6d4e});}catch(_0x9b4197){if(_0x2099ef)return null;throw _0x9b4197;}else{if(_0x2099ef)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x33ce68){if(_0x33ce68['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x33ce68['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x33ce68,!!this['shouldAutoInitialize']()){if(Rc(_0x33ce68))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x50bcdf,_0x1aaf0b]of this['instancesDeferred']['entries']()){const _0x466bc8=this['normalizeInstanceIdentifier'](_0x50bcdf);try{const _0xcfc129=this['getOrInitializeService']({'instanceIdentifier':_0x466bc8});_0x1aaf0b['resolve'](_0xcfc129);}catch{}}}}['clearInstance'](_0x457ea1=ke){this['instancesDeferred']['delete'](_0x457ea1),this['instancesOptions']['delete'](_0x457ea1),this['instances']['delete'](_0x457ea1);}async['delete'](){const _0x2eefa8=Array['from'](this['instances']['values']());await Promise['all']([..._0x2eefa8['filter'](_0x595eaf=>'INTERNAL'in _0x595eaf)['map'](_0x37feab=>_0x37feab['INTERNAL']['delete']()),..._0x2eefa8['filter'](_0x1d406c=>'_delete'in _0x1d406c)['map'](_0x1ece55=>_0x1ece55['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4cc603=ke){return this['instances']['has'](_0x4cc603);}['getOptions'](_0xd965e5=ke){return this['instancesOptions']['get'](_0xd965e5)||{};}['initialize'](_0x35c6fd={}){const {options:_0xcf06b3={}}=_0x35c6fd,_0x43378a=this['normalizeInstanceIdentifier'](_0x35c6fd['instanceIdentifier']);if(this['isInitialized'](_0x43378a))throw Error(this['name']+'('+_0x43378a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x572689=this['getOrInitializeService']({'instanceIdentifier':_0x43378a,'options':_0xcf06b3});for(const [_0xb0cbd2,_0x14a62a]of this['instancesDeferred']['entries']()){const _0x4c867d=this['normalizeInstanceIdentifier'](_0xb0cbd2);_0x43378a===_0x4c867d&&_0x14a62a['resolve'](_0x572689);}return _0x572689;}['onInit'](_0x2d9c44,_0x3c2f06){const _0x2f13d7=this['normalizeInstanceIdentifier'](_0x3c2f06),_0x530b32=this['onInitCallbacks']['get'](_0x2f13d7)??new Set();_0x530b32['add'](_0x2d9c44),this['onInitCallbacks']['set'](_0x2f13d7,_0x530b32);const _0x56c64c=this['instances']['get'](_0x2f13d7);return _0x56c64c&&_0x2d9c44(_0x56c64c,_0x2f13d7),()=>{_0x530b32['delete'](_0x2d9c44);};}['invokeOnInitCallbacks'](_0x32b6d8,_0x17dd35){const _0x10bb56=this['onInitCallbacks']['get'](_0x17dd35);if(_0x10bb56){for(const _0x1d5f0a of _0x10bb56)try{_0x1d5f0a(_0x32b6d8,_0x17dd35);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4b01a5,options:_0x31e8c0={}}){let _0x25992a=this['instances']['get'](_0x4b01a5);if(!_0x25992a&&this['component']&&(_0x25992a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x4b01a5),'options':_0x31e8c0}),this['instances']['set'](_0x4b01a5,_0x25992a),this['instancesOptions']['set'](_0x4b01a5,_0x31e8c0),this['invokeOnInitCallbacks'](_0x25992a,_0x4b01a5),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4b01a5,_0x25992a);}catch{}return _0x25992a||null;}['normalizeInstanceIdentifier'](_0x258b33=ke){return this['component']?this['component']['multipleInstances']?_0x258b33:ke:_0x258b33;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x2d65c0){return _0x2d65c0===ke?void 0x0:_0x2d65c0;}function Rc(_0x1a71e8){return _0x1a71e8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x228a45){this['name']=_0x228a45,this['providers']=new Map();}['addComponent'](_0x58c603){const _0x2143e7=this['getProvider'](_0x58c603['name']);if(_0x2143e7['isComponentSet']())throw new Error('Component\x20'+_0x58c603['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2143e7['setComponent'](_0x58c603);}['addOrOverwriteComponent'](_0x3699a9){this['getProvider'](_0x3699a9['name'])['isComponentSet']()&&this['providers']['delete'](_0x3699a9['name']),this['addComponent'](_0x3699a9);}['getProvider'](_0x4ec003){if(this['providers']['has'](_0x4ec003))return this['providers']['get'](_0x4ec003);const _0x3820bb=new Sc(_0x4ec003,this);return this['providers']['set'](_0x4ec003,_0x3820bb),_0x3820bb;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x517766){_0x517766[_0x517766['DEBUG']=0x0]='DEBUG',_0x517766[_0x517766['VERBOSE']=0x1]='VERBOSE',_0x517766[_0x517766['INFO']=0x2]='INFO',_0x517766[_0x517766['WARN']=0x3]='WARN',_0x517766[_0x517766['ERROR']=0x4]='ERROR',_0x517766[_0x517766['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x28ff2d,_0x2a0e8e,..._0x1f639e)=>{if(_0x2a0e8e<_0x28ff2d['logLevel'])return;const _0x4a0e8f=new Date()['toISOString'](),_0xe2fa54=Pc[_0x2a0e8e];if(_0xe2fa54)console[_0xe2fa54]('['+_0x4a0e8f+']\x20\x20'+_0x28ff2d['name']+':',..._0x1f639e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2a0e8e+')');};class xi{constructor(_0xe93cfd){this['name']=_0xe93cfd,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x17edaf){if(!(_0x17edaf in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x17edaf+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x17edaf;}['setLogLevel'](_0x27076e){this['_logLevel']=typeof _0x27076e=='string'?kc[_0x27076e]:_0x27076e;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x41eeb1){if(typeof _0x41eeb1!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x41eeb1;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x443934){this['_userLogHandler']=_0x443934;}['debug'](..._0x25bfaa){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x25bfaa),this['_logHandler'](this,T['DEBUG'],..._0x25bfaa);}['log'](..._0x4a3223){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4a3223),this['_logHandler'](this,T['VERBOSE'],..._0x4a3223);}['info'](..._0x5c21b){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5c21b),this['_logHandler'](this,T['INFO'],..._0x5c21b);}['warn'](..._0x32f8f1){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x32f8f1),this['_logHandler'](this,T['WARN'],..._0x32f8f1);}['error'](..._0x14ec5c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x14ec5c),this['_logHandler'](this,T['ERROR'],..._0x14ec5c);}}const Dc=(_0x4ed1d3,_0x1147a5)=>_0x1147a5['some'](_0x5ca0fd=>_0x4ed1d3 instanceof _0x5ca0fd);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x10389e){const _0x46df16=new Promise((_0x3abfa5,_0x4a0e54)=>{const _0xeb2e76=()=>{_0x10389e['removeEventListener']('success',_0x34f7fb),_0x10389e['removeEventListener']('error',_0x2c2504);},_0x34f7fb=()=>{_0x3abfa5(_e(_0x10389e['result'])),_0xeb2e76();},_0x2c2504=()=>{_0x4a0e54(_0x10389e['error']),_0xeb2e76();};_0x10389e['addEventListener']('success',_0x34f7fb),_0x10389e['addEventListener']('error',_0x2c2504);});return _0x46df16['then'](_0xf5ea3f=>{_0xf5ea3f instanceof IDBCursor&&Kr['set'](_0xf5ea3f,_0x10389e);})['catch'](()=>{}),Fi['set'](_0x46df16,_0x10389e),_0x46df16;}function Fc(_0x29d658){if(ui['has'](_0x29d658))return;const _0x1ddcdf=new Promise((_0x4bde46,_0xd22eba)=>{const _0x54b469=()=>{_0x29d658['removeEventListener']('complete',_0x508b92),_0x29d658['removeEventListener']('error',_0xff87c2),_0x29d658['removeEventListener']('abort',_0xff87c2);},_0x508b92=()=>{_0x4bde46(),_0x54b469();},_0xff87c2=()=>{_0xd22eba(_0x29d658['error']||new DOMException('AbortError','AbortError')),_0x54b469();};_0x29d658['addEventListener']('complete',_0x508b92),_0x29d658['addEventListener']('error',_0xff87c2),_0x29d658['addEventListener']('abort',_0xff87c2);});ui['set'](_0x29d658,_0x1ddcdf);}let di={'get'(_0x4a18c9,_0x215b02,_0x4c9668){if(_0x4a18c9 instanceof IDBTransaction){if(_0x215b02==='done')return ui['get'](_0x4a18c9);if(_0x215b02==='objectStoreNames')return _0x4a18c9['objectStoreNames']||Yr['get'](_0x4a18c9);if(_0x215b02==='store')return _0x4c9668['objectStoreNames'][0x1]?void 0x0:_0x4c9668['objectStore'](_0x4c9668['objectStoreNames'][0x0]);}return _e(_0x4a18c9[_0x215b02]);},'set'(_0x377060,_0x450eed,_0x1ec556){return _0x377060[_0x450eed]=_0x1ec556,!0x0;},'has'(_0x3b4150,_0x5159a8){return _0x3b4150 instanceof IDBTransaction&&(_0x5159a8==='done'||_0x5159a8==='store')?!0x0:_0x5159a8 in _0x3b4150;}};function Uc(_0xc861ec){di=_0xc861ec(di);}function Wc(_0x2bc93b){return _0x2bc93b===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4076a1,..._0x261bbf){const _0x51fbe1=_0x2bc93b['call'](Xn(this),_0x4076a1,..._0x261bbf);return Yr['set'](_0x51fbe1,_0x4076a1['sort']?_0x4076a1['sort']():[_0x4076a1]),_e(_0x51fbe1);}:Lc()['includes'](_0x2bc93b)?function(..._0x4bde64){return _0x2bc93b['apply'](Xn(this),_0x4bde64),_e(Kr['get'](this));}:function(..._0x103781){return _e(_0x2bc93b['apply'](Xn(this),_0x103781));};}function Bc(_0x4e52c5){return typeof _0x4e52c5=='function'?Wc(_0x4e52c5):(_0x4e52c5 instanceof IDBTransaction&&Fc(_0x4e52c5),Dc(_0x4e52c5,Mc())?new Proxy(_0x4e52c5,di):_0x4e52c5);}function _e(_0x45c72e){if(_0x45c72e instanceof IDBRequest)return xc(_0x45c72e);if(Jn['has'](_0x45c72e))return Jn['get'](_0x45c72e);const _0x4116bf=Bc(_0x45c72e);return _0x4116bf!==_0x45c72e&&(Jn['set'](_0x45c72e,_0x4116bf),Fi['set'](_0x4116bf,_0x45c72e)),_0x4116bf;}const Xn=_0x5e3815=>Fi['get'](_0x5e3815);function Vc(_0x87bed1,_0x2a3650,{blocked:_0x403184,upgrade:_0xe89a35,blocking:_0x4c3ef2,terminated:_0x55de42}={}){const _0x68d20d=indexedDB['open'](_0x87bed1,_0x2a3650),_0x454465=_e(_0x68d20d);return _0xe89a35&&_0x68d20d['addEventListener']('upgradeneeded',_0x455812=>{_0xe89a35(_e(_0x68d20d['result']),_0x455812['oldVersion'],_0x455812['newVersion'],_e(_0x68d20d['transaction']),_0x455812);}),_0x403184&&_0x68d20d['addEventListener']('blocked',_0x3dc4cd=>_0x403184(_0x3dc4cd['oldVersion'],_0x3dc4cd['newVersion'],_0x3dc4cd)),_0x454465['then'](_0x35d14d=>{_0x55de42&&_0x35d14d['addEventListener']('close',()=>_0x55de42()),_0x4c3ef2&&_0x35d14d['addEventListener']('versionchange',_0x14f7e1=>_0x4c3ef2(_0x14f7e1['oldVersion'],_0x14f7e1['newVersion'],_0x14f7e1));})['catch'](()=>{}),_0x454465;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0xcafa54,_0x4923ee){if(!(_0xcafa54 instanceof IDBDatabase&&!(_0x4923ee in _0xcafa54)&&typeof _0x4923ee=='string'))return;if(Zn['get'](_0x4923ee))return Zn['get'](_0x4923ee);const _0x14ceaf=_0x4923ee['replace'](/FromIndex$/,''),_0x1b88c3=_0x4923ee!==_0x14ceaf,_0x426f95=$c['includes'](_0x14ceaf);if(!(_0x14ceaf in(_0x1b88c3?IDBIndex:IDBObjectStore)['prototype'])||!(_0x426f95||Hc['includes'](_0x14ceaf)))return;const _0x201933=async function(_0xc51f91,..._0x152496){const _0xb34bc3=this['transaction'](_0xc51f91,_0x426f95?'readwrite':'readonly');let _0x36121c=_0xb34bc3['store'];return _0x1b88c3&&(_0x36121c=_0x36121c['index'](_0x152496['shift']())),(await Promise['all']([_0x36121c[_0x14ceaf](..._0x152496),_0x426f95&&_0xb34bc3['done']]))[0x0];};return Zn['set'](_0x4923ee,_0x201933),_0x201933;}Uc(_0xd53110=>({..._0xd53110,'get':(_0x38330e,_0x4242a0,_0x28e442)=>Os(_0x38330e,_0x4242a0)||_0xd53110['get'](_0x38330e,_0x4242a0,_0x28e442),'has':(_0x35f119,_0x302f6e)=>!!Os(_0x35f119,_0x302f6e)||_0xd53110['has'](_0x35f119,_0x302f6e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x227780){this['container']=_0x227780;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2e1678=>{if(qc(_0x2e1678)){const _0x2775ad=_0x2e1678['getImmediate']();return _0x2775ad['library']+'/'+_0x2775ad['version'];}else return null;})['filter'](_0x463f73=>_0x463f73)['join']('\x20');}}function qc(_0x36613a){const _0x234b9a=_0x36613a['getComponent']();return(_0x234b9a==null?void 0x0:_0x234b9a['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x472f7f,_0x5254d3){try{_0x472f7f['container']['addComponent'](_0x5254d3);}catch(_0x33b0b2){re['debug']('Component\x20'+_0x5254d3['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x472f7f['name'],_0x33b0b2);}}function et(_0x239bf0){const _0xb67c2c=_0x239bf0['name'];if(gi['has'](_0xb67c2c))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xb67c2c+'.'),!0x1;gi['set'](_0xb67c2c,_0x239bf0);for(const _0x5d1383 of Le['values']())Ms(_0x5d1383,_0x239bf0);for(const _0x19d58a of _i['values']())Ms(_0x19d58a,_0x239bf0);return!0x0;}function Ui(_0x544b73,_0x30e4ed){const _0x1323db=_0x544b73['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1323db&&_0x1323db['triggerHeartbeat'](),_0x544b73['container']['getProvider'](_0x30e4ed);}function H(_0x4cf491){return _0x4cf491==null?!0x1:_0x4cf491['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x14f15d,_0x5297ce,_0x280894){this['_isDeleted']=!0x1,this['_options']={..._0x14f15d},this['_config']={..._0x5297ce},this['_name']=_0x5297ce['name'],this['_automaticDataCollectionEnabled']=_0x5297ce['automaticDataCollectionEnabled'],this['_container']=_0x280894,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x112a4d){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x112a4d;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2d1b7f){this['_isDeleted']=_0x2d1b7f;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x475918,_0x2903e2={}){let _0xf832b3=_0x475918;typeof _0x2903e2!='object'&&(_0x2903e2={'name':_0x2903e2});const _0x72e1af={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x2903e2},_0x1bd7bf=_0x72e1af['name'];if(typeof _0x1bd7bf!='string'||!_0x1bd7bf)throw ge['create']('bad-app-name',{'appName':String(_0x1bd7bf)});if(_0xf832b3||(_0xf832b3=$r()),!_0xf832b3)throw ge['create']('no-options');const _0x5cf367=Le['get'](_0x1bd7bf);if(_0x5cf367){if(De(_0xf832b3,_0x5cf367['options'])&&De(_0x72e1af,_0x5cf367['config']))return _0x5cf367;throw ge['create']('duplicate-app',{'appName':_0x1bd7bf});}const _0x2e8eea=new Ac(_0x1bd7bf);for(const _0x1b8547 of gi['values']())_0x2e8eea['addComponent'](_0x1b8547);const _0x6d06b2=new Il(_0xf832b3,_0x72e1af,_0x2e8eea);return Le['set'](_0x1bd7bf,_0x6d06b2),_0x6d06b2;}function Qr(_0x31de21=pi){const _0x5ab5d6=Le['get'](_0x31de21);if(!_0x5ab5d6&&_0x31de21===pi&&$r())return wl();if(!_0x5ab5d6)throw ge['create']('no-app',{'appName':_0x31de21});return _0x5ab5d6;}function l_(){return Array['from'](Le['values']());}async function h_(_0x2d82a7){let _0x3d9af8=!0x1;const _0x1629a8=_0x2d82a7['name'];Le['has'](_0x1629a8)?(_0x3d9af8=!0x0,Le['delete'](_0x1629a8)):_i['has'](_0x1629a8)&&_0x2d82a7['decRefCount']()<=0x0&&(_i['delete'](_0x1629a8),_0x3d9af8=!0x0),_0x3d9af8&&(await Promise['all'](_0x2d82a7['container']['getProviders']()['map'](_0x2c2328=>_0x2c2328['delete']())),_0x2d82a7['isDeleted']=!0x0);}function me(_0x4f7506,_0x21994d,_0x3a6675){let _0x2e059b=vl[_0x4f7506]??_0x4f7506;_0x3a6675&&(_0x2e059b+='-'+_0x3a6675);const _0x8e97be=_0x2e059b['match'](/\s|\//),_0x84c89b=_0x21994d['match'](/\s|\//);if(_0x8e97be||_0x84c89b){const _0x2ee8d9=['Unable\x20to\x20register\x20library\x20\x22'+_0x2e059b+'\x22\x20with\x20version\x20\x22'+_0x21994d+'\x22:'];_0x8e97be&&_0x2ee8d9['push']('library\x20name\x20\x22'+_0x2e059b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x8e97be&&_0x84c89b&&_0x2ee8d9['push']('and'),_0x84c89b&&_0x2ee8d9['push']('version\x20name\x20\x22'+_0x21994d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x2ee8d9['join']('\x20'));return;}et(new Me(_0x2e059b+'-version',()=>({'library':_0x2e059b,'version':_0x21994d}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x1f1f54,_0x3e89a3)=>{switch(_0x3e89a3){case 0x0:try{_0x1f1f54['createObjectStore'](Rt);}catch(_0x28e060){console['warn'](_0x28e060);}}}})['catch'](_0x348b21=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x348b21['message']});})),ei;}async function Sl(_0x68e2e){try{const _0x4dba6d=(await Jr())['transaction'](Rt),_0x116f45=await _0x4dba6d['objectStore'](Rt)['get'](Xr(_0x68e2e));return await _0x4dba6d['done'],_0x116f45;}catch(_0x5485d4){if(_0x5485d4 instanceof Se)re['warn'](_0x5485d4['message']);else{const _0x276256=ge['create']('idb-get',{'originalErrorMessage':_0x5485d4==null?void 0x0:_0x5485d4['message']});re['warn'](_0x276256['message']);}}}async function Ls(_0x42692c,_0x145e71){try{const _0x491fe6=(await Jr())['transaction'](Rt,'readwrite');await _0x491fe6['objectStore'](Rt)['put'](_0x145e71,Xr(_0x42692c)),await _0x491fe6['done'];}catch(_0x1736c7){if(_0x1736c7 instanceof Se)re['warn'](_0x1736c7['message']);else{const _0x4e5774=ge['create']('idb-set',{'originalErrorMessage':_0x1736c7==null?void 0x0:_0x1736c7['message']});re['warn'](_0x4e5774['message']);}}}function Xr(_0x431917){return _0x431917['name']+'!'+_0x431917['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x3bee30){this['container']=_0x3bee30,this['_heartbeatsCache']=null;const _0x37d5ec=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x37d5ec),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x18ac8b=>(this['_heartbeatsCache']=_0x18ac8b,_0x18ac8b));}async['triggerHeartbeat'](){var _0x279452,_0x5917a7;try{const _0x2c7669=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4d2687=xs();if(((_0x279452=this['_heartbeatsCache'])==null?void 0x0:_0x279452['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5917a7=this['_heartbeatsCache'])==null?void 0x0:_0x5917a7['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4d2687||this['_heartbeatsCache']['heartbeats']['some'](_0x5605b1=>_0x5605b1['date']===_0x4d2687))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4d2687,'agent':_0x2c7669}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x36850b=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x36850b,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x34e70f){re['warn'](_0x34e70f);}}async['getHeartbeatsHeader'](){var _0x402a27;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x402a27=this['_heartbeatsCache'])==null?void 0x0:_0x402a27['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x132c08=xs(),{heartbeatsToSend:_0x3c874a,unsentEntries:_0x3fe619}=kl(this['_heartbeatsCache']['heartbeats']),_0x423dfa=an(JSON['stringify']({'version':0x2,'heartbeats':_0x3c874a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x132c08,_0x3fe619['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3fe619,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x423dfa;}catch(_0x2bfe4d){return re['warn'](_0x2bfe4d),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x7644a6,_0xcf4a28=bl){const _0x53385a=[];let _0x225e3e=_0x7644a6['slice']();for(const _0x3751f4 of _0x7644a6){const _0x50a716=_0x53385a['find'](_0xe81441=>_0xe81441['agent']===_0x3751f4['agent']);if(_0x50a716){if(_0x50a716['dates']['push'](_0x3751f4['date']),Fs(_0x53385a)>_0xcf4a28){_0x50a716['dates']['pop']();break;}}else{if(_0x53385a['push']({'agent':_0x3751f4['agent'],'dates':[_0x3751f4['date']]}),Fs(_0x53385a)>_0xcf4a28){_0x53385a['pop']();break;}}_0x225e3e=_0x225e3e['slice'](0x1);}return{'heartbeatsToSend':_0x53385a,'unsentEntries':_0x225e3e};}class Nl{constructor(_0x505878){this['app']=_0x505878,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1d174d=await Sl(this['app']);return _0x1d174d!=null&&_0x1d174d['heartbeats']?_0x1d174d:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x23c27c){if(await this['_canUseIndexedDBPromise']){const _0x3f8694=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x23c27c['lastSentHeartbeatDate']??_0x3f8694['lastSentHeartbeatDate'],'heartbeats':_0x23c27c['heartbeats']});}else return;}async['add'](_0x36b3de){if(await this['_canUseIndexedDBPromise']){const _0x29407a=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x36b3de['lastSentHeartbeatDate']??_0x29407a['lastSentHeartbeatDate'],'heartbeats':[..._0x29407a['heartbeats'],..._0x36b3de['heartbeats']]});}else return;}}function Fs(_0x160a6b){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x160a6b}))['length'];}function Pl(_0xfce5c3){if(_0xfce5c3['length']===0x0)return-0x1;let _0x4c3e74=0x0,_0x30463e=_0xfce5c3[0x0]['date'];for(let _0x341514=0x1;_0x341514<_0xfce5c3['length'];_0x341514++)_0xfce5c3[_0x341514]['date']<_0x30463e&&(_0x30463e=_0xfce5c3[_0x341514]['date'],_0x4c3e74=_0x341514);return _0x4c3e74;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x382b0c){et(new Me('platform-logger',_0x1e698f=>new Gc(_0x1e698f),'PRIVATE')),et(new Me('heartbeat',_0x430482=>new Al(_0x430482),'PRIVATE')),me(fi,Ds,_0x382b0c),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x298652){Zr=_0x298652;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x421dc2){this['domStorage_']=_0x421dc2,this['prefix_']='firebase:';}['set'](_0x5be7e4,_0x44aa50){_0x44aa50==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5be7e4)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5be7e4),O(_0x44aa50));}['get'](_0x13f570){const _0x221f05=this['domStorage_']['getItem'](this['prefixedName_'](_0x13f570));return _0x221f05==null?null:bt(_0x221f05);}['remove'](_0x3df62e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3df62e));}['prefixedName_'](_0x40931b){return this['prefix_']+_0x40931b;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x46864f,_0x23e996){_0x23e996==null?delete this['cache_'][_0x46864f]:this['cache_'][_0x46864f]=_0x23e996;}['get'](_0x31858d){return Y(this['cache_'],_0x31858d)?this['cache_'][_0x31858d]:null;}['remove'](_0x1882fb){delete this['cache_'][_0x1882fb];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x3387cc){try{if(typeof window<'u'&&typeof window[_0x3387cc]<'u'){const _0x271d4c=window[_0x3387cc];return _0x271d4c['setItem']('firebase:sentinel','cache'),_0x271d4c['removeItem']('firebase:sentinel'),new xl(_0x271d4c);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x46312b=0x1;return function(){return _0x46312b++;};}()),no=function(_0x59644d){const _0xfd975f=Tc(_0x59644d),_0x2709b5=new Ec();_0x2709b5['update'](_0xfd975f);const _0x40ef7b=_0x2709b5['digest']();return Di['encodeByteArray'](_0x40ef7b);},Bt=function(..._0x7e3fef){let _0x20e4cb='';for(let _0x4dcbf2=0x0;_0x4dcbf2<_0x7e3fef['length'];_0x4dcbf2++){const _0x7a6abe=_0x7e3fef[_0x4dcbf2];Array['isArray'](_0x7a6abe)||_0x7a6abe&&typeof _0x7a6abe=='object'&&typeof _0x7a6abe['length']=='number'?_0x20e4cb+=Bt['apply'](null,_0x7a6abe):typeof _0x7a6abe=='object'?_0x20e4cb+=O(_0x7a6abe):_0x20e4cb+=_0x7a6abe,_0x20e4cb+='\x20';}return _0x20e4cb;};let Et=null,Vs=!0x0;const Wl=function(_0xa02cc2,_0x13e949){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x5d9ae2){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x2d1fc0=Bt['apply'](null,_0x5d9ae2);Et(_0x2d1fc0);}},Vt=function(_0x20a5a5){return function(..._0x28698f){L(_0x20a5a5,..._0x28698f);};},mi=function(..._0x38acd0){const _0x24283e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x38acd0);Qe['error'](_0x24283e);},oe=function(..._0x26e393){const _0x2c0fe8='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x26e393);throw Qe['error'](_0x2c0fe8),new Error(_0x2c0fe8);},U=function(..._0x1c3732){const _0x115c05='FIREBASE\x20WARNING:\x20'+Bt(..._0x1c3732);Qe['warn'](_0x115c05);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x5b26da){return typeof _0x5b26da=='number'&&(_0x5b26da!==_0x5b26da||_0x5b26da===Number['POSITIVE_INFINITY']||_0x5b26da===Number['NEGATIVE_INFINITY']);},Vl=function(_0x24c96e){if(document['readyState']==='complete')_0x24c96e();else{let _0x3d68f4=!0x1;const _0x2e6f29=function(){if(!document['body']){setTimeout(_0x2e6f29,Math['floor'](0xa));return;}_0x3d68f4||(_0x3d68f4=!0x0,_0x24c96e());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2e6f29,!0x1),window['addEventListener']('load',_0x2e6f29,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2e6f29();}),window['attachEvent']('onload',_0x2e6f29));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4c9e93,_0x2d659c){if(_0x4c9e93===_0x2d659c)return 0x0;if(_0x4c9e93===xe||_0x2d659c===Ie)return-0x1;if(_0x2d659c===xe||_0x4c9e93===Ie)return 0x1;{const _0xd62482=Hs(_0x4c9e93),_0x53e056=Hs(_0x2d659c);return _0xd62482!==null?_0x53e056!==null?_0xd62482-_0x53e056===0x0?_0x4c9e93['length']-_0x2d659c['length']:_0xd62482-_0x53e056:-0x1:_0x53e056!==null?0x1:_0x4c9e93<_0x2d659c?-0x1:0x1;}},Hl=function(_0x314649,_0x2fcfba){return _0x314649===_0x2fcfba?0x0:_0x314649<_0x2fcfba?-0x1:0x1;},pt=function(_0x2393fc,_0xfee32e){if(_0xfee32e&&_0x2393fc in _0xfee32e)return _0xfee32e[_0x2393fc];throw new Error('Missing\x20required\x20key\x20('+_0x2393fc+')\x20in\x20object:\x20'+O(_0xfee32e));},Bi=function(_0x239c4e){if(typeof _0x239c4e!='object'||_0x239c4e===null)return O(_0x239c4e);const _0x217077=[];for(const _0x3c0bd9 in _0x239c4e)_0x217077['push'](_0x3c0bd9);_0x217077['sort']();let _0x49155d='{';for(let _0x405411=0x0;_0x405411<_0x217077['length'];_0x405411++)_0x405411!==0x0&&(_0x49155d+=','),_0x49155d+=O(_0x217077[_0x405411]),_0x49155d+=':',_0x49155d+=Bi(_0x239c4e[_0x217077[_0x405411]]);return _0x49155d+='}',_0x49155d;},io=function(_0x2f46ea,_0x10ab07){const _0x4bc611=_0x2f46ea['length'];if(_0x4bc611<=_0x10ab07)return[_0x2f46ea];const _0x47b3f4=[];for(let _0x31e08f=0x0;_0x31e08f<_0x4bc611;_0x31e08f+=_0x10ab07)_0x31e08f+_0x10ab07>_0x4bc611?_0x47b3f4['push'](_0x2f46ea['substring'](_0x31e08f,_0x4bc611)):_0x47b3f4['push'](_0x2f46ea['substring'](_0x31e08f,_0x31e08f+_0x10ab07));return _0x47b3f4;};function x(_0x49fd85,_0x30a6ba){for(const _0x5350ca in _0x49fd85)_0x49fd85['hasOwnProperty'](_0x5350ca)&&_0x30a6ba(_0x5350ca,_0x49fd85[_0x5350ca]);}const so=function(_0x5d1dea){f(!Wi(_0x5d1dea),'Invalid\x20JSON\x20number');const _0x11b870=0xb,_0x5d6c34=0x34,_0x4d8116=(0x1<<_0x11b870-0x1)-0x1;let _0x176f57,_0x332085,_0x29b4b1,_0x236c89,_0x2775d0;_0x5d1dea===0x0?(_0x332085=0x0,_0x29b4b1=0x0,_0x176f57=0x1/_0x5d1dea===-0x1/0x0?0x1:0x0):(_0x176f57=_0x5d1dea<0x0,_0x5d1dea=Math['abs'](_0x5d1dea),_0x5d1dea>=Math['pow'](0x2,0x1-_0x4d8116)?(_0x236c89=Math['min'](Math['floor'](Math['log'](_0x5d1dea)/Math['LN2']),_0x4d8116),_0x332085=_0x236c89+_0x4d8116,_0x29b4b1=Math['round'](_0x5d1dea*Math['pow'](0x2,_0x5d6c34-_0x236c89)-Math['pow'](0x2,_0x5d6c34))):(_0x332085=0x0,_0x29b4b1=Math['round'](_0x5d1dea/Math['pow'](0x2,0x1-_0x4d8116-_0x5d6c34))));const _0x980593=[];for(_0x2775d0=_0x5d6c34;_0x2775d0;_0x2775d0-=0x1)_0x980593['push'](_0x29b4b1%0x2?0x1:0x0),_0x29b4b1=Math['floor'](_0x29b4b1/0x2);for(_0x2775d0=_0x11b870;_0x2775d0;_0x2775d0-=0x1)_0x980593['push'](_0x332085%0x2?0x1:0x0),_0x332085=Math['floor'](_0x332085/0x2);_0x980593['push'](_0x176f57?0x1:0x0),_0x980593['reverse']();const _0xfe5354=_0x980593['join']('');let _0x3a8b22='';for(_0x2775d0=0x0;_0x2775d0<0x40;_0x2775d0+=0x8){let _0x3e25b0=parseInt(_0xfe5354['substr'](_0x2775d0,0x8),0x2)['toString'](0x10);_0x3e25b0['length']===0x1&&(_0x3e25b0='0'+_0x3e25b0),_0x3a8b22=_0x3a8b22+_0x3e25b0;}return _0x3a8b22['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x2902d4,_0x52ea59){let _0x862aff='Unknown\x20Error';_0x2902d4==='too_big'?_0x862aff='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2902d4==='permission_denied'?_0x862aff='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2902d4==='unavailable'&&(_0x862aff='The\x20service\x20is\x20unavailable');const _0xf73ab4=new Error(_0x2902d4+'\x20at\x20'+_0x52ea59['_path']['toString']()+':\x20'+_0x862aff);return _0xf73ab4['code']=_0x2902d4['toUpperCase'](),_0xf73ab4;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x13e182){if(zl['test'](_0x13e182)){const _0xf15776=Number(_0x13e182);if(_0xf15776>=jl&&_0xf15776<=Kl)return _0xf15776;}return null;},lt=function(_0x42b2b5){try{_0x42b2b5();}catch(_0x5daa40){setTimeout(()=>{const _0x191a47=_0x5daa40['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x191a47),_0x5daa40;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x8534a7,_0x171b74){const _0x4f7435=setTimeout(_0x8534a7,_0x171b74);return typeof _0x4f7435=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4f7435):typeof _0x4f7435=='object'&&_0x4f7435['unref']&&_0x4f7435['unref'](),_0x4f7435;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x235452,_0x1f2a8f){this['appCheckProvider']=_0x1f2a8f,this['appName']=_0x235452['name'],H(_0x235452)&&_0x235452['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x235452['settings']['appCheckToken']),this['appCheck']=_0x1f2a8f==null?void 0x0:_0x1f2a8f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1f2a8f==null||_0x1f2a8f['get']()['then'](_0x1ae9fb=>this['appCheck']=_0x1ae9fb);}['getToken'](_0x23dbf5){if(this['serverAppAppCheckToken']){if(_0x23dbf5)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x23dbf5):new Promise((_0x25c507,_0x19cc3c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x23dbf5)['then'](_0x25c507,_0x19cc3c):_0x25c507(null);},0x0);});}['addTokenChangeListener'](_0x1b4832){var _0x21478b;(_0x21478b=this['appCheckProvider'])==null||_0x21478b['get']()['then'](_0x2cbd69=>_0x2cbd69['addTokenListener'](_0x1b4832));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x42adc7,_0x23f020,_0x1b6297){this['appName_']=_0x42adc7,this['firebaseOptions_']=_0x23f020,this['authProvider_']=_0x1b6297,this['auth_']=null,this['auth_']=_0x1b6297['getImmediate']({'optional':!0x0}),this['auth_']||_0x1b6297['onInit'](_0x10de15=>this['auth_']=_0x10de15);}['getToken'](_0x5c864e){return this['auth_']?this['auth_']['getToken'](_0x5c864e)['catch'](_0x4ac800=>_0x4ac800&&_0x4ac800['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4ac800)):new Promise((_0x53e876,_0x2319ef)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x5c864e)['then'](_0x53e876,_0x2319ef):_0x53e876(null);},0x0);});}['addTokenChangeListener'](_0x3583c8){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3583c8):this['authProvider_']['get']()['then'](_0x700983=>_0x700983['addAuthTokenListener'](_0x3583c8));}['removeTokenChangeListener'](_0x557ca7){this['authProvider_']['get']()['then'](_0x5f044d=>_0x5f044d['removeAuthTokenListener'](_0x557ca7));}['notifyForInvalidToken'](){let _0x2267f5='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2267f5+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2267f5+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2267f5+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2267f5);}}class tn{constructor(_0x1920d9){this['accessToken']=_0x1920d9;}['getToken'](_0x84b312){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1c1eb5){_0x1c1eb5(this['accessToken']);}['removeTokenChangeListener'](_0x1423c2){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x144069,_0x317283,_0x444b42,_0x34f008,_0x200221=!0x1,_0x355e29='',_0x862e54=!0x1,_0x4b41c5=!0x1,_0x5acf45=null){this['secure']=_0x317283,this['namespace']=_0x444b42,this['webSocketOnly']=_0x34f008,this['nodeAdmin']=_0x200221,this['persistenceKey']=_0x355e29,this['includeNamespaceInQueryParams']=_0x862e54,this['isUsingEmulator']=_0x4b41c5,this['emulatorOptions']=_0x5acf45,this['_host']=_0x144069['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x144069)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2ba787){_0x2ba787!==this['internalHost']&&(this['internalHost']=_0x2ba787,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x543398=this['toURLString']();return this['persistenceKey']&&(_0x543398+='<'+this['persistenceKey']+'>'),_0x543398;}['toURLString'](){const _0xd70e7a=this['secure']?'https://':'http://',_0x454423=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xd70e7a+this['host']+'/'+_0x454423;}}function Xl(_0x5a480f){return _0x5a480f['host']!==_0x5a480f['internalHost']||_0x5a480f['isCustomHost']()||_0x5a480f['includeNamespaceInQueryParams'];}function go(_0x2c3456,_0x25ecb5,_0xcacc2c){f(typeof _0x25ecb5=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xcacc2c=='object','typeof\x20params\x20must\x20==\x20object');let _0x22b725;if(_0x25ecb5===fo)_0x22b725=(_0x2c3456['secure']?'wss://':'ws://')+_0x2c3456['internalHost']+'/.ws?';else{if(_0x25ecb5===po)_0x22b725=(_0x2c3456['secure']?'https://':'http://')+_0x2c3456['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x25ecb5);}Xl(_0x2c3456)&&(_0xcacc2c['ns']=_0x2c3456['namespace']);const _0x5a9820=[];return x(_0xcacc2c,(_0x464453,_0x3447f7)=>{_0x5a9820['push'](_0x464453+'='+_0x3447f7);}),_0x22b725+_0x5a9820['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x477b95,_0xe0894a=0x1){Y(this['counters_'],_0x477b95)||(this['counters_'][_0x477b95]=0x0),this['counters_'][_0x477b95]+=_0xe0894a;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x5378c8){const _0xd055bc=_0x5378c8['toString']();return ti[_0xd055bc]||(ti[_0xd055bc]=new Zl()),ti[_0xd055bc];}function eh(_0x54eff2,_0x227071){const _0xac65f2=_0x54eff2['toString']();return ni[_0xac65f2]||(ni[_0xac65f2]=_0x227071()),ni[_0xac65f2];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x22c438){this['onMessage_']=_0x22c438,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5c63b0,_0x240816){this['closeAfterResponse']=_0x5c63b0,this['onClose']=_0x240816,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x15a5c7,_0x4733c3){for(this['pendingResponses'][_0x15a5c7]=_0x4733c3;this['pendingResponses'][this['currentResponseNum']];){const _0x13fc7a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x280676=0x0;_0x280676<_0x13fc7a['length'];++_0x280676)_0x13fc7a[_0x280676]&&lt(()=>{this['onMessage_'](_0x13fc7a[_0x280676]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x53f5b3,_0x510bfe,_0x4dbfd9,_0x216eca,_0xcb95b6,_0x4fd2f5,_0x98ba70){this['connId']=_0x53f5b3,this['repoInfo']=_0x510bfe,this['applicationId']=_0x4dbfd9,this['appCheckToken']=_0x216eca,this['authToken']=_0xcb95b6,this['transportSessionId']=_0x4fd2f5,this['lastSessionId']=_0x98ba70,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x53f5b3),this['stats_']=Hi(_0x510bfe),this['urlFn']=_0x569061=>(this['appCheckToken']&&(_0x569061[yi]=this['appCheckToken']),go(_0x510bfe,po,_0x569061));}['open'](_0x5aa20f,_0x11ee40){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x11ee40,this['myPacketOrderer']=new th(_0x5aa20f),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x125b3f)=>{const [_0x53697a,_0x3dea8c,_0x19ee5c,_0x8e36f7,_0x787219]=_0x125b3f;if(this['incrementIncomingBytes_'](_0x125b3f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x53697a===$s)this['id']=_0x3dea8c,this['password']=_0x19ee5c;else{if(_0x53697a===nh)_0x3dea8c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3dea8c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x53697a);}}},(..._0xdfa2ae)=>{const [_0x38aae7,_0x9e7fb8]=_0xdfa2ae;this['incrementIncomingBytes_'](_0xdfa2ae),this['myPacketOrderer']['handleResponse'](_0x38aae7,_0x9e7fb8);},()=>{this['onClosed_']();},this['urlFn']);const _0x49dddd={};_0x49dddd[$s]='t',_0x49dddd[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x49dddd[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x49dddd[ro]=Vi,this['transportSessionId']&&(_0x49dddd[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x49dddd[ho]=this['lastSessionId']),this['applicationId']&&(_0x49dddd[uo]=this['applicationId']),this['appCheckToken']&&(_0x49dddd[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x49dddd[ao]=co);const _0x10772a=this['urlFn'](_0x49dddd);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x10772a),this['scriptTagHolder']['addTag'](_0x10772a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2f5e53){const _0x4b6eb9=O(_0x2f5e53);this['bytesSent']+=_0x4b6eb9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4b6eb9['length']);const _0x4b2561=Br(_0x4b6eb9),_0x270db7=io(_0x4b2561,hh);for(let _0x25a1c6=0x0;_0x25a1c6<_0x270db7['length'];_0x25a1c6++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x270db7['length'],_0x270db7[_0x25a1c6]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x23469b,_0x48917b){this['myDisconnFrame']=document['createElement']('iframe');const _0x349a8c={};_0x349a8c[lh]='t',_0x349a8c[mo]=_0x23469b,_0x349a8c[yo]=_0x48917b,this['myDisconnFrame']['src']=this['urlFn'](_0x349a8c),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x223de8){const _0x49eab7=O(_0x223de8)['length'];this['bytesReceived']+=_0x49eab7,this['stats_']['incrementCounter']('bytes_received',_0x49eab7);}}class $i{constructor(_0x2b456b,_0x4dc5a3,_0xf2693b,_0x3804fd){this['onDisconnect']=_0xf2693b,this['urlFn']=_0x3804fd,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x2b456b,window[sh+this['uniqueCallbackIdentifier']]=_0x4dc5a3,this['myIFrame']=$i['createIFrame_']();let _0x50613d='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x50613d='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1c752e='<html><body>'+_0x50613d+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1c752e),this['myIFrame']['doc']['close']();}catch(_0x378819){L('frame\x20writing\x20exception'),_0x378819['stack']&&L(_0x378819['stack']),L(_0x378819);}}}static['createIFrame_'](){const _0x499315=document['createElement']('iframe');if(_0x499315['style']['display']='none',document['body']){document['body']['appendChild'](_0x499315);try{_0x499315['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x40f6ec=document['domain'];_0x499315['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x40f6ec+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x499315['contentDocument']?_0x499315['doc']=_0x499315['contentDocument']:_0x499315['contentWindow']?_0x499315['doc']=_0x499315['contentWindow']['document']:_0x499315['document']&&(_0x499315['doc']=_0x499315['document']),_0x499315;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0xd2beb5=this['onDisconnect'];_0xd2beb5&&(this['onDisconnect']=null,_0xd2beb5());}['startLongPoll'](_0x490b45,_0x2c81e6){for(this['myID']=_0x490b45,this['myPW']=_0x2c81e6,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1ec353={};_0x1ec353[mo]=this['myID'],_0x1ec353[yo]=this['myPW'],_0x1ec353[vo]=this['currentSerial'];let _0x5b4a95=this['urlFn'](_0x1ec353),_0x5c9cdb='',_0x5e76ba=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x5c9cdb['length']<=Eo;){const _0x5280f1=this['pendingSegs']['shift']();_0x5c9cdb=_0x5c9cdb+'&'+oh+_0x5e76ba+'='+_0x5280f1['seg']+'&'+ah+_0x5e76ba+'='+_0x5280f1['ts']+'&'+ch+_0x5e76ba+'='+_0x5280f1['d'],_0x5e76ba++;}return _0x5b4a95=_0x5b4a95+_0x5c9cdb,this['addLongPollTag_'](_0x5b4a95,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x300996,_0x4da41f,_0x3f3883){this['pendingSegs']['push']({'seg':_0x300996,'ts':_0x4da41f,'d':_0x3f3883}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x193269,_0x54d293){this['outstandingRequests']['add'](_0x54d293);const _0x77b750=()=>{this['outstandingRequests']['delete'](_0x54d293),this['newRequest_']();},_0x278152=setTimeout(_0x77b750,Math['floor'](uh)),_0x151047=()=>{clearTimeout(_0x278152),_0x77b750();};this['addTag'](_0x193269,_0x151047);}['addTag'](_0x3d1988,_0x3e8a75){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x36e072=this['myIFrame']['doc']['createElement']('script');_0x36e072['type']='text/javascript',_0x36e072['async']=!0x0,_0x36e072['src']=_0x3d1988,_0x36e072['onload']=_0x36e072['onreadystatechange']=function(){const _0x45e35d=_0x36e072['readyState'];(!_0x45e35d||_0x45e35d==='loaded'||_0x45e35d==='complete')&&(_0x36e072['onload']=_0x36e072['onreadystatechange']=null,_0x36e072['parentNode']&&_0x36e072['parentNode']['removeChild'](_0x36e072),_0x3e8a75());},_0x36e072['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3d1988),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x36e072);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x138cf4,_0x5eb1e6,_0xc1b02e,_0x5a4739,_0x47e1d8,_0x43dccf,_0x50e0a6){this['connId']=_0x138cf4,this['applicationId']=_0xc1b02e,this['appCheckToken']=_0x5a4739,this['authToken']=_0x47e1d8,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x5eb1e6),this['connURL']=G['connectionURL_'](_0x5eb1e6,_0x43dccf,_0x50e0a6,_0x5a4739,_0xc1b02e),this['nodeAdmin']=_0x5eb1e6['nodeAdmin'];}static['connectionURL_'](_0x151f40,_0x21c5a1,_0x196ba2,_0x117c93,_0x1d7d33){const _0x56682c={};return _0x56682c[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x56682c[ao]=co),_0x21c5a1&&(_0x56682c[oo]=_0x21c5a1),_0x196ba2&&(_0x56682c[ho]=_0x196ba2),_0x117c93&&(_0x56682c[yi]=_0x117c93),_0x1d7d33&&(_0x56682c[uo]=_0x1d7d33),go(_0x151f40,fo,_0x56682c);}['open'](_0x5dd2eb,_0x14e068){this['onDisconnect']=_0x14e068,this['onMessage']=_0x5dd2eb,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x6d2bc;dc(),this['mySock']=new hn(this['connURL'],[],_0x6d2bc);}catch(_0x4c8e10){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1b774a=_0x4c8e10['message']||_0x4c8e10['data'];_0x1b774a&&this['log_'](_0x1b774a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3e80ad=>{this['handleIncomingFrame'](_0x3e80ad);},this['mySock']['onerror']=_0xe9d2a9=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x503f3f=_0xe9d2a9['message']||_0xe9d2a9['data'];_0x503f3f&&this['log_'](_0x503f3f),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4a6e50=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xbe50e6=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x5dafcc=navigator['userAgent']['match'](_0xbe50e6);_0x5dafcc&&_0x5dafcc['length']>0x1&&parseFloat(_0x5dafcc[0x1])<4.4&&(_0x4a6e50=!0x0);}return!_0x4a6e50&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x253cd5){if(this['frames']['push'](_0x253cd5),this['frames']['length']===this['totalFrames']){const _0x3874c7=this['frames']['join']('');this['frames']=null;const _0x4398c9=bt(_0x3874c7);this['onMessage'](_0x4398c9);}}['handleNewFrameCount_'](_0x568a9e){this['totalFrames']=_0x568a9e,this['frames']=[];}['extractFrameCount_'](_0x17da92){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x17da92['length']<=0x6){const _0x485ece=Number(_0x17da92);if(!isNaN(_0x485ece))return this['handleNewFrameCount_'](_0x485ece),null;}return this['handleNewFrameCount_'](0x1),_0x17da92;}['handleIncomingFrame'](_0x3ab0f4){if(this['mySock']===null)return;const _0x1b81a8=_0x3ab0f4['data'];if(this['bytesReceived']+=_0x1b81a8['length'],this['stats_']['incrementCounter']('bytes_received',_0x1b81a8['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1b81a8);else{const _0x124037=this['extractFrameCount_'](_0x1b81a8);_0x124037!==null&&this['appendFrame_'](_0x124037);}}['send'](_0x312ee8){this['resetKeepAlive']();const _0x5e9949=O(_0x312ee8);this['bytesSent']+=_0x5e9949['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5e9949['length']);const _0x2c1caf=io(_0x5e9949,fh);_0x2c1caf['length']>0x1&&this['sendString_'](String(_0x2c1caf['length']));for(let _0x3be6e8=0x0;_0x3be6e8<_0x2c1caf['length'];_0x3be6e8++)this['sendString_'](_0x2c1caf[_0x3be6e8]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x440a3a){try{this['mySock']['send'](_0x440a3a);}catch(_0x1e5585){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1e5585['message']||_0x1e5585['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x38e98a){this['initTransports_'](_0x38e98a);}['initTransports_'](_0x200f5e){const _0x229951=G&&G['isAvailable']();let _0x271b02=_0x229951&&!G['previouslyFailed']();if(_0x200f5e['webSocketOnly']&&(_0x229951||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x271b02=!0x0),_0x271b02)this['transports_']=[G];else{const _0x57afcc=this['transports_']=[];for(const _0x265698 of At['ALL_TRANSPORTS'])_0x265698&&_0x265698['isAvailable']()&&_0x57afcc['push'](_0x265698);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x436b63,_0x17d38f,_0x41f26a,_0x3380f1,_0xfb9b76,_0x23d998,_0x4456da,_0x3ad3d6,_0x192e9f,_0x4f0671){this['id']=_0x436b63,this['repoInfo_']=_0x17d38f,this['applicationId_']=_0x41f26a,this['appCheckToken_']=_0x3380f1,this['authToken_']=_0xfb9b76,this['onMessage_']=_0x23d998,this['onReady_']=_0x4456da,this['onDisconnect_']=_0x3ad3d6,this['onKill_']=_0x192e9f,this['lastSessionId']=_0x4f0671,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x17d38f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2e8637=this['transportManager_']['initialTransport']();this['conn_']=new _0x2e8637(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2e8637['responsesRequiredToBeHealthy']||0x0;const _0x22c10d=this['connReceiver_'](this['conn_']),_0x397e86=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x22c10d,_0x397e86);},Math['floor'](0x0));const _0x14276e=_0x2e8637['healthyTimeout']||0x0;_0x14276e>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x14276e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x37f487){return _0x3d9f7e=>{_0x37f487===this['conn_']?this['onConnectionLost_'](_0x3d9f7e):_0x37f487===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5b28b9){return _0xcf8317=>{this['state_']!==0x2&&(_0x5b28b9===this['rx_']?this['onPrimaryMessageReceived_'](_0xcf8317):_0x5b28b9===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xcf8317):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x47126c){const _0x2f2c17={'t':'d','d':_0x47126c};this['sendData_'](_0x2f2c17);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2e6f54){if(ii in _0x2e6f54){const _0x126695=_0x2e6f54[ii];_0x126695===js?this['upgradeIfSecondaryHealthy_']():_0x126695===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x126695===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3ff61f){const _0x15f9ff=pt('t',_0x3ff61f),_0x532e47=pt('d',_0x3ff61f);if(_0x15f9ff==='c')this['onSecondaryControl_'](_0x532e47);else{if(_0x15f9ff==='d')this['pendingDataMessages']['push'](_0x532e47);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x15f9ff);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x1a36e5){const _0x4b5246=pt('t',_0x1a36e5),_0x11a650=pt('d',_0x1a36e5);_0x4b5246==='c'?this['onControl_'](_0x11a650):_0x4b5246==='d'&&this['onDataMessage_'](_0x11a650);}['onDataMessage_'](_0x296945){this['onPrimaryResponse_'](),this['onMessage_'](_0x296945);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0xe72bdb){const _0x40153e=pt(ii,_0xe72bdb);if(Gs in _0xe72bdb){const _0x57fc43=_0xe72bdb[Gs];if(_0x40153e===Ih){const _0x10cf3f={..._0x57fc43};this['repoInfo_']['isUsingEmulator']&&(_0x10cf3f['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x10cf3f);}else{if(_0x40153e===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x402f8e=0x0;_0x402f8e<this['pendingDataMessages']['length'];++_0x402f8e)this['onDataMessage_'](this['pendingDataMessages'][_0x402f8e]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x40153e===vh?this['onConnectionShutdown_'](_0x57fc43):_0x40153e===qs?this['onReset_'](_0x57fc43):_0x40153e===Eh?mi('Server\x20Error:\x20'+_0x57fc43):_0x40153e===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x40153e);}}}['onHandshake_'](_0x159929){const _0x307dc3=_0x159929['ts'],_0x5f03b4=_0x159929['v'],_0x384ce9=_0x159929['h'];this['sessionId']=_0x159929['s'],this['repoInfo_']['host']=_0x384ce9,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x307dc3),Vi!==_0x5f03b4&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x424494=this['transportManager_']['upgradeTransport']();_0x424494&&this['startUpgrade_'](_0x424494);}['startUpgrade_'](_0x1a6acf){this['secondaryConn_']=new _0x1a6acf(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1a6acf['responsesRequiredToBeHealthy']||0x0;const _0x35dd1b=this['connReceiver_'](this['secondaryConn_']),_0x39da3c=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x35dd1b,_0x39da3c),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x1467b7){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1467b7),this['repoInfo_']['host']=_0x1467b7,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1c7c30,_0x28f91b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1c7c30,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x28f91b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x137cf0=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x137cf0||this['rx_']===_0x137cf0)&&this['close']();}['onConnectionLost_'](_0x24aed3){this['conn_']=null,!_0x24aed3&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x463db9){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x463db9),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xfdf7fa){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xfdf7fa);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x170249,_0x4eb79a,_0x1212ca,_0x34aefe){}['merge'](_0x548080,_0x485d69,_0x110d9a,_0x1876ba){}['refreshAuthToken'](_0x4ff381){}['refreshAppCheckToken'](_0x53e2a1){}['onDisconnectPut'](_0x4da90b,_0x17dc44,_0x923859){}['onDisconnectMerge'](_0x5f27d3,_0x36d114,_0xd55f3c){}['onDisconnectCancel'](_0x20c2d6,_0x4bc6ec){}['reportStats'](_0x4fa776){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x23f449){this['allowedEvents_']=_0x23f449,this['listeners_']={},f(Array['isArray'](_0x23f449)&&_0x23f449['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x58bd98,..._0x5b3e0b){if(Array['isArray'](this['listeners_'][_0x58bd98])){const _0x5ea906=[...this['listeners_'][_0x58bd98]];for(let _0x2a91b6=0x0;_0x2a91b6<_0x5ea906['length'];_0x2a91b6++)_0x5ea906[_0x2a91b6]['callback']['apply'](_0x5ea906[_0x2a91b6]['context'],_0x5b3e0b);}}['on'](_0x18693e,_0x2e37e9,_0x1973c3){this['validateEventType_'](_0x18693e),this['listeners_'][_0x18693e]=this['listeners_'][_0x18693e]||[],this['listeners_'][_0x18693e]['push']({'callback':_0x2e37e9,'context':_0x1973c3});const _0x1cb7dc=this['getInitialEvent'](_0x18693e);_0x1cb7dc&&_0x2e37e9['apply'](_0x1973c3,_0x1cb7dc);}['off'](_0xdce810,_0x2c4304,_0x569bcc){this['validateEventType_'](_0xdce810);const _0x428497=this['listeners_'][_0xdce810]||[];for(let _0x19b284=0x0;_0x19b284<_0x428497['length'];_0x19b284++)if(_0x428497[_0x19b284]['callback']===_0x2c4304&&(!_0x569bcc||_0x569bcc===_0x428497[_0x19b284]['context'])){_0x428497['splice'](_0x19b284,0x1);return;}}['validateEventType_'](_0x177083){f(this['allowedEvents_']['find'](_0xbd4166=>_0xbd4166===_0x177083),'Unknown\x20event:\x20'+_0x177083);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1e0f62){return f(_0x1e0f62==='online','Unknown\x20event\x20type:\x20'+_0x1e0f62),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x57829d,_0x472210){if(_0x472210===void 0x0){this['pieces_']=_0x57829d['split']('/');let _0x58b239=0x0;for(let _0x569ce3=0x0;_0x569ce3<this['pieces_']['length'];_0x569ce3++)this['pieces_'][_0x569ce3]['length']>0x0&&(this['pieces_'][_0x58b239]=this['pieces_'][_0x569ce3],_0x58b239++);this['pieces_']['length']=_0x58b239,this['pieceNum_']=0x0;}else this['pieces_']=_0x57829d,this['pieceNum_']=_0x472210;}['toString'](){let _0x3d7f65='';for(let _0x47608b=this['pieceNum_'];_0x47608b<this['pieces_']['length'];_0x47608b++)this['pieces_'][_0x47608b]!==''&&(_0x3d7f65+='/'+this['pieces_'][_0x47608b]);return _0x3d7f65||'/';}}function w(){return new C('');}function y(_0x306555){return _0x306555['pieceNum_']>=_0x306555['pieces_']['length']?null:_0x306555['pieces_'][_0x306555['pieceNum_']];}function we(_0x4dd9fe){return _0x4dd9fe['pieces_']['length']-_0x4dd9fe['pieceNum_'];}function b(_0x4f609f){let _0x14a0bc=_0x4f609f['pieceNum_'];return _0x14a0bc<_0x4f609f['pieces_']['length']&&_0x14a0bc++,new C(_0x4f609f['pieces_'],_0x14a0bc);}function Gi(_0x4f00e5){return _0x4f00e5['pieceNum_']<_0x4f00e5['pieces_']['length']?_0x4f00e5['pieces_'][_0x4f00e5['pieces_']['length']-0x1]:null;}function Ch(_0x225007){let _0x52303a='';for(let _0xbc08d0=_0x225007['pieceNum_'];_0xbc08d0<_0x225007['pieces_']['length'];_0xbc08d0++)_0x225007['pieces_'][_0xbc08d0]!==''&&(_0x52303a+='/'+encodeURIComponent(String(_0x225007['pieces_'][_0xbc08d0])));return _0x52303a||'/';}function kt(_0x4e65a5,_0x3b6620=0x0){return _0x4e65a5['pieces_']['slice'](_0x4e65a5['pieceNum_']+_0x3b6620);}function To(_0x58e7b6){if(_0x58e7b6['pieceNum_']>=_0x58e7b6['pieces_']['length'])return null;const _0xfae075=[];for(let _0x28bde5=_0x58e7b6['pieceNum_'];_0x28bde5<_0x58e7b6['pieces_']['length']-0x1;_0x28bde5++)_0xfae075['push'](_0x58e7b6['pieces_'][_0x28bde5]);return new C(_0xfae075,0x0);}function A(_0x2a37ff,_0x31e492){const _0x1cbab3=[];for(let _0x4cac15=_0x2a37ff['pieceNum_'];_0x4cac15<_0x2a37ff['pieces_']['length'];_0x4cac15++)_0x1cbab3['push'](_0x2a37ff['pieces_'][_0x4cac15]);if(_0x31e492 instanceof C){for(let _0x2cc475=_0x31e492['pieceNum_'];_0x2cc475<_0x31e492['pieces_']['length'];_0x2cc475++)_0x1cbab3['push'](_0x31e492['pieces_'][_0x2cc475]);}else{const _0x4c7ee0=_0x31e492['split']('/');for(let _0x32e743=0x0;_0x32e743<_0x4c7ee0['length'];_0x32e743++)_0x4c7ee0[_0x32e743]['length']>0x0&&_0x1cbab3['push'](_0x4c7ee0[_0x32e743]);}return new C(_0x1cbab3,0x0);}function v(_0x4a23e2){return _0x4a23e2['pieceNum_']>=_0x4a23e2['pieces_']['length'];}function F(_0x199f78,_0x3adf2a){const _0x316bbc=y(_0x199f78),_0x3e2e3c=y(_0x3adf2a);if(_0x316bbc===null)return _0x3adf2a;if(_0x316bbc===_0x3e2e3c)return F(b(_0x199f78),b(_0x3adf2a));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3adf2a+')\x20is\x20not\x20within\x20outerPath\x20('+_0x199f78+')');}function Th(_0x5c7c02,_0x68b6c6){const _0x4152f1=kt(_0x5c7c02,0x0),_0x21c69f=kt(_0x68b6c6,0x0);for(let _0x30a3c2=0x0;_0x30a3c2<_0x4152f1['length']&&_0x30a3c2<_0x21c69f['length'];_0x30a3c2++){const _0x4b356e=He(_0x4152f1[_0x30a3c2],_0x21c69f[_0x30a3c2]);if(_0x4b356e!==0x0)return _0x4b356e;}return _0x4152f1['length']===_0x21c69f['length']?0x0:_0x4152f1['length']<_0x21c69f['length']?-0x1:0x1;}function qi(_0x4d8340,_0x377c78){if(we(_0x4d8340)!==we(_0x377c78))return!0x1;for(let _0xd05445=_0x4d8340['pieceNum_'],_0x3cf04e=_0x377c78['pieceNum_'];_0xd05445<=_0x4d8340['pieces_']['length'];_0xd05445++,_0x3cf04e++)if(_0x4d8340['pieces_'][_0xd05445]!==_0x377c78['pieces_'][_0x3cf04e])return!0x1;return!0x0;}function $(_0x2a844c,_0x4ab4f5){let _0xc28ed3=_0x2a844c['pieceNum_'],_0x387b1c=_0x4ab4f5['pieceNum_'];if(we(_0x2a844c)>we(_0x4ab4f5))return!0x1;for(;_0xc28ed3<_0x2a844c['pieces_']['length'];){if(_0x2a844c['pieces_'][_0xc28ed3]!==_0x4ab4f5['pieces_'][_0x387b1c])return!0x1;++_0xc28ed3,++_0x387b1c;}return!0x0;}class Sh{constructor(_0x1fa587,_0x5964c2){this['errorPrefix_']=_0x5964c2,this['parts_']=kt(_0x1fa587,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x309918=0x0;_0x309918<this['parts_']['length'];_0x309918++)this['byteLength_']+=Pn(this['parts_'][_0x309918]);So(this);}}function bh(_0x508412,_0x50a94b){_0x508412['parts_']['length']>0x0&&(_0x508412['byteLength_']+=0x1),_0x508412['parts_']['push'](_0x50a94b),_0x508412['byteLength_']+=Pn(_0x50a94b),So(_0x508412);}function Rh(_0x6a3ddc){const _0x36ed3c=_0x6a3ddc['parts_']['pop']();_0x6a3ddc['byteLength_']-=Pn(_0x36ed3c),_0x6a3ddc['parts_']['length']>0x0&&(_0x6a3ddc['byteLength_']-=0x1);}function So(_0x218c1a){if(_0x218c1a['byteLength_']>Js)throw new Error(_0x218c1a['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x218c1a['byteLength_']+').');if(_0x218c1a['parts_']['length']>Qs)throw new Error(_0x218c1a['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x218c1a));}function Ne(_0x146373){return _0x146373['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x146373['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x53c2bd,_0x219102;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x219102='visibilitychange',_0x53c2bd='hidden'):typeof document['mozHidden']<'u'?(_0x219102='mozvisibilitychange',_0x53c2bd='mozHidden'):typeof document['msHidden']<'u'?(_0x219102='msvisibilitychange',_0x53c2bd='msHidden'):typeof document['webkitHidden']<'u'&&(_0x219102='webkitvisibilitychange',_0x53c2bd='webkitHidden')),this['visible_']=!0x0,_0x219102&&document['addEventListener'](_0x219102,()=>{const _0x6d2277=!document[_0x53c2bd];_0x6d2277!==this['visible_']&&(this['visible_']=_0x6d2277,this['trigger']('visible',_0x6d2277));},!0x1);}['getInitialEvent'](_0xcb7a1d){return f(_0xcb7a1d==='visible','Unknown\x20event\x20type:\x20'+_0xcb7a1d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x3c77b4,_0x34e36c,_0x255a13,_0x6274f2,_0x565668,_0x4564e3,_0xec83bc,_0x321c7e){if(super(),this['repoInfo_']=_0x3c77b4,this['applicationId_']=_0x34e36c,this['onDataUpdate_']=_0x255a13,this['onConnectStatus_']=_0x6274f2,this['onServerInfoUpdate_']=_0x565668,this['authTokenProvider_']=_0x4564e3,this['appCheckTokenProvider_']=_0xec83bc,this['authOverride_']=_0x321c7e,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x321c7e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3c77b4['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x58a7db,_0x55fb6e,_0x246af5){const _0x45dd0e=++this['requestNumber_'],_0xf9620b={'r':_0x45dd0e,'a':_0x58a7db,'b':_0x55fb6e};this['log_'](O(_0xf9620b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xf9620b),_0x246af5&&(this['requestCBHash_'][_0x45dd0e]=_0x246af5);}['get'](_0x162478){this['initConnection_']();const _0x4372af=new Ve(),_0x1ca6ba={'action':'g','request':{'p':_0x162478['_path']['toString'](),'q':_0x162478['_queryObject']},'onComplete':_0x22b92f=>{const _0x2b49a6=_0x22b92f['d'];_0x22b92f['s']==='ok'?_0x4372af['resolve'](_0x2b49a6):_0x4372af['reject'](_0x2b49a6);}};this['outstandingGets_']['push'](_0x1ca6ba),this['outstandingGetCount_']++;const _0x57aac2=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x57aac2),_0x4372af['promise'];}['listen'](_0x3ef2ae,_0x5bef58,_0x1bb8a7,_0x4571a5){this['initConnection_']();const _0x417064=_0x3ef2ae['_queryIdentifier'],_0x3e03e4=_0x3ef2ae['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e03e4+'\x20'+_0x417064),this['listens']['has'](_0x3e03e4)||this['listens']['set'](_0x3e03e4,new Map()),f(_0x3ef2ae['_queryParams']['isDefault']()||!_0x3ef2ae['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3e03e4)['has'](_0x417064),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x10e0a7={'onComplete':_0x4571a5,'hashFn':_0x5bef58,'query':_0x3ef2ae,'tag':_0x1bb8a7};this['listens']['get'](_0x3e03e4)['set'](_0x417064,_0x10e0a7),this['connected_']&&this['sendListen_'](_0x10e0a7);}['sendGet_'](_0x238ef0){const _0x241d82=this['outstandingGets_'][_0x238ef0];this['sendRequest']('g',_0x241d82['request'],_0x36c512=>{delete this['outstandingGets_'][_0x238ef0],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x241d82['onComplete']&&_0x241d82['onComplete'](_0x36c512);});}['sendListen_'](_0x48a6ab){const _0x29abc6=_0x48a6ab['query'],_0x58b06c=_0x29abc6['_path']['toString'](),_0x3ce648=_0x29abc6['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x58b06c+'\x20for\x20'+_0x3ce648);const _0x4aaa32={'p':_0x58b06c},_0x2e62a7='q';_0x48a6ab['tag']&&(_0x4aaa32['q']=_0x29abc6['_queryObject'],_0x4aaa32['t']=_0x48a6ab['tag']),_0x4aaa32['h']=_0x48a6ab['hashFn'](),this['sendRequest'](_0x2e62a7,_0x4aaa32,_0x325a24=>{const _0x4931f9=_0x325a24['d'],_0x3f64c1=_0x325a24['s'];ie['warnOnListenWarnings_'](_0x4931f9,_0x29abc6),(this['listens']['get'](_0x58b06c)&&this['listens']['get'](_0x58b06c)['get'](_0x3ce648))===_0x48a6ab&&(this['log_']('listen\x20response',_0x325a24),_0x3f64c1!=='ok'&&this['removeListen_'](_0x58b06c,_0x3ce648),_0x48a6ab['onComplete']&&_0x48a6ab['onComplete'](_0x3f64c1,_0x4931f9));});}static['warnOnListenWarnings_'](_0x259630,_0xe9ee51){if(_0x259630&&typeof _0x259630=='object'&&Y(_0x259630,'w')){const _0x136c33=Oe(_0x259630,'w');if(Array['isArray'](_0x136c33)&&~_0x136c33['indexOf']('no_index')){const _0xeffea0='\x22.indexOn\x22:\x20\x22'+_0xe9ee51['_queryParams']['getIndex']()['toString']()+'\x22',_0x5d287f=_0xe9ee51['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0xeffea0+'\x20at\x20'+_0x5d287f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x47fefd){this['authToken_']=_0x47fefd,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x47fefd);}['reduceReconnectDelayIfAdminCredential_'](_0x3e0572){(_0x3e0572&&_0x3e0572['length']===0x28||vc(_0x3e0572))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x41026f){this['appCheckToken_']=_0x41026f,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1772e6=this['authToken_'],_0x4ed82f=yc(_0x1772e6)?'auth':'gauth',_0x491e45={'cred':_0x1772e6};this['authOverride_']===null?_0x491e45['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x491e45['authvar']=this['authOverride_']),this['sendRequest'](_0x4ed82f,_0x491e45,_0x2f47ef=>{const _0x3b291a=_0x2f47ef['s'],_0x28a495=_0x2f47ef['d']||'error';this['authToken_']===_0x1772e6&&(_0x3b291a==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3b291a,_0x28a495));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x38f0d2=>{const _0x1ddfb6=_0x38f0d2['s'],_0x439bc9=_0x38f0d2['d']||'error';_0x1ddfb6==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1ddfb6,_0x439bc9);});}['unlisten'](_0x20385f,_0x321fdc){const _0x596dcd=_0x20385f['_path']['toString'](),_0x5770d9=_0x20385f['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x596dcd+'\x20'+_0x5770d9),f(_0x20385f['_queryParams']['isDefault']()||!_0x20385f['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x596dcd,_0x5770d9)&&this['connected_']&&this['sendUnlisten_'](_0x596dcd,_0x5770d9,_0x20385f['_queryObject'],_0x321fdc);}['sendUnlisten_'](_0x570cf6,_0x28cafa,_0x445716,_0x5a4dcc){this['log_']('Unlisten\x20on\x20'+_0x570cf6+'\x20for\x20'+_0x28cafa);const _0x5ca17e={'p':_0x570cf6},_0x46297c='n';_0x5a4dcc&&(_0x5ca17e['q']=_0x445716,_0x5ca17e['t']=_0x5a4dcc),this['sendRequest'](_0x46297c,_0x5ca17e);}['onDisconnectPut'](_0x291e74,_0x1186f8,_0x21b7e3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x291e74,_0x1186f8,_0x21b7e3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x291e74,'action':'o','data':_0x1186f8,'onComplete':_0x21b7e3});}['onDisconnectMerge'](_0x4bed6c,_0x1396b9,_0x52283e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4bed6c,_0x1396b9,_0x52283e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4bed6c,'action':'om','data':_0x1396b9,'onComplete':_0x52283e});}['onDisconnectCancel'](_0x1dce55,_0x224be2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1dce55,null,_0x224be2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1dce55,'action':'oc','data':null,'onComplete':_0x224be2});}['sendOnDisconnect_'](_0x2d45c0,_0x319f26,_0x1079e9,_0x501b1a){const _0x4a44bf={'p':_0x319f26,'d':_0x1079e9};this['log_']('onDisconnect\x20'+_0x2d45c0,_0x4a44bf),this['sendRequest'](_0x2d45c0,_0x4a44bf,_0x2c6438=>{_0x501b1a&&setTimeout(()=>{_0x501b1a(_0x2c6438['s'],_0x2c6438['d']);},Math['floor'](0x0));});}['put'](_0x510107,_0x5efef1,_0x2f6485,_0x2a69d6){this['putInternal']('p',_0x510107,_0x5efef1,_0x2f6485,_0x2a69d6);}['merge'](_0x1d3457,_0x7ba800,_0x548278,_0x36c588){this['putInternal']('m',_0x1d3457,_0x7ba800,_0x548278,_0x36c588);}['putInternal'](_0x564692,_0x36e104,_0x1e8ea1,_0x5eb4e3,_0x191d7d){this['initConnection_']();const _0x3e227b={'p':_0x36e104,'d':_0x1e8ea1};_0x191d7d!==void 0x0&&(_0x3e227b['h']=_0x191d7d),this['outstandingPuts_']['push']({'action':_0x564692,'request':_0x3e227b,'onComplete':_0x5eb4e3}),this['outstandingPutCount_']++;const _0x299c69=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x299c69):this['log_']('Buffering\x20put:\x20'+_0x36e104);}['sendPut_'](_0x3d51d1){const _0x377105=this['outstandingPuts_'][_0x3d51d1]['action'],_0x24a776=this['outstandingPuts_'][_0x3d51d1]['request'],_0x45ab2a=this['outstandingPuts_'][_0x3d51d1]['onComplete'];this['outstandingPuts_'][_0x3d51d1]['queued']=this['connected_'],this['sendRequest'](_0x377105,_0x24a776,_0x57b274=>{this['log_'](_0x377105+'\x20response',_0x57b274),delete this['outstandingPuts_'][_0x3d51d1],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x45ab2a&&_0x45ab2a(_0x57b274['s'],_0x57b274['d']);});}['reportStats'](_0x25ed7e){if(this['connected_']){const _0x5462e={'c':_0x25ed7e};this['log_']('reportStats',_0x5462e),this['sendRequest']('s',_0x5462e,_0x4d9209=>{if(_0x4d9209['s']!=='ok'){const _0x4a4687=_0x4d9209['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x4a4687);}});}}['onDataMessage_'](_0x192fe8){if('r'in _0x192fe8){this['log_']('from\x20server:\x20'+O(_0x192fe8));const _0x5afed2=_0x192fe8['r'],_0x3c7161=this['requestCBHash_'][_0x5afed2];_0x3c7161&&(delete this['requestCBHash_'][_0x5afed2],_0x3c7161(_0x192fe8['b']));}else{if('error'in _0x192fe8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x192fe8['error'];'a'in _0x192fe8&&this['onDataPush_'](_0x192fe8['a'],_0x192fe8['b']);}}['onDataPush_'](_0x2b3f42,_0x98e265){this['log_']('handleServerMessage',_0x2b3f42,_0x98e265),_0x2b3f42==='d'?this['onDataUpdate_'](_0x98e265['p'],_0x98e265['d'],!0x1,_0x98e265['t']):_0x2b3f42==='m'?this['onDataUpdate_'](_0x98e265['p'],_0x98e265['d'],!0x0,_0x98e265['t']):_0x2b3f42==='c'?this['onListenRevoked_'](_0x98e265['p'],_0x98e265['q']):_0x2b3f42==='ac'?this['onAuthRevoked_'](_0x98e265['s'],_0x98e265['d']):_0x2b3f42==='apc'?this['onAppCheckRevoked_'](_0x98e265['s'],_0x98e265['d']):_0x2b3f42==='sd'?this['onSecurityDebugPacket_'](_0x98e265):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2b3f42)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x46405d,_0x45cda){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x46405d),this['lastSessionId']=_0x45cda,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2e4652){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2e4652));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x57c7e9){_0x57c7e9&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x57c7e9;}['onOnline_'](_0x4ecdb3){_0x4ecdb3?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x484335=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x14cb8a=Math['max'](0x0,this['reconnectDelay_']-_0x484335);_0x14cb8a=Math['random']()*_0x14cb8a,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x14cb8a+'ms'),this['scheduleConnect_'](_0x14cb8a),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xaa3ad1=this['onDataMessage_']['bind'](this),_0x50b64b=this['onReady_']['bind'](this),_0x4ffb0c=this['onRealtimeDisconnect_']['bind'](this),_0x2af0c5=this['id']+':'+ie['nextConnectionId_']++,_0x261de3=this['lastSessionId'];let _0x411947=!0x1,_0x1820e1=null;const _0x2e1cfe=function(){_0x1820e1?_0x1820e1['close']():(_0x411947=!0x0,_0x4ffb0c());},_0x191f00=function(_0xcc87ec){f(_0x1820e1,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1820e1['sendRequest'](_0xcc87ec);};this['realtime_']={'close':_0x2e1cfe,'sendRequest':_0x191f00};const _0x40656a=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2b3ff9,_0xde883a]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x40656a),this['appCheckTokenProvider_']['getToken'](_0x40656a)]);_0x411947?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2b3ff9&&_0x2b3ff9['accessToken'],this['appCheckToken_']=_0xde883a&&_0xde883a['token'],_0x1820e1=new wh(_0x2af0c5,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xaa3ad1,_0x50b64b,_0x4ffb0c,_0x334d18=>{U(_0x334d18+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x261de3));}catch(_0x264c1){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x264c1),_0x411947||(this['repoInfo_']['nodeAdmin']&&U(_0x264c1),_0x2e1cfe());}}}['interrupt'](_0x24f0f3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x24f0f3),this['interruptReasons_'][_0x24f0f3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2c58f0){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2c58f0),delete this['interruptReasons_'][_0x2c58f0],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5c8ec2){const _0x26e7d9=_0x5c8ec2-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x26e7d9});}['cancelSentTransactions_'](){for(let _0x2ee343=0x0;_0x2ee343<this['outstandingPuts_']['length'];_0x2ee343++){const _0x411c53=this['outstandingPuts_'][_0x2ee343];_0x411c53&&'h'in _0x411c53['request']&&_0x411c53['queued']&&(_0x411c53['onComplete']&&_0x411c53['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2ee343],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2a2bcb,_0xcac26d){let _0x362b6f;_0xcac26d?_0x362b6f=_0xcac26d['map'](_0x3061fe=>Bi(_0x3061fe))['join']('$'):_0x362b6f='default';const _0x572384=this['removeListen_'](_0x2a2bcb,_0x362b6f);_0x572384&&_0x572384['onComplete']&&_0x572384['onComplete']('permission_denied');}['removeListen_'](_0x4c06d3,_0x34a413){const _0x272bed=new C(_0x4c06d3)['toString']();let _0x5875a0;if(this['listens']['has'](_0x272bed)){const _0x5827e4=this['listens']['get'](_0x272bed);_0x5875a0=_0x5827e4['get'](_0x34a413),_0x5827e4['delete'](_0x34a413),_0x5827e4['size']===0x0&&this['listens']['delete'](_0x272bed);}else _0x5875a0=void 0x0;return _0x5875a0;}['onAuthRevoked_'](_0x2c7e84,_0x4b9820){L('Auth\x20token\x20revoked:\x20'+_0x2c7e84+'/'+_0x4b9820),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2c7e84==='invalid_token'||_0x2c7e84==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x153568,_0x48c40a){L('App\x20check\x20token\x20revoked:\x20'+_0x153568+'/'+_0x48c40a),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x153568==='invalid_token'||_0x153568==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x13ac5d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x13ac5d):'msg'in _0x13ac5d&&console['log']('FIREBASE:\x20'+_0x13ac5d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4e0c15 of this['listens']['values']())for(const _0x2f4b4b of _0x4e0c15['values']())this['sendListen_'](_0x2f4b4b);for(let _0x4cb823=0x0;_0x4cb823<this['outstandingPuts_']['length'];_0x4cb823++)this['outstandingPuts_'][_0x4cb823]&&this['sendPut_'](_0x4cb823);for(;this['onDisconnectRequestQueue_']['length'];){const _0x100e49=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x100e49['action'],_0x100e49['pathString'],_0x100e49['data'],_0x100e49['onComplete']);}for(let _0x5f2776=0x0;_0x5f2776<this['outstandingGets_']['length'];_0x5f2776++)this['outstandingGets_'][_0x5f2776]&&this['sendGet_'](_0x5f2776);}['sendConnectStats_'](){const _0x5f53df={};let _0x33dae6='js';_0x5f53df['sdk.'+_0x33dae6+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x5f53df['framework.cordova']=0x1:qr()&&(_0x5f53df['framework.reactnative']=0x1),this['reportStats'](_0x5f53df);}['shouldReconnect_'](){const _0x3aa834=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x3aa834;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x41371d,_0x350e3d){this['name']=_0x41371d,this['node']=_0x350e3d;}static['Wrap'](_0x1c6a58,_0x40e0ed){return new E(_0x1c6a58,_0x40e0ed);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xefb05f,_0x7896fb){const _0x7152a6=new E(xe,_0xefb05f),_0x7913f7=new E(xe,_0x7896fb);return this['compare'](_0x7152a6,_0x7913f7)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x390c7d){Xt=_0x390c7d;}['compare'](_0x1f6c96,_0x4a6ed0){return He(_0x1f6c96['name'],_0x4a6ed0['name']);}['isDefinedOn'](_0x839ef1){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x202517,_0x27404d){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x199932,_0x3e1029){return f(typeof _0x199932=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x199932,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x17476e,_0x32cb0e,_0x44fd1a,_0x110935,_0x298a5e=null){this['isReverse_']=_0x110935,this['resultGenerator_']=_0x298a5e,this['nodeStack_']=[];let _0x1ac14a=0x1;for(;!_0x17476e['isEmpty']();)if(_0x17476e=_0x17476e,_0x1ac14a=_0x32cb0e?_0x44fd1a(_0x17476e['key'],_0x32cb0e):0x1,_0x110935&&(_0x1ac14a*=-0x1),_0x1ac14a<0x0)this['isReverse_']?_0x17476e=_0x17476e['left']:_0x17476e=_0x17476e['right'];else{if(_0x1ac14a===0x0){this['nodeStack_']['push'](_0x17476e);break;}else this['nodeStack_']['push'](_0x17476e),this['isReverse_']?_0x17476e=_0x17476e['right']:_0x17476e=_0x17476e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x15b3db=this['nodeStack_']['pop'](),_0x5562af;if(this['resultGenerator_']?_0x5562af=this['resultGenerator_'](_0x15b3db['key'],_0x15b3db['value']):_0x5562af={'key':_0x15b3db['key'],'value':_0x15b3db['value']},this['isReverse_']){for(_0x15b3db=_0x15b3db['left'];!_0x15b3db['isEmpty']();)this['nodeStack_']['push'](_0x15b3db),_0x15b3db=_0x15b3db['right'];}else{for(_0x15b3db=_0x15b3db['right'];!_0x15b3db['isEmpty']();)this['nodeStack_']['push'](_0x15b3db),_0x15b3db=_0x15b3db['left'];}return _0x5562af;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2b94d2=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2b94d2['key'],_0x2b94d2['value']):{'key':_0x2b94d2['key'],'value':_0x2b94d2['value']};}}class M{constructor(_0x22eea3,_0x46c7b6,_0x2e4555,_0x9c374e,_0x16325a){this['key']=_0x22eea3,this['value']=_0x46c7b6,this['color']=_0x2e4555??M['RED'],this['left']=_0x9c374e??B['EMPTY_NODE'],this['right']=_0x16325a??B['EMPTY_NODE'];}['copy'](_0x37c248,_0x4f9723,_0x23517c,_0x105ac1,_0x39f61d){return new M(_0x37c248??this['key'],_0x4f9723??this['value'],_0x23517c??this['color'],_0x105ac1??this['left'],_0x39f61d??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x27b503){return this['left']['inorderTraversal'](_0x27b503)||!!_0x27b503(this['key'],this['value'])||this['right']['inorderTraversal'](_0x27b503);}['reverseTraversal'](_0x607cfe){return this['right']['reverseTraversal'](_0x607cfe)||_0x607cfe(this['key'],this['value'])||this['left']['reverseTraversal'](_0x607cfe);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x47c24c,_0xd252f7,_0x2e2e0e){let _0x12e9ea=this;const _0x532999=_0x2e2e0e(_0x47c24c,_0x12e9ea['key']);return _0x532999<0x0?_0x12e9ea=_0x12e9ea['copy'](null,null,null,_0x12e9ea['left']['insert'](_0x47c24c,_0xd252f7,_0x2e2e0e),null):_0x532999===0x0?_0x12e9ea=_0x12e9ea['copy'](null,_0xd252f7,null,null,null):_0x12e9ea=_0x12e9ea['copy'](null,null,null,null,_0x12e9ea['right']['insert'](_0x47c24c,_0xd252f7,_0x2e2e0e)),_0x12e9ea['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1a4e64=this;return!_0x1a4e64['left']['isRed_']()&&!_0x1a4e64['left']['left']['isRed_']()&&(_0x1a4e64=_0x1a4e64['moveRedLeft_']()),_0x1a4e64=_0x1a4e64['copy'](null,null,null,_0x1a4e64['left']['removeMin_'](),null),_0x1a4e64['fixUp_']();}['remove'](_0x27367f,_0x25f527){let _0x3ca361,_0x195897;if(_0x3ca361=this,_0x25f527(_0x27367f,_0x3ca361['key'])<0x0)!_0x3ca361['left']['isEmpty']()&&!_0x3ca361['left']['isRed_']()&&!_0x3ca361['left']['left']['isRed_']()&&(_0x3ca361=_0x3ca361['moveRedLeft_']()),_0x3ca361=_0x3ca361['copy'](null,null,null,_0x3ca361['left']['remove'](_0x27367f,_0x25f527),null);else{if(_0x3ca361['left']['isRed_']()&&(_0x3ca361=_0x3ca361['rotateRight_']()),!_0x3ca361['right']['isEmpty']()&&!_0x3ca361['right']['isRed_']()&&!_0x3ca361['right']['left']['isRed_']()&&(_0x3ca361=_0x3ca361['moveRedRight_']()),_0x25f527(_0x27367f,_0x3ca361['key'])===0x0){if(_0x3ca361['right']['isEmpty']())return B['EMPTY_NODE'];_0x195897=_0x3ca361['right']['min_'](),_0x3ca361=_0x3ca361['copy'](_0x195897['key'],_0x195897['value'],null,null,_0x3ca361['right']['removeMin_']());}_0x3ca361=_0x3ca361['copy'](null,null,null,null,_0x3ca361['right']['remove'](_0x27367f,_0x25f527));}return _0x3ca361['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x475797=this;return _0x475797['right']['isRed_']()&&!_0x475797['left']['isRed_']()&&(_0x475797=_0x475797['rotateLeft_']()),_0x475797['left']['isRed_']()&&_0x475797['left']['left']['isRed_']()&&(_0x475797=_0x475797['rotateRight_']()),_0x475797['left']['isRed_']()&&_0x475797['right']['isRed_']()&&(_0x475797=_0x475797['colorFlip_']()),_0x475797;}['moveRedLeft_'](){let _0x50a265=this['colorFlip_']();return _0x50a265['right']['left']['isRed_']()&&(_0x50a265=_0x50a265['copy'](null,null,null,null,_0x50a265['right']['rotateRight_']()),_0x50a265=_0x50a265['rotateLeft_'](),_0x50a265=_0x50a265['colorFlip_']()),_0x50a265;}['moveRedRight_'](){let _0x382c49=this['colorFlip_']();return _0x382c49['left']['left']['isRed_']()&&(_0x382c49=_0x382c49['rotateRight_'](),_0x382c49=_0x382c49['colorFlip_']()),_0x382c49;}['rotateLeft_'](){const _0x476c74=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x476c74,null);}['rotateRight_'](){const _0x39398c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x39398c);}['colorFlip_'](){const _0x2e45c2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4683c9=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2e45c2,_0x4683c9);}['checkMaxDepth_'](){const _0x2dc7cc=this['check_']();return Math['pow'](0x2,_0x2dc7cc)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x23d318=this['left']['check_']();if(_0x23d318!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x23d318+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x3d66e2,_0x2c3cdc,_0x20cb79,_0x54aa00,_0x5c07bf){return this;}['insert'](_0x2fb62f,_0x57c049,_0x27727f){return new M(_0x2fb62f,_0x57c049,null);}['remove'](_0x55831f,_0x413717){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5c7015){return!0x1;}['reverseTraversal'](_0x1419ec){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x31394f,_0x168056=B['EMPTY_NODE']){this['comparator_']=_0x31394f,this['root_']=_0x168056;}['insert'](_0x24becf,_0x20e9bb){return new B(this['comparator_'],this['root_']['insert'](_0x24becf,_0x20e9bb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xbba0a7){return new B(this['comparator_'],this['root_']['remove'](_0xbba0a7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x51fcc2){let _0x524421,_0x36d2a2=this['root_'];for(;!_0x36d2a2['isEmpty']();){if(_0x524421=this['comparator_'](_0x51fcc2,_0x36d2a2['key']),_0x524421===0x0)return _0x36d2a2['value'];_0x524421<0x0?_0x36d2a2=_0x36d2a2['left']:_0x524421>0x0&&(_0x36d2a2=_0x36d2a2['right']);}return null;}['getPredecessorKey'](_0x4aa2d9){let _0x4cd0da,_0x925176=this['root_'],_0x2dbdbc=null;for(;!_0x925176['isEmpty']();)if(_0x4cd0da=this['comparator_'](_0x4aa2d9,_0x925176['key']),_0x4cd0da===0x0){if(_0x925176['left']['isEmpty']())return _0x2dbdbc?_0x2dbdbc['key']:null;for(_0x925176=_0x925176['left'];!_0x925176['right']['isEmpty']();)_0x925176=_0x925176['right'];return _0x925176['key'];}else _0x4cd0da<0x0?_0x925176=_0x925176['left']:_0x4cd0da>0x0&&(_0x2dbdbc=_0x925176,_0x925176=_0x925176['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x443c70){return this['root_']['inorderTraversal'](_0x443c70);}['reverseTraversal'](_0x7bc16e){return this['root_']['reverseTraversal'](_0x7bc16e);}['getIterator'](_0x393041){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x393041);}['getIteratorFrom'](_0x2af479,_0x14869c){return new Zt(this['root_'],_0x2af479,this['comparator_'],!0x1,_0x14869c);}['getReverseIteratorFrom'](_0x4b045d,_0x3b0a46){return new Zt(this['root_'],_0x4b045d,this['comparator_'],!0x0,_0x3b0a46);}['getReverseIterator'](_0x3642bf){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x3642bf);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x2130f1,_0x5aa8e2){return He(_0x2130f1['name'],_0x5aa8e2['name']);}function ji(_0x3a46bf,_0x3ebe53){return He(_0x3a46bf,_0x3ebe53);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x287074){vi=_0x287074;}const Ro=function(_0x476a61){return typeof _0x476a61=='number'?'number:'+so(_0x476a61):'string:'+_0x476a61;},Ao=function(_0x416512){if(_0x416512['isLeafNode']()){const _0xe323eb=_0x416512['val']();f(typeof _0xe323eb=='string'||typeof _0xe323eb=='number'||typeof _0xe323eb=='object'&&Y(_0xe323eb,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x416512===vi||_0x416512['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x416512===vi||_0x416512['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x3ab0bc){er=_0x3ab0bc;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x39d769,_0x8d1879=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x39d769,this['priorityNode_']=_0x8d1879,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x299bed){return new D(this['value_'],_0x299bed);}['getImmediateChild'](_0x362bbe){return _0x362bbe==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3a87e3){return v(_0x3a87e3)?this:y(_0x3a87e3)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x293733,_0x578838){return null;}['updateImmediateChild'](_0x361e1f,_0x4599d1){return _0x361e1f==='.priority'?this['updatePriority'](_0x4599d1):_0x4599d1['isEmpty']()&&_0x361e1f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x361e1f,_0x4599d1)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4ea0cb,_0x383524){const _0x59f191=y(_0x4ea0cb);return _0x59f191===null?_0x383524:_0x383524['isEmpty']()&&_0x59f191!=='.priority'?this:(f(_0x59f191!=='.priority'||we(_0x4ea0cb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x59f191,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4ea0cb),_0x383524)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x8716d9,_0x357562){return!0x1;}['val'](_0x3bccb1){return _0x3bccb1&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4d3087='';this['priorityNode_']['isEmpty']()||(_0x4d3087+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0xf3de79=typeof this['value_'];_0x4d3087+=_0xf3de79+':',_0xf3de79==='number'?_0x4d3087+=so(this['value_']):_0x4d3087+=this['value_'],this['lazyHash_']=no(_0x4d3087);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4420e2){return _0x4420e2===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4420e2 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4420e2['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4420e2));}['compareToLeafNode_'](_0x5a9c78){const _0x16b92c=typeof _0x5a9c78['value_'],_0x3e3832=typeof this['value_'],_0x23b865=D['VALUE_TYPE_ORDER']['indexOf'](_0x16b92c),_0x4a2bb3=D['VALUE_TYPE_ORDER']['indexOf'](_0x3e3832);return f(_0x23b865>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x16b92c),f(_0x4a2bb3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3e3832),_0x23b865===_0x4a2bb3?_0x3e3832==='object'?0x0:this['value_']<_0x5a9c78['value_']?-0x1:this['value_']===_0x5a9c78['value_']?0x0:0x1:_0x4a2bb3-_0x23b865;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4e1225){if(_0x4e1225===this)return!0x0;if(_0x4e1225['isLeafNode']()){const _0x27e9fb=_0x4e1225;return this['value_']===_0x27e9fb['value_']&&this['priorityNode_']['equals'](_0x27e9fb['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x538298){ko=_0x538298;}function xh(_0xb35458){No=_0xb35458;}class Fh extends On{['compare'](_0x26a5c6,_0x58a721){const _0x1945e2=_0x26a5c6['node']['getPriority'](),_0x171d3a=_0x58a721['node']['getPriority'](),_0x49e4f5=_0x1945e2['compareTo'](_0x171d3a);return _0x49e4f5===0x0?He(_0x26a5c6['name'],_0x58a721['name']):_0x49e4f5;}['isDefinedOn'](_0x5bf8fe){return!_0x5bf8fe['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x23d4a0,_0x3dcab4){return!_0x23d4a0['getPriority']()['equals'](_0x3dcab4['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x5324db,_0x248e16){const _0x581931=ko(_0x5324db);return new E(_0x248e16,new D('[PRIORITY-POST]',_0x581931));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x51a480){const _0x547769=_0x5cc87e=>parseInt(Math['log'](_0x5cc87e)/Uh,0xa),_0x1ff939=_0x20d56f=>parseInt(Array(_0x20d56f+0x1)['join']('1'),0x2);this['count']=_0x547769(_0x51a480+0x1),this['current_']=this['count']-0x1;const _0x530367=_0x1ff939(this['count']);this['bits_']=_0x51a480+0x1&_0x530367;}['nextBitIsOne'](){const _0x5aaabf=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5aaabf;}}const dn=function(_0x1ff9a3,_0x4efe15,_0x1e176a,_0x2bdc69){_0x1ff9a3['sort'](_0x4efe15);const _0x3515cc=function(_0x593a10,_0x26f934){const _0x51e6ff=_0x26f934-_0x593a10;let _0x252ae9,_0xe8a46;if(_0x51e6ff===0x0)return null;if(_0x51e6ff===0x1)return _0x252ae9=_0x1ff9a3[_0x593a10],_0xe8a46=_0x1e176a?_0x1e176a(_0x252ae9):_0x252ae9,new M(_0xe8a46,_0x252ae9['node'],M['BLACK'],null,null);{const _0x15d6a9=parseInt(_0x51e6ff/0x2,0xa)+_0x593a10,_0xe1157a=_0x3515cc(_0x593a10,_0x15d6a9),_0x5d7937=_0x3515cc(_0x15d6a9+0x1,_0x26f934);return _0x252ae9=_0x1ff9a3[_0x15d6a9],_0xe8a46=_0x1e176a?_0x1e176a(_0x252ae9):_0x252ae9,new M(_0xe8a46,_0x252ae9['node'],M['BLACK'],_0xe1157a,_0x5d7937);}},_0x508a89=function(_0x2f7535){let _0x3d8054=null,_0x398ff3=null,_0x52d6c9=_0x1ff9a3['length'];const _0x41270c=function(_0x40f475,_0x5f95bc){const _0x56c289=_0x52d6c9-_0x40f475,_0x141e21=_0x52d6c9;_0x52d6c9-=_0x40f475;const _0x1680b9=_0x3515cc(_0x56c289+0x1,_0x141e21),_0x34ac61=_0x1ff9a3[_0x56c289],_0x55f0c8=_0x1e176a?_0x1e176a(_0x34ac61):_0x34ac61;_0x5d95cd(new M(_0x55f0c8,_0x34ac61['node'],_0x5f95bc,null,_0x1680b9));},_0x5d95cd=function(_0x29b43d){_0x3d8054?(_0x3d8054['left']=_0x29b43d,_0x3d8054=_0x29b43d):(_0x398ff3=_0x29b43d,_0x3d8054=_0x29b43d);};for(let _0x555ae7=0x0;_0x555ae7<_0x2f7535['count'];++_0x555ae7){const _0x88f79c=_0x2f7535['nextBitIsOne'](),_0x31824c=Math['pow'](0x2,_0x2f7535['count']-(_0x555ae7+0x1));_0x88f79c?_0x41270c(_0x31824c,M['BLACK']):(_0x41270c(_0x31824c,M['BLACK']),_0x41270c(_0x31824c,M['RED']));}return _0x398ff3;},_0x26838b=new Wh(_0x1ff9a3['length']),_0x5c7c8c=_0x508a89(_0x26838b);return new B(_0x2bdc69||_0x4efe15,_0x5c7c8c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x417802,_0x50e6c7){this['indexes_']=_0x417802,this['indexSet_']=_0x50e6c7;}['get'](_0x3a4f7d){const _0x5adc96=Oe(this['indexes_'],_0x3a4f7d);if(!_0x5adc96)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3a4f7d);return _0x5adc96 instanceof B?_0x5adc96:null;}['hasIndex'](_0x573d58){return Y(this['indexSet_'],_0x573d58['toString']());}['addIndex'](_0x539ef4,_0x161c02){f(_0x539ef4!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x56c2eb=[];let _0x1867ee=!0x1;const _0x2b5b85=_0x161c02['getIterator'](E['Wrap']);let _0xb60ecf=_0x2b5b85['getNext']();for(;_0xb60ecf;)_0x1867ee=_0x1867ee||_0x539ef4['isDefinedOn'](_0xb60ecf['node']),_0x56c2eb['push'](_0xb60ecf),_0xb60ecf=_0x2b5b85['getNext']();let _0x53120a;_0x1867ee?_0x53120a=dn(_0x56c2eb,_0x539ef4['getCompare']()):_0x53120a=je;const _0x4ee9e5=_0x539ef4['toString'](),_0x7dc0ea={...this['indexSet_']};_0x7dc0ea[_0x4ee9e5]=_0x539ef4;const _0x1c06c9={...this['indexes_']};return _0x1c06c9[_0x4ee9e5]=_0x53120a,new ee(_0x1c06c9,_0x7dc0ea);}['addToIndexes'](_0x37a692,_0x1faeb4){const _0x1d37ad=ln(this['indexes_'],(_0x1bdc18,_0x218a77)=>{const _0x45a23b=Oe(this['indexSet_'],_0x218a77);if(f(_0x45a23b,'Missing\x20index\x20implementation\x20for\x20'+_0x218a77),_0x1bdc18===je){if(_0x45a23b['isDefinedOn'](_0x37a692['node'])){const _0x3e96d8=[],_0x3ce32e=_0x1faeb4['getIterator'](E['Wrap']);let _0x42620c=_0x3ce32e['getNext']();for(;_0x42620c;)_0x42620c['name']!==_0x37a692['name']&&_0x3e96d8['push'](_0x42620c),_0x42620c=_0x3ce32e['getNext']();return _0x3e96d8['push'](_0x37a692),dn(_0x3e96d8,_0x45a23b['getCompare']());}else return je;}else{const _0x1a6097=_0x1faeb4['get'](_0x37a692['name']);let _0x593ace=_0x1bdc18;return _0x1a6097&&(_0x593ace=_0x593ace['remove'](new E(_0x37a692['name'],_0x1a6097))),_0x593ace['insert'](_0x37a692,_0x37a692['node']);}});return new ee(_0x1d37ad,this['indexSet_']);}['removeFromIndexes'](_0x1517a7,_0x2371a0){const _0x8bd7df=ln(this['indexes_'],_0x59fd99=>{if(_0x59fd99===je)return _0x59fd99;{const _0x1eaff6=_0x2371a0['get'](_0x1517a7['name']);return _0x1eaff6?_0x59fd99['remove'](new E(_0x1517a7['name'],_0x1eaff6)):_0x59fd99;}});return new ee(_0x8bd7df,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x263f3a,_0xbe9e6,_0x4b2f3a){this['children_']=_0x263f3a,this['priorityNode_']=_0xbe9e6,this['indexMap_']=_0x4b2f3a,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0xdd6073){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xdd6073,this['indexMap_']);}['getImmediateChild'](_0x5bb079){if(_0x5bb079==='.priority')return this['getPriority']();{const _0x2ade65=this['children_']['get'](_0x5bb079);return _0x2ade65===null?gt:_0x2ade65;}}['getChild'](_0x1d0354){const _0x3f7890=y(_0x1d0354);return _0x3f7890===null?this:this['getImmediateChild'](_0x3f7890)['getChild'](b(_0x1d0354));}['hasChild'](_0xeb7cf4){return this['children_']['get'](_0xeb7cf4)!==null;}['updateImmediateChild'](_0x4bacf1,_0x1997d0){if(f(_0x1997d0,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4bacf1==='.priority')return this['updatePriority'](_0x1997d0);{const _0x216c01=new E(_0x4bacf1,_0x1997d0);let _0x512f83,_0x243a06;_0x1997d0['isEmpty']()?(_0x512f83=this['children_']['remove'](_0x4bacf1),_0x243a06=this['indexMap_']['removeFromIndexes'](_0x216c01,this['children_'])):(_0x512f83=this['children_']['insert'](_0x4bacf1,_0x1997d0),_0x243a06=this['indexMap_']['addToIndexes'](_0x216c01,this['children_']));const _0x3e5b4b=_0x512f83['isEmpty']()?gt:this['priorityNode_'];return new g(_0x512f83,_0x3e5b4b,_0x243a06);}}['updateChild'](_0x1cd80f,_0x310dd5){const _0x55cb83=y(_0x1cd80f);if(_0x55cb83===null)return _0x310dd5;{f(y(_0x1cd80f)!=='.priority'||we(_0x1cd80f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x27c0ab=this['getImmediateChild'](_0x55cb83)['updateChild'](b(_0x1cd80f),_0x310dd5);return this['updateImmediateChild'](_0x55cb83,_0x27c0ab);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x22e803){if(this['isEmpty']())return null;const _0x1c5218={};let _0x4496a7=0x0,_0x210b8e=0x0,_0x5ef767=!0x0;if(this['forEachChild'](R,(_0xfd0a5f,_0x561dc6)=>{_0x1c5218[_0xfd0a5f]=_0x561dc6['val'](_0x22e803),_0x4496a7++,_0x5ef767&&g['INTEGER_REGEXP_']['test'](_0xfd0a5f)?_0x210b8e=Math['max'](_0x210b8e,Number(_0xfd0a5f)):_0x5ef767=!0x1;}),!_0x22e803&&_0x5ef767&&_0x210b8e<0x2*_0x4496a7){const _0x1e8bd=[];for(const _0x2580fd in _0x1c5218)_0x1e8bd[_0x2580fd]=_0x1c5218[_0x2580fd];return _0x1e8bd;}else return _0x22e803&&!this['getPriority']()['isEmpty']()&&(_0x1c5218['.priority']=this['getPriority']()['val']()),_0x1c5218;}['hash'](){if(this['lazyHash_']===null){let _0x39230b='';this['getPriority']()['isEmpty']()||(_0x39230b+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x17b894,_0x7b697)=>{const _0x462c65=_0x7b697['hash']();_0x462c65!==''&&(_0x39230b+=':'+_0x17b894+':'+_0x462c65);}),this['lazyHash_']=_0x39230b===''?'':no(_0x39230b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4e36b8,_0x528aa9,_0x14c326){const _0x559a3e=this['resolveIndex_'](_0x14c326);if(_0x559a3e){const _0x3a62a2=_0x559a3e['getPredecessorKey'](new E(_0x4e36b8,_0x528aa9));return _0x3a62a2?_0x3a62a2['name']:null;}else return this['children_']['getPredecessorKey'](_0x4e36b8);}['getFirstChildName'](_0x2492b2){const _0xb4574f=this['resolveIndex_'](_0x2492b2);if(_0xb4574f){const _0x351cf5=_0xb4574f['minKey']();return _0x351cf5&&_0x351cf5['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x144a22){const _0x44a124=this['getFirstChildName'](_0x144a22);return _0x44a124?new E(_0x44a124,this['children_']['get'](_0x44a124)):null;}['getLastChildName'](_0x3414f5){const _0x3ad223=this['resolveIndex_'](_0x3414f5);if(_0x3ad223){const _0x135657=_0x3ad223['maxKey']();return _0x135657&&_0x135657['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3b63e8){const _0x3f1864=this['getLastChildName'](_0x3b63e8);return _0x3f1864?new E(_0x3f1864,this['children_']['get'](_0x3f1864)):null;}['forEachChild'](_0x45bc19,_0x92f780){const _0x1c1de3=this['resolveIndex_'](_0x45bc19);return _0x1c1de3?_0x1c1de3['inorderTraversal'](_0x10c965=>_0x92f780(_0x10c965['name'],_0x10c965['node'])):this['children_']['inorderTraversal'](_0x92f780);}['getIterator'](_0x5e628d){return this['getIteratorFrom'](_0x5e628d['minPost'](),_0x5e628d);}['getIteratorFrom'](_0x12469f,_0x2f4096){const _0x4a27b9=this['resolveIndex_'](_0x2f4096);if(_0x4a27b9)return _0x4a27b9['getIteratorFrom'](_0x12469f,_0x13a9a1=>_0x13a9a1);{const _0x3111af=this['children_']['getIteratorFrom'](_0x12469f['name'],E['Wrap']);let _0x439865=_0x3111af['peek']();for(;_0x439865!=null&&_0x2f4096['compare'](_0x439865,_0x12469f)<0x0;)_0x3111af['getNext'](),_0x439865=_0x3111af['peek']();return _0x3111af;}}['getReverseIterator'](_0x467873){return this['getReverseIteratorFrom'](_0x467873['maxPost'](),_0x467873);}['getReverseIteratorFrom'](_0x397955,_0xa3aa5b){const _0x5070b6=this['resolveIndex_'](_0xa3aa5b);if(_0x5070b6)return _0x5070b6['getReverseIteratorFrom'](_0x397955,_0xabaae2=>_0xabaae2);{const _0x22629d=this['children_']['getReverseIteratorFrom'](_0x397955['name'],E['Wrap']);let _0x356d3=_0x22629d['peek']();for(;_0x356d3!=null&&_0xa3aa5b['compare'](_0x356d3,_0x397955)>0x0;)_0x22629d['getNext'](),_0x356d3=_0x22629d['peek']();return _0x22629d;}}['compareTo'](_0x35040d){return this['isEmpty']()?_0x35040d['isEmpty']()?0x0:-0x1:_0x35040d['isLeafNode']()||_0x35040d['isEmpty']()?0x1:_0x35040d===Ht?-0x1:0x0;}['withIndex'](_0x4babdb){if(_0x4babdb===ye||this['indexMap_']['hasIndex'](_0x4babdb))return this;{const _0x1265f3=this['indexMap_']['addIndex'](_0x4babdb,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1265f3);}}['isIndexed'](_0x4b4ca8){return _0x4b4ca8===ye||this['indexMap_']['hasIndex'](_0x4b4ca8);}['equals'](_0x23f9c4){if(_0x23f9c4===this)return!0x0;if(_0x23f9c4['isLeafNode']())return!0x1;{const _0x8edcab=_0x23f9c4;if(this['getPriority']()['equals'](_0x8edcab['getPriority']())){if(this['children_']['count']()===_0x8edcab['children_']['count']()){const _0x258716=this['getIterator'](R),_0x2bf12b=_0x8edcab['getIterator'](R);let _0x4ad152=_0x258716['getNext'](),_0x29ab5d=_0x2bf12b['getNext']();for(;_0x4ad152&&_0x29ab5d;){if(_0x4ad152['name']!==_0x29ab5d['name']||!_0x4ad152['node']['equals'](_0x29ab5d['node']))return!0x1;_0x4ad152=_0x258716['getNext'](),_0x29ab5d=_0x2bf12b['getNext']();}return _0x4ad152===null&&_0x29ab5d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5b9f4c){return _0x5b9f4c===ye?null:this['indexMap_']['get'](_0x5b9f4c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x11922e){return _0x11922e===this?0x0:0x1;}['equals'](_0x61ce9c){return _0x61ce9c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x7b6cdd){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x5f1473,_0x1da61d=null){if(_0x5f1473===null)return g['EMPTY_NODE'];if(typeof _0x5f1473=='object'&&'.priority'in _0x5f1473&&(_0x1da61d=_0x5f1473['.priority']),f(_0x1da61d===null||typeof _0x1da61d=='string'||typeof _0x1da61d=='number'||typeof _0x1da61d=='object'&&'.sv'in _0x1da61d,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1da61d),typeof _0x5f1473=='object'&&'.value'in _0x5f1473&&_0x5f1473['.value']!==null&&(_0x5f1473=_0x5f1473['.value']),typeof _0x5f1473!='object'||'.sv'in _0x5f1473){const _0x4e0884=_0x5f1473;return new D(_0x4e0884,N(_0x1da61d));}if(!(_0x5f1473 instanceof Array)&&Vh){const _0x1b4f6f=[];let _0x5d0e45=!0x1;if(x(_0x5f1473,(_0x44f8c6,_0x5c2ab5)=>{if(_0x44f8c6['substring'](0x0,0x1)!=='.'){const _0x394477=N(_0x5c2ab5);_0x394477['isEmpty']()||(_0x5d0e45=_0x5d0e45||!_0x394477['getPriority']()['isEmpty'](),_0x1b4f6f['push'](new E(_0x44f8c6,_0x394477)));}}),_0x1b4f6f['length']===0x0)return g['EMPTY_NODE'];const _0x3eba2f=dn(_0x1b4f6f,Dh,_0x3037aa=>_0x3037aa['name'],ji);if(_0x5d0e45){const _0x12702e=dn(_0x1b4f6f,R['getCompare']());return new g(_0x3eba2f,N(_0x1da61d),new ee({'.priority':_0x12702e},{'.priority':R}));}else return new g(_0x3eba2f,N(_0x1da61d),ee['Default']);}else{let _0x463734=g['EMPTY_NODE'];return x(_0x5f1473,(_0x5ddb5d,_0x1f66ef)=>{if(Y(_0x5f1473,_0x5ddb5d)&&_0x5ddb5d['substring'](0x0,0x1)!=='.'){const _0x25fe98=N(_0x1f66ef);(_0x25fe98['isLeafNode']()||!_0x25fe98['isEmpty']())&&(_0x463734=_0x463734['updateImmediateChild'](_0x5ddb5d,_0x25fe98));}}),_0x463734['updatePriority'](N(_0x1da61d));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2d0263){super(),this['indexPath_']=_0x2d0263,f(!v(_0x2d0263)&&y(_0x2d0263)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x591150){return _0x591150['getChild'](this['indexPath_']);}['isDefinedOn'](_0x21f401){return!_0x21f401['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x381308,_0x1d82df){const _0x40e260=this['extractChild'](_0x381308['node']),_0x4306a8=this['extractChild'](_0x1d82df['node']),_0x7b0329=_0x40e260['compareTo'](_0x4306a8);return _0x7b0329===0x0?He(_0x381308['name'],_0x1d82df['name']):_0x7b0329;}['makePost'](_0x1cf9c8,_0x401861){const _0x2dd51f=N(_0x1cf9c8),_0x55dd4d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2dd51f);return new E(_0x401861,_0x55dd4d);}['maxPost'](){const _0x2b5292=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x2b5292);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x243eff,_0x496c18){const _0x1d77cc=_0x243eff['node']['compareTo'](_0x496c18['node']);return _0x1d77cc===0x0?He(_0x243eff['name'],_0x496c18['name']):_0x1d77cc;}['isDefinedOn'](_0x334c11){return!0x0;}['indexedValueChanged'](_0x18a8ee,_0x1e56be){return!_0x18a8ee['equals'](_0x1e56be);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2835e1,_0x105f27){const _0x5057f0=N(_0x2835e1);return new E(_0x105f27,_0x5057f0);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x5455a5){return{'type':'value','snapshotNode':_0x5455a5};}function tt(_0x36af41,_0x42d46c){return{'type':'child_added','snapshotNode':_0x42d46c,'childName':_0x36af41};}function Nt(_0x1bcfca,_0x567578){return{'type':'child_removed','snapshotNode':_0x567578,'childName':_0x1bcfca};}function Pt(_0x2bdad3,_0x375148,_0x9215f0){return{'type':'child_changed','snapshotNode':_0x375148,'childName':_0x2bdad3,'oldSnap':_0x9215f0};}function $h(_0x76fc11,_0xe541d9){return{'type':'child_moved','snapshotNode':_0xe541d9,'childName':_0x76fc11};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x54bc51){this['index_']=_0x54bc51;}['updateChild'](_0x4635ac,_0x5ab731,_0xcdcd00,_0x3b50fd,_0x26f513,_0x13935b){f(_0x4635ac['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1f59de=_0x4635ac['getImmediateChild'](_0x5ab731);return _0x1f59de['getChild'](_0x3b50fd)['equals'](_0xcdcd00['getChild'](_0x3b50fd))&&_0x1f59de['isEmpty']()===_0xcdcd00['isEmpty']()||(_0x13935b!=null&&(_0xcdcd00['isEmpty']()?_0x4635ac['hasChild'](_0x5ab731)?_0x13935b['trackChildChange'](Nt(_0x5ab731,_0x1f59de)):f(_0x4635ac['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1f59de['isEmpty']()?_0x13935b['trackChildChange'](tt(_0x5ab731,_0xcdcd00)):_0x13935b['trackChildChange'](Pt(_0x5ab731,_0xcdcd00,_0x1f59de))),_0x4635ac['isLeafNode']()&&_0xcdcd00['isEmpty']())?_0x4635ac:_0x4635ac['updateImmediateChild'](_0x5ab731,_0xcdcd00)['withIndex'](this['index_']);}['updateFullNode'](_0x588005,_0xb92411,_0x2c8d4e){return _0x2c8d4e!=null&&(_0x588005['isLeafNode']()||_0x588005['forEachChild'](R,(_0x3f55ef,_0x394745)=>{_0xb92411['hasChild'](_0x3f55ef)||_0x2c8d4e['trackChildChange'](Nt(_0x3f55ef,_0x394745));}),_0xb92411['isLeafNode']()||_0xb92411['forEachChild'](R,(_0x560a8f,_0x46c406)=>{if(_0x588005['hasChild'](_0x560a8f)){const _0x4bec5d=_0x588005['getImmediateChild'](_0x560a8f);_0x4bec5d['equals'](_0x46c406)||_0x2c8d4e['trackChildChange'](Pt(_0x560a8f,_0x46c406,_0x4bec5d));}else _0x2c8d4e['trackChildChange'](tt(_0x560a8f,_0x46c406));})),_0xb92411['withIndex'](this['index_']);}['updatePriority'](_0x3c6681,_0x32dc4b){return _0x3c6681['isEmpty']()?g['EMPTY_NODE']:_0x3c6681['updatePriority'](_0x32dc4b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x3b18e5){this['indexedFilter_']=new Yi(_0x3b18e5['getIndex']()),this['index_']=_0x3b18e5['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x3b18e5),this['endPost_']=Ot['getEndPost_'](_0x3b18e5),this['startIsInclusive_']=!_0x3b18e5['startAfterSet_'],this['endIsInclusive_']=!_0x3b18e5['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x7da617){const _0x55df25=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x7da617)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x7da617)<0x0,_0x1b3b6e=this['endIsInclusive_']?this['index_']['compare'](_0x7da617,this['getEndPost']())<=0x0:this['index_']['compare'](_0x7da617,this['getEndPost']())<0x0;return _0x55df25&&_0x1b3b6e;}['updateChild'](_0x5b0c2d,_0x1fdaf3,_0x35737a,_0x1504e3,_0x342b3b,_0x42fbad){return this['matches'](new E(_0x1fdaf3,_0x35737a))||(_0x35737a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5b0c2d,_0x1fdaf3,_0x35737a,_0x1504e3,_0x342b3b,_0x42fbad);}['updateFullNode'](_0x3f4ea2,_0x1ec959,_0x36567e){_0x1ec959['isLeafNode']()&&(_0x1ec959=g['EMPTY_NODE']);let _0x2191be=_0x1ec959['withIndex'](this['index_']);_0x2191be=_0x2191be['updatePriority'](g['EMPTY_NODE']);const _0x1488ac=this;return _0x1ec959['forEachChild'](R,(_0x18b37f,_0x2b3c79)=>{_0x1488ac['matches'](new E(_0x18b37f,_0x2b3c79))||(_0x2191be=_0x2191be['updateImmediateChild'](_0x18b37f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3f4ea2,_0x2191be,_0x36567e);}['updatePriority'](_0x2bd8fb,_0x448d67){return _0x2bd8fb;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x46a4bd){if(_0x46a4bd['hasStart']()){const _0x491460=_0x46a4bd['getIndexStartName']();return _0x46a4bd['getIndex']()['makePost'](_0x46a4bd['getIndexStartValue'](),_0x491460);}else return _0x46a4bd['getIndex']()['minPost']();}static['getEndPost_'](_0x28be84){if(_0x28be84['hasEnd']()){const _0x13b82c=_0x28be84['getIndexEndName']();return _0x28be84['getIndex']()['makePost'](_0x28be84['getIndexEndValue'](),_0x13b82c);}else return _0x28be84['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x5d6e45){this['withinDirectionalStart']=_0xd98d1=>this['reverse_']?this['withinEndPost'](_0xd98d1):this['withinStartPost'](_0xd98d1),this['withinDirectionalEnd']=_0x3edceb=>this['reverse_']?this['withinStartPost'](_0x3edceb):this['withinEndPost'](_0x3edceb),this['withinStartPost']=_0x22effb=>{const _0x58a455=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x22effb);return this['startIsInclusive_']?_0x58a455<=0x0:_0x58a455<0x0;},this['withinEndPost']=_0x2d5911=>{const _0x1413e8=this['index_']['compare'](_0x2d5911,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1413e8<=0x0:_0x1413e8<0x0;},this['rangedFilter_']=new Ot(_0x5d6e45),this['index_']=_0x5d6e45['getIndex'](),this['limit_']=_0x5d6e45['getLimit'](),this['reverse_']=!_0x5d6e45['isViewFromLeft'](),this['startIsInclusive_']=!_0x5d6e45['startAfterSet_'],this['endIsInclusive_']=!_0x5d6e45['endBeforeSet_'];}['updateChild'](_0x37e81a,_0x2fc70d,_0x5eff2c,_0x2881ec,_0x46de02,_0x16e93e){return this['rangedFilter_']['matches'](new E(_0x2fc70d,_0x5eff2c))||(_0x5eff2c=g['EMPTY_NODE']),_0x37e81a['getImmediateChild'](_0x2fc70d)['equals'](_0x5eff2c)?_0x37e81a:_0x37e81a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x37e81a,_0x2fc70d,_0x5eff2c,_0x2881ec,_0x46de02,_0x16e93e):this['fullLimitUpdateChild_'](_0x37e81a,_0x2fc70d,_0x5eff2c,_0x46de02,_0x16e93e);}['updateFullNode'](_0x26f4a2,_0x40e043,_0x1610d3){let _0x39aff1;if(_0x40e043['isLeafNode']()||_0x40e043['isEmpty']())_0x39aff1=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x40e043['numChildren']()&&_0x40e043['isIndexed'](this['index_'])){_0x39aff1=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x58c86f;this['reverse_']?_0x58c86f=_0x40e043['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x58c86f=_0x40e043['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x898e08=0x0;for(;_0x58c86f['hasNext']()&&_0x898e08<this['limit_'];){const _0xc2f98b=_0x58c86f['getNext']();if(this['withinDirectionalStart'](_0xc2f98b)){if(this['withinDirectionalEnd'](_0xc2f98b))_0x39aff1=_0x39aff1['updateImmediateChild'](_0xc2f98b['name'],_0xc2f98b['node']),_0x898e08++;else break;}else continue;}}else{_0x39aff1=_0x40e043['withIndex'](this['index_']),_0x39aff1=_0x39aff1['updatePriority'](g['EMPTY_NODE']);let _0x313233;this['reverse_']?_0x313233=_0x39aff1['getReverseIterator'](this['index_']):_0x313233=_0x39aff1['getIterator'](this['index_']);let _0x5c5387=0x0;for(;_0x313233['hasNext']();){const _0x3c9a0c=_0x313233['getNext']();_0x5c5387<this['limit_']&&this['withinDirectionalStart'](_0x3c9a0c)&&this['withinDirectionalEnd'](_0x3c9a0c)?_0x5c5387++:_0x39aff1=_0x39aff1['updateImmediateChild'](_0x3c9a0c['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x26f4a2,_0x39aff1,_0x1610d3);}['updatePriority'](_0x3a6269,_0x144241){return _0x3a6269;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x12eec3,_0x319a49,_0x4b7473,_0x5a8d5c,_0x5e568b){let _0x311fa0;if(this['reverse_']){const _0x5ba26f=this['index_']['getCompare']();_0x311fa0=(_0x1ef489,_0x506ca0)=>_0x5ba26f(_0x506ca0,_0x1ef489);}else _0x311fa0=this['index_']['getCompare']();const _0xa8bf74=_0x12eec3;f(_0xa8bf74['numChildren']()===this['limit_'],'');const _0x51e530=new E(_0x319a49,_0x4b7473),_0x4f2b6e=this['reverse_']?_0xa8bf74['getFirstChild'](this['index_']):_0xa8bf74['getLastChild'](this['index_']),_0x5766f7=this['rangedFilter_']['matches'](_0x51e530);if(_0xa8bf74['hasChild'](_0x319a49)){const _0xeee56d=_0xa8bf74['getImmediateChild'](_0x319a49);let _0x316aa0=_0x5a8d5c['getChildAfterChild'](this['index_'],_0x4f2b6e,this['reverse_']);for(;_0x316aa0!=null&&(_0x316aa0['name']===_0x319a49||_0xa8bf74['hasChild'](_0x316aa0['name']));)_0x316aa0=_0x5a8d5c['getChildAfterChild'](this['index_'],_0x316aa0,this['reverse_']);const _0x452a67=_0x316aa0==null?0x1:_0x311fa0(_0x316aa0,_0x51e530);if(_0x5766f7&&!_0x4b7473['isEmpty']()&&_0x452a67>=0x0)return _0x5e568b!=null&&_0x5e568b['trackChildChange'](Pt(_0x319a49,_0x4b7473,_0xeee56d)),_0xa8bf74['updateImmediateChild'](_0x319a49,_0x4b7473);{_0x5e568b!=null&&_0x5e568b['trackChildChange'](Nt(_0x319a49,_0xeee56d));const _0x3ee2c9=_0xa8bf74['updateImmediateChild'](_0x319a49,g['EMPTY_NODE']);return _0x316aa0!=null&&this['rangedFilter_']['matches'](_0x316aa0)?(_0x5e568b!=null&&_0x5e568b['trackChildChange'](tt(_0x316aa0['name'],_0x316aa0['node'])),_0x3ee2c9['updateImmediateChild'](_0x316aa0['name'],_0x316aa0['node'])):_0x3ee2c9;}}else return _0x4b7473['isEmpty']()?_0x12eec3:_0x5766f7&&_0x311fa0(_0x4f2b6e,_0x51e530)>=0x0?(_0x5e568b!=null&&(_0x5e568b['trackChildChange'](Nt(_0x4f2b6e['name'],_0x4f2b6e['node'])),_0x5e568b['trackChildChange'](tt(_0x319a49,_0x4b7473))),_0xa8bf74['updateImmediateChild'](_0x319a49,_0x4b7473)['updateImmediateChild'](_0x4f2b6e['name'],g['EMPTY_NODE'])):_0x12eec3;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x292a0c=new Qi();return _0x292a0c['limitSet_']=this['limitSet_'],_0x292a0c['limit_']=this['limit_'],_0x292a0c['startSet_']=this['startSet_'],_0x292a0c['startAfterSet_']=this['startAfterSet_'],_0x292a0c['indexStartValue_']=this['indexStartValue_'],_0x292a0c['startNameSet_']=this['startNameSet_'],_0x292a0c['indexStartName_']=this['indexStartName_'],_0x292a0c['endSet_']=this['endSet_'],_0x292a0c['endBeforeSet_']=this['endBeforeSet_'],_0x292a0c['indexEndValue_']=this['indexEndValue_'],_0x292a0c['endNameSet_']=this['endNameSet_'],_0x292a0c['indexEndName_']=this['indexEndName_'],_0x292a0c['index_']=this['index_'],_0x292a0c['viewFrom_']=this['viewFrom_'],_0x292a0c;}}function qh(_0x471138){return _0x471138['loadsAllData']()?new Yi(_0x471138['getIndex']()):_0x471138['hasLimit']()?new Gh(_0x471138):new Ot(_0x471138);}function zh(_0x33d2a2,_0x48d523){const _0x49cd8e=_0x33d2a2['copy']();return _0x49cd8e['limitSet_']=!0x0,_0x49cd8e['limit_']=_0x48d523,_0x49cd8e['viewFrom_']='l',_0x49cd8e;}function jh(_0x2182e0,_0x3d18f9,_0x5b5e8a){const _0x15e724=_0x2182e0['copy']();return _0x15e724['startSet_']=!0x0,_0x3d18f9===void 0x0&&(_0x3d18f9=null),_0x15e724['indexStartValue_']=_0x3d18f9,_0x5b5e8a!=null?(_0x15e724['startNameSet_']=!0x0,_0x15e724['indexStartName_']=_0x5b5e8a):(_0x15e724['startNameSet_']=!0x1,_0x15e724['indexStartName_']=''),_0x15e724;}function Kh(_0x637c9e,_0x5f1373,_0x8d3b22){const _0x758d8a=_0x637c9e['copy']();return _0x758d8a['endSet_']=!0x0,_0x5f1373===void 0x0&&(_0x5f1373=null),_0x758d8a['indexEndValue_']=_0x5f1373,_0x8d3b22!==void 0x0?(_0x758d8a['endNameSet_']=!0x0,_0x758d8a['indexEndName_']=_0x8d3b22):(_0x758d8a['endNameSet_']=!0x1,_0x758d8a['indexEndName_']=''),_0x758d8a;}function Do(_0x2d70a0,_0x18345b){const _0x102175=_0x2d70a0['copy']();return _0x102175['index_']=_0x18345b,_0x102175;}function tr(_0x533011){const _0x4d0647={};if(_0x533011['isDefault']())return _0x4d0647;let _0x55d9f2;if(_0x533011['index_']===R?_0x55d9f2='$priority':_0x533011['index_']===Po?_0x55d9f2='$value':_0x533011['index_']===ye?_0x55d9f2='$key':(f(_0x533011['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x55d9f2=_0x533011['index_']['toString']()),_0x4d0647['orderBy']=O(_0x55d9f2),_0x533011['startSet_']){const _0x1ffc62=_0x533011['startAfterSet_']?'startAfter':'startAt';_0x4d0647[_0x1ffc62]=O(_0x533011['indexStartValue_']),_0x533011['startNameSet_']&&(_0x4d0647[_0x1ffc62]+=','+O(_0x533011['indexStartName_']));}if(_0x533011['endSet_']){const _0x5a4056=_0x533011['endBeforeSet_']?'endBefore':'endAt';_0x4d0647[_0x5a4056]=O(_0x533011['indexEndValue_']),_0x533011['endNameSet_']&&(_0x4d0647[_0x5a4056]+=','+O(_0x533011['indexEndName_']));}return _0x533011['limitSet_']&&(_0x533011['isViewFromLeft']()?_0x4d0647['limitToFirst']=_0x533011['limit_']:_0x4d0647['limitToLast']=_0x533011['limit_']),_0x4d0647;}function nr(_0x527dad){const _0x53a0ae={};if(_0x527dad['startSet_']&&(_0x53a0ae['sp']=_0x527dad['indexStartValue_'],_0x527dad['startNameSet_']&&(_0x53a0ae['sn']=_0x527dad['indexStartName_']),_0x53a0ae['sin']=!_0x527dad['startAfterSet_']),_0x527dad['endSet_']&&(_0x53a0ae['ep']=_0x527dad['indexEndValue_'],_0x527dad['endNameSet_']&&(_0x53a0ae['en']=_0x527dad['indexEndName_']),_0x53a0ae['ein']=!_0x527dad['endBeforeSet_']),_0x527dad['limitSet_']){_0x53a0ae['l']=_0x527dad['limit_'];let _0x1c59ff=_0x527dad['viewFrom_'];_0x1c59ff===''&&(_0x527dad['isViewFromLeft']()?_0x1c59ff='l':_0x1c59ff='r'),_0x53a0ae['vf']=_0x1c59ff;}return _0x527dad['index_']!==R&&(_0x53a0ae['i']=_0x527dad['index_']['toString']()),_0x53a0ae;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x24321b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5b0e7b,_0x196f0b){return _0x196f0b!==void 0x0?'tag$'+_0x196f0b:(f(_0x5b0e7b['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5b0e7b['_path']['toString']());}constructor(_0x2acd8,_0x2447bd,_0x4715ca,_0x89ea47){super(),this['repoInfo_']=_0x2acd8,this['onDataUpdate_']=_0x2447bd,this['authTokenProvider_']=_0x4715ca,this['appCheckTokenProvider_']=_0x89ea47,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x40751e,_0x29ff0f,_0x251ac1,_0x1f6ae6){const _0xe7307d=_0x40751e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xe7307d+'\x20'+_0x40751e['_queryIdentifier']);const _0x50b9f6=fn['getListenId_'](_0x40751e,_0x251ac1),_0x2c350e={};this['listens_'][_0x50b9f6]=_0x2c350e;const _0x4825d9=tr(_0x40751e['_queryParams']);this['restRequest_'](_0xe7307d+'.json',_0x4825d9,(_0x41421e,_0x1a8b4f)=>{let _0x31e12b=_0x1a8b4f;if(_0x41421e===0x194&&(_0x31e12b=null,_0x41421e=null),_0x41421e===null&&this['onDataUpdate_'](_0xe7307d,_0x31e12b,!0x1,_0x251ac1),Oe(this['listens_'],_0x50b9f6)===_0x2c350e){let _0x31c710;_0x41421e?_0x41421e===0x191?_0x31c710='permission_denied':_0x31c710='rest_error:'+_0x41421e:_0x31c710='ok',_0x1f6ae6(_0x31c710,null);}});}['unlisten'](_0x27d9c8,_0x2a0c13){const _0x21196e=fn['getListenId_'](_0x27d9c8,_0x2a0c13);delete this['listens_'][_0x21196e];}['get'](_0x360db0){const _0x2f960e=tr(_0x360db0['_queryParams']),_0x3eb7d8=_0x360db0['_path']['toString'](),_0x43dea4=new Ve();return this['restRequest_'](_0x3eb7d8+'.json',_0x2f960e,(_0x430a87,_0x130aea)=>{let _0x20ef74=_0x130aea;_0x430a87===0x194&&(_0x20ef74=null,_0x430a87=null),_0x430a87===null?(this['onDataUpdate_'](_0x3eb7d8,_0x20ef74,!0x1,null),_0x43dea4['resolve'](_0x20ef74)):_0x43dea4['reject'](new Error(_0x20ef74));}),_0x43dea4['promise'];}['refreshAuthToken'](_0xc1b2b){}['restRequest_'](_0x4920a5,_0x145a17={},_0x459384){return _0x145a17['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3558a9,_0xe75ead])=>{_0x3558a9&&_0x3558a9['accessToken']&&(_0x145a17['auth']=_0x3558a9['accessToken']),_0xe75ead&&_0xe75ead['token']&&(_0x145a17['ac']=_0xe75ead['token']);const _0x10f1c6=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4920a5+'?ns='+this['repoInfo_']['namespace']+at(_0x145a17);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x10f1c6);const _0x4ceaf9=new XMLHttpRequest();_0x4ceaf9['onreadystatechange']=()=>{if(_0x459384&&_0x4ceaf9['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x10f1c6+'\x20received.\x20status:',_0x4ceaf9['status'],'response:',_0x4ceaf9['responseText']);let _0x25448e=null;if(_0x4ceaf9['status']>=0xc8&&_0x4ceaf9['status']<0x12c){try{_0x25448e=bt(_0x4ceaf9['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x10f1c6+':\x20'+_0x4ceaf9['responseText']);}_0x459384(null,_0x25448e);}else _0x4ceaf9['status']!==0x191&&_0x4ceaf9['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x10f1c6+'\x20Status:\x20'+_0x4ceaf9['status']),_0x459384(_0x4ceaf9['status']);_0x459384=null;}},_0x4ceaf9['open']('GET',_0x10f1c6,!0x0),_0x4ceaf9['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x125a16){return this['rootNode_']['getChild'](_0x125a16);}['updateSnapshot'](_0x17bb8c,_0x519f68){this['rootNode_']=this['rootNode_']['updateChild'](_0x17bb8c,_0x519f68);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x45e7ba,_0x511573,_0x21b2d7){if(v(_0x511573))_0x45e7ba['value']=_0x21b2d7,_0x45e7ba['children']['clear']();else{if(_0x45e7ba['value']!==null)_0x45e7ba['value']=_0x45e7ba['value']['updateChild'](_0x511573,_0x21b2d7);else{const _0x3adf20=y(_0x511573);_0x45e7ba['children']['has'](_0x3adf20)||_0x45e7ba['children']['set'](_0x3adf20,pn());const _0x227339=_0x45e7ba['children']['get'](_0x3adf20);_0x511573=b(_0x511573),Mo(_0x227339,_0x511573,_0x21b2d7);}}}function Ei(_0x372fcd,_0x1f499d,_0x375523){_0x372fcd['value']!==null?_0x375523(_0x1f499d,_0x372fcd['value']):Qh(_0x372fcd,(_0x560e69,_0x27ba27)=>{const _0x2dd4bd=new C(_0x1f499d['toString']()+'/'+_0x560e69);Ei(_0x27ba27,_0x2dd4bd,_0x375523);});}function Qh(_0x47c87d,_0x2f3f99){_0x47c87d['children']['forEach']((_0x273bd3,_0x45a78d)=>{_0x2f3f99(_0x45a78d,_0x273bd3);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0xb6c347){this['collection_']=_0xb6c347,this['last_']=null;}['get'](){const _0x159a5a=this['collection_']['get'](),_0x5df1d0={..._0x159a5a};return this['last_']&&x(this['last_'],(_0x2ccc36,_0x4350d1)=>{_0x5df1d0[_0x2ccc36]=_0x5df1d0[_0x2ccc36]-_0x4350d1;}),this['last_']=_0x159a5a,_0x5df1d0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x35e767,_0x738dae){this['server_']=_0x738dae,this['statsToReport_']={},this['statsListener_']=new Jh(_0x35e767);const _0x4afae1=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x4afae1));}['reportStats_'](){const _0x289732=this['statsListener_']['get'](),_0x35be8d={};let _0x43aa12=!0x1;x(_0x289732,(_0x3061bb,_0x365aed)=>{_0x365aed>0x0&&Y(this['statsToReport_'],_0x3061bb)&&(_0x35be8d[_0x3061bb]=_0x365aed,_0x43aa12=!0x0);}),_0x43aa12&&this['server_']['reportStats'](_0x35be8d),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x431be9){_0x431be9[_0x431be9['OVERWRITE']=0x0]='OVERWRITE',_0x431be9[_0x431be9['MERGE']=0x1]='MERGE',_0x431be9[_0x431be9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x431be9[_0x431be9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x2c3fad){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2c3fad,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x16f74d,_0x282697,_0x494b92){this['path']=_0x16f74d,this['affectedTree']=_0x282697,this['revert']=_0x494b92,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x159757){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x418531=this['affectedTree']['subtree'](new C(_0x159757));return new _n(w(),_0x418531,this['revert']);}}else return f(y(this['path'])===_0x159757,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x365239,_0x451029){this['source']=_0x365239,this['path']=_0x451029,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x4cedd7){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x2ce786,_0x22d753,_0x59f700){this['source']=_0x2ce786,this['path']=_0x22d753,this['snap']=_0x59f700,this['type']=q['OVERWRITE'];}['operationForChild'](_0x4a26d0){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x4a26d0)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x54d0f3,_0x52f1d0,_0x34b4d7){this['source']=_0x54d0f3,this['path']=_0x52f1d0,this['children']=_0x34b4d7,this['type']=q['MERGE'];}['operationForChild'](_0x38d2fb){if(v(this['path'])){const _0x39fece=this['children']['subtree'](new C(_0x38d2fb));return _0x39fece['isEmpty']()?null:_0x39fece['value']?new Fe(this['source'],w(),_0x39fece['value']):new nt(this['source'],w(),_0x39fece);}else return f(y(this['path'])===_0x38d2fb,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x18388e,_0x54258f,_0x373b8f){this['node_']=_0x18388e,this['fullyInitialized_']=_0x54258f,this['filtered_']=_0x373b8f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x3bdd18){if(v(_0x3bdd18))return this['isFullyInitialized']()&&!this['filtered_'];const _0x506a1e=y(_0x3bdd18);return this['isCompleteForChild'](_0x506a1e);}['isCompleteForChild'](_0x51a329){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x51a329);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x2606b6){this['query_']=_0x2606b6,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x4226c4,_0x401ddb,_0x49b189,_0x93b7f){const _0x1e9858=[],_0x24de9d=[];return _0x401ddb['forEach'](_0x501d80=>{_0x501d80['type']==='child_changed'&&_0x4226c4['index_']['indexedValueChanged'](_0x501d80['oldSnap'],_0x501d80['snapshotNode'])&&_0x24de9d['push']($h(_0x501d80['childName'],_0x501d80['snapshotNode']));}),mt(_0x4226c4,_0x1e9858,'child_removed',_0x401ddb,_0x93b7f,_0x49b189),mt(_0x4226c4,_0x1e9858,'child_added',_0x401ddb,_0x93b7f,_0x49b189),mt(_0x4226c4,_0x1e9858,'child_moved',_0x24de9d,_0x93b7f,_0x49b189),mt(_0x4226c4,_0x1e9858,'child_changed',_0x401ddb,_0x93b7f,_0x49b189),mt(_0x4226c4,_0x1e9858,'value',_0x401ddb,_0x93b7f,_0x49b189),_0x1e9858;}function mt(_0x5716c8,_0xad56a9,_0x2582f7,_0x24ed88,_0x26e781,_0x2a8a61){const _0x71e68f=_0x24ed88['filter'](_0x302740=>_0x302740['type']===_0x2582f7);_0x71e68f['sort']((_0x4ee50b,_0x4c53fd)=>su(_0x5716c8,_0x4ee50b,_0x4c53fd)),_0x71e68f['forEach'](_0x5a16ab=>{const _0x811b6f=iu(_0x5716c8,_0x5a16ab,_0x2a8a61);_0x26e781['forEach'](_0x294f4b=>{_0x294f4b['respondsTo'](_0x5a16ab['type'])&&_0xad56a9['push'](_0x294f4b['createEvent'](_0x811b6f,_0x5716c8['query_']));});});}function iu(_0x52db2e,_0x2392ab,_0x3f1539){return _0x2392ab['type']==='value'||_0x2392ab['type']==='child_removed'||(_0x2392ab['prevName']=_0x3f1539['getPredecessorChildName'](_0x2392ab['childName'],_0x2392ab['snapshotNode'],_0x52db2e['index_'])),_0x2392ab;}function su(_0x40e0d9,_0x26bc69,_0x47ea26){if(_0x26bc69['childName']==null||_0x47ea26['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x570886=new E(_0x26bc69['childName'],_0x26bc69['snapshotNode']),_0x48348f=new E(_0x47ea26['childName'],_0x47ea26['snapshotNode']);return _0x40e0d9['index_']['compare'](_0x570886,_0x48348f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x5c74fd,_0x1a4666){return{'eventCache':_0x5c74fd,'serverCache':_0x1a4666};}function wt(_0x1fbe0d,_0x43a8ca,_0x5e64fd,_0xfa7725){return Dn(new Ce(_0x43a8ca,_0x5e64fd,_0xfa7725),_0x1fbe0d['serverCache']);}function Lo(_0x5f1442,_0x1399e2,_0x2d53bc,_0x4ca737){return Dn(_0x5f1442['eventCache'],new Ce(_0x1399e2,_0x2d53bc,_0x4ca737));}function gn(_0x175729){return _0x175729['eventCache']['isFullyInitialized']()?_0x175729['eventCache']['getNode']():null;}function Ue(_0x4895f7){return _0x4895f7['serverCache']['isFullyInitialized']()?_0x4895f7['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0xeb052d){let _0x2ff5d7=new S(null);return x(_0xeb052d,(_0x2a90bc,_0xd10456)=>{_0x2ff5d7=_0x2ff5d7['set'](new C(_0x2a90bc),_0xd10456);}),_0x2ff5d7;}constructor(_0xe74496,_0x240538=ru()){this['value']=_0xe74496,this['children']=_0x240538;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x491444,_0xa1920){if(this['value']!=null&&_0xa1920(this['value']))return{'path':w(),'value':this['value']};if(v(_0x491444))return null;{const _0x20d74c=y(_0x491444),_0x54ca71=this['children']['get'](_0x20d74c);if(_0x54ca71!==null){const _0x27e91e=_0x54ca71['findRootMostMatchingPathAndValue'](b(_0x491444),_0xa1920);return _0x27e91e!=null?{'path':A(new C(_0x20d74c),_0x27e91e['path']),'value':_0x27e91e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xc073cd){return this['findRootMostMatchingPathAndValue'](_0xc073cd,()=>!0x0);}['subtree'](_0x4d46d4){if(v(_0x4d46d4))return this;{const _0x26f929=y(_0x4d46d4),_0x31a0a0=this['children']['get'](_0x26f929);return _0x31a0a0!==null?_0x31a0a0['subtree'](b(_0x4d46d4)):new S(null);}}['set'](_0x7fdfe,_0x1b5a9e){if(v(_0x7fdfe))return new S(_0x1b5a9e,this['children']);{const _0x1f570e=y(_0x7fdfe),_0x37902a=(this['children']['get'](_0x1f570e)||new S(null))['set'](b(_0x7fdfe),_0x1b5a9e),_0x150b40=this['children']['insert'](_0x1f570e,_0x37902a);return new S(this['value'],_0x150b40);}}['remove'](_0x1fb628){if(v(_0x1fb628))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x4013f5=y(_0x1fb628),_0x2acb35=this['children']['get'](_0x4013f5);if(_0x2acb35){const _0x5a7aaf=_0x2acb35['remove'](b(_0x1fb628));let _0x4fa8e7;return _0x5a7aaf['isEmpty']()?_0x4fa8e7=this['children']['remove'](_0x4013f5):_0x4fa8e7=this['children']['insert'](_0x4013f5,_0x5a7aaf),this['value']===null&&_0x4fa8e7['isEmpty']()?new S(null):new S(this['value'],_0x4fa8e7);}else return this;}}['get'](_0x52cba1){if(v(_0x52cba1))return this['value'];{const _0x397c37=y(_0x52cba1),_0x4df3a=this['children']['get'](_0x397c37);return _0x4df3a?_0x4df3a['get'](b(_0x52cba1)):null;}}['setTree'](_0x4b1382,_0x5cb7dd){if(v(_0x4b1382))return _0x5cb7dd;{const _0x382806=y(_0x4b1382),_0x20f8c0=(this['children']['get'](_0x382806)||new S(null))['setTree'](b(_0x4b1382),_0x5cb7dd);let _0x4b3e5f;return _0x20f8c0['isEmpty']()?_0x4b3e5f=this['children']['remove'](_0x382806):_0x4b3e5f=this['children']['insert'](_0x382806,_0x20f8c0),new S(this['value'],_0x4b3e5f);}}['fold'](_0x1c1cc4){return this['fold_'](w(),_0x1c1cc4);}['fold_'](_0x2335c7,_0x5a286a){const _0x2cfef9={};return this['children']['inorderTraversal']((_0x22273e,_0x2edea3)=>{_0x2cfef9[_0x22273e]=_0x2edea3['fold_'](A(_0x2335c7,_0x22273e),_0x5a286a);}),_0x5a286a(_0x2335c7,this['value'],_0x2cfef9);}['findOnPath'](_0x5614a2,_0x12e201){return this['findOnPath_'](_0x5614a2,w(),_0x12e201);}['findOnPath_'](_0x45232f,_0x5afe10,_0x301b4b){const _0x23dad4=this['value']?_0x301b4b(_0x5afe10,this['value']):!0x1;if(_0x23dad4)return _0x23dad4;if(v(_0x45232f))return null;{const _0x32d342=y(_0x45232f),_0xb75360=this['children']['get'](_0x32d342);return _0xb75360?_0xb75360['findOnPath_'](b(_0x45232f),A(_0x5afe10,_0x32d342),_0x301b4b):null;}}['foreachOnPath'](_0xf97221,_0x4bead5){return this['foreachOnPath_'](_0xf97221,w(),_0x4bead5);}['foreachOnPath_'](_0x59b738,_0x3505a2,_0x2c1c77){if(v(_0x59b738))return this;{this['value']&&_0x2c1c77(_0x3505a2,this['value']);const _0x5d833e=y(_0x59b738),_0x4fce38=this['children']['get'](_0x5d833e);return _0x4fce38?_0x4fce38['foreachOnPath_'](b(_0x59b738),A(_0x3505a2,_0x5d833e),_0x2c1c77):new S(null);}}['foreach'](_0x285f69){this['foreach_'](w(),_0x285f69);}['foreach_'](_0x54ad5d,_0x3374ba){this['children']['inorderTraversal']((_0x3f732f,_0x757070)=>{_0x757070['foreach_'](A(_0x54ad5d,_0x3f732f),_0x3374ba);}),this['value']&&_0x3374ba(_0x54ad5d,this['value']);}['foreachChild'](_0x27bc5d){this['children']['inorderTraversal']((_0x54af55,_0x58cb7a)=>{_0x58cb7a['value']&&_0x27bc5d(_0x54af55,_0x58cb7a['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x2826cd){this['writeTree_']=_0x2826cd;}static['empty'](){return new j(new S(null));}}function Ct(_0x3401b7,_0x168f20,_0x457c8c){if(v(_0x168f20))return new j(new S(_0x457c8c));{const _0x1d7f21=_0x3401b7['writeTree_']['findRootMostValueAndPath'](_0x168f20);if(_0x1d7f21!=null){const _0x46179e=_0x1d7f21['path'];let _0x24b423=_0x1d7f21['value'];const _0x33cea8=F(_0x46179e,_0x168f20);return _0x24b423=_0x24b423['updateChild'](_0x33cea8,_0x457c8c),new j(_0x3401b7['writeTree_']['set'](_0x46179e,_0x24b423));}else{const _0x1e6aff=new S(_0x457c8c),_0x2f9ea2=_0x3401b7['writeTree_']['setTree'](_0x168f20,_0x1e6aff);return new j(_0x2f9ea2);}}}function Ii(_0x4cc316,_0x2af15f,_0x143bcd){let _0x2479a5=_0x4cc316;return x(_0x143bcd,(_0x27f2bd,_0xac88e9)=>{_0x2479a5=Ct(_0x2479a5,A(_0x2af15f,_0x27f2bd),_0xac88e9);}),_0x2479a5;}function sr(_0x478f8b,_0xdc6345){if(v(_0xdc6345))return j['empty']();{const _0x5da832=_0x478f8b['writeTree_']['setTree'](_0xdc6345,new S(null));return new j(_0x5da832);}}function wi(_0x454466,_0x2a11c4){return $e(_0x454466,_0x2a11c4)!=null;}function $e(_0x3fc49d,_0x48be84){const _0x39ed59=_0x3fc49d['writeTree_']['findRootMostValueAndPath'](_0x48be84);return _0x39ed59!=null?_0x3fc49d['writeTree_']['get'](_0x39ed59['path'])['getChild'](F(_0x39ed59['path'],_0x48be84)):null;}function rr(_0x56aad8){const _0x2ea75b=[],_0xf06f71=_0x56aad8['writeTree_']['value'];return _0xf06f71!=null?_0xf06f71['isLeafNode']()||_0xf06f71['forEachChild'](R,(_0x58d88f,_0x496519)=>{_0x2ea75b['push'](new E(_0x58d88f,_0x496519));}):_0x56aad8['writeTree_']['children']['inorderTraversal']((_0x5611e3,_0x16698b)=>{_0x16698b['value']!=null&&_0x2ea75b['push'](new E(_0x5611e3,_0x16698b['value']));}),_0x2ea75b;}function ve(_0x22abed,_0x3e5459){if(v(_0x3e5459))return _0x22abed;{const _0x3d4b47=$e(_0x22abed,_0x3e5459);return _0x3d4b47!=null?new j(new S(_0x3d4b47)):new j(_0x22abed['writeTree_']['subtree'](_0x3e5459));}}function Ci(_0x154259){return _0x154259['writeTree_']['isEmpty']();}function it(_0x174db2,_0x4809b1){return xo(w(),_0x174db2['writeTree_'],_0x4809b1);}function xo(_0xd55407,_0x251f16,_0xa2912a){if(_0x251f16['value']!=null)return _0xa2912a['updateChild'](_0xd55407,_0x251f16['value']);{let _0xf764f7=null;return _0x251f16['children']['inorderTraversal']((_0x2bf046,_0x462fa7)=>{_0x2bf046==='.priority'?(f(_0x462fa7['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xf764f7=_0x462fa7['value']):_0xa2912a=xo(A(_0xd55407,_0x2bf046),_0x462fa7,_0xa2912a);}),!_0xa2912a['getChild'](_0xd55407)['isEmpty']()&&_0xf764f7!==null&&(_0xa2912a=_0xa2912a['updateChild'](A(_0xd55407,'.priority'),_0xf764f7)),_0xa2912a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x5b417c,_0x459770){return Bo(_0x459770,_0x5b417c);}function ou(_0x3700ac,_0x167d62,_0x6838b7,_0xb76135,_0x5e34e8){f(_0xb76135>_0x3700ac['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5e34e8===void 0x0&&(_0x5e34e8=!0x0),_0x3700ac['allWrites']['push']({'path':_0x167d62,'snap':_0x6838b7,'writeId':_0xb76135,'visible':_0x5e34e8}),_0x5e34e8&&(_0x3700ac['visibleWrites']=Ct(_0x3700ac['visibleWrites'],_0x167d62,_0x6838b7)),_0x3700ac['lastWriteId']=_0xb76135;}function au(_0x1b5989,_0x444618,_0xfbe25a,_0x4feec4){f(_0x4feec4>_0x1b5989['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1b5989['allWrites']['push']({'path':_0x444618,'children':_0xfbe25a,'writeId':_0x4feec4,'visible':!0x0}),_0x1b5989['visibleWrites']=Ii(_0x1b5989['visibleWrites'],_0x444618,_0xfbe25a),_0x1b5989['lastWriteId']=_0x4feec4;}function cu(_0x1869ee,_0x20877b){for(let _0x520b1b=0x0;_0x520b1b<_0x1869ee['allWrites']['length'];_0x520b1b++){const _0x251dc5=_0x1869ee['allWrites'][_0x520b1b];if(_0x251dc5['writeId']===_0x20877b)return _0x251dc5;}return null;}function lu(_0x167074,_0x4159de){const _0x49e52a=_0x167074['allWrites']['findIndex'](_0x116c9f=>_0x116c9f['writeId']===_0x4159de);f(_0x49e52a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x3201ca=_0x167074['allWrites'][_0x49e52a];_0x167074['allWrites']['splice'](_0x49e52a,0x1);let _0x5bc2f7=_0x3201ca['visible'],_0x3a9f9b=!0x1,_0x3cb218=_0x167074['allWrites']['length']-0x1;for(;_0x5bc2f7&&_0x3cb218>=0x0;){const _0x139cbd=_0x167074['allWrites'][_0x3cb218];_0x139cbd['visible']&&(_0x3cb218>=_0x49e52a&&hu(_0x139cbd,_0x3201ca['path'])?_0x5bc2f7=!0x1:$(_0x3201ca['path'],_0x139cbd['path'])&&(_0x3a9f9b=!0x0)),_0x3cb218--;}if(_0x5bc2f7){if(_0x3a9f9b)return uu(_0x167074),!0x0;if(_0x3201ca['snap'])_0x167074['visibleWrites']=sr(_0x167074['visibleWrites'],_0x3201ca['path']);else{const _0x2c8151=_0x3201ca['children'];x(_0x2c8151,_0x2cc849=>{_0x167074['visibleWrites']=sr(_0x167074['visibleWrites'],A(_0x3201ca['path'],_0x2cc849));});}return!0x0;}else return!0x1;}function hu(_0x1ff2fb,_0x273cc8){if(_0x1ff2fb['snap'])return $(_0x1ff2fb['path'],_0x273cc8);for(const _0x426902 in _0x1ff2fb['children'])if(_0x1ff2fb['children']['hasOwnProperty'](_0x426902)&&$(A(_0x1ff2fb['path'],_0x426902),_0x273cc8))return!0x0;return!0x1;}function uu(_0x38f17b){_0x38f17b['visibleWrites']=Fo(_0x38f17b['allWrites'],du,w()),_0x38f17b['allWrites']['length']>0x0?_0x38f17b['lastWriteId']=_0x38f17b['allWrites'][_0x38f17b['allWrites']['length']-0x1]['writeId']:_0x38f17b['lastWriteId']=-0x1;}function du(_0x36038c){return _0x36038c['visible'];}function Fo(_0x4c1ffb,_0x1c6bc8,_0x1584fe){let _0x1334d0=j['empty']();for(let _0x317ae2=0x0;_0x317ae2<_0x4c1ffb['length'];++_0x317ae2){const _0x35ab3b=_0x4c1ffb[_0x317ae2];if(_0x1c6bc8(_0x35ab3b)){const _0x37f519=_0x35ab3b['path'];let _0x28e656;if(_0x35ab3b['snap'])$(_0x1584fe,_0x37f519)?(_0x28e656=F(_0x1584fe,_0x37f519),_0x1334d0=Ct(_0x1334d0,_0x28e656,_0x35ab3b['snap'])):$(_0x37f519,_0x1584fe)&&(_0x28e656=F(_0x37f519,_0x1584fe),_0x1334d0=Ct(_0x1334d0,w(),_0x35ab3b['snap']['getChild'](_0x28e656)));else{if(_0x35ab3b['children']){if($(_0x1584fe,_0x37f519))_0x28e656=F(_0x1584fe,_0x37f519),_0x1334d0=Ii(_0x1334d0,_0x28e656,_0x35ab3b['children']);else{if($(_0x37f519,_0x1584fe)){if(_0x28e656=F(_0x37f519,_0x1584fe),v(_0x28e656))_0x1334d0=Ii(_0x1334d0,w(),_0x35ab3b['children']);else{const _0x512849=Oe(_0x35ab3b['children'],y(_0x28e656));if(_0x512849){const _0x5957c5=_0x512849['getChild'](b(_0x28e656));_0x1334d0=Ct(_0x1334d0,w(),_0x5957c5);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1334d0;}function Uo(_0x4bb1b3,_0x29fdba,_0x2d14ce,_0x48d529,_0x3debe7){if(!_0x48d529&&!_0x3debe7){const _0x58e456=$e(_0x4bb1b3['visibleWrites'],_0x29fdba);if(_0x58e456!=null)return _0x58e456;{const _0x419637=ve(_0x4bb1b3['visibleWrites'],_0x29fdba);if(Ci(_0x419637))return _0x2d14ce;if(_0x2d14ce==null&&!wi(_0x419637,w()))return null;{const _0x6ebb90=_0x2d14ce||g['EMPTY_NODE'];return it(_0x419637,_0x6ebb90);}}}else{const _0x52092d=ve(_0x4bb1b3['visibleWrites'],_0x29fdba);if(!_0x3debe7&&Ci(_0x52092d))return _0x2d14ce;if(!_0x3debe7&&_0x2d14ce==null&&!wi(_0x52092d,w()))return null;{const _0x55e893=function(_0x562479){return(_0x562479['visible']||_0x3debe7)&&(!_0x48d529||!~_0x48d529['indexOf'](_0x562479['writeId']))&&($(_0x562479['path'],_0x29fdba)||$(_0x29fdba,_0x562479['path']));},_0x1e6aeb=Fo(_0x4bb1b3['allWrites'],_0x55e893,_0x29fdba),_0x114579=_0x2d14ce||g['EMPTY_NODE'];return it(_0x1e6aeb,_0x114579);}}}function fu(_0x14e33b,_0x58c322,_0x29b7a8){let _0x72837a=g['EMPTY_NODE'];const _0xcec06e=$e(_0x14e33b['visibleWrites'],_0x58c322);if(_0xcec06e)return _0xcec06e['isLeafNode']()||_0xcec06e['forEachChild'](R,(_0x52669c,_0x41861b)=>{_0x72837a=_0x72837a['updateImmediateChild'](_0x52669c,_0x41861b);}),_0x72837a;if(_0x29b7a8){const _0x561f20=ve(_0x14e33b['visibleWrites'],_0x58c322);return _0x29b7a8['forEachChild'](R,(_0x2335ea,_0x488811)=>{const _0x19f308=it(ve(_0x561f20,new C(_0x2335ea)),_0x488811);_0x72837a=_0x72837a['updateImmediateChild'](_0x2335ea,_0x19f308);}),rr(_0x561f20)['forEach'](_0x194a75=>{_0x72837a=_0x72837a['updateImmediateChild'](_0x194a75['name'],_0x194a75['node']);}),_0x72837a;}else{const _0x170747=ve(_0x14e33b['visibleWrites'],_0x58c322);return rr(_0x170747)['forEach'](_0x2dd762=>{_0x72837a=_0x72837a['updateImmediateChild'](_0x2dd762['name'],_0x2dd762['node']);}),_0x72837a;}}function pu(_0x43e67e,_0x19ea9f,_0x4294f2,_0x35886a,_0x1ea8b5){f(_0x35886a||_0x1ea8b5,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x147656=A(_0x19ea9f,_0x4294f2);if(wi(_0x43e67e['visibleWrites'],_0x147656))return null;{const _0x747f7e=ve(_0x43e67e['visibleWrites'],_0x147656);return Ci(_0x747f7e)?_0x1ea8b5['getChild'](_0x4294f2):it(_0x747f7e,_0x1ea8b5['getChild'](_0x4294f2));}}function _u(_0x5ef922,_0xad4c9c,_0x58d28b,_0x1d87fc){const _0x372549=A(_0xad4c9c,_0x58d28b),_0x2f5910=$e(_0x5ef922['visibleWrites'],_0x372549);if(_0x2f5910!=null)return _0x2f5910;if(_0x1d87fc['isCompleteForChild'](_0x58d28b)){const _0x22c63a=ve(_0x5ef922['visibleWrites'],_0x372549);return it(_0x22c63a,_0x1d87fc['getNode']()['getImmediateChild'](_0x58d28b));}else return null;}function gu(_0x3b38c8,_0x5eff07){return $e(_0x3b38c8['visibleWrites'],_0x5eff07);}function mu(_0x1d4b86,_0x11412f,_0x58dc69,_0x4c476c,_0x413935,_0x1daeef,_0x11cdd8){let _0x1c498c;const _0x3527e2=ve(_0x1d4b86['visibleWrites'],_0x11412f),_0x47c153=$e(_0x3527e2,w());if(_0x47c153!=null)_0x1c498c=_0x47c153;else{if(_0x58dc69!=null)_0x1c498c=it(_0x3527e2,_0x58dc69);else return[];}if(_0x1c498c=_0x1c498c['withIndex'](_0x11cdd8),!_0x1c498c['isEmpty']()&&!_0x1c498c['isLeafNode']()){const _0x559b08=[],_0x32b05d=_0x11cdd8['getCompare'](),_0x4e87e8=_0x1daeef?_0x1c498c['getReverseIteratorFrom'](_0x4c476c,_0x11cdd8):_0x1c498c['getIteratorFrom'](_0x4c476c,_0x11cdd8);let _0x251016=_0x4e87e8['getNext']();for(;_0x251016&&_0x559b08['length']<_0x413935;)_0x32b05d(_0x251016,_0x4c476c)!==0x0&&_0x559b08['push'](_0x251016),_0x251016=_0x4e87e8['getNext']();return _0x559b08;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x25ea9b,_0x3f0a70,_0x459414,_0x340447){return Uo(_0x25ea9b['writeTree'],_0x25ea9b['treePath'],_0x3f0a70,_0x459414,_0x340447);}function es(_0x4be62a,_0x258825){return fu(_0x4be62a['writeTree'],_0x4be62a['treePath'],_0x258825);}function or(_0x350a7c,_0x686812,_0x314411,_0x88eddf){return pu(_0x350a7c['writeTree'],_0x350a7c['treePath'],_0x686812,_0x314411,_0x88eddf);}function yn(_0x223d98,_0x42fe0e){return gu(_0x223d98['writeTree'],A(_0x223d98['treePath'],_0x42fe0e));}function vu(_0x4aa496,_0x294643,_0x22f712,_0x1b61a4,_0x7e7901,_0x59a986){return mu(_0x4aa496['writeTree'],_0x4aa496['treePath'],_0x294643,_0x22f712,_0x1b61a4,_0x7e7901,_0x59a986);}function ts(_0x30e249,_0x2e2a2b,_0x2273ff){return _u(_0x30e249['writeTree'],_0x30e249['treePath'],_0x2e2a2b,_0x2273ff);}function Wo(_0x10a580,_0xb0367){return Bo(A(_0x10a580['treePath'],_0xb0367),_0x10a580['writeTree']);}function Bo(_0x58bf91,_0x267334){return{'treePath':_0x58bf91,'writeTree':_0x267334};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x305884){const _0xbbae60=_0x305884['type'],_0x375fbe=_0x305884['childName'];f(_0xbbae60==='child_added'||_0xbbae60==='child_changed'||_0xbbae60==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x375fbe!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x370113=this['changeMap']['get'](_0x375fbe);if(_0x370113){const _0x2eff3b=_0x370113['type'];if(_0xbbae60==='child_added'&&_0x2eff3b==='child_removed')this['changeMap']['set'](_0x375fbe,Pt(_0x375fbe,_0x305884['snapshotNode'],_0x370113['snapshotNode']));else{if(_0xbbae60==='child_removed'&&_0x2eff3b==='child_added')this['changeMap']['delete'](_0x375fbe);else{if(_0xbbae60==='child_removed'&&_0x2eff3b==='child_changed')this['changeMap']['set'](_0x375fbe,Nt(_0x375fbe,_0x370113['oldSnap']));else{if(_0xbbae60==='child_changed'&&_0x2eff3b==='child_added')this['changeMap']['set'](_0x375fbe,tt(_0x375fbe,_0x305884['snapshotNode']));else{if(_0xbbae60==='child_changed'&&_0x2eff3b==='child_changed')this['changeMap']['set'](_0x375fbe,Pt(_0x375fbe,_0x305884['snapshotNode'],_0x370113['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x305884+'\x20occurred\x20after\x20'+_0x370113);}}}}}else this['changeMap']['set'](_0x375fbe,_0x305884);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x36950e){return null;}['getChildAfterChild'](_0x5731ff,_0xd4243,_0x12f8f5){return null;}}const Vo=new Iu();class ns{constructor(_0x5da9e8,_0x1fb988,_0x4f27df=null){this['writes_']=_0x5da9e8,this['viewCache_']=_0x1fb988,this['optCompleteServerCache_']=_0x4f27df;}['getCompleteChild'](_0x44c249){const _0x3d6e6a=this['viewCache_']['eventCache'];if(_0x3d6e6a['isCompleteForChild'](_0x44c249))return _0x3d6e6a['getNode']()['getImmediateChild'](_0x44c249);{const _0x30daf8=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x44c249,_0x30daf8);}}['getChildAfterChild'](_0x1ac572,_0x257430,_0x7d52fb){const _0x20c8f7=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x5e154b=vu(this['writes_'],_0x20c8f7,_0x257430,0x1,_0x7d52fb,_0x1ac572);return _0x5e154b['length']===0x0?null:_0x5e154b[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x4c2a81){return{'filter':_0x4c2a81};}function Cu(_0x40dc45,_0x5d0788){f(_0x5d0788['eventCache']['getNode']()['isIndexed'](_0x40dc45['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5d0788['serverCache']['getNode']()['isIndexed'](_0x40dc45['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x1706ad,_0x37673d,_0x3f216a,_0x3a22c9,_0x27eace){const _0x3015c3=new Eu();let _0x4eccf1,_0x290691;if(_0x3f216a['type']===q['OVERWRITE']){const _0x329830=_0x3f216a;_0x329830['source']['fromUser']?_0x4eccf1=Ti(_0x1706ad,_0x37673d,_0x329830['path'],_0x329830['snap'],_0x3a22c9,_0x27eace,_0x3015c3):(f(_0x329830['source']['fromServer'],'Unknown\x20source.'),_0x290691=_0x329830['source']['tagged']||_0x37673d['serverCache']['isFiltered']()&&!v(_0x329830['path']),_0x4eccf1=vn(_0x1706ad,_0x37673d,_0x329830['path'],_0x329830['snap'],_0x3a22c9,_0x27eace,_0x290691,_0x3015c3));}else{if(_0x3f216a['type']===q['MERGE']){const _0x456cc2=_0x3f216a;_0x456cc2['source']['fromUser']?_0x4eccf1=bu(_0x1706ad,_0x37673d,_0x456cc2['path'],_0x456cc2['children'],_0x3a22c9,_0x27eace,_0x3015c3):(f(_0x456cc2['source']['fromServer'],'Unknown\x20source.'),_0x290691=_0x456cc2['source']['tagged']||_0x37673d['serverCache']['isFiltered'](),_0x4eccf1=Si(_0x1706ad,_0x37673d,_0x456cc2['path'],_0x456cc2['children'],_0x3a22c9,_0x27eace,_0x290691,_0x3015c3));}else{if(_0x3f216a['type']===q['ACK_USER_WRITE']){const _0x2d1c73=_0x3f216a;_0x2d1c73['revert']?_0x4eccf1=ku(_0x1706ad,_0x37673d,_0x2d1c73['path'],_0x3a22c9,_0x27eace,_0x3015c3):_0x4eccf1=Ru(_0x1706ad,_0x37673d,_0x2d1c73['path'],_0x2d1c73['affectedTree'],_0x3a22c9,_0x27eace,_0x3015c3);}else{if(_0x3f216a['type']===q['LISTEN_COMPLETE'])_0x4eccf1=Au(_0x1706ad,_0x37673d,_0x3f216a['path'],_0x3a22c9,_0x3015c3);else throw ot('Unknown\x20operation\x20type:\x20'+_0x3f216a['type']);}}}const _0x4a59b7=_0x3015c3['getChanges']();return Su(_0x37673d,_0x4eccf1,_0x4a59b7),{'viewCache':_0x4eccf1,'changes':_0x4a59b7};}function Su(_0x474ba0,_0x19602d,_0x2f9ccf){const _0x1e45f1=_0x19602d['eventCache'];if(_0x1e45f1['isFullyInitialized']()){const _0x148049=_0x1e45f1['getNode']()['isLeafNode']()||_0x1e45f1['getNode']()['isEmpty'](),_0x2dc2b3=gn(_0x474ba0);(_0x2f9ccf['length']>0x0||!_0x474ba0['eventCache']['isFullyInitialized']()||_0x148049&&!_0x1e45f1['getNode']()['equals'](_0x2dc2b3)||!_0x1e45f1['getNode']()['getPriority']()['equals'](_0x2dc2b3['getPriority']()))&&_0x2f9ccf['push'](Oo(gn(_0x19602d)));}}function Ho(_0x4e5aba,_0x20d2db,_0x48f947,_0x5d566c,_0x1ea247,_0x40f280){const _0x25c7d8=_0x20d2db['eventCache'];if(yn(_0x5d566c,_0x48f947)!=null)return _0x20d2db;{let _0x203b3f,_0x3af471;if(v(_0x48f947)){if(f(_0x20d2db['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x20d2db['serverCache']['isFiltered']()){const _0x1ebe8d=Ue(_0x20d2db),_0x2196c5=_0x1ebe8d instanceof g?_0x1ebe8d:g['EMPTY_NODE'],_0xb8ebeb=es(_0x5d566c,_0x2196c5);_0x203b3f=_0x4e5aba['filter']['updateFullNode'](_0x20d2db['eventCache']['getNode'](),_0xb8ebeb,_0x40f280);}else{const _0x14a999=mn(_0x5d566c,Ue(_0x20d2db));_0x203b3f=_0x4e5aba['filter']['updateFullNode'](_0x20d2db['eventCache']['getNode'](),_0x14a999,_0x40f280);}}else{const _0x265575=y(_0x48f947);if(_0x265575==='.priority'){f(we(_0x48f947)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x35bd12=_0x25c7d8['getNode']();_0x3af471=_0x20d2db['serverCache']['getNode']();const _0x10e1c9=or(_0x5d566c,_0x48f947,_0x35bd12,_0x3af471);_0x10e1c9!=null?_0x203b3f=_0x4e5aba['filter']['updatePriority'](_0x35bd12,_0x10e1c9):_0x203b3f=_0x25c7d8['getNode']();}else{const _0x2c9e0d=b(_0x48f947);let _0x587f79;if(_0x25c7d8['isCompleteForChild'](_0x265575)){_0x3af471=_0x20d2db['serverCache']['getNode']();const _0x261d0f=or(_0x5d566c,_0x48f947,_0x25c7d8['getNode'](),_0x3af471);_0x261d0f!=null?_0x587f79=_0x25c7d8['getNode']()['getImmediateChild'](_0x265575)['updateChild'](_0x2c9e0d,_0x261d0f):_0x587f79=_0x25c7d8['getNode']()['getImmediateChild'](_0x265575);}else _0x587f79=ts(_0x5d566c,_0x265575,_0x20d2db['serverCache']);_0x587f79!=null?_0x203b3f=_0x4e5aba['filter']['updateChild'](_0x25c7d8['getNode'](),_0x265575,_0x587f79,_0x2c9e0d,_0x1ea247,_0x40f280):_0x203b3f=_0x25c7d8['getNode']();}}return wt(_0x20d2db,_0x203b3f,_0x25c7d8['isFullyInitialized']()||v(_0x48f947),_0x4e5aba['filter']['filtersNodes']());}}function vn(_0x4f88e4,_0x4d6ec4,_0x5a68ac,_0x1a2163,_0x3ac091,_0x2a46b1,_0x358397,_0x12992b){const _0x130e90=_0x4d6ec4['serverCache'];let _0x3f9b6e;const _0x44f1d=_0x358397?_0x4f88e4['filter']:_0x4f88e4['filter']['getIndexedFilter']();if(v(_0x5a68ac))_0x3f9b6e=_0x44f1d['updateFullNode'](_0x130e90['getNode'](),_0x1a2163,null);else{if(_0x44f1d['filtersNodes']()&&!_0x130e90['isFiltered']()){const _0x12d9e6=_0x130e90['getNode']()['updateChild'](_0x5a68ac,_0x1a2163);_0x3f9b6e=_0x44f1d['updateFullNode'](_0x130e90['getNode'](),_0x12d9e6,null);}else{const _0x51e595=y(_0x5a68ac);if(!_0x130e90['isCompleteForPath'](_0x5a68ac)&&we(_0x5a68ac)>0x1)return _0x4d6ec4;const _0x2f3a0e=b(_0x5a68ac),_0x5347c3=_0x130e90['getNode']()['getImmediateChild'](_0x51e595)['updateChild'](_0x2f3a0e,_0x1a2163);_0x51e595==='.priority'?_0x3f9b6e=_0x44f1d['updatePriority'](_0x130e90['getNode'](),_0x5347c3):_0x3f9b6e=_0x44f1d['updateChild'](_0x130e90['getNode'](),_0x51e595,_0x5347c3,_0x2f3a0e,Vo,null);}}const _0x298d90=Lo(_0x4d6ec4,_0x3f9b6e,_0x130e90['isFullyInitialized']()||v(_0x5a68ac),_0x44f1d['filtersNodes']()),_0x1fa381=new ns(_0x3ac091,_0x298d90,_0x2a46b1);return Ho(_0x4f88e4,_0x298d90,_0x5a68ac,_0x3ac091,_0x1fa381,_0x12992b);}function Ti(_0x1fd751,_0x5dbca5,_0x5d1098,_0x11de12,_0x266f77,_0x6b0768,_0x2ac24b){const _0x3a14e3=_0x5dbca5['eventCache'];let _0x2011f9,_0x57e42a;const _0x2c600c=new ns(_0x266f77,_0x5dbca5,_0x6b0768);if(v(_0x5d1098))_0x57e42a=_0x1fd751['filter']['updateFullNode'](_0x5dbca5['eventCache']['getNode'](),_0x11de12,_0x2ac24b),_0x2011f9=wt(_0x5dbca5,_0x57e42a,!0x0,_0x1fd751['filter']['filtersNodes']());else{const _0x408bb8=y(_0x5d1098);if(_0x408bb8==='.priority')_0x57e42a=_0x1fd751['filter']['updatePriority'](_0x5dbca5['eventCache']['getNode'](),_0x11de12),_0x2011f9=wt(_0x5dbca5,_0x57e42a,_0x3a14e3['isFullyInitialized'](),_0x3a14e3['isFiltered']());else{const _0x1fa0ec=b(_0x5d1098),_0x27d9bc=_0x3a14e3['getNode']()['getImmediateChild'](_0x408bb8);let _0x1e1d53;if(v(_0x1fa0ec))_0x1e1d53=_0x11de12;else{const _0x18433c=_0x2c600c['getCompleteChild'](_0x408bb8);_0x18433c!=null?Gi(_0x1fa0ec)==='.priority'&&_0x18433c['getChild'](To(_0x1fa0ec))['isEmpty']()?_0x1e1d53=_0x18433c:_0x1e1d53=_0x18433c['updateChild'](_0x1fa0ec,_0x11de12):_0x1e1d53=g['EMPTY_NODE'];}if(_0x27d9bc['equals'](_0x1e1d53))_0x2011f9=_0x5dbca5;else{const _0x10b1de=_0x1fd751['filter']['updateChild'](_0x3a14e3['getNode'](),_0x408bb8,_0x1e1d53,_0x1fa0ec,_0x2c600c,_0x2ac24b);_0x2011f9=wt(_0x5dbca5,_0x10b1de,_0x3a14e3['isFullyInitialized'](),_0x1fd751['filter']['filtersNodes']());}}}return _0x2011f9;}function ar(_0x465070,_0x49d6c3){return _0x465070['eventCache']['isCompleteForChild'](_0x49d6c3);}function bu(_0x17b34a,_0x28b230,_0x5436ea,_0x54d231,_0x29bbae,_0x55de65,_0x58515f){let _0x5a0790=_0x28b230;return _0x54d231['foreach']((_0x26969c,_0x42486a)=>{const _0x3108c7=A(_0x5436ea,_0x26969c);ar(_0x28b230,y(_0x3108c7))&&(_0x5a0790=Ti(_0x17b34a,_0x5a0790,_0x3108c7,_0x42486a,_0x29bbae,_0x55de65,_0x58515f));}),_0x54d231['foreach']((_0x388c12,_0x3ff9d5)=>{const _0x39b49c=A(_0x5436ea,_0x388c12);ar(_0x28b230,y(_0x39b49c))||(_0x5a0790=Ti(_0x17b34a,_0x5a0790,_0x39b49c,_0x3ff9d5,_0x29bbae,_0x55de65,_0x58515f));}),_0x5a0790;}function cr(_0x425b5b,_0x5abd54,_0x23b634){return _0x23b634['foreach']((_0x8e41ee,_0xab7eb2)=>{_0x5abd54=_0x5abd54['updateChild'](_0x8e41ee,_0xab7eb2);}),_0x5abd54;}function Si(_0x1897a8,_0x138bde,_0x3b765f,_0x4b6716,_0xb14ea5,_0x3075e9,_0x47b0fe,_0x81add9){if(_0x138bde['serverCache']['getNode']()['isEmpty']()&&!_0x138bde['serverCache']['isFullyInitialized']())return _0x138bde;let _0x4d97c3=_0x138bde,_0x9cb7d6;v(_0x3b765f)?_0x9cb7d6=_0x4b6716:_0x9cb7d6=new S(null)['setTree'](_0x3b765f,_0x4b6716);const _0xf219f9=_0x138bde['serverCache']['getNode']();return _0x9cb7d6['children']['inorderTraversal']((_0x4aaf73,_0x22ed84)=>{if(_0xf219f9['hasChild'](_0x4aaf73)){const _0x37cdb4=_0x138bde['serverCache']['getNode']()['getImmediateChild'](_0x4aaf73),_0x17813a=cr(_0x1897a8,_0x37cdb4,_0x22ed84);_0x4d97c3=vn(_0x1897a8,_0x4d97c3,new C(_0x4aaf73),_0x17813a,_0xb14ea5,_0x3075e9,_0x47b0fe,_0x81add9);}}),_0x9cb7d6['children']['inorderTraversal']((_0xfea49a,_0x524b8c)=>{const _0x4db12f=!_0x138bde['serverCache']['isCompleteForChild'](_0xfea49a)&&_0x524b8c['value']===null;if(!_0xf219f9['hasChild'](_0xfea49a)&&!_0x4db12f){const _0x5a2c32=_0x138bde['serverCache']['getNode']()['getImmediateChild'](_0xfea49a),_0x1cc12e=cr(_0x1897a8,_0x5a2c32,_0x524b8c);_0x4d97c3=vn(_0x1897a8,_0x4d97c3,new C(_0xfea49a),_0x1cc12e,_0xb14ea5,_0x3075e9,_0x47b0fe,_0x81add9);}}),_0x4d97c3;}function Ru(_0x5b87a1,_0x25800f,_0x56d74a,_0x551dff,_0x266bfe,_0x35dfbc,_0x279d7d){if(yn(_0x266bfe,_0x56d74a)!=null)return _0x25800f;const _0x2eccbf=_0x25800f['serverCache']['isFiltered'](),_0x52e5f9=_0x25800f['serverCache'];if(_0x551dff['value']!=null){if(v(_0x56d74a)&&_0x52e5f9['isFullyInitialized']()||_0x52e5f9['isCompleteForPath'](_0x56d74a))return vn(_0x5b87a1,_0x25800f,_0x56d74a,_0x52e5f9['getNode']()['getChild'](_0x56d74a),_0x266bfe,_0x35dfbc,_0x2eccbf,_0x279d7d);if(v(_0x56d74a)){let _0x22ca3a=new S(null);return _0x52e5f9['getNode']()['forEachChild'](ye,(_0x398467,_0x4fa0ea)=>{_0x22ca3a=_0x22ca3a['set'](new C(_0x398467),_0x4fa0ea);}),Si(_0x5b87a1,_0x25800f,_0x56d74a,_0x22ca3a,_0x266bfe,_0x35dfbc,_0x2eccbf,_0x279d7d);}else return _0x25800f;}else{let _0x3d2854=new S(null);return _0x551dff['foreach']((_0x493a8c,_0x48ff17)=>{const _0x868079=A(_0x56d74a,_0x493a8c);_0x52e5f9['isCompleteForPath'](_0x868079)&&(_0x3d2854=_0x3d2854['set'](_0x493a8c,_0x52e5f9['getNode']()['getChild'](_0x868079)));}),Si(_0x5b87a1,_0x25800f,_0x56d74a,_0x3d2854,_0x266bfe,_0x35dfbc,_0x2eccbf,_0x279d7d);}}function Au(_0x2e8bc6,_0x151e85,_0x3406ce,_0x2f9bb4,_0x11410f){const _0x4202a5=_0x151e85['serverCache'],_0x5320f3=Lo(_0x151e85,_0x4202a5['getNode'](),_0x4202a5['isFullyInitialized']()||v(_0x3406ce),_0x4202a5['isFiltered']());return Ho(_0x2e8bc6,_0x5320f3,_0x3406ce,_0x2f9bb4,Vo,_0x11410f);}function ku(_0x550a4f,_0x160909,_0x3283b3,_0x3ce722,_0x3ad24c,_0x51efe5){let _0x3e537c;if(yn(_0x3ce722,_0x3283b3)!=null)return _0x160909;{const _0x42ce01=new ns(_0x3ce722,_0x160909,_0x3ad24c),_0x327e3f=_0x160909['eventCache']['getNode']();let _0x54859a;if(v(_0x3283b3)||y(_0x3283b3)==='.priority'){let _0x28030a;if(_0x160909['serverCache']['isFullyInitialized']())_0x28030a=mn(_0x3ce722,Ue(_0x160909));else{const _0x5c6586=_0x160909['serverCache']['getNode']();f(_0x5c6586 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x28030a=es(_0x3ce722,_0x5c6586);}_0x28030a=_0x28030a,_0x54859a=_0x550a4f['filter']['updateFullNode'](_0x327e3f,_0x28030a,_0x51efe5);}else{const _0x2aa099=y(_0x3283b3);let _0x1420e1=ts(_0x3ce722,_0x2aa099,_0x160909['serverCache']);_0x1420e1==null&&_0x160909['serverCache']['isCompleteForChild'](_0x2aa099)&&(_0x1420e1=_0x327e3f['getImmediateChild'](_0x2aa099)),_0x1420e1!=null?_0x54859a=_0x550a4f['filter']['updateChild'](_0x327e3f,_0x2aa099,_0x1420e1,b(_0x3283b3),_0x42ce01,_0x51efe5):_0x160909['eventCache']['getNode']()['hasChild'](_0x2aa099)?_0x54859a=_0x550a4f['filter']['updateChild'](_0x327e3f,_0x2aa099,g['EMPTY_NODE'],b(_0x3283b3),_0x42ce01,_0x51efe5):_0x54859a=_0x327e3f,_0x54859a['isEmpty']()&&_0x160909['serverCache']['isFullyInitialized']()&&(_0x3e537c=mn(_0x3ce722,Ue(_0x160909)),_0x3e537c['isLeafNode']()&&(_0x54859a=_0x550a4f['filter']['updateFullNode'](_0x54859a,_0x3e537c,_0x51efe5)));}return _0x3e537c=_0x160909['serverCache']['isFullyInitialized']()||yn(_0x3ce722,w())!=null,wt(_0x160909,_0x54859a,_0x3e537c,_0x550a4f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x4a4c21,_0x4b1fb5){this['query_']=_0x4a4c21,this['eventRegistrations_']=[];const _0x52c03b=this['query_']['_queryParams'],_0x4c6a6c=new Yi(_0x52c03b['getIndex']()),_0x4050b4=qh(_0x52c03b);this['processor_']=wu(_0x4050b4);const _0x39c115=_0x4b1fb5['serverCache'],_0x3f5826=_0x4b1fb5['eventCache'],_0x17fb9a=_0x4c6a6c['updateFullNode'](g['EMPTY_NODE'],_0x39c115['getNode'](),null),_0x2d3a44=_0x4050b4['updateFullNode'](g['EMPTY_NODE'],_0x3f5826['getNode'](),null),_0xafea18=new Ce(_0x17fb9a,_0x39c115['isFullyInitialized'](),_0x4c6a6c['filtersNodes']()),_0x288ba3=new Ce(_0x2d3a44,_0x3f5826['isFullyInitialized'](),_0x4050b4['filtersNodes']());this['viewCache_']=Dn(_0x288ba3,_0xafea18),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x3d0133){return _0x3d0133['viewCache_']['serverCache']['getNode']();}function Ou(_0x807056){return gn(_0x807056['viewCache_']);}function Du(_0x381604,_0x1e318f){const _0x4420a8=Ue(_0x381604['viewCache_']);return _0x4420a8&&(_0x381604['query']['_queryParams']['loadsAllData']()||!v(_0x1e318f)&&!_0x4420a8['getImmediateChild'](y(_0x1e318f))['isEmpty']())?_0x4420a8['getChild'](_0x1e318f):null;}function lr(_0x140f7c){return _0x140f7c['eventRegistrations_']['length']===0x0;}function Mu(_0x480946,_0xcae1dc){_0x480946['eventRegistrations_']['push'](_0xcae1dc);}function hr(_0x4d7ed7,_0x49a2b8,_0x44a11b){const _0x3b6217=[];if(_0x44a11b){f(_0x49a2b8==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5b42bc=_0x4d7ed7['query']['_path'];_0x4d7ed7['eventRegistrations_']['forEach'](_0x16fb23=>{const _0xa53abb=_0x16fb23['createCancelEvent'](_0x44a11b,_0x5b42bc);_0xa53abb&&_0x3b6217['push'](_0xa53abb);});}if(_0x49a2b8){let _0x4a5ead=[];for(let _0x3d5a5c=0x0;_0x3d5a5c<_0x4d7ed7['eventRegistrations_']['length'];++_0x3d5a5c){const _0x32293e=_0x4d7ed7['eventRegistrations_'][_0x3d5a5c];if(!_0x32293e['matches'](_0x49a2b8))_0x4a5ead['push'](_0x32293e);else{if(_0x49a2b8['hasAnyCallback']()){_0x4a5ead=_0x4a5ead['concat'](_0x4d7ed7['eventRegistrations_']['slice'](_0x3d5a5c+0x1));break;}}}_0x4d7ed7['eventRegistrations_']=_0x4a5ead;}else _0x4d7ed7['eventRegistrations_']=[];return _0x3b6217;}function ur(_0xd3d772,_0x43b284,_0x311078,_0x1b95ec){_0x43b284['type']===q['MERGE']&&_0x43b284['source']['queryId']!==null&&(f(Ue(_0xd3d772['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0xd3d772['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x46614b=_0xd3d772['viewCache_'],_0xc8c2ca=Tu(_0xd3d772['processor_'],_0x46614b,_0x43b284,_0x311078,_0x1b95ec);return Cu(_0xd3d772['processor_'],_0xc8c2ca['viewCache']),f(_0xc8c2ca['viewCache']['serverCache']['isFullyInitialized']()||!_0x46614b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0xd3d772['viewCache_']=_0xc8c2ca['viewCache'],$o(_0xd3d772,_0xc8c2ca['changes'],_0xc8c2ca['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x5aaea2,_0x3dd023){const _0x11217c=_0x5aaea2['viewCache_']['eventCache'],_0x3a8f45=[];return _0x11217c['getNode']()['isLeafNode']()||_0x11217c['getNode']()['forEachChild'](R,(_0x1f95b5,_0x544dc8)=>{_0x3a8f45['push'](tt(_0x1f95b5,_0x544dc8));}),_0x11217c['isFullyInitialized']()&&_0x3a8f45['push'](Oo(_0x11217c['getNode']())),$o(_0x5aaea2,_0x3a8f45,_0x11217c['getNode'](),_0x3dd023);}function $o(_0x54cca1,_0x516dbf,_0x1a0312,_0x5024f7){const _0x152761=_0x5024f7?[_0x5024f7]:_0x54cca1['eventRegistrations_'];return nu(_0x54cca1['eventGenerator_'],_0x516dbf,_0x1a0312,_0x152761);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x19d731){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x19d731;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x72ae08){return _0x72ae08['views']['size']===0x0;}function is(_0x3dfaef,_0x4d0261,_0x1d6d40,_0x37668a){const _0x296441=_0x4d0261['source']['queryId'];if(_0x296441!==null){const _0x499189=_0x3dfaef['views']['get'](_0x296441);return f(_0x499189!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x499189,_0x4d0261,_0x1d6d40,_0x37668a);}else{let _0x4e87a7=[];for(const _0x300620 of _0x3dfaef['views']['values']())_0x4e87a7=_0x4e87a7['concat'](ur(_0x300620,_0x4d0261,_0x1d6d40,_0x37668a));return _0x4e87a7;}}function qo(_0x7d5350,_0x48dbfc,_0x4c291f,_0x5ee7ae,_0x3f9b68){const _0x14fcd7=_0x48dbfc['_queryIdentifier'],_0x449de3=_0x7d5350['views']['get'](_0x14fcd7);if(!_0x449de3){let _0x2ae20b=mn(_0x4c291f,_0x3f9b68?_0x5ee7ae:null),_0x2efed7=!0x1;_0x2ae20b?_0x2efed7=!0x0:_0x5ee7ae instanceof g?(_0x2ae20b=es(_0x4c291f,_0x5ee7ae),_0x2efed7=!0x1):(_0x2ae20b=g['EMPTY_NODE'],_0x2efed7=!0x1);const _0x34574f=Dn(new Ce(_0x2ae20b,_0x2efed7,!0x1),new Ce(_0x5ee7ae,_0x3f9b68,!0x1));return new Nu(_0x48dbfc,_0x34574f);}return _0x449de3;}function Wu(_0x5bb904,_0x55684a,_0x9fa9f1,_0x5694bb,_0x27c80d,_0x290fbc){const _0x1b93d1=qo(_0x5bb904,_0x55684a,_0x5694bb,_0x27c80d,_0x290fbc);return _0x5bb904['views']['has'](_0x55684a['_queryIdentifier'])||_0x5bb904['views']['set'](_0x55684a['_queryIdentifier'],_0x1b93d1),Mu(_0x1b93d1,_0x9fa9f1),Lu(_0x1b93d1,_0x9fa9f1);}function Bu(_0x17037b,_0x36764b,_0x1daa2b,_0x33e504){const _0xf983fd=_0x36764b['_queryIdentifier'],_0x593830=[];let _0x263e8b=[];const _0x4b1137=Te(_0x17037b);if(_0xf983fd==='default'){for(const [_0x16675e,_0x991509]of _0x17037b['views']['entries']())_0x263e8b=_0x263e8b['concat'](hr(_0x991509,_0x1daa2b,_0x33e504)),lr(_0x991509)&&(_0x17037b['views']['delete'](_0x16675e),_0x991509['query']['_queryParams']['loadsAllData']()||_0x593830['push'](_0x991509['query']));}else{const _0x514eba=_0x17037b['views']['get'](_0xf983fd);_0x514eba&&(_0x263e8b=_0x263e8b['concat'](hr(_0x514eba,_0x1daa2b,_0x33e504)),lr(_0x514eba)&&(_0x17037b['views']['delete'](_0xf983fd),_0x514eba['query']['_queryParams']['loadsAllData']()||_0x593830['push'](_0x514eba['query'])));}return _0x4b1137&&!Te(_0x17037b)&&_0x593830['push'](new(Fu())(_0x36764b['_repo'],_0x36764b['_path'])),{'removed':_0x593830,'events':_0x263e8b};}function zo(_0x1e5bbc){const _0x417b26=[];for(const _0x127abd of _0x1e5bbc['views']['values']())_0x127abd['query']['_queryParams']['loadsAllData']()||_0x417b26['push'](_0x127abd);return _0x417b26;}function Ee(_0x577ec5,_0x41b585){let _0x246d74=null;for(const _0x58a7ef of _0x577ec5['views']['values']())_0x246d74=_0x246d74||Du(_0x58a7ef,_0x41b585);return _0x246d74;}function jo(_0x2413bf,_0x110202){if(_0x110202['_queryParams']['loadsAllData']())return Ln(_0x2413bf);{const _0x42500d=_0x110202['_queryIdentifier'];return _0x2413bf['views']['get'](_0x42500d);}}function Ko(_0x1aafaf,_0x5ee4ec){return jo(_0x1aafaf,_0x5ee4ec)!=null;}function Te(_0x2a8343){return Ln(_0x2a8343)!=null;}function Ln(_0xadd0e8){for(const _0x5aa00f of _0xadd0e8['views']['values']())if(_0x5aa00f['query']['_queryParams']['loadsAllData']())return _0x5aa00f;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x446631){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x446631;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x58eeab){this['listenProvider_']=_0x58eeab,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x196a4e,_0x816e4f,_0x46e200,_0x1f127c,_0xd922f2){return ou(_0x196a4e['pendingWriteTree_'],_0x816e4f,_0x46e200,_0x1f127c,_0xd922f2),_0xd922f2?ht(_0x196a4e,new Fe(Ji(),_0x816e4f,_0x46e200)):[];}function Gu(_0x3c3ea0,_0x530b6c,_0x33b468,_0x372e24){au(_0x3c3ea0['pendingWriteTree_'],_0x530b6c,_0x33b468,_0x372e24);const _0xb8aaca=S['fromObject'](_0x33b468);return ht(_0x3c3ea0,new nt(Ji(),_0x530b6c,_0xb8aaca));}function pe(_0x355d87,_0x4e0965,_0x1ab210=!0x1){const _0x35c5b1=cu(_0x355d87['pendingWriteTree_'],_0x4e0965);if(lu(_0x355d87['pendingWriteTree_'],_0x4e0965)){let _0x2a8011=new S(null);return _0x35c5b1['snap']!=null?_0x2a8011=_0x2a8011['set'](w(),!0x0):x(_0x35c5b1['children'],_0x1ace70=>{_0x2a8011=_0x2a8011['set'](new C(_0x1ace70),!0x0);}),ht(_0x355d87,new _n(_0x35c5b1['path'],_0x2a8011,_0x1ab210));}else return[];}function $t(_0x4c4034,_0xe7e363,_0x2b2ee2){return ht(_0x4c4034,new Fe(Xi(),_0xe7e363,_0x2b2ee2));}function qu(_0x1c9c48,_0x52454a,_0x9c1005){const _0x139669=S['fromObject'](_0x9c1005);return ht(_0x1c9c48,new nt(Xi(),_0x52454a,_0x139669));}function zu(_0xce4801,_0x3d5b74){return ht(_0xce4801,new Dt(Xi(),_0x3d5b74));}function ju(_0x27c18e,_0x3f1c39,_0x3733c9){const _0x51ea52=rs(_0x27c18e,_0x3733c9);if(_0x51ea52){const _0x59a893=os(_0x51ea52),_0x4784bb=_0x59a893['path'],_0x94c697=_0x59a893['queryId'],_0x270b92=F(_0x4784bb,_0x3f1c39),_0x188648=new Dt(Zi(_0x94c697),_0x270b92);return as(_0x27c18e,_0x4784bb,_0x188648);}else return[];}function wn(_0x321158,_0xa22ad2,_0x459000,_0x34f588,_0x40c69a=!0x1){const _0x396958=_0xa22ad2['_path'],_0x17f469=_0x321158['syncPointTree_']['get'](_0x396958);let _0x843f32=[];if(_0x17f469&&(_0xa22ad2['_queryIdentifier']==='default'||Ko(_0x17f469,_0xa22ad2))){const _0x2601db=Bu(_0x17f469,_0xa22ad2,_0x459000,_0x34f588);Uu(_0x17f469)&&(_0x321158['syncPointTree_']=_0x321158['syncPointTree_']['remove'](_0x396958));const _0x57cbce=_0x2601db['removed'];if(_0x843f32=_0x2601db['events'],!_0x40c69a){const _0x3b3f61=_0x57cbce['findIndex'](_0x434ff=>_0x434ff['_queryParams']['loadsAllData']())!==-0x1,_0xbf68dd=_0x321158['syncPointTree_']['findOnPath'](_0x396958,(_0x36d12f,_0x204719)=>Te(_0x204719));if(_0x3b3f61&&!_0xbf68dd){const _0x1937a6=_0x321158['syncPointTree_']['subtree'](_0x396958);if(!_0x1937a6['isEmpty']()){const _0x5df55a=Qu(_0x1937a6);for(let _0x364593=0x0;_0x364593<_0x5df55a['length'];++_0x364593){const _0x5499fd=_0x5df55a[_0x364593],_0x3d45b1=_0x5499fd['query'],_0x37a07d=Xo(_0x321158,_0x5499fd);_0x321158['listenProvider_']['startListening'](Tt(_0x3d45b1),Mt(_0x321158,_0x3d45b1),_0x37a07d['hashFn'],_0x37a07d['onComplete']);}}}!_0xbf68dd&&_0x57cbce['length']>0x0&&!_0x34f588&&(_0x3b3f61?_0x321158['listenProvider_']['stopListening'](Tt(_0xa22ad2),null):_0x57cbce['forEach'](_0x59f143=>{const _0x3b4872=_0x321158['queryToTagMap']['get'](Fn(_0x59f143));_0x321158['listenProvider_']['stopListening'](Tt(_0x59f143),_0x3b4872);}));}Ju(_0x321158,_0x57cbce);}return _0x843f32;}function Yo(_0x19a03a,_0x4026c2,_0x46a848,_0x6969e8){const _0x428f0e=rs(_0x19a03a,_0x6969e8);if(_0x428f0e!=null){const _0x4e212c=os(_0x428f0e),_0x4339ec=_0x4e212c['path'],_0x150f20=_0x4e212c['queryId'],_0x890b29=F(_0x4339ec,_0x4026c2),_0x19a943=new Fe(Zi(_0x150f20),_0x890b29,_0x46a848);return as(_0x19a03a,_0x4339ec,_0x19a943);}else return[];}function Ku(_0x4556bd,_0x1c565f,_0x12b48a,_0x2f5699){const _0x4c4a1e=rs(_0x4556bd,_0x2f5699);if(_0x4c4a1e){const _0x3e696e=os(_0x4c4a1e),_0x2858e4=_0x3e696e['path'],_0x44219e=_0x3e696e['queryId'],_0x5f962f=F(_0x2858e4,_0x1c565f),_0x5a584a=S['fromObject'](_0x12b48a),_0x57d401=new nt(Zi(_0x44219e),_0x5f962f,_0x5a584a);return as(_0x4556bd,_0x2858e4,_0x57d401);}else return[];}function bi(_0x16379f,_0x8dbf24,_0x1e4de7,_0x283db3=!0x1){const _0x3be2c1=_0x8dbf24['_path'];let _0x568fbb=null,_0x1b08a8=!0x1;_0x16379f['syncPointTree_']['foreachOnPath'](_0x3be2c1,(_0x463bbe,_0x5d67f9)=>{const _0x4ff099=F(_0x463bbe,_0x3be2c1);_0x568fbb=_0x568fbb||Ee(_0x5d67f9,_0x4ff099),_0x1b08a8=_0x1b08a8||Te(_0x5d67f9);});let _0x360999=_0x16379f['syncPointTree_']['get'](_0x3be2c1);_0x360999?(_0x1b08a8=_0x1b08a8||Te(_0x360999),_0x568fbb=_0x568fbb||Ee(_0x360999,w())):(_0x360999=new Go(),_0x16379f['syncPointTree_']=_0x16379f['syncPointTree_']['set'](_0x3be2c1,_0x360999));let _0xbd2693;_0x568fbb!=null?_0xbd2693=!0x0:(_0xbd2693=!0x1,_0x568fbb=g['EMPTY_NODE'],_0x16379f['syncPointTree_']['subtree'](_0x3be2c1)['foreachChild']((_0x29f4bf,_0x1a342d)=>{const _0x243660=Ee(_0x1a342d,w());_0x243660&&(_0x568fbb=_0x568fbb['updateImmediateChild'](_0x29f4bf,_0x243660));}));const _0x66299c=Ko(_0x360999,_0x8dbf24);if(!_0x66299c&&!_0x8dbf24['_queryParams']['loadsAllData']()){const _0x26723f=Fn(_0x8dbf24);f(!_0x16379f['queryToTagMap']['has'](_0x26723f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x348954=Xu();_0x16379f['queryToTagMap']['set'](_0x26723f,_0x348954),_0x16379f['tagToQueryMap']['set'](_0x348954,_0x26723f);}const _0x317c3f=Mn(_0x16379f['pendingWriteTree_'],_0x3be2c1);let _0x12f7de=Wu(_0x360999,_0x8dbf24,_0x1e4de7,_0x317c3f,_0x568fbb,_0xbd2693);if(!_0x66299c&&!_0x1b08a8&&!_0x283db3){const _0x48265a=jo(_0x360999,_0x8dbf24);_0x12f7de=_0x12f7de['concat'](Zu(_0x16379f,_0x8dbf24,_0x48265a));}return _0x12f7de;}function xn(_0x13f47a,_0x25350c,_0x4dac7f){const _0x1ea344=_0x13f47a['pendingWriteTree_'],_0x1a34be=_0x13f47a['syncPointTree_']['findOnPath'](_0x25350c,(_0x1b9755,_0x428cd4)=>{const _0x21826f=F(_0x1b9755,_0x25350c),_0x10c55e=Ee(_0x428cd4,_0x21826f);if(_0x10c55e)return _0x10c55e;});return Uo(_0x1ea344,_0x25350c,_0x1a34be,_0x4dac7f,!0x0);}function Yu(_0x513281,_0x80e76b){const _0x5e0da2=_0x80e76b['_path'];let _0x491e8d=null;_0x513281['syncPointTree_']['foreachOnPath'](_0x5e0da2,(_0x3fe6ea,_0x29565e)=>{const _0x1c7136=F(_0x3fe6ea,_0x5e0da2);_0x491e8d=_0x491e8d||Ee(_0x29565e,_0x1c7136);});let _0xfcbb0c=_0x513281['syncPointTree_']['get'](_0x5e0da2);_0xfcbb0c?_0x491e8d=_0x491e8d||Ee(_0xfcbb0c,w()):(_0xfcbb0c=new Go(),_0x513281['syncPointTree_']=_0x513281['syncPointTree_']['set'](_0x5e0da2,_0xfcbb0c));const _0x342084=_0x491e8d!=null,_0x1ba605=_0x342084?new Ce(_0x491e8d,!0x0,!0x1):null,_0x4cc202=Mn(_0x513281['pendingWriteTree_'],_0x80e76b['_path']),_0x5e4571=qo(_0xfcbb0c,_0x80e76b,_0x4cc202,_0x342084?_0x1ba605['getNode']():g['EMPTY_NODE'],_0x342084);return Ou(_0x5e4571);}function ht(_0x1dde41,_0x5b3fee){return Qo(_0x5b3fee,_0x1dde41['syncPointTree_'],null,Mn(_0x1dde41['pendingWriteTree_'],w()));}function Qo(_0x2468c9,_0x1ab61a,_0x577fc8,_0x34372b){if(v(_0x2468c9['path']))return Jo(_0x2468c9,_0x1ab61a,_0x577fc8,_0x34372b);{const _0x54ee14=_0x1ab61a['get'](w());_0x577fc8==null&&_0x54ee14!=null&&(_0x577fc8=Ee(_0x54ee14,w()));let _0x4ab06e=[];const _0x3061ad=y(_0x2468c9['path']),_0x1d4dd0=_0x2468c9['operationForChild'](_0x3061ad),_0x381375=_0x1ab61a['children']['get'](_0x3061ad);if(_0x381375&&_0x1d4dd0){const _0x162ecb=_0x577fc8?_0x577fc8['getImmediateChild'](_0x3061ad):null,_0x2171b7=Wo(_0x34372b,_0x3061ad);_0x4ab06e=_0x4ab06e['concat'](Qo(_0x1d4dd0,_0x381375,_0x162ecb,_0x2171b7));}return _0x54ee14&&(_0x4ab06e=_0x4ab06e['concat'](is(_0x54ee14,_0x2468c9,_0x34372b,_0x577fc8))),_0x4ab06e;}}function Jo(_0x47b7b5,_0x3b8cf5,_0x8f3ead,_0xd181e1){const _0x49837b=_0x3b8cf5['get'](w());_0x8f3ead==null&&_0x49837b!=null&&(_0x8f3ead=Ee(_0x49837b,w()));let _0x47bd28=[];return _0x3b8cf5['children']['inorderTraversal']((_0x389c75,_0x5e84ab)=>{const _0x2c015b=_0x8f3ead?_0x8f3ead['getImmediateChild'](_0x389c75):null,_0x3200e9=Wo(_0xd181e1,_0x389c75),_0x167d5f=_0x47b7b5['operationForChild'](_0x389c75);_0x167d5f&&(_0x47bd28=_0x47bd28['concat'](Jo(_0x167d5f,_0x5e84ab,_0x2c015b,_0x3200e9)));}),_0x49837b&&(_0x47bd28=_0x47bd28['concat'](is(_0x49837b,_0x47b7b5,_0xd181e1,_0x8f3ead))),_0x47bd28;}function Xo(_0x25585d,_0x11b0a9){const _0xa4e59=_0x11b0a9['query'],_0x162699=Mt(_0x25585d,_0xa4e59);return{'hashFn':()=>(Pu(_0x11b0a9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x328fc4=>{if(_0x328fc4==='ok')return _0x162699?ju(_0x25585d,_0xa4e59['_path'],_0x162699):zu(_0x25585d,_0xa4e59['_path']);{const _0x55f8a1=ql(_0x328fc4,_0xa4e59);return wn(_0x25585d,_0xa4e59,null,_0x55f8a1);}}};}function Mt(_0x34463d,_0x2b468b){const _0x4c13c4=Fn(_0x2b468b);return _0x34463d['queryToTagMap']['get'](_0x4c13c4);}function Fn(_0x53e44b){return _0x53e44b['_path']['toString']()+'$'+_0x53e44b['_queryIdentifier'];}function rs(_0x945d59,_0x22ae45){return _0x945d59['tagToQueryMap']['get'](_0x22ae45);}function os(_0x2691e1){const _0x433cdb=_0x2691e1['indexOf']('$');return f(_0x433cdb!==-0x1&&_0x433cdb<_0x2691e1['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2691e1['substr'](_0x433cdb+0x1),'path':new C(_0x2691e1['substr'](0x0,_0x433cdb))};}function as(_0x44f28f,_0x32509b,_0x5c4953){const _0x13c7c7=_0x44f28f['syncPointTree_']['get'](_0x32509b);f(_0x13c7c7,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2231bf=Mn(_0x44f28f['pendingWriteTree_'],_0x32509b);return is(_0x13c7c7,_0x5c4953,_0x2231bf,null);}function Qu(_0x3b1cc7){return _0x3b1cc7['fold']((_0x2d7cfa,_0x4099a5,_0x3d1994)=>{if(_0x4099a5&&Te(_0x4099a5))return[Ln(_0x4099a5)];{let _0x33363a=[];return _0x4099a5&&(_0x33363a=zo(_0x4099a5)),x(_0x3d1994,(_0x451d9d,_0x4d4722)=>{_0x33363a=_0x33363a['concat'](_0x4d4722);}),_0x33363a;}});}function Tt(_0x397722){return _0x397722['_queryParams']['loadsAllData']()&&!_0x397722['_queryParams']['isDefault']()?new(Hu())(_0x397722['_repo'],_0x397722['_path']):_0x397722;}function Ju(_0x144ce1,_0x25904e){for(let _0x5dbbdf=0x0;_0x5dbbdf<_0x25904e['length'];++_0x5dbbdf){const _0x9515d=_0x25904e[_0x5dbbdf];if(!_0x9515d['_queryParams']['loadsAllData']()){const _0x356802=Fn(_0x9515d),_0x3afd48=_0x144ce1['queryToTagMap']['get'](_0x356802);_0x144ce1['queryToTagMap']['delete'](_0x356802),_0x144ce1['tagToQueryMap']['delete'](_0x3afd48);}}}function Xu(){return $u++;}function Zu(_0x1f476f,_0x46c98b,_0x5fa35a){const _0x1a4f06=_0x46c98b['_path'],_0x1280dd=Mt(_0x1f476f,_0x46c98b),_0x53a618=Xo(_0x1f476f,_0x5fa35a),_0x1f2b7c=_0x1f476f['listenProvider_']['startListening'](Tt(_0x46c98b),_0x1280dd,_0x53a618['hashFn'],_0x53a618['onComplete']),_0x6d3406=_0x1f476f['syncPointTree_']['subtree'](_0x1a4f06);if(_0x1280dd)f(!Te(_0x6d3406['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x402fb1=_0x6d3406['fold']((_0x5da7ba,_0x2f1743,_0x54bfe9)=>{if(!v(_0x5da7ba)&&_0x2f1743&&Te(_0x2f1743))return[Ln(_0x2f1743)['query']];{let _0x1088ee=[];return _0x2f1743&&(_0x1088ee=_0x1088ee['concat'](zo(_0x2f1743)['map'](_0x9bf71c=>_0x9bf71c['query']))),x(_0x54bfe9,(_0x368297,_0xb10847)=>{_0x1088ee=_0x1088ee['concat'](_0xb10847);}),_0x1088ee;}});for(let _0xea292a=0x0;_0xea292a<_0x402fb1['length'];++_0xea292a){const _0x2a836d=_0x402fb1[_0xea292a];_0x1f476f['listenProvider_']['stopListening'](Tt(_0x2a836d),Mt(_0x1f476f,_0x2a836d));}}return _0x1f2b7c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x48e886){this['node_']=_0x48e886;}['getImmediateChild'](_0x5d333b){const _0x44e084=this['node_']['getImmediateChild'](_0x5d333b);return new cs(_0x44e084);}['node'](){return this['node_'];}}class ls{constructor(_0x5cdad8,_0x290047){this['syncTree_']=_0x5cdad8,this['path_']=_0x290047;}['getImmediateChild'](_0x2b7913){const _0x418266=A(this['path_'],_0x2b7913);return new ls(this['syncTree_'],_0x418266);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x51dd1d){return _0x51dd1d=_0x51dd1d||{},_0x51dd1d['timestamp']=_0x51dd1d['timestamp']||new Date()['getTime'](),_0x51dd1d;},fr=function(_0x544116,_0x2fdd9b,_0x2d0bff){if(!_0x544116||typeof _0x544116!='object')return _0x544116;if(f('.sv'in _0x544116,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x544116['.sv']=='string')return td(_0x544116['.sv'],_0x2fdd9b,_0x2d0bff);if(typeof _0x544116['.sv']=='object')return nd(_0x544116['.sv'],_0x2fdd9b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x544116,null,0x2));},td=function(_0x5931be,_0x543068,_0x42513e){switch(_0x5931be){case'timestamp':return _0x42513e['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x5931be);}},nd=function(_0x1c1970,_0x49fcdb,_0x592597){_0x1c1970['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1c1970,null,0x2));const _0x3e2dd7=_0x1c1970['increment'];typeof _0x3e2dd7!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3e2dd7);const _0x408b67=_0x49fcdb['node']();if(f(_0x408b67!==null&&typeof _0x408b67<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x408b67['isLeafNode']())return _0x3e2dd7;const _0x4ad961=_0x408b67['getValue']();return typeof _0x4ad961!='number'?_0x3e2dd7:_0x4ad961+_0x3e2dd7;},Zo=function(_0x47bb4e,_0x127961,_0x1df4b3,_0x543ad9){return us(_0x127961,new ls(_0x1df4b3,_0x47bb4e),_0x543ad9);},hs=function(_0x580bd6,_0x20d802,_0x28fdfa){return us(_0x580bd6,new cs(_0x20d802),_0x28fdfa);};function us(_0x55b5a3,_0x5ae1fe,_0x1dbde5){const _0x1d8750=_0x55b5a3['getPriority']()['val'](),_0x3707e7=fr(_0x1d8750,_0x5ae1fe['getImmediateChild']('.priority'),_0x1dbde5);let _0x3de329;if(_0x55b5a3['isLeafNode']()){const _0x376b54=_0x55b5a3,_0x19694d=fr(_0x376b54['getValue'](),_0x5ae1fe,_0x1dbde5);return _0x19694d!==_0x376b54['getValue']()||_0x3707e7!==_0x376b54['getPriority']()['val']()?new D(_0x19694d,N(_0x3707e7)):_0x55b5a3;}else{const _0x37ca1c=_0x55b5a3;return _0x3de329=_0x37ca1c,_0x3707e7!==_0x37ca1c['getPriority']()['val']()&&(_0x3de329=_0x3de329['updatePriority'](new D(_0x3707e7))),_0x37ca1c['forEachChild'](R,(_0x35f830,_0x384f77)=>{const _0x3b0451=us(_0x384f77,_0x5ae1fe['getImmediateChild'](_0x35f830),_0x1dbde5);_0x3b0451!==_0x384f77&&(_0x3de329=_0x3de329['updateImmediateChild'](_0x35f830,_0x3b0451));}),_0x3de329;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x212caf='',_0x57e8ee=null,_0x42e4c6={'children':{},'childCount':0x0}){this['name']=_0x212caf,this['parent']=_0x57e8ee,this['node']=_0x42e4c6;}}function Un(_0x22c114,_0x451f6f){let _0x5b5b14=_0x451f6f instanceof C?_0x451f6f:new C(_0x451f6f),_0x283109=_0x22c114,_0x225ca6=y(_0x5b5b14);for(;_0x225ca6!==null;){const _0x16bce7=Oe(_0x283109['node']['children'],_0x225ca6)||{'children':{},'childCount':0x0};_0x283109=new ds(_0x225ca6,_0x283109,_0x16bce7),_0x5b5b14=b(_0x5b5b14),_0x225ca6=y(_0x5b5b14);}return _0x283109;}function Ge(_0x1f8f9c){return _0x1f8f9c['node']['value'];}function fs(_0x2778e1,_0x2b7a03){_0x2778e1['node']['value']=_0x2b7a03,Ri(_0x2778e1);}function ea(_0x42d05f){return _0x42d05f['node']['childCount']>0x0;}function id(_0x4c4ee3){return Ge(_0x4c4ee3)===void 0x0&&!ea(_0x4c4ee3);}function Wn(_0x57f474,_0xf2816a){x(_0x57f474['node']['children'],(_0x48b2f4,_0x8f490d)=>{_0xf2816a(new ds(_0x48b2f4,_0x57f474,_0x8f490d));});}function ta(_0x17cb9b,_0x1b225d,_0x3cc2b1,_0x17f7b5){_0x3cc2b1&&_0x1b225d(_0x17cb9b),Wn(_0x17cb9b,_0x36daa1=>{ta(_0x36daa1,_0x1b225d,!0x0);});}function sd(_0x3f2890,_0x21cdb6,_0x242de2){let _0x443005=_0x3f2890['parent'];for(;_0x443005!==null;){if(_0x21cdb6(_0x443005))return!0x0;_0x443005=_0x443005['parent'];}return!0x1;}function Gt(_0x455951){return new C(_0x455951['parent']===null?_0x455951['name']:Gt(_0x455951['parent'])+'/'+_0x455951['name']);}function Ri(_0x168137){_0x168137['parent']!==null&&rd(_0x168137['parent'],_0x168137['name'],_0x168137);}function rd(_0x11f127,_0x3456d2,_0x15d556){const _0x502a55=id(_0x15d556),_0x2f69f9=Y(_0x11f127['node']['children'],_0x3456d2);_0x502a55&&_0x2f69f9?(delete _0x11f127['node']['children'][_0x3456d2],_0x11f127['node']['childCount']--,Ri(_0x11f127)):!_0x502a55&&!_0x2f69f9&&(_0x11f127['node']['children'][_0x3456d2]=_0x15d556['node'],_0x11f127['node']['childCount']++,Ri(_0x11f127));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x5260a0){return typeof _0x5260a0=='string'&&_0x5260a0['length']!==0x0&&!od['test'](_0x5260a0);},na=function(_0x117c2d){return typeof _0x117c2d=='string'&&_0x117c2d['length']!==0x0&&!ad['test'](_0x117c2d);},cd=function(_0x402ab0){return _0x402ab0&&(_0x402ab0=_0x402ab0['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x402ab0);},Cn=function(_0x32d14f){return _0x32d14f===null||typeof _0x32d14f=='string'||typeof _0x32d14f=='number'&&!Wi(_0x32d14f)||_0x32d14f&&typeof _0x32d14f=='object'&&Y(_0x32d14f,'.sv');},qt=function(_0x340ebe,_0x5119a4,_0x1ee5bc,_0x177569){_0x177569&&_0x5119a4===void 0x0||zt(Nn(_0x340ebe,'value'),_0x5119a4,_0x1ee5bc);},zt=function(_0x213d46,_0xb2ba02,_0x3a73ce){const _0x2e9cc6=_0x3a73ce instanceof C?new Sh(_0x3a73ce,_0x213d46):_0x3a73ce;if(_0xb2ba02===void 0x0)throw new Error(_0x213d46+'contains\x20undefined\x20'+Ne(_0x2e9cc6));if(typeof _0xb2ba02=='function')throw new Error(_0x213d46+'contains\x20a\x20function\x20'+Ne(_0x2e9cc6)+'\x20with\x20contents\x20=\x20'+_0xb2ba02['toString']());if(Wi(_0xb2ba02))throw new Error(_0x213d46+'contains\x20'+_0xb2ba02['toString']()+'\x20'+Ne(_0x2e9cc6));if(typeof _0xb2ba02=='string'&&_0xb2ba02['length']>oi/0x3&&Pn(_0xb2ba02)>oi)throw new Error(_0x213d46+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x2e9cc6)+'\x20(\x27'+_0xb2ba02['substring'](0x0,0x32)+'...\x27)');if(_0xb2ba02&&typeof _0xb2ba02=='object'){let _0x49dc16=!0x1,_0xaa51f4=!0x1;if(x(_0xb2ba02,(_0x44964a,_0x2faa42)=>{if(_0x44964a==='.value')_0x49dc16=!0x0;else{if(_0x44964a!=='.priority'&&_0x44964a!=='.sv'&&(_0xaa51f4=!0x0,!ps(_0x44964a)))throw new Error(_0x213d46+'\x20contains\x20an\x20invalid\x20key\x20('+_0x44964a+')\x20'+Ne(_0x2e9cc6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x2e9cc6,_0x44964a),zt(_0x213d46,_0x2faa42,_0x2e9cc6),Rh(_0x2e9cc6);}),_0x49dc16&&_0xaa51f4)throw new Error(_0x213d46+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2e9cc6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x2be379,_0x427307){let _0x35835e,_0x763f63;for(_0x35835e=0x0;_0x35835e<_0x427307['length'];_0x35835e++){_0x763f63=_0x427307[_0x35835e];const _0xa2b53e=kt(_0x763f63);for(let _0x2c38b9=0x0;_0x2c38b9<_0xa2b53e['length'];_0x2c38b9++)if(!(_0xa2b53e[_0x2c38b9]==='.priority'&&_0x2c38b9===_0xa2b53e['length']-0x1)){if(!ps(_0xa2b53e[_0x2c38b9]))throw new Error(_0x2be379+'contains\x20an\x20invalid\x20key\x20('+_0xa2b53e[_0x2c38b9]+')\x20in\x20path\x20'+_0x763f63['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x427307['sort'](Th);let _0x26c5d4=null;for(_0x35835e=0x0;_0x35835e<_0x427307['length'];_0x35835e++){if(_0x763f63=_0x427307[_0x35835e],_0x26c5d4!==null&&$(_0x26c5d4,_0x763f63))throw new Error(_0x2be379+'contains\x20a\x20path\x20'+_0x26c5d4['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x763f63['toString']());_0x26c5d4=_0x763f63;}},hd=function(_0x2c9644,_0x5ef301,_0x3ebd6b,_0x3b11f3){const _0xa8f0fc=Nn(_0x2c9644,'values');if(!(_0x5ef301&&typeof _0x5ef301=='object')||Array['isArray'](_0x5ef301))throw new Error(_0xa8f0fc+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x45e6fc=[];x(_0x5ef301,(_0x546cb4,_0x2916a4)=>{const _0x5afab3=new C(_0x546cb4);if(zt(_0xa8f0fc,_0x2916a4,A(_0x3ebd6b,_0x5afab3)),Gi(_0x5afab3)==='.priority'&&!Cn(_0x2916a4))throw new Error(_0xa8f0fc+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5afab3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x45e6fc['push'](_0x5afab3);}),ld(_0xa8f0fc,_0x45e6fc);},_s=function(_0x145fa9,_0x2de6eb,_0x49100e,_0x248ad0){if(!na(_0x49100e))throw new Error(Nn(_0x145fa9,_0x2de6eb)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x49100e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0xbafba3,_0x2e2564,_0x598bc8,_0x2de9e5){_0x598bc8&&(_0x598bc8=_0x598bc8['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0xbafba3,_0x2e2564,_0x598bc8);},gs=function(_0x3952b4,_0x3eb013){if(y(_0x3eb013)==='.info')throw new Error(_0x3952b4+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x272776,_0x252e69){const _0x5bc1a9=_0x252e69['path']['toString']();if(typeof _0x252e69['repoInfo']['host']!='string'||_0x252e69['repoInfo']['host']['length']===0x0||!ps(_0x252e69['repoInfo']['namespace'])&&_0x252e69['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5bc1a9['length']!==0x0&&!cd(_0x5bc1a9))throw new Error(Nn(_0x272776,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x559cb5,_0x49cb70){let _0x543e62=null;for(let _0x38a784=0x0;_0x38a784<_0x49cb70['length'];_0x38a784++){const _0x146ad2=_0x49cb70[_0x38a784],_0xd90637=_0x146ad2['getPath']();_0x543e62!==null&&!qi(_0xd90637,_0x543e62['path'])&&(_0x559cb5['eventLists_']['push'](_0x543e62),_0x543e62=null),_0x543e62===null&&(_0x543e62={'events':[],'path':_0xd90637}),_0x543e62['events']['push'](_0x146ad2);}_0x543e62&&_0x559cb5['eventLists_']['push'](_0x543e62);}function ia(_0x33c0b9,_0x2b758c,_0x24ec4a){Bn(_0x33c0b9,_0x24ec4a),sa(_0x33c0b9,_0xcb88b0=>qi(_0xcb88b0,_0x2b758c));}function V(_0x499534,_0x5b69c6,_0x5b49f2){Bn(_0x499534,_0x5b49f2),sa(_0x499534,_0x1956e0=>$(_0x1956e0,_0x5b69c6)||$(_0x5b69c6,_0x1956e0));}function sa(_0x2a82eb,_0x310454){_0x2a82eb['recursionDepth_']++;let _0x38e586=!0x0;for(let _0x342138=0x0;_0x342138<_0x2a82eb['eventLists_']['length'];_0x342138++){const _0x321aa0=_0x2a82eb['eventLists_'][_0x342138];if(_0x321aa0){const _0x8ecde0=_0x321aa0['path'];_0x310454(_0x8ecde0)?(pd(_0x2a82eb['eventLists_'][_0x342138]),_0x2a82eb['eventLists_'][_0x342138]=null):_0x38e586=!0x1;}}_0x38e586&&(_0x2a82eb['eventLists_']=[]),_0x2a82eb['recursionDepth_']--;}function pd(_0x3d8772){for(let _0x35b4ce=0x0;_0x35b4ce<_0x3d8772['events']['length'];_0x35b4ce++){const _0xfd73fd=_0x3d8772['events'][_0x35b4ce];if(_0xfd73fd!==null){_0x3d8772['events'][_0x35b4ce]=null;const _0x1ccc0c=_0xfd73fd['getEventRunner']();Et&&L('event:\x20'+_0xfd73fd['toString']()),lt(_0x1ccc0c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x568f58,_0x254df8,_0x1595a2,_0x3ea184){this['repoInfo_']=_0x568f58,this['forceRestClient_']=_0x254df8,this['authTokenProvider_']=_0x1595a2,this['appCheckProvider_']=_0x3ea184,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x24e484,_0x175cae,_0xe7569a){if(_0x24e484['stats_']=Hi(_0x24e484['repoInfo_']),_0x24e484['forceRestClient_']||Yl())_0x24e484['server_']=new fn(_0x24e484['repoInfo_'],(_0x2c37a9,_0x54a609,_0xa917a1,_0x464d59)=>{pr(_0x24e484,_0x2c37a9,_0x54a609,_0xa917a1,_0x464d59);},_0x24e484['authTokenProvider_'],_0x24e484['appCheckProvider_']),setTimeout(()=>_r(_0x24e484,!0x0),0x0);else{if(typeof _0xe7569a<'u'&&_0xe7569a!==null){if(typeof _0xe7569a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xe7569a);}catch(_0x3871a1){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x3871a1);}}_0x24e484['persistentConnection_']=new ie(_0x24e484['repoInfo_'],_0x175cae,(_0x3a7201,_0x3c7a96,_0x545e54,_0x259e06)=>{pr(_0x24e484,_0x3a7201,_0x3c7a96,_0x545e54,_0x259e06);},_0x5783e0=>{_r(_0x24e484,_0x5783e0);},_0x24a833=>{yd(_0x24e484,_0x24a833);},_0x24e484['authTokenProvider_'],_0x24e484['appCheckProvider_'],_0xe7569a),_0x24e484['server_']=_0x24e484['persistentConnection_'];}_0x24e484['authTokenProvider_']['addTokenChangeListener'](_0x33bd38=>{_0x24e484['server_']['refreshAuthToken'](_0x33bd38);}),_0x24e484['appCheckProvider_']['addTokenChangeListener'](_0xb57bc3=>{_0x24e484['server_']['refreshAppCheckToken'](_0xb57bc3['token']);}),_0x24e484['statsReporter_']=eh(_0x24e484['repoInfo_'],()=>new eu(_0x24e484['stats_'],_0x24e484['server_'])),_0x24e484['infoData_']=new Yh(),_0x24e484['infoSyncTree_']=new dr({'startListening':(_0x22b324,_0x19f815,_0x250a35,_0x149541)=>{let _0x181645=[];const _0x5bcbe2=_0x24e484['infoData_']['getNode'](_0x22b324['_path']);return _0x5bcbe2['isEmpty']()||(_0x181645=$t(_0x24e484['infoSyncTree_'],_0x22b324['_path'],_0x5bcbe2),setTimeout(()=>{_0x149541('ok');},0x0)),_0x181645;},'stopListening':()=>{}}),ms(_0x24e484,'connected',!0x1),_0x24e484['serverSyncTree_']=new dr({'startListening':(_0x563930,_0x446a2e,_0x341bca,_0x359175)=>(_0x24e484['server_']['listen'](_0x563930,_0x341bca,_0x446a2e,(_0xc36acb,_0x21e284)=>{const _0x4e5ac9=_0x359175(_0xc36acb,_0x21e284);V(_0x24e484['eventQueue_'],_0x563930['_path'],_0x4e5ac9);}),[]),'stopListening':(_0x2fc68d,_0xf90b4f)=>{_0x24e484['server_']['unlisten'](_0x2fc68d,_0xf90b4f);}});}function oa(_0x2f7d2a){const _0x1716ab=_0x2f7d2a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1716ab;}function jt(_0x2fbbc9){return ed({'timestamp':oa(_0x2fbbc9)});}function pr(_0x12413f,_0x326ffe,_0x5b19a5,_0x23015c,_0x38cdb6){_0x12413f['dataUpdateCount']++;const _0x12bde2=new C(_0x326ffe);_0x5b19a5=_0x12413f['interceptServerDataCallback_']?_0x12413f['interceptServerDataCallback_'](_0x326ffe,_0x5b19a5):_0x5b19a5;let _0x4d1f29=[];if(_0x38cdb6){if(_0x23015c){const _0x28d3ad=ln(_0x5b19a5,_0x4bcec4=>N(_0x4bcec4));_0x4d1f29=Ku(_0x12413f['serverSyncTree_'],_0x12bde2,_0x28d3ad,_0x38cdb6);}else{const _0x420585=N(_0x5b19a5);_0x4d1f29=Yo(_0x12413f['serverSyncTree_'],_0x12bde2,_0x420585,_0x38cdb6);}}else{if(_0x23015c){const _0x520c3d=ln(_0x5b19a5,_0x15e3cf=>N(_0x15e3cf));_0x4d1f29=qu(_0x12413f['serverSyncTree_'],_0x12bde2,_0x520c3d);}else{const _0x2ff842=N(_0x5b19a5);_0x4d1f29=$t(_0x12413f['serverSyncTree_'],_0x12bde2,_0x2ff842);}}let _0x1e5b8e=_0x12bde2;_0x4d1f29['length']>0x0&&(_0x1e5b8e=st(_0x12413f,_0x12bde2)),V(_0x12413f['eventQueue_'],_0x1e5b8e,_0x4d1f29);}function _r(_0x45df1d,_0x4fd2a0){ms(_0x45df1d,'connected',_0x4fd2a0),_0x4fd2a0===!0x1&&wd(_0x45df1d);}function yd(_0x9c623a,_0x5b77fa){x(_0x5b77fa,(_0x49e5b7,_0x7d1ab3)=>{ms(_0x9c623a,_0x49e5b7,_0x7d1ab3);});}function ms(_0x454a3d,_0x549648,_0x1f213f){const _0x31f6ad=new C('/.info/'+_0x549648),_0x9d4da2=N(_0x1f213f);_0x454a3d['infoData_']['updateSnapshot'](_0x31f6ad,_0x9d4da2);const _0xeb0823=$t(_0x454a3d['infoSyncTree_'],_0x31f6ad,_0x9d4da2);V(_0x454a3d['eventQueue_'],_0x31f6ad,_0xeb0823);}function Vn(_0x113d26){return _0x113d26['nextWriteId_']++;}function vd(_0x5a72c5,_0x28095b,_0x45770c){const _0x43bfd9=Yu(_0x5a72c5['serverSyncTree_'],_0x28095b);return _0x43bfd9!=null?Promise['resolve'](_0x43bfd9):_0x5a72c5['server_']['get'](_0x28095b)['then'](_0x2d27bb=>{const _0x492848=N(_0x2d27bb)['withIndex'](_0x28095b['_queryParams']['getIndex']());bi(_0x5a72c5['serverSyncTree_'],_0x28095b,_0x45770c,!0x0);let _0x1e4a76;if(_0x28095b['_queryParams']['loadsAllData']())_0x1e4a76=$t(_0x5a72c5['serverSyncTree_'],_0x28095b['_path'],_0x492848);else{const _0x3dc7ea=Mt(_0x5a72c5['serverSyncTree_'],_0x28095b);_0x1e4a76=Yo(_0x5a72c5['serverSyncTree_'],_0x28095b['_path'],_0x492848,_0x3dc7ea);}return V(_0x5a72c5['eventQueue_'],_0x28095b['_path'],_0x1e4a76),wn(_0x5a72c5['serverSyncTree_'],_0x28095b,_0x45770c,null,!0x0),_0x492848;},_0x23d4e6=>(ut(_0x5a72c5,'get\x20for\x20query\x20'+O(_0x28095b)+'\x20failed:\x20'+_0x23d4e6),Promise['reject'](new Error(_0x23d4e6))));}function Ed(_0x448212,_0x5ba7a5,_0x29c664,_0x256ecb,_0x3e3ebc){ut(_0x448212,'set',{'path':_0x5ba7a5['toString'](),'value':_0x29c664,'priority':_0x256ecb});const _0x969047=jt(_0x448212),_0x362f4b=N(_0x29c664,_0x256ecb),_0x1d5d61=xn(_0x448212['serverSyncTree_'],_0x5ba7a5),_0x2bfc75=hs(_0x362f4b,_0x1d5d61,_0x969047),_0x2e49b9=Vn(_0x448212),_0x51bcd2=ss(_0x448212['serverSyncTree_'],_0x5ba7a5,_0x2bfc75,_0x2e49b9,!0x0);Bn(_0x448212['eventQueue_'],_0x51bcd2),_0x448212['server_']['put'](_0x5ba7a5['toString'](),_0x362f4b['val'](!0x0),(_0x3dbf80,_0x57a7e2)=>{const _0x3b6c95=_0x3dbf80==='ok';_0x3b6c95||U('set\x20at\x20'+_0x5ba7a5+'\x20failed:\x20'+_0x3dbf80);const _0x1f77c0=pe(_0x448212['serverSyncTree_'],_0x2e49b9,!_0x3b6c95);V(_0x448212['eventQueue_'],_0x5ba7a5,_0x1f77c0),Ai(_0x448212,_0x3e3ebc,_0x3dbf80,_0x57a7e2);});const _0x9bcd2a=vs(_0x448212,_0x5ba7a5);st(_0x448212,_0x9bcd2a),V(_0x448212['eventQueue_'],_0x9bcd2a,[]);}function Id(_0x94c2a8,_0x289959,_0x4de4be,_0x4eac51){ut(_0x94c2a8,'update',{'path':_0x289959['toString'](),'value':_0x4de4be});let _0x4020f6=!0x0;const _0xb6e1fb=jt(_0x94c2a8),_0x258b14={};if(x(_0x4de4be,(_0xfd30b4,_0x1f2eba)=>{_0x4020f6=!0x1,_0x258b14[_0xfd30b4]=Zo(A(_0x289959,_0xfd30b4),N(_0x1f2eba),_0x94c2a8['serverSyncTree_'],_0xb6e1fb);}),_0x4020f6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x94c2a8,_0x4eac51,'ok',void 0x0);else{const _0x279a6d=Vn(_0x94c2a8),_0x265f7c=Gu(_0x94c2a8['serverSyncTree_'],_0x289959,_0x258b14,_0x279a6d);Bn(_0x94c2a8['eventQueue_'],_0x265f7c),_0x94c2a8['server_']['merge'](_0x289959['toString'](),_0x4de4be,(_0x114223,_0x422620)=>{const _0x410049=_0x114223==='ok';_0x410049||U('update\x20at\x20'+_0x289959+'\x20failed:\x20'+_0x114223);const _0xae67b3=pe(_0x94c2a8['serverSyncTree_'],_0x279a6d,!_0x410049),_0x2fb00f=_0xae67b3['length']>0x0?st(_0x94c2a8,_0x289959):_0x289959;V(_0x94c2a8['eventQueue_'],_0x2fb00f,_0xae67b3),Ai(_0x94c2a8,_0x4eac51,_0x114223,_0x422620);}),x(_0x4de4be,_0x593813=>{const _0xf85080=vs(_0x94c2a8,A(_0x289959,_0x593813));st(_0x94c2a8,_0xf85080);}),V(_0x94c2a8['eventQueue_'],_0x289959,[]);}}function wd(_0x18f59b){ut(_0x18f59b,'onDisconnectEvents');const _0xcac70c=jt(_0x18f59b),_0x3811af=pn();Ei(_0x18f59b['onDisconnect_'],w(),(_0x82c1e,_0x5b4218)=>{const _0x2bc95a=Zo(_0x82c1e,_0x5b4218,_0x18f59b['serverSyncTree_'],_0xcac70c);Mo(_0x3811af,_0x82c1e,_0x2bc95a);});let _0x486d5c=[];Ei(_0x3811af,w(),(_0x52d075,_0x5dd836)=>{_0x486d5c=_0x486d5c['concat']($t(_0x18f59b['serverSyncTree_'],_0x52d075,_0x5dd836));const _0x3081d8=vs(_0x18f59b,_0x52d075);st(_0x18f59b,_0x3081d8);}),_0x18f59b['onDisconnect_']=pn(),V(_0x18f59b['eventQueue_'],w(),_0x486d5c);}function Cd(_0xc5941e,_0x400f71,_0x30337b){let _0x52d096;y(_0x400f71['_path'])==='.info'?_0x52d096=bi(_0xc5941e['infoSyncTree_'],_0x400f71,_0x30337b):_0x52d096=bi(_0xc5941e['serverSyncTree_'],_0x400f71,_0x30337b),ia(_0xc5941e['eventQueue_'],_0x400f71['_path'],_0x52d096);}function Td(_0x2e6c1f,_0x18b24b,_0x3d1a2d){let _0x412283;y(_0x18b24b['_path'])==='.info'?_0x412283=wn(_0x2e6c1f['infoSyncTree_'],_0x18b24b,_0x3d1a2d):_0x412283=wn(_0x2e6c1f['serverSyncTree_'],_0x18b24b,_0x3d1a2d),ia(_0x2e6c1f['eventQueue_'],_0x18b24b['_path'],_0x412283);}function aa(_0x4ff5c4){_0x4ff5c4['persistentConnection_']&&_0x4ff5c4['persistentConnection_']['interrupt'](ra);}function Sd(_0x9b2d90){_0x9b2d90['persistentConnection_']&&_0x9b2d90['persistentConnection_']['resume'](ra);}function ut(_0x2374ba,..._0x7a5929){let _0x47feac='';_0x2374ba['persistentConnection_']&&(_0x47feac=_0x2374ba['persistentConnection_']['id']+':'),L(_0x47feac,..._0x7a5929);}function Ai(_0x29b190,_0x486c92,_0x215117,_0x1dd9f4){_0x486c92&&lt(()=>{if(_0x215117==='ok')_0x486c92(null);else{const _0x25b830=(_0x215117||'error')['toUpperCase']();let _0x335c2f=_0x25b830;_0x1dd9f4&&(_0x335c2f+=':\x20'+_0x1dd9f4);const _0x505bd8=new Error(_0x335c2f);_0x505bd8['code']=_0x25b830,_0x486c92(_0x505bd8);}});}function bd(_0xa96358,_0x3243f5,_0x293b95,_0x416d11,_0x5cbe25,_0xe8936e){ut(_0xa96358,'transaction\x20on\x20'+_0x3243f5);const _0x569b30={'path':_0x3243f5,'update':_0x293b95,'onComplete':_0x416d11,'status':null,'order':to(),'applyLocally':_0xe8936e,'retryCount':0x0,'unwatcher':_0x5cbe25,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2884e8=ys(_0xa96358,_0x3243f5,void 0x0);_0x569b30['currentInputSnapshot']=_0x2884e8;const _0x37ecb8=_0x569b30['update'](_0x2884e8['val']());if(_0x37ecb8===void 0x0)_0x569b30['unwatcher'](),_0x569b30['currentOutputSnapshotRaw']=null,_0x569b30['currentOutputSnapshotResolved']=null,_0x569b30['onComplete']&&_0x569b30['onComplete'](null,!0x1,_0x569b30['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x37ecb8,_0x569b30['path']),_0x569b30['status']=0x0;const _0xc3fc89=Un(_0xa96358['transactionQueueTree_'],_0x3243f5),_0x549cfc=Ge(_0xc3fc89)||[];_0x549cfc['push'](_0x569b30),fs(_0xc3fc89,_0x549cfc);let _0x3aa622;typeof _0x37ecb8=='object'&&_0x37ecb8!==null&&Y(_0x37ecb8,'.priority')?(_0x3aa622=Oe(_0x37ecb8,'.priority'),f(Cn(_0x3aa622),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3aa622=(xn(_0xa96358['serverSyncTree_'],_0x3243f5)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x247d64=jt(_0xa96358),_0x1d66f0=N(_0x37ecb8,_0x3aa622),_0x5e1c6d=hs(_0x1d66f0,_0x2884e8,_0x247d64);_0x569b30['currentOutputSnapshotRaw']=_0x1d66f0,_0x569b30['currentOutputSnapshotResolved']=_0x5e1c6d,_0x569b30['currentWriteId']=Vn(_0xa96358);const _0x2e9c34=ss(_0xa96358['serverSyncTree_'],_0x3243f5,_0x5e1c6d,_0x569b30['currentWriteId'],_0x569b30['applyLocally']);V(_0xa96358['eventQueue_'],_0x3243f5,_0x2e9c34),Hn(_0xa96358,_0xa96358['transactionQueueTree_']);}}function ys(_0x593733,_0x297352,_0x3fa627){return xn(_0x593733['serverSyncTree_'],_0x297352,_0x3fa627)||g['EMPTY_NODE'];}function Hn(_0x45deee,_0x35c21d=_0x45deee['transactionQueueTree_']){if(_0x35c21d||$n(_0x45deee,_0x35c21d),Ge(_0x35c21d)){const _0x2a57c4=la(_0x45deee,_0x35c21d);f(_0x2a57c4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2a57c4['every'](_0x4b6d53=>_0x4b6d53['status']===0x0)&&Rd(_0x45deee,Gt(_0x35c21d),_0x2a57c4);}else ea(_0x35c21d)&&Wn(_0x35c21d,_0x4ed22e=>{Hn(_0x45deee,_0x4ed22e);});}function Rd(_0x1de7ff,_0x2af5a6,_0x20cda8){const _0x274510=_0x20cda8['map'](_0x413f04=>_0x413f04['currentWriteId']),_0xf6490f=ys(_0x1de7ff,_0x2af5a6,_0x274510);let _0x49a832=_0xf6490f;const _0x133256=_0xf6490f['hash']();for(let _0x7dca7e=0x0;_0x7dca7e<_0x20cda8['length'];_0x7dca7e++){const _0x2eeb11=_0x20cda8[_0x7dca7e];f(_0x2eeb11['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2eeb11['status']=0x1,_0x2eeb11['retryCount']++;const _0x36a4a7=F(_0x2af5a6,_0x2eeb11['path']);_0x49a832=_0x49a832['updateChild'](_0x36a4a7,_0x2eeb11['currentOutputSnapshotRaw']);}const _0x361bdf=_0x49a832['val'](!0x0),_0x15f62f=_0x2af5a6;_0x1de7ff['server_']['put'](_0x15f62f['toString'](),_0x361bdf,_0xfe608=>{ut(_0x1de7ff,'transaction\x20put\x20response',{'path':_0x15f62f['toString'](),'status':_0xfe608});let _0xa1498a=[];if(_0xfe608==='ok'){const _0x2c416a=[];for(let _0x498999=0x0;_0x498999<_0x20cda8['length'];_0x498999++)_0x20cda8[_0x498999]['status']=0x2,_0xa1498a=_0xa1498a['concat'](pe(_0x1de7ff['serverSyncTree_'],_0x20cda8[_0x498999]['currentWriteId'])),_0x20cda8[_0x498999]['onComplete']&&_0x2c416a['push'](()=>_0x20cda8[_0x498999]['onComplete'](null,!0x0,_0x20cda8[_0x498999]['currentOutputSnapshotResolved'])),_0x20cda8[_0x498999]['unwatcher']();$n(_0x1de7ff,Un(_0x1de7ff['transactionQueueTree_'],_0x2af5a6)),Hn(_0x1de7ff,_0x1de7ff['transactionQueueTree_']),V(_0x1de7ff['eventQueue_'],_0x2af5a6,_0xa1498a);for(let _0x2afdce=0x0;_0x2afdce<_0x2c416a['length'];_0x2afdce++)lt(_0x2c416a[_0x2afdce]);}else{if(_0xfe608==='datastale'){for(let _0x5e2029=0x0;_0x5e2029<_0x20cda8['length'];_0x5e2029++)_0x20cda8[_0x5e2029]['status']===0x3?_0x20cda8[_0x5e2029]['status']=0x4:_0x20cda8[_0x5e2029]['status']=0x0;}else{U('transaction\x20at\x20'+_0x15f62f['toString']()+'\x20failed:\x20'+_0xfe608);for(let _0x240c82=0x0;_0x240c82<_0x20cda8['length'];_0x240c82++)_0x20cda8[_0x240c82]['status']=0x4,_0x20cda8[_0x240c82]['abortReason']=_0xfe608;}st(_0x1de7ff,_0x2af5a6);}},_0x133256);}function st(_0x1d7e91,_0x101e2e){const _0x55e97d=ca(_0x1d7e91,_0x101e2e),_0x2e23a2=Gt(_0x55e97d),_0x3556e4=la(_0x1d7e91,_0x55e97d);return Ad(_0x1d7e91,_0x3556e4,_0x2e23a2),_0x2e23a2;}function Ad(_0x5a87f4,_0x2b2345,_0x5e4ab6){if(_0x2b2345['length']===0x0)return;const _0x427b18=[];let _0x1fad8b=[];const _0x2d55c4=_0x2b2345['filter'](_0x312fc6=>_0x312fc6['status']===0x0)['map'](_0x46eaa7=>_0x46eaa7['currentWriteId']);for(let _0xda8ddd=0x0;_0xda8ddd<_0x2b2345['length'];_0xda8ddd++){const _0x58a9ff=_0x2b2345[_0xda8ddd],_0x2de8b7=F(_0x5e4ab6,_0x58a9ff['path']);let _0x417218=!0x1,_0x125857;if(f(_0x2de8b7!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x58a9ff['status']===0x4)_0x417218=!0x0,_0x125857=_0x58a9ff['abortReason'],_0x1fad8b=_0x1fad8b['concat'](pe(_0x5a87f4['serverSyncTree_'],_0x58a9ff['currentWriteId'],!0x0));else{if(_0x58a9ff['status']===0x0){if(_0x58a9ff['retryCount']>=_d)_0x417218=!0x0,_0x125857='maxretry',_0x1fad8b=_0x1fad8b['concat'](pe(_0x5a87f4['serverSyncTree_'],_0x58a9ff['currentWriteId'],!0x0));else{const _0x1cdef0=ys(_0x5a87f4,_0x58a9ff['path'],_0x2d55c4);_0x58a9ff['currentInputSnapshot']=_0x1cdef0;const _0x16987e=_0x2b2345[_0xda8ddd]['update'](_0x1cdef0['val']());if(_0x16987e!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x16987e,_0x58a9ff['path']);let _0x22cc07=N(_0x16987e);typeof _0x16987e=='object'&&_0x16987e!=null&&Y(_0x16987e,'.priority')||(_0x22cc07=_0x22cc07['updatePriority'](_0x1cdef0['getPriority']()));const _0x60b6bb=_0x58a9ff['currentWriteId'],_0x3f9295=jt(_0x5a87f4),_0x5c694e=hs(_0x22cc07,_0x1cdef0,_0x3f9295);_0x58a9ff['currentOutputSnapshotRaw']=_0x22cc07,_0x58a9ff['currentOutputSnapshotResolved']=_0x5c694e,_0x58a9ff['currentWriteId']=Vn(_0x5a87f4),_0x2d55c4['splice'](_0x2d55c4['indexOf'](_0x60b6bb),0x1),_0x1fad8b=_0x1fad8b['concat'](ss(_0x5a87f4['serverSyncTree_'],_0x58a9ff['path'],_0x5c694e,_0x58a9ff['currentWriteId'],_0x58a9ff['applyLocally'])),_0x1fad8b=_0x1fad8b['concat'](pe(_0x5a87f4['serverSyncTree_'],_0x60b6bb,!0x0));}else _0x417218=!0x0,_0x125857='nodata',_0x1fad8b=_0x1fad8b['concat'](pe(_0x5a87f4['serverSyncTree_'],_0x58a9ff['currentWriteId'],!0x0));}}}V(_0x5a87f4['eventQueue_'],_0x5e4ab6,_0x1fad8b),_0x1fad8b=[],_0x417218&&(_0x2b2345[_0xda8ddd]['status']=0x2,function(_0x7542d7){setTimeout(_0x7542d7,Math['floor'](0x0));}(_0x2b2345[_0xda8ddd]['unwatcher']),_0x2b2345[_0xda8ddd]['onComplete']&&(_0x125857==='nodata'?_0x427b18['push'](()=>_0x2b2345[_0xda8ddd]['onComplete'](null,!0x1,_0x2b2345[_0xda8ddd]['currentInputSnapshot'])):_0x427b18['push'](()=>_0x2b2345[_0xda8ddd]['onComplete'](new Error(_0x125857),!0x1,null))));}$n(_0x5a87f4,_0x5a87f4['transactionQueueTree_']);for(let _0x4b9c91=0x0;_0x4b9c91<_0x427b18['length'];_0x4b9c91++)lt(_0x427b18[_0x4b9c91]);Hn(_0x5a87f4,_0x5a87f4['transactionQueueTree_']);}function ca(_0xa7b873,_0x48965c){let _0x1839ce,_0xea4a9c=_0xa7b873['transactionQueueTree_'];for(_0x1839ce=y(_0x48965c);_0x1839ce!==null&&Ge(_0xea4a9c)===void 0x0;)_0xea4a9c=Un(_0xea4a9c,_0x1839ce),_0x48965c=b(_0x48965c),_0x1839ce=y(_0x48965c);return _0xea4a9c;}function la(_0x5ccb83,_0x28e7f3){const _0x5a977e=[];return ha(_0x5ccb83,_0x28e7f3,_0x5a977e),_0x5a977e['sort']((_0x43c988,_0x2a9d3f)=>_0x43c988['order']-_0x2a9d3f['order']),_0x5a977e;}function ha(_0x2b7f5f,_0x35755f,_0x3e502a){const _0x568b43=Ge(_0x35755f);if(_0x568b43){for(let _0xc0c19c=0x0;_0xc0c19c<_0x568b43['length'];_0xc0c19c++)_0x3e502a['push'](_0x568b43[_0xc0c19c]);}Wn(_0x35755f,_0x19fa49=>{ha(_0x2b7f5f,_0x19fa49,_0x3e502a);});}function $n(_0x9b02,_0x5e6e26){const _0x2ed5f5=Ge(_0x5e6e26);if(_0x2ed5f5){let _0x36bbf5=0x0;for(let _0x4a74a5=0x0;_0x4a74a5<_0x2ed5f5['length'];_0x4a74a5++)_0x2ed5f5[_0x4a74a5]['status']!==0x2&&(_0x2ed5f5[_0x36bbf5]=_0x2ed5f5[_0x4a74a5],_0x36bbf5++);_0x2ed5f5['length']=_0x36bbf5,fs(_0x5e6e26,_0x2ed5f5['length']>0x0?_0x2ed5f5:void 0x0);}Wn(_0x5e6e26,_0x167a4e=>{$n(_0x9b02,_0x167a4e);});}function vs(_0x3b0121,_0x374ed4){const _0x20a99d=Gt(ca(_0x3b0121,_0x374ed4)),_0xce651b=Un(_0x3b0121['transactionQueueTree_'],_0x374ed4);return sd(_0xce651b,_0x25fda7=>{ai(_0x3b0121,_0x25fda7);}),ai(_0x3b0121,_0xce651b),ta(_0xce651b,_0x5ac192=>{ai(_0x3b0121,_0x5ac192);}),_0x20a99d;}function ai(_0x5cdd22,_0x5e6ba9){const _0x174416=Ge(_0x5e6ba9);if(_0x174416){const _0x4ad87b=[];let _0x4b32ab=[],_0x484bc7=-0x1;for(let _0x9397a3=0x0;_0x9397a3<_0x174416['length'];_0x9397a3++)_0x174416[_0x9397a3]['status']===0x3||(_0x174416[_0x9397a3]['status']===0x1?(f(_0x484bc7===_0x9397a3-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x484bc7=_0x9397a3,_0x174416[_0x9397a3]['status']=0x3,_0x174416[_0x9397a3]['abortReason']='set'):(f(_0x174416[_0x9397a3]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x174416[_0x9397a3]['unwatcher'](),_0x4b32ab=_0x4b32ab['concat'](pe(_0x5cdd22['serverSyncTree_'],_0x174416[_0x9397a3]['currentWriteId'],!0x0)),_0x174416[_0x9397a3]['onComplete']&&_0x4ad87b['push'](_0x174416[_0x9397a3]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x484bc7===-0x1?fs(_0x5e6ba9,void 0x0):_0x174416['length']=_0x484bc7+0x1,V(_0x5cdd22['eventQueue_'],Gt(_0x5e6ba9),_0x4b32ab);for(let _0x57fbf8=0x0;_0x57fbf8<_0x4ad87b['length'];_0x57fbf8++)lt(_0x4ad87b[_0x57fbf8]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0xc2d7df){let _0x163ecd='';const _0xad78db=_0xc2d7df['split']('/');for(let _0x3bb736=0x0;_0x3bb736<_0xad78db['length'];_0x3bb736++)if(_0xad78db[_0x3bb736]['length']>0x0){let _0x236490=_0xad78db[_0x3bb736];try{_0x236490=decodeURIComponent(_0x236490['replace'](/\+/g,'\x20'));}catch{}_0x163ecd+='/'+_0x236490;}return _0x163ecd;}function Nd(_0x523109){const _0x57a70d={};_0x523109['charAt'](0x0)==='?'&&(_0x523109=_0x523109['substring'](0x1));for(const _0x477643 of _0x523109['split']('&')){if(_0x477643['length']===0x0)continue;const _0x598a06=_0x477643['split']('=');_0x598a06['length']===0x2?_0x57a70d[decodeURIComponent(_0x598a06[0x0])]=decodeURIComponent(_0x598a06[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x477643+'\x27\x20in\x20query\x20\x27'+_0x523109+'\x27');}return _0x57a70d;}const gr=function(_0x3dcc8d,_0x364968){const _0x1e9b45=Pd(_0x3dcc8d),_0x4062bf=_0x1e9b45['namespace'];_0x1e9b45['domain']==='firebase.com'&&oe(_0x1e9b45['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4062bf||_0x4062bf==='undefined')&&_0x1e9b45['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1e9b45['secure']||Bl();const _0x43777b=_0x1e9b45['scheme']==='ws'||_0x1e9b45['scheme']==='wss';return{'repoInfo':new _o(_0x1e9b45['host'],_0x1e9b45['secure'],_0x4062bf,_0x43777b,_0x364968,'',_0x4062bf!==_0x1e9b45['subdomain']),'path':new C(_0x1e9b45['pathString'])};},Pd=function(_0x1b087f){let _0x536385='',_0xf69112='',_0x52c42d='',_0x2cc619='',_0x1f619d='',_0x3e4d9e=!0x0,_0x260332='https',_0x51056f=0x1bb;if(typeof _0x1b087f=='string'){let _0x1db218=_0x1b087f['indexOf']('//');_0x1db218>=0x0&&(_0x260332=_0x1b087f['substring'](0x0,_0x1db218-0x1),_0x1b087f=_0x1b087f['substring'](_0x1db218+0x2));let _0x2726e8=_0x1b087f['indexOf']('/');_0x2726e8===-0x1&&(_0x2726e8=_0x1b087f['length']);let _0x424c18=_0x1b087f['indexOf']('?');_0x424c18===-0x1&&(_0x424c18=_0x1b087f['length']),_0x536385=_0x1b087f['substring'](0x0,Math['min'](_0x2726e8,_0x424c18)),_0x2726e8<_0x424c18&&(_0x2cc619=kd(_0x1b087f['substring'](_0x2726e8,_0x424c18)));const _0x332724=Nd(_0x1b087f['substring'](Math['min'](_0x1b087f['length'],_0x424c18)));_0x1db218=_0x536385['indexOf'](':'),_0x1db218>=0x0?(_0x3e4d9e=_0x260332==='https'||_0x260332==='wss',_0x51056f=parseInt(_0x536385['substring'](_0x1db218+0x1),0xa)):_0x1db218=_0x536385['length'];const _0x292313=_0x536385['slice'](0x0,_0x1db218);if(_0x292313['toLowerCase']()==='localhost')_0xf69112='localhost';else{if(_0x292313['split']('.')['length']<=0x2)_0xf69112=_0x292313;else{const _0x484b11=_0x536385['indexOf']('.');_0x52c42d=_0x536385['substring'](0x0,_0x484b11)['toLowerCase'](),_0xf69112=_0x536385['substring'](_0x484b11+0x1),_0x1f619d=_0x52c42d;}}'ns'in _0x332724&&(_0x1f619d=_0x332724['ns']);}return{'host':_0x536385,'port':_0x51056f,'domain':_0xf69112,'subdomain':_0x52c42d,'secure':_0x3e4d9e,'scheme':_0x260332,'pathString':_0x2cc619,'namespace':_0x1f619d};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x3861aa=0x0;const _0x88d884=[];return function(_0x2027cb){const _0x24c3a8=_0x2027cb===_0x3861aa;_0x3861aa=_0x2027cb;let _0x37ef7e;const _0x22e975=new Array(0x8);for(_0x37ef7e=0x7;_0x37ef7e>=0x0;_0x37ef7e--)_0x22e975[_0x37ef7e]=mr['charAt'](_0x2027cb%0x40),_0x2027cb=Math['floor'](_0x2027cb/0x40);f(_0x2027cb===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1455d6=_0x22e975['join']('');if(_0x24c3a8){for(_0x37ef7e=0xb;_0x37ef7e>=0x0&&_0x88d884[_0x37ef7e]===0x3f;_0x37ef7e--)_0x88d884[_0x37ef7e]=0x0;_0x88d884[_0x37ef7e]++;}else{for(_0x37ef7e=0x0;_0x37ef7e<0xc;_0x37ef7e++)_0x88d884[_0x37ef7e]=Math['floor'](Math['random']()*0x40);}for(_0x37ef7e=0x0;_0x37ef7e<0xc;_0x37ef7e++)_0x1455d6+=mr['charAt'](_0x88d884[_0x37ef7e]);return f(_0x1455d6['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1455d6;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x5485e4,_0x110c53,_0x517d8a,_0x1eb2a6){this['eventType']=_0x5485e4,this['eventRegistration']=_0x110c53,this['snapshot']=_0x517d8a,this['prevName']=_0x1eb2a6;}['getPath'](){const _0x991fb7=this['snapshot']['ref'];return this['eventType']==='value'?_0x991fb7['_path']:_0x991fb7['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x3ed8e8,_0x3d57fc,_0x3f73d8){this['eventRegistration']=_0x3ed8e8,this['error']=_0x3d57fc,this['path']=_0x3f73d8;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x5e57a1,_0x284963){this['snapshotCallback']=_0x5e57a1,this['cancelCallback']=_0x284963;}['onValue'](_0x3f8405,_0x3668bc){this['snapshotCallback']['call'](null,_0x3f8405,_0x3668bc);}['onCancel'](_0x3fd8a6){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3fd8a6);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5796a8){return this['snapshotCallback']===_0x5796a8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5796a8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5796a8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4ddbb5,_0xcffcd7,_0x453810,_0x2cfa0f){this['_repo']=_0x4ddbb5,this['_path']=_0xcffcd7,this['_queryParams']=_0x453810,this['_orderByCalled']=_0x2cfa0f;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xd4f511=nr(this['_queryParams']),_0x39ae67=Bi(_0xd4f511);return _0x39ae67==='{}'?'default':_0x39ae67;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x3e4cdc){if(_0x3e4cdc=k(_0x3e4cdc),!(_0x3e4cdc instanceof be))return!0x1;const _0x1eb7da=this['_repo']===_0x3e4cdc['_repo'],_0x51d42e=qi(this['_path'],_0x3e4cdc['_path']),_0x34db83=this['_queryIdentifier']===_0x3e4cdc['_queryIdentifier'];return _0x1eb7da&&_0x51d42e&&_0x34db83;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x42a447,_0x3b07a5){if(_0x42a447['_orderByCalled']===!0x0)throw new Error(_0x3b07a5+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x51d2be){let _0x54d47e=null,_0x32c2c5=null;if(_0x51d2be['hasStart']()&&(_0x54d47e=_0x51d2be['getIndexStartValue']()),_0x51d2be['hasEnd']()&&(_0x32c2c5=_0x51d2be['getIndexEndValue']()),_0x51d2be['getIndex']()===ye){const _0x21deda='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x29129c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x51d2be['hasStart']()){if(_0x51d2be['getIndexStartName']()!==xe)throw new Error(_0x21deda);if(typeof _0x54d47e!='string')throw new Error(_0x29129c);}if(_0x51d2be['hasEnd']()){if(_0x51d2be['getIndexEndName']()!==Ie)throw new Error(_0x21deda);if(typeof _0x32c2c5!='string')throw new Error(_0x29129c);}}else{if(_0x51d2be['getIndex']()===R){if(_0x54d47e!=null&&!Cn(_0x54d47e)||_0x32c2c5!=null&&!Cn(_0x32c2c5))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x51d2be['getIndex']()instanceof Ki||_0x51d2be['getIndex']()===Po,'unknown\x20index\x20type.'),_0x54d47e!=null&&typeof _0x54d47e=='object'||_0x32c2c5!=null&&typeof _0x32c2c5=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x19e8e7){if(_0x19e8e7['hasStart']()&&_0x19e8e7['hasEnd']()&&_0x19e8e7['hasLimit']()&&!_0x19e8e7['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x53a317,_0x1a941c){super(_0x53a317,_0x1a941c,new Qi(),!0x1);}get['parent'](){const _0x3a0d11=To(this['_path']);return _0x3a0d11===null?null:new Z(this['_repo'],_0x3a0d11);}get['root'](){let _0x5496c7=this;for(;_0x5496c7['parent']!==null;)_0x5496c7=_0x5496c7['parent'];return _0x5496c7;}}class rt{constructor(_0x3142e9,_0x536b26,_0x3e82c5){this['_node']=_0x3142e9,this['ref']=_0x536b26,this['_index']=_0x3e82c5;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5ed87d){const _0x5cb357=new C(_0x5ed87d),_0x492212=Lt(this['ref'],_0x5ed87d);return new rt(this['_node']['getChild'](_0x5cb357),_0x492212,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2b5ed4){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5e3fae,_0x1943e6)=>_0x2b5ed4(new rt(_0x1943e6,Lt(this['ref'],_0x5e3fae),R)));}['hasChild'](_0x1733bc){const _0x25635a=new C(_0x1733bc);return!this['_node']['getChild'](_0x25635a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function u_(_0x285b7f,_0x23c1fb){return _0x285b7f=k(_0x285b7f),_0x285b7f['_checkNotDeleted']('ref'),_0x23c1fb!==void 0x0?Lt(_0x285b7f['_root'],_0x23c1fb):_0x285b7f['_root'];}function Lt(_0x3b9219,_0x5cb855){return _0x3b9219=k(_0x3b9219),y(_0x3b9219['_path'])===null?ud('child','path',_0x5cb855):_s('child','path',_0x5cb855),new Z(_0x3b9219['_repo'],A(_0x3b9219['_path'],_0x5cb855));}function d_(_0x3461c1,_0x144ca2){_0x3461c1=k(_0x3461c1),gs('push',_0x3461c1['_path']),qt('push',_0x144ca2,_0x3461c1['_path'],!0x0);const _0x3857d6=oa(_0x3461c1['_repo']),_0x5638b3=Od(_0x3857d6),_0x5ddc8c=Lt(_0x3461c1,_0x5638b3),_0x4489c8=Lt(_0x3461c1,_0x5638b3);let _0x4dcb25;return _0x144ca2!=null?_0x4dcb25=Ld(_0x4489c8,_0x144ca2)['then'](()=>_0x4489c8):_0x4dcb25=Promise['resolve'](_0x4489c8),_0x5ddc8c['then']=_0x4dcb25['then']['bind'](_0x4dcb25),_0x5ddc8c['catch']=_0x4dcb25['then']['bind'](_0x4dcb25,void 0x0),_0x5ddc8c;}function Ld(_0x2230e3,_0x439797){_0x2230e3=k(_0x2230e3),gs('set',_0x2230e3['_path']),qt('set',_0x439797,_0x2230e3['_path'],!0x1);const _0x3d4754=new Ve();return Ed(_0x2230e3['_repo'],_0x2230e3['_path'],_0x439797,null,_0x3d4754['wrapCallback'](()=>{})),_0x3d4754['promise'];}function f_(_0x5a0ae6,_0x375bde){hd('update',_0x375bde,_0x5a0ae6['_path']);const _0x529309=new Ve();return Id(_0x5a0ae6['_repo'],_0x5a0ae6['_path'],_0x375bde,_0x529309['wrapCallback'](()=>{})),_0x529309['promise'];}function p_(_0x1be464){_0x1be464=k(_0x1be464);const _0x3d7240=new ua(()=>{}),_0x48d9ba=new qn(_0x3d7240);return vd(_0x1be464['_repo'],_0x1be464,_0x48d9ba)['then'](_0x377780=>new rt(_0x377780,new Z(_0x1be464['_repo'],_0x1be464['_path']),_0x1be464['_queryParams']['getIndex']()));}class qn{constructor(_0xea1cbf){this['callbackContext']=_0xea1cbf;}['respondsTo'](_0x39aa67){return _0x39aa67==='value';}['createEvent'](_0x56922b,_0x3bfe09){const _0x373cd7=_0x3bfe09['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x56922b['snapshotNode'],new Z(_0x3bfe09['_repo'],_0x3bfe09['_path']),_0x373cd7));}['getEventRunner'](_0x166228){return _0x166228['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x166228['error']):()=>this['callbackContext']['onValue'](_0x166228['snapshot'],null);}['createCancelEvent'](_0x5d5690,_0x90340a){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x5d5690,_0x90340a):null;}['matches'](_0x3bfe4e){return _0x3bfe4e instanceof qn?!_0x3bfe4e['callbackContext']||!this['callbackContext']?!0x0:_0x3bfe4e['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x3308cd,_0x5a090b,_0x24e229,_0x458874,_0x48c541){const _0x22905f=new ua(_0x24e229,void 0x0),_0x2c6172=new qn(_0x22905f);return Cd(_0x3308cd['_repo'],_0x3308cd,_0x2c6172),()=>Td(_0x3308cd['_repo'],_0x3308cd,_0x2c6172);}function Fd(_0x3c6b7d,_0x37245f,_0xbc4999,_0x22f8dc){return xd(_0x3c6b7d,'value',_0x37245f);}class dt{}class pa extends dt{constructor(_0x4e8000,_0x15a78e){super(),this['_value']=_0x4e8000,this['_key']=_0x15a78e,this['type']='endAt';}['_apply'](_0x42fdd1){qt('endAt',this['_value'],_0x42fdd1['_path'],!0x0);const _0x3d8806=Kh(_0x42fdd1['_queryParams'],this['_value'],this['_key']);if(fa(_0x3d8806),Gn(_0x3d8806),_0x42fdd1['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x42fdd1['_repo'],_0x42fdd1['_path'],_0x3d8806,_0x42fdd1['_orderByCalled']);}}function __(_0x567e7d,_0x345556){return new pa(_0x567e7d,_0x345556);}class _a extends dt{constructor(_0x961dd0,_0x293183){super(),this['_value']=_0x961dd0,this['_key']=_0x293183,this['type']='startAt';}['_apply'](_0x13f1a4){qt('startAt',this['_value'],_0x13f1a4['_path'],!0x0);const _0x32585e=jh(_0x13f1a4['_queryParams'],this['_value'],this['_key']);if(fa(_0x32585e),Gn(_0x32585e),_0x13f1a4['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x13f1a4['_repo'],_0x13f1a4['_path'],_0x32585e,_0x13f1a4['_orderByCalled']);}}function g_(_0xea7840=null,_0x586bb3){return new _a(_0xea7840,_0x586bb3);}class Ud extends dt{constructor(_0x3580c6){super(),this['_limit']=_0x3580c6,this['type']='limitToFirst';}['_apply'](_0x53c48c){if(_0x53c48c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x53c48c['_repo'],_0x53c48c['_path'],zh(_0x53c48c['_queryParams'],this['_limit']),_0x53c48c['_orderByCalled']);}}function m_(_0x426def){if(Math['floor'](_0x426def)!==_0x426def||_0x426def<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x426def);}class Wd extends dt{constructor(_0x2ecd43){super(),this['_path']=_0x2ecd43,this['type']='orderByChild';}['_apply'](_0x66a37e){da(_0x66a37e,'orderByChild');const _0x3ad8c1=new C(this['_path']);if(v(_0x3ad8c1))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x35e052=new Ki(_0x3ad8c1),_0x17510a=Do(_0x66a37e['_queryParams'],_0x35e052);return Gn(_0x17510a),new be(_0x66a37e['_repo'],_0x66a37e['_path'],_0x17510a,!0x0);}}function y_(_0x3484d4){if(_0x3484d4==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3484d4==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3484d4==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x3484d4),new Wd(_0x3484d4);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x55039d){da(_0x55039d,'orderByKey');const _0x1aba3b=Do(_0x55039d['_queryParams'],ye);return Gn(_0x1aba3b),new be(_0x55039d['_repo'],_0x55039d['_path'],_0x1aba3b,!0x0);}}function v_(){return new Bd();}class Vd extends dt{constructor(_0x36c669,_0x323011){super(),this['_value']=_0x36c669,this['_key']=_0x323011,this['type']='equalTo';}['_apply'](_0x941e58){if(qt('equalTo',this['_value'],_0x941e58['_path'],!0x1),_0x941e58['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x941e58['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x941e58));}}function E_(_0x1b954e,_0x2c6c69){return new Vd(_0x1b954e,_0x2c6c69);}function I_(_0x7d7a8f,..._0x4dd0ea){let _0x19acd4=k(_0x7d7a8f);for(const _0x2702d4 of _0x4dd0ea)_0x19acd4=_0x2702d4['_apply'](_0x19acd4);return _0x19acd4;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x77e825,_0x264dce,_0x24aedc,_0x1cead2){const _0x264c2f=_0x264dce['lastIndexOf'](':'),_0x5eed03=_0x264dce['substring'](0x0,_0x264c2f),_0x21233a=Wt(_0x5eed03);_0x77e825['repoInfo_']=new _o(_0x264dce,_0x21233a,_0x77e825['repoInfo_']['namespace'],_0x77e825['repoInfo_']['webSocketOnly'],_0x77e825['repoInfo_']['nodeAdmin'],_0x77e825['repoInfo_']['persistenceKey'],_0x77e825['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x24aedc),_0x1cead2&&(_0x77e825['authTokenProvider_']=_0x1cead2);}function qd(_0x3aa300,_0xbe9749,_0x2fd564,_0x591edf,_0xb8d2b9){let _0x32da34=_0x591edf||_0x3aa300['options']['databaseURL'];_0x32da34===void 0x0&&(_0x3aa300['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3aa300['options']['projectId']),_0x32da34=_0x3aa300['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1e2f16=gr(_0x32da34,_0xb8d2b9),_0x1c9ae1=_0x1e2f16['repoInfo'],_0x4de259;typeof process<'u'&&Us&&(_0x4de259=Us[Hd]),_0x4de259?(_0x32da34='http://'+_0x4de259+'?ns='+_0x1c9ae1['namespace'],_0x1e2f16=gr(_0x32da34,_0xb8d2b9),_0x1c9ae1=_0x1e2f16['repoInfo']):_0x1e2f16['repoInfo']['secure'];const _0x232dd1=new Jl(_0x3aa300['name'],_0x3aa300['options'],_0xbe9749);dd('Invalid\x20Firebase\x20Database\x20URL',_0x1e2f16),v(_0x1e2f16['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x461b99=jd(_0x1c9ae1,_0x3aa300,_0x232dd1,new Ql(_0x3aa300,_0x2fd564));return new Kd(_0x461b99,_0x3aa300);}function zd(_0x5e1d8f,_0x19e28f){const _0x5896b5=ki[_0x19e28f];(!_0x5896b5||_0x5896b5[_0x5e1d8f['key']]!==_0x5e1d8f)&&oe('Database\x20'+_0x19e28f+'('+_0x5e1d8f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x5e1d8f),delete _0x5896b5[_0x5e1d8f['key']];}function jd(_0x44de98,_0x42841f,_0x48fcba,_0x51439c){let _0x59817e=ki[_0x42841f['name']];_0x59817e||(_0x59817e={},ki[_0x42841f['name']]=_0x59817e);let _0x404bea=_0x59817e[_0x44de98['toURLString']()];return _0x404bea&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x404bea=new gd(_0x44de98,$d,_0x48fcba,_0x51439c),_0x59817e[_0x44de98['toURLString']()]=_0x404bea,_0x404bea;}class Kd{constructor(_0x1bf8fe,_0x305067){this['_repoInternal']=_0x1bf8fe,this['app']=_0x305067,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x444454){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x444454+'\x20on\x20a\x20deleted\x20database.');}}function w_(_0x2309f8=Qr(),_0x5e959f){const _0xe7961d=Ui(_0x2309f8,'database')['getImmediate']({'identifier':_0x5e959f});if(!_0xe7961d['_instanceStarted']){const _0x43c21b=ac('database');_0x43c21b&&Yd(_0xe7961d,..._0x43c21b);}return _0xe7961d;}function Yd(_0x1cd43f,_0x24b89e,_0x564378,_0xddc145={}){_0x1cd43f=k(_0x1cd43f),_0x1cd43f['_checkNotDeleted']('useEmulator');const _0x2bbe22=_0x24b89e+':'+_0x564378,_0x9798d3=_0x1cd43f['_repoInternal'];if(_0x1cd43f['_instanceStarted']){if(_0x2bbe22===_0x1cd43f['_repoInternal']['repoInfo_']['host']&&De(_0xddc145,_0x9798d3['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5a2b56;if(_0x9798d3['repoInfo_']['nodeAdmin'])_0xddc145['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5a2b56=new tn(tn['OWNER']);else{if(_0xddc145['mockUserToken']){const _0x2383d2=typeof _0xddc145['mockUserToken']=='string'?_0xddc145['mockUserToken']:cc(_0xddc145['mockUserToken'],_0x1cd43f['app']['options']['projectId']);_0x5a2b56=new tn(_0x2383d2);}}Wt(_0x24b89e)&&jr(_0x24b89e),Gd(_0x9798d3,_0x2bbe22,_0xddc145,_0x5a2b56);}function C_(_0x4da3fb){_0x4da3fb=k(_0x4da3fb),_0x4da3fb['_checkNotDeleted']('goOffline'),aa(_0x4da3fb['_repo']);}function T_(_0x2bc01f){_0x2bc01f=k(_0x2bc01f),_0x2bc01f['_checkNotDeleted']('goOnline'),Sd(_0x2bc01f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x37cfed){Ll(ct),et(new Me('database',(_0xe7162e,{instanceIdentifier:_0x1f415a})=>{const _0x5adfec=_0xe7162e['getProvider']('app')['getImmediate'](),_0x9f0b8f=_0xe7162e['getProvider']('auth-internal'),_0xd6de9e=_0xe7162e['getProvider']('app-check-internal');return qd(_0x5adfec,_0x9f0b8f,_0xd6de9e,_0x1f415a);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x37cfed),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jd={'.sv':'timestamp'};function S_(){return Jd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xd{constructor(_0x1a3430,_0x2b8fc6){this['committed']=_0x1a3430,this['snapshot']=_0x2b8fc6;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function b_(_0x3e15cc,_0x2ffeaf,_0x3891c0){if(_0x3e15cc=k(_0x3e15cc),gs('Reference.transaction',_0x3e15cc['_path']),_0x3e15cc['key']==='.length'||_0x3e15cc['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3e15cc['key']+'\x20is\x20a\x20read-only\x20object.';const _0x24e151=!0x0,_0x52cfc5=new Ve(),_0x20847f=(_0x20d694,_0x5f01be,_0x306373)=>{let _0x4a855a=null;_0x20d694?_0x52cfc5['reject'](_0x20d694):(_0x4a855a=new rt(_0x306373,new Z(_0x3e15cc['_repo'],_0x3e15cc['_path']),R),_0x52cfc5['resolve'](new Xd(_0x5f01be,_0x4a855a)));},_0x5b9223=Fd(_0x3e15cc,()=>{});return bd(_0x3e15cc['_repo'],_0x3e15cc['_path'],_0x2ffeaf,_0x20847f,_0x5b9223,_0x24e151),_0x52cfc5['promise'];}ie['prototype']['simpleListen']=function(_0xa3d3c9,_0x527ff2){this['sendRequest']('q',{'p':_0xa3d3c9},_0x527ff2);},ie['prototype']['echo']=function(_0x5d17f5,_0x5bb8d6){this['sendRequest']('echo',{'d':_0x5d17f5},_0x5bb8d6);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Zd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function ef(_0x44daa3,..._0x26cb5d){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x44daa3,..._0x26cb5d);}function nn(_0x42211d,..._0x262989){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x42211d,..._0x262989);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3159bd,..._0x23cc73){throw Es(_0x3159bd,..._0x23cc73);}function J(_0x542c17,..._0xf26302){return Es(_0x542c17,..._0xf26302);}function ya(_0xde41d6,_0x1c4155,_0x22b40b){const _0x24bbfd={...Zd(),[_0x1c4155]:_0x22b40b};return new Ut('auth','Firebase',_0x24bbfd)['create'](_0x1c4155,{'appName':_0xde41d6['name']});}function se(_0x2637f1){return ya(_0x2637f1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0xfc8cef,..._0x4f6d99){if(typeof _0xfc8cef!='string'){const _0x40c873=_0x4f6d99[0x0],_0x2481dc=[..._0x4f6d99['slice'](0x1)];return _0x2481dc[0x0]&&(_0x2481dc[0x0]['appName']=_0xfc8cef['name']),_0xfc8cef['_errorFactory']['create'](_0x40c873,..._0x2481dc);}return ma['create'](_0xfc8cef,..._0x4f6d99);}function m(_0x5c6093,_0x3152cd,..._0x5c2d62){if(!_0x5c6093)throw Es(_0x3152cd,..._0x5c2d62);}function te(_0x4a761f){const _0x494553='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4a761f;throw nn(_0x494553),new Error(_0x494553);}function ae(_0x2b3da1,_0x3855bb){_0x2b3da1||te(_0x3855bb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x280ead;return typeof self<'u'&&((_0x280ead=self['location'])==null?void 0x0:_0x280ead['href'])||'';}function tf(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x15c181;return typeof self<'u'&&((_0x15c181=self['location'])==null?void 0x0:_0x15c181['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(tf()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function sf(){if(typeof navigator>'u')return null;const _0x200706=navigator;return _0x200706['languages']&&_0x200706['languages'][0x0]||_0x200706['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x372a05,_0x3ba383){this['shortDelay']=_0x372a05,this['longDelay']=_0x3ba383,ae(_0x3ba383>_0x372a05,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return nf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x1d8cf6,_0x1c477f){ae(_0x1d8cf6['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x425783}=_0x1d8cf6['emulator'];return _0x1c477f?''+_0x425783+(_0x1c477f['startsWith']('/')?_0x1c477f['slice'](0x1):_0x1c477f):_0x425783;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x1c3822,_0x41b765,_0x530e0e){this['fetchImpl']=_0x1c3822,_0x41b765&&(this['headersImpl']=_0x41b765),_0x530e0e&&(this['responseImpl']=_0x530e0e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},of=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],af=new Kt(0x7530,0xea60);function Re(_0x5eb87f,_0x494e10){return _0x5eb87f['tenantId']&&!_0x494e10['tenantId']?{..._0x494e10,'tenantId':_0x5eb87f['tenantId']}:_0x494e10;}async function Ae(_0x38d1e2,_0x16fba6,_0x5cb542,_0x5b1615,_0xd68830={}){return Ea(_0x38d1e2,_0xd68830,async()=>{let _0x41c616={},_0x59a0f6={};_0x5b1615&&(_0x16fba6==='GET'?_0x59a0f6=_0x5b1615:_0x41c616={'body':JSON['stringify'](_0x5b1615)});const _0x5a3558=at({..._0x59a0f6,'key':_0x38d1e2['config']['apiKey']})['slice'](0x1),_0x5c9276=await _0x38d1e2['_getAdditionalHeaders']();_0x5c9276['Content-Type']='application/json',_0x38d1e2['languageCode']&&(_0x5c9276['X-Firebase-Locale']=_0x38d1e2['languageCode']);const _0x1683cf={'method':_0x16fba6,'headers':_0x5c9276,..._0x41c616};return lc()||(_0x1683cf['referrerPolicy']='strict-origin-when-cross-origin'),_0x38d1e2['emulatorConfig']&&Wt(_0x38d1e2['emulatorConfig']['host'])&&(_0x1683cf['credentials']='include'),va['fetch']()(await Ia(_0x38d1e2,_0x38d1e2['config']['apiHost'],_0x5cb542,_0x5a3558),_0x1683cf);});}async function Ea(_0x4bf7bc,_0x183d5a,_0x278258){_0x4bf7bc['_canInitEmulator']=!0x1;const _0x3e8c8a={...rf,..._0x183d5a};try{const _0x53e115=new lf(_0x4bf7bc),_0x419285=await Promise['race']([_0x278258(),_0x53e115['promise']]);_0x53e115['clearNetworkTimeout']();const _0x515469=await _0x419285['json']();if('needConfirmation'in _0x515469)throw en(_0x4bf7bc,'account-exists-with-different-credential',_0x515469);if(_0x419285['ok']&&!('errorMessage'in _0x515469))return _0x515469;{const _0x45f4af=_0x419285['ok']?_0x515469['errorMessage']:_0x515469['error']['message'],[_0x5d25f6,_0x4ce8ca]=_0x45f4af['split']('\x20:\x20');if(_0x5d25f6==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x4bf7bc,'credential-already-in-use',_0x515469);if(_0x5d25f6==='EMAIL_EXISTS')throw en(_0x4bf7bc,'email-already-in-use',_0x515469);if(_0x5d25f6==='USER_DISABLED')throw en(_0x4bf7bc,'user-disabled',_0x515469);const _0x4dbe2c=_0x3e8c8a[_0x5d25f6]||_0x5d25f6['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4ce8ca)throw ya(_0x4bf7bc,_0x4dbe2c,_0x4ce8ca);K(_0x4bf7bc,_0x4dbe2c);}}catch(_0x102ade){if(_0x102ade instanceof Se)throw _0x102ade;K(_0x4bf7bc,'network-request-failed',{'message':String(_0x102ade)});}}async function Yt(_0x577e10,_0x51dae5,_0x7377ac,_0x1b4fa0,_0x4aff67={}){const _0x1b4473=await Ae(_0x577e10,_0x51dae5,_0x7377ac,_0x1b4fa0,_0x4aff67);return'mfaPendingCredential'in _0x1b4473&&K(_0x577e10,'multi-factor-auth-required',{'_serverResponse':_0x1b4473}),_0x1b4473;}async function Ia(_0x2f3bde,_0x13454d,_0x5c6084,_0x1690d6){const _0x5518ba=''+_0x13454d+_0x5c6084+'?'+_0x1690d6,_0x550abb=_0x2f3bde,_0xfe4c74=_0x550abb['config']['emulator']?Is(_0x2f3bde['config'],_0x5518ba):_0x2f3bde['config']['apiScheme']+'://'+_0x5518ba;return of['includes'](_0x5c6084)&&(await _0x550abb['_persistenceManagerAvailable'],_0x550abb['_getPersistenceType']()==='COOKIE')?_0x550abb['_getPersistence']()['_getFinalTarget'](_0xfe4c74)['toString']():_0xfe4c74;}function cf(_0x506bc3){switch(_0x506bc3){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class lf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x37d514){this['auth']=_0x37d514,this['timer']=null,this['promise']=new Promise((_0x1ea5e2,_0x275411)=>{this['timer']=setTimeout(()=>_0x275411(J(this['auth'],'network-request-failed')),af['get']());});}}function en(_0x192368,_0x2d5e9e,_0x5e41a4){const _0x43751e={'appName':_0x192368['name']};_0x5e41a4['email']&&(_0x43751e['email']=_0x5e41a4['email']),_0x5e41a4['phoneNumber']&&(_0x43751e['phoneNumber']=_0x5e41a4['phoneNumber']);const _0x550192=J(_0x192368,_0x2d5e9e,_0x43751e);return _0x550192['customData']['_tokenResponse']=_0x5e41a4,_0x550192;}function vr(_0x194084){return _0x194084!==void 0x0&&_0x194084['enterprise']!==void 0x0;}class hf{constructor(_0x206a73){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x206a73['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x206a73['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x206a73['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x7516c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x11bbc9 of this['recaptchaEnforcementState'])if(_0x11bbc9['provider']&&_0x11bbc9['provider']===_0x7516c)return cf(_0x11bbc9['enforcementState']);return null;}['isProviderEnabled'](_0x4ac4d7){return this['getProviderEnforcementState'](_0x4ac4d7)==='ENFORCE'||this['getProviderEnforcementState'](_0x4ac4d7)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function uf(_0x52d1c9,_0x10443b){return Ae(_0x52d1c9,'GET','/v2/recaptchaConfig',Re(_0x52d1c9,_0x10443b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function df(_0x397dd0,_0x1c376d){return Ae(_0x397dd0,'POST','/v1/accounts:delete',_0x1c376d);}async function Sn(_0x5b09a9,_0x2e1449){return Ae(_0x5b09a9,'POST','/v1/accounts:lookup',_0x2e1449);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0xaa4de1){if(_0xaa4de1)try{const _0x17ef55=new Date(Number(_0xaa4de1));if(!isNaN(_0x17ef55['getTime']()))return _0x17ef55['toUTCString']();}catch{}}async function ff(_0x3270c4,_0x45c687=!0x1){const _0x32147c=k(_0x3270c4),_0x4c6eb7=await _0x32147c['getIdToken'](_0x45c687),_0x2985ed=ws(_0x4c6eb7);m(_0x2985ed&&_0x2985ed['exp']&&_0x2985ed['auth_time']&&_0x2985ed['iat'],_0x32147c['auth'],'internal-error');const _0x4b8900=typeof _0x2985ed['firebase']=='object'?_0x2985ed['firebase']:void 0x0,_0x42e21f=_0x4b8900==null?void 0x0:_0x4b8900['sign_in_provider'];return{'claims':_0x2985ed,'token':_0x4c6eb7,'authTime':St(ci(_0x2985ed['auth_time'])),'issuedAtTime':St(ci(_0x2985ed['iat'])),'expirationTime':St(ci(_0x2985ed['exp'])),'signInProvider':_0x42e21f||null,'signInSecondFactor':(_0x4b8900==null?void 0x0:_0x4b8900['sign_in_second_factor'])||null};}function ci(_0x57e6c7){return Number(_0x57e6c7)*0x3e8;}function ws(_0x306bc3){const [_0x43269a,_0x11d518,_0x580754]=_0x306bc3['split']('.');if(_0x43269a===void 0x0||_0x11d518===void 0x0||_0x580754===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x442a04=cn(_0x11d518);return _0x442a04?JSON['parse'](_0x442a04):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x502014){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x502014==null?void 0x0:_0x502014['toString']()),null;}}function Er(_0x23c7ed){const _0x4b16fe=ws(_0x23c7ed);return m(_0x4b16fe,'internal-error'),m(typeof _0x4b16fe['exp']<'u','internal-error'),m(typeof _0x4b16fe['iat']<'u','internal-error'),Number(_0x4b16fe['exp'])-Number(_0x4b16fe['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x5f42dd,_0x52390b,_0x5a8d7f=!0x1){if(_0x5a8d7f)return _0x52390b;try{return await _0x52390b;}catch(_0x35c113){throw _0x35c113 instanceof Se&&pf(_0x35c113)&&_0x5f42dd['auth']['currentUser']===_0x5f42dd&&await _0x5f42dd['auth']['signOut'](),_0x35c113;}}function pf({code:_0x395a8e}){return _0x395a8e==='auth/user-disabled'||_0x395a8e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _f{constructor(_0x3d45fd){this['user']=_0x3d45fd,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xa62611){if(_0xa62611){const _0x4f8cfb=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4f8cfb;}else{this['errorBackoff']=0x7530;const _0x342375=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x342375);}}['schedule'](_0x1b0ff7=!0x1){if(!this['isRunning'])return;const _0x508cc5=this['getInterval'](_0x1b0ff7);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x508cc5);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3aa163){(_0x3aa163==null?void 0x0:_0x3aa163['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5df972,_0x52801a){this['createdAt']=_0x5df972,this['lastLoginAt']=_0x52801a,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x55a416){this['createdAt']=_0x55a416['createdAt'],this['lastLoginAt']=_0x55a416['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0xe86654){var _0x42f768;const _0x3df115=_0xe86654['auth'],_0x3f1de9=await _0xe86654['getIdToken'](),_0x505c92=await xt(_0xe86654,Sn(_0x3df115,{'idToken':_0x3f1de9}));m(_0x505c92==null?void 0x0:_0x505c92['users']['length'],_0x3df115,'internal-error');const _0x5d4346=_0x505c92['users'][0x0];_0xe86654['_notifyReloadListener'](_0x5d4346);const _0x53b370=(_0x42f768=_0x5d4346['providerUserInfo'])!=null&&_0x42f768['length']?wa(_0x5d4346['providerUserInfo']):[],_0x156a44=mf(_0xe86654['providerData'],_0x53b370),_0x532e11=_0xe86654['isAnonymous'],_0x33aba4=!(_0xe86654['email']&&_0x5d4346['passwordHash'])&&!(_0x156a44!=null&&_0x156a44['length']),_0x27ecfc=_0x532e11?_0x33aba4:!0x1,_0x295d26={'uid':_0x5d4346['localId'],'displayName':_0x5d4346['displayName']||null,'photoURL':_0x5d4346['photoUrl']||null,'email':_0x5d4346['email']||null,'emailVerified':_0x5d4346['emailVerified']||!0x1,'phoneNumber':_0x5d4346['phoneNumber']||null,'tenantId':_0x5d4346['tenantId']||null,'providerData':_0x156a44,'metadata':new Pi(_0x5d4346['createdAt'],_0x5d4346['lastLoginAt']),'isAnonymous':_0x27ecfc};Object['assign'](_0xe86654,_0x295d26);}async function gf(_0x454019){const _0x3d60d5=k(_0x454019);await bn(_0x3d60d5),await _0x3d60d5['auth']['_persistUserIfCurrent'](_0x3d60d5),_0x3d60d5['auth']['_notifyListenersIfCurrent'](_0x3d60d5);}function mf(_0x46c8f3,_0x3f0830){return[..._0x46c8f3['filter'](_0x9419cf=>!_0x3f0830['some'](_0x22726c=>_0x22726c['providerId']===_0x9419cf['providerId'])),..._0x3f0830];}function wa(_0xacb24){return _0xacb24['map'](({providerId:_0x25421a,..._0x44cf1b})=>({'providerId':_0x25421a,'uid':_0x44cf1b['rawId']||'','displayName':_0x44cf1b['displayName']||null,'email':_0x44cf1b['email']||null,'phoneNumber':_0x44cf1b['phoneNumber']||null,'photoURL':_0x44cf1b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function yf(_0x1c3b9f,_0xdf3517){const _0x1b620c=await Ea(_0x1c3b9f,{},async()=>{const _0xafcd59=at({'grant_type':'refresh_token','refresh_token':_0xdf3517})['slice'](0x1),{tokenApiHost:_0x31600a,apiKey:_0x33ddc7}=_0x1c3b9f['config'],_0x455024=await Ia(_0x1c3b9f,_0x31600a,'/v1/token','key='+_0x33ddc7),_0x482db2=await _0x1c3b9f['_getAdditionalHeaders']();_0x482db2['Content-Type']='application/x-www-form-urlencoded';const _0x2afdee={'method':'POST','headers':_0x482db2,'body':_0xafcd59};return _0x1c3b9f['emulatorConfig']&&Wt(_0x1c3b9f['emulatorConfig']['host'])&&(_0x2afdee['credentials']='include'),va['fetch']()(_0x455024,_0x2afdee);});return{'accessToken':_0x1b620c['access_token'],'expiresIn':_0x1b620c['expires_in'],'refreshToken':_0x1b620c['refresh_token']};}async function vf(_0x5adbcf,_0x37e504){return Ae(_0x5adbcf,'POST','/v2/accounts:revokeToken',Re(_0x5adbcf,_0x37e504));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5c5cac){m(_0x5c5cac['idToken'],'internal-error'),m(typeof _0x5c5cac['idToken']<'u','internal-error'),m(typeof _0x5c5cac['refreshToken']<'u','internal-error');const _0x3bd1e6='expiresIn'in _0x5c5cac&&typeof _0x5c5cac['expiresIn']<'u'?Number(_0x5c5cac['expiresIn']):Er(_0x5c5cac['idToken']);this['updateTokensAndExpiration'](_0x5c5cac['idToken'],_0x5c5cac['refreshToken'],_0x3bd1e6);}['updateFromIdToken'](_0xaa48b8){m(_0xaa48b8['length']!==0x0,'internal-error');const _0x329ced=Er(_0xaa48b8);this['updateTokensAndExpiration'](_0xaa48b8,null,_0x329ced);}async['getToken'](_0x239427,_0x3c2e37=!0x1){return!_0x3c2e37&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x239427,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x239427,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x578528,_0x744084){const {accessToken:_0x505af0,refreshToken:_0x989151,expiresIn:_0x6f1640}=await yf(_0x578528,_0x744084);this['updateTokensAndExpiration'](_0x505af0,_0x989151,Number(_0x6f1640));}['updateTokensAndExpiration'](_0x5059a3,_0x503208,_0x2b29c8){this['refreshToken']=_0x503208||null,this['accessToken']=_0x5059a3||null,this['expirationTime']=Date['now']()+_0x2b29c8*0x3e8;}static['fromJSON'](_0x1cd3ef,_0x4d3831){const {refreshToken:_0x1f25c7,accessToken:_0x375bca,expirationTime:_0x4a7ac3}=_0x4d3831,_0x44ddeb=new Je();return _0x1f25c7&&(m(typeof _0x1f25c7=='string','internal-error',{'appName':_0x1cd3ef}),_0x44ddeb['refreshToken']=_0x1f25c7),_0x375bca&&(m(typeof _0x375bca=='string','internal-error',{'appName':_0x1cd3ef}),_0x44ddeb['accessToken']=_0x375bca),_0x4a7ac3&&(m(typeof _0x4a7ac3=='number','internal-error',{'appName':_0x1cd3ef}),_0x44ddeb['expirationTime']=_0x4a7ac3),_0x44ddeb;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2d4fe9){this['accessToken']=_0x2d4fe9['accessToken'],this['refreshToken']=_0x2d4fe9['refreshToken'],this['expirationTime']=_0x2d4fe9['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x31e1ce,_0x2f1c72){m(typeof _0x31e1ce=='string'||typeof _0x31e1ce>'u','internal-error',{'appName':_0x2f1c72});}class z{constructor({uid:_0x22c3e2,auth:_0x509b90,stsTokenManager:_0x45ea81,..._0x340f5e}){this['providerId']='firebase',this['proactiveRefresh']=new _f(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x22c3e2,this['auth']=_0x509b90,this['stsTokenManager']=_0x45ea81,this['accessToken']=_0x45ea81['accessToken'],this['displayName']=_0x340f5e['displayName']||null,this['email']=_0x340f5e['email']||null,this['emailVerified']=_0x340f5e['emailVerified']||!0x1,this['phoneNumber']=_0x340f5e['phoneNumber']||null,this['photoURL']=_0x340f5e['photoURL']||null,this['isAnonymous']=_0x340f5e['isAnonymous']||!0x1,this['tenantId']=_0x340f5e['tenantId']||null,this['providerData']=_0x340f5e['providerData']?[..._0x340f5e['providerData']]:[],this['metadata']=new Pi(_0x340f5e['createdAt']||void 0x0,_0x340f5e['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4d45b1){const _0x5ec435=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x4d45b1));return m(_0x5ec435,this['auth'],'internal-error'),this['accessToken']!==_0x5ec435&&(this['accessToken']=_0x5ec435,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5ec435;}['getIdTokenResult'](_0x235013){return ff(this,_0x235013);}['reload'](){return gf(this);}['_assign'](_0x507be8){this!==_0x507be8&&(m(this['uid']===_0x507be8['uid'],this['auth'],'internal-error'),this['displayName']=_0x507be8['displayName'],this['photoURL']=_0x507be8['photoURL'],this['email']=_0x507be8['email'],this['emailVerified']=_0x507be8['emailVerified'],this['phoneNumber']=_0x507be8['phoneNumber'],this['isAnonymous']=_0x507be8['isAnonymous'],this['tenantId']=_0x507be8['tenantId'],this['providerData']=_0x507be8['providerData']['map'](_0x24d594=>({..._0x24d594})),this['metadata']['_copy'](_0x507be8['metadata']),this['stsTokenManager']['_assign'](_0x507be8['stsTokenManager']));}['_clone'](_0x19bee9){const _0x9803c4=new z({...this,'auth':_0x19bee9,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x9803c4['metadata']['_copy'](this['metadata']),_0x9803c4;}['_onReload'](_0x9eb7aa){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x9eb7aa,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x61e28d){this['reloadListener']?this['reloadListener'](_0x61e28d):this['reloadUserInfo']=_0x61e28d;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2deac2,_0x1e8bea=!0x1){let _0x23798b=!0x1;_0x2deac2['idToken']&&_0x2deac2['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2deac2),_0x23798b=!0x0),_0x1e8bea&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x23798b&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1887d8=await this['getIdToken']();return await xt(this,df(this['auth'],{'idToken':_0x1887d8})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x33cf0b=>({..._0x33cf0b})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x513ca7,_0x2d6634){const _0x1a6ddf=_0x2d6634['displayName']??void 0x0,_0xf7a434=_0x2d6634['email']??void 0x0,_0x3b3ed4=_0x2d6634['phoneNumber']??void 0x0,_0x6d1668=_0x2d6634['photoURL']??void 0x0,_0x5749cd=_0x2d6634['tenantId']??void 0x0,_0x34e896=_0x2d6634['_redirectEventId']??void 0x0,_0x147d92=_0x2d6634['createdAt']??void 0x0,_0x15146a=_0x2d6634['lastLoginAt']??void 0x0,{uid:_0x2317f9,emailVerified:_0x1f4f6d,isAnonymous:_0x3dc991,providerData:_0x5e2122,stsTokenManager:_0x11a6e1}=_0x2d6634;m(_0x2317f9&&_0x11a6e1,_0x513ca7,'internal-error');const _0x427c8c=Je['fromJSON'](this['name'],_0x11a6e1);m(typeof _0x2317f9=='string',_0x513ca7,'internal-error'),ce(_0x1a6ddf,_0x513ca7['name']),ce(_0xf7a434,_0x513ca7['name']),m(typeof _0x1f4f6d=='boolean',_0x513ca7,'internal-error'),m(typeof _0x3dc991=='boolean',_0x513ca7,'internal-error'),ce(_0x3b3ed4,_0x513ca7['name']),ce(_0x6d1668,_0x513ca7['name']),ce(_0x5749cd,_0x513ca7['name']),ce(_0x34e896,_0x513ca7['name']),ce(_0x147d92,_0x513ca7['name']),ce(_0x15146a,_0x513ca7['name']);const _0x3c8a1a=new z({'uid':_0x2317f9,'auth':_0x513ca7,'email':_0xf7a434,'emailVerified':_0x1f4f6d,'displayName':_0x1a6ddf,'isAnonymous':_0x3dc991,'photoURL':_0x6d1668,'phoneNumber':_0x3b3ed4,'tenantId':_0x5749cd,'stsTokenManager':_0x427c8c,'createdAt':_0x147d92,'lastLoginAt':_0x15146a});return _0x5e2122&&Array['isArray'](_0x5e2122)&&(_0x3c8a1a['providerData']=_0x5e2122['map'](_0x1e198b=>({..._0x1e198b}))),_0x34e896&&(_0x3c8a1a['_redirectEventId']=_0x34e896),_0x3c8a1a;}static async['_fromIdTokenResponse'](_0x3fb520,_0x17942d,_0x22910e=!0x1){const _0x2a357b=new Je();_0x2a357b['updateFromServerResponse'](_0x17942d);const _0x4dd65c=new z({'uid':_0x17942d['localId'],'auth':_0x3fb520,'stsTokenManager':_0x2a357b,'isAnonymous':_0x22910e});return await bn(_0x4dd65c),_0x4dd65c;}static async['_fromGetAccountInfoResponse'](_0x171f34,_0x2afb12,_0x2760dc){const _0x2d4379=_0x2afb12['users'][0x0];m(_0x2d4379['localId']!==void 0x0,'internal-error');const _0x4e706c=_0x2d4379['providerUserInfo']!==void 0x0?wa(_0x2d4379['providerUserInfo']):[],_0x1cc782=!(_0x2d4379['email']&&_0x2d4379['passwordHash'])&&!(_0x4e706c!=null&&_0x4e706c['length']),_0xeb66da=new Je();_0xeb66da['updateFromIdToken'](_0x2760dc);const _0x39fcaf=new z({'uid':_0x2d4379['localId'],'auth':_0x171f34,'stsTokenManager':_0xeb66da,'isAnonymous':_0x1cc782}),_0x495a8b={'uid':_0x2d4379['localId'],'displayName':_0x2d4379['displayName']||null,'photoURL':_0x2d4379['photoUrl']||null,'email':_0x2d4379['email']||null,'emailVerified':_0x2d4379['emailVerified']||!0x1,'phoneNumber':_0x2d4379['phoneNumber']||null,'tenantId':_0x2d4379['tenantId']||null,'providerData':_0x4e706c,'metadata':new Pi(_0x2d4379['createdAt'],_0x2d4379['lastLoginAt']),'isAnonymous':!(_0x2d4379['email']&&_0x2d4379['passwordHash'])&&!(_0x4e706c!=null&&_0x4e706c['length'])};return Object['assign'](_0x39fcaf,_0x495a8b),_0x39fcaf;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x9a8f3){ae(_0x9a8f3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x126f49=Ir['get'](_0x9a8f3);return _0x126f49?(ae(_0x126f49 instanceof _0x9a8f3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x126f49):(_0x126f49=new _0x9a8f3(),Ir['set'](_0x9a8f3,_0x126f49),_0x126f49);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4ded4a,_0x308794){this['storage'][_0x4ded4a]=_0x308794;}async['_get'](_0x37e9f9){const _0x969b44=this['storage'][_0x37e9f9];return _0x969b44===void 0x0?null:_0x969b44;}async['_remove'](_0x46131b){delete this['storage'][_0x46131b];}['_addListener'](_0x3f8c,_0x4cb5c1){}['_removeListener'](_0xe4cbd5,_0x4a0674){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x1a1489,_0x41eb6d,_0x57f400){return'firebase:'+_0x1a1489+':'+_0x41eb6d+':'+_0x57f400;}class Xe{constructor(_0x21ee45,_0x3ebe55,_0x34a9a8){this['persistence']=_0x21ee45,this['auth']=_0x3ebe55,this['userKey']=_0x34a9a8;const {config:_0x234e69,name:_0x4a0e77}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x234e69['apiKey'],_0x4a0e77),this['fullPersistenceKey']=sn('persistence',_0x234e69['apiKey'],_0x4a0e77),this['boundEventHandler']=_0x3ebe55['_onStorageEvent']['bind'](_0x3ebe55),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1cc7d8){return this['persistence']['_set'](this['fullUserKey'],_0x1cc7d8['toJSON']());}async['getCurrentUser'](){const _0x188d94=await this['persistence']['_get'](this['fullUserKey']);if(!_0x188d94)return null;if(typeof _0x188d94=='string'){const _0xb6e1cf=await Sn(this['auth'],{'idToken':_0x188d94})['catch'](()=>{});return _0xb6e1cf?z['_fromGetAccountInfoResponse'](this['auth'],_0xb6e1cf,_0x188d94):null;}return z['_fromJSON'](this['auth'],_0x188d94);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x385619){if(this['persistence']===_0x385619)return;const _0x573360=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x385619,_0x573360)return this['setCurrentUser'](_0x573360);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x146c33,_0x5a484a,_0x19c269='authUser'){if(!_0x5a484a['length'])return new Xe(ne(wr),_0x146c33,_0x19c269);const _0x4bf351=(await Promise['all'](_0x5a484a['map'](async _0x18dcc=>{if(await _0x18dcc['_isAvailable']())return _0x18dcc;})))['filter'](_0x17b909=>_0x17b909);let _0x132f9d=_0x4bf351[0x0]||ne(wr);const _0xf11473=sn(_0x19c269,_0x146c33['config']['apiKey'],_0x146c33['name']);let _0x15574b=null;for(const _0x4116ee of _0x5a484a)try{const _0x2e20c6=await _0x4116ee['_get'](_0xf11473);if(_0x2e20c6){let _0x450209;if(typeof _0x2e20c6=='string'){const _0x49c141=await Sn(_0x146c33,{'idToken':_0x2e20c6})['catch'](()=>{});if(!_0x49c141)break;_0x450209=await z['_fromGetAccountInfoResponse'](_0x146c33,_0x49c141,_0x2e20c6);}else _0x450209=z['_fromJSON'](_0x146c33,_0x2e20c6);_0x4116ee!==_0x132f9d&&(_0x15574b=_0x450209),_0x132f9d=_0x4116ee;break;}}catch{}const _0x112b41=_0x4bf351['filter'](_0x456a5d=>_0x456a5d['_shouldAllowMigration']);return!_0x132f9d['_shouldAllowMigration']||!_0x112b41['length']?new Xe(_0x132f9d,_0x146c33,_0x19c269):(_0x132f9d=_0x112b41[0x0],_0x15574b&&await _0x132f9d['_set'](_0xf11473,_0x15574b['toJSON']()),await Promise['all'](_0x5a484a['map'](async _0x204593=>{if(_0x204593!==_0x132f9d)try{await _0x204593['_remove'](_0xf11473);}catch{}})),new Xe(_0x132f9d,_0x146c33,_0x19c269));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x4b9454){const _0x3bfd58=_0x4b9454['toLowerCase']();if(_0x3bfd58['includes']('opera/')||_0x3bfd58['includes']('opr/')||_0x3bfd58['includes']('opios/'))return'Opera';if(Ra(_0x3bfd58))return'IEMobile';if(_0x3bfd58['includes']('msie')||_0x3bfd58['includes']('trident/'))return'IE';if(_0x3bfd58['includes']('edge/'))return'Edge';if(Ta(_0x3bfd58))return'Firefox';if(_0x3bfd58['includes']('silk/'))return'Silk';if(ka(_0x3bfd58))return'Blackberry';if(Na(_0x3bfd58))return'Webos';if(Sa(_0x3bfd58))return'Safari';if((_0x3bfd58['includes']('chrome/')||ba(_0x3bfd58))&&!_0x3bfd58['includes']('edge/'))return'Chrome';if(Aa(_0x3bfd58))return'Android';{const _0x5f4539=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x44cd06=_0x4b9454['match'](_0x5f4539);if((_0x44cd06==null?void 0x0:_0x44cd06['length'])===0x2)return _0x44cd06[0x1];}return'Other';}function Ta(_0x1bea57=W()){return/firefox\//i['test'](_0x1bea57);}function Sa(_0x352e9f=W()){const _0x56933e=_0x352e9f['toLowerCase']();return _0x56933e['includes']('safari/')&&!_0x56933e['includes']('chrome/')&&!_0x56933e['includes']('crios/')&&!_0x56933e['includes']('android');}function ba(_0x4d1369=W()){return/crios\//i['test'](_0x4d1369);}function Ra(_0x1416c4=W()){return/iemobile/i['test'](_0x1416c4);}function Aa(_0xd28c65=W()){return/android/i['test'](_0xd28c65);}function ka(_0xab09d7=W()){return/blackberry/i['test'](_0xab09d7);}function Na(_0x18b9c8=W()){return/webos/i['test'](_0x18b9c8);}function Cs(_0x548b95=W()){return/iphone|ipad|ipod/i['test'](_0x548b95)||/macintosh/i['test'](_0x548b95)&&/mobile/i['test'](_0x548b95);}function Ef(_0x24dd41=W()){var _0x4c7d6b;return Cs(_0x24dd41)&&!!((_0x4c7d6b=window['navigator'])!=null&&_0x4c7d6b['standalone']);}function If(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5bd9c6=W()){return Cs(_0x5bd9c6)||Aa(_0x5bd9c6)||Na(_0x5bd9c6)||ka(_0x5bd9c6)||/windows phone/i['test'](_0x5bd9c6)||Ra(_0x5bd9c6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x39a16a,_0x355e03=[]){let _0x2dc57d;switch(_0x39a16a){case'Browser':_0x2dc57d=Cr(W());break;case'Worker':_0x2dc57d=Cr(W())+'-'+_0x39a16a;break;default:_0x2dc57d=_0x39a16a;}const _0x208b21=_0x355e03['length']?_0x355e03['join'](','):'FirebaseCore-web';return _0x2dc57d+'/JsCore/'+ct+'/'+_0x208b21;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3bbc73){this['auth']=_0x3bbc73,this['queue']=[];}['pushCallback'](_0x1faeae,_0x5747d5){const _0x50fe3e=_0x3e9f7f=>new Promise((_0x17fbcb,_0x5b79c0)=>{try{const _0x4ecb02=_0x1faeae(_0x3e9f7f);_0x17fbcb(_0x4ecb02);}catch(_0x1a042c){_0x5b79c0(_0x1a042c);}});_0x50fe3e['onAbort']=_0x5747d5,this['queue']['push'](_0x50fe3e);const _0xfb0d0e=this['queue']['length']-0x1;return()=>{this['queue'][_0xfb0d0e]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5f1892){if(this['auth']['currentUser']===_0x5f1892)return;const _0x12454c=[];try{for(const _0x12c7e2 of this['queue'])await _0x12c7e2(_0x5f1892),_0x12c7e2['onAbort']&&_0x12454c['push'](_0x12c7e2['onAbort']);}catch(_0x590303){_0x12454c['reverse']();for(const _0x5266ba of _0x12454c)try{_0x5266ba();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x590303==null?void 0x0:_0x590303['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Cf(_0x5e57e9,_0x46e1ed={}){return Ae(_0x5e57e9,'GET','/v2/passwordPolicy',Re(_0x5e57e9,_0x46e1ed));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tf=0x6;class Sf{constructor(_0xc82ead){var _0x3798b2;const _0xcd077c=_0xc82ead['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xcd077c['minPasswordLength']??Tf,_0xcd077c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xcd077c['maxPasswordLength']),_0xcd077c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xcd077c['containsLowercaseCharacter']),_0xcd077c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xcd077c['containsUppercaseCharacter']),_0xcd077c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xcd077c['containsNumericCharacter']),_0xcd077c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xcd077c['containsNonAlphanumericCharacter']),this['enforcementState']=_0xc82ead['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3798b2=_0xc82ead['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3798b2['join'](''))??'',this['forceUpgradeOnSignin']=_0xc82ead['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xc82ead['schemaVersion'];}['validatePassword'](_0x33e686){const _0x2dd86b={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x33e686,_0x2dd86b),this['validatePasswordCharacterOptions'](_0x33e686,_0x2dd86b),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['meetsMinPasswordLength']??!0x0),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['meetsMaxPasswordLength']??!0x0),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['containsLowercaseLetter']??!0x0),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['containsUppercaseLetter']??!0x0),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['containsNumericCharacter']??!0x0),_0x2dd86b['isValid']&&(_0x2dd86b['isValid']=_0x2dd86b['containsNonAlphanumericCharacter']??!0x0),_0x2dd86b;}['validatePasswordLengthOptions'](_0x58061a,_0x3eedc2){const _0x388936=this['customStrengthOptions']['minPasswordLength'],_0x5d9f19=this['customStrengthOptions']['maxPasswordLength'];_0x388936&&(_0x3eedc2['meetsMinPasswordLength']=_0x58061a['length']>=_0x388936),_0x5d9f19&&(_0x3eedc2['meetsMaxPasswordLength']=_0x58061a['length']<=_0x5d9f19);}['validatePasswordCharacterOptions'](_0x3f8497,_0x215bc7){this['updatePasswordCharacterOptionsStatuses'](_0x215bc7,!0x1,!0x1,!0x1,!0x1);let _0x1afe00;for(let _0x5ce2f6=0x0;_0x5ce2f6<_0x3f8497['length'];_0x5ce2f6++)_0x1afe00=_0x3f8497['charAt'](_0x5ce2f6),this['updatePasswordCharacterOptionsStatuses'](_0x215bc7,_0x1afe00>='a'&&_0x1afe00<='z',_0x1afe00>='A'&&_0x1afe00<='Z',_0x1afe00>='0'&&_0x1afe00<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1afe00));}['updatePasswordCharacterOptionsStatuses'](_0x1b21e0,_0x4edc50,_0x520862,_0x5d147e,_0x5be351){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1b21e0['containsLowercaseLetter']||(_0x1b21e0['containsLowercaseLetter']=_0x4edc50)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1b21e0['containsUppercaseLetter']||(_0x1b21e0['containsUppercaseLetter']=_0x520862)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1b21e0['containsNumericCharacter']||(_0x1b21e0['containsNumericCharacter']=_0x5d147e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1b21e0['containsNonAlphanumericCharacter']||(_0x1b21e0['containsNonAlphanumericCharacter']=_0x5be351));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x552205,_0x2cf7e8,_0x18b454,_0x47980a){this['app']=_0x552205,this['heartbeatServiceProvider']=_0x2cf7e8,this['appCheckServiceProvider']=_0x18b454,this['config']=_0x47980a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new wf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x552205['name'],this['clientVersion']=_0x47980a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4a9aa3=>this['_resolvePersistenceManagerAvailable']=_0x4a9aa3);}['_initializeWithPersistence'](_0x54f584,_0x5ae7fd){return _0x5ae7fd&&(this['_popupRedirectResolver']=ne(_0x5ae7fd)),this['_initializationPromise']=this['queue'](async()=>{var _0x3f80fc,_0x43caff,_0x151e4e;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x54f584),(_0x3f80fc=this['_resolvePersistenceManagerAvailable'])==null||_0x3f80fc['call'](this),!this['_deleted'])){if((_0x43caff=this['_popupRedirectResolver'])!=null&&_0x43caff['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5ae7fd),this['lastNotifiedUid']=((_0x151e4e=this['currentUser'])==null?void 0x0:_0x151e4e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x14d6df=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x14d6df)){if(this['currentUser']&&_0x14d6df&&this['currentUser']['uid']===_0x14d6df['uid']){this['_currentUser']['_assign'](_0x14d6df),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x14d6df,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x6665f8){try{const _0x4e84a6=await Sn(this,{'idToken':_0x6665f8}),_0x2d57ee=await z['_fromGetAccountInfoResponse'](this,_0x4e84a6,_0x6665f8);await this['directlySetCurrentUser'](_0x2d57ee);}catch(_0xc01ddc){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xc01ddc),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5c66c4){var _0x7bc0ce;if(H(this['app'])){const _0x4ab607=this['app']['settings']['authIdToken'];return _0x4ab607?new Promise(_0x9f7fd1=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4ab607)['then'](_0x9f7fd1,_0x9f7fd1));}):this['directlySetCurrentUser'](null);}const _0x1dabd1=await this['assertedPersistence']['getCurrentUser']();let _0x5cc1ae=_0x1dabd1,_0x168e4c=!0x1;if(_0x5c66c4&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2bf77d=(_0x7bc0ce=this['redirectUser'])==null?void 0x0:_0x7bc0ce['_redirectEventId'],_0x372c19=_0x5cc1ae==null?void 0x0:_0x5cc1ae['_redirectEventId'],_0x2940aa=await this['tryRedirectSignIn'](_0x5c66c4);(!_0x2bf77d||_0x2bf77d===_0x372c19)&&(_0x2940aa!=null&&_0x2940aa['user'])&&(_0x5cc1ae=_0x2940aa['user'],_0x168e4c=!0x0);}if(!_0x5cc1ae)return this['directlySetCurrentUser'](null);if(!_0x5cc1ae['_redirectEventId']){if(_0x168e4c)try{await this['beforeStateQueue']['runMiddleware'](_0x5cc1ae);}catch(_0x4d0713){_0x5cc1ae=_0x1dabd1,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4d0713));}return _0x5cc1ae?this['reloadAndSetCurrentUserOrClear'](_0x5cc1ae):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5cc1ae['_redirectEventId']?this['directlySetCurrentUser'](_0x5cc1ae):this['reloadAndSetCurrentUserOrClear'](_0x5cc1ae);}async['tryRedirectSignIn'](_0x983a6d){let _0x317dd0=null;try{_0x317dd0=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x983a6d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x317dd0;}async['reloadAndSetCurrentUserOrClear'](_0x5c2fcf){try{await bn(_0x5c2fcf);}catch(_0x4644c2){if((_0x4644c2==null?void 0x0:_0x4644c2['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5c2fcf);}['useDeviceLanguage'](){this['languageCode']=sf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2423d4){if(H(this['app']))return Promise['reject'](se(this));const _0x25021c=_0x2423d4?k(_0x2423d4):null;return _0x25021c&&m(_0x25021c['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x25021c&&_0x25021c['_clone'](this));}async['_updateCurrentUser'](_0x154d4a,_0xc133eb=!0x1){if(!this['_deleted'])return _0x154d4a&&m(this['tenantId']===_0x154d4a['tenantId'],this,'tenant-id-mismatch'),_0xc133eb||await this['beforeStateQueue']['runMiddleware'](_0x154d4a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x154d4a),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xa79560){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0xa79560));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xe16d4c){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x20a504=this['_getPasswordPolicyInternal']();return _0x20a504['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x20a504['validatePassword'](_0xe16d4c);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2e8945=await Cf(this),_0x555c8f=new Sf(_0x2e8945);this['tenantId']===null?this['_projectPasswordPolicy']=_0x555c8f:this['_tenantPasswordPolicies'][this['tenantId']]=_0x555c8f;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x22a07d){this['_errorFactory']=new Ut('auth','Firebase',_0x22a07d());}['onAuthStateChanged'](_0x3d58b3,_0x10f0cb,_0x379ac6){return this['registerStateListener'](this['authStateSubscription'],_0x3d58b3,_0x10f0cb,_0x379ac6);}['beforeAuthStateChanged'](_0x1a2a93,_0x17c9ee){return this['beforeStateQueue']['pushCallback'](_0x1a2a93,_0x17c9ee);}['onIdTokenChanged'](_0x547f49,_0x5dcf69,_0x31b4c0){return this['registerStateListener'](this['idTokenSubscription'],_0x547f49,_0x5dcf69,_0x31b4c0);}['authStateReady'](){return new Promise((_0x339d34,_0x50a4ed)=>{if(this['currentUser'])_0x339d34();else{const _0x53c5cf=this['onAuthStateChanged'](()=>{_0x53c5cf(),_0x339d34();},_0x50a4ed);}});}async['revokeAccessToken'](_0x15496a){if(this['currentUser']){const _0x4fbc9f=await this['currentUser']['getIdToken'](),_0x599d72={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x15496a,'idToken':_0x4fbc9f};this['tenantId']!=null&&(_0x599d72['tenantId']=this['tenantId']),await vf(this,_0x599d72);}}['toJSON'](){var _0x396386;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x396386=this['_currentUser'])==null?void 0x0:_0x396386['toJSON']()};}async['_setRedirectUser'](_0x7237b1,_0x4e6c0d){const _0x3bc616=await this['getOrInitRedirectPersistenceManager'](_0x4e6c0d);return _0x7237b1===null?_0x3bc616['removeCurrentUser']():_0x3bc616['setCurrentUser'](_0x7237b1);}async['getOrInitRedirectPersistenceManager'](_0x525f26){if(!this['redirectPersistenceManager']){const _0x24e81c=_0x525f26&&ne(_0x525f26)||this['_popupRedirectResolver'];m(_0x24e81c,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x24e81c['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x32befb){var _0x3b10dc,_0x484d64;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3b10dc=this['_currentUser'])==null?void 0x0:_0x3b10dc['_redirectEventId'])===_0x32befb?this['_currentUser']:((_0x484d64=this['redirectUser'])==null?void 0x0:_0x484d64['_redirectEventId'])===_0x32befb?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4b3459){if(_0x4b3459===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4b3459));}['_notifyListenersIfCurrent'](_0x3380b6){_0x3380b6===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x480fc4;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3b00a8=((_0x480fc4=this['currentUser'])==null?void 0x0:_0x480fc4['uid'])??null;this['lastNotifiedUid']!==_0x3b00a8&&(this['lastNotifiedUid']=_0x3b00a8,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2bb621,_0xafe0ee,_0x280f6b,_0x2cfbd5){if(this['_deleted'])return()=>{};const _0x79342a=typeof _0xafe0ee=='function'?_0xafe0ee:_0xafe0ee['next']['bind'](_0xafe0ee);let _0x109e5e=!0x1;const _0x29796a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x29796a,this,'internal-error'),_0x29796a['then'](()=>{_0x109e5e||_0x79342a(this['currentUser']);}),typeof _0xafe0ee=='function'){const _0x4a9985=_0x2bb621['addObserver'](_0xafe0ee,_0x280f6b,_0x2cfbd5);return()=>{_0x109e5e=!0x0,_0x4a9985();};}else{const _0xb47805=_0x2bb621['addObserver'](_0xafe0ee);return()=>{_0x109e5e=!0x0,_0xb47805();};}}async['directlySetCurrentUser'](_0xa23f5d){this['currentUser']&&this['currentUser']!==_0xa23f5d&&this['_currentUser']['_stopProactiveRefresh'](),_0xa23f5d&&this['isProactiveRefreshEnabled']&&_0xa23f5d['_startProactiveRefresh'](),this['currentUser']=_0xa23f5d,_0xa23f5d?await this['assertedPersistence']['setCurrentUser'](_0xa23f5d):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x28cb97){return this['operations']=this['operations']['then'](_0x28cb97,_0x28cb97),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x283080){!_0x283080||this['frameworks']['includes'](_0x283080)||(this['frameworks']['push'](_0x283080),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x3da643;const _0x1811dc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1811dc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1609a4=await((_0x3da643=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3da643['getHeartbeatsHeader']());_0x1609a4&&(_0x1811dc['X-Firebase-Client']=_0x1609a4);const _0x1f4e60=await this['_getAppCheckToken']();return _0x1f4e60&&(_0x1811dc['X-Firebase-AppCheck']=_0x1f4e60),_0x1811dc;}async['_getAppCheckToken'](){var _0x49b720;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1fb917=await((_0x49b720=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x49b720['getToken']());return _0x1fb917!=null&&_0x1fb917['error']&&ef('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1fb917['error']),_0x1fb917==null?void 0x0:_0x1fb917['token'];}}function qe(_0x36cdfb){return k(_0x36cdfb);}class Tr{constructor(_0xab744f){this['auth']=_0xab744f,this['observer']=null,this['addObserver']=Ic(_0x2c51b6=>this['observer']=_0x2c51b6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Rf(_0x458285){zn=_0x458285;}function Da(_0x5166f1){return zn['loadJS'](_0x5166f1);}function Af(){return zn['recaptchaEnterpriseScript'];}function kf(){return zn['gapiScript'];}function Nf(_0xe8d853){return'__'+_0xe8d853+Math['floor'](Math['random']()*0xf4240);}class Pf{constructor(){this['enterprise']=new Of();}['ready'](_0x472a8f){_0x472a8f();}['execute'](_0x23af6c,_0x50bb89){return Promise['resolve']('token');}['render'](_0x48d6e7,_0x227c2d){return'';}}class Of{['ready'](_0x3c2b96){_0x3c2b96();}['execute'](_0x22f238,_0x1ec979){return Promise['resolve']('token');}['render'](_0x12b299,_0x2b9cd7){return'';}}const Df='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x239bfa){this['type']=Df,this['auth']=qe(_0x239bfa);}async['verify'](_0xd4f545='verify',_0x314398=!0x1){async function _0x51804a(_0x303ca9){if(!_0x314398){if(_0x303ca9['tenantId']==null&&_0x303ca9['_agentRecaptchaConfig']!=null)return _0x303ca9['_agentRecaptchaConfig']['siteKey'];if(_0x303ca9['tenantId']!=null&&_0x303ca9['_tenantRecaptchaConfigs'][_0x303ca9['tenantId']]!==void 0x0)return _0x303ca9['_tenantRecaptchaConfigs'][_0x303ca9['tenantId']]['siteKey'];}return new Promise(async(_0x53be9a,_0x8ccf20)=>{uf(_0x303ca9,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x160748=>{if(_0x160748['recaptchaKey']===void 0x0)_0x8ccf20(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4b69ec=new hf(_0x160748);return _0x303ca9['tenantId']==null?_0x303ca9['_agentRecaptchaConfig']=_0x4b69ec:_0x303ca9['_tenantRecaptchaConfigs'][_0x303ca9['tenantId']]=_0x4b69ec,_0x53be9a(_0x4b69ec['siteKey']);}})['catch'](_0x50d936=>{_0x8ccf20(_0x50d936);});});}function _0x16d748(_0x358b3f,_0x3d7b23,_0x49d484){const _0x4168d3=window['grecaptcha'];vr(_0x4168d3)?_0x4168d3['enterprise']['ready'](()=>{_0x4168d3['enterprise']['execute'](_0x358b3f,{'action':_0xd4f545})['then'](_0x4a3294=>{_0x3d7b23(_0x4a3294);})['catch'](()=>{_0x3d7b23(Ma);});}):_0x49d484(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Pf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3d20c5,_0x9a7d71)=>{_0x51804a(this['auth'])['then'](async _0x1cd6f4=>{if(!_0x314398&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x16d748(_0x1cd6f4,_0x3d20c5,_0x9a7d71);else{if(typeof window>'u'){_0x9a7d71(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x269439=Af();_0x269439['length']!==0x0&&(_0x269439+=_0x1cd6f4+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x1ca061;(_0x1ca061=le['scriptInjectionDeferred'])==null||_0x1ca061['resolve']();},Da(_0x269439)['then'](()=>{var _0x42d381;return(_0x42d381=le['scriptInjectionDeferred'])==null?void 0x0:_0x42d381['promise'];})['then'](()=>{_0x16d748(_0x1cd6f4,_0x3d20c5,_0x9a7d71);})['catch'](_0x724b8a=>{_0x9a7d71(_0x724b8a);});}})['catch'](_0x113182=>{_0x9a7d71(_0x113182);});});}}le['scriptInjectionDeferred']=null;async function br(_0x2e0e11,_0x870838,_0x594776,_0x2a7026=!0x1,_0x3573d2=!0x1){const _0x53fb0b=new le(_0x2e0e11);let _0x113a23;if(_0x3573d2)_0x113a23=Ma;else try{_0x113a23=await _0x53fb0b['verify'](_0x594776);}catch{_0x113a23=await _0x53fb0b['verify'](_0x594776,!0x0);}const _0x14cb66={..._0x870838};if(_0x594776==='mfaSmsEnrollment'||_0x594776==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x14cb66){const _0xb6b18a=_0x14cb66['phoneEnrollmentInfo']['phoneNumber'],_0x32c9ce=_0x14cb66['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x14cb66,{'phoneEnrollmentInfo':{'phoneNumber':_0xb6b18a,'recaptchaToken':_0x32c9ce,'captchaResponse':_0x113a23,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x14cb66){const _0x166340=_0x14cb66['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x14cb66,{'phoneSignInInfo':{'recaptchaToken':_0x166340,'captchaResponse':_0x113a23,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x14cb66;}return _0x2a7026?Object['assign'](_0x14cb66,{'captchaResp':_0x113a23}):Object['assign'](_0x14cb66,{'captchaResponse':_0x113a23}),Object['assign'](_0x14cb66,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x14cb66,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x14cb66;}async function Oi(_0x2bb979,_0x588281,_0x1df698,_0x1004c8,_0x19ae55){var _0x222ac1;if((_0x222ac1=_0x2bb979['_getRecaptchaConfig']())!=null&&_0x222ac1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x11c317=await br(_0x2bb979,_0x588281,_0x1df698,_0x1df698==='getOobCode');return _0x1004c8(_0x2bb979,_0x11c317);}else return _0x1004c8(_0x2bb979,_0x588281)['catch'](async _0x821388=>{if(_0x821388['code']==='auth/missing-recaptcha-token'){console['log'](_0x1df698+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x15b5a9=await br(_0x2bb979,_0x588281,_0x1df698,_0x1df698==='getOobCode');return _0x1004c8(_0x2bb979,_0x15b5a9);}else return Promise['reject'](_0x821388);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mf(_0x3ee264,_0x37a932){const _0x4dda87=Ui(_0x3ee264,'auth');if(_0x4dda87['isInitialized']()){const _0x3a9111=_0x4dda87['getImmediate'](),_0xe95e3e=_0x4dda87['getOptions']();if(De(_0xe95e3e,_0x37a932??{}))return _0x3a9111;K(_0x3a9111,'already-initialized');}return _0x4dda87['initialize']({'options':_0x37a932});}function Lf(_0x103327,_0x3b5de5){const _0x548046=(_0x3b5de5==null?void 0x0:_0x3b5de5['persistence'])||[],_0xf2391a=(Array['isArray'](_0x548046)?_0x548046:[_0x548046])['map'](ne);_0x3b5de5!=null&&_0x3b5de5['errorMap']&&_0x103327['_updateErrorMap'](_0x3b5de5['errorMap']),_0x103327['_initializeWithPersistence'](_0xf2391a,_0x3b5de5==null?void 0x0:_0x3b5de5['popupRedirectResolver']);}function xf(_0xcb670d,_0x1517bc,_0x12c112){const _0x2a5384=qe(_0xcb670d);m(/^https?:\/\//['test'](_0x1517bc),_0x2a5384,'invalid-emulator-scheme');const _0x77592c=!0x1,_0x325a5b=La(_0x1517bc),{host:_0x5727b7,port:_0x13ff16}=Ff(_0x1517bc),_0x5defc5=_0x13ff16===null?'':':'+_0x13ff16,_0x195aaa={'url':_0x325a5b+'//'+_0x5727b7+_0x5defc5+'/'},_0x5d6aa6=Object['freeze']({'host':_0x5727b7,'port':_0x13ff16,'protocol':_0x325a5b['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x77592c})});if(!_0x2a5384['_canInitEmulator']){m(_0x2a5384['config']['emulator']&&_0x2a5384['emulatorConfig'],_0x2a5384,'emulator-config-failed'),m(De(_0x195aaa,_0x2a5384['config']['emulator'])&&De(_0x5d6aa6,_0x2a5384['emulatorConfig']),_0x2a5384,'emulator-config-failed');return;}_0x2a5384['config']['emulator']=_0x195aaa,_0x2a5384['emulatorConfig']=_0x5d6aa6,_0x2a5384['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x5727b7)?jr(_0x325a5b+'//'+_0x5727b7+_0x5defc5):Uf();}function La(_0x1ea64a){const _0x4ef83c=_0x1ea64a['indexOf'](':');return _0x4ef83c<0x0?'':_0x1ea64a['substr'](0x0,_0x4ef83c+0x1);}function Ff(_0x12a5c6){const _0x274a8c=La(_0x12a5c6),_0x3f7cb3=/(\/\/)?([^?#/]+)/['exec'](_0x12a5c6['substr'](_0x274a8c['length']));if(!_0x3f7cb3)return{'host':'','port':null};const _0x2ba372=_0x3f7cb3[0x2]['split']('@')['pop']()||'',_0x343ac5=/^(\[[^\]]+\])(:|$)/['exec'](_0x2ba372);if(_0x343ac5){const _0x3c2b7a=_0x343ac5[0x1];return{'host':_0x3c2b7a,'port':Rr(_0x2ba372['substr'](_0x3c2b7a['length']+0x1))};}else{const [_0x43a305,_0x59ca19]=_0x2ba372['split'](':');return{'host':_0x43a305,'port':Rr(_0x59ca19)};}}function Rr(_0x3fa5fe){if(!_0x3fa5fe)return null;const _0x3208c7=Number(_0x3fa5fe);return isNaN(_0x3208c7)?null:_0x3208c7;}function Uf(){function _0x1ee26e(){const _0x531b11=document['createElement']('p'),_0xe8732=_0x531b11['style'];_0x531b11['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xe8732['position']='fixed',_0xe8732['width']='100%',_0xe8732['backgroundColor']='#ffffff',_0xe8732['border']='.1em\x20solid\x20#000000',_0xe8732['color']='#b50000',_0xe8732['bottom']='0px',_0xe8732['left']='0px',_0xe8732['margin']='0px',_0xe8732['zIndex']='10000',_0xe8732['textAlign']='center',_0x531b11['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x531b11);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1ee26e):_0x1ee26e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x2c7917,_0x2fdc0c){this['providerId']=_0x2c7917,this['signInMethod']=_0x2fdc0c;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x430642){return te('not\x20implemented');}['_linkToIdToken'](_0x18e65b,_0x3539b5){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x4b3c5e){return te('not\x20implemented');}}async function Wf(_0x29e6df,_0x2eb073){return Ae(_0x29e6df,'POST','/v1/accounts:signUp',_0x2eb073);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x1517a1,_0x444337){return Yt(_0x1517a1,'POST','/v1/accounts:signInWithPassword',Re(_0x1517a1,_0x444337));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vf(_0x3536f0,_0x5bb2c5){return Yt(_0x3536f0,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3536f0,_0x5bb2c5));}async function Hf(_0x1e1054,_0x5eb252){return Yt(_0x1e1054,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1e1054,_0x5eb252));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x43138b,_0x3b96a5,_0x302e62,_0x2852b2=null){super('password',_0x302e62),this['_email']=_0x43138b,this['_password']=_0x3b96a5,this['_tenantId']=_0x2852b2;}static['_fromEmailAndPassword'](_0x39703d,_0x2622d3){return new Ft(_0x39703d,_0x2622d3,'password');}static['_fromEmailAndCode'](_0x3b0a12,_0x229ff8,_0x39ccd6=null){return new Ft(_0x3b0a12,_0x229ff8,'emailLink',_0x39ccd6);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x44b650){const _0x3744d1=typeof _0x44b650=='string'?JSON['parse'](_0x44b650):_0x44b650;if(_0x3744d1!=null&&_0x3744d1['email']&&(_0x3744d1!=null&&_0x3744d1['password'])){if(_0x3744d1['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3744d1['email'],_0x3744d1['password']);if(_0x3744d1['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3744d1['email'],_0x3744d1['password'],_0x3744d1['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1d71ba){switch(this['signInMethod']){case'password':const _0x212fe6={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x1d71ba,_0x212fe6,'signInWithPassword',Bf);case'emailLink':return Vf(_0x1d71ba,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x1d71ba,'internal-error');}}async['_linkToIdToken'](_0x5a1dd5,_0x28bf2c){switch(this['signInMethod']){case'password':const _0x40dd7a={'idToken':_0x28bf2c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x5a1dd5,_0x40dd7a,'signUpPassword',Wf);case'emailLink':return Hf(_0x5a1dd5,{'idToken':_0x28bf2c,'email':this['_email'],'oobCode':this['_password']});default:K(_0x5a1dd5,'internal-error');}}['_getReauthenticationResolver'](_0x352656){return this['_getIdTokenResponse'](_0x352656);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x4a1d19,_0x42e174){return Yt(_0x4a1d19,'POST','/v1/accounts:signInWithIdp',Re(_0x4a1d19,_0x42e174));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $f='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x50b8ec){const _0xcc9bef=new We(_0x50b8ec['providerId'],_0x50b8ec['signInMethod']);return _0x50b8ec['idToken']||_0x50b8ec['accessToken']?(_0x50b8ec['idToken']&&(_0xcc9bef['idToken']=_0x50b8ec['idToken']),_0x50b8ec['accessToken']&&(_0xcc9bef['accessToken']=_0x50b8ec['accessToken']),_0x50b8ec['nonce']&&!_0x50b8ec['pendingToken']&&(_0xcc9bef['nonce']=_0x50b8ec['nonce']),_0x50b8ec['pendingToken']&&(_0xcc9bef['pendingToken']=_0x50b8ec['pendingToken'])):_0x50b8ec['oauthToken']&&_0x50b8ec['oauthTokenSecret']?(_0xcc9bef['accessToken']=_0x50b8ec['oauthToken'],_0xcc9bef['secret']=_0x50b8ec['oauthTokenSecret']):K('argument-error'),_0xcc9bef;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x48bf99){const _0x7490e4=typeof _0x48bf99=='string'?JSON['parse'](_0x48bf99):_0x48bf99,{providerId:_0x3df6de,signInMethod:_0x14bc3a,..._0x16270f}=_0x7490e4;if(!_0x3df6de||!_0x14bc3a)return null;const _0x38a19b=new We(_0x3df6de,_0x14bc3a);return _0x38a19b['idToken']=_0x16270f['idToken']||void 0x0,_0x38a19b['accessToken']=_0x16270f['accessToken']||void 0x0,_0x38a19b['secret']=_0x16270f['secret'],_0x38a19b['nonce']=_0x16270f['nonce'],_0x38a19b['pendingToken']=_0x16270f['pendingToken']||null,_0x38a19b;}['_getIdTokenResponse'](_0x5a00c0){const _0xdc1bac=this['buildRequest']();return Ze(_0x5a00c0,_0xdc1bac);}['_linkToIdToken'](_0x747472,_0x20e1b6){const _0x43da15=this['buildRequest']();return _0x43da15['idToken']=_0x20e1b6,Ze(_0x747472,_0x43da15);}['_getReauthenticationResolver'](_0x4f7786){const _0xdad218=this['buildRequest']();return _0xdad218['autoCreate']=!0x1,Ze(_0x4f7786,_0xdad218);}['buildRequest'](){const _0x1a203d={'requestUri':$f,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1a203d['pendingToken']=this['pendingToken'];else{const _0x3f3d9b={};this['idToken']&&(_0x3f3d9b['id_token']=this['idToken']),this['accessToken']&&(_0x3f3d9b['access_token']=this['accessToken']),this['secret']&&(_0x3f3d9b['oauth_token_secret']=this['secret']),_0x3f3d9b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3f3d9b['nonce']=this['nonce']),_0x1a203d['postBody']=at(_0x3f3d9b);}return _0x1a203d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gf(_0x4b1b5c){switch(_0x4b1b5c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function qf(_0x579962){const _0x11eb8d=yt(vt(_0x579962))['link'],_0x489554=_0x11eb8d?yt(vt(_0x11eb8d))['deep_link_id']:null,_0x54b6f2=yt(vt(_0x579962))['deep_link_id'];return(_0x54b6f2?yt(vt(_0x54b6f2))['link']:null)||_0x54b6f2||_0x489554||_0x11eb8d||_0x579962;}class Ss{constructor(_0x4753d0){const _0x502142=yt(vt(_0x4753d0)),_0x134019=_0x502142['apiKey']??null,_0x3f52f0=_0x502142['oobCode']??null,_0x51b059=Gf(_0x502142['mode']??null);m(_0x134019&&_0x3f52f0&&_0x51b059,'argument-error'),this['apiKey']=_0x134019,this['operation']=_0x51b059,this['code']=_0x3f52f0,this['continueUrl']=_0x502142['continueUrl']??null,this['languageCode']=_0x502142['lang']??null,this['tenantId']=_0x502142['tenantId']??null;}static['parseLink'](_0x9f4853){const _0x115251=qf(_0x9f4853);try{return new Ss(_0x115251);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x5124b9,_0x4e5df4){return Ft['_fromEmailAndPassword'](_0x5124b9,_0x4e5df4);}static['credentialWithLink'](_0x3c88d0,_0x533f50){const _0x3f18f9=Ss['parseLink'](_0x533f50);return m(_0x3f18f9,'argument-error'),Ft['_fromEmailAndCode'](_0x3c88d0,_0x3f18f9['code'],_0x3f18f9['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x21f30e){this['providerId']=_0x21f30e,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x18fb16){this['defaultLanguageCode']=_0x18fb16;}['setCustomParameters'](_0x3185f2){return this['customParameters']=_0x3185f2,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x13f272){return this['scopes']['includes'](_0x13f272)||this['scopes']['push'](_0x13f272),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x285a39){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x285a39});}static['credentialFromResult'](_0x579489){return he['credentialFromTaggedObject'](_0x579489);}static['credentialFromError'](_0x3fc448){return he['credentialFromTaggedObject'](_0x3fc448['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e3555}){if(!_0x5e3555||!('oauthAccessToken'in _0x5e3555)||!_0x5e3555['oauthAccessToken'])return null;try{return he['credential'](_0x5e3555['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x25c8b8,_0x5058e4){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x25c8b8,'accessToken':_0x5058e4});}static['credentialFromResult'](_0x3ef5c5){return ue['credentialFromTaggedObject'](_0x3ef5c5);}static['credentialFromError'](_0x2d43e3){return ue['credentialFromTaggedObject'](_0x2d43e3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xe571f}){if(!_0xe571f)return null;const {oauthIdToken:_0xa45ed8,oauthAccessToken:_0x7d0b5a}=_0xe571f;if(!_0xa45ed8&&!_0x7d0b5a)return null;try{return ue['credential'](_0xa45ed8,_0x7d0b5a);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x893e4f){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x893e4f});}static['credentialFromResult'](_0x52bc74){return de['credentialFromTaggedObject'](_0x52bc74);}static['credentialFromError'](_0x349e3d){return de['credentialFromTaggedObject'](_0x349e3d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x29bf4e}){if(!_0x29bf4e||!('oauthAccessToken'in _0x29bf4e)||!_0x29bf4e['oauthAccessToken'])return null;try{return de['credential'](_0x29bf4e['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x188fb4,_0x4d95af){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x188fb4,'oauthTokenSecret':_0x4d95af});}static['credentialFromResult'](_0x1139ef){return fe['credentialFromTaggedObject'](_0x1139ef);}static['credentialFromError'](_0x3a651f){return fe['credentialFromTaggedObject'](_0x3a651f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x15402}){if(!_0x15402)return null;const {oauthAccessToken:_0xd3f965,oauthTokenSecret:_0x41a9fb}=_0x15402;if(!_0xd3f965||!_0x41a9fb)return null;try{return fe['credential'](_0xd3f965,_0x41a9fb);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function zf(_0x39ec78,_0x342981){return Yt(_0x39ec78,'POST','/v1/accounts:signUp',Re(_0x39ec78,_0x342981));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5816bc){this['user']=_0x5816bc['user'],this['providerId']=_0x5816bc['providerId'],this['_tokenResponse']=_0x5816bc['_tokenResponse'],this['operationType']=_0x5816bc['operationType'];}static async['_fromIdTokenResponse'](_0x1fadc3,_0x3bc8fd,_0x1aec4e,_0x40c53d=!0x1){const _0x29ee3b=await z['_fromIdTokenResponse'](_0x1fadc3,_0x1aec4e,_0x40c53d),_0x25155e=Ar(_0x1aec4e);return new Be({'user':_0x29ee3b,'providerId':_0x25155e,'_tokenResponse':_0x1aec4e,'operationType':_0x3bc8fd});}static async['_forOperation'](_0x2fc97b,_0xa3fe55,_0x2569cc){await _0x2fc97b['_updateTokensIfNecessary'](_0x2569cc,!0x0);const _0x5d90bf=Ar(_0x2569cc);return new Be({'user':_0x2fc97b,'providerId':_0x5d90bf,'_tokenResponse':_0x2569cc,'operationType':_0xa3fe55});}}function Ar(_0x376cb4){return _0x376cb4['providerId']?_0x376cb4['providerId']:'phoneNumber'in _0x376cb4?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x185ae3,_0x2f67d2,_0x2a95ba,_0x3c92c8){super(_0x2f67d2['code'],_0x2f67d2['message']),this['operationType']=_0x2a95ba,this['user']=_0x3c92c8,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x185ae3['name'],'tenantId':_0x185ae3['tenantId']??void 0x0,'_serverResponse':_0x2f67d2['customData']['_serverResponse'],'operationType':_0x2a95ba};}static['_fromErrorAndOperation'](_0x10b6c8,_0x110541,_0x2dec42,_0x24ee40){return new Rn(_0x10b6c8,_0x110541,_0x2dec42,_0x24ee40);}}function Fa(_0x4d11a1,_0x4499f2,_0x286828,_0xc589b4){return(_0x4499f2==='reauthenticate'?_0x286828['_getReauthenticationResolver'](_0x4d11a1):_0x286828['_getIdTokenResponse'](_0x4d11a1))['catch'](_0x374aa0=>{throw _0x374aa0['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x4d11a1,_0x374aa0,_0x4499f2,_0xc589b4):_0x374aa0;});}async function jf(_0x514035,_0x40d2d2,_0x1c8828=!0x1){const _0x9c5f3a=await xt(_0x514035,_0x40d2d2['_linkToIdToken'](_0x514035['auth'],await _0x514035['getIdToken']()),_0x1c8828);return Be['_forOperation'](_0x514035,'link',_0x9c5f3a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2592c4,_0x490387,_0x20fc19=!0x1){const {auth:_0x23e816}=_0x2592c4;if(H(_0x23e816['app']))return Promise['reject'](se(_0x23e816));const _0x3df583='reauthenticate';try{const _0x46fc2f=await xt(_0x2592c4,Fa(_0x23e816,_0x3df583,_0x490387,_0x2592c4),_0x20fc19);m(_0x46fc2f['idToken'],_0x23e816,'internal-error');const _0x4c5720=ws(_0x46fc2f['idToken']);m(_0x4c5720,_0x23e816,'internal-error');const {sub:_0x55a61c}=_0x4c5720;return m(_0x2592c4['uid']===_0x55a61c,_0x23e816,'user-mismatch'),Be['_forOperation'](_0x2592c4,_0x3df583,_0x46fc2f);}catch(_0x45a23d){throw(_0x45a23d==null?void 0x0:_0x45a23d['code'])==='auth/user-not-found'&&K(_0x23e816,'user-mismatch'),_0x45a23d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x5b7b81,_0x149a13,_0x3ef1ab=!0x1){if(H(_0x5b7b81['app']))return Promise['reject'](se(_0x5b7b81));const _0x183d35='signIn',_0x427716=await Fa(_0x5b7b81,_0x183d35,_0x149a13),_0x50ed65=await Be['_fromIdTokenResponse'](_0x5b7b81,_0x183d35,_0x427716);return _0x3ef1ab||await _0x5b7b81['_updateCurrentUser'](_0x50ed65['user']),_0x50ed65;}async function Yf(_0x2c6b38,_0x5e84d1){return Ua(qe(_0x2c6b38),_0x5e84d1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x367088){const _0x2b9005=qe(_0x367088);_0x2b9005['_getPasswordPolicyInternal']()&&await _0x2b9005['_updatePasswordPolicy']();}async function R_(_0x278817,_0x5b7457,_0x354696){if(H(_0x278817['app']))return Promise['reject'](se(_0x278817));const _0x4d6ebc=qe(_0x278817),_0x161047=await Oi(_0x4d6ebc,{'returnSecureToken':!0x0,'email':_0x5b7457,'password':_0x354696,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',zf)['catch'](_0x440666=>{throw _0x440666['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x278817),_0x440666;}),_0x2365f7=await Be['_fromIdTokenResponse'](_0x4d6ebc,'signIn',_0x161047);return await _0x4d6ebc['_updateCurrentUser'](_0x2365f7['user']),_0x2365f7;}function A_(_0x482272,_0x3b1f38,_0x30432c){return H(_0x482272['app'])?Promise['reject'](se(_0x482272)):Yf(k(_0x482272),ft['credential'](_0x3b1f38,_0x30432c))['catch'](async _0x1374ac=>{throw _0x1374ac['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x482272),_0x1374ac;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k_(_0x43ffcd,_0xffb342){return k(_0x43ffcd)['setPersistence'](_0xffb342);}function Qf(_0x5f56db,_0x1b7c4d,_0x1665bd,_0x4d34ff){return k(_0x5f56db)['onIdTokenChanged'](_0x1b7c4d,_0x1665bd,_0x4d34ff);}function Jf(_0xbbd6ad,_0x1e69f3,_0x1de2c7){return k(_0xbbd6ad)['beforeAuthStateChanged'](_0x1e69f3,_0x1de2c7);}function N_(_0x4f520a,_0x10bff4,_0x49de80,_0x4c7000){return k(_0x4f520a)['onAuthStateChanged'](_0x10bff4,_0x49de80,_0x4c7000);}function P_(_0x4f94ba){return k(_0x4f94ba)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x7d7e66,_0x5e97ba){this['storageRetriever']=_0x7d7e66,this['type']=_0x5e97ba;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x247ea8,_0xf4700f){return this['storage']['setItem'](_0x247ea8,JSON['stringify'](_0xf4700f)),Promise['resolve']();}['_get'](_0x2101b8){const _0x774dcd=this['storage']['getItem'](_0x2101b8);return Promise['resolve'](_0x774dcd?JSON['parse'](_0x774dcd):null);}['_remove'](_0x38aed1){return this['storage']['removeItem'](_0x38aed1),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xf=0x3e8,Zf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x47cfac,_0x10dc9f)=>this['onStorageEvent'](_0x47cfac,_0x10dc9f),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x327113){for(const _0x303a21 of Object['keys'](this['listeners'])){const _0x111061=this['storage']['getItem'](_0x303a21),_0x36d265=this['localCache'][_0x303a21];_0x111061!==_0x36d265&&_0x327113(_0x303a21,_0x36d265,_0x111061);}}['onStorageEvent'](_0x219d1e,_0x437536=!0x1){if(!_0x219d1e['key']){this['forAllChangedKeys']((_0x3861ec,_0xe9246,_0x52015a)=>{this['notifyListeners'](_0x3861ec,_0x52015a);});return;}const _0x23e218=_0x219d1e['key'];_0x437536?this['detachListener']():this['stopPolling']();const _0x2b289d=()=>{const _0x348c04=this['storage']['getItem'](_0x23e218);!_0x437536&&this['localCache'][_0x23e218]===_0x348c04||this['notifyListeners'](_0x23e218,_0x348c04);},_0x287fe7=this['storage']['getItem'](_0x23e218);If()&&_0x287fe7!==_0x219d1e['newValue']&&_0x219d1e['newValue']!==_0x219d1e['oldValue']?setTimeout(_0x2b289d,Zf):_0x2b289d();}['notifyListeners'](_0x12ec3b,_0x3877be){this['localCache'][_0x12ec3b]=_0x3877be;const _0x27ba95=this['listeners'][_0x12ec3b];if(_0x27ba95){for(const _0x2788dd of Array['from'](_0x27ba95))_0x2788dd(_0x3877be&&JSON['parse'](_0x3877be));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x44cd41,_0x584130,_0x2783c5)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x44cd41,'oldValue':_0x584130,'newValue':_0x2783c5}),!0x0);});},Xf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3ad546,_0x382cb2){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3ad546]||(this['listeners'][_0x3ad546]=new Set(),this['localCache'][_0x3ad546]=this['storage']['getItem'](_0x3ad546)),this['listeners'][_0x3ad546]['add'](_0x382cb2);}['_removeListener'](_0x1e45d8,_0x2b51d8){this['listeners'][_0x1e45d8]&&(this['listeners'][_0x1e45d8]['delete'](_0x2b51d8),this['listeners'][_0x1e45d8]['size']===0x0&&delete this['listeners'][_0x1e45d8]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x39cb87,_0x24016b){await super['_set'](_0x39cb87,_0x24016b),this['localCache'][_0x39cb87]=JSON['stringify'](_0x24016b);}async['_get'](_0x29dbfe){const _0x5b4b9a=await super['_get'](_0x29dbfe);return this['localCache'][_0x29dbfe]=JSON['stringify'](_0x5b4b9a),_0x5b4b9a;}async['_remove'](_0x3f05e0){await super['_remove'](_0x3f05e0),delete this['localCache'][_0x3f05e0];}}Va['type']='LOCAL';const ep=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x23ed57,_0x31ed3a){}['_removeListener'](_0x5879c7,_0x2b7a08){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tp(_0x25502f){return Promise['all'](_0x25502f['map'](async _0x4edfab=>{try{return{'fulfilled':!0x0,'value':await _0x4edfab};}catch(_0x5d69b1){return{'fulfilled':!0x1,'reason':_0x5d69b1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x275323){this['eventTarget']=_0x275323,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4edd75){const _0x35ee46=this['receivers']['find'](_0x37a15e=>_0x37a15e['isListeningto'](_0x4edd75));if(_0x35ee46)return _0x35ee46;const _0x41bbcf=new jn(_0x4edd75);return this['receivers']['push'](_0x41bbcf),_0x41bbcf;}['isListeningto'](_0x31388a){return this['eventTarget']===_0x31388a;}async['handleEvent'](_0x3c859b){const _0x201341=_0x3c859b,{eventId:_0x1ad363,eventType:_0x4cae77,data:_0x183992}=_0x201341['data'],_0x197237=this['handlersMap'][_0x4cae77];if(!(_0x197237!=null&&_0x197237['size']))return;_0x201341['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1ad363,'eventType':_0x4cae77});const _0x2bb534=Array['from'](_0x197237)['map'](async _0x3ec14f=>_0x3ec14f(_0x201341['origin'],_0x183992)),_0x23f640=await tp(_0x2bb534);_0x201341['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1ad363,'eventType':_0x4cae77,'response':_0x23f640});}['_subscribe'](_0x5ab31a,_0x572b1e){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5ab31a]||(this['handlersMap'][_0x5ab31a]=new Set()),this['handlersMap'][_0x5ab31a]['add'](_0x572b1e);}['_unsubscribe'](_0x35b441,_0x22f981){this['handlersMap'][_0x35b441]&&_0x22f981&&this['handlersMap'][_0x35b441]['delete'](_0x22f981),(!_0x22f981||this['handlersMap'][_0x35b441]['size']===0x0)&&delete this['handlersMap'][_0x35b441],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x24f751='',_0x37f1f4=0xa){let _0x5777cd='';for(let _0x22fc82=0x0;_0x22fc82<_0x37f1f4;_0x22fc82++)_0x5777cd+=Math['floor'](Math['random']()*0xa);return _0x24f751+_0x5777cd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class np{constructor(_0x2b1750){this['target']=_0x2b1750,this['handlers']=new Set();}['removeMessageHandler'](_0x5d2df3){_0x5d2df3['messageChannel']&&(_0x5d2df3['messageChannel']['port1']['removeEventListener']('message',_0x5d2df3['onMessage']),_0x5d2df3['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5d2df3);}async['_send'](_0x264b31,_0xc29567,_0x3c4697=0x32){const _0x432545=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x432545)throw new Error('connection_unavailable');let _0x448e44,_0x3a5289;return new Promise((_0x16fbd6,_0x5216eb)=>{const _0x2a4305=bs('',0x14);_0x432545['port1']['start']();const _0x1de2be=setTimeout(()=>{_0x5216eb(new Error('unsupported_event'));},_0x3c4697);_0x3a5289={'messageChannel':_0x432545,'onMessage'(_0x288f18){const _0x11a3e3=_0x288f18;if(_0x11a3e3['data']['eventId']===_0x2a4305)switch(_0x11a3e3['data']['status']){case'ack':clearTimeout(_0x1de2be),_0x448e44=setTimeout(()=>{_0x5216eb(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x448e44),_0x16fbd6(_0x11a3e3['data']['response']);break;default:clearTimeout(_0x1de2be),clearTimeout(_0x448e44),_0x5216eb(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3a5289),_0x432545['port1']['addEventListener']('message',_0x3a5289['onMessage']),this['target']['postMessage']({'eventType':_0x264b31,'eventId':_0x2a4305,'data':_0xc29567},[_0x432545['port2']]);})['finally'](()=>{_0x3a5289&&this['removeMessageHandler'](_0x3a5289);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function ip(_0xc91606){X()['location']['href']=_0xc91606;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function sp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function rp(){var _0xa2c5b5;return((_0xa2c5b5=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0xa2c5b5['controller'])||null;}function op(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',ap=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x23a61f){this['request']=_0x23a61f;}['toPromise'](){return new Promise((_0x24f780,_0x4d5923)=>{this['request']['addEventListener']('success',()=>{_0x24f780(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x4d5923(this['request']['error']);});});}}function Kn(_0x30adc8,_0x26d38a){return _0x30adc8['transaction']([kn],_0x26d38a?'readwrite':'readonly')['objectStore'](kn);}function cp(){const _0x3c9c3e=indexedDB['deleteDatabase'](qa);return new Jt(_0x3c9c3e)['toPromise']();}function ja(){const _0xf29b55=indexedDB['open'](qa,ap);return new Promise((_0x3d3f3a,_0x29fb31)=>{_0xf29b55['addEventListener']('error',()=>{_0x29fb31(_0xf29b55['error']);}),_0xf29b55['addEventListener']('upgradeneeded',()=>{const _0x487488=_0xf29b55['result'];try{_0x487488['createObjectStore'](kn,{'keyPath':za});}catch(_0x3bf4f5){_0x29fb31(_0x3bf4f5);}}),_0xf29b55['addEventListener']('success',async()=>{const _0x5c8025=_0xf29b55['result'];_0x5c8025['objectStoreNames']['contains'](kn)?_0x3d3f3a(_0x5c8025):(_0x5c8025['close'](),await cp(),_0x3d3f3a(await ja()));});});}async function kr(_0x3b39c8,_0x479c60,_0x505fab){const _0x6e02f5=Kn(_0x3b39c8,!0x0)['put']({[za]:_0x479c60,'value':_0x505fab});return new Jt(_0x6e02f5)['toPromise']();}async function lp(_0x3ac2a8,_0x20d497){const _0x1c4041=Kn(_0x3ac2a8,!0x1)['get'](_0x20d497),_0x5042db=await new Jt(_0x1c4041)['toPromise']();return _0x5042db===void 0x0?null:_0x5042db['value'];}function Nr(_0x24aa51,_0x5bb78d){const _0x5b3cd8=Kn(_0x24aa51,!0x0)['delete'](_0x5bb78d);return new Jt(_0x5b3cd8)['toPromise']();}const hp=0x320,up=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x584174){let _0x54bbab=0x0;for(;;)try{const _0x23396f=await this['_openDb']();return await _0x584174(_0x23396f);}catch(_0x5943c5){if(_0x54bbab++>up)throw _0x5943c5;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](op()),this['receiver']['_subscribe']('keyChanged',async(_0x5aec89,_0x41e1f3)=>({'keyProcessed':(await this['_poll']())['includes'](_0x41e1f3['key'])})),this['receiver']['_subscribe']('ping',async(_0x53e7fb,_0x35f94a)=>['keyChanged']);}async['initializeSender'](){var _0x20f3f8,_0x2e75dd;if(this['activeServiceWorker']=await sp(),!this['activeServiceWorker'])return;this['sender']=new np(this['activeServiceWorker']);const _0x144e36=await this['sender']['_send']('ping',{},0x320);_0x144e36&&(_0x20f3f8=_0x144e36[0x0])!=null&&_0x20f3f8['fulfilled']&&(_0x2e75dd=_0x144e36[0x0])!=null&&_0x2e75dd['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5035c3){if(!(!this['sender']||!this['activeServiceWorker']||rp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5035c3},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3029cc=>{await kr(_0x3029cc,An,'1'),await Nr(_0x3029cc,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x91fac0){this['pendingWrites']++;try{await _0x91fac0();}finally{this['pendingWrites']--;}}async['_set'](_0x389751,_0x277c4d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x59b26b=>kr(_0x59b26b,_0x389751,_0x277c4d)),this['localCache'][_0x389751]=_0x277c4d,this['notifyServiceWorker'](_0x389751)));}async['_get'](_0x3d2107){const _0xcb6ebd=await this['_withRetries'](_0x198230=>lp(_0x198230,_0x3d2107));return this['localCache'][_0x3d2107]=_0xcb6ebd,_0xcb6ebd;}async['_remove'](_0x2a36c0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3c42b5=>Nr(_0x3c42b5,_0x2a36c0)),delete this['localCache'][_0x2a36c0],this['notifyServiceWorker'](_0x2a36c0)));}async['_poll'](){const _0x4a079c=await this['_withRetries'](_0x173d6b=>{const _0x837581=Kn(_0x173d6b,!0x1)['getAll']();return new Jt(_0x837581)['toPromise']();});if(!_0x4a079c)return[];if(this['pendingWrites']!==0x0)return[];const _0x3d2d68=[],_0x556eca=new Set();if(_0x4a079c['length']!==0x0){for(const {fbase_key:_0x3c93d2,value:_0x1eefd5}of _0x4a079c)_0x556eca['add'](_0x3c93d2),JSON['stringify'](this['localCache'][_0x3c93d2])!==JSON['stringify'](_0x1eefd5)&&(this['notifyListeners'](_0x3c93d2,_0x1eefd5),_0x3d2d68['push'](_0x3c93d2));}for(const _0x4110ee of Object['keys'](this['localCache']))this['localCache'][_0x4110ee]&&!_0x556eca['has'](_0x4110ee)&&(this['notifyListeners'](_0x4110ee,null),_0x3d2d68['push'](_0x4110ee));return _0x3d2d68;}['notifyListeners'](_0x4373ce,_0x366307){this['localCache'][_0x4373ce]=_0x366307;const _0x32e138=this['listeners'][_0x4373ce];if(_0x32e138){for(const _0x3b97a4 of Array['from'](_0x32e138))_0x3b97a4(_0x366307);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),hp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x17637b,_0x577b7d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x17637b]||(this['listeners'][_0x17637b]=new Set(),this['_get'](_0x17637b)),this['listeners'][_0x17637b]['add'](_0x577b7d);}['_removeListener'](_0x197f4e,_0x3f394e){this['listeners'][_0x197f4e]&&(this['listeners'][_0x197f4e]['delete'](_0x3f394e),this['listeners'][_0x197f4e]['size']===0x0&&delete this['listeners'][_0x197f4e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const dp=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function fp(_0x57fcf4,_0xddbd40){return _0xddbd40?ne(_0xddbd40):(m(_0x57fcf4['_popupRedirectResolver'],_0x57fcf4,'argument-error'),_0x57fcf4['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x961f75){super('custom','custom'),this['params']=_0x961f75;}['_getIdTokenResponse'](_0xcadad0){return Ze(_0xcadad0,this['_buildIdpRequest']());}['_linkToIdToken'](_0x49e1ae,_0x4604b0){return Ze(_0x49e1ae,this['_buildIdpRequest'](_0x4604b0));}['_getReauthenticationResolver'](_0x2b5903){return Ze(_0x2b5903,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x37dade){const _0x596f57={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x37dade&&(_0x596f57['idToken']=_0x37dade),_0x596f57;}}function pp(_0x3dd66b){return Ua(_0x3dd66b['auth'],new Rs(_0x3dd66b),_0x3dd66b['bypassAuthState']);}function _p(_0x562015){const {auth:_0x4414e0,user:_0x1c3d90}=_0x562015;return m(_0x1c3d90,_0x4414e0,'internal-error'),Kf(_0x1c3d90,new Rs(_0x562015),_0x562015['bypassAuthState']);}async function gp(_0x426c8c){const {auth:_0x204a6d,user:_0x141020}=_0x426c8c;return m(_0x141020,_0x204a6d,'internal-error'),jf(_0x141020,new Rs(_0x426c8c),_0x426c8c['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x2f3473,_0x242284,_0x4e234f,_0x57bab6,_0x4fb890=!0x1){this['auth']=_0x2f3473,this['resolver']=_0x4e234f,this['user']=_0x57bab6,this['bypassAuthState']=_0x4fb890,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x242284)?_0x242284:[_0x242284];}['execute'](){return new Promise(async(_0x4d5110,_0x190164)=>{this['pendingPromise']={'resolve':_0x4d5110,'reject':_0x190164};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4622f8){this['reject'](_0x4622f8);}});}async['onAuthEvent'](_0x199517){const {urlResponse:_0x5483a8,sessionId:_0x22b776,postBody:_0x199b2e,tenantId:_0x201985,error:_0x4162e0,type:_0x4e2d0f}=_0x199517;if(_0x4162e0){this['reject'](_0x4162e0);return;}const _0x2307a7={'auth':this['auth'],'requestUri':_0x5483a8,'sessionId':_0x22b776,'tenantId':_0x201985||void 0x0,'postBody':_0x199b2e||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4e2d0f)(_0x2307a7));}catch(_0x2299d2){this['reject'](_0x2299d2);}}['onError'](_0x24a94c){this['reject'](_0x24a94c);}['getIdpTask'](_0x2152e1){switch(_0x2152e1){case'signInViaPopup':case'signInViaRedirect':return pp;case'linkViaPopup':case'linkViaRedirect':return gp;case'reauthViaPopup':case'reauthViaRedirect':return _p;default:K(this['auth'],'internal-error');}}['resolve'](_0x260b5a){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x260b5a),this['unregisterAndCleanUp']();}['reject'](_0x4762c6){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x4762c6),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x24bc6d,_0x9254d8,_0x1c25fa,_0x5081f9,_0x4c0d0a){super(_0x24bc6d,_0x9254d8,_0x5081f9,_0x4c0d0a),this['provider']=_0x1c25fa,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0xcf128f=await this['execute']();return m(_0xcf128f,this['auth'],'internal-error'),_0xcf128f;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x36d314=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x36d314),this['authWindow']['associatedEvent']=_0x36d314,this['resolver']['_originValidation'](this['auth'])['catch'](_0x78f114=>{this['reject'](_0x78f114);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1bded8=>{_0x1bded8||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x569720;return((_0x569720=this['authWindow'])==null?void 0x0:_0x569720['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x15ee15=()=>{var _0x10b797,_0x38652c;if((_0x38652c=(_0x10b797=this['authWindow'])==null?void 0x0:_0x10b797['window'])!=null&&_0x38652c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x15ee15,mp['get']());};_0x15ee15();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yp='pendingRedirect',rn=new Map();class vp extends Ya{constructor(_0x5d5438,_0x252d7f,_0x35b195=!0x1){super(_0x5d5438,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x252d7f,void 0x0,_0x35b195),this['eventId']=null;}async['execute'](){let _0x21531a=rn['get'](this['auth']['_key']());if(!_0x21531a){try{const _0x1778c6=await Ep(this['resolver'],this['auth'])?await super['execute']():null;_0x21531a=()=>Promise['resolve'](_0x1778c6);}catch(_0x280c4c){_0x21531a=()=>Promise['reject'](_0x280c4c);}rn['set'](this['auth']['_key'](),_0x21531a);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x21531a();}async['onAuthEvent'](_0x1ace05){if(_0x1ace05['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1ace05);if(_0x1ace05['type']==='unknown'){this['resolve'](null);return;}if(_0x1ace05['eventId']){const _0x5b4802=await this['auth']['_redirectUserForId'](_0x1ace05['eventId']);if(_0x5b4802)return this['user']=_0x5b4802,super['onAuthEvent'](_0x1ace05);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Ep(_0xdfffb2,_0x2699b3){const _0x3614be=Cp(_0x2699b3),_0x3cf141=wp(_0xdfffb2);if(!await _0x3cf141['_isAvailable']())return!0x1;const _0x1e5a3d=await _0x3cf141['_get'](_0x3614be)==='true';return await _0x3cf141['_remove'](_0x3614be),_0x1e5a3d;}function Ip(_0x7e2510,_0x461146){rn['set'](_0x7e2510['_key'](),_0x461146);}function wp(_0x253721){return ne(_0x253721['_redirectPersistence']);}function Cp(_0x19265f){return sn(yp,_0x19265f['config']['apiKey'],_0x19265f['name']);}async function Tp(_0x53c67e,_0x4de3bb,_0x5a4c6a=!0x1){if(H(_0x53c67e['app']))return Promise['reject'](se(_0x53c67e));const _0x3f7f9f=qe(_0x53c67e),_0x4bb581=fp(_0x3f7f9f,_0x4de3bb),_0x43bc64=await new vp(_0x3f7f9f,_0x4bb581,_0x5a4c6a)['execute']();return _0x43bc64&&!_0x5a4c6a&&(delete _0x43bc64['user']['_redirectEventId'],await _0x3f7f9f['_persistUserIfCurrent'](_0x43bc64['user']),await _0x3f7f9f['_setRedirectUser'](null,_0x4de3bb)),_0x43bc64;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp=0x258*0x3e8;class bp{constructor(_0x4a272e){this['auth']=_0x4a272e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x485392){this['consumers']['add'](_0x485392),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x485392)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x485392),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x20b0d8){this['consumers']['delete'](_0x20b0d8);}['onEvent'](_0x30025c){if(this['hasEventBeenHandled'](_0x30025c))return!0x1;let _0x3f195a=!0x1;return this['consumers']['forEach'](_0x2741b=>{this['isEventForConsumer'](_0x30025c,_0x2741b)&&(_0x3f195a=!0x0,this['sendToConsumer'](_0x30025c,_0x2741b),this['saveEventToCache'](_0x30025c));}),this['hasHandledPotentialRedirect']||!Rp(_0x30025c)||(this['hasHandledPotentialRedirect']=!0x0,_0x3f195a||(this['queuedRedirectEvent']=_0x30025c,_0x3f195a=!0x0)),_0x3f195a;}['sendToConsumer'](_0x2aef3d,_0x1c7ca2){var _0x4f3137;if(_0x2aef3d['error']&&!Qa(_0x2aef3d)){const _0x20634b=((_0x4f3137=_0x2aef3d['error']['code'])==null?void 0x0:_0x4f3137['split']('auth/')[0x1])||'internal-error';_0x1c7ca2['onError'](J(this['auth'],_0x20634b));}else _0x1c7ca2['onAuthEvent'](_0x2aef3d);}['isEventForConsumer'](_0x1bf3db,_0x2887ee){const _0x127800=_0x2887ee['eventId']===null||!!_0x1bf3db['eventId']&&_0x1bf3db['eventId']===_0x2887ee['eventId'];return _0x2887ee['filter']['includes'](_0x1bf3db['type'])&&_0x127800;}['hasEventBeenHandled'](_0x4844e1){return Date['now']()-this['lastProcessedEventTime']>=Sp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x4844e1));}['saveEventToCache'](_0x4fcab6){this['cachedEventUids']['add'](Pr(_0x4fcab6)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x122965){return[_0x122965['type'],_0x122965['eventId'],_0x122965['sessionId'],_0x122965['tenantId']]['filter'](_0x307c22=>_0x307c22)['join']('-');}function Qa({type:_0x17fe92,error:_0x574237}){return _0x17fe92==='unknown'&&(_0x574237==null?void 0x0:_0x574237['code'])==='auth/no-auth-event';}function Rp(_0x311a0b){switch(_0x311a0b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x311a0b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ap(_0x5748b1,_0x3495c9={}){return Ae(_0x5748b1,'GET','/v1/projects',_0x3495c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Np=/^https?/;async function Pp(_0x2e807b){if(_0x2e807b['config']['emulator'])return;const {authorizedDomains:_0x272528}=await Ap(_0x2e807b);for(const _0xd25548 of _0x272528)try{if(Op(_0xd25548))return;}catch{}K(_0x2e807b,'unauthorized-domain');}function Op(_0x1719b7){const _0x125f0e=Ni(),{protocol:_0x36a283,hostname:_0x2e6d9b}=new URL(_0x125f0e);if(_0x1719b7['startsWith']('chrome-extension://')){const _0x1e276e=new URL(_0x1719b7);return _0x1e276e['hostname']===''&&_0x2e6d9b===''?_0x36a283==='chrome-extension:'&&_0x1719b7['replace']('chrome-extension://','')===_0x125f0e['replace']('chrome-extension://',''):_0x36a283==='chrome-extension:'&&_0x1e276e['hostname']===_0x2e6d9b;}if(!Np['test'](_0x36a283))return!0x1;if(kp['test'](_0x1719b7))return _0x2e6d9b===_0x1719b7;const _0x5315cb=_0x1719b7['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5315cb+'|'+_0x5315cb+')$','i')['test'](_0x2e6d9b);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=new Kt(0x7530,0xea60);function Or(){const _0x5006ec=X()['___jsl'];if(_0x5006ec!=null&&_0x5006ec['H']){for(const _0x440d8c of Object['keys'](_0x5006ec['H']))if(_0x5006ec['H'][_0x440d8c]['r']=_0x5006ec['H'][_0x440d8c]['r']||[],_0x5006ec['H'][_0x440d8c]['L']=_0x5006ec['H'][_0x440d8c]['L']||[],_0x5006ec['H'][_0x440d8c]['r']=[..._0x5006ec['H'][_0x440d8c]['L']],_0x5006ec['CP']){for(let _0xfa4563=0x0;_0xfa4563<_0x5006ec['CP']['length'];_0xfa4563++)_0x5006ec['CP'][_0xfa4563]=null;}}}function Mp(_0x27a7e6){return new Promise((_0x5a2ed3,_0x466d60)=>{var _0x554ebc,_0x23d32b,_0xd399b1;function _0x50676b(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5a2ed3(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x466d60(J(_0x27a7e6,'network-request-failed'));},'timeout':Dp['get']()});}if((_0x23d32b=(_0x554ebc=X()['gapi'])==null?void 0x0:_0x554ebc['iframes'])!=null&&_0x23d32b['Iframe'])_0x5a2ed3(gapi['iframes']['getContext']());else{if((_0xd399b1=X()['gapi'])!=null&&_0xd399b1['load'])_0x50676b();else{const _0x562781=Nf('iframefcb');return X()[_0x562781]=()=>{gapi['load']?_0x50676b():_0x466d60(J(_0x27a7e6,'network-request-failed'));},Da(kf()+'?onload='+_0x562781)['catch'](_0x246043=>_0x466d60(_0x246043));}}})['catch'](_0x377dc6=>{throw on=null,_0x377dc6;});}let on=null;function Lp(_0x15741c){return on=on||Mp(_0x15741c),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=new Kt(0x1388,0x3a98),Fp='__/auth/iframe',Up='emulator/auth/iframe',Wp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Bp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Vp(_0x2552f6){const _0x39c4fc=_0x2552f6['config'];m(_0x39c4fc['authDomain'],_0x2552f6,'auth-domain-config-required');const _0x197daa=_0x39c4fc['emulator']?Is(_0x39c4fc,Up):'https://'+_0x2552f6['config']['authDomain']+'/'+Fp,_0x375a6d={'apiKey':_0x39c4fc['apiKey'],'appName':_0x2552f6['name'],'v':ct},_0x35f242=Bp['get'](_0x2552f6['config']['apiHost']);_0x35f242&&(_0x375a6d['eid']=_0x35f242);const _0xc9f9c7=_0x2552f6['_getFrameworks']();return _0xc9f9c7['length']&&(_0x375a6d['fw']=_0xc9f9c7['join'](',')),_0x197daa+'?'+at(_0x375a6d)['slice'](0x1);}async function Hp(_0x369919){const _0x30e8ba=await Lp(_0x369919),_0x3e2217=X()['gapi'];return m(_0x3e2217,_0x369919,'internal-error'),_0x30e8ba['open']({'where':document['body'],'url':Vp(_0x369919),'messageHandlersFilter':_0x3e2217['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Wp,'dontclear':!0x0},_0x7295d=>new Promise(async(_0xe29727,_0x2d8abd)=>{await _0x7295d['restyle']({'setHideOnLeave':!0x1});const _0x4e08c2=J(_0x369919,'network-request-failed'),_0x2294ef=X()['setTimeout'](()=>{_0x2d8abd(_0x4e08c2);},xp['get']());function _0x31422c(){X()['clearTimeout'](_0x2294ef),_0xe29727(_0x7295d);}_0x7295d['ping'](_0x31422c)['then'](_0x31422c,()=>{_0x2d8abd(_0x4e08c2);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Gp=0x1f4,qp=0x258,zp='_blank',jp='http://localhost';class Dr{constructor(_0x2021b7){this['window']=_0x2021b7,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Kp(_0x122d97,_0x39c3ab,_0x5cb28d,_0x2fed7f=Gp,_0x51e5e8=qp){const _0x10bf15=Math['max']((window['screen']['availHeight']-_0x51e5e8)/0x2,0x0)['toString'](),_0x1033cf=Math['max']((window['screen']['availWidth']-_0x2fed7f)/0x2,0x0)['toString']();let _0x921c1='';const _0x291c72={...$p,'width':_0x2fed7f['toString'](),'height':_0x51e5e8['toString'](),'top':_0x10bf15,'left':_0x1033cf},_0x565dc4=W()['toLowerCase']();_0x5cb28d&&(_0x921c1=ba(_0x565dc4)?zp:_0x5cb28d),Ta(_0x565dc4)&&(_0x39c3ab=_0x39c3ab||jp,_0x291c72['scrollbars']='yes');const _0x2b716b=Object['entries'](_0x291c72)['reduce']((_0x3f878f,[_0x358619,_0x21a891])=>''+_0x3f878f+_0x358619+'='+_0x21a891+',','');if(Ef(_0x565dc4)&&_0x921c1!=='_self')return Yp(_0x39c3ab||'',_0x921c1),new Dr(null);const _0x1c45ec=window['open'](_0x39c3ab||'',_0x921c1,_0x2b716b);m(_0x1c45ec,_0x122d97,'popup-blocked');try{_0x1c45ec['focus']();}catch{}return new Dr(_0x1c45ec);}function Yp(_0x25ab43,_0xf00974){const _0x1606b2=document['createElement']('a');_0x1606b2['href']=_0x25ab43,_0x1606b2['target']=_0xf00974;const _0x1f929b=document['createEvent']('MouseEvent');_0x1f929b['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1606b2['dispatchEvent'](_0x1f929b);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp='__/auth/handler',Jp='emulator/auth/handler',Xp=encodeURIComponent('fac');async function Mr(_0x565821,_0x267b4a,_0x354521,_0x308583,_0xb89177,_0x80f1e2){m(_0x565821['config']['authDomain'],_0x565821,'auth-domain-config-required'),m(_0x565821['config']['apiKey'],_0x565821,'invalid-api-key');const _0x4261c1={'apiKey':_0x565821['config']['apiKey'],'appName':_0x565821['name'],'authType':_0x354521,'redirectUrl':_0x308583,'v':ct,'eventId':_0xb89177};if(_0x267b4a instanceof xa){_0x267b4a['setDefaultLanguage'](_0x565821['languageCode']),_0x4261c1['providerId']=_0x267b4a['providerId']||'',hi(_0x267b4a['getCustomParameters']())||(_0x4261c1['customParameters']=JSON['stringify'](_0x267b4a['getCustomParameters']()));for(const [_0x1519da,_0x42ef0c]of Object['entries']({}))_0x4261c1[_0x1519da]=_0x42ef0c;}if(_0x267b4a instanceof Qt){const _0x399358=_0x267b4a['getScopes']()['filter'](_0x3af455=>_0x3af455!=='');_0x399358['length']>0x0&&(_0x4261c1['scopes']=_0x399358['join'](','));}_0x565821['tenantId']&&(_0x4261c1['tid']=_0x565821['tenantId']);const _0x1fdc38=_0x4261c1;for(const _0x45b7d2 of Object['keys'](_0x1fdc38))_0x1fdc38[_0x45b7d2]===void 0x0&&delete _0x1fdc38[_0x45b7d2];const _0x12e958=await _0x565821['_getAppCheckToken'](),_0x5af960=_0x12e958?'#'+Xp+'='+encodeURIComponent(_0x12e958):'';return Zp(_0x565821)+'?'+at(_0x1fdc38)['slice'](0x1)+_0x5af960;}function Zp({config:_0xef03f1}){return _0xef03f1['emulator']?Is(_0xef03f1,Jp):'https://'+_0xef03f1['authDomain']+'/'+Qp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class e_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Tp,this['_overrideRedirectResult']=Ip;}async['_openPopup'](_0x5eb3ed,_0x5ecb33,_0x29e894,_0x226d67){var _0x52c1e1;ae((_0x52c1e1=this['eventManagers'][_0x5eb3ed['_key']()])==null?void 0x0:_0x52c1e1['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x32c065=await Mr(_0x5eb3ed,_0x5ecb33,_0x29e894,Ni(),_0x226d67);return Kp(_0x5eb3ed,_0x32c065,bs());}async['_openRedirect'](_0x43562d,_0x58438a,_0x55f4e0,_0x331f7f){await this['_originValidation'](_0x43562d);const _0x78cc4d=await Mr(_0x43562d,_0x58438a,_0x55f4e0,Ni(),_0x331f7f);return ip(_0x78cc4d),new Promise(()=>{});}['_initialize'](_0x45d5e1){const _0x1c8800=_0x45d5e1['_key']();if(this['eventManagers'][_0x1c8800]){const {manager:_0x153e13,promise:_0x4c7419}=this['eventManagers'][_0x1c8800];return _0x153e13?Promise['resolve'](_0x153e13):(ae(_0x4c7419,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4c7419);}const _0x46a1ed=this['initAndGetManager'](_0x45d5e1);return this['eventManagers'][_0x1c8800]={'promise':_0x46a1ed},_0x46a1ed['catch'](()=>{delete this['eventManagers'][_0x1c8800];}),_0x46a1ed;}async['initAndGetManager'](_0x237089){const _0x15c560=await Hp(_0x237089),_0x422e59=new bp(_0x237089);return _0x15c560['register']('authEvent',_0xa2dc3c=>(m(_0xa2dc3c==null?void 0x0:_0xa2dc3c['authEvent'],_0x237089,'invalid-auth-event'),{'status':_0x422e59['onEvent'](_0xa2dc3c['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x237089['_key']()]={'manager':_0x422e59},this['iframes'][_0x237089['_key']()]=_0x15c560,_0x422e59;}['_isIframeWebStorageSupported'](_0x24d280,_0x57a9a8){this['iframes'][_0x24d280['_key']()]['send'](li,{'type':li},_0x352ce5=>{var _0x533a19;const _0x4e4ebf=(_0x533a19=_0x352ce5==null?void 0x0:_0x352ce5[0x0])==null?void 0x0:_0x533a19[li];_0x4e4ebf!==void 0x0&&_0x57a9a8(!!_0x4e4ebf),K(_0x24d280,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x30b6d4){const _0x2e7258=_0x30b6d4['_key']();return this['originValidationPromises'][_0x2e7258]||(this['originValidationPromises'][_0x2e7258]=Pp(_0x30b6d4)),this['originValidationPromises'][_0x2e7258];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const t_=e_;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class n_{constructor(_0x6b5030){this['auth']=_0x6b5030,this['internalListeners']=new Map();}['getUid'](){var _0x4f7dbc;return this['assertAuthConfigured'](),((_0x4f7dbc=this['auth']['currentUser'])==null?void 0x0:_0x4f7dbc['uid'])||null;}async['getToken'](_0x5ab0dd){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5ab0dd)}:null;}['addAuthTokenListener'](_0x3e620a){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3e620a))return;const _0x265d3c=this['auth']['onIdTokenChanged'](_0x281f9e=>{_0x3e620a((_0x281f9e==null?void 0x0:_0x281f9e['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3e620a,_0x265d3c),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4d0234){this['assertAuthConfigured']();const _0x26863f=this['internalListeners']['get'](_0x4d0234);_0x26863f&&(this['internalListeners']['delete'](_0x4d0234),_0x26863f(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function i_(_0x5838c6){switch(_0x5838c6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function s_(_0x1544da){et(new Me('auth',(_0x36c152,{options:_0x514c0a})=>{const _0x358909=_0x36c152['getProvider']('app')['getImmediate'](),_0x1e9c90=_0x36c152['getProvider']('heartbeat'),_0x55d867=_0x36c152['getProvider']('app-check-internal'),{apiKey:_0x36853c,authDomain:_0x4c8a61}=_0x358909['options'];m(_0x36853c&&!_0x36853c['includes'](':'),'invalid-api-key',{'appName':_0x358909['name']});const _0x409ab4={'apiKey':_0x36853c,'authDomain':_0x4c8a61,'clientPlatform':_0x1544da,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x1544da)},_0x38c9aa=new bf(_0x358909,_0x1e9c90,_0x55d867,_0x409ab4);return Lf(_0x38c9aa,_0x514c0a),_0x38c9aa;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x37bd90,_0x4db0a3,_0x3fc338)=>{_0x37bd90['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x1d1c03=>{const _0x56c8cf=qe(_0x1d1c03['getProvider']('auth')['getImmediate']());return(_0x308ab9=>new n_(_0x308ab9))(_0x56c8cf);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,i_(_0x1544da)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const r_=0x12c,o_=Gr('authIdTokenMaxAge')||r_;let Fr=null;const a_=_0x2acf20=>async _0xeccfdb=>{const _0x8c11ca=_0xeccfdb&&await _0xeccfdb['getIdTokenResult'](),_0x228cfd=_0x8c11ca&&(new Date()['getTime']()-Date['parse'](_0x8c11ca['issuedAtTime']))/0x3e8;if(_0x228cfd&&_0x228cfd>o_)return;const _0x19f08d=_0x8c11ca==null?void 0x0:_0x8c11ca['token'];Fr!==_0x19f08d&&(Fr=_0x19f08d,await fetch(_0x2acf20,{'method':_0x19f08d?'POST':'DELETE','headers':_0x19f08d?{'Authorization':'Bearer\x20'+_0x19f08d}:{}}));};function O_(_0x1436c3=Qr()){const _0x34a6e6=Ui(_0x1436c3,'auth');if(_0x34a6e6['isInitialized']())return _0x34a6e6['getImmediate']();const _0x12a5da=Mf(_0x1436c3,{'popupRedirectResolver':t_,'persistence':[dp,ep,$a]}),_0x2bbb07=Gr('authTokenSyncURL');if(_0x2bbb07&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2a0097=new URL(_0x2bbb07,location['origin']);if(location['origin']===_0x2a0097['origin']){const _0x4513f2=a_(_0x2a0097['toString']());Jf(_0x12a5da,_0x4513f2,()=>_0x4513f2(_0x12a5da['currentUser'])),Qf(_0x12a5da,_0x52e03d=>_0x4513f2(_0x52e03d));}}const _0x450970=Hr('auth');return _0x450970&&xf(_0x12a5da,'http://'+_0x450970),_0x12a5da;}function c_(){var _0x17e615;return((_0x17e615=document['getElementsByTagName']('head'))==null?void 0x0:_0x17e615[0x0])??document;}Rf({'loadJS'(_0x49a6e3){return new Promise((_0x446e08,_0x5c3234)=>{const _0x359d8e=document['createElement']('script');_0x359d8e['setAttribute']('src',_0x49a6e3),_0x359d8e['onload']=_0x446e08,_0x359d8e['onerror']=_0x168d13=>{const _0x40bc01=J('internal-error');_0x40bc01['customData']=_0x168d13,_0x5c3234(_0x40bc01);},_0x359d8e['type']='text/javascript',_0x359d8e['charset']='UTF-8',c_()['appendChild'](_0x359d8e);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),s_('Browser');export{R_ as A,P_ as B,v_ as C,O_ as a,ep as b,A_ as c,l_ as d,h_ as e,Qr as f,w_ as g,p_ as h,wl as i,S_ as j,E_ as k,Lt as l,Ld as m,N_ as n,y_ as o,d_ as p,I_ as q,u_ as r,k_ as s,T_ as t,f_ as u,C_ as v,b_ as w,g_ as x,__ as y,m_ as z};